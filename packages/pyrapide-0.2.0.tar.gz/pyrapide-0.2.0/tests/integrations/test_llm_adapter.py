import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.integrations.llm import (
    LLMEventAdapter,
    LLMEventTypes,
    MockLLMClient,
)


class TestLLMRequestEvent:
    async def test_llm_request_event(self):
        """Simulate LLM request. Event generated correctly."""
        client = MockLLMClient("gpt-test")
        adapter = LLMEventAdapter("llm-source", client=client)

        await client.request("Hello, world!")
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        request_events = [e for e in events if e.name == LLMEventTypes.REQUEST]
        assert len(request_events) == 1

        req = request_events[0]
        assert req.payload["prompt"] == "Hello, world!"
        assert req.payload["model"] == "gpt-test"
        assert req.source == "llm-source"

        # Should also have a response
        response_events = [e for e in events if e.name == LLMEventTypes.RESPONSE]
        assert len(response_events) == 1


class TestLLMCausalLink:
    async def test_llm_causal_link(self):
        """Request -> response causality via correlation_id metadata."""
        client = MockLLMClient("model-x")
        adapter = LLMEventAdapter("llm", client=client)

        await client.request("test prompt")
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        req = [e for e in events if e.name == LLMEventTypes.REQUEST][0]
        resp = [e for e in events if e.name == LLMEventTypes.RESPONSE][0]

        # Same correlation_id
        assert req.metadata["correlation_id"] == resp.metadata["correlation_id"]
        # Response points back to request
        assert resp.metadata["caused_by_id"] == req.id

        # Build computation with causal link
        comp = Computation()
        comp.record(req)
        comp.record(resp, caused_by=[req])
        assert comp.is_ancestor(req, resp)


class TestLLMStreamChunks:
    async def test_llm_stream_chunks(self):
        """Request -> multiple stream chunks, all caused by request."""
        client = MockLLMClient("model-y")
        adapter = LLMEventAdapter("llm", client=client)

        await client.request("streaming prompt", stream=True, num_chunks=3)
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        req = [e for e in events if e.name == LLMEventTypes.REQUEST][0]
        chunks = [e for e in events if e.name == LLMEventTypes.STREAM_CHUNK]
        resp = [e for e in events if e.name == LLMEventTypes.RESPONSE][0]

        assert len(chunks) == 3

        # All chunks should reference the request
        for chunk in chunks:
            assert chunk.metadata["caused_by_id"] == req.id
            assert chunk.metadata["correlation_id"] == req.metadata["correlation_id"]

        # Response also references the request
        assert resp.metadata["caused_by_id"] == req.id

        # Build computation: all chunks and response caused by request
        comp = Computation()
        comp.record(req)
        for chunk in chunks:
            comp.record(chunk, caused_by=[req])
        comp.record(resp, caused_by=[req])

        assert comp.is_ancestor(req, resp)
        for chunk in chunks:
            assert comp.is_ancestor(req, chunk)
