import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.core.poset import Poset
from pyrapide.patterns.base import Pattern, PatternMatch
from pyrapide.integrations.mcp import (
    MCPEventAdapter,
    MCPEventTypes,
    MCPPatterns,
    MockMCPClient,
)
from pyrapide.runtime.streaming import StreamProcessor


class TestMCPEventTypes:
    def test_mcp_event_types(self):
        """Assert all constant names are correct strings."""
        assert MCPEventTypes.TOOL_CALL == "mcp.tool_call"
        assert MCPEventTypes.TOOL_RESULT == "mcp.tool_result"
        assert MCPEventTypes.RESOURCE_READ == "mcp.resource_read"
        assert MCPEventTypes.ERROR == "mcp.error"
        assert MCPEventTypes.CONNECT == "mcp.connect"
        assert MCPEventTypes.DISCONNECT == "mcp.disconnect"


class TestMCPToolCallEvent:
    async def test_mcp_tool_call_event(self):
        """Simulate a tool call. Adapter yields an Event with correct name and payload."""
        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client=client)

        # Script a tool call (produces call + result)
        await client.call_tool("read_file", args={"path": "/tmp/test.txt"})
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        # Should have tool_call and tool_result
        call_events = [e for e in events if e.name == MCPEventTypes.TOOL_CALL]
        assert len(call_events) == 1

        call_evt = call_events[0]
        assert call_evt.payload["tool"] == "read_file"
        assert call_evt.payload["args"] == {"path": "/tmp/test.txt"}
        assert call_evt.payload["server"] == "test-server"
        assert call_evt.source == "test-server"


class TestMCPToolResultEvent:
    async def test_mcp_tool_result_event(self):
        """Simulate a tool result. Correct event generated."""
        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client=client)

        await client.call_tool("search", args={"query": "hello"})
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        result_events = [e for e in events if e.name == MCPEventTypes.TOOL_RESULT]
        assert len(result_events) == 1

        result_evt = result_events[0]
        assert result_evt.payload["tool"] == "search"
        assert "result" in result_evt.payload
        assert result_evt.payload["server"] == "test-server"


class TestMCPCausalLink:
    async def test_mcp_causal_link(self):
        """Simulate tool_call then tool_result. Assert tool_result is caused
        by tool_call in the computation via correlation_id metadata."""
        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client=client)

        await client.call_tool("execute", args={"cmd": "ls"})
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        call_evt = [e for e in events if e.name == MCPEventTypes.TOOL_CALL][0]
        result_evt = [e for e in events if e.name == MCPEventTypes.TOOL_RESULT][0]

        # Both share a correlation_id
        assert call_evt.metadata["correlation_id"] == result_evt.metadata["correlation_id"]
        # Result's caused_by_id points to the call
        assert result_evt.metadata["caused_by_id"] == call_evt.id

        # Build a computation with causal link
        comp = Computation()
        comp.record(call_evt)
        comp.record(result_evt, caused_by=[call_evt])
        assert comp.is_ancestor(call_evt, result_evt)


class TestMCPErrorEvent:
    async def test_mcp_error_event(self):
        """Simulate a tool error. Error event is caused by the tool_call."""
        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client=client)

        await client.call_tool_error("bad_tool", error="permission denied")
        await client.close()

        events = []
        async for event in adapter.events():
            events.append(event)

        call_events = [e for e in events if e.name == MCPEventTypes.TOOL_CALL]
        error_events = [e for e in events if e.name == MCPEventTypes.ERROR]

        assert len(call_events) == 1
        assert len(error_events) == 1

        call_evt = call_events[0]
        error_evt = error_events[0]

        assert error_evt.payload["error"] == "permission denied"
        assert error_evt.payload["tool"] == "bad_tool"
        assert error_evt.metadata["caused_by_id"] == call_evt.id


class TestMCPPatternsToolCall:
    def test_mcp_patterns_tool_call(self):
        """MCPPatterns.tool_call() matches mcp.tool_call events."""
        pattern = MCPPatterns.tool_call()
        poset = Poset()
        evt = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "read", "server": "s1"}, source="s1")
        poset.add(evt)

        matches = pattern.match_in(poset)
        assert len(matches) == 1
        assert evt in matches[0].events

    def test_mcp_patterns_tool_call_filtered(self):
        """MCPPatterns.tool_call(tool_name) filters by tool name."""
        pattern = MCPPatterns.tool_call("read")
        poset = Poset()
        evt1 = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "read"}, source="s1")
        evt2 = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "write"}, source="s1")
        poset.add(evt1)
        poset.add(evt2)

        matches = pattern.match_in(poset)
        assert len(matches) == 1
        assert evt1 in matches[0].events


class TestMCPPatternsRoundtrip:
    def test_mcp_patterns_roundtrip(self):
        """MCPPatterns.tool_roundtrip() matches call >> result sequence."""
        pattern = MCPPatterns.tool_roundtrip()
        comp = Computation()
        call_evt = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "test"}, source="s1")
        result_evt = Event(name=MCPEventTypes.TOOL_RESULT, payload={"tool": "test"}, source="s1")
        comp.record(call_evt)
        comp.record(result_evt, caused_by=[call_evt])

        matches = pattern.match_in(comp._poset)
        assert len(matches) >= 1


class TestMCPAdapterAsStreamSource:
    async def test_mcp_adapter_as_stream_source(self):
        """Use MCPEventAdapter with StreamProcessor. Events flow through."""
        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client=client)

        processor = StreamProcessor()
        processor.add_source("mcp", adapter)

        received: list[Event] = []

        async def on_evt(event: Event) -> None:
            received.append(event)

        processor.on_event(on_evt)

        # Script events
        await client.connect()
        await client.call_tool("list_files")
        await client.disconnect()
        await client.close()

        await processor.run()

        assert len(received) >= 4  # connect, tool_call, tool_result, disconnect
        names = [e.name for e in received]
        assert MCPEventTypes.CONNECT in names
        assert MCPEventTypes.TOOL_CALL in names
        assert MCPEventTypes.TOOL_RESULT in names
        assert MCPEventTypes.DISCONNECT in names


class TestMCPMultiServer:
    async def test_mcp_multi_server(self):
        """Two MCPEventAdapters for different servers. Events have distinct sources."""
        client1 = MockMCPClient("server-a")
        client2 = MockMCPClient("server-b")
        adapter1 = MCPEventAdapter("server-a", client=client1)
        adapter2 = MCPEventAdapter("server-b", client=client2)

        processor = StreamProcessor()
        processor.add_source("a", adapter1)
        processor.add_source("b", adapter2)

        received: list[Event] = []

        async def on_evt(event: Event) -> None:
            received.append(event)

        processor.on_event(on_evt)

        await client1.call_tool("tool_a")
        await client1.close()
        await client2.call_tool("tool_b")
        await client2.close()

        await processor.run()

        sources = {e.source for e in received}
        assert "server-a" in sources
        assert "server-b" in sources

        a_events = [e for e in received if e.source == "server-a"]
        b_events = [e for e in received if e.source == "server-b"]
        assert len(a_events) >= 2  # call + result
        assert len(b_events) >= 2


class TestMockMCPClient:
    async def test_mock_mcp_client(self):
        """MockMCPClient generates expected sequence of events."""
        client = MockMCPClient("test")

        await client.connect({"tools": True})
        await client.call_tool("search", {"q": "test"})
        await client.read_resource("file:///test.txt")
        await client.disconnect("shutdown")
        await client.close()

        raw_events = []
        async for raw in client.raw_events():
            raw_events.append(raw)

        types = [e["type"] for e in raw_events]
        assert types == ["connect", "tool_call", "tool_result", "resource_read", "disconnect"]

        # Check connect
        assert raw_events[0]["capabilities"] == {"tools": True}

        # Check tool call
        assert raw_events[1]["tool"] == "search"
        assert raw_events[1]["args"] == {"q": "test"}

        # Check tool result
        assert raw_events[2]["tool"] == "search"
        assert "result" in raw_events[2]

        # Check resource read
        assert raw_events[3]["uri"] == "file:///test.txt"

        # Check disconnect
        assert raw_events[4]["reason"] == "shutdown"
