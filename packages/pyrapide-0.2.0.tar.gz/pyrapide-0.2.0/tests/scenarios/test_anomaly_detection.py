"""End-to-end Scenario 3: Streaming Anomaly Detection Pipeline.

Validates the prediction engine, anomaly detection, and real-time
constraint monitoring working together.
"""

import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.types.actions import action
from pyrapide.types.interface import interface
from pyrapide.patterns.base import Pattern, PatternMatch
from pyrapide.runtime.streaming import StreamProcessor, InMemoryEventSource
from pyrapide.constraints.pattern_constraints import Never
from pyrapide.analysis.prediction import (
    AnomalyDetector,
    Anomaly,
    CausalPredictor,
    Prediction,
)


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

@interface
class SensorInterface:
    @action
    async def reading(self, sensor_id: str, value: float) -> None:
        pass

    @action
    async def alert(self, sensor_id: str, severity: str) -> None:
        pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reading_event(sensor_id: str, value: float) -> Event:
    return Event(
        name="SensorInterface.reading",
        payload={"sensor_id": sensor_id, "value": value},
        source=f"sensor_{sensor_id}",
    )


def _alert_event(sensor_id: str, severity: str) -> Event:
    return Event(
        name="SensorInterface.alert",
        payload={"sensor_id": sensor_id, "severity": severity},
        source=f"sensor_{sensor_id}",
    )


def _normal_computation(n_events: int = 100) -> Computation:
    """Build a normal computation: reading events with values in [10..90],
    each sensor generates independent readings, readings within the same
    sensor are causally chained.
    """
    import random
    rng = random.Random(42)
    comp = Computation()
    last_by_sensor: dict[str, Event] = {}

    for i in range(n_events):
        sensor_id = str((i % 5) + 1)
        value = rng.uniform(10.0, 90.0)
        evt = _reading_event(sensor_id, value)

        causes = []
        if sensor_id in last_by_sensor:
            causes = [last_by_sensor[sensor_id]]

        comp.record(evt, caused_by=causes or None)
        last_by_sensor[sensor_id] = evt

    return comp


def _anomalous_computation() -> Computation:
    """Build a computation with injected anomalies:
    - Sensor 3 generates value 500.0 (way out of range)
    - Sensor 5 reading causally depends on sensor 2 (unusual cross-sensor dep)
    - An unknown event type "sensor.malfunction" appears
    """
    comp = Computation()
    last_by_sensor: dict[str, Event] = {}

    # Some normal readings first
    for i in range(10):
        sensor_id = str((i % 5) + 1)
        evt = _reading_event(sensor_id, 50.0)
        causes = []
        if sensor_id in last_by_sensor:
            causes = [last_by_sensor[sensor_id]]
        comp.record(evt, caused_by=causes or None)
        last_by_sensor[sensor_id] = evt

    # Anomaly 1: Sensor 3 value way out of range
    outlier = _reading_event("3", 500.0)
    comp.record(outlier, caused_by=[last_by_sensor["3"]])
    last_by_sensor["3"] = outlier

    # Anomaly 2: Sensor 5 reading caused by sensor 2 (unusual cross-dependency)
    cross_dep = _reading_event("5", 45.0)
    comp.record(cross_dep, caused_by=[last_by_sensor["2"]])
    last_by_sensor["5"] = cross_dep

    # Anomaly 3: Unknown event type
    malfunction = Event(
        name="sensor.malfunction",
        payload={"sensor_id": "3", "reason": "hardware failure"},
        source="sensor_3",
    )
    comp.record(malfunction, caused_by=[last_by_sensor["3"]])

    return comp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAnomalyTrainAndDetect:
    def test_anomaly_train_and_detect(self):
        """Train on normal computations, detect anomalies in abnormal one."""
        detector = AnomalyDetector()

        # Train on 10 normal computations
        training_data = [_normal_computation(100) for _ in range(10)]
        detector.learn(training_data)

        # Detect anomalies in the anomalous computation
        anomalous = _anomalous_computation()
        anomalies = detector.detect(anomalous)

        # Should find at least 2: the unknown event type and the unusual cross-dep
        assert len(anomalies) >= 2

        # Check for unseen event type ("sensor.malfunction")
        unseen = [a for a in anomalies if a.anomaly_type == "unseen_event"]
        assert len(unseen) >= 1
        assert any(a.event.name == "sensor.malfunction" for a in unseen)

        # Check for unusual cause (sensor 2 -> sensor 5 reading)
        unusual = [a for a in anomalies if a.anomaly_type == "unusual_cause"]
        assert len(unusual) >= 1


class TestPredictionAfterTraining:
    def test_prediction_after_training(self):
        """Train predictor on normal patterns. Predict from partial computation."""
        predictor = CausalPredictor()

        # Train on normal computations
        for _ in range(10):
            predictor.learn(_normal_computation(100))

        # Give it a partial computation with a few reading events
        partial = Computation()
        e1 = _reading_event("1", 50.0)
        e2 = _reading_event("1", 55.0)
        partial.record(e1)
        partial.record(e2, caused_by=[e1])

        # Predict: should expect more reading events
        predictions = predictor.predict(partial)
        assert len(predictions) > 0

        # The predicted event should be a reading (that's all we trained on)
        assert predictions[0].event_name == "SensorInterface.reading"
        assert predictions[0].confidence > 0.5
        assert predictions[0].likely_cause == "SensorInterface.reading"


class TestStreamingAnomalyMonitoring:
    async def test_streaming_anomaly_monitoring(self):
        """StreamProcessor with 5 sensor sources. Constraint: never out-of-range.
        Feed normal events then inject anomaly. Assert violation detected.
        """
        processor = StreamProcessor()
        sources: dict[str, InMemoryEventSource] = {}
        for i in range(1, 6):
            src = InMemoryEventSource(f"sensor_{i}")
            sources[str(i)] = src
            processor.add_source(f"sensor_{i}", src)

        # Constraint: never a reading with value > 100 or < 0
        out_of_range_pattern = Pattern.match("SensorInterface.reading").where(
            lambda m: any(
                e.payload.get("value", 50) > 100 or e.payload.get("value", 50) < 0
                for e in m.events
            )
        )
        out_of_range_constraint = Never(
            out_of_range_pattern,
            name="no_out_of_range",
            description="Sensor readings must be in [0, 100]",
        )
        processor.enforce(out_of_range_constraint)

        # Track violations
        violations_detected: list = []
        processor.on_violation(lambda v: violations_detected.append(v))

        async def feed_events():
            # Normal readings
            for i in range(1, 6):
                for _ in range(3):
                    await sources[str(i)].put(_reading_event(str(i), 50.0))

            # Inject anomaly: sensor 3 with value 500
            await sources["3"].put(_reading_event("3", 500.0))

            # Close all sources
            for src in sources.values():
                await src.close()

        feed_task = asyncio.create_task(feed_events())
        await processor.run()
        await feed_task

        # Should have detected at least one violation (the out-of-range reading)
        assert len(violations_detected) >= 1
        assert any(v.constraint_name == "no_out_of_range" for v in violations_detected)

        # Computation should have all events
        comp = processor.computation
        # 5 sensors * 3 normal + 1 anomaly = 16
        assert len(comp) == 16


class TestAnomalySeverityRanking:
    def test_anomaly_severity_ranking(self):
        """Multiple anomalies of different types have different severity scores."""
        detector = AnomalyDetector()

        # Train on normal data
        detector.learn([_normal_computation(100) for _ in range(10)])

        # Create computation with multiple anomaly types
        comp = _anomalous_computation()
        anomalies = detector.detect(comp)

        assert len(anomalies) >= 2

        # All severities should be between 0 and 1
        for a in anomalies:
            assert 0.0 <= a.severity <= 1.0

        # Unseen events should have higher severity than unusual causes
        unseen_severities = [a.severity for a in anomalies if a.anomaly_type == "unseen_event"]
        unusual_severities = [a.severity for a in anomalies if a.anomaly_type == "unusual_cause"]

        if unseen_severities and unusual_severities:
            assert max(unseen_severities) > min(unusual_severities)

        # Anomalies should be sortable by severity (descending)
        sorted_anomalies = sorted(anomalies, key=lambda a: -a.severity)
        for i in range(len(sorted_anomalies) - 1):
            assert sorted_anomalies[i].severity >= sorted_anomalies[i + 1].severity


class TestFullPipeline:
    async def test_full_pipeline(self):
        """Train -> Stream -> Detect -> Predict in sequence.
        Full pipeline: stream events, detect anomalies, predict next events.
        """
        # Phase 1: Train on normal data
        predictor = CausalPredictor()
        detector = AnomalyDetector()

        training_comps = [_normal_computation(100) for _ in range(10)]
        for comp in training_comps:
            predictor.learn(comp)
        detector.learn(training_comps)

        # Phase 2: Stream live events
        processor = StreamProcessor()
        sources: dict[str, InMemoryEventSource] = {}
        for i in range(1, 4):  # 3 sensors for simplicity
            src = InMemoryEventSource(f"sensor_{i}")
            sources[str(i)] = src
            processor.add_source(f"sensor_{i}", src)

        # Constraint: no out-of-range values
        out_of_range_pattern = Pattern.match("SensorInterface.reading").where(
            lambda m: any(
                e.payload.get("value", 50) > 100 or e.payload.get("value", 50) < 0
                for e in m.events
            )
        )
        processor.enforce(Never(out_of_range_pattern, name="no_out_of_range"))

        violations: list = []
        processor.on_violation(lambda v: violations.append(v))

        async def feed():
            # Normal readings
            for i in range(1, 4):
                for _ in range(5):
                    await sources[str(i)].put(_reading_event(str(i), 50.0))
            # One anomaly
            await sources["2"].put(_reading_event("2", 999.0))
            # Close
            for src in sources.values():
                await src.close()

        feed_task = asyncio.create_task(feed())
        await processor.run()
        await feed_task

        live_comp = processor.computation

        # Phase 3: Detect anomalies in the streamed data
        # Build a computation with causal chains for detection
        detection_comp = Computation()
        last_by_sensor: dict[str, Event] = {}
        for evt in live_comp.topological_order():
            sensor_id = evt.payload.get("sensor_id", "")
            causes = []
            if sensor_id in last_by_sensor:
                causes = [last_by_sensor[sensor_id]]
            detection_comp.record(evt, caused_by=causes or None)
            last_by_sensor[sensor_id] = evt

        anomalies = detector.detect(detection_comp)
        # The 999.0 reading is within known event types, but we should detect
        # no unseen_event anomalies (all types are normal "SensorInterface.reading")
        # The streaming violation is caught by the Never constraint

        # Phase 4: Predict next events
        predictions = predictor.predict(detection_comp)
        assert len(predictions) > 0
        assert predictions[0].event_name == "SensorInterface.reading"

        # Verify stream caught the constraint violation
        assert len(violations) >= 1

        # Verify computation is coherent
        assert len(live_comp) == 16  # 3 sensors * 5 + 1 anomaly

        # Full pipeline interaction: all components ran without errors
        stats = processor.stats
        assert stats["event_count"] == 16
        assert stats["violation_count"] >= 1
