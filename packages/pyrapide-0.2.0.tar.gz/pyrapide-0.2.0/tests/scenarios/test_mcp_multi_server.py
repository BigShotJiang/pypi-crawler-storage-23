"""End-to-end Scenario 2: MCP Multi-Server Orchestration.

Validates the MCP integration, streaming processor, constraints, and
causal tracing across multiple concurrent servers.
"""

import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.integrations.mcp import (
    MCPEventAdapter,
    MCPEventTypes,
    MCPPatterns,
    MockMCPClient,
)
from pyrapide.integrations.llm import LLMEventTypes
from pyrapide.runtime.streaming import StreamProcessor
from pyrapide.constraints.pattern_constraints import MustMatch, Never
from pyrapide.analysis.queries import (
    causal_distance,
    parallel_events,
    root_causes,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _feed_tool_server(client: MockMCPClient, n: int = 5) -> None:
    """Feed n tool_call+tool_result pairs into the client, then close."""
    for i in range(n):
        await client.call_tool(f"tool_{i}")
    await client.close()


async def _feed_resource_server(client: MockMCPClient, n: int = 3) -> None:
    """Feed n resource_read events into the client, then close."""
    for i in range(n):
        await client.read_resource(f"file://resource_{i}")
    await client.close()


async def _feed_memory_server(client: MockMCPClient, n: int = 2) -> None:
    """Feed n memory_store tool_call+tool_result pairs, then close."""
    for i in range(n):
        await client.call_tool(f"memory_store_{i}")
    await client.close()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestMCPThreeServersStreaming:
    async def test_mcp_three_servers_streaming(self):
        """Create StreamProcessor with 3 MCPEventAdapters.
        Feed events from all 3 servers. Assert all roundtrips detected,
        no constraint violations, correct causal links.
        """
        # Set up 3 mock MCP servers
        tool_client = MockMCPClient("tool-server")
        resource_client = MockMCPClient("resource-server")
        memory_client = MockMCPClient("memory-server")

        tool_adapter = MCPEventAdapter("tool-server", tool_client)
        resource_adapter = MCPEventAdapter("resource-server", resource_client)
        memory_adapter = MCPEventAdapter("memory-server", memory_client)

        # Track roundtrip matches via individual event watches
        tool_call_events: list[Event] = []
        tool_result_events: list[Event] = []

        def on_event(event: Event) -> None:
            if event.name == MCPEventTypes.TOOL_CALL:
                tool_call_events.append(event)
            elif event.name == MCPEventTypes.TOOL_RESULT:
                tool_result_events.append(event)

        # Set up processor
        processor = StreamProcessor()
        processor.add_source("tool-server", tool_adapter)
        processor.add_source("resource-server", resource_adapter)
        processor.add_source("memory-server", memory_adapter)
        processor.on_event(on_event)

        # Feed events concurrently with processing
        async def feed_all():
            await asyncio.gather(
                _feed_tool_server(tool_client, 5),
                _feed_resource_server(resource_client, 3),
                _feed_memory_server(memory_client, 2),
            )

        feed_task = asyncio.create_task(feed_all())
        await processor.run()
        await feed_task

        comp = processor.computation

        # 5 tool calls + 5 results + 3 resource reads + 2 memory calls + 2 results = 17
        assert len(comp) == 17

        # 7 tool call events (5 tool + 2 memory)
        assert len(tool_call_events) == 7
        # 7 tool result events (5 tool + 2 memory)
        assert len(tool_result_events) == 7

        # Resource reads
        resource_events = [e for e in comp.events if e.name == MCPEventTypes.RESOURCE_READ]
        assert len(resource_events) == 3

        # Verify each tool_call has a matching tool_result via correlation_id
        calls_by_corr: dict[str, Event] = {}
        results_by_corr: dict[str, Event] = {}
        for e in comp.events:
            corr = e.metadata.get("correlation_id", "")
            if not corr:
                continue
            if e.name == MCPEventTypes.TOOL_CALL:
                calls_by_corr[corr] = e
            elif e.name == MCPEventTypes.TOOL_RESULT:
                results_by_corr[corr] = e

        # Every tool_call correlation_id should have a matching result
        for corr_id in calls_by_corr:
            assert corr_id in results_by_corr, (
                f"Tool call with correlation_id {corr_id} has no matching result"
            )

        # Verify caused_by_id metadata links results back to calls
        for corr_id, result_event in results_by_corr.items():
            call_event = calls_by_corr[corr_id]
            caused_by_id = result_event.metadata.get("caused_by_id", "")
            assert caused_by_id == call_event.id


class TestMCPConstraintViolation:
    async def test_mcp_constraint_violation(self):
        """Same setup but one ToolServer tool_call does NOT get a result.
        Assert MustMatch detects the unpaired call.
        """
        # Build a computation with an orphan tool_call (no result)
        comp = Computation()

        # A complete roundtrip
        call1 = Event(
            name=MCPEventTypes.TOOL_CALL,
            payload={"tool": "read_file"},
            source="tool-server",
        )
        result1 = Event(
            name=MCPEventTypes.TOOL_RESULT,
            payload={"tool": "read_file"},
            source="tool-server",
        )
        comp.record(call1)
        comp.record(result1, caused_by=[call1])

        # An orphan tool_call with no result
        orphan_call = Event(
            name=MCPEventTypes.TOOL_CALL,
            payload={"tool": "write_file"},
            source="tool-server",
        )
        comp.record(orphan_call)

        # Check the roundtrip constraint
        roundtrip_constraint = MustMatch(
            MCPPatterns.tool_roundtrip(),
            name="every_call_gets_result",
        )

        # The constraint should be satisfied (at least one roundtrip exists)
        violations = roundtrip_constraint.check(comp)
        assert len(violations) == 0  # MustMatch just requires at least one match

        # Now test with a computation that has NO roundtrips at all
        orphan_comp = Computation()
        orphan_call2 = Event(
            name=MCPEventTypes.TOOL_CALL,
            payload={"tool": "write_file"},
            source="tool-server",
        )
        orphan_comp.record(orphan_call2)

        violations = roundtrip_constraint.check(orphan_comp)
        assert len(violations) > 0
        assert violations[0].constraint_name == "every_call_gets_result"


class TestMCPCausalTracing:
    async def test_mcp_causal_tracing(self):
        """Simulate: LLM request -> tool_call -> resource_read -> tool_result -> LLM response.
        Assert full causal chain is traceable.
        """
        comp = Computation()

        llm_request = Event(
            name=LLMEventTypes.REQUEST,
            payload={"prompt": "analyze data"},
            source="llm",
        )
        tool_call = Event(
            name=MCPEventTypes.TOOL_CALL,
            payload={"tool": "read_data"},
            source="tool-server",
        )
        resource_read = Event(
            name=MCPEventTypes.RESOURCE_READ,
            payload={"uri": "file://data.csv"},
            source="resource-server",
        )
        tool_result = Event(
            name=MCPEventTypes.TOOL_RESULT,
            payload={"tool": "read_data", "result": {"data": "..."}},
            source="tool-server",
        )
        llm_response = Event(
            name=LLMEventTypes.RESPONSE,
            payload={"result": {"text": "analysis complete"}},
            source="llm",
        )

        comp.record(llm_request)
        comp.record(tool_call, caused_by=[llm_request])
        comp.record(resource_read, caused_by=[tool_call])
        comp.record(tool_result, caused_by=[resource_read])
        comp.record(llm_response, caused_by=[tool_result])

        # Full causal chain should be traceable
        chain = comp.causal_chain(llm_request, llm_response)
        assert chain is not None
        assert len(chain) == 5
        assert chain[0] == llm_request
        assert chain[1] == tool_call
        assert chain[2] == resource_read
        assert chain[3] == tool_result
        assert chain[4] == llm_response

        # Causal distance from request to response
        dist = causal_distance(comp, llm_request, llm_response)
        assert dist == 4

        # LLM request is ancestor of everything
        assert comp.is_ancestor(llm_request, llm_response)
        assert comp.is_ancestor(llm_request, tool_call)
        assert comp.is_ancestor(tool_call, tool_result)


class TestMCPParallelEvents:
    async def test_mcp_parallel_events(self):
        """Two tool calls happening independently (from different prompts).
        Assert they are causally independent.
        """
        comp = Computation()

        # Prompt 1 chain
        req1 = Event(name=LLMEventTypes.REQUEST, payload={"prompt": "p1"}, source="llm")
        call1 = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "t1"}, source="server-a")
        comp.record(req1)
        comp.record(call1, caused_by=[req1])

        # Prompt 2 chain (independent)
        req2 = Event(name=LLMEventTypes.REQUEST, payload={"prompt": "p2"}, source="llm")
        call2 = Event(name=MCPEventTypes.TOOL_CALL, payload={"tool": "t2"}, source="server-b")
        comp.record(req2)
        comp.record(call2, caused_by=[req2])

        # The two chains should be causally independent
        assert comp.are_independent(call1, call2)
        assert comp.are_independent(req1, req2)
        assert comp.are_independent(req1, call2)

        # parallel_events should find them
        groups = parallel_events(comp)
        all_parallel = set()
        for group in groups:
            all_parallel.update(group)

        # At least the two tool calls should appear as parallel
        assert call1 in all_parallel or call2 in all_parallel


class TestMCPRootCauseAnalysis:
    async def test_mcp_root_cause_analysis(self):
        """Simulate an error event. Use root_causes() to trace back to
        the originating tool_call.
        """
        comp = Computation()

        # Root: tool_call
        tool_call = Event(
            name=MCPEventTypes.TOOL_CALL,
            payload={"tool": "risky_operation"},
            source="tool-server",
        )
        comp.record(tool_call)

        # Intermediate processing
        processing = Event(
            name="internal.processing",
            payload={"step": "validate"},
            source="tool-server",
        )
        comp.record(processing, caused_by=[tool_call])

        # Error occurs
        error = Event(
            name=MCPEventTypes.ERROR,
            payload={"tool": "risky_operation", "error": "validation failed"},
            source="tool-server",
        )
        comp.record(error, caused_by=[processing])

        # Root cause analysis should trace back to the tool_call
        roots = root_causes(comp, error)
        assert tool_call in roots
        assert len(roots) == 1

        # Causal chain from tool_call to error
        chain = comp.causal_chain(tool_call, error)
        assert chain is not None
        assert len(chain) == 3
        assert chain[0] == tool_call
        assert chain[1] == processing
        assert chain[2] == error
