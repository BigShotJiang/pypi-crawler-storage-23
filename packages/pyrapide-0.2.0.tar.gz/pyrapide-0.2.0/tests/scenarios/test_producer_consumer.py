"""End-to-end Scenario 1: Producer-Consumer Pipeline.

Classic RAPIDE example: a producer generates items that flow through a
connection to a consumer.  Validates that the full stack works together:
interfaces, modules, architecture, connections, patterns, and the engine.
"""

import pytest

from pyrapide.types.actions import action
from pyrapide.types.interface import interface
from pyrapide.executable.module import module, get_context
from pyrapide.executable.reactive import when
from pyrapide.patterns.base import Pattern, PatternMatch, placeholder
from pyrapide.architecture.architecture import architecture
from pyrapide.architecture.connections import connect
from pyrapide.runtime.engine import Engine
from pyrapide.analysis.visualization import to_dot


# ---------------------------------------------------------------------------
# Interfaces
# ---------------------------------------------------------------------------

@interface
class ProducerInterface:
    @action
    async def produce(self, item: str) -> None:
        pass


@interface
class ConsumerInterface:
    @action
    async def consume(self, item: str) -> None:
        pass


# ---------------------------------------------------------------------------
# Modules
# ---------------------------------------------------------------------------

@module(implements=ProducerInterface)
class ProducerModule:
    async def start(self):
        ctx = get_context(self)
        for i in range(1, 6):
            ctx.generate_event(
                "ProducerInterface.produce",
                payload={"item": f"item_{i}"},
            )


@module(implements=ConsumerInterface)
class ConsumerModule:
    @when(Pattern.match("ProducerInterface.produce"))
    async def on_produce(self, match: PatternMatch):
        ctx = get_context(self)
        event = list(match.events)[0]
        item = event.payload.get("item", "")
        ctx.generate_event(
            "ConsumerInterface.consume",
            payload={"item": item},
            caused_by=list(match.events),
        )


# ---------------------------------------------------------------------------
# Architecture
# ---------------------------------------------------------------------------

@architecture
class ProducerConsumerArch:
    producer: ProducerInterface
    consumer: ConsumerInterface

    def connections(self):
        return [
            connect(Pattern.match("ProducerInterface.produce"), "consumer"),
        ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestProducerConsumerPipeline:
    async def test_producer_consumer_pipeline(self):
        """Instantiate with Engine. Run architecture.
        Assert computation has 10 events (5 produce + 5 consume).
        Assert each produce event causes the corresponding consume event.
        Assert causal depth is 1 for each produce->consume pair.
        """
        engine = Engine()
        arch = ProducerConsumerArch()
        engine.bind(arch, "producer", ProducerModule)
        engine.bind(arch, "consumer", ConsumerModule)

        computation = await engine.run(arch, timeout=5.0)

        # 5 produce + 5 consume = 10 events
        produce_events = [e for e in computation.events if e.name == "ProducerInterface.produce"]
        consume_events = [e for e in computation.events if e.name == "ConsumerInterface.consume"]

        assert len(produce_events) == 5, f"Expected 5 produce events, got {len(produce_events)}"
        assert len(consume_events) == 5, f"Expected 5 consume events, got {len(consume_events)}"
        assert len(computation) == 10

        # Each produce event should cause a corresponding consume event with the same item
        produce_by_item = {e.payload["item"]: e for e in produce_events}
        consume_by_item = {e.payload["item"]: e for e in consume_events}

        for item in [f"item_{i}" for i in range(1, 6)]:
            assert item in produce_by_item, f"Missing produce event for {item}"
            assert item in consume_by_item, f"Missing consume event for {item}"
            p = produce_by_item[item]
            c = consume_by_item[item]
            assert computation.is_ancestor(p, c), (
                f"Produce({item}) should cause Consume({item})"
            )

        # FIFO order: each produce is matched to the consume with the same item
        # (the pipe preserves the produce→consume pairing)
        consume_ordered = computation.topological_order()
        consume_in_order = [e for e in consume_ordered if e.name == "ConsumerInterface.consume"]
        consumed_items = [e.payload["item"] for e in consume_in_order]
        assert set(consumed_items) == {f"item_{i}" for i in range(1, 6)}

        # Causal depth of 1 for each produce->consume pair
        from pyrapide.analysis.queries import causal_distance
        for item in [f"item_{i}" for i in range(1, 6)]:
            p = produce_by_item[item]
            c = consume_by_item[item]
            dist = causal_distance(computation, p, c)
            assert dist == 1, f"Expected causal distance 1 for {item}, got {dist}"

    async def test_producer_consumer_poset_structure(self):
        """Verify root_events are the 5 produce events.
        Verify leaf_events are the 5 consume events.
        Verify all produce-consume pairs have correct causal links.
        """
        engine = Engine()
        arch = ProducerConsumerArch()
        engine.bind(arch, "producer", ProducerModule)
        engine.bind(arch, "consumer", ConsumerModule)

        computation = await engine.run(arch, timeout=5.0)

        roots = computation.root_events()
        leaves = computation.leaf_events()

        # All roots should be produce events
        assert len(roots) == 5
        root_names = {e.name for e in roots}
        assert root_names == {"ProducerInterface.produce"}

        # All leaves should be consume events
        assert len(leaves) == 5
        leaf_names = {e.name for e in leaves}
        assert leaf_names == {"ConsumerInterface.consume"}

        # Each produce event should have exactly one consume descendant with matching item
        produce_events = [e for e in computation.events if e.name == "ProducerInterface.produce"]
        consume_events = [e for e in computation.events if e.name == "ConsumerInterface.consume"]

        for p in produce_events:
            descendants = computation.descendants(p)
            consume_descendants = [d for d in descendants if d.name == "ConsumerInterface.consume"]
            assert len(consume_descendants) == 1, (
                f"Produce({p.payload['item']}) should have exactly 1 consume descendant"
            )
            assert consume_descendants[0].payload["item"] == p.payload["item"]

    async def test_producer_consumer_visualization(self):
        """Generate DOT visualization of the computation.
        Assert it's valid DOT syntax (contains 'digraph', all 10 event nodes, 5 edges).
        """
        engine = Engine()
        arch = ProducerConsumerArch()
        engine.bind(arch, "producer", ProducerModule)
        engine.bind(arch, "consumer", ConsumerModule)

        computation = await engine.run(arch, timeout=5.0)

        dot = to_dot(computation)

        # Valid DOT syntax
        assert "digraph" in dot
        assert dot.strip().endswith("}")

        # All event names should appear
        assert "ProducerInterface.produce" in dot
        assert "ConsumerInterface.consume" in dot

        # Should have edges (->)
        arrow_count = dot.count("->")
        assert arrow_count >= 5, f"Expected at least 5 edges, got {arrow_count}"

        # All event nodes should be present (10 events = 10 node definitions)
        produce_events = [e for e in computation.events if e.name == "ProducerInterface.produce"]
        consume_events = [e for e in computation.events if e.name == "ConsumerInterface.consume"]
        for e in produce_events + consume_events:
            assert e.id in dot, f"Event {e.id[:8]} not found in DOT output"
