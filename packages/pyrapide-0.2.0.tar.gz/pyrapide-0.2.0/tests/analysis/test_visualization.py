import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.analysis.visualization import (
    to_dot,
    to_mermaid,
    to_json,
    to_ascii,
    summary,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make(name: str, source: str = "test") -> Event:
    return Event(name=name, source=source)


def _simple_computation() -> tuple[Computation, list[Event]]:
    """Build: Send(client) -> Process(server) -> Reply(server)."""
    comp = Computation()
    e1 = _make("Send", source="client")
    e2 = _make("Process", source="server")
    e3 = _make("Reply", source="server")
    comp.record(e1)
    comp.record(e2, caused_by=[e1])
    comp.record(e3, caused_by=[e2])
    return comp, [e1, e2, e3]


def _diamond() -> tuple[Computation, list[Event]]:
    comp = Computation()
    root = _make("Root", "src")
    a = _make("A", "worker1")
    b = _make("B", "worker2")
    leaf = _make("Leaf", "sink")
    comp.record(root)
    comp.record(a, caused_by=[root])
    comp.record(b, caused_by=[root])
    comp.record(leaf, caused_by=[a, b])
    return comp, [root, a, b, leaf]


# ---------------------------------------------------------------------------
# Tests: to_dot
# ---------------------------------------------------------------------------

class TestToDot:
    def test_to_dot_basic(self):
        """Generate DOT string from a simple poset. Contains digraph, nodes, edges."""
        comp, events = _simple_computation()
        dot = to_dot(comp)

        assert "digraph" in dot
        # Should contain node labels with event names
        assert "Send" in dot
        assert "Process" in dot
        assert "Reply" in dot
        # Should contain edges (->)
        assert "->" in dot

    def test_to_dot_highlight(self):
        """Highlighted events have different color attribute."""
        comp, events = _simple_computation()
        highlight = {events[1]}  # Highlight "Process"
        dot = to_dot(comp, highlight=highlight)

        assert "digraph" in dot
        # Highlighted node should have a distinct color
        assert "red" in dot or "fillcolor" in dot

    def test_to_dot_filter_event_types(self):
        """Only specified event types appear."""
        comp, events = _simple_computation()
        dot = to_dot(comp, event_types={"Send", "Reply"})

        assert "Send" in dot
        assert "Reply" in dot
        # "Process" should be filtered out
        assert "Process" not in dot

    def test_to_dot_max_events(self):
        """More events than max_events. Output is truncated with a note."""
        comp = Computation()
        for i in range(20):
            comp.record(_make(f"E{i}"))

        dot = to_dot(comp, max_events=5)
        assert "digraph" in dot
        assert "truncated" in dot.lower() or "..." in dot or "showing" in dot.lower()


# ---------------------------------------------------------------------------
# Tests: to_mermaid
# ---------------------------------------------------------------------------

class TestToMermaid:
    def test_to_mermaid_basic(self):
        """Generate Mermaid string. Contains 'graph TD' and node definitions."""
        comp, events = _simple_computation()
        mmd = to_mermaid(comp)

        assert "graph TD" in mmd
        assert "Send" in mmd
        assert "Process" in mmd
        assert "Reply" in mmd
        # Should contain edges (-->)
        assert "-->" in mmd


# ---------------------------------------------------------------------------
# Tests: to_json
# ---------------------------------------------------------------------------

class TestToJson:
    def test_to_json_structure(self):
        """JSON dict has 'events', 'edges', 'metadata' keys."""
        comp, events = _simple_computation()
        data = to_json(comp)

        assert "events" in data
        assert "edges" in data
        assert "metadata" in data
        assert isinstance(data["events"], list)
        assert isinstance(data["edges"], list)
        assert isinstance(data["metadata"], dict)
        assert data["metadata"]["event_count"] == 3
        assert data["metadata"]["edge_count"] == 2

    def test_to_json_roundtrip(self):
        """Events and edges in JSON match the original computation."""
        comp, events = _simple_computation()
        data = to_json(comp)

        event_ids = {e["id"] for e in data["events"]}
        assert len(event_ids) == 3

        # All original event IDs should be present
        for e in events:
            assert e.id in event_ids

        # Edges should reflect the causal links
        edge_pairs = {(edge["from"], edge["to"]) for edge in data["edges"]}
        assert (events[0].id, events[1].id) in edge_pairs
        assert (events[1].id, events[2].id) in edge_pairs


# ---------------------------------------------------------------------------
# Tests: to_ascii
# ---------------------------------------------------------------------------

class TestToAscii:
    def test_to_ascii(self):
        """ASCII output is a non-empty string containing event names."""
        comp, events = _simple_computation()
        text = to_ascii(comp)

        assert isinstance(text, str)
        assert len(text) > 0
        assert "Send" in text
        assert "Process" in text
        assert "Reply" in text


# ---------------------------------------------------------------------------
# Tests: summary
# ---------------------------------------------------------------------------

class TestSummary:
    def test_summary(self):
        """Summary string contains event count and depth."""
        comp, events = _simple_computation()
        text = summary(comp)

        assert "3 events" in text
        assert "2 causal edges" in text
        # Depth of a 3-event chain is 2
        assert "depth 2" in text


# ---------------------------------------------------------------------------
# Tests: empty computation
# ---------------------------------------------------------------------------

class TestEmptyComputation:
    def test_empty_computation_viz(self):
        """All viz functions handle empty computation without error."""
        comp = Computation()

        dot = to_dot(comp)
        assert isinstance(dot, str)
        assert "digraph" in dot

        mmd = to_mermaid(comp)
        assert isinstance(mmd, str)
        assert "graph TD" in mmd

        data = to_json(comp)
        assert data["metadata"]["event_count"] == 0
        assert data["events"] == []
        assert data["edges"] == []

        text = to_ascii(comp)
        assert isinstance(text, str)

        s = summary(comp)
        assert "0 events" in s
