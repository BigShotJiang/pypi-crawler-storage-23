import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.analysis.queries import (
    critical_path,
    root_causes,
    impact_set,
    causal_distance,
    common_ancestors,
    backward_slice,
    forward_slice,
    parallel_events,
    bottleneck_events,
    event_frequency,
    causal_density,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make(name: str, source: str = "test") -> Event:
    return Event(name=name, source=source)


def _linear_chain(n: int) -> tuple[Computation, list[Event]]:
    """Build a linear chain: e0 -> e1 -> ... -> e(n-1)."""
    comp = Computation()
    events = [_make(f"E{i}") for i in range(n)]
    comp.record(events[0])
    for i in range(1, n):
        comp.record(events[i], caused_by=[events[i - 1]])
    return comp, events


def _diamond() -> tuple[Computation, list[Event]]:
    """Build a diamond poset: root -> a, root -> b, a -> leaf, b -> leaf."""
    comp = Computation()
    root = _make("Root")
    a = _make("A")
    b = _make("B")
    leaf = _make("Leaf")
    comp.record(root)
    comp.record(a, caused_by=[root])
    comp.record(b, caused_by=[root])
    comp.record(leaf, caused_by=[a, b])
    return comp, [root, a, b, leaf]


# ---------------------------------------------------------------------------
# Tests: critical_path
# ---------------------------------------------------------------------------

class TestCriticalPath:
    def test_critical_path_linear(self):
        """Chain of 5. Critical path is the full chain."""
        comp, events = _linear_chain(5)
        path = critical_path(comp)
        assert len(path) == 5
        # Should be in causal order
        for i in range(len(path) - 1):
            assert comp.is_ancestor(path[i], path[i + 1])

    def test_critical_path_diamond(self):
        """Diamond poset. Critical path is length 3 (root -> a/b -> leaf)."""
        comp, [root, a, b, leaf] = _diamond()
        path = critical_path(comp)
        # Longest path in diamond is 3 events (length 2 edges): root -> a -> leaf or root -> b -> leaf
        assert len(path) == 3
        assert path[0] == root
        assert path[-1] == leaf


# ---------------------------------------------------------------------------
# Tests: root_causes
# ---------------------------------------------------------------------------

class TestRootCauses:
    def test_root_causes(self):
        """Event at bottom of diamond. Root causes is the single root."""
        comp, [root, a, b, leaf] = _diamond()
        roots = root_causes(comp, leaf)
        assert roots == frozenset({root})

    def test_root_causes_multiple_roots(self):
        """Two independent chains merge. Both roots returned."""
        comp = Computation()
        r1 = _make("R1")
        r2 = _make("R2")
        mid = _make("Mid")
        comp.record(r1)
        comp.record(r2)
        comp.record(mid, caused_by=[r1, r2])

        roots = root_causes(comp, mid)
        assert roots == frozenset({r1, r2})


# ---------------------------------------------------------------------------
# Tests: impact_set
# ---------------------------------------------------------------------------

class TestImpactSet:
    def test_impact_set(self):
        """Root event in diamond. Impact set includes all other events."""
        comp, [root, a, b, leaf] = _diamond()
        impact = impact_set(comp, root)
        assert impact == frozenset({a, b, leaf})


# ---------------------------------------------------------------------------
# Tests: causal_distance
# ---------------------------------------------------------------------------

class TestCausalDistance:
    def test_causal_distance_direct(self):
        """Distance 1 for directly connected events."""
        comp, events = _linear_chain(3)
        assert causal_distance(comp, events[0], events[1]) == 1

    def test_causal_distance_transitive(self):
        """Distance 2 for A -> B -> C from A to C."""
        comp, events = _linear_chain(3)
        assert causal_distance(comp, events[0], events[2]) == 2

    def test_causal_distance_none(self):
        """Independent events. Distance is None."""
        comp = Computation()
        e1 = _make("E1")
        e2 = _make("E2")
        comp.record(e1)
        comp.record(e2)
        assert causal_distance(comp, e1, e2) is None


# ---------------------------------------------------------------------------
# Tests: common_ancestors
# ---------------------------------------------------------------------------

class TestCommonAncestors:
    def test_common_ancestors(self):
        """Diamond: a and b share root as common ancestor."""
        comp, [root, a, b, leaf] = _diamond()
        common = common_ancestors(comp, a, b)
        assert root in common


# ---------------------------------------------------------------------------
# Tests: backward_slice / forward_slice
# ---------------------------------------------------------------------------

class TestSlicing:
    def test_backward_slice(self):
        """Slice from leaf of diamond. Contains all 4 events."""
        comp, [root, a, b, leaf] = _diamond()
        sliced = backward_slice(comp, leaf)
        assert len(sliced) == 4
        assert sliced.is_ancestor(root, leaf)
        assert sliced.is_ancestor(a, leaf)
        assert sliced.is_ancestor(b, leaf)

    def test_forward_slice(self):
        """Slice from root of diamond. Contains all 4 events."""
        comp, [root, a, b, leaf] = _diamond()
        sliced = forward_slice(comp, root)
        assert len(sliced) == 4
        assert sliced.is_ancestor(root, leaf)

    def test_backward_slice_partial(self):
        """Slice from middle of chain. Contains only ancestors + target."""
        comp, events = _linear_chain(5)
        sliced = backward_slice(comp, events[2])
        assert len(sliced) == 3  # e0, e1, e2
        assert events[0] in sliced.events
        assert events[1] in sliced.events
        assert events[2] in sliced.events
        assert events[3] not in sliced.events

    def test_forward_slice_partial(self):
        """Slice from middle of chain. Contains only descendants + source."""
        comp, events = _linear_chain(5)
        sliced = forward_slice(comp, events[2])
        assert len(sliced) == 3  # e2, e3, e4
        assert events[2] in sliced.events
        assert events[3] in sliced.events
        assert events[4] in sliced.events
        assert events[0] not in sliced.events


# ---------------------------------------------------------------------------
# Tests: parallel_events
# ---------------------------------------------------------------------------

class TestParallelEvents:
    def test_parallel_events(self):
        """Two independent event groups identified."""
        comp = Computation()
        a1 = _make("A1")
        a2 = _make("A2")
        b1 = _make("B1")
        b2 = _make("B2")
        comp.record(a1)
        comp.record(a2, caused_by=[a1])
        comp.record(b1)
        comp.record(b2, caused_by=[b1])

        groups = parallel_events(comp)
        # Should find at least one group with independent events
        # a1 and b1 are independent, a2 and b2 are independent, etc.
        all_parallel = set()
        for group in groups:
            if len(group) > 1:
                all_parallel.update(group)

        # At least some events should appear in parallel groups
        assert len(all_parallel) > 0

        # Verify all events in each group are actually independent
        for group in groups:
            event_list = list(group)
            for i in range(len(event_list)):
                for j in range(i + 1, len(event_list)):
                    assert comp.are_independent(event_list[i], event_list[j])


# ---------------------------------------------------------------------------
# Tests: bottleneck_events
# ---------------------------------------------------------------------------

class TestBottleneck:
    def test_bottleneck_linear(self):
        """Linear chain: every event is a bottleneck."""
        comp, events = _linear_chain(4)
        bottlenecks = bottleneck_events(comp)
        assert set(bottlenecks) == set(events)

    def test_bottleneck_diamond(self):
        """Diamond: root and leaf are bottlenecks, a and b are not."""
        comp, [root, a, b, leaf] = _diamond()
        bottlenecks = bottleneck_events(comp)
        assert root in bottlenecks
        assert leaf in bottlenecks
        # a and b are not bottlenecks because paths can go through either
        assert a not in bottlenecks
        assert b not in bottlenecks


# ---------------------------------------------------------------------------
# Tests: event_frequency
# ---------------------------------------------------------------------------

class TestEventFrequency:
    def test_event_frequency(self):
        """3 'Send' and 2 'Receive' events. Counts correct."""
        comp = Computation()
        for i in range(3):
            comp.record(_make("Send"))
        for i in range(2):
            comp.record(_make("Receive"))

        freq = event_frequency(comp)
        assert freq["Send"] == 3
        assert freq["Receive"] == 2


# ---------------------------------------------------------------------------
# Tests: causal_density
# ---------------------------------------------------------------------------

class TestCausalDensity:
    def test_causal_density_full(self):
        """Fully connected chain has high density."""
        comp, events = _linear_chain(3)
        # Linear chain: 2 edges, 3 events, max possible = 3*2/2 = 3
        density = causal_density(comp)
        assert 0.0 < density <= 1.0

    def test_causal_density_sparse(self):
        """Independent events have zero density."""
        comp = Computation()
        for i in range(5):
            comp.record(_make(f"E{i}"))

        density = causal_density(comp)
        assert density == 0.0

    def test_causal_density_empty(self):
        """Empty computation has zero density."""
        comp = Computation()
        density = causal_density(comp)
        assert density == 0.0
