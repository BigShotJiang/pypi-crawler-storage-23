import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.analysis.prediction import CausalPredictor, Prediction


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make(name: str, source: str = "test") -> Event:
    return Event(name=name, source=source)


def _abc_chain() -> Computation:
    """Build A -> B -> C chain."""
    comp = Computation()
    a = _make("A")
    b = _make("B")
    c = _make("C")
    comp.record(a)
    comp.record(b, caused_by=[a])
    comp.record(c, caused_by=[b])
    return comp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestPredictorLearn:
    def test_predictor_learn(self):
        """Learn from a computation with A -> B -> C pattern repeated 10 times.
        Internal frequencies reflect this."""
        predictor = CausalPredictor()
        for _ in range(10):
            comp = _abc_chain()
            predictor.learn(comp)

        # Transition A->B should have count 10
        assert predictor._transitions["A"]["B"] == 10
        # Transition B->C should have count 10
        assert predictor._transitions["B"]["C"] == 10


class TestPredictorPredict:
    def test_predictor_predict(self):
        """After learning A->B->C, predict from leaf event of type A.
        Returns B with high confidence."""
        predictor = CausalPredictor()
        for _ in range(10):
            predictor.learn(_abc_chain())

        # Create a computation where A is a leaf
        comp = Computation()
        a = _make("A")
        comp.record(a)

        predictions = predictor.predict(comp)
        assert len(predictions) > 0
        # B should be the top prediction
        assert predictions[0].event_name == "B"
        assert predictions[0].confidence > 0.5
        assert predictions[0].likely_cause == "A"


class TestPredictorMultiplePaths:
    def test_predictor_multiple_paths(self):
        """Learn A->B (8 times) and A->C (2 times).
        Predict from A: B has higher confidence than C."""
        predictor = CausalPredictor()

        for _ in range(8):
            comp = Computation()
            a = _make("A")
            b = _make("B")
            comp.record(a)
            comp.record(b, caused_by=[a])
            predictor.learn(comp)

        for _ in range(2):
            comp = Computation()
            a = _make("A")
            c = _make("C")
            comp.record(a)
            comp.record(c, caused_by=[a])
            predictor.learn(comp)

        comp = Computation()
        a = _make("A")
        comp.record(a)

        predictions = predictor.predict(comp)
        names = [p.event_name for p in predictions]
        assert "B" in names
        assert "C" in names
        b_pred = next(p for p in predictions if p.event_name == "B")
        c_pred = next(p for p in predictions if p.event_name == "C")
        assert b_pred.confidence > c_pred.confidence


class TestPredictorConfidenceThreshold:
    def test_predictor_confidence_threshold(self):
        """Set high threshold. Only high-confidence predictions returned."""
        predictor = CausalPredictor()

        for _ in range(8):
            comp = Computation()
            a = _make("A")
            b = _make("B")
            comp.record(a)
            comp.record(b, caused_by=[a])
            predictor.learn(comp)

        for _ in range(2):
            comp = Computation()
            a = _make("A")
            c = _make("C")
            comp.record(a)
            comp.record(c, caused_by=[a])
            predictor.learn(comp)

        comp = Computation()
        a = _make("A")
        comp.record(a)

        # High threshold should filter out low-confidence predictions
        predictions = predictor.predict(comp, confidence_threshold=0.5)
        for p in predictions:
            assert p.confidence >= 0.5
        # B (0.8) should pass, C (0.2) should not
        names = [p.event_name for p in predictions]
        assert "B" in names
        assert "C" not in names


class TestPredictorEmptyHistory:
    def test_predictor_empty_history(self):
        """No learning. Predict returns empty list."""
        predictor = CausalPredictor()
        comp = Computation()
        a = _make("A")
        comp.record(a)

        predictions = predictor.predict(comp)
        assert predictions == []


class TestPredictionDetails:
    def test_prediction_details(self):
        """Prediction has event_name, confidence, likely_cause, reasoning."""
        predictor = CausalPredictor()
        for _ in range(10):
            predictor.learn(_abc_chain())

        comp = Computation()
        a = _make("A")
        comp.record(a)

        predictions = predictor.predict(comp)
        p = predictions[0]
        assert isinstance(p.event_name, str)
        assert isinstance(p.confidence, float)
        assert isinstance(p.likely_cause, str)
        assert isinstance(p.reasoning, str)


class TestPredictFromEvent:
    def test_predict_from_event(self):
        """Predict based on a single event type."""
        predictor = CausalPredictor()
        for _ in range(10):
            predictor.learn(_abc_chain())

        event = _make("B")
        predictions = predictor.predict_from_event(event)
        assert len(predictions) > 0
        assert predictions[0].event_name == "C"
        assert predictions[0].likely_cause == "B"
