import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.analysis.prediction import AnomalyDetector, Anomaly


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make(name: str, source: str = "test", timestamp: float | None = None) -> Event:
    if timestamp is not None:
        return Event(name=name, source=source, timestamp=timestamp)
    return Event(name=name, source=source)


def _normal_computation() -> Computation:
    """Build a normal A -> B -> C computation."""
    comp = Computation()
    a = _make("A")
    b = _make("B")
    c = _make("C")
    comp.record(a)
    comp.record(b, caused_by=[a])
    comp.record(c, caused_by=[b])
    return comp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAnomalyDetectorLearn:
    def test_anomaly_detector_learn(self):
        """Learn from normal computations."""
        detector = AnomalyDetector()
        comps = [_normal_computation() for _ in range(10)]
        detector.learn(comps)

        # Should have learned event types and causal pairs
        assert "A" in detector._known_event_types
        assert "B" in detector._known_event_types
        assert "C" in detector._known_event_types
        assert ("A", "B") in detector._known_causal_pairs
        assert ("B", "C") in detector._known_causal_pairs


class TestAnomalyUnseenEvent:
    def test_anomaly_unseen_event(self):
        """Inject an event type never seen in training. Detected as anomaly."""
        detector = AnomalyDetector()
        detector.learn([_normal_computation() for _ in range(10)])

        # Create computation with unseen event type
        comp = Computation()
        a = _make("A")
        x = _make("NeverSeen")
        comp.record(a)
        comp.record(x, caused_by=[a])

        anomalies = detector.detect(comp)
        unseen = [a for a in anomalies if a.anomaly_type == "unseen_event"]
        assert len(unseen) > 0
        assert any(a.event.name == "NeverSeen" for a in unseen)


class TestAnomalyUnusualCause:
    def test_anomaly_unusual_cause(self):
        """Create a causal link (A -> D) never seen in training. Detected."""
        detector = AnomalyDetector()
        detector.learn([_normal_computation() for _ in range(10)])

        # A -> C is unusual (normally A -> B -> C)
        comp = Computation()
        a = _make("A")
        c = _make("C")
        comp.record(a)
        comp.record(c, caused_by=[a])

        anomalies = detector.detect(comp)
        unusual = [a for a in anomalies if a.anomaly_type == "unusual_cause"]
        assert len(unusual) > 0


class TestAnomalyNoAnomalies:
    def test_anomaly_no_anomalies(self):
        """Feed a normal computation. No anomalies detected."""
        detector = AnomalyDetector()
        detector.learn([_normal_computation() for _ in range(10)])

        # Feed back a normal computation
        comp = _normal_computation()
        anomalies = detector.detect(comp)
        assert anomalies == []


class TestAnomalySeverity:
    def test_anomaly_severity(self):
        """More unusual patterns have higher severity scores."""
        detector = AnomalyDetector()
        detector.learn([_normal_computation() for _ in range(10)])

        # Computation with both unseen event AND unusual causal link
        comp = Computation()
        a = _make("A")
        x = _make("NeverSeen")
        comp.record(a)
        comp.record(x, caused_by=[a])

        anomalies = detector.detect(comp)
        # Unseen event should have higher severity than unusual cause
        unseen = [a for a in anomalies if a.anomaly_type == "unseen_event"]
        unusual_cause = [a for a in anomalies if a.anomaly_type == "unusual_cause"]

        # All anomalies should have severity between 0 and 1
        for a in anomalies:
            assert 0.0 <= a.severity <= 1.0

        # An unseen event that also has an unusual cause should produce
        # at least anomalies with non-zero severity
        assert len(anomalies) > 0
        assert all(a.severity > 0.0 for a in anomalies)
