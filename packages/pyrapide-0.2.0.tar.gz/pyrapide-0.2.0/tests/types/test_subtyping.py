from pyrapide.types.actions import action, provides, requires
from pyrapide.types.interface import interface
from pyrapide.types.subtyping import is_subtype, conforms_to
from pyrapide.types.function_types import FunctionSignature, is_function_subtype


class TestSubtyping:
    def test_subtype_match(self):
        @interface
        class BasicSender:
            @action
            def send(self, msg: str) -> None:
                pass

        @interface
        class AdvancedSender:
            @action
            def send(self, msg: str) -> None:
                pass

            @action
            def send_batch(self, msgs: list) -> None:
                pass

        assert is_subtype(AdvancedSender, BasicSender) is True

    def test_subtype_mismatch(self):
        @interface
        class BasicSender:
            @action
            def send(self, msg: str) -> None:
                pass

        @interface
        class AdvancedSender:
            @action
            def send(self, msg: str) -> None:
                pass

            @action
            def send_batch(self, msgs: list) -> None:
                pass

        assert is_subtype(BasicSender, AdvancedSender) is False

    def test_identical_interfaces(self):
        @interface
        class A:
            @action
            def do_thing(self) -> None:
                pass

            @provides
            def status(self) -> str:
                return "ok"

        @interface
        class B:
            @action
            def do_thing(self) -> None:
                pass

            @provides
            def status(self) -> str:
                return "ok"

        assert is_subtype(A, B) is True
        assert is_subtype(B, A) is True

    def test_empty_interface_supertype(self):
        @interface
        class Empty:
            pass

        @interface
        class Sender:
            @action
            def send(self) -> None:
                pass

        assert is_subtype(Sender, Empty) is True


class TestConformsTo:
    def test_conforms_to_with_requires(self):
        @interface
        class NeedsLogger:
            @requires
            def log(self, msg: str) -> None:
                ...

            @requires
            def flush(self) -> None:
                ...

        class MyModule:
            def log(self, msg: str) -> None:
                print(msg)

            def flush(self) -> None:
                pass

        assert conforms_to(MyModule, NeedsLogger) is True

    def test_conforms_to_missing_requires(self):
        @interface
        class NeedsLogger:
            @requires
            def log(self, msg: str) -> None:
                ...

            @requires
            def flush(self) -> None:
                ...

        class PartialModule:
            def log(self, msg: str) -> None:
                print(msg)

        assert conforms_to(PartialModule, NeedsLogger) is False


class TestFunctionSubtyping:
    def test_function_subtype_basic(self):
        sig1 = FunctionSignature(
            params={"x": int},
            return_type=int,
        )
        sig2 = FunctionSignature(
            params={"x": int},
            return_type=int,
        )
        assert is_function_subtype(sig1, sig2) is True
