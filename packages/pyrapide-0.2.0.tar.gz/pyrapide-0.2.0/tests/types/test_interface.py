from pyrapide.types.interface import interface
from pyrapide.types.actions import action, provides, requires, behavior


class TestInterfaceDecorator:
    def test_interface_decorator_basic(self):
        @interface
        class MyInterface:
            @action
            def do_thing(self):
                pass

        assert hasattr(MyInterface, "_pyrapide_actions")

    def test_action_registration(self):
        @interface
        class Foo:
            @action
            def send(self):
                pass

            @action
            def receive(self):
                pass

        info = Foo.get_interface_info()
        assert info["actions"] == {"send", "receive"}

    def test_provides_registration(self):
        @interface
        class Foo:
            @provides
            def get_data(self):
                return 42

            @provides
            def get_status(self):
                return "ok"

        info = Foo.get_interface_info()
        assert info["provides"] == {"get_data", "get_status"}

    def test_requires_registration(self):
        @interface
        class Foo:
            @requires
            def external_call(self):
                ...

        info = Foo.get_interface_info()
        assert info["requires"] == {"external_call"}

    def test_event_alphabet(self):
        @interface
        class Foo:
            @action
            def send(self):
                pass

            @action
            def receive(self):
                pass

        info = Foo.get_interface_info()
        assert info["event_alphabet"] == {"Foo.send", "Foo.receive"}

    def test_interface_still_instantiable(self):
        @interface
        class Greeter:
            def __init__(self, name):
                self.name = name

            def greet(self):
                return f"Hello, {self.name}!"

            @action
            def wave(self):
                return "waving"

        g = Greeter("Alice")
        assert g.greet() == "Hello, Alice!"
        assert g.wave() == "waving"

    def test_mixed_decorators(self):
        @interface
        class Foo:
            @provides
            @action
            def send(self):
                pass

        info = Foo.get_interface_info()
        assert "send" in info["actions"]
        assert "send" in info["provides"]

    def test_behavior_registration(self):
        @interface
        class Foo:
            @behavior
            def on_receive(self):
                pass

        info = Foo.get_interface_info()
        assert info["behaviors"] == {"on_receive"}

    def test_no_actions_interface(self):
        @interface
        class Empty:
            def helper(self):
                pass

        info = Empty.get_interface_info()
        assert info["actions"] == set()
        assert info["event_alphabet"] == set()

    def test_interface_inheritance(self):
        @interface
        class Base:
            @action
            def base_action(self):
                pass

            @provides
            def base_op(self):
                pass

        @interface
        class Child(Base):
            @action
            def child_action(self):
                pass

        info = Child.get_interface_info()
        assert info["actions"] == {"base_action", "child_action"}
        assert "Child.base_action" in info["event_alphabet"]
        assert "Child.child_action" in info["event_alphabet"]
        assert "base_op" in info["provides"]
