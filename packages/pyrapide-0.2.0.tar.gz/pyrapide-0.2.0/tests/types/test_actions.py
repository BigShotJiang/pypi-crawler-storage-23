from pyrapide.types.actions import action, provides, requires, behavior


class TestActionDecorator:
    def test_action_decorator_marks_method(self):
        @action
        def send(self):
            pass

        assert send._pyrapide_is_action is True

    def test_provides_decorator_marks_method(self):
        @provides
        def get_data(self):
            pass

        assert get_data._pyrapide_is_provided is True

    def test_requires_decorator_marks_method(self):
        @requires
        def external_service(self):
            ...

        assert external_service._pyrapide_is_required is True

    def test_decorator_stacking(self):
        @provides
        @action
        def send(self):
            pass

        assert send._pyrapide_is_action is True
        assert send._pyrapide_is_provided is True
