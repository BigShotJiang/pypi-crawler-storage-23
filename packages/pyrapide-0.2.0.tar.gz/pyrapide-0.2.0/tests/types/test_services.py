from pyrapide.types.actions import action, provides, requires
from pyrapide.types.interface import interface


class TestServiceDetection:
    def test_service_detection(self):
        @interface
        class Router:
            class Forwarding:
                @action
                def forward(self):
                    pass

                @action
                def drop(self):
                    pass

        info = Router.get_interface_info()
        assert "Forwarding" in info["services"]
        svc = info["services"]["Forwarding"]
        assert svc["actions"] == {"forward", "drop"}

    def test_service_event_alphabet(self):
        @interface
        class Router:
            class Forwarding:
                @action
                def forward(self):
                    pass

        info = Router.get_interface_info()
        assert "Router.Forwarding.forward" in info["event_alphabet"]

    def test_multiple_services(self):
        @interface
        class Server:
            class Auth:
                @action
                def login(self):
                    pass

            class Data:
                @action
                def fetch(self):
                    pass

                @provides
                def status(self):
                    pass

        info = Server.get_interface_info()
        assert "Auth" in info["services"]
        assert "Data" in info["services"]
        assert info["services"]["Auth"]["actions"] == {"login"}
        assert info["services"]["Data"]["actions"] == {"fetch"}
        assert info["services"]["Data"]["provides"] == {"status"}
        assert "Server.Auth.login" in info["event_alphabet"]
        assert "Server.Data.fetch" in info["event_alphabet"]

    def test_empty_service(self):
        @interface
        class Foo:
            class NotAService:
                def helper(self):
                    pass

        info = Foo.get_interface_info()
        assert "NotAService" not in info["services"]
