import pytest

from pyrapide import Event, Poset, CausalCycleError
from pyrapide.core.clock import SynchronousClock, ClockManager
from pyrapide.core.computation import Computation


class TestComputationRecord:
    def test_record_and_query(self):
        c = Computation()
        clock = SynchronousClock(name="sys")
        c.clock_manager.register(clock)

        e1 = Event(name="Send", source="A")
        e2 = Event(name="Receive", source="B")
        e3 = Event(name="Send", source="A")

        c.record(e1, clock="sys")
        clock.tick()
        c.record(e2, caused_by=[e1], clock="sys")
        clock.tick()
        c.record(e3, caused_by=[e2], clock="sys")

        assert len(c) == 3
        assert e1 in c.events
        sends = c.events_by_name("Send")
        assert len(sends) == 2
        assert sends[0] is e1
        assert sends[1] is e3


class TestComputationCausalChain:
    def test_causal_chain(self):
        c = Computation()
        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        c.record(e1)
        c.record(e2, caused_by=[e1])
        c.record(e3, caused_by=[e2])
        chain = c.causal_chain(e1, e3)
        assert chain == [e1, e2, e3]


class TestComputationRootLeaf:
    def test_root_leaf(self):
        c = Computation()
        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        e4 = Event(name="D")
        c.record(e1)
        c.record(e2, caused_by=[e1])
        c.record(e3, caused_by=[e1])
        c.record(e4, caused_by=[e2, e3])
        assert c.root_events() == frozenset({e1})
        assert c.leaf_events() == frozenset({e4})


class TestComputationFilters:
    def test_events_by_name(self):
        c = Computation()
        e1 = Event(name="Send")
        e2 = Event(name="Receive")
        e3 = Event(name="Send")
        c.record(e1)
        c.record(e2)
        c.record(e3)
        result = c.events_by_name("Send")
        assert len(result) == 2
        assert all(e.name == "Send" for e in result)

    def test_events_by_source(self):
        c = Computation()
        e1 = Event(name="A", source="client")
        e2 = Event(name="B", source="server")
        e3 = Event(name="C", source="client")
        c.record(e1)
        c.record(e2)
        c.record(e3)
        result = c.events_by_source("client")
        assert len(result) == 2
        assert all(e.source == "client" for e in result)

    def test_events_since(self):
        c = Computation()
        clock = SynchronousClock(name="sys")
        c.clock_manager.register(clock)

        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        c.record(e1, clock="sys")
        clock.tick(5.0)
        c.record(e2, clock="sys")
        clock.tick(5.0)
        c.record(e3, clock="sys")

        result = c.events_since(4.0, clock_name="sys")
        assert len(result) == 2
        assert e2 in result
        assert e3 in result

    def test_events_between(self):
        c = Computation()
        clock = SynchronousClock(name="sys")
        c.clock_manager.register(clock)

        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        e4 = Event(name="D")
        c.record(e1, clock="sys")       # t=0
        clock.tick(3.0)
        c.record(e2, clock="sys")       # t=3
        clock.tick(3.0)
        c.record(e3, clock="sys")       # t=6
        clock.tick(3.0)
        c.record(e4, clock="sys")       # t=9

        result = c.events_between(2.0, 7.0, clock_name="sys")
        assert len(result) == 2
        assert e2 in result
        assert e3 in result


class TestComputationCausalDepth:
    def test_causal_depth(self):
        c = Computation()
        events = []
        for i in range(5):
            e = Event(name=f"E{i}")
            c.record(e, caused_by=[events[-1]] if events else None)
            events.append(e)
        assert c.causal_depth() == 4

    def test_causal_depth_empty(self):
        c = Computation()
        assert c.causal_depth() == 0

    def test_causal_depth_single(self):
        c = Computation()
        c.record(Event(name="A"))
        assert c.causal_depth() == 0


class TestComputationMerge:
    def test_merge_disjoint(self):
        c1 = Computation()
        e1 = Event(name="A")
        e2 = Event(name="B")
        c1.record(e1)
        c1.record(e2, caused_by=[e1])

        c2 = Computation()
        e3 = Event(name="C")
        e4 = Event(name="D")
        c2.record(e3)
        c2.record(e4, caused_by=[e3])

        merged = c1.merge(c2)
        assert len(merged) == 4
        assert e1 in merged.events
        assert e3 in merged.events
        # Causal structure preserved
        assert merged.ancestors(e2) == frozenset({e1})
        assert merged.ancestors(e4) == frozenset({e3})

    def test_merge_overlapping(self):
        shared = Event(name="Shared")

        c1 = Computation()
        e1 = Event(name="A")
        c1.record(e1)
        c1.record(shared, caused_by=[e1])

        c2 = Computation()
        e2 = Event(name="B")
        c2.record(shared)
        c2.record(e2, caused_by=[shared])

        merged = c1.merge(c2)
        # shared should not be duplicated
        assert len(merged) == 3
        ids = [e.id for e in merged.events]
        assert ids.count(shared.id) == 1


class TestComputationTopological:
    def test_topological_order(self):
        c = Computation()
        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        e4 = Event(name="D")
        c.record(e1)
        c.record(e2, caused_by=[e1])
        c.record(e3, caused_by=[e1])
        c.record(e4, caused_by=[e2, e3])

        order = c.topological_order()
        assert len(order) == 4
        # e1 must come before e2, e3; e2 and e3 before e4
        assert order.index(e1) < order.index(e2)
        assert order.index(e1) < order.index(e3)
        assert order.index(e2) < order.index(e4)
        assert order.index(e3) < order.index(e4)

    def test_iter(self):
        c = Computation()
        e1 = Event(name="A")
        e2 = Event(name="B")
        c.record(e1)
        c.record(e2, caused_by=[e1])
        events = list(c)
        assert len(events) == 2
        assert events.index(e1) < events.index(e2)


class TestComputationSerialization:
    def test_serialization_roundtrip(self):
        c = Computation()
        clock = SynchronousClock(name="sys")
        c.clock_manager.register(clock)

        e1 = Event(name="A", source="s1")
        e2 = Event(name="B", source="s2")
        e3 = Event(name="C", source="s1")
        c.record(e1, clock="sys")
        clock.tick()
        c.record(e2, caused_by=[e1], clock="sys")
        clock.tick()
        c.record(e3, caused_by=[e1, e2], clock="sys")

        d = c.to_dict()
        c2 = Computation.from_dict(d)

        assert len(c2) == 3
        original_ids = {e.id for e in c.events}
        restored_ids = {e.id for e in c2.events}
        assert original_ids == restored_ids

        # Verify causal structure
        e3_restored = next(e for e in c2.events if e.id == e3.id)
        cause_ids = {e.id for e in c2.ancestors(e3_restored)}
        assert cause_ids == {e1.id, e2.id}
