import time

import pytest

from pyrapide import Event


class TestEventCreation:
    def test_event_creation(self):
        e = Event(name="Send", payload={"msg": "hello"}, source="client_1")
        assert e.name == "Send"
        assert e.payload == {"msg": "hello"}
        assert e.source == "client_1"
        assert isinstance(e.id, str)
        assert len(e.id) > 0
        assert isinstance(e.timestamp, float)
        assert isinstance(e.metadata, dict)

    def test_event_auto_id(self):
        e1 = Event(name="A")
        e2 = Event(name="A")
        assert e1.id != e2.id

    def test_event_auto_timestamp(self):
        before = time.time()
        e = Event(name="Tick")
        after = time.time()
        assert before <= e.timestamp <= after

    def test_event_default_payload(self):
        e = Event(name="Empty")
        assert e.payload == {}

    def test_event_default_source(self):
        e = Event(name="Empty")
        assert e.source == ""

    def test_event_payload_access(self):
        e = Event(name="Data", payload={"x": 1, "y": "hello"})
        assert e.payload["x"] == 1
        assert e.payload["y"] == "hello"


class TestEventImmutability:
    def test_event_immutability(self):
        e = Event(name="Send")
        with pytest.raises(Exception):
            e.name = "X"


class TestEventIdentity:
    def test_event_identity_equality(self):
        e1 = Event(name="Send", payload={"x": 1}, source="s")
        e2 = Event(name="Send", payload={"x": 1}, source="s")
        assert e1 != e2

    def test_event_self_equality(self):
        e1 = Event(name="Send")
        assert e1 == e1

    def test_event_hashable(self):
        e1 = Event(name="A")
        e2 = Event(name="B")
        s = {e1, e2}
        assert len(s) == 2
        d = {e1: "first", e2: "second"}
        assert d[e1] == "first"
        assert d[e2] == "second"


class TestEventSerialization:
    def test_event_serialization_roundtrip(self):
        e = Event(name="Send", payload={"x": 1, "nested": {"a": 2}}, source="c1",
                  metadata={"trace": "abc"})
        d = e.to_dict()
        e2 = Event.from_dict(d)
        assert e == e2
        assert e.id == e2.id
        assert e.name == e2.name
        assert e.payload == e2.payload
        assert e.source == e2.source
        assert e.timestamp == e2.timestamp
        assert e.metadata == e2.metadata


class TestEventRepr:
    def test_event_repr(self):
        e = Event(name="Send", source="client_1")
        r = repr(e)
        assert "Send" in r
        assert e.id[:8] in r
