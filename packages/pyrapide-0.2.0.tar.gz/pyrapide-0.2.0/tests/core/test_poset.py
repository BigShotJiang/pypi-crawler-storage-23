import time

import pytest

from pyrapide import Event, Poset
from pyrapide.core.exceptions import CausalCycleError


class TestPosetAdd:
    def test_add_single_event(self):
        p = Poset()
        e = Event(name="A")
        p.add(e)
        assert e in p
        assert len(p) == 1

    def test_add_with_single_cause(self):
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e1)
        p.add(e2, caused_by=[e1])
        assert p.causes(e2) == frozenset({e1})
        assert p.effects(e1) == frozenset({e2})

    def test_add_with_multiple_causes(self):
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        p.add(e1)
        p.add(e2)
        p.add(e3, caused_by=[e1, e2])
        assert p.causes(e3) == frozenset({e1, e2})

    def test_add_caused_by_unknown_raises(self):
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        with pytest.raises(ValueError):
            p.add(e2, caused_by=[e1])

    def test_cycle_detection(self):
        """Adding a causal link that would create a cycle raises CausalCycleError."""
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        e3 = Event(name="C")
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3, caused_by=[e2])
        # e1 -> e2 -> e3; adding e3 -> e1 would create a cycle
        with pytest.raises(CausalCycleError):
            p.add_causal_link(e3, e1)
        # Verify poset is unchanged after the failed operation
        assert len(p) == 3
        assert p.effects(e3) == frozenset()


class TestPosetAncestors:
    def test_ancestors_direct(self, linear_poset):
        p, e1, e2, e3 = linear_poset
        assert p.ancestors(e2) == frozenset({e1})

    def test_ancestors_transitive(self, linear_poset):
        p, e1, e2, e3 = linear_poset
        assert p.ancestors(e3) == frozenset({e1, e2})

    def test_ancestors_diamond(self, diamond_poset):
        p, e1, e2, e3, e4 = diamond_poset
        assert p.ancestors(e4) == frozenset({e1, e2, e3})

    def test_descendants(self, linear_poset):
        p, e1, e2, e3 = linear_poset
        assert p.descendants(e1) == frozenset({e2, e3})


class TestPosetRelations:
    def test_is_ancestor(self, linear_poset):
        p, e1, e2, e3 = linear_poset
        assert p.is_ancestor(e1, e3) is True
        assert p.is_ancestor(e3, e1) is False

    def test_are_independent(self, diamond_poset):
        p, e1, e2, e3, e4 = diamond_poset
        assert p.are_independent(e2, e3) is True
        assert p.are_independent(e1, e2) is False

    def test_common_ancestors(self, diamond_poset):
        p, e1, e2, e3, e4 = diamond_poset
        assert p.common_ancestors(e2, e3) == frozenset({e1})


class TestPosetStructure:
    def test_root_events(self, sample_events):
        p = Poset()
        e1, e2, e3, e4, e5 = (
            sample_events["e1"],
            sample_events["e2"],
            sample_events["e3"],
            sample_events["e4"],
            sample_events["e5"],
        )
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3)
        p.add(e4, caused_by=[e3])
        p.add(e5, caused_by=[e2, e4])
        assert p.root_events() == frozenset({e1, e3})

    def test_leaf_events(self, sample_events):
        p = Poset()
        e1, e2, e3, e4, e5 = (
            sample_events["e1"],
            sample_events["e2"],
            sample_events["e3"],
            sample_events["e4"],
            sample_events["e5"],
        )
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3)
        p.add(e4, caused_by=[e3])
        p.add(e5, caused_by=[e2, e4])
        assert p.leaf_events() == frozenset({e5})


class TestPosetCausalChain:
    def test_causal_chain_exists(self, linear_poset):
        p, e1, e2, e3 = linear_poset
        chain = p.causal_chain(e1, e3)
        assert chain == [e1, e2, e3]

    def test_causal_chain_none(self):
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e1)
        p.add(e2)
        assert p.causal_chain(e1, e2) is None


class TestPosetFilter:
    def test_filter_by_name(self):
        p = Poset()
        a1 = Event(name="A")
        a2 = Event(name="A")
        b1 = Event(name="B")
        p.add(a1)
        p.add(a2, caused_by=[a1])
        p.add(b1, caused_by=[a1])
        filtered = p.filter_by_name("A")
        assert len(filtered) == 2
        assert all(e.name == "A" for e in filtered.events)

    def test_filter_by_name_preserves_edges(self):
        p = Poset()
        a1 = Event(name="A")
        a2 = Event(name="A")
        b1 = Event(name="B")
        p.add(a1)
        p.add(b1, caused_by=[a1])
        p.add(a2, caused_by=[b1])
        # a1 -> b1 -> a2: only direct edges where both endpoints are "A" survive
        filtered = p.filter_by_name("A")
        assert len(filtered) == 2
        # No direct edge between a1 and a2 in the original, so none in filtered
        assert filtered.causes(a2) == frozenset()

    def test_filter_by_source(self):
        p = Poset()
        e1 = Event(name="A", source="s1")
        e2 = Event(name="B", source="s1")
        e3 = Event(name="C", source="s2")
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3, caused_by=[e1])
        filtered = p.filter_by_source("s1")
        assert len(filtered) == 2
        assert all(e.source == "s1" for e in filtered.events)


class TestPosetSerialization:
    def test_serialization_roundtrip(self, sample_events):
        p = Poset()
        e1, e2, e3, e4, e5 = (
            sample_events["e1"],
            sample_events["e2"],
            sample_events["e3"],
            sample_events["e4"],
            sample_events["e5"],
        )
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3, caused_by=[e1])
        p.add(e4, caused_by=[e2, e3])
        p.add(e5, caused_by=[e4])

        d = p.to_dict()
        p2 = Poset.from_dict(d)

        assert len(p2) == 5
        # Verify all event ids are preserved
        original_ids = {e.id for e in p.events}
        restored_ids = {e.id for e in p2.events}
        assert original_ids == restored_ids

        # Verify causal structure by checking edges via event ids
        for e in p2.events:
            if e.id == e4.id:
                cause_ids = {c.id for c in p2.causes(e)}
                assert cause_ids == {e2.id, e3.id}
            if e.id == e5.id:
                cause_ids = {c.id for c in p2.causes(e)}
                assert cause_ids == {e4.id}


class TestPosetEdgeCases:
    def test_empty_poset(self):
        p = Poset()
        assert len(p) == 0
        assert p.root_events() == frozenset()
        assert p.leaf_events() == frozenset()
        assert p.events == frozenset()

    def test_large_poset_performance(self):
        p = Poset()
        events = []
        for i in range(1000):
            e = Event(name=f"E{i}")
            caused_by = [events[-1]] if events else None
            p.add(e, caused_by=caused_by)
            events.append(e)

        start = time.time()
        anc = p.ancestors(events[-1])
        elapsed = time.time() - start

        assert len(anc) == 999
        assert elapsed < 5.0
