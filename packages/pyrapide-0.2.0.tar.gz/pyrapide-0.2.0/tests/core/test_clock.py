import pytest

from pyrapide import Event
from pyrapide.core.clock import (
    Clock,
    ClockManager,
    RegularClock,
    SlavedClock,
    SynchronousClock,
)


class TestSynchronousClock:
    def test_synchronous_clock_creation(self):
        c = SynchronousClock(name="sys")
        assert c.name == "sys"
        assert c.read() == 0.0

    def test_synchronous_clock_tick(self):
        c = SynchronousClock(name="sys")
        c.tick()
        assert c.read() == 1.0
        c.tick(2.5)
        assert c.read() == 3.5


class TestRegularClock:
    def test_regular_clock_period(self):
        c = RegularClock(name="reg", period=0.1)
        for _ in range(10):
            c.auto_tick()
        assert abs(c.read() - 1.0) < 1e-9


class TestSlavedClock:
    def test_slaved_clock(self):
        parent = SynchronousClock(name="parent")
        slave = SlavedClock(name="slave", parent=parent, divisor=5)
        for _ in range(10):
            parent.tick()
        assert slave.read() == pytest.approx(2.0)


class TestClockStamping:
    def test_clock_stamp_event(self):
        c = SynchronousClock(name="sys")
        e = Event(name="A")
        c.tick(5.0)
        ts = c.stamp(e)
        assert ts.event is e
        assert ts.time == 5.0
        assert ts.clock_name == "sys"
        assert c.start_time(e) == 5.0
        assert c.finish_time(e) == 5.0

    def test_clock_stamp_start_finish(self):
        c = SynchronousClock(name="sys")
        e = Event(name="LongOp")
        c.stamp(e, phase="start")
        c.tick(3.0)
        c.stamp(e, phase="finish")
        assert c.start_time(e) == 0.0
        assert c.finish_time(e) == 3.0

    def test_clock_temporal_ordering(self):
        c = SynchronousClock(name="sys")
        e1 = Event(name="E1")
        e2 = Event(name="E2")
        e3 = Event(name="E3")
        c.stamp(e1)
        c.tick()
        c.stamp(e2)
        c.tick()
        c.stamp(e3)
        order = c.get_temporal_order()
        assert order == [e1, e2, e3]

    def test_multi_clock_stamping(self):
        fast = SynchronousClock(name="fast")
        slow = SynchronousClock(name="slow")
        e1 = Event(name="E1")
        e2 = Event(name="E2")
        e3 = Event(name="E3")

        # Stamp on fast clock: e1 at 0, e2 at 1, e3 at 2
        fast.stamp(e1)
        fast.tick()
        fast.stamp(e2)
        fast.tick()
        fast.stamp(e3)

        # Stamp on slow clock in reverse order: e3 at 0, e2 at 1, e1 at 2
        slow.stamp(e3)
        slow.tick()
        slow.stamp(e2)
        slow.tick()
        slow.stamp(e1)

        assert fast.get_temporal_order() == [e1, e2, e3]
        assert slow.get_temporal_order() == [e3, e2, e1]


class TestClockManager:
    def test_clock_manager(self):
        mgr = ClockManager()
        c1 = SynchronousClock(name="clock1")
        c2 = SynchronousClock(name="clock2")
        mgr.register(c1)
        mgr.register(c2)

        e1 = Event(name="E1")
        e2 = Event(name="E2")

        # Stamp e1 on clock1 only
        mgr.stamp_event(e1, clock_name="clock1")
        c1.tick()
        c2.tick(5.0)

        # Stamp e2 on all clocks
        mgr.stamp_event(e2)

        order1 = mgr.get_temporal_order("clock1")
        assert order1 == [e1, e2]

        order2 = mgr.get_temporal_order("clock2")
        assert order2 == [e2]
