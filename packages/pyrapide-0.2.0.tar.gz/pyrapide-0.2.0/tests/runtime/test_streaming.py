import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.patterns.base import Pattern, PatternMatch
from pyrapide.constraints.pattern_constraints import Never, ConstraintViolation
from pyrapide.runtime.streaming import (
    EventSource,
    InMemoryEventSource,
    StreamProcessor,
)


class TestStreamSingleSource:
    async def test_stream_single_source(self):
        """One InMemoryEventSource, put 5 events, run processor,
        on_event callback receives all 5."""
        source = InMemoryEventSource("src1")
        processor = StreamProcessor()
        processor.add_source("src1", source)

        received: list[Event] = []

        async def on_evt(event: Event) -> None:
            received.append(event)

        processor.on_event(on_evt)

        # Put events before running (they'll be consumed during run)
        for i in range(5):
            await source.put(Event(name=f"E{i}", source="test"))

        # Signal end of source
        await source.close()

        await processor.run()

        assert len(received) == 5


class TestStreamMultiSource:
    async def test_stream_multi_source(self):
        """Two sources, each put 3 events. Processor receives all 6."""
        src1 = InMemoryEventSource("src1")
        src2 = InMemoryEventSource("src2")

        processor = StreamProcessor()
        processor.add_source("src1", src1)
        processor.add_source("src2", src2)

        received: list[Event] = []

        async def on_evt(event: Event) -> None:
            received.append(event)

        processor.on_event(on_evt)

        for i in range(3):
            await src1.put(Event(name=f"A{i}", source="src1"))
        for i in range(3):
            await src2.put(Event(name=f"B{i}", source="src2"))

        await src1.close()
        await src2.close()

        await processor.run()

        assert len(received) == 6
        names = {e.name for e in received}
        assert names == {"A0", "A1", "A2", "B0", "B1", "B2"}


class TestStreamPatternWatch:
    async def test_stream_pattern_watch(self):
        """Watch for 'Error' pattern. Put 2 Error events among 10 events.
        Callback fired twice."""
        source = InMemoryEventSource("src")
        processor = StreamProcessor()
        processor.add_source("src", source)

        matches: list[PatternMatch] = []

        async def on_match(match: PatternMatch) -> None:
            matches.append(match)

        processor.watch(Pattern.match("Error"), on_match)

        for i in range(10):
            name = "Error" if i in (3, 7) else f"OK{i}"
            await source.put(Event(name=name, source="test"))

        await source.close()
        await processor.run()

        assert len(matches) == 2
        for m in matches:
            assert any(e.name == "Error" for e in m.events)


class TestStreamConstraintEnforcement:
    async def test_stream_constraint_enforcement(self):
        """Enforce a never('BadEvent') constraint. Put events including
        the bad pattern. Violation callback fires."""
        source = InMemoryEventSource("src")
        processor = StreamProcessor()
        processor.add_source("src", source)

        violations: list[ConstraintViolation] = []

        async def on_violation(v: ConstraintViolation) -> None:
            violations.append(v)

        processor.enforce(Never(Pattern.match("BadEvent"), name="no_bad"))
        processor.on_violation(on_violation)

        await source.put(Event(name="Good", source="test"))
        await source.put(Event(name="BadEvent", source="test"))
        await source.put(Event(name="Good2", source="test"))

        await source.close()
        await processor.run()

        assert len(violations) >= 1
        assert any(v.constraint_name == "no_bad" for v in violations)


class TestStreamSlidingWindow:
    async def test_stream_sliding_window(self):
        """Set window_size=5. Put 10 events. Computation contains at most ~5
        recent events."""
        source = InMemoryEventSource("src")
        processor = StreamProcessor()
        processor.add_source("src", source)

        for i in range(10):
            await source.put(Event(name=f"E{i}", source="test"))

        await source.close()
        await processor.run(window_size=5)

        # Computation should have at most window_size events
        assert len(processor.computation) <= 5


class TestStreamStats:
    async def test_stream_stats(self):
        """Run processor, check stats dict."""
        src1 = InMemoryEventSource("src1")
        src2 = InMemoryEventSource("src2")
        processor = StreamProcessor()
        processor.add_source("src1", src1)
        processor.add_source("src2", src2)

        processor.enforce(Never(Pattern.match("Bad"), name="no_bad"))

        for i in range(3):
            await src1.put(Event(name=f"A{i}", source="src1"))
        await src2.put(Event(name="Bad", source="src2"))
        await src2.put(Event(name="B1", source="src2"))

        await src1.close()
        await src2.close()

        await processor.run()

        stats = processor.stats
        assert stats["event_count"] == 5
        assert stats["source_counts"]["src1"] == 3
        assert stats["source_counts"]["src2"] == 2
        assert stats["violation_count"] >= 1


class TestStreamStop:
    async def test_stream_stop(self):
        """Start processor, stop it, assert it shuts down cleanly."""
        source = InMemoryEventSource("src")
        processor = StreamProcessor()
        processor.add_source("src", source)

        received: list[Event] = []

        async def on_evt(event: Event) -> None:
            received.append(event)

        processor.on_event(on_evt)

        # Put some events
        await source.put(Event(name="E0", source="test"))
        await source.put(Event(name="E1", source="test"))

        # Run in background and stop after a short delay
        async def run_and_stop():
            run_task = asyncio.create_task(processor.run())
            await asyncio.sleep(0.05)
            await processor.stop()
            await run_task

        await run_and_stop()

        # Should have processed some events and shut down cleanly
        assert len(received) >= 1
