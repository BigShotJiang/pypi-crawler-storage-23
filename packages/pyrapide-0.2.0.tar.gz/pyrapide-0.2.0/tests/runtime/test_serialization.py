import json

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.runtime.serialization import (
    serialize_event,
    deserialize_event,
    serialize_computation,
    deserialize_computation,
)


class TestSerializeEvent:
    def test_serialize_event_json(self):
        """Roundtrip event serialization."""
        event = Event(name="TestEvent", payload={"key": "value"}, source="src")
        data = serialize_event(event)

        assert isinstance(data, dict)
        assert data["name"] == "TestEvent"
        assert data["payload"] == {"key": "value"}
        assert data["source"] == "src"

        restored = deserialize_event(data)
        assert restored.id == event.id
        assert restored.name == event.name
        assert restored.payload == event.payload
        assert restored.source == event.source


class TestSerializeComputation:
    def test_serialize_computation_json(self):
        """Roundtrip computation serialization."""
        comp = Computation()
        e1 = Event(name="A", source="s1")
        e2 = Event(name="B", source="s2")
        comp.record(e1)
        comp.record(e2, caused_by=[e1])

        json_str = serialize_computation(comp, format="json")
        assert isinstance(json_str, str)

        # Should be valid JSON
        parsed = json.loads(json_str)
        assert "poset" in parsed

        restored = deserialize_computation(json_str, format="json")
        assert len(restored) == 2

        restored_names = {e.name for e in restored.events}
        assert restored_names == {"A", "B"}

    def test_serialize_preserves_causality(self):
        """Causal edges survive serialization."""
        comp = Computation()
        e1 = Event(name="Cause", source="s1")
        e2 = Event(name="Effect", source="s2")
        e3 = Event(name="Final", source="s3")

        comp.record(e1)
        comp.record(e2, caused_by=[e1])
        comp.record(e3, caused_by=[e2])

        json_str = serialize_computation(comp, format="json")
        restored = deserialize_computation(json_str, format="json")

        # Find events by name
        cause = [e for e in restored.events if e.name == "Cause"][0]
        effect = [e for e in restored.events if e.name == "Effect"][0]
        final = [e for e in restored.events if e.name == "Final"][0]

        assert restored.is_ancestor(cause, effect)
        assert restored.is_ancestor(effect, final)
        assert restored.is_ancestor(cause, final)
