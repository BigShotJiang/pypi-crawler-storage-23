import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.core.computation import Computation
from pyrapide.patterns.base import Pattern, PatternMatch
from pyrapide.types.actions import action, provides, requires, behavior
from pyrapide.types.interface import interface
from pyrapide.architecture.architecture import architecture
from pyrapide.architecture.connections import connect, BasicConnection
from pyrapide.constraints.pattern_constraints import must_match, never, MustMatch, Never
from pyrapide.executable.module import module, get_context, ModuleContext
from pyrapide.executable.reactive import when, WhenRegistry
from pyrapide.runtime.engine import Engine


# ---------------------------------------------------------------------------
# Helper interfaces and architectures
# ---------------------------------------------------------------------------


@interface
class ProducerInterface:
    @action
    def produce(self) -> None:
        pass


@interface
class ConsumerInterface:
    @action
    def consume(self) -> None:
        pass


@interface
class RelayInterface:
    @action
    def relay(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestEngine:
    async def test_engine_instantiate(self):
        """Instantiate an architecture. Components exist."""

        @architecture
        class SimpleArch:
            producer: ProducerInterface

            def connections(self):
                return []

        arch = SimpleArch()
        engine = Engine()

        assert arch.components is not None
        assert "producer" in arch.components
        assert hasattr(arch, "computation")

    async def test_engine_run_simple(self):
        """Architecture with one component that generates one event in start().
        Run engine. Computation has the event."""

        @module()
        class ProducerMod:
            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Produced", payload={"value": 42})

        @architecture
        class SimpleArch:
            producer: ProducerInterface

            def connections(self):
                return []

        engine = Engine()
        arch = SimpleArch()

        # Bind the module implementation to the component
        engine.bind(arch, "producer", ProducerMod)

        computation = await engine.run(arch)

        produced = [e for e in computation.events if e.name == "Produced"]
        assert len(produced) == 1
        assert produced[0].payload["value"] == 42

    async def test_engine_connection_propagation(self):
        """Architecture with two components. Component A generates 'Request' in
        start(). Connection routes 'Request' to component B's handler. B
        generates 'Response'. Computation has both events with correct causal link."""

        @module()
        class ClientMod:
            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Request", payload={"data": "hello"})

        @module()
        class ServerMod:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                ctx = get_context(self)
                # Set causal context to the matched event
                ctx.generate_event(
                    "Response",
                    payload={"data": "world"},
                    caused_by=list(match.events),
                )

        @architecture
        class ClientServerArch:
            client: ProducerInterface
            server: ConsumerInterface

            def connections(self):
                return [
                    connect(Pattern.match("Request"), "server"),
                ]

        engine = Engine()
        arch = ClientServerArch()
        engine.bind(arch, "client", ClientMod)
        engine.bind(arch, "server", ServerMod)

        computation = await engine.run(arch)

        requests = [e for e in computation.events if e.name == "Request"]
        responses = [e for e in computation.events if e.name == "Response"]

        assert len(requests) == 1
        assert len(responses) == 1

        # Response should be causally linked to Request
        assert computation.is_ancestor(requests[0], responses[0])

    async def test_engine_inject(self):
        """Run engine, inject an external event. Event appears in computation."""

        @module()
        class PassiveMod:
            pass

        @architecture
        class PassiveArch:
            component: ProducerInterface

            def connections(self):
                return []

        engine = Engine()
        arch = PassiveArch()
        engine.bind(arch, "component", PassiveMod)

        # Start the engine in a task so we can inject
        async def run_and_inject():
            run_task = asyncio.create_task(engine.run(arch, timeout=1.0))

            # Give engine time to start
            await asyncio.sleep(0.05)

            await engine.inject(
                Event(name="External", payload={"source": "test"}, source="external")
            )

            return await run_task

        computation = await run_and_inject()

        externals = [e for e in computation.events if e.name == "External"]
        assert len(externals) == 1
        assert externals[0].payload["source"] == "test"

    async def test_engine_timeout(self):
        """Set a short timeout. Engine stops even if components could generate
        more events."""

        @module()
        class InfiniteProducer:
            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Tick", payload={"n": 0})

            @when(Pattern.match("Tick"))
            async def on_tick(self, match: PatternMatch):
                ctx = get_context(self)
                n = list(match.events)[0].payload.get("n", 0)
                await asyncio.sleep(0.01)
                ctx.generate_event(
                    "Tick",
                    payload={"n": n + 1},
                    caused_by=list(match.events),
                )

        @architecture
        class TickArch:
            ticker: ProducerInterface

            def connections(self):
                return []

        engine = Engine()
        arch = TickArch()
        engine.bind(arch, "ticker", InfiniteProducer)

        computation = await engine.run(arch, timeout=0.15)

        # Should have generated some events but not infinite
        ticks = [e for e in computation.events if e.name == "Tick"]
        assert len(ticks) >= 1
        # Should have stopped due to timeout, not run forever
        assert len(ticks) < 100

    async def test_engine_constraint_violation(self):
        """Architecture with a never constraint. Component generates a
        forbidden pattern. Engine's computation records the violation."""

        @module()
        class ForbiddenMod:
            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Forbidden", payload={})

        @architecture
        class ConstrainedArch:
            comp: ProducerInterface

            def connections(self):
                return []

            def constraints(self):
                return [
                    Never(Pattern.match("Forbidden"), name="no_forbidden"),
                ]

        engine = Engine()
        arch = ConstrainedArch()
        engine.bind(arch, "comp", ForbiddenMod)

        computation = await engine.run(arch)

        # Forbidden event should exist
        forbidden = [e for e in computation.events if e.name == "Forbidden"]
        assert len(forbidden) == 1

        # Violations should be recorded
        assert len(engine.violations) > 0
        assert any(v.constraint_name == "no_forbidden" for v in engine.violations)

    async def test_engine_multiple_components(self):
        """Architecture with 3 components and 2 connections. Verify full event
        propagation."""

        @module()
        class SourceMod:
            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Data", payload={"step": 1})

        @module()
        class RelayMod:
            @when(Pattern.match("Data"))
            async def on_data(self, match: PatternMatch):
                ctx = get_context(self)
                event = list(match.events)[0]
                ctx.generate_event(
                    "Relayed",
                    payload={"step": event.payload["step"] + 1},
                    caused_by=list(match.events),
                )

        @module()
        class SinkMod:
            @when(Pattern.match("Relayed"))
            async def on_relayed(self, match: PatternMatch):
                ctx = get_context(self)
                event = list(match.events)[0]
                ctx.generate_event(
                    "Done",
                    payload={"step": event.payload["step"] + 1},
                    caused_by=list(match.events),
                )

        @architecture
        class PipelineArch:
            source: ProducerInterface
            relay: RelayInterface
            sink: ConsumerInterface

            def connections(self):
                return [
                    connect(Pattern.match("Data"), "relay"),
                    connect(Pattern.match("Relayed"), "sink"),
                ]

        engine = Engine()
        arch = PipelineArch()
        engine.bind(arch, "source", SourceMod)
        engine.bind(arch, "relay", RelayMod)
        engine.bind(arch, "sink", SinkMod)

        computation = await engine.run(arch)

        data_events = [e for e in computation.events if e.name == "Data"]
        relayed_events = [e for e in computation.events if e.name == "Relayed"]
        done_events = [e for e in computation.events if e.name == "Done"]

        assert len(data_events) == 1
        assert len(relayed_events) == 1
        assert len(done_events) == 1

        # Full causal chain: Data -> Relayed -> Done
        assert computation.is_ancestor(data_events[0], relayed_events[0])
        assert computation.is_ancestor(relayed_events[0], done_events[0])
        assert computation.is_ancestor(data_events[0], done_events[0])

    async def test_engine_quiescence(self):
        """Architecture where all components eventually stop generating events.
        Engine reaches quiescence and returns."""

        @module()
        class CounterMod:
            @when(Pattern.match("Count"))
            async def on_count(self, match: PatternMatch):
                ctx = get_context(self)
                event = list(match.events)[0]
                n = event.payload["n"]
                if n < 3:
                    ctx.generate_event(
                        "Count",
                        payload={"n": n + 1},
                        caused_by=list(match.events),
                    )

            async def start(self):
                ctx = get_context(self)
                ctx.generate_event("Count", payload={"n": 0})

        @architecture
        class QuiescentArch:
            counter: ProducerInterface

            def connections(self):
                return []

        engine = Engine()
        arch = QuiescentArch()
        engine.bind(arch, "counter", CounterMod)

        computation = await engine.run(arch, timeout=5.0)

        counts = [e for e in computation.events if e.name == "Count"]
        # Should have Count(0), Count(1), Count(2), Count(3) = 4 events
        assert len(counts) == 4
        ns = sorted(e.payload["n"] for e in counts)
        assert ns == [0, 1, 2, 3]
