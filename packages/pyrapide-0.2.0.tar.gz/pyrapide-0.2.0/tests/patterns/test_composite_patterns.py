import pytest

from pyrapide import Event, Poset
from pyrapide.patterns.base import (
    BasicPattern,
    Pattern,
    PatternMatch,
)
from pyrapide.patterns.composite import (
    DisjunctionPattern,
    ImmediateSequencePattern,
    IndependencePattern,
    IterationPattern,
    JoinPattern,
    SequencePattern,
    UnionPattern,
)


class TestSequencePattern:
    def test_sequence_match(self):
        """e1(Send) -> e2(Ack). Pattern (Send >> Ack) matches with events (e1, e2)."""
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Ack")
        p.add(e1)
        p.add(e2, caused_by=[e1])

        pat = Pattern.match("Send") >> Pattern.match("Ack")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e1 in matches[0].events
        assert e2 in matches[0].events

    def test_sequence_no_causal_link(self):
        """e1(Send), e2(Ack) independent — sequence does NOT match."""
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Ack")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send") >> Pattern.match("Ack")
        matches = pat.match_in(p)
        assert len(matches) == 0

    def test_sequence_transitive(self):
        """e1(Send) -> e2(Process) -> e3(Ack). (Send >> Ack) matches via transitive causality."""
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Process")
        e3 = Event(name="Ack")
        p.add(e1)
        p.add(e2, caused_by=[e1])
        p.add(e3, caused_by=[e2])

        pat = Pattern.match("Send") >> Pattern.match("Ack")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e1 in matches[0].events
        assert e3 in matches[0].events


class TestImmediateSequencePattern:
    def test_immediate_sequence_direct(self):
        """e1 -> e2 directly. Immediate sequence matches."""
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Ack")
        p.add(e1)
        p.add(e2, caused_by=[e1])

        pat = Pattern.match("Send").then_immediately(Pattern.match("Ack"))
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e1 in matches[0].events
        assert e2 in matches[0].events

    def test_immediate_sequence_indirect_no_match(self):
        """e1 -> e_mid -> e2: immediate sequence does NOT match for e1->e2."""
        p = Poset()
        e1 = Event(name="Send")
        e_mid = Event(name="Process")
        e2 = Event(name="Ack")
        p.add(e1)
        p.add(e_mid, caused_by=[e1])
        p.add(e2, caused_by=[e_mid])

        pat = Pattern.match("Send").then_immediately(Pattern.match("Ack"))
        matches = pat.match_in(p)
        assert len(matches) == 0


class TestJoinPattern:
    def test_join_common_ancestor(self):
        """e0 -> e1(A), e0 -> e2(B). Join(A, B) matches because e0 is common ancestor."""
        p = Poset()
        e0 = Event(name="Root")
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e0)
        p.add(e1, caused_by=[e0])
        p.add(e2, caused_by=[e0])

        pat = Pattern.match("A") & Pattern.match("B")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e1 in matches[0].events
        assert e2 in matches[0].events

    def test_join_no_common_ancestor(self):
        """e1(A), e2(B) both roots. Join does NOT match."""
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("A") & Pattern.match("B")
        matches = pat.match_in(p)
        assert len(matches) == 0


class TestIndependencePattern:
    def test_independence_match(self):
        """e1(A), e2(B) with no causal relation. Independence matches."""
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("A") | Pattern.match("B")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e1 in matches[0].events
        assert e2 in matches[0].events

    def test_independence_no_match(self):
        """e1(A) -> e2(B). Independence does NOT match."""
        p = Poset()
        e1 = Event(name="A")
        e2 = Event(name="B")
        p.add(e1)
        p.add(e2, caused_by=[e1])

        pat = Pattern.match("A") | Pattern.match("B")
        matches = pat.match_in(p)
        assert len(matches) == 0


class TestDisjunctionPattern:
    def test_disjunction(self):
        """P matches Send OR Receive. Poset has both. Returns matches for both."""
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Receive")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send").or_(Pattern.match("Receive"))
        matches = pat.match_in(p)
        assert len(matches) == 2
        matched_names = {m.events[0].name for m in matches}
        assert matched_names == {"Send", "Receive"}

    def test_disjunction_one_side(self):
        """Only Send events in poset. Disjunction still matches (from Send side)."""
        p = Poset()
        e1 = Event(name="Send")
        p.add(e1)

        pat = Pattern.match("Send").or_(Pattern.match("Receive"))
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events[0].name == "Send"


class TestUnionPattern:
    def test_union(self):
        """Similar to disjunction, bindings preserved from matching side."""
        from pyrapide.patterns.base import placeholder

        p = Poset()
        e1 = Event(name="Send", payload={"msg": "hi"})
        e2 = Event(name="Receive", payload={"data": 42})
        p.add(e1)
        p.add(e2)

        m = placeholder("m")
        d = placeholder("d")
        pat = Pattern.match("Send", msg=m).union(Pattern.match("Receive", data=d))
        matches = pat.match_in(p)
        assert len(matches) == 2
        all_bindings = {k: v for match in matches for k, v in match.bindings.items()}
        assert all_bindings["m"] == "hi"
        assert all_bindings["d"] == 42


class TestIterationPattern:
    def test_iteration(self):
        """5 'Error' events in poset. repeat() returns single match with all 5 events."""
        p = Poset()
        errors = []
        for i in range(5):
            e = Event(name="Error", payload={"code": i})
            p.add(e)
            errors.append(e)

        pat = Pattern.match("Error").repeat()
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert len(matches[0].events) == 5
        for e in errors:
            assert e in matches[0].events

    def test_iteration_empty(self):
        """No 'Error' events. repeat() returns empty list."""
        p = Poset()
        p.add(Event(name="Send"))

        pat = Pattern.match("Error").repeat()
        matches = pat.match_in(p)
        assert len(matches) == 0

    def test_iteration_bindings_collected(self):
        """Bindings are collected into lists across all individual matches."""
        from pyrapide.patterns.base import placeholder

        p = Poset()
        for i in range(3):
            p.add(Event(name="Error", payload={"code": i}))

        code = placeholder("code")
        pat = Pattern.match("Error", code=code).repeat()
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert sorted(matches[0].bindings["code"]) == [0, 1, 2]


class TestNestedComposition:
    def test_nested_composition(self):
        """(Send >> (Process & Log)) — sequence into a join."""
        p = Poset()
        e_send = Event(name="Send")
        e_proc = Event(name="Process")
        e_log = Event(name="Log")
        p.add(e_send)
        p.add(e_proc, caused_by=[e_send])
        p.add(e_log, caused_by=[e_send])

        pat = Pattern.match("Send") >> (Pattern.match("Process") & Pattern.match("Log"))
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert e_send in matches[0].events
        assert e_proc in matches[0].events
        assert e_log in matches[0].events


class TestOperatorSyntax:
    def test_operator_syntax(self):
        """Verify P >> Q, P & Q, P | Q create the correct pattern types."""
        p = Pattern.match("A")
        q = Pattern.match("B")

        assert isinstance(p >> q, SequencePattern)
        assert isinstance(p & q, JoinPattern)
        assert isinstance(p | q, IndependencePattern)
