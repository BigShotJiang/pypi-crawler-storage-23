from pyrapide import Event, Poset
from pyrapide.core.clock import SynchronousClock
from pyrapide.patterns.base import Pattern


class TestTimedPattern:
    def _make_stamped_poset(self):
        """Helper: create a poset with events stamped at clock times 0, 5, 10."""
        clock = SynchronousClock(name="sys")
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Send")
        e3 = Event(name="Send")
        p.add(e1)
        clock.stamp(e1)
        clock.tick(5.0)
        p.add(e2, caused_by=[e1])
        clock.stamp(e2)
        clock.tick(5.0)
        p.add(e3, caused_by=[e2])
        clock.stamp(e3)
        return p, clock, e1, e2, e3

    def test_timed_pattern_max_duration(self):
        p, clock, e1, e2, e3 = self._make_stamped_poset()

        # max_duration=5.0: events at t=0 and t=5 fit; t=0 and t=10 don't
        pat = Pattern.match("Send").timed(clock, max_duration=5.0)
        matches = pat.match_in(p)
        # All 3 individual Send matches pass because max_duration checks the
        # span of events within each PatternMatch. Each BasicPattern match is
        # a single event, so span is 0 which is <= 5.0
        assert len(matches) == 3

        # Now test with a sequence spanning time
        seq = (Pattern.match("Send") >> Pattern.match("Send")).timed(clock, max_duration=6.0)
        matches = seq.match_in(p)
        # e1->e2 (span 5), e1->e3 (span 10), e2->e3 (span 5)
        # Only e1->e2 and e2->e3 fit within 6.0
        for m in matches:
            times = [clock.start_time(e) for e in m.events]
            assert max(times) - min(times) <= 6.0

    def test_timed_pattern_after(self):
        p, clock, e1, e2, e3 = self._make_stamped_poset()

        pat = Pattern.match("Send").timed(clock, after=4.0)
        matches = pat.match_in(p)
        # e1 at t=0 excluded; e2 at t=5 and e3 at t=10 included
        assert len(matches) == 2

    def test_timed_pattern_before(self):
        p, clock, e1, e2, e3 = self._make_stamped_poset()

        pat = Pattern.match("Send").timed(clock, before=6.0)
        matches = pat.match_in(p)
        # e1 at t=0 and e2 at t=5 included; e3 at t=10 excluded
        assert len(matches) == 2

    def test_timed_pattern_window(self):
        p, clock, e1, e2, e3 = self._make_stamped_poset()

        pat = Pattern.match("Send").timed(clock, after=2.0, before=8.0)
        matches = pat.match_in(p)
        # Only e2 at t=5 is within (2.0, 8.0)
        assert len(matches) == 1
        assert matches[0].events[0] is e2
