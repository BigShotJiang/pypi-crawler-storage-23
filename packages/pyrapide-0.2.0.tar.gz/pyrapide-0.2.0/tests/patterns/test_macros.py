from pyrapide import Event, Poset
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.patterns.macros import pattern_macro, PatternLibrary


class TestPatternMacro:
    def test_pattern_macro_decorator(self):
        @pattern_macro
        def any_send():
            return Pattern.match("Send")

        assert any_send._pyrapide_is_pattern_macro is True
        pat = any_send()
        assert isinstance(pat, Pattern)

    def test_pattern_macro_with_args(self):
        @pattern_macro
        def request_response(service: str):
            return Pattern.match(f"{service}.Request") >> Pattern.match(f"{service}.Response")

        pat = request_response("Auth")

        p = Poset()
        e1 = Event(name="Auth.Request")
        e2 = Event(name="Auth.Response")
        p.add(e1)
        p.add(e2, caused_by=[e1])

        matches = pat.match_in(p)
        assert len(matches) == 1


class TestPatternLibrary:
    def test_pattern_library(self):
        lib = PatternLibrary()

        @pattern_macro
        def error_pattern(code: int):
            return Pattern.match("Error", code=code)

        lib.register("error", error_pattern)

        pat = lib.get("error", code=404)
        assert isinstance(pat, Pattern)

        p = Poset()
        e1 = Event(name="Error", payload={"code": 404})
        e2 = Event(name="Error", payload={"code": 500})
        p.add(e1)
        p.add(e2)

        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events[0].payload["code"] == 404
