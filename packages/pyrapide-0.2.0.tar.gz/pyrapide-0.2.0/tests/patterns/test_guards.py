from pyrapide import Event, Poset
from pyrapide.patterns.base import Pattern, PatternMatch, placeholder


class TestGuardedPattern:
    def test_guard_filters_matches(self):
        p = Poset()
        e1 = Event(name="Send", payload={"message": "hi"})
        e2 = Event(name="Send", payload={"message": "hello world"})
        p.add(e1)
        p.add(e2)

        msg = placeholder("m")
        pat = Pattern.match("Send", message=msg).where(
            lambda m: len(m.bindings["m"]) > 5
        )
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].bindings["m"] == "hello world"

    def test_guard_passes_all(self):
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Send")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send").where(lambda m: True)
        matches = pat.match_in(p)
        assert len(matches) == 2

    def test_guard_rejects_all(self):
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Send")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send").where(lambda m: False)
        matches = pat.match_in(p)
        assert len(matches) == 0

    def test_guard_with_composite(self):
        p = Poset()
        e1 = Event(name="Send", payload={"size": 10})
        e2 = Event(name="Ack", payload={"ok": True})
        p.add(e1)
        p.add(e2, caused_by=[e1])

        sz = placeholder("sz")
        pat = (Pattern.match("Send", size=sz) >> Pattern.match("Ack")).where(
            lambda m: m.bindings["sz"] > 5
        )
        matches = pat.match_in(p)
        assert len(matches) == 1

        # Now with a guard that rejects
        pat2 = (Pattern.match("Send", size=sz) >> Pattern.match("Ack")).where(
            lambda m: m.bindings["sz"] > 100
        )
        matches2 = pat2.match_in(p)
        assert len(matches2) == 0
