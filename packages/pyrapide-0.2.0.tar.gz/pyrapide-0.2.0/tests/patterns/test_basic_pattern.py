import pytest

from pyrapide import Event, Poset
from pyrapide.patterns.base import (
    BasicPattern,
    Pattern,
    PatternMatch,
    Placeholder,
    placeholder,
)


class TestBasicMatchByName:
    def test_basic_match_by_name(self):
        p = Poset()
        e1 = Event(name="Send", source="c1")
        e2 = Event(name="Receive", source="c2")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events == (e1,)

    def test_basic_match_wildcard(self):
        p = Poset()
        e1 = Event(name="Send")
        e2 = Event(name="Receive")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("*")
        matches = pat.match_in(p)
        assert len(matches) == 2


class TestBasicMatchFields:
    def test_basic_match_with_field_value(self):
        p = Poset()
        e1 = Event(name="Send", payload={"message": "hello"})
        e2 = Event(name="Send", payload={"message": "world"})
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send", message="hello")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events == (e1,)

    def test_basic_match_with_placeholder(self):
        p = Poset()
        e1 = Event(name="Send", payload={"message": "hello"})
        p.add(e1)

        msg = placeholder("msg")
        pat = Pattern.match("Send", message=msg)
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].bindings["msg"] == "hello"

    def test_basic_match_multiple_fields(self):
        p = Poset()
        e1 = Event(name="Send", payload={"to": "bob", "priority": 1})
        e2 = Event(name="Send", payload={"to": "bob", "priority": 2})
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send", to="bob", priority=1)
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events == (e1,)


class TestBasicMatchSource:
    def test_basic_match_with_source(self):
        p = Poset()
        e1 = Event(name="Send", source="client_1")
        e2 = Event(name="Send", source="client_2")
        p.add(e1)
        p.add(e2)

        pat = Pattern.match("Send", source="client_1")
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].events == (e1,)

    def test_basic_match_source_placeholder(self):
        p = Poset()
        e1 = Event(name="Send", source="client_1")
        p.add(e1)

        src = placeholder("src")
        pat = Pattern.match("Send", source=src)
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].bindings["src"] == "client_1"


class TestBasicMatchEdgeCases:
    def test_basic_match_no_match(self):
        p = Poset()
        e1 = Event(name="Receive")
        p.add(e1)

        pat = Pattern.match("Send")
        matches = pat.match_in(p)
        assert matches == []

    def test_basic_match_multiple_matches(self):
        p = Poset()
        for _ in range(3):
            p.add(Event(name="Send"))

        pat = Pattern.match("Send")
        matches = pat.match_in(p)
        assert len(matches) == 3


class TestPatternMatch:
    def test_pattern_match_immutability(self):
        e = Event(name="Send")
        pm = PatternMatch(events=(e,), bindings={"x": 1})
        with pytest.raises(AttributeError):
            pm.events = (Event(name="Other"),)  # type: ignore[misc]
        with pytest.raises(AttributeError):
            pm.bindings = {}  # type: ignore[misc]

    def test_pattern_match_bindings(self):
        p = Poset()
        e = Event(name="Send", payload={"x": 42, "y": "hi"}, source="src1")
        p.add(e)

        xp = placeholder("xval")
        yp = placeholder("yval")
        sp = placeholder("src")
        pat = Pattern.match("Send", source=sp, x=xp, y=yp)
        matches = pat.match_in(p)
        assert len(matches) == 1
        assert matches[0].bindings == {"xval": 42, "yval": "hi", "src": "src1"}


class TestPlaceholder:
    def test_placeholder_equality(self):
        a = placeholder("msg")
        b = placeholder("msg")
        assert a == b
        assert hash(a) == hash(b)

    def test_placeholder_inequality(self):
        a = placeholder("msg")
        b = placeholder("src")
        assert a != b
