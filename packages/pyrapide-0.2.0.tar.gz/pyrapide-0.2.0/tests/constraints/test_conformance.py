import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.constraints.pattern_constraints import must_match, never
from pyrapide.constraints.conformance import check_conformance


class TestConformance:
    def test_conformance_all_pass(self):
        """Computation satisfies all constraints."""
        comp = Computation()
        req = Event(name="Request", payload={"id": "1"})
        resp = Event(name="Response", payload={"request_id": "1"})
        comp.record(req)
        comp.record(resp, caused_by=[req])

        constraints = [
            must_match(
                Pattern.match("Request") >> Pattern.match("Response"),
                name="need_rr",
            ),
            never(Pattern.match("Error"), name="no_errors"),
        ]

        violations = check_conformance(comp, constraints)
        assert len(violations) == 0

    def test_conformance_some_fail(self):
        """Computation violates some constraints."""
        comp = Computation()
        comp.record(Event(name="Error", payload={"code": 500}))
        comp.record(Event(name="Request", payload={"id": "1"}))
        # No Response event

        req_p = placeholder("req")
        constraints = [
            must_match(
                Pattern.match("Request", id=req_p)
                >> Pattern.match("Response", request_id=req_p),
                name="need_rr",
            ),
            never(Pattern.match("Error"), name="no_errors"),
            must_match(Pattern.match("Init"), name="need_init"),
        ]

        violations = check_conformance(comp, constraints)
        assert len(violations) >= 2
        names = {v.constraint_name for v in violations}
        # need_rr violated (no response), no_errors violated (Error present),
        # need_init violated (no Init)
        assert "no_errors" in names
        assert "need_init" in names
