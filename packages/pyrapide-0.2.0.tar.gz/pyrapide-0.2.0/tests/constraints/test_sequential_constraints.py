import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.constraints.pattern_constraints import must_match, never


class TestSequentialConstraints:
    def test_sequence_must_match_multiple_pairs(self):
        """Each Request must be followed by a Response — test with multiple pairs."""
        comp = Computation()
        r1 = Event(name="Request", payload={"id": "1"})
        s1 = Event(name="Response", payload={"request_id": "1"})
        r2 = Event(name="Request", payload={"id": "2"})
        s2 = Event(name="Response", payload={"request_id": "2"})

        comp.record(r1)
        comp.record(s1, caused_by=[r1])
        comp.record(r2)
        comp.record(s2, caused_by=[r2])

        req_p = placeholder("req")
        c = must_match(
            Pattern.match("Request", id=req_p)
            >> Pattern.match("Response", request_id=req_p),
            name="all_requests_responded",
        )
        violations = c.check(comp)
        assert len(violations) == 0

    def test_sequence_no_response_at_all(self):
        """No request-response pair exists — must_match violations."""
        comp = Computation()
        r1 = Event(name="Request", payload={"id": "1"})
        r2 = Event(name="Request", payload={"id": "2"})
        # No Response events at all

        comp.record(r1)
        comp.record(r2)

        req_p = placeholder("req")
        c = must_match(
            Pattern.match("Request", id=req_p)
            >> Pattern.match("Response", request_id=req_p),
            name="all_requests_responded",
        )
        violations = c.check(comp)
        assert len(violations) == 1

    def test_sequence_partial_match_still_satisfies(self):
        """must_match is existential: one matching pair satisfies it even if others are unmatched."""
        comp = Computation()
        r1 = Event(name="Request", payload={"id": "1"})
        s1 = Event(name="Response", payload={"request_id": "1"})
        r2 = Event(name="Request", payload={"id": "2"})
        # r2 has no response, but r1->s1 exists

        comp.record(r1)
        comp.record(s1, caused_by=[r1])
        comp.record(r2)

        req_p = placeholder("req")
        c = must_match(
            Pattern.match("Request", id=req_p)
            >> Pattern.match("Response", request_id=req_p),
            name="at_least_one_pair",
        )
        violations = c.check(comp)
        # Existential: at least one match exists, so no violation
        assert len(violations) == 0

    def test_never_out_of_order(self):
        """Never should a Shutdown precede an Init in causal order."""
        comp = Computation()
        shutdown = Event(name="Shutdown", payload={})
        init = Event(name="Init", payload={})
        comp.record(shutdown)
        comp.record(init, caused_by=[shutdown])

        c = never(
            Pattern.match("Shutdown") >> Pattern.match("Init"),
            name="no_restart_after_shutdown",
        )
        violations = c.check(comp)
        assert len(violations) >= 1

    def test_causal_independence_not_sequential(self):
        """Independent events don't satisfy sequence constraints."""
        comp = Computation()
        a = Event(name="A", payload={})
        b = Event(name="B", payload={})
        comp.record(a)
        comp.record(b)  # No causal link — independent

        c = must_match(
            Pattern.match("A") >> Pattern.match("B"),
            name="a_then_b",
        )
        violations = c.check(comp)
        # No causal link means sequence doesn't match
        assert len(violations) == 1
