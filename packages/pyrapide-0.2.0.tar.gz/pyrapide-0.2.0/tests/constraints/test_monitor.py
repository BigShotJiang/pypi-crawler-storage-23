import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.constraints.pattern_constraints import (
    ConstraintViolation,
    must_match,
    never,
)
from pyrapide.constraints.monitor import AsyncConstraintMonitor, ConstraintMonitor


class TestMonitorNoViolations:
    def test_monitor_no_violations(self):
        """Feed 10 clean events. No violations."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        for i in range(10):
            violations = monitor.check(Event(name="OK", payload={"i": i}))
            assert len(violations) == 0

        assert len(monitor.violations) == 0


class TestMonitorNeverViolation:
    def test_monitor_detects_never_violation(self):
        """Feed events that form a forbidden pattern. Violation detected."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        # Clean events first
        monitor.check(Event(name="Request", payload={}))
        monitor.check(Event(name="Response", payload={}))

        # Now a forbidden event
        violations = monitor.check(Event(name="Error", payload={"code": 500}))
        assert len(violations) >= 1
        assert violations[0].constraint_name == "no_errors"
        assert violations[0].violation_type == "never_violated"


class TestMonitorMustMatchAtEnd:
    def test_monitor_detects_must_match_at_end(self):
        """After feeding all events, check if expected pattern exists."""
        monitor = ConstraintMonitor()
        req_p = placeholder("req")
        monitor.add_constraint(
            must_match(
                Pattern.match("Request", id=req_p)
                >> Pattern.match("Response", request_id=req_p),
                name="need_rr",
            )
        )

        # Feed request without response — must_match not yet satisfied
        r1 = Event(name="Request", payload={"id": "1"})
        violations = monitor.check(r1)
        # must_match still not satisfied (no response yet)
        assert any(v.constraint_name == "need_rr" for v in violations)

        # Feed response causally linked to request
        s1 = Event(name="Response", payload={"request_id": "1"})
        monitor.record_causal_link(r1, s1)
        violations = monitor.check(s1)
        # Now the pattern should be satisfied
        must_match_violations = [v for v in violations if v.constraint_name == "need_rr"]
        assert len(must_match_violations) == 0


class TestMonitorIncremental:
    def test_monitor_incremental(self):
        """Feed events one at a time. Violation detected on the specific event
        that completes the forbidden pattern."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(
            never(
                Pattern.match("Shutdown") >> Pattern.match("Init"),
                name="no_init_after_shutdown",
            )
        )

        # First event: Shutdown — no violation yet (sequence incomplete)
        shutdown = Event(name="Shutdown", payload={})
        violations = monitor.check(shutdown)
        shutdown_violations = [v for v in violations if v.constraint_name == "no_init_after_shutdown"]
        assert len(shutdown_violations) == 0

        # Second event: Init caused by Shutdown — now the forbidden sequence exists
        init = Event(name="Init", payload={})
        monitor.record_causal_link(shutdown, init)
        violations = monitor.check(init)
        assert any(v.constraint_name == "no_init_after_shutdown" for v in violations)


class TestMonitorReset:
    def test_monitor_reset(self):
        """Feed events, reset, feed again. State is fresh."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        # Trigger a violation
        monitor.check(Event(name="Error", payload={"code": 500}))
        assert len(monitor.violations) >= 1

        # Reset clears state
        monitor.reset()
        assert len(monitor.violations) == 0

        # Constraints are still registered
        assert len(monitor.constraint_names) == 1

        # Feed clean events — no violations
        monitor.check(Event(name="OK", payload={}))
        assert len(monitor.violations) == 0


class TestMonitorMultipleConstraints:
    def test_monitor_multiple_constraints(self):
        """Two constraints, one violated, one satisfied. Returns only the violated one."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(must_match(Pattern.match("Init"), name="need_init"))
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        # Feed Init (satisfies need_init) and no Error (satisfies no_errors)
        monitor.check(Event(name="Init", payload={}))
        monitor.check(Event(name="OK", payload={}))

        # At this point need_init is satisfied and no_errors is satisfied
        # Check final state via check on the last event
        all_violations = monitor.violations
        # need_init should be satisfied (Init was recorded)
        need_init_v = [v for v in all_violations if v.constraint_name == "need_init"]
        no_errors_v = [v for v in all_violations if v.constraint_name == "no_errors"]
        assert len(need_init_v) == 0
        assert len(no_errors_v) == 0

    def test_monitor_one_violated_one_satisfied(self):
        """One constraint violated, one satisfied."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(must_match(Pattern.match("Init"), name="need_init"))
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        # Feed Error only — need_init violated (no Init), no_errors violated (Error present)
        violations = monitor.check(Event(name="Error", payload={}))
        names = {v.constraint_name for v in monitor.violations}
        assert "no_errors" in names


class TestMonitorCausalLink:
    def test_monitor_causal_link(self):
        """Record causal link between events. Pattern involving causality correctly detected."""
        monitor = ConstraintMonitor()
        req_p = placeholder("req")
        monitor.add_constraint(
            must_match(
                Pattern.match("Request", id=req_p)
                >> Pattern.match("Response", request_id=req_p),
                name="rr_pair",
            )
        )

        # Add request
        r = Event(name="Request", payload={"id": "42"})
        monitor.check(r)

        # Add response (not yet causally linked)
        s = Event(name="Response", payload={"request_id": "42"})
        monitor.check(s)

        # Without causal link, the sequence pattern won't match
        rr_violations = [v for v in monitor.violations if v.constraint_name == "rr_pair"]
        assert len(rr_violations) > 0  # Still violated — no causal link

        # Now add the causal link
        monitor.record_causal_link(r, s)

        # Re-check: the pattern should now be satisfied
        # We need to trigger a re-evaluation
        dummy = Event(name="Ping", payload={})
        monitor.check(dummy)
        rr_violations = [v for v in monitor.violations if v.constraint_name == "rr_pair"]
        assert len(rr_violations) == 0


class TestMonitorViolationsAccumulate:
    def test_monitor_violations_accumulate(self):
        """Feed multiple violations. violations property returns all."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        monitor.check(Event(name="Error", payload={"code": 500}))
        monitor.check(Event(name="Error", payload={"code": 404}))
        monitor.check(Event(name="Error", payload={"code": 503}))

        # All three errors should be recorded as violations
        assert len(monitor.violations) >= 3


class TestMonitorRemoveAndList:
    def test_monitor_remove_constraint(self):
        """Monitor can remove constraints by name."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))
        monitor.add_constraint(must_match(Pattern.match("A"), name="need_a"))

        monitor.remove_constraint("no_errors")
        assert "no_errors" not in monitor.constraint_names
        assert "need_a" in monitor.constraint_names

    def test_monitor_list_constraints(self):
        """Monitor can list all registered constraint names."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(must_match(Pattern.match("A"), name="c1"))
        monitor.add_constraint(never(Pattern.match("B"), name="c2"))

        assert monitor.constraint_names == ["c1", "c2"]


class TestMonitorCheckBatch:
    def test_check_batch(self):
        """check_batch processes multiple events at once."""
        monitor = ConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        events = [
            Event(name="OK", payload={}),
            Event(name="Error", payload={"code": 500}),
            Event(name="OK", payload={}),
        ]
        violations = monitor.check_batch(events)
        assert any(v.constraint_name == "no_errors" for v in violations)


class TestAsyncConstraintMonitor:
    async def test_async_monitor_stream(self):
        """Create an async generator yielding events. Monitor detects violations in stream."""

        async def event_source():
            yield Event(name="Start", payload={})
            yield Event(name="OK", payload={})
            yield Event(name="Error", payload={"code": 500})
            yield Event(name="OK", payload={})
            yield Event(name="Error", payload={"code": 404})

        monitor = AsyncConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        collected_violations: list[ConstraintViolation] = []

        def on_violation(v: ConstraintViolation) -> None:
            collected_violations.append(v)

        await monitor.monitor_stream(event_source(), on_violation=on_violation)

        # Should have detected at least 2 violations (one per Error event)
        assert len(collected_violations) >= 2
        assert all(v.constraint_name == "no_errors" for v in collected_violations)

    async def test_async_check(self):
        """Async check works like sync check."""
        monitor = AsyncConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        violations = await monitor.async_check(Event(name="OK", payload={}))
        assert len(violations) == 0

        violations = await monitor.async_check(Event(name="Error", payload={"code": 500}))
        assert len(violations) >= 1

    async def test_async_check_batch(self):
        """Async check_batch processes multiple events."""
        monitor = AsyncConstraintMonitor()
        monitor.add_constraint(never(Pattern.match("Error"), name="no_errors"))

        events = [
            Event(name="OK", payload={}),
            Event(name="Error", payload={"code": 500}),
        ]
        violations = await monitor.async_check_batch(events)
        assert any(v.constraint_name == "no_errors" for v in violations)
