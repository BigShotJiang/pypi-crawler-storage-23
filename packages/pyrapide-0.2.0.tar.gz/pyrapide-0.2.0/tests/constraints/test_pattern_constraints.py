import time

import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.constraints.pattern_constraints import (
    Constraint,
    ConstraintViolation,
    MustMatch,
    Never,
    constraint,
    must_match,
    never,
)


class TestMustMatch:
    def test_must_match_satisfied(self):
        """Computation has the expected pattern. check() returns empty list."""
        comp = Computation()
        req = Event(name="Request", payload={"id": "r1"})
        resp = Event(name="Response", payload={"request_id": "r1"})
        comp.record(req)
        comp.record(resp, caused_by=[req])

        req_p = placeholder("req")
        c = must_match(
            Pattern.match("Request", id=req_p)
            >> Pattern.match("Response", request_id=req_p),
            name="request_response",
        )
        violations = c.check(comp)
        assert len(violations) == 0

    def test_must_match_violated(self):
        """Computation lacks the pattern. check() returns one violation."""
        comp = Computation()
        req = Event(name="Request", payload={"id": "r1"})
        comp.record(req)
        # No Response event

        req_p = placeholder("req")
        c = must_match(
            Pattern.match("Request", id=req_p)
            >> Pattern.match("Response", request_id=req_p),
            name="request_response",
        )
        violations = c.check(comp)
        assert len(violations) == 1
        assert violations[0].constraint_name == "request_response"
        assert violations[0].violation_type == "must_match_failed"

    def test_must_match_with_placeholders(self):
        """Pattern with placeholders; satisfied when binding exists."""
        comp = Computation()
        e1 = Event(name="Send", payload={"message": "hello", "dest": "server"})
        comp.record(e1)

        msg = placeholder("msg")
        dest = placeholder("dest")
        c = must_match(
            Pattern.match("Send", message=msg, dest=dest),
            name="send_exists",
        )
        violations = c.check(comp)
        assert len(violations) == 0

    def test_must_match_with_placeholders_violated(self):
        """Pattern with placeholders; violated when no event matches."""
        comp = Computation()
        e1 = Event(name="Receive", payload={"data": "x"})
        comp.record(e1)

        msg = placeholder("msg")
        c = must_match(
            Pattern.match("Send", message=msg),
            name="need_send",
        )
        violations = c.check(comp)
        assert len(violations) == 1


class TestNever:
    def test_never_satisfied(self):
        """Computation has no forbidden pattern. check() returns empty list."""
        comp = Computation()
        req = Event(name="Request", payload={"id": "r1"})
        resp = Event(name="Response", payload={"request_id": "r1"})
        comp.record(req)
        comp.record(resp, caused_by=[req])

        req_p = placeholder("req")
        c = never(
            Pattern.match("Response", request_id=req_p)
            >> Pattern.match("Request", id=req_p),
            name="no_response_before_request",
        )
        violations = c.check(comp)
        assert len(violations) == 0

    def test_never_violated(self):
        """Computation contains the forbidden pattern. check() returns violation with matched events."""
        comp = Computation()
        resp = Event(name="Response", payload={"request_id": "r1"})
        req = Event(name="Request", payload={"id": "r1"})
        comp.record(resp)
        comp.record(req, caused_by=[resp])

        req_p = placeholder("req")
        c = never(
            Pattern.match("Response", request_id=req_p)
            >> Pattern.match("Request", id=req_p),
            name="no_response_before_request",
        )
        violations = c.check(comp)
        assert len(violations) >= 1
        assert violations[0].constraint_name == "no_response_before_request"
        assert violations[0].violation_type == "never_violated"
        assert len(violations[0].matched_events) > 0

    def test_never_with_sequence(self):
        """never(P >> Q). Violated when P causes Q."""
        comp = Computation()
        shutdown = Event(name="Shutdown", payload={})
        init = Event(name="Init", payload={})
        comp.record(shutdown)
        comp.record(init, caused_by=[shutdown])

        c = never(
            Pattern.match("Shutdown") >> Pattern.match("Init"),
            name="no_init_after_shutdown",
        )
        violations = c.check(comp)
        assert len(violations) >= 1
        assert violations[0].violation_type == "never_violated"
        # Matched events should include both Shutdown and Init
        event_names = {e.name for e in violations[0].matched_events}
        assert "Shutdown" in event_names
        assert "Init" in event_names

    def test_never_multiple_violations(self):
        """never reports each occurrence as a violation."""
        comp = Computation()
        e1 = Event(name="Error", payload={"code": 500})
        e2 = Event(name="Error", payload={"code": 500})
        comp.record(e1)
        comp.record(e2)

        c = never(
            Pattern.match("Error") | Pattern.match("Error"),
            name="no_independent_errors",
        )
        violations = c.check(comp)
        assert len(violations) >= 1


class TestConstraintDecorator:
    def test_constraint_decorator(self):
        """Define a @constraint class with must_match and never. Extract constraints."""

        @constraint
        class OrderingConstraint:
            """Every Request must get a Response."""
            name = "ordering"

            def define(self):
                req_p = placeholder("req")
                must_match(
                    Pattern.match("Request", id=req_p)
                    >> Pattern.match("Response", request_id=req_p),
                    name="request_needs_response",
                )
                never(
                    Pattern.match("Error"),
                    name="no_errors",
                )

        c = OrderingConstraint()
        assert isinstance(c, Constraint)
        assert c.name == "ordering"
        assert len(c.constraints) == 2

    def test_multiple_constraints(self):
        """Multiple must_match and never in one class. All checked."""

        @constraint
        class StrictProtocol:
            name = "strict_protocol"

            def define(self):
                must_match(Pattern.match("Init"), name="need_init")
                must_match(Pattern.match("Ready"), name="need_ready")
                never(Pattern.match("Error"), name="no_errors")
                never(Pattern.match("Timeout"), name="no_timeouts")

        c = StrictProtocol()
        assert len(c.constraints) == 4

        # All four violated: no Init, no Ready, and Error + Timeout present
        comp = Computation()
        comp.record(Event(name="Error", payload={}))
        comp.record(Event(name="Timeout", payload={}))
        violations = c.check(comp)
        assert len(violations) == 4
        names = {v.constraint_name for v in violations}
        assert names == {"need_init", "need_ready", "no_errors", "no_timeouts"}

    def test_constraint_decorator_with_rules_method(self):
        """@constraint also works with rules() method."""

        @constraint
        class SimpleConstraint:
            name = "simple"

            def rules(self):
                never(Pattern.match("Crash"), name="no_crash")

        c = SimpleConstraint()
        comp = Computation()
        comp.record(Event(name="Crash", payload={}))
        violations = c.check(comp)
        assert len(violations) == 1

    def test_constraint_decorator_check(self):
        """A @constraint class correctly checks its rules against a computation."""

        @constraint
        class NoErrorConstraint:
            name = "no_errors"

            def define(self):
                never(Pattern.match("Error"), name="no_errors_allowed")

        c = NoErrorConstraint()

        comp = Computation()
        comp.record(Event(name="Request", payload={}))
        assert len(c.check(comp)) == 0

        comp2 = Computation()
        comp2.record(Event(name="Error", payload={"code": 500}))
        violations = c.check(comp2)
        assert len(violations) >= 1


class TestConstraintViolation:
    def test_constraint_violation_details(self):
        """Violation has correct name, type, description."""
        before = time.time()
        v = ConstraintViolation(
            constraint_name="test_constraint",
            violation_type="must_match_failed",
            description="Required pattern not found",
            matched_events=[],
        )
        after = time.time()

        assert v.constraint_name == "test_constraint"
        assert v.violation_type == "must_match_failed"
        assert v.description == "Required pattern not found"
        assert v.matched_events == []
        assert before <= v.timestamp <= after

    def test_violation_with_matched_events(self):
        """ConstraintViolation stores matched events for never violations."""
        e = Event(name="Error", payload={"code": 500})
        v = ConstraintViolation(
            constraint_name="no_errors",
            violation_type="never_violated",
            description="Forbidden pattern matched",
            matched_events=[e],
        )
        assert v.violation_type == "never_violated"
        assert len(v.matched_events) == 1
        assert v.matched_events[0].name == "Error"
