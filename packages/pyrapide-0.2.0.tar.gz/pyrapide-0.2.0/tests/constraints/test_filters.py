import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern
from pyrapide.types.actions import action, provides
from pyrapide.types.interface import interface
from pyrapide.constraints.filters import AlphabetFilter, PatternFilter


class TestPatternFilter:
    def test_pattern_filter(self):
        """Filter computation to only 'Request' and 'Response' events."""
        comp = Computation()
        req = Event(name="Request", payload={"id": "1"})
        resp = Event(name="Response", payload={"request_id": "1"})
        log = Event(name="Log", payload={"msg": "debug"})
        err = Event(name="Error", payload={"code": 500})

        comp.record(req)
        comp.record(resp, caused_by=[req])
        comp.record(log)
        comp.record(err)

        filtered = PatternFilter.filter_computation(
            comp,
            [Pattern.match("Request"), Pattern.match("Response")],
        )

        event_names = {e.name for e in filtered.events}
        assert event_names == {"Request", "Response"}
        assert len(filtered.events) == 2

    def test_filter_preserves_causality(self):
        """Filtered computation preserves causal edges between surviving events."""
        comp = Computation()
        a = Event(name="Request", payload={"id": "1"})
        b = Event(name="Process", payload={})
        c = Event(name="Response", payload={"request_id": "1"})

        comp.record(a)
        comp.record(b, caused_by=[a])
        comp.record(c, caused_by=[b])

        # Filter to only Request and Response — Process is removed
        filtered = PatternFilter.filter_computation(
            comp,
            [Pattern.match("Request"), Pattern.match("Response")],
        )

        assert len(filtered.events) == 2
        # The causal edge a->c is preserved (both endpoints survive)
        # Note: the intermediate b is removed, so the direct a->c edge
        # only exists if there was a direct edge in the original.
        # Since a->b->c, there is no direct a->c edge, so causality
        # is preserved only for direct edges.
        req_event = next(e for e in filtered.events if e.name == "Request")
        resp_event = next(e for e in filtered.events if e.name == "Response")

        # Direct edge a->b and b->c existed, but not a->c.
        # So in the filtered poset, they should be independent (no direct link).
        assert filtered.are_independent(req_event, resp_event)

    def test_filter_preserves_direct_causality(self):
        """When both endpoints of a causal edge survive, the edge is preserved."""
        comp = Computation()
        a = Event(name="Request", payload={"id": "1"})
        b = Event(name="Response", payload={"request_id": "1"})
        c = Event(name="Log", payload={})

        comp.record(a)
        comp.record(b, caused_by=[a])  # Direct edge a -> b
        comp.record(c)

        filtered = PatternFilter.filter_computation(
            comp,
            [Pattern.match("Request"), Pattern.match("Response")],
        )

        assert len(filtered.events) == 2
        req_event = next(e for e in filtered.events if e.name == "Request")
        resp_event = next(e for e in filtered.events if e.name == "Response")
        assert filtered.is_ancestor(req_event, resp_event)

    def test_filter_empty(self):
        """Filter that matches nothing returns empty computation."""
        comp = Computation()
        comp.record(Event(name="Request", payload={}))
        comp.record(Event(name="Response", payload={}))

        filtered = PatternFilter.filter_computation(
            comp,
            [Pattern.match("NonExistent")],
        )

        assert len(filtered.events) == 0


class TestAlphabetFilter:
    def test_alphabet_filter(self):
        """Filter computation by an interface's event alphabet."""

        @interface
        class MyService:
            @provides
            @action
            def query(self, sql: str) -> list:
                ...

            @provides
            @action
            def insert(self, data: dict) -> int:
                ...

        comp = Computation()
        # Events in the alphabet
        q = Event(name="MyService.query", payload={"sql": "SELECT 1"})
        i = Event(name="MyService.insert", payload={"data": {}})
        # Event NOT in the alphabet
        x = Event(name="Other.event", payload={})

        comp.record(q)
        comp.record(i, caused_by=[q])
        comp.record(x)

        filtered = AlphabetFilter.filter_by_alphabet(comp, MyService)

        event_names = {e.name for e in filtered.events}
        assert event_names == {"MyService.query", "MyService.insert"}
        assert len(filtered.events) == 2

    def test_alphabet_filter_preserves_causality(self):
        """Alphabet-filtered computation preserves causal edges."""

        @interface
        class Svc:
            @action
            def start(self) -> None:
                ...

            @action
            def finish(self) -> None:
                ...

        comp = Computation()
        s = Event(name="Svc.start", payload={})
        f = Event(name="Svc.finish", payload={})
        comp.record(s)
        comp.record(f, caused_by=[s])

        filtered = AlphabetFilter.filter_by_alphabet(comp, Svc)

        start_ev = next(e for e in filtered.events if e.name == "Svc.start")
        finish_ev = next(e for e in filtered.events if e.name == "Svc.finish")
        assert filtered.is_ancestor(start_ev, finish_ev)

    def test_alphabet_filter_rejects_non_interface(self):
        """Passing a non-interface class raises TypeError."""

        class NotAnInterface:
            pass

        comp = Computation()
        with pytest.raises(TypeError, match="not a @interface"):
            AlphabetFilter.filter_by_alphabet(comp, NotAnInterface)

    def test_alphabet_filter_empty(self):
        """If no events match the alphabet, returns empty computation."""

        @interface
        class EmptySvc:
            @action
            def do_thing(self) -> None:
                ...

        comp = Computation()
        comp.record(Event(name="Unrelated", payload={}))

        filtered = AlphabetFilter.filter_by_alphabet(comp, EmptySvc)
        assert len(filtered.events) == 0
