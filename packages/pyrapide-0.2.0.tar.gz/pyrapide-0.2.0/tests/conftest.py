# Shared test fixtures will be added as modules are built

import pytest

from pyrapide import Event, Poset


@pytest.fixture
def sample_events():
    """Five named events for general test use."""
    return {
        "e1": Event(name="E1", source="src1"),
        "e2": Event(name="E2", source="src1"),
        "e3": Event(name="E3", source="src2"),
        "e4": Event(name="E4", source="src2"),
        "e5": Event(name="E5", source="src1"),
    }


@pytest.fixture
def linear_poset(sample_events):
    """A 3-event chain: e1 -> e2 -> e3."""
    p = Poset()
    e1, e2, e3 = sample_events["e1"], sample_events["e2"], sample_events["e3"]
    p.add(e1)
    p.add(e2, caused_by=[e1])
    p.add(e3, caused_by=[e2])
    return p, e1, e2, e3


@pytest.fixture
def diamond_poset(sample_events):
    """Diamond: e1 -> e2, e1 -> e3, e2 -> e4, e3 -> e4."""
    p = Poset()
    e1, e2, e3, e4 = (
        sample_events["e1"],
        sample_events["e2"],
        sample_events["e3"],
        sample_events["e4"],
    )
    p.add(e1)
    p.add(e2, caused_by=[e1])
    p.add(e3, caused_by=[e1])
    p.add(e4, caused_by=[e2, e3])
    return p, e1, e2, e3, e4
