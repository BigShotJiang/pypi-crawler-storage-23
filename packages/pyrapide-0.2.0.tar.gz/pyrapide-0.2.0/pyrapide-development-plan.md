# PyRapide: Development Plan

## A Python Library for Causal Event-Driven Architecture Modeling

> *"Just as PySpark rendered the API for Spark, PyRapide renders causal event-driven architectures for Python developers."*

---

## 1. Project Vision & Context

### 1.1 What Is This?

PyRapide is a Python library that implements the semantics of RAPIDE 1.0 — an event-based architecture description language (EADL) developed at Stanford University's Computer Systems Lab (1997). RAPIDE's distinguishing capability is that executing a model produces not just events, but **causal histories** — partially ordered event sets (posets) that capture *why* things happened, not just *what* happened.

PyRapide does not wrap or compile RAPIDE source code. It provides a native Python API that lets developers define interfaces, architectures, event patterns, connections, constraints, and modules using idiomatic Python syntax — decorators, context managers, type hints, async/await — while preserving RAPIDE's formal semantics underneath.

### 1.2 Why Does This Matter Now?

The agentic AI ecosystem — particularly Model Context Protocol (MCP) servers — is producing an explosion of asynchronous, distributed events with no causal traceability. When dozens or hundreds of MCP servers fire events simultaneously, engineers need a way to:

- **Trace causality**: Understand *why* an event happened, not just that it happened.
- **Detect patterns**: Recognize complex event sequences across distributed sources in real time.
- **Enforce constraints**: Define what event patterns are acceptable and unacceptable.
- **Predict outcomes**: Use causal history to forecast future behavior.
- **Maintain human control**: Let engineers define and override orchestration rules with granular precision.

PyRapide provides the formal mathematical foundation for all of this, exposed through a Python API that working engineers can actually use.

### 1.3 Design Principles

1. **Pythonic over academic** — Use decorators, type hints, async/await, and context managers. No one should need to read the 1997 reference manuals to use this library.
2. **Semantically faithful** — The underlying computation model must faithfully implement RAPIDE's poset-based causal semantics. Cutting corners on the math means the causal reasoning is unreliable.
3. **Streaming-first** — Everything must work in real-time streaming contexts. Batch-only analysis is not sufficient for MCP server orchestration.
4. **Composable and extensible** — Architects should be able to compose small event patterns into large ones, nest architectures, and extend the system with custom event sources.
5. **Observable and debuggable** — Posets, pattern matches, and constraint violations should all be inspectable, serializable, and visualizable.

---

## 2. RAPIDE Language Specification Summary

This section maps every major construct from the seven RAPIDE 1.0 reference manuals to what must be implemented in Python. Use this as the definitive checklist.

### 2.1 Core Computation Model (from Overview & Patterns LRM)

The foundation of everything in RAPIDE is the computation model. A **computation** is a set of events with two ordering relations:

| Concept | RAPIDE Definition | Python Implementation Target |
|---|---|---|
| **Event** | Uniquely identifiable tuple of values with identity relation `==` | `Event` dataclass with UUID, timestamp, payload, and source metadata |
| **Causal Preorder (`≤c`)** | Reflexive, antisymmetric, transitive relation; "event A caused event B" | Directed acyclic graph (DAG) edge stored on the `Poset` |
| **Temporal Preorder (`≤t`)** | Reflexive, antisymmetric, transitive relation per clock; "A happened before B on clock t" | Timestamp-based ordering per `Clock` instance |
| **Causal Equivalence (`=c`)** | Two events are causally equivalent if `A ≤c B` and `B ≤c A` | Cycle detection / equivalence class on the DAG |
| **Temporal Equivalence (`=t`)** | Two events are temporally equivalent per a given clock | Same-tick grouping on a `Clock` |
| **Poset** | Partially ordered set of events with causal and temporal orderings | `Poset` class — the central data structure of the entire library |
| **Computation** | A set of events produced by executing a RAPIDE program | `Computation` class wrapping a `Poset` with query/filter methods |

**Key invariant (causal-temporal consistency):**
If `A <c B` (A causally precedes B), then it is never the case that `B <t A` (B temporally precedes A). The library must enforce this.

### 2.2 Types Language (from Types LRM)

RAPIDE has two fundamental type kinds: **interface types** and **function types**, plus **type constructors** for generic parameterization.

| Construct | RAPIDE Syntax | Python Target |
|---|---|---|
| **Interface type** | `type T is interface ... end T;` | Python class decorated with `@interface` |
| **Function type** | `function(X: Integer) return Integer` | `typing.Callable` wrapper or `FunctionType` descriptor |
| **Type constructor** | `type Set(type Element <: Equality(Element)) is ...` | Generic class using `typing.Generic[T]` with bounds |
| **Subtyping** | `T1 <: T2` (structural subtyping) | `__subclasshook__` or Protocol-based structural checks |
| **Provides clause** | `provides action Send(M: Message)` | Methods decorated with `@provides` |
| **Requires clause** | `requires function Compute(X: Integer) return Integer` | Abstract methods decorated with `@requires` |
| **Name declarations** | Actions, functions, variables in interface scope | Class-level declarations with type annotations |

**Interface type components (from Types LRM Chapter 4):**

- **Actions** — Asynchronous operations that generate events. Declared with `action` keyword. In Python: methods decorated `@action`.
- **Functions** — Synchronous operations that return values. In Python: regular methods on the interface class.
- **Variables** — State within an interface. In Python: instance attributes with type annotations.
- **Services** — Sub-interfaces that group related actions/functions. In Python: nested classes or composed interface objects.
- **Behaviors** — Transition rules specifying how an interface reacts to events. In Python: `@behavior` decorated reactive methods.

### 2.3 Architecture Language (from Architectures LRM)

Architectures are the structural compositions — they define *what* components exist and *how* they're connected.

| Construct | RAPIDE Semantics | Python Target |
|---|---|---|
| **Architecture** | Module containing components, connections, and constraints | `@architecture` decorated class |
| **Component** | Declared interface object within an architecture | Instance attributes typed to an interface |
| **Connection (basic)** | `P to Q` — events matching P trigger corresponding events on Q | `connect(source_pattern, target_pattern)` call |
| **Connection (pipe)** | `P ||> Q` — queued, ordered delivery | `pipe(source, target)` with FIFO semantics |
| **Connection (agent)** | `P => Q` — independent concurrent delivery | `agent(source, target)` with async dispatch |
| **Connection generator** | `for all X: T ...` — parametric connections | Loop/comprehension over typed component sets |
| **Service connection** | Connects entire service sub-interfaces | `connect_service(svc_a, svc_b)` |
| **Map** | Defines relationship between two architectures for runtime comparison | `ArchitectureMap` class with mapping rules |
| **Binding** | Binds an interface to a module dynamically | `bind(interface_obj, module)` |

**Connection semantics detail (from Architectures LRM Chapter 3.5):**

The three connection types differ in how causality is tracked:

- **Basic (`to`)**: Events generated by the trigger pattern *directly cause* the generated events. The causal link is immediate. Both sides share the same causal context.
- **Pipe (`||>`)**: Events are queued and delivered in order. The causal link exists but delivery is serialized. Generated events depend on the triggering event *and* on the completion of previously queued events.
- **Agent (`=>`)**: Events are dispatched independently — the connection itself is a separate concurrent agent. Generated events are causally dependent on the trigger but temporally independent of other events generated by the same agent connection.

### 2.4 Event Pattern Language (from Patterns LRM)

Event patterns are the matching/detection language — used in connections, behaviors, constraints, and reactive processes. This is one of the most important subsystems.

| Pattern Type | RAPIDE Syntax | Semantics | Python Target |
|---|---|---|---|
| **Basic pattern** | `X.Send(?M)` | Match a single event; bind values to placeholders | `Pattern.match(event_name, **bindings)` |
| **Sequence** | `P ; Q` | P matched, then later Q matched (P causally before Q) | `P >> Q` operator |
| **Immediate sequence** | `P ~ Q` | P matched, then Q matched with nothing in between | `P.then_immediately(Q)` |
| **Join** | `P and Q` | Both P and Q matched, and they share a common causal ancestor | `P & Q` operator |
| **Independence** | `P || Q` | Both P and Q matched, and they are causally independent | `P | Q` operator |
| **Disjunction** | `P or Q` | Either P or Q matched | `P.or_(Q)` or `PatternOr(P, Q)` |
| **Conjunction** | `P and Q` (no causal requirement) | Both P and Q matched (regardless of causal relation) | Context-dependent; see join |
| **Union** | `P union Q` | Matches any event matched by P or Q, preserving bindings | `P.union(Q)` |
| **Iteration** | `(?X) P(X)` | P matched repeatedly, binding each match | `P.repeat()` or `P.iterate(binding)` |
| **Guarded pattern** | `P where guard_expr` | P matched and guard expression is true | `P.where(lambda ctx: ...)` |
| **Placeholder** | `?X` | Bind matched event or value to variable X | Named capture in pattern definition |
| **Pattern macro** | `pattern_name(args)` | Reusable parameterized pattern | `@pattern_macro` decorated function |
| **Timing operator** | `@T(P)` | P matched with timing constraints from clock T | `P.at_clock(T)` or `P.timed(clock, constraint)` |

**Pattern matching semantics (from Patterns LRM Chapter 1.3):**

A pattern `P` is said to *match* in a computation `C` (written `C |= P`) when there exists a subset of events in C that satisfies the structural and ordering requirements of P. Pattern matching produces **bindings** — assignments of events or values to placeholders. A single pattern may have multiple simultaneous matches in a computation.

### 2.5 Constraint Language (from Constraints LRM)

Constraints specify what is required and what is forbidden in a computation's event history.

| Construct | RAPIDE Syntax | Semantics | Python Target |
|---|---|---|---|
| **Pattern constraint** | `observe ... match P ... end observe;` | Assert that pattern P must match in the filtered computation | `@constraint` with `must_match(P)` |
| **Never constraint** | `never P` | Assert that pattern P must never match | `@constraint` with `never(P)` |
| **Pattern filter** | `from basic_pattern_list` | Only consider events matching the filter patterns | `constraint.filter(patterns)` |
| **Alphabet filter** | Filter by event alphabet of specific interfaces | `constraint.alphabet(interface)` |
| **Map filter** | Filter computation through a map | `constraint.through_map(map)` |
| **Nested constraint** | Constraint within constraint body | Nested `@constraint` definitions |
| **Sequential constraint** | First-order logic predicate on object state | `@invariant` decorator with predicate function |
| **Parameter constraint** | Constraint on function/interface parameters | Type-level constraint annotations |

**Conformance (from Constraints LRM Chapter 1.7):**

A module *conforms* to a constraint if every computation it can produce satisfies the constraint. Constraint checking can be done at runtime (monitoring) or post-hoc (analysis). For MCP server use cases, runtime monitoring is the primary mode.

### 2.6 Executable Language (from Executable LRM)

The executable language provides the imperative/reactive programming constructs.

| Construct | RAPIDE Syntax | Python Target |
|---|---|---|
| **Module generator** | `is module ... begin ... end;` | `@module` class with `__init__` and body |
| **Process** | Reactive execution unit within a module | `async def` coroutine or background `Task` |
| **Action call** | `X.Send(M)` — generates an event | `await self.send(M)` or `self.actions.send(M)` |
| **Reactive statement (await)** | `await P => S` — wait for pattern, then execute | `async for match in pattern.observe(): ...` |
| **Reactive statement (when)** | `when P => S` — whenever pattern matches, execute (persistent) | `@when(pattern) async def handler(match): ...` |
| **Causal generation** | `S1 ; S2` — S2's events are causally dependent on S1's events | `async with causal_context(): ...` |
| **Independent generation** | `S1 || S2` — events are causally independent | `asyncio.gather(s1(), s2())` with independent causal contexts |
| **Serial module** | Module where processes execute one at a time | `@module(serial=True)` |
| **Exception handling** | `begin ... except ... end;` | Standard Python `try/except` |
| **Clock** | Timing source for temporal ordering | `Clock` class with tick/read interface |

**Event generation semantics (from Executable LRM Chapter 7):**

When a module calls an action (e.g., `self.send(M)`), this generates a new event in the computation. The event is causally dependent on:
1. The event(s) that triggered the currently executing reactive statement (if any).
2. Any events generated earlier in the same sequential block.
3. Nothing else (the event is a causal root) if generated in initialization or independently.

### 2.7 Predefined Types (from Predefined Types LRM)

| Type | Description | Python Mapping |
|---|---|---|
| `Boolean` | True/False with and, or, not, xor | `bool` |
| `Integer` | Arbitrary precision integer | `int` |
| `Float` | Floating point | `float` |
| `Character` | Single character | `str` (length 1) |
| `String` | Character sequence | `str` |
| `Record` | Named fields (structural product type) | `@dataclass` or `TypedDict` |
| `Union` | Tagged union / variant type | `Union` type with discriminator |
| `Enumeration` | Finite set of named values | `enum.Enum` |
| `Set(T)` | Unordered collection of T with membership test | `set` or `frozenset` |
| `Array(T, Range)` | Indexed collection | `list` |
| `Range` | Bounded numeric interval | `range` |
| `Map(K, V)` | Key-value mapping | `dict` |
| `Clock` | Timing source; subtypes: synchronous, regular, slaved | `Clock` class hierarchy |
| `Event(params)` | Event with typed payload fields | `Event` dataclass |
| `Triv` | Unit type (single value) | `None` |

**Clock hierarchy (from Executable LRM Chapter 10 / Predefined LRM Chapter 17):**

Clocks form a subtype hierarchy:
- `Clock` — base type; can read current time, has start/finish operations on events
- `SynchronousClock <: Clock` — all modules sharing this clock agree on current time (global synchronous time)
- `RegularClock <: SynchronousClock` — ticks at a fixed period with bounded accuracy
- `SlavedClock <: Clock` — derived from another clock by a function (e.g., divide-by-N)

---

## 3. Package Architecture

```
pyrapide/
├── __init__.py                  # Public API exports
├── core/
│   ├── __init__.py
│   ├── event.py                 # Event, EventId, event identity & creation
│   ├── poset.py                 # Poset (partially ordered event set) — the central data structure
│   ├── computation.py           # Computation — a Poset with query interface
│   ├── causality.py             # Causal ordering engine, DAG management, consistency checks
│   └── clock.py                 # Clock hierarchy: Clock, SynchronousClock, RegularClock, SlavedClock
├── types/
│   ├── __init__.py
│   ├── interface.py             # @interface decorator, InterfaceType metaclass
│   ├── actions.py               # @action, @provides, @requires decorators
│   ├── services.py              # Service grouping within interfaces
│   ├── function_types.py        # FunctionType wrapper, subtyping for callables
│   ├── type_constructors.py     # Generic parameterized type support
│   └── subtyping.py             # Structural subtype checking engine
├── patterns/
│   ├── __init__.py
│   ├── base.py                  # Pattern ABC, BasicPattern, placeholder system
│   ├── composite.py             # Sequence, Join, Independence, Disjunction, Union, Iteration
│   ├── guards.py                # Guarded patterns (where clauses)
│   ├── macros.py                # @pattern_macro decorator and pattern composition
│   ├── matching.py              # Pattern matching engine — core algorithm against a Poset
│   └── timing.py                # Timed patterns, clock-qualified matching
├── architecture/
│   ├── __init__.py
│   ├── architecture.py          # @architecture decorator, Architecture class
│   ├── connections.py           # Basic, Pipe, Agent connections; connection generators
│   ├── communication.py         # Communication model: who can talk to whom and when
│   ├── maps.py                  # Architecture maps for cross-architecture comparison
│   └── bindings.py              # Dynamic interface-to-module bindings
├── constraints/
│   ├── __init__.py
│   ├── pattern_constraints.py   # @constraint, must_match, never
│   ├── sequential_constraints.py # @invariant — first-order logic on state
│   ├── filters.py               # Pattern filters, alphabet filters, map filters
│   ├── conformance.py           # Conformance checking engine
│   └── monitor.py               # Real-time constraint monitoring for streaming
├── executable/
│   ├── __init__.py
│   ├── module.py                # @module decorator, module generator, module lifecycle
│   ├── process.py               # Process management, multiple concurrent processes
│   ├── reactive.py              # @when decorator, await pattern, reactive statements
│   ├── statements.py            # Sequential statements: if, case, loop, exit
│   └── exceptions.py            # Exception and interrupt handling
├── runtime/
│   ├── __init__.py
│   ├── engine.py                # Simulation/execution engine — orchestrates everything
│   ├── scheduler.py             # Event scheduling, causal ordering enforcement
│   ├── streaming.py             # Streaming event ingestion and real-time processing
│   └── serialization.py         # Poset/computation serialization (JSON, protobuf, etc.)
├── integrations/
│   ├── __init__.py
│   ├── mcp.py                   # MCP server adapter — wraps MCP events as PyRapide events
│   ├── llm.py                   # LLM call/response event instrumentation
│   └── opentelemetry.py         # OpenTelemetry span-to-event bridge
├── analysis/
│   ├── __init__.py
│   ├── queries.py               # Poset queries: ancestors, descendants, critical path, etc.
│   ├── visualization.py         # Poset visualization (Graphviz DOT, Mermaid, JSON for UI)
│   ├── prediction.py            # Causal prediction engine — forecast future events from history
│   └── anomaly.py               # Anomaly detection on event patterns
└── utils/
    ├── __init__.py
    ├── ids.py                   # UUID/ULID generation for events
    ├── logging.py               # Structured logging for PyRapide internals
    └── config.py                # Library configuration and defaults
```

---

## 4. Development Phases

### Phase 1: Core Computation Model

**Goal**: Build the mathematical foundation — events, posets, causal ordering, and clocks. Everything else depends on this being correct.

#### Step 1.1: Event Primitives

Create `pyrapide/core/event.py`.

An Event must have:
- A globally unique identity (UUID or ULID)
- A name/type identifier (e.g., `"Send"`, `"Receive"`)
- A typed payload (dictionary of named values)
- A source identifier (which interface/module generated it)
- A creation timestamp
- Immutability after creation

```python
# Target API example:
from pyrapide import Event

evt = Event(name="Send", payload={"message": "hello", "dest": "server_2"}, source="client_1")
assert evt.id is not None
assert evt.timestamp is not None
```

**Validation**:
- [ ] Events are immutable after creation.
- [ ] Two events with the same data but created separately have different identities.
- [ ] Event equality (`==`) is based on identity, not structural content.
- [ ] Events are hashable and can be used as dict keys and set members.
- [ ] Serialization round-trips (JSON encode → decode → identical event).

**Tests to write**:
```
tests/core/test_event.py
  - test_event_creation
  - test_event_immutability
  - test_event_identity_uniqueness
  - test_event_equality_is_identity_based
  - test_event_hashability
  - test_event_serialization_roundtrip
  - test_event_payload_types
```

#### Step 1.2: Poset (Partially Ordered Event Set)

Create `pyrapide/core/poset.py`.

The Poset is the central data structure. It stores events and two ordering relations:
- **Causal ordering**: A directed acyclic graph where edge `(A, B)` means "A causally precedes B."
- **Temporal ordering**: Per-clock timestamp ordering.

The Poset must enforce the **causal-temporal consistency invariant**: if `A <c B`, then `¬(B <t A)`.

```python
# Target API example:
from pyrapide import Poset, Event

poset = Poset()

e1 = Event(name="Request", payload={"url": "/api/data"})
e2 = Event(name="Fetch", payload={"source": "db"})
e3 = Event(name="Response", payload={"status": 200})

poset.add(e1)
poset.add(e2, caused_by=[e1])       # e1 -> e2
poset.add(e3, caused_by=[e1, e2])   # e1 -> e3, e2 -> e3

assert poset.is_ancestor(e1, e3)     # True: e1 causally precedes e3
assert not poset.is_ancestor(e3, e1) # False: no reverse causation
assert poset.are_independent(e1, e2) is False  # e1 causes e2
assert poset.ancestors(e3) == {e1, e2}
assert poset.descendants(e1) == {e2, e3}
```

**Validation**:
- [ ] Causal ordering is a valid DAG (no cycles).
- [ ] Adding a causal edge that would create a cycle raises `CausalCycleError`.
- [ ] Causal-temporal consistency is enforced: adding events that violate it raises `CausalTemporalViolation`.
- [ ] Transitivity queries work: if A → B → C, then `is_ancestor(A, C)` returns True.
- [ ] Concurrent (independent) event detection works.
- [ ] Poset can be filtered by event type, source, time range.
- [ ] Poset serialization preserves full structure.

**Tests to write**:
```
tests/core/test_poset.py
  - test_add_event_with_no_causes
  - test_add_event_with_single_cause
  - test_add_event_with_multiple_causes
  - test_cycle_detection_raises
  - test_causal_temporal_consistency
  - test_ancestor_query
  - test_descendant_query
  - test_independence_check
  - test_causal_equivalence
  - test_filter_by_event_type
  - test_filter_by_source
  - test_filter_by_time_range
  - test_poset_serialization_roundtrip
  - test_large_poset_performance (1000+ events)
```

#### Step 1.3: Clocks

Create `pyrapide/core/clock.py`.

Implement the RAPIDE clock hierarchy:

```python
# Target API:
from pyrapide import SynchronousClock, RegularClock, SlavedClock

# Global synchronous time
gst = SynchronousClock("global")

# A clock ticking every 100ms
fast_clock = RegularClock("sensor_clock", period_ms=100)

# A clock derived from another: ticks every 10th tick of parent
slow_clock = SlavedClock("aggregation_clock", parent=fast_clock, divisor=10)
```

**Validation**:
- [ ] SynchronousClock keeps global agreement.
- [ ] RegularClock ticks at configured intervals.
- [ ] SlavedClock derives correctly from parent.
- [ ] Events can be stamped with multiple clocks.
- [ ] Temporal ordering is consistent within each clock.

**Tests to write**:
```
tests/core/test_clock.py
  - test_synchronous_clock_creation
  - test_regular_clock_ticking
  - test_slaved_clock_derivation
  - test_multi_clock_event_stamping
  - test_temporal_ordering_per_clock
```

#### Step 1.4: Computation

Create `pyrapide/core/computation.py`.

A Computation wraps a Poset with query and analysis methods.

```python
from pyrapide import Computation

comp = Computation()
comp.record(e1)
comp.record(e2, caused_by=[e1])

# Query interface
recent = comp.events_since(timestamp)
causal_chain = comp.causal_chain(e1, e3)  # Returns path
roots = comp.root_events()  # Events with no causes
leaves = comp.leaf_events()  # Events with no effects
```

**Tests to write**:
```
tests/core/test_computation.py
  - test_record_and_query
  - test_causal_chain_extraction
  - test_root_and_leaf_events
  - test_events_since_timestamp
  - test_computation_merge (combine two computations)
```

---

### Phase 2: Type System

**Goal**: Implement interface types, function types, actions, services, subtyping, and the `@interface` decorator system.

#### Step 2.1: Interface Type Decorator

Create `pyrapide/types/interface.py` and `pyrapide/types/actions.py`.

```python
# Target API:
from pyrapide import interface, action, provides, requires

@interface
class MessageBroker:
    """An interface for sending and receiving messages."""

    @provides
    @action
    async def send(self, destination: str, payload: dict) -> None:
        """Generates a Send event."""
        ...

    @provides
    @action
    async def receive(self) -> dict:
        """Generates a Receive event when called."""
        ...

    @requires
    def validate(self, payload: dict) -> bool:
        """Must be implemented by any module conforming to this interface."""
        ...
```

**Implementation notes**:
- `@interface` transforms the class into a RAPIDE interface type. It registers all `@action` methods, extracts `provides`/`requires` declarations, and creates the interface's event alphabet.
- `@action` marks a method as event-generating. When called at runtime, it creates an Event in the current computation and links it to the causal context.
- `@provides` marks externally visible operations.
- `@requires` marks operations that must be supplied by implementing modules (like abstract methods).

**Validation**:
- [ ] `@interface` classes can be introspected for their action list, provides set, and requires set.
- [ ] Attempting to instantiate an interface with unimplemented `@requires` raises `ConformanceError`.
- [ ] Actions generate events when called within a running computation.
- [ ] The event alphabet (set of all possible event names) is derivable from the interface.

**Tests to write**:
```
tests/types/test_interface.py
  - test_interface_decorator_registers_actions
  - test_provides_requires_extraction
  - test_event_alphabet_derivation
  - test_requires_enforcement
  - test_interface_introspection
```

#### Step 2.2: Services

Create `pyrapide/types/services.py`.

Services group related actions and functions within an interface.

```python
@interface
class DatabaseServer:

    class ReadService:
        @action
        async def query(self, sql: str) -> list: ...

        @action
        async def get_by_id(self, table: str, id: int) -> dict: ...

    class WriteService:
        @action
        async def insert(self, table: str, data: dict) -> int: ...

        @action
        async def update(self, table: str, id: int, data: dict) -> None: ...
```

**Validation**:
- [ ] Services are accessible as sub-interfaces.
- [ ] Service-level connections are supported (connect all actions in a service).
- [ ] Service actions appear in the parent interface's event alphabet.

#### Step 2.3: Structural Subtyping

Create `pyrapide/types/subtyping.py`.

RAPIDE uses structural subtyping: `T1 <: T2` if T1 provides at least everything T2 provides. This matches Python's Protocol model.

```python
from pyrapide import interface, is_subtype

@interface
class BasicSender:
    @action
    async def send(self, msg: str): ...

@interface
class AdvancedSender:
    @action
    async def send(self, msg: str): ...

    @action
    async def send_batch(self, msgs: list[str]): ...

assert is_subtype(AdvancedSender, BasicSender)  # True: AdvancedSender has everything BasicSender has
assert not is_subtype(BasicSender, AdvancedSender)  # False: missing send_batch
```

**Tests to write**:
```
tests/types/test_subtyping.py
  - test_structural_subtype_match
  - test_structural_subtype_mismatch
  - test_function_type_contravariance
  - test_interface_type_covariance_on_provides
```

#### Step 2.4: Behaviors and Transition Rules

Create behavior support in `pyrapide/types/interface.py`.

Behaviors define how an interface reacts to its own events — they are transition rules.

```python
@interface
class Thermostat:
    temperature: float = 72.0
    target: float = 72.0

    @action
    async def temp_reading(self, value: float): ...

    @action
    async def heat_on(self): ...

    @action
    async def heat_off(self): ...

    @behavior
    async def regulate(self):
        """When a temp reading comes in below target, turn heat on."""
        async for match in self.observe(self.temp_reading):
            if match.payload["value"] < self.target:
                await self.heat_on()
            else:
                await self.heat_off()
```

---

### Phase 3: Event Pattern Language

**Goal**: Implement the full pattern matching engine. This is the most algorithmically complex part of the library.

#### Step 3.1: Basic Patterns and Placeholders

Create `pyrapide/patterns/base.py`.

```python
from pyrapide.patterns import Pattern, placeholder

# Match any Send event, capturing the message payload
msg = placeholder("msg")
p = Pattern.match("Send", message=msg)

# Match a specific source
p2 = Pattern.match("Send", source="client_1")
```

**Implementation**: A basic pattern matches a single event by name and optionally by payload field values. Placeholders are unbound variables that get filled during matching.

#### Step 3.2: Composite Patterns

Create `pyrapide/patterns/composite.py`.

```python
from pyrapide.patterns import Pattern, placeholder

msg = placeholder("msg")
ack = placeholder("ack_id")

# Sequence: Send happens, then later Ack happens (causally ordered)
send_then_ack = Pattern.match("Send", message=msg) >> Pattern.match("Ack", id=ack)

# Independence: two events with no causal relation
independent_reads = Pattern.match("Read", source="db1") | Pattern.match("Read", source="db2")

# Join: two events that share a common causal ancestor
coordinated = Pattern.match("PartA") & Pattern.match("PartB")

# Guarded: pattern with runtime condition
large_payload = Pattern.match("Send", message=msg).where(lambda ctx: len(ctx["msg"]) > 1000)

# Iteration: match repeated occurrences
all_errors = Pattern.match("Error").repeat()
```

**Operator mapping from RAPIDE to Python**:

| RAPIDE | Python operator | Method alternative |
|---|---|---|
| `P ; Q` (sequence) | `P >> Q` | `P.then(Q)` |
| `P ~ Q` (immediate sequence) | — | `P.then_immediately(Q)` |
| `P and Q` (join) | `P & Q` | `P.join(Q)` |
| `P \|\| Q` (independence) | `P \| Q` | `P.independent(Q)` |
| `P or Q` (disjunction) | — | `P.or_(Q)` |
| `P union Q` | — | `P.union(Q)` |
| `(?X) P(X)` (iteration) | — | `P.repeat()` / `P.iterate(binding)` |
| `P where guard` | — | `P.where(predicate)` |

#### Step 3.3: Pattern Matching Engine

Create `pyrapide/patterns/matching.py`.

This is the core algorithm. Given a pattern P and a computation C (or streaming event feed), determine all matches.

```python
from pyrapide.patterns import Pattern, match_pattern
from pyrapide import Computation

comp = Computation(...)

# Find all matches of a pattern in a computation
matches = match_pattern(send_then_ack, comp)
for m in matches:
    print(f"Send event: {m.events[0]}, Ack event: {m.events[1]}")
    print(f"Bound message: {m.bindings['msg']}")
```

**Key algorithmic concerns**:
- Pattern matching against a poset is not just sequential string matching — it must respect causal and temporal ordering.
- Sequence patterns (`P >> Q`) require that the matched events satisfy `P_event <c Q_event`.
- Join patterns (`P & Q`) require a common causal ancestor.
- Independence patterns (`P | Q`) require `¬(P_event ≤c Q_event) ∧ ¬(Q_event ≤c P_event)`.
- The engine must handle streaming (incremental matching as new events arrive).

**Validation**:
- [ ] Basic pattern matches correct events by name and payload.
- [ ] Sequence pattern respects causal ordering.
- [ ] Independence pattern correctly identifies causally unrelated events.
- [ ] Join pattern correctly identifies common ancestors.
- [ ] Guarded patterns evaluate predicates correctly.
- [ ] Iteration collects all repeated matches.
- [ ] Streaming matching emits matches as new events arrive.

**Tests to write**:
```
tests/patterns/test_basic_pattern.py
tests/patterns/test_sequence.py
tests/patterns/test_join.py
tests/patterns/test_independence.py
tests/patterns/test_disjunction.py
tests/patterns/test_guards.py
tests/patterns/test_iteration.py
tests/patterns/test_streaming_match.py
tests/patterns/test_complex_composition.py  # Nested composite patterns
```

#### Step 3.4: Pattern Macros

Create `pyrapide/patterns/macros.py`.

```python
from pyrapide.patterns import pattern_macro, Pattern, placeholder

@pattern_macro
def request_response(service_name: str):
    req = placeholder("req")
    resp = placeholder("resp")
    return (
        Pattern.match(f"{service_name}.Request", data=req)
        >> Pattern.match(f"{service_name}.Response", data=resp)
    )

# Usage
http_rr = request_response("HTTP")
```

---

### Phase 4: Architecture & Connections

**Goal**: Implement architecture definitions, the three connection types, and the communication model.

#### Step 4.1: Architecture Decorator

Create `pyrapide/architecture/architecture.py`.

```python
from pyrapide import architecture, interface, connect, pipe, agent

@architecture
class ClientServerArch:
    client: ClientInterface
    server: ServerInterface
    database: DatabaseInterface

    def connections(self):
        # Basic connection: client requests trigger server processing
        connect(
            source=Pattern.match("client.Request"),
            target=lambda match: self.server.process(match.bindings["data"])
        )

        # Pipe connection: server queries are queued to database
        pipe(
            source=Pattern.match("server.Query"),
            target=lambda match: self.database.execute(match.bindings["sql"])
        )

        # Agent connection: logging happens independently
        agent(
            source=Pattern.match("*"),  # All events
            target=lambda match: self.logger.log(match.event)
        )
```

**Validation**:
- [ ] Architecture declares components with typed interfaces.
- [ ] Connections are established during architecture initialization.
- [ ] Basic connections create direct causal links.
- [ ] Pipe connections queue events in FIFO order.
- [ ] Agent connections dispatch independently with separate causal contexts.
- [ ] Connection generators work with `for_all` comprehensions over typed component sets.

**Tests to write**:
```
tests/architecture/test_architecture_creation.py
tests/architecture/test_basic_connection.py
tests/architecture/test_pipe_connection.py
tests/architecture/test_agent_connection.py
tests/architecture/test_connection_generator.py
tests/architecture/test_communication_model.py
```

#### Step 4.2: Communication Model

Create `pyrapide/architecture/communication.py`.

The communication model defines who can observe whose events. From the Architectures LRM Chapter 4:

- A module can observe its own events.
- The parent architecture can observe all component events.
- A module linked to another module can observe the linked module's events.
- Communication happens either through events (async) or function calls (sync).

```python
# The communication model is enforced by the runtime
# Modules can only react to events they are allowed to observe

@module(implements=ServerInterface)
class Server:
    @when(Pattern.match("Request"))  # Can observe own events
    async def handle_request(self, match):
        ...
        # Cannot observe client.internal_event — not in communication scope
```

---

### Phase 5: Constraints & Monitoring

**Goal**: Implement constraint definitions and real-time constraint monitoring.

#### Step 5.1: Pattern Constraints

Create `pyrapide/constraints/pattern_constraints.py`.

```python
from pyrapide.constraints import constraint, must_match, never

@constraint
class OrderingConstraint:
    """Every Request must eventually get a Response."""

    filter = Pattern.match("Request").union(Pattern.match("Response"))

    def body(self):
        req = placeholder("req")
        resp = placeholder("resp")

        must_match(
            Pattern.match("Request", id=req)
            >> Pattern.match("Response", request_id=req)
        )

        never(
            Pattern.match("Response", request_id=req)
            >> Pattern.match("Request", id=req)  # Response before Request
        )
```

#### Step 5.2: Real-Time Constraint Monitor

Create `pyrapide/constraints/monitor.py`.

This is critical for the MCP server use case. The monitor watches a live event stream and reports violations as they occur.

```python
from pyrapide.constraints import ConstraintMonitor

monitor = ConstraintMonitor()
monitor.add_constraint(OrderingConstraint())
monitor.add_constraint(LatencyConstraint(max_ms=500))

# Stream events to the monitor
async for event in mcp_event_stream:
    violations = await monitor.check(event)
    for v in violations:
        print(f"VIOLATION: {v.constraint_name}: {v.description}")
```

**Validation**:
- [ ] `must_match` constraints correctly detect missing patterns.
- [ ] `never` constraints correctly detect forbidden patterns.
- [ ] Filters correctly limit the event scope.
- [ ] Monitor handles streaming events incrementally.
- [ ] Monitor reports violations with full context (which events, which constraint).

**Tests to write**:
```
tests/constraints/test_must_match.py
tests/constraints/test_never.py
tests/constraints/test_filters.py
tests/constraints/test_monitor_streaming.py
tests/constraints/test_conformance_check.py
```

---

### Phase 6: Executable Modules & Runtime

**Goal**: Implement module generators, reactive processes, and the execution engine.

#### Step 6.1: Module Definition

Create `pyrapide/executable/module.py`.

```python
from pyrapide import module, interface, when, action

@module(implements=ServerInterface)
class ServerModule:
    request_count: int = 0

    async def start(self):
        """Called when the module starts executing."""
        print("Server starting")

    @when(Pattern.match("Request"))
    async def handle_request(self, match):
        self.request_count += 1
        data = await self.process(match.bindings["data"])
        await self.respond(data)  # Generates Response event, causally linked to Request

    async def finish(self):
        """Called when the module is finalized."""
        print(f"Server handled {self.request_count} requests")
```

#### Step 6.2: Execution Engine

Create `pyrapide/runtime/engine.py`.

The engine orchestrates everything: it creates modules, runs processes, delivers events through connections, and builds the computation poset.

```python
from pyrapide.runtime import Engine

engine = Engine()
arch = engine.instantiate(ClientServerArch)

# Run the architecture (async event loop)
async with engine.run(arch) as computation:
    # Inject external events (e.g., from MCP servers)
    await engine.inject(Event(name="ExternalTrigger", payload={...}))

    # Wait for completion or timeout
    await engine.wait(timeout=30)

# Analyze the resulting computation
print(f"Total events: {len(computation.events)}")
print(f"Causal depth: {computation.max_causal_depth()}")
```

**Validation**:
- [ ] Modules initialize and start correctly.
- [ ] Reactive `@when` handlers fire on matching events.
- [ ] Causal links are correctly established between triggering events and generated events.
- [ ] Multiple concurrent processes execute correctly.
- [ ] Module finalization runs when computation completes.
- [ ] External event injection integrates with the causal model.

**Tests to write**:
```
tests/executable/test_module_lifecycle.py
tests/executable/test_reactive_when.py
tests/executable/test_causal_linking.py
tests/executable/test_concurrent_processes.py
tests/executable/test_serial_module.py
tests/runtime/test_engine_basic.py
tests/runtime/test_engine_injection.py
```

---

### Phase 7: Streaming & MCP Integration

**Goal**: Build the real-time streaming infrastructure and MCP server adapter.

#### Step 7.1: Streaming Event Processor

Create `pyrapide/runtime/streaming.py`.

```python
from pyrapide.runtime import StreamProcessor

processor = StreamProcessor()

# Register event sources
processor.add_source("mcp_server_1", mcp_adapter_1)
processor.add_source("mcp_server_2", mcp_adapter_2)
processor.add_source("sensor_bus", sensor_adapter)

# Register patterns to watch
processor.watch(request_response_pattern, callback=on_rr_match)
processor.watch(anomaly_pattern, callback=on_anomaly)

# Register constraints
processor.enforce(ordering_constraint)

# Run (processes all sources concurrently)
await processor.run()
```

**Key requirements**:
- Process events from multiple sources concurrently.
- Maintain a sliding window of recent events for pattern matching (configurable retention).
- Emit pattern matches in real time.
- Detect constraint violations in real time.
- Handle backpressure when event rate exceeds processing capacity.

#### Step 7.2: MCP Server Adapter

Create `pyrapide/integrations/mcp.py`.

```python
from pyrapide.integrations import MCPAdapter

# Wrap an MCP server as a PyRapide event source
adapter = MCPAdapter(
    server_url="http://localhost:3000",
    name="data_retrieval_server"
)

# MCP tool calls become events
# MCP tool results become events
# Causal links: tool_call -> tool_result
# Causal links: llm_request -> tool_call (if context available)

async for event in adapter.events():
    print(f"MCP Event: {event.name} from {event.source}")
```

**MCP event mapping**:

| MCP Concept | PyRapide Event |
|---|---|
| Tool call initiated | `Event("mcp.tool_call", {tool, args, server})` |
| Tool result returned | `Event("mcp.tool_result", {tool, result, server})` |
| Resource read | `Event("mcp.resource_read", {uri, content})` |
| Prompt sent | `Event("mcp.prompt", {name, args})` |
| Error | `Event("mcp.error", {tool, error, server})` |
| Server connected | `Event("mcp.connect", {server, capabilities})` |
| Server disconnected | `Event("mcp.disconnect", {server, reason})` |

**Causal links established automatically**:
- `tool_call → tool_result` (same invocation)
- `prompt → tool_call` (prompt triggered the call)
- `resource_read → tool_result` (if resource was used to produce result)

---

### Phase 8: Analysis & Prediction

**Goal**: Build the analysis, visualization, and prediction capabilities.

#### Step 8.1: Poset Queries

Create `pyrapide/analysis/queries.py`.

```python
from pyrapide.analysis import queries

# Find the critical path (longest causal chain)
critical = queries.critical_path(computation)

# Find all root causes of a specific event
roots = queries.root_causes(computation, error_event)

# Find all events affected by a specific event
impact = queries.impact_set(computation, config_change_event)

# Compute causal distance between two events
distance = queries.causal_distance(computation, event_a, event_b)

# Find common ancestors of two events
common = queries.common_ancestors(computation, event_a, event_b)

# Slice: extract sub-computation relevant to a specific event
sliced = queries.backward_slice(computation, target_event)
```

#### Step 8.2: Visualization

Create `pyrapide/analysis/visualization.py`.

```python
from pyrapide.analysis import visualize

# Generate Graphviz DOT
dot_string = visualize.to_dot(computation, highlight=error_events)

# Generate Mermaid diagram
mermaid_string = visualize.to_mermaid(computation)

# Generate JSON for custom UIs
json_data = visualize.to_json(computation)

# Filter visualization by time range or event types
filtered_viz = visualize.to_dot(
    computation,
    event_types=["Request", "Response", "Error"],
    time_range=(start, end)
)
```

#### Step 8.3: Prediction Engine

Create `pyrapide/analysis/prediction.py`.

This is the forward-looking capability — using historical causal patterns to predict what events are likely to happen next.

```python
from pyrapide.analysis import PredictionEngine

predictor = PredictionEngine()

# Train on historical computations
for historical_comp in training_data:
    predictor.learn(historical_comp)

# Given current partial computation, predict likely next events
predictions = predictor.predict(
    current_computation,
    horizon=10,  # Predict up to 10 events ahead
    confidence_threshold=0.7
)

for pred in predictions:
    print(f"Likely next: {pred.event_name} (confidence: {pred.confidence:.2f})")
    print(f"  Expected cause: {pred.likely_cause}")
    print(f"  Expected timing: {pred.expected_time}")
```

**Implementation approaches** (select during development):
- Frequent causal subgraph mining on historical posets.
- Markov models over event type sequences with causal conditioning.
- Graph neural networks on poset structure (for complex patterns).
- Start simple (frequency-based), iterate to more sophisticated models.

---

## 5. Testing Strategy

### 5.1 Test Organization

```
tests/
├── conftest.py              # Shared fixtures: sample events, posets, interfaces
├── core/
│   ├── test_event.py
│   ├── test_poset.py
│   ├── test_clock.py
│   └── test_computation.py
├── types/
│   ├── test_interface.py
│   ├── test_actions.py
│   ├── test_services.py
│   └── test_subtyping.py
├── patterns/
│   ├── test_basic_pattern.py
│   ├── test_composite_patterns.py
│   ├── test_guards.py
│   ├── test_macros.py
│   ├── test_matching_engine.py
│   └── test_streaming_match.py
├── architecture/
│   ├── test_architecture.py
│   ├── test_connections.py
│   └── test_communication.py
├── constraints/
│   ├── test_pattern_constraints.py
│   ├── test_sequential_constraints.py
│   └── test_monitor.py
├── executable/
│   ├── test_module.py
│   ├── test_process.py
│   └── test_reactive.py
├── runtime/
│   ├── test_engine.py
│   ├── test_streaming.py
│   └── test_serialization.py
├── integrations/
│   ├── test_mcp_adapter.py
│   └── test_opentelemetry.py
├── analysis/
│   ├── test_queries.py
│   ├── test_visualization.py
│   └── test_prediction.py
└── scenarios/
    ├── test_producer_consumer.py      # Classic RAPIDE example
    ├── test_dining_philosophers.py    # Classic RAPIDE example
    ├── test_client_server.py          # Simple client-server architecture
    ├── test_mcp_multi_server.py       # Multiple MCP servers interacting
    └── test_anomaly_detection.py      # Streaming anomaly detection scenario
```

### 5.2 Testing Approach Per Phase

Each phase should be developed with this cycle:

1. **Write interface tests first** — Define the target API in test form before implementing.
2. **Implement minimum viable version** — Get tests passing with the simplest correct implementation.
3. **Add edge case tests** — Boundary conditions, error cases, concurrency issues.
4. **Performance tests** — Ensure acceptable performance at target scale (1000+ events for posets, 100+ concurrent event sources for streaming).
5. **Integration tests** — Test the phase's components working together with previous phases.

### 5.3 Key Scenario Tests

These end-to-end tests validate that the library works as a coherent system:

**Scenario 1: Producer-Consumer Pipeline** (from RAPIDE overview document, Section 3.5)
- Define Producer and Consumer interfaces with Send/Receive actions.
- Connect with pipe connection.
- Verify correct causal ordering in the resulting poset.
- This is a baseline correctness test from the original RAPIDE documentation.

**Scenario 2: MCP Multi-Server Orchestration**
- Define 3 MCP server adapters (tools, resources, memory).
- Define an architecture connecting them through an LLM coordinator.
- Stream 100 concurrent events.
- Verify causal traceability from LLM prompt through tool calls to final responses.
- Verify constraint: every tool_call gets a tool_result within 5 seconds.

**Scenario 3: Anomaly Detection Pipeline**
- Define a sensor architecture with 10 sensor interfaces.
- Define normal behavior patterns and constraint violations.
- Stream 1000 events with injected anomalies.
- Verify the constraint monitor catches all injected anomalies.
- Verify the prediction engine identifies likely future anomalies.

---

## 6. Development Dependencies

```toml
# pyproject.toml
[project]
name = "pyrapide"
version = "0.1.0"
description = "Python library for causal event-driven architecture modeling"
requires-python = ">=3.11"

dependencies = [
    "networkx>=3.0",           # DAG operations for posets
    "pydantic>=2.0",           # Data validation for events, configs
    "typing-extensions>=4.0",  # Advanced type hints
]

[project.optional-dependencies]
streaming = [
    "aiokafka>=0.9",           # Kafka integration for high-volume streaming
    "aiohttp>=3.9",            # Async HTTP for MCP server communication
]
viz = [
    "graphviz>=0.20",          # Poset visualization
]
prediction = [
    "numpy>=1.24",             # Numerical computation for prediction
    "scikit-learn>=1.3",       # ML models for prediction
]
mcp = [
    "mcp>=1.0",                # MCP SDK
]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "pytest-benchmark>=4.0",
    "mypy>=1.8",
    "ruff>=0.3",
    "coverage>=7.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

---

## 7. Claude Code Session Workflow

When working in Claude Code, follow this sequence for each phase:

### Session Template

```
1. ORIENT
   - State which phase and step you're working on.
   - Review the target API from this document.
   - Review any existing code from previous phases.

2. TEST FIRST
   - Create the test file for this step.
   - Write tests covering the target API, edge cases, and error conditions.
   - Run tests to confirm they all fail (red phase).

3. IMPLEMENT
   - Create the source file(s).
   - Implement the minimum code to pass the tests.
   - Run tests after each meaningful code change.

4. REFINE
   - Add type hints to all public APIs.
   - Add docstrings with usage examples.
   - Run mypy for type checking.
   - Run ruff for style/lint.

5. INTEGRATE
   - Run ALL tests (not just current phase) to catch regressions.
   - Write one integration test showing the new feature working with previous phases.

6. DOCUMENT
   - Update __init__.py exports.
   - Add a brief usage example in the module docstring.
```

### Phase-Specific Claude Code Instructions

**Phase 1 prompt pattern**:
> "Implement PyRapide Phase 1, Step 1.X: [Event Primitives / Poset / Clocks / Computation]. Follow the spec in the development plan. Write tests first in `tests/core/test_X.py`, then implement in `pyrapide/core/X.py`. Use Python 3.11+ with async support, dataclasses, and type hints. Run all tests after implementation."

**Phase 2 prompt pattern**:
> "Implement PyRapide Phase 2, Step 2.X: [Interface Decorator / Services / Subtyping / Behaviors]. The core event/poset system from Phase 1 is already implemented. Build on top of it. Write tests first, then implement. Ensure interface actions generate real Events on the Poset when called."

**Phase 3 prompt pattern**:
> "Implement PyRapide Phase 3, Step 3.X: [Basic Patterns / Composite Patterns / Matching Engine / Macros]. This is the most algorithmically complex phase. The pattern matching engine must match against poset structure, respecting causal and temporal ordering. Start with basic patterns, build up to composite. Write extensive tests including the RAPIDE specification examples (producer-consumer, dining philosophers)."

**Phase 4-8 follow the same pattern, building on previous phases.**

---

## 8. Key Risks and Mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| Pattern matching performance on large posets | Unusable for real-time MCP monitoring | Use incremental matching; maintain pre-computed indices; benchmark at every step |
| Causal cycle detection at scale | Slow event ingestion | Use NetworkX's efficient DAG algorithms; cache transitivity results |
| Memory growth from unbounded event history | OOM in long-running streaming scenarios | Implement configurable event retention / sliding window with causal-preserving eviction |
| Async complexity in reactive statements | Deadlocks, race conditions | Use `asyncio` primitives carefully; write concurrency tests; consider `trio` as alternative |
| Predefined types bloat | Over-engineering types that map trivially to Python builtins | Use Python builtins directly where semantics match; only create wrapper types when RAPIDE semantics diverge |

---

## 9. Glossary (RAPIDE → PyRapide)

| RAPIDE Term | PyRapide Equivalent | Description |
|---|---|---|
| Interface type | `@interface` class | Defines external behavior of a component |
| Module | `@module` class | Implementation of an interface |
| Architecture | `@architecture` class | Composition of components with connections |
| Action | `@action` method | Async operation that generates events |
| Event | `Event` instance | Immutable record of something that happened |
| Poset | `Poset` instance | Set of events with causal + temporal ordering |
| Computation | `Computation` instance | A poset produced by an execution |
| Event pattern | `Pattern` instance | Template for matching events in a poset |
| Connection rule | `connect()` / `pipe()` / `agent()` | Communication link between components |
| Constraint | `@constraint` | Required or forbidden event patterns |
| Process | `async` coroutine in a module | Concurrent unit of execution |
| Behavior | `@behavior` method | Reactive transition rule on an interface |
| Service | Nested class within `@interface` | Grouped sub-interface |
| Clock | `Clock` instance | Source of temporal ordering |
| Map | `ArchitectureMap` | Cross-architecture relationship |
| Binding | `bind()` | Dynamic interface-to-module association |
| Placeholder | `placeholder()` | Unbound variable in a pattern |
| Pattern macro | `@pattern_macro` | Reusable parameterized pattern definition |
| Conformance | `is_subtype()` / `conforms_to()` | Whether a module satisfies an interface or constraint |
