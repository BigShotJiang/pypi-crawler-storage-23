from __future__ import annotations

from collections.abc import AsyncIterable, Callable
from typing import Any

from pyrapide.constraints.pattern_constraints import (
    Constraint,
    ConstraintViolation,
    MustMatch,
    Never,
)
from pyrapide.core.computation import Computation
from pyrapide.core.event import Event


class ConstraintMonitor:
    """Watches a live event stream and checks constraints incrementally.

    Maintains an internal Computation that grows as events arrive.
    Tracks all violations detected so far.
    """

    def __init__(self) -> None:
        self._constraints: list[Constraint] = []
        self._computation = Computation()
        self._violations: list[ConstraintViolation] = []
        # Track which MustMatch constraints have been satisfied
        self._must_match_satisfied: dict[str, bool] = {}

    def add_constraint(self, constraint: Constraint) -> None:
        """Register a constraint to monitor."""
        self._constraints.append(constraint)
        if isinstance(constraint, MustMatch):
            self._must_match_satisfied[constraint.name] = False

    def remove_constraint(self, name: str) -> None:
        """Remove a constraint by name."""
        self._constraints = [c for c in self._constraints if c.name != name]
        self._must_match_satisfied.pop(name, None)

    @property
    def constraint_names(self) -> list[str]:
        """Return the names of all registered constraints."""
        return [c.name for c in self._constraints]

    @property
    def violations(self) -> list[ConstraintViolation]:
        """All violations detected so far, recomputed from current state.

        Never violations accumulate from historical checks.
        MustMatch violations reflect current computation state.
        """
        # Rebuild: keep accumulated never violations, recompute must_match
        result: list[ConstraintViolation] = []

        # Never violations that were previously detected
        result.extend(v for v in self._violations if v.violation_type == "never_violated")

        # Re-evaluate must_match constraints against current computation
        for c in self._constraints:
            if isinstance(c, MustMatch):
                current = c.check(self._computation)
                result.extend(current)

        return result

    @property
    def computation(self) -> Computation:
        """The internal computation being monitored."""
        return self._computation

    def check(self, event: Event) -> list[ConstraintViolation]:
        """Process a single new event.

        Adds the event to the internal computation, then runs constraints.
        Returns any new violations from this event.
        """
        # Add event to internal computation (no causal link by default)
        if event.id not in self._computation._poset._events:
            self._computation.record(event)

        new_violations: list[ConstraintViolation] = []

        for c in self._constraints:
            if isinstance(c, Never):
                # Incremental: check if the new event participates in a violation
                all_violations = c.check(self._computation)
                for v in all_violations:
                    if event in v.matched_events:
                        # Only report violations involving the new event
                        # and that haven't been seen before
                        if not self._is_duplicate_never_violation(v):
                            new_violations.append(v)
                            self._violations.append(v)
            elif isinstance(c, MustMatch):
                # Re-check the full computation for must_match
                current = c.check(self._computation)
                if current:
                    self._must_match_satisfied[c.name] = False
                    new_violations.extend(current)
                else:
                    self._must_match_satisfied[c.name] = True
            else:
                # Generic constraint: full check
                violations = c.check(self._computation)
                new_violations.extend(violations)

        return new_violations

    def check_batch(self, events: list[Event]) -> list[ConstraintViolation]:
        """Process multiple events at once. Returns all new violations."""
        all_violations: list[ConstraintViolation] = []
        for event in events:
            violations = self.check(event)
            all_violations.extend(violations)
        return all_violations

    def record_causal_link(self, cause: Event, effect: Event) -> None:
        """Declare a causal link between two events already in the computation.

        If either event hasn't been checked in yet, it is added first.
        """
        if cause.id not in self._computation._poset._events:
            self._computation.record(cause)
        if effect.id not in self._computation._poset._events:
            self._computation.record(effect)
        self._computation._poset.add_causal_link(cause, effect)

    def reset(self) -> None:
        """Clear internal state. Constraints remain registered."""
        self._computation = Computation()
        self._violations.clear()
        for name in self._must_match_satisfied:
            self._must_match_satisfied[name] = False

    def _is_duplicate_never_violation(self, violation: ConstraintViolation) -> bool:
        """Check if an identical never violation has already been recorded."""
        event_ids = {e.id for e in violation.matched_events}
        for existing in self._violations:
            if (existing.constraint_name == violation.constraint_name
                    and existing.violation_type == "never_violated"):
                existing_ids = {e.id for e in existing.matched_events}
                if event_ids == existing_ids:
                    return True
        return False

    # --- Backward-compatible methods ---

    def check_all(self, computation: Computation) -> list[ConstraintViolation]:
        """Check all constraints against a provided computation (batch mode)."""
        violations: list[ConstraintViolation] = []
        for c in self._constraints:
            violations.extend(c.check(computation))
        return violations

    def check_event(
        self, event: Event, computation: Computation
    ) -> list[ConstraintViolation]:
        """Incrementally check constraints after a new event (legacy API)."""
        violations: list[ConstraintViolation] = []
        for c in self._constraints:
            if isinstance(c, Never):
                new_violations = c.check(computation)
                for v in new_violations:
                    if event in v.matched_events or not v.matched_events:
                        violations.append(v)
            else:
                violations.extend(c.check(computation))
        return violations


class AsyncConstraintMonitor(ConstraintMonitor):
    """Async version of ConstraintMonitor for use with async event streams."""

    async def async_check(self, event: Event) -> list[ConstraintViolation]:
        """Async version of check()."""
        return self.check(event)

    async def async_check_batch(self, events: list[Event]) -> list[ConstraintViolation]:
        """Async version of check_batch()."""
        return self.check_batch(events)

    async def monitor_stream(
        self,
        event_source: AsyncIterable[Event],
        on_violation: Callable[[ConstraintViolation], Any],
    ) -> None:
        """Continuously monitor an async event stream.

        Calls on_violation for each violation detected.
        """
        async for event in event_source:
            violations = self.check(event)
            for v in violations:
                on_violation(v)
