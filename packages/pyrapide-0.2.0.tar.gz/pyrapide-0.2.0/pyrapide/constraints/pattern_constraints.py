from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern


@dataclass
class ConstraintViolation:
    """A record of a constraint being violated."""

    constraint_name: str
    violation_type: str  # "must_match_failed" or "never_violated"
    description: str
    matched_events: list[Event] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class Constraint:
    """Base class for all constraints."""

    name: str = "unnamed"
    description: str = ""

    def check(self, computation: Computation) -> list[ConstraintViolation]:
        raise NotImplementedError


class MustMatch(Constraint):
    """A constraint requiring that a pattern has at least one match in the computation.

    If the pattern has no matches, this is a violation.
    """

    def __init__(
        self,
        pattern: Pattern,
        name: str | None = None,
        description: str = "",
    ) -> None:
        self.pattern = pattern
        self.name = name or "must_match"
        self.description = description or "Pattern must match in computation"

    def check(self, computation: Computation) -> list[ConstraintViolation]:
        poset = computation._poset
        matches = self.pattern.match_in(poset)
        if matches:
            return []

        return [
            ConstraintViolation(
                constraint_name=self.name,
                violation_type="must_match_failed",
                description=f"Required pattern not found (must_match constraint '{self.name}')",
                matched_events=[],
            )
        ]


class Never(Constraint):
    """A constraint forbidding a pattern from matching in the computation.

    Each match of the pattern is a separate violation.
    """

    def __init__(
        self,
        pattern: Pattern,
        name: str | None = None,
        description: str = "",
    ) -> None:
        self.pattern = pattern
        self.name = name or "never"
        self.description = description or "Pattern must never match in computation"

    def check(self, computation: Computation) -> list[ConstraintViolation]:
        poset = computation._poset
        matches = self.pattern.match_in(poset)
        violations = []
        for m in matches:
            violations.append(
                ConstraintViolation(
                    constraint_name=self.name,
                    violation_type="never_violated",
                    description=f"Forbidden pattern matched (never constraint '{self.name}')",
                    matched_events=list(m.events),
                )
            )
        return violations


# --- Factory functions ---

# Storage for rules collected during @constraint define()/rules() execution
_current_rules: list[Constraint] = []


def must_match(
    pattern: Pattern,
    name: str | None = None,
    description: str = "",
) -> MustMatch:
    """Create a must-match constraint (pattern must exist in the computation).

    When called inside a @constraint class's define()/rules() method, registers the rule.
    Can also be used standalone.
    """
    c = MustMatch(pattern=pattern, name=name, description=description)
    _current_rules.append(c)
    return c


def never(
    pattern: Pattern,
    name: str | None = None,
    description: str = "",
) -> Never:
    """Create a never constraint (pattern must not exist in the computation).

    When called inside a @constraint class's define()/rules() method, registers the rule.
    Can also be used standalone.
    """
    c = Never(pattern=pattern, name=name, description=description)
    _current_rules.append(c)
    return c


# --- @constraint decorator ---

def constraint(cls: type) -> type:
    """Class decorator that turns a constraint definition class into a Constraint.

    The decorated class should define:
    - name (str): constraint name
    - description (str, optional): constraint description
    - define(self) or rules(self): method that calls must_match() / never() to declare rules
    - filter (optional Pattern): limits which events are checked
    """
    original_init = cls.__init__ if hasattr(cls, "__init__") and cls.__init__ is not object.__init__ else None  # type: ignore[misc]

    class WrappedConstraint(Constraint):
        __doc__ = cls.__doc__
        __name__ = cls.__name__
        __qualname__ = cls.__qualname__

        def __init__(self) -> None:
            self.name = getattr(cls, "name", cls.__name__)
            self.description = getattr(cls, "description", "")
            self.filter_pattern: Pattern | None = getattr(cls, "filter", None)
            self._rules: list[Constraint] = []
            self._collect_rules()

        def _collect_rules(self) -> None:
            global _current_rules
            saved = _current_rules
            _current_rules = []
            try:
                tmp: Any = object.__new__(cls)
                if original_init:
                    original_init(tmp)
                # Support both define() and rules() methods
                if hasattr(cls, "define"):
                    cls.define(tmp)
                elif hasattr(cls, "rules"):
                    cls.rules(tmp)
                self._rules = list(_current_rules)
            finally:
                _current_rules = saved

        @property
        def constraints(self) -> list[Constraint]:
            return list(self._rules)

        def check(self, computation: Computation) -> list[ConstraintViolation]:
            violations: list[ConstraintViolation] = []
            for rule in self._rules:
                violations.extend(rule.check(computation))
            return violations

    return WrappedConstraint


# Backward-compatible aliases
MustMatchConstraint = MustMatch
NeverConstraint = Never
