from __future__ import annotations

from pyrapide.constraints.pattern_constraints import Constraint, ConstraintViolation
from pyrapide.core.computation import Computation


def check_conformance(
    computation: Computation,
    constraints: list[Constraint],
) -> list[ConstraintViolation]:
    """Batch check all constraints against a full computation.

    Returns all violations found across all constraints.
    """
    violations: list[ConstraintViolation] = []
    for c in constraints:
        violations.extend(c.check(computation))
    return violations
