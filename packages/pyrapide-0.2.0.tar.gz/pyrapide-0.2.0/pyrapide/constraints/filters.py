from __future__ import annotations

from pyrapide.core.computation import Computation
from pyrapide.core.poset import Poset
from pyrapide.patterns.base import Pattern


class PatternFilter:
    """Filters a computation to only events matching given patterns."""

    @staticmethod
    def filter_computation(
        computation: Computation,
        filter_patterns: list[Pattern],
    ) -> Computation:
        """Return a new computation containing only events matching any of the filter patterns.

        Preserves causal edges between surviving events.
        """
        poset = computation._poset
        # Collect IDs of all events that match any filter pattern
        kept_ids: set[str] = set()
        for pattern in filter_patterns:
            matches = pattern.match_in(poset)
            for m in matches:
                for event in m.events:
                    kept_ids.add(event.id)

        return _build_filtered_computation(computation, kept_ids)


class AlphabetFilter:
    """Filters a computation to only events in an interface's event alphabet."""

    @staticmethod
    def filter_by_alphabet(
        computation: Computation,
        interface_class: type,
    ) -> Computation:
        """Return a new computation containing only events whose names are in the
        interface's event alphabet.
        """
        if not getattr(interface_class, "_pyrapide_is_interface", False):
            raise TypeError(
                f"{interface_class.__name__} is not a @interface-decorated class"
            )

        alphabet: set[str] = interface_class._pyrapide_event_alphabet  # type: ignore[attr-defined]

        poset = computation._poset
        kept_ids: set[str] = set()
        for event in poset.events:
            if event.name in alphabet:
                kept_ids.add(event.id)

        return _build_filtered_computation(computation, kept_ids)


def _build_filtered_computation(
    computation: Computation,
    kept_ids: set[str],
) -> Computation:
    """Build a new Computation from a subset of events, preserving causal edges."""
    source_poset = computation._poset
    new_poset = Poset()

    for eid in kept_ids:
        event = source_poset._events[eid]
        new_poset._events[eid] = event
        new_poset._graph.add_node(eid)

    # Preserve causal edges between surviving events
    for u, v in source_poset._graph.edges():
        if u in kept_ids and v in kept_ids:
            new_poset._graph.add_edge(u, v)

    return Computation(poset=new_poset)
