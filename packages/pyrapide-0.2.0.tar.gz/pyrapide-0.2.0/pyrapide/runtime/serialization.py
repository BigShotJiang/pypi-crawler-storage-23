from __future__ import annotations

import json
from typing import Any

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event


def serialize_event(event: Event) -> dict[str, Any]:
    """Serialize an event to a dict."""
    return event.to_dict()


def deserialize_event(data: dict[str, Any]) -> Event:
    """Deserialize an event from a dict."""
    return Event.from_dict(data)


def serialize_computation(computation: Computation, format: str = "json") -> str | bytes:
    """Serialize a computation to JSON string.

    Args:
        computation: The computation to serialize.
        format: Output format. Currently only "json" is supported.

    Returns:
        JSON string representation of the computation.
    """
    data = computation.to_dict()
    if format == "json":
        return json.dumps(data, default=str)
    raise ValueError(f"Unsupported format: {format}")


def deserialize_computation(data: str | bytes, format: str = "json") -> Computation:
    """Deserialize a computation from JSON string.

    Args:
        data: Serialized computation data.
        format: Input format. Currently only "json" is supported.

    Returns:
        Reconstructed Computation.
    """
    if format == "json":
        if isinstance(data, bytes):
            data = data.decode("utf-8")
        parsed = json.loads(data)
        return Computation.from_dict(parsed)
    raise ValueError(f"Unsupported format: {format}")
