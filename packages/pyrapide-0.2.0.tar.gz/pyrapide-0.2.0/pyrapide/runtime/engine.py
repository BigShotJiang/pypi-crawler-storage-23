from __future__ import annotations

import asyncio
from typing import Any

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern
from pyrapide.executable.module import ModuleContext, get_context
from pyrapide.executable.reactive import WhenRegistry
from pyrapide.constraints.monitor import ConstraintMonitor
from pyrapide.constraints.pattern_constraints import ConstraintViolation
from pyrapide.runtime.scheduler import EventScheduler


class Engine:
    """Central execution engine for PyRapide architectures.

    Orchestrates module lifecycle, event propagation through connections,
    reactive handler dispatch, and constraint monitoring.
    """

    def __init__(self) -> None:
        self._bindings: dict[str, tuple[Any, type]] = {}  # arch_id -> {comp_name -> (instance, cls)}
        self._module_instances: dict[str, Any] = {}  # comp_name -> module instance
        self._module_contexts: dict[str, ModuleContext] = {}  # comp_name -> ctx
        self._registries: dict[str, WhenRegistry] = {}  # comp_name -> registry
        self._monitor: ConstraintMonitor | None = None
        self._scheduler: EventScheduler | None = None
        self._computation: Computation | None = None
        self._connections: list[tuple[Pattern, str]] = []  # (pattern, target_component)
        self._running: bool = False
        self._violations: list[ConstraintViolation] = []
        self._fired: set[tuple[str, str]] = set()  # (event_id, comp_name) already dispatched

    @property
    def violations(self) -> list[ConstraintViolation]:
        """All constraint violations detected during execution."""
        return list(self._violations)

    def bind(self, arch: Any, component_name: str, module_class: type) -> None:
        """Bind a module implementation to an architecture component."""
        arch_id = id(arch)
        key = f"{arch_id}:{component_name}"
        self._bindings[key] = (arch, module_class)

    async def run(self, arch: Any, timeout: float | None = None) -> Computation:
        """Main execution loop.

        1. Initialize all components (start hooks).
        2. Set up connections from architecture.
        3. Set up constraint monitor.
        4. Process events: propagate through connections, fire reactive handlers.
        5. Continue until quiescence or timeout.
        6. Finalize all components (finish hooks).
        7. Return the final Computation.
        """
        self._computation = Computation()
        self._scheduler = EventScheduler()
        self._module_instances.clear()
        self._module_contexts.clear()
        self._registries.clear()
        self._connections.clear()
        self._violations.clear()
        self._fired.clear()
        self._running = True

        arch_id = id(arch)

        # --- Phase 1: Instantiate module bindings ---
        for comp_name in (arch.components or {}):
            key = f"{arch_id}:{comp_name}"
            if key in self._bindings:
                _, module_class = self._bindings[key]
                instance = module_class()
                self._module_instances[comp_name] = instance

                ctx = get_context(instance)
                self._module_contexts[comp_name] = ctx

                registry = WhenRegistry.scan(instance)
                self._registries[comp_name] = registry

        # --- Phase 2: Set up connections ---
        connections_method = getattr(arch, "connections", None)
        if connections_method is not None and callable(connections_method):
            raw_connections = connections_method()
            if raw_connections:
                for conn in raw_connections:
                    # Connections are BasicConnection objects with
                    # source_pattern and handler (handler is a string = target component name)
                    target = conn.handler
                    self._connections.append((conn.source_pattern, target))

        # --- Phase 3: Set up constraint monitor ---
        self._monitor = ConstraintMonitor()
        constraints_method = getattr(arch, "constraints", None)
        if constraints_method is not None and callable(constraints_method):
            constraints = constraints_method()
            if constraints:
                for c in constraints:
                    self._monitor.add_constraint(c)

        # --- Phase 4: Run start() hooks, collect initial events ---
        for comp_name, ctx in self._module_contexts.items():
            events_before = set(ctx.computation.events)
            await ctx.run_start()
            events_after = set(ctx.computation.events)

            # Schedule any events generated during start()
            for event in events_after - events_before:
                self._record_event(event)
                self._scheduler.enqueue(event)

        # --- Phase 5: Event processing loop ---
        try:
            if timeout is not None:
                await asyncio.wait_for(
                    self._process_loop(),
                    timeout=timeout,
                )
            else:
                await self._process_loop()
        except asyncio.TimeoutError:
            pass  # Timeout reached, stop processing

        self._running = False

        # --- Phase 6: Finish hooks ---
        for comp_name, ctx in self._module_contexts.items():
            if ctx.state == "RUNNING":
                await ctx.run_finish()

        assert self._computation is not None
        return self._computation

    async def _process_loop(self) -> None:
        """Process events until quiescence (no more events to process)."""
        assert self._scheduler is not None
        assert self._computation is not None
        while self._running:
            # Check if there are pending events
            if self._scheduler.pending == 0:
                # Give a brief moment for any async handlers to generate events
                await asyncio.sleep(0.01)
                if self._scheduler.pending == 0:
                    # Quiescence reached
                    break

            try:
                event = self._scheduler._queue.get_nowait()
            except asyncio.QueueEmpty:
                break

            if event is None:
                break

            await self._dispatch_event(event)
            self._scheduler.mark_processed(event)

    async def _dispatch_event(self, event: Event) -> None:
        """Dispatch an event through connections and reactive handlers."""
        assert self._scheduler is not None
        assert self._computation is not None
        # --- Check constraints ---
        if self._monitor is not None:
            violations = self._monitor.check(event)
            self._violations.extend(violations)

        # --- Route through connections to target components ---
        for pattern, target_comp in self._connections:
            from pyrapide.core.poset import Poset

            p = Poset()
            p.add(event)
            matches = pattern.match_in(p)

            if matches and target_comp in self._registries:
                fire_key = (event.id, target_comp)
                if fire_key in self._fired:
                    continue
                self._fired.add(fire_key)

                registry = self._registries[target_comp]
                ctx = self._module_contexts[target_comp]

                # Record the event in the target's computation so its handlers can see it
                if event not in ctx.computation._poset:
                    ctx.computation.record(event)

                events_before = set(ctx.computation.events)
                await registry.fire_all(event, ctx)
                events_after = set(ctx.computation.events)

                # Schedule newly generated events
                for new_event in events_after - events_before:
                    self._record_event(new_event, caused_by=event)
                    self._scheduler.enqueue(new_event)

        # --- Fire reactive handlers on components that own this event ---
        for comp_name, ctx in self._module_contexts.items():
            fire_key = (event.id, comp_name)
            if fire_key in self._fired:
                continue

            if event in ctx.computation._poset:
                self._fired.add(fire_key)
                owner_registry = self._registries.get(comp_name)
                if owner_registry is not None:
                    events_before = set(ctx.computation.events)
                    await owner_registry.fire_all(event, ctx)
                    events_after = set(ctx.computation.events)

                    for new_event in events_after - events_before:
                        self._record_event(new_event, caused_by=event)
                        self._scheduler.enqueue(new_event)

    def _record_event(self, event: Event, caused_by: Event | None = None) -> None:
        """Record an event in the global computation."""
        assert self._computation is not None
        if event not in self._computation._poset:
            causes = [caused_by] if caused_by is not None else None
            self._computation.record(event, caused_by=causes)
        elif caused_by is not None and caused_by in self._computation._poset:
            # Add causal link if both events already exist
            try:
                self._computation._poset.add_causal_link(caused_by, event)
            except Exception:
                pass  # Link may already exist or would create cycle

    async def inject(self, event: Event, caused_by: Event | None = None) -> None:
        """Inject an external event into the running computation."""
        self._record_event(event, caused_by=caused_by)
        if self._scheduler is not None:
            self._scheduler.enqueue(event)

    async def wait(self, timeout: float | None = None) -> None:
        """Wait for the computation to reach quiescence."""
        if not self._running:
            return
        if timeout is not None:
            await asyncio.sleep(timeout)
        else:
            # Wait until no more pending events
            while self._scheduler is not None and self._scheduler.pending > 0:
                await asyncio.sleep(0.01)
