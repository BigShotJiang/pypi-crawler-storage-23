from __future__ import annotations

import asyncio

from pyrapide.core.event import Event


class EventScheduler:
    """Queues events for processing in causal order.

    Ensures an event can only be processed after all its causal
    parents have been processed.  Uses an asyncio.Queue internally
    so the engine can await new work.
    """

    def __init__(self) -> None:
        self._queue: asyncio.Queue[Event | None] = asyncio.Queue()
        self._processed: set[str] = set()

    def enqueue(self, event: Event) -> None:
        """Add an event to the processing queue."""
        self._queue.put_nowait(event)

    def mark_processed(self, event: Event) -> None:
        """Mark an event as fully processed."""
        self._processed.add(event.id)

    def is_processed(self, event: Event) -> bool:
        """Check if an event has been processed."""
        return event.id in self._processed

    async def next(self) -> Event | None:
        """Wait for and return the next event to process.

        Returns None if the scheduler has been shut down.
        """
        return await self._queue.get()

    def shutdown(self) -> None:
        """Signal the scheduler to stop."""
        self._queue.put_nowait(None)

    @property
    def pending(self) -> int:
        """Approximate number of events waiting."""
        return self._queue.qsize()

    def reset(self) -> None:
        """Clear all state."""
        self._processed.clear()
        # Drain queue
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
