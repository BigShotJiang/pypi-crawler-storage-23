from __future__ import annotations

import asyncio
import inspect
from collections.abc import AsyncIterator
from typing import Any, Callable, Protocol, runtime_checkable

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.core.poset import Poset
from pyrapide.patterns.base import Pattern
from pyrapide.constraints.monitor import ConstraintMonitor
from pyrapide.constraints.pattern_constraints import Constraint


@runtime_checkable
class EventSource(Protocol):
    """Protocol for event sources that yield events asynchronously."""

    @property
    def name(self) -> str: ...

    def events(self) -> AsyncIterator[Event]: ...


class InMemoryEventSource:
    """Simple event source backed by an asyncio.Queue.

    Useful for testing and programmatic event injection.
    """

    def __init__(self, name: str) -> None:
        self._name = name
        self._queue: asyncio.Queue[Event | None] = asyncio.Queue()

    @property
    def name(self) -> str:
        return self._name

    async def put(self, event: Event) -> None:
        """Enqueue an event for consumption."""
        await self._queue.put(event)

    async def close(self) -> None:
        """Signal that no more events will be produced."""
        await self._queue.put(None)

    async def events(self) -> AsyncIterator[Event]:
        """Yield events until closed."""
        while True:
            item = await self._queue.get()
            if item is None:
                break
            yield item


class StreamProcessor:
    """Processes events from multiple concurrent sources in real time.

    Supports pattern watches, constraint enforcement, sliding window
    eviction, and per-event callbacks.
    """

    def __init__(self) -> None:
        self._sources: dict[str, EventSource] = {}
        self._watches: list[tuple[Pattern, Callable[..., Any]]] = []
        self._monitor = ConstraintMonitor()
        self._event_callbacks: list[Callable[..., Any]] = []
        self._violation_callbacks: list[Callable[..., Any]] = []
        self._computation = Computation()
        self._running = False
        self._stop_event = asyncio.Event()

        # Stats
        self._event_count = 0
        self._source_counts: dict[str, int] = {}
        self._violation_count = 0
        self._match_count = 0

    @property
    def computation(self) -> Computation:
        """The current computation (within the sliding window)."""
        return self._computation

    @property
    def stats(self) -> dict[str, Any]:
        """Processing statistics."""
        return {
            "event_count": self._event_count,
            "source_counts": dict(self._source_counts),
            "violation_count": self._violation_count,
            "match_count": self._match_count,
        }

    def add_source(self, name: str, source: EventSource) -> None:
        """Register an event source."""
        self._sources[name] = source
        self._source_counts.setdefault(name, 0)

    def remove_source(self, name: str) -> None:
        """Remove a source."""
        self._sources.pop(name, None)

    def watch(self, pattern: Pattern, callback: Callable[..., Any]) -> None:
        """Register a pattern watch with callback."""
        self._watches.append((pattern, callback))

    def unwatch(self, pattern: Pattern) -> None:
        """Remove a watch by pattern identity."""
        self._watches = [(p, cb) for p, cb in self._watches if p is not pattern]

    def enforce(self, constraint: Constraint) -> None:
        """Add a constraint to monitor in real time."""
        self._monitor.add_constraint(constraint)

    def on_violation(self, callback: Callable[..., Any]) -> None:
        """Register violation callback."""
        self._violation_callbacks.append(callback)

    def on_event(self, callback: Callable[..., Any]) -> None:
        """Register callback for every event."""
        self._event_callbacks.append(callback)

    async def run(self, window_size: int = 10000) -> None:
        """Main processing loop.

        Consumes events from all sources concurrently, processes them
        through pattern watches and constraints, and maintains a
        sliding window.
        """
        self._running = True
        self._stop_event.clear()

        # Create a shared queue for all sources to feed into
        event_queue: asyncio.Queue[tuple[str, Event] | None] = asyncio.Queue()

        async def consume_source(name: str, source: EventSource) -> None:
            """Consume events from a single source into the shared queue."""
            try:
                async for event in source.events():
                    if not self._running:
                        break
                    await event_queue.put((name, event))
            except Exception:
                pass
            finally:
                await event_queue.put(None)  # Signal this source is done

        # Start all source consumers
        source_tasks = [
            asyncio.create_task(consume_source(name, source))
            for name, source in self._sources.items()
        ]

        sources_done = 0
        total_sources = len(self._sources)

        # Process events as they arrive
        while self._running:
            if self._stop_event.is_set():
                break

            try:
                item = await asyncio.wait_for(event_queue.get(), timeout=0.1)
            except asyncio.TimeoutError:
                if sources_done >= total_sources:
                    break
                continue

            if item is None:
                sources_done += 1
                if sources_done >= total_sources:
                    break
                continue

            source_name, event = item

            # Record in computation
            self._computation.record(event)
            self._event_count += 1
            self._source_counts[source_name] = self._source_counts.get(source_name, 0) + 1

            # Fire on_event callbacks
            for cb in self._event_callbacks:
                result = cb(event)
                if inspect.isawaitable(result):
                    await result

            # Check pattern watches
            p = Poset()
            p.add(event)
            for pattern, callback in self._watches:
                matches = pattern.match_in(p)
                for match in matches:
                    self._match_count += 1
                    result = callback(match)
                    if inspect.isawaitable(result):
                        await result

            # Check constraints
            violations = self._monitor.check(event)
            for v in violations:
                self._violation_count += 1
                for cb in self._violation_callbacks:
                    result = cb(v)
                    if inspect.isawaitable(result):
                        await result

            # Sliding window eviction
            if len(self._computation) > window_size:
                self._evict_oldest(window_size)

        self._running = False

        # Wait for source tasks to finish
        for task in source_tasks:
            task.cancel()
        await asyncio.gather(*source_tasks, return_exceptions=True)

    def _evict_oldest(self, window_size: int) -> None:
        """Evict oldest events to maintain the sliding window.

        Preserves causal edges for surviving events.
        """
        events_ordered = self._computation.topological_order()
        if len(events_ordered) <= window_size:
            return

        # Keep the most recent window_size events
        to_keep = set(events_ordered[-window_size:])

        # Build a new computation with only surviving events
        new_comp = Computation()
        # Add surviving events in topological order, preserving causal edges
        old_poset = self._computation._poset
        for event in events_ordered:
            if event not in to_keep:
                continue
            # Find causes that are also in the surviving set
            causes = [
                c for c in old_poset.causes(event)
                if c in to_keep
            ]
            new_comp.record(event, caused_by=causes or None)

        self._computation = new_comp
        # Also reset the monitor's internal computation to match
        self._monitor.reset()
        for event in new_comp.topological_order():
            self._monitor.check(event)

    async def stop(self) -> None:
        """Gracefully shut down all source consumers."""
        self._running = False
        self._stop_event.set()
        # Close any InMemoryEventSource that hasn't been closed
        for source in self._sources.values():
            if isinstance(source, InMemoryEventSource):
                try:
                    await source.close()
                except Exception:
                    pass
