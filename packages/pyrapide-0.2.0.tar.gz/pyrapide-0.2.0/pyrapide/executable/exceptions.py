class ConformanceError(Exception):
    """Raised when a module doesn't conform to its interface."""


class ModuleStateError(Exception):
    """Raised when an operation is invalid for the current module state."""
