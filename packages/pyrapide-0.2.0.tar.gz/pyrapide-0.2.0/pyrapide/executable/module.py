from __future__ import annotations

import inspect
from typing import Any

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.executable.exceptions import ConformanceError, ModuleStateError


# Module state constants
CREATED = "CREATED"
STARTING = "STARTING"
RUNNING = "RUNNING"
FINISHING = "FINISHING"
FINISHED = "FINISHED"


class ModuleContext:
    """Runtime context for a module instance.

    Tracks the module's state, its contribution to the computation,
    and the current causal context for event generation.
    """

    def __init__(self, module_instance: Any, module_name: str) -> None:
        self._module = module_instance
        self._module_name = module_name
        self._state: str = CREATED
        self._computation = Computation()
        self._causal_context: list[Event] = []
        self._module_events: list[Event] = []

    @property
    def state(self) -> str:
        return self._state

    @property
    def computation(self) -> Computation:
        return self._computation

    @property
    def causal_context(self) -> list[Event]:
        return list(self._causal_context)

    @property
    def module_events(self) -> list[Event]:
        return list(self._module_events)

    async def run_start(self) -> None:
        """Run the module's start lifecycle hook."""
        if self._state != CREATED:
            raise ModuleStateError(
                f"Cannot start module in state '{self._state}' (must be CREATED)"
            )

        self._state = STARTING

        start_method = getattr(self._module, "start", None)
        if start_method is not None and callable(start_method):
            result = start_method()
            if inspect.isawaitable(result):
                await result

        self._state = RUNNING

    async def run_finish(self) -> None:
        """Run the module's finish lifecycle hook."""
        if self._state != RUNNING:
            raise ModuleStateError(
                f"Cannot finish module in state '{self._state}' (must be RUNNING)"
            )

        self._state = FINISHING

        finish_method = getattr(self._module, "finish", None)
        if finish_method is not None and callable(finish_method):
            result = finish_method()
            if inspect.isawaitable(result):
                await result

        self._state = FINISHED

    def generate_event(
        self,
        name: str,
        payload: dict[str, Any] | None = None,
        caused_by: list[Event] | None = None,
    ) -> Event:
        """Generate an event in this module's computation.

        If caused_by is not specified, uses the current causal context.
        The new event becomes the current causal context for subsequent events.
        """
        causes = caused_by if caused_by is not None else list(self._causal_context)

        event = Event(
            name=name,
            payload=payload or {},
            source=self._module_name,
        )

        self._computation.record(event, caused_by=causes or None)
        self._module_events.append(event)

        # Update causal context: new event replaces previous context
        self._causal_context = [event]

        return event


# --- Module registry: instance -> ModuleContext ---
_module_contexts: dict[int, ModuleContext] = {}


def get_context(module_instance: Any) -> ModuleContext:
    """Get the ModuleContext for a module instance.

    Creates one if it doesn't exist yet.
    """
    key = id(module_instance)
    if key not in _module_contexts:
        module_name = type(module_instance).__name__
        ctx = ModuleContext(module_instance, module_name)
        _module_contexts[key] = ctx
    return _module_contexts[key]


# --- @module decorator ---

def module(implements: type | None = None, serial: bool = False) -> Any:
    """Decorator that transforms a class into a RAPIDE module.

    Args:
        implements: Optional @interface class this module implements.
            If set, checks at decoration time that the module provides
            implementations for all @requires methods.
        serial: If True, only one @when handler executes at a time.
    """

    def decorator(cls: type) -> type:
        # Conformance check
        if implements is not None:
            required: set[str] = getattr(implements, "_pyrapide_requires", set())
            missing = []
            for method_name in required:
                method = getattr(cls, method_name, None)
                if method is None or not callable(method):
                    missing.append(method_name)
            if missing:
                raise ConformanceError(
                    f"{cls.__name__} does not conform to "
                    f"{implements.__name__}: missing required methods: "
                    f"{', '.join(sorted(missing))}"
                )

        cls._pyrapide_is_module = True  # type: ignore[attr-defined]
        cls._pyrapide_implements = implements  # type: ignore[attr-defined]
        cls._pyrapide_serial = serial  # type: ignore[attr-defined]

        return cls

    return decorator
