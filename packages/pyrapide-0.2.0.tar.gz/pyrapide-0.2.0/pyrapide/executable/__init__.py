"""Executable modules: module lifecycle, reactive event handlers, and process management."""

from pyrapide.executable.exceptions import ConformanceError, ModuleStateError
from pyrapide.executable.module import ModuleContext, get_context, module
from pyrapide.executable.process import ProcessManager
from pyrapide.executable.reactive import ReactiveProcess, WhenRegistry, when

__all__ = [
    "ConformanceError",
    "ModuleContext",
    "ModuleStateError",
    "ProcessManager",
    "ReactiveProcess",
    "WhenRegistry",
    "get_context",
    "module",
    "when",
]
