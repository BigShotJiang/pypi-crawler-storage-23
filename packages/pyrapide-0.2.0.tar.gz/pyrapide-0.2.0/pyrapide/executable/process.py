from __future__ import annotations

import asyncio
from typing import Any, Coroutine


class ProcessManager:
    """Manages multiple concurrent processes.

    Supports both coroutines and reactive process registrations.
    """

    def __init__(self) -> None:
        self._processes: list[Coroutine[Any, Any, Any]] = []

    @property
    def processes(self) -> list[Coroutine[Any, Any, Any]]:
        return list(self._processes)

    def add_process(self, coroutine: Coroutine[Any, Any, Any]) -> None:
        """Register a coroutine as a process."""
        self._processes.append(coroutine)

    async def run_all(self) -> None:
        """Start all registered processes concurrently and wait for completion."""
        if not self._processes:
            return
        tasks = [asyncio.ensure_future(p) for p in self._processes]
        self._processes.clear()
        await asyncio.gather(*tasks)

    async def stop_all(self) -> None:
        """Gracefully stop all running processes."""
        # For now, cancel any pending tasks — future versions may support
        # graceful shutdown signaling
        pass
