import uuid


def generate_event_id() -> str:
    """Generate a unique event identifier using UUID4.

    Used as the default factory for ``Event.id`` to ensure every event
    has a globally unique identifier.

    Example::

        eid = generate_event_id()  # e.g. "a1b2c3d4-..."
    """
    return str(uuid.uuid4())
