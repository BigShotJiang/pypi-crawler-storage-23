from __future__ import annotations

from dataclasses import dataclass

from pyrapide.core.event import Event


@dataclass(frozen=True)
class TimestampedEvent:
    """Lightweight wrapper associating a clock timestamp with an event."""

    event: Event
    time: float
    clock_name: str


class Clock:
    """Base clock providing temporal ordering for events."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._start_times: dict[str, float] = {}   # event.id -> start time
        self._finish_times: dict[str, float] = {}   # event.id -> finish time
        self._stamps: list[tuple[float, Event]] = []  # ordered (time, event)

    def read(self) -> float:
        raise NotImplementedError

    def stamp(self, event: Event, phase: str = "both") -> TimestampedEvent:
        t = self.read()
        if phase == "start":
            self._start_times[event.id] = t
        elif phase == "finish":
            self._finish_times[event.id] = t
        else:  # "both"
            self._start_times.setdefault(event.id, t)
            self._finish_times[event.id] = t

        # Track for temporal ordering — only record on first stamp
        if not any(e.id == event.id for _, e in self._stamps):
            self._stamps.append((t, event))

        return TimestampedEvent(event=event, time=t, clock_name=self.name)

    def start_time(self, event: Event) -> float | None:
        return self._start_times.get(event.id)

    def finish_time(self, event: Event) -> float | None:
        return self._finish_times.get(event.id)

    def get_temporal_order(self) -> list[Event]:
        sorted_stamps = sorted(self._stamps, key=lambda x: x[0])
        return [e for _, e in sorted_stamps]


class SynchronousClock(Clock):
    """Clock where all observers agree on the current time."""

    def __init__(self, name: str) -> None:
        super().__init__(name)
        self._time: float = 0.0

    def read(self) -> float:
        return self._time

    def tick(self, amount: float = 1.0) -> None:
        self._time += amount


class RegularClock(SynchronousClock):
    """Synchronous clock that ticks at a fixed period."""

    def __init__(self, name: str, period: float, accuracy: float = 1.0) -> None:
        super().__init__(name)
        self.period = period
        self.accuracy = accuracy

    def auto_tick(self) -> None:
        self.tick(self.period)


class SlavedClock(Clock):
    """Clock derived from a parent clock by a divisor."""

    def __init__(self, name: str, parent: Clock, divisor: int) -> None:
        super().__init__(name)
        self.parent = parent
        self.divisor = divisor

    def read(self) -> float:
        return self.parent.read() / self.divisor


class ClockManager:
    """Manages multiple clocks for a computation."""

    def __init__(self) -> None:
        self._clocks: dict[str, Clock] = {}

    def register(self, clock: Clock) -> None:
        self._clocks[clock.name] = clock

    def stamp_event(self, event: Event, clock_name: str | None = None) -> None:
        if clock_name is not None:
            clock = self._clocks[clock_name]
            clock.stamp(event)
        else:
            for clock in self._clocks.values():
                clock.stamp(event)

    def get_clock(self, clock_name: str) -> Clock:
        return self._clocks[clock_name]

    def get_temporal_order(self, clock_name: str) -> list[Event]:
        return self._clocks[clock_name].get_temporal_order()
