from __future__ import annotations

from typing import Any

import networkx as nx

from pyrapide.core.event import Event
from pyrapide.core.exceptions import CausalCycleError


class Poset:
    """Partially ordered set of events with causal ordering (DAG)."""

    def __init__(self) -> None:
        self._graph: nx.DiGraph = nx.DiGraph()
        self._events: dict[str, Event] = {}  # id -> Event

    def add(self, event: Event, caused_by: list[Event] | None = None) -> None:
        if caused_by:
            for cause in caused_by:
                if cause.id not in self._events:
                    raise ValueError(
                        f"Causal event '{cause.id}' not in poset"
                    )

        self._graph.add_node(event.id)
        self._events[event.id] = event

        if caused_by:
            for cause in caused_by:
                self._graph.add_edge(cause.id, event.id)

            if not nx.is_directed_acyclic_graph(self._graph):
                # Roll back
                for cause in caused_by:
                    self._graph.remove_edge(cause.id, event.id)
                self._graph.remove_node(event.id)
                del self._events[event.id]
                raise CausalCycleError(
                    f"Adding event '{event.id}' with given causes would create a cycle"
                )

    def add_causal_link(self, cause: Event, effect: Event) -> None:
        """Add a causal edge between two events already in the poset."""
        if cause.id not in self._events:
            raise ValueError(f"Cause event '{cause.id}' not in poset")
        if effect.id not in self._events:
            raise ValueError(f"Effect event '{effect.id}' not in poset")
        self._graph.add_edge(cause.id, effect.id)
        if not nx.is_directed_acyclic_graph(self._graph):
            self._graph.remove_edge(cause.id, effect.id)
            raise CausalCycleError(
                f"Adding causal link from '{cause.id}' to '{effect.id}' would create a cycle"
            )

    @property
    def events(self) -> frozenset[Event]:
        return frozenset(self._events.values())

    def __len__(self) -> int:
        return len(self._events)

    def __contains__(self, event: object) -> bool:
        if not isinstance(event, Event):
            return False
        return event.id in self._events

    def causes(self, event: Event) -> frozenset[Event]:
        return frozenset(
            self._events[pid] for pid in self._graph.predecessors(event.id)
        )

    def effects(self, event: Event) -> frozenset[Event]:
        return frozenset(
            self._events[cid] for cid in self._graph.successors(event.id)
        )

    def ancestors(self, event: Event) -> frozenset[Event]:
        ancestor_ids = nx.ancestors(self._graph, event.id)
        return frozenset(self._events[aid] for aid in ancestor_ids)

    def descendants(self, event: Event) -> frozenset[Event]:
        desc_ids = nx.descendants(self._graph, event.id)
        return frozenset(self._events[did] for did in desc_ids)

    def is_ancestor(self, a: Event, b: Event) -> bool:
        return nx.has_path(self._graph, a.id, b.id) and a.id != b.id

    def are_independent(self, a: Event, b: Event) -> bool:
        return not self.is_ancestor(a, b) and not self.is_ancestor(b, a)

    def root_events(self) -> frozenset[Event]:
        return frozenset(
            self._events[nid]
            for nid in self._graph.nodes()
            if self._graph.in_degree(nid) == 0
        )

    def leaf_events(self) -> frozenset[Event]:
        return frozenset(
            self._events[nid]
            for nid in self._graph.nodes()
            if self._graph.out_degree(nid) == 0
        )

    def causal_chain(self, a: Event, b: Event) -> list[Event] | None:
        try:
            path_ids = nx.shortest_path(self._graph, a.id, b.id)
            return [self._events[nid] for nid in path_ids]
        except nx.NetworkXNoPath:
            return None
        except nx.NodeNotFound:
            return None

    def common_ancestors(self, a: Event, b: Event) -> frozenset[Event]:
        anc_a = nx.ancestors(self._graph, a.id)
        anc_b = nx.ancestors(self._graph, b.id)
        common_ids = anc_a & anc_b
        return frozenset(self._events[cid] for cid in common_ids)

    def topological_order(self) -> list[Event]:
        return [self._events[nid] for nid in nx.topological_sort(self._graph)]

    def filter_by_name(self, name: str) -> Poset:
        return self._filter(lambda e: e.name == name)

    def filter_by_source(self, source: str) -> Poset:
        return self._filter(lambda e: e.source == source)

    def _filter(self, predicate: Any) -> Poset:
        kept_ids = {eid for eid, e in self._events.items() if predicate(e)}
        new_poset = Poset()
        for eid in kept_ids:
            new_poset._graph.add_node(eid)
            new_poset._events[eid] = self._events[eid]
        for u, v in self._graph.edges():
            if u in kept_ids and v in kept_ids:
                new_poset._graph.add_edge(u, v)
        return new_poset

    def to_dict(self) -> dict[str, Any]:
        return {
            "events": [e.to_dict() for e in self._events.values()],
            "edges": [[u, v] for u, v in self._graph.edges()],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Poset:
        poset = cls()
        for event_data in d["events"]:
            event = Event.from_dict(event_data)
            poset._events[event.id] = event
            poset._graph.add_node(event.id)
        for u, v in d["edges"]:
            poset._graph.add_edge(u, v)
        return poset
