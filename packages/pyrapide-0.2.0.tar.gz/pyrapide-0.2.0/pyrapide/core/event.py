from __future__ import annotations

import time
from typing import Any

from pydantic import Field

from pydantic import BaseModel

from pyrapide.utils.ids import generate_event_id


class Event(BaseModel, frozen=True):
    """An immutable causal event with a unique identifier, name, and optional payload.

    Events are the fundamental unit of computation in PyRapide. They are frozen
    Pydantic models identified by UUID, compared by id, and hashable for use in sets
    and as dictionary keys.

    Example::

        event = Event(name="request.received", payload={"url": "/api/data"}, source="server")
    """

    id: str = Field(default_factory=generate_event_id)
    name: str
    payload: dict[str, Any] = Field(default_factory=dict)
    source: str = ""
    timestamp: float = Field(default_factory=time.time)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Event):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __repr__(self) -> str:
        return f"Event(id='{self.id}', name='{self.name}', source='{self.source}')"

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Event:
        return cls.model_validate(d)
