from __future__ import annotations

from typing import Any, Iterator

import networkx as nx

from pyrapide.core.clock import ClockManager
from pyrapide.core.event import Event
from pyrapide.core.exceptions import CausalCycleError
from pyrapide.core.poset import Poset


class Computation:
    """High-level wrapper around a Poset and ClockManager for querying causal event computations."""

    def __init__(
        self,
        poset: Poset | None = None,
        clock_manager: ClockManager | None = None,
    ) -> None:
        self._poset = poset or Poset()
        self._clock_manager = clock_manager or ClockManager()

    @property
    def clock_manager(self) -> ClockManager:
        return self._clock_manager

    def record(
        self,
        event: Event,
        caused_by: list[Event] | None = None,
        clock: str | None = None,
    ) -> None:
        self._poset.add(event, caused_by=caused_by)
        if clock is not None:
            self._clock_manager.stamp_event(event, clock_name=clock)

    # --- Delegated properties and methods ---

    @property
    def events(self) -> frozenset[Event]:
        return self._poset.events

    def __len__(self) -> int:
        return len(self._poset)

    def root_events(self) -> frozenset[Event]:
        return self._poset.root_events()

    def leaf_events(self) -> frozenset[Event]:
        return self._poset.leaf_events()

    def ancestors(self, event: Event) -> frozenset[Event]:
        return self._poset.ancestors(event)

    def descendants(self, event: Event) -> frozenset[Event]:
        return self._poset.descendants(event)

    def is_ancestor(self, a: Event, b: Event) -> bool:
        return self._poset.is_ancestor(a, b)

    def are_independent(self, a: Event, b: Event) -> bool:
        return self._poset.are_independent(a, b)

    def causal_chain(self, a: Event, b: Event) -> list[Event] | None:
        return self._poset.causal_chain(a, b)

    # --- Query methods ---

    def events_by_name(self, name: str) -> list[Event]:
        matching = [e for e in self._poset.events if e.name == name]
        return self._sort_by_clock(matching)

    def events_by_source(self, source: str) -> list[Event]:
        matching = [e for e in self._poset.events if e.source == source]
        return self._sort_by_clock(matching)

    def _sort_by_clock(self, events: list[Event]) -> list[Event]:
        """Sort events by timestamp on the first available clock, falling back to insertion order."""
        if not self._clock_manager._clocks:
            return events
        # Use the first registered clock that has stamps for these events
        for clock in self._clock_manager._clocks.values():
            stamped = {e.id: clock.start_time(e) for e in events if clock.start_time(e) is not None}
            if stamped:
                return sorted(events, key=lambda e: stamped.get(e.id, float("inf")))  # type: ignore[arg-type,return-value]
        return events

    def events_since(self, timestamp: float, clock_name: str | None = None) -> list[Event]:
        clock = self._get_clock(clock_name)
        if clock is None:
            return []
        return [
            e for e in self._poset.events
            if (t := clock.start_time(e)) is not None and t >= timestamp
        ]

    def events_between(self, start: float, end: float, clock_name: str | None = None) -> list[Event]:
        clock = self._get_clock(clock_name)
        if clock is None:
            return []
        return [
            e for e in self._poset.events
            if (t := clock.start_time(e)) is not None and start <= t <= end
        ]

    def _get_clock(self, clock_name: str | None = None) -> Any:
        if clock_name is not None:
            return self._clock_manager.get_clock(clock_name)
        # Return first available clock
        clocks = self._clock_manager._clocks
        if clocks:
            return next(iter(clocks.values()))
        return None

    def causal_depth(self) -> int:
        if len(self._poset) == 0:
            return 0
        return int(nx.dag_longest_path_length(self._poset._graph))

    # --- Merge ---

    def merge(self, other: Computation) -> Computation:
        merged_poset = Poset()

        # Add all events from both posets (dedup by id)
        for event in self._poset.events:
            merged_poset._events[event.id] = event
            merged_poset._graph.add_node(event.id)
        for event in other._poset.events:
            if event.id not in merged_poset._events:
                merged_poset._events[event.id] = event
                merged_poset._graph.add_node(event.id)

        # Add all edges from both
        for u, v in self._poset._graph.edges():
            merged_poset._graph.add_edge(u, v)
        for u, v in other._poset._graph.edges():
            merged_poset._graph.add_edge(u, v)

        if not nx.is_directed_acyclic_graph(merged_poset._graph):
            raise CausalCycleError("Merging computations would introduce a cycle")

        return Computation(poset=merged_poset)

    # --- Iteration ---

    def __iter__(self) -> Iterator[Event]:
        return iter(self.topological_order())

    def topological_order(self) -> list[Event]:
        return self._poset.topological_order()

    # --- Serialization ---

    def to_dict(self) -> dict[str, Any]:
        return {
            "poset": self._poset.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Computation:
        poset = Poset.from_dict(d["poset"])
        return cls(poset=poset)
