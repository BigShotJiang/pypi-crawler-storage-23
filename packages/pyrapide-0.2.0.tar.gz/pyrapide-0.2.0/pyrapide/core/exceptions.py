class CausalCycleError(Exception):
    """Raised when adding a causal edge would create a cycle in the poset."""
