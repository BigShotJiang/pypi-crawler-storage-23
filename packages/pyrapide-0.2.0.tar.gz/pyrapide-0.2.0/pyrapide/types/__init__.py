"""RAPIDE type system: interfaces, actions, behaviors, and subtype conformance checking."""

from pyrapide.types.actions import action, behavior, provides, requires
from pyrapide.types.interface import interface
from pyrapide.types.subtyping import conforms_to, is_subtype

__all__ = [
    "action",
    "behavior",
    "conforms_to",
    "interface",
    "is_subtype",
    "provides",
    "requires",
]
