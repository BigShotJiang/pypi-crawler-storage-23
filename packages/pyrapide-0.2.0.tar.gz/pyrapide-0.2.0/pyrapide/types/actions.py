from __future__ import annotations

from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def action(fn: F) -> F:
    """Mark a method as an event-generating action."""
    fn._pyrapide_is_action = True  # type: ignore[attr-defined]
    return fn


def provides(fn: F) -> F:
    """Mark a method as part of the externally visible interface."""
    fn._pyrapide_is_provided = True  # type: ignore[attr-defined]
    return fn


def requires(fn: F) -> F:
    """Mark a method as required but not implemented (like abstract)."""
    fn._pyrapide_is_required = True  # type: ignore[attr-defined]
    return fn


def behavior(fn: F) -> F:
    """Mark a method as a reactive behavior rule."""
    fn._pyrapide_is_behavior = True  # type: ignore[attr-defined]
    return fn
