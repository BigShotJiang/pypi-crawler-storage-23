from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class FunctionSignature:
    """Captures parameter names/types and return type for a callable."""

    params: dict[str, Any] = field(default_factory=dict)
    return_type: Any = None


def is_function_subtype(f1: FunctionSignature, f2: FunctionSignature) -> bool:
    """Check if f1 is a subtype of f2.

    f1 is a subtype of f2 if f1 accepts at least the same parameters
    (contravariance on inputs) and returns a compatible type (covariance on output).
    """
    # f1 must accept all parameters that f2 accepts
    for param_name in f2.params:
        if param_name not in f1.params:
            return False
    # Return type: f1's return must be the same or a subtype of f2's return
    if f2.return_type is not None and f1.return_type is not None:
        if f1.return_type is not f2.return_type:
            try:
                if not issubclass(f1.return_type, f2.return_type):
                    return False
            except TypeError:
                # Non-class types, fall back to equality
                if f1.return_type != f2.return_type:
                    return False
    return True
