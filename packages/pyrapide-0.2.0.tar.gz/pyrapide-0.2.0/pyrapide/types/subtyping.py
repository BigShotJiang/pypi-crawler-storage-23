from __future__ import annotations



def is_subtype(candidate: type, target: type) -> bool:
    """Check if candidate provides at least all operations that target provides.

    Operations = actions + provides. Checked by name.
    """
    target_actions: set[str] = getattr(target, "_pyrapide_actions", set())
    target_provides: set[str] = getattr(target, "_pyrapide_provides", set())
    target_ops = target_actions | target_provides

    candidate_actions: set[str] = getattr(candidate, "_pyrapide_actions", set())
    candidate_provides: set[str] = getattr(candidate, "_pyrapide_provides", set())
    candidate_ops = candidate_actions | candidate_provides

    return target_ops.issubset(candidate_ops)


def conforms_to(module_class: type, interface_class: type) -> bool:
    """Check if module_class implements all @requires methods of interface_class."""
    required: set[str] = getattr(interface_class, "_pyrapide_requires", set())
    for name in required:
        method = getattr(module_class, name, None)
        if method is None or not callable(method):
            return False
    return True
