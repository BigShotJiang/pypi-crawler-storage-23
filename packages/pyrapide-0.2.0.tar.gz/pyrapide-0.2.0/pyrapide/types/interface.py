from __future__ import annotations

import inspect
from typing import Any


def _scan_methods(klass: type) -> dict[str, set[str]]:
    """Scan a class for decorated methods, returning sets by category."""
    result: dict[str, set[str]] = {
        "actions": set(),
        "provides": set(),
        "requires": set(),
        "behaviors": set(),
    }
    for name, method in inspect.getmembers(klass, predicate=inspect.isfunction):
        if getattr(method, "_pyrapide_is_action", False):
            result["actions"].add(name)
        if getattr(method, "_pyrapide_is_provided", False):
            result["provides"].add(name)
        if getattr(method, "_pyrapide_is_required", False):
            result["requires"].add(name)
        if getattr(method, "_pyrapide_is_behavior", False):
            result["behaviors"].add(name)
    return result


def interface(cls: type) -> type:
    """Transform a Python class into a RAPIDE interface type.

    Scans for methods marked with @action, @provides, @requires, @behavior
    and nested service classes containing decorated methods.
    """
    actions: set[str] = set()
    provided: set[str] = set()
    required: set[str] = set()
    behaviors: set[str] = set()

    # Collect from all bases (MRO) for inheritance support
    for klass in reversed(cls.__mro__):
        if klass is object:
            continue
        for name, method in inspect.getmembers(klass, predicate=inspect.isfunction):
            if getattr(method, "_pyrapide_is_action", False):
                actions.add(name)
            if getattr(method, "_pyrapide_is_provided", False):
                provided.add(name)
            if getattr(method, "_pyrapide_is_required", False):
                required.add(name)
            if getattr(method, "_pyrapide_is_behavior", False):
                behaviors.add(name)

    interface_name = cls.__name__

    # Detect nested service classes
    services: dict[str, dict[str, set[str]]] = {}
    for attr_name, attr_val in inspect.getmembers(cls, predicate=inspect.isclass):
        if attr_val is cls or attr_val in cls.__mro__:
            continue
        svc_info = _scan_methods(attr_val)
        # Only register as a service if it has at least one decorated method
        has_decorations = any(svc_info[k] for k in svc_info)
        if has_decorations:
            services[attr_name] = svc_info

    # Build event alphabet: own actions + service actions (namespaced)
    event_alphabet = {f"{interface_name}.{a}" for a in actions}
    for svc_name, svc_info in services.items():
        for a in svc_info["actions"]:
            event_alphabet.add(f"{interface_name}.{svc_name}.{a}")

    cls._pyrapide_actions = actions  # type: ignore[attr-defined]
    cls._pyrapide_provides = provided  # type: ignore[attr-defined]
    cls._pyrapide_requires = required  # type: ignore[attr-defined]
    cls._pyrapide_behaviors = behaviors  # type: ignore[attr-defined]
    cls._pyrapide_services = services  # type: ignore[attr-defined]
    cls._pyrapide_event_alphabet = event_alphabet  # type: ignore[attr-defined]
    cls._pyrapide_is_interface = True  # type: ignore[attr-defined]

    @classmethod  # type: ignore[misc]
    def get_interface_info(klass: type) -> dict[str, Any]:
        return {
            "actions": klass._pyrapide_actions,  # type: ignore[attr-defined]
            "provides": klass._pyrapide_provides,  # type: ignore[attr-defined]
            "requires": klass._pyrapide_requires,  # type: ignore[attr-defined]
            "behaviors": klass._pyrapide_behaviors,  # type: ignore[attr-defined]
            "services": klass._pyrapide_services,  # type: ignore[attr-defined]
            "event_alphabet": klass._pyrapide_event_alphabet,  # type: ignore[attr-defined]
        }

    cls.get_interface_info = get_interface_info  # type: ignore[attr-defined]

    return cls
