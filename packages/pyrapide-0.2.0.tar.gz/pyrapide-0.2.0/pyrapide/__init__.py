"""PyRapide: Causal event-driven architecture modeling for Python, based on the RAPIDE 1.0 specification."""

__version__ = "0.2.0"

# Core
from pyrapide.core.clock import (
    Clock,
    ClockManager,
    RegularClock,
    SlavedClock,
    SynchronousClock,
)
from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.core.exceptions import CausalCycleError
from pyrapide.core.poset import Poset

# Types
from pyrapide.types.actions import action, behavior, provides, requires
from pyrapide.types.interface import interface
from pyrapide.types.subtyping import conforms_to, is_subtype

# Patterns
from pyrapide.patterns.base import BasicPattern, Pattern, PatternMatch, placeholder

# Architecture
from pyrapide.architecture.architecture import architecture
from pyrapide.architecture.connections import agent, connect, pipe

# Constraints
from pyrapide.constraints.monitor import ConstraintMonitor
from pyrapide.constraints.pattern_constraints import (
    Constraint,
    ConstraintViolation,
    MustMatch,
    Never,
    constraint,
    must_match,
    never,
)

# Executable
from pyrapide.executable.module import module
from pyrapide.executable.reactive import when

# Runtime
from pyrapide.runtime.engine import Engine
from pyrapide.runtime.streaming import InMemoryEventSource, StreamProcessor

# Integrations
from pyrapide.integrations.llm import LLMEventAdapter, LLMEventTypes
from pyrapide.integrations.mcp import MCPEventAdapter, MCPEventTypes, MCPPatterns

# Analysis
from pyrapide.analysis import queries, visualization
from pyrapide.analysis.prediction import AnomalyDetector, CausalPredictor

__all__ = [
    "__version__",
    # Core
    "CausalCycleError",
    "Clock",
    "ClockManager",
    "Computation",
    "Event",
    "Poset",
    "RegularClock",
    "SlavedClock",
    "SynchronousClock",
    # Types
    "action",
    "behavior",
    "conforms_to",
    "interface",
    "is_subtype",
    "provides",
    "requires",
    # Patterns
    "BasicPattern",
    "Pattern",
    "PatternMatch",
    "placeholder",
    # Architecture
    "agent",
    "architecture",
    "connect",
    "pipe",
    # Constraints
    "Constraint",
    "ConstraintMonitor",
    "ConstraintViolation",
    "MustMatch",
    "Never",
    "constraint",
    "must_match",
    "never",
    # Executable
    "module",
    "when",
    # Runtime
    "Engine",
    "InMemoryEventSource",
    "StreamProcessor",
    # Integrations
    "LLMEventAdapter",
    "LLMEventTypes",
    "MCPEventAdapter",
    "MCPEventTypes",
    "MCPPatterns",
    # Analysis
    "AnomalyDetector",
    "CausalPredictor",
    "queries",
    "visualization",
]
