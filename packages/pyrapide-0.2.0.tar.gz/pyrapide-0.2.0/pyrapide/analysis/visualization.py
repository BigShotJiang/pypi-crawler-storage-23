from __future__ import annotations

from typing import Any

import networkx as nx

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event


def to_dot(
    computation: Computation,
    highlight: set[Event] | None = None,
    event_types: set[str] | None = None,
    time_range: tuple[float, float] | None = None,
    max_events: int = 200,
) -> str:
    """Generate a Graphviz DOT string representing the computation poset.

    Args:
        computation: The computation to visualize.
        highlight: Events to color differently (red).
        event_types: Only show events with these names.
        time_range: Only show events within (start, end) timestamps.
        max_events: Truncate if more events than this.
    """
    highlight = highlight or set()
    highlight_ids = {e.id for e in highlight}

    events = _filter_events(computation, event_types, time_range)
    truncated = len(events) > max_events
    if truncated:
        events = events[:max_events]

    event_ids = {e.id for e in events}
    poset = computation._poset

    # Group events by source for subgraphs
    by_source: dict[str, list[Event]] = {}
    for e in events:
        by_source.setdefault(e.source or "unknown", []).append(e)

    lines = ["digraph computation {"]
    lines.append('  rankdir=TB;')
    if truncated:
        lines.append(f'  label="Showing {max_events} of {len(computation)} events (truncated)";')
    lines.append('  node [shape=box, style=filled, fillcolor=lightblue, fontsize=10];')
    lines.append("")

    # Subgraphs by source
    for idx, (source, source_events) in enumerate(sorted(by_source.items())):
        lines.append(f'  subgraph cluster_{idx} {{')
        lines.append(f'    label="{source}";')
        lines.append('    style=dashed;')
        for e in source_events:
            short_id = e.id[:8]
            label = f"{e.name}\\n{e.source}\\n{short_id}"
            if e.id in highlight_ids:
                lines.append(f'    "{e.id}" [label="{label}", fillcolor=red, fontcolor=white];')
            else:
                lines.append(f'    "{e.id}" [label="{label}"];')
        lines.append('  }')
        lines.append("")

    # Edges
    for e in events:
        if e.id not in poset._events:
            continue
        for pred_id in poset._graph.predecessors(e.id):
            if pred_id in event_ids:
                lines.append(f'  "{pred_id}" -> "{e.id}";')

    lines.append("}")
    return "\n".join(lines)


def to_mermaid(
    computation: Computation,
    highlight: set[Event] | None = None,
    event_types: set[str] | None = None,
    max_events: int = 100,
) -> str:
    """Generate a Mermaid flowchart string representing the computation poset."""
    highlight = highlight or set()
    highlight_ids = {e.id for e in highlight}

    events = _filter_events(computation, event_types, None)
    truncated = len(events) > max_events
    if truncated:
        events = events[:max_events]

    event_ids = {e.id for e in events}
    poset = computation._poset

    lines = ["graph TD"]

    if truncated:
        lines.append(f"  %% Showing {max_events} of {len(computation)} events")

    # Node definitions
    for e in events:
        safe_id = _mermaid_id(e.id)
        label = f"{e.name}\\n{e.source}"
        lines.append(f'  {safe_id}["{label}"]')

    # Edges
    for e in events:
        if e.id not in poset._events:
            continue
        for pred_id in poset._graph.predecessors(e.id):
            if pred_id in event_ids:
                lines.append(f"  {_mermaid_id(pred_id)} --> {_mermaid_id(e.id)}")

    # Highlight styling
    if highlight_ids:
        styled = [_mermaid_id(eid) for eid in highlight_ids if eid in event_ids]
        if styled:
            lines.append(f"  style {','.join(styled)} fill:#f66,color:#fff")

    return "\n".join(lines)


def to_json(computation: Computation) -> dict[str, Any]:
    """Return a JSON-serializable dict of the computation.

    Suitable for feeding to custom UI frameworks (D3.js, React, etc.).
    """
    poset = computation._poset
    events_list = []
    for e in computation.topological_order():
        events_list.append(e.to_dict())

    edges_list = []
    for u, v in poset._graph.edges():
        edges_list.append({"from": u, "to": v})

    depth = computation.causal_depth() if len(computation) > 0 else 0

    return {
        "events": events_list,
        "edges": edges_list,
        "metadata": {
            "event_count": len(computation),
            "edge_count": poset._graph.number_of_edges(),
            "causal_depth": depth,
        },
    }


def to_ascii(computation: Computation, max_width: int = 120) -> str:
    """Simple ASCII art representation for terminal output.

    Shows events with indentation representing causal depth.
    """
    if len(computation) == 0:
        return "(empty computation)"

    poset = computation._poset
    graph = poset._graph
    ordered = list(nx.topological_sort(graph))

    # Compute depth (longest path from any root to this node)
    depths: dict[str, int] = {}
    for node in ordered:
        preds = list(graph.predecessors(node))
        if not preds:
            depths[node] = 0
        else:
            depths[node] = max(depths[p] for p in preds) + 1

    lines = []
    for eid in ordered:
        event = poset._events[eid]
        depth = depths[eid]
        indent = "  " * depth
        marker = "+-" if depth > 0 else "* "
        preds = list(graph.predecessors(eid))

        line = f"{indent}{marker}[{event.name}] ({event.source}) {eid[:8]}"
        if len(line) > max_width:
            line = line[:max_width - 3] + "..."
        lines.append(line)

        # Show causal arrows for non-root events
        if preds:
            causes = ", ".join(poset._events[p].name for p in preds if p in poset._events)
            arrow_line = f"{indent}  <- {causes}"
            if len(arrow_line) > max_width:
                arrow_line = arrow_line[:max_width - 3] + "..."
            lines.append(arrow_line)

    return "\n".join(lines)


def summary(computation: Computation) -> str:
    """Human-readable text summary of a computation."""
    n_events = len(computation)
    n_edges = computation._poset._graph.number_of_edges() if n_events > 0 else 0
    depth = computation.causal_depth() if n_events > 0 else 0
    n_roots = len(computation.root_events()) if n_events > 0 else 0
    n_leaves = len(computation.leaf_events()) if n_events > 0 else 0

    lines = [
        f"Computation: {n_events} events, {n_edges} causal edges, "
        f"depth {depth}, {n_roots} root events, {n_leaves} leaf events"
    ]

    if n_events > 0:
        # Top event types by frequency
        freq: dict[str, int] = {}
        source_counts: dict[str, int] = {}
        for e in computation.events:
            freq[e.name] = freq.get(e.name, 0) + 1
            source_counts[e.source] = source_counts.get(e.source, 0) + 1

        top_types = sorted(freq.items(), key=lambda x: -x[1])[:5]
        lines.append("Top event types:")
        for name, count in top_types:
            lines.append(f"  {name}: {count}")

        top_sources = sorted(source_counts.items(), key=lambda x: -x[1])[:3]
        lines.append("Top sources:")
        for source, count in top_sources:
            lines.append(f"  {source}: {count}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _filter_events(
    computation: Computation,
    event_types: set[str] | None,
    time_range: tuple[float, float] | None,
) -> list[Event]:
    """Filter and return events in topological order."""
    events = computation.topological_order()

    if event_types is not None:
        events = [e for e in events if e.name in event_types]

    if time_range is not None:
        start, end = time_range
        events = [e for e in events if start <= e.timestamp <= end]

    return events


def _mermaid_id(event_id: str) -> str:
    """Convert a UUID to a valid Mermaid node ID."""
    return "n" + event_id.replace("-", "")
