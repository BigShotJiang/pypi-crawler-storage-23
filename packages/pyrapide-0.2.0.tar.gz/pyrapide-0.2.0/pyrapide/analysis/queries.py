from __future__ import annotations


import networkx as nx

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.core.poset import Poset


def critical_path(computation: Computation) -> list[Event]:
    """Return the longest causal chain in the computation.

    If multiple chains tie, returns any one of them.
    """
    poset = computation._poset
    if len(poset) == 0:
        return []

    path_ids = nx.dag_longest_path(poset._graph)
    return [poset._events[eid] for eid in path_ids]


def root_causes(computation: Computation, target_event: Event) -> frozenset[Event]:
    """Return all root events that are ancestors of the target event."""
    poset = computation._poset
    ancestors = nx.ancestors(poset._graph, target_event.id)
    roots = computation.root_events()
    return frozenset(r for r in roots if r.id in ancestors)


def impact_set(computation: Computation, source_event: Event) -> frozenset[Event]:
    """Return all events that are descendants of source_event."""
    return computation.descendants(source_event)


def causal_distance(computation: Computation, a: Event, b: Event) -> int | None:
    """Return the length of the shortest causal path from a to b, or None."""
    poset = computation._poset
    try:
        path = nx.shortest_path(poset._graph, a.id, b.id)
        return len(path) - 1
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return None


def common_ancestors(computation: Computation, a: Event, b: Event) -> frozenset[Event]:
    """Return events that are ancestors of both a and b."""
    return computation._poset.common_ancestors(a, b)


def backward_slice(computation: Computation, target_event: Event) -> Computation:
    """Return a Computation with only target_event and all its transitive ancestors.

    All causal edges between surviving events are preserved.
    """
    poset = computation._poset
    ancestor_ids = nx.ancestors(poset._graph, target_event.id)
    ancestor_ids.add(target_event.id)

    return _build_subcomputation(poset, ancestor_ids)


def forward_slice(computation: Computation, source_event: Event) -> Computation:
    """Return a Computation with only source_event and all its transitive descendants.

    All causal edges between surviving events are preserved.
    """
    poset = computation._poset
    descendant_ids = nx.descendants(poset._graph, source_event.id)
    descendant_ids.add(source_event.id)

    return _build_subcomputation(poset, descendant_ids)


def _build_subcomputation(poset: Poset, event_ids: set[str]) -> Computation:
    """Build a new Computation from a subset of events, preserving causal edges."""
    new_comp = Computation()
    ordered = [eid for eid in nx.topological_sort(poset._graph) if eid in event_ids]

    for eid in ordered:
        event = poset._events[eid]
        causes = [
            poset._events[pred]
            for pred in poset._graph.predecessors(eid)
            if pred in event_ids
        ]
        new_comp.record(event, caused_by=causes or None)

    return new_comp


def parallel_events(computation: Computation) -> list[frozenset[Event]]:
    """Return groups of events that are mutually causally independent.

    Uses an antichain decomposition: partition events into sets where
    all members are pairwise independent.
    """
    poset = computation._poset
    if len(poset) == 0:
        return []

    graph = poset._graph
    ordered = list(nx.topological_sort(graph))

    # Compute the longest path length from any root to each node
    # Events at the same "level" in a width partition are candidates for independence
    levels: dict[str, int] = {}
    for node in ordered:
        preds = list(graph.predecessors(node))
        if not preds:
            levels[node] = 0
        else:
            levels[node] = max(levels[p] for p in preds) + 1

    # Group by level
    level_groups: dict[int, list[str]] = {}
    for node, level in levels.items():
        level_groups.setdefault(level, []).append(node)

    # Filter each level group to only truly independent events
    result: list[frozenset[Event]] = []
    for level, nodes in sorted(level_groups.items()):
        if len(nodes) < 2:
            continue
        # Verify pairwise independence
        independent = set()
        for i, n1 in enumerate(nodes):
            for n2 in nodes[i + 1:]:
                if not nx.has_path(graph, n1, n2) and not nx.has_path(graph, n2, n1):
                    independent.add(n1)
                    independent.add(n2)
        if independent:
            result.append(frozenset(poset._events[eid] for eid in independent))

    return result


def bottleneck_events(computation: Computation) -> list[Event]:
    """Return events that appear on every causal path from every root to every leaf.

    These are the "cut points" — removing any one would disconnect some
    root-to-leaf path.
    """
    poset = computation._poset
    if len(poset) == 0:
        return []

    graph = poset._graph
    roots = [eid for eid, d in graph.in_degree() if d == 0]
    leaves = [eid for eid, d in graph.out_degree() if d == 0]

    if not roots or not leaves:
        return []

    # An event is a bottleneck if it lies on ALL root-to-leaf paths
    # Collect all events that appear on every root-to-leaf path
    # Use the intersection approach: for each (root, leaf) pair, find all
    # events on any path between them, then intersect across all pairs.

    all_path_events: set[str] | None = None

    for root in roots:
        for leaf in leaves:
            if not nx.has_path(graph, root, leaf):
                continue
            # Find all nodes that lie on some path from root to leaf
            # A node v is on some root->leaf path iff:
            #   root can reach v AND v can reach leaf
            reachable_from_root = nx.descendants(graph, root) | {root}
            can_reach_leaf = nx.ancestors(graph, leaf) | {leaf}
            on_some_path = reachable_from_root & can_reach_leaf

            # A node is a bottleneck for this pair if removing it disconnects root from leaf
            pair_bottlenecks = set()
            for node in on_some_path:
                if node == root or node == leaf:
                    # Root and leaf are always on the path
                    pair_bottlenecks.add(node)
                    continue
                # Check if root can still reach leaf without this node
                remaining = on_some_path - {node}
                # Build subgraph without node
                sub = graph.subgraph(remaining)
                if not nx.has_path(sub, root, leaf):
                    pair_bottlenecks.add(node)

            if all_path_events is None:
                all_path_events = pair_bottlenecks
            else:
                all_path_events &= pair_bottlenecks

    if all_path_events is None:
        return []

    # Return in topological order
    ordered = list(nx.topological_sort(graph))
    return [poset._events[eid] for eid in ordered if eid in all_path_events]


def event_frequency(computation: Computation) -> dict[str, int]:
    """Count events by name."""
    counter: dict[str, int] = {}
    for event in computation.events:
        counter[event.name] = counter.get(event.name, 0) + 1
    return counter


def causal_density(computation: Computation) -> float:
    """Ratio of actual causal edges to maximum possible edges in a DAG.

    Returns 0.0 for empty or single-event computations.
    """
    n = len(computation)
    if n < 2:
        return 0.0

    max_edges = n * (n - 1) / 2  # Maximum edges in a DAG
    actual_edges = computation._poset._graph.number_of_edges()
    return float(actual_edges / max_edges)
