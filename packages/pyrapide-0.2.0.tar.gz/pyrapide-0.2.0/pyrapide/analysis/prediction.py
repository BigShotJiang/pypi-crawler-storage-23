from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event


@dataclass(frozen=True)
class Prediction:
    """A predicted future event."""

    event_name: str
    confidence: float
    likely_cause: str
    expected_delay: float | None
    reasoning: str


@dataclass(frozen=True)
class Anomaly:
    """A detected anomaly in a computation."""

    event: Event
    anomaly_type: str  # "unseen_event", "unusual_cause", "timing_anomaly"
    severity: float  # 0.0 to 1.0
    description: str


class CausalPredictor:
    """Learns causal patterns from computations and predicts future events."""

    def __init__(self) -> None:
        # transition_counts[cause_type][effect_type] = count
        self._transitions: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        # timing[cause_type][effect_type] = list of delays
        self._timing: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))

    def learn(self, computation: Computation) -> None:
        """Extract causal patterns from a computation."""
        poset = computation._poset
        graph = poset._graph

        for edge_u, edge_v in graph.edges():
            cause = poset._events[edge_u]
            effect = poset._events[edge_v]
            self._transitions[cause.name][effect.name] += 1

            delay = effect.timestamp - cause.timestamp
            if delay >= 0:
                self._timing[cause.name][effect.name].append(delay)

    def predict(
        self,
        current_computation: Computation,
        horizon: int = 5,
        confidence_threshold: float = 0.1,
    ) -> list[Prediction]:
        """Predict likely next events based on current leaf events."""
        if not self._transitions:
            return []

        leaves = current_computation.leaf_events()
        leaf_types = {e.name for e in leaves}

        predictions: list[Prediction] = []
        seen: set[tuple[str, str]] = set()  # (cause_type, effect_type)

        for cause_type in leaf_types:
            if cause_type not in self._transitions:
                continue
            preds = self._predict_for_type(cause_type, confidence_threshold)
            for p in preds:
                key = (p.likely_cause, p.event_name)
                if key not in seen:
                    seen.add(key)
                    predictions.append(p)

        predictions.sort(key=lambda p: -p.confidence)
        return predictions[:horizon]

    def predict_from_event(self, event: Event) -> list[Prediction]:
        """Predict what is likely to follow a specific event type."""
        if event.name not in self._transitions:
            return []
        return self._predict_for_type(event.name, confidence_threshold=0.0)

    def _predict_for_type(
        self, cause_type: str, confidence_threshold: float
    ) -> list[Prediction]:
        """Generate predictions for a given cause event type."""
        successors = self._transitions.get(cause_type, {})
        total = sum(successors.values())
        if total == 0:
            return []

        predictions: list[Prediction] = []
        for effect_type, count in sorted(successors.items(), key=lambda x: -x[1]):
            confidence = count / total
            if confidence < confidence_threshold:
                continue

            timing_data = self._timing.get(cause_type, {}).get(effect_type, [])
            expected_delay = (
                sum(timing_data) / len(timing_data) if timing_data else None
            )

            predictions.append(
                Prediction(
                    event_name=effect_type,
                    confidence=confidence,
                    likely_cause=cause_type,
                    expected_delay=expected_delay,
                    reasoning=f"{cause_type} caused {effect_type} in {count}/{total} observations ({confidence:.0%})",
                )
            )

        return predictions


class AnomalyDetector:
    """Detects anomalies in computations by comparing against learned patterns."""

    def __init__(self) -> None:
        self._known_event_types: set[str] = set()
        self._known_causal_pairs: set[tuple[str, str]] = set()
        self._timing_stats: dict[tuple[str, str], _TimingStats] = {}

    def learn(self, computations: list[Computation]) -> None:
        """Build a model of normal causal patterns from training data."""
        timing_data: dict[tuple[str, str], list[float]] = defaultdict(list)

        for comp in computations:
            poset = comp._poset
            graph = poset._graph

            for eid in graph.nodes():
                event = poset._events[eid]
                self._known_event_types.add(event.name)

            for edge_u, edge_v in graph.edges():
                cause = poset._events[edge_u]
                effect = poset._events[edge_v]
                pair = (cause.name, effect.name)
                self._known_causal_pairs.add(pair)

                delay = effect.timestamp - cause.timestamp
                if delay >= 0:
                    timing_data[pair].append(delay)

        # Compute timing statistics
        for pair, delays in timing_data.items():
            if delays:
                mean = sum(delays) / len(delays)
                variance = sum((d - mean) ** 2 for d in delays) / len(delays)
                std = variance**0.5
                self._timing_stats[pair] = _TimingStats(mean=mean, std=std, count=len(delays))

    def detect(self, computation: Computation) -> list[Anomaly]:
        """Identify anomalous events or causal links in a computation."""
        anomalies: list[Anomaly] = []
        poset = computation._poset
        graph = poset._graph

        for eid in graph.nodes():
            event = poset._events[eid]

            # Check for unseen event types
            if event.name not in self._known_event_types:
                anomalies.append(
                    Anomaly(
                        event=event,
                        anomaly_type="unseen_event",
                        severity=0.9,
                        description=f"Event type '{event.name}' was never observed during training",
                    )
                )

            # Check causal links from predecessors
            for pred_id in graph.predecessors(eid):
                cause = poset._events[pred_id]
                pair = (cause.name, event.name)

                if pair not in self._known_causal_pairs:
                    # Only flag unusual cause if both event types are known
                    # (unseen events are already flagged above)
                    severity = 0.7 if event.name in self._known_event_types else 0.5
                    anomalies.append(
                        Anomaly(
                            event=event,
                            anomaly_type="unusual_cause",
                            severity=severity,
                            description=f"Causal link '{cause.name}' -> '{event.name}' was never observed during training",
                        )
                    )

                # Check timing anomalies
                if pair in self._timing_stats:
                    stats = self._timing_stats[pair]
                    delay = event.timestamp - cause.timestamp
                    if stats.std > 0 and stats.count >= 3:
                        z_score = abs(delay - stats.mean) / stats.std
                        if z_score > 3.0:
                            severity = min(1.0, z_score / 10.0)
                            anomalies.append(
                                Anomaly(
                                    event=event,
                                    anomaly_type="timing_anomaly",
                                    severity=severity,
                                    description=f"Timing of '{cause.name}' -> '{event.name}' is {z_score:.1f} std devs from mean ({delay:.3f}s vs {stats.mean:.3f}s avg)",
                                )
                            )

        return anomalies


@dataclass(frozen=True)
class _TimingStats:
    mean: float
    std: float
    count: int
