from __future__ import annotations

from typing import Any

from pyrapide.types.subtyping import conforms_to


class Binding:
    """Stores an interface-module association."""

    def __init__(self, interface_instance: Any, module_class: type) -> None:
        self.interface_instance = interface_instance
        self.module_class = module_class


def bind(interface_obj: Any, module_class: type) -> Binding:
    """Bind a module implementation to an interface object at runtime.

    Raises TypeError if the module does not conform to the interface's @requires.
    """
    interface_type = type(interface_obj)
    if not conforms_to(module_class, interface_type):
        raise TypeError(
            f"{module_class.__name__} does not conform to "
            f"{interface_type.__name__}: missing required methods"
        )
    return Binding(interface_instance=interface_obj, module_class=module_class)
