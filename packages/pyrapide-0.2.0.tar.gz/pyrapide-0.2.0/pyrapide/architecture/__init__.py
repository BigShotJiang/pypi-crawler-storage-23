"""Architecture definitions: component composition, connections, bindings, and communication scopes."""

from pyrapide.architecture.architecture import architecture
from pyrapide.architecture.bindings import Binding, bind
from pyrapide.architecture.communication import CommunicationContext, CommunicationScope
from pyrapide.architecture.connections import (
    AgentConnection,
    BasicConnection,
    Connection,
    ConnectionManager,
    PipeConnection,
    agent,
    connect,
    pipe,
)
from pyrapide.architecture.maps import ArchitectureMap

__all__ = [
    "AgentConnection",
    "ArchitectureMap",
    "BasicConnection",
    "Binding",
    "CommunicationContext",
    "CommunicationScope",
    "Connection",
    "ConnectionManager",
    "PipeConnection",
    "agent",
    "architecture",
    "bind",
    "connect",
    "pipe",
]
