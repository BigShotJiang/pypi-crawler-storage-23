from __future__ import annotations

import asyncio
from typing import Any, Callable, TYPE_CHECKING

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, PatternMatch

if TYPE_CHECKING:
    from pyrapide.core.computation import Computation


class Connection:
    """Base class for architecture connections."""

    def __init__(
        self,
        source_pattern: Pattern,
        handler: Callable[..., Any],
        connection_type: str = "basic",
    ) -> None:
        self.source_pattern = source_pattern
        self.handler = handler
        self.connection_type = connection_type
        self.active: bool = True


class BasicConnection(Connection):
    """Synchronous connection: handler called directly when pattern matches."""

    def __init__(self, source_pattern: Pattern, handler: Callable[..., Any]) -> None:
        super().__init__(source_pattern, handler, connection_type="basic")

    def fire(self, match: PatternMatch, computation: Computation) -> None:
        self.handler(match, computation)


class PipeConnection(Connection):
    """Queued FIFO connection: matches are enqueued and processed in order."""

    def __init__(self, source_pattern: Pattern, handler: Callable[..., Any]) -> None:
        super().__init__(source_pattern, handler, connection_type="pipe")
        self._queue: asyncio.Queue[tuple[PatternMatch, Computation] | None] = asyncio.Queue()
        self._task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self._task = asyncio.create_task(self._consumer())

    async def stop(self) -> None:
        await self._queue.put(None)
        if self._task is not None:
            await self._task

    async def enqueue(self, event: Event, computation: Computation) -> None:
        from pyrapide.core.poset import Poset

        # Build a tiny poset with just this event for pattern matching
        p = Poset()
        p.add(event)
        matches = self.source_pattern.match_in(p)
        for m in matches:
            await self._queue.put((m, computation))

    async def drain(self) -> None:
        """Wait until all currently queued items are processed."""
        await self._queue.join()

    async def _consumer(self) -> None:
        while True:
            item = await self._queue.get()
            if item is None:
                self._queue.task_done()
                break
            match, comp = item
            result = self.handler(match, comp)
            if asyncio.iscoroutine(result):
                await result
            self._queue.task_done()


class AgentConnection(Connection):
    """Independent async connection: each match dispatched as a separate task."""

    def __init__(self, source_pattern: Pattern, handler: Callable[..., Any]) -> None:
        super().__init__(source_pattern, handler, connection_type="agent")

    async def dispatch(self, event: Event, computation: Computation) -> asyncio.Task[None]:
        from pyrapide.core.poset import Poset

        p = Poset()
        p.add(event)
        matches = self.source_pattern.match_in(p)

        async def _run() -> None:
            for m in matches:
                result = self.handler(m, computation)
                if asyncio.iscoroutine(result):
                    await result

        return asyncio.create_task(_run())


class ConnectionManager:
    """Manages all connections for an architecture."""

    def __init__(self) -> None:
        self._connections: list[Connection] = []

    def add_connection(self, connection: Connection) -> None:
        self._connections.append(connection)

    @property
    def connections(self) -> list[Connection]:
        return list(self._connections)

    def process_event(self, event: Event, computation: Computation) -> None:
        """Process an event through all active basic connections."""
        from pyrapide.core.poset import Poset

        # Build a single-event poset for matching
        p = Poset()
        p.add(event)

        for conn in self._connections:
            if not conn.active:
                continue
            matches = conn.source_pattern.match_in(p)
            for match in matches:
                if isinstance(conn, BasicConnection):
                    conn.fire(match, computation)


# Factory functions

def connect(source_pattern: Pattern, handler: Callable[..., Any]) -> BasicConnection:
    """Create a synchronous connection that fires a handler when a pattern matches.

    This is the standard connection type where the handler is called directly
    in the current execution context whenever the source pattern matches an event.

    Example::

        conn = connect(Pattern.match("request"), "handler_component")
    """
    return BasicConnection(source_pattern=source_pattern, handler=handler)


def pipe(source_pattern: Pattern, handler: Callable[..., Any]) -> PipeConnection:
    """Create a FIFO pipe connection that queues matches for ordered processing.

    Pipe connections enqueue pattern matches and process them sequentially,
    preserving the order in which events were received.

    Example::

        conn = pipe(Pattern.match("data.chunk"), process_chunk)
    """
    return PipeConnection(source_pattern=source_pattern, handler=handler)


def agent(source_pattern: Pattern, handler: Callable[..., Any]) -> AgentConnection:
    """Create an independent async connection that dispatches each match as a separate task.

    Agent connections run each matched event's handler concurrently as an
    independent asyncio task, suitable for long-running or parallel processing.

    Example::

        conn = agent(Pattern.match("job.submitted"), run_job)
    """
    return AgentConnection(source_pattern=source_pattern, handler=handler)
