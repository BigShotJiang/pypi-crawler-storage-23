from __future__ import annotations

from pyrapide.core.event import Event


class CommunicationScope:
    """Defines who can observe whose events at runtime."""

    def __init__(self) -> None:
        self._links: set[tuple[str, str]] = set()
        self._children: dict[str, set[str]] = {}  # parent -> {children}

    def register_link(self, a: str, b: str) -> None:
        """Record that a and b are connected (bidirectional observation)."""
        self._links.add((a, b))
        self._links.add((b, a))

    def register_parent(self, parent: str, child: str) -> None:
        """Record that parent architecture contains child component."""
        self._children.setdefault(parent, set()).add(child)

    def can_observe(self, observer: str, target: str) -> bool:
        """Check whether the observer component can see events from the target.

        A component can observe itself, its children (if it is a parent architecture),
        or any component it is explicitly linked to.

        Example::

            scope = CommunicationScope()
            scope.register_link("server", "database")
            assert scope.can_observe("server", "database")
        """
        # A module can always observe itself
        if observer == target:
            return True
        # Parent can observe its children
        if target in self._children.get(observer, set()):
            return True
        # Linked modules can observe each other
        if (observer, target) in self._links:
            return True
        return False


class CommunicationContext:
    """Tracks the current causal context during execution."""

    def __init__(self, causes: list[Event] | None = None) -> None:
        self._causes: list[Event] = list(causes) if causes else []

    @property
    def current_causes(self) -> list[Event]:
        return self._causes

    def push_cause(self, event: Event) -> None:
        self._causes.append(event)

    def pop_cause(self) -> Event:
        return self._causes.pop()

    def fork(self) -> CommunicationContext:
        """Create an independent causal context with the same current causes."""
        return CommunicationContext(causes=list(self._causes))
