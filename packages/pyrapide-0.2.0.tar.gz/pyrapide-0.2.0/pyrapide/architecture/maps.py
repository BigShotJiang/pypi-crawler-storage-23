from __future__ import annotations


from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.core.poset import Poset
from pyrapide.patterns.base import Pattern


class ArchitectureMap:
    """Maps events from one architecture (domain) to another (range).

    mapping_rules: list of (source_pattern, target_event_name) tuples.
    When a source event matches source_pattern, a new event with target_event_name
    is created in the target computation, preserving payload and causal structure.
    """

    def __init__(
        self,
        domain: str,
        range: str,
        mapping_rules: list[tuple[Pattern, str]],
    ) -> None:
        self.domain = domain
        self.range = range
        self.mapping_rules = mapping_rules

    def apply(self, source_computation: Computation) -> Computation:
        """Transform a computation from domain to range architecture."""
        target = Computation()
        # Map from source event id -> target event, for preserving causality
        id_map: dict[str, Event] = {}

        # Process events in topological order to ensure causes are mapped first
        for source_event in source_computation.topological_order():
            target_name = self._find_mapping(source_event, source_computation)
            if target_name is None:
                continue

            mapped_event = Event(
                name=target_name,
                payload=dict(source_event.payload),
                source=source_event.source,
                metadata={**source_event.metadata, "_source_id": source_event.id},
            )

            # Find mapped causes
            source_causes = source_computation._poset.causes(source_event)
            mapped_causes = [
                id_map[c.id] for c in source_causes if c.id in id_map
            ]

            target.record(mapped_event, caused_by=mapped_causes or None)
            id_map[source_event.id] = mapped_event

        return target

    def _find_mapping(self, event: Event, computation: Computation) -> str | None:
        """Find the target event name for a source event, or None if no rule matches."""
        # Build a single-event poset for pattern matching
        p = Poset()
        p.add(event)
        for pattern, target_name in self.mapping_rules:
            if pattern.match_in(p):
                return target_name
        return None
