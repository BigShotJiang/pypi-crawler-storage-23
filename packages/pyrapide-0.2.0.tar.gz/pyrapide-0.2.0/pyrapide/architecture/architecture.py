from __future__ import annotations

from typing import Any, get_type_hints

from pyrapide.core.computation import Computation


def _is_interface_type(typ: Any) -> bool:
    """Check if a type is an @interface-decorated class."""
    return isinstance(typ, type) and getattr(typ, "_pyrapide_is_interface", False)


def architecture(cls: type) -> type:
    """Transform a class into a RAPIDE architecture.

    Scans type-annotated attributes for @interface-decorated types (components)
    and stores architecture metadata.
    """
    # Resolve annotations — use get_type_hints to handle forward refs,
    # but fall back to __annotations__ if that fails (e.g. unresolvable refs)
    try:
        hints = get_type_hints(cls)
    except Exception:
        hints = getattr(cls, "__annotations__", {})

    components: dict[str, type] = {}
    for attr_name, attr_type in hints.items():
        if _is_interface_type(attr_type):
            components[attr_name] = attr_type

    cls._pyrapide_is_architecture = True  # type: ignore[attr-defined]
    cls._pyrapide_components = components  # type: ignore[attr-defined]

    original_init = cls.__init__ if "__init__" in cls.__dict__ else None  # type: ignore[misc]

    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        if original_init is not None:
            original_init(self, *args, **kwargs)
        # Auto-instantiate components
        for name, iface_type in self._pyrapide_components.items():
            if not hasattr(self, name) or not isinstance(getattr(self, name), iface_type):
                setattr(self, name, iface_type())
        # Internal computation
        if not hasattr(self, "_computation"):
            self._computation = Computation()

    cls.__init__ = __init__  # type: ignore[misc]

    cls.components = property(lambda self: {n: getattr(self, n) for n in self._pyrapide_components})  # type: ignore[attr-defined]
    cls.computation = property(lambda self: self._computation)  # type: ignore[attr-defined]

    @classmethod  # type: ignore[misc]
    def get_architecture_info(klass: type) -> dict[str, Any]:
        return {
            "components": {n: t.__name__ for n, t in klass._pyrapide_components.items()},  # type: ignore[attr-defined]
            "component_types": dict(klass._pyrapide_components),  # type: ignore[attr-defined]
            "is_architecture": True,
        }

    cls.get_architecture_info = get_architecture_info  # type: ignore[attr-defined]

    return cls
