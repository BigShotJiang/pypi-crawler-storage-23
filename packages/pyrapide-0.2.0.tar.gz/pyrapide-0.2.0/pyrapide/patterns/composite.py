from __future__ import annotations

from typing import Any, TYPE_CHECKING

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, PatternMatch

if TYPE_CHECKING:
    from pyrapide.core.poset import Poset


def _merge_bindings(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    merged = dict(a)
    merged.update(b)
    return merged


def _merge_events(
    a: tuple[Any, ...], b: tuple[Any, ...]
) -> tuple[Any, ...]:
    seen_ids: set[str] = set()
    result = []
    for e in (*a, *b):
        if e.id not in seen_ids:
            seen_ids.add(e.id)
            result.append(e)
    return tuple(result)


class SequencePattern(Pattern):
    """P >> Q: P must causally precede Q."""

    def __init__(self, first: Pattern, second: Pattern) -> None:
        self.first = first
        self.second = second

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        p_matches = self.first.match_in(poset, bindings)
        q_matches = self.second.match_in(poset, bindings)
        results: list[PatternMatch] = []
        for pm in p_matches:
            for qm in q_matches:
                if self._has_causal_link(poset, pm, qm):
                    results.append(PatternMatch(
                        events=_merge_events(pm.events, qm.events),
                        bindings=_merge_bindings(pm.bindings, qm.bindings),
                    ))
        return results

    def _has_causal_link(self, poset: Poset, pm: PatternMatch, qm: PatternMatch) -> bool:
        for pe in pm.events:
            for qe in qm.events:
                if pe.id != qe.id and poset.is_ancestor(pe, qe):
                    return True
        return False


class ImmediateSequencePattern(Pattern):
    """P then immediately Q: P is a DIRECT cause of Q."""

    def __init__(self, first: Pattern, second: Pattern) -> None:
        self.first = first
        self.second = second

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        p_matches = self.first.match_in(poset, bindings)
        q_matches = self.second.match_in(poset, bindings)
        results: list[PatternMatch] = []
        for pm in p_matches:
            for qm in q_matches:
                if self._has_direct_link(poset, pm, qm):
                    results.append(PatternMatch(
                        events=_merge_events(pm.events, qm.events),
                        bindings=_merge_bindings(pm.bindings, qm.bindings),
                    ))
        return results

    def _has_direct_link(self, poset: Poset, pm: PatternMatch, qm: PatternMatch) -> bool:
        for pe in pm.events:
            for qe in qm.events:
                if pe in poset.causes(qe):
                    return True
        return False


class JoinPattern(Pattern):
    """P & Q: Both match and share at least one common causal ancestor."""

    def __init__(self, left: Pattern, right: Pattern) -> None:
        self.left = left
        self.right = right

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        l_matches = self.left.match_in(poset, bindings)
        r_matches = self.right.match_in(poset, bindings)
        results: list[PatternMatch] = []
        for lm in l_matches:
            for rm in r_matches:
                if self._has_common_ancestor(poset, lm, rm):
                    results.append(PatternMatch(
                        events=_merge_events(lm.events, rm.events),
                        bindings=_merge_bindings(lm.bindings, rm.bindings),
                    ))
        return results

    def _has_common_ancestor(self, poset: Poset, lm: PatternMatch, rm: PatternMatch) -> bool:
        for le in lm.events:
            for re in rm.events:
                if poset.common_ancestors(le, re):
                    return True
        return False


class IndependencePattern(Pattern):
    """P | Q: Both match but are causally independent."""

    def __init__(self, left: Pattern, right: Pattern) -> None:
        self.left = left
        self.right = right

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        l_matches = self.left.match_in(poset, bindings)
        r_matches = self.right.match_in(poset, bindings)
        results: list[PatternMatch] = []
        for lm in l_matches:
            for rm in r_matches:
                if self._all_independent(poset, lm, rm):
                    results.append(PatternMatch(
                        events=_merge_events(lm.events, rm.events),
                        bindings=_merge_bindings(lm.bindings, rm.bindings),
                    ))
        return results

    def _all_independent(self, poset: Poset, lm: PatternMatch, rm: PatternMatch) -> bool:
        for le in lm.events:
            for re in rm.events:
                if not poset.are_independent(le, re):
                    return False
        return True


class DisjunctionPattern(Pattern):
    """P or Q: Either P or Q matches."""

    def __init__(self, left: Pattern, right: Pattern) -> None:
        self.left = left
        self.right = right

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        return self.left.match_in(poset, bindings) + self.right.match_in(poset, bindings)


class UnionPattern(Pattern):
    """Union of P and Q: like disjunction, bindings preserved from matching side."""

    def __init__(self, left: Pattern, right: Pattern) -> None:
        self.left = left
        self.right = right

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        return self.left.match_in(poset, bindings) + self.right.match_in(poset, bindings)


class IterationPattern(Pattern):
    """P.repeat(): Matches all occurrences of P, returning a single combined match."""

    def __init__(self, pattern: Pattern) -> None:
        self.pattern = pattern

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        individual = self.pattern.match_in(poset, bindings)
        if not individual:
            return []

        all_events: list[Event] = []
        collected_bindings: dict[str, list[Any]] = {}
        seen_ids: set[str] = set()

        for m in individual:
            for e in m.events:
                if e.id not in seen_ids:
                    seen_ids.add(e.id)
                    all_events.append(e)
            for k, v in m.bindings.items():
                collected_bindings.setdefault(k, []).append(v)

        return [PatternMatch(
            events=tuple(all_events),
            bindings=collected_bindings,
        )]
