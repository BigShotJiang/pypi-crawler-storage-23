from __future__ import annotations

from typing import Any, TYPE_CHECKING

from pyrapide.patterns.base import Pattern, PatternMatch

if TYPE_CHECKING:
    from pyrapide.core.clock import Clock
    from pyrapide.core.poset import Poset


class TimedPattern(Pattern):
    """Pattern with timing constraints relative to a clock."""

    def __init__(
        self,
        pattern: Pattern,
        clock: Clock,
        max_duration: float | None = None,
        after_time: float | None = None,
        before_time: float | None = None,
    ) -> None:
        self.pattern = pattern
        self.clock = clock
        self.max_duration = max_duration
        self.after_time = after_time
        self.before_time = before_time

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        inner_matches = self.pattern.match_in(poset, bindings)
        return [m for m in inner_matches if self._passes_timing(m)]

    def _passes_timing(self, match: PatternMatch) -> bool:
        times: list[float] = []
        for event in match.events:
            t = self.clock.start_time(event)
            if t is None:
                return False
            times.append(t)

        if not times:
            return False

        if self.after_time is not None:
            if any(t < self.after_time for t in times):
                return False

        if self.before_time is not None:
            if any(t > self.before_time for t in times):
                return False

        if self.max_duration is not None:
            span = max(times) - min(times)
            if span > self.max_duration:
                return False

        return True
