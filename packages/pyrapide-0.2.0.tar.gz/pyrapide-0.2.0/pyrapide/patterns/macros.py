from __future__ import annotations

from typing import Any, Callable

from pyrapide.patterns.base import Pattern


def pattern_macro(fn: Callable[..., Pattern]) -> Callable[..., Pattern]:
    """Decorator marking a function as a pattern macro (factory)."""
    fn._pyrapide_is_pattern_macro = True  # type: ignore[attr-defined]
    return fn


class PatternLibrary:
    """Registry of named pattern macros."""

    def __init__(self) -> None:
        self._macros: dict[str, Callable[..., Pattern]] = {}

    def register(self, name: str, macro_fn: Callable[..., Pattern]) -> None:
        self._macros[name] = macro_fn

    def get(self, name: str, **kwargs: Any) -> Pattern:
        return self._macros[name](**kwargs)
