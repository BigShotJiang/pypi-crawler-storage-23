from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from pyrapide.core.poset import Poset
    from pyrapide.core.event import Event


@dataclass(frozen=True)
class Placeholder:
    """A binding variable used in pattern definitions to capture matched values."""

    name: str


def placeholder(name: str) -> Placeholder:
    """Factory function for creating placeholders."""
    return Placeholder(name=name)


@dataclass(frozen=True)
class PatternMatch:
    """Result of a pattern match: the matched events and bound values."""

    events: tuple[Event, ...]
    bindings: dict[str, Any]


class Pattern:
    """Abstract base class for all patterns."""

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        raise NotImplementedError

    @classmethod
    def match(cls, event_name: str, source: str | Placeholder | None = None, **field_matchers: Any) -> BasicPattern:
        return BasicPattern(
            event_name=event_name,
            field_matchers=field_matchers,
            source_matcher=source,
        )

    def __rshift__(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import SequencePattern
        return SequencePattern(self, other)

    def __and__(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import JoinPattern
        return JoinPattern(self, other)

    def __or__(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import IndependencePattern
        return IndependencePattern(self, other)

    def then(self, other: Pattern) -> Pattern:
        return self >> other

    def then_immediately(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import ImmediateSequencePattern
        return ImmediateSequencePattern(self, other)

    def or_(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import DisjunctionPattern
        return DisjunctionPattern(self, other)

    def union(self, other: Pattern) -> Pattern:
        from pyrapide.patterns.composite import UnionPattern
        return UnionPattern(self, other)

    def where(self, predicate: Any) -> Pattern:
        return GuardedPattern(self, predicate)

    def timed(
        self,
        clock: Any,
        max_duration: float | None = None,
        after: float | None = None,
        before: float | None = None,
    ) -> Pattern:
        from pyrapide.patterns.timing import TimedPattern
        return TimedPattern(self, clock, max_duration=max_duration, after_time=after, before_time=before)

    def repeat(self) -> Pattern:
        from pyrapide.patterns.composite import IterationPattern
        return IterationPattern(self)


class BasicPattern(Pattern):
    """Matches individual events by name, source, and payload fields."""

    def __init__(
        self,
        event_name: str,
        field_matchers: dict[str, Any] | None = None,
        source_matcher: str | Placeholder | None = None,
    ) -> None:
        self.event_name = event_name
        self.field_matchers = field_matchers or {}
        self.source_matcher = source_matcher

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        results: list[PatternMatch] = []
        for event in poset.events:
            match_result = self._try_match(event, bindings)
            if match_result is not None:
                results.append(match_result)
        return results

    def _try_match(self, event: Event, bindings: dict[str, Any] | None = None) -> PatternMatch | None:
        # Check event name
        if self.event_name != "*" and event.name != self.event_name:
            return None

        new_bindings: dict[str, Any] = dict(bindings) if bindings else {}

        # Check source
        if self.source_matcher is not None:
            if isinstance(self.source_matcher, Placeholder):
                new_bindings[self.source_matcher.name] = event.source
            elif event.source != self.source_matcher:
                return None

        # Check payload fields
        for field_name, matcher in self.field_matchers.items():
            if field_name not in event.payload:
                return None
            value = event.payload[field_name]
            if isinstance(matcher, Placeholder):
                new_bindings[matcher.name] = value
            elif value != matcher:
                return None

        return PatternMatch(events=(event,), bindings=new_bindings)


class GuardedPattern(Pattern):
    """Pattern with a predicate guard: filters inner match results through predicate."""

    def __init__(self, pattern: Pattern, predicate: Any) -> None:
        self.pattern = pattern
        self.predicate = predicate

    def match_in(self, poset: Poset, bindings: dict[str, Any] | None = None) -> list[PatternMatch]:
        return [m for m in self.pattern.match_in(poset, bindings) if self.predicate(m)]
