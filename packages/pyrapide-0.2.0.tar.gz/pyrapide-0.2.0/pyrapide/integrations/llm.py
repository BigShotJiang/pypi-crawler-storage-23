from __future__ import annotations

import asyncio
import uuid
from typing import Any, AsyncIterator

from pyrapide.core.event import Event


# ---------------------------------------------------------------------------
# LLM Event Type Constants
# ---------------------------------------------------------------------------

class LLMEventTypes:
    """LLM API event type constants."""

    REQUEST = "llm.request"
    RESPONSE = "llm.response"
    STREAM_CHUNK = "llm.stream_chunk"
    ERROR = "llm.error"


# ---------------------------------------------------------------------------
# Mock LLM Client (for testing)
# ---------------------------------------------------------------------------

class MockLLMClient:
    """Simulates an LLM API for testing.

    Scripts request/response and streaming sequences.
    """

    def __init__(self, model_name: str = "mock-model") -> None:
        self.model_name = model_name
        self._queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()

    async def request(self, prompt: str, model: str | None = None,
                      stream: bool = False, num_chunks: int = 3) -> dict[str, Any]:
        """Simulate an LLM request. Enqueues request and response events."""
        correlation_id = str(uuid.uuid4())
        used_model = model or self.model_name

        await self._queue.put({
            "type": "request",
            "prompt": prompt,
            "model": used_model,
            "correlation_id": correlation_id,
            "stream": stream,
        })

        if stream:
            # Emit stream chunks
            for i in range(num_chunks):
                await self._queue.put({
                    "type": "stream_chunk",
                    "chunk": f"chunk_{i}",
                    "index": i,
                    "model": used_model,
                    "correlation_id": correlation_id,
                })
            # Final response after all chunks
            result = {"text": f"streamed_response_for_{prompt}", "model": used_model}
        else:
            result = {"text": f"response_for_{prompt}", "model": used_model}

        await self._queue.put({
            "type": "response",
            "result": result,
            "model": used_model,
            "correlation_id": correlation_id,
        })
        return result

    async def request_error(self, prompt: str, error: str = "API error") -> None:
        """Simulate a request that results in an error."""
        correlation_id = str(uuid.uuid4())
        await self._queue.put({
            "type": "request",
            "prompt": prompt,
            "model": self.model_name,
            "correlation_id": correlation_id,
        })
        await self._queue.put({
            "type": "error",
            "error": error,
            "model": self.model_name,
            "correlation_id": correlation_id,
        })

    async def close(self) -> None:
        """Signal no more events."""
        await self._queue.put(None)

    async def raw_events(self) -> AsyncIterator[dict[str, Any]]:
        """Yield raw event dicts until closed."""
        while True:
            item = await self._queue.get()
            if item is None:
                break
            yield item


# ---------------------------------------------------------------------------
# LLM Event Adapter
# ---------------------------------------------------------------------------

class LLMEventAdapter:
    """Translates LLM API events into PyRapide Events with causal linking.

    Implements the EventSource protocol for use with StreamProcessor.
    """

    def __init__(self, source_name: str, client: MockLLMClient | None = None) -> None:
        self._source_name = source_name
        self._client = client
        self._pending_requests: dict[str, Event] = {}  # correlation_id -> request Event

    @property
    def name(self) -> str:
        return self._source_name

    def _make_event(self, event_type: str, payload: dict[str, Any],
                    metadata: dict[str, Any] | None = None) -> Event:
        """Create a PyRapide Event from LLM data."""
        return Event(
            name=event_type,
            payload=payload,
            source=self._source_name,
            metadata=metadata or {},
        )

    async def events(self) -> AsyncIterator[Event]:
        """Yield PyRapide events translated from LLM API events.

        Automatically establishes causal links between request and
        response/stream_chunk/error events via correlation_id.
        """
        if self._client is None:
            return

        async for raw in self._client.raw_events():
            event_type = raw.get("type", "")
            correlation_id = raw.get("correlation_id", "")

            if event_type == "request":
                evt = self._make_event(
                    LLMEventTypes.REQUEST,
                    {
                        "prompt": raw.get("prompt", ""),
                        "model": raw.get("model", ""),
                        "stream": raw.get("stream", False),
                    },
                    metadata={"correlation_id": correlation_id},
                )
                if correlation_id:
                    self._pending_requests[correlation_id] = evt
                yield evt

            elif event_type == "response":
                caused_by_id = ""
                if correlation_id and correlation_id in self._pending_requests:
                    caused_by_id = self._pending_requests[correlation_id].id
                    del self._pending_requests[correlation_id]

                evt = self._make_event(
                    LLMEventTypes.RESPONSE,
                    {
                        "result": raw.get("result", {}),
                        "model": raw.get("model", ""),
                    },
                    metadata={
                        "correlation_id": correlation_id,
                        "caused_by_id": caused_by_id,
                    },
                )
                yield evt

            elif event_type == "stream_chunk":
                caused_by_id = ""
                if correlation_id and correlation_id in self._pending_requests:
                    caused_by_id = self._pending_requests[correlation_id].id

                evt = self._make_event(
                    LLMEventTypes.STREAM_CHUNK,
                    {
                        "chunk": raw.get("chunk", ""),
                        "index": raw.get("index", 0),
                        "model": raw.get("model", ""),
                    },
                    metadata={
                        "correlation_id": correlation_id,
                        "caused_by_id": caused_by_id,
                    },
                )
                yield evt

            elif event_type == "error":
                caused_by_id = ""
                if correlation_id and correlation_id in self._pending_requests:
                    caused_by_id = self._pending_requests[correlation_id].id
                    del self._pending_requests[correlation_id]

                evt = self._make_event(
                    LLMEventTypes.ERROR,
                    {
                        "error": raw.get("error", ""),
                        "model": raw.get("model", ""),
                    },
                    metadata={
                        "correlation_id": correlation_id,
                        "caused_by_id": caused_by_id,
                    },
                )
                yield evt
