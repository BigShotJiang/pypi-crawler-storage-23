from __future__ import annotations

import asyncio
import uuid
from typing import Any, AsyncIterator

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern


# ---------------------------------------------------------------------------
# MCP Event Type Constants
# ---------------------------------------------------------------------------

class MCPEventTypes:
    """MCP protocol event type constants."""

    TOOL_CALL = "mcp.tool_call"
    TOOL_RESULT = "mcp.tool_result"
    RESOURCE_READ = "mcp.resource_read"
    ERROR = "mcp.error"
    CONNECT = "mcp.connect"
    DISCONNECT = "mcp.disconnect"


# ---------------------------------------------------------------------------
# MCP Pattern Library
# ---------------------------------------------------------------------------

class MCPPatterns:
    """Pre-built pattern library for common MCP event patterns."""

    @staticmethod
    def tool_call(tool_name: str | None = None) -> Pattern:
        """Match any tool call, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(MCPEventTypes.TOOL_CALL, tool=tool_name)
        return Pattern.match(MCPEventTypes.TOOL_CALL)

    @staticmethod
    def tool_result(tool_name: str | None = None) -> Pattern:
        """Match any tool result, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(MCPEventTypes.TOOL_RESULT, tool=tool_name)
        return Pattern.match(MCPEventTypes.TOOL_RESULT)

    @staticmethod
    def tool_roundtrip(tool_name: str | None = None) -> Pattern:
        """Match a tool_call >> tool_result sequence."""
        return MCPPatterns.tool_call(tool_name) >> MCPPatterns.tool_result(tool_name)

    @staticmethod
    def tool_error(tool_name: str | None = None) -> Pattern:
        """Match tool errors, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(MCPEventTypes.ERROR, tool=tool_name)
        return Pattern.match(MCPEventTypes.ERROR)

    @staticmethod
    def server_lifecycle() -> Pattern:
        """Match a connect >> disconnect sequence."""
        return Pattern.match(MCPEventTypes.CONNECT) >> Pattern.match(MCPEventTypes.DISCONNECT)


# ---------------------------------------------------------------------------
# Mock MCP Client (for testing)
# ---------------------------------------------------------------------------

class MockMCPClient:
    """Simulates an MCP server for testing.

    Records tool calls and allows scripting responses.
    """

    def __init__(self, server_name: str) -> None:
        self.server_name = server_name
        self._queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
        self._connected = False

    async def connect(self, capabilities: dict[str, Any] | None = None) -> dict[str, Any]:
        """Simulate connecting to the MCP server."""
        self._connected = True
        caps = capabilities or {"tools": True, "resources": True}
        await self._queue.put({
            "type": "connect",
            "capabilities": caps,
        })
        return caps

    async def call_tool(self, tool_name: str, args: dict[str, Any] | None = None) -> Any:
        """Simulate calling a tool. Enqueues call and result events."""
        correlation_id = str(uuid.uuid4())
        await self._queue.put({
            "type": "tool_call",
            "tool": tool_name,
            "args": args or {},
            "correlation_id": correlation_id,
        })
        # Simulate a successful result
        result = {"status": "ok", "data": f"result_of_{tool_name}"}
        await self._queue.put({
            "type": "tool_result",
            "tool": tool_name,
            "result": result,
            "correlation_id": correlation_id,
        })
        return result

    async def call_tool_error(self, tool_name: str, args: dict[str, Any] | None = None,
                              error: str = "tool failed") -> None:
        """Simulate a tool call that results in an error."""
        correlation_id = str(uuid.uuid4())
        await self._queue.put({
            "type": "tool_call",
            "tool": tool_name,
            "args": args or {},
            "correlation_id": correlation_id,
        })
        await self._queue.put({
            "type": "error",
            "tool": tool_name,
            "error": error,
            "correlation_id": correlation_id,
        })

    async def read_resource(self, uri: str) -> dict[str, Any]:
        """Simulate reading a resource."""
        await self._queue.put({
            "type": "resource_read",
            "uri": uri,
        })
        return {"uri": uri, "content": f"content_of_{uri}"}

    async def disconnect(self, reason: str = "normal") -> None:
        """Simulate disconnecting from the MCP server."""
        self._connected = False
        await self._queue.put({
            "type": "disconnect",
            "reason": reason,
        })

    async def close(self) -> None:
        """Signal no more events."""
        await self._queue.put(None)

    async def raw_events(self) -> AsyncIterator[dict[str, Any]]:
        """Yield raw event dicts until closed."""
        while True:
            item = await self._queue.get()
            if item is None:
                break
            yield item


# ---------------------------------------------------------------------------
# MCP Event Adapter
# ---------------------------------------------------------------------------

class MCPEventAdapter:
    """Translates MCP protocol events into PyRapide Events with causal linking.

    Implements the EventSource protocol for use with StreamProcessor.
    """

    def __init__(self, server_name: str, client: MockMCPClient | None = None) -> None:
        self._server_name = server_name
        self._client = client
        self._pending_calls: dict[str, Event] = {}  # correlation_id -> tool_call Event

    @property
    def name(self) -> str:
        return self._server_name

    def _make_event(self, event_type: str, payload: dict[str, Any],
                    metadata: dict[str, Any] | None = None) -> Event:
        """Create a PyRapide Event from MCP data."""
        return Event(
            name=event_type,
            payload=payload,
            source=self._server_name,
            metadata=metadata or {},
        )

    async def events(self) -> AsyncIterator[Event]:
        """Yield PyRapide events translated from MCP protocol events.

        Automatically establishes causal links between tool_call and
        tool_result/error events via correlation_id.
        """
        if self._client is None:
            return

        async for raw in self._client.raw_events():
            event_type = raw.get("type", "")
            correlation_id = raw.get("correlation_id", "")

            if event_type == "connect":
                yield self._make_event(
                    MCPEventTypes.CONNECT,
                    {"server": self._server_name, "capabilities": raw.get("capabilities", {})},
                )

            elif event_type == "disconnect":
                yield self._make_event(
                    MCPEventTypes.DISCONNECT,
                    {"server": self._server_name, "reason": raw.get("reason", "")},
                )

            elif event_type == "tool_call":
                evt = self._make_event(
                    MCPEventTypes.TOOL_CALL,
                    {"tool": raw["tool"], "args": raw.get("args", {}), "server": self._server_name},
                    metadata={"correlation_id": correlation_id},
                )
                if correlation_id:
                    self._pending_calls[correlation_id] = evt
                yield evt

            elif event_type == "tool_result":
                evt = self._make_event(
                    MCPEventTypes.TOOL_RESULT,
                    {"tool": raw["tool"], "result": raw.get("result", {}), "server": self._server_name},
                    metadata={
                        "correlation_id": correlation_id,
                        "caused_by_id": self._pending_calls.get(correlation_id, Event(name="")).id
                        if correlation_id and correlation_id in self._pending_calls else "",
                    },
                )
                if correlation_id in self._pending_calls:
                    del self._pending_calls[correlation_id]
                yield evt

            elif event_type == "error":
                evt = self._make_event(
                    MCPEventTypes.ERROR,
                    {"tool": raw.get("tool", ""), "error": raw.get("error", ""), "server": self._server_name},
                    metadata={
                        "correlation_id": correlation_id,
                        "caused_by_id": self._pending_calls.get(correlation_id, Event(name="")).id
                        if correlation_id and correlation_id in self._pending_calls else "",
                    },
                )
                if correlation_id in self._pending_calls:
                    del self._pending_calls[correlation_id]
                yield evt

            elif event_type == "resource_read":
                yield self._make_event(
                    MCPEventTypes.RESOURCE_READ,
                    {"uri": raw.get("uri", ""), "server": self._server_name},
                )
