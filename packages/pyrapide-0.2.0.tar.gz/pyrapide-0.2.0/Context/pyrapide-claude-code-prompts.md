# PyRapide — Claude Code Prompt Guide

## How To Use This Document

This file contains **28 numbered prompts** you paste into Claude Code **in order**. Each prompt is self-contained — it tells Claude Code what to build, what tests to write, and how to validate. Do not skip prompts. Each one depends on the output of the previous ones.

**Before you start**: Place the file `pyrapide-development-plan.md` in your project root so Claude Code can reference it.

**Workflow per prompt**:
1. Copy the entire prompt block (everything inside the fenced section).
2. Paste it into Claude Code.
3. Let it run to completion.
4. Verify the stated validation criteria pass before moving to the next prompt.
5. If tests fail, tell Claude Code: *"Tests X, Y, Z are failing. Fix the implementation until all tests pass."*

---

## PROMPT 0 — Project Scaffolding

```
Create the PyRapide project scaffolding. This is a Python library for causal event-driven architecture modeling based on the RAPIDE 1.0 language specification.

Create the following directory structure with empty __init__.py files:

pyrapide/
├── __init__.py
├── core/
│   └── __init__.py
├── types/
│   └── __init__.py
├── patterns/
│   └── __init__.py
├── architecture/
│   └── __init__.py
├── constraints/
│   └── __init__.py
├── executable/
│   └── __init__.py
├── runtime/
│   └── __init__.py
├── integrations/
│   └── __init__.py
├── analysis/
│   └── __init__.py
└── utils/
    └── __init__.py

tests/
├── __init__.py
├── conftest.py
├── core/
│   └── __init__.py
├── types/
│   └── __init__.py
├── patterns/
│   └── __init__.py
├── architecture/
│   └── __init__.py
├── constraints/
│   └── __init__.py
├── executable/
│   └── __init__.py
├── runtime/
│   └── __init__.py
├── integrations/
│   └── __init__.py
├── analysis/
│   └── __init__.py
└── scenarios/
    └── __init__.py

Create a pyproject.toml with:
- name: "pyrapide"
- version: "0.1.0"
- requires-python: ">=3.11"
- dependencies: networkx>=3.0, pydantic>=2.0, typing-extensions>=4.0
- dev dependencies: pytest>=8.0, pytest-asyncio>=0.23, pytest-benchmark>=4.0, mypy>=1.8, ruff>=0.3, coverage>=7.0
- optional deps group "viz": graphviz>=0.20
- optional deps group "prediction": numpy>=1.24, scikit-learn>=1.3
- optional deps group "mcp": mcp>=1.0
- build system: hatchling

Create a pytest.ini or pyproject.toml section configuring pytest with asyncio_mode = "auto".

In the top-level pyrapide/__init__.py, add a comment: # PyRapide: Causal Event-Driven Architecture Modeling for Python

In tests/conftest.py, add a comment placeholder: # Shared test fixtures will be added as modules are built

Install dev dependencies and verify pytest runs with 0 tests collected (no errors).

VALIDATION: Run `pytest --co` and confirm it exits cleanly with "no tests ran" or 0 collected. Run `python -c "import pyrapide"` and confirm no import errors.
```

---

## PHASE 1: CORE COMPUTATION MODEL

---

## PROMPT 1 — Event Primitives

```
Implement PyRapide Phase 1 Step 1: Event Primitives.

Create pyrapide/core/event.py implementing an Event class with these requirements:

1. Event is a frozen/immutable dataclass (or Pydantic model).
2. Fields:
   - id: str — auto-generated UUID4 string, globally unique
   - name: str — the event type name (e.g., "Send", "Receive", "Error")
   - payload: dict[str, Any] — named values carried by the event (default empty dict)
   - source: str — identifier of the component that generated this event (default "")
   - timestamp: float — auto-generated time.time() at creation
   - metadata: dict[str, Any] — extensible metadata bag (default empty dict)
3. Immutability: After creation, no field can be changed. Attempting to set an attribute raises an error.
4. Identity semantics: Two Events are equal (==) ONLY if they have the same id. Two events with identical name/payload/source but created separately are NOT equal.
5. Hashable: Events can be used as dict keys and set members. Hash is based on id.
6. Serialization: Implement to_dict() -> dict and a classmethod from_dict(d) -> Event that roundtrips perfectly (from_dict(e.to_dict()) == e with same id).
7. String representation: __repr__ returns something readable like Event(id='abc123...', name='Send', source='client_1')

Also create pyrapide/utils/ids.py with a generate_event_id() function that returns a UUID4 string.

Create pyrapide/core/__init__.py exporting Event.
Update pyrapide/__init__.py to export Event from pyrapide.core.

WRITE TESTS FIRST in tests/core/test_event.py:
- test_event_creation: Create an event with name, payload, source; assert all fields are set.
- test_event_auto_id: Create two events; assert their ids differ.
- test_event_auto_timestamp: Create event; assert timestamp is a positive float close to now.
- test_event_immutability: Create event; assert setting evt.name = "X" raises an error.
- test_event_identity_equality: Create two events with same name/payload; assert e1 != e2.
- test_event_self_equality: assert e1 == e1.
- test_event_hashable: Put two events in a set; assert len is 2. Use as dict keys.
- test_event_serialization_roundtrip: Create event; d = e.to_dict(); e2 = Event.from_dict(d); assert e == e2 and e.id == e2.id and e.payload == e2.payload.
- test_event_payload_access: Create event with payload {"x": 1, "y": "hello"}; assert payload values accessible.
- test_event_default_payload: Create event with no payload arg; assert payload is empty dict.
- test_event_default_source: Create event with no source arg; assert source is "".
- test_event_repr: Assert repr contains the event name and a portion of the id.

Run tests. ALL must pass.

VALIDATION: Run `pytest tests/core/test_event.py -v` — all 12 tests pass. Run `python -c "from pyrapide import Event; e = Event(name='Test'); print(e)"` — prints cleanly.
```

---

## PROMPT 2 — Poset (Partially Ordered Event Set)

```
Implement PyRapide Phase 1 Step 2: Poset — the central data structure of the entire library.

Create pyrapide/core/poset.py implementing a Poset class. A Poset stores a set of Events with a causal ordering relation (a directed acyclic graph). Use networkx.DiGraph internally for the DAG.

Requirements:

1. add(event, caused_by=None): Add an event to the poset. caused_by is an optional list of Event objects already in the poset that causally precede this event. If caused_by contains an event not in the poset, raise ValueError. If adding this causal edge would create a cycle, raise CausalCycleError (define this custom exception in pyrapide/core/exceptions.py).

2. events property: Returns a frozenset of all events in the poset.

3. __len__(): Returns the number of events.

4. __contains__(event): Returns True if the event is in the poset.

5. causes(event) -> frozenset[Event]: Returns the direct causes (parents) of an event.

6. effects(event) -> frozenset[Event]: Returns the direct effects (children) of an event.

7. ancestors(event) -> frozenset[Event]: Returns ALL transitive ancestors (all events that causally precede this event, directly or indirectly). Does NOT include the event itself.

8. descendants(event) -> frozenset[Event]: Returns ALL transitive descendants.

9. is_ancestor(a, b) -> bool: Returns True if a causally precedes b (directly or transitively).

10. are_independent(a, b) -> bool: Returns True if neither a is ancestor of b nor b is ancestor of a (they are causally unrelated).

11. root_events() -> frozenset[Event]: Events with no causes.

12. leaf_events() -> frozenset[Event]: Events with no effects.

13. causal_chain(a, b) -> list[Event] | None: Returns a list of events forming a causal path from a to b, or None if no path exists. If multiple paths exist, return the shortest.

14. filter_by_name(name) -> Poset: Returns a new Poset containing only events with the given name, preserving causal edges between them (transitive reduction through removed events is NOT needed — only keep direct edges where both endpoints survive the filter).

15. filter_by_source(source) -> Poset: Same but filtering by source.

16. to_dict() -> dict and from_dict(d) -> Poset: Serialization that preserves events and causal structure.

17. common_ancestors(a, b) -> frozenset[Event]: Events that are ancestors of both a and b.

Create pyrapide/core/exceptions.py with CausalCycleError(Exception).

Update pyrapide/core/__init__.py to export Poset, CausalCycleError.
Update pyrapide/__init__.py to export Poset, CausalCycleError.

WRITE TESTS FIRST in tests/core/test_poset.py:
- test_add_single_event: Add one event, assert it's in poset, len is 1.
- test_add_with_single_cause: Add e1, then e2 caused_by=[e1]. Assert causes(e2) == {e1}, effects(e1) == {e2}.
- test_add_with_multiple_causes: Add e1, e2, then e3 caused_by=[e1, e2]. Assert causes(e3) == {e1, e2}.
- test_add_caused_by_unknown_raises: Add e2 caused_by=[e1] where e1 is not in poset. Assert ValueError.
- test_cycle_detection: Add e1, e2 caused_by=[e1], then try adding e1 caused_by=[e2] or creating a cycle via e3. Assert CausalCycleError.
- test_ancestors_direct: e1 -> e2. ancestors(e2) == {e1}.
- test_ancestors_transitive: e1 -> e2 -> e3. ancestors(e3) == {e1, e2}.
- test_ancestors_diamond: e1 -> e2, e1 -> e3, e2 -> e4, e3 -> e4. ancestors(e4) == {e1, e2, e3}.
- test_descendants: e1 -> e2 -> e3. descendants(e1) == {e2, e3}.
- test_is_ancestor: e1 -> e2 -> e3. is_ancestor(e1, e3) is True, is_ancestor(e3, e1) is False.
- test_are_independent: e1 -> e2, e1 -> e3 (e2 and e3 are siblings). are_independent(e2, e3) is True. are_independent(e1, e2) is False.
- test_root_events: e1 -> e2, e3 -> e4, e2 -> e5, e4 -> e5. root_events() == {e1, e3}.
- test_leaf_events: Same poset. leaf_events() == {e5}.
- test_causal_chain_exists: e1 -> e2 -> e3. causal_chain(e1, e3) returns [e1, e2, e3].
- test_causal_chain_none: e1, e2 independent. causal_chain(e1, e2) returns None.
- test_common_ancestors: e1 -> e2, e1 -> e3. common_ancestors(e2, e3) == {e1}.
- test_filter_by_name: Add events with names "A", "A", "B". filter_by_name("A") contains 2 events.
- test_filter_by_source: Similar test with source.
- test_serialization_roundtrip: Build a poset with 5 events and edges. Serialize, deserialize, assert same structure.
- test_empty_poset: len is 0, root_events is empty, leaf_events is empty.
- test_large_poset_performance: Add 1000 events in a chain. Assert ancestors of last event has 999 members. This should complete in under 5 seconds.

Also add shared fixtures to tests/conftest.py:
- A fixture `sample_events` that creates 5 named events (e1-e5).
- A fixture `linear_poset` that creates a 3-event chain: e1 -> e2 -> e3.
- A fixture `diamond_poset` that creates: e1 -> e2, e1 -> e3, e2 -> e4, e3 -> e4.

Run ALL tests. All must pass.

VALIDATION: Run `pytest tests/core/ -v` — all Event tests and all Poset tests pass. Confirm the 1000-event performance test completes in under 5 seconds.
```
---

## PROMPT 3 — Clock Hierarchy

```
Implement PyRapide Phase 1 Step 3: Clock hierarchy.

Create pyrapide/core/clock.py implementing the RAPIDE clock system. Clocks provide temporal ordering for events.

Requirements:

1. Clock (base class):
   - name: str — identifier for this clock
   - read() -> float — returns current time value
   - stamp(event: Event) -> TimestampedEvent — associates the current clock time with an event (returns a lightweight wrapper or stores in a dict). Don't mutate the event; use an external mapping.
   - start_time(event) -> float | None — returns the timestamp when this event started on this clock
   - finish_time(event) -> float | None — returns the timestamp when this event finished on this clock

2. SynchronousClock(Clock):
   - All observers of this clock agree on the current time at any point.
   - Internally tracks a monotonically increasing time value.
   - tick(amount: float = 1.0) — advances the clock.

3. RegularClock(SynchronousClock):
   - period: float — tick interval
   - accuracy: float — bounded accuracy (default 1.0, meaning perfect)
   - auto_tick() — advances by one period

4. SlavedClock(Clock):
   - parent: Clock — the parent clock this is derived from
   - divisor: int — this clock ticks once every N ticks of the parent
   - Reads time as parent.read() / divisor (or tracks its own derived counter)

5. ClockManager:
   - Manages multiple clocks for a computation.
   - register(clock) — adds a clock
   - stamp_event(event, clock_name=None) — stamps an event with one or all clocks
   - get_temporal_order(clock_name) -> list[Event] — returns events ordered by timestamp on a given clock

Create tests/core/test_clock.py:
- test_synchronous_clock_creation: Create, read initial time (0).
- test_synchronous_clock_tick: Tick by 1, read is 1. Tick by 2.5, read is 3.5.
- test_regular_clock_period: Create with period=0.1, auto_tick 10 times, read is close to 1.0.
- test_slaved_clock: Create parent, slave with divisor=5. Parent ticks 10 times, slave read reflects divided value.
- test_clock_stamp_event: Create clock, stamp an event, retrieve the timestamp.
- test_clock_temporal_ordering: Stamp e1, tick, stamp e2, tick, stamp e3. Temporal order is [e1, e2, e3].
- test_multi_clock_stamping: Two clocks stamp same events at different rates. Each returns correct order.
- test_clock_manager: Register two clocks, stamp events through manager, query ordering per clock.

Update pyrapide/core/__init__.py to export Clock, SynchronousClock, RegularClock, SlavedClock, ClockManager.

Run ALL tests (core/test_event.py, core/test_poset.py, core/test_clock.py).

VALIDATION: `pytest tests/core/ -v` — all tests pass. No regressions in event or poset tests.
```

---

## PROMPT 4 — Computation

```
Implement PyRapide Phase 1 Step 4: Computation — the query-rich wrapper around a Poset.

Create pyrapide/core/computation.py.

A Computation wraps a Poset and a ClockManager, providing a higher-level query API.

Requirements:

1. Computation class:
   - Internal poset: Poset
   - Internal clock_manager: ClockManager (optional, auto-created if not provided)
   - record(event, caused_by=None, clock=None): Adds event to internal poset and stamps with clock.
   - events property: delegates to poset.events
   - __len__(): delegates to poset
   - root_events(), leaf_events(): delegate to poset
   - ancestors(e), descendants(e), is_ancestor(a,b), are_independent(a,b): delegate to poset

2. Query methods:
   - causal_chain(a, b) -> list[Event] | None: delegate to poset
   - events_by_name(name) -> list[Event]: all events with given name, ordered by timestamp if a clock is available
   - events_by_source(source) -> list[Event]: same but by source
   - events_since(timestamp, clock_name=None) -> list[Event]: events stamped after the given time
   - events_between(start, end, clock_name=None) -> list[Event]: events in time range
   - causal_depth() -> int: length of the longest causal chain in the computation

3. Merge:
   - merge(other: Computation) -> Computation: Creates a new computation combining events from both. Events that exist in both (by id) are not duplicated. Causal edges from both are preserved. Raises CausalCycleError if merging would introduce a cycle.

4. Serialization:
   - to_dict() / from_dict(): Full roundtrip including poset and clock timestamps.

5. Iteration:
   - __iter__: iterates over events in insertion order or topological order
   - topological_order() -> list[Event]: events in causal topological order

Create tests/core/test_computation.py:
- test_record_and_query: Record 3 events with causal links, query by name.
- test_causal_chain: Record e1 -> e2 -> e3, extract chain.
- test_root_leaf: Record diamond, check roots and leaves.
- test_events_by_name: Record events with mixed names, filter.
- test_events_by_source: Record events with mixed sources, filter.
- test_events_since: Record events, query those after a timestamp.
- test_events_between: Record events, query a time range.
- test_causal_depth: Linear chain of 5 events, depth is 4 (edges).
- test_merge_disjoint: Two computations with no shared events, merge preserves all.
- test_merge_overlapping: Two computations sharing one event, merge deduplicates.
- test_topological_order: Diamond poset returns valid topological sort.
- test_serialization_roundtrip: Full computation serialize/deserialize.

Update pyrapide/core/__init__.py to export Computation.
Update pyrapide/__init__.py to export Computation.

Run ALL tests in tests/core/.

VALIDATION: `pytest tests/core/ -v` — ALL tests pass across event, poset, clock, and computation modules. Run `python -c "from pyrapide import Event, Poset, Computation; print('Phase 1 complete')"`.
```

---

## PHASE 2: TYPE SYSTEM

---

## PROMPT 5 — Interface Decorator and Actions

```
Implement PyRapide Phase 2 Step 1: The @interface decorator, @action, @provides, and @requires.

Create pyrapide/types/interface.py:

The @interface decorator transforms a Python class into a RAPIDE interface type. It must:
1. Scan the class for methods marked with @action, @provides, @requires.
2. Store metadata on the class: _pyrapide_actions (set of action names), _pyrapide_provides (set of provided operation names), _pyrapide_requires (set of required operation names), _pyrapide_event_alphabet (set of event names this interface can generate).
3. The event alphabet is derived from action names: each @action method named "foo" creates event names like "InterfaceName.foo".
4. The class should remain a normal Python class (users can still instantiate and use it).
5. Add a class method get_interface_info() that returns a dict with keys: "actions", "provides", "requires", "event_alphabet".

Create pyrapide/types/actions.py:

1. @action decorator: Marks a method as event-generating. When called within a running computation context, it should generate an Event. For now, just mark the method with _pyrapide_is_action = True and store the action name. The actual event generation integration with the runtime will come in Phase 6.

2. @provides decorator: Marks a method as part of the externally visible interface. Sets _pyrapide_is_provided = True.

3. @requires decorator: Marks a method as required but not implemented (like abstract). Sets _pyrapide_is_required = True. The method body should be a stub (pass or ...).

4. @behavior decorator: Marks a method as a reactive behavior rule. Sets _pyrapide_is_behavior = True. Implementation of actual reactive execution comes in Phase 6.

Create pyrapide/types/__init__.py exporting interface, action, provides, requires, behavior.
Update pyrapide/__init__.py to export these.

Create tests/types/test_interface.py:
- test_interface_decorator_basic: Decorate a class with @interface, assert it has _pyrapide_actions attribute.
- test_action_registration: Define interface with two @action methods. Assert both appear in get_interface_info()["actions"].
- test_provides_registration: Mark methods with @provides. Assert they appear in get_interface_info()["provides"].
- test_requires_registration: Mark methods with @requires. Assert they appear in get_interface_info()["requires"].
- test_event_alphabet: Interface "Foo" with actions "send", "receive". Alphabet should include "Foo.send", "Foo.receive".
- test_interface_still_instantiable: Assert you can create an instance of an @interface class and call non-action methods normally.
- test_mixed_decorators: @provides @action on same method. Appears in both provides and actions.
- test_behavior_registration: @behavior method appears in interface info.
- test_no_actions_interface: Interface with no actions. Actions set is empty, alphabet is empty.
- test_interface_inheritance: Create interface B that inherits from interface A. B should inherit A's actions and add its own.

Create tests/types/test_actions.py:
- test_action_decorator_marks_method: Decorated method has _pyrapide_is_action = True.
- test_provides_decorator_marks_method: Decorated method has _pyrapide_is_provided = True.
- test_requires_decorator_marks_method: Decorated method has _pyrapide_is_required = True.
- test_decorator_stacking: @provides and @action together, both flags present.

Run ALL tests (core/ and types/).

VALIDATION: `pytest tests/ -v` — all tests pass. No regressions.
```

---

## PROMPT 6 — Services and Subtyping

```
Implement PyRapide Phase 2 Step 2: Services and Structural Subtyping.

Create pyrapide/types/services.py:

Services group related actions within an interface. Implementation:
1. Detect nested classes within an @interface class that contain @action methods.
2. Register them as services with names like "InterfaceName.ServiceName".
3. Each service's actions are included in the parent interface's event alphabet, namespaced: "InterfaceName.ServiceName.action_name".
4. Add "services" key to get_interface_info() returning a dict of {service_name: {actions, provides, requires}}.

Create pyrapide/types/subtyping.py:

Implement structural subtyping checks for interfaces:
1. is_subtype(candidate, target) -> bool: Returns True if candidate provides at least all the operations (actions + provides) that target provides. Checks by name and parameter signatures (using inspect).
2. conforms_to(module_class, interface_class) -> bool: Returns True if module_class implements all @requires methods of interface_class.

Create pyrapide/types/function_types.py:
1. FunctionSignature class: Captures parameter names, types, and return type for a callable.
2. is_function_subtype(f1_sig, f2_sig) -> bool: f1 is a subtype of f2 if f1 accepts at least the same parameters (contravariance on inputs) and returns a compatible type (covariance on output).

Update exports in types/__init__.py and pyrapide/__init__.py to include is_subtype, conforms_to.

Create tests/types/test_services.py:
- test_service_detection: Interface with nested service class containing @action methods. Services appear in get_interface_info().
- test_service_event_alphabet: Service actions contribute namespaced entries to the parent's event alphabet.
- test_multiple_services: Interface with two services, each with distinct actions.
- test_empty_service: Nested class with no actions is not registered as a service.

Create tests/types/test_subtyping.py:
- test_subtype_match: AdvancedSender (send + send_batch) is subtype of BasicSender (send only).
- test_subtype_mismatch: BasicSender is NOT subtype of AdvancedSender (missing send_batch).
- test_identical_interfaces: Two interfaces with same actions are subtypes of each other.
- test_empty_interface_supertype: Any interface is a subtype of an empty interface.
- test_conforms_to_with_requires: Module class implementing all @requires methods of an interface. conforms_to returns True.
- test_conforms_to_missing_requires: Module class missing a @requires method. conforms_to returns False.
- test_function_subtype_basic: function(int) -> int is subtype of function(int) -> int.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass. No regressions in Phase 1 tests.
```

---

## PHASE 3: EVENT PATTERN LANGUAGE

---

## PROMPT 7 — Basic Patterns and Placeholders

```
Implement PyRapide Phase 3 Step 1: Basic Patterns and the Placeholder system.

Create pyrapide/patterns/base.py:

1. Placeholder class:
   - name: str — the binding variable name
   - placeholder(name: str) -> Placeholder: factory function
   - Placeholders are used in pattern definitions to capture matched values.

2. Pattern (abstract base class):
   - All patterns inherit from this.
   - __rshift__(self, other) -> SequencePattern: operator >> for sequence (P >> Q). Just store the composition for now; SequencePattern is created in the next prompt.
   - __and__(self, other) -> JoinPattern: operator & for join.
   - __or__(self, other) -> IndependencePattern: operator | for independence.
   - Abstract method match_in(poset, bindings=None) -> list[PatternMatch]: to be implemented by subclasses.
   - where(predicate) -> GuardedPattern: wraps this pattern with a guard (implemented next prompt).
   - then(other) -> SequencePattern: alias for >>.
   - or_(other) -> DisjunctionPattern: logical or.
   - union(other) -> UnionPattern.
   - repeat() -> IterationPattern.

3. BasicPattern(Pattern):
   - event_name: str — the event name to match (e.g., "Send", "Server.Request")
   - field_matchers: dict[str, Any] — dict mapping payload field names to expected values or Placeholder objects
   - source_matcher: str | Placeholder | None — optional source filter
   - match_in(poset, bindings=None) -> list[PatternMatch]: Iterate over events in the poset. An event matches if:
     a. Its name matches event_name (or event_name is "*" for wildcard)
     b. For each field in field_matchers: if the value is a Placeholder, bind the event's payload field to the placeholder name. If the value is a concrete value, assert equality.
     c. If source_matcher is set, same logic for source.
   - Return a list of PatternMatch objects, one per matching event.

4. PatternMatch:
   - events: tuple[Event, ...] — the matched events
   - bindings: dict[str, Any] — placeholder name -> bound value
   - Immutable after creation.

5. Pattern.match(event_name, source=None, **field_matchers) -> BasicPattern: Class method / factory for creating basic patterns conveniently.

Create pyrapide/patterns/__init__.py exporting Pattern, BasicPattern, Placeholder, placeholder, PatternMatch.
Update pyrapide/__init__.py to export Pattern, placeholder.

Create tests/patterns/test_basic_pattern.py:
- test_basic_match_by_name: Pattern.match("Send") matches event named "Send", not "Receive".
- test_basic_match_wildcard: Pattern.match("*") matches any event.
- test_basic_match_with_field_value: Pattern.match("Send", message="hello") matches only events with payload["message"] == "hello".
- test_basic_match_with_placeholder: msg = placeholder("msg"); Pattern.match("Send", message=msg) matches any Send event and binds payload["message"] to "msg" in the match bindings.
- test_basic_match_with_source: Pattern.match("Send", source="client_1") matches only events from client_1.
- test_basic_match_source_placeholder: src = placeholder("src"); Pattern.match("Send", source=src) binds the source.
- test_basic_match_multiple_fields: Match on two payload fields simultaneously.
- test_basic_match_no_match: Pattern.match("Send") against a poset with only "Receive" events returns empty list.
- test_basic_match_multiple_matches: Poset with 3 "Send" events. Pattern returns 3 PatternMatch objects.
- test_pattern_match_immutability: PatternMatch fields cannot be changed after creation.
- test_placeholder_equality: Two placeholders with same name are equal.
- test_pattern_match_bindings: Verify bindings dict contains correct values after match.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass including all Phase 1 and Phase 2 tests.
```

---

## PROMPT 8 — Composite Patterns

```
Implement PyRapide Phase 3 Step 2: Composite Patterns.

Create pyrapide/patterns/composite.py with the following pattern types. Each takes two child patterns (left, right) except Iteration which wraps a single pattern.

All composite patterns extend Pattern and implement match_in(poset, bindings=None).

1. SequencePattern(Pattern): (P >> Q)
   - Matches when P matches event(s) and Q matches event(s), AND at least one P-matched event is a causal ancestor of at least one Q-matched event in the poset.
   - Returns PatternMatch with events from both P and Q matches, and merged bindings.
   - match_in: Get all P matches and all Q matches. For each (p_match, q_match) pair, check if any event in p_match.events is an ancestor of any event in q_match.events.

2. ImmediateSequencePattern(Pattern): P.then_immediately(Q)
   - Like SequencePattern but requires P's event is a DIRECT cause of Q's event (no intermediate events of the same type in between).

3. JoinPattern(Pattern): (P & Q)
   - Matches when both P and Q match, AND the matched events share at least one common causal ancestor.
   - match_in: Get P and Q matches. For each pair, check common_ancestors is non-empty.

4. IndependencePattern(Pattern): (P | Q)
   - Matches when both P and Q match, AND no P-matched event is an ancestor or descendant of any Q-matched event (they are causally independent).
   - match_in: Check are_independent between all pairs of matched events.

5. DisjunctionPattern(Pattern): P.or_(Q)
   - Matches when either P or Q matches. Returns matches from both.

6. UnionPattern(Pattern): P.union(Q)
   - Like disjunction but preserves bindings from whichever side matched.

7. IterationPattern(Pattern): P.repeat()
   - Matches all occurrences of P in the poset. Returns a single PatternMatch containing ALL matched events across all individual P matches, with bindings collected into lists.

8. Add .then_immediately(other) method to Pattern base class returning ImmediateSequencePattern.

Update pyrapide/patterns/__init__.py to export all composite pattern classes.

Create tests/patterns/test_composite_patterns.py:
- test_sequence_match: e1(Send) -> e2(Ack). Pattern (Send >> Ack) matches with events (e1, e2).
- test_sequence_no_causal_link: e1(Send), e2(Ack) both in poset but independent. Sequence does NOT match.
- test_sequence_transitive: e1(Send) -> e2(Process) -> e3(Ack). (Send >> Ack) matches via transitive causality.
- test_immediate_sequence: e1 -> e2 directly. Immediate sequence matches. e1 -> e_mid -> e2: immediate sequence does NOT match for e1->e2.
- test_join_common_ancestor: e0 -> e1(A), e0 -> e2(B). Join(A, B) matches because e0 is common ancestor.
- test_join_no_common_ancestor: e1(A), e2(B) both roots. Join does NOT match.
- test_independence_match: e1(A), e2(B) with no causal relation. Independence matches.
- test_independence_no_match: e1(A) -> e2(B). Independence does NOT match.
- test_disjunction: P matches Send OR Receive. Poset has both. Returns matches for both.
- test_disjunction_one_side: Only Send events in poset. Disjunction still matches (from Send side).
- test_union: Similar to disjunction, bindings preserved from matching side.
- test_iteration: 5 "Error" events in poset. repeat() returns single match with all 5 events.
- test_iteration_empty: No "Error" events. repeat() returns empty or match with 0 events.
- test_nested_composition: (Send >> (Process & Log)) — sequence into a join. Build poset where Send causes both Process and Log (which share common ancestor Send). Verify match.
- test_operator_syntax: Verify P >> Q, P & Q, P | Q all create the correct pattern types.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 9 — Guards, Macros, and Timed Patterns

```
Implement PyRapide Phase 3 Step 3: Guarded Patterns, Pattern Macros, and Timed Patterns.

Create pyrapide/patterns/guards.py:
1. GuardedPattern(Pattern):
   - Wraps an inner pattern and a predicate function: predicate(match: PatternMatch) -> bool.
   - match_in: Run inner pattern's match_in, then filter results through the predicate.
   - Created via Pattern.where(predicate).

Create pyrapide/patterns/macros.py:
1. @pattern_macro decorator:
   - Decorates a function that takes parameters and returns a Pattern.
   - The resulting callable is itself a pattern factory.
   - Adds a _pyrapide_is_pattern_macro = True attribute.

2. PatternLibrary class:
   - A registry of named pattern macros.
   - register(name, macro_fn): Registers a macro.
   - get(name, **kwargs) -> Pattern: Instantiates a macro with given args.

Create pyrapide/patterns/timing.py:
1. TimedPattern(Pattern):
   - Wraps a pattern with timing constraints relative to a clock.
   - clock: Clock reference
   - max_duration: Optional float — matched events must occur within this time window.
   - after_time: Optional float — events must occur after this clock time.
   - before_time: Optional float — events must occur before this clock time.
   - match_in: Runs inner pattern match, then filters by timing constraints using the clock's timestamps on the matched events.

2. Add .timed(clock, max_duration=None, after=None, before=None) method to Pattern base class.

Update all __init__.py exports.

Create tests/patterns/test_guards.py:
- test_guard_filters_matches: Pattern.match("Send", message=placeholder("m")).where(lambda m: len(m.bindings["m"]) > 5). Only matches events with message longer than 5 chars.
- test_guard_passes_all: Guard that always returns True. All matches pass through.
- test_guard_rejects_all: Guard that always returns False. No matches.
- test_guard_with_composite: (P >> Q).where(predicate). Guard applied to sequence result.

Create tests/patterns/test_macros.py:
- test_pattern_macro_decorator: Define a @pattern_macro function. Call it, get a Pattern back.
- test_pattern_macro_with_args: Macro takes a service name, returns a request-response pattern.
- test_pattern_library: Register macros, retrieve by name.

Create tests/patterns/test_timing.py:
- test_timed_pattern_max_duration: Events within 5.0 clock ticks match; events 10.0 ticks apart don't.
- test_timed_pattern_after: Only matches events after clock time 100.
- test_timed_pattern_before: Only matches events before clock time 200.
- test_timed_pattern_window: Combines after and before for a time window.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass. Pattern system is complete.
```

---


## PHASE 4: ARCHITECTURE & CONNECTIONS

---

## PROMPT 10 — Architecture Decorator

```
Implement PyRapide Phase 4 Step 1: The @architecture decorator and Architecture class.

Create pyrapide/architecture/architecture.py:

1. @architecture decorator:
   - Transforms a class into a RAPIDE architecture.
   - Scans for type-annotated attributes whose types are @interface-decorated classes. These become components.
   - Looks for a connections(self) method that defines how components communicate.
   - Looks for a constraints(self) method (optional) that defines architecture-level constraints.
   - Stores metadata: _pyrapide_components (dict of name -> interface type), _pyrapide_is_architecture = True.

2. Architecture base/mixin (mixed in by decorator):
   - components property: Returns dict of {name: interface_instance} for all declared components.
   - get_component(name) -> interface instance.
   - computation property: Returns the Computation being built during execution.
   - get_architecture_info() -> dict with "components", "component_types", "is_architecture".
   
3. Component instantiation:
   - When an architecture is instantiated, each declared component (type-annotated interface) gets an instance created automatically (using default constructor).
   - Components are accessible as attributes: arch.client, arch.server, etc.

Update pyrapide/architecture/__init__.py to export architecture.
Update pyrapide/__init__.py to export architecture.

Create tests/architecture/test_architecture.py:
- test_architecture_decorator: Decorate a class with @architecture. Assert _pyrapide_is_architecture is True.
- test_component_detection: Architecture with two interface-typed attributes. get_architecture_info()["components"] has both.
- test_component_instantiation: Instantiate architecture. Components are real instances of their interface types.
- test_component_access: Access arch.client, arch.server as attributes.
- test_architecture_info: get_architecture_info returns correct component types.
- test_architecture_with_connections_method: Define a connections() method. Assert it's callable (actual connection semantics in next prompt).
- test_empty_architecture: Architecture with no components. Components dict is empty.
- test_architecture_with_non_interface_attributes: Regular typed attributes (int, str) are NOT treated as components.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 11 — Connections

```
Implement PyRapide Phase 4 Step 2: Connection system — basic, pipe, and agent connections.

Create pyrapide/architecture/connections.py:

1. Connection (base class):
   - source_pattern: Pattern — triggers the connection
   - handler: Callable — what to do when the pattern matches (typically generates events on target)
   - connection_type: str — "basic", "pipe", or "agent"
   - active: bool — whether the connection is currently active

2. BasicConnection(Connection):
   - When source_pattern matches, handler is called synchronously in the same causal context. Generated events are directly caused by the triggering events.

3. PipeConnection(Connection):
   - Maintains an internal asyncio.Queue.
   - When source_pattern matches, the match is enqueued.
   - A background consumer processes the queue FIFO, calling handler for each.
   - Generated events depend on the triggering event AND on completion of previously queued items.

4. AgentConnection(Connection):
   - When source_pattern matches, handler is dispatched as an independent asyncio.Task.
   - Generated events are causally dependent on the trigger but temporally independent of other agent dispatches.

5. ConnectionManager:
   - Manages all connections for an architecture.
   - add_connection(connection): Registers a connection.
   - process_event(event, computation): For each connection whose source_pattern matches this event, execute according to connection type.
   - connections property: list of all connections.

6. Top-level factory functions (these are what users call inside an architecture's connections() method):
   - connect(source_pattern, handler) -> BasicConnection
   - pipe(source_pattern, handler) -> PipeConnection  
   - agent(source_pattern, handler) -> AgentConnection

Update exports.

Create tests/architecture/test_connections.py:
- test_basic_connection_creation: Create with pattern and handler. Assert type is "basic".
- test_pipe_connection_creation: Assert type is "pipe".
- test_agent_connection_creation: Assert type is "agent".
- test_connection_manager_add: Add 3 connections to manager. Assert len is 3.
- test_basic_connection_fires: Create a basic connection with a pattern matching "Request". Add a "Request" event to a computation. Call process_event. Assert handler was called with the match.
- test_basic_connection_no_match: Add a "Ping" event. Connection with "Request" pattern. Handler NOT called.
- test_pipe_connection_ordering: Enqueue 3 matches rapidly. Assert handler receives them in FIFO order. Use asyncio for this test.
- test_agent_connection_independence: Fire 3 matches. Assert all handlers run (concurrently). Use asyncio.
- test_connect_factory: connect() returns a BasicConnection.
- test_pipe_factory: pipe() returns a PipeConnection.
- test_agent_factory: agent() returns an AgentConnection.
- test_connection_with_placeholder_pattern: Connection whose source pattern has placeholders. Handler receives the bindings.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass. Async tests run correctly.
```

---

## PROMPT 12 — Communication Model

```
Implement PyRapide Phase 4 Step 3: Communication Model and Architecture Maps.

Create pyrapide/architecture/communication.py:

1. CommunicationScope:
   - Defines who can observe whose events at runtime.
   - Rules:
     a. A module can always observe its own events.
     b. The parent architecture can observe all of its component events.
     c. A module linked via a connection can observe the connected module's events.
   - can_observe(observer, target) -> bool: Returns whether observer is allowed to see target's events.
   - register_link(a, b): Records that a and b are connected.

2. CommunicationContext:
   - Tracks the current causal context during execution.
   - current_causes: list[Event] — events that will be causal parents of the next generated event.
   - push_cause(event): Adds to current causes.
   - pop_cause(): Removes last cause.
   - fork() -> CommunicationContext: Creates an independent causal context (for agent connections and || parallelism).

Create pyrapide/architecture/maps.py:
1. ArchitectureMap:
   - domain: Architecture type (source)
   - range: Architecture type (target)
   - mapping_rules: list of (source_pattern, target_action) tuples
   - Defines how events in one architecture correspond to events in another.
   - apply(source_computation) -> Computation: Transforms a computation from domain to range architecture.

Create pyrapide/architecture/bindings.py:
1. bind(interface_obj, module) -> None: Dynamically associates a module implementation with an interface object at runtime.
2. Binding class storing the interface-module association.

Update exports.

Create tests/architecture/test_communication.py:
- test_self_observation: Module can observe its own events.
- test_parent_observation: Architecture can observe component events.
- test_linked_observation: Connected modules can observe each other.
- test_unlinked_no_observation: Unconnected module cannot observe another.
- test_causal_context_push_pop: Push two causes, pop one, verify state.
- test_causal_context_fork: Fork creates independent context.

Create tests/architecture/test_maps.py:
- test_architecture_map_creation: Create a map between two architectures.
- test_architecture_map_apply: Apply map to a computation, get transformed computation.
- test_map_preserves_causality: Causal relationships survive the mapping.

Create tests/architecture/test_bindings.py:
- test_bind_module_to_interface: Bind a module to an interface. Assert the binding is recorded.
- test_binding_type_check: Binding a module that doesn't conform raises an error.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PHASE 5: CONSTRAINTS & MONITORING

---


## PROMPT 13 — Pattern Constraints

```
Implement PyRapide Phase 5 Step 1: Constraint definitions — must_match and never.

Create pyrapide/constraints/pattern_constraints.py:

1. Constraint (base class):
   - name: str
   - description: str
   - check(computation: Computation) -> list[ConstraintViolation]: Evaluate the constraint against a computation. Return a list of violations (empty if constraint is satisfied).

2. MustMatch(Constraint):
   - pattern: Pattern
   - Constraint is VIOLATED if the pattern does NOT match anywhere in the computation.
   - Violation message includes which pattern was expected.

3. Never(Constraint):
   - pattern: Pattern
   - Constraint is VIOLATED if the pattern DOES match in the computation.
   - Violation includes the matched events that should not have occurred.

4. ConstraintViolation:
   - constraint_name: str
   - violation_type: str ("must_match_failed" or "never_violated")
   - description: str
   - matched_events: list[Event] (for never violations) or empty (for must_match failures)
   - timestamp: float

5. @constraint decorator:
   - Decorates a class that defines constraints.
   - Scans for must_match() and never() calls within the class body or a define() method.
   - Stores list of Constraint objects.

6. Convenience functions:
   - must_match(pattern, name=None) -> MustMatch
   - never(pattern, name=None) -> Never

Create pyrapide/constraints/filters.py:
1. PatternFilter: Limits which events the constraint examines.
   - filter_computation(computation, filter_patterns) -> Computation: Returns a filtered computation containing only events matching any of the filter patterns.
2. AlphabetFilter: Filters by interface event alphabet.
   - filter_by_alphabet(computation, interface_class) -> Computation: Only events in that interface's alphabet.

Create pyrapide/constraints/__init__.py exporting Constraint, MustMatch, Never, ConstraintViolation, must_match, never, constraint, PatternFilter, AlphabetFilter.

Create tests/constraints/test_pattern_constraints.py:
- test_must_match_satisfied: Computation has the expected pattern. check() returns empty list.
- test_must_match_violated: Computation lacks the pattern. check() returns one violation.
- test_never_satisfied: Computation has no forbidden pattern. check() returns empty list.
- test_never_violated: Computation contains the forbidden pattern. check() returns violation with matched events.
- test_must_match_with_placeholders: Pattern with placeholders; satisfied when binding exists.
- test_never_with_sequence: never(P >> Q). Violated when P causes Q.
- test_constraint_decorator: Define a @constraint class with must_match and never. Extract constraints.
- test_multiple_constraints: Multiple must_match and never in one class. All checked.
- test_constraint_violation_details: Violation has correct name, type, description.

Create tests/constraints/test_filters.py:
- test_pattern_filter: Filter computation to only "Request" and "Response" events.
- test_alphabet_filter: Filter computation by an interface's event alphabet.
- test_filter_preserves_causality: Filtered computation preserves causal edges between surviving events.
- test_filter_empty: Filter that matches nothing returns empty computation.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 14 — Real-Time Constraint Monitor

```
Implement PyRapide Phase 5 Step 2: Real-time streaming constraint monitor.

Create pyrapide/constraints/monitor.py:

1. ConstraintMonitor:
   - Watches a live event stream and checks constraints incrementally.
   - add_constraint(constraint): Register a constraint to monitor.
   - remove_constraint(name): Remove by name.
   - check(event: Event) -> list[ConstraintViolation]: Process a single new event. Updates internal computation state, then runs all constraints. Returns any new violations.
   - check_batch(events: list[Event]) -> list[ConstraintViolation]: Process multiple events.
   - reset(): Clear internal state.
   - violations property: All violations detected so far.
   - Internal Computation that grows as events arrive.
   - record_causal_link(cause: Event, effect: Event): Allows external code to declare causality between events that have already been checked in.

2. Efficiency considerations:
   - The monitor should NOT re-check the entire computation on every event. For Never constraints, it should check if the new event completes any forbidden pattern. For MustMatch, it tracks whether the pattern has been seen yet.
   - Add an incremental flag: if True, only check patterns that could involve the new event.

3. AsyncConstraintMonitor(ConstraintMonitor):
   - async check(event) and async check_batch(events) versions.
   - async monitor_stream(event_source: AsyncIterable[Event], on_violation: Callable): Continuously monitors an async event stream, calling on_violation for each violation detected.

Create pyrapide/constraints/conformance.py:
1. check_conformance(computation: Computation, constraints: list[Constraint]) -> list[ConstraintViolation]:
   Batch check all constraints against a full computation. Returns all violations.

Update exports.

Create tests/constraints/test_monitor.py:
- test_monitor_no_violations: Feed 10 clean events. No violations.
- test_monitor_detects_never_violation: Feed events that form a forbidden pattern. Violation detected.
- test_monitor_detects_must_match_at_end: After feeding all events, check if expected pattern exists.
- test_monitor_incremental: Feed events one at a time. Violation detected on the specific event that completes the forbidden pattern.
- test_monitor_reset: Feed events, reset, feed again. State is fresh.
- test_monitor_multiple_constraints: Two constraints, one violated, one satisfied. Returns only the violated one.
- test_monitor_causal_link: Record causal link between events. Pattern involving causality correctly detected.
- test_async_monitor_stream: Create an async generator yielding events. Monitor detects violations in stream. Use asyncio.
- test_monitor_violations_accumulate: Feed multiple violations. violations property returns all.

Create tests/constraints/test_conformance.py:
- test_conformance_all_pass: Computation satisfies all constraints.
- test_conformance_some_fail: Computation violates some constraints.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass. Async tests run correctly.
```

---

## PHASE 6: EXECUTABLE MODULES & RUNTIME

---


## PROMPT 15 — Module Definition and Lifecycle

```
Implement PyRapide Phase 6 Step 1: The @module decorator and module lifecycle.

Create pyrapide/executable/module.py:

1. @module(implements=None) decorator:
   - Transforms a class into a RAPIDE module (an implementation of an interface).
   - Optional `implements` parameter specifying which @interface class this module implements.
   - If `implements` is set, check at decoration time that the module class provides implementations for all @requires methods of the interface. Raise ConformanceError if not.
   - Stores metadata: _pyrapide_is_module = True, _pyrapide_implements = interface_class.

2. Module lifecycle hooks (detected by name convention):
   - async start(self): Called when the module begins executing.
   - async finish(self): Called when the module is being finalized.
   - Module has states: CREATED, STARTING, RUNNING, FINISHING, FINISHED.
   - state property returns current state.

3. ModuleContext:
   - Each running module has a context containing:
     - computation: Computation — the computation this module contributes to
     - causal_context: list[Event] — current causal parents for the next generated event
     - module_events: list[Event] — all events generated by this module
   - get_context(module) -> ModuleContext (module registry)

4. Event generation support:
   - When a @module's @action method is called, it should:
     a. Create an Event with name = "InterfaceName.action_name" (or "ModuleName.action_name")
     b. Add it to the computation with caused_by = current causal context
     c. Update the causal context (the new event becomes a cause for subsequent events in the same sequential block)
     d. Return the event (or the action's return value if any)
   - For now, implement this with a generate_event(name, payload, caused_by) method on the module base.

Create pyrapide/executable/exceptions.py:
1. ConformanceError(Exception) — raised when a module doesn't conform to its interface.
2. ModuleStateError(Exception) — raised when an operation is invalid for the current module state.

Create pyrapide/executable/__init__.py exporting module, ModuleContext, ConformanceError, ModuleStateError.
Update pyrapide/__init__.py.

Create tests/executable/test_module.py:
- test_module_decorator: Decorate a class. Assert _pyrapide_is_module is True.
- test_module_implements: @module(implements=MyInterface) stores the interface reference.
- test_module_conformance_check: Module missing a required method. Raises ConformanceError at decoration time.
- test_module_lifecycle_states: Create module, assert CREATED. Call start(), assert STARTING then RUNNING. Call finish(), assert FINISHED.
- test_module_start_hook: Module with async start(). Assert it's called during lifecycle.
- test_module_finish_hook: Module with async finish(). Assert it's called.
- test_module_generate_event: Module generates an event. Event appears in its context's computation.
- test_module_causal_chain: Module generates e1, then e2. e2 is caused by e1.
- test_module_context: Access module's context, verify computation and module_events.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---


## PROMPT 16 — Reactive Statements

```
Implement PyRapide Phase 6 Step 2: Reactive statements — @when decorator and process support.

Create pyrapide/executable/reactive.py:

1. @when(pattern) decorator:
   - Decorates an async method on a @module class.
   - When the module is running, any time the given pattern matches in the module's observable events, the decorated handler is called with the PatternMatch.
   - The handler runs with a causal context set to the matched events (i.e., any events generated inside the handler are causally dependent on the triggering matched events).
   - Multiple @when handlers can be active simultaneously.
   - Stores _pyrapide_when_pattern on the method.

2. ReactiveProcess:
   - Manages a single @when handler registration.
   - Tracks: pattern, handler function, active flag.
   - check_and_fire(event, computation) -> list[Event]: When a new event arrives, check if this event (combined with existing computation state) completes the pattern. If so, call the handler.

3. WhenRegistry:
   - Collects all @when-decorated methods on a module class.
   - scan(module_class) -> list[ReactiveProcess]: Returns all reactive processes for the module.
   - fire_all(event, computation) -> list[Event]: For each registered process, check if the new event triggers it.

Create pyrapide/executable/process.py:

1. ProcessManager:
   - Manages multiple concurrent processes (both @when handlers and explicit async processes).
   - add_process(coroutine_or_reactive): Register a process.
   - run_all(): Start all processes concurrently.
   - stop_all(): Gracefully stop all processes.

2. Support for serial modules: @module(serial=True)
   - In a serial module, only one @when handler executes at a time (mutual exclusion).
   - Implement with an asyncio.Lock.

Update exports.

Create tests/executable/test_reactive.py:
- test_when_decorator: Decorated method has _pyrapide_when_pattern attribute.
- test_when_fires_on_match: Module with @when(Pattern.match("Request")). Feed a "Request" event. Handler is called with the match.
- test_when_no_fire_on_mismatch: Feed a "Ping" event. Handler NOT called.
- test_when_multiple_handlers: Two @when handlers for different patterns. Each fires independently.
- test_when_causal_context: Handler generates an event. That event is causally linked to the triggering matched event.
- test_when_persistent: Feed two "Request" events. Handler is called twice (once for each).
- test_when_with_placeholder: @when(Pattern.match("Request", data=placeholder("d"))). Handler receives bindings with data.
- test_when_registry_scan: Scan a module class. Returns correct ReactiveProcess list.

Create tests/executable/test_process.py:
- test_process_manager_add: Add 3 processes.
- test_serial_module_mutual_exclusion: Two @when handlers on a serial module. Feed two events simultaneously. Assert only one handler runs at a time (sequential execution).
- test_concurrent_module_parallel: Non-serial module. Both handlers can run concurrently.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 17 — Execution Engine

```
Implement PyRapide Phase 6 Step 3: The central execution engine.

Create pyrapide/runtime/engine.py:

1. Engine class:
   - The orchestrator that runs everything: creates modules, runs processes, delivers events through connections, and builds the computation poset.
   
   - instantiate(architecture_class, **kwargs) -> Architecture instance:
     Creates an instance of the architecture, instantiates all components.
   
   - async run(architecture, timeout=None) -> Computation:
     Main execution loop:
     a. Initialize all components (call start() hooks).
     b. Set up all connections from the architecture's connections() method.
     c. Set up the constraint monitor from the architecture's constraints() method (if any).
     d. Enter event processing loop: when any component generates an event, propagate it through connections, fire reactive handlers, check constraints.
     e. Continue until no more events can be generated (quiescence) or timeout.
     f. Call finish() hooks on all components.
     g. Return the final Computation.
   
   - async inject(event, caused_by=None):
     Inject an external event into the running computation (e.g., from an MCP server). The event enters the computation and is processed through connections like any internally generated event.
   
   - async wait(timeout=None):
     Wait for the computation to reach quiescence.

2. EventDispatcher (internal):
   - Receives generated events.
   - Passes them through all active connections (via ConnectionManager).
   - Triggers all reactive handlers (via WhenRegistry on each component).
   - Monitors constraints (via ConstraintMonitor).
   - All of this must maintain correct causal context.

Create pyrapide/runtime/scheduler.py:
1. EventScheduler:
   - Queues events for processing.
   - Ensures causal ordering: an event can only be processed after all its causal parents have been processed.
   - Topological order processing of events.

Create pyrapide/runtime/__init__.py and update pyrapide/__init__.py to export Engine.

Create tests/runtime/test_engine.py:
- test_engine_instantiate: Instantiate an architecture. Components exist.
- test_engine_run_simple: Architecture with one component that generates one event in start(). Run engine. Computation has the event.
- test_engine_connection_propagation: Architecture with two components. Component A generates "Request" in start(). Connection routes "Request" to component B's handler. B generates "Response". Computation has both events with correct causal link.
- test_engine_inject: Run engine, inject an external event. Event appears in computation.
- test_engine_timeout: Set a short timeout. Engine stops even if components could generate more events.
- test_engine_constraint_violation: Architecture with a never constraint. Component generates a forbidden pattern. Engine's computation records the violation.
- test_engine_multiple_components: Architecture with 3 components and 2 connections. Verify full event propagation.
- test_engine_quiescence: Architecture where all components eventually stop generating events. Engine reaches quiescence and returns.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass. This is a major milestone — the core runtime is working.
```

---

## PHASE 7: STREAMING & MCP INTEGRATION

---

## PROMPT 18 — Streaming Event Processor

```
Implement PyRapide Phase 7 Step 1: Streaming event processor for real-time multi-source event ingestion.

Create pyrapide/runtime/streaming.py:

1. EventSource (Protocol / ABC):
   - name: str
   - async events() -> AsyncIterator[Event]: Yields events from this source.

2. StreamProcessor:
   - Processes events from multiple concurrent sources in real time.
   
   - add_source(name: str, source: EventSource): Register an event source.
   - remove_source(name: str): Remove a source.
   
   - watch(pattern: Pattern, callback: Callable[[PatternMatch], Awaitable[None]]): Register a pattern to watch for. When matched, callback is called.
   - unwatch(pattern): Remove a watch.
   
   - enforce(constraint: Constraint): Add a constraint to monitor in real time.
   
   - on_violation(callback: Callable[[ConstraintViolation], Awaitable[None]]): Register violation callback.
   - on_event(callback: Callable[[Event], Awaitable[None]]): Register callback for every event.
   
   - async run(window_size: int = 10000):
     Main loop:
     a. Consume events from all sources concurrently (asyncio.gather on all source tasks).
     b. For each event, add to internal Computation.
     c. Check pattern watches and fire callbacks.
     d. Check constraints and fire violation callbacks.
     e. Maintain a sliding window: evict events older than window_size to prevent unbounded memory growth. Eviction must preserve causal edges for surviving events.
   
   - async stop(): Gracefully shut down all source consumers.
   
   - computation property: Returns the current Computation (within the window).
   - stats property: Returns dict with event_count, source_counts, violation_count, match_count.

3. InMemoryEventSource(EventSource):
   - Simple source backed by an asyncio.Queue.
   - async put(event): Enqueue an event.
   - Useful for testing and for injecting events programmatically.

Create pyrapide/runtime/serialization.py:
1. serialize_computation(computation, format="json") -> str | bytes:
   Serialize a computation to JSON or a compact binary format.
2. deserialize_computation(data, format="json") -> Computation:
   Reverse.
3. serialize_event(event) -> dict: Delegates to event.to_dict().
4. deserialize_event(data) -> Event: Delegates to Event.from_dict(data).

Update exports.

Create tests/runtime/test_streaming.py:
- test_stream_single_source: One InMemoryEventSource, put 5 events, run processor, on_event callback receives all 5.
- test_stream_multi_source: Two sources, each put 3 events. Processor receives all 6.
- test_stream_pattern_watch: Watch for "Error" pattern. Put 2 Error events among 10 events. Callback fired twice.
- test_stream_constraint_enforcement: Enforce a never("BadPattern") constraint. Put events completing the bad pattern. Violation callback fires.
- test_stream_sliding_window: Set window_size=5. Put 10 events. Computation contains at most ~5 recent events.
- test_stream_stats: Run processor, check stats dict.
- test_stream_stop: Start processor, stop it, assert it shuts down cleanly.

Create tests/runtime/test_serialization.py:
- test_serialize_event_json: Roundtrip event serialization.
- test_serialize_computation_json: Roundtrip computation serialization.
- test_serialize_preserves_causality: Causal edges survive serialization.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 19 — MCP Server Adapter

```
Implement PyRapide Phase 7 Step 2: MCP server integration adapter.

Create pyrapide/integrations/mcp.py:

1. MCPEventAdapter(EventSource):
   - Translates MCP protocol events into PyRapide Events with automatic causal linking.
   - Constructor takes: server_name: str, and optionally a connected MCP client or a URL.
   
   - Event mapping (create these as constants/enum):
     - MCP tool call initiated -> Event("mcp.tool_call", {"tool": name, "args": args, "server": server_name})
     - MCP tool result returned -> Event("mcp.tool_result", {"tool": name, "result": result, "server": server_name})  
     - MCP resource read -> Event("mcp.resource_read", {"uri": uri, "server": server_name})
     - MCP error -> Event("mcp.error", {"tool": name, "error": str, "server": server_name})
     - MCP server connected -> Event("mcp.connect", {"server": server_name, "capabilities": caps})
     - MCP server disconnected -> Event("mcp.disconnect", {"server": server_name, "reason": reason})
   
   - Automatic causal links:
     - tool_call -> tool_result (matched by a correlation_id in metadata)
     - tool_call -> error (if the call failed)
   
   - async events() -> AsyncIterator[Event]: Yields PyRapide events.
   
   - For now, implement a MockMCPClient for testing that simulates tool calls and results.

2. MCPEventTypes (module-level constants or enum):
   - TOOL_CALL = "mcp.tool_call"
   - TOOL_RESULT = "mcp.tool_result"
   - RESOURCE_READ = "mcp.resource_read"
   - ERROR = "mcp.error"
   - CONNECT = "mcp.connect"
   - DISCONNECT = "mcp.disconnect"

3. MCPPatterns (pre-built pattern library for common MCP patterns):
   - tool_call(tool_name=None) -> Pattern: Matches any tool call, optionally filtered by tool name.
   - tool_result(tool_name=None) -> Pattern: Matches any tool result.
   - tool_roundtrip(tool_name=None) -> Pattern: Sequence of tool_call >> tool_result.
   - tool_error(tool_name=None) -> Pattern: Matches tool errors.
   - server_lifecycle() -> Pattern: connect >> disconnect sequence.

Create pyrapide/integrations/llm.py:
1. LLMEventAdapter:
   - Similar adapter but for LLM API calls.
   - Events: "llm.request", "llm.response", "llm.stream_chunk", "llm.error"
   - Causal: request -> response, request -> stream_chunk(s)
   - MockLLMClient for testing.

Update exports.

Create tests/integrations/test_mcp_adapter.py:
- test_mcp_event_types: Assert all constant names are correct strings.
- test_mcp_tool_call_event: Simulate a tool call. Adapter yields an Event with correct name and payload.
- test_mcp_tool_result_event: Simulate a tool result. Correct event generated.
- test_mcp_causal_link: Simulate tool_call then tool_result. Assert tool_result is caused by tool_call in the computation.
- test_mcp_error_event: Simulate a tool error. Error event is caused by the tool_call.
- test_mcp_patterns_tool_call: MCPPatterns.tool_call() matches mcp.tool_call events.
- test_mcp_patterns_roundtrip: MCPPatterns.tool_roundtrip() matches call >> result sequence.
- test_mcp_adapter_as_stream_source: Use MCPEventAdapter with StreamProcessor. Events flow through.
- test_mcp_multi_server: Two MCPEventAdapters for different servers. Events have distinct sources.
- test_mock_mcp_client: MockMCPClient generates expected sequence of events.

Create tests/integrations/test_llm_adapter.py:
- test_llm_request_event: Simulate LLM request. Event generated correctly.
- test_llm_causal_link: Request -> response causality.
- test_llm_stream_chunks: Request -> multiple stream chunks, all caused by request.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PHASE 8: ANALYSIS & PREDICTION

---

## PROMPT 20 — Poset Queries

```
Implement PyRapide Phase 8 Step 1: Advanced poset query engine.

Create pyrapide/analysis/queries.py:

1. critical_path(computation) -> list[Event]:
   Returns the longest causal chain in the computation. If multiple chains tie, return any one of them.

2. root_causes(computation, target_event) -> frozenset[Event]:
   Returns all root events (events with no causes) that are ancestors of the target event.

3. impact_set(computation, source_event) -> frozenset[Event]:
   Returns all events that are descendants of source_event (everything it caused, directly or transitively).

4. causal_distance(computation, a, b) -> int | None:
   Returns the length of the shortest causal path from a to b, or None if no path exists.

5. common_ancestors(computation, a, b) -> frozenset[Event]:
   Delegates to poset.common_ancestors.

6. backward_slice(computation, target_event) -> Computation:
   Returns a new Computation containing only the target event and all its transitive ancestors, with all causal edges between them preserved.

7. forward_slice(computation, source_event) -> Computation:
   Returns a new Computation containing only the source event and all its transitive descendants.

8. parallel_events(computation) -> list[frozenset[Event]]:
   Returns groups of events that are mutually causally independent (could have occurred in any order). Useful for identifying concurrency.

9. bottleneck_events(computation) -> list[Event]:
   Returns events that appear on every causal path from every root to every leaf (the "cut points" of the DAG). These are potential bottlenecks.

10. event_frequency(computation) -> dict[str, int]:
    Counts events by name.

11. causal_density(computation) -> float:
    Ratio of actual causal edges to maximum possible edges. Indicates how interconnected the computation is.

Update pyrapide/analysis/__init__.py and pyrapide/__init__.py.

Create tests/analysis/test_queries.py:
- test_critical_path_linear: Chain of 5. Critical path is the full chain.
- test_critical_path_diamond: Diamond poset. Critical path is length 2.
- test_root_causes: Event at bottom of diamond. Root causes is the single root.
- test_root_causes_multiple_roots: Two independent chains merge. Both roots returned.
- test_impact_set: Root event in diamond. Impact set includes all other events.
- test_causal_distance_direct: Distance 1 for directly connected events.
- test_causal_distance_transitive: Distance 2 for A -> B -> C from A to C.
- test_causal_distance_none: Independent events. Distance is None.
- test_backward_slice: Slice from leaf of diamond. Contains all 4 events.
- test_forward_slice: Slice from root of diamond. Contains all 4 events.
- test_parallel_events: Two independent event groups identified.
- test_bottleneck: Linear chain: every event is a bottleneck. Diamond: root and leaf are bottlenecks.
- test_event_frequency: 3 "Send" and 2 "Receive" events. Counts correct.
- test_causal_density: Fully connected vs sparse computations.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 21 — Visualization

```
Implement PyRapide Phase 8 Step 2: Visualization — Graphviz DOT, Mermaid, and JSON export.

Create pyrapide/analysis/visualization.py:

1. to_dot(computation, highlight=None, event_types=None, time_range=None, max_events=200) -> str:
   - Generates a Graphviz DOT string representing the poset.
   - Each event is a node labeled with "name\nsource\nid_short".
   - Each causal edge is a directed edge.
   - highlight: optional set of events to color differently (e.g., red for errors).
   - event_types: optional filter to only show certain event names.
   - time_range: optional (start, end) tuple to filter by timestamp.
   - max_events: truncate display if too many events (show warning in graph title).
   - Use subgraphs to group events by source.

2. to_mermaid(computation, highlight=None, event_types=None, max_events=100) -> str:
   - Generates a Mermaid flowchart string.
   - Similar filtering options as to_dot.
   - Format: "graph TD\n  id1[\"Send\\nclient_1\"] --> id2[\"Process\\nserver\"]"

3. to_json(computation) -> dict:
   - Returns a JSON-serializable dict with:
     - "events": list of event dicts
     - "edges": list of {"from": event_id, "to": event_id} dicts
     - "metadata": {"event_count": N, "edge_count": M, "causal_depth": D}
   - Suitable for feeding to custom UI frameworks (D3.js, React, etc.).

4. to_ascii(computation, max_width=120) -> str:
   - Simple ASCII art representation for terminal output.
   - Show events as lines with indentation representing causal depth.
   - Show causal links with arrows.

5. summary(computation) -> str:
   - Human-readable text summary.
   - "Computation: 47 events, 52 causal edges, depth 8, 3 root events, 5 leaf events"
   - Lists top 5 event types by frequency.
   - Lists top 3 sources by event count.

Update exports.

Create tests/analysis/test_visualization.py:
- test_to_dot_basic: Generate DOT string from a simple poset. Assert it contains "digraph", node labels, edges.
- test_to_dot_highlight: Highlighted events have different color attribute.
- test_to_dot_filter_event_types: Only specified event types appear.
- test_to_dot_max_events: More events than max_events. Output is truncated with a note.
- test_to_mermaid_basic: Generate Mermaid string. Assert it contains "graph TD" and node definitions.
- test_to_json_structure: JSON dict has "events", "edges", "metadata" keys.
- test_to_json_roundtrip: Events and edges in JSON match the original computation.
- test_to_ascii: ASCII output is a non-empty string containing event names.
- test_summary: Summary string contains event count and depth.
- test_empty_computation_viz: All viz functions handle empty computation without error.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 22 — Prediction Engine

```
Implement PyRapide Phase 8 Step 3: Causal prediction engine.

Create pyrapide/analysis/prediction.py:

1. CausalPredictor:
   - Learns from historical computations and predicts likely future events.
   
   - learn(computation: Computation):
     Analyzes the computation and extracts causal patterns:
     a. Event type transition frequencies: P(event_B | event_A caused event_B). Count how often each event type directly causes each other event type.
     b. Sequence frequencies: Common sequences of 2 and 3 event types.
     c. Timing statistics: Average time between causally linked event pairs.
   
   - predict(current_computation: Computation, horizon: int = 5, confidence_threshold: float = 0.1) -> list[Prediction]:
     Given the current state (especially leaf events), predict what events are likely to happen next.
     a. Look at each leaf event's type.
     b. From learned transition frequencies, identify the most likely next event types.
     c. Score by frequency / total transitions from that event type.
     d. Return up to `horizon` predictions above the confidence threshold.
   
   - predict_from_event(event: Event) -> list[Prediction]:
     Predict what is likely to follow a specific event.

2. Prediction:
   - event_name: str — predicted event type
   - confidence: float — 0.0 to 1.0
   - likely_cause: str — the event type that would trigger this
   - expected_delay: float | None — average time between cause and effect (if timing data available)
   - reasoning: str — human-readable explanation

3. AnomalyDetector:
   - Uses learned patterns to detect anomalies (unusual causal sequences).
   
   - learn(computations: list[Computation]):
     Build a model of "normal" causal patterns.
   
   - detect(computation: Computation) -> list[Anomaly]:
     Identify events or causal links that deviate significantly from learned patterns.
     a. Event types never seen before.
     b. Causal links between types never observed together.
     c. Unusual timing (significantly faster or slower than average).
   
4. Anomaly:
   - event: Event
   - anomaly_type: str ("unseen_event", "unusual_cause", "timing_anomaly")
   - severity: float — 0.0 to 1.0
   - description: str

Create pyrapide/analysis/anomaly.py — re-export AnomalyDetector and Anomaly from prediction.py, or put them here and import in prediction.py. Your choice for clean organization.

Update exports.

Create tests/analysis/test_prediction.py:
- test_predictor_learn: Learn from a computation with A -> B -> C pattern repeated 10 times. Internal frequencies reflect this.
- test_predictor_predict: After learning A->B->C, predict from leaf event of type A. Returns B with high confidence.
- test_predictor_multiple_paths: Learn A->B (8 times) and A->C (2 times). Predict from A: B has higher confidence than C.
- test_predictor_confidence_threshold: Set high threshold. Only high-confidence predictions returned.
- test_predictor_empty_history: No learning. Predict returns empty list.
- test_prediction_details: Prediction has event_name, confidence, likely_cause, reasoning.
- test_predict_from_event: Predict based on a single event type.

Create tests/analysis/test_anomaly.py:
- test_anomaly_detector_learn: Learn from normal computations.
- test_anomaly_unseen_event: Inject an event type never seen in training. Detected as anomaly.
- test_anomaly_unusual_cause: Create a causal link (A -> D) never seen in training. Detected.
- test_anomaly_no_anomalies: Feed a normal computation. No anomalies detected.
- test_anomaly_severity: More unusual patterns have higher severity scores.

Run ALL tests.

VALIDATION: `pytest tests/ -v` — all tests pass.
```

---

## PHASE 9: END-TO-END SCENARIOS

---



## PROMPT 23 — Scenario: Producer-Consumer

```
Implement end-to-end Scenario 1: Producer-Consumer Pipeline.

This is a classic RAPIDE example from the specification. It validates that the full stack works together: interfaces, modules, architecture, connections, patterns, and the engine.

Create tests/scenarios/test_producer_consumer.py:

Define:

1. ProducerInterface (@interface):
   - @action async def produce(self, item: str): ...

2. ConsumerInterface (@interface):
   - @action async def consume(self, item: str): ...

3. ProducerModule (@module implementing ProducerInterface):
   - In start(), generate 5 produce events with items "item_1" through "item_5".

4. ConsumerModule (@module implementing ConsumerInterface):
   - @when(Pattern.match("ProducerInterface.produce", item=placeholder("item")))
   - Handler calls self.consume(item=match.bindings["item"])

5. ProducerConsumerArch (@architecture):
   - producer: ProducerInterface
   - consumer: ConsumerInterface
   - connections(): pipe(Pattern.match("ProducerInterface.produce"), handler that triggers consumer.consume)

6. Test: test_producer_consumer_pipeline:
   - Instantiate with Engine.
   - Run architecture.
   - Assert computation has 10 events (5 produce + 5 consume).
   - Assert each produce event causes the corresponding consume event.
   - Assert pipe connection maintained FIFO order.
   - Assert causal depth is 1 for each produce->consume pair.

7. Test: test_producer_consumer_poset_structure:
   - Verify root_events are the 5 produce events.
   - Verify leaf_events are the 5 consume events.
   - Verify all produce-consume pairs have correct causal links.

8. Test: test_producer_consumer_visualization:
   - Generate DOT visualization of the computation.
   - Assert it's valid DOT syntax (contains "digraph", all 10 event nodes, 5 edges).

Run ALL tests.

VALIDATION: `pytest tests/scenarios/test_producer_consumer.py -v` — all scenario tests pass. `pytest tests/ -v` — all tests pass.
```

---

## PROMPT 24 — Scenario: MCP Multi-Server

```
Implement end-to-end Scenario 2: MCP Multi-Server Orchestration.

This validates the MCP integration, streaming processor, constraints, and causal tracing across multiple concurrent servers.

Create tests/scenarios/test_mcp_multi_server.py:

Define:

1. Three MockMCPServers:
   - ToolServer: Generates tool_call and tool_result events.
   - ResourceServer: Generates resource_read events.
   - MemoryServer: Generates tool_call (memory_store) and tool_result events.

2. Each backed by MCPEventAdapter wrapping a MockMCPClient.

3. Constraints:
   - Every tool_call must eventually get a tool_result (MustMatch on tool_roundtrip pattern).
   - No tool_result should occur without a preceding tool_call (Never on orphan results).

4. Test: test_mcp_three_servers_streaming:
   - Create StreamProcessor with all 3 MCPEventAdapters.
   - Watch for MCPPatterns.tool_roundtrip() pattern. Track matches.
   - Enforce the two constraints above.
   - Feed events from all 3 servers: 5 tool calls from ToolServer, 3 resource reads from ResourceServer, 2 memory stores from MemoryServer. All get results.
   - Run processor.
   - Assert all 7 tool roundtrips were detected (5 tool + 2 memory).
   - Assert no constraint violations.
   - Assert computation has correct causal links (each call -> result pair).

5. Test: test_mcp_constraint_violation:
   - Same setup but one ToolServer tool_call does NOT get a result.
   - Assert MustMatch violation is detected.

6. Test: test_mcp_causal_tracing:
   - Simulate: LLM request -> tool_call -> resource_read -> tool_result -> LLM response.
   - Assert full causal chain is traceable from LLM request to LLM response.
   - Use queries.causal_chain() to verify.

7. Test: test_mcp_parallel_events:
   - Two tool calls happening independently (from different prompts).
   - Assert they are causally independent.
   - Use queries.parallel_events() to verify.

8. Test: test_mcp_root_cause_analysis:
   - Simulate an error event. Use queries.root_causes() to trace back to the originating tool_call.

Run ALL tests.

VALIDATION: `pytest tests/scenarios/test_mcp_multi_server.py -v` — all scenario tests pass.
```

---

## PROMPT 25 — Scenario: Anomaly Detection

```
Implement end-to-end Scenario 3: Streaming Anomaly Detection Pipeline.

This validates the prediction engine, anomaly detection, and real-time constraint monitoring working together.

Create tests/scenarios/test_anomaly_detection.py:

Define:

1. SensorInterface (@interface):
   - @action async def reading(self, sensor_id: str, value: float): ...
   - @action async def alert(self, sensor_id: str, severity: str): ...

2. Create 5 mock sensor event sources using InMemoryEventSource that generate "reading" events with values.

3. Normal pattern: reading events with values between 10.0 and 90.0. Readings from different sensors are independent.

4. Anomaly injections:
   - Sensor 3 generates a value of 500.0 (way out of range).
   - Sensor 5 generates a reading that causally depends on sensor 2 (unusual cross-sensor dependency).
   - An unknown event type "sensor.malfunction" appears.

5. Test: test_anomaly_train_and_detect:
   - Create CausalPredictor and AnomalyDetector.
   - Train on 10 normal computations (100 events each, all normal patterns).
   - Feed a computation with injected anomalies.
   - Assert AnomalyDetector finds at least 2 anomalies (the value outlier and the unknown event type).

6. Test: test_prediction_after_training:
   - Train predictor on normal patterns.
   - Give it a partial computation (a few reading events).
   - Assert it predicts more reading events with reasonable confidence.

7. Test: test_streaming_anomaly_monitoring:
   - Set up StreamProcessor with 5 sensor sources.
   - Define constraints: never pattern for out-of-range values.
   - Feed normal events then inject anomalies.
   - Assert violations are detected in real-time stream.

8. Test: test_anomaly_severity_ranking:
   - Multiple anomalies of different types.
   - Assert they have different severity scores and are rankable.

9. Test: test_full_pipeline:
   - Train -> Stream -> Detect -> Predict in sequence.
   - Full pipeline running: stream events, detect anomalies, predict next events.
   - Assert all components interact correctly.

Run ALL tests.

VALIDATION: `pytest tests/scenarios/test_anomaly_detection.py -v` — all scenario tests pass.
```

---

## PHASE 10: POLISH & FINAL VALIDATION

---

## PROMPT 26 — Public API Cleanup

```
Review and clean up the public API for PyRapide.

1. Update pyrapide/__init__.py to export all primary user-facing classes and functions in a clean, organized way:

   # Core
   from pyrapide.core import Event, Poset, Computation, Clock, SynchronousClock, RegularClock, SlavedClock, ClockManager, CausalCycleError

   # Types
   from pyrapide.types import interface, action, provides, requires, behavior, is_subtype, conforms_to

   # Patterns
   from pyrapide.patterns import Pattern, BasicPattern, placeholder, PatternMatch

   # Architecture
   from pyrapide.architecture import architecture, connect, pipe, agent

   # Constraints
   from pyrapide.constraints import constraint, must_match, never, Constraint, MustMatch, Never, ConstraintViolation, ConstraintMonitor

   # Executable
   from pyrapide.executable import module, when

   # Runtime
   from pyrapide.runtime import Engine, StreamProcessor, InMemoryEventSource

   # Integrations
   from pyrapide.integrations import MCPEventAdapter, MCPPatterns, MCPEventTypes, LLMEventAdapter

   # Analysis
   from pyrapide.analysis import queries, visualization, CausalPredictor, AnomalyDetector

2. Add a __version__ = "0.1.0" to pyrapide/__init__.py.

3. Add a __all__ list containing all exported names.

4. Add module-level docstrings to every __init__.py file (one sentence describing the subpackage).

5. Add docstrings to every public class and function that doesn't already have one. Each docstring should have a one-line summary, a description paragraph, and an example.

6. Run mypy on the entire codebase: `mypy pyrapide/ --ignore-missing-imports`. Fix any type errors.

7. Run ruff: `ruff check pyrapide/`. Fix any lint issues.

8. Verify the full import works: `python -c "from pyrapide import *; print('All exports working')"`.

VALIDATION: mypy passes with no errors. ruff passes with no errors. `python -c "from pyrapide import *"` works. `pytest tests/ -v` — all tests still pass (no regressions from cleanup).
```

---



## PROMPT 27 — README and Usage Documentation

```
Create a README.md for the PyRapide project.

Include the following sections:

1. **Header**: PyRapide logo placeholder, one-line description, badges placeholder.

2. **What is PyRapide?**: 3-paragraph explanation — what it does, what RAPIDE is, why it matters for MCP servers and agentic AI systems.

3. **Quick Start**: pip install, then a 30-line complete example that:
   - Defines a simple interface with two actions.
   - Defines a simple architecture connecting two components.
   - Runs the architecture with the Engine.
   - Prints the resulting computation summary.
   - Checks a constraint.

4. **Core Concepts**: Brief explanation (2-3 sentences each) of:
   - Events and Causal History
   - Posets (Partially Ordered Event Sets)
   - Interfaces and Modules
   - Architectures and Connections
   - Event Patterns
   - Constraints and Monitoring
   - Streaming and MCP Integration

5. **MCP Integration Example**: 20-line example showing how to monitor MCP servers with PyRapide:
   - Set up MCPEventAdapter for two servers.
   - Define a constraint.
   - Run StreamProcessor.
   - Detect violations.

6. **API Reference**: Point to docstrings (or future Sphinx docs). List the main import paths.

7. **Architecture**: Brief description of the package structure and the 10 subpackages.

8. **Development**: How to set up dev environment, run tests, run type checks and linting.

9. **Based on RAPIDE 1.0**: Attribution to Stanford's RAPIDE work, link to original publications, note about David Luckham's "The Power of Events".

10. **License**: MIT placeholder.

Save as README.md in the project root.

Also create a brief CONTRIBUTING.md with development setup instructions and the test-first workflow.

VALIDATION: README.md exists and is well-formatted. All code examples in the README are syntactically valid Python (run them through `python -c "import ast; ast.parse(open('snippet.py').read())"` or similar check).
```

---

#### STARTHERE

## PROMPT 28 — Final Comprehensive Test Suite

```
Create the final comprehensive validation test suite for PyRapide.

This suite validates the ENTIRE library works as an integrated system. Create tests/test_final_validation.py.

This file should contain the following test functions. Each test must be self-contained (imports everything it needs from pyrapide). Each test exercises multiple subsystems together.

## Integration Tests

1. test_full_import:
   Import every public name from pyrapide. Assert none are None. Assert __version__ is "0.1.0".

2. test_event_lifecycle:
   Create Event -> Add to Poset -> Add to Computation -> Serialize -> Deserialize -> Assert equality.

3. test_interface_to_module_to_architecture:
   Define @interface with 3 actions. Define @module implementing it. Define @architecture using it. Instantiate architecture. Assert components exist and are correct types.

4. test_pattern_matching_on_live_computation:
   Build a computation with 20 events and complex causal structure. Define 5 different patterns (basic, sequence, join, independence, guarded). Assert each matches correctly.

5. test_constraint_enforcement_end_to_end:
   Define must_match and never constraints. Build a computation that satisfies must_match but violates never. Run constraint checker. Assert exactly one violation of the correct type.

6. test_engine_full_execution:
   Define complete architecture with 3 components, connections, and constraints. Run with Engine. Assert computation is non-empty, causal links are correct, no constraint violations.

7. test_streaming_processor_full:
   Create StreamProcessor with 3 InMemoryEventSources. Add pattern watches and constraints. Feed 50 events. Assert pattern matches detected, no constraint violations (for clean data).

8. test_mcp_integration_full:
   Create MCPEventAdapter (mock), stream events through StreamProcessor, check causal traceability from tool_call to tool_result.

9. test_analysis_pipeline:
   Build computation. Run queries (critical_path, root_causes, impact_set). Generate DOT visualization. Generate JSON export. Generate summary. Assert all return correct types and non-empty results.

10. test_prediction_pipeline:
    Train CausalPredictor on 5 computations. Predict from a partial computation. Assert predictions are non-empty and have reasonable confidence values.

11. test_anomaly_pipeline:
    Train AnomalyDetector on normal data. Feed anomalous computation. Assert anomalies detected.

12. test_clock_integration:
    Create RegularClock and SlavedClock. Stamp events. Assert temporal ordering is correct and consistent with causal ordering.

## Stress Tests

13. test_large_computation:
    Create computation with 5000 events in a complex DAG (mix of linear chains, diamonds, independent branches). Assert:
    - Poset operations (ancestors, descendants, is_ancestor) complete in under 10 seconds.
    - Serialization roundtrip works.
    - Visualization doesn't crash (may be truncated).

14. test_many_pattern_matches:
    Computation with 1000 events. Pattern that matches ~100 of them. Assert matching completes in under 5 seconds.

15. test_streaming_throughput:
    Stream 1000 events through StreamProcessor as fast as possible. Assert all events processed, total time under 10 seconds.

## Regression Guards

16. test_empty_everything:
    Empty computation, empty poset, empty pattern match against empty poset. Nothing crashes.

17. test_single_event_everything:
    One event in poset. All queries work. Visualization works. No crashes.

18. test_no_causal_edges:
    100 events, all independent (no causal links). Poset works. Pattern independence checks work. Visualization shows all as parallel.

Now run the COMPLETE test suite:

pytest tests/ -v --tb=short 2>&1 | tail -50

Report the total count of tests, how many passed, and how many failed. If any fail, fix them until all pass.

FINAL VALIDATION:
- `pytest tests/ -v` — ALL tests pass (0 failures).
- `pytest tests/ --tb=short -q` — print summary line showing total passed.
- `python -c "from pyrapide import *; print(f'PyRapide v{__version__} ready: {len(__all__)} exports')"` — prints version and export count.
- `mypy pyrapide/ --ignore-missing-imports` — no errors.
- `ruff check pyrapide/` — no errors.

Print "PyRapide build complete. All validations passed." when done.
```

---

## Summary Checklist

After completing all 29 prompts (0–28), you will have:

| Component | Prompt(s) | Test Files |
|---|---|---|
| Project scaffolding | 0 | — |
| Event primitives | 1 | test_event.py |
| Poset (DAG) | 2 | test_poset.py |
| Clock hierarchy | 3 | test_clock.py |
| Computation | 4 | test_computation.py |
| Interface/Action decorators | 5 | test_interface.py, test_actions.py |
| Services/Subtyping | 6 | test_services.py, test_subtyping.py |
| Basic patterns | 7 | test_basic_pattern.py |
| Composite patterns | 8 | test_composite_patterns.py |
| Guards/Macros/Timing | 9 | test_guards.py, test_macros.py, test_timing.py |
| Architecture decorator | 10 | test_architecture.py |
| Connections | 11 | test_connections.py |
| Communication/Maps/Bindings | 12 | test_communication.py, test_maps.py, test_bindings.py |
| Pattern constraints | 13 | test_pattern_constraints.py, test_filters.py |
| Constraint monitor | 14 | test_monitor.py, test_conformance.py |
| Module lifecycle | 15 | test_module.py |
| Reactive statements | 16 | test_reactive.py, test_process.py |
| Execution engine | 17 | test_engine.py |
| Streaming processor | 18 | test_streaming.py, test_serialization.py |
| MCP adapter | 19 | test_mcp_adapter.py, test_llm_adapter.py |
| Poset queries | 20 | test_queries.py |
| Visualization | 21 | test_visualization.py |
| Prediction/Anomaly | 22 | test_prediction.py, test_anomaly.py |
| Scenario: Producer-Consumer | 23 | test_producer_consumer.py |
| Scenario: MCP Multi-Server | 24 | test_mcp_multi_server.py |
| Scenario: Anomaly Detection | 25 | test_anomaly_detection.py |
| API cleanup | 26 | (regressions only) |
| README | 27 | (syntax checks) |
| **Final validation suite** | **28** | **test_final_validation.py** |

**Total estimated test count: 200–250 tests across 30+ test files.**
