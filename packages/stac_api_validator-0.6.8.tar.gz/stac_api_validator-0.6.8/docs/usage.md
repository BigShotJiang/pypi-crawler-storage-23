# Usage

```{eval-rst}
.. click:: stac_api_validator.__main__:main
    :prog: stac-api-validator
    :nested: full
```
