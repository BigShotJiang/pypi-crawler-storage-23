# stitch

Python package metadata for the STITCH CLI.

Project documentation lives in the repository root `README.md`.
