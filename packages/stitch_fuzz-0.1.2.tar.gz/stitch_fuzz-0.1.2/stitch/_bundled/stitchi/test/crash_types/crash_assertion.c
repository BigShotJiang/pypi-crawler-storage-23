#include <assert.h>

int main(void) {
    int x = 0;
    assert(x > 1);
    return 0;
}
