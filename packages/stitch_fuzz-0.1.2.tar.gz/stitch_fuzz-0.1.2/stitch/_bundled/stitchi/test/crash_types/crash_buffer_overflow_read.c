#include <stdio.h>
#include <stdlib.h>

int main(void) {
    char *buf = (char *)malloc(8);
    char x = buf[8];
    return 0;
}
