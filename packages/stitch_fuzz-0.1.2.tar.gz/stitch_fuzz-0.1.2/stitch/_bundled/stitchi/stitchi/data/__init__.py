"""Data models and metadata for stitchi."""
