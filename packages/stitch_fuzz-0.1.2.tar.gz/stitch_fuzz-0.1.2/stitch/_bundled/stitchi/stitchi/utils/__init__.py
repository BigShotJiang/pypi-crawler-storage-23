"""Utility helpers for stitchi."""
