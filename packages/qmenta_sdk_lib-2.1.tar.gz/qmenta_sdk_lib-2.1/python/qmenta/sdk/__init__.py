__version__ = "{version}"  # This is filled by CI at build time (also used for documentation)
