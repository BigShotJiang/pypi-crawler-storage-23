import os

from analogai.deepthink.thinker import DeepThinker
from analogai.deepthink.infrastructure.gateways.llm.enums.llm_provider import LlmProvider


thinker = DeepThinker(
    llm_provider=LlmProvider.AZURE,
    llm_model="gpt-4o-mini",
)


if __name__ == "__main__":
    while True:
        message = input("Message: ")
        result = thinker.chat(message)
        print(result if result else "(no response)")
