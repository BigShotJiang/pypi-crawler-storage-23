                                                          
                                                                                                 
import sys
from pathlib import Path

                                         
parent_dir = Path(__file__).parent.parent

                                       
import importlib.util
config_file = parent_dir / 'config.py'
spec = importlib.util.spec_from_file_location("application.config_module", str(config_file))
config_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(config_module)

                                             
__all__ = []
for attr_name in dir(config_module):
    if not attr_name.startswith('_'):
        globals()[attr_name] = vars(config_module)[attr_name]
        __all__.append(attr_name)



