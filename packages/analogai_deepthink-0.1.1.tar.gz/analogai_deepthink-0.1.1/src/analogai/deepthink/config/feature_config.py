from dataclasses import dataclass


@dataclass(frozen=True)
class FeatureConfig:
    notion_enrichment_enabled: bool = True
    # statement_decomposition_enabled: bool = False

    @classmethod
    def from_environment(cls) -> "FeatureConfig":
        import analogai.deepthink.config as app_config
        return cls(
            notion_enrichment_enabled=app_config.NOTION_ENRICHMENT_ENABLED,
            # statement_decomposition_enabled=app_config.STATEMENT_DECOMPOSITION_ENABLED
        )
