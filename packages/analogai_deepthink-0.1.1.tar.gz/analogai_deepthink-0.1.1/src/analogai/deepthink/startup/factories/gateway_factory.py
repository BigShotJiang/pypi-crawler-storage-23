from enum import Enum


class PromptFileName(Enum):
    pass


