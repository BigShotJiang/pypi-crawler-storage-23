from __future__ import annotations

from typing import Optional

from analogai.foundation.setup.factories.agent_service_factory import AgentServiceFactory
from analogai.foundation.setup.factories.belief_service_factory import BeliefServiceFactory
from analogai.foundation.setup.factories.categorical_deduction_service_factory import (
    CategoricalDeductionServiceFactory,
)
from analogai.foundation.setup.factories.conditional_deduction_service_factory import (
    ConditionalDeductionServiceFactory,
)
from analogai.foundation.setup.factories.hypothetical_statement_service_factory import (
    HypotheticalStatementServiceFactory,
)
from analogai.foundation.setup.factories.notion_service_factory import NotionServiceFactory
try:
    from analogai.foundation.setup.factories.direct_statement_service_factory import (  # type: ignore[import-not-found]
        DirectStatementServiceFactory,
    )
except ImportError:  # fallback for older foundation naming
    from analogai.foundation.setup.factories.statement_service_factory import (
        StatementServiceFactory as DirectStatementServiceFactory,
    )
from analogai.foundation.setup.factories.user_service_factory import UserServiceFactory


class DomainServiceFactory:
    def __init__(self):
        self._user_service = None
        self._agent_service = None
        self._notion_service = None
        self._direct_statement_service = None
        self._belief_service = None
        self._categorical_deduction_service = None
        self._conditional_deduction_service = None
        self._hypothetical_statement_service = None

    def get_user_service(self):
        if self._user_service is None:
            self._user_service = UserServiceFactory().get_service()
        return self._user_service

    def get_agent_service(self):
        if self._agent_service is None:
            self._agent_service = AgentServiceFactory().get_service()
        return self._agent_service

    def get_notion_service(self):
        if self._notion_service is None:
            self._notion_service = NotionServiceFactory().get_service()
        return self._notion_service

    def get_direct_statement_service(self):
        if self._direct_statement_service is None:
            self._direct_statement_service = DirectStatementServiceFactory().get_service()
        return self._direct_statement_service

    def get_statement_service(self):
        return self.get_direct_statement_service()

    def get_belief_service(self):
        if self._belief_service is None:
            self._belief_service = BeliefServiceFactory(
                notion_service=self.get_notion_service(),
            ).get_service()
            self._wire_deduction_services()
        return self._belief_service

    def get_deductive_inference_service(self):
        if self._categorical_deduction_service is None:
            self._categorical_deduction_service = CategoricalDeductionServiceFactory(
                belief_service=self.get_belief_service(),
            ).get_service()
        return self._categorical_deduction_service

    def get_conditional_deduction_service(self):
        if self._conditional_deduction_service is None:
            self._conditional_deduction_service = ConditionalDeductionServiceFactory(
                belief_service=self.get_belief_service(),
            ).get_service()
        return self._conditional_deduction_service

    def get_conditional_statement_service(self):
        return self.get_hypothetical_statement_service()

    def get_hypothetical_statement_service(self):
        if self._hypothetical_statement_service is None:
            self._hypothetical_statement_service = HypotheticalStatementServiceFactory().get_service()
        return self._hypothetical_statement_service

    def _wire_deduction_services(self) -> None:
        belief_service = self._belief_service
        if belief_service is None:
            return
        belief_service.set_categorical_deduction_service(
            self.get_deductive_inference_service()
        )
        belief_service.set_conditional_deduction_service(
            self.get_conditional_deduction_service()
        )
