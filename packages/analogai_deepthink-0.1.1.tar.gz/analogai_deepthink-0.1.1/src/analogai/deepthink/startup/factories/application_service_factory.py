from analogai.deepthink.startup.factories.domain_service_factory import DomainServiceFactory
from analogai.foundation.common.enums.environment import Environment


class ApplicationServiceFactory:
    

    def __init__(
        self,
        domain_service_factory: DomainServiceFactory,
        env: Environment,
    ):
        self._domain_service_factory = domain_service_factory
        self._env = env
        self._extensions_factory = None
        self._expression_factory = None

    def _get_extensions_factory(self):
        if self._extensions_factory is None:
            from analogai.deepthink.startup.extensions_service_factory import ExtensionsServiceFactory

            self._extensions_factory = ExtensionsServiceFactory(
                self._domain_service_factory,
                self._env,
            )
        return self._extensions_factory

    def get_conversation_service(self):
        return self._get_extensions_factory().get_conversation_service()

    def get_statement_derivation_service(self):
        return self._get_extensions_factory().get_statement_derivation_service()

    def get_belief_query_service(self):
        return self._get_extensions_factory().get_belief_query_service()

    def get_expression_factory(self):
        if self._expression_factory is None:
            from analogai.foundation.common.utils.expression_factory import ExpressionFactory
            self._expression_factory = ExpressionFactory()
        return self._expression_factory

    def initialize(self):
        pass
