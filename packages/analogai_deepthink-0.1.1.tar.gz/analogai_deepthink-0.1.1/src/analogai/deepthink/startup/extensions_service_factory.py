from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from analogai.deepthink.startup.factories.domain_service_factory import DomainServiceFactory


class ExtensionsServiceFactory:
    def __init__(
        self,
        domain_service_factory: "DomainServiceFactory",
        env=None,
        config: Optional[object] = None,
    ):
        self._domain_service_factory = domain_service_factory
        self._env = env
        self._config = config
        self._conversation_service = None
        self._authorization_factory = None


    def get_conversation_service(self):
        if self._conversation_service is None:
            from analogai.foundation.extensions.conversation.factories.conversation_service_factory import (
                ConversationServiceFactory,
            )

            self._conversation_service = ConversationServiceFactory().create()
        return self._conversation_service


    def get_authorization_factory(self):
        if self._authorization_factory is None:
            from analogai.foundation.extensions.authorization.authorization_factory import AuthorizationFactory

            self._authorization_factory = AuthorizationFactory()
        return self._authorization_factory


    def get_belief_query_service(self):
        return _create_belief_query_service(self._domain_service_factory)

    def get_statement_derivation_service(self):
        return _create_statement_derivation_service(self._domain_service_factory)


def _create_belief_query_service(domain_service_factory: "DomainServiceFactory"):
    belief_service = domain_service_factory.get_belief_service()
    from analogai.foundation.setup.factories.belief_query_service_factory import (
        BeliefQueryServiceFactory,
    )

    return BeliefQueryServiceFactory(
        belief_service=belief_service,
    ).get_service()


def _create_statement_derivation_service(domain_service_factory: "DomainServiceFactory"):
    return domain_service_factory.get_direct_statement_service()
