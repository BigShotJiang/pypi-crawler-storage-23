from analogai.foundation.common.logging.app_logger import app_logger

class InsufficientAuthorityError(ValueError):
    def __init__(self, message: str = "Insufficient authority to perform this operation"):
        super().__init__(message)
        app_logger.warning(message)



