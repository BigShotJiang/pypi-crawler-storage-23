from typing import Optional

from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects import Relation
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.value_objects.user_agent import UserAgent


class LearnerContext:
    def __init__(self):
        self.user_agent: UserAgent | None = None
        self.subject_notion = None
        self.complement_notion = None
        self.subject_notion_expression: NotionExpression | None = None
        self.complement_notion_expression: NotionExpression | None = None
        self.relation: Optional[Relation] = None
        self.proposed_probability = None
        self.proposed_validity = None
        self.proposed_quantity: Optional[float] = None
        self.statement = None
        self.modifier: Optional[Modifier] = None
        self.statement_name: Optional[str] = None
        self.complement_caption_rest: Optional[str] = None
