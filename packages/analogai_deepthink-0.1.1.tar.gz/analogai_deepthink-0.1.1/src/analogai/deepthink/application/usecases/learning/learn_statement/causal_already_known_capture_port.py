from analogai.deepthink.application.usecases.learning.make_direct_statement.ports import MakeStatementOutputPort
from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse


class CausalAlreadyKnownCapturePort(MakeStatementOutputPort):
    def __init__(self, inner: MakeStatementOutputPort):
        self._inner = inner
        self.already_known = False

    def output_create_statement_success(self, response: MakeDirectStatementResponse):
        self.already_known = False
        return self._inner.output_create_statement_success(response)

    def output_statement_already_known(self, response: MakeDirectStatementResponse):
        self.already_known = True
        return self._inner.output_statement_already_known(response)

    def output_statement_update_success(self, response: MakeDirectStatementResponse):
        self.already_known = False
        return self._inner.output_statement_update_success(response)

    def output_update_not_applicable(self, response: MakeDirectStatementResponse):
        self.already_known = False
        return self._inner.output_update_not_applicable(response)

    def output_forbidden(self, response: MakeDirectStatementResponse):
        self.already_known = False
        return self._inner.output_forbidden(response)

