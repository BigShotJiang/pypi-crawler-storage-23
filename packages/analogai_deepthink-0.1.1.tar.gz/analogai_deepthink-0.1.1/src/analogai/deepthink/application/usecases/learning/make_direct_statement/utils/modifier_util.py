def times_match(time1, time2) -> bool:
    if time1 is None and time2 is None:
        return True
    if time1 is None or time2 is None:
        return False
    return (
        time1.year == time2.year
        and time1.month == time2.month
        and time1.day == time2.day
        and time1.hour == time2.hour
        and time1.minute == time2.minute
    )


def modifiers_match(modal1, modal2) -> bool:
    if modal1 is None and modal2 is None:
        return True
    if modal1 is None or modal2 is None:
        return False
    if modal1.location != modal2.location:
        return False
    if modal1.deontic_modality != modal2.deontic_modality:
        return False
    if not times_match(modal1.from_time, modal2.from_time):
        return False
    if not times_match(modal1.to_time, modal2.to_time):
        return False
    return True
