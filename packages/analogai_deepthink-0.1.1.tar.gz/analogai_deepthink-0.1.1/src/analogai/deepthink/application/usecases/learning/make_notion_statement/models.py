from typing import Optional

from pydantic import BaseModel, ConfigDict
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.value_objects.user_agent import UserAgent


class MakeNotionStatementRequest(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    notion_expression: NotionExpression


class MakeNotionStatementResponse(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    notion_expression: NotionExpression
    saved: bool = True


MakeNotionStatementRequest.model_rebuild()
MakeNotionStatementResponse.model_rebuild()
