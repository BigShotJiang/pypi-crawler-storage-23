from abc import ABC, abstractmethod
from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse, MakeDirectStatementRequest


class LearnInputPort(ABC):
    @abstractmethod
    def execute(self, request: MakeDirectStatementRequest):
        pass


class MakeStatementOutputPort(ABC):
    @abstractmethod
    def output_create_statement_success(self, response: MakeDirectStatementResponse) -> object | None:
        pass

    @abstractmethod
    def output_statement_already_known(self, response: MakeDirectStatementResponse) -> object | None:
        pass

    @abstractmethod
    def output_statement_update_success(self, response: MakeDirectStatementResponse) -> object | None:
        pass

    @abstractmethod
    def output_update_not_applicable(self, response: MakeDirectStatementResponse) -> object | None:
        pass

    @abstractmethod
    def output_forbidden(self, response: MakeDirectStatementResponse) -> object | None:
        pass
