from abc import ABC, abstractmethod
from analogai.deepthink.application.usecases.learning.make_conditional_statement.models import (
    MakeConditionalStatementRequest,
    MakeConditionalStatementResponse,
)


class MakeConditionalStatementInputPort(ABC):
    @abstractmethod
    def execute(self, request: MakeConditionalStatementRequest):
        pass


class MakeConditionalStatementOutputPort(ABC):
    @abstractmethod
    def output_create_statement_success(self, response: MakeConditionalStatementResponse) -> object | None:
        pass

    @abstractmethod
    def output_forbidden(self, response: MakeConditionalStatementResponse) -> object | None:
        pass
