from abc import ABC, abstractmethod
from analogai.deepthink.application.usecases.learning.learn_statement.models import LearnStatementRequest


class LearnStatementInputPort(ABC):
    @abstractmethod
    def execute(self, request: LearnStatementRequest):
        pass


class LearnStatementOutputPort(ABC):
    pass
