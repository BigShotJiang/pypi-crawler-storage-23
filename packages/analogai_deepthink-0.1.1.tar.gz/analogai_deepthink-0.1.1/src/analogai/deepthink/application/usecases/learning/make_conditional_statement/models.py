from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field
from analogai.foundation.common.enums.certainty import Certainty
from analogai.foundation.common.dtos.belief_expression import BeliefExpression
from analogai.deepthink.application.value_objects.user_agent import UserAgent


class CriterionValue(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    tag: str
    value: Optional[float] = None
    unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None


class CriterionData(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    subject_caption: str
    complement_caption: Optional[str] = None
    relation: Optional[str] = None
    location: Optional[str] = None
    time: Optional[str] = None
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    quantity: Optional[float] = None
    deontic_modality: Optional[str] = None
    certainty: Optional[Certainty] = None
    attribute_values: list[CriterionValue] = Field(default_factory=list)


class CauseCriteria(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    criteria: CriterionData


class MakeConditionalStatementRequest(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    probability: float
    causes: list[CauseCriteria]
    effect: CauseCriteria


class MakeConditionalStatementResponse(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    belief_expression: BeliefExpression
    causes: list[CauseCriteria]
    effect: CauseCriteria
    probability: float
    validity: float = 1.0
    effect_belief_id: Optional[str] = None


MakeConditionalStatementRequest.model_rebuild()
MakeConditionalStatementResponse.model_rebuild()
