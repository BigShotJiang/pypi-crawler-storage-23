from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementRequest
from .learner_context import LearnerContext
from analogai.foundation.modules.notion.notion_service import NotionService
from analogai.deepthink.application.exceptions.authority_exceptions import InsufficientAuthorityError


class LearnerContextHandler:
    def __init__(self, context: LearnerContext, notion_service: NotionService):
        self.context = context
        self.notion_service = notion_service
        self.request = None

    def reset(self):
        self.context.subject_notion = None
        self.context.complement_notion = None
        self.context.subject_notion_expression = None
        self.context.complement_notion_expression = None
        self.context.relation = None
        self.context.proposed_probability = None
        self.context.proposed_validity = None
        self.context.proposed_quantity = None
        self.context.user_agent = None
        self.context.statement_name = None
        self.context.complement_caption_rest = None
        self.request = None

    def create_from_request(self, request: MakeDirectStatementRequest):
        if request.user_agent.user_authority == 0.0:
            raise InsufficientAuthorityError(f"User {request.user_agent.user_id} attempted to make a statement with 0 authority")

        self.request = request
        self.context.user_agent = request.user_agent
        self.context.subject_notion_expression = request.subject_notion_expression
        self.context.complement_notion_expression = request.complement_notion_expression
        self.context.subject_notion = self.notion_service.find_or_create(request.user_agent.user_id, request.user_agent.agent_id, request.subject_notion_expression)
        self._notify_notion_created(self.context.subject_notion)
        self.context.complement_notion = self.notion_service.find_or_create(request.user_agent.user_id, request.user_agent.agent_id, request.complement_notion_expression)
        self._notify_notion_created(self.context.complement_notion)
        self.context.relation = request.relation
        self.context.proposed_probability = request.probability
        self.context.proposed_validity = self._get_proposed_validity()
        self.context.proposed_quantity = None
        modifier = request.modifier
        if request.quantity is not None:
            if modifier is None:
                from analogai.foundation.core.value_objects.modifier import Modifier
                modifier = Modifier(quantity=request.quantity)
            else:
                modifier.quantity = request.quantity
        self.context.modifier = modifier
        self.context.statement_name = request.statement_name
        self.context.complement_caption_rest = request.complement_caption_rest
        return self.context

    def _notify_notion_created(self, notion) -> None:
        if notion is None:
            return
        try:
            from analogai.deepthink.config import NOTION_ENRICHMENT_ENABLED
            if not NOTION_ENRICHMENT_ENABLED:
                return
            from analogai.deepthink.features.notion_enrichment.registry import get_notion_enrichment_observer
            observer = get_notion_enrichment_observer()
            if observer is None:
                return
            observer.on_notion_created(notion)
        except Exception:
            return

    def _get_proposed_validity(self):
        return max(self.context.user_agent.user_authority, 0.1)

