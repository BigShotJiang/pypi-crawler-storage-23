from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects import Relation
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.value_objects.user_agent import UserAgent
from enum import Enum


class Attribute(BaseModel):
    tag: str
    values: List[float] = Field(default_factory=list)
    unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None


class StatementType(str, Enum):
    SIMPLE = "simple"
    ATTRIBUTE_QUANTITY = "attribute_quantity"
    NOTION_ATTRIBUTE = "notion_attribute"


class LearnStatementRequest(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")
    
    user_agent: UserAgent
    statement_type: StatementType
    subject: NotionExpression
    complement: Optional[NotionExpression] = None
    relation: Optional[Relation] = None
    probability: Optional[float] = None
    modifier: Optional[Modifier] = None
    attributes: List[Attribute] = Field(default_factory=list)
    quantity: Optional[float] = None
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    location: Optional[str] = None
    deontic_modality: Optional[str] = None
