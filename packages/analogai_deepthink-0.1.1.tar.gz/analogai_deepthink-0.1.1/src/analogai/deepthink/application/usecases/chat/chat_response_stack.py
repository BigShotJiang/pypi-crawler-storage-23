from collections import deque
from analogai.foundation.common.logging.app_logger import app_logger
from analogai.foundation.modules.belief.belief import Belief

class ChatResponseStack:
    MAX_SIZE = 5
    
    def __init__(self):
        self._responses = deque(maxlen=self.MAX_SIZE)
        
    def add(self, response: Belief) -> None:
        if response is None:
            app_logger.warning("Attempted to add None to response stack")
            return
        app_logger.info("Adding belief to response stack")
        self._responses.append(response)
            
    def get_latest(self) -> Belief | None:
        if not self._responses:
            app_logger.warning("No items at response stack to return")
            return None
        return self._responses[-1]

    def get_size(self) -> int:
        return len(self._responses)
    
    def get_all(self) -> deque:
        return self._responses
    
    def clear(self) -> None:
        self._responses = deque(maxlen=self.MAX_SIZE)


