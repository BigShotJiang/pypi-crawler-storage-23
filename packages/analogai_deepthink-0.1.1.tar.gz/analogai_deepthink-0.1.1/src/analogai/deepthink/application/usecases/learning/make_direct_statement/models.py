from typing import Optional

from pydantic import BaseModel, ConfigDict
from analogai.foundation.common.dtos.belief_expression import Modifier, Relation
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.common.dtos.belief_expression import BeliefExpression
from analogai.deepthink.application.value_objects.user_agent import UserAgent


class MakeDirectStatementRequest(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    subject_notion_expression: NotionExpression
    complement_notion_expression: NotionExpression
    relation: Relation
    probability: float
    modifier: Optional[Modifier] = None
    quantity: Optional[float] = None
    statement_name: Optional[str] = None
    complement_caption_rest: Optional[str] = None


class MakeDirectStatementResponse(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

    user_agent: UserAgent
    belief_expression: BeliefExpression


MakeDirectStatementRequest.model_rebuild()
MakeDirectStatementResponse.model_rebuild()
