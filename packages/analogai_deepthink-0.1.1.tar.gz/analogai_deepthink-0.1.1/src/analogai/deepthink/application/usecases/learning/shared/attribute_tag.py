from enum import Enum


class AttributeTag(Enum):
    COST = "cost"
    PRICE = "price"
    QUANTITY = "quantity"
    WEIGHT = "weight"
    HEIGHT = "height"
    WIDTH = "width"
    LENGTH = "length"
    DEPTH = "depth"
    AREA = "area"
    DISTANCE = "distance"
    COLOR = "color"