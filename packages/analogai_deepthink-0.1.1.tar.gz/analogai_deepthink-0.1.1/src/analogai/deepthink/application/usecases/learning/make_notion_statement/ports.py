from typing import Protocol

from analogai.deepthink.application.usecases.learning.make_notion_statement.models import MakeNotionStatementResponse
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class MakeNotionStatementOutputPort(Protocol):
    def output_notion_statement_saved(
        self,
        response: MakeNotionStatementResponse,
    ) -> PresenterResponse | None:
        ...
