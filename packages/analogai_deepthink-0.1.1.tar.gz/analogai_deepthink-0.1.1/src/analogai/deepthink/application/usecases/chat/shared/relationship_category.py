from enum import Enum


class RelationshipCategory(Enum):
    WHAT = "what"
    WHERE = "where"
    HOW = "how"
    WHY = "why"
    WHO = "who"
    WHEN = "when"
    WHICH = "which"
    HOW_MANY = "how many"
    HOW_MUCH = "how much"
    DISTANCE = "distance"
    CAN = "can"
    ORIGIN = "origin"
    SIMPLE = "simple"
    GENERAL = "general"
    UNCATEGORIZED = "uncategorized"
