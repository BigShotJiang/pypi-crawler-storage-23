from analogai.foundation.common.dtos.belief_expression import BeliefExpression
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse
from analogai.foundation.common.utils.expression_factory import ExpressionFactory


class LearnerResponseBuilder:
    def __init__(self, context):
        self.context = context
        self._expression_factory = ExpressionFactory()

    def build_response(self, probability=None):
        if self.context.statement:
            belief_expression = self._expression_factory.propagate_belief_expression(self.context.statement)
        else:
            subject_notion_expression = self._express_notion(self.context.subject_notion) if self.context.subject_notion else self.context.subject_notion_expression
            complement_notion_expression = self._express_notion(self.context.complement_notion) if self.context.complement_notion else self.context.complement_notion_expression
            if probability is not None:
                response_probability = probability
            else:
                response_probability = self.context.proposed_probability

            relation = self.context.relation
            belief_expression = BeliefExpression(
                subject_notion_expression=subject_notion_expression,
                complement_notion_expression=complement_notion_expression,
                relation=relation,
                probability=response_probability,
                validity=1.0,
                modifier=self.context.modifier,
            )

        return MakeDirectStatementResponse(
            user_agent=self.context.user_agent,
            belief_expression=belief_expression
        )

    def _express_notion(self, notion):
        from analogai.deepthink.application.utils.notion_expresser_util import generate_expression
        return generate_expression(notion)

