import unittest
from analogai.deepthink.application.value_objects.user_agent import UserAgent


class TestUserAgent(unittest.TestCase):
    
    def test_build_context_id_returns_correct_format(self):
        user_agent = UserAgent(
            user_id="user123",
            agent_id="agent456",
            user_authority=0.5
        )
        result = user_agent.build_context_id()
        self.assertEqual(result, "user123:agent456")
    
    def test_build_context_id_with_different_ids(self):
        user_agent = UserAgent(
            user_id="test_user",
            agent_id="test_agent",
            user_authority=0.5
        )
        result = user_agent.build_context_id()
        self.assertEqual(result, "test_user:test_agent")
    
    def test_user_agent_with_optional_agent_name(self):
        user_agent = UserAgent(
            user_id="u1",
            agent_id="a1",
            user_authority=0.5,
            agent_name="MyAgent"
        )
        self.assertEqual(user_agent.agent_name, "MyAgent")
    
    def test_user_agent_without_optional_agent_name(self):
        user_agent = UserAgent(
            user_id="u1",
            agent_id="a1",
            user_authority=0.5
        )
        self.assertIsNone(user_agent.agent_name)
if __name__ == "__main__":
    unittest.main()

