import unittest
from analogai.foundation.common.enums import RelationshipType
from analogai.deepthink.application.usecases.chat.shared.relationship_category import RelationshipCategory
from analogai.deepthink.application.usecases.chat.utils.relationship_categorizer_util import RelationshipCategorizer

class TestRelationshipCategorizer(unittest.TestCase):
    def setUp(self):
        self.categorizer = RelationshipCategorizer()


    def test_origin_relationships(self):
        origin_relationships = self.categorizer.get_origin_relationships()

        self.assertIn(RelationshipType.DERIVED_FROM, origin_relationships)
        self.assertIn(RelationshipType.ETYMOLOGICALLY_RELATED_TO, origin_relationships)
        self.assertIn(RelationshipType.ETYMOLOGICALLY_DERIVED_FROM, origin_relationships)

        self.assertNotIn(RelationshipType.IS_A, origin_relationships)


    def test_relationship_categorization_completeness(self):
        all_relationships = set().union(
            self.categorizer.get_what_relationships(),
            self.categorizer.get_where_relationships(),
            self.categorizer.get_how_relationships(),
            self.categorizer.get_why_relationships(),
            self.categorizer.get_who_relationships(),
            self.categorizer.get_origin_relationships()
        )

        for relationship_type in RelationshipType:
            category = self.categorizer.get_category_for_relationship(relationship_type.value)
            self.assertIsNotNone(category, f"Relationship {relationship_type} should be categorized")
            if relationship_type in all_relationships:
                self.assertNotEqual(category, RelationshipCategory.UNCATEGORIZED,
                                   f"Relationship {relationship_type} should not be uncategorized")

if __name__ == '__main__':
    unittest.main() 



