from dataclasses import dataclass
from typing import Optional

@dataclass
class UserAgent:
    user_id: str
    agent_id: str
    user_authority: float
    agent_name: Optional[str] = None
    timezone: Optional[str] = None
    
    def build_state_id(self) -> str:
        return f"{self.user_id}:{self.agent_id}"
    
    def build_context_id(self) -> str:
        return f"{self.user_id}:{self.agent_id}"


