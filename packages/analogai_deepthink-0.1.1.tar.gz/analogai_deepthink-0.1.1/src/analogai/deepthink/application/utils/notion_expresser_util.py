from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.common.dtos.notion_expression import NotionExpression


def generate_expression(notion: Notion):
    attributes = getattr(notion, "attributes", None)
    return NotionExpression(caption=notion.caption, attributes=attributes)


