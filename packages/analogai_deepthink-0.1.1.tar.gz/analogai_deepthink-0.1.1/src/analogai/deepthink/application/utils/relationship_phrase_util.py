from analogai.foundation.common.enums import RelationshipType
from analogai.foundation.core.value_objects.relation import Relation
_SEMANTIC_RELATIONS = frozenset(
    Relation.from_type(rt) for rt in RelationshipType if rt != RelationshipType.DO
)


def is_semantic_relationship(relation: Relation) -> bool:
    if not relation:
        return False
    return relation in _SEMANTIC_RELATIONS
