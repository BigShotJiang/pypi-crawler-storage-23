from typing import Any, Optional
from analogai.foundation.common.enums.criterion import Criterion


def apply_modifier(builder: Any, modifier: Optional[object]) -> Any:
    if modifier is None:
        return builder
    location = modifier.location
    if location is not None and str(location).strip():
        builder.where(Criterion.Location, str(location).strip())
    from_time = modifier.from_time
    to_time = modifier.to_time
    if from_time is not None or to_time is not None:
        builder.whereNotNull(Criterion.Time)
        if from_time is not None:
            builder.whereMin(Criterion.Time, from_time)
        if to_time is not None:
            builder.whereMax(Criterion.Time, to_time)
    deontic = modifier.deontic_modality
    if deontic is not None:
        builder.where(Criterion.DeonticModality, deontic)
    return builder
