from analogai.deepthink.config import PROBABILITY_THRESHOLD

def check_update_statement_applicable(existing_probability, proposed_probability, existing_validity, proposed_validity):
	probability_is_different = False
	has_enough_validity = False
	if abs(existing_probability - proposed_probability) > PROBABILITY_THRESHOLD:
		probability_is_different = True
	if proposed_validity >= existing_validity:
		has_enough_validity = True
	return probability_is_different and has_enough_validity



