def stringify_statement(statement):
    return f"{statement.subject_notion.caption} -> {statement.relationship_type} -> {statement.complement_notion.caption} ({statement.probability}). validity: {statement.validity}"



