from threading import Lock
from typing import List

from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse


class LearningResponseStack:
    def __init__(self) -> None:
        self._stack: List[MakeDirectStatementResponse] = []
        self._lock = Lock()

    def push(self, response: MakeDirectStatementResponse) -> None:
        with self._lock:
            self._stack.append(response)

    def get_all(self) -> List[MakeDirectStatementResponse]:
        with self._lock:
            return list(self._stack)

    def clear(self) -> None:
        with self._lock:
            self._stack.clear()

    def size(self) -> int:
        with self._lock:
            return len(self._stack)

