import os
from dotenv import load_dotenv

load_dotenv()

ENVIRONMENT = os.getenv('ENVIRONMENT', 'production')

def get_int_env(key: str, default: int) -> int:
    value = os.getenv(key)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default

def get_float_env(key: str, default: float) -> float:
    value = os.getenv(key)
    if value is None:
        return default    
    try:
        return float(value)
    except ValueError:
        return default

MONGODB_URI = os.getenv('MONGODB_URI', '')
MONGODB_DATABASE = os.getenv('MONGODB_DATABASE', '')

                                        
                                          
                                                  
                                                  
                                                                                
                                                                                
                                                                     
                                                                               

                                                      
                                                             
                                                     
                                                             
                                                                                     


                                                  
                                                               
                                                                                    



