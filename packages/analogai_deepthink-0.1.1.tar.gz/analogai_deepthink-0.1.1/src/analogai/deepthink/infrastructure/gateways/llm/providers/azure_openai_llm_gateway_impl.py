from typing import AsyncGenerator

from openai import AzureOpenAI

from analogai.deepthink.infrastructure.gateways.llm import config
from analogai.deepthink.infrastructure.gateways.llm.gateway import LlmGateway


class AzureOpenaiLlmGatewayImpl(LlmGateway):
    def __init__(
        self,
        system_prompt: str | None = None,
        max_tokens: int = 300,
        model: str | None = None,
        azure_client: AzureOpenAI | None = None,
        api_version: str | None = None,
    ):
        api_key = config.AZURE_OPENAI_API_KEY
        endpoint = config.AZURE_OPENAI_ENDPOINT
        if not api_key:
            raise ValueError("AZURE_OPENAI_API_KEY must be set for Azure OpenAI gateway")
        if not endpoint:
            raise ValueError("AZURE_OPENAI_ENDPOINT must be set for Azure OpenAI gateway")
        if not model:
            raise ValueError("Model name must be provided for Azure OpenAI gateway")
        self.model = model
        self.default_system_prompt = system_prompt or ""
        self.default_max_tokens = min(max_tokens, 300)
        self.client = azure_client or AzureOpenAI(
            api_version=api_version or "2024-12-01-preview",
            azure_endpoint=endpoint,
            api_key=api_key,
        )

    def set_model(self, model: str) -> None:
        self.model = model

    def set_system_prompt(self, system_prompt: str) -> None:
        self.default_system_prompt = system_prompt

    def generate_completion(
        self,
        user_message: str,
    ) -> str:
        final_system_prompt = self.default_system_prompt
        max_completion_tokens = self.default_max_tokens
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": final_system_prompt},
                {"role": "user", "content": user_message},
            ],
            max_completion_tokens=max_completion_tokens,
            temperature=1.0,
            top_p=1.0,
        )
        return response.choices[0].message.content.strip()

    async def generate_streaming_completion(
        self,
        user_message: str,
    ) -> AsyncGenerator:
        final_system_prompt = self.default_system_prompt
        max_completion_tokens = self.default_max_tokens
        stream = self.client.chat.completions.create(
            stream=True,
            model=self.model,
            messages=[
                {"role": "system", "content": final_system_prompt},
                {"role": "user", "content": user_message},
            ],
            max_completion_tokens=max_completion_tokens,
            temperature=1.0,
            top_p=1.0,
        )
        for chunk in stream:
            yield chunk

    def close(self) -> None:
        try:
            self.client.close()
        except AttributeError:
            pass


if __name__ == "__main__":
    gateway = AzureOpenaiLlmGatewayImpl(model="gpt-5.2-chat")
    result = gateway.generate_completion("Hello, how are you?")
    print(result)