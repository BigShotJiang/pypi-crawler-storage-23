from typing import Optional, Dict, Type

from analogai.deepthink.config import DEFAULT_LLM_GATEWAY_TYPE
from analogai.deepthink.infrastructure.gateways.llm.enums.llm_gateway_type import LlmGatewayType
from analogai.deepthink.infrastructure.gateways.llm.gateway import LlmGateway
from analogai.deepthink.infrastructure.gateways.llm.providers.anthropic_llm_gateway_impl import AnthropicLlmGatewayImpl
from analogai.deepthink.infrastructure.gateways.llm.providers.bedrock_llm_gateway_impl import BedrockLlmGatewayImpl
from analogai.deepthink.infrastructure.gateways.llm.providers.openai_llm_gateway_impl import OpenaiLlmGatewayImpl
from analogai.deepthink.infrastructure.gateways.llm.providers.azure_llm_gateway_impl import AzureLlmGatewayImpl
from analogai.deepthink.infrastructure.gateways.llm.providers.azure_openai_llm_gateway_impl import AzureOpenaiLlmGatewayImpl
from analogai.deepthink.infrastructure.gateways.llm.providers.xai_llm_gateway_impl import XaiLlmGatewayImpl


_GATEWAY_REGISTRY: Dict[LlmGatewayType, Type[LlmGateway]] = {
    LlmGatewayType.ANTHROPIC: AnthropicLlmGatewayImpl,
    LlmGatewayType.OPENAI: OpenaiLlmGatewayImpl,
    LlmGatewayType.AZURE: AzureLlmGatewayImpl,
    LlmGatewayType.AZURE_OPENAI: AzureOpenaiLlmGatewayImpl,
    LlmGatewayType.GROK: XaiLlmGatewayImpl,
    LlmGatewayType.BEDROCK: BedrockLlmGatewayImpl,
}


class LlmGatewayProviderFactory:
    _default_gateway_type: Optional[LlmGatewayType] = DEFAULT_LLM_GATEWAY_TYPE
    _default_model: Optional[str] = None

    @classmethod
    def set_default_gateway_type(cls, gateway_type: LlmGatewayType) -> None:
        cls._default_gateway_type = gateway_type

    @classmethod
    def get_default_gateway_type(cls) -> LlmGatewayType:
        if cls._default_gateway_type is None:
            raise ValueError("LLM gateway type must be provided; defaults are disabled")
        return cls._default_gateway_type

    @classmethod
    def set_default_model(cls, model: Optional[str]) -> None:
        cls._default_model = model

    @classmethod
    def get_default_model(cls) -> Optional[str]:
        return cls._default_model

    @classmethod
    def create_gateway(
        cls,
        gateway_type: Optional[LlmGatewayType] = None,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
    ) -> LlmGateway:
        resolved_type = gateway_type or cls._default_gateway_type
        if resolved_type is None:
            raise ValueError("LLM gateway type must be provided; defaults are disabled")
        resolved_model = model or cls._default_model
        if not resolved_model:
            raise ValueError("Model name must be provided when creating an LLM gateway")
        kwargs: Dict[str, object] = {}
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        kwargs["model"] = resolved_model

        gateway_cls = _GATEWAY_REGISTRY.get(resolved_type)
        if gateway_cls is None:
            raise ValueError(f"Unsupported LLM gateway type: {resolved_type}")
        gateway = gateway_cls(**kwargs)
        if system_prompt is not None:
            gateway.set_system_prompt(system_prompt)
        return gateway
