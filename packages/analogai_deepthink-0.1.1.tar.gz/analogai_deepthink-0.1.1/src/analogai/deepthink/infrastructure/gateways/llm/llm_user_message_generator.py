from typing import List, Callable, Optional

class LlmUserMessageGenerator:
    def __init__(
        self,
        memory: List[str],
        user_message: str,
        belief_surroundings: str = "",
        pronoun_processor: Optional[Callable[[str], str]] = None
    ):
        self.memory = memory
        self.user_message = user_message
        self.belief_surroundings = belief_surroundings
        self.pronoun_processor = pronoun_processor
    
    def build_user_message(self) -> str:
        processed_message = self.user_message
        if self.pronoun_processor:
            processed_message = self.pronoun_processor(self.user_message)
        
        parts = []
        if self.belief_surroundings:
            parts.append(self.belief_surroundings)
        if self.memory:
            memory_text = " ".join(self.memory)
            parts.append(memory_text)
        parts.append(processed_message)
        return "\n".join(parts) if len(parts) > 1 else processed_message
