from abc import ABC, abstractmethod
from typing import AsyncGenerator

class LlmGateway(ABC):
    @abstractmethod
    def generate_completion(
        self,
        user_message: str
    ) -> str:
        pass

    @abstractmethod
    async def generate_streaming_completion(
        self,
        user_message: str
    ) -> AsyncGenerator[str, None]:
        if False:
            yield ""

    @abstractmethod
    def set_system_prompt(self, system_prompt: str) -> None:
        pass
