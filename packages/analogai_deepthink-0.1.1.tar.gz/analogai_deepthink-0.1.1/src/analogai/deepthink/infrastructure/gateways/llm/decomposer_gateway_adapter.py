from analogai.deepthink.infrastructure.gateways.llm.gateway import LlmGateway


class LlmDecomposerGatewayAdapter:
    def __init__(self, llm_gateway: LlmGateway):
        self._llm_gateway = llm_gateway

    def generate_completion(self, user_message: str) -> str:
        return self._llm_gateway.generate_completion(user_message)
