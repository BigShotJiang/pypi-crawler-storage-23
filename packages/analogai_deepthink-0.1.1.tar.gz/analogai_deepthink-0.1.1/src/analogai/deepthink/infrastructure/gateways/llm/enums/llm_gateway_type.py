from enum import Enum


class LlmGatewayType(str, Enum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    AZURE = "azure"
    AZURE_OPENAI = "azure_openai"
    GROK = "grok"
    BEDROCK = "bedrock"
