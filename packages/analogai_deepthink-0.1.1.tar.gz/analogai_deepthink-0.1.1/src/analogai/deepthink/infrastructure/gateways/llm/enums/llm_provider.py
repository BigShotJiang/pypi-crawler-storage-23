from enum import Enum


class LlmProvider(str, Enum):
    XAI = "xai"
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    AZURE = "azure"
    AZURE_OPENAI = "azure_openai"
    BEDROCK = "bedrock"
