from __future__ import annotations

from typing import Any, Optional


def extract_text_from_response(data: dict) -> str:
    if not isinstance(data, dict):
        return ""

    if "output" in data:
        output = data["output"]
        if isinstance(output, str):
            return output.strip()
        if isinstance(output, list) and output:
            first = output[0]
            if isinstance(first, dict):
                content = first.get("content") or first.get("text")
                if isinstance(content, str):
                    return content.strip()
            return str(first).strip()
        if isinstance(output, dict):
            content = output.get("content")
            if isinstance(content, str):
                return content.strip()
            delta = output.get("delta")
            if isinstance(delta, dict):
                delta_content = delta.get("content")
                if isinstance(delta_content, str):
                    return delta_content.strip()
        return str(output).strip()

    if "choices" in data and isinstance(data.get("choices"), list) and data["choices"]:
        first_choice = data["choices"][0]
        if isinstance(first_choice, dict):
            message = first_choice.get("message")
            if isinstance(message, dict):
                content = message.get("content")
                if isinstance(content, str):
                    return content.strip()
            content = first_choice.get("content")
            if isinstance(content, str):
                return content.strip()

    if "content" in data and isinstance(data.get("content"), str):
        return str(data["content"]).strip()

    return ""


def extract_stream_delta(data: dict) -> Optional[str]:
    if not isinstance(data, dict):
        return None

    if "output" in data:
        output = data["output"]
        if isinstance(output, str):
            return output
        if isinstance(output, list) and output:
            first = output[0]
            if isinstance(first, dict):
                content = first.get("content") or first.get("text")
                if isinstance(content, str):
                    return content
                delta = first.get("delta")
                if isinstance(delta, dict):
                    delta_content = delta.get("content")
                    if isinstance(delta_content, str):
                        return delta_content
            return None
        if isinstance(output, dict):
            delta = output.get("delta")
            if isinstance(delta, dict):
                delta_content = delta.get("content")
                if isinstance(delta_content, str):
                    return delta_content
            content = output.get("content")
            if isinstance(content, str):
                return content

    if "choices" in data and isinstance(data.get("choices"), list) and data["choices"]:
        first_choice = data["choices"][0]
        if isinstance(first_choice, dict):
            delta = first_choice.get("delta")
            if isinstance(delta, dict):
                content = delta.get("content")
                if isinstance(content, str):
                    return content

    if "delta" in data and isinstance(data.get("delta"), dict):
        content = data["delta"].get("content")
        if isinstance(content, str):
            return content

    return None
