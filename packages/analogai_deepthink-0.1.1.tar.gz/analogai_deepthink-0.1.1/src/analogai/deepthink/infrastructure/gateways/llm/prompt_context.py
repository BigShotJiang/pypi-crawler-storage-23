from dataclasses import dataclass
from typing import Optional


@dataclass
class PromptContext:
    knowledge_base: Optional[str] = None
    related_beliefs: Optional[str] = None
