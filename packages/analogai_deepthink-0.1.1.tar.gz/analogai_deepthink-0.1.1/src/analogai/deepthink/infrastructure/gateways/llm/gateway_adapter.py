from analogai.deepthink.infrastructure.gateways.llm.gateway import LlmGateway
from typing import AsyncGenerator


class LegacyGatewayAdapter(LlmGateway):
    def __init__(self, legacy_gateway):
        self._legacy_gateway = legacy_gateway
    
    def generate_completion(
        self,
        user_message: str
    ) -> str:
        return self._legacy_gateway.generate_completion(
            user_message=user_message
        )
    
    async def generate_streaming_completion(
        self,
        user_message: str
    ) -> AsyncGenerator[str, None]:
        async for chunk in self._legacy_gateway.generate_streaming_completion(
            user_message=user_message
        ):
            yield chunk
    
    def _build_system_prompt(self, context) -> str:
        parts = []
        if context.knowledge_base:
            parts.append(context.knowledge_base)
        if context.related_beliefs:
            parts.append(context.related_beliefs)
        return "\n".join(parts)

