from dotenv import load_dotenv
import os

load_dotenv()

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY', '')
EMBEDDING_MODEL_NAME = os.getenv('EMBEDDING_MODEL_NAME', 'text-embedding-3-small')

XAI_API_KEY = os.getenv('XAI_API_KEY', '')

AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID', '')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY', '')
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
BEDROCK_MODEL_ID = os.getenv('BEDROCK_MODEL_ID', 'anthropic.claude-3-sonnet-20240229-v1:0')

AZURE_AI_FOUNDRY_ENDPOINT = os.getenv('AZURE_AI_FOUNDRY_ENDPOINT', '')
AZURE_AI_FOUNDRY_API_KEY = os.getenv('AZURE_AI_FOUNDRY_API_KEY', '')

AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT', '')
AZURE_OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY', '')

TRACK_LLM = os.getenv('TRACK_LLM', 'true').lower() == 'true'

OLLAMA_HOST = os.getenv('OLLAMA_HOST', 'localhost')
OLLAMA_PORT = os.getenv('OLLAMA_PORT', '11434')
OLLAMA_MODEL_NAME = os.getenv('OLLAMA_MODEL_NAME', 'qwen2.5:0.5b-instruct')
