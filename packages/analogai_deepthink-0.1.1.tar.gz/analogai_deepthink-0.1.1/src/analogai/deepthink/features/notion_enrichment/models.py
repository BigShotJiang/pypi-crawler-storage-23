from dataclasses import dataclass
from typing import List
from analogai.foundation.common.enums import RelationshipType


@dataclass
class EnrichmentSuggestion:
    subject_caption: str
    relationship_type: RelationshipType
    complement_caption: str


@dataclass
class EnrichmentResult:
    notion_caption: str
    suggestions: List[EnrichmentSuggestion]
