from typing import Optional
from analogai.deepthink.features.notion_enrichment.ports import NotionCreatedObserverPort

_observer: Optional[NotionCreatedObserverPort] = None


def get_notion_enrichment_observer() -> Optional[NotionCreatedObserverPort]:
    return _observer


def register_notion_enrichment_observer(observer: NotionCreatedObserverPort) -> None:
    global _observer
    _observer = observer
