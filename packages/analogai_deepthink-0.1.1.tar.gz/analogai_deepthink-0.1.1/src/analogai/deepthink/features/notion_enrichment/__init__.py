from analogai.deepthink.features.notion_enrichment.observer_factory import (
    create_and_register_notion_enrichment_observer,
    create_notion_enrichment_observer,
)
from analogai.deepthink.features.notion_enrichment.registry import get_notion_enrichment_observer
