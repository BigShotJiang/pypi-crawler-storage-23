from analogai.foundation.modules.notion.notion_service import NotionService
from analogai.deepthink.features.notion_enrichment.enricher_service import NotionEnricherService
from analogai.deepthink.features.notion_enrichment.observer import NotionEnrichmentObserver
from analogai.deepthink.features.notion_enrichment.ports import NotionEnrichmentGatewayPort
from analogai.deepthink.features.notion_enrichment.registry import register_notion_enrichment_observer


def create_notion_enrichment_observer(
    statement_service,
    notion_service: NotionService,
    enrichment_gateway: NotionEnrichmentGatewayPort,
) -> NotionEnrichmentObserver:
    enricher_service = NotionEnricherService(
        statement_service=statement_service,
        notion_service=notion_service,
        gateway=enrichment_gateway,
    )
    return NotionEnrichmentObserver(enricher_service=enricher_service)


def create_and_register_notion_enrichment_observer(
    statement_service,
    notion_service: NotionService,
    enrichment_gateway: NotionEnrichmentGatewayPort,
) -> None:
    observer = create_notion_enrichment_observer(
        statement_service=statement_service,
        notion_service=notion_service,
        enrichment_gateway=enrichment_gateway,
    )
    register_notion_enrichment_observer(observer)

