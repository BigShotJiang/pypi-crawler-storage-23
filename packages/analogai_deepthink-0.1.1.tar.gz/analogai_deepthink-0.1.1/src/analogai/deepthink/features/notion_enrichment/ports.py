from abc import ABC, abstractmethod
from analogai.deepthink.application.value_objects.user_agent import UserAgent
from analogai.deepthink.features.notion_enrichment.models import EnrichmentResult


class NotionEnrichmentGatewayPort(ABC):
    @abstractmethod
    def enrich(self, notion_caption: str, user_agent: UserAgent) -> EnrichmentResult:
        pass


class NotionCreatedObserverPort(ABC):
    @abstractmethod
    def on_notion_created(self, notion: object) -> None:
        pass
