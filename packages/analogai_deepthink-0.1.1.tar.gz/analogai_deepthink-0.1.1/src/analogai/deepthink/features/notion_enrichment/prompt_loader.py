from pathlib import Path

from analogai.foundation.common.enums import RelationshipType


def _relationship_list() -> str:
    parts = [f"- {rt.name}: {rt.value}" for rt in RelationshipType]
    return "\n".join(parts)


def load_notion_enrichment_prompt() -> str:
    prompts_dir = Path(__file__).resolve().parents[2] / "infrastructure" / "prompts"
    path = prompts_dir / "notion_enrichment_prompt.txt"
    if not path.exists():
        raise FileNotFoundError(f"Prompt file not found: {path}")
    raw = path.read_text(encoding="utf-8")
    return raw.replace("{relationship_types}", _relationship_list())
