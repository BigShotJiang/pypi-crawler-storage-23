from __future__ import annotations

from analogai.foundation.common.logging.app_logger import app_logger


def is_question(text: str) -> bool:
    if not text:
        return False
    trimmed = text.strip()
    if "?" in trimmed:
        app_logger.info(
            f"[QuestionDetector] is_question=True (reason=question_mark) text={trimmed!r}"
        )
        return True
    app_logger.info(
        f"[QuestionDetector] is_question=False (reason=no_question_mark) text={trimmed!r}"
    )
    return False
