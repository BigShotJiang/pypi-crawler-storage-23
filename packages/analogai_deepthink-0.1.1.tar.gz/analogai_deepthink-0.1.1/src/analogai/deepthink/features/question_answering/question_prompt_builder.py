from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass
class QuestionPromptContext:
    question: str
    entities: List[str]
    belief_context: str


@dataclass
class QuestionSynthesisContext:
    question: str
    tasks: str
    facts: str


class QuestionPromptBuilder:
    def build_system_prompt(self) -> str:
        return ""

    def build_user_message(self, context: QuestionPromptContext) -> str:
        entities = ", ".join(context.entities) if context.entities else "(none detected)"
        belief_context = context.belief_context or "(no matching beliefs found)"
        return (
            f"Question: {context.question}\n"
            f"Entities: {entities}\n"
            "Belief context:\n"
            f"{belief_context}\n\n"
            "Answer:"
        )

    def build_synthesis_prompt(self, context: QuestionSynthesisContext) -> str:
        template = _load_synthesizer_prompt_template()
        return template.format(
            question=context.question,
            tasks=context.tasks,
            facts=context.facts,
        )


def _load_synthesizer_prompt_template() -> str:
    prompts_dir = Path(__file__).resolve().parents[2] / "infrastructure" / "prompts"
    prompt_path = prompts_dir / "question_answer_synthesizer_prompt.txt"
    if not prompt_path.exists():
        raise FileNotFoundError(f"Prompt file not found: {prompt_path}")
    return prompt_path.read_text(encoding="utf-8")
