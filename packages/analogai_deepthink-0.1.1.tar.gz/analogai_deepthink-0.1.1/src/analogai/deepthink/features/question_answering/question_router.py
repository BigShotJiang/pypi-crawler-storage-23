from __future__ import annotations

from typing import Callable, Optional

from analogai.deepthink.application.value_objects.user_agent import UserAgent
from analogai.deepthink.presentation.preprocessing.previous_messages_stack import PreviousMessagesStack
from analogai.deepthink.features.question_answering.question_answering_service import QuestionAnsweringService
from analogai.deepthink.features.question_answering.question_detection import is_question


class QuestionRouter:
    def __init__(self, question_service: QuestionAnsweringService):
        self._question_service = question_service

    def is_question(self, text: str) -> bool:
        return is_question(text)

    def route(
        self,
        raw_message: str,
        user_agent: UserAgent,
        previous_messages_stack: PreviousMessagesStack,
        statement_handler: Callable[[str, UserAgent, PreviousMessagesStack], Optional[str]],
    ) -> Optional[str]:
        if self.is_question(raw_message):
            return self._question_service.search(
                question_text=raw_message,
                user_agent=user_agent,
            )
        return statement_handler(raw_message, user_agent, previous_messages_stack)
