from __future__ import annotations

from analogai.deepthink.infrastructure.gateways.llm.gateway import LlmGateway


class QuestionLlmCaller:
    def __init__(self, gateway: LlmGateway):
        self._gateway = gateway

    def answer(self, user_message: str) -> str:
        return self._gateway.generate_completion(user_message)
