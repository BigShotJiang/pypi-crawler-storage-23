from unittest.mock import Mock
import uuid
from analogai.foundation.modules.belief.belief import Belief
from analogai.foundation.common.dtos.belief_expression import Relation
from analogai.deepthink.tests.mocks.entities.mock_statement_factory import MockStatementFactory
from analogai.deepthink.tests.mocks.entities.mock_notion_factory import MockNotionFactory
from analogai.foundation.common.enums import RelationshipType

class MockBeliefFactory:
    @staticmethod
    def create(repository=None, statements=None, subject_notion=None, complement_notion=None, relationship_type=RelationshipType.IS_A, probability=0.7, validity=0.8, agent=None):
        if not repository:
            repository = Mock()
        if statements is None:
            statements = [MockStatementFactory.create() for _ in range(3)]
        if subject_notion is None:
            subject_notion = MockNotionFactory.create()
        if complement_notion is None:
            complement_notion = MockNotionFactory.create()
        if agent is None:
            agent = Mock()
        belief = Mock(spec=Belief,name=f"{subject_notion.caption}->{relationship_type.value}->{complement_notion.caption}")
        belief.id = str(uuid.uuid4())
        belief.repository = repository
        belief.statements = statements
        belief.subject_notion = subject_notion
        belief.complement_notion = complement_notion
        belief.relation = Relation.from_type(relationship_type)
        belief.probability = float(probability)
        belief.validity = float(validity)
        belief.agent = agent
        return belief 


