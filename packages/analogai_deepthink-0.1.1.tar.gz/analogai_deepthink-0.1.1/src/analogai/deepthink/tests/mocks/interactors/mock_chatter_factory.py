from unittest.mock import Mock
from analogai.deepthink.application.usecases.chat.chatter import Chatter

class MockChatterFactory:
    @staticmethod
    def create(history=None, knowledge_base=None):
        if history is None:
            history = []
        chatter = Mock(spec=Chatter)
        chatter.history = history
        chatter.knowledge_base = knowledge_base
        return chatter 


