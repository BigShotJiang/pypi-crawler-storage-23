from unittest.mock import Mock
from analogai.deepthink.application.usecases.learning.make_direct_statement.ports import MakeStatementOutputPort
from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse

class MockLearningOutputPort(MakeStatementOutputPort):
    def __init__(self):
        self._mock_output_update_not_applicable = Mock()
        self._mock_output_create_statement_success = Mock()
        self._mock_output_statement_update_success = Mock()
        self._mock_output_forbidden = Mock()
        self._mock_output_statement_already_known = Mock()

    @property
    def mock_output_update_not_applicable(self):
        return self._mock_output_update_not_applicable

    @property
    def mock_output_create_statement_success(self):
        return self._mock_output_create_statement_success

    @property
    def mock_output_statement_update_success(self):
        return self._mock_output_statement_update_success

    @property
    def mock_output_forbidden(self):
        return self._mock_output_forbidden

    @property
    def mock_output_statement_already_known(self):
        return self._mock_output_statement_already_known

    def output_update_not_applicable(self, response: MakeDirectStatementResponse):
        return self._mock_output_update_not_applicable(response)

    def output_create_statement_success(self, response: MakeDirectStatementResponse):
        return self._mock_output_create_statement_success(response)

    def output_statement_update_success(self, response: MakeDirectStatementResponse):
        return self._mock_output_statement_update_success(response)

    def output_forbidden(self, response: MakeDirectStatementResponse):
        return self._mock_output_forbidden(response)

    def output_statement_already_known(self, response: MakeDirectStatementResponse):
        return self._mock_output_statement_already_known(response)



