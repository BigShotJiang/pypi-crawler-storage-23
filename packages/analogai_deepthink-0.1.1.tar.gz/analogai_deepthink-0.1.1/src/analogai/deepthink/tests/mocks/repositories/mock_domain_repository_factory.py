from unittest.mock import Mock
from analogai.foundation.modules.user.user import User


class MockDomainRepositoryFactory:
    def __init__(self):
        self._notion_repo = Mock()
        self._statement_repo = Mock()
        self._belief_repo = Mock()
        self._deductive_inference_repo = Mock()
        self._inductive_inference_repo = Mock()
        self._user_repo = Mock()

        self._user_repo.find_by_id.return_value = User(id="test_user_1", name="Test User", email="test@example.com")

    def get_notion_repository(self):
        return self._notion_repo

    def get_direct_statement_repository(self):
        return self._statement_repo

    def get_belief_repository(self):
        return self._belief_repo

    def get_deductive_inference_repository(self):
        return self._deductive_inference_repo

    def get_inductive_inference_repository(self):
        return self._inductive_inference_repo

    def get_user_repository(self):
        return self._user_repo


