from unittest.mock import Mock
from analogai.foundation.modules.notion.notion import Notion
    
class MockNotionFactory:
    @staticmethod
    def create(caption='default_caption', user=None, agent=None, user_id="test-user-id", agent_id="test-agent-id"):
        notion = Mock(spec=Notion, name=caption)
        notion.caption = caption
        notion.id = "mock_id"
        notion.user_id = user_id
        notion.agent_id = agent_id
        notion.user = user or Mock()
        notion.agent = agent or Mock()
        notion.context = []
        return notion


