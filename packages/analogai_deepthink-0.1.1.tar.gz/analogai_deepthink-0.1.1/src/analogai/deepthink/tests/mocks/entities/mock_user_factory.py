from unittest.mock import Mock
from analogai.foundation.modules.user.user import User

class MockUserFactory:
    @staticmethod
    def create(id='default_user'):
        user = Mock(spec=User, name=id)
        return user


