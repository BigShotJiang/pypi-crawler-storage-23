from unittest.mock import Mock
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.common.enums import RelationshipType

class MockRequestFactory:
    request_class = None

    @classmethod
    def create(cls, subject_notion_expression=None, complement_notion_expression=None, relationship_type=RelationshipType.IS_A, **kwargs):
        if subject_notion_expression is None:
            subject_notion_expression = NotionExpression(caption="test_subject")
        if complement_notion_expression is None:
            complement_notion_expression = NotionExpression(caption="test_object")
        request = Mock(spec=cls.request_class)
        request.subject_notion_expression = subject_notion_expression
        request.complement_notion_expression = complement_notion_expression
        request.relationship_type = relationship_type
        for key, value in kwargs.items():
            setattr(request, key, value)
        return request 


