from unittest.mock import Mock
from analogai.deepthink.tests.mocks.entities.mock_notion_factory import MockNotionFactory
from analogai.foundation.common.enums import RelationshipType
from .mock_user_factory import MockUserFactory

class MockStatementFactory:
    @staticmethod
    def create(content='default_statement', subject_notion=None, complement_notion=None, relationship_type=RelationshipType.IS_A, probability=0.3, validity=0.4, author=None, agent=None):
        if subject_notion is None:
            subject_notion = MockNotionFactory.create()
        if complement_notion is None:
            complement_notion = MockNotionFactory.create()
        if agent is None:
            agent = Mock()
        statement = Mock(name=f"{subject_notion.caption}->{relationship_type.value}->{complement_notion.caption}")
        statement.content = content
        statement.subject_notion = subject_notion
        statement.complement_notion = complement_notion
        statement.relation = relationship_type.value
        statement.probability = float(probability)
        statement.validity = float(validity)
        statement.author = author or MockUserFactory.create()
        statement.agent = agent
        return statement 


