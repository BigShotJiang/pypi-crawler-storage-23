from unittest.mock import Mock
from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.common.enums import RelationshipType
from analogai.deepthink.tests.mocks.entities.mock_notion_factory import MockNotionFactory
from analogai.deepthink.tests.mocks.entities.mock_belief_factory import MockBeliefFactory
from analogai.deepthink.tests.mocks.entities.mock_user_factory import MockUserFactory

class MockDeductiveInferenceFactory:
    @staticmethod
    def create(major_premise=None, minor_premise=None, subject_notion=None, complement_notion=None, relationship_type=RelationshipType.IS_A, probability=1.0, validity=1.0, author=None):
        if major_premise is None:
            major_premise = MockBeliefFactory.create(relationship_type=relationship_type)
        if minor_premise is None:
            minor_premise = MockBeliefFactory.create(relationship_type=relationship_type)
        if subject_notion is None:
            subject_notion = MockNotionFactory.create()
        if complement_notion is None:
            complement_notion = MockNotionFactory.create()
        inference = Mock(name=f"{subject_notion.caption}->{relationship_type.value}->{complement_notion.caption}")
        inference.major_premise = major_premise
        inference.minor_premise = minor_premise
        inference.subject_notion = subject_notion
        inference.complement_notion = complement_notion
        inference.probability = float(probability)
        inference.validity = float(validity)
        inference.author = author or MockUserFactory.create()
        inference.modifier = None
        return inference 


