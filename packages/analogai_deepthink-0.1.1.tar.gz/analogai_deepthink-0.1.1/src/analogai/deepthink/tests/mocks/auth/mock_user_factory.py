from analogai.foundation.modules.user.user import User

class MockUserFactory:
    DEFAULT_ID = "test_user_id"
    DEFAULT_NAME = "Test User"
    DEFAULT_EMAIL = "test@example.com"
    
    @classmethod
    def create(cls, 
               id=DEFAULT_ID,
               name=DEFAULT_NAME,
               email=DEFAULT_EMAIL):
        return User(
            id=id,
            name=name,
            email=email
        ) 


