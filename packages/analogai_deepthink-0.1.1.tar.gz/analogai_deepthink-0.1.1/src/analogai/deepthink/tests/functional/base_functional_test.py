import unittest
from analogai.deepthink.tests.functional.storage_cleaner import cleanup_storages

class BaseFunctionalTest(unittest.TestCase):
    
    def setUp(self):
        cleanup_storages()
    
    def tearDown(self):
        cleanup_storages()



