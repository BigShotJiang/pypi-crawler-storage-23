from unittest.mock import Mock
from analogai.foundation.modules.user.user import User


class _statementServiceTestAdapter:
    def __init__(self, statement_service):
        self._service = statement_service

    def create(self, user_id, agent_id, subject_notion, complement_notion, relationship_type,
               probability=1.0, validity=1.0, modifier=None, **kwargs):
        relation = relationship_type.value
        return self._service.create(
            user_id=user_id,
            agent_id=agent_id,
            subject_notion=subject_notion,
            relation=relation,
            complement_notion=complement_notion,
            probability=probability,
            validity=validity,
            modifier=modifier,
            **{k: v for k, v in kwargs.items() if k in ('quantity', 'id')}
        )

    def update_probability(self, statement, probability):
        target = getattr(statement, "statement_for_update", lambda: statement)()
        return self._service.update_probability(target, probability)

    def update_validity(self, statement, validity):
        return self._service.update_validity(statement, validity)
from analogai.foundation.modules.agent.agent import Agent
from analogai.deepthink.startup.factories.domain_service_factory import DomainServiceFactory
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.usecases.chat.chat_response_stack import ChatResponseStack
from analogai.deepthink.application.value_objects.user_agent import UserAgent
from analogai.deepthink.tests.functional.storage_cleaner import cleanup_storages


class ChatterTestSetup:
    def __init__(self):
        domain_service_factory = DomainServiceFactory()
        self.domain_service_factory = domain_service_factory

        self.notion_service = domain_service_factory.get_notion_service()
        self.belief_service = domain_service_factory.get_belief_service()
        self.statement_service = domain_service_factory.get_statement_service()
        self.statement_service = _statementServiceTestAdapter(self.statement_service)
        self.deductive_inference_service = domain_service_factory.get_deductive_inference_service()
        self.belief_query_service = self._get_belief_query_service(domain_service_factory)
        
        self.user = User(id="test-user", name="Test User", email="test@example.com")
        self.agent = Agent(id="test-agent", knowledge_base="Test KB", creator=self.user)
        self.user_agent = UserAgent(
            user_id=self.user.id,
            agent_id=self.agent.id,
            user_authority=1.0
        )
        self.mock_output_port = Mock()
        self.response_stack = ChatResponseStack()
        
        self.socrates_notion = self.create_notion("socrates")
        self.human_notion = self.create_notion("human")
        self.mortal_notion = self.create_notion("mortal")

    def _get_belief_query_service(self, domain_service_factory):
        from analogai.deepthink.startup.extensions_service_factory import ExtensionsServiceFactory
        return ExtensionsServiceFactory(domain_service_factory).get_belief_query_service()

    def create_notion(self, caption):
        return self.notion_service.find_or_create(
            self.user.id,
            self.agent.id,
            NotionExpression(caption=caption)
        )

    def tear_down(self):
        cleanup_storages()


