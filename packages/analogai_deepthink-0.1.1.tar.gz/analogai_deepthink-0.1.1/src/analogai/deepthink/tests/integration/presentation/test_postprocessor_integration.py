import unittest
from analogai.deepthink.presentation.postprocessing.postprocessor import postprocess_text
from analogai.deepthink.presentation.postprocessing.postprocessors.pronoun_postprocessior import postprocesses_pronouns
from analogai.deepthink.presentation.enums.pronoun_placeholder import PronounPlaceholder


class TestPostprocessorIntegration(unittest.TestCase):
    def test_postprocessor_chain(self):
        input_text = f"{PronounPlaceholder.AGENT_PLACEHOLDER.value} is human friend"
        postprocessed = postprocess_text(input_text)
        self.assertIsNotNone(postprocessed)
        self.assertIsInstance(postprocessed, str)
        self.assertEqual(postprocessed, "I am human friend")

    def test_postprocessor_with_pronouns(self):
        input_text = f"{PronounPlaceholder.AGENT_PLACEHOLDER.value} is human friend"
        postprocessed = postprocess_text(input_text)
        self.assertIsNotNone(postprocessed)
        self.assertIsInstance(postprocessed, str)
        self.assertEqual(postprocessed, "I am human friend")

    def test_postprocessor_with_sentence(self):
        input_text = f"is {PronounPlaceholder.AGENT_PLACEHOLDER.value} human friend"
        postprocessed = postprocess_text(input_text)
        self.assertIsNotNone(postprocessed)
        self.assertIsInstance(postprocessed, str)

    def test_postprocessor_with_multiple_pronouns(self):
        agent = PronounPlaceholder.AGENT_PLACEHOLDER.value
        input_text = f"{agent} could be human friend and {agent} is smart"
        postprocessed = postprocess_text(input_text)
        self.assertIsNotNone(postprocessed)
        self.assertIsInstance(postprocessed, str)
        self.assertEqual(postprocessed, "I could be human friend and I am smart")

    def test_pronoun_replacement_after_grammar_correction(self):
        respondent = PronounPlaceholder.RESPONDENT_PLACEHOLDER.value
        grammar_corrected = f"{respondent} can sell the iphone 12 today"
        pronoun_formatted = postprocesses_pronouns(grammar_corrected)
        self.assertIn("you", pronoun_formatted.lower())
        self.assertIn("the iphone 12", pronoun_formatted.lower())
        self.assertNotIn(respondent, pronoun_formatted)


if __name__ == "__main__":
    unittest.main()


