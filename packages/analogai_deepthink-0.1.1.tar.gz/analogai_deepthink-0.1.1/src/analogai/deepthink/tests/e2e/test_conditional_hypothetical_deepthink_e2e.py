import unittest

from analogai.deepthink.tests.e2e.base_deepthink_e2e_test import BaseThinkerE2ETest


class TestCausalHypotheticalThinkerE2E(BaseThinkerE2ETest):

    def test_conditional_statement_with_time_modifiers(self):
        response = self._think("if today it rains, tomorrow there will be floods")
        self.assertIsNotNone(response)
        self.assertIn("if", response.lower())
        self.assertIn("then", response.lower())

    def test_conditional_statement_with_location_modifiers(self):
        response = self._think("if there is heavy rain in the mountains, there is flooding in the valley")
        self.assertIsNotNone(response)
        self.assertIn("if", response.lower())
        self.assertIn("then", response.lower())



if __name__ == "__main__":
    unittest.main()
