import os
import unittest
import uuid

os.environ['QUICK_TESTING'] = 'true'

from analogai.deepthink.tests.functional.storage_cleaner import cleanup_storages
from analogai.deepthink.thinker import DeepThinker
from analogai.deepthink.presentation.preprocessing.previous_messages_stack import PreviousMessagesStack


class BaseThinkerE2ETest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from analogai.deepthink import config
        config.QUICK_TESTING = True
        config.LLM_PROCESSING_ENABLED = False
        config.NOTION_ENRICHMENT_ENABLED = False
        cls._deepthink = DeepThinker()

    def setUp(self):
        cleanup_storages()
        self._user_id = str(uuid.uuid4())
        self._agent_id = str(uuid.uuid4())
        self._stack = PreviousMessagesStack()

    def tearDown(self):
        cleanup_storages()

    def _think(self, message: str) -> str | None:
        return self._deepthink.deepthink(
            message,
            user_id=self._user_id,
            agent_id=self._agent_id,
            previous_messages_stack=self._stack,
        )
