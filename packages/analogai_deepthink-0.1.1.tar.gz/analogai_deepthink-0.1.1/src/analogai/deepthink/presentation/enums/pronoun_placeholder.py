from enum import Enum


class PronounPlaceholder(Enum):
    COMPANY_PLACEHOLDER = "we"
    AGENT_PLACEHOLDER = "agent"
    RESPONDENT_PLACEHOLDER = "respondent"

