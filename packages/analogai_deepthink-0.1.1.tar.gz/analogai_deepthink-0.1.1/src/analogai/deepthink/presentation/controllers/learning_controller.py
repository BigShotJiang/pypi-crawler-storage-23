from typing import Optional, Any
from analogai.deepthink.application.usecases.learning.learn_statement.ports import LearnStatementInputPort
from analogai.deepthink.application.usecases.learning.learn_statement.models import LearnStatementRequest
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class LearningController:
    def __init__(
        self,
        learn_statement_usecase: LearnStatementInputPort,
        make_conditional_statement_usecase: Any = None,
    ):
        self._learn_statement_usecase = learn_statement_usecase
        self._make_conditional_statement_usecase = make_conditional_statement_usecase

    def learn_statement(self, request: LearnStatementRequest) -> Optional[PresenterResponse]:
        return self._learn_statement_usecase.execute(request)

    def learn_conditional_statement(self, request: Any) -> Optional[PresenterResponse]:
        return self._make_conditional_statement_usecase.execute(request)
