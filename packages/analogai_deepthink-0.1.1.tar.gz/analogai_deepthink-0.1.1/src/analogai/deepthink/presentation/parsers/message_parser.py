from typing import List
import logging

from .propagated_sentence import PropagatedSentence
from .propagated_sentence_builder import build_propagated_sentence
from .json_sentence_parser import parse_json, is_json_format


logger = logging.getLogger(__name__)


class MessageParser:
    def parse(self, text: str) -> List[PropagatedSentence]:
        if not text or not text.strip():
            return []
        text = text.strip()
        if not is_json_format(text):
            return []
        
        logger.debug(f"[1] Parsing JSON: {text[:100]}...")
        parsed_sentences = parse_json(text)
        logger.debug(f"[2] Extracted {len(parsed_sentences)} sentences: {parsed_sentences}")
        
        result = [build_propagated_sentence(s) for s in parsed_sentences]
        logger.debug(f"[3] Enum propagated: {result}")
        
        return result
