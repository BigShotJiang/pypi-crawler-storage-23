from typing import Optional
from analogai.deepthink.presentation.intent_type import IntentType


INTENT_MAP = {
    "making_statement": IntentType.MAKING_STATEMENT,
    "making_conditional_statement": IntentType.MAKING_CAUSAL_STATEMENT,
    "making_notion_attribute_statement": IntentType.MAKING_NOTION_ATTRIBUTE_STATEMENT,
    "attribute_quantity_statement": IntentType.MAKING_STATEMENT,
    "attribute_statement": IntentType.MAKING_STATEMENT,
}


def _resolve_identity(intent: IntentType) -> Optional[IntentType]:
    return intent


def _resolve_string(intent: str) -> Optional[IntentType]:
    return INTENT_MAP.get(intent)


def _resolve_default(_: object) -> Optional[IntentType]:
    return None


_INTENT_RESOLVERS = {
    IntentType: _resolve_identity,
    str: _resolve_string,
}


def map_intent(intent_str: Optional[str]) -> Optional[IntentType]:
    if not intent_str:
        return None
    resolver = _INTENT_RESOLVERS.get(type(intent_str), _resolve_default)
    return resolver(intent_str)
