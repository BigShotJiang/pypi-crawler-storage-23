from dataclasses import dataclass, field
from typing import Optional, List, TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from analogai.foundation.common.enums.certainty import Certainty


class AttributeDict(TypedDict, total=False):
    tag: str
    value: str
    unit: Optional[str]


@dataclass
class ParsedData:
    subject: Optional[str] = None
    complement: Optional[str] = None
    subject_attributes: Optional[List[AttributeDict]] = None
    complement_attributes: Optional[List[AttributeDict]] = None
    relationship_phrase: Optional[str] = None
    location: Optional[str] = None
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    time: Optional[str] = None
    probability: Optional[float] = None
    certainty: Optional["Certainty"] = None
    attributes: Optional[List[AttributeDict]] = None
    quantity: Optional[str] = None
    deontic_modality: Optional[str] = None
    causes: Optional[List["ParsedData"]] = None
    effects: Optional[List["ParsedData"]] = None


@dataclass
class ParsedSentence:
    intent_type: Optional[str] = None
    data: Optional[ParsedData] = None
    
    def __repr__(self):
        return f"ParsedSentence(intent_type={repr(self.intent_type)}, data={repr(self.data)})"
