from enum import Enum


class Certainty(Enum):
    CERTAIN = "certain"
    UNCERTAIN = "uncertain"
    NEGATED = "negated"
