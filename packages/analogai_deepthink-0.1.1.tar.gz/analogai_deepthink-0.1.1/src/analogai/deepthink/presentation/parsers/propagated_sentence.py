from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field

from analogai.deepthink.presentation.intent_type import IntentType
from analogai.foundation.common.enums.certainty import Certainty
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.core.value_objects.relation import Relation


class Attribute(BaseModel):
    tag: str
    values: List[float] = Field(default_factory=list)
    unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None


class PropagatedData(BaseModel):
    subject: Optional[NotionExpression] = None
    complement: Optional[NotionExpression] = None
    location: Optional[str] = None
    relation: Optional[Relation] = None
    attributes: List[Attribute] = Field(default_factory=list)
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    time: Optional[str] = None
    quantity: Optional[float] = None
    probability: Optional[float] = None
    certainty: Optional[Certainty] = None
    causes: List["PropagatedData"] = Field(default_factory=list)
    effects: List["PropagatedData"] = Field(default_factory=list)
    deontic_modality: Optional[str] = None


class PropagatedSentence(BaseModel):
    intent_type: IntentType
    data: PropagatedData
    
    def __repr__(self) -> str:
        fields = []
        fields.append(f"intent={self.intent_type.value}")
        if self.data.subject:
            fields.append(f"subj={self.data.subject.caption}")
        if self.data.complement:
            fields.append(f"comp={self.data.complement.caption}")
        if self.data.relation:
            fields.append(f"rel={self.data.relation.value}")
        if self.data.quantity is not None:
            fields.append(f"qty={self.data.quantity}")
        if self.data.attributes:
            attrs_str = ", ".join(f"{a.tag}={a.values}{a.unit or ''}" for a in self.data.attributes)
            fields.append(f"attrs=[{attrs_str}]")
        if self.data.location:
            fields.append(f"loc={self.data.location}")
        if self.data.causes:
            fields.append(f"causes={len(self.data.causes)}")
        if self.data.effects:
            fields.append(f"effects={len(self.data.effects)}")
        return f"PropagatedSentence({', '.join(fields)})"
