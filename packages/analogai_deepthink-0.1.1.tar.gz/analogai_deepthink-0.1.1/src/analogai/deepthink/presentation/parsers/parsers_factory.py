from __future__ import annotations

from .message_parser import MessageParser


def build_message_parser() -> MessageParser:
    return MessageParser()
