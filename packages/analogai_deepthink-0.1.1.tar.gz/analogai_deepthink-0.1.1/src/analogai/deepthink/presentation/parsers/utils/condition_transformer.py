from typing import Dict


def transform_condition_to_causal(rel: dict) -> dict:
    condition = rel.get("condition")
    if not condition or not isinstance(condition, dict):
        return rel

    cause_subj = condition.get("subject") or condition.get("subject_caption")
    cause_predicate = condition.get("predicate") if isinstance(condition.get("predicate"), dict) else {}
    cause_rel = (
        cause_predicate.get("relation")
        or condition.get("relationship")
        or condition.get("relation")
        or condition.get("relation_name")
        or condition.get("relationship_phrase")
    )
    cause_obj = (
        cause_predicate.get("complement_caption")
        or cause_predicate.get("complement")
        or condition.get("object")
        or condition.get("complement")
        or condition.get("complement_caption")
    )
    location = condition.get("location")
    
    cause_parts = [str(p) for p in (cause_subj, cause_rel, cause_obj) if p]
    cause_phrase = " ".join(cause_parts) if cause_parts else "condition"
    if location:
        cause_phrase = f"{cause_phrase} in {location}"

    effect_subj = rel.get("subject") or rel.get("subject_caption")
    effect_predicate = rel.get("predicate") if isinstance(rel.get("predicate"), dict) else {}
    effect_rel = (
        effect_predicate.get("relation")
        or rel.get("relationship")
        or rel.get("relation")
        or rel.get("relation_name")
        or rel.get("relationship_phrase")
    )
    effect_obj = (
        effect_predicate.get("complement_caption")
        or effect_predicate.get("complement")
        or rel.get("object")
        or rel.get("complement")
        or rel.get("complement_caption")
    )
    
    effect_parts = [str(p) for p in (effect_subj, effect_rel, effect_obj) if p]
    effect_phrase = " ".join(effect_parts) if effect_parts else "effect"
    
    result = {
        "intent_type": "making_conditional_statement" if location else "making_statement",
        "subject": cause_phrase.strip(),
        "predicate": {
            "relation": "causes",
            "complement": effect_phrase.strip(),
        },
        "probability": rel.get("probability", 1.0),
    }
    
    for key in ("cause_subject", "cause_location", "effect_subject", "effect_location"):
        if key in rel and rel[key]:
            result[key] = rel[key]
    
    return result
