from typing import Optional

from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.common.utils.expression_factory import ExpressionFactory


class NotionExpressionBuilder:
    def __init__(self, expression_factory: Optional[ExpressionFactory] = None) -> None:
        self._expression_factory = expression_factory or ExpressionFactory()

    def build(self, caption: str, attributes=None) -> NotionExpression:
        return self._expression_factory.create_notion_expression(caption, attributes=attributes)
