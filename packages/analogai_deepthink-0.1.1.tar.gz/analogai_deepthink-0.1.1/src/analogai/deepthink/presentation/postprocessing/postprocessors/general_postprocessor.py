def capitalize_first(s: str) -> str:
    if not s:
        return ""
    return s[0].upper() + s[1:]
