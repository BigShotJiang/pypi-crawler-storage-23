from analogai.foundation.common.logging.app_logger import app_logger
from analogai.deepthink.presentation.postprocessing.postprocessor_factory import create_postprocessor_chain

def postprocess_text(text: str) -> str:
    app_logger.important(f"Starting postprocessing: {text}")
    postprocessors = create_postprocessor_chain()
    for i, postprocessor in enumerate(postprocessors, 1):
        text = postprocessor.process(text)
        app_logger.info("Step %d - %s: %s", i, postprocessor.__class__.__name__, text)
    app_logger.success(f"Finished postprocessing: {text}")
    return text

if __name__ == "__main__":
    test_inputs = [
        'agent is cute',
        'human is mortal',
        'human could is mortal',
        'is humans mortal?',
        'you work at museum'
    ]
    
    for test_input in test_inputs:
        print(postprocess_text(test_input))
        print('--------------------------------')
