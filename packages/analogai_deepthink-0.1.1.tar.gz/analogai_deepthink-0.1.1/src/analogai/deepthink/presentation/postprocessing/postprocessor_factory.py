from typing import List
from analogai.foundation.common.logging.app_logger import app_logger
from .postprocessors.pronoun_postprocessior import postprocesses_pronouns
from .postprocessors.general_postprocessor import capitalize_first

class BasePostprocessorHandler:
    def process(self, text: str) -> str:
        raise NotImplementedError

class PronounPostprocessorHandler(BasePostprocessorHandler):
    def process(self, text: str) -> str:
        return postprocesses_pronouns(text)

class GeneralPostprocessorHandler(BasePostprocessorHandler):
    def process(self, text: str) -> str:
        return capitalize_first(text)

def create_postprocessor_chain() -> List[BasePostprocessorHandler]:
    postprocessors: List[BasePostprocessorHandler] = [
        PronounPostprocessorHandler(),
        GeneralPostprocessorHandler()
    ]
    return postprocessors
