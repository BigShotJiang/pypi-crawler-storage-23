import re
from typing import List

class SentenceSplitter:
    _ABBREVIATIONS = {
        'mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'vs', 'etc', 'inc', 'ltd',
        'corp', 'co', 'st', 'ave', 'blvd', 'rd', 'u.s', 'u.s.a', 'e.g', 'i.e',
        'a.m', 'p.m', 'ph.d', 'b.c', 'a.d', 'no', 'vol', 'pp', 'ed', 'est'
    }
    _ABBREVIATIONS_ALWAYS_MERGE = {
        'mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr'
    }
    _COMMA_PLACEHOLDER = "___COMMA___"
    _IF_COMMA_PATTERN = re.compile(r'\bif\b.*?,.*?', re.IGNORECASE)

    @classmethod
    def _is_likely_abbreviation(cls, word: str) -> bool:
        word_clean = word.lower().rstrip('.,!?;:')
        return word_clean in cls._ABBREVIATIONS

    @classmethod
    def split_into_sentences(cls, text: str) -> List[str]:
        text = text.strip()
        if not text:
            return []

        if cls._IF_COMMA_PATTERN.search(text):
            text = re.sub(r'(\bif\b[^,.?!]*),([^.?!]*)', r'\1' + cls._COMMA_PLACEHOLDER + r'\2', text, flags=re.IGNORECASE)

        sentences = []
        current_sentence = ""
        i = 0
        in_quotes = False
        
        while i < len(text):
            char = text[i]
            
            if char == '"':
                in_quotes = not in_quotes
                current_sentence += char
                if not in_quotes:
                    if i + 1 < len(text) and text[i + 1] == ' ':
                        if i + 2 < len(text):
                            next_word_start = i + 2
                            while next_word_start < len(text) and text[next_word_start] == ' ':
                                next_word_start += 1
                            if next_word_start < len(text) and text[next_word_start].isupper():
                                period_pos = current_sentence.rfind('.', 0, len(current_sentence) - 1)
                                if period_pos != -1:
                                    quote_pos = current_sentence.rfind('"', 0, period_pos)
                                    if quote_pos != -1:
                                        first_part = current_sentence[:len(current_sentence)].strip()
                                        if first_part:
                                            sentences.append(first_part)
                                        current_sentence = ""
                i += 1
                continue
            
            current_sentence += char
            
            if char in '.!?' and not in_quotes:
                if i + 1 < len(text):
                    next_char = text[i + 1]
                    if next_char == ' ':
                        if i + 2 < len(text):
                            next_word_start = i + 2
                            while next_word_start < len(text) and text[next_word_start] == ' ':
                                next_word_start += 1
                            
                            if next_word_start < len(text):
                                next_char_after_space = text[next_word_start]
                                
                                words = current_sentence.split()
                                if words:
                                    last_word = words[-1].rstrip('.,!?;:')
                                    if cls._is_likely_abbreviation(last_word):
                                        if last_word.lower() in cls._ABBREVIATIONS_ALWAYS_MERGE:
                                            i += 1
                                            continue
                                        elif next_char_after_space.islower():
                                            i += 1
                                            continue
                                
                                    first_word = words[0]
                                    if first_word and first_word[0].islower():
                                        i += 1
                                        continue
                                
                                if next_char_after_space.islower():
                                    i += 1
                                    continue
                                
                                if next_char_after_space.isupper():
                                    sentences.append(current_sentence.strip())
                                    current_sentence = ""
                                    i += 1
                                    continue
                    elif next_char.islower():
                        i += 1
                        continue
                    elif next_char in '.!?':
                        i += 1
                        continue
                else:
                    if current_sentence.strip():
                        sentences.append(current_sentence.strip())
                    current_sentence = ""
            
            i += 1
        
        if current_sentence.strip():
            sentences.append(current_sentence.strip())
        
        if not sentences:
            text = text.replace(cls._COMMA_PLACEHOLDER, ',')
            sentences = [text] if text else []
        
        filtered_result = []
        for s in sentences:
            s = s.replace(cls._COMMA_PLACEHOLDER, ',')
            s = s.strip()
            if not s:
                continue
            s_no_punct = re.sub(r'[.!?;:,\s"\']+', '', s)
            if len(s_no_punct) <= 1:
                continue
            if re.match(r'^[.!?;:,\s"\']+$', s):
                continue
            filtered_result.append(s)
        
        return filtered_result

def split_into_sentences(text: str) -> List[str]:
    return SentenceSplitter.split_into_sentences(text)

if __name__ == "__main__":
    test_text = "I'm good, aren't I? If you go, I'll stay. You're mortal. Socrates isn't human!"
    print(split_into_sentences(test_text))


