from analogai.deepthink.presentation.enums.pronoun_placeholder import PronounPlaceholder


def preprocess_pronouns(text: str, user_id: str | None = None) -> str:
    if not text:
        return text

    agent = PronounPlaceholder.AGENT_PLACEHOLDER.value
    company = PronounPlaceholder.COMPANY_PLACEHOLDER.value
    respondent = PronounPlaceholder.RESPONDENT_PLACEHOLDER.value
    if user_id:
        respondent = f"{respondent}:{user_id}"

    replacements = {
        "i": respondent,
        "my": f"{respondent}'s",
        "you": agent,
        "your": f"{agent}'s",
        "we": company,
        "our": f"{company}'s",
    }

    words = text.split()
    sentence = []
    for word in words:
        word_lower = word.lower()
        sentence.append(replacements.get(word_lower, word))
    normalized = " ".join(sentence)
    normalized = normalized.replace(f"{respondent} am", f"{respondent} is")
    normalized = normalized.replace(f"am {respondent}", f"is {respondent}")
    normalized = normalized.replace(f"{agent} are", f"{agent} is")
    normalized = normalized.replace(f"are {agent}", f"is {agent}")
    return normalized


if __name__ == "__main__":
    sentences = [
        "we sell iphones",
        "i be your creator. your voice sounds good. you be cute"
    ]
    for text in sentences:
        result = preprocess_pronouns(text)
        print(result)



