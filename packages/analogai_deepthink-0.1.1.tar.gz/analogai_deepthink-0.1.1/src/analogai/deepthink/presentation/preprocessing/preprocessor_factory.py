from typing import List, Optional
from analogai.deepthink.presentation.preprocessing.previous_messages_stack import PreviousMessagesStack
from .preprocessors.sentence_transformer import get_sentence_transformer
from .preprocessors.pronoun_preprocessor import preprocess_pronouns


class BasePreprocessorHandler:
    def process(self, text: str) -> str:
        raise NotImplementedError


class PronounPreprocessorHandler(BasePreprocessorHandler):
    def __init__(self, user_id: str | None = None):
        self._user_id = user_id

    def process(self, text: str) -> str:
        return preprocess_pronouns(text, user_id=self._user_id)


class LlmSentenceTransformerPreprocessorHandler(BasePreprocessorHandler):
    def __init__(self, previous_messages_stack: PreviousMessagesStack):
        self._previous_messages_stack = previous_messages_stack

    def process(self, text: str) -> str:
        return get_sentence_transformer()(text, self._previous_messages_stack)


def create_preprocessor_chain(
    previous_messages_stack: PreviousMessagesStack,
    user_id: str | None = None,
    extra_preprocessors: Optional[List[BasePreprocessorHandler]] = None,
) -> List[BasePreprocessorHandler]:
    chain = [
        PronounPreprocessorHandler(user_id=user_id),
        LlmSentenceTransformerPreprocessorHandler(previous_messages_stack),
    ]
    if extra_preprocessors:
        chain.extend(extra_preprocessors)
    return chain

