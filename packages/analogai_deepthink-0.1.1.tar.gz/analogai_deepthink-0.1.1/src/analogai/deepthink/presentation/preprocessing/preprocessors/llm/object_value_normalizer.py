import re
from analogai.foundation.common.logging.app_logger import app_logger

                                                                                    
_OBJECT_PRICE_PATTERN = re.compile(
    r"\[object:(\s*(?:costs?|is\s+priced\s+at|priced\s+at|worth|pays?)\s+)(\d+(?:[.,]\d+)?(?:\s*(?:usd|eur|gbp|\$|€|£|dollars?|euros?|pounds?))?\s*)\]",
    re.IGNORECASE,
)
                                                                            
_OBJECT_QUANTITY_PATTERN = re.compile(
    r"\[object:(\s*(?:weighs?|height|weight|length|width|depth)(?:\s+is)?\s+)(\d+(?:[.,]\d+)?(?:\s*(?:m|cm|km|kg|g|lb|lbs|feet|ft|inches?|mm|meters?))?\s*)\]",
    re.IGNORECASE,
)


def normalize_object_value_only(text: str) -> str:
    """
    Replace [object:costs 800 usd] with [object:800 usd] and similar
    so the object contains only value + currency/unit.
    """
    if not text or not text.strip():
        return text
    original = text
                                                                   
    text = _OBJECT_PRICE_PATTERN.sub(r"[object:\2]", text)
                                                        
    text = _OBJECT_QUANTITY_PATTERN.sub(r"[object:\2]", text)
    if text != original:
        app_logger.info(
            f"[ObjectValueNormalizer] Normalized object to value-only: '{original.strip()}' -> '{text.strip()}'"
        )
    return text
