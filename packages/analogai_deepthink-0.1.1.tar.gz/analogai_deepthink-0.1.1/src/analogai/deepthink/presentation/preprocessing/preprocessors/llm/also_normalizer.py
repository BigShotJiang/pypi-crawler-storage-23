from analogai.foundation.common.logging.app_logger import app_logger

def normalize_also_separated(text: str) -> str:
    if not text or not text.strip():
        return text
    
    if '[also]' in text:
        parts = [part.strip() for part in text.split('[also]') if part.strip()]
        if len(parts) > 1:
            normalized = '[also]'.join(parts)
            app_logger.info(f"Normalized [also] separated text: {len(parts)} relationships")
            return normalized
        return text
    
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    if len(lines) > 1:
        normalized = '[also]'.join(lines)
        app_logger.info(f"Normalized newline separated text: converted {len(lines)} lines to [also] format")
        return normalized
    
    return text

