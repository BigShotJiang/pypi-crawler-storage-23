from collections import deque
from typing import Deque, Sequence, Tuple


class PreviousMessagesStack:
    MAX_LEN = 5
    
    def __init__(self, maxlen: int = 5):
        self._data: Deque[Tuple[str, str]] = deque(maxlen=min(maxlen, self.MAX_LEN))

    def add(self, text: str) -> None:
        self.add_user(text)

    def add_user(self, text: str) -> None:
        if text is None:
            return
        self._data.append(("user", text))

    def add_agent(self, text: str) -> None:
        if text is None:
            return
        self._data.append(("agent", text))

    def get_history(self) -> Sequence[str]:
        return tuple(text for _, text in self._data)

    def get_history_pairs(self) -> Sequence[Tuple[str, str]]:
        return tuple(self._data)

