from enum import Enum


class IntentType(Enum):
    MAKING_STATEMENT = "making_statement"
    MAKING_CAUSAL_STATEMENT = "making_conditional_statement"
    MAKING_NOTION_ATTRIBUTE_STATEMENT = "making_notion_attribute_statement"
