from typing import Optional, Callable

from analogai.deepthink.presentation.intent_type import IntentType
from analogai.deepthink.presentation.intents.intent import Intent, NullIntent
from analogai.deepthink.presentation.intents.collection import (
    MakeStatementIntent,
    MakeConditionalStatementIntent,
    MakeNotionAttributeStatementIntent,
)
from analogai.deepthink.presentation.controllers.learning_controller import LearningController
from analogai.deepthink.startup.factories.domain_service_factory import DomainServiceFactory


class IntentsFactory:
    def __init__(
        self,
        domain_service_factory: DomainServiceFactory,
        learning_controller: LearningController,
        aura_service: Optional[object] = None,
    ):
        self.domain_service_factory = domain_service_factory
        self.learning_controller = learning_controller
        self.aura_service = aura_service
        self._null_intent = NullIntent()
        self._intent_builders = self._build_intent_registry()

    def _build_intent_registry(self) -> dict[IntentType, Callable[[], Intent]]:
        learning_controller = self.learning_controller

        return {
            IntentType.MAKING_STATEMENT: lambda: MakeStatementIntent(learning_controller),
            IntentType.MAKING_CAUSAL_STATEMENT: lambda: MakeConditionalStatementIntent(learning_controller),
            IntentType.MAKING_NOTION_ATTRIBUTE_STATEMENT: lambda: MakeNotionAttributeStatementIntent(learning_controller),
        }

    def create_intents(self) -> dict[IntentType, Intent]:
        return {
            intent_type: builder()
            for intent_type, builder in self._intent_builders.items()
        }

    def get_intent(self, intent_type: Optional[IntentType]) -> Intent:
        if intent_type is None:
            return self._null_intent
        builder = self._intent_builders.get(intent_type)
        if builder is None:
            return self._null_intent
        return builder()


