from analogai.deepthink.presentation.interpreters.collection.conditional_statement_interpreter import ConditionalStatementInterpreter
from analogai.deepthink.presentation.interpreters.collection.statement_learning_interpreter import StatementLearningInterpreter
from analogai.deepthink.presentation.interpreters.collection.notion_attribute_statement_interpreter import (
    NotionAttributeStatementInterpreter,
)


class InterpretersFactory:
    def create_all(self):
        return [
            ConditionalStatementInterpreter(),
            NotionAttributeStatementInterpreter(),
            StatementLearningInterpreter(),
        ]




