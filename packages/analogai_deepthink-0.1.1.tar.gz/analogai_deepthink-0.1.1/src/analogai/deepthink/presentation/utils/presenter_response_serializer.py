from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


def serialize_presenter_response(response: PresenterResponse) -> dict:
    return {"message": response.message, "suggestions": response.suggestions}
