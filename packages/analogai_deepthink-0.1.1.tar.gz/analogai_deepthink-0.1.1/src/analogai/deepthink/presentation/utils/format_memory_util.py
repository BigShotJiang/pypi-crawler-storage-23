from analogai.deepthink.presentation.preprocessing.preprocessors.pronoun_preprocessor import preprocess_pronouns


def format_memory(turns, user_id: str | None = None):
    formatted_memory = ""
    for turn in turns:
        formatted_memory += (
            f"Q:{preprocess_pronouns(turn.user_message, user_id=user_id)}\n"
            f"A:{preprocess_pronouns(turn.agent_response, user_id=user_id)}\n"
        )
    return formatted_memory
