from dataclasses import dataclass
from typing import Any

from analogai.deepthink.presentation.intent_type import IntentType


@dataclass
class InterpreterResult:
    intent_type: IntentType
    request: Any
