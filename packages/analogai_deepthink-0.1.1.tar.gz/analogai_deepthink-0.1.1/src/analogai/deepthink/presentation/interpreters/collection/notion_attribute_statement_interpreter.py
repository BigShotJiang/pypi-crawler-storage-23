from analogai.foundation.common.logging.app_logger import app_logger
from analogai.deepthink.presentation.interpreters.interpreter import Interpreter
from analogai.deepthink.presentation.interpreters.interpreter_result import InterpreterResult
from analogai.deepthink.presentation.interpreters.utils.modifier_builder import build_modifier_from_parsed
from analogai.deepthink.application.usecases.learning.learn_statement.models import LearnStatementRequest, StatementType
from analogai.deepthink.presentation.intent_type import IntentType


class NotionAttributeStatementInterpreter(Interpreter):
    def interpret(self, parsed_message, user_agent, message_text):
        if parsed_message is None:
            return None
        if parsed_message.intent_type != IntentType.MAKING_NOTION_ATTRIBUTE_STATEMENT:
            return None
        if not parsed_message.data or not parsed_message.data.subject:
            return None

        modifier = build_modifier_from_parsed(parsed_message.data, user_agent)
        subject_caption = parsed_message.data.subject.caption if parsed_message.data.subject else ""
        app_logger.info(
            "Statement interpreted: type=%s subject=%s",
            StatementType.NOTION_ATTRIBUTE.value,
            subject_caption,
        )
        request = LearnStatementRequest(
            user_agent=user_agent,
            statement_type=StatementType.NOTION_ATTRIBUTE,
            subject=parsed_message.data.subject,
            complement=None,
            relation=parsed_message.data.relation,
            probability=parsed_message.data.probability if parsed_message.data.probability is not None else 1.0,
            modifier=modifier,
            attributes=[],
            quantity=None,
            from_time=parsed_message.data.from_time,
            to_time=parsed_message.data.to_time,
            location=parsed_message.data.location,
            deontic_modality=parsed_message.data.deontic_modality,
        )
        return InterpreterResult(
            intent_type=IntentType.MAKING_NOTION_ATTRIBUTE_STATEMENT,
            request=request,
        )
