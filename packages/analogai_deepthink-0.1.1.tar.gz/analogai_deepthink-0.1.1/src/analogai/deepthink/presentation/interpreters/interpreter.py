from typing import Any

from analogai.deepthink.presentation.interpreters.interpreter_result import InterpreterResult


class Interpreter:
    def interpret(
        self,
        parsed_message: Any,
        user_agent: Any,
        message_text: str,
    ) -> InterpreterResult | None | bool:
        raise NotImplementedError("Subclasses must implement this method")

