from dataclasses import dataclass
from typing import Optional, Any

from analogai.deepthink.presentation.intent_type import IntentType
# from analogai.deepthink.presentation.user_message import UserMessage
from analogai.deepthink.presentation.pipeline.results import (
    PreprocessResult,
    TransformResult,
    ParseResult,
    InterpretResult,
    IntentResult,
    PostprocessResult,
    OutputResult,
)


@dataclass
class PipelineState:
    # raw_message: str
    user_agent: Optional[Any] = None
    message_text: Optional[str] = None
    intent_type: Optional[IntentType] = None
    request: Optional[Any] = None
    preprocess_result: Optional[PreprocessResult] = None
    transform_result: Optional[TransformResult] = None
    parse_result: Optional[ParseResult] = None
    interpret_result: Optional[InterpretResult] = None
    intent_result: Optional[IntentResult] = None
    postprocess_result: Optional[PostprocessResult] = None
    output_result: Optional[OutputResult] = None
