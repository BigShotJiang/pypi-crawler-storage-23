from dataclasses import dataclass
from typing import Optional, List

# from analogai.deepthink.presentation.agent_message import AgentMessage
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse
from analogai.deepthink.presentation.intent_type import IntentType
from analogai.deepthink.presentation.interpreters.interpreter_result import InterpreterResult
from analogai.deepthink.presentation.parsers.parsed_sentence import ParsedSentence


@dataclass
class PreprocessResult:
    text: str


@dataclass
class TransformResult:
    text: str


@dataclass
class ParseResult:
    parsed_message: Optional[ParsedSentence]


@dataclass
class InterpretResult:
    result: Optional[InterpreterResult]


@dataclass
class IntentResult:
    intent_type: Optional[IntentType]
    response: Optional[PresenterResponse]


@dataclass
class PostprocessResult:
    message_text: str
    suggestions: List[str]


@dataclass
class OutputResult:
    agent_message: Optional[str]


@dataclass
class PipelineOutput:
    message_text: Optional[str]
    suggestions: List[str]
    transformed_json: Optional[str] = None