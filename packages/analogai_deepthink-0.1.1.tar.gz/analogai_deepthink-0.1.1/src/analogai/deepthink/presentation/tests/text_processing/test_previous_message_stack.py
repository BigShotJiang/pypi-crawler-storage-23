import unittest
from analogai.deepthink.presentation.preprocessing.previous_messages_stack import PreviousMessagesStack


class TestPreviousMessageStack(unittest.TestCase):
    def test_limits_history(self):
        store = PreviousMessagesStack(maxlen=5)
        for i in range(6):
            store.add(f"text {i}")
        history = store.get_history()
        self.assertEqual(len(history), 5)
        self.assertEqual(history[0], "text 1")
        self.assertEqual(history[-1], "text 5")


if __name__ == "__main__":
    unittest.main()

