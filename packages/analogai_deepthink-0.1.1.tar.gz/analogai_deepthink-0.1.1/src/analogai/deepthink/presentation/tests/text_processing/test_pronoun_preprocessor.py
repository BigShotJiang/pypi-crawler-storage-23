import unittest
from analogai.deepthink.presentation.preprocessing.preprocessors.pronoun_preprocessor import (
    preprocess_pronouns,
)
from analogai.deepthink.presentation.enums.pronoun_placeholder import PronounPlaceholder


class TestPronounPreprocessor(unittest.TestCase):
    def test_preprocess_pronouns_you_to_agent_placeholder(self):
        result = preprocess_pronouns("you are great")
        self.assertEqual(result, f"{PronounPlaceholder.AGENT_PLACEHOLDER.value} is great")

    def test_preprocess_pronouns_your_to_agent_placeholder_s(self):
        result = preprocess_pronouns("your voice sounds good")
        self.assertEqual(result, f"{PronounPlaceholder.AGENT_PLACEHOLDER.value}'s voice sounds good")

    def test_preprocess_pronouns_we_becomes_company_placeholder(self):
        result = preprocess_pronouns("we sell iphones")
        self.assertEqual(result, f"{PronounPlaceholder.COMPANY_PLACEHOLDER.value} sell iphones")

    def test_preprocess_pronouns_our_becomes_company_placeholder(self):
        result = preprocess_pronouns("our products are good")
        self.assertEqual(result, f"{PronounPlaceholder.COMPANY_PLACEHOLDER.value}'s products are good")

    def test_preprocess_pronouns_i_to_respondent_placeholder(self):
        result = preprocess_pronouns("i am here")
        self.assertEqual(result, f"{PronounPlaceholder.RESPONDENT_PLACEHOLDER.value} is here")

    def test_preprocess_pronouns_am_respondent_to_is_respondent(self):
        respondent = PronounPlaceholder.RESPONDENT_PLACEHOLDER.value
        result = preprocess_pronouns(f"am {respondent} here")
        self.assertEqual(result, f"is {respondent} here")

    def test_preprocess_pronouns_agent_are_to_agent_is(self):
        agent = PronounPlaceholder.AGENT_PLACEHOLDER.value
        result = preprocess_pronouns(f"{agent} are nice")
        self.assertEqual(result, f"{agent} is nice")

    def test_preprocess_pronouns_are_agent_to_is_agent(self):
        agent = PronounPlaceholder.AGENT_PLACEHOLDER.value
        result = preprocess_pronouns(f"are {agent} nice")
        self.assertEqual(result, f"is {agent} nice")

    def test_preprocess_pronouns_my_to_respondent_placeholder_s(self):
        result = preprocess_pronouns("my name is john")
        self.assertEqual(result, f"{PronounPlaceholder.RESPONDENT_PLACEHOLDER.value}'s name is john")

    def test_preprocess_pronouns_complex_sentence(self):
        result = preprocess_pronouns("i think you are great and we should work together")
        agent = PronounPlaceholder.AGENT_PLACEHOLDER.value
        company = PronounPlaceholder.COMPANY_PLACEHOLDER.value
        respondent = PronounPlaceholder.RESPONDENT_PLACEHOLDER.value
        self.assertEqual(
            result,
            f"{respondent} think {agent} is great and {company} should work together"
        )

    def test_preprocess_pronouns_from_pronoun_you_capitalized(self):
        result = preprocess_pronouns("You are great")
        self.assertEqual(result, f"{PronounPlaceholder.AGENT_PLACEHOLDER.value} is great")

    def test_preprocess_pronouns_from_pronoun_i_capitalized(self):
        result = preprocess_pronouns("I think so")
        self.assertEqual(result, f"{PronounPlaceholder.RESPONDENT_PLACEHOLDER.value} think so")


if __name__ == "__main__":
    unittest.main()