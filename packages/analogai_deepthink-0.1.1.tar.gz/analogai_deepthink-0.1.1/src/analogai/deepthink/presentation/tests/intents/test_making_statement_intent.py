import unittest
from analogai.foundation.common.enums import RelationshipType
from analogai.foundation.common.dtos.belief_expression import Relation
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.deepthink.application.usecases.learning.learn_statement.models import LearnStatementRequest, StatementType
from analogai.deepthink.application.value_objects.user_agent import UserAgent
from analogai.deepthink.presentation.intents.collection.learning.make_statement_intent import MakeStatementIntent


class _LearningController:
    def __init__(self):
        self.learn_calls = 0
        self.learned_requests = []

    def learn_statement(self, request):
        self.learn_calls += 1
        self.learned_requests.append(request)
        return "learned"


class TestMakeStatementIntent(unittest.TestCase):
    def setUp(self):
        self.learning_controller = _LearningController()
        self.intent = MakeStatementIntent(self.learning_controller)

    def test_executes_with_learn_statement_request(self):
        user_agent = UserAgent(user_id="u", agent_id="a", user_authority=1.0)
        request = LearnStatementRequest(
            user_agent=user_agent,
            statement_type=StatementType.SIMPLE,
            subject=NotionExpression(caption="human"),
            complement=NotionExpression(caption="mortal"),
            relation=Relation.from_type(RelationshipType.IS_A),
            probability=0.9,
            modifier=None,
        )
        result = self.intent.execute(request)
        self.assertEqual(result, "learned")
        self.assertEqual(self.learning_controller.learn_calls, 1)

    def test_returns_none_when_request_is_none(self):
        result = self.intent.execute(None)
        self.assertIsNone(result)
        self.assertEqual(self.learning_controller.learn_calls, 0)

if __name__ == "__main__":
    unittest.main()



