import unittest
from typing import Optional, Any
from analogai.deepthink.presentation.intents.intents_processor import IntentsProcessor
from analogai.deepthink.presentation.intents.intent import Intent, NullIntent
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse
from analogai.deepthink.presentation.intent_type import IntentType


class _FakeIntent(Intent):
    def __init__(self, name: str, responses: list[Optional[str]]):
        self.name = name
        self.responses = responses

    def execute(self, request: Any) -> Optional[PresenterResponse]:
        response = self.responses.pop(0) if self.responses else None
        if response is None:
            return None
        return PresenterResponse(message=response)


class _FakeIntentsFactory:
    def __init__(self, intents: dict[IntentType, Intent]):
        self._intents = intents
        self._null_intent = NullIntent()

    def create_intents(self):
        return self._intents

    def get_intent(self, intent_type: Optional[IntentType]) -> Intent:
        if intent_type is None:
            return self._null_intent
        return self._intents.get(intent_type, self._null_intent)


class TestIntentsProcessor(unittest.TestCase):
    def setUp(self):
        self.user_message = "hi"

    def test_returns_none_when_intent_type_is_none(self):
        processor = IntentsProcessor(_FakeIntentsFactory({}))
        result = processor.execute(None, self.user_message)
        self.assertIsNone(result)

    def test_routes_request_to_intent(self):
        intent = _FakeIntent("i1", ["res"])
        factory = _FakeIntentsFactory({IntentType.MAKING_STATEMENT: intent})
        processor = IntentsProcessor(factory)
        result = processor.execute(IntentType.MAKING_STATEMENT, self.user_message)
        self.assertIsNotNone(result)
        self.assertEqual(result.message, "res")

    def test_returns_none_when_intent_not_found(self):
        factory = _FakeIntentsFactory({})
        processor = IntentsProcessor(factory)
        result = processor.execute(IntentType.MAKING_STATEMENT, self.user_message)
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()




