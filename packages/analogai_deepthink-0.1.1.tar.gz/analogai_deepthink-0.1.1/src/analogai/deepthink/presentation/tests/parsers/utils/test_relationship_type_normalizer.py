import unittest
from analogai.foundation.common.enums import RelationshipType
from analogai.deepthink.presentation.parsers.utils.relationship_type_normalizer import (
    tag_key_to_relationship_type,
    relationship_type_tag_keys,
)


class TestTagKeyToRelationshipType(unittest.TestCase):
    def test_matches_enum_name_lower(self):
        self.assertEqual(tag_key_to_relationship_type("IS_A"), RelationshipType.IS_A)
        self.assertEqual(tag_key_to_relationship_type("is_a"), RelationshipType.IS_A)

    def test_matches_enum_value(self):
        self.assertEqual(tag_key_to_relationship_type("is"), RelationshipType.IS_A)
        self.assertEqual(tag_key_to_relationship_type("do"), RelationshipType.DO)

    def test_normalizes_spaces_to_underscores(self):
        self.assertEqual(tag_key_to_relationship_type("  is  "), RelationshipType.IS_A)

    def test_matches_has_property(self):
        self.assertEqual(tag_key_to_relationship_type("has property"), RelationshipType.HAS_PROPERTY)
        self.assertEqual(tag_key_to_relationship_type("has_property"), RelationshipType.HAS_PROPERTY)
        self.assertEqual(tag_key_to_relationship_type("HAS_PROPERTY"), RelationshipType.HAS_PROPERTY)

    def test_returns_none_for_unknown(self):
        self.assertIsNone(tag_key_to_relationship_type("unknown"))
        self.assertIsNone(tag_key_to_relationship_type(""))


class TestRelationshipTypeTagKeys(unittest.TestCase):
    def test_yields_value_and_name_for_each_enum(self):
        keys_and_rt = list(relationship_type_tag_keys())
        self.assertIn(("do", RelationshipType.DO), keys_and_rt)
        self.assertIn(("is", RelationshipType.IS_A), keys_and_rt)


if __name__ == "__main__":
    unittest.main()
