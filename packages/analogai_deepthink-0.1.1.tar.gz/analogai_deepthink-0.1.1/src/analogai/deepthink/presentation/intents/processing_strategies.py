from abc import ABC, abstractmethod
from typing import Optional, Any
from analogai.deepthink.presentation.intents.intent import Intent
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class IntentProcessingStrategy(ABC):
	@abstractmethod
	def execute(self, request: Any) -> tuple[Optional[PresenterResponse], Optional[Intent]]:
		pass


class ContextualIntentStrategy(IntentProcessingStrategy):
	def __init__(self, last_successful_intent: Intent):
		self._last_successful_intent = last_successful_intent
 
	def execute(self, request: Any) -> tuple[Optional[PresenterResponse], Optional[Intent]]:
		result = self._last_successful_intent.execute(request)
		return result if result is not None else None, None


class DefaultIntentStrategy(IntentProcessingStrategy):
	def __init__(self, intents: list[Intent]):
		self._intents = intents
 
	def execute(self, request: Any) -> tuple[Optional[PresenterResponse], Optional[Intent]]:
		for intent in self._intents:
			result = intent.execute(request)
			if result is not None:
				return result, intent
		return None, None



