from abc import ABC, abstractmethod
from typing import Optional, Any
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class Intent(ABC):
	@abstractmethod
	def execute(self, request: Any) -> Optional[PresenterResponse]:
		pass


class NullIntent(Intent):
	def execute(self, request: Any) -> Optional[PresenterResponse]:
		return None



