from typing import Optional, Any
from analogai.deepthink.presentation.intents.intent import Intent
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse
from analogai.foundation.common.logging.app_logger import app_logger


class MakeConditionalStatementIntent(Intent):
    def __init__(self, controller):
        self.controller = controller

    def execute(self, request: Any) -> Optional[PresenterResponse]:
        app_logger.important("Processing make conditional statement intent")
        if request is None:
            app_logger.warning("[MakeConditionalStatementIntent] request is None")
            return None
        return self.controller.learn_conditional_statement(request)
