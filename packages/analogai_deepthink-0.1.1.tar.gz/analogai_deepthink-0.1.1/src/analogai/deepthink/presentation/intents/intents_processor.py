from typing import Optional, Any
from analogai.deepthink.presentation.factories.intents_factory import IntentsFactory
from analogai.deepthink.presentation.intent_type import IntentType
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class IntentsProcessor:
	def __init__(self, intents_factory: IntentsFactory):
		self.intents_factory = intents_factory

	def execute(self, intent_type: Optional[IntentType], request: Any) -> Optional[PresenterResponse]:
		return self.intents_factory.get_intent(intent_type).execute(request)


