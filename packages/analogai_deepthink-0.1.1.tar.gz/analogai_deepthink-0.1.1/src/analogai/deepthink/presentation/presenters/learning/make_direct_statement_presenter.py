from analogai.deepthink.application.usecases.learning.make_direct_statement.models import MakeDirectStatementResponse
from analogai.deepthink.application.usecases.learning.make_direct_statement.ports import MakeStatementOutputPort
from analogai.foundation.common.enums import RelationshipType
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse
from analogai.foundation.common.utils.expressions_serializer import serialize_belief_expression
from analogai.foundation.common.logging.app_logger import app_logger


class MakeDirectStatementPresenter(MakeStatementOutputPort):
    """
    Presenter for simple statement responses.
    Handles formatting of belief expressions for display.
    """
    
    def output_create_statement_success(self, response: MakeDirectStatementResponse):
        belief = response.belief_expression

        app_logger.info(f"Outputting learning success: {repr(belief)}")
        
        message = serialize_belief_expression(
            belief,
            timezone=response.user_agent.timezone,
        )
        
        return PresenterResponse(message=message)

    def output_statement_already_known(self, response: MakeDirectStatementResponse):
        belief = response.belief_expression

        app_logger.info("Outputting statement already known")
        serialized = serialize_belief_expression(belief)
        return PresenterResponse(message=f"{serialized}")

    def output_statement_update_success(self, response: MakeDirectStatementResponse):
        belief = response.belief_expression

        app_logger.info("Outputting statement update success")
        serialized = serialize_belief_expression(belief)
        return PresenterResponse(message=f"I see, will remember, that {serialized}")

    def output_update_not_applicable(self, response: MakeDirectStatementResponse):
        belief = response.belief_expression

        app_logger.info("Outputting update not applicable from learning response interface")
        serialized = serialize_belief_expression(belief)
        return PresenterResponse(message=f"I believe that {serialized}, will ask my companions about it")

    def output_forbidden(self, response: MakeDirectStatementResponse):
        app_logger.info("Outputting forbidden direct statement")
        return self.output_create_statement_success(response)

