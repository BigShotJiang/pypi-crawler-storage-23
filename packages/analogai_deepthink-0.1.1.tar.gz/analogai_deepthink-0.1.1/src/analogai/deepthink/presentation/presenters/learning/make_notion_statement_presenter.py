from analogai.foundation.common.logging.app_logger import app_logger
from analogai.foundation.common.utils.statement_serializers.notion_serializer import (
    serialize_notion_expression,
)

from analogai.deepthink.application.usecases.learning.make_notion_statement.models import (
    MakeNotionStatementResponse,
)
from analogai.deepthink.application.usecases.learning.make_notion_statement.ports import (
    MakeNotionStatementOutputPort,
)
from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse


class MakeNotionStatementPresenter(MakeNotionStatementOutputPort):
    def output_notion_statement_saved(
        self,
        response: MakeNotionStatementResponse,
    ) -> PresenterResponse:
        app_logger.info("Outputting notion statement saved")
        message = serialize_notion_expression(response.notion_expression)
        return PresenterResponse(message=message)
