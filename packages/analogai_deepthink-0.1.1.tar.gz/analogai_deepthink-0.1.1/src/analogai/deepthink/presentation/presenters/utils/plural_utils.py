IRREGULAR_PAST = {
    "sell": "sold",
    "buy": "bought",
    "make": "made",
    "do": "did",
    "have": "had",
    "go": "went",
    "get": "got",
    "take": "took",
    "give": "gave",
    "see": "saw",
    "come": "came",
    "think": "thought",
    "find": "found",
    "tell": "told",
    "know": "knew",
    "become": "became",
    "leave": "left",
    "put": "put",
    "mean": "meant",
    "keep": "kept",
    "let": "let",
    "begin": "began",
    "seem": "seemed",
    "help": "helped",
    "show": "showed",
    "hear": "heard",
    "play": "played",
    "run": "ran",
    "move": "moved",
    "live": "lived",
    "believe": "believed",
    "hold": "held",
    "bring": "brought",
    "happen": "happened",
    "write": "wrote",
    "provide": "provided",
    "sit": "sat",
    "stand": "stood",
    "lose": "lost",
    "pay": "paid",
    "meet": "met",
    "include": "included",
    "continue": "continued",
    "set": "set",
    "learn": "learned",
    "change": "changed",
    "lead": "led",
    "understand": "understood",
    "watch": "watched",
    "follow": "followed",
    "stop": "stopped",
    "create": "created",
    "speak": "spoke",
    "read": "read",
    "allow": "allowed",
    "add": "added",
    "spend": "spent",
    "grow": "grew",
    "open": "opened",
    "walk": "walked",
    "win": "won",
    "offer": "offered",
    "remember": "remembered",
    "love": "loved",
    "consider": "considered",
    "appear": "appeared",
    "wait": "waited",
    "serve": "served",
    "die": "died",
    "send": "sent",
    "expect": "expected",
    "build": "built",
    "stay": "stayed",
    "fall": "fell",
    "cut": "cut",
    "reach": "reached",
    "kill": "killed",
    "remain": "remained",
    "suggest": "suggested",
    "raise": "raised",
    "pass": "passed",
}


def to_past_tense(verb: str) -> str:
    if not verb:
        return ""
    lower = verb.lower()
    if lower in IRREGULAR_PAST:
        return IRREGULAR_PAST[lower]
    return lower + "d" if lower.endswith("e") else lower + "ed"


def pluralize_category(category_caption: str | None) -> str:
    if not category_caption:
        return ""
    if category_caption.endswith("s"):
        return category_caption
    return category_caption + "s"


def get_plural_relationship(relation: str) -> str:
    relation_value = relation

    if not relation_value:
        relation_value = "related to"

    try:
        from analogai.foundation.common.utils.statement_serializer.relation_verbalization_map import (
            RELATION_TO_VERBALIZATION,
        )
        from analogai.foundation.common.utils.statement_serializer import Verbalization
    except ModuleNotFoundError:
        try:
            from analogai.foundation.common.utils.statement_serializers.relation_verbalization_map import (
                RELATION_TO_VERBALIZATION,
            )
            from analogai.foundation.common.utils.statement_serializers import Verbalization
        except ModuleNotFoundError:
            return str(relation_value)

    verbalization = RELATION_TO_VERBALIZATION.get(relation_value)
    if verbalization is None:
        verbalization = Verbalization.RELATED_TO
    forms = verbalization._forms(is_plural=True)
    return forms["positive"]
