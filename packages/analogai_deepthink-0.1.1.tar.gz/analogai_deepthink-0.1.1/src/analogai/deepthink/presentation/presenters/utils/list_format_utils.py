def format_items_and(items: list[str]) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return ", ".join(items[:-1]) + f", and {items[-1]}"


def format_items_and_capitalized(items: list[str]) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0].capitalize()
    if len(items) == 2:
        return f"{items[0].capitalize()} and {items[1].capitalize()}"
    return ", ".join(n.capitalize() for n in items[:-1]) + f", and {items[-1].capitalize()}"
