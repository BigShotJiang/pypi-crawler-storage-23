from analogai.deepthink.application.usecases.learning.make_statement_statement.ports import statementStatementOutputPort


class LearningStatementPresenter(LearningStatementOutputPort):
    def output(self, result):
        return result
