from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class PresenterResponse:
    message: Optional[str]
    suggestions: List[str] = field(default_factory=list)

