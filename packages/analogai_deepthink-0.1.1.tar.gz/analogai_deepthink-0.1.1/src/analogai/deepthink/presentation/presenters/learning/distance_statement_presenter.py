from analogai.deepthink.presentation.presenters.presenter_response import PresenterResponse
from analogai.deepthink.application.usecases.learning.make_distance_statement.ports import DistanceStatementOutputPort


class DistanceStatementPresenter(DistanceStatementOutputPort):
    def output(self, result):
        if result is None:
            return PresenterResponse(message="I couldn't save that distance.")
        return PresenterResponse(message="I've learned that distance.")
