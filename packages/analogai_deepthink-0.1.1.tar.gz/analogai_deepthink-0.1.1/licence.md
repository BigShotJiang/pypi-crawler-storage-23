# Functional Source License, Version 1.1

## Parameters

- **Licensor:** AnalogAI
- **Software:** Deepthink
- **Additional Use Grant:** None
- **Change Date:** 2028-03-02
- **Change License:** MIT

## Terms

### 1. Definitions

- **Licensor** means the copyright owner or entity granting this license.
- **Software** means the software specified in the Parameters section.
- **You** (or **Your**) means an individual or a legal entity exercising permissions granted by this license.
- **Change Date** means the date specified in the Parameters section.
- **Change License** means the license specified in the Parameters section that will apply on and after the Change Date.
- **Additional Use Grant** means any additional permissions specified in the Parameters section.

### 2. License Grant

Subject to the terms and conditions of this license, the Licensor hereby grants You a non-exclusive, worldwide, royalty-free license to use, copy, modify, and distribute the Software.

### 3. Limitations

You may not use the Software for a purpose not permitted by the Functional Source License until the Change Date, unless an Additional Use Grant explicitly permits that use.

### 4. Change License

On the Change Date, the Licensor will grant You a license to the Software under the Change License. From that date forward, the Software will be available under the terms of the Change License.

### 5. Compliance

If You violate any term of this license, your rights under this license automatically terminate. If You cure the violation within 30 days of becoming aware of it, your rights are reinstated.

### 6. Disclaimer of Warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE LICENSOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
