import argparse
from pathlib import Path

from dsp_tools.cli.args import NetworkRequirements
from dsp_tools.cli.args import PathDependencies
from dsp_tools.cli.args import ProhibitedPaths
from dsp_tools.cli.args import ValidationSeverity
from dsp_tools.cli.utils import check_docker_health
from dsp_tools.cli.utils import check_input_dependencies
from dsp_tools.cli.utils import get_canonical_server_and_dsp_ingest_url
from dsp_tools.cli.utils import get_creds
from dsp_tools.commands.create.create import create
from dsp_tools.commands.create.lists_only import create_lists_only
from dsp_tools.commands.create.project_validate import validate_project_only
from dsp_tools.commands.excel2json.old_lists import validate_lists_section_from_project
from dsp_tools.commands.get.get import get_project
from dsp_tools.commands.ingest_xmlupload.create_resources.upload_xml import ingest_xmlupload
from dsp_tools.commands.ingest_xmlupload.ingest_files.ingest_files import ingest_files
from dsp_tools.commands.ingest_xmlupload.upload_files.upload_files import upload_files
from dsp_tools.commands.migration.config_file import parse_config_file
from dsp_tools.commands.migration.download import download
from dsp_tools.commands.migration.exceptions import InvalidMigrationConfigFile
from dsp_tools.commands.migration.export import export
from dsp_tools.commands.migration.import_zip import import_zip
from dsp_tools.commands.resume_xmlupload.resume_xmlupload import resume_xmlupload
from dsp_tools.commands.start_stack.start_stack import StackConfiguration
from dsp_tools.commands.start_stack.start_stack import StackHandler
from dsp_tools.commands.validate_data.validate_data import validate_data
from dsp_tools.commands.xmlupload.upload_config import UploadConfig
from dsp_tools.commands.xmlupload.xmlupload import xmlupload
from dsp_tools.error.exceptions import UnreachableCodeError
from dsp_tools.utils.xml_parsing.parse_clean_validate_xml import parse_and_validate_xml_file


def call_start_stack(args: argparse.Namespace) -> bool:
    check_docker_health()
    stack_handler = StackHandler(
        StackConfiguration(
            max_file_size=args.max_file_size,
            enforce_docker_system_prune=args.prune,
            suppress_docker_system_prune=args.no_prune,
            latest_dev_version=args.latest,
            upload_test_data=args.with_test_data,
            custom_host=args.custom_host,
        )
    )
    return stack_handler.start_stack()


def call_stop_stack() -> bool:
    check_docker_health()
    stack_handler = StackHandler(StackConfiguration())
    return stack_handler.stop_stack()


def call_upload_files(args: argparse.Namespace) -> bool:
    xml_path = Path(args.xml_file)
    image_dir = Path(args.imgdir)
    network_requirements = NetworkRequirements(api_url=args.server)
    path_requirements = PathDependencies([xml_path], required_directories=[image_dir])
    check_input_dependencies(path_requirements, network_requirements)

    return upload_files(
        xml_file=xml_path,
        creds=get_creds(args),
        imgdir=image_dir,
    )


def call_ingest_files(args: argparse.Namespace) -> bool:
    check_input_dependencies(network_dependencies=NetworkRequirements(api_url=args.server))
    return ingest_files(creds=get_creds(args), shortcode=args.shortcode)


def call_ingest_xmlupload(args: argparse.Namespace) -> bool:
    xml_path = Path(args.xml_file)
    required_files = [xml_path]
    id2iri_file = args.id2iri_file
    if id2iri_file:
        required_files.append(Path(id2iri_file))
    always_requires_docker = False if args.skip_validation else True
    network_requirements = NetworkRequirements(args.server, always_requires_docker=always_requires_docker)
    path_deps = PathDependencies(required_files)
    check_input_dependencies(path_deps, network_requirements)

    interrupt_after = args.interrupt_after if args.interrupt_after > 0 else None
    return ingest_xmlupload(
        xml_file=xml_path,
        creds=get_creds(args),
        interrupt_after=interrupt_after,
        skip_validation=args.skip_validation,
        skip_ontology_validation=args.skip_ontology_validation,
        id2iri_file=id2iri_file,
        do_not_request_resource_metadata_from_db=args.do_not_request_resource_metadata_from_db,
    )


def call_xmlupload(args: argparse.Namespace) -> bool:
    xml_path = Path(args.xmlfile)
    required_files = [xml_path]
    id2iri_file = args.id2iri_file
    if id2iri_file:
        required_files.append(Path(id2iri_file))
    always_requires_docker = False if args.skip_validation else True
    network_requirements = NetworkRequirements(args.server, always_requires_docker=always_requires_docker)
    path_deps = PathDependencies(required_files, [Path(args.imgdir)])
    check_input_dependencies(path_deps, network_requirements)

    if args.validate_only:
        if parse_and_validate_xml_file(xml_path):
            print("The XML file is syntactically correct.")
            return True
        else:
            return False  # detailed error report has already been printed
    else:
        interrupt_after = args.interrupt_after if args.interrupt_after > 0 else None
        match args.validation_severity:
            case "info":
                severity = ValidationSeverity.INFO
            case "warning":
                severity = ValidationSeverity.WARNING
            case "error":
                severity = ValidationSeverity.ERROR
            case _:
                raise UnreachableCodeError()
        return xmlupload(
            input_file=xml_path,
            creds=get_creds(args),
            imgdir=args.imgdir,
            config=UploadConfig(
                interrupt_after=interrupt_after,
                skip_iiif_validation=args.no_iiif_uri_validation,
                skip_validation=args.skip_validation,
                ignore_duplicate_files_warning=args.ignore_duplicate_files_warning,
                validation_severity=severity,
                skip_ontology_validation=args.skip_ontology_validation,
                do_not_request_resource_metadata_from_db=args.do_not_request_resource_metadata_from_db,
                id2iri_file=id2iri_file,
            ),
        )


def call_validate_data(args: argparse.Namespace) -> bool:
    xml_path = Path(args.xmlfile)
    required_files = [xml_path]
    id2iri_file = args.id2iri_file
    if id2iri_file:
        required_files.append(Path(id2iri_file))
    network_requirements = NetworkRequirements(args.server, always_requires_docker=True)
    path_deps = PathDependencies(required_files)
    check_input_dependencies(path_deps, network_requirements)

    return validate_data(
        filepath=xml_path,
        creds=get_creds(args),
        save_graphs=args.save_graphs,
        ignore_duplicate_files_warning=args.ignore_duplicate_files_warning,
        skip_ontology_validation=args.skip_ontology_validation,
        id2iri_file=id2iri_file,
        do_not_request_resource_metadata_from_db=args.do_not_request_resource_metadata_from_db,
    )


def call_resume_xmlupload(args: argparse.Namespace) -> bool:
    # this does not need docker if not on localhost, as does not need to validate
    check_input_dependencies(network_dependencies=NetworkRequirements(args.server))
    return resume_xmlupload(
        creds=get_creds(args),
        skip_first_resource=args.skip_first_resource,
    )


def call_get(args: argparse.Namespace) -> bool:
    network_dependencies = NetworkRequirements(args.server)
    path_dependencies = PathDependencies(required_directories=[Path(args.project_definition).parent])
    check_input_dependencies(path_dependencies, network_dependencies)

    return get_project(
        project_identifier=args.project,
        outfile_path=args.project_definition,
        creds=get_creds(args),
        verbose=args.verbose,
    )


def call_create(args: argparse.Namespace) -> bool:
    network_dependencies = NetworkRequirements(args.server)
    path_dependencies = PathDependencies([Path(args.project_definition)])
    check_input_dependencies(path_dependencies, network_dependencies)
    project_file = Path(args.project_definition)
    creds = get_creds(args)

    success = False
    match args.lists_only, args.validate_only:
        case True, True:
            success = validate_lists_section_from_project(project_file)
            print("'Lists' section of the JSON project file is syntactically correct and passed validation.")
        case True, False:
            success = create_lists_only(
                project_file=project_file,
                creds=creds,
            )
        case False, True:
            success = validate_project_only(project_file, creds.server)
        case False, False:
            success = create(
                project_file=project_file,
                creds=creds,
                exit_if_exists=args.exit_if_exists,
            )
    return success


def call_migration_export(args: argparse.Namespace) -> bool:
    config_path = Path(args.config_file)
    check_input_dependencies(required_paths=PathDependencies([config_path]))
    migration_info = parse_config_file(config_path)
    if migration_info.source is None:
        raise InvalidMigrationConfigFile(
            f"The config file '{config_path}' must contain a 'source-server' section for the export command."
        )
    server, _ = get_canonical_server_and_dsp_ingest_url(migration_info.source.server)
    migration_info.source.server = server
    check_input_dependencies(
        network_dependencies=NetworkRequirements(migration_info.source.server),
        prohibited_paths=ProhibitedPaths([migration_info.config.reference_savepath]),
    )
    return export(migration_info.source, migration_info.config)


def call_migration_download(args: argparse.Namespace) -> bool:
    config_path = Path(args.config_file)
    check_input_dependencies(required_paths=PathDependencies([config_path]))
    migration_info = parse_config_file(config_path)
    if migration_info.source is None:
        raise InvalidMigrationConfigFile(
            f"The config file '{config_path}' must contain a 'source-server' section for the download command."
        )
    server, _ = get_canonical_server_and_dsp_ingest_url(migration_info.source.server)
    migration_info.source.server = server
    check_input_dependencies(
        network_dependencies=NetworkRequirements(migration_info.source.server),
        required_paths=PathDependencies([migration_info.config.reference_savepath]),
        prohibited_paths=ProhibitedPaths([migration_info.config.export_savepath]),
    )
    return download(migration_info.source, migration_info.config)


def call_migration_import(args: argparse.Namespace) -> bool:
    config_path = Path(args.config_file)
    check_input_dependencies(required_paths=PathDependencies([config_path]))
    migration_info = parse_config_file(config_path)
    if migration_info.target is None:
        raise InvalidMigrationConfigFile(
            f"The config file '{config_path}' must contain a 'target-server' section for the import command."
        )
    server, _ = get_canonical_server_and_dsp_ingest_url(migration_info.target.server)
    migration_info.target.server = server
    check_input_dependencies(
        network_dependencies=NetworkRequirements(migration_info.target.server),
        required_paths=PathDependencies(
            [migration_info.config.reference_savepath, migration_info.config.export_savepath]
        ),
    )
    return import_zip(migration_info.target, migration_info.config)
