## [0.4.5](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.4...v0.4.5) (2026-02-21)


### Bug Fixes

* counter for security findings in navigation ([f762720](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/f762720bb1d8d1bd63e69aab2b4c71c43b22e64b))

## [0.4.4](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.3...v0.4.4) (2026-02-21)


### Bug Fixes

* show detected cleartext pws in description/info fields ([bcdfc22](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/bcdfc223e00bd696b3145c1c146967eb48ebb629))

## [0.4.3](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.2...v0.4.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([93d9e4b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/93d9e4b36c6fb417549e805788db60099735fb09))

## [0.4.2](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.1...v0.4.2) (2026-02-21)


### Bug Fixes

* column sorting bug ([158ddfa](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/158ddfafe5f1d9ae8b72bafa6a9b393f9a1d067f))

## [0.4.1](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.0...v0.4.1) (2026-02-21)


### Bug Fixes

* --no-dashboard ([3c0768a](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/3c0768a2817c41c7eaa70534a31aa869b049b05a))

