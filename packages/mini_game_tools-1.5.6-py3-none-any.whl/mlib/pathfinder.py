# spath.py - 广度优先搜索寻路
from .svector import vec2

def bfs(grid, start, end):
    """
    广度优先搜索寻路 - 保证最短路径
    
    参数:
        grid: 二维列表，0=可走，1=障碍
        start: (x, y) 或 vec2
        end: (x, y) 或 vec2
    
    返回:
        路径列表 [(x1,y1), (x2,y2), ...] 或 None
    """
    # 转成元组好处理
    start = (int(start[0]), int(start[1]))
    end = (int(end[0]), int(end[1]))
    
    # 检查起点终点
    if not _is_passable(grid, start) or not _is_passable(grid, end):
        return None
    
    # 手动实现队列：列表 + 头尾指针
    queue = [start]          # 队列
    queue_head = 0           # 队头指针
    
    # 记录路径
    came_from = {start: None}
    
    # BFS主循环
    while queue_head < len(queue):
        current = queue[queue_head]
        queue_head += 1
        
        # 到达终点
        if current == end:
            return _reconstruct_path(came_from, start, end)
        
        x, y = current
        # 4方向探索
        
        """BFS但优先探索靠近终点的方向"""
        # 可以排序邻居：先走曼哈顿距离小的方向
        directions = [(0,1), (1,0), (0,-1), (-1,0)]
        # 按曼哈顿距离排序
        directions.sort(key=lambda d: abs(end[0]-(start[0]+d[0])) + 
                                     abs(end[1]-(start[1]+d[1])))
        for dx, dy in [(0,1), (1,0), (0,-1), (-1,0)]:
            nx, ny = x + dx, y + dy
            neighbor = (nx, ny)
            
            # 如果可走且没访问过
            if _is_passable(grid, neighbor) and neighbor not in came_from:
                came_from[neighbor] = current
                queue.append(neighbor)
    
    return None  # 没找到路径


def _is_passable(grid, pos):
    """检查位置是否可通行"""
    x, y = pos
    if y < 0 or y >= len(grid) or x < 0 or x >= len(grid[0]):
        return False
    return grid[y][x] == 0


def _reconstruct_path(came_from, start, end):
    """重建路径"""
    path = []
    current = end
    
    while current != start:
        path.append(current)
        current = came_from[current]
    
    path.append(start)
    path.reverse()
    
    # 转成vec2列表
    return [vec2(x, y) for x, y in path]


# 使用示例
if __name__ == "__main__":
    # 测试地图
    grid = [
        [0,0,0,0,0],
        [0,1,1,1,1],
        [0,0,1,0,0],
        [0,1,1,1,0],
        [0,0,0,0,0]
    ]
    
    path = bfs(grid, (0,0), (4,4))
    if path:
        print("找到路径:", [(p.x, p.y) for p in path])
    else:
        print("没找到路径")
    
    # 测试2: 直线路径
    path2 = bfs(grid, (0,0), (0,4))
    if path2:
        print("直线路径:", [(p.x, p.y) for p in path2])
