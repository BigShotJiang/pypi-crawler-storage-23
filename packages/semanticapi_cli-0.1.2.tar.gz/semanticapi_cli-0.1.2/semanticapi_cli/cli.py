#!/usr/bin/env python3
"""
Semantic API CLI - Query APIs with natural language from your terminal.

Usage:
    semanticapi query "send an SMS"
    semanticapi query "send an SMS" --key sapi_your_key
    semanticapi query "send an SMS" --execute
    semanticapi batch "send SMS" "process payment" "get weather"
    semanticapi preflight "send an SMS"
    semanticapi discover "twilio"
    semanticapi discover-url "https://docs.stripe.com/api"
    semanticapi config set-key sapi_your_key
    semanticapi status
"""

import argparse
import sys
from typing import List, Optional

from . import __version__
from .config import (
    get_api_key, 
    get_base_url, 
    set_api_key, 
    set_base_url, 
    load_config,
    clear_config,
    CONFIG_FILE,
)
from .api import APIClient, APIError
from .output import (
    print_error,
    print_result,
    format_query_result,
    format_preflight_result,
    format_discover_result,
    format_status_result,
    format_agentic_result,
    success,
    warning,
    dim,
)


# Exit codes
EXIT_SUCCESS = 0
EXIT_ERROR = 1
EXIT_AUTH_REQUIRED = 2


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser with all subcommands."""
    parser = argparse.ArgumentParser(
        prog="semanticapi",
        description="Semantic API CLI - Query APIs with natural language",
        epilog="Examples:\n"
               "  semanticapi query \"send an SMS via twilio\"\n"
               "  semanticapi preflight \"send an email\"\n"
               "  semanticapi discover sendgrid\n"
               "  semanticapi config set-key sapi_your_key",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"semanticapi-cli {__version__}",
    )
    
    # Global options
    parser.add_argument(
        "--key", "-k",
        metavar="KEY",
        help="API key (overrides SEMANTICAPI_KEY env var and config file)",
    )
    parser.add_argument(
        "--url", "-u",
        metavar="URL",
        help="Base URL (default: https://semanticapi.dev)",
    )
    parser.add_argument(
        "--raw", "-r",
        action="store_true",
        help="Output compact JSON (no formatting)",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Output minimal information",
    )
    
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")
    
    # ── query command ──────────────────────────────────────
    query_parser = subparsers.add_parser(
        "query",
        help="Execute a natural language query",
        description="Execute a natural language query against connected APIs.",
    )
    query_parser.add_argument(
        "query",
        help="Natural language query (e.g., 'send an SMS')",
    )
    query_parser.add_argument(
        "--execute", "-x",
        action="store_true",
        help="Use agentic mode (actually execute API calls)",
    )
    query_parser.add_argument(
        "--no-discover",
        action="store_true",
        help="Disable auto-discovery of unknown providers",
    )
    
    # ── batch command ──────────────────────────────────────
    batch_parser = subparsers.add_parser(
        "batch",
        help="Execute multiple queries at once",
        description="Execute multiple queries in a single API call (max 10).",
    )
    batch_parser.add_argument(
        "queries",
        nargs="+",
        help="Queries to execute",
    )
    
    # ── preflight command ──────────────────────────────────
    preflight_parser = subparsers.add_parser(
        "preflight",
        help="Pre-check a query (free, no LLM cost)",
        description="Pre-analyze a query to identify required providers and their status.",
    )
    preflight_parser.add_argument(
        "query",
        help="Query to analyze",
    )
    
    # ── discover command ──────────────────────────────────
    discover_parser = subparsers.add_parser(
        "discover",
        help="Discover a provider by name",
        description="Search for and auto-discover a provider configuration by name.",
    )
    discover_parser.add_argument(
        "provider",
        help="Provider name (e.g., 'twilio', 'sendgrid')",
    )
    discover_parser.add_argument(
        "--intent", "-i",
        metavar="TEXT",
        help="What you want to do (helps discover relevant capabilities)",
    )
    
    # ── discover-url command ───────────────────────────────
    discover_url_parser = subparsers.add_parser(
        "discover-url",
        help="Discover a provider from documentation URL",
        description="Generate a provider configuration from API documentation.",
    )
    discover_url_parser.add_argument(
        "url",
        help="API documentation URL",
    )
    discover_url_parser.add_argument(
        "--intent", "-i",
        metavar="TEXT",
        help="What you want to do (guides capability extraction)",
    )
    
    # ── status command ─────────────────────────────────────
    subparsers.add_parser(
        "status",
        help="Check API status and show config",
        description="Check Semantic API health and show current configuration.",
    )
    
    # ── config command ─────────────────────────────────────
    config_parser = subparsers.add_parser(
        "config",
        help="Manage configuration",
        description="View and update CLI configuration.",
    )
    config_subparsers = config_parser.add_subparsers(dest="config_command", metavar="ACTION")
    
    # config set-key
    set_key_parser = config_subparsers.add_parser(
        "set-key",
        help="Set default API key",
    )
    set_key_parser.add_argument("key", help="API key to save")
    
    # config set-url
    set_url_parser = config_subparsers.add_parser(
        "set-url",
        help="Set default base URL",
    )
    set_url_parser.add_argument("url", help="Base URL to save")
    
    # config show
    config_subparsers.add_parser(
        "show",
        help="Show current configuration",
    )
    
    # config clear
    config_subparsers.add_parser(
        "clear",
        help="Clear all configuration",
    )
    
    return parser


def cmd_query(args) -> int:
    """Handle query command."""
    api_key = get_api_key(args.key)
    base_url = get_base_url(args.url)
    
    if not api_key:
        print_error("API key required. Set with --key, SEMANTICAPI_KEY env var, or 'semanticapi config set-key'")
        return EXIT_AUTH_REQUIRED
    
    client = APIClient(base_url, api_key)
    
    try:
        if args.execute:
            # Agentic mode
            result = client.agentic(args.query)
            print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_agentic_result)
        else:
            # Regular query
            result = client.query(args.query, auto_discover=not args.no_discover)
            print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_query_result)
        
        return EXIT_SUCCESS if result.get("success") else EXIT_ERROR
        
    except APIError as e:
        if e.status_code == 401:
            print_error("Invalid API key or authentication failed")
            return EXIT_AUTH_REQUIRED
        elif e.status_code == 429:
            print_error("Rate limit exceeded. Try again later.")
            return EXIT_ERROR
        else:
            print_error(str(e))
            return EXIT_ERROR


def cmd_batch(args) -> int:
    """Handle batch command."""
    api_key = get_api_key(args.key)
    base_url = get_base_url(args.url)
    
    if not api_key:
        print_error("API key required")
        return EXIT_AUTH_REQUIRED
    
    if len(args.queries) > 10:
        print_error("Maximum 10 queries per batch")
        return EXIT_ERROR
    
    client = APIClient(base_url, api_key)
    
    try:
        result = client.query_batch(args.queries)
        print_result(result, raw=args.raw, quiet=args.quiet)
        
        # Check if all queries succeeded
        results = result.get("results", [])
        all_success = all(r.get("success") for r in results)
        return EXIT_SUCCESS if all_success else EXIT_ERROR
        
    except APIError as e:
        if e.status_code == 401:
            print_error("Invalid API key")
            return EXIT_AUTH_REQUIRED
        print_error(str(e))
        return EXIT_ERROR


def cmd_preflight(args) -> int:
    """Handle preflight command."""
    api_key = get_api_key(args.key)
    base_url = get_base_url(args.url)
    
    if not api_key:
        print_error("API key required")
        return EXIT_AUTH_REQUIRED
    
    client = APIClient(base_url, api_key)
    
    try:
        result = client.preflight(args.query)
        print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_preflight_result)
        return EXIT_SUCCESS
        
    except APIError as e:
        if e.status_code == 401:
            print_error("Invalid API key")
            return EXIT_AUTH_REQUIRED
        print_error(str(e))
        return EXIT_ERROR


def cmd_discover(args) -> int:
    """Handle discover command."""
    api_key = get_api_key(args.key)
    base_url = get_base_url(args.url)
    
    if not api_key:
        print_error("API key required")
        return EXIT_AUTH_REQUIRED
    
    client = APIClient(base_url, api_key)
    
    try:
        result = client.discover(args.provider, user_intent=args.intent)
        print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_discover_result)
        return EXIT_SUCCESS if result.get("success") else EXIT_ERROR
        
    except APIError as e:
        if e.status_code == 401:
            print_error("Invalid API key")
            return EXIT_AUTH_REQUIRED
        print_error(str(e))
        return EXIT_ERROR


def cmd_discover_url(args) -> int:
    """Handle discover-url command."""
    api_key = get_api_key(args.key)
    base_url = get_base_url(args.url)
    
    if not api_key:
        print_error("API key required")
        return EXIT_AUTH_REQUIRED
    
    client = APIClient(base_url, api_key)
    
    try:
        result = client.discover_url(args.url, user_intent=args.intent)
        print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_discover_result)
        return EXIT_SUCCESS if result.get("success") else EXIT_ERROR
        
    except APIError as e:
        if e.status_code == 401:
            print_error("Invalid API key")
            return EXIT_AUTH_REQUIRED
        print_error(str(e))
        return EXIT_ERROR


def cmd_status(args) -> int:
    """Handle status command."""
    base_url = get_base_url(args.url)
    api_key = get_api_key(args.key)
    
    # Show config first
    if not args.quiet and not args.raw:
        print(f"  {dim('Config file:')} {CONFIG_FILE}")
        print(f"  {dim('Base URL:')} {base_url}")
        if api_key:
            masked = api_key[:8] + "..." + api_key[-4:] if len(api_key) > 12 else "***"
            print(f"  {dim('API key:')} {masked}")
        else:
            print(f"  {dim('API key:')} {warning('not set')}")
        print()
    
    # Check API health (no auth required for health check)
    client = APIClient(base_url, api_key)
    
    try:
        result = client.health()
        print_result(result, raw=args.raw, quiet=args.quiet, formatter=format_status_result)
        return EXIT_SUCCESS
        
    except APIError as e:
        print_error(f"Could not reach API: {e}")
        return EXIT_ERROR


def cmd_config(args) -> int:
    """Handle config command."""
    if args.config_command == "set-key":
        set_api_key(args.key)
        print(success(f"✓ API key saved to {CONFIG_FILE}"))
        return EXIT_SUCCESS
        
    elif args.config_command == "set-url":
        set_base_url(args.url)
        print(success(f"✓ Base URL saved to {CONFIG_FILE}"))
        return EXIT_SUCCESS
        
    elif args.config_command == "show":
        config = load_config()
        if not config:
            print(dim("No configuration file found."))
            print(dim(f"Create one with: semanticapi config set-key YOUR_KEY"))
        else:
            print(f"Config file: {CONFIG_FILE}")
            print()
            for key, value in config.items():
                if key == "api_key" and value:
                    # Mask API key
                    masked = value[:8] + "..." + value[-4:] if len(value) > 12 else "***"
                    print(f"  {key}: {masked}")
                else:
                    print(f"  {key}: {value}")
        return EXIT_SUCCESS
        
    elif args.config_command == "clear":
        clear_config()
        print(success("✓ Configuration cleared"))
        return EXIT_SUCCESS
        
    else:
        # No subcommand - show current config
        return cmd_config_show(args)


def cmd_config_show(args) -> int:
    """Show current configuration."""
    config = load_config()
    if not config:
        print(dim("No configuration file found."))
        print(dim(f"Create one with: semanticapi config set-key YOUR_KEY"))
    else:
        print(f"Config file: {CONFIG_FILE}")
        print()
        for key, value in config.items():
            if key == "api_key" and value:
                masked = value[:8] + "..." + value[-4:] if len(value) > 12 else "***"
                print(f"  {key}: {masked}")
            else:
                print(f"  {key}: {value}")
    return EXIT_SUCCESS


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point for CLI."""
    parser = create_parser()
    args = parser.parse_args(argv)
    
    if not args.command:
        parser.print_help()
        return EXIT_SUCCESS
    
    # Route to command handler
    handlers = {
        "query": cmd_query,
        "batch": cmd_batch,
        "preflight": cmd_preflight,
        "discover": cmd_discover,
        "discover-url": cmd_discover_url,
        "status": cmd_status,
        "config": cmd_config,
    }
    
    handler = handlers.get(args.command)
    if handler:
        try:
            return handler(args)
        except KeyboardInterrupt:
            print("\nInterrupted")
            return EXIT_ERROR
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            return EXIT_ERROR
    else:
        parser.print_help()
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
