"""
API client for Semantic API CLI.

Uses stdlib urllib only - no external dependencies.
"""

import json
import os
import sys
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, Dict, Any, Tuple

from . import __version__


_DEBUG = os.environ.get("SEMANTICAPI_DEBUG", "").lower() in ("1", "true", "yes")


def _debug(msg: str) -> None:
    if _DEBUG:
        print(f"[DEBUG] {msg}", file=sys.stderr)


class APIError(Exception):
    """Error from Semantic API."""
    def __init__(self, message: str, status_code: int = 0, details: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details or {}


class APIClient:
    """HTTP client for Semantic API."""
    
    def __init__(self, base_url: str, api_key: Optional[str] = None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
    
    def _request(
        self, 
        method: str, 
        path: str, 
        data: Optional[Dict] = None,
        timeout: int = 60,
    ) -> Tuple[int, Dict[str, Any]]:
        """
        Make HTTP request to API.
        
        Returns (status_code, response_json).
        Raises APIError on failure.
        """
        url = f"{self.base_url}{path}"
        
        body = json.dumps(data).encode("utf-8") if data else None
        
        req = urllib.request.Request(url, data=body, method=method)
        
        # Set headers via add_unredirected_header so they survive redirects
        req.add_unredirected_header("Content-Type", "application/json")
        req.add_unredirected_header("Accept", "application/json")
        req.add_unredirected_header("User-Agent", f"semanticapi-cli/{__version__}")
        
        if self.api_key:
            req.add_unredirected_header("Authorization", f"Bearer {self.api_key}")
            req.add_unredirected_header("X-API-Key", self.api_key)
        
        _debug(f"{method} {url}")
        _debug(f"api_key present: {bool(self.api_key)}")
        _debug(f"headers: {req.header_items()}")
        
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                response_body = response.read().decode("utf-8")
                try:
                    return response.status, json.loads(response_body)
                except json.JSONDecodeError:
                    return response.status, {"raw": response_body}
                    
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8") if e.fp else ""
            _debug(f"HTTP error {e.code}: {body[:200]}")
            try:
                error_data = json.loads(body)
                detail = error_data.get("detail", str(e))
            except json.JSONDecodeError:
                detail = body or str(e)
            
            # Add hint for auth-related errors
            if e.code in (401, 402, 403) and self.api_key:
                _debug(f"Auth header was set but got {e.code}. Key starts with: {self.api_key[:8]}...")
            
            raise APIError(detail, status_code=e.code, details={"body": body})
            
        except urllib.error.URLError as e:
            raise APIError(f"Connection failed: {e.reason}")
        except TimeoutError:
            raise APIError("Request timed out")
    
    def query(self, query: str, auto_discover: bool = True) -> Dict[str, Any]:
        """Execute a natural language query."""
        status, data = self._request("POST", "/api/query", {
            "query": query,
            "auto_discover": auto_discover,
        })
        return data
    
    def query_batch(self, queries: list) -> Dict[str, Any]:
        """Execute multiple queries in one call."""
        status, data = self._request("POST", "/api/query/batch", {
            "queries": queries,
        })
        return data
    
    def preflight(self, query: str) -> Dict[str, Any]:
        """Pre-analyze a query to identify needed providers."""
        status, data = self._request("POST", "/api/query/preflight", {
            "query": query,
        })
        return data
    
    def agentic(self, query: str, execution_id: Optional[str] = None) -> Dict[str, Any]:
        """Execute a query with agentic (execution) mode."""
        payload = {"query": query}
        if execution_id:
            payload["execution_id"] = execution_id
        status, data = self._request("POST", "/api/query/agentic", payload, timeout=120)
        return data
    
    def discover(self, provider_name: str, user_intent: Optional[str] = None) -> Dict[str, Any]:
        """Discover a provider by name."""
        payload = {"provider_name": provider_name}
        if user_intent:
            payload["user_intent"] = user_intent
        status, data = self._request("POST", "/api/discover/search", payload, timeout=60)
        return data
    
    def discover_url(self, url: str, user_intent: Optional[str] = None) -> Dict[str, Any]:
        """Discover a provider from documentation URL."""
        payload = {"url": url}
        if user_intent:
            payload["user_intent"] = user_intent
        status, data = self._request("POST", "/api/discover/from-url", payload, timeout=60)
        return data
    
    def health(self) -> Dict[str, Any]:
        """Get API health status."""
        status, data = self._request("GET", "/api/health")
        return data
