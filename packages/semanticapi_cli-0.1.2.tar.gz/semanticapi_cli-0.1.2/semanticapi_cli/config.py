"""
Configuration management for Semantic API CLI.

Config priority: CLI args > environment variables > config file
"""

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any


CONFIG_DIR = Path.home() / ".semanticapi"
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULT_BASE_URL = "https://semanticapi.dev"


def ensure_config_dir() -> None:
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Dict[str, Any]:
    """Load config from ~/.semanticapi/config.json."""
    if not CONFIG_FILE.exists():
        return {}
    
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_config(config: Dict[str, Any]) -> None:
    """Save config to ~/.semanticapi/config.json."""
    ensure_config_dir()
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_api_key(cli_key: Optional[str] = None) -> Optional[str]:
    """
    Get API key with priority: CLI arg > env var > config file.
    
    Returns None if no key is found.
    """
    # 1. CLI argument (highest priority)
    if cli_key:
        return cli_key
    
    # 2. Environment variable
    env_key = os.environ.get("SEMANTICAPI_KEY")
    if env_key:
        return env_key
    
    # 3. Config file
    config = load_config()
    return config.get("api_key")


def get_base_url(cli_url: Optional[str] = None) -> str:
    """
    Get base URL with priority: CLI arg > env var > config file > default.
    """
    # 1. CLI argument
    if cli_url:
        return cli_url.rstrip("/")
    
    # 2. Environment variable
    env_url = os.environ.get("SEMANTICAPI_URL")
    if env_url:
        return env_url.rstrip("/")
    
    # 3. Config file
    config = load_config()
    if config.get("base_url"):
        return config["base_url"].rstrip("/")
    
    # 4. Default
    return DEFAULT_BASE_URL


def set_api_key(key: str) -> None:
    """Save API key to config file."""
    config = load_config()
    config["api_key"] = key
    save_config(config)


def set_base_url(url: str) -> None:
    """Save base URL to config file."""
    config = load_config()
    config["base_url"] = url.rstrip("/")
    save_config(config)


def clear_config() -> None:
    """Clear all config."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
