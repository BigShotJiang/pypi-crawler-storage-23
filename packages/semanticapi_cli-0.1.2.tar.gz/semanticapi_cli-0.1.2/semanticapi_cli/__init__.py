"""
Semantic API CLI
================

A command-line interface for Semantic API - discover and query APIs with natural language.

Usage:
    python -m semanticapi_cli query "send an SMS"
    semanticapi query "send an SMS" --key sapi_your_key
"""

__version__ = "0.1.2"
