# Semantic API CLI

Query 700+ APIs with natural language from your terminal. Zero dependencies.

```bash
pip install semanticapi-cli
```

## Quick Start

```bash
# Save your API key
semanticapi config set-key sapi_your_key

# Query any API
semanticapi query "send an SMS via Twilio"

# Pre-check what you'll need (free, no LLM cost)
semanticapi preflight "send an email"

# Discover a provider
semanticapi discover stripe

# Batch queries
semanticapi batch "send email" "upload file" "translate text"
```

## Commands

| Command | Description |
|---------|-------------|
| `query` | Natural language API query |
| `batch` | Multiple queries in one call |
| `preflight` | Pre-check (free, identifies needed auth) |
| `discover` | Look up a provider by name |
| `discover-url` | Discover provider from docs URL |
| `status` | Show config and API health |
| `config` | Manage API key and settings |

## Authentication

API key priority (first found wins):

1. `--key sapi_xxx` flag
2. `SEMANTICAPI_KEY` environment variable
3. `~/.semanticapi/config.json` (saved via `config set-key`)

Get your key at [semanticapi.dev](https://semanticapi.dev).

## Output Modes

```bash
# Pretty-printed (default)
semanticapi query "get weather"

# Raw JSON (for piping)
semanticapi --raw query "get weather"

# Minimal output
semanticapi --quiet query "get weather"
```

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error |
| 2 | Auth required |

## What You Get Back

Every query returns:
- **Provider** and endpoint details
- **Code snippets** (curl + Python) ready to copy-paste
- **Auth requirements** and setup instructions
- **Alternative providers** ranked by relevance

## Related

- [Semantic API](https://semanticapi.dev) — The API
- [MCP Server](https://pypi.org/project/semanticapi-mcp/) — For Claude Desktop / ChatGPT
- [Agent Skill](https://pypi.org/project/semantic-api-skill/) — For autonomous agents
- [Open Source Engine](https://github.com/peter-j-thompson/semanticapi-engine) — AGPL-3.0

## License

MIT
