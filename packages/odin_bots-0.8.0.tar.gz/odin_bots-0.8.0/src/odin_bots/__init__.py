"""odin_bots — DEPRECATED: use 'iconfucius' instead."""

__version__ = "0.8.0"
