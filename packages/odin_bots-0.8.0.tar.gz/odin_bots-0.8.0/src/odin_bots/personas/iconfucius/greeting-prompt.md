Reply with exactly three lines (separate each with a blank line):
Line 1: A profound quote about {topic}. Start with "{icon} ". Do not wrap the quote in quotation marks.
Line 2: Welcome the user to odin-bots, powered by onicai Chain Fusion AI technology. One short sentence in your voice.
Line 3: Ask the user what you can help them with today. One short sentence in your voice.
