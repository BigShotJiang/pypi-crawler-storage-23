"""CLI output rendering helpers."""

from __future__ import annotations

import json
from typing import Any


def _format_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True)
    return str(value)


def _render_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "(no rows)"
    columns: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in columns:
                columns.append(key)
    widths = {
        key: max(len(key), *(len(_format_cell(row.get(key))) for row in rows))
        for key in columns
    }
    header = " | ".join(key.ljust(widths[key]) for key in columns)
    divider = "-+-".join("-" * widths[key] for key in columns)
    body = [
        " | ".join(_format_cell(row.get(key)).ljust(widths[key]) for key in columns)
        for row in rows
    ]
    return "\n".join([header, divider, *body])


def emit_payload(payload: Any, *, output_mode: str) -> None:
    if output_mode == "json":
        print(json.dumps(payload, indent=2, sort_keys=True, default=str))
        return

    if isinstance(payload, dict) and isinstance(payload.get("items"), list):
        print(_render_table(payload.get("items") or []))
        metadata = {
            key: value
            for key, value in payload.items()
            if key != "items"
        }
        if metadata:
            print("")
            for key, value in metadata.items():
                print(f"{key}: {_format_cell(value)}")
        return

    if isinstance(payload, list):
        if payload and all(isinstance(item, dict) for item in payload):
            print(_render_table(payload))
        else:
            for item in payload:
                print(_format_cell(item))
        return

    if isinstance(payload, dict):
        for key, value in payload.items():
            print(f"{key}: {_format_cell(value)}")
        return

    print(_format_cell(payload))
