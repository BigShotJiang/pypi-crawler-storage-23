"""Persistent profile and credential storage for the public CLI."""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
import json
import os
from pathlib import Path
from typing import Any


KEYRING_SENTINEL = "__keyring__"
KEYRING_SERVICE_NAME = "wilfie-cli"


def default_config_path() -> Path:
    override = os.getenv("WILFIE_CLI_CONFIG_PATH")
    if override:
        return Path(override).expanduser()
    config_home = os.getenv("XDG_CONFIG_HOME")
    if config_home:
        return Path(config_home).expanduser() / "wilfie" / "cli.json"
    return Path.home() / ".config" / "wilfie" / "cli.json"


def _load_keyring():
    if os.getenv("WILFIE_CLI_DISABLE_KEYRING", "").strip() == "1":
        return None
    try:
        import keyring  # type: ignore
    except Exception:  # noqa: BLE001
        return None
    return keyring


def _normalize_scopes(values: list[str] | None) -> list[str]:
    if not values:
        return []
    normalized = {str(value).strip() for value in values if str(value).strip()}
    return sorted(normalized)


@dataclass
class OAuthTokens:
    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str = "Bearer"
    expires_at_epoch: int | None = None
    client_id: str = "wilfie-cli"
    scope: str | None = None


@dataclass
class CliProfile:
    base_url: str = "https://wilfie.ai"
    output: str = "table"
    oauth: OAuthTokens = field(default_factory=OAuthTokens)
    api_key: str | None = None
    api_key_scopes: list[str] = field(default_factory=list)


class ProfileStore:
    """Read/write CLI profiles with keyring-first secret persistence."""

    def __init__(self, path: Path | None = None):
        self.path = path or default_config_path()
        self._keyring = _load_keyring()

    def load_profile(self, profile_name: str) -> CliProfile:
        data = self._read()
        profiles = data.get("profiles") or {}
        raw_profile = profiles.get(profile_name) or {}
        return self._decode_profile(profile_name=profile_name, raw=raw_profile)

    def save_profile(self, profile_name: str, profile: CliProfile) -> None:
        data = self._read()
        profiles = data.get("profiles")
        if not isinstance(profiles, dict):
            profiles = {}
        profiles[profile_name] = self._encode_profile(
            profile_name=profile_name, profile=profile
        )
        data["profiles"] = profiles
        self._write(data)

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"profiles": {}}
        raw = self.path.read_text(encoding="utf-8")
        if not raw.strip():
            return {"profiles": {}}
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise ValueError("Invalid CLI config payload.")
        return payload

    def _write(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.path.parent, 0o700)
        except OSError:
            pass
        serialized = json.dumps(payload, indent=2, sort_keys=True) + "\n"
        self.path.write_text(serialized, encoding="utf-8")
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def _decode_profile(
        self, *, profile_name: str, raw: dict[str, Any]
    ) -> CliProfile:
        oauth_raw = raw.get("oauth") if isinstance(raw.get("oauth"), dict) else {}
        oauth = OAuthTokens(
            access_token=self._decode_secret(
                profile_name=profile_name,
                field_name="oauth_access_token",
                value=oauth_raw.get("access_token"),
            ),
            refresh_token=self._decode_secret(
                profile_name=profile_name,
                field_name="oauth_refresh_token",
                value=oauth_raw.get("refresh_token"),
            ),
            token_type=str(oauth_raw.get("token_type") or "Bearer"),
            expires_at_epoch=(
                int(oauth_raw["expires_at_epoch"])
                if oauth_raw.get("expires_at_epoch") is not None
                else None
            ),
            client_id=str(oauth_raw.get("client_id") or "wilfie-cli"),
            scope=(
                str(oauth_raw.get("scope"))
                if oauth_raw.get("scope") is not None
                else None
            ),
        )
        return CliProfile(
            base_url=str(raw.get("base_url") or "https://wilfie.ai"),
            output=str(raw.get("output") or "table"),
            oauth=oauth,
            api_key=self._decode_secret(
                profile_name=profile_name,
                field_name="api_key",
                value=raw.get("api_key"),
            ),
            api_key_scopes=_normalize_scopes(
                raw.get("api_key_scopes")
                if isinstance(raw.get("api_key_scopes"), list)
                else []
            ),
        )

    def _encode_profile(
        self, *, profile_name: str, profile: CliProfile
    ) -> dict[str, Any]:
        oauth = profile.oauth
        return {
            "base_url": profile.base_url.strip().rstrip("/"),
            "output": profile.output.strip() or "table",
            "oauth": {
                "access_token": self._encode_secret(
                    profile_name=profile_name,
                    field_name="oauth_access_token",
                    value=oauth.access_token,
                ),
                "refresh_token": self._encode_secret(
                    profile_name=profile_name,
                    field_name="oauth_refresh_token",
                    value=oauth.refresh_token,
                ),
                "token_type": oauth.token_type or "Bearer",
                "expires_at_epoch": oauth.expires_at_epoch,
                "client_id": oauth.client_id or "wilfie-cli",
                "scope": oauth.scope,
            },
            "api_key": self._encode_secret(
                profile_name=profile_name,
                field_name="api_key",
                value=profile.api_key,
            ),
            "api_key_scopes": _normalize_scopes(profile.api_key_scopes),
        }

    def _secret_label(self, profile_name: str, field_name: str) -> str:
        return f"{profile_name}:{field_name}"

    def _decode_secret(
        self,
        *,
        profile_name: str,
        field_name: str,
        value: Any,
    ) -> str | None:
        if value is None:
            return None
        if value != KEYRING_SENTINEL:
            return str(value)
        if self._keyring is None:
            return None
        label = self._secret_label(profile_name, field_name)
        try:
            return self._keyring.get_password(KEYRING_SERVICE_NAME, label)
        except Exception:  # noqa: BLE001
            return None

    def _encode_secret(
        self,
        *,
        profile_name: str,
        field_name: str,
        value: str | None,
    ) -> str | None:
        if value is None:
            self._delete_keyring_secret(profile_name, field_name)
            return None
        if self._keyring is None:
            return value
        label = self._secret_label(profile_name, field_name)
        try:
            self._keyring.set_password(KEYRING_SERVICE_NAME, label, value)
            return KEYRING_SENTINEL
        except Exception:  # noqa: BLE001
            return value

    def _delete_keyring_secret(self, profile_name: str, field_name: str) -> None:
        if self._keyring is None:
            return
        label = self._secret_label(profile_name, field_name)
        try:
            self._keyring.delete_password(KEYRING_SERVICE_NAME, label)
        except Exception:  # noqa: BLE001
            return
