"""HTTP client wrapper for the public Wilfie CLI."""

from __future__ import annotations

import json
import time
from typing import Any
from typing import Callable
from urllib.error import HTTPError
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request
from urllib.request import urlopen
from uuid import uuid4

from wilfie_cli import __version__


RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class HttpResponse:
    def __init__(self, *, status_code: int, text: str, headers: dict[str, str]):
        self.status_code = status_code
        self.text = text
        self.headers = headers

    def json(self) -> Any:
        return json.loads(self.text)


def _safe_json(response: HttpResponse) -> Any:
    try:
        return response.json()
    except Exception:  # noqa: BLE001
        return None


class ApiError(RuntimeError):
    """Structured API error for CLI handling."""

    def __init__(
        self,
        *,
        status_code: int,
        code: str | None,
        detail: Any,
        payload: Any,
    ):
        self.status_code = status_code
        self.code = code
        self.detail = detail
        self.payload = payload
        detail_text = (
            json.dumps(detail, sort_keys=True)
            if isinstance(detail, (dict, list))
            else str(detail)
        )
        error_code = code or "api_error"
        super().__init__(f"HTTP {status_code} [{error_code}] {detail_text}")

    @classmethod
    def from_response(cls, response: HttpResponse) -> "ApiError":
        payload = _safe_json(response)
        code: str | None = None
        detail: Any = response.text.strip() or f"HTTP {response.status_code}"
        if isinstance(payload, dict):
            raw_error = payload.get("error")
            if isinstance(raw_error, str):
                code = raw_error
                detail = payload.get("error_description") or detail
            elif isinstance(raw_error, dict):
                code = (
                    raw_error.get("code")
                    if isinstance(raw_error.get("code"), str)
                    else None
                )
                detail = (
                    raw_error.get("message")
                    or raw_error.get("detail")
                    or detail
                )
            elif payload.get("detail") is not None:
                detail = payload.get("detail")
        return cls(
            status_code=response.status_code,
            code=code,
            detail=detail,
            payload=payload,
        )


class WilfieHttpClient:
    """Thin API wrapper with retries, request IDs, and OAuth refresh retry."""

    def __init__(
        self,
        *,
        base_url: str,
        oauth_token_getter: Callable[[], str | None],
        api_key_getter: Callable[[], str | None],
        oauth_refresh_callback: Callable[[], bool],
    ):
        self.base_url = base_url.rstrip("/")
        self.oauth_token_getter = oauth_token_getter
        self.api_key_getter = api_key_getter
        self.oauth_refresh_callback = oauth_refresh_callback

    def request_json(
        self,
        method: str,
        path: str,
        *,
        auth_mode: str,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        allow_refresh_retry: bool = True,
    ) -> Any:
        response = self.request(
            method,
            path,
            auth_mode=auth_mode,
            params=params,
            json_body=json_body,
            data=data,
            headers=headers,
            allow_refresh_retry=allow_refresh_retry,
        )
        if response.status_code == 204 or not response.text.strip():
            return None
        payload = _safe_json(response)
        if payload is not None:
            return payload
        return {"raw": response.text}

    def request(
        self,
        method: str,
        path: str,
        *,
        auth_mode: str,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        allow_refresh_retry: bool = True,
    ) -> HttpResponse:
        response = self._request_once(
            method=method,
            path=path,
            auth_mode=auth_mode,
            params=params,
            json_body=json_body,
            data=data,
            headers=headers,
        )
        if (
            response.status_code == 401
            and auth_mode == "oauth"
            and allow_refresh_retry
            and self.oauth_refresh_callback()
        ):
            response = self._request_once(
                method=method,
                path=path,
                auth_mode=auth_mode,
                params=params,
                json_body=json_body,
                data=data,
                headers=headers,
            )
        if response.status_code >= 400:
            raise ApiError.from_response(response)
        return response

    def _request_once(
        self,
        *,
        method: str,
        path: str,
        auth_mode: str,
        params: dict[str, Any] | None,
        json_body: dict[str, Any] | None,
        data: dict[str, Any] | None,
        headers: dict[str, str] | None,
    ) -> HttpResponse:
        request_headers = {
            "Accept": "application/json",
            "User-Agent": f"wilfie-cli/{__version__}",
            "X-Request-Id": str(uuid4()),
        }
        if headers:
            request_headers.update(headers)
        if auth_mode == "oauth":
            token = self.oauth_token_getter()
            if token:
                request_headers["Authorization"] = f"Bearer {token}"
        elif auth_mode in {"api_key", "api-key"}:
            api_key = self.api_key_getter()
            if api_key:
                request_headers["X-API-Key"] = api_key

        body_bytes: bytes | None = None
        if json_body is not None:
            body_bytes = json.dumps(json_body).encode("utf-8")
            request_headers["Content-Type"] = "application/json"
        elif data is not None:
            body_bytes = urlencode(data).encode("utf-8")
            request_headers["Content-Type"] = (
                "application/x-www-form-urlencoded"
            )

        query = f"?{urlencode(params, doseq=True)}" if params else ""
        url = f"{self.base_url}/{path.lstrip('/')}{query}"

        attempts = 3
        for attempt in range(attempts):
            try:
                response = self._send_request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    body=body_bytes,
                )
            except ApiError as error:
                if error.status_code == 0 and attempt < attempts - 1:
                    time.sleep(0.25 * (2**attempt))
                    continue
                raise
            if (
                response.status_code in RETRYABLE_STATUS_CODES
                and attempt < attempts - 1
            ):
                time.sleep(0.25 * (2**attempt))
                continue
            return response
        raise RuntimeError("Unreachable retry state")

    def _send_request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str],
        body: bytes | None,
    ) -> HttpResponse:
        request = Request(url=url, data=body, headers=headers, method=method)
        try:
            with urlopen(request, timeout=30) as response:
                raw = response.read().decode("utf-8", errors="replace")
                return HttpResponse(
                    status_code=response.getcode(),
                    text=raw,
                    headers=dict(response.headers.items()),
                )
        except HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            return HttpResponse(
                status_code=exc.code,
                text=raw,
                headers=dict(exc.headers.items()) if exc.headers else {},
            )
        except URLError as exc:
            raise ApiError(
                status_code=0,
                code="network_error",
                detail=str(exc.reason),
                payload=None,
            ) from exc
