"""Public `wilfie` CLI entrypoint."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time
import webbrowser
from typing import Any

from wilfie_cli import __version__
from wilfie_cli.http_client import ApiError
from wilfie_cli.http_client import WilfieHttpClient
from wilfie_cli.render import emit_payload
from wilfie_cli.storage import OAuthTokens
from wilfie_cli.storage import ProfileStore


READ_SCOPE_FALLBACKS = {
    "wms.read": "wms.write",
    "workflows.read": "workflows.write",
}


class CliError(RuntimeError):
    """User-facing CLI error."""


def _parse_query_pairs(values: list[str] | None) -> dict[str, Any]:
    params: dict[str, Any] = {}
    for raw in values or []:
        if "=" not in raw:
            raise CliError(
                "Invalid --param value. Expected key=value format."
            )
        key, value = raw.split("=", 1)
        normalized_key = key.strip()
        if not normalized_key:
            raise CliError("Query parameter key cannot be empty.")
        normalized_value = value.strip()
        if normalized_key in params:
            existing = params[normalized_key]
            if isinstance(existing, list):
                existing.append(normalized_value)
            else:
                params[normalized_key] = [existing, normalized_value]
        else:
            params[normalized_key] = normalized_value
    return params


def _normalize_wms_query_path(*, workspace_code: str, path: str) -> str:
    normalized = path.strip()
    if not normalized:
        raise CliError("--path is required.")
    if "://" in normalized:
        raise CliError("--path must be an API path, not a full URL.")

    raw = normalized.lstrip("/")
    suffix = ""

    for root in ("api/v2/workspaces/", "workspaces/"):
        if raw.startswith(root):
            remainder = raw.removeprefix(root)
            if "/" not in remainder:
                raise CliError("--path is missing the /wms/ segment.")
            workspace_in_path, rest = remainder.split("/", 1)
            if workspace_in_path not in {workspace_code, "{workspace_code}"}:
                raise CliError(
                    "--path workspace must match --workspace."
                )
            if not rest.startswith("wms/"):
                raise CliError("--path must target a /wms/ endpoint.")
            suffix = rest.removeprefix("wms/")
            break

    if not suffix:
        if raw.startswith("api/v2/wms/"):
            suffix = raw.removeprefix("api/v2/wms/")
        elif raw.startswith("wms/"):
            suffix = raw.removeprefix("wms/")
        else:
            suffix = raw

    suffix = suffix.lstrip("/")
    if not suffix:
        raise CliError("--path must include a WMS endpoint path.")
    return f"/api/v2/workspaces/{workspace_code}/wms/{suffix}"


def _normalize_scopes(values: list[str] | tuple[str, ...] | None) -> list[str]:
    if not values:
        return []
    normalized = {str(value).strip() for value in values if str(value).strip()}
    return sorted(normalized)


def _to_cli_error(error: ApiError) -> CliError:
    detail = error.detail
    if isinstance(detail, (dict, list)):
        detail_text = json.dumps(detail, sort_keys=True)
    else:
        detail_text = str(detail)
    label = error.code if error.code else "api_error"
    return CliError(f"HTTP {error.status_code} [{label}] {detail_text}")


def _load_json_file(path: str | None) -> dict[str, Any]:
    if path is None:
        return {}
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CliError("JSON payload must be an object.")
    return payload


def _mask_secret(value: str | None) -> str | None:
    if not value:
        return None
    if len(value) > 16:
        return f"{value[:9]}...{value[-4:]}"
    return "***"


class CliState:
    """Command runtime state and auth/token management."""

    def __init__(
        self,
        *,
        profile_name: str,
        base_url_override: str | None,
        output_override: str | None,
        auth_mode: str,
    ):
        self.profile_name = profile_name
        self.store = ProfileStore()
        self.profile = self.store.load_profile(profile_name)
        if base_url_override:
            self.profile.base_url = base_url_override.rstrip("/")
        if output_override:
            self.profile.output = output_override
        self.auth_mode = auth_mode
        self._validated_workspaces: set[str] = set()

    @property
    def output_mode(self) -> str:
        mode = (self.profile.output or "table").strip().lower()
        if mode in {"json", "table"}:
            return mode
        return "table"

    @property
    def base_url(self) -> str:
        value = (self.profile.base_url or "").strip().rstrip("/")
        if value:
            return value
        return "https://wilfie.ai"

    def save(self) -> None:
        self.store.save_profile(self.profile_name, self.profile)

    def has_oauth_credentials(self) -> bool:
        return bool(
            self.profile.oauth.access_token or self.profile.oauth.refresh_token
        )

    def resolve_auth_mode(self, *, allow_api_key: bool) -> str:
        if self.auth_mode in {"oauth", "api-key"}:
            if self.auth_mode == "api-key" and not allow_api_key:
                raise CliError("This command requires OAuth auth mode.")
            return self.auth_mode
        if self.has_oauth_credentials():
            return "oauth"
        if allow_api_key and self.profile.api_key:
            return "api-key"
        return "oauth"

    def _oauth_expired(self) -> bool:
        expires_at = self.profile.oauth.expires_at_epoch
        if expires_at is None:
            return False
        return expires_at <= int(time.time()) + 30

    def _oauth_access_token_for_request(self) -> str | None:
        if self.profile.oauth.access_token and not self._oauth_expired():
            return self.profile.oauth.access_token
        if self.refresh_oauth(silent=True):
            return self.profile.oauth.access_token
        return self.profile.oauth.access_token

    def _api_key_for_request(self) -> str | None:
        return self.profile.api_key

    def _http_client(self) -> WilfieHttpClient:
        return WilfieHttpClient(
            base_url=self.base_url,
            oauth_token_getter=self._oauth_access_token_for_request,
            api_key_getter=self._api_key_for_request,
            oauth_refresh_callback=lambda: self.refresh_oauth(silent=True),
        )

    def _update_oauth_tokens(self, payload: dict[str, Any]) -> None:
        expires_in = payload.get("expires_in")
        expires_epoch = None
        if isinstance(expires_in, int):
            expires_epoch = int(time.time()) + max(1, expires_in) - 30
        self.profile.oauth = OAuthTokens(
            access_token=str(payload.get("access_token") or ""),
            refresh_token=str(payload.get("refresh_token") or ""),
            token_type=str(payload.get("token_type") or "Bearer"),
            expires_at_epoch=expires_epoch,
            client_id=str(
                payload.get("client_id")
                or self.profile.oauth.client_id
                or "wilfie-cli"
            ),
            scope=(
                str(payload.get("scope"))
                if payload.get("scope") is not None
                else self.profile.oauth.scope
            ),
        )
        self.save()

    def login_device_flow(
        self,
        *,
        client_id: str,
        scope: str,
        audience: str | None,
        open_browser: bool,
    ) -> dict[str, Any]:
        client = self._http_client()
        try:
            device_payload = client.request_json(
                "POST",
                "/api/v2/oauth/device_authorization",
                auth_mode="none",
                json_body={
                    "client_id": client_id,
                    "scope": scope,
                    **({"audience": audience} if audience else {}),
                },
                allow_refresh_retry=False,
            )
        except ApiError as error:
            raise _to_cli_error(error)

        if not isinstance(device_payload, dict):
            raise CliError(
                "Device authorization response was not a JSON object."
            )
        device_code = str(device_payload.get("device_code") or "")
        user_code = str(device_payload.get("user_code") or "")
        verification_uri = str(device_payload.get("verification_uri") or "")
        verification_uri_complete = str(
            device_payload.get("verification_uri_complete") or ""
        )
        expires_in = int(device_payload.get("expires_in") or 0)
        interval = max(1, int(device_payload.get("interval") or 5))

        if not device_code or not user_code or not verification_uri:
            raise CliError("Device authorization response is incomplete.")

        print(f"Verification URL: {verification_uri}")
        if verification_uri_complete:
            print(f"One-click URL: {verification_uri_complete}")
        print(f"User code: {user_code}")
        if open_browser and verification_uri_complete:
            try:
                webbrowser.open(verification_uri_complete)
            except Exception:  # noqa: BLE001
                pass

        deadline = time.time() + max(1, expires_in)
        while time.time() < deadline:
            time.sleep(interval)
            try:
                token_payload = client.request_json(
                    "POST",
                    "/api/v2/oauth/token",
                    auth_mode="none",
                    json_body={
                        "grant_type": (
                            "urn:ietf:params:oauth:grant-type:device_code"
                        ),
                        "client_id": client_id,
                        "device_code": device_code,
                    },
                    allow_refresh_retry=False,
                )
            except ApiError as error:
                if error.code == "authorization_pending":
                    continue
                if error.code == "slow_down":
                    interval += 1
                    continue
                if error.code in {"expired_token", "access_denied"}:
                    raise _to_cli_error(error)
                raise _to_cli_error(error)

            if not isinstance(token_payload, dict):
                raise CliError("Token response was not JSON.")
            if not token_payload.get("access_token"):
                raise CliError("Token response missing access token.")

            self._update_oauth_tokens(token_payload)
            self.profile.oauth.client_id = client_id
            self.save()
            return token_payload

        raise CliError("Device authorization timed out.")

    def refresh_oauth(self, *, silent: bool) -> bool:
        refresh_token = self.profile.oauth.refresh_token
        if not refresh_token:
            return False
        client_id = self.profile.oauth.client_id or "wilfie-cli"
        try:
            payload = self._http_client().request_json(
                "POST",
                "/api/v2/oauth/token",
                auth_mode="none",
                json_body={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "refresh_token": refresh_token,
                },
                allow_refresh_retry=False,
            )
        except ApiError as error:
            if not silent:
                raise _to_cli_error(error)
            return False
        if not isinstance(payload, dict) or not payload.get("access_token"):
            if not silent:
                raise CliError("Refresh response is invalid.")
            return False
        self._update_oauth_tokens(payload)
        return True

    def logout_oauth(self) -> None:
        refresh_token = self.profile.oauth.refresh_token
        client_id = self.profile.oauth.client_id or "wilfie-cli"
        if refresh_token:
            try:
                self._http_client().request_json(
                    "POST",
                    "/api/v2/oauth/revoke",
                    auth_mode="none",
                    json_body={
                        "client_id": client_id,
                        "token": refresh_token,
                        "token_type_hint": "refresh_token",
                    },
                    allow_refresh_retry=False,
                )
            except ApiError:
                pass
        self.profile.oauth = OAuthTokens(client_id=client_id)
        self.save()

    def set_api_key(self, *, api_key: str, scopes: list[str]) -> None:
        if not api_key.strip():
            raise CliError("API key cannot be empty.")
        self.profile.api_key = api_key.strip()
        self.profile.api_key_scopes = _normalize_scopes(scopes)
        self.save()

    def clear_api_key(self) -> None:
        self.profile.api_key = None
        self.profile.api_key_scopes = []
        self.save()

    def ensure_api_key_scope(self, required_scope: str | None) -> None:
        if required_scope is None:
            return
        if not self.profile.api_key:
            raise CliError("No API key is configured.")
        scopes = set(self.profile.api_key_scopes or [])
        if not scopes:
            raise CliError(
                "API key scopes are unknown. Reconfigure with "
                "`wilfie auth api-key set --scope ...`."
            )
        if required_scope in scopes:
            return
        write_fallback = READ_SCOPE_FALLBACKS.get(required_scope)
        if write_fallback and write_fallback in scopes:
            return
        raise CliError(
            f"Stored API key scopes do not include `{required_scope}`."
        )

    def preflight_workspace_access(
        self, *, workspace_code: str, auth_mode: str
    ) -> None:
        if auth_mode != "oauth":
            return
        if workspace_code in self._validated_workspaces:
            return
        try:
            self._http_client().request_json(
                "GET",
                f"/api/v2/workspaces/{workspace_code}",
                auth_mode="oauth",
            )
        except ApiError as error:
            raise _to_cli_error(error)
        self._validated_workspaces.add(workspace_code)

    def request_api(
        self,
        *,
        method: str,
        path: str,
        allow_api_key: bool,
        required_scope: str | None = None,
        workspace_code: str | None = None,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> Any:
        auth_mode = self.resolve_auth_mode(allow_api_key=allow_api_key)
        if auth_mode == "oauth":
            if not self.profile.oauth.access_token and not self.refresh_oauth(
                silent=True
            ):
                raise CliError(
                    "OAuth login required. Run `wilfie auth login`."
                )
        if auth_mode == "api-key":
            self.ensure_api_key_scope(required_scope)
        if workspace_code:
            self.preflight_workspace_access(
                workspace_code=workspace_code,
                auth_mode=auth_mode,
            )
        try:
            return self._http_client().request_json(
                method,
                path,
                auth_mode=auth_mode,
                params=params,
                json_body=json_body,
            )
        except ApiError as error:
            raise _to_cli_error(error)


def _cmd_auth_login(args: argparse.Namespace, state: CliState) -> Any:
    return state.login_device_flow(
        client_id=args.client_id,
        scope=args.scope,
        audience=args.audience,
        open_browser=args.open_browser,
    )


def _cmd_auth_refresh(_args: argparse.Namespace, state: CliState) -> Any:
    if not state.refresh_oauth(silent=False):
        raise CliError("No refresh token is available.")
    print("Refreshed OAuth tokens.")
    return None


def _cmd_auth_logout(_args: argparse.Namespace, state: CliState) -> Any:
    state.logout_oauth()
    print("Cleared OAuth session.")
    return None


def _cmd_auth_whoami(_args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path="/api/v2/users/me",
        allow_api_key=False,
    )


def _cmd_auth_status(_args: argparse.Namespace, state: CliState) -> Any:
    oauth_access = state.profile.oauth.access_token
    oauth_refresh = state.profile.oauth.refresh_token
    api_key_value = state.profile.api_key
    oauth_mode_available = bool(oauth_access or oauth_refresh)
    api_key_mode_available = bool(api_key_value)
    active_mode = state.resolve_auth_mode(allow_api_key=True)

    return {
        "profile": state.profile_name,
        "base_url": state.base_url,
        "auth_mode_preference": state.auth_mode,
        "auth_mode_resolved": active_mode,
        "oauth": {
            "configured": oauth_mode_available,
            "access_token": _mask_secret(oauth_access),
            "refresh_token": _mask_secret(oauth_refresh),
            "access_token_expired": (
                state._oauth_expired() if bool(oauth_access) else None
            ),
            "expires_at_epoch": state.profile.oauth.expires_at_epoch,
            "client_id": state.profile.oauth.client_id or "wilfie-cli",
            "scope": state.profile.oauth.scope,
        },
        "api_key": {
            "configured": api_key_mode_available,
            "api_key": _mask_secret(api_key_value),
            "scopes": state.profile.api_key_scopes,
        },
    }


def _cmd_auth_api_key_set(args: argparse.Namespace, state: CliState) -> Any:
    if args.api_key is None:
        raise CliError("--api-key is required.")
    state.set_api_key(api_key=args.api_key, scopes=args.scope or [])
    print("Saved API key configuration.")
    return None


def _cmd_auth_api_key_show(_args: argparse.Namespace, state: CliState) -> Any:
    value = state.profile.api_key
    return {
        "configured": bool(value),
        "api_key": _mask_secret(value),
        "scopes": state.profile.api_key_scopes,
    }


def _cmd_auth_api_key_clear(_args: argparse.Namespace, state: CliState) -> Any:
    state.clear_api_key()
    print("Cleared API key configuration.")
    return None


def _cmd_workspaces_list(_args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path="/api/v2/workspaces",
        allow_api_key=False,
    )


def _cmd_workspaces_get(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workspaces_roles(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}/roles",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workspaces_permission_definitions(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}/permission-definitions",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workflows_list(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/workflows",
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
    )


def _cmd_workflows_runs(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/workflows/runs",
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
        json_body={"workflow_id": args.workflow_id},
    )


def _cmd_workflows_execute(args: argparse.Namespace, state: CliState) -> Any:
    overrides = _load_json_file(args.overrides_file) if args.overrides_file else {}
    payload: dict[str, Any] = {
        "workflow_id": args.workflow_id,
        "run_type": args.run_type,
    }
    if args.entry_node_id:
        payload["entry_node_id"] = args.entry_node_id
    if overrides:
        payload["overrides"] = overrides
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/workflows/execute",
        allow_api_key=True,
        required_scope="workflows.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_facilities(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/facilities",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
            "require_manage_stock": str(args.require_manage_stock).lower(),
        },
    )


def _cmd_wms_skus(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
        "include_on_hand": str(args.include_on_hand).lower(),
        "in_stock_only": str(args.in_stock_only).lower(),
    }
    if args.query:
        params["query"] = args.query
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/skus",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_query(args: argparse.Namespace, state: CliState) -> Any:
    params = _parse_query_pairs(args.param)
    endpoint_path = _normalize_wms_query_path(
        workspace_code=args.workspace,
        path=args.path,
    )
    return state.request_api(
        method="GET",
        path=endpoint_path,
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params if params else None,
    )


def _cmd_wms_connections_list(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {}
    if args.integration_type:
        params["integration_type"] = args.integration_type
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/integration-connections",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params if params else None,
    )


def _cmd_wms_sku_mappings_by_connection(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.external_object_type:
        params["external_object_type"] = args.external_object_type
    if args.external_object_id:
        params["external_object_id"] = args.external_object_id
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/integration-connections/"
            f"{args.integration_connection_id}/sku-mappings"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_sku_mappings_by_sku(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/skus/{args.sku_id}/mappings",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_wms_reconcile_available(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "integration_connection_id": args.integration_connection_id,
        "limit": args.limit,
        "offset": args.offset,
        "actionable_only": str(args.actionable_only).lower(),
        "managed_only": str(args.managed_only).lower(),
    }
    if args.sku_id:
        params["sku_id"] = args.sku_id
    if args.facility_id:
        params["facility_id"] = args.facility_id
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/reconcile/available",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_connections_list(
    args: argparse.Namespace, state: CliState
) -> Any:
    payload = state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/integrations/connections",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )
    if not args.integration_type:
        return payload
    if not isinstance(payload, dict):
        return payload
    connections = payload.get("connections")
    if not isinstance(connections, list):
        return payload
    filtered = [
        item
        for item in connections
        if isinstance(item, dict)
        and item.get("integration_type") == args.integration_type
    ]
    return {
        **payload,
        "connections": filtered,
    }


def _integrations_objects_base_path(
    *, workspace: str, integration_connection_id: str
) -> str:
    return (
        f"/api/v2/workspaces/{workspace}/integrations/connections/"
        f"{integration_connection_id}/objects"
    )


def _cmd_integrations_objects_products(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/products"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_variants(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/variants"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_inventory_items(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/inventory-items"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_inventory_levels(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/inventory-levels"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_by_type(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/by-type/{args.external_object_type}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_fetch(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="POST",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/fetch/{args.external_object_type}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        json_body={
            "external_object_ids": args.external_object_id,
        },
    )


def _cmd_integrations_objects_get(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/{args.integration_object_id}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_integrations_objects_timeline(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/{args.integration_object_id}/timeline"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={"limit": args.limit},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wilfie",
        description="Wilfie public API wrapper CLI",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--profile",
        default=os.getenv("WILFIE_CLI_PROFILE", "default"),
        help="CLI profile name.",
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("WILFIE_BASE_URL"),
        help="Override API base URL for this command.",
    )
    parser.add_argument(
        "--output",
        choices=["json", "table"],
        default=None,
        help="Output mode.",
    )
    parser.add_argument(
        "--auth-mode",
        choices=["auto", "oauth", "api-key"],
        default="auto",
        help="Auth mode preference.",
    )

    root_subparsers = parser.add_subparsers(dest="group", required=True)

    auth_parser = root_subparsers.add_parser("auth", help="Auth commands")
    auth_sub = auth_parser.add_subparsers(dest="auth_cmd", required=True)

    auth_login = auth_sub.add_parser("login", help="OAuth device login")
    auth_login.add_argument("--client-id", default="wilfie-cli")
    auth_login.add_argument("--scope", default="openid offline_access")
    auth_login.add_argument("--audience", default=None)
    auth_login.add_argument(
        "--open-browser",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    auth_login.set_defaults(handler=_cmd_auth_login)

    auth_refresh = auth_sub.add_parser("refresh", help="Refresh OAuth tokens")
    auth_refresh.set_defaults(handler=_cmd_auth_refresh)

    auth_logout = auth_sub.add_parser("logout", help="Logout and revoke")
    auth_logout.set_defaults(handler=_cmd_auth_logout)

    auth_whoami = auth_sub.add_parser("whoami", help="Show current user")
    auth_whoami.set_defaults(handler=_cmd_auth_whoami)

    auth_status = auth_sub.add_parser("status", help="Show auth status")
    auth_status.set_defaults(handler=_cmd_auth_status)

    auth_api_key = auth_sub.add_parser("api-key", help="API-key subcommands")
    auth_api_key_sub = auth_api_key.add_subparsers(
        dest="auth_api_key_cmd", required=True
    )

    api_key_set = auth_api_key_sub.add_parser("set", help="Store API key")
    api_key_set.add_argument("--api-key", required=True)
    api_key_set.add_argument(
        "--scope",
        action="append",
        default=[],
        help="Declared API-key scope (repeatable).",
    )
    api_key_set.set_defaults(handler=_cmd_auth_api_key_set)

    api_key_show = auth_api_key_sub.add_parser("show", help="Show API key state")
    api_key_show.set_defaults(handler=_cmd_auth_api_key_show)

    api_key_clear = auth_api_key_sub.add_parser(
        "clear", help="Clear API-key config"
    )
    api_key_clear.set_defaults(handler=_cmd_auth_api_key_clear)

    workspaces_parser = root_subparsers.add_parser(
        "workspaces", help="Workspace commands"
    )
    workspaces_sub = workspaces_parser.add_subparsers(
        dest="workspaces_cmd", required=True
    )

    workspaces_list = workspaces_sub.add_parser("list", help="List workspaces")
    workspaces_list.set_defaults(handler=_cmd_workspaces_list)

    workspaces_get = workspaces_sub.add_parser("get", help="Get workspace")
    workspaces_get.add_argument("workspace_code")
    workspaces_get.set_defaults(handler=_cmd_workspaces_get)

    workspaces_roles = workspaces_sub.add_parser("roles", help="List roles")
    workspaces_roles.add_argument("workspace_code")
    workspaces_roles.set_defaults(handler=_cmd_workspaces_roles)

    workspaces_permissions = workspaces_sub.add_parser(
        "permission-definitions", help="List permission definitions"
    )
    workspaces_permissions.add_argument("workspace_code")
    workspaces_permissions.set_defaults(
        handler=_cmd_workspaces_permission_definitions
    )

    workflows_parser = root_subparsers.add_parser(
        "workflows", help="Workflow commands"
    )
    workflows_sub = workflows_parser.add_subparsers(
        dest="workflows_cmd", required=True
    )

    workflows_list = workflows_sub.add_parser("list", help="List workflows")
    workflows_list.add_argument("--workspace", required=True)
    workflows_list.set_defaults(handler=_cmd_workflows_list)

    workflows_runs = workflows_sub.add_parser("runs", help="List workflow runs")
    workflows_runs.add_argument("--workspace", required=True)
    workflows_runs.add_argument("--workflow-id", required=True)
    workflows_runs.set_defaults(handler=_cmd_workflows_runs)

    workflows_execute = workflows_sub.add_parser(
        "execute", help="Execute workflow"
    )
    workflows_execute.add_argument("--workspace", required=True)
    workflows_execute.add_argument("--workflow-id", required=True)
    workflows_execute.add_argument("--run-type", default="manual")
    workflows_execute.add_argument("--entry-node-id", default=None)
    workflows_execute.add_argument("--overrides-file", default=None)
    workflows_execute.set_defaults(handler=_cmd_workflows_execute)

    integrations_parser = root_subparsers.add_parser(
        "integrations", help="Integration commands"
    )
    integrations_sub = integrations_parser.add_subparsers(
        dest="integrations_cmd", required=True
    )

    integrations_connections = integrations_sub.add_parser(
        "connections",
        help="Integration connection commands",
    )
    integrations_connections_sub = integrations_connections.add_subparsers(
        dest="integrations_connections_cmd",
        required=True,
    )

    integrations_connections_list = integrations_connections_sub.add_parser(
        "list",
        help="List integration connections",
    )
    integrations_connections_list.add_argument("--workspace", required=True)
    integrations_connections_list.add_argument(
        "--integration-type",
        default=None,
        help="Optional client-side filter on integration type",
    )
    integrations_connections_list.set_defaults(
        handler=_cmd_integrations_connections_list
    )

    integrations_objects = integrations_connections_sub.add_parser(
        "objects",
        help="Integration object diagnostics",
    )
    integrations_objects_sub = integrations_objects.add_subparsers(
        dest="integrations_objects_cmd",
        required=True,
    )

    integrations_objects_products = integrations_objects_sub.add_parser(
        "products",
        help="List Shopify product objects",
    )
    integrations_objects_products.add_argument("--workspace", required=True)
    integrations_objects_products.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_products.add_argument("--limit", type=int, default=50)
    integrations_objects_products.add_argument("--offset", type=int, default=0)
    integrations_objects_products.set_defaults(
        handler=_cmd_integrations_objects_products
    )

    integrations_objects_variants = integrations_objects_sub.add_parser(
        "variants",
        aliases=["skus"],
        help="List Shopify variant objects (includes SKU data)",
    )
    integrations_objects_variants.add_argument("--workspace", required=True)
    integrations_objects_variants.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_variants.add_argument("--limit", type=int, default=50)
    integrations_objects_variants.add_argument("--offset", type=int, default=0)
    integrations_objects_variants.set_defaults(
        handler=_cmd_integrations_objects_variants
    )

    integrations_objects_inventory_items = integrations_objects_sub.add_parser(
        "inventory-items",
        help="List Shopify inventory item objects",
    )
    integrations_objects_inventory_items.add_argument("--workspace", required=True)
    integrations_objects_inventory_items.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_inventory_items.add_argument("--limit", type=int, default=50)
    integrations_objects_inventory_items.add_argument(
        "--offset", type=int, default=0
    )
    integrations_objects_inventory_items.set_defaults(
        handler=_cmd_integrations_objects_inventory_items
    )

    integrations_objects_inventory_levels = integrations_objects_sub.add_parser(
        "inventory-levels",
        help="List Shopify inventory level objects",
    )
    integrations_objects_inventory_levels.add_argument("--workspace", required=True)
    integrations_objects_inventory_levels.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_inventory_levels.add_argument(
        "--limit", type=int, default=50
    )
    integrations_objects_inventory_levels.add_argument("--offset", type=int, default=0)
    integrations_objects_inventory_levels.set_defaults(
        handler=_cmd_integrations_objects_inventory_levels
    )

    integrations_objects_by_type = integrations_objects_sub.add_parser(
        "by-type",
        help="List integration objects for any external object type",
    )
    integrations_objects_by_type.add_argument("--workspace", required=True)
    integrations_objects_by_type.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_by_type.add_argument(
        "--external-object-type", required=True
    )
    integrations_objects_by_type.add_argument("--limit", type=int, default=50)
    integrations_objects_by_type.add_argument("--offset", type=int, default=0)
    integrations_objects_by_type.set_defaults(
        handler=_cmd_integrations_objects_by_type
    )

    integrations_objects_fetch = integrations_objects_sub.add_parser(
        "fetch",
        help="Fetch Shopify objects by external type/id using fixed queries",
    )
    integrations_objects_fetch.add_argument("--workspace", required=True)
    integrations_objects_fetch.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_fetch.add_argument(
        "--external-object-type",
        required=True,
        help="External object type or Shopify mirror entity (e.g. variant, inventory_item, variants)",
    )
    integrations_objects_fetch.add_argument(
        "--external-object-id",
        action="append",
        required=True,
        help="External object id (Shopify gid or numeric id). Repeat for multiple ids.",
    )
    integrations_objects_fetch.set_defaults(
        handler=_cmd_integrations_objects_fetch
    )

    integrations_objects_get = integrations_objects_sub.add_parser(
        "get",
        help="Get one integration object payload by integration object id",
    )
    integrations_objects_get.add_argument("--workspace", required=True)
    integrations_objects_get.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_get.add_argument("--integration-object-id", required=True)
    integrations_objects_get.set_defaults(handler=_cmd_integrations_objects_get)

    integrations_objects_timeline = integrations_objects_sub.add_parser(
        "timeline",
        help="Show event/webhook timeline for one integration object",
    )
    integrations_objects_timeline.add_argument("--workspace", required=True)
    integrations_objects_timeline.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_timeline.add_argument(
        "--integration-object-id", required=True
    )
    integrations_objects_timeline.add_argument("--limit", type=int, default=50)
    integrations_objects_timeline.set_defaults(
        handler=_cmd_integrations_objects_timeline
    )

    wms_parser = root_subparsers.add_parser("wms", help="WMS commands")
    wms_sub = wms_parser.add_subparsers(dest="wms_cmd", required=True)

    wms_facilities = wms_sub.add_parser("facilities", help="List facilities")
    wms_facilities.add_argument("--workspace", required=True)
    wms_facilities.add_argument("--limit", type=int, default=50)
    wms_facilities.add_argument("--offset", type=int, default=0)
    wms_facilities.add_argument(
        "--require-manage-stock",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_facilities.set_defaults(handler=_cmd_wms_facilities)

    wms_skus = wms_sub.add_parser("skus", help="List SKUs")
    wms_skus.add_argument("--workspace", required=True)
    wms_skus.add_argument("--query", default=None)
    wms_skus.add_argument("--limit", type=int, default=50)
    wms_skus.add_argument("--offset", type=int, default=0)
    wms_skus.add_argument(
        "--include-on-hand",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_skus.add_argument(
        "--in-stock-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_skus.set_defaults(handler=_cmd_wms_skus)

    wms_query = wms_sub.add_parser(
        "query",
        help="Query any read-only WMS endpoint (debug helper)",
    )
    wms_query.add_argument("--workspace", required=True)
    wms_query.add_argument(
        "--path",
        required=True,
        help=(
            "Endpoint path relative to /workspaces/{workspace}/wms, or full "
            "/api/v2/workspaces/{workspace}/wms path."
        ),
    )
    wms_query.add_argument(
        "--param",
        action="append",
        default=[],
        help="Query parameter in key=value format (repeatable).",
    )
    wms_query.set_defaults(handler=_cmd_wms_query)

    wms_connections = wms_sub.add_parser(
        "connections",
        help="Integration connection commands",
    )
    wms_connections_sub = wms_connections.add_subparsers(
        dest="wms_connections_cmd",
        required=True,
    )
    wms_connections_list = wms_connections_sub.add_parser(
        "list",
        help="List integration connections",
    )
    wms_connections_list.add_argument("--workspace", required=True)
    wms_connections_list.add_argument("--integration-type", default=None)
    wms_connections_list.set_defaults(handler=_cmd_wms_connections_list)

    wms_sku_mappings = wms_sub.add_parser(
        "sku-mappings",
        help="SKU mapping diagnostic commands",
    )
    wms_sku_mappings_sub = wms_sku_mappings.add_subparsers(
        dest="wms_sku_mappings_cmd",
        required=True,
    )
    wms_sku_mappings_by_connection = wms_sku_mappings_sub.add_parser(
        "by-connection",
        help="List SKU mappings for an integration connection",
    )
    wms_sku_mappings_by_connection.add_argument("--workspace", required=True)
    wms_sku_mappings_by_connection.add_argument(
        "--integration-connection-id",
        required=True,
    )
    wms_sku_mappings_by_connection.add_argument("--external-object-type", default=None)
    wms_sku_mappings_by_connection.add_argument("--external-object-id", default=None)
    wms_sku_mappings_by_connection.add_argument("--limit", type=int, default=50)
    wms_sku_mappings_by_connection.add_argument("--offset", type=int, default=0)
    wms_sku_mappings_by_connection.set_defaults(
        handler=_cmd_wms_sku_mappings_by_connection
    )

    wms_sku_mappings_by_sku = wms_sku_mappings_sub.add_parser(
        "by-sku",
        help="List mappings for a specific WMS SKU",
    )
    wms_sku_mappings_by_sku.add_argument("--workspace", required=True)
    wms_sku_mappings_by_sku.add_argument("--sku-id", required=True)
    wms_sku_mappings_by_sku.set_defaults(handler=_cmd_wms_sku_mappings_by_sku)

    wms_reconcile = wms_sub.add_parser(
        "reconcile",
        help="Inventory reconcile diagnostics",
    )
    wms_reconcile_sub = wms_reconcile.add_subparsers(
        dest="wms_reconcile_cmd",
        required=True,
    )
    wms_reconcile_available = wms_reconcile_sub.add_parser(
        "available",
        help="List WMS vs integration available-quantity reconcile rows",
    )
    wms_reconcile_available.add_argument("--workspace", required=True)
    wms_reconcile_available.add_argument(
        "--integration-connection-id",
        required=True,
    )
    wms_reconcile_available.add_argument("--sku-id", default=None)
    wms_reconcile_available.add_argument("--facility-id", default=None)
    wms_reconcile_available.add_argument("--limit", type=int, default=200)
    wms_reconcile_available.add_argument("--offset", type=int, default=0)
    wms_reconcile_available.add_argument(
        "--actionable-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_reconcile_available.add_argument(
        "--managed-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_reconcile_available.set_defaults(handler=_cmd_wms_reconcile_available)

    return parser


def cli(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    state = CliState(
        profile_name=args.profile,
        base_url_override=args.base_url,
        output_override=args.output,
        auth_mode=args.auth_mode,
    )
    try:
        payload = args.handler(args, state)  # type: ignore[attr-defined]
        if payload is not None:
            emit_payload(payload, output_mode=state.output_mode)
        return 0
    except CliError as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(cli())
