"""Public Wilfie API-wrapper CLI package."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as package_version

__all__ = ["__version__"]

try:
    __version__ = package_version("wilfie")
except PackageNotFoundError:
    __version__ = "0.1.0"
