# Wilfie CLI

Wilfie is a command-line client for Wilfie APIs.

Use it to authenticate and run workspace, workflow, and WMS commands from your terminal.

## Install

```bash
uv tool install wilfie
```

Or with `pip`:

```bash
pip install wilfie
```

## Quickstart

Login with device flow:

```bash
wilfie auth login --client-id wilfie-cli
```

Check auth status:

```bash
wilfie auth status
```

List workspaces:

```bash
wilfie workspaces list
```

Run a WMS query:

```bash
wilfie wms query \
  --workspace <workspace_code> \
  --path facility-locations/search \
  --param query=A-01 \
  --param limit=25
```

## Common Commands

- `wilfie auth login`
- `wilfie auth refresh`
- `wilfie auth logout`
- `wilfie workflows list --workspace <workspace_code>`
- `wilfie workflows execute --workspace <workspace_code> --workflow-id <id>`
- `wilfie wms facilities --workspace <workspace_code>`
- `wilfie wms skus --workspace <workspace_code>`

## Configuration

- Default API host is `https://wilfie.ai`.
- Use `--base-url` to target another environment.
- Output modes: `--output table` (default), `--output json`.

## Links

- Homepage: <https://wilfie.ai>
- Documentation: <https://github.com/gavincliffe/wilfie-flask-app/tree/main/docs>
