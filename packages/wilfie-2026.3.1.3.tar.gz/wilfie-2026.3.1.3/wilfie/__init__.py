"""Compatibility module for `python -m wilfie`."""
