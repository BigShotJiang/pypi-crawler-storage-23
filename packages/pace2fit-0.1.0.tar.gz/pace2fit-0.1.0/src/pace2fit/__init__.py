"""pace2fit - Generate Garmin FIT workout files from a simple DSL."""

__version__ = "0.1.0"
