slc
---

.. automodule:: telnetlib3.slc
   :members:
