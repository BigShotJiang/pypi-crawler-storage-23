fingerprinting
--------------

.. automodule:: telnetlib3.fingerprinting
   :members:
