stream_writer
-------------

.. automodule:: telnetlib3.stream_writer
   :members:
