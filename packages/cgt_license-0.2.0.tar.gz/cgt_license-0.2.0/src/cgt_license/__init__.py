"""CGT License SDK -- Python wrapper for Guard.dll."""

__version__ = "0.2.0"

from ._guard import (
    GuardFFI,
    LicenseError,
    InvalidKeyError,
    MaxDevicesError,
    ProductMismatchError,
    NetworkError,
    NotInitializedError,
    NoSecretError,
    DecryptError,
)
from .bootstrap import bootstrap

# Global guard instance, set by bootstrap
_guard_instance: GuardFFI | None = None


def get_guard() -> GuardFFI:
    """Get the bootstrapped guard instance."""
    if _guard_instance is None:
        raise NotInitializedError(
            "License not bootstrapped. Add 'import cgt_license_bootstrap' "
            "at the top of your entrypoint."
        )
    return _guard_instance


def decrypt_asset(encrypted: bytes) -> bytes:
    """Decrypt an encrypted asset file using the runtime secret.

    The runtime secret is held by Guard.dll and was obtained during lease.
    Key derivation: HKDF-SHA256(runtime_secret, salt="cgt-asset", info=product_id)
    Cipher: AES-256-GCM
    Format: nonce(12) + ciphertext + tag(16)
    """
    return get_guard().decrypt_asset(encrypted)
