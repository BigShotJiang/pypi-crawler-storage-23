"""CGT License Bootstrap -- import this module to activate license gating.

Usage in your app's entrypoint:
    import cgt_license_bootstrap  # This line gates the app

    # If execution reaches here, license is valid
    from myapp import MainWindow
    ...
"""

from cgt_license.bootstrap import bootstrap
import cgt_license

# Run bootstrap immediately on import
_guard = bootstrap()

# Store guard instance globally for decrypt_asset() etc.
cgt_license._guard_instance = _guard
