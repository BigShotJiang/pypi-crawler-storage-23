import os
os.chdir(os.path.dirname(__file__))