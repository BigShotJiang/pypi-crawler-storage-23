"""
Celery utilities module.

This module provides interface classes for interacting with Celery
in different ways (inspect API, result backends, event monitors, etc.).
"""

from .base import CeleryAbstractInterface
from .inspector import CeleryInspector
from .periodic_tasks import (
    CeleryPeriodicTasksConfigBackend,
    CeleryPeriodicTasksDjangoCeleryBeatBackend,
    CeleryPeriodicTasksInterface,
    PeriodicTaskListPage,
)
from .queues import (
    CeleryQueuesInspectBackend,
    CeleryQueuesInterface,
    QueueDetailPage,
    QueueListPage,
)
from .tasks import (
    CeleryTasksDjangoCeleryResultsBackend,
    CeleryTasksInspectBackend,
    CeleryTasksInterface,
    TaskDetailPage,
    TaskListPage,
)
from .workers import (
    CeleryWorkersInspectBackend,
    CeleryWorkersInterface,
    WorkerDetailPage,
    WorkerListPage,
)

__all__ = [
    # Base classes
    "CeleryAbstractInterface",
    # Inspector
    "CeleryInspector",
    # Tasks
    "CeleryTasksInterface",
    "CeleryTasksDjangoCeleryResultsBackend",
    "CeleryTasksInspectBackend",
    "TaskListPage",
    "TaskDetailPage",
    # Workers
    "CeleryWorkersInterface",
    "CeleryWorkersInspectBackend",
    "WorkerListPage",
    "WorkerDetailPage",
    # Queues
    "CeleryQueuesInterface",
    "CeleryQueuesInspectBackend",
    "QueueListPage",
    "QueueDetailPage",
    # Periodic Tasks
    "CeleryPeriodicTasksInterface",
    "CeleryPeriodicTasksConfigBackend",
    "CeleryPeriodicTasksDjangoCeleryBeatBackend",
    "PeriodicTaskListPage",
]
