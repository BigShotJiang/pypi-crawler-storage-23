from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.contrib import admin, messages
from celery import current_app

from .conf import get_css_context
from .celery_utils import (
    CeleryInspector,
    CeleryPeriodicTasksInterface,
    CeleryQueuesInterface,
    CeleryTasksInterface,
    CeleryWorkersInterface,
)


@staff_member_required
def index(request):
    """
    Display Celery panel overview with static configuration information.
    Fast-loading page with no inspect API calls.
    """
    inspector = CeleryInspector(current_app)

    # Get static configuration info (no broker calls)
    config = inspector.get_configuration_info()

    # Get registered tasks (local operation)
    registered_tasks = inspector.get_registered_tasks(exclude_internal=True)

    # Get periodic tasks using the interface
    periodic_tasks_interface = CeleryPeriodicTasksInterface(current_app)
    periodic_tasks_result = periodic_tasks_interface.get_periodic_tasks()

    # Use Django's messaging framework for errors
    if periodic_tasks_result.error:
        messages.warning(request, periodic_tasks_result.error)

    # Get backend info for periodic tasks
    periodic_backend_info = periodic_tasks_interface.get_backend_info()

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": "Django Celery Panel - Overview",
            "current_tab": "overview",
            "config": config,
            "registered_tasks": registered_tasks,
            "registered_tasks_count": len(registered_tasks),
            "periodic_tasks": periodic_tasks_result.periodic_tasks,
            "periodic_tasks_count": periodic_tasks_result.periodic_tasks_count,
            "periodic_backend_info": periodic_backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/index.html", context)


@staff_member_required
def workers(request):
    """
    Display active Celery workers with real-time inspection data.
    """
    # Get workers using the interface
    worker_interface = CeleryWorkersInterface(current_app)
    worker_result = worker_interface.get_workers()

    # Use Django's messaging framework for errors and notifications
    if worker_result.error:
        messages.error(request, worker_result.error)

    # Get configuration for sidebar
    inspector = CeleryInspector(current_app)
    config = inspector.get_configuration_info()

    # Get backend info
    backend_info = worker_interface.get_backend_info()

    # Format result to match existing template expectations
    celery_status = {
        "celery_available": worker_result.celery_available,
        "workers": worker_result.workers,
        "workers_detail": worker_result.workers_detail,
        "active_workers_count": worker_result.active_workers_count,
        "error": worker_result.error,
        "config": config,
    }

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": "Django Celery Panel - Active Workers",
            "celery_status": celery_status,
            "current_tab": "workers",
            "backend_info": backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/workers.html", context)


@staff_member_required
def tasks(request):
    """
    Display task execution history with pagination and search.
    """
    # Get pagination and search parameters
    page = request.GET.get("page", 1)
    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1

    search_query = request.GET.get("search", "").strip()
    filter_type = request.GET.get("filter", None)
    # Convert string "None" or empty string to actual Python None
    if filter_type in ("None", "", None):
        filter_type = None
    per_page = 50

    # Get tasks using the interface
    task_interface = CeleryTasksInterface(current_app)

    # Get task data (interface will apply backend's default filter if needed)
    task_data = task_interface.get_tasks(
        search_query=search_query if search_query else None,
        page=page,
        per_page=per_page,
        filter_type=filter_type,
    )

    # Handle errors
    if task_data.error:
        messages.warning(request, f"Task retrieval warning: {task_data.error}")

    # Get backend info and available filters
    backend_info = task_interface.get_backend_info()
    available_filters = task_interface.get_available_filters()

    # Get the actual filter that was used (may differ from filter_type if backend has default)
    effective_filter = (
        filter_type if filter_type is not None else task_interface.get_default_filter()
    )

    # Add "selected" flag to each filter based on effective filter
    task_filters = []
    for filter_option in available_filters:
        filter_option_copy = filter_option.copy()
        filter_option_copy["selected"] = filter_option["value"] == effective_filter
        task_filters.append(filter_option_copy)

    # Show filters only if there are multiple options to choose from
    show_filters = len(task_filters) > 1

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": "Django Celery Panel - Tasks",
            "current_tab": "tasks",
            "tasks": task_data.tasks,
            "total_count": task_data.total_count,
            "page": task_data.page,
            "per_page": task_data.per_page,
            "total_pages": task_data.total_pages,
            "has_previous": task_data.has_previous,
            "has_next": task_data.has_next,
            "previous_page": task_data.previous_page,
            "next_page": task_data.next_page,
            "search_query": search_query,
            "backend_info": backend_info,
            "show_filters": show_filters,
            "task_filters": task_filters,
            "current_filter": filter_type,
        }
    )
    return render(request, "admin/dj_celery_panel/tasks.html", context)


@staff_member_required
def queues(request):
    """
    Display Celery queues information from active workers.
    """
    # Get queues using the interface
    queue_interface = CeleryQueuesInterface(current_app)
    queue_result = queue_interface.get_queues()

    if queue_result.error:
        messages.warning(
            request, f"Could not retrieve queue information: {queue_result.error}"
        )

    # Get backend info
    backend_info = queue_interface.get_backend_info()

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": "Django Celery Panel - Queues",
            "current_tab": "queues",
            "queues": queue_result.queues,
            "backend_info": backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/queues.html", context)


@staff_member_required
def queue_detail(request, queue_name):
    """
    Display detailed information about a specific queue.
    """
    # Get queue details using the interface
    queue_interface = CeleryQueuesInterface(current_app)
    result = queue_interface.get_queue_detail(queue_name)

    # Handle errors
    if result.error:
        messages.error(request, f"Error retrieving queue: {result.error}")

    # Get backend info
    backend_info = queue_interface.get_backend_info()

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": f"Django Celery Panel - Queue {queue_name}",
            "current_tab": "queues",
            "queue": result.queue,
            "queue_name": queue_name,
            "backend_info": backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/queue_detail.html", context)


@staff_member_required
def task_detail(request, task_id):
    """
    Display detailed information about a specific task instance.
    """
    # Get task details using the interface
    task_interface = CeleryTasksInterface(current_app)
    result = task_interface.get_task_detail(task_id)

    # Handle errors
    if result.error:
        messages.error(request, f"Error retrieving task: {result.error}")

    # Get backend info
    backend_info = task_interface.get_backend_info()

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": f"Django Celery Panel - Task {task_id[:8]}...",
            "current_tab": "tasks",
            "task": result.task,
            "backend_info": backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/task_detail.html", context)


@staff_member_required
def worker_detail(request, worker_id):
    """
    Display detailed information about a specific worker.
    """
    # Get worker details using the interface
    worker_interface = CeleryWorkersInterface(current_app)
    result = worker_interface.get_worker_detail(worker_id)

    # Handle errors
    if result.error:
        messages.error(request, f"Error retrieving worker: {result.error}")

    # Get backend info
    backend_info = worker_interface.get_backend_info()

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": f"Django Celery Panel - Worker {worker_id}",
            "current_tab": "workers",
            "worker": result.worker,
            "worker_id": worker_id,
            "backend_info": backend_info,
        }
    )
    return render(request, "admin/dj_celery_panel/worker_detail.html", context)


@staff_member_required
def configuration(request):
    """
    Display Celery configuration and DJ Celery Panel settings.
    """
    from django.conf import settings

    inspector = CeleryInspector(current_app)
    config = inspector.get_configuration_info()

    # Get DJ Celery Panel settings
    panel_settings = getattr(settings, "DJ_CELERY_PANEL_SETTINGS", {})

    context = admin.site.each_context(request)
    context.update(get_css_context())
    context.update(
        {
            "title": "Django Celery Panel - Configuration",
            "config": config,
            "panel_settings": panel_settings,
            "current_tab": "configuration",
        }
    )
    return render(request, "admin/dj_celery_panel/configuration.html", context)
