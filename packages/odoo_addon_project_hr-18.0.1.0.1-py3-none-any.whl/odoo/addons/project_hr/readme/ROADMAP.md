- Limit project and task visibility according employee categories
  through overriding security methods (as through record rules is not
  possible without modifying existing ones).
