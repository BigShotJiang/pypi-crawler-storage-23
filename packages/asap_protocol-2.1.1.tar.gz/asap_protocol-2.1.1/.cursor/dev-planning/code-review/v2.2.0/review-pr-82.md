# Code Review: PR #82

**PR Title:** Release v2.1.1: Tech debt & security hardening (SEC-01, ARCH-01, CONC-01)  
**Branch:** `release/2.1.1-tech-debt` → `main`  
**Reviewer:** Claude Opus 4.6 + Gemini 3.1 Pro
**Review Date:** 2026-03-01  
**Files Changed:** 24 (+422 / -52)  
**PR Checks:** pytest ✅ (2549 passed), ruff ✅, ruff format ✅, mypy ✅

---

## 1. Executive Summary

| Category | Status | Summary |
| :--- | :--- | :--- |
| **Tech Stack** | ✅ | No new external dependencies added. `joserfc`, `aiosqlite`, `Pydantic v2`, `httpx` — all correct. `redis-py` added as **optional** extra (`[redis]`), which is appropriate. |
| **Architecture** | ✅ | SEC-01, ARCH-01, CONC-01 all addressed faithfully. Async methods added to `SQLiteSnapshotStore`, `asyncio.Lock` replaces `threading.Lock` in auth caches, WAL mode enabled. |
| **Security** | ⚠️ | JWT algorithm allowlist correctly implemented. Vercel AI `api_key_header` guard is functional but has two minor gaps (see §2). |
| **Tests** | ✅ | Excellent coverage for all new code paths: algorithm confusion, concurrent async save/get, WAL mode verification, dead letters cap, API key 401/200, `aud` array coercion, echo handler validation error. |

> **General Feedback:** This is a high-quality tech debt PR that systematically resolves every finding from the v2.1.0 Red-Team review. The changes are backward-compatible, well-tested, and correctly scoped. There are **no blocking issues** — only recommendations to harden further. The code is merge-ready after reviewing the suggestions below.

---

## 2. Required Fixes (Must Address Before Merge)

**None.** There are no blocking issues. All items below are recommendations.

---

## 3. Recommended Fixes (Strongly Suggested)

### 3.1 [SEC-LOW] `_require_api_key` Does Not Compare Against Expected Value

*   **Location:** `src/asap/integrations/vercel_ai.py:141-148`
*   **Problem:** The `_require_api_key` dependency only checks that the header is *present and non-empty*, but never compares it against an expected secret value. Any non-empty string is accepted:
    ```python
    async def _require_api_key(request: Request) -> None:
        if api_key_header is None:
            return
        value = (request.headers.get(api_key_header) or "").strip()
        if not value:
            raise HTTPException(status_code=401, ...)
    ```
    While the docstring says "all routes require that header to be present and non-empty", this provides a **presence check only** — not authentication. An attacker who guesses the header name can send `X-API-Key: anything` and pass.
*   **Rationale:** This is a defense-in-depth gap. The task (1.3) says "optional `api_key_header` parameter", and the current behavior matches the literal spec. However, users may *expect* that setting `api_key_header` actually enforces a secret. Adding an `api_key_value` parameter would close this.
*   **Fix Suggestion:**
    ```python
    def create_asap_tools_router(
        ...
        api_key_header: str | None = None,
        api_key_value: str | None = None,  # NEW: expected secret value
    ) -> APIRouter:
        ...
        async def _require_api_key(request: Request) -> None:
            if api_key_header is None:
                return
            value = (request.headers.get(api_key_header) or "").strip()
            if not value:
                raise HTTPException(status_code=401, ...)
            if api_key_value is not None and not hmac.compare_digest(value, api_key_value):
                raise HTTPException(status_code=401, detail="Invalid API key")
    ```
    Use `hmac.compare_digest()` for constant-time comparison to prevent timing attacks.
*   **Severity:** Low (current behavior matches the task spec; fix can be deferred to v2.2.0).

---

## 4. Tech-Specific Bug Hunt (Deep Dive)

### FastAPI & Pydantic v2

- [x] **`echo_handler` Pydantic validation**: Correctly changed from `TaskRequest(**dict)` to `TaskRequest.model_validate()`. Test confirms `ValidationError` is raised on invalid input. ✅
- [x] **Mutable defaults**: No mutable default arguments found in any Pydantic models or function signatures. ✅
- [x] **`dependency_overrides` cleanup**: Not applicable to this PR's test changes. Existing pattern is correct per v2.1.0 review. ✅

### Asyncio & aiosqlite

- [ ] **`_apply_wal_pragmas()` Called Per-Operation (Performance):**  
  `_apply_wal_pragmas()` is called inside every `_save_impl`, `_get_impl`, `_list_versions_impl`, and `_delete_impl` method — 10+ call sites across `sqlite.py` and `storage.py`. Since each method opens a *new* `aiosqlite.connect()` context, the pragmas must be re-applied each time (they are per-connection). This is correct but **adds ~2 extra SQL round-trips per operation**. 

  Consider adding a `_connect()` helper that handles both connection + pragmas:
  ```python
  @asynccontextmanager
  async def _connect(self):
      async with aiosqlite.connect(self._db_path) as conn:
          await _apply_wal_pragmas(conn)
          yield conn
  ```
  This isn't a bug but reduces duplication and makes it harder to forget pragmas on new methods.

- [ ] **`ManifestCache` Still Uses `threading.Lock` (Consistency):**  
  `transport/cache.py:77` — `ManifestCache` uses `threading.Lock()` for all `get()`, `set()`, `invalidate()`, and `cleanup_expired()` operations. The `start_periodic_cleanup()` calls `cache.cleanup_expired()` from an async context. Since `threading.Lock` is held very briefly (in-memory dict ops), this is **safe** here — unlike the auth caches which did HTTP I/O under the lock. However, for consistency with the CONC-01 fix pattern, consider migrating to `asyncio.Lock` in a future sprint.

- [x] **`asyncio.create_task()` stored reference**: `start_periodic_cleanup()` returns the task, and tests properly `cancel()` it. No GC risk. ✅
- [x] **No nested transactions**: WAL pragma is a session-level command, not a transaction. Correct. ✅
- [x] **`SQLiteMeteringStorage._ensure_table_once`**: Lazy init flag in `storage.py` correctly skips redundant `CREATE TABLE IF NOT EXISTS` after first call. ✅

### Security

- [x] **JWT algorithm allowlist (SEC-01)**: `_ALLOWED_JWT_ALGORITHMS` defined in `jwks.py`, imported in `middleware.py`. Passed to both `jose_jwt.decode()` call sites. Test for `alg: none` rejection passes. ✅
- [x] **`aud` claim list coercion**: `isinstance(aud, list)` check correctly extracts `aud[0]` per RFC 7519. Handles empty list (`None`). Dedicated test with `aud: ["urn:asap:agent:b"]` verifies. ✅
- [x] **Ed25519 enforcement**: No new signing paths introduced. ✅
- [x] **No hardcoded secrets**: No API keys, tokens, or passwords found in diff. ✅
- [x] **SQL injection**: All new SQL uses parameterized `?` placeholders. Table names remain module constants. ✅

### Next.js / Frontend

- Not applicable — this PR only touches Python backend and planning docs.

---

## 5. Improvements & Refactoring (Highly Recommended)

- [ ] **`dead_letters.pop(0)` is O(n) — Use `deque`:**  
  `webhook.py:513` — `self._dead_letters.pop(0)` on a `list` is O(n) because it shifts all elements. Under sustained webhook failures with `MAX_DEAD_LETTERS=1000`, this means ~1000 memory moves per dead letter. Replace with `collections.deque(maxlen=MAX_DEAD_LETTERS)`:
  ```python
  self._dead_letters: deque[DeadLetterEntry] = deque(maxlen=MAX_DEAD_LETTERS)
  # Remove the manual pop(0) — deque handles eviction automatically.
  self._dead_letters.append(entry)
  ```
  Note: `dead_letters` property would need `list(self._dead_letters)` return (already the case).

- [ ] **`_ensure_table_once` is Not Thread-Safe (Minor):**  
  `storage.py:506-509` — The `_initialized` flag is checked and set without a lock. Under concurrent first-time calls, multiple tasks could race into `_ensure_table()`. This is **harmless** because `CREATE TABLE IF NOT EXISTS` is idempotent, but adding a simple `asyncio.Lock()` guard would make it formally correct:
  ```python
  async def _ensure_table_once(self, conn: aiosqlite.Connection) -> None:
      if self._initialized:
          return
      async with self._init_lock:
          if not self._initialized:
              await self._ensure_table(conn)
              self._initialized = True
  ```

- [ ] **Stale Docstring in `JWKSValidator.fetch_keys`:**  
  `jwks.py:140` says "thread-safe cache" but it now uses `asyncio.Lock` (task-safe, not thread-safe). Update to "task-safe" for accuracy.

- [ ] **`reset_registry_cache()` Removed Lock Guard:**  
  `registry.py:191-193` — `_registry_cache.clear()` and `_registry_locks.clear()` are now called without the former `_registry_locks_guard` threading lock. This is used in test teardowns only, so it's safe. However, if ever called concurrently with `discover_from_registry()`, the `.clear()` on `_registry_locks` could remove a lock that's actively held. Add a comment that this is test-only:
  ```python
  def reset_registry_cache() -> None:
      """Clear module-level registry cache and locks (TEST ONLY — not safe to call concurrently)."""
  ```

---

## 6. Verification Steps

All recommended fixes can be verified with:

```bash
# Full regression (should already pass):
uv run pytest tests/ -x -q
uv run mypy src/ scripts/ tests/
uv run ruff check src/

# Specific verifications:
uv run pytest tests/auth/test_jwks.py -v -k "none_algorithm"
uv run pytest tests/state/test_sqlite_store.py -v -k "concurrent"
uv run pytest tests/state/test_sqlite_store.py -v -k "wal"
uv run pytest tests/integrations/test_vercel_ai.py -v
uv run pytest tests/economics/test_delegation.py -v -k "aud_claim_array"
```

---

## 7. Things Done Well (Strengths)

- **Comprehensive task tracking**: Every item from the v2.1.0 review has a corresponding task number, implementation, and test.
- **Test quality**: New tests don't just check the happy path — `test_validate_jwt_raises_on_none_algorithm_token`, `test_sqlite_snapshot_store_concurrent_async_save_get` (50 concurrent ops), and `test_echo_handler_raises_validation_error_on_invalid_payload` all exercise failure modes.
- **Backward compatibility**: Sync `SnapshotStore` Protocol methods preserved alongside new `_async` variants. No wire protocol changes.
- **CHANGELOG discipline**: Comprehensive and well-structured v2.1.1 entry with clear categories.
- **Clean git history**: One logical commit per concern area, clean branch naming.
