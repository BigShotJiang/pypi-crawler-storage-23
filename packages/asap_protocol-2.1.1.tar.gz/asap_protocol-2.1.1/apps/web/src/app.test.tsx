import { describe, it, expect } from 'vitest';

describe('App', () => {
    it('should run tests successfully', () => {
        expect(true).toBe(true);
    });
});
