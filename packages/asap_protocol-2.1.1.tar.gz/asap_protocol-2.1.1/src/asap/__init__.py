"""ASAP: Async Simple Agent Protocol.

A streamlined, scalable, asynchronous protocol for agent-to-agent communication
and task coordination.
"""

__version__ = "2.1.1"

__all__ = ["__version__"]
