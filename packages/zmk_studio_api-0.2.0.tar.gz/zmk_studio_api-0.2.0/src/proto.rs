include!(concat!(env!("OUT_DIR"), "/proto_mod.rs"));
