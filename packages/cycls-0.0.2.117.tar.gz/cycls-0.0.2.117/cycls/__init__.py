from .function import function, Function
from .app import app, App
from .agent import Agent

# Module-level config
api_key = None
base_url = None
