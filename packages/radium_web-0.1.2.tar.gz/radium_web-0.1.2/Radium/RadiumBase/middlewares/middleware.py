def middleware(path, environ):
    if True: # you can add conditions here
        return # return the Response
    else:
        return None

# outputs should be either JSONResponse or RedirectResponse
