# =====================================
# generator=datazen
# version=3.2.3
# hash=d7721d3e4e7fae6161d538f1104cee4b
# =====================================
"""
svgen - Package's default entry-point.
"""

# built-in
import sys

# internal
from svgen.entry import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
