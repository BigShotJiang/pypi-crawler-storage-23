# =====================================
# generator=datazen
# version=3.2.3
# hash=190361f08245c620060caef38f06d492
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A tool for working with scalable vector graphics."
PKG_NAME = "svgen"
VERSION = "0.9.4"
