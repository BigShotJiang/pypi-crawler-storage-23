django_jsoneditor_init = {
    mode: 'code',
    modes: ['code', 'form', 'text', 'tree', 'view'], // all modes
    // modes: ['code', 'tree'], // allowed modes
    sortObjectKeys: true,
    search: false,

}
// expandFolds
