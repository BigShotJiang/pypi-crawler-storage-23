from policygate_capital.version import __version__

__all__ = ["__version__"]
