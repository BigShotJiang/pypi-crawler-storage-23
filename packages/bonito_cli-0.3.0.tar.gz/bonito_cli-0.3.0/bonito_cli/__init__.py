"""Bonito CLI — Unified multi-cloud AI management from your terminal."""

__version__ = "0.3.0"
