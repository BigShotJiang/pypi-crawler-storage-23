"""
UNI Protocol query definitions.

Created on 26 Jan 2026

:author: semuadmin (Steve Smith)
"""

# no POLL messages currently defined in protocol (uses ASCII queries)
UNI_PAYLOADS_POLL = {}
