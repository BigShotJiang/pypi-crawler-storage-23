"""
UNI Protocol command payload definitions.

Created on 26 Jan 2026

:author: semuadmin (Steve Smith)
"""

# no SET messages currently defined in protocol (uses ASCII commands)
UNI_PAYLOADS_SET = {}
