"""Shared fixtures and configuration for integration tests."""
from __future__ import annotations

import httpx
import pytest

from xapiand import client


@pytest.fixture(autouse=True)
def _reset_xapiand_session():
    """Reset the httpx session before each test to avoid event loop issues."""
    from xapiand import Xapiand
    Xapiand.session = httpx.AsyncClient(
        limits=httpx.Limits(max_connections=100, max_keepalive_connections=100),
        trust_env=False,
        follow_redirects=False,
    )
    old_commit = client.commit
    client.commit = True
    yield
    client.commit = old_commit
