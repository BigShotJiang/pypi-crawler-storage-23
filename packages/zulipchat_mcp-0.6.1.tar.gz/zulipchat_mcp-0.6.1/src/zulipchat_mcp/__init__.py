"""ZulipChat MCP Server package."""

__version__ = "0.6.1"

__all__: list[str] = []
