"""Client integration helpers for ZulipChat MCP."""

from .registry import main

__all__ = ["main"]
