#!/usr/bin/env bash
set -euo pipefail
codex mcp add zulipchat uvx zulipchat-mcp --zulip-config-file ~/.zuliprc
