---
name: Feature Request
about: Suggest an improvement
title: ""
labels: enhancement, needs-triage
assignees: ""
---

## Problem

What problem should this solve?

## Proposed Change

Describe the expected behavior.

## Alternatives

What alternatives did you consider?

## Additional Context

Links, examples, or prior discussions.
