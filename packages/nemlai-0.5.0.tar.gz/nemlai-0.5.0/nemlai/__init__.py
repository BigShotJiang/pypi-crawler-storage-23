"""NemlAI Python SDK — a thin client for the NemlAI CLI API."""

from nemlai.client import NemlAI, NemlAIError, parse_response
from nemlai.models import (
    BasketItem,
    BasketItemV2,
    BasketItems,
    BatchAddResult,
    Product,
    SearchResults,
)

__version__ = "0.5.0"

__all__ = [
    "NemlAI",
    "NemlAIError",
    "parse_response",
    "BasketItem",
    "BasketItemV2",
    "BasketItems",
    "BatchAddResult",
    "Product",
    "SearchResults",
    "__version__",
]
