"""VERONICA adapters — optional framework integrations.

Each adapter module declares its own external dependency.
Import adapters explicitly; they are not loaded by veronica_core at startup.
"""
