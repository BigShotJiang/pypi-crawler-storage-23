"""VERONICA Execution Shield."""
from veronica_core.shield.adaptive_budget import (
    AdaptiveBudgetHook,
    AdjustmentResult,
)
from veronica_core.shield.budget_window import BudgetWindowHook
from veronica_core.shield.config import ShieldConfig
from veronica_core.shield.input_compression import (
    Compressor,
    InputCompressionHook,
    TemplateCompressor,
)
from veronica_core.shield.time_policy import TimeAwarePolicy, TimeResult
from veronica_core.shield.token_budget import TokenBudgetHook
from veronica_core.shield.errors import ShieldBlockedError
from veronica_core.shield.event import SafetyEvent
from veronica_core.shield.hooks import (
    BudgetBoundaryHook,
    EgressBoundaryHook,
    PostDispatchHook,
    PreDispatchHook,
    RetryBoundaryHook,
    ToolDispatchHook,
)
from veronica_core.shield.noop import (
    NoopBudgetBoundaryHook,
    NoopEgressBoundaryHook,
    NoopPostDispatchHook,
    NoopPreDispatchHook,
    NoopRetryBoundaryHook,
    NoopToolDispatchHook,
)
from veronica_core.shield.pipeline import ShieldPipeline
from veronica_core.shield.safe_mode import SafeModeHook
from veronica_core.shield.types import Decision, ToolCallContext

__all__ = [
    "ShieldConfig", "ShieldPipeline", "ShieldBlockedError",
    "Decision", "ToolCallContext",
    "PreDispatchHook", "PostDispatchHook", "EgressBoundaryHook", "RetryBoundaryHook", "BudgetBoundaryHook",
    "ToolDispatchHook",
    "NoopPreDispatchHook", "NoopPostDispatchHook", "NoopEgressBoundaryHook", "NoopRetryBoundaryHook", "NoopBudgetBoundaryHook",
    "NoopToolDispatchHook",
    "SafeModeHook",
    "BudgetWindowHook",
    "TokenBudgetHook",
    "Compressor",
    "InputCompressionHook",
    "TemplateCompressor",
    "AdaptiveBudgetHook",
    "AdjustmentResult",
    "TimeAwarePolicy",
    "TimeResult",
    "SafetyEvent",
]
