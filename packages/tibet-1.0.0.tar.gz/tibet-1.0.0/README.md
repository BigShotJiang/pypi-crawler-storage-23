# TIBET

> **The Trust Kernel for AI**
>
> Audit as a Precondition, Not an Afterthought.

[![PyPI](https://img.shields.io/pypi/v/tibet.svg)](https://pypi.org/project/tibet/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
# Core CLI
pip install tibet

# With compliance scanning
pip install tibet[audit]

# With trust scoring
pip install tibet[forge]

# Everything
pip install tibet[full]
```

## Quick Start

```bash
# Initialize TIBET in your project
tibet init

# Run compliance scan (AI Act, NIS2, GDPR)
tibet audit

# Check trust score
tibet forge

# Create provenance token
tibet create deploy --why "Release v1.0.0" --refs ticket-123

# Check status
tibet status
```

## Commands

| Command | Description |
|---------|-------------|
| `tibet init` | Initialize TIBET in project |
| `tibet audit` | Run compliance health scan |
| `tibet forge` | Run trust score analysis |
| `tibet create` | Create provenance token |
| `tibet verify` | Verify token integrity |
| `tibet export` | Export audit trail |
| `tibet status` | Show ecosystem status |
| `tibet version` | Show component versions |

## TIBET Ecosystem

| Package | Purpose |
|---------|---------|
| [tibet-core](https://pypi.org/project/tibet-core/) | Provenance tokens (ERIN/ERAAN/EROMHEEN/ERACHTER) |
| [tibet-audit](https://pypi.org/project/tibet-audit/) | Compliance scanning (AI Act, NIS2, GDPR) |
| [tibet-forge](https://pypi.org/project/tibet-forge/) | Trust scoring & certification |
| [tibet-vault](https://pypi.org/project/tibet-vault/) | Time-locked secrets |

## Philosophy

Every AI action, documented before execution.
Compliance built-in, not bolted-on.
One kernel. Every AI. Full provenance.

**ERIN** - What's IN the action (content)
**ERAAN** - What's attached (dependencies)
**EROMHEEN** - Context around it (environment)
**ERACHTER** - Intent behind it (why)

## Links

- [Humotica](https://humotica.com)
- [Documentation](https://humotica.com/docs/tibet)
- [MCP Server](https://pypi.org/project/mcp-server-tibet-core/)

---

**One Love, One fAmIly!**

Built by Humotica AI Lab
