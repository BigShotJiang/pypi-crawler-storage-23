"""
TIBET Unified CLI - The Trust Kernel for AI

Audit as a Precondition, Not an Afterthought.
"""

import click
import sys
import subprocess
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


BANNER = """
████████╗██╗██████╗ ███████╗████████╗
╚══██╔══╝██║██╔══██╗██╔════╝╚══██╔══╝
   ██║   ██║██████╔╝█████╗     ██║
   ██║   ██║██╔══██╗██╔══╝     ██║
   ██║   ██║██████╔╝███████╗   ██║
   ╚═╝   ╚═╝╚═════╝ ╚══════╝   ╚═╝
"""


@click.group()
@click.version_option(version="1.0.0", prog_name="tibet")
def main():
    """TIBET - The Trust Kernel for AI.

    Audit as a Precondition, Not an Afterthought.

    Unified CLI for compliance, provenance, and trust scoring.
    """
    pass


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--format", "-f", type=click.Choice(["text", "json", "markdown"]), default="text")
def audit(path, format):
    """Run compliance health scan (tibet-audit).

    Scans your project for AI Act, NIS2, GDPR compliance.
    """
    try:
        cmd = ["tibet-audit", "scan", path]
        if format != "text":
            cmd.extend(["--format", format])
        subprocess.run(cmd, check=True)
    except FileNotFoundError:
        console.print("[red]tibet-audit not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[audit][/cyan]")
        sys.exit(1)


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
def forge(path):
    """Run trust score scan (tibet-forge).

    Analyzes code quality, security, efficiency, and provenance readiness.
    """
    try:
        subprocess.run(["tibet-forge", "scan", path], check=True)
    except FileNotFoundError:
        console.print("[red]tibet-forge not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[forge][/cyan]")
        sys.exit(1)


@main.command()
@click.argument("action")
@click.option("--why", "-w", required=True, help="Intent behind this action (ERACHTER)")
@click.option("--what", "-W", default="{}", help="Content JSON (ERIN)")
@click.option("--refs", "-r", multiple=True, help="References (ERAAN)")
@click.option("--actor", "-a", default="cli", help="Who is performing this action")
def create(action, why, what, refs, actor):
    """Create a TIBET provenance token.

    Documents an action BEFORE execution with full provenance.

    Example:
        tibet create file_write --why "Fix login bug" --refs issue-123
    """
    try:
        from tibet_core import Provider
        import json

        provider = Provider(actor=actor)

        erin = json.loads(what) if what != "{}" else {}
        eraan = list(refs) if refs else []

        token = provider.create(
            action=action,
            erin=erin,
            erachter=why,
            eraan=eraan,
            eromheen={"cli": "tibet", "cwd": str(Path.cwd())}
        )

        console.print(Panel(
            f"[green]Token Created[/green]\n\n"
            f"[bold]ID:[/bold] {token.id}\n"
            f"[bold]Action:[/bold] {action}\n"
            f"[bold]Intent:[/bold] {why}\n"
            f"[bold]Actor:[/bold] {actor}",
            title="TIBET Provenance",
            border_style="green"
        ))

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[/cyan]")
        sys.exit(1)


@main.command()
@click.argument("token_id")
def verify(token_id):
    """Verify a TIBET token's integrity."""
    try:
        from tibet_core import Provider

        provider = Provider()
        token = provider.get(token_id)

        if not token:
            console.print(f"[red]Token not found: {token_id}[/red]")
            sys.exit(1)

        is_valid = token.verify()

        if is_valid:
            console.print(Panel(
                f"[green]✓ Token Valid[/green]\n\n"
                f"[bold]Action:[/bold] {token.action}\n"
                f"[bold]Actor:[/bold] {token.actor}\n"
                f"[bold]Created:[/bold] {token.timestamp}",
                title="Verification Result",
                border_style="green"
            ))
        else:
            console.print(Panel(
                "[red]✗ Token Invalid - Possible tampering detected[/red]",
                title="Verification Result",
                border_style="red"
            ))
            sys.exit(1)

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        sys.exit(1)


@main.command()
@click.option("--format", "-f", type=click.Choice(["json", "markdown", "summary"]), default="summary")
def export(format):
    """Export the full audit trail."""
    try:
        from tibet_core import Provider
        import json

        provider = Provider()
        data = provider.export()

        if format == "json":
            console.print(json.dumps(data, indent=2, default=str))
        elif format == "markdown":
            console.print("# TIBET Audit Trail\n")
            for token in data.get("tokens", []):
                console.print(f"## {token.get('action')}")
                console.print(f"- ID: `{token.get('id')}`")
                console.print(f"- Actor: {token.get('actor')}")
                console.print(f"- Intent: {token.get('erachter')}\n")
        else:
            tokens = data.get("tokens", [])
            console.print(Panel(
                f"[bold]Total Tokens:[/bold] {len(tokens)}\n"
                f"[bold]Actors:[/bold] {len(set(t.get('actor') for t in tokens))}\n"
                f"[bold]Actions:[/bold] {len(set(t.get('action') for t in tokens))}",
                title="TIBET Audit Summary",
                border_style="blue"
            ))

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        sys.exit(1)


@main.command()
def status():
    """Show TIBET ecosystem status."""
    console.print(BANNER, style="cyan")
    console.print("[bold]The Trust Kernel for AI[/bold]")
    console.print("[dim]Audit as a Precondition, Not an Afterthought.[/dim]\n")

    table = Table(title="Installed Components")
    table.add_column("Component", style="cyan")
    table.add_column("Version", style="green")
    table.add_column("Status")

    # Check tibet-core
    try:
        from tibet_core import __version__ as core_v
        table.add_row("tibet-core", core_v, "✅ Installed")
    except ImportError:
        table.add_row("tibet-core", "-", "❌ Not installed")

    # Check tibet-audit
    try:
        from tibet_audit import __version__ as audit_v
        table.add_row("tibet-audit", audit_v, "✅ Installed")
    except ImportError:
        table.add_row("tibet-audit", "-", "❌ pip install tibet[audit]")

    # Check tibet-forge
    try:
        from tibet_forge import __version__ as forge_v
        table.add_row("tibet-forge", forge_v, "✅ Installed")
    except ImportError:
        table.add_row("tibet-forge", "-", "❌ pip install tibet[forge]")

    # Check tibet-vault
    try:
        from tibet_vault import __version__ as vault_v
        table.add_row("tibet-vault", vault_v, "✅ Installed")
    except ImportError:
        table.add_row("tibet-vault", "-", "❌ pip install tibet[full]")

    console.print(table)
    console.print("\n[dim]One love, one fAmIly![/dim]")


@main.command()
@click.argument("path", default=".", type=click.Path())
def init(path):
    """Initialize TIBET in a project.

    Creates .tibet/ directory for local token storage.
    """
    tibet_dir = Path(path) / ".tibet"
    tibet_dir.mkdir(exist_ok=True)

    config_file = tibet_dir / "config.json"
    if not config_file.exists():
        import json
        config = {
            "version": "1.0.0",
            "actor": "local",
            "store": "file",
            "created": str(Path.cwd())
        }
        config_file.write_text(json.dumps(config, indent=2))

    console.print(Panel(
        f"[green]TIBET initialized in {path}[/green]\n\n"
        f"Created: .tibet/config.json\n\n"
        f"Next steps:\n"
        f"  tibet audit    - Scan for compliance\n"
        f"  tibet forge    - Check trust score\n"
        f"  tibet create   - Create provenance token",
        title="TIBET Init",
        border_style="green"
    ))


@main.command()
def version():
    """Show versions of all TIBET components."""
    from tibet import __version__

    versions = {"tibet": __version__}

    try:
        from tibet_core import __version__ as v
        versions["tibet-core"] = v
    except ImportError:
        pass

    try:
        from tibet_audit import __version__ as v
        versions["tibet-audit"] = v
    except ImportError:
        pass

    try:
        from tibet_forge import __version__ as v
        versions["tibet-forge"] = v
    except ImportError:
        pass

    for pkg, ver in versions.items():
        console.print(f"{pkg}: [cyan]{ver}[/cyan]")


if __name__ == "__main__":
    main()
