"""
This module provides functionality for agent-to-agent (A2A) communication.
It allows agents to send messages to each other using predefined A2A clients.
"""

from uuid import uuid4

from a2a.types import Message, Part, Role, Task, TaskState
from a2a.utils import get_text_parts
from pydantic_ai import FunctionToolset

from aixtools.a2a.google_sdk.config import DEFAULT_FUNCTION_TOOLS_MAX_RETRIES
from aixtools.a2a.google_sdk.pydantic_ai_adapter.types import (
    A2ATools,
    GetAgentCardResult,
    InvokeAgentResult,
    TaskRegistry,
)
from aixtools.a2a.google_sdk.remote_agent_connection import RemoteAgentConnection
from aixtools.context import session_id_var, user_id_var
from aixtools.utils import get_logger

logger = get_logger(__name__)


def get_a2a_tools(
    a2a_clients: dict[str, RemoteAgentConnection],
    conversation_id: str,
    task_registry: TaskRegistry | None = None,
) -> A2ATools:
    """Get the A2A tool for the agent to use.
    This tool allows the agent to communicate with other agents.

    Args:
        a2a_clients: Dictionary of A2A clients
        conversation_id: conversation ID for task tracking
        task_registry: Optional A2A task registry for tracking tasks
    """

    async def invoke_agent(
        agent_name: str,
        message_parts: list[Part],
        metadata: dict | None,
    ) -> InvokeAgentResult | None:
        """
        Send a message to the specified agent and return the response.

        if result.state returned as 'input-required' decide on your own is it possible to update request
            or ask user for additional input. Once you have input, call the same tool with the same agent_name
            and pass metadata['task_id'] to resume the task.

        Args:
            agent_name (str): The name of the agent to send the message to.
            message_parts (list[Part]): The parts of the message to send.
            metadata (dict, optional): Additional metadata for the message.
                Can include "task_id" to resume a previous task.
        Returns:
            InvokeAgentResult
        """
        if agent_name not in a2a_clients:
            return InvokeAgentResult(
                task_id="",
                state=TaskState.failed,
                artifacts=[],
                text_message=f"Agent {agent_name} not found. Next agents are available: {list(a2a_clients.keys())}",
            )
        client = a2a_clients[agent_name]

        metadata = metadata or {}
        task_id = metadata.get("task_id")
        metadata["user_id"] = user_id_var.get()
        metadata["session_id"] = session_id_var.get()
        message = Message(
            role=Role.user,
            parts=message_parts,
            message_id=str(uuid4()),
            metadata=metadata,
            task_id=task_id,
            context_id=session_id_var.get(),
        )
        # Track the actual task ID that gets used
        new_task_id = task_id

        def on_task_submitted(received_task_id: str) -> None:
            """Callback to handle task ID updates during polling."""
            nonlocal new_task_id
            new_task_id = received_task_id
            if task_registry:
                task_registry.register_task(conversation_id, received_task_id, client)

        try:
            result = await client.send_message_with_polling(
                message, sleep_time=2.0, on_task_submitted=on_task_submitted
            )
        finally:
            if task_registry:
                task_registry.unregister_task(conversation_id, new_task_id)
        if isinstance(result, Task):
            task_status = result.status
            text_message = None
            if task_status.message:
                text_message = "\n".join(get_text_parts(task_status.message.parts))
            return InvokeAgentResult(
                task_id=result.id,
                state=task_status.state,
                artifacts=result.artifacts,
                text_message=text_message,
            )

        if isinstance(result, Message):
            return InvokeAgentResult(
                task_id=task_id,
                state=TaskState.completed,
                artifacts=[],
                text_message="\n".join(get_text_parts(result.parts)),
            )

        return None

    def get_agent_card(agent_name: str) -> GetAgentCardResult:
        """
        Get the agent card for the specified agent name.

        Args:
            agent_name (str): The name of the agent to send the message to.
        Returns:
            GetAgentCardResult
        """

        if agent_name not in a2a_clients:
            return GetAgentCardResult(
                is_error=True,
                agent_card=None,
                error=f"Agent {agent_name} not found. Next agents are available: {list(a2a_clients.keys())}",
            )
        client = a2a_clients[agent_name]
        return GetAgentCardResult(is_error=False, agent_card=client.get_agent_card())

    return A2ATools(
        invoke_agent=invoke_agent,
        get_agent_card=get_agent_card,
    )


def get_a2a_toolset(
    a2a_clients: dict[str, RemoteAgentConnection],
    conversation_id: str,
    task_registry: TaskRegistry | None = None,
    max_retries: int = DEFAULT_FUNCTION_TOOLS_MAX_RETRIES,
) -> FunctionToolset:
    """Get the A2A toolset for the agent to use.
    This toolset allows the agent to communicate with other agents.

    Args:
        a2a_clients: Dictionary of A2A clients
        conversation_id: conversation ID for task tracking
        task_registry: Optional A2A task registry for tracking tasks
        max_retries: Maximum number of retries for a2a tools
    """
    a2a_tools = get_a2a_tools(
        a2a_clients=a2a_clients,
        conversation_id=conversation_id,
        task_registry=task_registry,
    )
    return FunctionToolset(tools=list(a2a_tools.values()), max_retries=max_retries)
