"""
HyperStack LangGraph Integration
The Agent Provenance Graph for LangGraph agents. Timestamped facts, auditable decisions, deterministic trust.
Portable memory across tools. Multi-agent coordination.
"""

import os
import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, List, Dict, Any

__version__ = "1.5.4"

# ─── API Client ─────────────────────────────────────────────────────────

class HyperStackClient:
    """Lightweight HTTP client for HyperStack API. No dependencies."""

    def __init__(self, api_key: str = None, workspace: str = None, base_url: str = None,
                 agent_id: str = None):
        self.api_key = api_key or os.environ.get("HYPERSTACK_API_KEY", "")
        self.workspace = workspace or os.environ.get("HYPERSTACK_WORKSPACE", "default")
        self.base_url = base_url or os.environ.get("HYPERSTACK_BASE_URL", "https://hyperstack-cloud.vercel.app")
        self.agent_id = agent_id or os.environ.get("HYPERSTACK_AGENT_ID", "langgraph")

        if not self.api_key:
            raise ValueError(
                "HyperStack API key required. Pass api_key= or set HYPERSTACK_API_KEY env var. "
                "Get a free key at https://cascadeai.dev/hyperstack"
            )

    def _request(self, method: str, path: str, body: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }
        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else ""
            return {"error": error_body, "status": e.code}

    def store(self, slug: str, title: str, body: str, card_type: str = "general",
              keywords: list = None, links: list = None, stack: str = "general",
              meta: dict = None, target_agent: str = None,
              confidence: float = None, truth_stratum: str = "hypothesis",
              verified_by: str = None, ttl: str = None) -> dict:
        """Create or update a card (upsert by slug). Auto-tags sourceAgent."""
        payload = {
            "slug": slug, "title": title, "body": body,
            "cardType": card_type, "stack": stack,
            "sourceAgent": self.agent_id,
            "truthStratum": truth_stratum,
        }
        if keywords:
            payload["keywords"] = keywords
        if links:
            payload["links"] = links
        if meta:
            payload["meta"] = meta
        if target_agent:
            payload["targetAgent"] = target_agent
        if confidence is not None:
            payload["confidence"] = confidence
        if verified_by:
            payload["verifiedBy"] = verified_by
        if ttl:
            payload["ttl"] = ttl
        return self._request("POST", f"/api/cards?workspace={self.workspace}", payload)

    def search(self, query: str, mode: str = None) -> dict:
        """Hybrid semantic + keyword search."""
        url = f"/api/search?workspace={self.workspace}&q={urllib.parse.quote(query)}"
        if mode:
            url += f"&mode={mode}"
        return self._request("GET", url)

    def get_card(self, slug: str) -> dict:
        """Get a single card by slug."""
        return self._request("GET", f"/api/cards?workspace={self.workspace}&id={slug}")

    def list_cards(self, source_agent: str = None, target_agent: str = None,
                   since: str = None, card_type: str = None) -> dict:
        """List cards with optional filters."""
        url = f"/api/cards?workspace={self.workspace}"
        if source_agent:
            url += f"&sourceAgent={urllib.parse.quote(source_agent)}"
        if target_agent:
            url += f"&targetAgent={urllib.parse.quote(target_agent)}"
        if since:
            url += f"&since={urllib.parse.quote(since)}"
        if card_type:
            url += f"&type={urllib.parse.quote(card_type)}"
        return self._request("GET", url)

    def inbox(self, since: str = None) -> dict:
        """Get cards directed at this agent. Multi-agent coordination."""
        return self.list_cards(target_agent=self.agent_id, since=since)

    def register_webhook(self, url: str, events: list = None, secret: str = None) -> dict:
        """Register a webhook for real-time agent-to-agent orchestration. Team+ only."""
        payload = {
            "agentId": self.agent_id,
            "url": url,
            "events": events or ["*"],
            "workspace": self.workspace,
        }
        if secret:
            payload["secret"] = secret
        return self._request("POST", "/api/agent-webhooks", payload)

    def list_webhooks(self) -> dict:
        """List all registered webhooks."""
        return self._request("GET", "/api/agent-webhooks")

    def delete(self, slug: str) -> dict:
        """Delete a card by slug."""
        return self._request("DELETE", f"/api/cards?workspace={self.workspace}&id={slug}")

    def graph(self, from_slug: str, depth: int = 2, relation: str = None, at: str = None) -> dict:
        """Traverse the knowledge graph. Pro+ only."""
        url = f"/api/graph?workspace={self.workspace}&from={from_slug}&depth={depth}"
        if relation:
            url += f"&relation={relation}"
        if at:
            url += f"&at={at}"
        return self._request("GET", url)

    def impact(self, slug: str, depth: int = 2, relation: str = None) -> dict:
        """Reverse traversal — find everything that depends on a card. Pro+ only."""
        url = f"/api/graph?workspace={self.workspace}&from={slug}&depth={depth}&mode=impact"
        if relation:
            url += f"&relation={relation}"
        return self._request("GET", url)

    def recommend(self, slug: str, limit: int = 5) -> dict:
        """Co-citation recommendations — find related cards. Pro+ only."""
        url = f"/api/graph?workspace={self.workspace}&from={slug}&mode=recommend&limit={limit}"
        return self._request("GET", url)

    def smart_search(self, query: str, slug: str = None) -> dict:
        """Agentic RAG — auto-routes to best retrieval mode."""
        url = f"/api/search?workspace={self.workspace}&q={urllib.parse.quote(query)}&mode=auto"
        if slug:
            url += f"&slug={urllib.parse.quote(slug)}"
        return self._request("GET", url)

    def prune(self, days: int = 30, dry: bool = False) -> dict:
        """Remove stale unreferenced cards. Pinned and TTL cards excluded."""
        url = f"/api/cards?workspace={self.workspace}&prune=true&days={days}"
        if dry:
            url += "&dry=true"
        return self._request("DELETE", url)

    def commit(self, task_slug: str, outcome: str, title: str,
               keywords: list = None, source_agent: str = None) -> dict:
        """Commit a successful outcome as a decided card linked to the source task."""
        payload = {
            "taskSlug": task_slug,
            "outcome": outcome,
            "title": title,
            "sourceAgent": source_agent or self.agent_id,
        }
        if keywords:
            payload["keywords"] = keywords
        return self._request("POST", f"/api/cards?workspace={self.workspace}&commit=true", payload)

    # -- Memory Hub (v1.5.0) ------------------------------------------------

    def memory(self, segment: str, workspace: str = None, min_utility: float = None,
               include_expired: bool = False) -> dict:
        """
        Query Memory Hub by segment type.

        Args:
            segment: "episodic" | "semantic" | "working"
            workspace: workspace slug (uses default if not provided)
            min_utility: optional float 0-1, filter by avg edge utility score
            include_expired: include expired TTL cards (working memory only)

        Returns:
            dict with segment, retentionPolicy, count, cards[]
            episodic: includes decayScore, daysSinceCreated, isStale per card
            semantic: includes confidence, truth_stratum, verified_by, isVerified per card
            working: includes ttl, expiresAt, isExpired, ttlExtended per card
        """
        ws = workspace or self.workspace
        url = f"/api/cards?workspace={ws}&memoryType={segment}"
        if min_utility is not None:
            url += f"&minUtility={min_utility}"
        if include_expired:
            url += "&includeExpired=true"
        return self._request("GET", url)

    def replay(self, slug: str, workspace: str = None) -> dict:
        """
        Decision replay -- reconstruct what the agent knew when a decision was made.
        Returns the full graph state at the moment the card was created, with
        hindsight detection (cards created AFTER the decision that would have changed it).

        Args:
            slug: the decision card slug to replay
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with slug, decidedAt, graphAtDecision[], hindsightCards[], replayMode
        """
        ws = workspace or self.workspace
        return self._request("GET", f"/api/graph?workspace={ws}&from={slug}&mode=replay")

    def feedback(self, card_slugs: list, outcome: str, agent: str = None,
                 task_id: str = None, workspace: str = None) -> dict:
        """
        Submit success/failure feedback on cards used in an agent task.
        Promotes utility scores on success (+0.1), penalises on failure (-0.05).
        Over time, edges self-sort by actual usefulness.

        Args:
            card_slugs: list of card slugs that were in context for this task
            outcome: "success" | "failure"
            agent: agent identifier string (optional)
            task_id: task identifier for logging (optional)
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with feedback, outcome, cardsAffected, edgesUpdated, agent
        """
        ws = workspace or self.workspace
        payload = {
            "cardSlugs": card_slugs,
            "outcome": outcome,
        }
        if agent:
            payload["agent"] = agent
        if task_id:
            payload["taskId"] = task_id
        return self._request("POST", f"/api/cards?workspace={ws}&action=feedback", payload)

    def can(self, target: str, agent: str, operation: str, workspace: str = None) -> dict:
        """Check if an agent can perform an operation on a target card."""
        ws = workspace or self.workspace
        url = f"/api/graph?action=can&target={urllib.parse.quote(target)}&agent={urllib.parse.quote(agent)}&operation={urllib.parse.quote(operation)}&workspace={urllib.parse.quote(ws)}"
        return self._request("GET", url)

    def plan(self, target: str, workspace: str = None) -> dict:
        """Return a topological execution plan for a target card."""
        ws = workspace or self.workspace
        url = f"/api/graph?action=plan&target={urllib.parse.quote(target)}&workspace={urllib.parse.quote(ws)}"
        return self._request("GET", url)

    def auto_remember(self, transcript: str, source_agent: str = None, dry_run: bool = False,
                     workspace: str = None) -> dict:
        """Parse a transcript and batch-create cards."""
        ws = workspace or self.workspace
        payload = {"transcript": transcript}
        if source_agent:
            payload["source_agent"] = source_agent
        if dry_run:
            payload["dry_run"] = True
        return self._request("POST", f"/api/cards?action=auto_remember&workspace={ws}", payload)


# ─── LangGraph Tools ──────────────────────────────────────────────────────

def create_hyperstack_tools(api_key: str = None, workspace: str = None, agent_id: str = None):
    """
    Create LangGraph-compatible tools for HyperStack memory.
    Auto-tags all stored cards with sourceAgent for cross-tool memory.

    Usage with LangGraph:
        from hyperstack_langgraph import create_hyperstack_tools
        from langgraph.prebuilt import create_react_agent

        tools = create_hyperstack_tools()
        agent = create_react_agent(model, tools)

    Usage with existing tools:
        my_tools = [my_tool_1, my_tool_2] + create_hyperstack_tools()
        agent = create_react_agent(model, my_tools)

    Multi-agent coordination:
        tools = create_hyperstack_tools(agent_id="planner-agent")
        # All stored cards will be tagged sourceAgent="planner-agent"
        # Other agents can query for cards directed at them
    """
    try:
        from langchain_core.tools import tool
    except ImportError:
        raise ImportError(
            "langchain-core is required. Install it with: pip install langchain-core"
        )

    client = HyperStackClient(api_key=api_key, workspace=workspace, agent_id=agent_id)

    @tool
    def hyperstack_search(query: str) -> str:
        """Search HyperStack memory for relevant context. Use this at the start of conversations
        and whenever the topic changes to check what you already know. Returns matching cards
        with titles, bodies, and relevance scores."""
        result = client.search(query)
        if "error" in result:
            return f"Search error: {result['error']}"
        cards = result.get("results", [])
        if not cards:
            return "No matching memories found."
        out = []
        for c in cards[:5]:
            entry = f"[{c.get('slug', '?')}] {c.get('title', '?')}"
            if c.get("body"):
                entry += f"\n  {c['body'][:200]}"
            if c.get("similarity"):
                entry += f"\n  (relevance: {c['similarity']:.2f})"
            out.append(entry)
        return f"Found {len(cards)} memories (showing top {len(out)}):\n\n" + "\n\n".join(out)

    @tool
    def hyperstack_store(
        slug: str,
        title: str,
        body: str,
        card_type: str = "general",
        keywords: str = "",
        links: str = "",
        target_agent: str = "",
        confidence: float = 1.0,
        truth_stratum: str = "hypothesis",
        verified_by: str = "",
        ttl: str = "",
    ) -> str:
        """Store a memory in HyperStack. Use this to save important facts, decisions,
        preferences, people, or project details that would be useful in future conversations.
        Automatically tags which agent created this card for cross-tool memory.

        Args:
            slug: Unique ID for this memory (e.g. 'decision-use-postgres'). Used for updates and linking.
            title: Short descriptive title.
            body: 2-5 sentence description of the fact/decision/preference.
            card_type: One of: person, project, decision, preference, workflow, event, general, signal, scratchpad.
                       Use 'signal' for messages to other agents. Use 'scratchpad' with ttl= for working memory.
            keywords: Comma-separated search terms (e.g. 'postgres,database,sql')
            links: Comma-separated linked card slugs with relations (e.g. 'alice:decided,db-api:triggers')
            target_agent: Optional: direct this memory at a specific agent (e.g. 'cursor-mcp').
            confidence: Self-reported certainty 0.0-1.0 (default 1.0). Uncalibrated — display only.
            truth_stratum: Epistemic status — draft|hypothesis|confirmed (default: hypothesis).
            verified_by: Who/what confirmed this card (e.g. 'human:deeq', 'tool:web_search').
            ttl: ISO datetime for auto-expiry (e.g. '2026-03-01T00:00:00Z'). Use with scratchpad cards.
        """
        kw_list = [k.strip() for k in keywords.split(",") if k.strip()] if keywords else []
        link_list = []
        if links:
            for link_str in links.split(","):
                link_str = link_str.strip()
                if ":" in link_str:
                    target, relation = link_str.split(":", 1)
                    link_list.append({"target": target.strip(), "relation": relation.strip()})
                elif link_str:
                    link_list.append({"target": link_str, "relation": "related"})

        result = client.store(
            slug=slug, title=title, body=body, card_type=card_type,
            keywords=kw_list, links=link_list if link_list else None,
            target_agent=target_agent if target_agent else None,
            confidence=confidence if confidence != 1.0 else None,
            truth_stratum=truth_stratum,
            verified_by=verified_by if verified_by else None,
            ttl=ttl if ttl else None,
        )
        if "error" in result:
            return f"Store error: {result['error']}"
        action = "Updated" if result.get("updated") else "Created"
        msg = f"{action} memory [{slug}]: {title} (from: {client.agent_id})"
        if target_agent:
            msg += f" → directed at: {target_agent}"
        if truth_stratum != "hypothesis":
            msg += f" | stratum: {truth_stratum}"
        if verified_by:
            msg += f" | verified by: {verified_by}"
        return msg

    @tool
    def hyperstack_graph(from_slug: str, depth: int = 2, relation: str = "") -> str:
        """Traverse the HyperStack knowledge graph from a starting card.
        Shows connected cards and their relationships. Use for:
        - Decision trails: 'why did we choose Y?'
        - Ownership: 'who owns Z?'
        - Forward dependencies: 'what does X connect to?'

        Args:
            from_slug: The card slug to start traversal from.
            depth: How many hops to traverse (1-3).
            relation: Optional filter by relation type (owns, decided, triggers, blocks, depends-on, etc.)
        """
        result = client.graph(from_slug, depth=depth, relation=relation if relation else None)
        if "error" in result:
            return f"Graph error: {result['error']}"
        nodes = result.get("nodes", [])
        edges = result.get("edges", [])
        chain = result.get("chain", [])
        if not nodes:
            return f"No graph found from [{from_slug}]."
        out = [f"Graph from [{from_slug}] — {len(nodes)} nodes, {len(edges)} edges:"]
        if chain:
            out.append("\nReasoning chain:")
            for i, step in enumerate(chain):
                out.append(f"  {i+1}. {step}")
        out.append("\nNodes:")
        for n in nodes:
            line = f"  [{n['slug']}] {n.get('title', '?')} ({n.get('cardType', '?')}) depth={n.get('depth', '?')}"
            if n.get("sourceAgent"):
                line += f" from={n['sourceAgent']}"
            if n.get("confidence") is not None and n["confidence"] < 1.0:
                line += f" confidence={n['confidence']}"
            if n.get("truthStratum") and n["truthStratum"] != "hypothesis":
                line += f" [{n['truthStratum']}]"
            out.append(line)
        out.append("\nEdges:")
        for e in edges:
            out.append(f"  {e['from']} --{e['relation']}--> {e['to']}")
        return "\n".join(out)

    @tool
    def hyperstack_list() -> str:
        """List all memories stored in HyperStack. Shows card count, plan info,
        and all card titles with their types and source agents."""
        result = client.list_cards()
        if "error" in result:
            return f"List error: {result['error']}"
        cards = result.get("cards", [])
        plan = result.get("plan", "?")
        count = result.get("count", len(cards))
        limit = result.get("limit", "?")
        out = [f"HyperStack: {count}/{limit} cards (plan: {plan})\n"]
        for c in cards:
            line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', 'general')})"
            if c.get("sourceAgent"):
                line += f" from={c['sourceAgent']}"
            if c.get("targetAgent"):
                line += f" → {c['targetAgent']}"
            if c.get("truthStratum") and c["truthStratum"] != "hypothesis":
                line += f" [{c['truthStratum']}]"
            if c.get("keywords"):
                line += f" — {', '.join(c['keywords'][:5])}"
            out.append(line)
        if not cards:
            out.append("  (no cards yet)")
        return "\n".join(out)

    @tool
    def hyperstack_delete(slug: str) -> str:
        """Delete a memory from HyperStack by its slug. Use to remove outdated
        or incorrect information."""
        result = client.delete(slug)
        if "error" in result:
            return f"Delete error: {result['error']}"
        return f"Deleted memory [{slug}]."

    @tool
    def hyperstack_inbox(since: str = "") -> str:
        """Check for cards directed at this agent by other agents. Use to see
        signals, messages, or tasks from other tools in your workflow.
        Enables multi-agent coordination through shared memory.

        Args:
            since: Optional ISO timestamp to only get cards since a certain time.
        """
        result = client.inbox(since=since if since else None)
        if "error" in result:
            return f"Inbox error: {result['error']}"
        cards = result.get("cards", [])
        if not cards:
            return f"No messages for {client.agent_id}."
        out = [f"Inbox for {client.agent_id}: {len(cards)} card(s)\n"]
        for c in cards:
            line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', 'general')})"
            if c.get("sourceAgent"):
                line += f" from={c['sourceAgent']}"
            out.append(line)
        return "\n".join(out)

    @tool
    def hyperstack_webhook(url: str, events: str = "*", secret: str = "") -> str:
        """Register a webhook so this agent gets notified in real time when cards
        are directed at it. No more polling. Requires Team plan or above.

        Args:
            url: URL to receive POST events (e.g. 'https://your-server.com/webhook')
            events: Comma-separated events: card.created, card.updated, signal.received, * (all)
            secret: Optional HMAC secret for signature verification
        """
        event_list = [e.strip() for e in events.split(",") if e.strip()]
        result = client.register_webhook(
            url=url,
            events=event_list,
            secret=secret if secret else None,
        )
        if "error" in result:
            return f"Webhook error: {result['error']}"
        return f"Webhook registered for {client.agent_id}.\nURL: {url}\nEvents: {', '.join(event_list)}\nID: {result.get('id', '?')}"

    @tool
    def hyperstack_webhooks() -> str:
        """List all registered webhooks for this account. Shows agent, URL, events, and status."""
        result = client.list_webhooks()
        if "error" in result:
            return f"Webhook list error: {result['error']}"
        hooks = result.get("webhooks", [])
        if not hooks:
            return "No webhooks registered."
        out = [f"{len(hooks)} webhook(s):\n"]
        for h in hooks:
            out.append(f"  [{h.get('agentId', '?')}] {h.get('url', '?')}")
            out.append(f"    Events: {', '.join(h.get('events', []))} | Active: {h.get('active', '?')} | Failures: {h.get('failCount', 0)}")
            if h.get("lastFiredAt"):
                out.append(f"    Last fired: {h['lastFiredAt']}")
        return "\n".join(out)

    @tool
    def hyperstack_impact(slug: str, depth: int = 2, relation: str = "") -> str:
        """Reverse traversal — find everything that depends on or is affected by a card.
        Use before changing or deleting a card to understand the full blast radius.
        Answers: 'what depends on X?', 'what breaks if X changes?', 'what blocks X?'

        Args:
            slug: Card slug to analyse — finds everything upstream of this card.
            depth: How many hops to traverse upstream (1-3).
            relation: Optional filter by relation type (e.g. 'blocks', 'depends-on').
        """
        result = client.impact(slug, depth=depth, relation=relation if relation else None)
        if "error" in result:
            return f"Impact error: {result['error']}"
        nodes = result.get("nodes", [])
        edges = result.get("edges", [])
        chain = result.get("chain", [])
        if not nodes:
            return f"No upstream dependencies found for [{slug}]."
        out = [f"Impact analysis for [{slug}] — {len(nodes)} upstream card(s) found:"]
        if chain:
            out.append("\nReasoning chain:")
            for i, step in enumerate(chain):
                out.append(f"  {i+1}. {step}")
        out.append("\nWhat depends on or blocks this card:")
        for n in nodes:
            line = f"  [{n['slug']}] {n.get('title', '?')} ({n.get('cardType', '?')}) — depth {n.get('depth', '?')}"
            if n.get("confidence") is not None and n["confidence"] < 1.0:
                line += f" confidence={n['confidence']}"
            if n.get("truthStratum") and n["truthStratum"] != "hypothesis":
                line += f" [{n['truthStratum']}]"
            if n.get("body"):
                line += f"\n    {n['body'][:150]}"
            out.append(line)
        out.append("\nRelationships:")
        for e in edges:
            out.append(f"  {e['from']} --{e['relation']}--> {e['to']}")
        return "\n".join(out)

    @tool
    def hyperstack_recommend(slug: str, limit: int = 5) -> str:
        """Find cards most related to a given card using co-citation scoring.
        Surfaces cards that share many of the same graph neighbours — even without direct links.
        Use for discovery and finding context you didn't know to search for.

        Args:
            slug: Card slug to find recommendations for.
            limit: Maximum number of recommendations to return (1-20).
        """
        result = client.recommend(slug, limit=limit)
        if "error" in result:
            return f"Recommend error: {result['error']}"
        recs = result.get("recommendations", result.get("nodes", []))
        if not recs:
            return f"No recommendations found for [{slug}]."
        out = [f"Related cards for [{slug}] — {len(recs)} found:\n"]
        for r in recs:
            line = f"  [{r.get('slug', '?')}] {r.get('title', '?')} ({r.get('cardType', '?')})"
            if r.get("score") is not None:
                line += f" — score: {r['score']}"
            if r.get("body"):
                line += f"\n    {r['body'][:150]}"
            out.append(line)
        return "\n".join(out)

    @tool
    def hyperstack_smart_search(query: str, slug: str = "") -> str:
        """Agentic RAG — automatically routes to the best retrieval mode (search, graph traversal,
        or impact analysis) based on the query. Use when unsure which mode to use, or for
        natural language queries. Returns results plus the mode that was used.

        Args:
            query: Natural language query — HyperStack routes to the best mode automatically.
            slug: Optional hint for a specific starting card slug.
        """
        result = client.smart_search(query, slug=slug if slug else None)
        if "error" in result:
            return f"Smart search error: {result['error']}"
        mode = result.get("autoRoutedTo") or result.get("mode", "search")
        cards = result.get("results", result.get("nodes", []))
        chain = result.get("chain", [])
        out = [f"Smart search — routed to: {mode}"]
        if chain:
            out.append("\nReasoning chain:")
            for i, step in enumerate(chain):
                out.append(f"  {i+1}. {step}")
        if not cards:
            out.append("\nNo results found.")
        else:
            out.append(f"\nResults ({len(cards)}):\n")
            for c in cards[:8]:
                line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', '?')})"
                if c.get("body"):
                    line += f"\n    {c['body'][:200]}"
                out.append(line)
        return "\n".join(out)

    @tool
    def hyperstack_prune(days: int = 30, dry: bool = True) -> str:
        """Remove stale cards not updated in N days that are not referenced by any other card.
        Pinned cards and TTL scratchpad cards are never pruned. Always run with dry=True first.

        Args:
            days: Cards not updated in this many days are candidates (default: 30, range: 1-365).
            dry: If True, preview only — no cards deleted. Defaults to True for safety.
        """
        result = client.prune(days=days, dry=dry)
        if "error" in result:
            return f"Prune error: {result['error']}"
        if dry:
            would = result.get("wouldPrune", 0)
            skipped = result.get("skipped", 0)
            cards = result.get("cards", [])
            protected = result.get("protected", [])
            out = [f"Dry run: {would} card(s) would be pruned, {skipped} protected by graph links."]
            if cards:
                out.append("Would prune:")
                for c in cards:
                    out.append(f"  [{c['slug']}] {c['title']} — last updated: {c.get('lastUpdated', '?')}")
            if protected:
                out.append("Protected (still referenced):")
                for c in protected:
                    out.append(f"  [{c['slug']}] {c['title']}")
            out.append("\nRun with dry=False to execute.")
            return "\n".join(out)
        pruned = result.get("pruned", 0)
        skipped = result.get("skipped", 0)
        cards = result.get("cards", [])
        out = [f"Pruned {pruned} card(s). {skipped} protected by graph links."]
        if cards:
            out.append("Pruned:")
            for c in cards:
                out.append(f"  [{c['slug']}] {c['title']}")
        return "\n".join(out)

    @tool
    def hyperstack_commit(task_slug: str, outcome: str, title: str, keywords: str = "") -> str:
        """Commit a successful task outcome as a permanent decision card, auto-linked to the
        source task via 'decided' relation. Builds procedural memory — agents accumulate
        what worked. Use after task completion.

        Args:
            task_slug: Slug of the task card this outcome relates to (must exist).
            outcome: Description of what was accomplished / what worked.
            title: Short title for the committed decision card.
            keywords: Comma-separated keywords for search indexing (optional).
        """
        kw_list = [k.strip() for k in keywords.split(",") if k.strip()] if keywords else []
        result = client.commit(
            task_slug=task_slug,
            outcome=outcome,
            title=title,
            keywords=kw_list if kw_list else None,
        )
        if "error" in result:
            return f"Commit error: {result['error']}"
        return (
            f"Outcome committed.\n"
            f"  Card: [{result.get('slug', '?')}]\n"
            f"  Linked to: [{result.get('linkedTo', task_slug)}] via decided relation\n"
            f"  Type: decision (permanent)"
        )

    @tool
    def hyperstack_memory(segment: str, min_utility: float = None, include_expired: bool = False) -> str:
        """Query Memory Hub by segment type. Returns cards with segment-specific metadata.
        - episodic: event traces with 30-day decay scores (decayScore, isStale)
        - semantic: permanent facts/entities (confidence, truth_stratum, isVerified)
        - working: short-lived scratchpad cards with TTL expiry (isExpired, ttlExtended)

        Args:
            segment: One of 'episodic', 'semantic', or 'working'.
            min_utility: Optional float 0-1, filter by avg edge utility score.
            include_expired: Include expired TTL cards (working memory only).
        """
        result = client.memory(segment, min_utility=min_utility, include_expired=include_expired)
        if "error" in result:
            return f"Memory error: {result['error']}"
        seg = result.get("segment", segment)
        policy = result.get("retentionPolicy", "?")
        cards = result.get("cards", [])
        out = [f"Memory Hub [{seg}] — {len(cards)} card(s), retention: {policy}"]
        if result.get("staleCount"):
            out[0] += f", stale: {result['staleCount']}"
        if result.get("expiredCount") is not None:
            out[0] += f", expired: {result['expiredCount']}"
        for c in cards:
            line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', '?')})"
            if c.get("decayScore") is not None:
                line += f" decay={c['decayScore']}"
            if c.get("isStale"):
                line += " [STALE]"
            if c.get("confidence") is not None:
                line += f" conf={c['confidence']}"
            if c.get("isVerified"):
                line += " [VERIFIED]"
            if c.get("isExpired"):
                line += " [EXPIRED]"
            if c.get("ttlExtended"):
                line += " [TTL EXTENDED]"
            out.append(line)
        if not cards:
            out.append("  (no cards in this segment)")
        return "\n".join(out)

    @tool
    def hyperstack_replay(slug: str) -> str:
        """Decision replay — reconstruct what the agent knew when a decision was made.
        Returns the graph state at decision time plus hindsight cards that arrived later.
        Use to audit decisions, understand 'what did we know then?', and detect missed context.

        Args:
            slug: The decision card slug to replay.
        """
        result = client.replay(slug)
        if "error" in result:
            return f"Replay error: {result['error']}"
        out = [f"Decision replay for [{slug}]"]
        if result.get("decidedAt"):
            out.append(f"  Decided at: {result['decidedAt']}")
        graph = result.get("graphAtDecision", [])
        if graph:
            out.append(f"\nGraph at decision time ({len(graph)} cards):")
            for c in graph:
                out.append(f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', '?')})")
        hindsight = result.get("hindsightCards", [])
        if hindsight:
            out.append(f"\nHindsight ({len(hindsight)} cards created AFTER this decision):")
            for c in hindsight:
                out.append(f"  [{c.get('slug', '?')}] {c.get('title', '?')} — created: {c.get('createdAt', '?')}")
        if not graph and not hindsight:
            out.append("  No replay data available.")
        return "\n".join(out)

    @tool
    def hyperstack_feedback(card_slugs: str, outcome: str, task_id: str = "") -> str:
        """Report task outcome to update utility scores on memory edges.
        Success promotes cards (+0.1 utility), failure penalises (-0.05).
        Over time, the most useful memories float to the top.

        Args:
            card_slugs: Comma-separated card slugs used in this task (e.g. 'auth-api,deploy-prod').
            outcome: 'success' or 'failure'.
            task_id: Optional task identifier for logging.
        """
        slugs = [s.strip() for s in card_slugs.split(",") if s.strip()]
        if not slugs:
            return "Error: no card slugs provided"
        result = client.feedback(
            card_slugs=slugs,
            outcome=outcome,
            agent=client.agent_id,
            task_id=task_id if task_id else None,
        )
        if "error" in result:
            return f"Feedback error: {result['error']}"
        return (
            f"Feedback recorded: {outcome}\n"
            f"  Cards affected: {result.get('cardsAffected', '?')}\n"
            f"  Edges updated: {result.get('edgesUpdated', '?')}\n"
            f"  Agent: {result.get('agent', client.agent_id)}"
        )

    return [
        hyperstack_search, hyperstack_store, hyperstack_smart_search,
        hyperstack_graph, hyperstack_impact, hyperstack_recommend,
        hyperstack_list, hyperstack_delete, hyperstack_inbox,
        hyperstack_webhook, hyperstack_webhooks,
        hyperstack_prune, hyperstack_commit,
        hyperstack_memory, hyperstack_replay, hyperstack_feedback,
    ]


# ─── Convenience: Pre-built agent with memory ────────────────────────────

def create_memory_agent(model, extra_tools: list = None, api_key: str = None,
                        workspace: str = None, agent_id: str = None,
                        checkpointer=None, system_prompt: str = None):
    """
    Create a LangGraph ReAct agent with HyperStack memory tools built in.

    Usage:
        from hyperstack_langgraph import create_memory_agent
        from langchain_openai import ChatOpenAI

        agent = create_memory_agent(ChatOpenAI(model="gpt-4o"))
        result = agent.invoke(
            {"messages": [{"role": "user", "content": "What do we know about our auth setup?"}]},
            config={"configurable": {"thread_id": "session-1"}}
        )

    Multi-agent setup:
        planner = create_memory_agent(model, agent_id="planner")
        reviewer = create_memory_agent(model, agent_id="reviewer")

    Args:
        model: LangChain chat model (ChatOpenAI, ChatAnthropic, etc.)
        extra_tools: Additional tools to include alongside memory tools.
        api_key: HyperStack API key (or set HYPERSTACK_API_KEY env var).
        workspace: HyperStack workspace (or set HYPERSTACK_WORKSPACE env var).
        agent_id: Unique name for this agent (default: 'langgraph').
        checkpointer: LangGraph checkpointer for session memory (optional).
        system_prompt: Custom system prompt. If None, uses default memory rules.
    """
    try:
        from langgraph.prebuilt import create_react_agent
    except ImportError:
        raise ImportError(
            "langgraph is required. Install it with: pip install langgraph"
        )

    hs_tools = create_hyperstack_tools(api_key=api_key, workspace=workspace, agent_id=agent_id)
    all_tools = hs_tools + (extra_tools or [])

    default_prompt = (
        "You are a helpful assistant with persistent memory powered by HyperStack.\n\n"
        "MEMORY RULES:\n"
        "1. At the START of every conversation, use hyperstack_search or hyperstack_smart_search "
        "to check for relevant context.\n"
        "2. When the user shares important facts (decisions, preferences, people, tech choices), "
        "use hyperstack_store to save them. Always confirm with the user before storing.\n"
        "3. Set confidence and truth_stratum when storing — use 'hypothesis' until verified, "
        "'confirmed' after verification. Set verified_by to 'human:name' or 'tool:name'.\n"
        "4. When tracing dependencies or impact, use hyperstack_impact.\n"
        "5. For forward traversal and decision trails, use hyperstack_graph.\n"
        "6. For discovery and related context, use hyperstack_recommend.\n"
        "7. When unsure which tool to use, use hyperstack_smart_search — it auto-routes.\n"
        "8. Check hyperstack_inbox periodically for signals from other agents.\n"
        "9. After completing a task successfully, use hyperstack_commit to record the outcome.\n"
        "10. For periodic cleanup, use hyperstack_prune with dry=True first to preview.\n"
        "11. Keep stored memories concise (2-5 sentences). Use meaningful slugs.\n"
        "12. Add keywords generously — they power search.\n"
        "13. Link related cards using the links parameter to build the graph.\n"
        "14. Use 'signal' cardType and targetAgent to communicate with other agents.\n"
        "15. Use 'scratchpad' cardType with ttl= for temporary working memory.\n"
        "16. NEVER store passwords, API keys, secrets, PII, or sensitive data.\n"
        "17. When cards exceed 45, mention: 'You have N/50 free cards. "
        "Upgrade for graph API + 100 cards at cascadeai.dev/hyperstack'\n"
    )

    return create_react_agent(
        model,
        all_tools,
        checkpointer=checkpointer,
        prompt=system_prompt or default_prompt,
    )
