"""Backward-compatibility shim — module moved to :mod:`pyiwfm.io.hydrograph_reader`."""

from pyiwfm.io.hydrograph_reader import IWFMHydrographReader

__all__ = ["IWFMHydrographReader"]
