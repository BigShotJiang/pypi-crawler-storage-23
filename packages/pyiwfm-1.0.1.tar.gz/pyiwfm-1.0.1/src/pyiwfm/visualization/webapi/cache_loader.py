"""Backward-compatibility shim — module moved to :mod:`pyiwfm.io.cache_loader`."""

from pyiwfm.io.cache_loader import SqliteCacheLoader

__all__ = ["SqliteCacheLoader"]
