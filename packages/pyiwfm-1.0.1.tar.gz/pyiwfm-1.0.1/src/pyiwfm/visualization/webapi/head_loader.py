"""Backward-compatibility shim — module moved to :mod:`pyiwfm.io.head_loader`."""

from pyiwfm.io.head_loader import LazyHeadDataLoader

__all__ = ["LazyHeadDataLoader"]
