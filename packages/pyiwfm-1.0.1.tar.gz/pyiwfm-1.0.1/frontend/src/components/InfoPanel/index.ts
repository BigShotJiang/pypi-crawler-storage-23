export { default as InfoPanel } from './InfoPanel';
