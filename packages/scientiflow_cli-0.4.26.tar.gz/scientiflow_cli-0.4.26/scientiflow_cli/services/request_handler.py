import requests
from scientiflow_cli.utils.config import get_app_base_url
from scientiflow_cli.cli.auth_utils import getAuthToken


def handle_response(response, error_message):
    return response 

def make_auth_request(endpoint, method, data=None, params=None, error_message=None):
    headers = {'Authorization': f'Bearer {getAuthToken()}'}
    base_url = get_app_base_url()

    try:
        if method == 'GET':
            response = requests.get(base_url + endpoint, headers=headers, params=params)
        elif method == 'POST':
            response = requests.post(base_url + endpoint, json=data, headers=headers)
        else:
            raise ValueError("Unsupported HTTP method")

        return handle_response(response, error_message)

    except requests.RequestException as e:
        return "Request failed"


def make_no_auth_request(endpoint, method, data=None, error_message=None):
    base_url = get_app_base_url()

    try:
        if method == 'GET':
            response = requests.get(base_url + endpoint)
        elif method == 'POST':
            response = requests.post(base_url + endpoint, json=data)
        else:
            raise ValueError("Unsupported HTTP method")

        return handle_response(response, error_message)

    except requests.RequestException as e:
        return "Request failed"
