from pathlib import Path
from scientiflow_cli.services.rich_printer import RichPrinter
import os

printer = RichPrinter()

# Use ~/.scientiflow/mode for mode configuration (plain text file)
MODE_FILE = os.path.expanduser("~/.scientiflow/mode")
MODE_DIR = os.path.dirname(MODE_FILE)

def set_mode(mode: str):
    mode = mode.lower()
    if mode not in {"dev", "prod"}:
        raise ValueError("Mode must be either 'dev' or 'prod'")

    # Ensure directory exists
    os.makedirs(MODE_DIR, exist_ok=True)

    # Write mode to plain text file
    with open(MODE_FILE, "w") as file:
        file.write(mode)

    printer.print_message(
        f"ScientiFlow mode set to '{mode}'",
        style="bold green"
    )


def get_mode() -> str:
    # Create mode file with default "prod" if it doesn't exist
    if not os.path.exists(MODE_FILE):
        os.makedirs(MODE_DIR, exist_ok=True)
        with open(MODE_FILE, "w") as file:
            file.write("prod")
        return "prod"

    # Read mode from file
    try:
        with open(MODE_FILE, "r") as file:
            mode = file.read().strip().lower()
            if mode in {"dev", "prod"}:
                return mode
            return "prod"
    except Exception:
        return "prod"