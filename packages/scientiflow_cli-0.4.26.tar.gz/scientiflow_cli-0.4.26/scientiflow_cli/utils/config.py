from scientiflow_cli.services.modes import get_mode


def get_app_base_url() -> str:
    mode = get_mode()
    if mode == "dev":
        return "https://scientiflow-backend-dev.scientiflow.com/api"

    return "https://www.backend.scientiflow.com/api"
