from ctyun_python_sdk_core import CtyunClient, Credential, ClientConfig, CtyunRequestException

from .models import *


class EcsClient:
    def __init__(self, client_config: ClientConfig):
        self.endpoint = client_config.endpoint
        self.credential = Credential(client_config.access_key_id, client_config.access_key_secret)
        self.ctyun_client = CtyunClient(client_config.verify_tls)

    def v4_ecs_batch_rebuild_instances(self, request: V4EcsBatchRebuildInstancesRequest) -> V4EcsBatchRebuildInstancesResponse:
        """
        该接口提供用户重装多台云主机功能，通过填写相应云主机ID、镜像ID对云主机进行重装。<br/>
        该接口提供用户开启多台云主机功能。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          多台操作：当前接口进行批量操作，重装一台云主机建议使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8302&data=87">重装一台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9271&data=87">查询多个异步任务的结果</a>来查询这些操作是否成功<br/>
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a>
          整机镜像：当使用包含数据盘的整机镜像，重装过程中仅会更换系统盘，原实例数据盘不受影响。请确保该变更不会因为系统盘对数据盘的操作而影响业务流程<br />
        """
        url = f"{self.endpoint}/v4/ecs/batch-rebuild-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchRebuildInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_network_spec(self, request: V4EcsUpdateNetworkSpecRequest) -> V4EcsUpdateNetworkSpecResponse:
        """
        支持对一台处于关机状态的云主机进行带宽变更。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br/>
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br/>
          异步接口：该接口为异步接口，下单成功不代表业务成功
        """
        url = f"{self.endpoint}/v4/ecs/update-network-spec"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateNetworkSpecResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_instance_spec(self, request: V4EcsUpdateInstanceSpecRequest) -> V4EcsUpdateInstanceSpecResponse:
        """
        支持对一台处于关机状态的云主机进行带宽或规格的变更。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br/>
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br/>
          异步接口：该接口为异步接口，下单成功不代表业务成功
        """
        url = f"{self.endpoint}/v4/ecs/update-instance-spec"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateInstanceSpecResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_flavor_spec(self, request: V4EcsUpdateFlavorSpecRequest) -> V4EcsUpdateFlavorSpecResponse:
        """
        支持对一台处于关机状态的云主机进行规格变更<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br/>
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br/>
          异步接口：该接口为异步接口，下单成功不代表业务成功<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额
        """
        url = f"{self.endpoint}/v4/ecs/update-flavor-spec"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateFlavorSpecResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_live_resize(self, request: V4EcsLiveResizeRequest) -> V4EcsLiveResizeResponse:
        """
        该接口提供云主机热变配功能，即开机状态实现变更规格<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          确认当前云主机是否可进行热变配，您可以通过接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=13078&data=87">查询云主机支持的热变配规格信息</a>获取当前云主机是否可以进行热变配，以及可以热变配规格信息<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额<b>热变配当前支持规格和镜像信息为（不同资源池下的镜像和规格支持情况不同，以查询云主机支持热变配规格信息接口的返回值为准）：</b><br />
        支持的云主机镜像：<br />
          CentOS：CentOS 7.6 64位、CentOS 7.8 64位、CentOS 7.9 64位、CentOS 8.0 64位、CentOS 8.1 64位、CentOS 8.2 64位、CentOS 8.4 64位<br />
          CTyunOS：CTyunOS 2.0.1-21.06.4 64位、CTyunOS 3-23.01 64位<br />
          KylinOS：KylinOS V10 SP1 64位、KylinOS V10 SP2 64位<br />
          其他：openEuler 22.03 SP2 64位、UnionTechOS V20 1050u1e 64位<br />支持的云主机规格：<br />
          除二代机以外的规格且vcpu≥32
        """
        url = f"{self.endpoint}/v4/ecs/live-resize"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsLiveResizeResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_operate_label(self, request: V4EcsBatchOperateLabelRequest) -> V4EcsBatchOperateLabelResponse:
        """
        支持批量绑定/解绑云主机标签<br /><b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          关联资源：本次标签操作会将当前云主机及关联资源（云硬盘、弹性公网ip）都进行相同操作<br />
          绑定操作：如果当前资源及关联资源（云硬盘、弹性公网ip）绑定的标签中存在与本次请求标签列表里某一标签具有相同的标签键，则会以本次请求的标签进行覆盖；如果不存在，则会新增一个标签绑定当前资源到及关联资源（云硬盘、弹性公网ip）<br />
          解绑操作：如果当前资源及关联资源（云硬盘、弹性公网ip）绑定的标签中存在与本次请求标签列表里相同的标签（即相同标签键和标签值），则会解绑标签；如果不存在，则不进行操作<br />
          标签配额：资源可绑定标签具有上限，上述绑定操作中出现的请求与当前资源绑定标签存在相同标签键情况下，覆盖操作不占用配额
        """
        url = f"{self.endpoint}/v4/ecs/batch-operate-label"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchOperateLabelResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_deletion_protection(self, request: V4EcsUpdateDeletionProtectionRequest) -> V4EcsUpdateDeletionProtectionResponse:
        """
        更新云主机实例删除保护状态<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/update-deletion-protection"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateDeletionProtectionResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_reset_password(self, request: V4EcsResetPasswordRequest) -> V4EcsResetPasswordResponse:
        """
        该接口提供用户更新云主机的密码的功能<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          如果使用私有镜像创建的云主机执行该操作时，请先检查云主机内部是否安装了QGA（qemu-guest-agent）。不同操作系统请参考：<a href="https://www.ctyun.cn/document/10027726/10747194">Windows系统盘镜像文件安装QGA</a>和<a href="https://www.ctyun.cn/document/10027726/10747147">Linux系统盘镜像文件安装QGA</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/reset-password"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsResetPasswordResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_instance(self, request: V4EcsUpdateInstanceRequest) -> V4EcsUpdateInstanceResponse:
        """
        该接口提供用户更新云主机的部分信息的功能<br />
        目前支持更新云主机的信息为：云主机显示名称（displayName）
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          如果使用私有镜像创建的云主机执行该操作时，请先检查云主机内部是否安装了QGA（qemu-guest-agent）。不同操作系统请参考：<a href="https://www.ctyun.cn/document/10027726/10747194">Windows系统盘镜像文件安装QGA</a>和<a href="https://www.ctyun.cn/document/10027726/10747147">Linux系统盘镜像文件安装QGA</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/update-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_reset_password(self, request: V4EcsBatchResetPasswordRequest) -> V4EcsBatchResetPasswordResponse:
        """
        该接口提供用户更新多台云主机的密码的功能<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          如果使用私有镜像创建的云主机执行该操作时，请先检查云主机内部是否安装了QGA（qemu-guest-agent）。不同操作系统请参考：<a href="https://www.ctyun.cn/document/10027726/10747194">Windows系统盘镜像文件安装QGA</a>和<a href="https://www.ctyun.cn/document/10027726/10747147">Linux系统盘镜像文件安装QGA</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/batch-reset-password"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchResetPasswordResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_update_instances(self, request: V4EcsBatchUpdateInstancesRequest) -> V4EcsBatchUpdateInstancesResponse:
        """
        该接口提供用户更新多台云主机的部分信息的功能<br />
        目前支持更新云主机的信息为：云主机显示名称（displayName）、云主机名称（instanceName）、云主机描述信息（instanceDescription）<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          如果使用私有镜像创建的云主机执行该操作时，请先检查云主机内部是否安装了QGA（qemu-guest-agent）。不同操作系统请参考：<a href="https://www.ctyun.cn/document/10027726/10747194">Windows系统盘镜像文件安装QGA</a>和<a href="https://www.ctyun.cn/document/10027726/10747147">Linux系统盘镜像文件安装QGA</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/batch-update-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchUpdateInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_label_update(self, request: V4EcsLabelUpdateRequest) -> V4EcsLabelUpdateResponse:
        """
        支持编辑云主机标签<br /><b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          关联资源：本次标签操作会将当前云主机及关联资源（云硬盘、弹性公网ip）都进行相同操作<br />
          绑定操作：如果当前资源及关联资源（云硬盘、弹性公网ip）绑定的标签中存在与本次请求标签列表里某一标签具有相同的标签键，则会以本次请求的标签进行覆盖；如果不存在，则会新增一个标签绑定当前资源到及关联资源（云硬盘、弹性公网ip）<br />
          解绑操作：如果当前资源及关联资源（云硬盘、弹性公网ip）绑定的标签中存在与本次请求标签列表里相同的标签（即相同标签键和标签值），则会解绑标签；如果不存在，则不进行操作<br />
          标签配额：资源可绑定标签具有上限，上述绑定操作中出现的请求与当前资源绑定标签存在相同标签键情况下，覆盖操作不占用配额
        """
        url = f"{self.endpoint}/v4/ecs/label/update"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsLabelUpdateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_available_region(self, request: V4EcsFlavorAvailableRegionRequest) -> V4EcsFlavorAvailableRegionResponse:
        """
        该接口提供用户云主机规格可售地域总览查询功能<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据<br />
        """
        url = f"{self.endpoint}/v4/ecs/flavor/available-region"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorAvailableRegionResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_query_options(self, request: V4EcsFlavorQueryOptionsRequest) -> V4EcsFlavorQueryOptionsResponse:
        """
        该接口提供用户云主机规格可售地域总览查询条件范围能力<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/flavor/query-options"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorQueryOptionsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_query_async_result(self, request: V4EcsQueryAsyncResultRequest) -> V4EcsQueryAsyncResultResponse:
        """
        该接口通过一个异步任务的jobID查询任务执行的结果<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看构造请求<br/>
          认证鉴权：openapi请求需要进行加密调用，详细查看认证鉴权<br/>
        <b>注意事项：</b><br/>
          异步任务结果查询：请先通过异步接口得到对应的任务ID（jobID），注：异步任务查询不支持查询订单接口（即涉及付费的接口，如创建云主机）<br/>
          单个任务查询：当前接口只能查询单个任务结果，查询同资源池下多个任务结果，请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9271&data=87">查询多个异步任务的结果</a>来查询
        """
        url = f"{self.endpoint}/v4/ecs/query-async-result"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsQueryAsyncResultResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_list(self, request: V4EcsFlavorListRequest) -> V4EcsFlavorListResponse:
        """
        该接口提供用户可用规格列表查询功能，可返回云主机规格的详细信息，并允许用户根据云主机规格的特殊字段进行筛选。用户可以根据此接口的返回值了解自己可使用的云主机规格有哪些。<br />
        您可以通过<a href="https://www.ctyun.cn/document/10026730/10118193">规格说明</a>了解弹性云主机的选型基本信息<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/flavor/list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_job_query(self, request: V4EcsJobQueryRequest) -> V4EcsJobQueryResponse:
        """
        该接口通过一个或多个异步任务的jobID查询任务执行的结果。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br/>
          异步任务结果查询：请先通过异步接口得到对应的任务ID（jobID），注：异步任务查询不支持查询订单接口（即涉及付费的接口，如创建云主机）<br/>
          多个任务查询：当前接口可以查询同一资源池内多个任务结果，查询单个任务结果，推荐使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5543&data=87">查询一个异步任务的结果</a>来查询
        """
        url = f"{self.endpoint}/v4/ecs/job/query"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsJobQueryResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_userdata_details(self, request: V4EcsUserdataDetailsRequest) -> V4EcsUserdataDetailsResponse:
        """
        根据云主机ID，查询云主机的用户自定义数据。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/userdata/details"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUserdataDetailsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_update_spec_list(self, request: V4EcsFlavorUpdateSpecListRequest) -> V4EcsFlavorUpdateSpecListResponse:
        """
        该接口提供查询当前云主机支持冷变配的规格信息，用户可以根据此接口的返回值了解自己可使用的云主机规格有哪些<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          确认云主机是否存在于当前资源池<br />
          该接口查询的规格适用于冷变配操作，您可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8293&data=87&isNormal=1">云主机修改规格</a>来变更
        """
        url = f"{self.endpoint}/v4/ecs/flavor/update-spec-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorUpdateSpecListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_live_resize_list(self, request: V4EcsFlavorLiveResizeListRequest) -> V4EcsFlavorLiveResizeListResponse:
        """
        该接口提供查询当前云主机支持热变配的规格信息，用户可以根据此接口的返回值了解自己可使用的云主机规格有哪些<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          确认云主机是否存在于当前资源池<br />
          如无法进行热变配，则返回规格结果为空
        """
        url = f"{self.endpoint}/v4/ecs/flavor/live-resize-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorLiveResizeListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_vnc_details(self, request: V4EcsVncDetailsRequest) -> V4EcsVncDetailsResponse:
        """
        查询一台云主机的Web管理终端地址。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
          确认资源池类型：您可以查询<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5855&data=87">资源池信息</a>，查询结果中zoneList内，若返回存在可用区名称，则为多可用区类型资源池；若为空，则为非多可用区类型资源池<b>获取访问地址与使用：</b><br/>
          多可用区：```
        wss://vm-vnc.ctyun.cn/vm_vnc/huadong1/az1/ws?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2OTU3NTY0NTQsImlhdCI6MTY5MjE1NjQ1NCwidXNlcl9pZCI6ImVhYWZlNWRjOWU1OWRlMmM3NmQwNmQwOGFlZTQ0YWZkIiwicHJvamVjdF9pZCI6ImFkOTFkMmNjMDUwY2M0YmIyMTVhZDc0ZDE1OGYzMGQxIiwiZG9tYWluX2lkIjoiZGVmYXVsdCIsInJvbGVzIjpbInVzZXIiXSwiY29uc3VtZXJfaWQiOiIiLCJpc3N1ZWRfYXQiOiIyMDIzLTA4LTE2VDAzOjI3OjM0LjAwMDAwMFoiLCJleHBpcmVfYXQiOiIyMDIzLTA5LTI2VDE5OjI3OjM0LjAwMDAwMFoiLCJNZXRob2QiOlsicGFzc3dvcmQiXX0.1cf3TcvzUfH5I7b4oBYK2yQ2g_ASUllpM5QtOMsWBB0&instanceId=df5e3e31-6cea-05a9-cbce-d74504328bef&instance_name=ecm-f856(df5e3e31-6cea-05a9-cbce-d74504328bef)
        ```访问地址分几部分：> `<WebSocket URL Prefix>` + `ws?` + `token=<token>` + `instanceId=<uuid>`* `<WebSocket URL Prefix>`，即VNC的访问URL前缀，固定访问协议为`wss`，即使用`HTTPS`方式访问\`有如上信息后，可在调用OpenAPI获取VNC token后拼接访问地址，使用noVNC等client进行访问，以noVNC为例，具体操作步骤如下：* 本地启动<a href="https://novnc.com/noVNC/vnc.html">noVNC服务</a>，打开vnc页面；
        * 点击左侧`⚙`，打开`高级`-`WebSocket`，在`主机`中，填写去掉`wss`协议的地址`vm-vnc.ctyun.cn/vm_vnc/<region name>/<az name>/ws?instanceId=<uuid>&token=<token>`，选中`加密`，端口写入`443`
        * 点击右侧连接按钮，即可访问。  单可用区：```
        http://55.7.114.250:60001/vnc_auto.html?token=9b661818-f700-4c33-8ada-94cfe0b9a528&instance_name=ctapi-new-1(1edcf309-4128-4db4-a0b5-99b0240ac27d)
        ```查到信息后，可直接浏览器输入访问地址进行访问
        """
        url = f"{self.endpoint}/v4/ecs/vnc/details"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsVncDetailsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_volume_list(self, request: V4EcsVolumeListRequest) -> V4EcsVolumeListResponse:
        """
        该接口提供查询云主机的云硬盘列表功能<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据<br />
        """
        url = f"{self.endpoint}/v4/ecs/volume/list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsVolumeListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_fixed_ip_list(self, request: V4EcsFixedIpListRequest) -> V4EcsFixedIpListResponse:
        """
        根据云主机ID，查询云主机的固定IP。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/fixed-ip-list"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFixedIpListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_get_auto_renew_config(self, request: V4EcsGetAutoRenewConfigRequest) -> V4EcsGetAutoRenewConfigResponse:
        """
        查询一台包周期付费类型（包年包月）的云主机自动续订配置信息。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/get-auto-renew-config"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsGetAutoRenewConfigResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_families_list(self, request: V4EcsFlavorFamiliesListRequest) -> V4EcsFlavorFamiliesListResponse:
        """
        该接口提供用户可用规格族列表查询功能，每种规格族代表不同种类的云主机规格，用户可以根据此接口的返回值了解自己可使用的规格族有哪些。<br />
          云主机-二代机：X86云主机,包含通用型s2、内存优化型m2。s2、m2实例规格簇均为cpu共享型，上线时间较早。<br />
          云主机-三代机：X86云主机,包含通用型S3、计算增强型c3、内存优化型m3。S3实例规格簇为cpu共享型，c3、m3实例规格簇为cpu独享,软硬件升级，性能增强。<br />
          云主机-六代机：X86云主机,包含通用型s6、通用计算增强c6、内存优化型m6。S6实例规格簇为cpu共享型，c6、m6实例规格簇为cpu独享,性能优良，能承载不同业务需求。<br />
          云主机-七代机：X86云主机,包含通用型s7、通用计算增强c7、内存优化型m7。通用型S7实例规格簇为cpu共享型，c7、m7实例规格簇为cpu独享,提供更大规格更优性能，能满足更高业务需要。<br />
          国产化云主机：X86与ARM云主机,包含鲲鹏计算增强型kc1、海光计算增强型hc1、飞腾计算增强型fc1、鲲鹏内存优化型km1、海光内存优化型hm1、飞腾内存优化型fm1，对安全性有较高要求的政府或企业应用。<br />
          本地盘云主机：X86云主机，包含云主机规格（ip3），提供数据盘为本地盘的云主机。<br />
          GPU云主机：包含图形加速基础型G5、图形加速基础型G7；计算加速型P2V、计算加速型PI7、计算加速型P8A、计算加速型PS4、计算加速型PI3、计算加速型PI2；图形加速基础型G6、图形加速基础型G7。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/flavor-families/list"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorFamiliesListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_flavor_list_by_families(self, request: V4EcsFlavorListByFamiliesRequest) -> V4EcsFlavorListByFamiliesResponse:
        """
        该接口提供用户根据指定规格族查询云主机的名称、云主机 ID 及规格详情<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi 请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示 50 条数据
        """
        url = f"{self.endpoint}/v4/ecs/flavor/list-by-families"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsFlavorListByFamiliesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_statistics_instance(self, request: V4EcsStatisticsInstanceRequest) -> V4EcsStatisticsInstanceResponse:
        """
        查询用户云主机统计信息<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/statistics-instance"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsStatisticsInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_volume_statistics(self, request: V4EcsVolumeStatisticsRequest) -> V4EcsVolumeStatisticsResponse:
        """
        查询用户云硬盘统计信息<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/volume/statistics"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsVolumeStatisticsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_order_query_uuid(self, request: V4EcsOrderQueryUuidRequest) -> V4EcsOrderQueryUuidResponse:
        """
        根据输入订单号masterOrderID查询出云主机的UUID<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          订单查询：通过创建云主机接口得到对应的主订单ID后，使用该接口获取订单状态，并在订单状态为成功之后获取对应的云主机ID
        """
        url = f"{self.endpoint}/v4/ecs/order/query-uuid"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsOrderQueryUuidResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_instance_status_list(self, request: V4EcsInstanceStatusListRequest) -> V4EcsInstanceStatusListResponse:
        """
        该接口提供用户多台云主机状态信息查询功能，用户可以根据此接口的返回值得到多台云主机的状态信息。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据<br />
          匹配查找：可以通过部分字段进行匹配筛选数据，无符合条件的为空，在指定多台云主机ID的情况下，只返回匹配到的云主机信息。推荐每次使用单个条件查找
        """
        url = f"{self.endpoint}/v4/ecs/instance-status-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsInstanceStatusListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_affinity_group_create(self, request: V4EcsAffinityGroupCreateRequest) -> V4EcsAffinityGroupCreateResponse:
        """
        该接口提供用户创建云主机组的功能<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          用户配额：确认个人在不同资源池下资源配额，可以通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9714&data=87">用户配额查询</a>接口进行查询<br />
        """
        url = f"{self.endpoint}/v4/ecs/affinity-group/create"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsAffinityGroupCreateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_affinity_group_delete(self, request: V4EcsAffinityGroupDeleteRequest) -> V4EcsAffinityGroupDeleteResponse:
        """
        该接口提供用户删除云主机组的功能<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/affinity-group-delete"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsAffinityGroupDeleteResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_detach_instance(self, request: V4EcsKeypairDetachInstanceRequest) -> V4EcsKeypairDetachInstanceResponse:
        """
        为Linux云主机解绑SSH密钥对<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/detach-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairDetachInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_delete(self, request: V4EcsKeypairDeleteRequest) -> V4EcsKeypairDeleteResponse:
        """
        此接口供用户用来删除SSH密钥对。系统会根据您输入的SSH密钥对的名称删除对应的密钥对，并返回删除成功信息。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/delete"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairDeleteResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_attach_instance(self, request: V4EcsKeypairAttachInstanceRequest) -> V4EcsKeypairAttachInstanceResponse:
        """
        此接口提供用户绑定SSH密钥对到云主机功能。系统会接收用户输入的云主机id和SSH密钥对，将对应SSH密钥对绑定到对应云主机上。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          1. 如果实例已经绑定了SSH密钥对，新的SSH密钥对自动替换原来的SSH密钥对 <br />
          2. 如果使用的是私有镜像创建的云主机，需要注意私有镜像中是否含有qga插件，不含则会绑定失败
        """
        url = f"{self.endpoint}/v4/ecs/keypair/attach-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairAttachInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_update_label(self, request: V4EcsKeypairUpdateLabelRequest) -> V4EcsKeypairUpdateLabelResponse:
        """
        支持编辑密钥对标签<br /><b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          绑定操作：如果当前密钥对绑定的标签中存在与本次请求标签列表里某一标签具有相同的标签键，则会以本次请求的标签进行覆盖；如果不存在，则会新增一个标签绑定密钥对<br />
          解绑操作：如果当前密钥对绑定的标签中存在与本次请求标签列表里相同的标签（即相同标签键和标签值），则会解绑标签；如果不存在，则不进行操作<br />
          标签配额：密钥对可绑定标签具有上限，上述绑定操作中出现的请求与当前资源绑定标签存在相同标签键情况下，覆盖操作不占用配额
        """
        url = f"{self.endpoint}/v4/ecs/keypair/update-label"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairUpdateLabelResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_share_interface_attach(self, request: V4EcsShareInterfaceAttachRequest) -> V4EcsShareInterfaceAttachResponse:
        """
        给云主机添加共享网卡<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看构造请求<br />
          认证鉴权：openapi请求需要进行加密调用，详细查看认证鉴权<br />
        <b>注意事项：</b><br />
          该接口给云主机添加共享网卡后，共享网卡不能通过普通网卡方式进行卸载，只能随着退订云主机时进行删除，请谨慎使用
        """
        url = f"{self.endpoint}/v4/ecs/share-interface/attach"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsShareInterfaceAttachResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_auto_renew_config(self, request: V4EcsUpdateAutoRenewConfigRequest) -> V4EcsUpdateAutoRenewConfigResponse:
        """
        对原包周期付费类型（包年包月）的云主机自动续订配置进行修改，包括开启自动续订或关闭自动续订。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项</b>：<br />
          若实例到期前10天内系统已下发自动续订任务，此时取消自动续订操作仅对后续周期生效。具体表现为：当前已触发的续订任务仍将正常执行完成，而自动续订功能将在实例下一次到期时正式停用。
        """
        url = f"{self.endpoint}/v4/ecs/update-auto-renew-config"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateAutoRenewConfigResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_clone_instance(self, request: V4EcsCloneInstanceRequest) -> V4EcsCloneInstanceResponse:
        """
        使用已创建成功的云主机，克隆一台新的云主机。新云主机的规格、镜像、数据盘、系统盘及数据等均与备份一致。<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
          计费模式：确认开通云主机的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
          网络规划：规划云主机的网络环境，详细查看<a href="https://www.ctyun.cn/document/10026730/10237410">弹性云主机-网络</a><br />
        <b>注意事项：</b><br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          用户配额：确认个人在不同资源池下资源配额，可以通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9714&data=87">用户配额查询</a>接口进行查询<br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
          企业项目：保证资源隔离，需确保所有资源与云主机处于相同企业项目下才可进行挂载操作，如网络资源：VPC、安全组、弹性IP、子网<br />
          标签绑定：云主机绑定标签时，标签键和值存在的情况下，绑定对应标签；不存在的情况下，创建新的标签并绑定云主机。主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）。<br />
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a>
          内网DNS域名解析：VPC默认启用DNS主机名配，生成的DNS解析绑定实例主网卡的内网IP地址。设置4种云主机内网域名解析类型，分别为IP\_TO\_IPV4：启用IP格式主机名到实例主私网IPv4的DNS 解析（A记录），INSTANCE\_ID\_TO\_IPV4：启用实例ID格式主机名到实例主内网IPv4的DNS解析（A记录），INSTANCE\_ID\_TO\_IPV6：启用实例ID格式主机名到实例主内网IPv6的DNS解析（AAAA记录），IPV4\_TO\_IP：启用实例主内网IPv4到IP格式主机名的反向DNS解析（PTR记录）
        """
        url = f"{self.endpoint}/v4/ecs/clone-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsCloneInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_operate_all_instances(self, request: V4EcsOperateAllInstancesRequest) -> V4EcsOperateAllInstancesResponse:
        """
        支持全部开机、关机、重启资源池云主机，返回执行开机/关机/重启操作的云主机ID及其对应任务ID<br /><b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/operate-all-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsOperateAllInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_stop_instance(self, request: V4EcsStopInstanceRequest) -> V4EcsStopInstanceResponse:
        """
        该接口提供用户关闭一台云主机功能，可选两种关机模式：普通关机、强制关机。<br />
        请求下发后云主机变为关机中（stopping）状态，待异步任务完成后，云主机变为关机（stopped）状态。<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          单台操作：当前接口只能操作单台云主机，关闭多台云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8304&data=87">关闭多台云主机</a>进行操作<br />
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5543&data=87">查询一个异步任务的结果</a>来查询操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/stop-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsStopInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_stop_instances(self, request: V4EcsBatchStopInstancesRequest) -> V4EcsBatchStopInstancesResponse:
        """
        该接口提供用户关闭多台云主机功能，可选两种关机模式：普通关机、强制关机。<br />
        普通关机与强制关机模式下，请求下发后云主机变为关机中（stopping）状态，待异步任务完成后，云主机变为关机（stopped）状态。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          多台操作：当前接口进行批量操作，关闭一台云主机建议使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8297&data=87">关闭一台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9271&data=87">查询多个异步任务的结果</a>来查询这些操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/batch-stop-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchStopInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_create_same_config_instances(self, request: V4EcsCreateSameConfigInstancesRequest) -> V4EcsCreateSameConfigInstancesResponse:
        """
        支持创建一台或多台与已有云主机相同配置的云主机<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
          计费模式：确认开通云主机的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
          地域选择：选择创建云主机的资源池，详细查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a><br />
          产品选型：购买弹性云主机前，请先阅读<a href="https://www.ctyun.cn/document/10026730/10118193">规格说明</a>了解弹性云主机的选型基本信息，并通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8327&data=87">查询一个或多个云主机规格资源</a>接口，获取当前资源池可用云主机规格信息<br />
          网络规划：规划云主机的网络环境，详细查看<a href="https://www.ctyun.cn/document/10026730/10237410">弹性云主机-网络</a><br />
        <b>注意事项：</b><br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          用户配额：确认个人在不同资源池下资源配额，可以通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9714&data=87">用户配额查询</a>接口进行查询<br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
          单台创建：当前接口只能创建单台同类型云主机，批量创建同类型云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>进行创建<br />
          企业项目：保证资源隔离，需确保所有资源与云主机处于相同企业项目下才可进行挂载操作，如网络资源：VPC、安全组、弹性IP、子网<br />
          标签绑定：云主机绑定标签时，标签键和值存在的情况下，绑定对应标签；不存在的情况下，创建新的标签并绑定云主机。主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）<br />
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a><br />
          相同配置：体现在主机配置方面与原云主机一致，包括付费方式、规格、镜像、磁盘（包含是否加密和加密密钥）、虚拟私有云、安全组、网卡（网卡和网卡数量，但内网IP地址自动分配）、云主机组、登录方式（若采用密码方式登录，则需要重新配置密码；若采用密钥方式登录，则使用原密钥，若原密钥失效，则需要重新选择密钥）、企业项目、标签，但所有的字段均可修改。在弹性公网IP（默认不使用）、购买时长、购买数量、是否开启监控、用户自定义数据、用户名方面需要重新设置<br />
          内网DNS域名解析：VPC默认启用DNS主机名配，生成的DNS解析绑定实例主网卡的内网IP地址。设置4种云主机内网域名解析类型，分别为IP\_TO\_IPV4：启用IP格式主机名到实例主私网IPv4的DNS 解析（A记录），INSTANCE\_ID\_TO\_IPV4：启用实例ID格式主机名到实例主内网IPv4的DNS解析（A记录），INSTANCE\_ID\_TO\_IPV6：启用实例ID格式主机名到实例主内网IPv6的DNS解析（AAAA记录），IPV4\_TO\_IP：启用实例主内网IPv4到IP格式主机名的反向DNS解析（PTR记录）
        """
        url = f"{self.endpoint}/v4/ecs/create-same-config-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsCreateSameConfigInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_delete_instance(self, request: V4EcsDeleteInstanceRequest) -> V4EcsDeleteInstanceResponse:
        """
        支持删除云主机，并选择是否释放关联资源<br/>
        对于包周期的云主机为退订，最终状态会转变为包周期已退订（unsubscribed）<br/>
        对于按量付费的云主机为删除，删除完成后，无法再次通过云主机相关查询接口查询到该云主机信息<br/><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          释放前请确保文件已进行备份，释放后不可恢复。在云主机订购时，一起订购的其他资源，比如绑定的网卡、云硬盘、弹性IP等资源，会一起被释放。非一起订购的资源，比如绑定的网卡、云硬盘、弹性IP等资源会被解绑。
        """
        url = f"{self.endpoint}/v4/ecs/delete-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsDeleteInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_convert_to_ondemand(self, request: V4EcsConvertToOndemandRequest) -> V4EcsConvertToOndemandResponse:
        """
        对原包周期付费类型（包年包月）的云主机标记，当前仅支持包周期云主机到期转变为按需付费类型。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/convert-to-ondemand"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsConvertToOndemandResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_start_instance(self, request: V4EcsStartInstanceRequest) -> V4EcsStartInstanceResponse:
        """
        该接口提供用户开启一台云主机功能。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          单台操作：当前接口只能操作单台云主机，开启多台云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8303&data=87">开启多台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5543&data=87">查询一个异步任务的结果</a>来查询操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/start-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsStartInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_start_instances(self, request: V4EcsBatchStartInstancesRequest) -> V4EcsBatchStartInstancesResponse:
        """
        该接口提供用户开启多台云主机功能。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          多台操作：当前接口进行批量操作，开启一台云主机建议使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8296&data=87">开启一台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9271&data=87">查询多个异步任务的结果</a>来查询这些操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/batch-start-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchStartInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_recover_unsubscribed_instance(self, request: V4EcsRecoverUnsubscribedInstanceRequest) -> V4EcsRecoverUnsubscribedInstanceResponse:
        """
        恢复包年或者包月已退订的云主机。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看构造请求<br />
          认证鉴权：openapi请求需要进行加密调用，详细查看认证鉴权<br /><b>注意事项</b>：<br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9715&data=87&isNormal=1">根据订单号查询uuid</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
        """
        url = f"{self.endpoint}/v4/ecs/recover-unsubscribed-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsRecoverUnsubscribedInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_delete_instances(self, request: V4EcsBatchDeleteInstancesRequest) -> V4EcsBatchDeleteInstancesResponse:
        """
        支持批量退订或删除云主机释放关联资源，并选择是否释放关联资源<br/>
        对于包周期的云主机为退订，最终状态会转变为包周期已退订（unsubscribed）<br/>
        对于按量付费的云主机为删除，删除完成后，无法再次通过云主机相关查询接口查询到该云主机信息<br/><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          释放前请确保文件已进行备份，释放后不可恢复。绑定的网卡会被释放，在云主机订购时，一起订购的其他资源，比如云硬盘、弹性IP等资源，会一起被释放；非一起订购的资源，比如绑定的云硬盘、弹性IP等资源会被解绑。
          异步操作：请求成功仅代表退订或删除请求已下发，具体执行结果请到订单中心查看。
        """
        url = f"{self.endpoint}/v4/ecs/batch-delete-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchDeleteInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_delete(self, request: V4EcsBatchDeleteRequest) -> V4EcsBatchDeleteResponse:
        """
        批量释放云主机，对于包周期的云主机为退订，对于按量付费的云主机为删除。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          释放前请确保文件已进行备份，释放后不可恢复。在云主机订购时，一起订购的其他资源，比如绑定的网卡、云硬盘、弹性IP等资源，会一起被释放。非一起订购的资源，比如绑定的网卡、云硬盘、弹性IP等资源会被解绑。
        """
        url = f"{self.endpoint}/v4/ecs/batch-delete"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchDeleteResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_convert_to_cycle(self, request: V4EcsConvertToCycleRequest) -> V4EcsConvertToCycleResponse:
        """
        对原按需付费类型（onDemand为True）的云主机进行付费类型转换，转变为包年包月支付类型云主机。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/convert-to-cycle"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsConvertToCycleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_resubscribe_instance(self, request: V4EcsResubscribeInstanceRequest) -> V4EcsResubscribeInstanceResponse:
        """
        续订一台包年或者包月的云主机。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1&vid=81">根据masterOrderID查询云主机ID</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额
        """
        url = f"{self.endpoint}/v4/ecs/resubscribe-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsResubscribeInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_shelve_instance(self, request: V4EcsShelveInstanceRequest) -> V4EcsShelveInstanceResponse:
        """
        该接口提供用户对一台云主机节省关机功能，请求下发后云主机变为节省关机中（shelving）状态，待异步任务完成后，云主机变为节省关机（shelve）状态。<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          单台操作：当前接口只能操作单台云主机，关闭多台云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8304&data=87">关闭多台云主机</a>进行操作<br />
          异步接口：该接口为异步接口，当云主机状态变为节省关机（shelve）状态时，异步操作结果成功
        """
        url = f"{self.endpoint}/v4/ecs/shelve-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsShelveInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_shelve_instances(self, request: V4EcsBatchShelveInstancesRequest) -> V4EcsBatchShelveInstancesResponse:
        """
        该接口提供用户节省关机多台云主机功能，请求下发后云主机变为节省关机中（shelving）状态，待异步任务完成后，云主机变为节省关机（shelve）状态。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          多台操作：当前接口进行批量操作，关闭一台云主机建议使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8297&data=87">关闭一台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，当云主机状态变为节省关机（shelve）状态时，异步操作结果成功
        """
        url = f"{self.endpoint}/v4/ecs/batch-shelve-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchShelveInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_unsubscribe_instance(self, request: V4EcsUnsubscribeInstanceRequest) -> V4EcsUnsubscribeInstanceResponse:
        """
        释放云主机，对于包周期的云主机为退订，对于按量付费的云主机为删除。<br />
        随主机一同创建（即下单云主机时填写其他的资源配置，如数据盘和弹性公网）的资源默认随主机一同释放。<b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          释放前请确保文件已进行备份，释放后不可恢复。在云主机订购时，一起订购的其他资源，比如绑定的网卡、云硬盘、弹性IP等资源，会一起被释放。非一起订购的资源，比如绑定的网卡、云硬盘、弹性IP等资源会被解绑。
        """
        url = f"{self.endpoint}/v4/ecs/unsubscribe-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUnsubscribeInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_reboot_instance(self, request: V4EcsRebootInstanceRequest) -> V4EcsRebootInstanceResponse:
        """
        该接口提供用户重启一台云主机功能。<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          单台操作：当前接口只能操作单台云主机，重启多台云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8305&data=87">重启多台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5543&data=87">查询一个异步任务的结果</a>来查询操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/reboot-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsRebootInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_reboot_instances(self, request: V4EcsBatchRebootInstancesRequest) -> V4EcsBatchRebootInstancesResponse:
        """
        该接口提供用户重启多台云主机功能<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          多台操作：当前接口进行批量操作，重启一台云主机建议使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8298&data=87">重启一台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9271&data=87">查询多个异步任务的结果</a>来查询这些操作是否成功
        """
        url = f"{self.endpoint}/v4/ecs/batch-reboot-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchRebootInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_rebuild_instance(self, request: V4EcsRebuildInstanceRequest) -> V4EcsRebuildInstanceResponse:
        """
        该接口提供用户重装一台云主机功能，通过填写相应云主机ID、镜像ID对云主机进行重装<br/>
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项：</b><br />
          单台操作：当前接口只能操作单台云主机，重装多台云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8306&data=87">重装多台云主机</a>进行操作<br/>
          异步接口：该接口为异步接口，请求过后会拿到任务ID（jobID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5543&data=87">查询一个异步任务的结果</a>来查询操作是否成功<br />
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a><br />
          整机镜像：当使用包含数据盘的整机镜像，重装过程中仅会更换系统盘，原实例数据盘不受影响。请确保该变更不会因为系统盘对数据盘的操作而影响业务流程<br />
        """
        url = f"{self.endpoint}/v4/ecs/rebuild-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsRebuildInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_destroy_instance(self, request: V4EcsDestroyInstanceRequest) -> V4EcsDestroyInstanceResponse:
        """
        销毁一台包周期已退订云主机<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          1. 对于成功销毁，并重复使用clientToken再次请求的情况下，只保证返回第一次使用该clientToken时请求参数对应的主订单ID（masterOrderID）<br />
          2. 包周期已退订云主机已不再计费，但占用户资源相关配额，确认该云主机需要销毁的情况下执行该请求
        """
        url = f"{self.endpoint}/v4/ecs/destroy-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsDestroyInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_create_instances(self, request: V4EcsBatchCreateInstancesRequest) -> V4EcsBatchCreateInstancesResponse:
        """
        支持批量创建按量付费或包年包月云主机<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
          计费模式：确认开通云主机的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
          地域选择：选择创建云主机的资源池，详细查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a><br />
          产品选型：购买弹性云主机前，请先阅读<a href="https://www.ctyun.cn/document/10026730/10118193">规格说明</a>了解弹性云主机的选型基本信息，并通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8327&data=87">查询一个或多个云主机规格资源</a>接口，获取当前资源池可用云主机规格信息<br />
          网络规划：规划云主机的网络环境，详细查看<a href="https://www.ctyun.cn/document/10026730/10237410">弹性云主机-网络</a><br />
        <b>注意事项：</b><br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          用户配额：确认个人在不同资源池下资源配额，可以通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9714&data=87">用户配额查询</a>接口进行查询<br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
          多台创建：当前接口只能创建多个同类型云主机，个性化创建不同类型云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a>进行创建<br />
          企业项目：保证资源隔离，需确保所有资源与云主机处于相同企业项目下才可进行挂载操作，如网络资源：VPC、安全组、弹性IP、子网<br />
          标签绑定：云主机绑定标签时，标签键和值存在的情况下，绑定对应标签；不存在的情况下，创建新的标签并绑定云主机。主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）<br />
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额。<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a>
          安全防护：有三种类型：旗舰版、企业版和基础版。旗舰版适用于防御勒索软件攻击，全面提升防护效果的场景；企业版适用于有效保护云上资产，满足等保合规要求的场景；基础版适用于为用户免费提供基础安全防护能力。更多安全防护的信息请参考<a href="https://www.ctyun.cn/document/10026775/10308306">安全防护产品介绍</a>
          内网DNS域名解析：VPC默认启用DNS主机名配，生成的DNS解析绑定实例主网卡的内网IP地址。设置4种云主机内网域名解析类型，分别为IP\_TO\_IPV4：启用IP格式主机名到实例主私网IPv4的DNS 解析（A记录），INSTANCE\_ID\_TO\_IPV4：启用实例ID格式主机名到实例主内网IPv4的DNS解析（A记录），INSTANCE\_ID\_TO\_IPV6：启用实例ID格式主机名到实例主内网IPv6的DNS解析（AAAA记录），IPV4\_TO\_IP：启用实例主内网IPv4到IP格式主机名的反向DNS解析（PTR记录）
        """
        url = f"{self.endpoint}/v4/ecs/batch-create-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchCreateInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_instance_details(self, request: V4EcsInstanceDetailsRequest) -> V4EcsInstanceDetailsResponse:
        """
        该接口提供用户一台云主机信息查询功能，用户可以根据此接口的返回值了解自己云主机的详细信息。<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          单台查询：当前接口只能查询单台云主机信息，查询多台云主机信息请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a>进行查询<br />
        """
        url = f"{self.endpoint}/v4/ecs/instance-details"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsInstanceDetailsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_describe_instances(self, request: V4EcsDescribeInstancesRequest) -> V4EcsDescribeInstancesResponse:
        """
        该接口提供用户多台云主机信息查询功能，用户可以根据此接口的返回值得到多台云主机信息。该接口相较于/v4/ecs/list-instances提供更精简的云主机信息，拥有更高的查找效率<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据<br />
          匹配查找：可以通过部分字段进行匹配筛选数据，无符合条件的为空，在指定多台云主机ID的情况下，只返回匹配到的云主机信息。推荐每次使用单个条件查找
        """
        url = f"{self.endpoint}/v4/ecs/describe-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsDescribeInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_list_instances(self, request: V4EcsListInstancesRequest) -> V4EcsListInstancesResponse:
        """
        该接口提供用户多台云主机信息查询功能，用户可以根据此接口的返回值得到多台云主机信息。<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据<br />
          匹配查找：可以通过部分字段进行匹配筛选数据，无符合条件的为空，在指定多台云主机ID的情况下，只返回匹配到的云主机信息。推荐每次使用单个条件查找
        """
        url = f"{self.endpoint}/v4/ecs/list-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsListInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_create_keypair(self, request: V4EcsKeypairCreateKeypairRequest) -> V4EcsKeypairCreateKeypairResponse:
        """
        此接口用来创建一对SSH密钥对。系统会为您保管密钥的公钥部分，并返回未加密私钥。您需要自行妥善保管私钥部分。 <br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/create-keypair"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairCreateKeypairResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_import_keypair(self, request: V4EcsKeypairImportKeypairRequest) -> V4EcsKeypairImportKeypairResponse:
        """
        导入由其他工具产生的RSA密钥对的公钥部分，密钥对的类型必须是SSH或x509。 <br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/import-keypair"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairImportKeypairResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_details(self, request: V4EcsKeypairDetailsRequest) -> V4EcsKeypairDetailsResponse:
        """
        此接口提供用户查询SSH密钥对功能。系统会接收用户输入的查询条件，并返回符合条件的密钥对详细信息。用户可根据此接口的返回值了解对应条件下的密钥对信息。 <br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/details"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairDetailsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_create_instance(self, request: V4EcsCreateInstanceRequest) -> V4EcsCreateInstanceResponse:
        """
        支持创建一台按量付费或包年包月的云主机<br />
        <b>准备工作：</b><br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
          计费模式：确认开通云主机的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
          地域选择：选择创建云主机的资源池，详细查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a><br />
          产品选型：购买弹性云主机前，请先阅读<a href="https://www.ctyun.cn/document/10026730/10118193">规格说明</a>了解弹性云主机的选型基本信息，并通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8327&data=87">查询一个或多个云主机规格资源</a>接口，获取当前资源池可用云主机规格信息<br />
          网络规划：规划云主机的网络环境，详细查看<a href="https://www.ctyun.cn/document/10026730/10237410">弹性云主机-网络</a><br />
        <b>注意事项：</b><br />
          成本估算：了解云主机的<a href="https://www.ctyun.cn/document/10026730/10028700">计费项</a><br />
          用户配额：确认个人在不同资源池下资源配额，可以通过<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9714&data=87">用户配额查询</a>接口进行查询<br />
          异步接口：该接口为异步接口，下单过后会拿到主订单ID（masterOrderID），后续可以调用<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>，使用主订单ID来对订单情况与开通成功后的资源ID进行查询<br />
          单台创建：当前接口只能创建单台同类型云主机，批量创建同类型云主机请使用接口<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>进行创建<br />
          企业项目：保证资源隔离，需确保所有资源与云主机处于相同企业项目下才可进行挂载操作，如网络资源：VPC、安全组、弹性IP、子网<br />
          标签绑定：云主机绑定标签时，标签键和值存在的情况下，绑定对应标签；不存在的情况下，创建新的标签并绑定云主机。主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）<br />
          监控安装：在云服务器创建成功后，3-5分钟内将完成详细监控Agent安装，即开启云服务器CPU，内存，网络，磁盘，进程等指标详细监控，若不开启，则无任何监控数据。<br />
          代金券：只支持预付费用户抵扣包周期资源的金额，且不可超过包周期资源的金额。<br />
          用户数据：Windows 支持 bat 和 powershell两种格式，在 Base64 编码前需以“#ps1”开头。Linux 支持 shell 脚本，在 Base64 编码前需以“#!/bin/bash”、“#cloud-config”开头。更多的格式参考<a href="https://cloudinit.readthedocs.io/en/latest/explanation/format.html?regionid=b6bb383e876c11ea8a5e0242ac110002">cloud-init</a> <br />
          安全防护：有三种类型：旗舰版、企业版和基础版。旗舰版适用于防御勒索软件攻击，全面提升防护效果的场景；企业版适用于有效保护云上资产，满足等保合规要求的场景；基础版适用于为用户免费提供基础安全防护能力。更多安全防护的信息请参考<a href="https://www.ctyun.cn/document/10026775/10308306">安全防护产品介绍</a> <br />
          内网DNS域名解析：VPC默认启用DNS主机名配，生成的DNS解析绑定实例主网卡的内网IP地址。设置4种云主机内网域名解析类型，分别为IP\_TO\_IPV4：启用IP格式主机名到实例主私网IPv4的DNS 解析（A记录），INSTANCE\_ID\_TO\_IPV4：启用实例ID格式主机名到实例主内网IPv4的DNS解析（A记录），INSTANCE\_ID\_TO\_IPV6：启用实例ID格式主机名到实例主内网IPv6的DNS解析（AAAA记录），IPV4\_TO\_IP：启用实例主内网IPv4到IP格式主机名的反向DNS解析（PTR记录）
        """
        url = f"{self.endpoint}/v4/ecs/create-instance"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsCreateInstanceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_job_info(self, request: V4JobInfoRequest) -> V4JobInfoResponse:
        """查看job任务状态等"""
        url = f"{self.endpoint}/v4/job/info"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4JobInfoResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_check_demand(self, request: V4RegionCheckDemandRequest) -> V4RegionCheckDemandResponse:
        """查询用户可用的产品是否可售，支持云主机、云硬盘、弹性公网IP产品的可售查询。"""
        url = f"{self.endpoint}/v4/region/check-demand"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionCheckDemandResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_order_new_query_price(self, request: V4OrderNewQueryPriceRequest) -> V4OrderNewQueryPriceResponse:
        """购买云产品时询价接口，支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、物理机、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月或按量订单的询价功能"""
        url = f"{self.endpoint}/v4/order/new-query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4OrderNewQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_order_upgrade_query_price(self, request: V4OrderUpgradeQueryPriceRequest) -> V4OrderUpgradeQueryPriceResponse:
        """支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月或按量订单变配时的询价功能"""
        url = f"{self.endpoint}/v4/order/upgrade-query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4OrderUpgradeQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_order_renew_query_price(self, request: V4OrderRenewQueryPriceRequest) -> V4OrderRenewQueryPriceResponse:
        """支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、物理机、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月订单的续订询价功能"""
        url = f"{self.endpoint}/v4/order/renew-query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4OrderRenewQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_customer_resources(self, request: V4RegionCustomerResourcesRequest) -> V4RegionCustomerResourcesResponse:
        """根据regionID查询用户已有资源"""
        url = f"{self.endpoint}/v4/region/customer-resources"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionCustomerResourcesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_customer_quotas(self, request: V4RegionCustomerQuotasRequest) -> V4RegionCustomerQuotasResponse:
        """根据regionID查询用户配额"""
        url = f"{self.endpoint}/v4/region/customer-quotas"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionCustomerQuotasResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_common_get_ecs_flavors(self, request: V4CommonGetEcsFlavorsRequest) -> V4CommonGetEcsFlavorsResponse:
        """查询资源池虚机规格信息"""
        url = f"{self.endpoint}/v4/common/get-ecs-flavors"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4CommonGetEcsFlavorsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_order_query_uuid(self, request: V4OrderQueryUuidRequest) -> V4OrderQueryUuidResponse:
        """根据订单号masterOrderId输出订单状态、资源类型、资源uuid列表"""
        url = f"{self.endpoint}/v4/order/query-uuid"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4OrderQueryUuidResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_new_order_query_price(self, request: V4NewOrderQueryPriceRequest) -> V4NewOrderQueryPriceResponse:
        """购买云产品时询价接口，支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、物理机、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月或按量订单的询价功能"""
        url = f"{self.endpoint}/v4/new-order/query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4NewOrderQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_upgrade_order_query_price(self, request: V4UpgradeOrderQueryPriceRequest) -> V4UpgradeOrderQueryPriceResponse:
        """支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月或按量订单变配时的询价功能"""
        url = f"{self.endpoint}/v4/upgrade-order/query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4UpgradeOrderQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_get_products(self, request: V4RegionGetProductsRequest) -> V4RegionGetProductsResponse:
        """查询一个资源池支持的云产品信息列表，以及云产品的产品特性信息。"""
        url = f"{self.endpoint}/v4/region/get-products"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionGetProductsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_list_regions(self, request: V4RegionListRegionsRequest) -> V4RegionListRegionsResponse:
        """查询租户可见的资源池列表。"""
        url = f"{self.endpoint}/v4/region/list-regions"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionListRegionsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_get_zones(self, request: V4RegionGetZonesRequest) -> V4RegionGetZonesResponse:
        """查询单个资源池的可用区信息"""
        url = f"{self.endpoint}/v4/region/get-zones"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionGetZonesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_region_get_summary(self, request: V4RegionGetSummaryRequest) -> V4RegionGetSummaryResponse:
        """查询资源池概况，比如地域，多az信息，支持的cpu架构，资源池占用类型，资源池版本信息等"""
        url = f"{self.endpoint}/v4/region/get-summary"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4RegionGetSummaryResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_renew_order_query_price(self, request: V4RenewOrderQueryPriceRequest) -> V4RenewOrderQueryPriceResponse:
        """支持云主机、云硬盘、弹性公网IP、NAT网关、共享带宽、物理机、性能保障型负载均衡、云主机备份存储库和云硬盘备份存储库产品的包年/包月订单的续订询价功能"""
        url = f"{self.endpoint}/v4/renew-order/query-price"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4RenewOrderQueryPriceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_availability_zones_details(self, request: V4EcsAvailabilityZonesDetailsRequest) -> V4EcsAvailabilityZonesDetailsResponse:
        """查询账户指定资源池中可用区的信息。"""
        url = f"{self.endpoint}/v4/ecs/availability-zones/details"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsAvailabilityZonesDetailsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_update_dns_record(self, request: V4EcsUpdateDnsRecordRequest) -> V4EcsUpdateDnsRecordResponse:
        """
        支持对一台云主机进行内网DNS记录的修改。<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        <b>注意事项：</b><br />
          内网DNS域名解析：VPC默认启用DNS主机名配，生成的DNS解析绑定实例主网卡的内网IP地址。设置4种云主机内网域名解析类型，分别为IP\_TO\_IPV4：启用IP格式主机名到实例主私网IPv4的DNS 解析（A记录），INSTANCE\_ID\_TO\_IPV4：启用实例ID格式主机名到实例主内网IPv4的DNS解析（A记录），INSTANCE\_ID\_TO\_IPV6：启用实例ID格式主机名到实例主内网IPv6的DNS解析（AAAA记录），IPV4\_TO\_IP：启用实例主内网IPv4到IP格式主机名的反向DNS解析（PTR记录）
        """
        url = f"{self.endpoint}/v4/ecs/update-dns-record"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsUpdateDnsRecordResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_query_dns_record(self, request: V4EcsQueryDnsRecordRequest) -> V4EcsQueryDnsRecordResponse:
        """
        该接口提供用户云主机的内网DNS记录查询功能<br />
        <b>准备工作：</b><br/>
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/query-dns-record"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4EcsQueryDnsRecordResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_gpu_drivers_list(self, request: V4EcsGpuDriversListRequest) -> V4EcsGpuDriversListResponse:
        """
        该接口提供用户使用GPU云主机规格、镜像查询可用驱动版本。<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/gpu-drivers/list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsGpuDriversListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_batch_destroy_instances(self, request: V4EcsBatchDestroyInstancesRequest) -> V4EcsBatchDestroyInstancesResponse:
        """
        销毁一台或多台包周期云主机<br /><b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br /><b>注意事项</b>：<br />
          1. 对于成功销毁，并重复使用clientToken再次请求的情况下，只保证返回第一次使用该clientToken时请求参数对应的主订单ID（masterOrderID）<br />
          2. 包周期已退订、已到期或已冻结云主机已不再计费，但占用户资源相关配额，确认该云主机需要销毁的情况下执行该请求
        """
        url = f"{self.endpoint}/v4/ecs/batch-destroy-instances"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsBatchDestroyInstancesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_ecs_keypair_update_keypair(self, request: V4EcsKeypairUpdateKeypairRequest) -> V4EcsKeypairUpdateKeypairResponse:
        """
        该接口提供用户更新云主机的部分信息的功能<br />
        <b>准备工作</b>：<br />
          构造请求：在调用前需要了解如何构造请求，详情查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81">构造请求</a><br />
          认证鉴权：openapi请求需要进行加密调用，详细查看<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u8BA4%u8BC1%u9274%u6743&data=87&vid=81">认证鉴权</a><br />
        """
        url = f"{self.endpoint}/v4/ecs/keypair/update-keypair"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4EcsKeypairUpdateKeypairResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))



