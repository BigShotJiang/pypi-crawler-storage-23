from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4RegionCustomerResourcesRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionCustomerResourcesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4RegionCustomerResourcesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObj:
    resources: Optional['V4RegionCustomerResourcesReturnObjResources'] = None  # 资源信息


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResources:
    VM: Optional['V4RegionCustomerResourcesReturnObjResourcesVM'] = None  # 云主机
    Volume: Optional['V4RegionCustomerResourcesReturnObjResourcesVolume'] = None  # 磁盘
    VOLUME_SNAPSHOT: Optional['V4RegionCustomerResourcesReturnObjResourcesVOLUME_SNAPSHOT'] = None  # 磁盘快照
    VPC: Optional['V4RegionCustomerResourcesReturnObjResourcesVPC'] = None  # VPC
    Public_IP: Optional['V4RegionCustomerResourcesReturnObjResourcesPublic_IP'] = None  # 公网IP
    BMS: Optional['V4RegionCustomerResourcesReturnObjResourcesBMS'] = None  # 物理机
    NAT: Optional['V4RegionCustomerResourcesReturnObjResourcesNAT'] = None  # NAT
    Disk_Backup: Optional['V4RegionCustomerResourcesReturnObjResourcesDisk_Backup'] = None  # 磁盘备份
    Vm_Group: Optional['V4RegionCustomerResourcesReturnObjResourcesVm_Group'] = None  # 云主机组
    SNAPSHOT: Optional['V4RegionCustomerResourcesReturnObjResourcesSNAPSHOT'] = None  # 云主机快照
    ACLLIST: Optional['V4RegionCustomerResourcesReturnObjResourcesACLLIST'] = None  # ACL
    IP_POOL: Optional['V4RegionCustomerResourcesReturnObjResourcesIP_POOL'] = None  # 共享带宽
    IMAGE: Optional['V4RegionCustomerResourcesReturnObjResourcesIMAGE'] = None  # 私有镜像
    LB_LISTENER: Optional['V4RegionCustomerResourcesReturnObjResourcesLB_LISTENER'] = None  # 负载均衡监听器
    LOADBALANCER: Optional['V4RegionCustomerResourcesReturnObjResourcesLOADBALANCER'] = None  # 负载均衡
    OS_Backup: Optional['V4RegionCustomerResourcesReturnObjResourcesOS_Backup'] = None  # 操作系统备份
    TrafficMirror_Flow: Optional['V4RegionCustomerResourcesReturnObjResourcesTrafficMirror_Flow'] = None  # 镜像流量
    TrafficMirror_Filter: Optional['V4RegionCustomerResourcesReturnObjResourcesTrafficMirror_Filter'] = None  # 镜像流量
    CBR: Optional['V4RegionCustomerResourcesReturnObjResourcesCBR'] = None  # 云主机备份
    CERT: Optional['V4RegionCustomerResourcesReturnObjResourcesCERT'] = None  # 负载均衡证书
    CBR_VBS: Optional['V4RegionCustomerResourcesReturnObjResourcesCBR_VBS'] = None  # 磁盘存储备份


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesVM:
    vm_shutd_count: Optional[int] = None  # 已关机云主机数量
    expire_count: Optional[int] = None  # 过期云主机数量
    expire_running_count: Optional[int] = None  # 已过期的运行中云主机数量
    expire_shutd_count: Optional[int] = None  # 已过期的关机云主机数量
    vm_running_count: Optional[int] = None  # 运行中云主机数量
    total_count: Optional[int] = None  # 云主机总数
    cpu_count: Optional[int] = None  # CPU总数
    memory_count: Optional[int] = None  # 总内存大小
    detail_total_count: Optional[int] = None  # 云主机总数


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesVolume:
    vo_root_count: Optional[int] = None  # 系统盘数量
    vo_disk_count: Optional[int] = None  # 数据盘数量
    total_count: Optional[int] = None  # 磁盘总数
    detail_total_count: Optional[int] = None  # 磁盘总数
    total_size: Optional[int] = None  # 磁盘总大小
    vo_disk_size: Optional[int] = None  # 数据盘大小
    vo_root_size: Optional[int] = None  # 系统盘大小


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesVOLUME_SNAPSHOT:
    total_count: Optional[int] = None  # 磁盘快照总数
    detail_total_count: Optional[int] = None  # 磁盘快照总数


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesVPC:
    total_count: Optional[int] = None  # VPC总数
    detail_total_count: Optional[int] = None  # VPC总数


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesPublic_IP:
    total_count: Optional[int] = None  # 公网IP总数
    detail_total_count: Optional[int] = None  # 公网IP总数


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesBMS:
    total_count: Optional[int] = None  # 物理机总数
    detail_total_count: Optional[int] = None  # 物理机总数
    memory_count: Optional[int] = None  # 固定为0
    cpu_count: Optional[int] = None  # 固定为0
    bm_shutd_count: Optional[int] = None  # 固定为0
    expire_running_count: Optional[int] = None  # 固定为0
    bm_running_count: Optional[int] = None  # 固定为0
    expire_count: Optional[int] = None  # 固定为0
    expire_shutd_count: Optional[int] = None  # 固定为0


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesNAT:
    total_count: Optional[int] = None  # nat总数
    detail_total_count: Optional[int] = None  # nat总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesDisk_Backup:
    total_count: Optional[int] = None  # 磁盘备份总数
    detail_total_count: Optional[int] = None  # 磁盘备份总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesVm_Group:
    total_count: Optional[int] = None  # 云主机组总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesSNAPSHOT:
    total_count: Optional[int] = None  # 云主机快照总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesACLLIST:
    total_count: Optional[int] = None  # ACL总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesIP_POOL:
    total_count: Optional[int] = None  # 共享带宽总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesIMAGE:
    total_count: Optional[int] = None  # 私有镜像总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesLB_LISTENER:
    total_count: Optional[int] = None  # 负载均衡监听器总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesLOADBALANCER:
    total_count: Optional[int] = None  # 负载均衡总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesOS_Backup:
    total_count: Optional[int] = None  # 固定为0
    detail_total_count: Optional[int] = None  # 固定为0


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesTrafficMirror_Flow:
    total_count: Optional[int] = None  # 总量
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesTrafficMirror_Filter:
    total_count: Optional[int] = None  # 总量
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesCBR:
    total_count: Optional[int] = None  # 云主机备份总数
    detail_total_count: Optional[int] = None  # 云主机备份总数
    total_size: Optional[int] = None  # 云主机备份总大小
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesCERT:
    total_count: Optional[int] = None  # 负载均衡证书总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量


@dataclass_json
@dataclass
class V4RegionCustomerResourcesReturnObjResourcesCBR_VBS:
    total_count: Optional[int] = None  # 磁盘存储备份总数
    detail_total_count: Optional[int] = None  # 磁盘存储备份总数
    detail: Optional[Dict[str, int]] = None  # 对应资源池id下的数量
