from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsStatisticsInstanceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    projectID: Optional[str] = None  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10017248/10017961">创建企业项目</a>了解如何创建企业项目

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsStatisticsInstanceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsStatisticsInstanceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsStatisticsInstanceReturnObj:
    instanceStatistics: Optional['V4EcsStatisticsInstanceReturnObjInstanceStatistics'] = None  # 分页明细


@dataclass_json
@dataclass
class V4EcsStatisticsInstanceReturnObjInstanceStatistics:
    totalCount: Optional[int] = None  # 云主机总数
    RunningCount: Optional[int] = None  # 运行中的云主机数量
    shutdownCount: Optional[int] = None  # 关机数量
    expireCount: Optional[int] = None  # 过期数量
    expireRunningCount: Optional[int] = None  # 过期运行中数量
    expireShutdownCount: Optional[int] = None  # 过期已关机数量
    cpuCount: Optional[int] = None  # cpu数量
    memoryCount: Optional[int] = None  # 内存总量，单位为GB
