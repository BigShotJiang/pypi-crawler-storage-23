from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4OrderUpgradeQueryPriceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    resourceUUID: str  # 资源uuid
    resourceType: str  # 资源类型
    flavorName: Optional[str] = None  # 云主机规格，当resourceType为VM时必填
    bandwidth: Optional[int] = None  # 带宽大小，当resourceType为IP时必填
    diskSize: Optional[int] = None  # 磁盘大小，当resourceType为EBS时必填
    natType: Optional[str] = None  # nat规格，当resourceType为NAT时必填
    ipPoolBandwidth: Optional[int] = None  # 共享带宽大小，当resourceType为IP_POOL时必填
    elbType: Optional[str] = None  # 性能保障型负载均衡类型(支持standardI/standardII/enhancedI/enhancedII/higherI)，当resourceType为PGELB时必填
    cbrValue: Optional[int] = None  # 存储库大小，100-1024000GB，当resourceType为CBR_VM或CBR_VBS时必填

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderUpgradeQueryPriceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4OrderUpgradeQueryPriceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderUpgradeQueryPriceReturnObj:
    totalPrice: Optional[float] = None  # 总价格
    discountPrice: Optional[float] = None  # 折后价格
    finalPrice: Optional[float] = None  # 最终价格
    subOrderPrices: Optional[List['V4OrderUpgradeQueryPriceReturnObjSubOrderPrices']] = None  # 子订单价格信息


@dataclass_json
@dataclass
class V4OrderUpgradeQueryPriceReturnObjSubOrderPrices:
    serviceTag: Optional[str] = None  # 服务类型
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
    orderItemPrices: Optional[List['V4OrderUpgradeQueryPriceReturnObjSubOrderPricesOrderItemPrices']] = None  # 资源价格信息


@dataclass_json
@dataclass
class V4OrderUpgradeQueryPriceReturnObjSubOrderPricesOrderItemPrices:
    resourceType: Optional[str] = None  # 资源类型
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
