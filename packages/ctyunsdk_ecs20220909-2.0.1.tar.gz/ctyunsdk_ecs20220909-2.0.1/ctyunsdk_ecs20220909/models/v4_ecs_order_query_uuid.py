from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsOrderQueryUuidRequest(CtyunOpenAPIRequest):
    masterOrderID: str  # 订单ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsOrderQueryUuidResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsOrderQueryUuidReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsOrderQueryUuidReturnObj:
    orderStatus: Optional[str] = None  # 订单状态，具体值代表含义。<br />1：待支付，<br />2：已支付，<br />3：完成，<br />4：取消，<br />5：施工失败，<br />7：正在支付中，<br />8：待审核，<br />9：审核通过，<br />10：审核未通过，<br />11：撤单完成，<br />12：退订中，<br />13：退订完成，<br />14：开通中，<br />15：变更移除，<br />16：自动撤单中，<br />17：手动撤单中，<br />18：终止中，<br />22：支付失败，<br />\-2：待撤单，<br />\-1：未知，<br />0：错误，<br />140：已初始化，<br />999：逻辑错误。
    instanceIDList: Optional[List[str]] = None  # 云主机的ID列表，订单处于创建中，返回为空列表。待订单完成后才能正常返回ID
