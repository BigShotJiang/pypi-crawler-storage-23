from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsKeypairCreateKeypairRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    keyPairName: str  # 密钥对名称。满足以下规则：只能由数字、字母、-组成，不能以数字和-开头、以-结尾，且长度为2-63字符
    projectID: Optional[str] = None  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10017248/10017961">创建企业项目</a>了解如何创建企业项目<br />注：默认值为"0"
    keyPairDescription: Optional[str] = None  # 密钥对描述。满足以下规则：长度为0~255个字符。<br />注：只多可用区资源池支持描述
    labelList: Optional[List['V4EcsKeypairCreateKeypairRequestLabelList']] = None  # 标签信息列表，注：单个密钥对最多可绑定10个标签；密钥对创建完成后，此时标签仍可能未绑定，需等待一段时间（0-10分钟）；当前仅多可用区资源池支持标签功能。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsKeypairCreateKeypairRequestLabelList:
    labelKey: str  # 标签键，长度限制1-128字符，首字符不能为空格，注：同一个密钥对绑定多个标签时，标签键不可重复
    labelValue: str  # 标签值，长度限制1-128字符，首字符不能为空格，


@dataclass_json
@dataclass
class V4EcsKeypairCreateKeypairResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsKeypairCreateKeypairReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsKeypairCreateKeypairReturnObj:
    publicKey: Optional[str] = None  # 密钥对的公钥
    privateKey: Optional[str] = None  # 密钥对的私钥
    keyPairName: Optional[str] = None  # 密钥对名称
    fingerPrint: Optional[str] = None  # 密钥对的指纹，采用MD5信息摘要算法
    keyPairID: Optional[str] = None  # 密钥对的ID
    keyPairDescription: Optional[str] = None  # 密钥对的描述
