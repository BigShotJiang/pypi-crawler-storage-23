from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsFlavorUpdateSpecListRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceID: str  # 云主机ID，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorUpdateSpecListResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsFlavorUpdateSpecListReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorUpdateSpecListReturnObj:
    flavorList: Optional[List['V4EcsFlavorUpdateSpecListReturnObjFlavorList']] = None  # 规格列表


@dataclass_json
@dataclass
class V4EcsFlavorUpdateSpecListReturnObjFlavorList:
    cpuInfo: Optional[str] = None  # cpu架构
    baseBandwidth: Optional[float] = None  # 基准带宽
    flavorName: Optional[str] = None  # 云主机规格名称
    flavorType: Optional[str] = None  # 规格类型，取值范围：[CPU、CPU_C3、CPU_C6、CPU_C7、CPU_c7ne、CPU_C8、CPU_D3、CPU_FC1、CPU_FM1、CPU_FS1、CPU_HC1、CPU_HM1、CPU_HS1、CPU_IP3、CPU_IR3、CPU_IP3_2、CPU_IR3_2、CPU_KC1、CPU_KM1、CPU_KS1、CPU_M2、CPU_M3、CPU_M6、CPU_M7、CPU_M8、CPU_S2、CPU_S3、CPU_S6、CPU_S7、CPU_S8、CPU_s8r、GPU_N_V100_V_FMGQ、GPU_N_V100_V、GPU_N_V100S_V、GPU_N_V100S_V_FMGQ、GPU_N_T4_V、GPU_N_G7_V、GPU_N_V100、GPU_N_V100_SHIPINYUN、GPU_N_V100_SUANFA、GPU_N_P2V_RENMIN、GPU_N_V100S、GPU_N_T4、GPU_N_T4_AIJISUAN、GPU_N_T4_ASR、GPU_N_T4_JX、GPU_N_T4_SHIPINYUN、GPU_N_T4_SUANFA、GPU_N_T4_YUNYOUXI、GPU_N_PI7、GPU_N_P8A、GPU_A_PAK1、GPU_C_PCH1]，支持类型会随着功能升级增加
    flavorSeries: Optional[str] = None  # 云主机规格系列，规格系列说明：<br />s（通用型），<br />c（计算增强型），<br />m（内存优化型），<br />hs（海光通用型），<br />hc（海光计算增强型），<br />hm（海光内存优化型），<br />fs（飞腾通用型），<br />fc（飞腾计算增强型），<br />fm（飞腾内存优化型），<br />ks（鲲鹏通用型），<br />kc（鲲鹏计算增强型），<br />km（鲲鹏内存优化型），<br />p（GPU计算加速型），<br />g（GPU图像加速基础型），<br />ip3（超高IO型）
    nicMultiQueue: Optional[int] = None  # 网卡多队列数目
    pps: Optional[int] = None  # 最大收发包限制
    flavorCPU: Optional[int] = None  # VCPU个数
    flavorRAM: Optional[int] = None  # 内存
    bandwidth: Optional[float] = None  # 带宽
    flavorID: Optional[str] = None  # 云主机规格ID
    gpuVendor: Optional[str] = None  # GPU厂商
    videoMemSize: Optional[int] = None  # GPU显存大小
    gpuType: Optional[str] = None  # GPU类型，取值范围：T4、V100、V100S、A10、A100、atlas 300i pro、mlu370-s4，支持类型会随着功能升级增加
    gpuCount: Optional[int] = None  # GPU设备数量
    available: Optional[bool] = None  # 是否可用（true：可用；false：不可用，已售罄）
    azList: Optional[List[str]] = None  # 多az名称列表（非多可用区为["default"]）
    flavorSeriesName: Optional[str] = None  # 规格系列名称，参照参数flavorSeries说明
    dedicatedAreaZone: Optional[str] = None  # 可用分区ID
    dedicatedAreaZoneName: Optional[str] = None  # 可用分区名称
