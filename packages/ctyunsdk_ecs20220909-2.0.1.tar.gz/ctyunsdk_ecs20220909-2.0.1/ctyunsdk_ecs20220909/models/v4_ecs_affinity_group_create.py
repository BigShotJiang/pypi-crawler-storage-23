from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsAffinityGroupCreateRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    affinityGroupName: str  # 云主机组名称，满足以下规则：长度在1-64个字符，只能由中文、英文字母、数字、下划线_、中划线-、点.组成
    policyType: Optional[int] = None  # 云主机组策略类型。<br />取值范围：<br />0（强制反亲和性），<br />1（强制亲和性），<br />2（反亲和性），<br />3（亲和性) <br />注：默认值2

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsAffinityGroupCreateResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsAffinityGroupCreateReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsAffinityGroupCreateReturnObj:
    affinityGroupID: Optional[str] = None  # 云主机组ID
    affinityGroupName: Optional[str] = None  # 云主机组名称
    affinityGroupPolicy: Optional['V4EcsAffinityGroupCreateReturnObjAffinityGroupPolicy'] = None  # 云主机组策略


@dataclass_json
@dataclass
class V4EcsAffinityGroupCreateReturnObjAffinityGroupPolicy:
    policyType: Optional[int] = None  # 云主机组策略类型。<br />取值范围：<br />0（强制反亲和性），<br />1（强制亲和性），<br />2（反亲和性），<br />3（亲和性)
    policyTypeName: Optional[str] = None  # 云主机组策略类型名称。<br />取值范围：<br />anti-affinity（强制反亲和性），<br />affinity（强制亲和性），<br />soft-anti-affinity（反亲和性），<br />soft-affinity（亲和性)
