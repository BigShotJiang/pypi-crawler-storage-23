from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsFlavorQueryOptionsRequest(CtyunOpenAPIRequest):
    def __post_init__(self):
        super().__init__()



@dataclass_json
@dataclass
class V4EcsFlavorQueryOptionsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsFlavorQueryOptionsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorQueryOptionsReturnObj:
    flavorNameScope: Optional[List[str]] = None  # 规格名称
    flavorCPUScope: Optional[List[str]] = None  # 规格vcpu
    flavorRAMScope: Optional[List[str]] = None  # 规格内存大小
    flavorFamilyScope: Optional[List[str]] = None  # 规格族名称
    gpuConfigScope: Optional[List[str]] = None  # GPU配置信息
    localDiskSizeScope: Optional[List[str]] = None  # 本地盘配置
