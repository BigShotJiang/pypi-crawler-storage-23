from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4RegionGetSummaryRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetSummaryResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4RegionGetSummaryReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetSummaryReturnObj:
    regionID: Optional[str] = None  # 资源池ID
    regionParent: Optional[str] = None  # 资源池所属省份
    regionName: Optional[str] = None  # 资源池名称
    regionType: Optional[str] = None  # 资源池类型
    isMultiZones: Optional[bool] = None  # 是否多可用区资源池
    zoneList: Optional[List[str]] = None  # 可用区列表
    cpuArches: Optional[List[str]] = None  # 资源池cpu架构信息
    regionVersion: Optional[str] = None  # 资源池版本
    dedicated: Optional[bool] = None  # 是否是专属资源池，账户可能访问的是一个自己可见的专属资源池
    province: Optional[str] = None  # 省份
    city: Optional[str] = None  # 城市
    openapiAvailable: Optional[bool] = None  # 是否支持通过OpenAPI访问
