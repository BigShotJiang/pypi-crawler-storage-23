from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsFlavorAvailableRegionRequest(CtyunOpenAPIRequest):
    flavorNameList: Optional[str] = None  # 云主机规格名称列表，多个名称逗号隔开
    flavorFamilyList: Optional[str] = None  # 云主机规格族列表，多个规格族逗号分隔
    flavorCPUList: Optional[str] = None  # 云主机规格vcpu个数列表，多个vcpu逗号分隔
    flavorRAMList: Optional[str] = None  # 云主机规格内存大小列表，多个内存大小逗号分隔
    localDiskSizeList: Optional[str] = None  # 本地盘容量配置列表，多个容量配置逗号分隔
    gpuConfigList: Optional[str] = None  # GPU配置列表列表，多个容量配置逗号分隔
    pageNo: Optional[str] = None  # 页码，取值范围：正整数（≥1），注：默认值为1，这里为字符串
    pageSize: Optional[str] = None  # 每页记录数目，取值范围：[1, 50]，注：默认值为10，这里为字符串

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorAvailableRegionResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsFlavorAvailableRegionReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorAvailableRegionReturnObj:
    currentCount: Optional[int] = None  # 当前页记录数目
    totalCount: Optional[int] = None  # 总记录数
    totalPage: Optional[int] = None  # 总页数
    availableStatusResourceList: Optional[List['V4EcsFlavorAvailableRegionReturnObjAvailableStatusResourceList']] = None  # 规格及可售地域组合


@dataclass_json
@dataclass
class V4EcsFlavorAvailableRegionReturnObjAvailableStatusResourceList:
    flavorName: Optional[str] = None  # 规格名称
    flavorCPU: Optional[int] = None  # 规格vcpu
    flavorRAM: Optional[int] = None  # 规格内存大小
    flavorFamily: Optional[str] = None  # 规格族名称
    gpuConfig: Optional[str] = None  # GPU配置信息
    localDiskConfig: Optional[str] = None  # 本地盘配置
    availableStatusRegionList: Optional[List['V4EcsFlavorAvailableRegionReturnObjAvailableStatusResourceListAvailableStatusRegionList']] = None  # 可售地域及余量组合


@dataclass_json
@dataclass
class V4EcsFlavorAvailableRegionReturnObjAvailableStatusResourceListAvailableStatusRegionList:
    azName: Optional[str] = None  # 可用区名称
    regionID: Optional[str] = None  # 资源池id
    regionName: Optional[str] = None  # 资源池名称
    available: Optional[bool] = None  # 规格是否可用（true: 可用，未售罄；不可用，已售罄）
