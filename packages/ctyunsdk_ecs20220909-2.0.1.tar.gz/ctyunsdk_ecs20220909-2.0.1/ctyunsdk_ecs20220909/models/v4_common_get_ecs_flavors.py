from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4CommonGetEcsFlavorsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    azName: Optional[str] = None  # 多az可用区名称（4.0场景）
    series: Optional[str] = None  # 系列

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4CommonGetEcsFlavorsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4CommonGetEcsFlavorsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4CommonGetEcsFlavorsReturnObj:
    totalCount: Optional[int] = None  # 总条数
    results: Optional[List['V4CommonGetEcsFlavorsReturnObjResults']] = None  # 规格列表


@dataclass_json
@dataclass
class V4CommonGetEcsFlavorsReturnObjResults:
    flavorID: Optional[str] = None  # 规格id
    specName: Optional[str] = None  # 规格名称
    flavorType: Optional[str] = None  # 规格类型
    flavorName: Optional[str] = None  # 规格类型名称
    cpuNum: Optional[int] = None  # cpu核数
    memSize: Optional[int] = None  # 内存大小
    multiQueue: Optional[int] = None  # 网卡多队列数
    pps: Optional[int] = None  # 网络最大收发包能力  (万PPS)
    bandwidthBase: Optional[float] = None  # 基准带宽 (Gbps)
    bandwidthMax: Optional[float] = None  # 最大带宽 (Gbps)
    cpuArch: Optional[str] = None  # cpu架构 （x86架构、arm架构）
    series: Optional[str] = None  # 系列
    azList: Optional[List[str]] = None  # 支持的az名称列表（4.0场景）(未传azName情况)
    nicCount: Optional[int] = None  # 当前规格主机最大可挂载网卡数 (cpu类型的会返回，其他类型没有，且非必返回字段)
    ctLimitCount: Optional[int] = None  # 最大连接数 (cpu类型的会返回，其他类型没有，且非必返回字段)
