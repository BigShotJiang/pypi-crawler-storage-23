from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4JobInfoRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    jobID: str  # 异步任务ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4JobInfoResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4JobInfoReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4JobInfoReturnObj:
    jobID: Optional[str] = None  # 异步任务ID
    status: Optional[int] = None  # 任务状态 (0:执行中 1:执行成功 2:执行失败)
    jobStatus: Optional[str] = None  # job任务状态('executing':执行中, 'success':执行成功, 'fail':执行失败)
    resourceId: Optional[str] = None  # 资源ID
    fields: Optional['V4JobInfoReturnObjFields'] = None  # 任务信息


@dataclass_json
@dataclass
class V4JobInfoReturnObjFields:
    taskName: Optional[str] = None  # 任务名
