from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesRequest(CtyunOpenAPIRequest):
    clientToken: str  # 客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一，使用同一个ClientToken值，其他请求参数相同时，则代表为同一个请求。保留时间为24小时
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceID: str  # 已有的云主机ID，获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>
    instanceName: str  # 云主机名称。不同操作系统下，云主机名称规则有差异。<br />Windows：长度为2-15个字符，允许使用大小写字母、数字或连字符（-）。不能以连字符（-）开头或结尾，不能连续使用连字符（-），也不能仅使用数字；<br />其他操作系统：长度为2-64字符，允许使用点（.）分隔字符成多段，每段允许使用大小写字母、数字或连字符（-），但不能连续使用点号（.）或连字符（-），不能以点号（.）或连字符（-）开头或结尾，也不能仅使用数字
    displayName: str  # 云主机显示名称，长度为2-63字符
    extIP: str  # 是否使用弹性公网IP，默认不使用弹性公网IP。<br />若您需要更改，请重新设置。取值范围：<br />0（不使用），<br />1（自动分配），<br />2（使用已有）。<br />注：自动分配弹性公网，默认分配IPv4弹性公网，需填写带宽大小，如需ipv6请填写弹性IP版本（即参数extIP="1"时，需填写参数bandwidth、ipVersion，ipVersion含默认值ipv4）；<br />使用已有弹性公网，请填写弹性公网IP的ID，默认为ipv4版本，如使用已有ipv6，请填写弹性ip版本（即参数extIP="2"时，需填写eipID或ipv6AddressID，同时ipv6情况下请填写ipVersion）
    azName: Optional[str] = None  # 可用区名称，默认使用原云主机的可用区。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解可用区 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5855&data=87">资源池可用区查询</a><br />注：查询结果中zoneList内返回存在可用区名称(即多可用区，本字段填写实际可用区名称)，若查询结果中zoneList为空（即为单可用区,无需填写本字段）
    flavorID: Optional[str] = None  # 云主机规格ID，默认使用原云主机的规格。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026730/10118193">规格说明</a>了解弹性云主机的选型基本信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8327&data=87">查询一个或多个云主机规格资源</a><br />注：同一规格名称在不同资源池不同可用区的规格ID是不同的，调用前需确认规格ID是否归属当前资源池，多可用区资源池确认是否归属当前可用区
    imageID: Optional[str] = None  # 镜像ID，默认使用原云主机的镜像。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026730/10030151">镜像概述</a>来了解云主机镜像<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=23&api=4763&data=89">查询可以使用的镜像资源</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=23&api=4765&data=89">创建私有镜像（云主机系统盘）</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=23&api=5230&data=89">创建私有镜像（云主机数据盘）</a><br />注：同一镜像名称在不同资源池的镜像ID是不同的，调用前需确认镜像ID是否归属当前资源池
    bootDiskType: Optional[str] = None  # 系统盘类型，默认使用原云主机的盘类型。<br />取值范围：<br />SATA（普通IO），<br />SAS（高IO），<br />SSD（超高IO），<br />SSD-genric（通用型SSD），<br />FAST-SSD（极速型SSD），<br />XSSD（XSSD-0、XSSD-1、XSSD-2）您可以查看<a href="https://www.ctyun.cn/document/10027696/10162918">磁盘类型及性能介绍</a>来了解磁盘类型及其对应性能指标，查看<a href="https://www.ctyun.cn/document/10027696/10179346">X系列云硬盘</a>来了解X系列云硬盘
    bootDiskSize: Optional[int] = None  # 系统盘大小单位为GB，默认使用原云主机的盘大小。<br />非X系列云盘，单个系统盘取值范围：[所选镜像大小，2048]；X系列系云盘，单个系统盘取值范围：[所选镜像大小，2048]，如果为XSSD-2类型，单个系统盘取值范围：[max(所选镜像大小，512)~2048]，您可以查看<a href="https://www.ctyun.cn/document/10027696/10027936">磁盘使用限制</a>来了解磁盘容量。<br />注：创建云主机过程中会存在单位转换，因此该参数只能传入整型，如果填写小数值则会被取整，影响到涉及计费
    bootDiskIsEncrypt: Optional[bool] = None  # 系统盘是否加密，默认与原云主机的盘加密情况一致。<br />取值范围：true（加密）、false（不加密）
    bootDiskCmkID: Optional[str] = None  # 系统盘加密密钥ID，若原云主机盘加密，默认使用原云主机盘的密钥。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10014047/10789926">密钥管理概述</a>了解密钥<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=7&api=5840&data=107&isNormal=1&vid=101">批量查询密钥信息</a><br />注：bootDiskCmkID与bootDiskIsEncrypt组合使用，需要填写系统盘是否加密（bootDiskIsEncrypt） 为true；暂不支持包周期密钥
    bootDiskProvisionedIops: Optional[int] = None  # 预配置iops值，默认使用原云主机盘设置的iops值。<br />若您需要更改，请重新设置。系统盘类型为XSSD时，可设置盘的预配置iops值，其他类型的盘不支持设置。当provisionedIops为0或者不传时，表示不配置iops值。当配置iops值时，最小值为1。
    vpcID: Optional[str] = None  # 虚拟私有云ID，默认使用原云主机虚拟私有云。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026755/10028310">产品定义-虚拟私有云</a>来了解虚拟私有云<br />&#32;获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4814&data=94">查询VPC列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4811&data=94">创建VPC</a><br />注：在多可用区类型资源池下，vpcID通常为“vpc-”开头，非多可用区类型资源池vpcID为uuid格式
    onDemand: Optional[bool] = None  # 购买方式，默认使用原云主机的付费方式。<br />若您需要更改，请重新设置。取值范围：<br />false（按周期），<br />true（按需）<br />您可以查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a>了解云主机的计费模式<br />注：按周期（false）创建云主机需要同时指定cycleCount和cycleType参数
    networkCardList: Optional[List['V4EcsCreateSameConfigInstancesRequestNetworkCardList']] = None  # 网卡信息列表，默认使用原云主机的网卡（网卡和网卡数量，但内网IP地址自动分配）。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026730/10225195">弹性网卡概述</a>了解弹性网卡相关信息
    projectID: Optional[str] = None  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理，默认使用原云主机的企业项目。<br />若您需要更改，可以通过查看<a href="https://www.ctyun.cn/document/10017248/10017961">创建企业项目</a>了解如何创建企业项目
    secGroupList: Optional[List[str]] = None  # 安全组ID列表，默认使用原云主机的安全组。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026755/10028520">安全组概述</a>了解安全组相关信息 <br />获取： <br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4817&data=94">查询用户安全组列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4821&data=94">创建安全组</a><br />注：在多可用区类型资源池下，安全组ID通常以“sg-”开头，非多可用区类型资源池安全组ID为uuid格式；默认使用默认安全组，无默认安全组情况下请填写该参数
    dataDiskList: Optional[List['V4EcsCreateSameConfigInstancesRequestDataDiskList']] = None  # 数据盘信息列表，默认使用原云主机的盘类型、大小等。<br />若您需要更改，请重新设置。同一云主机下最多可挂载8块数据盘
    ipVersion: Optional[str] = None  # 弹性IP版本，默认不使用弹性公网IP。<br />若您需要更改，取值范围：<br />ipv4（v4地址），<br />ipv6（v6地址），<br />不指定默认为ipv4。注：请先确认该资源池是否支持ipv6（多可用区类资源池暂不支持）
    bandwidth: Optional[int] = None  # 带宽大小，单位为Mbit/s，取值范围：[1, 2000]
    ipv6AddressID: Optional[str] = None  # 弹性公网IPv6的ID，默认不使用弹性公网IP。<br />若您需要更改，填写该参数时请填写ipVersion为ipv6
    eipID: Optional[str] = None  # 弹性公网IP的ID，默认不使用弹性公网IP。<br />若您需要使用弹性IP，可以查看<a href="https://www.ctyun.cn/document/10026753/10026909">产品定义-弹性IP</a>来了解弹性公网IP <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=8652&data=94&isNormal=1&vid=88">查询指定地域已创建的弹性 IP</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=5723&data=94&vid=88">创建弹性 IP</a>
    affinityGroupID: Optional[str] = None  # 云主机组ID，默认使用原云主机的云主机组。<br />若您需要更改，获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8324&data=87">查询云主机组列表或者详情</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8316&data=87">&#32;创建云主机组</a>
    keyPairID: Optional[str] = None  # 密钥对ID，若采用密钥方式登录，默认使用原云主机的密钥。<br />若您需要更改，您可以查看<a href="https://www.ctyun.cn/document/10026730/10230540">密钥对</a>来了解密钥对相关内容 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8342&data=87">查询一个或多个密钥对</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8344&data=87">创建一对SSH密钥对</a>。<br />注：密码和密钥对ID，请避免同时使用，同时使用时只有绑定密钥生效
    userName: Optional[str] = None  # 用户名，若采用密码方式登录，请重新设置用户名。当操作系统为非Windows使用密码登录时，用户名取值范围：<br />root（系统超级用户），<br />ecs-user（系统普通用户），<br />注：非Windows云主机用户默认为root；该参数大小写敏感
    userPassword: Optional[str] = None  # 用户密码，若采用密码方式登录，请重新设置密码。<br />满足以下规则：<br />长度在8～30个字符；<br />必须包含大写字母、小写字母、数字以及特殊符号中的三项；<br />特殊符号可选：()`-!@#$%^&*_-+=｜{}[]:;'<>,.?/且不能以斜线号 / 开头；<br />不能包含3个及以上连续字符；<br />Linux镜像不能包含镜像用户名（root）、用户名的倒序（toor）、用户名大小写变化（如RoOt、rOot等），若Linux镜像用户名为ecs-user，密码不能包含用户名(ecs-user)、用户名的倒序(resu-sce)、用户名大小写变化(如ECS-USER等)；<br />Windows镜像不能包含镜像用户名（Administrator）、用户名大小写变化（adminiSTrator等<br />注：密码和密钥对ID，请避免同时使用，同时使用时只有绑定密钥生效
    cycleCount: Optional[int] = None  # 订购时长，若您采用包周期的订购方式，请重新设置订购时长。<br />该参数需要与cycleType一同使用，最长订购周期为60个月（5年）；cycleType与cycleCount一起填写；按量付费（即onDemand为true）时，无需填写该参数（填写无效）
    cycleType: Optional[str] = None  # 订购周期类型，若您采用包周期的订购方式，请重新设置订购周期类型。<br />取值范围：<br />MONTH：按月，<br />YEAR：按年。注：cycleType与cycleCount一起填写；按量付费（即onDemand为true）时，无需填写该参数（填写无效）
    autoRenewStatus: Optional[int] = None  # 是否自动续订，默认不续订。<br />若您需要更改，请重新设置。需要取值范围：<br />0（不续费），<br />1（自动续费），<br />注：按月购买，自动续订周期为1个月；按年购买，自动续订周期为1年
    userData: Optional[str] = None  # 用户自定义数据，需要重新设置。以Base64方式编码，Base64编码后的长度限制为1-16384字符。
    orderCount: Optional[int] = None  # 购买数量，需要重新设置。取值范围：[1, 50]。注：不填则默认为1
    payVoucherPrice: Optional[float] = None  # 代金券，满足以下规则：<br />两位小数，不足两位自动补0，超过两位小数无效；<br />不可为负数；<br />注：字段为0时表示不使用代金券，默认不使用代金券。
    labelList: Optional[List['V4EcsCreateSameConfigInstancesRequestLabelList']] = None  # 标签信息列表，默认使用原云主机的标签。<br />若您需要更新，请重新设置。单台云主机最多可绑定10个标签；主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）。
    gpuDriverKits: Optional[str] = None  # GPU云主机安装驱动的工具包，默认使用原云主机的GPU云主机安装驱动的工具包。<br />若您需要更改，请重新设置。仅在同时选择NVIDIA显卡、计算加速型、linux公共镜像三个条件下，支持安装驱动。
    monitorService: Optional[bool] = None  # 监控参数，默认安装监控。<br />若您需要更改，请重新设置。支持通过该参数指定云主机在创建后是否开启详细监控，取值范围： <br />false（不开启），<br />true（开启）<br />若指定该参数为true或不指定该参数，云主机内默认开启最新详细监控服务。<br />若指定该参数为false，默认公共镜像不开启最新监控服务；私有镜像使用镜像中保留的监控服务。<br />说明：仅部分资源池支持monitorService参数，详细请参考<a href="https://www.ctyun.cn/document/10026730/10325957">监控Agent概览</a>。
    privateDnsNameOptions: Optional[List[str]] = None  # 内网DNS域名解析类型，取值范围：<br />IP_TO_IPV4，<br />INSTANCE_ID_TO_IPV4，<br />INSTANCE_ID_TO_IPV6，<br />IPV4_TO_IP <br />注：内网DNS只支持绑定主网卡的主内网IP；只有当主网卡的子网支持ipv6时，内网域名解析类型支持选择INSTANCE_ID_TO_IPV6；大小写敏感
    trustInstance: Optional[bool] = None  # 是否开启可信系统，默认与原云主机保持一致。<br />若您需要更新，请重新设置。取值范围：<br />true：开启<br />false：不开启。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesRequestNetworkCardList:
    nicName: Optional[str] = None  # 该参数暂时无法使用。网卡名称，长度2~32，支持拉丁字母、中文、数字、下划线、连字符，中文或英文字母开头，不能以http:或https:开头
    fixedIP: Optional[str] = None  # 内网IPv4地址，请重新设置。当购买数量超过1时（orderCount>1），默认从该ip批量递增创建云主机，若递增中有占用过的ip则跳过，若批量递增内网ip创建时数量不足，则会报错，无法创建。<br />注：不可使用已占用IP；部分资源池不支持批量递增内网ip创建云主机；订单数量大于1时且指定了该参数，则创建参数中不同网卡的子网id不可重复（即orderCount>1，fixedIP存在，networkCardList参数中不可出现重复的subnetID），
    isMaster: Optional[bool] = None  # 是否主网卡，默认与原云主机网卡设置情况相同。<br />若您需要更改，请重新设置。取值范围：<br />true（表示主网卡），<br />false（表示扩展网卡）<br />注：只能含有一个主网卡
    subnetID: Optional[str] = None  # 子网ID，默认使用原云主机的子网。<br />若您需要更改，请重新设置。您可以查看<a href="https://www.ctyun.cn/document/10026755/10098380">基本概念</a>来查找子网的相关定义 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=8659&data=94">查询子网列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4812&data=94">创建子网</a><br />注：在多可用区类型资源池下，subnetID通常以“subnet-”开头，非多可用区类型资源池subnetID为uuid格式


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesRequestDataDiskList:
    diskMode: Optional[str] = None  # 云硬盘属性，默认使用原云主机盘属性。<br />若您需要更改，请重新设置。取值范围：<br />FCSAN（光纤通道协议的SAN网络），<br />ISCSI（小型计算机系统接口），<br />VBD（虚拟块存储设备）<br />您可以查看<a href="https://www.ctyun.cn/document/10027696/10162960">磁盘模式及使用方法</a><br />注：默认为VBD
    diskType: Optional[str] = None  # 磁盘类型，默认使用原云主机盘类型。<br />若您需要更改，请重新设置。取值范围：<br />SATA（普通IO），<br />SAS（高IO），<br />SSD（超高IO），<br />SSD-genric（通用型SSD），<br />FAST-SSD（极速型SSD），<br />XSSD（XSSD-0、XSSD-1、XSSD-2）您可以查看<a href="https://www.ctyun.cn/document/10027696/10162918">磁盘类型及性能介绍</a>来了解磁盘类型及其对应性能指标，查看<a href="https://www.ctyun.cn/document/10027696/10179346">X系列云硬盘</a>来了解X系列云硬盘
    diskSize: Optional[int] = None  # 磁盘容量，单位为GB，默认使用原云主机盘容量。<br />若您需要更改，请重新设置。非X系列云盘，单个数据盘取值范围：[10，32768]；X系列云盘，单个数据盘取值范围：[20，65536]，如果为XSSD-2类型，单个数据盘取值范围：[512~65536]。您可以查看<a href="https://www.ctyun.cn/document/10027696/10027936">磁盘使用限制</a>来了解磁盘容量
    isEncrypt: Optional[bool] = None  # 磁盘是否加密，默认与原云主机盘加密情况一致。<br />若您需要更改，请重新设置。取值范围：true（加密）、false（不加密），注：默认值false；若该参数为true且不填写cmkID（加密密钥ID），则生成默认密钥（不在密钥列表中）进行加密
    cmkID: Optional[str] = None  # 加密密钥ID，若原云主机盘加密，默认使用原云主机盘的密钥。<br />若您需要更改，请重新设置。加密数据盘填写该参数，同时需要填写数据盘是否加密（bootDiskIsEncrypt） 为true；暂不支持包周期密钥
    provisionedIops: Optional[int] = None  # 预配置iops值，默认使用原云主机盘设置的iops值。<br />若您需要更改，请重新设置。系统盘类型为XSSD时，可设置盘的预配置iops值，其他类型的盘不支持设置。当provisionedIops为0或者不传时，表示不配置iops值。当配置iops值时，最小值为1


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesRequestLabelList:
    labelKey: str  # 标签键，默认使用原云主机的标签键。<br />若您需要更改，请重新设置。长度限制1-32字符，注：同一台云主机绑定多个标签时，标签键不可重复
    labelValue: str  # 标签值，默认使用原云主机的标签值。<br />若您需要更改，请重新设置。长度限制1-32字符


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsCreateSameConfigInstancesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsCreateSameConfigInstancesReturnObj:
    masterOrderID: Optional[str] = None  # 主订单ID。调用方在拿到masterOrderID之后，可以使用materOrderID进一步确认订单状态及资源状态<br />查询订单状态及资源UUID: <br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>
    masterOrderNO: Optional[str] = None  # 订单号
    masterResourceID: Optional[str] = None  # 主资源ID
    regionID: Optional[str] = None  # 资源池ID
