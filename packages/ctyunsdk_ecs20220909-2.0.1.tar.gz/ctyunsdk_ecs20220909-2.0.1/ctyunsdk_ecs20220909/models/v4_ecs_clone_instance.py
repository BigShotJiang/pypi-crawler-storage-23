from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsCloneInstanceRequest(CtyunOpenAPIRequest):
    clientToken: str  # 客户端存根，用于保证订单幂等性。保留时间为24小时，使用同一个clientToken值，则代表为同一个请求
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceID: str  # 被克隆云主机ID，获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>
    instanceName: str  # 云主机名称。不同操作系统下，云主机名称规则有差异。<br />Windows：长度为2-15个字符，允许使用大小写字母、数字或连字符（-）。不能以连字符（-）开头或结尾，不能连续使用连字符（-），也不能仅使用数字；<br />其他操作系统：长度为2-64字符，允许使用点（.）分隔字符成多段，每段允许使用大小写字母、数字或连字符（-），但不能连续使用点号（.）或连字符（-），不能以点号（.）或连字符（-）开头或结尾，也不能仅使用数字
    displayName: str  # 云主机显示名称，长度为2-63字符
    extIP: str  # 是否使用弹性公网IP，默认不使用弹性公网IP。<br />若您需要更改，请重新设置。取值范围：<br />0（不使用），<br />1（自动分配），<br />2（使用已有）。<br />注：自动分配弹性公网，默认分配IPv4弹性公网，需填写带宽大小，如需ipv6请填写弹性IP版本（即参数extIP="1"时，需填写参数bandwidth、ipVersion，ipVersion含默认值ipv4）；<br />使用已有弹性公网，请填写弹性公网IP的ID，默认为ipv4版本，如使用已有ipv6，请填写弹性ip版本（即参数extIP="2"时，需填写eipID或ipv6AddressID，同时ipv6情况下请填写ipVersion）
    vpcID: Optional[str] = None  # 虚拟私有云ID，默认使用原云主机虚拟私有云。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026755/10028310">产品定义-虚拟私有云</a>来了解虚拟私有云<br />&#32;获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4814&data=94">查询VPC列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4811&data=94">创建VPC</a><br />注：在多可用区类型资源池下，vpcID通常为“vpc-”开头，非多可用区类型资源池vpcID为uuid格式
    onDemand: Optional[bool] = None  # 购买方式，默认使用原云主机的付费方式。<br />若您需要更改，请重新设置。取值范围：<br />false（按周期），<br />true（按需）<br />您可以查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a>了解云主机的计费模式<br />注：按周期（false）创建云主机需要同时指定cycleCount和cycleType参数
    secGroupList: Optional[List[str]] = None  # 安全组ID列表，默认使用原云主机的安全组。<br />若您需要更改，可以查看<a href="https://www.ctyun.cn/document/10026755/10028520">安全组概述</a>了解安全组相关信息 <br />获取： <br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4817&data=94">查询用户安全组列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4821&data=94">创建安全组</a><br />注：在多可用区类型资源池下，安全组ID通常以“sg-”开头，非多可用区类型资源池安全组ID为uuid格式；默认使用默认安全组，无默认安全组情况下请填写该参数
    networkCardList: Optional[List['V4EcsCloneInstanceRequestNetworkCardList']] = None  # 网卡信息列表，您可以查看<a href="https://www.ctyun.cn/document/10026730/10225195">弹性网卡概述</a>了解弹性网卡相关信息
    ipVersion: Optional[str] = None  # 弹性IP版本，默认不使用弹性公网IP。<br />若您需要更改，取值范围：<br />ipv4（v4地址），<br />ipv6（v6地址），<br />不指定默认为ipv4。注：请先确认该资源池是否支持ipv6 （多可用区类资源池暂不支持）
    bandwidth: Optional[int] = None  # 带宽大小，单位为Mbit/s，取值范围：[1, 2000]<br />注：extIP取值1时，bandwidth生效且必填
    ipv6AddressID: Optional[str] = None  # 弹性公网IPv6的ID，默认不使用弹性公网IP。<br />若您需要更改，填写该参数时请填写ipVersion为ipv6
    eipID: Optional[str] = None  # 弹性公网IP的ID，默认不使用弹性公网IP。<br />若您需要使用弹性IP，可以查看<a href="https://www.ctyun.cn/document/10026753/10026909">产品定义-弹性IP</a>来了解弹性公网IP <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=8652&data=94&isNormal=1&vid=88">查询指定地域已创建的弹性 IP</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=5723&data=94&vid=88">创建弹性 IP</a>
    affinityGroupID: Optional[str] = None  # 云主机组ID，默认使用原云主机的云主机组。<br />若您需要更改，获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8324&data=87">查询云主机组列表或者详情</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8316&data=87">&#32;创建云主机组</a>
    keyPairID: Optional[str] = None  # 密钥对ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10230540">密钥对</a>来了解密钥对相关内容 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8342&data=87">查询一个或多个密钥对</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8344&data=87">创建一对SSH密钥对</a>。<br />注：密码和密钥对ID，请避免同时使用，同时使用时只有绑定密钥生效
    userPassword: Optional[str] = None  # 用户密码，满足以下规则：<br />长度在8～30个字符；<br />必须包含大写字母、小写字母、数字以及特殊符号中的三项；<br />特殊符号可选：()`-!@#$%^&*_-+=｜{}[]:;'<>,.?/且不能以斜线号 / 开头；<br />不能包含3个及以上连续字符；<br />Linux镜像不能包含镜像用户名（root）、用户名的倒序（toor）、用户名大小写变化（如RoOt、rOot等），若Linux镜像用户名为ecs-user，密码不能包含用户名(ecs-user)、用户名的倒序(resu-sce)、用户名大小写变化(如ECS-USER等)；<br />Windows镜像不能包含镜像用户名（Administrator）、用户名大小写变化（adminiSTrator等）<br />注：密码和密钥对ID，请避免同时使用，同时使用时只有绑定密钥生效
    userName: Optional[str] = None  # 用户名。当操作系统为非Windows使用密码登录时，用户名取值范围：<br />root（系统超级用户），<br />ecs-user（系统普通用户），<br />注：非Windows云主机用户默认为root；该参数大小写敏感
    cycleCount: Optional[int] = None  # 订购时长，该参数需要与cycleType一同使用<br />注：最长订购周期为60个月（5年）；cycleType与cycleCount一起填写；按量付费（即onDemand为true）时，无需填写该参数（填写无效）
    cycleType: Optional[str] = None  # 订购周期类型，取值范围：<br />MONTH：按月，<br />YEAR：按年。注：cycleType与cycleCount一起填写；按量付费（即onDemand为true）时，无需填写该参数（填写无效）
    autoRenewStatus: Optional[int] = None  # 是否自动续订，取值范围：<br />0（不续费），<br />1（自动续费），<br />注：按月购买，自动续订周期为1个月；按年购买，自动续订周期为1年
    userData: Optional[str] = None  # 用户自定义数据，需要以Base64方式编码，Base64编码后的长度限制为1-16384字符。
    projectID: Optional[str] = None  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理，默认使用原云主机的企业项目。<br />若您需要更改，可以通过查看<a href="https://www.ctyun.cn/document/10017248/10017961">创建企业项目</a>了解如何创建企业项目
    labelList: Optional[List['V4EcsCloneInstanceRequestLabelList']] = None  # 标签信息列表，默认使用原云主机的标签。<br />若您需要更新，请重新设置。注：单台云主机最多可绑定10个标签；云主机创建完成后，云主机变为运行状态，此时标签仍可能未绑定，需等待一段时间（0-10分钟）。
    monitorService: Optional[bool] = None  # 监控参数，默认安装监控。<br />若您需要更改，请重新设置。支持通过该参数指定云主机在创建后是否开启详细监控，取值范围： <br />false（不开启），<br />true（开启）<br />若指定该参数为true或不指定该参数，云主机内默认开启最新详细监控服务。<br />若指定该参数为false，默认不开启最新监控服务，而使用与原云主机相同的监控服务。<br />说明：仅部分资源池支持monitorService参数，详细请参考<a href="https://www.ctyun.cn/document/10026730/10325957">监控Agent概览</a>。
    privateDnsNameOptions: Optional[List[str]] = None  # 内网DNS域名解析类型，取值范围：<br />IP_TO_IPV4，<br />INSTANCE_ID_TO_IPV4，<br />INSTANCE_ID_TO_IPV6，<br />IPV4_TO_IP <br />注：内网DNS只支持绑定主网卡的主内网IP；只有当主网卡的子网支持ipv6时，内网域名解析类型支持选择INSTANCE_ID_TO_IPV6；大小写敏感

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsCloneInstanceRequestNetworkCardList:
    isMaster: bool  # 是否主网卡，默认与原云主机网卡设置情况相同。<br />若您需要更改，请重新设置。取值范围：<br />true（表示主网卡），<br />false（表示扩展网卡）<br />注：只能含有一个主网卡
    subnetID: str  # 子网ID，默认使用原云主机的子网。<br />若您需要更改，请重新设置。您可以查看<a href="https://www.ctyun.cn/document/10026755/10098380">基本概念</a>来查找子网的相关定义 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=8659&data=94">查询子网列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=18&api=4812&data=94">创建子网</a><br />注：在多可用区类型资源池下，subnetID通常以“subnet-”开头，非多可用区类型资源池subnetID为uuid格式
    nicName: Optional[str] = None  # 长度2-32，支持拉丁字母、中文、数字、下划线、连字符，中文或英文字母开头，不能以http:或https:开头
    fixedIP: Optional[str] = None  # 内网IPv4地址，注：不可使用已占用IP


@dataclass_json
@dataclass
class V4EcsCloneInstanceRequestLabelList:
    labelKey: str  # 标签键，长度限制1-32字符，注：同一台云主机绑定多个标签时，标签键不可重复
    labelValue: str  # 标签值，长度限制1-32字符


@dataclass_json
@dataclass
class V4EcsCloneInstanceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsCloneInstanceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsCloneInstanceReturnObj:
    masterOrderID: Optional[str] = None  # 主订单ID。调用方在拿到masterOrderID之后，可以使用materOrderID进一步确认订单状态及资源状态<br />查询订单状态及资源UUID: <br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=9607&data=87&isNormal=1">根据masterOrderID查询云主机ID</a>
    masterOrderNO: Optional[str] = None  # 订单号
    masterResourceID: Optional[str] = None  # 主资源ID
    regionID: Optional[str] = None  # 资源池ID
