from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4RegionGetProductsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetProductsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4RegionGetProductsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObj:
    ebs: Optional['V4RegionGetProductsReturnObjEbs'] = None  # 云硬盘产品信息
    ecs: Optional['V4RegionGetProductsReturnObjEcs'] = None  # 云主机产品信息
    pm: Optional['V4RegionGetProductsReturnObjPm'] = None  # 物理机产品信息
    image: Optional['V4RegionGetProductsReturnObjImage'] = None  # 镜像产品信息
    monitor: Optional['V4RegionGetProductsReturnObjMonitor'] = None  # 监控产品信息
    oss: Optional['V4RegionGetProductsReturnObjOss'] = None  # 对象存储产品信息
    paas: Optional['V4RegionGetProductsReturnObjPaas'] = None  # PAAS产品信息
    saas: Optional['V4RegionGetProductsReturnObjSaas'] = None  # SAAS产品信息
    caas: Optional['V4RegionGetProductsReturnObjCaas'] = None  # 容器产品信息
    hpc: Optional['V4RegionGetProductsReturnObjHpc'] = None  # HPC产品信息
    sdwan: Optional['V4RegionGetProductsReturnObjSdwan'] = None  # SD-WAN产品信息
    order: Optional['V4RegionGetProductsReturnObjOrder'] = None  # IT订单相关产品信息
    lb: Optional['V4RegionGetProductsReturnObjLb'] = None  # 弹性负载均衡产品信息
    scaling: Optional['V4RegionGetProductsReturnObjScaling'] = None  # 弹性伸缩产品信息
    eip: Optional['V4RegionGetProductsReturnObjEip'] = None  # 弹性公网IP产品信息
    sfs: Optional['V4RegionGetProductsReturnObjSfs'] = None  # 弹性文件产品信息
    dec: Optional['V4RegionGetProductsReturnObjDec'] = None  # 专属云产品信息
    ch: Optional['V4RegionGetProductsReturnObjCh'] = None  # 云间高速产品信息
    vpc: Optional['V4RegionGetProductsReturnObjVpc'] = None  # 虚拟私有云产品信息
    cnssl: Optional['V4RegionGetProductsReturnObjCnssl'] = None  # 云网超级专线产品信息
    securitySafe: Optional['V4RegionGetProductsReturnObjSecuritySafe'] = None  # 云安全产品信息
    rds: Optional['V4RegionGetProductsReturnObjRds'] = None  # RDS产品信息
    kms: Optional['V4RegionGetProductsReturnObjKms'] = None  # KMS加密产品信息
    acl: Optional['V4RegionGetProductsReturnObjAcl'] = None  # ACL网络访问控制产品信息
    cda: Optional['V4RegionGetProductsReturnObjCda'] = None  # cda云专线产品信息
    efs: Optional['V4RegionGetProductsReturnObjEfs'] = None  # efs产品信息
    other: Optional['V4RegionGetProductsReturnObjOther'] = None  # 其他产品信息(或未分类信息)
    azList: Optional[List['V4RegionGetProductsReturnObjAzList']] = None  # az分区列表


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEbs:
    storageType: Optional[List['V4RegionGetProductsReturnObjEbsStorageType']] = None  # 存储类型
    hasBks: Optional[str] = None  # 是否支持云硬盘备份
    hasEbsKms: Optional[str] = None  # 是否支持云硬盘的KMS加密
    hasEbsFromBks: Optional[str] = None  # 是否支持从云硬盘备份创建云主机
    hasEbsFromBksFlag: Optional[str] = None
    hasISCSI: Optional[str] = None  # 是否支持ISCSI 磁盘
    hasFCSAN: Optional[str] = None  # 是否支持FCSAN磁盘
    shareEbs: Optional[str] = None  # 是否支持共享磁盘	(share_ebs)
    hasVolumeSpeedLimit: Optional[str] = None  # 是否支持磁盘限速(has_volume_speed_limit)
    upgradeSysVolume: Optional[str] = None  # 是否支持系统盘扩容
    HasVolumePool: Optional[str] = None  # 是否支持多pool资源池, 0--不支持，1--支持
    hasEbsSnapshot: Optional[str] = None  # 是否支持云硬盘快照
    hasAutoSnapPolicy: Optional[str] = None  # 是否支持云硬盘自动快照策略
    hasEbsUpdateDisk: Optional[str] = None  # 是否支持云硬盘修改磁盘类型


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEbsStorageType:
    type: Optional[str] = None  # 存储类型
    name: Optional[str] = None  # 类型名称


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEcs:
    hasGroup: Optional[str] = None  # 是否支持云主机反亲和组
    hasCloneVM: Optional[str] = None  # 是否支持创建相同配置云主机
    hasCloneVMNew: Optional[str] = None  # Real clone vm
    hasAdvancedConfiguration: Optional[str] = None  # 是否支持创建云主机中的高级配置
    hasCreateVMByBackup: Optional[str] = None  # 是否支持使用备份创建云主机
    hasCsbs: Optional[str] = None  # 是否支持云主机备份/云主机备份策略
    hasSnapshot: Optional[str] = None  # 是否支持云主机快照(OS)
    hasAddNic: Optional[str] = None  # 是否支持为云主机额外添加网卡（多网卡）
    hasChangeNetwork: Optional[str] = None  # 是否支持修改云主机内网IP地址
    hasChangeV6Network: Optional[str] = None  # 是否支持修改云主机内网IPv6地址
    hasVnc: Optional[str] = None  # 是否支持云主机远程登陆
    vmVncDomainName: Optional[str] = None
    hasS2M2: Optional[str] = None  # 是否支持s2m2规格
    hasS6: Optional[str] = None  # 是否支持s6规格
    hasS7: Optional[str] = None  # 是否支持s7规格
    flavorTypes: Optional['V4RegionGetProductsReturnObjEcsFlavorTypes'] = None  # 云主机规格列表


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEcsFlavorTypes:
    s: Optional[List[str]] = None  # s系列(通用型)支持的规格类型
    m: Optional[List[str]] = None  # m系列(内存优化型)支持的规格类型
    c: Optional[List[str]] = None  # c系列(计算增强型)支持的规格类型
    hs: Optional[List[str]] = None  # hs系列(海光通用型)支持的规格类型
    hc: Optional[List[str]] = None  # hc系列(海光计算增强型)支持的规格类型
    hm: Optional[List[str]] = None  # hm系列(海光内存优化型)支持的规格类型
    fs: Optional[List[str]] = None  # fs系列(飞腾通用)支持的规格类型
    fc: Optional[List[str]] = None  # fc系列(飞腾计算增强)支持的规格类型
    fm: Optional[List[str]] = None  # fm系列(飞腾内存优化)支持的规格类型
    kc: Optional[List[str]] = None  # kc系列(鲲鹏计算增强)支持的规格类型
    km: Optional[List[str]] = None  # km系列(鲲鹏内存优化)支持的规格类型
    ks: Optional[List[str]] = None  # ks系列(鲲鹏通用)支持的规格类型
    g: Optional[List[str]] = None  # g系列(虚拟化)支持的规格类型
    p: Optional[List[str]] = None  # p系列(直通)支持的规格类型


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjPm:
    pm: Optional[str] = None  # 是否支持物理机
    PmVnc: Optional[str] = None  # 是否支持物理机远程登录
    pmVncDomainName: Optional[str] = None  # 物理机远程登录域名
    hasPmChangeVpc: Optional[str] = None  # 支持物理机vpc切换
    hasPmGpu: Optional[str] = None  # 是否支持GPU物理机
    hasPMMultiNic: Optional[str] = None  # 是否支持物理机多网卡
    hasPmAdaptation: Optional[str] = None  # 是否支持物理机适配
    hasPmKeypair: Optional[str] = None  # 物理机是否支持密钥
    hasPmBindNic: Optional[str] = None  # 绑定弹性IP是否支持网卡选择


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjImage:
    selectionImage: Optional[str] = None  # 是否支持甄选应用镜像
    shareImage: Optional[str] = None  # 是否支持共享镜像
    safeImage: Optional[str] = None  # 是否支持安全镜像
    hasMakeDiskImage: Optional[str] = None  # 是否支持数据盘镜像
    hasExportDiskImage: Optional[str] = None  # 是否支持数据盘镜像 导入导出
    hasPrivateImageExport: Optional[str] = None  # 是否支持私有镜像导出


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjMonitor:
    hasMonitor: Optional[str] = None  # 是否支持云监控产品（包括云主机监控，云硬盘监控）
    hasAuditLog: Optional[str] = None  # 是否支持操作日志
    hasChMonitor: Optional[str] = None  # 是否支持云间高速监控
    hasEipMonitor: Optional[str] = None  # 是否支持弹性IP监控
    hasV6NicMonitor: Optional[str] = None  # 是否支持IPv6监控
    hasFGMonitor: Optional[str] = None  # 是否支持细粒度监控


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjOss:
    hasMakeImageByOss: Optional[str] = None  # 是否支持从对象存储制作镜像
    hasOss: Optional[str] = None  # 是否支持对象存储(标准版)
    hasOssKms: Optional[str] = None  # 对象存储是否支持KMS加密
    hasOSSWebSite: Optional[str] = None  # 是否对象存储支持静态网站托管
    hasOssServerOpen: Optional[str] = None  # 是否支持对象存储服务开通
    hasOssVpc: Optional[str] = None  # 是否支持对象存储Vpc
    hasOssResource: Optional[str] = None  # 是否支持对象存储资源包


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjPaas:
    PaaSPayAsYouGoProducts: Optional[str] = None  # 支持按量计费的PaaS产品
    PaasUpgradeProducts: Optional[str] = None  # 支持扩容的PAAS产品
    aiPaasContentdetection: Optional[str] = None  # PaaS是否支持内容审核	[是否支持](#has_product)
    aiPaasFacedetection: Optional[str] = None  # 是否支持人脸识别
    dataPaasMapreduce: Optional[str] = None  # 是否支持翼MapReduce
    dataPaasMapreduceUrl: Optional[str] = None  # PaaS组件mapreduce的URL
    dbPaasDrds: Optional[str] = None  # 是否支持分布式关系型数据库
    dbPaasDrdsUrl: Optional[str] = None  # PaaS组件DRDS的URL
    dbPaasHbase: Optional[str] = None  # 是否支持Hbase数据库
    dbPaasHbaseUrl: Optional[str] = None  # PaaS组件HBase的URL
    dbPaasMemcache: Optional[str] = None  # 是否支持分布式缓存-Memcache
    dbPaasMemcacheUrl: Optional[str] = None  # PaaS组件Memcache的URL
    dbPaasMongodb: Optional[str] = None  # 是否支持文档数据库-MongoDB
    dbPaasMongodbUrl: Optional[str] = None  # PaaS组件MongoDB的URL
    dbPaasPgsql: Optional[str] = None  # 是否支持PaaS组件PostgreSQ
    dbPaasPgsqlUrl: Optional[str] = None  # PaaS组件PostgreSQ的URL
    dbPaasRds: Optional[str] = None  # 是否支持关系型数据库
    dbPaasRdsUrl: Optional[str] = None  # PaaS组件RDS的URL
    dbPaasRedis: Optional[str] = None  # 是否支持分布式缓存Redis
    dbPaasRedisUrl: Optional[str] = None  # PaaS组件REDIS的URL
    dbPaasTsdb: Optional[str] = None  # 是否支持时序数据库
    dbPaasTsdbUrl: Optional[str] = None  # PaaS组件TSDB的URL
    middlewarePaasKafka: Optional[str] = None  # 是否支持分布式消息服务-kafka
    middlewarePaasKafkaUrl: Optional[str] = None  # PaaS组件kafka的URL
    middlewarePaasMq: Optional[str] = None  # 是否支持分布式消息服务-RockrtMQ
    middlewarePaasMqUrl: Optional[str] = None  # PaaS组件MQ的URL
    middlewarePaasMqtt: Optional[str] = None  # PaaS组件MQTT的上线状态
    middlewarePaasMqttUrl: Optional[str] = None  # PaaS组件MQTT的URL
    middlewarePaasRabbit: Optional[str] = None  # 是否支持分布式消息服务-RabbitMQ
    middlewarePaasRabbitUrl: Optional[str] = None  # PaaS组件RabbitMQ的URL
    paasApiUrl: Optional[str] = None  # PaaS组件URL
    paasCidr: Optional[str] = None  # PaaS预置区CIDR
    paasProZone: Optional[str] = None  # PaaS用户可用区


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjSaas:
    middlewareSaasServicestage: Optional[str] = None  # 是否支持SaaS组件微服务
    middlewareSaasServicestageUrl: Optional[str] = None  # SaaS组件微服务平台的URL


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjCaas:
    computedCaas: Optional[str] = None  # 是否支持容器实例
    computedCaasUrl: Optional[str] = None  # 容器实例的URL
    computedCce: Optional[str] = None  # 是否支持容器引擎
    computedCceUrl: Optional[str] = None  # 容器引擎的URL
    computedCcr: Optional[str] = None  # 是否支持容器镜像
    computedCcrUrl: Optional[str] = None  # 容器镜像的URL
    caasApiUrl: Optional[str] = None  # CaaS组件URL
    caasShareNetworkId: Optional[str] = None  # CAAS共享网络ID


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjHpc:
    computedHpc: Optional[str] = None  # 是否支持高性能运算hpc
    computedHpcUrl: Optional[str] = None  # 高性能运算的URL
    hpcApiUrl: Optional[str] = None  # HPC组件api的url
    hpcShareNetworkId: Optional[str] = None  # HPC共享网络ID


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjSdwan:
    hasSdwan: Optional[str] = None  # 是否支持Sdwan
    hasSdwanIpv6: Optional[str] = None  # 是否支持Sdwan下的ipv6功能
    hasQos: Optional[str] = None  # 是否支持Qos策略
    sdwanQlinksSafeFw: Optional[str] = None  # SDWAN快捷链接安全专区的日志审计和防火墙产品


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjOrder:
    hasAutoRenew: Optional[str] = None  # 是否支持自动续订
    hasAutoRevoke: Optional[str] = None  # 是否支持自动撤单
    billingByQuantity: Optional[str] = None  # 是否支持按量付费
    ctcsVmBind: Optional[str] = None  # 是否支持安全专区订单
    hasCycleTerminate: Optional[str] = None  # 是否支持包周期中止
    hasRecoveredOrder: Optional[str] = None  # 是否支持订单退订恢复
    supportDownConfig: Optional[str] = None  # 是否支持包周期资源降配


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjLb:
    hasElb: Optional[str] = None  # 是否支持负载均衡
    hasElbPG: Optional[str] = None  # 是否支持性能保障型负载均衡
    hasElbBA: Optional[str] = None  # 是否支持经典型负载均衡
    subnetOfferingIdWithInternalLb: Optional[str] = None  # 内网负载均衡子网方案
    subnetOfferingIdWithInternalLbNosnat: Optional[str] = None  # 内网负载均衡子网方案(非SNAT)
    subnetOfferingIdWithLb: Optional[str] = None  # 负载均衡子网方案
    subnetOfferingIdWithLbNosnat: Optional[str] = None  # 负载均衡子网方案(非SNAT)
    hasLBSupportSession: Optional[str] = None  # 负载均衡X-Forward-For与会话保持功能
    hasListenerOnHttps: Optional[str] = None  # 负载均衡是否支持HTTPS类型监听器
    hasListenerOnHttp: Optional[str] = None  # 负载均衡下是否支持HTTP协议类型监听器
    hasElbCert: Optional[str] = None  # 负载均衡证书管理以及https
    hasElbSubnetIpv6: Optional[str] = None  # 负载均衡子网选择项是否支持ipv6
    hasElbListenerHttpRedirect: Optional[str] = None  # 负载均衡监听器和转发策略支持创建http重定向
    hasElbHttp2: Optional[str] = None  # 负载均衡创建监听器时是否支持HTTP2.0
    hasElbCustomTimeout: Optional[str] = None  # 负载均衡是否支持自定义超时
    hasElbCrossVpc: Optional[str] = None  # 负载均衡是否支持跨VPC后端连接
    hasKeepSession: Optional[str] = None  # 负载均衡是否支持TCP/UDP会话保持
    hasElbAddEcmGroup: Optional[str] = None  # 负载均衡下是否支持单独添加后端主机组
    hasElbProtocolProto: Optional[str] = None  # 弹性负载均衡-HTTP/HTTPS协议监听器-是否支持服务端获取监听协议
    hasElbProtocolPort: Optional[str] = None  # 弹性负载均衡-HTTP/HTTPS协议监听器-是否支持服务端获取监听端口
    hasElbClientRealSourceIp: Optional[str] = None  # 弹性负载均衡-tcp协议支持获取客户端真实源IP
    hasElbPgHigh2: Optional[str] = None  # 负载均衡是否支持高阶型II
    hasElbPgSupper1: Optional[str] = None  # 负载均衡是否支持超强型I
    hasElbPgSupper2: Optional[str] = None  # 负载均衡是否支持超强型II
    hasElbPackYearDiscount: Optional[str] = None  # 负载均衡是否支持包年折扣


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjScaling:
    hasEss: Optional[str] = None  # 是否支持弹性伸缩


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEip:
    hasPayByTraffic: Optional[str] = None  # 是否支持弹性IP 按流量计费
    hasEipMonitor: Optional[str] = None  # 是否支持弹性IP监控


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjSfs:
    fileSystem: Optional[str] = None  # 是否支持弹性文件系统


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjDec:
    hasDec: Optional[str] = None  # 是否支持专属云（公有云资源池）


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjCh:
    hasCh: Optional[str] = None  # 是否支持云间高速（标准版）
    hasChMonitor: Optional[str] = None  # 是否支持云间高速监控


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjVpc:
    dns1: Optional[str] = None  # 子网DNS1
    dns2: Optional[str] = None  # 子网DNS2
    getguestcidr6suffix: Optional[str] = None  # ipv6的cidr前缀
    hasV6Nic: Optional[str] = None  # 扩展网卡是否支持IPV6（多网卡）
    hasV6NicMonitor: Optional[str] = None  # 是否支持IPv6监控
    hasVPCRouter: Optional[str] = None  # 是否支持VPC配置路由
    hasVPN: Optional[str] = None  # 是否支持VPN网关
    hasVirtualIp: Optional[str] = None  # 是否支持虚拟IP
    hasSharedBw: Optional[str] = None  # 是否支持共享带宽
    hasNat: Optional[str] = None  # 是否支持Nat网关
    ipv6: Optional[str] = None  # 是否支持IPv6，需要同步设置IPv6前缀
    hasP2P: Optional[str] = None  # 是否支持对等连接
    shareNetworkId: Optional[str] = None  # 共享网络ID
    subnetPoolId: Optional[str] = None  # 子网地址池ID


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjCnssl:
    hasCnssl: Optional[str] = None  # 是否支持云网超级专线
    hasCnsslEdgeActiveStandby: Optional[str] = None  # 是否支持云网超级专线下智能网关接入双机配置
    hasCnsslOrderFee: Optional[str] = None  # 是否支持云网超级专线订单展示费用相关业务
    hasCnsslLineSafeguard: Optional[str] = None  # 云网超级专线是否支持安全业务
    hasCnsslOrderFeeSafeguard: Optional[str] = None  # 云网超级专线是否支持安全业务计费
    hasCnsslOverviewMapview: Optional[str] = None  # 云网超级专线总览是否显示地图视图
    hasCnsslLineOnlineDnat: Optional[str] = None  # 云网超级专线 是否支持dnat业务
    hasCnsslLineSecure: Optional[str] = None  # 云网超级专线 是否支持应用保障业务


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjSecuritySafe:
    securitySafe: Optional[str] = None  # 是否支持云服务器安全
    securitySafeUrl: Optional[str] = None  # 云安全的URL


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjRds:
    rdsStorage: Optional[str] = None  # RDS是否加载存储类型
    rdsStorageType: Optional[str] = None  # RDS组件支持的存储类型
    hasFixedVIP4RDS: Optional[str] = None
    hasRDSReadNode: Optional[str] = None  # 是否RDS支持只读实例
    hasRDSZOS: Optional[str] = None  # 是否RDS支持对象存储备份


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjKms:
    hasKms: Optional[str] = None  # 是否支持KMS加密
    hasKmsServer: Optional[str] = None  # 是否支持KMS服务
    hasEfsKms: Optional[str] = None  # EFS是否支持KMS加密
    hasOssKms: Optional[str] = None  # 对象存储是否支持KMS加密
    hasEbsKms: Optional[str] = None  # 是否支持云硬盘的KMS加密


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjAcl:
    hasAcl: Optional[str] = None  # 是否支持ACL（防火墙）


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjCda:
    hasCda: Optional[str] = None  # 是否支持云专线1.0
    hasCda2: Optional[str] = None  # 是否支持云专线2.0
    hasCdaMonitor: Optional[str] = None  # 是否支持云专线监控
    hasCdaPermission: Optional[str] = None  # 是否支持云专线企业项目
    hasCdaGrant: Optional[str] = None  # 是否支持云专线授权


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjEfs:
    hasEfsPermission: Optional[str] = None
    hasEfsKms: Optional[str] = None  # 文件系统KMS加密功能
    hasEfsPay: Optional[str] = None
    hasEfsIpv6: Optional[str] = None  # 文件系统支持IPv6功能
    hasEfsV6Tip: Optional[str] = None  # 临时方案提示-文件系统临时提示


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjOther:
    GPU: Optional[str] = None  # 是否支持GPU
    hasMetalSubnet: Optional[str] = None  # 4\.0是否支持标准裸金属
    hasPmForceStop: Optional[str] = None  # 物理机是否支持强制关机
    hasPmForceRestart: Optional[str] = None  # 物理机是否支持强制重启
    hasPmDesc: Optional[str] = None  # 物理机是否支持自定义描述
    hasPmUserData: Optional[str] = None  # 物理机是否支持用户自定义数据
    hasPmEditProps: Optional[str] = None  # 物理机修改实例属性（名称，描述）
    setDiskReleaseWithPm: Optional[str] = None  # 设置云盘随物理机实例释放
    hasPmPayOnDemand: Optional[str] = None  # 物理机是否支持按量付费
    hasMetalIms: Optional[str] = None  # 是否支持物理机镜像
    hasClonePm: Optional[str] = None  # 创建相同配置物理机
    computedServerless: Optional[str] = None
    cutover: Optional[str] = None  # 是否已割接完
    dtpApiUrl: Optional[str] = None  # DTP组件URL
    eLoadBalance: Optional[str] = None
    hasBackupUsedSize: Optional[str] = None
    hasEfsKms: Optional[str] = None  # EFS是否支持KMS加密
    hasEfsPay: Optional[str] = None
    hasMaintenanceLog: Optional[str] = None  # 是否支持运维操作日志
    hasMultiCidr4VPC: Optional[str] = None  # 是否支持VPC扩展网段
    hasPps: Optional[str] = None
    hasSMSAlarm: Optional[str] = None  # 是否支持发送短信告警
    hasShoppingCart: Optional[str] = None  # 是否支持购物车
    hasTranscoding: Optional[str] = None
    hbaseApiUrl: Optional[str] = None  # HBase组件URL
    hostGroupAdjustable: Optional[str] = None  # 是否支持主机组可迁移
    lat: Optional[str] = None  # 纬度
    lng: Optional[str] = None  # 经度
    mapReduceShareNetworkId: Optional[str] = None  # 翼MR共享网络ID
    mqttInternetAbility: Optional[str] = None
    mrApiUrl: Optional[str] = None  # MR组件URL
    resourceSoldout: Optional[str] = None  # 是否支持资源按规格售罄
    userRole: Optional[str] = None


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjAzList:
    azName: Optional[str] = None  # 可用区名称
    azDisplayName: Optional[str] = None  # 可用区展示名
    details: Optional['V4RegionGetProductsReturnObjAzListDetails'] = None  # 可用区详细信息


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjAzListDetails:
    storageType: Optional[List['V4RegionGetProductsReturnObjAzListDetailsStorageType']] = None  # 不同az可用区的存储类型


@dataclass_json
@dataclass
class V4RegionGetProductsReturnObjAzListDetailsStorageType:
    type: Optional[str] = None  # 存储类型
    name: Optional[str] = None  # 类型名称
