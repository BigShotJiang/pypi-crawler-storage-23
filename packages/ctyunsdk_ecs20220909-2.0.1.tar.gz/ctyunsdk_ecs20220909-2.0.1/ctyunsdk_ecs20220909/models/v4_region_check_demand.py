from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4RegionCheckDemandRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    productType: str  # 产品类型 可选值：ecs:云主机,eip:IP,ebs:磁盘
    azName: Optional[str] = None  # 可用区名称(云主机规格和云硬盘4.0资源池区分az)
    flavorID: Optional[str] = None  # productType为ecs时传，云主机规格ID（获取规格列表/v4/common/get-ecs-flavors，取flavorID或specName）
    specName: Optional[str] = None  # productType为ecs时传，主机规格名称（specName和flavorID可二选一，都传以flavorID为准，获取规格列表/v4/common/get-ecs-flavors，取specName）
    ecsAmount: Optional[int] = None  # productType为ecs时传，云主机需求量（可选，不传默认为1）
    ebsType: Optional[str] = None  # productType为ebs时传，磁盘类型： SATA/SAS/SSD/SATA-KUNPENG/SATA-HAIGUANG/SAS-KUNPENG/SAS-HAIGUANG/SSD-genric/FAST-SSD/XSSD-0/XSSD-1/XSSD-2
    ebsSize: Optional[int] = None  # productType为ebs时传，磁盘大小
    eipAmount: Optional[int] = None  # productType为eip时传，IP需求量（可选，不传默认为1）

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionCheckDemandResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4RegionCheckDemandReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionCheckDemandReturnObj:
    satisfied: Optional[bool] = None  # 是否可售
    sellout: Optional[bool] = None  # 是否售罄
    hasQuota: Optional[bool] = None  # 用户配额余量是否满足(paas带channel的调用不会返回)
    quotaInfo: Optional['V4RegionCheckDemandReturnObjQuotaInfo'] = None  # 产品用户配额信息(paas带channel的调用不会返回)
    usedInfo: Optional['V4RegionCheckDemandReturnObjUsedInfo'] = None  # 用户已用量信息(paas带channel的调用不会返回)


@dataclass_json
@dataclass
class V4RegionCheckDemandReturnObjQuotaInfo:
    ecsCountQuota: Optional[int] = None  # 云主机数量配额，当productType=ecs时返回
    cpuVcoreQuota: Optional[int] = None  # cpu核数配额，当productType=ecs时返回
    memQuota: Optional[int] = None  # 内存大小配额，当productType=ecs时返回
    ebsCountQuota: Optional[int] = None  # 云硬盘数量配额，当productType=ebs时返回
    ebsSizeQuota: Optional[int] = None  # 云硬盘大小配额，单位G，当productType=ebs时返回
    ipCountQuota: Optional[int] = None  # 弹性ip数量配额，当productType=eip时返回


@dataclass_json
@dataclass
class V4RegionCheckDemandReturnObjUsedInfo:
    ecsCount: Optional[int] = None  # 已用云主机数量配额，当productType=ecs时返回
    cpuVcoreCount: Optional[int] = None  # 已用cpu核数配额，当productType=ecs时返回
    memUsed: Optional[int] = None  # 已用内存大小配额，当productType=ecs时返回
    ebsCount: Optional[int] = None  # 已用云硬盘数量配额，当productType=ebs时返回
    ebsSize: Optional[int] = None  # 已用云硬盘大小配额，单位G，当productType=ebs时返回
    ipCount: Optional[int] = None  # 已用弹性ip数量配额，当productType=eip时返回
