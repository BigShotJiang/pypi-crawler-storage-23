from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4OrderRenewQueryPriceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    resourceType: str  # 资源类型
    resourceUUID: str  # 资源uuid
    cycleType: str  # 订购周期类型，可选值：MONTH 月，YEAR 年
    cycleCount: int  # 订购周期大小

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderRenewQueryPriceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4OrderRenewQueryPriceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderRenewQueryPriceReturnObj:
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
    subOrderPrices: Optional[List['V4OrderRenewQueryPriceReturnObjSubOrderPrices']] = None  # 子订单价格信息


@dataclass_json
@dataclass
class V4OrderRenewQueryPriceReturnObjSubOrderPrices:
    serviceTag: Optional[str] = None  # 服务类型
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
    orderItemPrices: Optional[List['V4OrderRenewQueryPriceReturnObjSubOrderPricesOrderItemPrices']] = None  # 资源价格信息


@dataclass_json
@dataclass
class V4OrderRenewQueryPriceReturnObjSubOrderPricesOrderItemPrices:
    resourceType: Optional[str] = None  # 资源类型
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
