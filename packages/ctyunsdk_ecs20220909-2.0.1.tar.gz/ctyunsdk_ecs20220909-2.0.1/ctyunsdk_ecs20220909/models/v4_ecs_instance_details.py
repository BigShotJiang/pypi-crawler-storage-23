from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsInstanceDetailsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceID: str  # 云主机ID，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsInstanceDetailsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsInstanceDetailsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObj:
    projectID: Optional[str] = None  # 企业项目ID
    azName: Optional[str] = None  # 可用区名称
    attachedVolume: Optional[List[str]] = None  # 云硬盘ID列表
    addresses: Optional[List['V4EcsInstanceDetailsReturnObjAddresses']] = None  # 网络地址信息
    resourceID: Optional[str] = None  # 云主机资源ID
    instanceID: Optional[str] = None  # 云主机ID
    displayName: Optional[str] = None  # 云主机显示名称
    instanceName: Optional[str] = None  # 云主机名称
    osType: Optional[int] = None  # 操作系统类型，取值范围：<br />1（linux），<br />2（windows），<br />3（redhat），<br />4（ubuntu），<br />5（centos），<br />6（oracle）
    instanceStatus: Optional[str] = None  # 云主机状态，取值范围：<br />backuping: 备份中，<br />creating: 创建中，<br />expired: 已到期，<br />freezing: 已冻结，<br />rebuild: 重装，<br />restarting: 重启中，<br />running: 运行中，<br />starting: 开机中，<br />stopped: 已关机，<br />stopping: 关机中，<br />error: 错误，<br />snapshotting: 快照创建中，<br />unsubscribed: 包周期已退订，<br />unsubscribing: 包周期退订中。<br />更多云主机状态请通过<a href="https://www.ctyun.cn/document/10026730/10741614">状态枚举值</a>查看云主机使用状态
    expiredTime: Optional[str] = None  # 到期时间
    availableDay: Optional[int] = None  # 可用天数
    updatedTime: Optional[str] = None  # 更新时间
    createdTime: Optional[str] = None  # 创建时间
    zabbixName: Optional[str] = None  # 监控对象名称
    secGroupList: Optional[List['V4EcsInstanceDetailsReturnObjSecGroupList']] = None  # 安全组信息
    privateIP: Optional[str] = None  # 内网IPv4地址
    privateIPv6: Optional[str] = None  # 内网IPv6地址
    networkCardList: Optional[List['V4EcsInstanceDetailsReturnObjNetworkCardList']] = None  # 网卡信息
    vipInfoList: Optional[List['V4EcsInstanceDetailsReturnObjVipInfoList']] = None  # 虚拟IP信息列表
    vipCount: Optional[int] = None  # vip数目
    affinityGroup: Optional['V4EcsInstanceDetailsReturnObjAffinityGroup'] = None  # 云主机组信息
    image: Optional['V4EcsInstanceDetailsReturnObjImage'] = None  # 镜像信息
    flavor: Optional['V4EcsInstanceDetailsReturnObjFlavor'] = None  # 云主机规格信息
    onDemand: Optional[bool] = None  # 付费方式，取值范围：<br />true（表示按量付费）; <br />false（表示包周期）
    vpcName: Optional[str] = None  # 虚拟私有云名称
    vpcID: Optional[str] = None  # 虚拟私有云ID
    fixedIPList: Optional[List[str]] = None  # 内网IP列表
    floatingIP: Optional[str] = None  # 公网IP
    subnetIDList: Optional[List[str]] = None  # 子网ID列表
    keypairName: Optional[str] = None  # 密钥对名称
    deletionProtection: Optional[bool] = None  # 是否开启实例删除保护
    delegateName: Optional[str] = None  # 委托名称，注：委托绑定目前仅支持多可用区类型资源池，非可用区资源池为空字符串
    remainingDay: Optional[int] = None  # 距离释放剩余天数
    releaseTime: Optional[str] = None  # 释放时间
    dedicatedHostID: Optional[str] = None  # 宿主机UUID
    dedicatedHostName: Optional[str] = None  # 宿主机名称
    instanceDescription: Optional[str] = None  # 云主机描述信息
    metadata: Optional[Dict[str, str]] = None  # 用户自定义元数据，注：仅多可用区类型资源池支持返回，非可用区资源池请调用查询元数据接口 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8319&data=87&isNormal=1">云主机元数据查询</a>
    pciInfo: Optional['V4EcsInstanceDetailsReturnObjPciInfo'] = None  # pci地址信息，注：仅多可用区类型资源池返回；该字段内测中。
    labelList: Optional[List['V4EcsInstanceDetailsReturnObjLabelList']] = None  # 标签列表
    trustInstance: Optional[bool] = None  # 可信实例，取值范围：<br />true（表示已开启）; <br />false（表示未开启）


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjAddresses:
    vpcName: Optional[str] = None  # vpc名称
    addressList: Optional[List['V4EcsInstanceDetailsReturnObjAddressesAddressList']] = None  # 网络地址列表


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjAddressesAddressList:
    addr: Optional[str] = None  # IP地址
    version: Optional[int] = None  # IP版本
    type: Optional[str] = None  # 网络类型，取值范围：<br />fixed（内网），<br />floating（弹性公网）
    isMaster: Optional[bool] = None  # 是否为主网卡
    macAddress: Optional[str] = None  # mac地址


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjSecGroupList:
    securityGroupID: Optional[str] = None  # 安全组ID
    securityGroupName: Optional[str] = None  # 安全组名称


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjNetworkCardList:
    IPv4Address: Optional[str] = None  # IPv4地址
    IPv6Address: Optional[List[str]] = None  # IPv6地址列表
    subnetID: Optional[str] = None  # 子网ID
    subnetCidr: Optional[str] = None  # 子网网段信息
    isMaster: Optional[bool] = None  # 是否主网卡，取值范围：<br />true（主网卡），<br />false（扩展网卡）
    gateway: Optional[str] = None  # 网关地址
    networkCardID: Optional[str] = None  # 网卡ID
    securityGroup: Optional[List[str]] = None  # 安全组ID列表


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjVipInfoList:
    vipID: Optional[str] = None  # 虚拟IP的ID
    vipAddress: Optional[str] = None  # 虚拟IP地址
    vipBindNicIP: Optional[str] = None  # 虚拟IP绑定的网卡对应IPv4地址
    vipBindNicIPv6: Optional[str] = None  # 虚拟IP绑定的网卡对应IPv6地址
    nicID: Optional[str] = None  # 网卡ID


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjAffinityGroup:
    affinityGroupPolicy: Optional[str] = None  # 云主机组策略
    affinityGroupName: Optional[str] = None  # 云主机组名称
    affinityGroupID: Optional[str] = None  # 云主机组ID


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjImage:
    imageID: Optional[str] = None  # 镜像ID
    imageName: Optional[str] = None  # 镜像名称
    supportXssd: Optional[bool] = None  # 是否支持XSSD类型云硬盘


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjFlavor:
    flavorID: Optional[str] = None  # 规格ID
    flavorName: Optional[str] = None  # 规格名称
    flavorCPU: Optional[int] = None  # VCPU
    flavorRAM: Optional[int] = None  # 内存
    gpuType: Optional[str] = None  # GPU类型，取值范围：T4、V100、V100S、A10、A100、atlas 300i pro、mlu370-s4，支持类型会随着功能升级增加
    gpuCount: Optional[int] = None  # GPU数目
    gpuVendor: Optional[str] = None  # GPU供应商名称
    videoMemSize: Optional[int] = None  # GPU显存大小


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjPciInfo:
    nicPciList: Optional[List['V4EcsInstanceDetailsReturnObjPciInfoNicPciList']] = None  # 网卡pci信息列表


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjPciInfoNicPciList:
    networkInterfaceID: Optional[str] = None  # 网卡id
    pci: Optional[str] = None  # pci地址


@dataclass_json
@dataclass
class V4EcsInstanceDetailsReturnObjLabelList:
    labelKey: Optional[str] = None  # 标签键
    labelValue: Optional[str] = None  # 标签值
