from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsBatchUpdateInstancesRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    updateInfo: List['V4EcsBatchUpdateInstancesRequestUpdateInfo']  # 批量更新信息列表

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsBatchUpdateInstancesRequestUpdateInfo:
    instanceID: str  # 云主机ID，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>
    displayName: Optional[str] = None  # 云主机显示名称，长度为2~63个字符。<br />注：displayName、instanceName、instanceDescription不可全为空。
    instanceName: Optional[str] = None  # 云主机名称，支持模式串。不同操作系统下，云主机名称规则有差异。<br />Windows：长度为2-15个字符，允许使用大小写字母、数字或连字符（-）。不能以连字符（-）开头或结尾，不能连续使用连字符（-），也不能仅使用数字；<br />其他操作系统：长度为2-64字符，允许使用点（.）分隔字符成多段，每段允许使用大小写字母、数字或连字符（-），但不能连续使用点号（.）或连字符（-），不能以点号（.）或连字符（-）开头或结尾，也不能仅使用数字。<br />注：displayName、instanceName、instanceDescription不可全为空。
    instanceDescription: Optional[str] = None  # 云主机描述信息，限制长度为0~255个字符。<br />注：displayName、instanceName、instanceDescription不可全为空。


@dataclass_json
@dataclass
class V4EcsBatchUpdateInstancesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsBatchUpdateInstancesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsBatchUpdateInstancesReturnObj:
    updateInfo: Optional[List['V4EcsBatchUpdateInstancesReturnObjUpdateInfo']] = None  # 被更新云主机信息


@dataclass_json
@dataclass
class V4EcsBatchUpdateInstancesReturnObjUpdateInfo:
    instanceID: Optional[str] = None  # 被更新名称的云主机ID
    displayName: Optional[str] = None  # 更新后的云主机名称
    instanceName: Optional[str] = None  # 被更新云主机名称
    instanceDescription: Optional[str] = None  # 被更新云主机描述信息
