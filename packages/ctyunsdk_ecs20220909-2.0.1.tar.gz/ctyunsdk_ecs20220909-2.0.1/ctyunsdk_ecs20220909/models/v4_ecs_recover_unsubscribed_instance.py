from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsRecoverUnsubscribedInstanceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceIDList: List[str]  # 云主机ID，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br />注：最大操作数量为10台
    cycleCount: int  # 订购时长，该参数需要与cycleType一同使用<br />注：最长订购周期为36个月（3年）
    cycleType: str  # 订购周期类型，取值范围：<br />MONTH：按月，<br />YEAR：按年

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsRecoverUnsubscribedInstanceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsRecoverUnsubscribedInstanceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsRecoverUnsubscribedInstanceReturnObj:
    orderInfo: Optional[List['V4EcsRecoverUnsubscribedInstanceReturnObjOrderInfo']] = None  # 订单信息


@dataclass_json
@dataclass
class V4EcsRecoverUnsubscribedInstanceReturnObjOrderInfo:
    masterOrderID: Optional[str] = None  # 主订单ID。调用方在拿到masterOrderID之后，可以使用masterOrderID进一步确认订单状态及资源状态。
    masterOrderNO: Optional[str] = None  # 订单号
    instanceID: Optional[str] = None  # 云主机ID
