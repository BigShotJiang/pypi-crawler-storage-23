from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsJobQueryRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    jobIDs: str  # 异步任务ID列表，以英文逗号分隔每个ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsJobQueryResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsJobQueryReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsJobQueryReturnObj:
    jobList: Optional[List['V4EcsJobQueryReturnObjJobList']] = None  # 异步任务列表


@dataclass_json
@dataclass
class V4EcsJobQueryReturnObjJobList:
    jobID: Optional[str] = None  # 异步任务ID
    jobStatus: Optional[int] = None  # 任务执行状态，取值范围：<br />0：执行中,<br />1：执行成功,<br />2：执行失败
