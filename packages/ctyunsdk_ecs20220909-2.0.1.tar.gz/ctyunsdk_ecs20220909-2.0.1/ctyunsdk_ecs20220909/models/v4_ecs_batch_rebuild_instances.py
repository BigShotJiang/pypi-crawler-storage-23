from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsBatchRebuildInstancesRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    rebuildInfo: List['V4EcsBatchRebuildInstancesRequestRebuildInfo']  # 重装信息列表

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsBatchRebuildInstancesRequestRebuildInfo:
    instanceID: str  # 云主机ID，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>
    userName: Optional[str] = None  # 用户名。当操作系统为非Windows使用密码登录时，用户名取值范围：<br />root（系统超级用户），<br />ecs-user（系统普通用户），<br />注：非Windows云主机用户默认为root，该参数大小写敏感
    password: Optional[str] = None  # 用户密码，密码和密钥对ID，二者必传一个。满足以下规则：<br />长度在8～30个字符；<br />必须包含大写字母、小写字母、数字以及特殊符号中的三项；<br />特殊符号可选：()`~!@#$%^&*_-+=｜{}[]:;'<>,.?/\且不能以斜线号 / 开头；<br />不能包含3个及以上连续字符；<br />Linux镜像不能包含镜像用户名（root）、用户名的倒序（toor）、用户名大小写变化（如RoOt、rOot等），若Linux镜像用户名为ecs-user，密码不能包含用户名(ecs-user)、用户名的倒序(resu-sce)、用户名大小写变化(如ECS-USER等)；<br />Windows镜像不能包含镜像用户名（Administrator）、用户名大小写变化（adminiSTrator等）
    keyPairID: Optional[str] = None  # 密钥对ID，密码和密钥对ID，二者必传一个。请避免同时使用，同时使用时只有绑定密钥生效；windows主机不支持密钥对。
    imageID: Optional[str] = None  # 镜像ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10030151">镜像概述</a>来了解云主机镜像<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=23&api=4763&data=89">查询可以使用的镜像资源</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=23&api=4765&data=89">创建私有镜像（云主机系统盘）</a><br />注：不填默认以原镜像进行重装
    userData: Optional[str] = None  # 用户自定义数据，需要以Base64方式编码，Base64编码后的长度限制为1-16384字符。
    instanceName: Optional[str] = None  # 云主机名称。不同操作系统下，云主机名称规则有差异。<br />Windows：长度为2~15个字符，允许使用大小写字母、数字或连字符（-）。不能以连字符（-）开头或结尾，不能连续使用连字符（-），也不能仅使用数字；<br />其他操作系统：长度为2~64字符，允许使用点（.）分隔字符成多段，每段允许使用大小写字母、数字或连字符（-），但不能连续使用点号（.）或连字符（-），不能以点号（.）或连字符（-）开头或结尾，也不能仅使用数字<br />注：如果不填，默认值为原来云主机名称
    monitorService: Optional[bool] = None  # 监控参数，支持通过该参数指定云主机在创建后是否开启详细监控，取值范围： <br />false（不开启），<br />true（开启）<br />若指定该参数为true或不指定该参数，云主机内默认开启最新详细监控服务。<br />若指定该参数为false，默认公共镜像不开启最新监控服务；私有镜像使用镜像中保留的监控服务。<br />说明：仅部分资源池支持monitorService参数，详细请参考<a href="https://www.ctyun.cn/document/10026730/10325957">监控Agent概览</a>。
    gpuDriverKits: Optional[str] = None  # GPU云主机安装驱动的工具包。注：只多可用区支持安装GPU驱动
    trustInstance: Optional[bool] = None  # 是否开启可信系统。取值范围：<br />true：开启<br />false（默认）：不开启。注：只支持多可用区资源池


@dataclass_json
@dataclass
class V4EcsBatchRebuildInstancesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsBatchRebuildInstancesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsBatchRebuildInstancesReturnObj:
    jobIDList: Optional[List['V4EcsBatchRebuildInstancesReturnObjJobIDList']] = None  # 重装任务列表


@dataclass_json
@dataclass
class V4EcsBatchRebuildInstancesReturnObjJobIDList:
    jobID: Optional[str] = None  # 重装任务ID
    instanceID: Optional[str] = None  # 对应任务云主机ID
