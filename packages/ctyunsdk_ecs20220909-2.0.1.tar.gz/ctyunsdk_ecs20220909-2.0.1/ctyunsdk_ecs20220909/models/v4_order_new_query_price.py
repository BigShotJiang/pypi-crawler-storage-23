from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4OrderNewQueryPriceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    resourceType: str  # 资源类型，[资源类型](#resource_type)
    count: int  # 订购数量
    onDemand: bool  # 是否按需资源，true 按需 / false 包周期
    cycleType: Optional[str] = None  # 订购周期类型，当onDemand为false时为必填，可选值：<li>MONTH 月<li>YEAR 年
    cycleCount: Optional[int] = None  # 订购周期大小，当onDemand为false时为必填
    flavorName: Optional[str] = None  # 云主机规格，当resourceType为VM时必填
    imageUUID: Optional[str] = None  # 云主机镜像UUID，当resourceType为VM时必填
    sysDiskType: Optional[str] = None  # 云主机系统盘类型，当resourceType为VM时必填,[磁盘类型](#disk_type)
    sysDiskSize: Optional[int] = None  # 云主机系统盘大小，当resourceType为VM时必填
    disks: Optional[List['V4OrderNewQueryPriceRequestDisks']] = None  # 数据盘信息，当resourceType为VM选填，订购云主机时如果成套订购数据盘时需要该字段
    bandwidth: Optional[int] = None  # 带宽大小，当resourceType为IP时必填；当resourceType为VM时，如果成套订购弹性公网IP时需要该字段
    diskType: Optional[str] = None  # 磁盘类型，当resourceType为EBS时必填,[磁盘类型](#disk_type)
    diskSize: Optional[int] = None  # 磁盘大小，当resourceType为EBS时必填
    diskMode: Optional[str] = None  # 磁盘模式(VBD/ISCSI/FCSAN)，当resourceType为EBS时必填
    natType: Optional[str] = None  # nat规格，当resourceType为NAT时必填,[NAT规格](#nat_type)
    ipPoolBandwidth: Optional[int] = None  # 共享带宽大小，当resourceType为IP_POOL时必填
    deviceType: Optional[str] = None  # 物理机规格，当resourceType为BMS时必填
    azName: Optional[str] = None  # 物理机规格可用区，当resourceType为BMS时必填
    orderDisks: Optional[List['V4OrderNewQueryPriceRequestOrderDisks']] = None  # 物理机云硬盘信息，当resourceType为BMS选填
    elbType: Optional[str] = None  # 性能保障型负载均衡类型(支持standardI/standardII/enhancedI/enhancedII/higherI)，当resourceType为PGELB时必填
    cbrValue: Optional[int] = None  # 存储库大小，100-1024000GB，当resourceType为CBR_VM或CBR_VBS时必填

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderNewQueryPriceRequestDisks:
    diskType: str  # 磁盘类型
    diskSize: int  # 磁盘大小


@dataclass_json
@dataclass
class V4OrderNewQueryPriceRequestOrderDisks:
    diskType: str  # 磁盘类型
    diskSize: int  # 磁盘大小


@dataclass_json
@dataclass
class V4OrderNewQueryPriceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4OrderNewQueryPriceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4OrderNewQueryPriceReturnObj:
    totalPrice: Optional[float] = None  # 总价格
    discountPrice: Optional[float] = None  # 折后价格，云主机相关产品有
    finalPrice: Optional[float] = None  # 最终价格
    subOrderPrices: Optional[List['V4OrderNewQueryPriceReturnObjSubOrderPrices']] = None  # 子订单价格信息


@dataclass_json
@dataclass
class V4OrderNewQueryPriceReturnObjSubOrderPrices:
    serviceTag: Optional[str] = None  # 服务类型
    totalPrice: Optional[float] = None  # 子订单总价格
    orderItemPrices: Optional[List['V4OrderNewQueryPriceReturnObjSubOrderPricesOrderItemPrices']] = None  # item价格信息


@dataclass_json
@dataclass
class V4OrderNewQueryPriceReturnObjSubOrderPricesOrderItemPrices:
    resourceType: Optional[str] = None  # 资源类型
    totalPrice: Optional[float] = None  # 总价格
    finalPrice: Optional[float] = None  # 最终价格
