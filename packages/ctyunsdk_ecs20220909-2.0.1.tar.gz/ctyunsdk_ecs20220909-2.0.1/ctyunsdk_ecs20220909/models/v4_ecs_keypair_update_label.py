from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsKeypairUpdateLabelRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    keyPairID: str  # 密钥对ID
    action: str  # 操作类型，可选值：ADD（增加）、UPDATE（修改）、DELETE（删除）
    labelList: List['V4EcsKeypairUpdateLabelRequestLabelList']  # 标签列表，注：当前仅多可用区资源池支持标签功能。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsKeypairUpdateLabelRequestLabelList:
    labelKey: str  # 标签键
    labelValue: str  # 标签值


@dataclass_json
@dataclass
class V4EcsKeypairUpdateLabelResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional[object] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


