from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4RegionGetZonesRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetZonesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4RegionGetZonesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4RegionGetZonesReturnObj:
    zoneList: Optional[List['V4RegionGetZonesReturnObjZoneList']] = None  # 可用区列表


@dataclass_json
@dataclass
class V4RegionGetZonesReturnObjZoneList:
    name: Optional[str] = None  # 可用区名称，其他需要可用区参数的接口需要依赖该名称结果
    azDisplayName: Optional[str] = None  # 可用区展示名
