from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsUpdateAutoRenewConfigRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    instanceIDList: str  # 云主机ID列表，多台使用英文逗号分割，您可以查看<a href="https://www.ctyun.cn/products/ecs">弹性云主机</a>了解云主机的相关信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8309&data=87">查询云主机列表</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8281&data=87">创建一台按量付费或包年包月的云主机</a><br /><span style="background-color: rgb(97, 175, 254);color: rgb(255,255,255);padding: 2px; margin:2px">创</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8282&data=87">批量创建按量付费或包年包月云主机</a>
    autoRenewStatus: int  # 是否自动续订，取值范围：<br />0（不续费），<br />1（自动续费），<br />注：如填写值为1，而不填写autoRenewCycleType和autoRenewCycleCount，则默认开启自动续订且自动续订周期为1个月；如填写值为0，则autoRenewCycleType和autoRenewCycleCount填写无效
    autoRenewCycleType: Optional[str] = None  # 自动续订周期类型，取值范围：<br />MONTH：按月，<br />YEAR：按年。<br />注：不填默认值（缺省值）为MONTH
    autoRenewCycleCount: Optional[int] = None  # 订购时长，该参数需要与cycleType一同使用<br />注：当autoRenewCycleType为MONTH时，取值范围为[1, 11]；当autoRenewCycleType为YEAR时，取值范围为[1, 3]。即按月最大可自动续订11个月，按年最大自动续订3年。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsUpdateAutoRenewConfigResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional[object] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


