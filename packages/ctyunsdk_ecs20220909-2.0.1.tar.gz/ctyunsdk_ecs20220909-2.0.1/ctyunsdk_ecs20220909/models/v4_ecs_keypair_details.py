from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsKeypairDetailsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    projectID: Optional[str] = None  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10017248/10017961">创建企业项目</a>了解如何创建企业项目
    keyPairName: Optional[str] = None  # 密钥对名称。满足以下规则：只能由数字、字母、-组成，不能以数字和-开头、以-结尾，且长度为2-63字符.
    queryContent: Optional[str] = None  # 模糊匹配查询内容（匹配字段：keyPairName、keyPairID）
    labelList: Optional[List['V4EcsKeypairDetailsRequestLabelList']] = None  # 标签信息列表
    pageNo: Optional[int] = None  # 页码，取值范围：正整数（≥1），注：默认值为1
    pageSize: Optional[int] = None  # 每页记录数目，取值范围：[1, 50]，注：默认值为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsKeypairDetailsRequestLabelList:
    labelKey: str  # 标签键，长度限制1~128字符
    labelValue: str  # 标签值，长度限制1~128字符


@dataclass_json
@dataclass
class V4EcsKeypairDetailsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsKeypairDetailsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsKeypairDetailsReturnObj:
    currentCount: Optional[int] = None  # 当前页记录数目
    totalCount: Optional[int] = None  # 总记录数
    results: Optional[List['V4EcsKeypairDetailsReturnObjResults']] = None  # 分页明细


@dataclass_json
@dataclass
class V4EcsKeypairDetailsReturnObjResults:
    publicKey: Optional[str] = None  # 密钥对的公钥
    keyPairName: Optional[str] = None  # 密钥对名称
    fingerPrint: Optional[str] = None  # 密钥对的指纹，采用MD5信息摘要算法。
    keyPairID: Optional[str] = None  # 密钥对的ID
    projectID: Optional[str] = None  # 企业项目ID
    bindInstanceNum: Optional[int] = None  # 绑定云主机实例数
    keyPairDescription: Optional[str] = None  # 密钥对的描述
    labelList: Optional[List['V4EcsKeypairDetailsReturnObjResultsLabelList']] = None  # 绑定的标签信息


@dataclass_json
@dataclass
class V4EcsKeypairDetailsReturnObjResultsLabelList:
    labelKey: Optional[str] = None  # 标签键，长度限制1~128字符
    labelValue: Optional[str] = None  # 标签值，长度限制1~128字符
