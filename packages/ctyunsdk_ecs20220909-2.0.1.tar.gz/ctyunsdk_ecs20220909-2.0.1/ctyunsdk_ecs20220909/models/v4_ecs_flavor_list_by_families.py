from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4EcsFlavorListByFamiliesRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池 ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    flavorFamily: str  # 规格族名称，您可以查看<a href="https://www.ctyun.cn/document/10026730/10138523">规格族</a>来了解规格族信息<br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=8326&data=87">查询云主机规格族列表<a>
    azName: Optional[str] = None  # 可用区名称，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解可用区 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span>&#32;<a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5855&data=87">资源池可用区查询</a><br />注：查询结果中 zoneList 内返回存在可用区名称(即多可用区，本字段填写实际可用区名称)，若查询结果中 zoneList 为空（即为单可用区，本字段填写 default）
    pageNo: Optional[int] = None  # 页码，取值范围：正整数（≥1），注：默认值为 1
    pageSize: Optional[int] = None  # 每页记录数目，取值范围：[1, 50]，注：默认值为 10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorListByFamiliesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4EcsFlavorListByFamiliesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4EcsFlavorListByFamiliesReturnObj:
    currentCount: Optional[int] = None  # 当前页记录数目
    totalCount: Optional[int] = None  # 总记录数
    totalPage: Optional[int] = None  # 总页数
    results: Optional[List['V4EcsFlavorListByFamiliesReturnObjResults']] = None  # 云主机列表


@dataclass_json
@dataclass
class V4EcsFlavorListByFamiliesReturnObjResults:
    instanceID: Optional[str] = None  # 云主机 ID
    instanceName: Optional[str] = None  # 云主机名称
    flavor: Optional['V4EcsFlavorListByFamiliesReturnObjResultsFlavor'] = None  # 云主机规格详情


@dataclass_json
@dataclass
class V4EcsFlavorListByFamiliesReturnObjResultsFlavor:
    flavorID: Optional[str] = None  # 规格 ID
    flavorName: Optional[str] = None  # 规格名称
    flavorCPU: Optional[int] = None  # VCPU 个数
    flavorRAM: Optional[int] = None  # 内存
    gpuType: Optional[str] = None  # GPU 类型，取值范围：T4、V100、V100S、A10、A100、atlas 300i pro、mlu370-s4，支持类型会随着功能升级增加
    gpuCount: Optional[int] = None  # GPU 数目
    gpuVendor: Optional[str] = None  # GPU 厂商
    videoMemSize: Optional[int] = None  # GPU 显存大小
