"""Setup script for editable install; pyproject.toml is canonical."""
from setuptools import setup

setup()
