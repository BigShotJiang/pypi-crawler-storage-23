"""LLM clients: AbstractLLMClient ABC."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from llm_rotator._types import LLMResponse, StreamChunk


class AbstractLLMClient(ABC):
    """Strategy for a specific LLM provider."""

    @abstractmethod
    async def generate(
        self,
        messages: list[dict],
        model: str,
        api_key: str,
        base_url: str | None = None,
        **kwargs: Any,
    ) -> LLMResponse: ...

    @abstractmethod
    async def stream(
        self,
        messages: list[dict],
        model: str,
        api_key: str,
        base_url: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]: ...
