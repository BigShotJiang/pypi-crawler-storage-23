"""llm-rotator: Fault-tolerant LLM provider rotation."""

import contextlib

from llm_rotator._types import (
    Candidate,
    LLMResponse,
    RoutingContext,
    StreamChunk,
    ToolCall,
    Usage,
)
from llm_rotator.backends import AbstractStateBackend, InMemoryBackend
from llm_rotator.backends.redis import RedisBackend
from llm_rotator.circuit_breaker import CircuitBreaker
from llm_rotator.clients import AbstractLLMClient
from llm_rotator.clients.anthropic import AnthropicClient
from llm_rotator.clients.gemini import GeminiClient
from llm_rotator.clients.openai import OpenAIClient
from llm_rotator.config import (
    ClientType,
    KeyConfig,
    ModelGroupConfig,
    ProviderConfig,
    RequestQuotaConfig,
    ResetSchedule,
    RotatorConfig,
    ServerErrorRetryConfig,
    TokenQuotaConfig,
)
from llm_rotator.exceptions import (
    AllAttemptsFailedError,
    KeyDeadError,
    LLMRotatorError,
    ModelRateLimitError,
    QuotaExceededError,
    ServerError,
)
from llm_rotator.logging import RoutingTrace
from llm_rotator.quota import QuotaManager, QuotaWarning
from llm_rotator.rotator import LLMRotator

with contextlib.suppress(ImportError):
    from llm_rotator.integrations.langchain import RotatorChatModel

__all__ = [
    "AbstractLLMClient",
    "AbstractStateBackend",
    "AllAttemptsFailedError",
    "AnthropicClient",
    "Candidate",
    "CircuitBreaker",
    "ClientType",
    "GeminiClient",
    "InMemoryBackend",
    "KeyConfig",
    "KeyDeadError",
    "LLMResponse",
    "LLMRotator",
    "LLMRotatorError",
    "ModelGroupConfig",
    "ModelRateLimitError",
    "OpenAIClient",
    "ProviderConfig",
    "QuotaExceededError",
    "QuotaManager",
    "QuotaWarning",
    "RedisBackend",
    "RequestQuotaConfig",
    "ResetSchedule",
    "RotatorChatModel",
    "RotatorConfig",
    "RoutingContext",
    "RoutingTrace",
    "ServerError",
    "ServerErrorRetryConfig",
    "StreamChunk",
    "TokenQuotaConfig",
    "ToolCall",
    "Usage",
]
