"""Core types: LLMResponse, Usage, StreamChunk, Candidate, RoutingContext."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from llm_rotator.config import ClientType


@dataclass(frozen=True)
class Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass(frozen=True)
class ToolCall:
    id: str
    name: str
    arguments: str  # JSON string


@dataclass(frozen=True)
class LLMResponse:
    content: str | None
    usage: Usage
    model: str
    provider: str
    key_alias: str
    tool_calls: list[ToolCall] | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class StreamChunk:
    delta: str
    usage: Usage | None = None
    done: bool = False
    tool_calls: list[ToolCall] | None = None


@dataclass(frozen=True)
class Candidate:
    provider_name: str
    model: str
    key_alias: str
    key_token: str
    model_group: str | None
    base_url: str | None
    client_type: ClientType


@dataclass
class RoutingContext:
    tier: int = 1
    model_group: str | None = None
    allowed_providers: list[str] | None = None
    allow_downgrade: bool = True
    tags: dict[str, Any] = field(default_factory=dict)
