# Remote
این کتابخانه فقط برای استفاده شخصی است.

## نصب
```bash
pip install git+https://github.com/MohammadAhmadi-R/private-pylib.git