"""
Main Bot Entry
Production Ready
Single Router Architecture
"""

import asyncio
import logging
import signal
from contextlib import suppress

from pyrogram import Client, filters, idle
from pyrogram.types import Message

from ..config import main_config
from .command_router import CommandRouter
import os
from ..config.main_config import SESSIONS_DIR 
 
os.makedirs(SESSIONS_DIR, exist_ok=True)
# ==========================================================
# LOGGING CONFIG
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

logger = logging.getLogger("REMOTTXREA_BOT")


# ==========================================================
# CREATE APP
# ==========================================================

def create_app() -> Client:
    if not main_config.BOT_TOKEN:
        raise ValueError("BOT_TOKEN is not set")

    if not main_config.API_ID:
        raise ValueError("API_ID is not set")

    if not main_config.API_HASH:
        raise ValueError("API_HASH is not set")

    logger.info("Creating bot client...")

    return Client(
        name="remottxrea_bot",
        bot_token=main_config.BOT_TOKEN,
        api_id=main_config.API_ID,
        api_hash=main_config.API_HASH,
        workers=10,
        in_memory=True,
    )


# ==========================================================
# RUN
# ==========================================================

def run():

    app = create_app()
    router = CommandRouter()

    @app.on_message(filters.private)
    async def handle_private(client: Client, message: Message):
        try:
            await router.dispatch(client, message)
        except Exception:
            logger.exception("Unhandled exception in dispatch")
            await message.reply("⚠️ Internal error occurred.")

    async def main():
        await app.start()
        logger.info("Bot is running...")
        await idle()

    async def shutdown():
        logger.info("Stopping bot...")
        with suppress(Exception):
            await router.shutdown()
        with suppress(Exception):
            await app.stop()
        logger.info("Bot stopped cleanly.")

    loop = asyncio.get_event_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig,
            lambda: asyncio.create_task(shutdown())
        )

    try:
        loop.run_until_complete(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Exit signal received.")
    finally:
        loop.run_until_complete(shutdown())
        loop.close()


# ==========================================================
# ENTRY POINT
# ==========================================================

if __name__ == "__main__":
    run()