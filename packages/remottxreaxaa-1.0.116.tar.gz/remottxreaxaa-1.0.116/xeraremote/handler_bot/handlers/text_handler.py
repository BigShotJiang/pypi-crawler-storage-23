from pyrogram.types import Message
from pyrogram import Client

from ...core.text_store import text_store


# ==============================================
# /text something
# ==============================================

async def handle_add_text(client: Client, message: Message):

    parts = message.text.split(" ", 1)

    if len(parts) < 2:
        await message.reply("Usage: /text your text here")
        return

    text = parts[1]

    ok = await text_store.add(text)

    if ok:
        await message.reply("✅ Added")
    else:
        await message.reply("⚠️ Already exists or empty")


# ==============================================
# /deltext something
# ==============================================

async def handle_remove_text(client: Client, message: Message):

    parts = message.text.split(" ", 1)

    if len(parts) < 2:
        await message.reply("Usage: /deltext text")
        return

    ok = await text_store.remove(parts[1])

    if ok:
        await message.reply("🗑 Removed")
    else:
        await message.reply("❌ Not found")


# ==============================================
# /textmulti (reply to multi-line message)
# ==============================================

async def handle_add_multi(client: Client, message: Message):

    if not message.reply_to_message:
        await message.reply("Reply to a multi-line message.")
        return

    text_block = message.reply_to_message.text

    count = await text_store.add_multi(text_block)

    await message.reply(f"✅ {count} lines added")


# ==============================================
# /listtext
# ==============================================

async def handle_list_text(client: Client, message: Message):

    items = await text_store.list()

    if not items:
        await message.reply("List is empty.")
        return

    formatted = "\n".join(
        f"{i+1}. {t}" for i, t in enumerate(items)
    )

    await message.reply(f"Stored Texts:\n\n{formatted}")


# ==============================================
# /cleartext
# ==============================================

async def handle_clear(client: Client, message: Message):

    await text_store.clear()
    await message.reply("🧹 Cleared")