"""
Sender + Target Full Integration Handler
Multi-Session Ready
Production Grade
"""

import asyncio
from typing import Dict, Optional

from ...actions.sender_engine import SenderEngine
from ...actions.target_spammer import TargetManager


class SenderHandlers:

    def __init__(self, session_manager):
        """
        session_manager must provide:
            - get_client(session_name) -> pyrogram.Client
            - get_all_sessions() -> list[str]
        """
        self.session_manager = session_manager

        # session_name -> SenderEngine
        self.senders: Dict[str, SenderEngine] = {}

        # session_name -> TargetManager
        self.target_managers: Dict[str, TargetManager] = {}

        # Global sender config
        self.sender_text: Optional[str] = None
        self.sender_delay: float = 2.0

    # ==========================================================
    async def handle(self, message):

        if not message.text:
            return

        parts = message.text.strip().split()
        command = parts[0].lower()

        # ------------------------------
        # Sender Commands
        # ------------------------------

        if command == "start_sender":
            await self._start_sender(message)

        elif command == "stop_sender":
            await self._stop_sender(message)

        # ------------------------------
        # Target Commands
        # ------------------------------

        elif command == "add_target":
            await self._add_target(message, parts)

        elif command == "list_targets":
            await self._list_targets(message)

        elif command == "remove_target":
            await self._remove_target(message, parts)

        elif command == "test_target":
            await self._test_target(message, parts)

        # ------------------------------
        # Config Commands
        # ------------------------------

        elif command == "add_text":
            await self._add_text(message)

        elif command == "add_delay":
            await self._add_delay(message, parts)

    # ==========================================================
    # SESSION HELPERS
    # ==========================================================

    def _get_target_manager(self, session_name: str) -> TargetManager:
        if session_name not in self.target_managers:
            client = self.session_manager.get_client(session_name)
            self.target_managers[session_name] = TargetManager(
                client,
                config_path=f"spammer_config_{session_name}.json"
            )
        return self.target_managers[session_name]

    def _get_sender(self, session_name: str) -> SenderEngine:
        if session_name not in self.senders:
            client = self.session_manager.get_client(session_name)
            self.senders[session_name] = SenderEngine(
                client,
                session_name=session_name,
                base_delay=self.sender_delay
            )
        return self.senders[session_name]

    # ==========================================================
    # SENDER COMMANDS
    # ==========================================================

    async def _start_sender(self, message):

        if not self.sender_text:
            await message.reply("No text configured. Use add_text first.")
            return

        sessions = self.session_manager.get_all_sessions()

        if not sessions:
            await message.reply("No active sessions.")
            return

        for session_name in sessions:
            sender = self._get_sender(session_name)
            target_manager = self._get_target_manager(session_name)
            targets = target_manager.list_targets()

            if not targets:
                continue

            for target in targets:
                await sender.start(
                    target=target["chat_id"],
                    message=self.sender_text
                )

        await message.reply("Sender started on all sessions.")

    async def _stop_sender(self, message):

        for sender in self.senders.values():
            await sender.stop()

        await message.reply("All senders stopped.")

    # ==========================================================
    # TARGET COMMANDS
    # ==========================================================

    async def _add_target(self, message, parts):

        if len(parts) < 2:
            await message.reply("Usage: add_target <id | username | link>")
            return

        raw_target = parts[1]
        sessions = self.session_manager.get_all_sessions()

        if not sessions:
            await message.reply("No active sessions.")
            return

        results = []

        for session_name in sessions:
            try:
                manager = self._get_target_manager(session_name)
                target = await manager.add_target(raw_target)
                results.append(f"{session_name}: OK ({target['chat_id']})")
            except Exception as e:
                results.append(f"{session_name}: ERROR ({e})")

        await message.reply("\n".join(results))

    async def _list_targets(self, message):

        sessions = self.session_manager.get_all_sessions()
        output = []

        for session_name in sessions:
            manager = self._get_target_manager(session_name)
            targets = manager.list_targets()

            output.append(f"\nSession: {session_name}")

            if not targets:
                output.append("  No targets.")
            else:
                for t in targets:
                    output.append(
                        f"  - {t['chat_id']} | {t.get('username')}"
                    )

        await message.reply("\n".join(output))

    async def _remove_target(self, message, parts):

        if len(parts) < 2:
            await message.reply("Usage: remove_target <chat_id>")
            return

        try:
            chat_id = int(parts[1])
        except ValueError:
            await message.reply("chat_id must be numeric.")
            return

        sessions = self.session_manager.get_all_sessions()
        results = []

        for session_name in sessions:
            try:
                manager = self._get_target_manager(session_name)
                manager.remove_target(chat_id)
                results.append(f"{session_name}: removed")
            except Exception as e:
                results.append(f"{session_name}: {e}")

        await message.reply("\n".join(results))

    async def _test_target(self, message, parts):

        if len(parts) < 2:
            await message.reply("Usage: test_target <chat_id>")
            return

        try:
            chat_id = int(parts[1])
        except ValueError:
            await message.reply("chat_id must be numeric.")
            return

        sessions = self.session_manager.get_all_sessions()
        results = []

        for session_name in sessions:
            try:
                manager = self._get_target_manager(session_name)
                await manager.test_target(chat_id)
                results.append(f"{session_name}: OK")
            except Exception as e:
                results.append(f"{session_name}: FAIL ({e})")

        await message.reply("\n".join(results))

    # ==========================================================
    # CONFIG COMMANDS
    # ==========================================================

    async def _add_text(self, message):

        if not message.text or len(message.text.split()) < 2:
            await message.reply("Usage: add_text <your message>")
            return

        self.sender_text = message.text.split(maxsplit=1)[1]
        await message.reply("Sender text updated.")

    async def _add_delay(self, message, parts):

        if len(parts) < 2:
            await message.reply("Usage: add_delay <seconds>")
            return

        try:
            delay = float(parts[1])
        except ValueError:
            await message.reply("Delay must be numeric.")
            return

        self.sender_delay = delay

        # Update running senders
        for sender in self.senders.values():
            sender.base_delay = delay

        await message.reply(f"Delay updated to {delay} seconds.")