
class Start:
    async def handle(self, message):         
        msg = await message.reply_text("⏳...")
        startMSG = '''
/addaccount
    /phone
        /code
            /2fa
    /cancel
    
/leave
/join
/changephoto
/changename
/changefname
/listacc
        
        '''

        await msg.edit_text(f"```\n{startMSG}\n```")