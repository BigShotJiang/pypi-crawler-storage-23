"""
Command Router
Single dispatch entry point
"""

import logging

from ..config.main_config import is_admin
from .command_registry import CommandRegistry


logger = logging.getLogger("REMOTTXREA_BOT")


class CommandRouter:

    def __init__(self):
        self.registry = CommandRegistry()

    # --------------------------------------------------
    async def dispatch(self, client, message):

        if not message or not message.from_user:
            return

        user_id = message.from_user.id

        # ---- admin guard ----
        if not is_admin(user_id):
            logger.warning(f"Unauthorized access attempt: {user_id}")
            return

        # ---- resolve handler ----
        handler = self.registry.resolve(message)

        if not handler:
            return

        await handler.handle(message)

    # --------------------------------------------------
    async def shutdown(self):
        """
        Graceful shutdown hook
        """
        if hasattr(self.registry, "runner"):
            await self.registry.runner.stop_all()