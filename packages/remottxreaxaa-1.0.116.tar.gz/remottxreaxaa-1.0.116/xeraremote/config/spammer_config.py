# remottxrea/config/spammer_config.py

"""
Spammer Config
تنظیمات مربوط به تارگت سندر
ذخیره و مدیریت چت آیدی مقصد
"""

import os
import json
from typing import Optional, Dict, Any, Union

from ..core.logger import get_action_logger


class SpammerConfig:
    """
    کانفیگ اختصاصی برای تارگت سندر
    شبیه main_config.py اما مخصوص اسپمر
    """

    # فایل ذخیره سازی تارگت
    CONFIG_DIR = os.path.dirname(os.path.dirname(__file__))
    TARGET_FILE = os.path.join(CONFIG_DIR, "data", "spammer_target.json")

    # مقدار پیشفرض تارگت
    TARGET_CHAT_ID: Optional[Union[int, str]] = None
    TARGET_TYPE: Optional[str] = None  # "private_link", "public_link", "username", "numeric_id"
    TARGET_RAW: Optional[str] = None

    logger = get_action_logger(
        action="spammer_config",
        session="global"
    )

    @classmethod
    def _ensure_data_dir(cls):
        """ایجاد پوشه data اگه وجود نداشت"""
        os.makedirs(os.path.dirname(cls.TARGET_FILE), exist_ok=True)

    @classmethod
    def save_target(cls, target: Union[str, int], target_type: str = None, raw: str = None) -> bool:
        """
        ذخیره تارگت در فایل JSON
        """
        cls._ensure_data_dir()

        data = {
            "target_chat_id": target,
            "target_type": target_type,
            "target_raw": raw or str(target),
            "updated_at": __import__('datetime').datetime.now().isoformat()
        }

        try:
            with open(cls.TARGET_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            cls.TARGET_CHAT_ID = target
            cls.TARGET_TYPE = target_type
            cls.TARGET_RAW = raw or str(target)

            cls.logger.info(f"Target saved: {target} (type: {target_type})")
            return True

        except Exception as e:
            cls.logger.error(f"Failed to save target: {e}")
            return False

    @classmethod
    def load_target(cls) -> Optional[Dict[str, Any]]:
        """لود تارگت از فایل JSON"""
        if not os.path.exists(cls.TARGET_FILE):
            return None

        try:
            with open(cls.TARGET_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)

            cls.TARGET_CHAT_ID = data.get("target_chat_id")
            cls.TARGET_TYPE = data.get("target_type")
            cls.TARGET_RAW = data.get("target_raw")

            return data

        except Exception as e:
            cls.logger.error(f"Failed to load target: {e}")
            return None

    @classmethod
    def clear_target(cls) -> bool:
        """پاک کردن تارگت ذخیره شده"""
        try:
            if os.path.exists(cls.TARGET_FILE):
                os.remove(cls.TARGET_FILE)

            cls.TARGET_CHAT_ID = None
            cls.TARGET_TYPE = None
            cls.TARGET_RAW = None

            cls.logger.info("Target cleared")
            return True

        except Exception as e:
            cls.logger.error(f"Failed to clear target: {e}")
            return False

    @classmethod
    def get_target(cls) -> Optional[Union[int, str]]:
        """گرفتن آیدی تارگت"""
        if cls.TARGET_CHAT_ID is None:
            cls.load_target()
        return cls.TARGET_CHAT_ID

    @classmethod
    def is_target_set(cls) -> bool:
        """چک کردن اینکه تارگت تنظیم شده یا نه"""
        return cls.get_target() is not None


# ==================================================
# شورتکات‌ها (مثل main_config.py)
# ==================================================

TARGET_CHAT_ID = SpammerConfig.TARGET_CHAT_ID
TARGET_TYPE = SpammerConfig.TARGET_TYPE
TARGET_RAW = SpammerConfig.TARGET_RAW


def set_target(target: Union[str, int], target_type: str = None, raw: str = None) -> bool:
    """تنظیم تارگت جدید"""
    return SpammerConfig.save_target(target, target_type, raw)


def get_target() -> Optional[Union[int, str]]:
    """گرفتن تارگت فعلی"""
    return SpammerConfig.get_target()


def clear_target() -> bool:
    """پاک کردن تارگت"""
    return SpammerConfig.clear_target()


def is_target_active() -> bool:
    """آیا تارگت فعال است"""
    return SpammerConfig.is_target_set()


# ==================================================
# اطمینان از وجود پوشه data
# ==================================================
os.makedirs(os.path.dirname(SpammerConfig.TARGET_FILE), exist_ok=True)