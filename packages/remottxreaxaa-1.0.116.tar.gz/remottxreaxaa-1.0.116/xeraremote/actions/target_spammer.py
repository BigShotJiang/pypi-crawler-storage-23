 
import json 
from pathlib import Path
from typing import Dict, Any, List
from ..core.logger import get_action_logger
from pyrogram.errors import (
    UsernameInvalid,
    PeerIdInvalid,
    RPCError,
)

logger = get_action_logger(        
        action="spammer_target",
        session="global")

class TargetError(Exception):
    pass


class TargetManager:
    """
    Multi-target manager for spammer system.

    Features:
    - Add target (id | username | link)
    - Remove target
    - List targets
    - Test connection
    - Persistent JSON storage
    """

    def init(self, client, config_path: str = "spammer_config.json"):
        self.client = client
        self.config_path = Path(config_path)
        self._ensure_config_exists()

    # =====================================================
    # PUBLIC API
    # =====================================================

    async def add_target(self, raw_input: str) -> Dict[str, Any]:
        chat = await self._resolve_target(raw_input)
        await self._validate_write_access(chat)

        target_data = self._normalize_chat(chat)

        config = self._load_config()

        if self._target_exists(config, target_data["chat_id"]):
            raise TargetError("Target already exists.")

        config["targets"].append(target_data)
        self._save_config(config)

        logger.info(f"Target added: {target_data['chat_id']}")
        return target_data

    def list_targets(self) -> List[Dict[str, Any]]:
        config = self._load_config()
        return config.get("targets", [])

    def remove_target(self, chat_id: int) -> bool:
        config = self._load_config()

        original_count = len(config["targets"])
        config["targets"] = [
            t for t in config["targets"] if t["chat_id"] != chat_id
        ]

        if len(config["targets"]) == original_count:
            raise TargetError("Target not found.")

        self._save_config(config)
        logger.info(f"Target removed: {chat_id}")
        return True

    async def test_target(self, chat_id: int) -> bool:
        try:
            await self.client.send_chat_action(chat_id, "typing")
            return True
        except Exception as e:
            raise TargetError(f"Connection test failed: {e}")

    # =====================================================
    # RESOLVE
    # =====================================================

    async def _resolve_target(self, raw_input: str):
        try:
            chat = await self.client.get_chat(raw_input)
            return chat

        except (UsernameInvalid, PeerIdInvalid):
            raise TargetError("Invalid username or ID.")

        except RPCError as e:
            raise TargetError(f"Telegram error: {e}")

        except Exception as e:
            raise TargetError(f"Unexpected error: {e}")

    # =====================================================
    # VALIDATION
    # =====================================================

    async def _validate_write_access(self, chat):
        try:
            await self.client.send_chat_action(chat.id, "typing")
        except Exception as e:
            raise TargetError(
                f"No write access to this target: {e}"
            )

    # =====================================================
    # NORMALIZATION
    # =====================================================

    def _normalize_chat(self, chat) -> Dict[str, Any]:
        return {
            "chat_id": chat.id,
            "title": getattr(chat, "title", None),
            "username": getattr(chat, "username", None),
            "type": str(chat.type),
        }

    # =====================================================
    # CONFIG HANDLING
    # =====================================================

    def _ensure_config_exists(self):
        if not self.config_path.exists():
            self._save_config({"targets": []})
 
    def _load_config(self) -> Dict[str, Any]:
            try:
                return json.loads(self.config_path.read_text())
            except Exception:
                logger.warning("Config corrupted. Rebuilding.")
                config = {"targets": []}
                self._save_config(config)
                return config

    def _save_config(self, config: Dict[str, Any]):
        self.config_path.write_text(
            json.dumps(config, indent=4, ensure_ascii=False)
        )

    def _target_exists(self, config: Dict[str, Any], chat_id: int) -> bool:
        return any(t["chat_id"] == chat_id for t in config["targets"])