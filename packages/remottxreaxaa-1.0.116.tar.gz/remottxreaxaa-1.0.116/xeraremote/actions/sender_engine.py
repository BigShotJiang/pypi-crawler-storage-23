"""
Final Sender Engine
Integrated with SpammerConfig
Multi Target + Multi Text + Anti-Ban
Production Ready
"""

import asyncio
import logging
from typing import Optional
from pyrogram.errors import FloodWait, RPCError
from ..core.logger import get_action_logger
from xeraremote.config.spammer_config import SpammerConfig

logger = get_action_logger(        
        action="spammer_sender",
        session="global")



class SenderEngine:

    def __init__(self, client, session_name: str):
        self.client = client
        self.session_name = session_name

        self._running = False
        self._task: Optional[asyncio.Task] = None

        self._consecutive_errors = 0

    # =====================================================
    # PUBLIC API
    # =====================================================

    async def start(self):

        if self._running:
            return

        self._running = True
        self._task = asyncio.create_task(self._run())

        logger.info(f"[{self.session_name}] Sender started.")

    async def stop(self):

        self._running = False

        if self._task:
            await self._task

        logger.info(f"[{self.session_name}] Sender stopped.")

    def is_running(self):
        return self._running

    # =====================================================
    # MAIN LOOP
    # =====================================================

    async def _run(self):

        while self._running:

            targets = SpammerConfig.get_targets()
            text = SpammerConfig.get_random_text()

            if not targets:
                logger.warning("No targets configured.")
                await asyncio.sleep(5)
                continue

            if not text:
                logger.warning("No texts configured.")
                await asyncio.sleep(5)
                continue

            for target in targets:

                if not self._running:
                    break

                try:
                    await self.client.send_message(
                        target["chat_id"],
                        text
                    )

                    self._consecutive_errors = 0

                except FloodWait as e:

                    wait_time = e.value
                    logger.warning(
                        f"[{self.session_name}] FloodWait {wait_time}s"
                    )

                    await asyncio.sleep(wait_time)
                    continue

                except RPCError as e:
                    self._consecutive_errors += 1
                    logger.error(
                        f"[{self.session_name}] RPC Error: {e}"
                    )

                    if self._consecutive_errors >= 5:
                        logger.error(
                            f"[{self.session_name}] Circuit breaker triggered."
                        )
                        self._running = False
                        break

                except Exception as e:
                    logger.error(
                        f"[{self.session_name}] Unexpected error: {e}"
                    )

                # delay from config (with anti-ban)
                delay = SpammerConfig.get_random_delay()
                await asyncio.sleep(delay)

        logger.info(f"[{self.session_name}] Loop exited.")