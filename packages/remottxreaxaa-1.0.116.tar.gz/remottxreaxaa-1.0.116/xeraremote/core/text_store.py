# remottxrea/core/text_store.py

import os
import json
import asyncio
from typing import List


DATA_PATH = "downloads/text_store.json"


class TextStore:
    """
    Thread-safe in-memory list
    + JSON persistence
    """

    def __init__(self):
        self._items: List[str] = []
        self._lock = asyncio.Lock()

    # ======================================================
    # INIT
    # ======================================================

    async def load(self):
        if not os.path.exists(DATA_PATH):
            os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
            await self._save()
            return

        async with self._lock:
            try:
                with open(DATA_PATH, "r", encoding="utf-8") as f:
                    self._items = json.load(f)
            except Exception:
                self._items = []

    async def _save(self):
        with open(DATA_PATH, "w", encoding="utf-8") as f:
            json.dump(self._items, f, ensure_ascii=False, indent=2)

    # ======================================================
    # CRUD
    # ======================================================

    async def add(self, text: str) -> bool:
        text = text.strip()
        if not text:
            return False

        async with self._lock:
            if text in self._items:
                return False

            self._items.append(text)
            await self._save()
            return True

    async def add_multi(self, text_block: str) -> int:
        """
        Add multi-line text (each line separately)
        """
        lines = [
            line.strip()
            for line in text_block.splitlines()
            if line.strip()
        ]

        added = 0

        async with self._lock:
            for line in lines:
                if line not in self._items:
                    self._items.append(line)
                    added += 1

            await self._save()

        return added

    async def remove(self, text: str) -> bool:
        text = text.strip()

        async with self._lock:
            if text not in self._items:
                return False

            self._items.remove(text)
            await self._save()
            return True

    async def clear(self):
        async with self._lock:
            self._items.clear()
            await self._save()

    async def list(self) -> List[str]:
        async with self._lock:
            return list(self._items)


# singleton
text_store = TextStore()