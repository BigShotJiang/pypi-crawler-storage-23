"""
core/rpc_handler.py

Handles Telegram RPC errors
Classification + logging
"""

from pyrogram.errors import RPCError

from ..core.logger import get_action_logger


class RPCHandler:

    @staticmethod
    async def handle(
        error: RPCError,
        session_name: str,
        action: str
    ):

        logger = get_action_logger(
            action="rpc_handler",
            session=session_name
        )

        err_name = error.__class__.__name__

        logger.error(
            f"RPC Error | "
            f"Action={action} | "
            f"Type={err_name} | "
            f"Message={error}"
        )

        # دسته‌بندی پایه
        if "PEER_FLOOD" in err_name:
            logger.critical(
                "PeerFlood detected → risk flag"
            )

        elif "USER_BANNED" in err_name:
            logger.critical(
                "User banned / deactivated"
            )

        elif "CHAT_WRITE_FORBIDDEN" in err_name:
            logger.warning(
                "Write forbidden in chat"
            )

        # فعلاً retry نمی‌کنیم
        return False
