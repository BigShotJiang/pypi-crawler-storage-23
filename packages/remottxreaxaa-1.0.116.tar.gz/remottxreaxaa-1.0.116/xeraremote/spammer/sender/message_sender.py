# sender/message_sender.py

import os
from telethon import TelegramClient

from core.config import Config
from core.device_pool import get_device
from core.safe_executor import safe_executor


class MessageSender:

    async def send(self, session: str, target: str, text: str):

        device = get_device()

        client = TelegramClient(
            os.path.join(Config.SESSIONS_DIR, session),
            Config.API_ID,
            Config.API_HASH,
            device_model=device["device_model"],
            system_version=device["system_version"],
            app_version=device["app_version"]
        )

        await client.connect()

        async def _send():
            return await client.send_message(target, text)

        await safe_executor.execute(
            key=session,
            coro=_send
        )

        await client.disconnect()
