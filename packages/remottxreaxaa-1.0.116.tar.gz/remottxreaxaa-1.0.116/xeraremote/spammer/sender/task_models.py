from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class Task:

    account: str
    method: str
    func: Any
    args: tuple
    kwargs: Dict

    retries: int = 0
    max_retries: int = 3
