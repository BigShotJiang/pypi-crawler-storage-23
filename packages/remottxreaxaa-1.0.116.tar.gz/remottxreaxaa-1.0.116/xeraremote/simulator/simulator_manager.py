# remottxrea/simulator/simulator_manager.py

import asyncio
import random


class SimulatorManager:

    # ---------- TYPING ----------
    async def typing(
        self,
        app,
        chat_id,
        duration_range=(3, 7)
    ):

        duration = random.uniform(
            *duration_range
        )

        async with app.send_chat_action(
            chat_id,
            "typing"
        ):

            await asyncio.sleep(duration)

    # ---------- ONLINE ----------
    async def online_pulse(
        self,
        app,
        duration_range=(5, 12)
    ):

        # صرفاً نگه داشتن اتصال
        duration = random.uniform(
            *duration_range
        )

        await asyncio.sleep(duration)

    # ---------- READ ----------
    async def read(
        self,
        app,
        chat_id,
        max_id=0
    ):

        await app.read_chat_history(
            chat_id,
            max_id=max_id
        )

    # ---------- ORCHESTRATION ----------
    async def simulate_session_cycle(
        self,
        app,
        chat_id
    ):

        await self.online_pulse(app)

        await self.typing(app, chat_id)

        await asyncio.sleep(
            random.uniform(2, 5)
        )

        await self.read(app, chat_id)


simulator_manager = SimulatorManager()
