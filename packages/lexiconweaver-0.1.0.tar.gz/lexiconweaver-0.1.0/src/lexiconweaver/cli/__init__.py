"""CLI interface for LexiconWeaver."""

from lexiconweaver.cli.commands import app, main

__all__ = ["app", "main"]
