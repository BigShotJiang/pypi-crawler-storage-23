"""Main entry point for LexiconWeaver."""

from lexiconweaver.cli.commands import main

if __name__ == "__main__":
    main()
