"""LexiconWeaver: A robust, human-in-the-loop framework for web novel translation."""

__version__ = "0.1.0"
__author__ = "LexiconWeaver Contributors"
