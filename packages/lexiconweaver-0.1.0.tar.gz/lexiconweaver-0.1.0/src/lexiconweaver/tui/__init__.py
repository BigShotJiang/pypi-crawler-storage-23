"""Terminal User Interface for LexiconWeaver."""

from lexiconweaver.tui.app import LexiconWeaverApp

__all__ = ["LexiconWeaverApp"]
