"""Attention layers with Rotary Position Embeddings.

This module provides BERT-compatible attention layers that use RoPE
for position encoding instead of learned position embeddings.
"""

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn

__all__ = [
    "BertSelfAttentionWithRoPE",
    "BertAttentionWithRoPE",
    "BertSelfOutput",
]
import torch.nn.functional as F
from torch import Tensor
from transformers import BertConfig

from .rope import RotaryPositionEmbedding


class BertSelfAttentionWithRoPE(nn.Module):
    """BERT self-attention with Rotary Position Embeddings.

    Drop-in replacement for BertSelfAttention that uses RoPE for
    position encoding. Compatible with the same interface.

    Args:
        config: BERT configuration
        rope_base: Base frequency for RoPE (default 10000.0)
        position_embedding_type: Ignored, always uses RoPE
    """

    def __init__(
        self,
        config: BertConfig,
        rope_base: float = 10000.0,
        position_embedding_type: Optional[str] = None,
    ):
        super().__init__()
        if config.hidden_size % config.num_attention_heads != 0 and not hasattr(
            config, "embedding_size"
        ):
            raise ValueError(
                f"hidden_size ({config.hidden_size}) is not a multiple of "
                f"num_attention_heads ({config.num_attention_heads})"
            )

        self.num_attention_heads = config.num_attention_heads
        self.attention_head_size = config.hidden_size // config.num_attention_heads
        self.all_head_size = self.num_attention_heads * self.attention_head_size

        # Q, K, V projections
        # TODO getattr is a code smell
        use_bias = getattr(config, 'use_bias', False)
        use_bias = config.use_bias
        self.query = nn.Linear(config.hidden_size, self.all_head_size, bias=use_bias)
        self.key = nn.Linear(config.hidden_size, self.all_head_size, bias=use_bias)
        self.value = nn.Linear(config.hidden_size, self.all_head_size, bias=use_bias)

        # Attention dropout
        dropout_prob = getattr(config, 'dropout_attn_weights', config.attention_probs_dropout_prob)
        self.dropout = nn.Dropout(dropout_prob)

        # RoPE - applied to Q and K
        self.rotary_emb = RotaryPositionEmbedding(
            dim=self.attention_head_size,
            base=rope_base,
        )

        # Store config for reference
        self.config = config
        self.rope_base = rope_base

    def transpose_for_scores(self, x: Tensor) -> Tensor:
        """Reshape for multi-head attention.

        Args:
            x: Input tensor (batch, seq_len, all_head_size)

        Returns:
            Reshaped tensor (batch, num_heads, seq_len, head_size)
        """
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        head_mask: Optional[Tensor] = None,
        encoder_hidden_states: Optional[Tensor] = None,
        encoder_attention_mask: Optional[Tensor] = None,
        past_key_value: Optional[Tuple[Tensor, Tensor]] = None,
        output_attentions: bool = False,
        position_ids: Optional[Tensor] = None,
    ) -> Tuple[Tensor, ...]:
        """Forward pass.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size)
            attention_mask: Attention mask (batch, 1, 1, seq_len) or (batch, 1, seq_len, seq_len)
            head_mask: Optional head mask
            encoder_hidden_states: For cross-attention (not used)
            encoder_attention_mask: For cross-attention (not used)
            past_key_value: For incremental decoding (not fully supported)
            output_attentions: Whether to return attention weights
            position_ids: Optional position indices for RoPE

        Returns:
            Tuple of (context_layer, attention_probs) if output_attentions else (context_layer,)
        """
        # Project Q, K, V
        query_layer = self.transpose_for_scores(self.query(hidden_states))
        key_layer = self.transpose_for_scores(self.key(hidden_states))
        value_layer = self.transpose_for_scores(self.value(hidden_states))

        # Apply RoPE to Q and K
        query_layer, key_layer = self.rotary_emb(query_layer, key_layer, position_ids)

        # Handle past key values for incremental decoding
        if past_key_value is not None:
            key_layer = torch.cat([past_key_value[0], key_layer], dim=2)
            value_layer = torch.cat([past_key_value[1], value_layer], dim=2)

        # Compute attention scores: Q @ K^T / sqrt(d)
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)

        # Apply attention mask
        if attention_mask is not None:
            attention_scores = attention_scores + attention_mask

        # Softmax and dropout
        attention_probs = F.softmax(attention_scores, dim=-1)
        attention_probs = self.dropout(attention_probs)

        # Apply head mask if provided
        if head_mask is not None:
            attention_probs = attention_probs * head_mask

        # Compute context: attention @ V
        context_layer = torch.matmul(attention_probs, value_layer)

        # Reshape back: (batch, num_heads, seq_len, head_size) -> (batch, seq_len, all_head_size)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(new_context_layer_shape)

        outputs = (context_layer, attention_probs) if output_attentions else (context_layer,)

        return outputs

class BertAttentionWithRoPE(nn.Module):
    """BERT attention block with RoPE (self-attention + output projection).

    This wraps BertSelfAttentionWithRoPE with the output projection layer.
    Drop-in replacement for BertAttention.

    Args:
        config: BERT configuration
        rope_base: Base frequency for RoPE
    """

    def __init__(self, config: BertConfig, rope_base: float = 10000.0):
        super().__init__()
        self.self = BertSelfAttentionWithRoPE(config, rope_base=rope_base)
        self.output = BertSelfOutput(config)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        head_mask: Optional[Tensor] = None,
        encoder_hidden_states: Optional[Tensor] = None,
        encoder_attention_mask: Optional[Tensor] = None,
        past_key_value: Optional[Tuple[Tensor, Tensor]] = None,
        output_attentions: bool = False,
        position_ids: Optional[Tensor] = None,
        # Additional parameters for compatibility with BertLayer
        past_key_values: Optional[Tuple[Tensor, Tensor]] = None,
        cache_position: Optional[Tensor] = None,
        **kwargs,
    ) -> Tuple[Tensor, ...]:
        """Forward pass."""
        # Use past_key_values if past_key_value is None (compatibility)
        effective_past_key_value = past_key_value if past_key_value is not None else past_key_values

        self_outputs = self.self(
            hidden_states,
            attention_mask,
            head_mask,
            encoder_hidden_states,
            encoder_attention_mask,
            effective_past_key_value,
            output_attentions,
            position_ids,
        )
        attention_output = self.output(self_outputs[0], hidden_states)
        outputs = (attention_output,) + self_outputs[1:]
        return outputs

class BertSelfOutput(nn.Module):
    """BERT self-attention output projection."""

    def __init__(self, config: BertConfig):
        super().__init__()
        use_bias = getattr(config, 'use_bias', False)
        self.dense = nn.Linear(config.hidden_size, config.hidden_size, bias=use_bias)
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps, bias=use_bias)
        dropout_prob = getattr(config, 'dropout_attn_output', getattr(config, 'dropout_mlp', 0.1))
        self.dropout = nn.Dropout(dropout_prob)

    def forward(self, hidden_states: Tensor, input_tensor: Tensor) -> Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)
        return hidden_states
