"""Flash Attention utilities for efficient attention computation.

This module provides a unified interface for Flash Attention 2/3 and PyTorch SDPA,
with automatic fallback to eager attention when flash implementations are unavailable.

Supported implementations:
- "eager": Standard PyTorch matmul-based attention
- "sdpa": PyTorch's scaled_dot_product_attention (built-in since PyTorch 2.0)
- "flash_attention_2": Flash Attention 2 (requires flash-attn package)
- "flash_attention_3": Flash Attention 3 (requires flash_attn_3 package, Hopper GPUs only)
"""

import importlib.metadata
import importlib.util
import logging
import math
from functools import lru_cache
from typing import Optional, Tuple

import torch
import torch.nn.functional as F
from packaging import version
from torch import Tensor

logger = logging.getLogger(__name__)

__all__ = [
    "is_flash_attn_2_available",
    "is_flash_attn_3_available",
    "is_sdpa_available",
    "get_available_implementations",
    "validate_attn_implementation",
    "eager_attention",
    "sdpa_attention",
    "flash_attention_2",
    "flash_attention_3",
    "flash_attention_2_varlen",
    "flash_attention_3_varlen",
    "sdpa_attention_varlen",
    "eager_attention_varlen",
    "attention_forward",
]


@lru_cache(maxsize=1)
def is_flash_attn_2_available() -> bool:
    """Check if Flash Attention 2 is available."""
    if not importlib.util.find_spec("flash_attn"):
        return False

    if not torch.cuda.is_available():
        return False

    try:
        fa_version = importlib.metadata.version("flash_attn")
        if torch.version.cuda:
            return version.parse(fa_version) >= version.parse("2.1.0")
        elif torch.version.hip:
            # ROCm support
            return version.parse(fa_version) >= version.parse("2.0.4")
    except importlib.metadata.PackageNotFoundError:
        return False

    return False


@lru_cache(maxsize=1)
def is_flash_attn_3_available() -> bool:
    """Check if Flash Attention 3 is available (Hopper GPUs only)."""
    if not importlib.util.find_spec("flash_attn_3"):
        return False

    if not torch.cuda.is_available():
        return False

    # FA3 only supports Hopper architecture (H100, etc.)
    return True


@lru_cache(maxsize=1)
def is_sdpa_available() -> bool:
    """Check if PyTorch's scaled_dot_product_attention is available."""
    return hasattr(F, "scaled_dot_product_attention")


def get_available_implementations() -> list[str]:
    """Return list of available attention implementations."""
    available = ["eager"]
    if is_sdpa_available():
        available.append("sdpa")
    if is_flash_attn_2_available():
        available.append("flash_attention_2")
    if is_flash_attn_3_available():
        available.append("flash_attention_3")
    return available


def validate_attn_implementation(implementation: Optional[str]) -> str:
    """Validate and potentially adjust the attention implementation.

    Args:
        implementation: Requested attention implementation (None defaults to "sdpa")

    Returns:
        Validated implementation (may fall back to a supported option)

    Raises:
        ValueError: If implementation is not recognized
    """
    # Default to flash_attention_2 if not specified
    if implementation is None:
        implementation = "flash_attention_2"

    valid_implementations = {"eager", "sdpa", "flash_attention_2", "flash_attention_3"}

    if implementation not in valid_implementations:
        raise ValueError(
            f"Unknown attention implementation: {implementation}. "
            f"Valid options are: {valid_implementations}"
        )

    available = get_available_implementations()

    if implementation in available:
        return implementation

    # Fall back to best available
    if implementation == "flash_attention_3" and "flash_attention_2" in available:
        logger.warning(
            "Flash Attention 3 not available, falling back to Flash Attention 2"
        )
        return "flash_attention_2"

    if implementation in ("flash_attention_2", "flash_attention_3"):
        if "sdpa" in available:
            logger.warning(
                f"{implementation} not available, falling back to SDPA"
            )
            return "sdpa"
        logger.warning(
            f"{implementation} not available, falling back to eager attention"
        )
        return "eager"

    if implementation == "sdpa":
        logger.warning("SDPA not available, falling back to eager attention")
        return "eager"

    return "eager"


def eager_attention(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    attention_mask: Optional[Tensor] = None,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Standard eager attention using matmul.

    Args:
        query: (batch, num_heads, seq_len, head_dim)
        key: (batch, num_heads, seq_len, head_dim)
        value: (batch, num_heads, seq_len, head_dim)
        attention_mask: Additive mask (batch, 1, 1, seq_len) with -inf for masked
        dropout_p: Dropout probability
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode (affects dropout)

    Returns:
        Attention output (batch, num_heads, seq_len, head_dim)
    """
    head_dim = query.size(-1)
    if scale is None:
        scale = 1.0 / math.sqrt(head_dim)

    # Q @ K^T / sqrt(d)
    attention_scores = torch.matmul(query, key.transpose(-1, -2)) * scale

    # Apply attention mask
    if attention_mask is not None:
        attention_scores = attention_scores + attention_mask

    # Softmax and dropout
    attention_probs = F.softmax(attention_scores, dim=-1)
    if dropout_p > 0.0 and training:
        attention_probs = F.dropout(attention_probs, p=dropout_p, training=training)

    # Attention @ V
    return torch.matmul(attention_probs, value)


def sdpa_attention(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    attention_mask: Optional[Tensor] = None,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """PyTorch's scaled_dot_product_attention.

    Args:
        query: (batch, num_heads, seq_len, head_dim)
        key: (batch, num_heads, seq_len, head_dim)
        value: (batch, num_heads, seq_len, head_dim)
        attention_mask: Additive mask (batch, 1, 1, seq_len) with -inf for masked
        dropout_p: Dropout probability
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode (affects dropout)

    Returns:
        Attention output (batch, num_heads, seq_len, head_dim)
    """
    return F.scaled_dot_product_attention(
        query,
        key,
        value,
        attn_mask=attention_mask,
        dropout_p=dropout_p if training else 0.0,
        scale=scale,
    )


def _get_flash_attn_2_func():
    """Lazy import Flash Attention 2 function."""
    from flash_attn import flash_attn_func
    return flash_attn_func


def _get_flash_attn_3_func():
    """Lazy import Flash Attention 3 function."""
    from flash_attn_interface import flash_attn_func
    return flash_attn_func


def flash_attention_2(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    attention_mask: Optional[Tensor] = None,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Flash Attention 2 implementation.

    Note: Flash Attention expects (batch, seq_len, num_heads, head_dim) layout,
    but we receive (batch, num_heads, seq_len, head_dim). This function handles
    the transpose.

    Args:
        query: (batch, num_heads, seq_len, head_dim)
        key: (batch, num_heads, seq_len, head_dim)
        value: (batch, num_heads, seq_len, head_dim)
        attention_mask: Not directly supported; use cu_seqlens for variable length
        dropout_p: Dropout probability
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode

    Returns:
        Attention output (batch, num_heads, seq_len, head_dim)
    """
    flash_fn = _get_flash_attn_2_func()

    # Transpose from (batch, heads, seq, dim) to (batch, seq, heads, dim)
    query = query.transpose(1, 2)
    key = key.transpose(1, 2)
    value = value.transpose(1, 2)

    # Flash attention call
    out = flash_fn(
        query,
        key,
        value,
        dropout_p=dropout_p if training else 0.0,
        softmax_scale=scale,
        causal=False,  # BERT uses bidirectional attention
    )

    # Transpose back to (batch, heads, seq, dim)
    return out.transpose(1, 2)


def flash_attention_3(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    attention_mask: Optional[Tensor] = None,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Flash Attention 3 implementation.

    Args:
        query: (batch, num_heads, seq_len, head_dim)
        key: (batch, num_heads, seq_len, head_dim)
        value: (batch, num_heads, seq_len, head_dim)
        attention_mask: Not directly supported
        dropout_p: Dropout probability (may not be supported in FA3)
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode

    Returns:
        Attention output (batch, num_heads, seq_len, head_dim)
    """
    flash_fn = _get_flash_attn_3_func()

    # Transpose from (batch, heads, seq, dim) to (batch, seq, heads, dim)
    query = query.transpose(1, 2)
    key = key.transpose(1, 2)
    value = value.transpose(1, 2)

    # Flash attention 3 call
    out = flash_fn(
        query,
        key,
        value,
        softmax_scale=scale,
        causal=False,
    )
    # Handle tuple return (some FA3 versions return (output, softmax_lse))
    if isinstance(out, tuple):
        out = out[0]

    # Transpose back to (batch, heads, seq, dim)
    return out.transpose(1, 2)


# =============================================================================
# Variable-length (unpadded) attention functions
# =============================================================================


def _get_flash_attn_2_varlen_func():
    """Lazy import Flash Attention 2 variable-length function."""
    from flash_attn import flash_attn_varlen_qkvpacked_func

    return flash_attn_varlen_qkvpacked_func


def _get_flash_attn_3_varlen_func():
    """Lazy import Flash Attention 3 variable-length function."""
    from flash_attn_interface import flash_attn_varlen_func

    return flash_attn_varlen_func


def flash_attention_2_varlen(
    qkv: Tensor,
    cu_seqlens: Tensor,
    max_seqlen: int,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Flash Attention 2 for variable-length (unpadded) sequences.

    Args:
        qkv: Packed QKV tensor (total_nnz, 3, num_heads, head_dim)
        cu_seqlens: Cumulative sequence lengths (batch + 1,) as int32
        max_seqlen: Maximum sequence length in batch
        dropout_p: Dropout probability
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode

    Returns:
        Attention output (total_nnz, num_heads, head_dim)
    """
    flash_fn = _get_flash_attn_2_varlen_func()

    # FA2 requires fp16 or bf16
    convert_dtype = qkv.dtype not in (torch.float16, torch.bfloat16)
    if convert_dtype:
        orig_dtype = qkv.dtype
        qkv = qkv.to(torch.bfloat16)

    out = flash_fn(
        qkv,
        cu_seqlens=cu_seqlens,
        max_seqlen=max_seqlen,
        dropout_p=dropout_p if training else 0.0,
        softmax_scale=scale,
        causal=False,
    )

    if convert_dtype:
        out = out.to(orig_dtype)

    return out


def flash_attention_3_varlen(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    cu_seqlens: Tensor,
    max_seqlen: int,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Flash Attention 3 for variable-length (unpadded) sequences.

    Args:
        q: Query tensor (total_nnz, num_heads, head_dim)
        k: Key tensor (total_nnz, num_heads, head_dim)
        v: Value tensor (total_nnz, num_heads, head_dim)
        cu_seqlens: Cumulative sequence lengths (batch + 1,) as int32
        max_seqlen: Maximum sequence length in batch
        dropout_p: Dropout probability (may not be supported)
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode

    Returns:
        Attention output (total_nnz, num_heads, head_dim)
    """
    flash_fn = _get_flash_attn_3_varlen_func()

    # FA3 requires fp16 or bf16
    convert_dtype = q.dtype not in (torch.float16, torch.bfloat16)
    if convert_dtype:
        orig_dtype = q.dtype
        q, k, v = q.to(torch.bfloat16), k.to(torch.bfloat16), v.to(torch.bfloat16)

    out, _ = flash_fn(
        q=q,
        k=k,
        v=v,
        cu_seqlens_q=cu_seqlens,
        cu_seqlens_k=cu_seqlens,
        max_seqlen_q=max_seqlen,
        max_seqlen_k=max_seqlen,
    )

    if convert_dtype:
        out = out.to(orig_dtype)

    return out


def sdpa_attention_varlen(
    qkv: Tensor,
    cu_seqlens: Tensor,
    max_seqlen: int,
    indices: Tensor,
    batch_size: int,
    attention_mask: Tensor,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """SDPA for variable-length sequences (pad -> attend -> unpad).

    SDPA doesn't natively support variable-length sequences, so we:
    1. Pad the input back to original shape
    2. Run SDPA with attention mask
    3. Unpad the output

    Args:
        qkv: Packed QKV tensor (total_nnz, 3, num_heads, head_dim)
        cu_seqlens: Cumulative sequence lengths (batch + 1,)
        max_seqlen: Maximum sequence length in batch
        indices: Indices from unpad_input for restoring padding
        batch_size: Original batch size
        attention_mask: Original (batch, seqlen) mask where 1=valid, 0=padding
        dropout_p: Dropout probability
        scale: Attention scale
        training: Whether in training mode

    Returns:
        Attention output (total_nnz, num_heads, head_dim)
    """
    from .bert_padding import pad_input, unpad_input_only

    num_heads = qkv.shape[2]
    head_dim = qkv.shape[3]

    # Re-pad QKV for SDPA: (total_nnz, 3, heads, dim) -> (batch, seq, 3, heads, dim)
    qkv_padded = pad_input(qkv, indices, batch_size, max_seqlen)

    # Split and transpose for SDPA
    q, k, v = qkv_padded.unbind(dim=2)  # each (batch, seq, heads, dim)
    q = q.transpose(1, 2)  # (batch, heads, seq, dim)
    k = k.transpose(1, 2)
    v = v.transpose(1, 2)

    # Create SDPA-compatible attention mask
    # attention_mask: (batch, seq) with 1=valid, 0=padding
    # SDPA expects: (batch, 1, 1, seq) or (batch, 1, seq, seq) with -inf for masked
    attn_mask = attention_mask[:, None, None, :].to(q.dtype)
    attn_mask = (1.0 - attn_mask) * torch.finfo(q.dtype).min

    out = F.scaled_dot_product_attention(
        q,
        k,
        v,
        attn_mask=attn_mask,
        dropout_p=dropout_p if training else 0.0,
        scale=scale,
    )

    # out: (batch, heads, seq, dim) -> (batch, seq, heads, dim)
    out = out.transpose(1, 2)

    # Unpad output
    out = unpad_input_only(out, attention_mask)

    return out


def eager_attention_varlen(
    qkv: Tensor,
    cu_seqlens: Tensor,
    max_seqlen: int,
    indices: Tensor,
    batch_size: int,
    attention_mask: Tensor,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
) -> Tensor:
    """Eager attention for variable-length sequences (pad -> attend -> unpad).

    Args:
        qkv: Packed QKV tensor (total_nnz, 3, num_heads, head_dim)
        cu_seqlens: Cumulative sequence lengths (batch + 1,)
        max_seqlen: Maximum sequence length in batch
        indices: Indices from unpad_input for restoring padding
        batch_size: Original batch size
        attention_mask: Original (batch, seqlen) mask where 1=valid, 0=padding
        dropout_p: Dropout probability
        scale: Attention scale
        training: Whether in training mode

    Returns:
        Attention output (total_nnz, num_heads, head_dim)
    """
    from .bert_padding import pad_input, unpad_input_only

    num_heads = qkv.shape[2]
    head_dim = qkv.shape[3]

    if scale is None:
        scale = 1.0 / math.sqrt(head_dim)

    # Re-pad QKV: (total_nnz, 3, heads, dim) -> (batch, seq, 3, heads, dim)
    qkv_padded = pad_input(qkv, indices, batch_size, max_seqlen)

    # Split and transpose
    q, k, v = qkv_padded.unbind(dim=2)  # each (batch, seq, heads, dim)
    q = q.transpose(1, 2)  # (batch, heads, seq, dim)
    k = k.transpose(1, 2)
    v = v.transpose(1, 2)

    # Compute attention scores
    attention_scores = torch.matmul(q, k.transpose(-1, -2)) * scale

    # Apply mask: (batch, seq) -> (batch, 1, 1, seq)
    attn_mask = attention_mask[:, None, None, :].to(attention_scores.dtype)
    attn_mask = (1.0 - attn_mask) * torch.finfo(attention_scores.dtype).min
    attention_scores = attention_scores + attn_mask

    # Softmax and dropout
    attention_probs = F.softmax(attention_scores, dim=-1)
    if dropout_p > 0.0 and training:
        attention_probs = F.dropout(attention_probs, p=dropout_p, training=training)

    # Attention @ V
    out = torch.matmul(attention_probs, v)

    # out: (batch, heads, seq, dim) -> (batch, seq, heads, dim)
    out = out.transpose(1, 2)

    # Unpad output
    out = unpad_input_only(out, attention_mask)

    return out


# Dispatch table for attention implementations
_ATTENTION_IMPLEMENTATIONS = {
    "eager": eager_attention,
    "sdpa": sdpa_attention,
    "flash_attention_2": flash_attention_2,
    "flash_attention_3": flash_attention_3,
}


def attention_forward(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    attention_mask: Optional[Tensor] = None,
    dropout_p: float = 0.0,
    scale: Optional[float] = None,
    training: bool = False,
    implementation: str = "eager",
) -> Tensor:
    """Unified attention forward function.

    Dispatches to the appropriate attention implementation based on config.

    Args:
        query: (batch, num_heads, seq_len, head_dim)
        key: (batch, num_heads, seq_len, head_dim)
        value: (batch, num_heads, seq_len, head_dim)
        attention_mask: Additive mask (batch, 1, 1, seq_len) with -inf for masked
        dropout_p: Dropout probability
        scale: Attention scale (default: 1/sqrt(head_dim))
        training: Whether in training mode
        implementation: Which attention implementation to use

    Returns:
        Attention output (batch, num_heads, seq_len, head_dim)
    """
    # Validate and potentially fall back
    implementation = validate_attn_implementation(implementation)

    attn_fn = _ATTENTION_IMPLEMENTATIONS[implementation]
    return attn_fn(
        query,
        key,
        value,
        attention_mask=attention_mask,
        dropout_p=dropout_p,
        scale=scale,
        training=training,
    )
