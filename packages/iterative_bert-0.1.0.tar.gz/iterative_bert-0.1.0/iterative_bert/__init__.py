"""Iterative refinement BERT encoder based on Tiny Recursive Models."""

__version__ = "0.1.0"

from .model import create_single_layer_bert_config, IterativeBertConfig, IterativeBert
from .modern_bert import GATED_ACTIVATIONS, ModernBertConfig, ModernBertEmbeddings, ModernBertSelfAttention, ModernBertSelfOutput, ModernBertAttention, ModernBertIntermediate, ModernBertOutput, ModernBertLayer, ModernBertEncoder, ModernBert
from .rope import RotaryPositionEmbedding, UnpaddedRotaryPositionEmbedding
from .embeddings import BertEmbeddingsWithoutPosition
from .layers import get_norm_layer, RMSNorm, RMSNormWithWeight
from .flash_attention import is_flash_attn_2_available, is_flash_attn_3_available, is_sdpa_available, get_available_implementations, validate_attn_implementation, eager_attention, sdpa_attention, flash_attention_2, flash_attention_3, flash_attention_2_varlen, flash_attention_3_varlen, sdpa_attention_varlen, eager_attention_varlen, attention_forward
from .initialization import InitMethod, ModuleType, init_weights, apply_megatron_init
from .bert_padding import IndexFirstAxis, IndexPutFirstAxis, index_first_axis, index_put_first_axis, unpad_input, unpad_input_only, pad_input
from .attention import BertSelfAttentionWithRoPE, BertAttentionWithRoPE, BertSelfOutput

__all__ = [
    "create_single_layer_bert_config",
    "IterativeBertConfig",
    "IterativeBert",
    "GATED_ACTIVATIONS",
    "ModernBertConfig",
    "ModernBertEmbeddings",
    "ModernBertSelfAttention",
    "ModernBertSelfOutput",
    "ModernBertAttention",
    "ModernBertIntermediate",
    "ModernBertOutput",
    "ModernBertLayer",
    "ModernBertEncoder",
    "ModernBert",
    "RotaryPositionEmbedding",
    "UnpaddedRotaryPositionEmbedding",
    "BertEmbeddingsWithoutPosition",
    "get_norm_layer",
    "RMSNorm",
    "RMSNormWithWeight",
    "is_flash_attn_2_available",
    "is_flash_attn_3_available",
    "is_sdpa_available",
    "get_available_implementations",
    "validate_attn_implementation",
    "eager_attention",
    "sdpa_attention",
    "flash_attention_2",
    "flash_attention_3",
    "flash_attention_2_varlen",
    "flash_attention_3_varlen",
    "sdpa_attention_varlen",
    "eager_attention_varlen",
    "attention_forward",
    "InitMethod",
    "ModuleType",
    "init_weights",
    "apply_megatron_init",
    "IndexFirstAxis",
    "IndexPutFirstAxis",
    "index_first_axis",
    "index_put_first_axis",
    "unpad_input",
    "unpad_input_only",
    "pad_input",
    "BertSelfAttentionWithRoPE",
    "BertAttentionWithRoPE",
    "BertSelfOutput",
    "__version__",
]
