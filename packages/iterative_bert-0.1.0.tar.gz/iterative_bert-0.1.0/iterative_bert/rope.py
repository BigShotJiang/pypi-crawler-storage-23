"""Rotary Position Embeddings (RoPE) implementation.

Based on "RoFormer: Enhanced Transformer with Rotary Position Embedding"
https://arxiv.org/abs/2104.09864

This implementation is designed for standard padded sequences and is
compatible with future flash attention integration.

Supports optional liger-kernel fused RoPE for improved performance.
"""

from typing import Optional, Tuple

import torch
import torch.nn as nn

__all__ = [
    "RotaryPositionEmbedding",
    "UnpaddedRotaryPositionEmbedding",
]
from torch import Tensor


# Cache for liger RoPE import
_LIGER_ROPE_FN = None
_LIGER_ROPE_CHECKED = False


def _get_liger_rope_fn():
    """Lazily import liger RoPE function."""
    global _LIGER_ROPE_FN, _LIGER_ROPE_CHECKED
    if not _LIGER_ROPE_CHECKED:
        try:
            from liger_kernel.transformers.rope import liger_rotary_pos_emb
            _LIGER_ROPE_FN = liger_rotary_pos_emb
        except ImportError:
            _LIGER_ROPE_FN = None
        _LIGER_ROPE_CHECKED = True
    return _LIGER_ROPE_FN


class RotaryPositionEmbedding(nn.Module):
    """Rotary Position Embeddings for standard padded attention.

    RoPE encodes position information by rotating query and key vectors,
    allowing the model to learn relative positions without fixed position
    limits.

    Args:
        dim: Dimension to apply rotary embeddings (typically head_dim)
        base: Base for computing inverse frequencies (default 10000.0)
        max_seq_len: Initial cache size (will extend dynamically)
        use_liger: Use liger-kernel's fused RoPE (default False)

    Example:
        rope = RotaryPositionEmbedding(dim=64, base=10000.0)
        q_rot, k_rot = rope(q, k)  # Apply RoPE to query and key
    """

    def __init__(
        self,
        dim: int,
        base: float = 10000.0,
        max_seq_len: int = 2048,
        use_liger: bool = False,
    ):
        super().__init__()

        # RoPE requires even dimension for rotate_half operation
        assert dim % 2 == 0, (
            f"RoPE requires even head dimension, got dim={dim}. "
            f"Ensure hidden_size % (2 * num_attention_heads) == 0. "
            f"For example: hidden_size=312 works with num_attention_heads=6 (head_dim=26) "
            f"but not with num_attention_heads=4 (head_dim=39)."
        )

        self.dim = dim
        self.base = base
        self.max_seq_len = max_seq_len

        # Liger-kernel fused RoPE
        self.use_liger = use_liger
        self._liger_rope_fn = None
        if use_liger:
            self._liger_rope_fn = _get_liger_rope_fn()
            if self._liger_rope_fn is None:
                self.use_liger = False  # Fall back to standard if import failed

        # Compute inverse frequencies: 1 / (base^(2i/dim)) for i in [0, dim/2)
        inv_freq = 1.0 / (
            self.base ** (torch.arange(0, self.dim, 2, dtype=torch.float32) / self.dim)
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Pre-compute cos/sin cache and register as buffers
        # This ensures proper device handling and CUDAGraphs compatibility
        cos, sin = self._compute_cos_sin(max_seq_len)
        self.register_buffer("cos_cached", cos, persistent=False)
        self.register_buffer("sin_cached", sin, persistent=False)
        self._seq_len_cached = max_seq_len

    def _compute_cos_sin(
        self,
        seq_len: int,
        device: Optional[torch.device] = None,
        dtype: Optional[torch.dtype] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Compute cos/sin tables for given sequence length.

        Args:
            seq_len: Sequence length to compute for
            device: Device to create tensors on
            dtype: Data type for output tensors

        Returns:
            Tuple of (cos, sin) tensors with shape (seq_len, dim/2)
        """
        # Position indices [0, 1, 2, ..., seq_len-1]
        # Use fp32 for position indices to avoid precision loss
        t = torch.arange(seq_len, device=device or self.inv_freq.device, dtype=torch.float32)

        # Compute frequencies: outer product of positions and inverse frequencies
        # Shape: (seq_len, dim/2)
        inv_freq = self.inv_freq.to(device=device or self.inv_freq.device)
        freqs = torch.outer(t, inv_freq)

        # Compute cos and sin, then convert to target dtype
        # Shape: (seq_len, dim/2)
        cos = torch.cos(freqs)
        sin = torch.sin(freqs)

        if dtype is not None:
            cos = cos.to(dtype)
            sin = sin.to(dtype)

        return cos, sin

    def _update_cache(
        self,
        seq_len: int,
        device: Optional[torch.device] = None,
        dtype: Optional[torch.dtype] = None,
    ) -> None:
        """Update cos/sin cache if needed for longer sequences or different device/dtype."""
        # Check if we need to update
        needs_update = False

        if seq_len > self._seq_len_cached:
            needs_update = True
        elif device is not None and self.cos_cached.device != device:
            needs_update = True
        elif dtype is not None and self.cos_cached.dtype != dtype:
            needs_update = True

        if not needs_update:
            return

        # Compute new cos/sin tables
        new_seq_len = max(seq_len, self._seq_len_cached)
        cos, sin = self._compute_cos_sin(new_seq_len, device, dtype)

        # Re-register buffers with new tensors
        # This ensures proper device/dtype handling
        self.register_buffer("cos_cached", cos, persistent=False)
        self.register_buffer("sin_cached", sin, persistent=False)
        self._seq_len_cached = new_seq_len

    def _rotate_half(self, x: Tensor) -> Tensor:
        """Rotate half the hidden dims of the input.

        For RoPE, we split x into two halves and rotate:
        [-x2, x1] where x = [x1, x2]
        """
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat([-x2, x1], dim=-1)

    def _apply_rotary(
        self,
        x: Tensor,
        cos: Tensor,
        sin: Tensor,
    ) -> Tensor:
        """Apply rotary embeddings to input tensor.

        Args:
            x: Input tensor of shape (..., seq_len, dim)
            cos: Cosine values of shape (seq_len, dim/2)
            sin: Sine values of shape (seq_len, dim/2)

        Returns:
            Rotated tensor of same shape as x
        """
        # Expand cos/sin for the rotation
        # cos/sin shape: (seq_len, dim/2) -> (1, 1, seq_len, dim/2)
        # Then repeat to match x: (batch, heads, seq_len, dim)
        seq_len = x.shape[-2]
        cos = cos[:seq_len].unsqueeze(0).unsqueeze(0)
        sin = sin[:seq_len].unsqueeze(0).unsqueeze(0)

        # Repeat cos/sin to match full dimension
        # (1, 1, seq_len, dim/2) -> (1, 1, seq_len, dim)
        cos = torch.cat([cos, cos], dim=-1)
        sin = torch.cat([sin, sin], dim=-1)

        # Apply rotation: x * cos + rotate_half(x) * sin
        return x * cos + self._rotate_half(x) * sin

    def forward(
        self,
        q: Tensor,
        k: Tensor,
        position_ids: Optional[Tensor] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Apply rotary position embeddings to query and key tensors.

        Args:
            q: Query tensor of shape (batch, heads, seq_len, head_dim)
            k: Key tensor of shape (batch, heads, seq_len, head_dim)
            position_ids: Optional position indices (batch, seq_len)
                         If None, uses [0, 1, 2, ..., seq_len-1]

        Returns:
            Tuple of (rotated_q, rotated_k) with same shapes as inputs
        """
        seq_len = q.shape[-2]
        device = q.device
        dtype = q.dtype

        # Update cache if needed (for longer sequences or different device/dtype)
        self._update_cache(seq_len, device=device, dtype=dtype)

        # Use liger fused RoPE if available
        if self.use_liger and self._liger_rope_fn is not None:
            # liger_rotary_pos_emb expects cos/sin of shape (seq_len, dim)
            # where dim is head_dim (not dim/2)
            cos = self.cos_cached[:seq_len]  # (seq_len, dim/2)
            sin = self.sin_cached[:seq_len]  # (seq_len, dim/2)

            # Liger expects full dim, so concatenate
            cos = torch.cat([cos, cos], dim=-1)  # (seq_len, dim)
            sin = torch.cat([sin, sin], dim=-1)  # (seq_len, dim)

            # liger_rotary_pos_emb signature: (q, k, cos, sin, position_ids, unsqueeze_dim)
            # unsqueeze_dim=1 because q/k shape is (batch, heads, seq_len, head_dim)
            q_rot, k_rot = self._liger_rope_fn(
                q, k, cos, sin, position_ids, unsqueeze_dim=1
            )
            return q_rot, k_rot

        # Standard implementation
        if position_ids is not None:
            # Gather cos/sin for specific positions
            # position_ids shape: (batch, seq_len)
            cos = self.cos_cached[position_ids]  # (batch, seq_len, dim/2)
            sin = self.sin_cached[position_ids]  # (batch, seq_len, dim/2)

            # Expand for heads dimension
            cos = cos.unsqueeze(1)  # (batch, 1, seq_len, dim/2)
            sin = sin.unsqueeze(1)

            # Repeat to match full dimension
            cos = torch.cat([cos, cos], dim=-1)
            sin = torch.cat([sin, sin], dim=-1)

            q_rot = q * cos + self._rotate_half(q) * sin
            k_rot = k * cos + self._rotate_half(k) * sin
        else:
            # Use sequential positions [0, 1, 2, ..., seq_len-1]
            q_rot = self._apply_rotary(q, self.cos_cached, self.sin_cached)
            k_rot = self._apply_rotary(k, self.cos_cached, self.sin_cached)

        return q_rot, k_rot

    def extra_repr(self) -> str:
        return f"dim={self.dim}, base={self.base}"


class UnpaddedRotaryPositionEmbedding(nn.Module):
    """Rotary Position Embeddings for unpadded (variable-length) sequences.

    This variant works with unpadded sequences where tokens from different
    sequences are concatenated and tracked via cu_seqlens (cumulative sequence
    lengths). It computes position IDs on-the-fly from cu_seqlens.

    Args:
        dim: Dimension to apply rotary embeddings (typically head_dim)
        base: Base for computing inverse frequencies (default 10000.0)

    Example:
        rope = UnpaddedRotaryPositionEmbedding(dim=64, base=10000.0)
        q_rot, k_rot = rope(q, k, cu_seqlens, max_seqlen)
    """

    def __init__(
        self,
        dim: int,
        base: float = 10000.0,
    ):
        super().__init__()

        assert dim % 2 == 0, f"RoPE requires even head dimension, got dim={dim}"

        self.dim = dim
        self.base = base

        # Compute inverse frequencies: 1 / (base^(2i/dim)) for i in [0, dim/2)
        inv_freq = 1.0 / (
            self.base ** (torch.arange(0, self.dim, 2, dtype=torch.float32) / self.dim)
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def _rotate_half(self, x: Tensor) -> Tensor:
        """Rotate half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat([-x2, x1], dim=-1)

    def _compute_position_ids(
        self,
        cu_seqlens: Tensor,
        total_nnz: int,
        device: torch.device,
    ) -> Tensor:
        """Compute position IDs from cumulative sequence lengths.

        For each sequence, positions are [0, 1, 2, ..., seq_len_i - 1].

        Args:
            cu_seqlens: Cumulative sequence lengths (batch + 1,)
            total_nnz: Total number of non-padding tokens
            device: Device to create tensor on

        Returns:
            Position IDs tensor of shape (total_nnz,)
        """
        batch_size = cu_seqlens.shape[0] - 1
        position_ids = torch.zeros(total_nnz, dtype=torch.long, device=device)

        for i in range(batch_size):
            start = cu_seqlens[i].item()
            end = cu_seqlens[i + 1].item()
            seq_len = end - start
            position_ids[start:end] = torch.arange(seq_len, device=device)

        return position_ids

    def forward(
        self,
        q: Tensor,
        k: Tensor,
        cu_seqlens: Tensor,
        max_seqlen: int,
    ) -> Tuple[Tensor, Tensor]:
        """Apply rotary position embeddings to unpadded query and key tensors.

        Args:
            q: Query tensor of shape (total_nnz, num_heads, head_dim)
            k: Key tensor of shape (total_nnz, num_heads, head_dim)
            cu_seqlens: Cumulative sequence lengths (batch + 1,) as int32
            max_seqlen: Maximum sequence length in batch

        Returns:
            Tuple of (rotated_q, rotated_k) with same shapes as inputs
        """
        total_nnz = q.shape[0]
        device = q.device
        dtype = q.dtype

        # Compute position IDs from cu_seqlens
        position_ids = self._compute_position_ids(cu_seqlens, total_nnz, device)

        # Compute cos/sin for all positions
        # position_ids: (total_nnz,)
        t = position_ids.float()
        inv_freq = self.inv_freq.to(device=device)
        freqs = torch.outer(t, inv_freq)  # (total_nnz, dim/2)

        cos = torch.cos(freqs).to(dtype)  # (total_nnz, dim/2)
        sin = torch.sin(freqs).to(dtype)

        # Expand cos/sin to match q/k shape: (total_nnz, 1, dim/2) for broadcast
        cos = cos.unsqueeze(1)  # (total_nnz, 1, dim/2)
        sin = sin.unsqueeze(1)

        # Repeat to match full dimension
        cos = torch.cat([cos, cos], dim=-1)  # (total_nnz, 1, dim)
        sin = torch.cat([sin, sin], dim=-1)

        # Apply rotation: x * cos + rotate_half(x) * sin
        q_rot = q * cos + self._rotate_half(q) * sin
        k_rot = k * cos + self._rotate_half(k) * sin

        return q_rot, k_rot

    def extra_repr(self) -> str:
        return f"dim={self.dim}, base={self.base}"
