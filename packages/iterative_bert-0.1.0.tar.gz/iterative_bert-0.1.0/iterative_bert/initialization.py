"""Weight initialization methods for transformer models.

Provides Megatron-style initialization which scales output projections
by 1/sqrt(2*num_layers) to prevent variance explosion in deep networks.

Reference: ModernBERT paper (arXiv:2412.13663)
"""

import math
from enum import Enum
from typing import Optional, Union

import torch
import torch.nn as nn

__all__ = [
    "InitMethod",
    "ModuleType",
    "init_weights",
    "apply_megatron_init",
]


class InitMethod(str, Enum):
    """Available initialization methods."""

    default = "default"
    """Standard initialization (normal with std=0.02)."""

    megatron = "megatron"
    """
    Megatron-style initialization (used by Llama 2, ModernBERT).
    - Input layers: normal with std=init_std
    - Output layers: normal with std=init_std / sqrt(2 * num_layers)
    - Embeddings: normal with std=init_std
    """

    small_init = "small_init"
    """Small initialization for embeddings (uniform [-1e-4, 1e-4])."""


class ModuleType(str, Enum):
    """Types of modules for initialization."""

    input = "input"
    """Input projections (Q, K, V, FFN up-projection)."""

    output = "output"
    """Output projections (attention out, FFN down-projection)."""

    embedding = "embedding"
    """Token/position embeddings."""


def init_weights(
    module: Union[nn.Linear, nn.Embedding],
    method: Union[str, InitMethod] = InitMethod.default,
    module_type: Optional[Union[str, ModuleType]] = None,
    num_layers: int = 1,
    init_std: float = 0.02,
    init_cutoff_factor: float = 3.0,
) -> None:
    """Initialize weights of a linear or embedding module.

    Args:
        module: The module to initialize
        method: Initialization method to use
        module_type: Type of module (required for megatron init)
        num_layers: Number of layers (for megatron scaling)
        init_std: Base standard deviation
        init_cutoff_factor: Truncation factor for truncated normal

    Example:
        >>> layer = nn.Linear(768, 768)
        >>> init_weights(layer, method="megatron", module_type="output", num_layers=12)
    """
    if isinstance(method, str):
        method = InitMethod(method)
    if isinstance(module_type, str):
        module_type = ModuleType(module_type)

    if method == InitMethod.default:
        # Standard BERT initialization
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=init_std)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=init_std)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()

    elif method == InitMethod.megatron:
        if module_type is None:
            raise ValueError("module_type is required for megatron initialization")

        # Compute std based on module type
        if module_type == ModuleType.input:
            std = init_std
        elif module_type == ModuleType.output:
            # Scale down by 1/sqrt(2*num_layers) for residual connections
            std = init_std / math.sqrt(2.0 * num_layers)
        elif module_type == ModuleType.embedding:
            std = init_std
        else:
            raise ValueError(f"Unknown module_type: {module_type}")

        # Apply truncated normal initialization
        cutoff = init_cutoff_factor * std
        if isinstance(module, (nn.Linear, nn.Embedding)):
            nn.init.trunc_normal_(
                module.weight,
                mean=0.0,
                std=std,
                a=-cutoff,
                b=cutoff,
            )

        # Zero bias for linear layers
        if isinstance(module, nn.Linear) and module.bias is not None:
            module.bias.data.zero_()

        # Zero padding idx for embeddings
        if isinstance(module, nn.Embedding) and module.padding_idx is not None:
            module.weight.data[module.padding_idx].zero_()

    elif method == InitMethod.small_init:
        # Small uniform init for embeddings (RWKV style)
        if isinstance(module, nn.Embedding):
            nn.init.uniform_(module.weight, a=-1e-4, b=1e-4)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()
        else:
            # Fall back to default for non-embeddings
            module.weight.data.normal_(mean=0.0, std=init_std)
            if hasattr(module, 'bias') and module.bias is not None:
                module.bias.data.zero_()


def apply_megatron_init(
    model: nn.Module,
    num_layers: int,
    init_std: float = 0.02,
    init_cutoff_factor: float = 3.0,
) -> None:
    """Apply Megatron-style initialization to a transformer model.

    This function walks through the model and applies appropriate initialization
    based on layer names. Output projections (attention output, FFN output) are
    scaled down by 1/sqrt(2*num_layers).

    Args:
        model: The model to initialize
        num_layers: Number of transformer layers (or refinement steps)
        init_std: Base standard deviation (default: 0.02)
        init_cutoff_factor: Truncation factor for truncated normal (default: 3.0)

    Example:
        >>> model = ModernBert(config)
        >>> apply_megatron_init(model, num_layers=12)
    """
    for name, module in model.named_modules():
        if isinstance(module, nn.Embedding):
            init_weights(
                module,
                method=InitMethod.megatron,
                module_type=ModuleType.embedding,
                num_layers=num_layers,
                init_std=init_std,
                init_cutoff_factor=init_cutoff_factor,
            )
        elif isinstance(module, nn.Linear):
            # Determine if this is an output projection
            # Output projections: attention output (dense after attention),
            # FFN output (down-projection)
            is_output = any(
                pattern in name.lower()
                for pattern in [
                    "output.dense",  # ModernBertSelfOutput.dense, ModernBertOutput.dense
                    "attn_out",
                    "ff_out",
                    "o_proj",  # Common naming
                    "down_proj",  # FFN down-projection
                ]
            )

            module_type = ModuleType.output if is_output else ModuleType.input
            init_weights(
                module,
                method=InitMethod.megatron,
                module_type=module_type,
                num_layers=num_layers,
                init_std=init_std,
                init_cutoff_factor=init_cutoff_factor,
            )

        elif isinstance(module, nn.LayerNorm):
            # LayerNorm: weight=1, bias=0
            if hasattr(module, 'weight') and module.weight is not None:
                module.weight.data.fill_(1.0)
            if hasattr(module, 'bias') and module.bias is not None:
                module.bias.data.zero_()
