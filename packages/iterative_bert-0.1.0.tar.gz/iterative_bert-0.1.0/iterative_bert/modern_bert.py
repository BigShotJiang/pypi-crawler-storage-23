"""ModernBERT: A clean BERT implementation with modern features.

This module provides a from-scratch BERT implementation that supports:
- Rotary Position Embeddings (RoPE) for unlimited sequence length
- Position-free embeddings when using RoPE
- Clean integration with transformers components where useful

ModernBERT serves as the base class for IterativeBert.
"""

from typing import Optional, Tuple, List

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from transformers import PretrainedConfig, PreTrainedModel, BertConfig
from transformers.modeling_outputs import BaseModelOutput

from .rope import RotaryPositionEmbedding
from .embeddings import BertEmbeddingsWithoutPosition
from .initialization import InitMethod, apply_megatron_init
from .flash_attention import attention_forward, validate_attn_implementation
from .layers import RMSNorm, RMSNormWithWeight, get_norm_layer

__all__ = [
    "GATED_ACTIVATIONS",
    "ModernBertConfig",
    "ModernBertEmbeddings",
    "ModernBertSelfAttention",
    "ModernBertSelfOutput",
    "ModernBertAttention",
    "ModernBertIntermediate",
    "ModernBertOutput",
    "ModernBertLayer",
    "ModernBertEncoder",
    "ModernBert",
]


class ModernBertConfig(PretrainedConfig):
    """Configuration for ModernBERT.

    This extends BertConfig with modern architecture options.
    """

    model_type = "modern_bert"

    def __init__(
        self,
        vocab_size: int = 30522,
        hidden_size: int = 768,
        num_hidden_layers: int = 12,
        num_attention_heads: int = 12,
        intermediate_size: int = 3072,
        activation_fn: str = "gelu",
        dropout_mlp: float = 0.0,
        dropout_attn_weights: float = 0.0,
        dropout_attn_output: float = 0.1,
        max_position_embeddings: int = 512,
        type_vocab_size: int = 2,
        layer_norm_eps: float = 1e-12,
        norm_type: str = "layernorm",  # "layernorm" | "rmsnorm" | "rmsnorm_weighted"
        pad_token_id: int = 0,
        # Modern options
        use_rope: bool = False,
        rope_base: float = 10000.0,
        use_bias: bool = False,  # Disable bias in Linear/LayerNorm (modern practice)
        # Initialization options
        init_method: str = "default",  # "default", "megatron", "small_init"
        init_std: float = 0.02,
        init_cutoff_factor: float = 3.0,
        # ConvGated options (for ConvSwiGLU/ConvGeGLU/ConvReGLU)
        use_conv: bool = False,
        conv_kernel_size: int = 2,
        # Per-step configuration (ModernBERT-style alternating attention)
        h_step_rope_base: float = 160000.0,  # Global attention theta for H-steps
        l_step_rope_base: float = 10000.0,   # Local attention theta for L-steps
        h_step_use_conv: bool = False,       # H-steps: SwiGLU (no conv)
        l_step_use_conv: bool = True,        # L-steps: ConvSwiGLU
        # Attention implementation: "eager", "sdpa", "flash_attention_2", "flash_attention_3"
        attn_implementation: str = "flash_attention_2",
        # Unpadding: remove padding before attention, restore after (MosaicBERT optimization)
        use_unpadding: bool = False,
        # Liger-kernel optimizations
        liger_fused_swiglu: bool = False,  # Use liger fused SwiGLU kernel
        liger_fused_rope: bool = False,    # Use liger fused RoPE kernel
        liger_fused_rmsnorm: bool = False, # Use liger fused RMSNorm kernel
        **kwargs,
    ):
        super().__init__(pad_token_id=pad_token_id, **kwargs)
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.activation_fn = activation_fn
        self.intermediate_size = intermediate_size
        self.dropout_mlp = dropout_mlp
        self.dropout_attn_weights = dropout_attn_weights
        self.dropout_attn_output = dropout_attn_output
        self.max_position_embeddings = max_position_embeddings
        self.type_vocab_size = type_vocab_size
        self.layer_norm_eps = layer_norm_eps
        self.norm_type = norm_type

        # Modern options
        self.use_rope = use_rope
        self.rope_base = rope_base
        self.use_bias = use_bias

        # Initialization options
        self.init_method = init_method
        self.init_std = init_std
        self.init_cutoff_factor = init_cutoff_factor

        # ConvGated options
        self.use_conv = use_conv
        self.conv_kernel_size = conv_kernel_size

        # Per-step configuration (ModernBERT-style alternating attention)
        self.h_step_rope_base = h_step_rope_base
        self.l_step_rope_base = l_step_rope_base
        self.h_step_use_conv = h_step_use_conv
        self.l_step_use_conv = l_step_use_conv

        # Attention implementation
        self.attn_implementation = attn_implementation

        # Unpadding optimization
        self.use_unpadding = use_unpadding

        # Liger-kernel optimizations
        self.liger_fused_swiglu = liger_fused_swiglu
        self.liger_fused_rope = liger_fused_rope
        self.liger_fused_rmsnorm = liger_fused_rmsnorm


class ModernBertEmbeddings(nn.Module):
    """Embeddings layer with optional position embeddings.

    When use_rope=True, position embeddings are skipped (RoPE handles
    positions in attention).
    """

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.config = config
        self.use_rope = config.use_rope

        # Word embeddings
        self.word_embeddings = nn.Embedding(
            config.vocab_size,
            config.hidden_size,
            padding_idx=config.pad_token_id,
        )

        # Token type embeddings
        self.token_type_embeddings = nn.Embedding(
            config.type_vocab_size,
            config.hidden_size,
        )

        # Position embeddings (only when not using RoPE)
        if not self.use_rope:
            self.position_embeddings = nn.Embedding(
                config.max_position_embeddings,
                config.hidden_size,
            )

        # Layer norm and dropout
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps, bias=config.use_bias)
        self.dropout = nn.Dropout(config.dropout_mlp)

    def forward(
        self,
        input_ids: Tensor,
        token_type_ids: Optional[Tensor] = None,
        position_ids: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass.

        Args:
            input_ids: Token IDs (batch, seq_len)
            token_type_ids: Segment IDs (batch, seq_len)
            position_ids: Position IDs (batch, seq_len)

        Returns:
            Embeddings tensor (batch, seq_len, hidden_size)
        """
        batch_size, seq_length = input_ids.size()
        device = input_ids.device

        # Default token type ids to zeros
        if token_type_ids is None:
            token_type_ids = torch.zeros(
                (batch_size, seq_length), dtype=torch.long, device=device
            )

        # Get word and token type embeddings
        word_embeds = self.word_embeddings(input_ids)
        token_type_embeds = self.token_type_embeddings(token_type_ids)

        embeddings = word_embeds + token_type_embeds

        # Add position embeddings only when not using RoPE
        if not self.use_rope:
            if seq_length > self.config.max_position_embeddings:
                raise ValueError(
                    f"Sequence length ({seq_length}) exceeds max_position_embeddings "
                    f"({self.config.max_position_embeddings}). Either truncate your input "
                    f"or enable RoPE (use_rope=True) for unlimited sequence length."
                )
            if position_ids is None:
                position_ids = torch.arange(
                    seq_length, dtype=torch.long, device=device
                ).unsqueeze(0).expand(batch_size, -1)
            position_embeds = self.position_embeddings(position_ids)
            embeddings = embeddings + position_embeds

        embeddings = self.LayerNorm(embeddings)
        embeddings = self.dropout(embeddings)

        return embeddings


class ModernBertSelfAttention(nn.Module):
    """Self-attention with optional RoPE and configurable attention implementation.

    When use_rope=True, applies rotary position embeddings to Q and K.

    Supports multiple attention implementations:
    - "eager": Standard PyTorch matmul-based attention
    - "sdpa": PyTorch's scaled_dot_product_attention
    - "flash_attention_2": Flash Attention 2
    - "flash_attention_3": Flash Attention 3 (Hopper GPUs only)

    Also supports unpadded (variable-length) sequences when use_unpadding=True.
    """

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        if config.hidden_size % config.num_attention_heads != 0:
            raise ValueError(
                f"hidden_size ({config.hidden_size}) must be divisible by "
                f"num_attention_heads ({config.num_attention_heads})"
            )

        self.num_attention_heads = config.num_attention_heads
        self.attention_head_size = config.hidden_size // config.num_attention_heads
        self.all_head_size = self.num_attention_heads * self.attention_head_size

        self.query = nn.Linear(config.hidden_size, self.all_head_size, bias=config.use_bias)
        self.key = nn.Linear(config.hidden_size, self.all_head_size, bias=config.use_bias)
        self.value = nn.Linear(config.hidden_size, self.all_head_size, bias=config.use_bias)

        self.dropout_prob = config.dropout_attn_weights

        # Attention implementation
        self.attn_implementation = validate_attn_implementation(
            getattr(config, "attn_implementation", "eager")
        )

        # Unpadding support
        self.use_unpadding = getattr(config, "use_unpadding", False)

        self.use_rope = config.use_rope
        if self.use_rope:
            # Check if liger fused RoPE is enabled
            use_liger_rope = getattr(config, "liger_fused_rope", False)

            # Always create padded RoPE for standard forward path
            self.rotary_emb_l = RotaryPositionEmbedding(
                dim=self.attention_head_size,
                base=config.l_step_rope_base,
                use_liger=use_liger_rope,
            )
            self.rotary_emb_h = RotaryPositionEmbedding(
                dim=self.attention_head_size,
                base=config.h_step_rope_base,
                use_liger=use_liger_rope,
            )

            if self.use_unpadding:
                # Also create unpadded RoPE for variable-length sequences
                # Note: Liger RoPE not yet supported for unpadded sequences
                from .rope import UnpaddedRotaryPositionEmbedding
                self.rotary_emb_l_unpadded = UnpaddedRotaryPositionEmbedding(
                    dim=self.attention_head_size,
                    base=config.l_step_rope_base,
                )
                self.rotary_emb_h_unpadded = UnpaddedRotaryPositionEmbedding(
                    dim=self.attention_head_size,
                    base=config.h_step_rope_base,
                )

    def transpose_for_scores(self, x: Tensor) -> Tensor:
        """Reshape for multi-head attention."""
        new_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(new_shape)
        return x.permute(0, 2, 1, 3)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        output_attentions: bool = False,
        step_type: Optional[str] = None,
        # Unpadding context (when use_unpadding=True)
        cu_seqlens: Optional[Tensor] = None,
        max_seqlen: Optional[int] = None,
        indices: Optional[Tensor] = None,
        batch_size: Optional[int] = None,
    ) -> Tuple[Tensor, ...]:
        """Forward pass with optional unpadding support.

        Args:
            hidden_states: Input tensor
                - Padded: (batch, seq_len, hidden_size)
                - Unpadded: (total_nnz, hidden_size)
            attention_mask: Mask for padded attention or original (batch, seq) mask for unpadded
            output_attentions: Whether to return attention weights
            step_type: "h" for H-step (global attention), "l" for L-step (local attention)
            cu_seqlens: Cumulative sequence lengths for unpadded (batch + 1,)
            max_seqlen: Maximum sequence length in batch for unpadded
            indices: Indices for re-padding (from unpad_input)
            batch_size: Original batch size for re-padding

        Returns:
            Tuple of (context, attention_probs) if output_attentions else (context,)
        """
        is_unpadded = cu_seqlens is not None

        if is_unpadded:
            return self._forward_unpadded(
                hidden_states, attention_mask, output_attentions, step_type,
                cu_seqlens, max_seqlen, indices, batch_size
            )
        else:
            return self._forward_padded(
                hidden_states, attention_mask, output_attentions, step_type
            )

    def _forward_padded(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor],
        output_attentions: bool,
        step_type: Optional[str],
    ) -> Tuple[Tensor, ...]:
        """Standard padded forward pass."""
        query_layer = self.transpose_for_scores(self.query(hidden_states))
        key_layer = self.transpose_for_scores(self.key(hidden_states))
        value_layer = self.transpose_for_scores(self.value(hidden_states))

        # Apply RoPE (select based on step_type)
        if self.use_rope:
            rope = self.rotary_emb_h if step_type == "h" else self.rotary_emb_l
            query_layer, key_layer = rope(query_layer, key_layer)

        # Use unified attention forward
        context_layer = attention_forward(
            query_layer,
            key_layer,
            value_layer,
            attention_mask=attention_mask,
            dropout_p=self.dropout_prob,
            training=self.training,
            implementation=self.attn_implementation,
        )

        # Reshape back: (batch, num_heads, seq_len, head_size) -> (batch, seq_len, all_head_size)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(new_shape)

        # Note: attention_probs not available with flash/sdpa implementations
        if output_attentions and self.attn_implementation == "eager":
            # Recompute attention probs for output (only in eager mode)
            attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
            attention_scores = attention_scores / (self.attention_head_size ** 0.5)
            if attention_mask is not None:
                attention_scores = attention_scores + attention_mask
            attention_probs = F.softmax(attention_scores, dim=-1)
            outputs = (context_layer, attention_probs)
        else:
            outputs = (context_layer,)

        return outputs

    def _forward_unpadded(
        self,
        hidden_states: Tensor,  # (total_nnz, hidden_size)
        attention_mask: Tensor,  # Original (batch, seq) mask
        output_attentions: bool,
        step_type: Optional[str],
        cu_seqlens: Tensor,
        max_seqlen: int,
        indices: Tensor,
        batch_size: int,
    ) -> Tuple[Tensor, ...]:
        """Unpadded forward pass using variable-length attention."""
        from .flash_attention import (
            flash_attention_2_varlen,
            flash_attention_3_varlen,
            sdpa_attention_varlen,
            eager_attention_varlen,
        )

        total_nnz = hidden_states.shape[0]

        # Project Q, K, V: (total_nnz, hidden) -> (total_nnz, all_head_size)
        q = self.query(hidden_states)
        k = self.key(hidden_states)
        v = self.value(hidden_states)

        # Reshape to (total_nnz, num_heads, head_dim)
        q = q.view(total_nnz, self.num_attention_heads, self.attention_head_size)
        k = k.view(total_nnz, self.num_attention_heads, self.attention_head_size)
        v = v.view(total_nnz, self.num_attention_heads, self.attention_head_size)

        # Apply RoPE (unpadded version)
        if self.use_rope:
            rope = self.rotary_emb_h_unpadded if step_type == "h" else self.rotary_emb_l_unpadded
            q, k = rope(q, k, cu_seqlens, max_seqlen)

        # Pack QKV for flash attention: (total_nnz, 3, num_heads, head_dim)
        qkv = torch.stack([q, k, v], dim=1)

        # Dispatch to appropriate implementation
        if self.attn_implementation == "flash_attention_2":
            context = flash_attention_2_varlen(
                qkv, cu_seqlens, max_seqlen,
                dropout_p=self.dropout_prob,
                training=self.training,
            )
        elif self.attn_implementation == "flash_attention_3":
            context = flash_attention_3_varlen(
                q, k, v, cu_seqlens, max_seqlen,
                dropout_p=self.dropout_prob,
                training=self.training,
            )
        elif self.attn_implementation == "sdpa":
            context = sdpa_attention_varlen(
                qkv, cu_seqlens, max_seqlen, indices, batch_size,
                attention_mask,
                dropout_p=self.dropout_prob,
                training=self.training,
            )
        else:  # eager
            context = eager_attention_varlen(
                qkv, cu_seqlens, max_seqlen, indices, batch_size,
                attention_mask,
                dropout_p=self.dropout_prob,
                training=self.training,
            )

        # context: (total_nnz, num_heads, head_dim) -> (total_nnz, all_head_size)
        context = context.view(total_nnz, self.all_head_size)

        # Note: attention_probs not available in unpadded mode
        return (context,)


class ModernBertSelfOutput(nn.Module):
    """Self-attention output projection (no LayerNorm - Pre-Norm handles it)."""

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size, bias=config.use_bias)
        self.dropout = nn.Dropout(config.dropout_attn_output)

    def forward(self, hidden_states: Tensor) -> Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states


class ModernBertAttention(nn.Module):
    """Full attention block (self-attention + output projection)."""

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.self = ModernBertSelfAttention(config)
        self.output = ModernBertSelfOutput(config)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        output_attentions: bool = False,
        step_type: Optional[str] = None,
        # Unpadding context
        cu_seqlens: Optional[Tensor] = None,
        max_seqlen: Optional[int] = None,
        indices: Optional[Tensor] = None,
        batch_size: Optional[int] = None,
    ) -> Tuple[Tensor, ...]:
        self_outputs = self.self(
            hidden_states, attention_mask, output_attentions, step_type=step_type,
            cu_seqlens=cu_seqlens, max_seqlen=max_seqlen, indices=indices, batch_size=batch_size
        )
        attention_output = self.output(self_outputs[0])
        outputs = (attention_output,) + self_outputs[1:]
        return outputs


# Gated activations require two projections (gate + up)
GATED_ACTIVATIONS = {"geglu", "swiglu", "reglu"}


class ModernBertIntermediate(nn.Module):
    """Feed-forward intermediate layer with support for gated activations."""

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        activation_fn = getattr(config, "activation_fn", "gelu")
        self.is_gated = activation_fn in GATED_ACTIVATIONS
        self.activation_fn = activation_fn

        # Liger-kernel optimizations
        self.use_liger_swiglu = (
            getattr(config, "liger_fused_swiglu", False)
            and activation_fn == "swiglu"
        )
        self._liger_silu_mul = None
        if self.use_liger_swiglu:
            try:
                from liger_kernel.ops.swiglu import LigerSiLUMulFunction
                self._liger_silu_mul = LigerSiLUMulFunction.apply
            except ImportError:
                self.use_liger_swiglu = False

        if self.is_gated:
            # Gated activations: gate_proj for activation, up_proj for values
            self.gate_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=config.use_bias)
            self.up_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=config.use_bias)

            # Create depthwise conv if any step type uses it (for ConvSwiGLU/ConvGeGLU/ConvReGLU)
            use_conv = getattr(config, "use_conv", False)
            h_step_use_conv = getattr(config, "h_step_use_conv", False)
            l_step_use_conv = getattr(config, "l_step_use_conv", True)
            if use_conv or h_step_use_conv or l_step_use_conv:
                self.dwconv = nn.Conv1d(
                    in_channels=config.intermediate_size,
                    out_channels=config.intermediate_size,
                    kernel_size=config.conv_kernel_size,
                    padding=config.conv_kernel_size // 2,
                    groups=config.intermediate_size,  # Depthwise: each channel independently
                    bias=True,
                )
                # Post-conv activation matches the gate activation
                if activation_fn == "swiglu":
                    self.conv_act = nn.SiLU()
                elif activation_fn == "geglu":
                    self.conv_act = nn.GELU()
                elif activation_fn == "reglu":
                    self.conv_act = nn.ReLU()
        else:
            # Standard activations: single projection
            self.dense = nn.Linear(config.hidden_size, config.intermediate_size, bias=config.use_bias)

    def forward(self, hidden_states: Tensor, use_conv: Optional[bool] = None) -> Tensor:
        """Forward pass.

        Args:
            hidden_states: Input tensor
            use_conv: Whether to apply conv. If None, defaults to True if dwconv exists.
        """
        if self.is_gated:
            gate = self.gate_proj(hidden_states)
            up = self.up_proj(hidden_states)

            # Apply depthwise conv if requested and available
            apply_conv = use_conv if use_conv is not None else hasattr(self, "dwconv")

            # Use liger fused SwiGLU only when NOT using conv
            # (liger kernel can't handle the conv step)
            if self.use_liger_swiglu and self._liger_silu_mul is not None and not apply_conv:
                # Liger fused: silu(gate) * up in one kernel
                x = self._liger_silu_mul(gate, up)
            else:
                # Standard path: separate activation and multiplication
                if self.activation_fn == "geglu":
                    gate = F.gelu(gate)
                elif self.activation_fn == "swiglu":
                    gate = F.silu(gate)
                elif self.activation_fn == "reglu":
                    gate = F.relu(gate)
                x = gate * up

            # Apply depthwise conv if requested and available
            if apply_conv and hasattr(self, "dwconv"):
                seq_len = x.size(1)
                # Conv1d expects (batch, channels, seq_len)
                x = x.transpose(1, 2)
                x = self.dwconv(x)
                # Trim to original sequence length if padding added extra
                x = x[..., :seq_len]
                x = self.conv_act(x)
                x = x.transpose(1, 2)

            return x
        else:
            x = self.dense(hidden_states)
            if self.activation_fn == "gelu":
                return F.gelu(x)
            elif self.activation_fn == "relu":
                return F.relu(x)
            raise ValueError(f"Unknown activation: {self.activation_fn}")


class ModernBertOutput(nn.Module):
    """Feed-forward output projection (no LayerNorm - Pre-Norm handles it)."""

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.dense = nn.Linear(config.intermediate_size, config.hidden_size, bias=config.use_bias)
        self.dropout = nn.Dropout(config.dropout_mlp)

    def forward(self, hidden_states: Tensor) -> Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states


class ModernBertLayer(nn.Module):
    """A single transformer layer with Pre-Norm architecture.

    Pre-Norm applies LayerNorm BEFORE each sublayer:
        x = x + Sublayer(LayerNorm(x))

    This improves training stability compared to Post-Norm.
    Reference: ModernBERT paper (arXiv:2412.13663)
    """

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        # Pre-Norm
        self.attn_norm = get_norm_layer(config)
        self.ffn_norm = get_norm_layer(config)

        # Sublayers
        self.attention = ModernBertAttention(config)
        self.intermediate = ModernBertIntermediate(config)
        self.output = ModernBertOutput(config)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        output_attentions: bool = False,
        step_type: Optional[str] = None,
        use_conv: Optional[bool] = None,
        # Unpadding context
        cu_seqlens: Optional[Tensor] = None,
        max_seqlen: Optional[int] = None,
        indices: Optional[Tensor] = None,
        batch_size: Optional[int] = None,
    ) -> Tuple[Tensor, ...]:
        is_unpadded = cu_seqlens is not None

        # Pre-Norm attention: x = x + Attention(LayerNorm(x))
        normed = self.attn_norm(hidden_states)
        attention_outputs = self.attention(
            normed, attention_mask, output_attentions, step_type=step_type,
            cu_seqlens=cu_seqlens, max_seqlen=max_seqlen, indices=indices, batch_size=batch_size
        )
        hidden_states = hidden_states + attention_outputs[0]

        # Pre-Norm FFN: x = x + FFN(LayerNorm(x))
        normed = self.ffn_norm(hidden_states)

        # For conv with unpadded sequences: pad -> conv -> unpad
        if is_unpadded and use_conv:
            intermediate_output = self._intermediate_with_unpadded_conv(
                normed, use_conv, cu_seqlens, max_seqlen, indices, batch_size
            )
        else:
            intermediate_output = self.intermediate(normed, use_conv=use_conv)

        ffn_output = self.output(intermediate_output)
        hidden_states = hidden_states + ffn_output

        outputs = (hidden_states,) + attention_outputs[1:]
        return outputs

    def _intermediate_with_unpadded_conv(
        self,
        normed: Tensor,
        use_conv: bool,
        cu_seqlens: Tensor,
        max_seqlen: int,
        indices: Tensor,
        batch_size: int,
    ) -> Tensor:
        """Handle conv on unpadded sequences by padding temporarily."""
        from .bert_padding import pad_input, unpad_input_only

        # Pad for conv: (total_nnz, hidden) -> (batch, seq, hidden)
        padded = pad_input(normed, indices, batch_size, max_seqlen)

        # Run intermediate with conv
        intermediate = self.intermediate(padded, use_conv=use_conv)

        # Create mask from cu_seqlens for unpadding
        mask = torch.zeros(batch_size, max_seqlen, device=normed.device, dtype=torch.bool)
        for i in range(batch_size):
            seq_len = cu_seqlens[i + 1] - cu_seqlens[i]
            mask[i, :seq_len] = True

        # Unpad: (batch, seq, hidden) -> (total_nnz, hidden)
        return unpad_input_only(intermediate, mask)


class ModernBertEncoder(nn.Module):
    """Stack of transformer layers with Pre-Norm architecture.

    Includes a final LayerNorm after all layers since Pre-Norm leaves the
    last layer's output un-normalized.
    """

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.layer = nn.ModuleList(
            [ModernBertLayer(config) for _ in range(config.num_hidden_layers)]
        )
        # Final norm for Pre-Norm architecture
        self.final_norm = get_norm_layer(config)

    def forward(
        self,
        hidden_states: Tensor,
        attention_mask: Optional[Tensor] = None,
        output_attentions: bool = False,
        output_hidden_states: bool = False,
        step_type: Optional[str] = None,
        use_conv: Optional[bool] = None,
        # Unpadding context
        cu_seqlens: Optional[Tensor] = None,
        max_seqlen: Optional[int] = None,
        indices: Optional[Tensor] = None,
        batch_size: Optional[int] = None,
    ) -> Tuple[Tensor, ...]:
        all_hidden_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None

        for layer_module in self.layer:
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            layer_outputs = layer_module(
                hidden_states, attention_mask, output_attentions,
                step_type=step_type, use_conv=use_conv,
                cu_seqlens=cu_seqlens, max_seqlen=max_seqlen, indices=indices, batch_size=batch_size
            )
            hidden_states = layer_outputs[0]

            if output_attentions:
                all_attentions = all_attentions + (layer_outputs[1],)

        # Apply final LayerNorm (Pre-Norm architecture)
        hidden_states = self.final_norm(hidden_states)

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)

        return (hidden_states, all_hidden_states, all_attentions)


class ModernBert(nn.Module):
    """ModernBERT: A clean BERT implementation with modern features.

    Supports:
    - Rotary Position Embeddings (RoPE) for unlimited sequence length
    - Standard absolute position embeddings (default)

    Args:
        config: ModernBertConfig or BertConfig
    """

    def __init__(self, config: ModernBertConfig):
        super().__init__()
        self.config = config

        self.embeddings = ModernBertEmbeddings(config)
        self.encoder = ModernBertEncoder(config)

        # Apply weight initialization
        self._init_weights()

    def _init_weights(self) -> None:
        """Initialize weights based on config.init_method."""
        init_method = getattr(self.config, 'init_method', 'default')

        if init_method == "megatron":
            apply_megatron_init(
                self,
                num_layers=self.config.num_hidden_layers,
                init_std=getattr(self.config, 'init_std', 0.02),
                init_cutoff_factor=getattr(self.config, 'init_cutoff_factor', 3.0),
            )
        elif init_method == "default":
            # Standard BERT initialization
            init_std = getattr(self.config, 'init_std', 0.02)
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    module.weight.data.normal_(mean=0.0, std=init_std)
                    if module.bias is not None:
                        module.bias.data.zero_()
                elif isinstance(module, nn.Embedding):
                    module.weight.data.normal_(mean=0.0, std=init_std)
                    if module.padding_idx is not None:
                        module.weight.data[module.padding_idx].zero_()
                elif isinstance(module, nn.LayerNorm):
                    if module.weight is not None:
                        module.weight.data.fill_(1.0)
                    if module.bias is not None:
                        module.bias.data.zero_()
                elif isinstance(module, (RMSNorm, RMSNormWithWeight)):
                    # RMSNormWithWeight has learnable weight, RMSNorm is parameter-free
                    if hasattr(module, 'weight') and module.weight is not None:
                        module.weight.data.fill_(1.0)
        # small_init handled separately for embeddings only

    def get_extended_attention_mask(
        self,
        attention_mask: Tensor,
        input_shape: Tuple[int, ...],
        device: torch.device,
    ) -> Tensor:
        """Convert attention mask to extended format."""
        if attention_mask.dim() == 3:
            extended_mask = attention_mask[:, None, :, :]
        elif attention_mask.dim() == 2:
            extended_mask = attention_mask[:, None, None, :]
        else:
            raise ValueError(f"Wrong attention_mask shape: {attention_mask.shape}")

        extended_mask = extended_mask.to(dtype=torch.float32)
        extended_mask = (1.0 - extended_mask) * -10000.0
        return extended_mask

    def forward(
        self,
        input_ids: Tensor,
        attention_mask: Optional[Tensor] = None,
        token_type_ids: Optional[Tensor] = None,
        position_ids: Optional[Tensor] = None,
        output_attentions: bool = False,
        output_hidden_states: bool = False,
    ) -> BaseModelOutput:
        """Forward pass.

        Args:
            input_ids: Token IDs (batch, seq_len)
            attention_mask: Attention mask (batch, seq_len)
            token_type_ids: Segment IDs (batch, seq_len)
            position_ids: Position IDs (batch, seq_len)
            output_attentions: Return attention weights
            output_hidden_states: Return all hidden states

        Returns:
            BaseModelOutput with last_hidden_state
        """
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids)

        extended_attention_mask = self.get_extended_attention_mask(
            attention_mask,
            input_ids.size(),
            input_ids.device,
        )

        hidden_states = self.embeddings(
            input_ids,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
        )

        encoder_outputs = self.encoder(
            hidden_states,
            attention_mask=extended_attention_mask,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )

        return BaseModelOutput(
            last_hidden_state=encoder_outputs[0],
            hidden_states=encoder_outputs[1],
            attentions=encoder_outputs[2],
        )

    def resize_token_embeddings(self, new_num_tokens: int) -> nn.Embedding:
        """Resize the token embeddings."""
        old_embeddings = self.embeddings.word_embeddings
        old_num_tokens, embedding_dim = old_embeddings.weight.shape

        if new_num_tokens == old_num_tokens:
            return old_embeddings

        new_embeddings = nn.Embedding(
            new_num_tokens,
            embedding_dim,
            padding_idx=old_embeddings.padding_idx,
        )

        num_to_copy = min(old_num_tokens, new_num_tokens)
        new_embeddings.weight.data[:num_to_copy] = old_embeddings.weight.data[:num_to_copy]

        if new_num_tokens > old_num_tokens:
            new_embeddings.weight.data[old_num_tokens:] = old_embeddings.weight.data.mean(
                dim=0, keepdim=True
            )

        self.embeddings.word_embeddings = new_embeddings
        return new_embeddings

    @classmethod
    def from_bert_config(
        cls,
        bert_config: BertConfig,
        use_rope: bool = False,
        rope_base: float = 10000.0,
        use_bias: bool = False,
    ) -> "ModernBert":
        """Create ModernBert from a BertConfig."""
        config = ModernBertConfig(
            vocab_size=bert_config.vocab_size,
            hidden_size=bert_config.hidden_size,
            num_hidden_layers=bert_config.num_hidden_layers,
            num_attention_heads=bert_config.num_attention_heads,
            intermediate_size=bert_config.intermediate_size,
            activation_fn=getattr(bert_config, 'activation_fn', bert_config.hidden_act),
            dropout_mlp=bert_config.hidden_dropout_prob,
            dropout_attn_weights=bert_config.attention_probs_dropout_prob,
            max_position_embeddings=bert_config.max_position_embeddings,
            type_vocab_size=bert_config.type_vocab_size,
            layer_norm_eps=bert_config.layer_norm_eps,
            pad_token_id=bert_config.pad_token_id,
            use_rope=use_rope,
            rope_base=rope_base,
            use_bias=use_bias,
        )
        return cls(config)
