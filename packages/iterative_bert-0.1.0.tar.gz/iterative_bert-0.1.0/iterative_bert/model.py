"""Iterative refinement BERT encoder based on Tiny Recursive Models."""

from typing import Optional, Tuple

import torch
import torch.nn as nn
from transformers import PretrainedConfig, PreTrainedModel, BertConfig
from transformers.modeling_outputs import BaseModelOutput

__all__ = [
    "create_single_layer_bert_config",
    "IterativeBertConfig",
    "IterativeBert",
]


def create_single_layer_bert_config(
    hidden_size: int = 312,
    intermediate_size: int = 1200,
    num_attention_heads: int = 12,
    vocab_size: int = 50272,
    max_position_embeddings: int = 512,
    **kwargs,
) -> PretrainedConfig:
    """
    Create a single-layer BERT configuration with TinyBERT-like dimensions.

    This creates a shallow encoder (1 transformer layer) that can be used with
    IterativeBert for multi-cycle iterative refinement. The single layer will be
    applied multiple times (h_cycles * l_cycles) to achieve effective depth.

    Parameters
    ----------
    hidden_size : int, default=312
        Hidden dimension size (matches TinyBERT)
    intermediate_size : int, default=1200
        Feed-forward intermediate size
    num_attention_heads : int, default=12
        Number of attention heads
    vocab_size : int, default=50272
        Vocabulary size (tiktoken gpt2 + special tokens)
    max_position_embeddings : int, default=512
        Maximum sequence length
    **kwargs
        Additional arguments passed to BertConfig

    Returns
    -------
    PretrainedConfig
        BertConfig with num_hidden_layers=1
    """
    config = BertConfig(
        vocab_size=vocab_size,
        hidden_size=hidden_size,
        num_hidden_layers=1,  # Single layer for iterative refinement
        num_attention_heads=num_attention_heads,
        intermediate_size=intermediate_size,
        max_position_embeddings=max_position_embeddings,
        **kwargs,
    )
    return config


class IterativeBertConfig(PretrainedConfig):
    """Configuration for IterativeBert.

    Combines ModernBertConfig fields with iterative refinement settings.
    This config is saved/loaded with the model for HuggingFace compatibility.
    """

    model_type = "iterative_bert"

    def __init__(
        self,
        # Core encoder params
        vocab_size: int = 30522,
        hidden_size: int = 768,
        num_hidden_layers: int = 1,
        num_attention_heads: int = 12,
        intermediate_size: int = 3072,
        activation_fn: str = "gelu",
        dropout_mlp: float = 0.0,
        dropout_attn_weights: float = 0.0,
        dropout_attn_output: float = 0.1,
        max_position_embeddings: int = 512,
        type_vocab_size: int = 2,
        layer_norm_eps: float = 1e-12,
        norm_type: str = "layernorm",  # "layernorm" | "rmsnorm" | "rmsnorm_weighted"
        pad_token_id: int = 0,
        # Modern options
        use_rope: bool = False,
        rope_base: float = 10000.0,
        use_bias: bool = False,
        init_method: str = "default",
        init_std: float = 0.02,
        init_cutoff_factor: float = 3.0,
        # IterativeBert-specific params
        residual_mode: str = "add",
        # Multi-cycle recurrence (URM-style)
        h_cycles: int = 1,  # Outer cycles (H-1 run forward-only, 1 with gradients)
        l_cycles: int = 8,  # Inner cycles per H cycle
        use_input_injection: bool = True,  # Re-inject input embeddings at each L cycle
        tbptl_forward_only_steps: int = 0,  # TBPTL within final H cycle
        # Convolution settings
        use_conv: bool = False,  # Enable depthwise conv in gated activations
        conv_kernel_size: int = 2,  # Kernel size for depthwise conv
        # Per-step configuration (ModernBERT-style alternating attention)
        h_step_rope_base: float = 160000.0,  # Global attention theta for H-steps
        l_step_rope_base: float = 10000.0,  # Local attention theta for L-steps
        h_step_use_conv: bool = False,  # H-steps: SwiGLU (no conv)
        l_step_use_conv: bool = True,  # L-steps: ConvSwiGLU
        # ACT (Adaptive Computation Time) halting
        use_act: bool = False,  # Enable ACT halting
        act_exploration_prob: float = 0.1,  # Training: random early halt probability
        act_loss_type: str = "bce",  # "bce" | "ponder" | "entropy" | "none"
        act_loss_weight: float = 0.5,  # Weight for ACT loss component
        # Attention implementation: "eager", "sdpa", "flash_attention_2", "flash_attention_3"
        attn_implementation: str = "flash_attention_2",
        # Unpadding: remove padding before attention, restore after (MosaicBERT optimization)
        use_unpadding: bool = False,
        # Liger-kernel optimizations
        liger_fused_swiglu: bool = False,  # Use liger fused SwiGLU kernel
        liger_fused_rope: bool = False,  # Use liger fused RoPE kernel
        liger_fused_rmsnorm: bool = False,  # Use liger fused RMSNorm kernel
        **kwargs,
    ):
        super().__init__(pad_token_id=pad_token_id, **kwargs)
        # Core encoder params
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.intermediate_size = intermediate_size
        self.activation_fn = activation_fn
        self.dropout_mlp = dropout_mlp
        self.dropout_attn_weights = dropout_attn_weights
        self.dropout_attn_output = dropout_attn_output
        self.max_position_embeddings = max_position_embeddings
        self.type_vocab_size = type_vocab_size
        self.layer_norm_eps = layer_norm_eps
        self.norm_type = norm_type

        # Modern options
        self.use_rope = use_rope
        self.rope_base = rope_base
        self.use_bias = use_bias
        self.init_method = init_method
        self.init_std = init_std
        self.init_cutoff_factor = init_cutoff_factor

        # IterativeBert-specific
        self.residual_mode = residual_mode
        self.h_cycles = h_cycles
        self.l_cycles = l_cycles
        self.use_input_injection = use_input_injection
        self.tbptl_forward_only_steps = tbptl_forward_only_steps

        # Convolution settings
        self.use_conv = use_conv
        self.conv_kernel_size = conv_kernel_size

        # Per-step configuration (ModernBERT-style alternating attention)
        self.h_step_rope_base = h_step_rope_base
        self.l_step_rope_base = l_step_rope_base
        self.h_step_use_conv = h_step_use_conv
        self.l_step_use_conv = l_step_use_conv

        # ACT halting
        self.use_act = use_act
        self.act_exploration_prob = act_exploration_prob
        self.act_loss_type = act_loss_type
        self.act_loss_weight = act_loss_weight

        # Attention implementation
        self.attn_implementation = attn_implementation

        # Unpadding optimization
        self.use_unpadding = use_unpadding

        # Liger-kernel optimizations
        self.liger_fused_swiglu = liger_fused_swiglu
        self.liger_fused_rope = liger_fused_rope
        self.liger_fused_rmsnorm = liger_fused_rmsnorm

    def to_modern_bert_config(self):
        """Create ModernBertConfig for internal _base_model."""
        from .modern_bert import ModernBertConfig

        return ModernBertConfig(
            vocab_size=self.vocab_size,
            hidden_size=self.hidden_size,
            num_hidden_layers=self.num_hidden_layers,
            num_attention_heads=self.num_attention_heads,
            intermediate_size=self.intermediate_size,
            activation_fn=self.activation_fn,
            dropout_mlp=self.dropout_mlp,
            dropout_attn_weights=self.dropout_attn_weights,
            dropout_attn_output=self.dropout_attn_output,
            max_position_embeddings=self.max_position_embeddings,
            type_vocab_size=self.type_vocab_size,
            layer_norm_eps=self.layer_norm_eps,
            norm_type=self.norm_type,
            pad_token_id=self.pad_token_id,
            use_rope=self.use_rope,
            rope_base=self.rope_base,
            use_bias=self.use_bias,
            init_method=self.init_method,
            init_std=self.init_std,
            init_cutoff_factor=self.init_cutoff_factor,
            # Convolution settings
            use_conv=self.use_conv,
            conv_kernel_size=self.conv_kernel_size,
            # Per-step config for alternating attention
            h_step_rope_base=self.h_step_rope_base,
            l_step_rope_base=self.l_step_rope_base,
            h_step_use_conv=self.h_step_use_conv,
            l_step_use_conv=self.l_step_use_conv,
            # Attention implementation
            attn_implementation=self.attn_implementation,
            # Unpadding optimization
            use_unpadding=self.use_unpadding,
            # Liger-kernel optimizations
            liger_fused_swiglu=self.liger_fused_swiglu,
            liger_fused_rope=self.liger_fused_rope,
            liger_fused_rmsnorm=self.liger_fused_rmsnorm,
        )


class IterativeBert(PreTrainedModel):
    """
    Iterative refinement transformer encoder.

    Applies iterative refinement (Universal Transformer-style) using ModernBert
    as the base architecture with configurable residual connection modes.

    Supports Rotary Position Embeddings (RoPE) for unlimited sequence length
    via the ModernBert base class.
    """

    config_class = IterativeBertConfig
    base_model_prefix = "iterative_bert"

    def __init__(self, config: IterativeBertConfig):
        super().__init__(config)

        # Validate residual mode
        valid_modes = ["none", "add", "gated", "learned_alpha"]
        if config.residual_mode not in valid_modes:
            raise ValueError(f"residual_mode must be one of {valid_modes}, got {config.residual_mode}")

        # Validate RoPE compatibility: head_dim must be even
        if config.use_rope:
            head_dim = config.hidden_size // config.num_attention_heads
            assert head_dim % 2 == 0, (
                f"RoPE requires even head dimension, got hidden_size={config.hidden_size} / "
                f"num_attention_heads={config.num_attention_heads} = {head_dim}. "
                f"Ensure hidden_size % (2 * num_attention_heads) == 0."
            )

        # Create ModernBert from config
        from .modern_bert import ModernBert

        modern_config = config.to_modern_bert_config()
        self._base_model = ModernBert(modern_config)

        # Initialize residual connection components
        if config.residual_mode == "gated":
            self.gate = nn.Sequential(
                nn.Linear(config.hidden_size * 2, config.hidden_size, bias=config.use_bias),
                nn.Sigmoid(),
            )
        elif config.residual_mode == "learned_alpha":
            self.alpha = nn.Parameter(torch.tensor(0.3))

        # ACT halting: q_head predicts P(halt) from [CLS] token
        if config.use_act:
            self.q_head = nn.Linear(config.hidden_size, 1, bias=True)
            # Initialize bias to -5 to prefer continuing initially
            with torch.no_grad():
                self.q_head.bias.fill_(-5.0)

    @property
    def embeddings(self):
        """Access embeddings from the base model."""
        return self._base_model.embeddings

    @property
    def encoder(self):
        """Access encoder from the base model."""
        return self._base_model.encoder

    def get_extended_attention_mask(
        self,
        attention_mask: torch.Tensor,
        input_shape: Tuple,
        device: torch.device,
    ) -> torch.Tensor:
        """Convert attention mask to extended format."""
        return self._base_model.get_extended_attention_mask(attention_mask, input_shape, device)

    def embed(self, input_ids, token_type_ids=None, position_ids=None):
        """Embed input tokens."""
        return self.embeddings(
            input_ids=input_ids,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
        )

    def _apply_residual(self, old: torch.Tensor, new: torch.Tensor) -> torch.Tensor:
        """Apply residual connection based on configured mode."""
        if self.config.residual_mode == "none":
            return new
        if self.config.residual_mode == "add":
            # Classic resnet-style addition
            return old + new
        if self.config.residual_mode == "gated":
            # Highway network-style gating - let the model decide what to keep
            gate = self.gate(torch.cat([old, new], dim=-1))
            return gate * new + (1 - gate) * old
        if self.config.residual_mode == "learned_alpha":
            # Simple lerp with learned mixing
            alpha = torch.sigmoid(self.alpha)  # Keep it bounded
            return alpha * new + (1 - alpha) * old
        raise ValueError(f"Unknown residual mode: {self.config.residual_mode}")

    def _refine_step(
        self,
        hidden_states: torch.Tensor,
        extended_mask: torch.Tensor,
        step_type: str = "l",
        # Unpadding context
        cu_seqlens: Optional[torch.Tensor] = None,
        max_seqlen: Optional[int] = None,
        indices: Optional[torch.Tensor] = None,
        batch_size: Optional[int] = None,
    ) -> torch.Tensor:
        """Apply a single refinement step (one pass through encoder layer).

        Args:
            hidden_states: Current hidden states
                - Padded: (batch, seq_len, hidden_size)
                - Unpadded: (total_nnz, hidden_size)
            extended_mask: Extended attention mask or original (batch, seq) mask for unpadded
            step_type: "l" for L-step (local attention, ConvSwiGLU) or
                       "h" for H-step (global attention, SwiGLU)
            cu_seqlens: Cumulative sequence lengths for unpadded
            max_seqlen: Maximum sequence length for unpadded
            indices: Indices for re-padding
            batch_size: Original batch size for re-padding
        """
        old_hidden = hidden_states

        # Determine use_conv based on step type
        use_conv = self.config.h_step_use_conv if step_type == "h" else self.config.l_step_use_conv

        # Apply encoder layer (ModernBertEncoder returns tuple)
        encoder_outputs = self.encoder(
            hidden_states,
            attention_mask=extended_mask,
            step_type=step_type,
            use_conv=use_conv,
            cu_seqlens=cu_seqlens,
            max_seqlen=max_seqlen,
            indices=indices,
            batch_size=batch_size,
        )
        # ModernBertEncoder returns (hidden_states, all_hidden_states, all_attentions)
        new_hidden = encoder_outputs[0]

        # Apply residual connection
        return self._apply_residual(old_hidden, new_hidden)

    def refine(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
        input_embeddings: Optional[torch.Tensor] = None,
        return_all_steps: bool = False,
        tbptl_forward_only_steps: Optional[int] = None,
        # Pre-computed unpadding context (for sequence packing)
        cu_seqlens: Optional[torch.Tensor] = None,
        max_seqlen: Optional[int] = None,
    ):
        """
        Apply multi-cycle iterative refinement to hidden states.

        Implements URM-style hierarchical recurrence (arXiv:2512.14693v3):
        - H_cycles - 1 outer cycles run forward-only (no gradients)
        - Final H cycle runs with gradients
        - Within each H cycle, L_cycles refinement steps are applied
        - Input embeddings are optionally re-injected at each L cycle

        Also supports TBPTL within the final H cycle via tbptl_forward_only_steps.

        When use_act=True, implements Adaptive Computation Time (ACT) halting:
        - Each sequence can halt independently when q_head predicts P(halt) > 0.5
        - Halted sequences are frozen via torch.where (GPU-efficient, constant shapes)
        - Returns act_info dict with halt_logits and steps_taken for loss computation

        When use_unpadding=True (and use_act=False), uses MosaicBERT-style unpadding:
        - Removes padding tokens before attention computation
        - Uses variable-length Flash Attention for efficiency
        - Restores padding at the end

        Sequence Packing Mode:
        - When cu_seqlens and max_seqlen are provided, input is assumed to be pre-packed
        - Hidden states should be (1, total_tokens, hidden_size) or (total_tokens, hidden_size)
        - cu_seqlens marks document boundaries for block-diagonal attention
        - Skips unpad_input() call since data is already unpadded

        Parameters
        ----------
        hidden_states : torch.Tensor
            Initial hidden states [batch_size, seq_len, hidden_size] or
            [1, total_tokens, hidden_size] for packed sequences
        attention_mask : torch.Tensor
            Attention mask [batch_size, seq_len] (ignored when cu_seqlens provided)
        input_embeddings : torch.Tensor, optional
            Original input embeddings for re-injection at each L cycle.
            If None, no input injection is performed.
        return_all_steps : bool
            If True, return all intermediate hidden states
        tbptl_forward_only_steps : int, optional
            Number of forward-only steps within final H cycle.
            Overrides self.config.tbptl_forward_only_steps.
        cu_seqlens : torch.Tensor, optional
            Pre-computed cumulative sequence lengths for packed sequences.
            Shape: (num_sequences + 1,), dtype: int32
        max_seqlen : int, optional
            Pre-computed maximum sequence length for packed sequences.

        Returns
        -------
        torch.Tensor or tuple
            - If use_act=False: hidden_states or (hidden_states, all_hidden)
            - If use_act=True: (hidden_states, act_info) or (hidden_states, all_hidden, act_info)
        """
        # Check if we should use unpadding
        # Note: ACT requires padded tensors for halting logic, so disable unpadding with ACT
        use_unpadding = getattr(self.config, "use_unpadding", False) and not self.config.use_act

        # Detect packed mode: cu_seqlens provided directly
        is_packed = cu_seqlens is not None

        batch_size_orig = hidden_states.size(0)
        seq_len_orig = hidden_states.size(1) if hidden_states.dim() > 1 else hidden_states.size(0)
        device = hidden_states.device

        # Unpadding context (initialized to None or from packed input)
        indices = None
        batch_size_for_unpad = None

        if is_packed:
            # PACKED MODE: Data is already unpadded, cu_seqlens provided directly
            # Hidden states should be (1, total_tokens, hidden) or (total_tokens, hidden)
            if hidden_states.dim() == 3 and hidden_states.size(0) == 1:
                hidden_states = hidden_states.squeeze(0)  # (total_tokens, hidden)
            if input_embeddings is not None and input_embeddings.dim() == 3:
                input_embeddings = input_embeddings.squeeze(0)

            # For packed mode, num_sequences = cu_seqlens.shape[0] - 1
            batch_size_for_unpad = cu_seqlens.shape[0] - 1

            # Packed mode requires flash attention (handles variable-length natively)
            # Use validate_attn_implementation to get the actual implementation after fallback
            from .flash_attention import validate_attn_implementation

            requested_impl = getattr(self.config, "attn_implementation", "flash_attention_2")
            actual_impl = validate_attn_implementation(requested_impl)
            if actual_impl in ("sdpa", "eager"):
                raise ValueError(
                    "Packed mode (cu_seqlens) requires flash_attention_2 or flash_attention_3, "
                    f"but attn_implementation='{requested_impl}' falls back to '{actual_impl}'. "
                    "Either install flash-attn or disable packing."
                )
            indices = None

            # Use attention_mask as extended_mask (not really used with cu_seqlens for flash)
            extended_mask = attention_mask
        elif use_unpadding:
            from .bert_padding import unpad_input, unpad_input_only, pad_input

            # STANDARD UNPADDING: Unpad from attention_mask
            hidden_states, indices, cu_seqlens, max_seqlen = unpad_input(
                hidden_states, attention_mask
            )
            batch_size_for_unpad = batch_size_orig

            # Unpad input embeddings if provided
            if input_embeddings is not None:
                input_embeddings = unpad_input_only(input_embeddings, attention_mask)

            # For unpadded mode, use the original attention_mask (not extended)
            extended_mask = attention_mask
        else:
            extended_mask = self.get_extended_attention_mask(
                attention_mask, hidden_states.shape[:-1], hidden_states.device
            )

        all_hidden = [hidden_states] if return_all_steps else None

        # Multi-cycle recurrence with alternating attention pattern:
        # - L-steps: local attention (low RoPE theta) + ConvSwiGLU
        # - H-step: global attention (high RoPE theta) + SwiGLU
        # Pattern per H-cycle: L, L, ..., L (l_cycles), H (1)
        # Total steps = h_cycles × (l_cycles + 1)
        h_cycles = self.config.h_cycles
        l_cycles = self.config.l_cycles
        total_steps = h_cycles * (l_cycles + 1)

        # ACT tracking (only if enabled)
        use_act = self.config.use_act
        if use_act:
            halted = torch.zeros(batch_size_orig, dtype=torch.bool, device=device)
            halt_logits_all = []
            steps_taken = torch.zeros(batch_size_orig, dtype=torch.long, device=device)
            final_hidden = hidden_states.clone()

        current_step = 0

        def _maybe_check_halt(hs: torch.Tensor, is_last_step: bool = False) -> torch.Tensor:
            """Check halt after each step, freeze halted sequences."""
            nonlocal halted, halt_logits_all, steps_taken, final_hidden

            if not use_act:
                return hs

            # Compute halt logit from [CLS] token
            halt_logit = self.q_head(hs[:, 0])  # [batch, 1]
            halt_logits_all.append(halt_logit)

            # Halting decision: logit > 0 (equiv to sigmoid > 0.5)
            should_halt = (halt_logit.squeeze(-1) > 0) | is_last_step

            # Training exploration: random early halt
            if self.training and self.config.act_exploration_prob > 0:
                explore = torch.rand(batch_size_orig, device=device) < self.config.act_exploration_prob
                should_halt = should_halt | explore

            # Update steps for non-halted sequences
            steps_taken = torch.where(halted, steps_taken, steps_taken + 1)

            # Capture hidden states for newly halted
            newly_halted = should_halt & ~halted
            final_hidden = torch.where(newly_halted.view(-1, 1, 1), hs, final_hidden)
            halted = halted | should_halt

            # Freeze halted sequences (restore to final_hidden)
            return torch.where(halted.view(-1, 1, 1), final_hidden, hs)

        # H_cycles - 1: Forward-only cycles (no gradients)
        if h_cycles > 1:
            with torch.no_grad():
                for _h in range(h_cycles - 1):
                    # L-steps within H-cycle (local attention)
                    for _l in range(l_cycles):
                        if input_embeddings is not None:
                            hidden_states = hidden_states + input_embeddings
                        hidden_states = self._refine_step(
                            hidden_states,
                            extended_mask,
                            step_type="l",
                            cu_seqlens=cu_seqlens,
                            max_seqlen=max_seqlen,
                            indices=indices,
                            batch_size=batch_size_for_unpad,
                        )
                        current_step += 1
                        hidden_states = _maybe_check_halt(
                            hidden_states, is_last_step=(current_step == total_steps)
                        )
                        if return_all_steps:
                            all_hidden.append(hidden_states)

                    # H-step after L-steps (global attention)
                    if input_embeddings is not None:
                        hidden_states = hidden_states + input_embeddings
                    hidden_states = self._refine_step(
                        hidden_states,
                        extended_mask,
                        step_type="h",
                        cu_seqlens=cu_seqlens,
                        max_seqlen=max_seqlen,
                        indices=indices,
                        batch_size=batch_size_for_unpad,
                    )
                    current_step += 1
                    hidden_states = _maybe_check_halt(
                        hidden_states, is_last_step=(current_step == total_steps)
                    )
                    if return_all_steps:
                        all_hidden.append(hidden_states)

        # Final H cycle: With gradients
        # TBPTL: determine number of forward-only steps within this cycle
        forward_only = (
            tbptl_forward_only_steps
            if tbptl_forward_only_steps is not None
            else self.config.tbptl_forward_only_steps
        )

        # L-steps within final H-cycle
        for l_idx in range(l_cycles):
            if input_embeddings is not None:
                hidden_states = hidden_states + input_embeddings

            hidden_states = self._refine_step(
                hidden_states,
                extended_mask,
                step_type="l",
                cu_seqlens=cu_seqlens,
                max_seqlen=max_seqlen,
                indices=indices,
                batch_size=batch_size_for_unpad,
            )
            current_step += 1
            hidden_states = _maybe_check_halt(hidden_states, is_last_step=(current_step == total_steps))

            # TBPTL: detach gradients for initial steps within final H cycle
            if self.training and l_idx < forward_only:
                hidden_states = hidden_states.detach()

            if return_all_steps:
                all_hidden.append(hidden_states)

        # Final H-step (global attention) with gradients
        if input_embeddings is not None:
            hidden_states = hidden_states + input_embeddings
        hidden_states = self._refine_step(
            hidden_states,
            extended_mask,
            step_type="h",
            cu_seqlens=cu_seqlens,
            max_seqlen=max_seqlen,
            indices=indices,
            batch_size=batch_size_for_unpad,
        )
        current_step += 1
        hidden_states = _maybe_check_halt(hidden_states, is_last_step=True)
        if return_all_steps:
            all_hidden.append(hidden_states)

        # Pad output back to original shape if we were using unpadding
        if use_unpadding:
            from .bert_padding import pad_input

            hidden_states = pad_input(hidden_states, indices, batch_size_orig, seq_len_orig)
            # Also pad all_hidden if returning all steps
            if return_all_steps:
                all_hidden = [pad_input(h, indices, batch_size_orig, seq_len_orig) for h in all_hidden]

        # Build return value
        if use_act:
            act_info = {
                "halt_logits": torch.stack(halt_logits_all, dim=1),  # [batch, steps, 1]
                "steps_taken": steps_taken,  # [batch]
            }
            if return_all_steps:
                return hidden_states, all_hidden, act_info
            return hidden_states, act_info

        if return_all_steps:
            return hidden_states, all_hidden
        return hidden_states

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor = None,
        token_type_ids: torch.Tensor = None,
        position_ids: torch.Tensor = None,
        return_all_steps: bool = False,
        # Pre-computed unpadding context (for sequence packing)
        cu_seqlens: Optional[torch.Tensor] = None,
        max_seqlen: Optional[int] = None,
        **kwargs,
    ):
        """
        Forward pass with multi-cycle iterative refinement.

        Parameters
        ----------
        input_ids : torch.Tensor
            Input token IDs [batch_size, seq_len] or [total_tokens] for packed
        attention_mask : torch.Tensor, optional
            Attention mask [batch_size, seq_len] (ignored when cu_seqlens provided)
        token_type_ids : torch.Tensor, optional
            Token type IDs
        position_ids : torch.Tensor, optional
            Position IDs
        return_all_steps : bool
            If True, return all intermediate states
        cu_seqlens : torch.Tensor, optional
            Pre-computed cumulative sequence lengths for packed sequences.
            Shape: (num_sequences + 1,), dtype: int32
        max_seqlen : int, optional
            Pre-computed maximum sequence length for packed sequences.

        Returns
        -------
        BaseModelOutput
            Model output with last_hidden_state attribute.
            When use_act=True, also stores act_info in self._last_act_info.
        """
        # Detect packed mode
        is_packed = cu_seqlens is not None

        if attention_mask is None and not is_packed:
            attention_mask = torch.ones_like(input_ids)

        # For packed mode, add batch dimension if needed
        if is_packed and input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)  # (1, total_tokens)

        # Embed input tokens
        hidden_states = self.embed(input_ids, token_type_ids=token_type_ids, position_ids=position_ids)

        # Store input embeddings for re-injection if enabled
        input_embeddings = hidden_states.clone() if self.config.use_input_injection else None

        # Apply multi-cycle iterative refinement
        refined_result = self.refine(
            hidden_states,
            attention_mask,
            input_embeddings=input_embeddings,
            return_all_steps=return_all_steps,
            cu_seqlens=cu_seqlens,
            max_seqlen=max_seqlen,
        )

        # Handle ACT info if enabled
        # refine() returns different formats based on use_act and return_all_steps:
        # - use_act=False, return_all_steps=False: hidden_states
        # - use_act=False, return_all_steps=True: (hidden_states, all_hidden)
        # - use_act=True, return_all_steps=False: (hidden_states, act_info)
        # - use_act=True, return_all_steps=True: (hidden_states, all_hidden, act_info)
        self._last_act_info = None

        if self.config.use_act:
            if return_all_steps:
                refined_hidden, all_hidden, act_info = refined_result
            else:
                refined_hidden, act_info = refined_result
            self._last_act_info = act_info
        else:
            if return_all_steps:
                refined_hidden, all_hidden = refined_result
            else:
                refined_hidden = refined_result

        return BaseModelOutput(last_hidden_state=refined_hidden)

    def resize_token_embeddings(self, new_num_tokens: int):
        """Resize token embeddings to match new vocabulary size."""
        # BertEmbeddings doesn't have resize_token_embeddings, but word_embeddings does
        if hasattr(self.embeddings, "resize_token_embeddings"):
            return self.embeddings.resize_token_embeddings(new_num_tokens)
        if hasattr(self.embeddings, "word_embeddings"):
            # Resize the word_embeddings directly
            old_embeddings = self.embeddings.word_embeddings
            old_num_tokens, embedding_dim = old_embeddings.weight.shape

            if new_num_tokens == old_num_tokens:
                return self.embeddings

            # Create new embeddings
            new_embeddings = nn.Embedding(new_num_tokens, embedding_dim)
            new_embeddings.weight.data[:old_num_tokens] = old_embeddings.weight.data

            # Initialize new tokens (if expanding)
            if new_num_tokens > old_num_tokens:
                new_embeddings.weight.data[old_num_tokens:] = old_embeddings.weight.data.mean(
                    dim=0, keepdim=True
                )

            self.embeddings.word_embeddings = new_embeddings
            return self.embeddings
        raise AttributeError("Cannot resize token embeddings - embeddings structure not recognized")
