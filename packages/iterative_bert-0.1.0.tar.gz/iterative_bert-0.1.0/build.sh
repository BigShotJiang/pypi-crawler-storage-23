#!/usr/bin/env bash
# Build the iterative-bert inference-only package for PyPI.
#
# This script copies only the inference modules from src/tiner into a local
# iterative_bert/ directory, builds the wheel/sdist, and cleans up.
#
# Usage: ./build.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SRC="$REPO_ROOT/src/tiner"

cd "$SCRIPT_DIR"

# Clean previous builds
rm -rf iterative_bert/ dist/ build/

# Stage inference modules
mkdir -p iterative_bert

INFERENCE_MODULES=(
  iterative_bert.py
  modern_bert.py
  rope.py
  embeddings.py
  layers.py
  flash_attention.py
  initialization.py
  bert_padding.py
  attention.py
)

for mod in "${INFERENCE_MODULES[@]}"; do
  if [ -f "$SRC/$mod" ]; then
    dest="iterative_bert/$mod"
    if [ "$mod" = "iterative_bert.py" ]; then
      dest="iterative_bert/model.py"
    fi
    cp "$SRC/$mod" "$dest"
  else
    echo "Warning: $SRC/$mod not found, skipping"
  fi
done

# Generate package __init__.py from staged modules (uses package __version__)
SOURCE_INIT="$SCRIPT_DIR/__init__.py"
INIT_VERSION=$(grep '^__version__' "$SOURCE_INIT" | sed 's/__version__ = "\(.*\)"/\1/')
MODULE_LIST=$(printf "%s\n" "${INFERENCE_MODULES[@]}")
export SCRIPT_DIR INIT_VERSION MODULE_LIST
python - <<'PY'
import ast
import os
from pathlib import Path

script_dir = Path(os.environ["SCRIPT_DIR"])
staged_dir = script_dir / "iterative_bert"
source_init = script_dir / "__init__.py"
version = os.environ["INIT_VERSION"]
module_list = os.environ["MODULE_LIST"].splitlines()

def read_docstring(path: Path) -> str:
    tree = ast.parse(path.read_text())
    doc = ast.get_docstring(tree) or ""
    return doc

def read_all(path: Path) -> list[str]:
    tree = ast.parse(path.read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, (ast.List, ast.Tuple)):
                        values = []
                        for elt in node.value.elts:
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                values.append(elt.value)
                            else:
                                raise SystemExit(f"{path.name}: __all__ must be a list/tuple of strings")
                        return values
                    raise SystemExit(f"{path.name}: __all__ must be a list or tuple")
    raise SystemExit(f"{path.name}: missing __all__")

docstring = read_docstring(source_init)

modules = []
for mod in module_list:
    if mod == "iterative_bert.py":
        mod_path = staged_dir / "model.py"
        mod_name = "model"
    else:
        mod_path = staged_dir / mod
        mod_name = Path(mod).stem
    if not mod_path.exists():
        raise SystemExit(f"Missing staged module: {mod_path}")
    modules.append((mod_name, mod_path))

init_lines = []
if docstring:
    init_lines.append('"""' + docstring + '"""')
    init_lines.append("")
init_lines.append(f'__version__ = "{version}"')
init_lines.append("")

all_names = []
for mod_name, mod_path in modules:
    names = read_all(mod_path)
    if names:
        init_lines.append(f"from .{mod_name} import {', '.join(names)}")
        all_names.extend(names)

init_lines.append("")
init_lines.append("__all__ = [")
init_lines.extend([f'    "{name}",' for name in all_names])
init_lines.append('    "__version__",')
init_lines.append("]")
init_lines.append("")

(staged_dir / "__init__.py").write_text("\n".join(init_lines))
PY

echo "Staged ${#INFERENCE_MODULES[@]} modules + __init__.py into iterative_bert/"

# Version consistency check
PYPROJECT_VERSION=$(grep '^version' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
INIT_VERSION=$(grep '^__version__' iterative_bert/__init__.py | sed 's/__version__ = "\(.*\)"/\1/')
if [ "$PYPROJECT_VERSION" != "$INIT_VERSION" ]; then
  echo "ERROR: Version mismatch! pyproject.toml=$PYPROJECT_VERSION, __init__.py=$INIT_VERSION"
  exit 1
fi
echo "Version: $PYPROJECT_VERSION"

# Build
uv build --no-sources

echo ""
echo "Build complete. Artifacts in dist/:"
ls -lh dist/

# Verify wheel contents
echo ""
echo "Wheel contents:"
unzip -l dist/iterative_bert-*.whl | grep "\.py$"

# Check that training code is NOT included
echo ""
echo "Checking for excluded training code..."
if unzip -l dist/iterative_bert-*.whl | grep -qE "(trainer|datasets|prodigy|kernels|hub/|tokenizers/|agent\.py|main\.py|utils/|config\.py|losses\.py)"; then
  echo "ERROR: Training code found in wheel!"
  exit 1
else
  echo "OK: No training code in wheel."
fi

# Clean up staged files
rm -rf iterative_bert/

echo ""
echo "Done. Upload with: uv publish dist/*"
