"""Debrief: generates BRIEF.md summaries for Python projects."""
