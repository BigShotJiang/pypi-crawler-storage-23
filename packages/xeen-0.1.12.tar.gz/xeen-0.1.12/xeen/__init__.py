"""xeen - Screenshot capture, edit, crop, publish. One command."""

__version__ = "0.1.12"
