Add Department to Projects and task to corresponding tree, search and
form views.
