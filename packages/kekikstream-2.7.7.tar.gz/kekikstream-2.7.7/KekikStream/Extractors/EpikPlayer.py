# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class EpikPlayer(BePlayerExtractor):
    name     = "EpikPlayer"
    main_url = "https://epikplayer.xyz"
