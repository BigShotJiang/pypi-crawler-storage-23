# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import NonceDecryptExtractor

class Videostr(NonceDecryptExtractor):
    name     = "Videostr"
    main_url = "https://videostr.net"
    key_name = "vidstr"
