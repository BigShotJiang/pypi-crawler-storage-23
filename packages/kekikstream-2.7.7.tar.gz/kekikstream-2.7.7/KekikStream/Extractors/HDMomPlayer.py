# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class HDMomPlayer(BePlayerExtractor):
    name     = "HDMomPlayer"
    main_url = "https://hdmomplayer.com"
