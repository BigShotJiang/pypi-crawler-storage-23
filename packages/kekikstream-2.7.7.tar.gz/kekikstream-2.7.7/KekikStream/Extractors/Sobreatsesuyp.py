# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import PlaylistAPIExtractor

class Sobreatsesuyp(PlaylistAPIExtractor):
    name     = "Sobreatsesuyp"
    main_url = "https://sobreatsesuyp.com"
