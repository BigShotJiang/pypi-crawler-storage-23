# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import PlaylistAPIExtractor

class TRsTX(PlaylistAPIExtractor):
    name     = "TRsTX"
    main_url = "https://trstx.org"
