# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import SecuredLinkExtractor

class HDLoad(SecuredLinkExtractor):
    name     = "HDLoad"
    main_url = "https://hdload.site"
