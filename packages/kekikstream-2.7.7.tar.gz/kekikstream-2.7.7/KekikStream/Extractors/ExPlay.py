# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import VideoPlayerExtractor

class ExPlay(VideoPlayerExtractor):
    name        = "ExPlay"
    main_url    = "https://explay.store"
    strip_query = True
