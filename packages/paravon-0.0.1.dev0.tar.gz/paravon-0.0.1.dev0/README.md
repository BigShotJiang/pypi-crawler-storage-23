# Paravon

Paravon is a leaderless, peer‑to‑peer distributed database that blends strong per‑key consistency with global,
deterministic convergence. Built for resilience, simplicity, and high performance across unreliable networks.
