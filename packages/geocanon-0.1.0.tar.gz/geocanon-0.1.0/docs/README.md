# GeoCanon Documentation

## Modules

- [Jurisdictions](jurisdictions.md) — Country registry, forms, and middleware
- [Dial Codes](dial-codes.md) — International dial codes and phone validation
- [Flags](flags.md) — Country flag CSS class mapping
- [Timezones](timezones.md) — Jurisdiction-aware local time
- [Languages](languages.md) — Language choices and jurisdiction mapping
- [Duration](duration.md) — i18n-aware duration formatting
- [Holidays](holidays.md) — Public holiday detection
- [Settings](settings.md) — Configuration reference

## Quick Links

- [PyPI](https://pypi.org/project/GeoCanon/)
- [GitHub](https://github.com/Tunet-xyz/geo_canon)
- [Changelog](https://github.com/Tunet-xyz/geo_canon/blob/main/CHANGELOG.md)
