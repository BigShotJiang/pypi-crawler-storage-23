```{include} ../README.md
```

```{toctree}
---
hidden:
---

Home <self>
Package guide <_apidoc/typespecs>
```
