from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models import FilterEntity, BattleReport, KillCompensation, CharMailParse
from eveuniverse.models import EveEntity
from allianceauth.framework.api.user import get_main_character_from_user
from utils.hosting import is_installed


logger = get_extension_logger(__name__)


class DashboardView(LoginRequiredMixin, PermissionRequiredMixin,TemplateView): 
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        character = get_main_character_from_user(self.request.user)
        
        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            match f.entity_type:
                case FilterEntity.ALLIANCE:
                    entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
                case FilterEntity.CORPORATION:
                    entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
                case FilterEntity.CHARACTER:
                    entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
                case _:
                    entry_icon = ''
            
            try:
                entry = EveEntity.objects.get(id=f.entity_id)
                
                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': entry.name,
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': entry.name,
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        match filter:
            case 'rejected':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
                context['listTitle'] = 'Отмененные'
            case 'accepted':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
                context['listTitle'] = 'Выполненные'
            case 'all':
                kills = KillCompensation.objects.all()
                context['listTitle'] = 'Все'
            case _:
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = 'Текущие'    
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["killmails"] = kills.order_by('status', 'timestamp','-loss_value').all()
        context["mailparser"] = CharMailParse.objects.get(character_id=character.character_id) if character and CharMailParse.objects.filter(character_id = character.character_id).exists() else None
        context["parse_check"] = 'checked' if context['mailparser'] is not None else ''
        context["character_id"] = character.character_id
        context["show_api"] = is_installed('rest_framework')
        
        return context


class BattleReportsView(LoginRequiredMixin,PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["reports"] = BattleReport.objects.all()
        context["form"] = AddBrForm()
        context["show_api"] = is_installed('rest_framework')
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})
    
dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()