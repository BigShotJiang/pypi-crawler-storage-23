use anyhow::{Context, Result};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use crate::config::Config;
use crate::download::{download_uv, get_uv_cache_dir, uv_exists};
use crate::embed::{extract_embedded_archive, has_embedded_archive, read_metadata};
use crate::platform::Platform;

/// Find uv binary in the following order:
/// 1. Same directory as ux binary (bundled mode)
/// 2. Cache directory (downloaded mode)
pub fn find_uv(platform: &Platform) -> Option<PathBuf> {
    let binary_name = platform.uv_binary_name();

    // 1. Check same directory as ux binary
    if let Ok(exe_path) = std::env::current_exe()
        && let Some(exe_dir) = exe_path.parent()
    {
        let bundled_uv = exe_dir.join(binary_name);
        if uv_exists(&bundled_uv) {
            return Some(bundled_uv);
        }
    }

    // 2. Check cache directory
    if let Ok(cache_dir) = get_uv_cache_dir() {
        let cached_uv = cache_dir.join(binary_name);
        if uv_exists(&cached_uv) {
            return Some(cached_uv);
        }
    }

    None
}

/// Ensure uv is available, downloading if necessary
pub async fn ensure_uv(platform: &Platform, version: &str) -> Result<PathBuf> {
    // First, try to find existing uv
    if let Some(uv_path) = find_uv(platform) {
        return Ok(uv_path);
    }

    // Download uv to cache directory
    let cache_dir = get_uv_cache_dir()?;
    download_uv(platform, version, &cache_dir).await
}

/// Run application from embedded archive (bundled binary mode)
pub fn run_embedded(args: &[String]) -> Result<i32> {
    // Extract embedded archive
    let extracted_dir = extract_embedded_archive()?;

    // Read metadata
    let metadata = read_metadata(&extracted_dir)?;

    // Find uv in extracted directory
    let uv_path = extracted_dir.join("uv");
    if !uv_path.exists() {
        return Err(anyhow::anyhow!("uv binary not found in bundle"));
    }

    println!("Running {} ...", metadata.entry_point);

    // Build the command, switching strategy based on offline mode.
    let status = if metadata.offline {
        run_offline(&extracted_dir, &metadata, args)?
    } else {
        // Online mode: delegate to uv run as before.
        let mut cmd = Command::new(&uv_path);
        cmd.arg("run")
            .arg("--project")
            .arg(&extracted_dir)
            .arg(&metadata.entry_point);
        for arg in args {
            cmd.arg(arg);
        }
        cmd.stdin(Stdio::inherit())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit())
            .status()
            .with_context(|| format!("Failed to execute: {}", uv_path.display()))?
    };

    Ok(status.code().unwrap_or(1))
}

/// Run the application using the bundled Python + pre-downloaded wheels.
///
/// Strategy (avoids uv lockfile resolution entirely):
///   1. Create a venv from the bundled Python interpreter (once, cached).
///   2. Install packages from bundled wheels via pip (once, cached).
///   3. Run the entry point using `entry_module` (+ extracted_dir on sys.path)
///      or fall back to the installed console script.
fn run_offline(
    extracted_dir: &Path,
    metadata: &crate::embed::BundleMetadata,
    args: &[String],
) -> Result<std::process::ExitStatus> {
    #[cfg(windows)]
    let python_bin = extracted_dir.join("python").join("python.exe");
    #[cfg(not(windows))]
    let python_bin = extracted_dir.join("python").join("bin").join("python3");

    if !python_bin.exists() {
        return Err(anyhow::anyhow!(
            "Bundled Python not found at {}",
            python_bin.display()
        ));
    }

    let wheels_dir = extracted_dir.join("wheels");
    let venv_dir = extracted_dir.join(".venv");

    #[cfg(windows)]
    let venv_python = venv_dir.join("Scripts").join("python.exe");
    #[cfg(not(windows))]
    let venv_python = venv_dir.join("bin").join("python3");

    // --- First-run setup (idempotent: guarded by venv_python existence) ---
    if !venv_python.exists() {
        println!("Setting up offline environment...");

        // 1. Create a virtual environment using the bundled Python
        let status = Command::new(&python_bin)
            .args(["-m", "venv"])
            .arg(&venv_dir)
            .status()
            .with_context(|| "Failed to create virtual environment")?;
        if !status.success() {
            return Err(anyhow::anyhow!("Failed to create virtual environment"));
        }

        // 2. Install production dependencies from bundled wheels
        let requirements_path = wheels_dir.join("requirements.txt");
        if requirements_path.exists() {
            println!("Installing packages from bundled wheels...");
            let status = Command::new(&venv_python)
                .args([
                    "-m",
                    "pip",
                    "install",
                    "--no-index",
                    "--find-links",
                    wheels_dir.to_str().unwrap(),
                    "--no-deps",
                    "-r",
                    requirements_path.to_str().unwrap(),
                ])
                .status()
                .with_context(|| "Failed to install packages from bundled wheels")?;
            if !status.success() {
                return Err(anyhow::anyhow!(
                    "Package installation failed. \
                     Check that all wheels are present in the bundle."
                ));
            }
        }
    }

    // --- Run the application ---
    //
    // Prefer entry_module ("pkg.module:func") for direct invocation without
    // having to install the project itself — the source is already on sys.path
    // via the extracted directory.
    //
    // Fall back to a console script installed in the venv (requires the project
    // to be installed as a wheel, so this path is mainly for compatibility).
    let mut cmd = if !metadata.entry_module.is_empty() {
        let parts: Vec<&str> = metadata.entry_module.splitn(2, ':').collect();
        let module = parts[0];
        let func = if parts.len() > 1 { parts[1] } else { "main" };

        let dir_str = extracted_dir.to_str().unwrap_or("").replace('\'', "\\'");
        let code = format!(
            "import sys; sys.path.insert(0, '{d}'); from {m} import {f}; {f}()",
            d = dir_str,
            m = module,
            f = func
        );

        let mut c = Command::new(&venv_python);
        c.arg("-c").arg(code);
        c
    } else {
        #[cfg(windows)]
        let entry_script = venv_dir.join("Scripts").join(&metadata.entry_point);
        #[cfg(not(windows))]
        let entry_script = venv_dir.join("bin").join(&metadata.entry_point);

        Command::new(entry_script)
    };

    for arg in args {
        cmd.arg(arg);
    }

    cmd.stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()
        .with_context(|| "Failed to execute application")
}

/// Run the application using uv (development mode)
pub async fn run_app(project_dir: &Path, args: &[String]) -> Result<i32> {
    let platform = Platform::current()?;
    let config = Config::load(project_dir)?;

    println!("Running {} ...", config.entry_point);

    // Ensure uv is available
    let uv_path = ensure_uv(&platform, &config.uv_version).await?;

    // Build command: uv run --project <dir> <entry_point> [args...]
    let mut cmd = Command::new(&uv_path);
    cmd.arg("run")
        .arg("--project")
        .arg(project_dir)
        .arg(&config.entry_point);

    // Add user arguments
    for arg in args {
        cmd.arg(arg);
    }

    // Inherit stdio
    cmd.stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit());

    // Run the command
    let status = cmd
        .status()
        .with_context(|| format!("Failed to execute: {}", uv_path.display()))?;

    Ok(status.code().unwrap_or(1))
}

/// Check if running as a bundled binary
pub fn is_bundled() -> bool {
    has_embedded_archive().unwrap_or(false)
}
