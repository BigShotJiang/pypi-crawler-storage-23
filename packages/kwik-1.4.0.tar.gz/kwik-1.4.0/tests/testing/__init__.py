"""Tests for the kwik.testing module."""
