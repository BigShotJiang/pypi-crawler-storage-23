"""Pydantic models for database tool inputs/outputs."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from namespaces.base.models import BaseRequest, BaseResponse
from namespaces.database.constants import (
    DEFAULT_SCHEMA_SEARCH_LIMIT,
    MAX_SCHEMA_SEARCH_LIMIT,
    MIN_SCHEMA_SEARCH_LIMIT,
)


class DatabaseSchemaSearchRequest(BaseRequest):
    """Request to search database schema."""

    query: str = Field(..., description="Natural language query for schema search.")
    database_id: str = Field(
        ...,
        description="The database_id as shown in the DATABASE CONFIGURATIONS context. Case-insensitive.",
    )
    limit: int = Field(
        DEFAULT_SCHEMA_SEARCH_LIMIT,
        description=f"Max number of tables to return. Default is {DEFAULT_SCHEMA_SEARCH_LIMIT}.",
        ge=MIN_SCHEMA_SEARCH_LIMIT,
        le=MAX_SCHEMA_SEARCH_LIMIT,
    )
    schemas: Optional[list[str]] = Field(
        None,
        description="Filter to specific database schemas (e.g., ['public', 'billing']). By default, all schemas are included.",
    )
    catalogs: Optional[list[str]] = Field(
        None,
        description="Filter to specific catalogs (Databricks only).",
    )
    force_reindex: bool = Field(
        False,
        description="Force re-extraction of schema from database. Only use if schema has changed. Takes 5-10 seconds.",
    )


class DatabaseSchemaSearchResponse(BaseResponse):
    """Response from schema search."""

    database_id: str = Field(..., description="Database id used for the query.")


class DatabaseListResponse(BaseModel):
    """Response listing available databases."""

    databases: list[str] = Field(
        ..., description="Available database ids derived from DATABASE_<ID>_URL."
    )
    count: int = Field(..., description="Number of available databases.")
