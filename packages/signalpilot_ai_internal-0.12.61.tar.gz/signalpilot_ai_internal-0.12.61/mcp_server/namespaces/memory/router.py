"""FastAPI router for memory operations."""

from fastapi import APIRouter

from namespaces.memory.models import (
    ChatSearchRequest,
    ChatSearchResponse,
    MemoryUpdateRequest,
    MemoryUpdateResponse,
)
from namespaces.memory.service import get_memory_service

router = APIRouter()


@router.post(
    "/update",
    name="update",
    operation_id="memory-update",
    summary="Update project memory file.",
    description="Read, append, or replace content in the SIGNALPILOT.md project memory file.",
)
async def update(request: MemoryUpdateRequest) -> MemoryUpdateResponse:
    """Update the project memory file."""
    service = get_memory_service()
    return await service.update(request)


@router.post(
    "/chat_search",
    name="chat_search",
    operation_id="memory-chat_search",
    summary="Search chat history.",
    description="Search through past SignalPilot chat conversations for keywords, code snippets, or previous discussions.",
)
async def chat_search(request: ChatSearchRequest) -> ChatSearchResponse:
    """Search through chat history files."""
    service = get_memory_service()
    return await service.chat_search(request)
