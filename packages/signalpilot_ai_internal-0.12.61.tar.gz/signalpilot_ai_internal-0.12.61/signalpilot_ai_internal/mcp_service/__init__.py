"""MCP Service Package - Manages connections to Model Context Protocol servers."""
