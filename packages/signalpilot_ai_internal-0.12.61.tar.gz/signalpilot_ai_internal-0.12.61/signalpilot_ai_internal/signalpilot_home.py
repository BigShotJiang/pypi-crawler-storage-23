"""
SignalPilotHomeManager - Centralized configuration management for connect/ folder

The connect/ folder is stored in the OS-specific cache directory:
- macOS: ~/Library/Caches/SignalPilotAI/connect/
- Windows: %LOCALAPPDATA%/SignalPilotAI/Cache/connect/
- Linux: ~/.cache/signalpilot-ai-internal/connect/

Provides unified access to:
- mcp.json - MCP server configurations
- db.toml - Database configurations
- .env - OAuth tokens
"""

import json
import logging
import os
import platform
import shutil
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

# TOML reading - tomllib is built-in for Python 3.11+
if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

logger = logging.getLogger(__name__)


def _snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    parts = name.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


def _normalize_config_keys(config: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize snake_case keys to camelCase for consistency."""
    return {_snake_to_camel(k): v for k, v in config.items()}


def _get_cache_base_directory() -> Path:
    """Get the OS-specific cache directory for SignalPilotAI."""
    system = platform.system().lower()

    try:
        if system == "windows":
            appdata_local = os.environ.get('LOCALAPPDATA')
            if appdata_local:
                return Path(appdata_local) / "SignalPilotAI" / "Cache"
            appdata_roaming = os.environ.get('APPDATA')
            if appdata_roaming:
                return Path(appdata_roaming) / "SignalPilotAI" / "Cache"
            userprofile = os.environ.get('USERPROFILE')
            if userprofile:
                return Path(userprofile) / ".signalpilot-cache"

        elif system == "darwin":  # macOS
            return Path.home() / "Library" / "Caches" / "SignalPilotAI"

        else:  # Linux and other Unix-like
            cache_home = os.environ.get('XDG_CACHE_HOME')
            if cache_home:
                return Path(cache_home) / "signalpilot-ai-internal"
            return Path.home() / ".cache" / "signalpilot-ai-internal"

    except Exception as e:
        logger.error(f"Error determining cache directory: {e}")

    # Fallback
    return Path(tempfile.gettempdir()) / f"signalpilot-ai-internal-{os.getuid() if hasattr(os, 'getuid') else 'user'}"


def _format_toml_value(value: Any) -> str:
    """Format a Python value as a TOML value string."""
    if value is None:
        return '""'
    elif isinstance(value, bool):
        return "true" if value else "false"
    elif isinstance(value, int):
        return str(value)
    elif isinstance(value, float):
        return str(value)
    elif isinstance(value, str):
        # Check if multiline
        if '\n' in value:
            # Use multiline basic string
            escaped = value.replace('\\', '\\\\').replace('"""', '\\"\\"\\"')
            return f'"""{escaped}"""'
        else:
            # Use basic string with escaping
            escaped = value.replace('\\', '\\\\').replace('"', '\\"')
            return f'"{escaped}"'
    elif isinstance(value, list):
        items = [_format_toml_value(v) for v in value]
        return f"[{', '.join(items)}]"
    else:
        # Fallback to string representation
        return f'"{str(value)}"'


def _write_toml(data: Dict[str, Any]) -> str:
    """
    Simple TOML writer for our specific use case.
    Handles: [defaults], [defaults.type], [[type]] arrays of tables
    """
    lines = []

    # Write defaults section first if present
    defaults = data.get("defaults", {})
    if defaults:
        lines.append("[defaults]")
        for key, value in defaults.items():
            if isinstance(value, dict):
                # Will be written as [defaults.key] later
                continue
            lines.append(f"{key} = {_format_toml_value(value)}")
        lines.append("")

        # Write nested defaults like [defaults.snowflake]
        for key, value in defaults.items():
            if isinstance(value, dict):
                lines.append(f"[defaults.{key}]")
                for k, v in value.items():
                    lines.append(f"{k} = {_format_toml_value(v)}")
                lines.append("")

    # Write array of tables for each database type
    for db_type in ["snowflake", "postgres", "mysql", "databricks"]:
        if db_type in data and data[db_type]:
            for entry in data[db_type]:
                lines.append(f"[[{db_type}]]")
                for key, value in entry.items():
                    if not isinstance(value, (dict, list)) or isinstance(value, list):
                        lines.append(f"{key} = {_format_toml_value(value)}")
                lines.append("")

    return "\n".join(lines)


class SignalPilotHomeManager:
    """
    Centralized manager for SignalPilot configuration files.
    All configs stored in the OS-specific cache directory under connect/
    (e.g., ~/Library/Caches/SignalPilotAI/connect/ on macOS)
    """

    _instance = None
    _lock = threading.Lock()

    # Directory structure
    CONNECT_DIR_NAME = "connect"

    # File names
    MCP_CONFIG_FILE = "mcp.json"
    DB_CONFIG_FILE = "db.toml"
    ENV_FILE = ".env"

    def __init__(self):
        self._base_path: Optional[Path] = None
        self._connect_path: Optional[Path] = None
        self._file_lock = threading.RLock()
        self._setup_directories()

    @classmethod
    def get_instance(cls) -> 'SignalPilotHomeManager':
        """Get singleton instance (thread-safe)."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = SignalPilotHomeManager()
        return cls._instance

    def _setup_directories(self):
        """Create connect/ directory in the OS-specific cache location."""
        self._base_path = _get_cache_base_directory()
        self._connect_path = self._base_path / self.CONNECT_DIR_NAME

        try:
            self._connect_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"[SignalPilotHomeManager] Using directory: {self._connect_path}")
        except Exception as e:
            logger.error(f"[SignalPilotHomeManager] Error creating directory: {e}")

    # ==================== Path Accessors ====================

    @property
    def base_path(self) -> Path:
        """Get the cache base directory (e.g., ~/Library/Caches/SignalPilotAI on macOS)"""
        return self._base_path

    @property
    def connect_path(self) -> Path:
        """Get the connect directory (e.g., ~/Library/Caches/SignalPilotAI/connect on macOS)"""
        return self._connect_path

    @property
    def mcp_config_path(self) -> Path:
        """Get path to mcp.json"""
        return self._connect_path / self.MCP_CONFIG_FILE

    @property
    def db_config_path(self) -> Path:
        """Get path to db.toml"""
        return self._connect_path / self.DB_CONFIG_FILE

    @property
    def env_path(self) -> Path:
        """Get path to .env"""
        return self._connect_path / self.ENV_FILE

    # ==================== Safe File Operations ====================

    def _safe_write_json(self, file_path: Path, data: Any, max_retries: int = 3) -> bool:
        """Safely write JSON data with atomic operations."""
        with self._file_lock:
            if not file_path.parent.exists():
                try:
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    logger.error(f"Failed to create directory {file_path.parent}: {e}")
                    return False

            # Log what we're about to write
            try:
                data_preview = json.dumps(data, indent=2)[:500]
                logger.debug(f"[SignalPilotHome] _safe_write_json: writing to {file_path}, data preview: {data_preview}")
            except Exception:
                logger.debug(f"[SignalPilotHome] _safe_write_json: writing to {file_path}")

            for attempt in range(max_retries):
                temp_path = file_path.with_suffix(f".tmp.{uuid.uuid4().hex[:8]}")

                try:
                    # Write to temporary file first
                    with open(temp_path, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)

                    # Verify the written data
                    with open(temp_path, 'r', encoding='utf-8') as f:
                        verified_data = json.load(f)
                    logger.debug(f"[SignalPilotHome] _safe_write_json: verified temp file OK, keys: {list(verified_data.keys()) if isinstance(verified_data, dict) else 'not-dict'}")

                    # Atomic move to final location
                    # Use os.replace() which is atomic on both Windows and POSIX
                    try:
                        os.replace(str(temp_path), str(file_path))
                    except OSError:
                        # Fallback for edge cases where os.replace fails
                        if platform.system().lower() == "windows":
                            if file_path.exists():
                                file_path.unlink()
                        shutil.move(str(temp_path), str(file_path))

                    # Verify final file after move
                    with open(file_path, 'r', encoding='utf-8') as f:
                        final_data = json.load(f)
                    logger.info(f"[SignalPilotHome] _safe_write_json: successfully wrote {file_path}, final keys: {list(final_data.keys()) if isinstance(final_data, dict) else 'not-dict'}")
                    return True

                except Exception as e:
                    logger.error(f"Write attempt {attempt + 1} failed for {file_path}: {e}")

                    try:
                        if temp_path.exists():
                            temp_path.unlink()
                    except:
                        pass

                    if attempt < max_retries - 1:
                        time.sleep(0.1 * (attempt + 1))

            logger.error(f"[SignalPilotHome] _safe_write_json: all {max_retries} attempts failed for {file_path}")
            return False

    def _safe_read_json(self, file_path: Path, default: Any = None) -> Any:
        """Safely read JSON data."""
        if not file_path.exists():
            logger.debug(f"[SignalPilotHome] _safe_read_json: file does not exist: {file_path}, returning default")
            return default

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.debug(f"[SignalPilotHome] _safe_read_json: read {file_path}, keys: {list(data.keys()) if isinstance(data, dict) else 'not-dict'}")
            return data
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            return default

    def _safe_write_toml(self, file_path: Path, data: Dict[str, Any], max_retries: int = 3) -> bool:
        """Safely write TOML data with atomic operations."""
        with self._file_lock:
            if not file_path.parent.exists():
                try:
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    logger.error(f"Failed to create directory {file_path.parent}: {e}")
                    return False

            for attempt in range(max_retries):
                temp_path = file_path.with_suffix(f".tmp.{uuid.uuid4().hex[:8]}")

                try:
                    # Format TOML content
                    toml_content = _write_toml(data)

                    # Write to temporary file first
                    with open(temp_path, 'w', encoding='utf-8') as f:
                        f.write(toml_content)

                    # Verify the written data can be read back
                    with open(temp_path, 'rb') as f:
                        tomllib.load(f)

                    # Atomic move to final location
                    if platform.system().lower() == "windows":
                        if file_path.exists():
                            file_path.unlink()

                    shutil.move(str(temp_path), str(file_path))
                    return True

                except Exception as e:
                    logger.error(f"TOML write attempt {attempt + 1} failed for {file_path}: {e}")

                    try:
                        if temp_path.exists():
                            temp_path.unlink()
                    except:
                        pass

                    if attempt < max_retries - 1:
                        time.sleep(0.1 * (attempt + 1))

            return False

    def _safe_read_toml(self, file_path: Path, default: Any = None) -> Any:
        """Safely read TOML data."""
        if not file_path.exists():
            return default

        try:
            with open(file_path, 'rb') as f:
                return tomllib.load(f)
        except Exception as e:
            logger.error(f"Failed to read TOML {file_path}: {e}")
            return default

    # ==================== MCP Config (JSON) ====================

    def read_mcp_config(self) -> Dict[str, Any]:
        """Read mcp.json configuration."""
        return self._safe_read_json(self.mcp_config_path, {"mcpServers": {}})

    def write_mcp_config(self, config: Dict[str, Any]) -> bool:
        """Write mcp.json configuration."""
        return self._safe_write_json(self.mcp_config_path, config)

    def get_mcp_servers(self) -> Dict[str, Any]:
        """Get all MCP servers from config."""
        config = self.read_mcp_config()
        return config.get("mcpServers", {})

    def set_mcp_server(self, server_id: str, server_config: Dict[str, Any]) -> bool:
        """Set/update a single MCP server."""
        config = self.read_mcp_config()
        if "mcpServers" not in config:
            config["mcpServers"] = {}
        logger.debug(f"[SignalPilotHome] set_mcp_server: setting server '{server_id}' with keys: {list(server_config.keys())}")
        config["mcpServers"][server_id] = server_config
        result = self.write_mcp_config(config)
        logger.debug(f"[SignalPilotHome] set_mcp_server: write result={result}, total servers: {len(config.get('mcpServers', {}))}")
        return result

    def remove_mcp_server(self, server_id: str) -> bool:
        """Remove an MCP server."""
        config = self.read_mcp_config()
        servers = config.get("mcpServers", {})
        if server_id in servers:
            del servers[server_id]
            config["mcpServers"] = servers
            return self.write_mcp_config(config)
        return True

    # ==================== DB Config (TOML) ====================

    def read_db_config(self) -> Dict[str, Any]:
        """Read db.toml configuration."""
        return self._safe_read_toml(self.db_config_path, {"defaults": {}})

    def write_db_config(self, config: Dict[str, Any]) -> bool:
        """Write db.toml configuration."""
        return self._safe_write_toml(self.db_config_path, config)

    def get_database_configs(self) -> List[Dict[str, Any]]:
        """Get all database configurations from db.toml."""
        config = self.read_db_config()
        defaults = config.get("defaults", {})

        databases = []
        for db_type in ["snowflake", "postgres", "mysql", "databricks"]:
            if db_type in config:
                type_defaults = defaults.get(db_type, {})
                global_defaults = {k: v for k, v in defaults.items()
                                   if not isinstance(v, dict)}

                for db_config in config[db_type]:
                    # Merge: global defaults < type defaults < specific config
                    merged = {**global_defaults, **type_defaults, **db_config}
                    merged["type"] = db_type
                    # Normalize snake_case keys to camelCase
                    databases.append(_normalize_config_keys(merged))

        return databases

    def get_database_config(self, db_type: str, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific database configuration."""
        configs = self.get_database_configs()
        for config in configs:
            if config.get("type") == db_type and config.get("name") == name:
                return config
        return None

    def add_database_config(self, db_type: str, config: Dict[str, Any]) -> bool:
        """Add a new database configuration to db.toml."""
        full_config = self.read_db_config()

        if db_type not in full_config:
            full_config[db_type] = []

        # Check for duplicate name
        for existing in full_config[db_type]:
            if existing.get("name") == config.get("name"):
                logger.error(f"Database config with name '{config.get('name')}' already exists")
                return False

        full_config[db_type].append(config)
        return self.write_db_config(full_config)

    def update_database_config(self, db_type: str, name: str,
                               updates: Dict[str, Any]) -> bool:
        """Update an existing database configuration."""
        full_config = self.read_db_config()

        if db_type not in full_config:
            return False

        for i, db in enumerate(full_config[db_type]):
            if db.get("name") == name:
                full_config[db_type][i] = {**db, **updates}
                return self.write_db_config(full_config)

        return False

    def remove_database_config(self, db_type: str, name: str) -> bool:
        """Remove a database configuration."""
        full_config = self.read_db_config()

        if db_type not in full_config:
            return False

        original_len = len(full_config[db_type])
        full_config[db_type] = [
            db for db in full_config[db_type]
            if db.get("name") != name
        ]

        if len(full_config[db_type]) < original_len:
            return self.write_db_config(full_config)
        return False

    def set_database_defaults(self, defaults: Dict[str, Any]) -> bool:
        """Set global defaults for database configurations."""
        full_config = self.read_db_config()
        full_config["defaults"] = defaults
        return self.write_db_config(full_config)

    def get_database_defaults(self) -> Dict[str, Any]:
        """Get global defaults."""
        config = self.read_db_config()
        return config.get("defaults", {})

    # ==================== OAuth Tokens (.env) ====================

    def read_env(self) -> Dict[str, str]:
        """Read .env file as key-value pairs."""
        if not self.env_path.exists():
            return {}

        env_vars = {}
        try:
            with open(self.env_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, _, value = line.partition('=')
                        # Remove quotes if present
                        value = value.strip()
                        if (value.startswith('"') and value.endswith('"')) or \
                           (value.startswith("'") and value.endswith("'")):
                            value = value[1:-1]
                        env_vars[key.strip()] = value
        except Exception as e:
            logger.error(f"[SignalPilotHomeManager] Error reading .env: {e}")

        return env_vars

    def write_env(self, env_vars: Dict[str, str]) -> bool:
        """Write .env file from key-value pairs."""
        with self._file_lock:
            try:
                temp_path = self.env_path.with_suffix(f".tmp.{uuid.uuid4().hex[:8]}")

                with open(temp_path, 'w', encoding='utf-8') as f:
                    f.write("# SignalPilot OAuth Tokens\n")
                    f.write("# Auto-generated - do not edit manually\n\n")

                    for key in sorted(env_vars.keys()):
                        value = env_vars[key]
                        # Quote values containing spaces, quotes, or special chars
                        if any(c in value for c in ' "\'\n\r\t#'):
                            # Escape existing quotes and wrap in quotes
                            value = value.replace('\\', '\\\\').replace('"', '\\"')
                            value = f'"{value}"'
                        f.write(f"{key}={value}\n")

                # Atomic move
                if platform.system().lower() == "windows":
                    if self.env_path.exists():
                        self.env_path.unlink()

                shutil.move(str(temp_path), str(self.env_path))
                return True

            except Exception as e:
                logger.error(f"[SignalPilotHomeManager] Error writing .env: {e}")
                try:
                    if temp_path.exists():
                        temp_path.unlink()
                except:
                    pass
                return False

    def _get_env_prefix(self, server_id: str) -> str:
        """Generate env variable prefix for a server ID."""
        # Convert server-id to OAUTH_SERVER_ID_
        safe_id = server_id.upper().replace('-', '_').replace('.', '_')
        return f"OAUTH_{safe_id}_"

    def get_oauth_tokens(self, server_id: str) -> Optional[Dict[str, str]]:
        """Get OAuth tokens for a specific MCP server."""
        env_vars = self.read_env()
        prefix = self._get_env_prefix(server_id)

        tokens = {}
        for key, value in env_vars.items():
            if key.startswith(prefix):
                # Remove prefix to get original token name
                token_name = key[len(prefix):]
                tokens[token_name] = value

        return tokens if tokens else None

    def set_oauth_tokens(self, server_id: str, tokens: Dict[str, str]) -> bool:
        """Set OAuth tokens for an MCP server."""
        env_vars = self.read_env()
        prefix = self._get_env_prefix(server_id)

        # Remove existing tokens for this server
        env_vars = {k: v for k, v in env_vars.items()
                    if not k.startswith(prefix)}

        # Add new tokens
        for token_name, value in tokens.items():
            env_vars[f"{prefix}{token_name}"] = value

        return self.write_env(env_vars)

    def remove_oauth_tokens(self, server_id: str) -> bool:
        """Remove OAuth tokens for an MCP server."""
        env_vars = self.read_env()
        prefix = self._get_env_prefix(server_id)

        new_env = {k: v for k, v in env_vars.items()
                   if not k.startswith(prefix)}

        if len(new_env) < len(env_vars):
            return self.write_env(new_env)
        return True  # Nothing to remove

    def get_oauth_registry(self) -> Dict[str, str]:
        """Get mapping of server IDs to integration IDs from .env registry."""
        env_vars = self.read_env()
        registry = {}

        for key, value in env_vars.items():
            if key.startswith("OAUTH_REGISTRY_"):
                # OAUTH_REGISTRY_SERVER_ID=integration_id
                server_id = key[15:].lower().replace('_', '-')
                registry[server_id] = value

        return registry

    def set_oauth_registry_entry(self, server_id: str, integration_id: str) -> bool:
        """Add an entry to the OAuth registry."""
        env_vars = self.read_env()
        registry_key = f"OAUTH_REGISTRY_{server_id.upper().replace('-', '_')}"
        env_vars[registry_key] = integration_id
        return self.write_env(env_vars)

    def remove_oauth_registry_entry(self, server_id: str) -> bool:
        """Remove an entry from the OAuth registry."""
        env_vars = self.read_env()
        registry_key = f"OAUTH_REGISTRY_{server_id.upper().replace('-', '_')}"

        if registry_key in env_vars:
            del env_vars[registry_key]
            return self.write_env(env_vars)
        return True

    # ==================== Utility Methods ====================

    def is_available(self) -> bool:
        """Check if the SignalPilotHome directory is available."""
        return self._connect_path is not None and self._connect_path.exists()

    def get_info(self) -> Dict[str, Any]:
        """Get information about the SignalPilotHome setup."""
        info = {
            "available": self.is_available(),
            "base_path": str(self._base_path),
            "connect_path": str(self._connect_path),
            "mcp_config_exists": self.mcp_config_path.exists(),
            "db_config_exists": self.db_config_path.exists(),
            "env_exists": self.env_path.exists(),
        }

        if self.is_available():
            try:
                if self.mcp_config_path.exists():
                    info["mcp_config_size"] = self.mcp_config_path.stat().st_size
                    info["mcp_servers_count"] = len(self.get_mcp_servers())

                if self.db_config_path.exists():
                    info["db_config_size"] = self.db_config_path.stat().st_size
                    info["db_configs_count"] = len(self.get_database_configs())

                if self.env_path.exists():
                    info["env_size"] = self.env_path.stat().st_size
                    info["oauth_registry_count"] = len(self.get_oauth_registry())

            except Exception as e:
                info["error"] = str(e)

        return info


# Global instance accessor
def get_signalpilot_home() -> SignalPilotHomeManager:
    """Get the singleton instance."""
    return SignalPilotHomeManager.get_instance()


class UserRulesManager:
    """
    Manager for user-defined rules (snippets) stored as markdown files.

    Rules are stored in two locations:
    - ~/SignalPilotHome/default-rules/ - System-provided default rules (synced from package)
    - ~/SignalPilotHome/user-rules/ - User-created or customized rules

    Each rule file follows a format:
    ---
    title: Rule Title
    description: Optional description
    default: true/false
    category: core/database/mcp
    active: true/false
    version: "1.0.0"
    alwaysApply: true/false
    applyIntelligently: true/false
    created_at: ISO timestamp
    updated_at: ISO timestamp
    ---

    Rule content goes here...
    """

    _instance = None
    _lock = threading.Lock()

    SIGNALPILOT_HOME_DIR = "SignalPilotHome"
    USER_RULES_DIR = "user-rules"
    DEFAULT_RULES_DIR = "default-rules"
    BUNDLED_RULES_PATH = "default-rules"  # Relative to package

    def __init__(self):
        self._rules_path: Optional[Path] = None
        self._default_rules_path: Optional[Path] = None
        self._file_lock = threading.RLock()
        self._setup_directory()

    @classmethod
    def get_instance(cls) -> 'UserRulesManager':
        """Get singleton instance (thread-safe)."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = UserRulesManager()
        return cls._instance

    def _setup_directory(self):
        """Create user-rules and default-rules directories in ~/SignalPilotHome/."""
        try:
            # Use ~/SignalPilotHome/
            home_dir = Path.home() / self.SIGNALPILOT_HOME_DIR

            # User rules directory
            self._rules_path = home_dir / self.USER_RULES_DIR
            self._rules_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"[UserRulesManager] User rules directory: {self._rules_path}")

            # Default rules directory
            self._default_rules_path = home_dir / self.DEFAULT_RULES_DIR
            self._default_rules_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"[UserRulesManager] Default rules directory: {self._default_rules_path}")

        except Exception as e:
            logger.error(f"[UserRulesManager] Error creating directories: {e}")
            self._rules_path = None
            self._default_rules_path = None

    @property
    def rules_path(self) -> Optional[Path]:
        """Get the user-rules directory path."""
        return self._rules_path

    @property
    def default_rules_path(self) -> Optional[Path]:
        """Get the default-rules directory path."""
        return self._default_rules_path

    def _parse_frontmatter(self, content: str) -> tuple[Dict[str, Any], str]:
        """Parse YAML frontmatter from markdown content."""
        if not content.startswith('---'):
            return {}, content

        parts = content.split('---', 2)
        if len(parts) < 3:
            return {}, content

        frontmatter_str = parts[1].strip()
        body = parts[2].strip()

        # Simple YAML parsing for our specific use case
        frontmatter = {}
        for line in frontmatter_str.split('\n'):
            line = line.strip()
            if ':' in line:
                key, _, value = line.partition(':')
                key = key.strip()
                value = value.strip()
                # Remove quotes if present
                if (value.startswith('"') and value.endswith('"')) or \
                   (value.startswith("'") and value.endswith("'")):
                    value = value[1:-1]
                # Parse boolean values
                if value.lower() == 'true':
                    value = True
                elif value.lower() == 'false':
                    value = False
                frontmatter[key] = value

        return frontmatter, body

    def _determine_mode(self, frontmatter: Dict[str, Any]) -> str:
        """Determine rule mode from frontmatter fields."""
        if frontmatter.get('alwaysApply', False):
            return 'always'
        if frontmatter.get('applyIntelligently', False):
            return 'intelligent'
        return 'manual'

    def _estimate_tokens(self, content: str) -> int:
        """Rough token estimate (4 chars = 1 token)."""
        return len(content) // 4

    def _format_frontmatter(self, metadata: Dict[str, Any]) -> str:
        """Format metadata as YAML frontmatter in Cursor-style format."""
        lines = ['---']
        for key, value in metadata.items():
            # Skip id field - we use filename as identifier
            if key == 'id':
                continue
            if value is not None:
                # Handle boolean values
                if isinstance(value, bool):
                    value = 'true' if value else 'false'
                # Quote strings that contain special characters
                elif isinstance(value, str) and any(c in value for c in ':\n"\''):
                    value = f'"{value}"'
                lines.append(f'{key}: {value}')
        lines.append('---')
        return '\n'.join(lines)

    def _build_frontmatter(self, metadata: Dict[str, Any], body: str) -> str:
        """Build complete markdown content with frontmatter and body."""
        frontmatter = self._format_frontmatter(metadata)
        return f"{frontmatter}\n\n{body}"

    def _sanitize_filename(self, title: str) -> str:
        """Convert title to safe filename."""
        import re
        # Replace spaces with hyphens, remove special characters
        filename = re.sub(r'[^\w\s-]', '', title.lower())
        filename = re.sub(r'[-\s]+', '-', filename).strip('-')
        return filename[:50]  # Limit length

    def _read_rule_file(self, md_file: Path, source: str = 'user') -> Optional[Dict[str, Any]]:
        """Read a single rule file and return its data."""
        try:
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()

            frontmatter, body = self._parse_frontmatter(content)
            filename = md_file.stem

            return {
                'filename': filename,
                'title': frontmatter.get('title', filename),
                'description': frontmatter.get('description', ''),
                'content': body,
                'mode': self._determine_mode(frontmatter),
                'source': source,
                'default': frontmatter.get('default', False) if source == 'default' else False,
                'category': frontmatter.get('category', 'core'),
                'active': frontmatter.get('active', True),
                'version': frontmatter.get('version', '1.0.0'),
                'deactivated': False,  # Will be set later for overridden defaults
                'file_path': str(md_file),
                'created_at': frontmatter.get('created_at', ''),
                'updated_at': frontmatter.get('updated_at', ''),
                'token_count': self._estimate_tokens(body)
            }
        except Exception as e:
            logger.error(f"[UserRulesManager] Error reading {md_file}: {e}")
            return None

    def list_rules(self) -> List[Dict[str, Any]]:
        """List all rules from both user-rules and default-rules directories."""
        rules = []
        user_filenames = set()

        # First, read user rules to know which defaults are overridden
        if self._rules_path and self._rules_path.exists():
            try:
                for md_file in sorted(self._rules_path.glob('*.md')):
                    rule = self._read_rule_file(md_file, source='user')
                    if rule:
                        rules.append(rule)
                        user_filenames.add(rule['filename'])
            except Exception as e:
                logger.error(f"[UserRulesManager] Error listing user rules: {e}")

        # Then, read default rules and mark as deactivated if overridden
        if self._default_rules_path and self._default_rules_path.exists():
            try:
                for md_file in sorted(self._default_rules_path.glob('*.md')):
                    rule = self._read_rule_file(md_file, source='default')
                    if rule:
                        # Mark as deactivated if user has an override
                        rule['deactivated'] = rule['filename'] in user_filenames
                        rule['default'] = True
                        rules.append(rule)
            except Exception as e:
                logger.error(f"[UserRulesManager] Error listing default rules: {e}")

        return rules

    def get_rule(self, filename: str) -> Optional[Dict[str, Any]]:
        """Get a specific rule by filename (without extension).

        Priority: user-rules > default-rules
        """
        # First check user rules
        if self._rules_path:
            user_filepath = self._rules_path / f"{filename}.md"
            if user_filepath.exists():
                return self._read_rule_file(user_filepath, source='user')

        # Then check default rules
        if self._default_rules_path:
            default_filepath = self._default_rules_path / f"{filename}.md"
            if default_filepath.exists():
                rule = self._read_rule_file(default_filepath, source='default')
                if rule:
                    rule['default'] = True
                return rule

        return None

    def create_rule(self, title: str, content: str, description: str = '',
                    mode: str = 'manual') -> Dict[str, Any]:
        """
        Create a new rule as a markdown file.

        Returns dict with 'success' key. On failure, includes 'error' and optionally 'error_code'.
        Error codes: 'DUPLICATE_TITLE', 'NO_RULES_PATH', 'WRITE_ERROR'
        """
        if not self._rules_path:
            logger.error("[UserRulesManager] Rules directory not available")
            return {'success': False, 'error': 'Rules directory not available', 'error_code': 'NO_RULES_PATH'}

        with self._file_lock:
            # Generate filename from title
            filename = self._sanitize_filename(title)
            if not filename:
                filename = f"untitled-{int(time.time())}"

            filepath = self._rules_path / f"{filename}.md"

            # Enforce title uniqueness - return error if file exists
            if filepath.exists():
                logger.error(f"[UserRulesManager] Rule with this title already exists: {title}")
                return {
                    'success': False,
                    'error': 'A rule with this title already exists',
                    'error_code': 'DUPLICATE_TITLE',
                    'existing_filename': filename
                }

            now = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

            # Translate mode to Cursor-style frontmatter fields
            always_apply = mode == 'always'
            apply_intelligently = mode == 'intelligent'

            metadata = {
                'alwaysApply': always_apply,
                'applyIntelligently': apply_intelligently,
                'title': title,
                'description': description,
                'source': 'user',
                'created_at': now,
                'updated_at': now
            }

            frontmatter_str = self._format_frontmatter(metadata)
            full_content = f"{frontmatter_str}\n\n{content}"

            try:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(full_content)

                logger.info(f"[UserRulesManager] Created rule: {filepath}")

                return {
                    'success': True,
                    'rule': {
                        'filename': filename,
                        'title': title,
                        'description': description,
                        'content': content,
                        'mode': mode,
                        'source': 'user',
                        'file_path': str(filepath),
                        'created_at': now,
                        'updated_at': now,
                        'token_count': self._estimate_tokens(content)
                    }
                }
            except Exception as e:
                logger.error(f"[UserRulesManager] Error creating rule: {e}")
                return {'success': False, 'error': str(e), 'error_code': 'WRITE_ERROR'}

    def update_rule(self, filename: str, title: Optional[str] = None,
                    content: Optional[str] = None,
                    description: Optional[str] = None,
                    mode: Optional[str] = None,
                    active: Optional[bool] = None) -> Dict[str, Any]:
        """
        Update an existing rule by filename.

        If updating a default rule, creates a copy in user-rules first.
        If title changes, the file will be renamed to match the new title.
        Returns dict with 'success' key. On success, includes 'rule' and optionally 'previous_filename'.
        Error codes: 'NOT_FOUND', 'DUPLICATE_TITLE', 'NO_RULES_PATH', 'WRITE_ERROR'
        """
        if not self._rules_path:
            return {'success': False, 'error': 'Rules directory not available', 'error_code': 'NO_RULES_PATH'}

        with self._file_lock:
            user_filepath = self._rules_path / f"{filename}.md"
            default_filepath = self._default_rules_path / f"{filename}.md" if self._default_rules_path else None

            # Determine source file
            if user_filepath.exists():
                filepath = user_filepath
                is_default = False
            elif default_filepath and default_filepath.exists():
                # Copy default to user-rules first (copy-on-edit)
                filepath = default_filepath
                is_default = True
                logger.info(f"[UserRulesManager] Copy-on-edit: copying default rule {filename} to user-rules")
            else:
                logger.warning(f"[UserRulesManager] Rule not found: {filename}")
                return {'success': False, 'error': 'Rule not found', 'error_code': 'NOT_FOUND', 'filename': filename}

            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    file_content = f.read()

                frontmatter, body = self._parse_frontmatter(file_content)

                new_filename = filename
                previous_filename = None

                # Handle title change - requires file rename
                if title is not None and title != frontmatter.get('title'):
                    new_filename = self._sanitize_filename(title)
                    new_filepath = self._rules_path / f"{new_filename}.md"

                    # Check uniqueness (excluding current file if it's a user file)
                    if new_filepath.exists() and (is_default or new_filepath != filepath):
                        logger.error(f"[UserRulesManager] Cannot rename: title already exists: {title}")
                        return {
                            'success': False,
                            'error': 'A rule with this title already exists',
                            'error_code': 'DUPLICATE_TITLE',
                            'existing_filename': new_filename
                        }

                    frontmatter['title'] = title
                    previous_filename = filename

                # Update other fields
                if description is not None:
                    frontmatter['description'] = description
                if content is not None:
                    body = content
                if mode is not None:
                    frontmatter['alwaysApply'] = mode == 'always'
                    frontmatter['applyIntelligently'] = mode == 'intelligent'
                if active is not None:
                    frontmatter['active'] = active

                # Mark as user rule (no longer default)
                frontmatter['source'] = 'user'
                if 'default' in frontmatter:
                    del frontmatter['default']

                frontmatter['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

                # Write updated content to user-rules
                new_frontmatter = self._format_frontmatter(frontmatter)
                full_content = f"{new_frontmatter}\n\n{body}"

                final_filepath = self._rules_path / f"{new_filename}.md"
                with open(final_filepath, 'w', encoding='utf-8') as f:
                    f.write(full_content)

                # Delete old user file if renamed (don't delete default files)
                if not is_default and new_filename != filename:
                    user_filepath.unlink()
                    logger.info(f"[UserRulesManager] Renamed rule: {filename} -> {new_filename}")
                else:
                    logger.info(f"[UserRulesManager] Updated rule: {final_filepath}")

                result = {
                    'success': True,
                    'rule': {
                        'filename': new_filename,
                        'title': frontmatter.get('title', ''),
                        'description': frontmatter.get('description', ''),
                        'content': body,
                        'mode': self._determine_mode(frontmatter),
                        'source': 'user',
                        'default': False,
                        'category': frontmatter.get('category', 'core'),
                        'active': frontmatter.get('active', True),
                        'deactivated': False,
                        'file_path': str(final_filepath),
                        'created_at': frontmatter.get('created_at', ''),
                        'updated_at': frontmatter.get('updated_at', ''),
                        'token_count': self._estimate_tokens(body)
                    }
                }

                if previous_filename:
                    result['previous_filename'] = previous_filename

                return result

            except Exception as e:
                logger.error(f"[UserRulesManager] Error updating {filename}: {e}")
                return {'success': False, 'error': str(e), 'error_code': 'WRITE_ERROR'}

    def delete_rule(self, filename: str) -> bool:
        """Delete a rule by filename (without extension)."""
        if not self._rules_path:
            return False

        with self._file_lock:
            filepath = self._rules_path / f"{filename}.md"
            if filepath.exists():
                filepath.unlink()
                logger.info(f"[UserRulesManager] Deleted rule: {filepath}")
                return True

        logger.warning(f"[UserRulesManager] Rule not found for deletion: {filename}")
        return False

    def migrate_from_json(self, snippets: List[Dict[str, Any]]) -> int:
        """
        Migrate snippets from JSON format to markdown files.
        Returns the number of successfully migrated rules.
        """
        migrated = 0
        for snippet in snippets:
            try:
                result = self.create_rule(
                    title=snippet.get('title', 'Untitled'),
                    content=snippet.get('content', ''),
                    description=snippet.get('description', ''),
                    mode=snippet.get('mode', 'manual')
                )
                if result.get('success'):
                    migrated += 1
            except Exception as e:
                logger.error(f"[UserRulesManager] Error migrating snippet: {e}")

        logger.info(f"[UserRulesManager] Migrated {migrated}/{len(snippets)} snippets")
        return migrated

    def sync_default_rules(self) -> Dict[str, Any]:
        """
        Sync bundled default rules from package to user's default-rules directory.

        This should be called on startup to ensure users have the latest default rules.
        Rules with a user override (same filename in user-rules) are skipped.
        Version comparison is used to determine if an update is needed.
        Rules that no longer exist in the bundled package are deleted.

        Returns dict with sync results.
        """
        import importlib.resources

        result = {
            'synced': 0,
            'skipped': 0,
            'deleted': 0,
            'errors': [],
            'details': []
        }

        if not self._default_rules_path:
            result['errors'].append('Default rules path not available')
            return result

        try:
            # Try to get bundled rules from package
            try:
                # Python 3.9+ approach
                package_files = importlib.resources.files('signalpilot_ai_internal')
                bundled_dir = package_files / self.BUNDLED_RULES_PATH

                if not bundled_dir.is_dir():
                    logger.info("[UserRulesManager] No bundled default-rules directory in package")
                    return result

                bundled_files = [f for f in bundled_dir.iterdir() if f.name.endswith('.md')]

            except (AttributeError, TypeError):
                # Fallback for older Python or when package resources aren't available
                import pkg_resources
                try:
                    bundled_path = pkg_resources.resource_filename('signalpilot_ai_internal', self.BUNDLED_RULES_PATH)
                    bundled_dir = Path(bundled_path)
                    if not bundled_dir.exists():
                        logger.info("[UserRulesManager] No bundled default-rules directory in package")
                        return result
                    bundled_files = list(bundled_dir.glob('*.md'))
                except Exception:
                    logger.info("[UserRulesManager] Could not locate bundled rules")
                    return result

            # Ensure default-rules directory exists
            self._default_rules_path.mkdir(parents=True, exist_ok=True)

            for bundled_file in bundled_files:
                try:
                    filename = bundled_file.name
                    local_file = self._default_rules_path / filename
                    user_override = self._rules_path / filename if self._rules_path else None

                    # Skip if user has an override (they've customized this rule)
                    if user_override and user_override.exists():
                        result['skipped'] += 1
                        result['details'].append(f"{filename}: skipped (user override exists)")
                        continue

                    # Read bundled rule content
                    if hasattr(bundled_file, 'read_text'):
                        bundled_content = bundled_file.read_text(encoding='utf-8')
                    else:
                        with open(bundled_file, 'r', encoding='utf-8') as f:
                            bundled_content = f.read()

                    bundled_meta, _ = self._parse_frontmatter(bundled_content)
                    bundled_version = str(bundled_meta.get('version', '0.0.0'))

                    should_update = False

                    if local_file.exists():
                        # Compare versions
                        local_content = local_file.read_text(encoding='utf-8')
                        local_meta, _ = self._parse_frontmatter(local_content)
                        local_version = str(local_meta.get('version', '0.0.0'))

                        if bundled_version > local_version:
                            should_update = True
                            result['details'].append(f"{filename}: updated {local_version} -> {bundled_version}")
                        else:
                            result['skipped'] += 1
                            result['details'].append(f"{filename}: skipped (version {local_version} >= {bundled_version})")
                    else:
                        # New rule, copy it
                        should_update = True
                        result['details'].append(f"{filename}: new rule (version {bundled_version})")

                    if should_update:
                        with open(local_file, 'w', encoding='utf-8') as f:
                            f.write(bundled_content)
                        result['synced'] += 1

                except Exception as e:
                    error_msg = f"Error syncing {bundled_file.name}: {e}"
                    logger.error(f"[UserRulesManager] {error_msg}")
                    result['errors'].append(error_msg)

            # Delete orphaned rules (local rules that no longer exist in bundled package)
            bundled_filenames = {f.name for f in bundled_files}
            try:
                local_default_files = list(self._default_rules_path.glob('*.md'))
                for local_file in local_default_files:
                    if local_file.name not in bundled_filenames:
                        # This rule no longer exists in the bundled package - delete it
                        try:
                            local_file.unlink()
                            result['deleted'] += 1
                            result['details'].append(f"{local_file.name}: deleted (no longer in bundled rules)")
                            logger.info(f"[UserRulesManager] Deleted orphaned rule: {local_file.name}")
                        except Exception as e:
                            error_msg = f"Error deleting orphaned rule {local_file.name}: {e}"
                            logger.error(f"[UserRulesManager] {error_msg}")
                            result['errors'].append(error_msg)
            except Exception as e:
                error_msg = f"Error checking for orphaned rules: {e}"
                logger.error(f"[UserRulesManager] {error_msg}")
                result['errors'].append(error_msg)

        except Exception as e:
            error_msg = f"Error during sync: {e}"
            logger.error(f"[UserRulesManager] {error_msg}")
            result['errors'].append(error_msg)

        logger.info(f"[UserRulesManager] Sync complete: {result['synced']} synced, {result['skipped']} skipped, {result['deleted']} deleted")
        return result

    def is_available(self) -> bool:
        """Check if the user rules directory is available."""
        return self._rules_path is not None and self._rules_path.exists()

    def get_info(self) -> Dict[str, Any]:
        """Get information about the user rules setup."""
        info = {
            "available": self.is_available(),
            "rules_path": str(self._rules_path) if self._rules_path else None,
            "default_rules_path": str(self._default_rules_path) if self._default_rules_path else None,
            "user_rules_count": 0,
            "default_rules_count": 0
        }

        if self.is_available():
            try:
                info["user_rules_count"] = len(list(self._rules_path.glob('*.md')))
                if self._default_rules_path and self._default_rules_path.exists():
                    info["default_rules_count"] = len(list(self._default_rules_path.glob('*.md')))
            except Exception as e:
                info["error"] = str(e)

        return info


# Global user rules instance accessor
def get_user_rules_manager() -> UserRulesManager:
    """Get the singleton instance."""
    return UserRulesManager.get_instance()
