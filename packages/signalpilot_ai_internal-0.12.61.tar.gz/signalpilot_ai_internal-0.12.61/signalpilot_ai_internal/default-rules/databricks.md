---
title: Databricks Connector
description: Databricks Lakehouse connection and querying with Unity Catalog support. Use when the user needs to connect to Databricks, explore catalogs/schemas, or query data using SQL Warehouses. Explains 3-level namespace and mart concepts.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:08Z"
default: true
category: database
version: "1.0.0"
active: true
---

# Databricks Connector

Expert guidance for working with Databricks Lakehouse Platform.

## Critical Safety Rules

### Destructive Operations - ALWAYS WARN

Before generating ANY of these operations, you MUST warn the user about potential data loss:

- `DROP TABLE`, `DROP DATABASE`, `DROP SCHEMA`, `DROP CATALOG`
- `DELETE` (especially without WHERE clause)
- `TRUNCATE TABLE`
- `ALTER TABLE` (structure changes)
- `UPDATE` without WHERE clause
- `VACUUM` with short retention (removes Time Travel history)

When user requests destructive operations:
1. **Warn clearly**: "This operation will permanently delete/modify data and cannot be undone."
2. **Suggest safer alternatives**: soft deletes, CLONE for backups, WHERE clause additions, Time Travel for recovery
3. **Show exactly what will be affected**: row counts, table names
4. **Never execute DELETE/UPDATE without WHERE** unless user explicitly confirms they want to affect all rows

### Query Safety - LIMIT Enforcement

For exploratory or ad-hoc SELECT queries:

1. **Always apply LIMIT** (default 1000) unless user explicitly requests all rows
2. **Warn about large result sets**: "This query may return many rows. Adding LIMIT 1000."
3. **Consider TABLESAMPLE** for very large tables: `SELECT * FROM table TABLESAMPLE (1000 ROWS)`

Never generate unbounded `SELECT *` on tables without knowing their size.

### Data Privacy

Be cautious with columns that may contain PII:
- `email`, `phone`, `ssn`, `address`, `name`, `first_name`, `last_name`
- Columns containing `personal`, `private`, `secret`, `password`, `token`
- `ip_address`, `credit_card`, `bank_account`, `dob`, `date_of_birth`

## Package

```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install databricks-sql-connector
# - Otherwise: !pip install databricks-sql-connector
```

## Connection Setup

Databricks supports two authentication methods. Check the DATABASE CONFIGURATIONS section in the context to see which auth type is configured for your database.

### Personal Access Token (PAT) Authentication
Use this when `auth_type: pat` or when env vars include `ACCESS_TOKEN`:

```python
import os
from databricks import sql

conn = sql.connect(
    server_hostname=os.environ['MYDB_HOST'],
    http_path=os.environ['MYDB_WAREHOUSE_HTTP_PATH'],
    access_token=os.environ['MYDB_ACCESS_TOKEN']
)
```

### Service Principal (OAuth M2M) Authentication
Use this when `auth_type: service_principal` or when env vars include `CLIENT_ID` and `CLIENT_SECRET`:

```python
import os
from databricks import sql
from databricks.sdk.core import oauth_service_principal

def credential_provider():
    return oauth_service_principal(
        client_id=os.environ['MYDB_CLIENT_ID'],
        client_secret=os.environ['MYDB_CLIENT_SECRET']
    )

conn = sql.connect(
    server_hostname=os.environ['MYDB_HOST'],
    http_path=os.environ['MYDB_WAREHOUSE_HTTP_PATH'],
    credentials_provider=credential_provider
)
```

### Using Context Managers (Recommended)
```python
from databricks import sql

with sql.connect(
    server_hostname="your-workspace.cloud.databricks.com",
    http_path="/sql/1.0/warehouses/your-warehouse-id",
    access_token="your-access-token"  # or credentials_provider for OAuth
) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM catalog.schema.table")
        results = cursor.fetchall()
```

### Using with pandas
```python
import pandas as pd
from databricks import sql

with sql.connect(
    server_hostname="your-workspace.cloud.databricks.com",
    http_path="/sql/1.0/warehouses/your-warehouse-id",
    access_token="your-access-token"  # or credentials_provider for OAuth
) as conn:
    df = pd.read_sql("SELECT * FROM catalog.schema.table", conn)
```

## Unity Catalog - 3-Level Namespace

Databricks uses a **3-level namespace**: `CATALOG.SCHEMA.TABLE`

```
CATALOG.SCHEMA.TABLE
   |       |      |
   |       |      +-- Tables, Views, Functions
   |       +-- Logical grouping (similar to database schema)
   +-- Top-level container (like a database in traditional systems)
```

### Example Hierarchy
```
production_catalog/
+-- raw_data/
|   +-- sales_transactions
|   +-- customer_events
+-- silver_layer/
|   +-- cleaned_sales
|   +-- customer_profiles
+-- gold_layer/
    +-- daily_revenue_mart
    +-- customer_360_mart
```

## Schema Discovery

```sql
-- List all catalogs you have access to
SHOW CATALOGS;

-- List schemas in a catalog
SHOW SCHEMAS IN catalog_name;

-- List tables in a schema
SHOW TABLES IN catalog_name.schema_name;

-- Get table details
DESCRIBE TABLE catalog_name.schema_name.table_name;

-- Get extended table info (includes properties, location)
DESCRIBE TABLE EXTENDED catalog_name.schema_name.table_name;
```

## Setting Context

```sql
-- Set default catalog
USE CATALOG production_catalog;

-- Set default schema
USE SCHEMA gold_layer;

-- Now you can query without full path
SELECT * FROM daily_revenue_mart;

-- Check current context
SELECT current_catalog(), current_schema();
```

## Query Patterns

### Date/Time Functions

```sql
-- Current timestamp
SELECT current_timestamp();
SELECT current_date();

-- Date arithmetic
SELECT date_add(current_date(), 7);  -- Add days
SELECT datediff('2024-12-31', '2024-01-01');  -- Days between

-- Date truncation
SELECT date_trunc('month', current_timestamp());
SELECT date_trunc('week', current_timestamp());
```

### Window Functions

```sql
-- Row number
SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY category ORDER BY amount DESC) as rank
FROM products;

-- Running total
SELECT
    date,
    amount,
    SUM(amount) OVER (ORDER BY date) as running_total
FROM transactions;

-- Deduplication with ROW_NUMBER
WITH ranked AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY updated_at DESC) as rn
    FROM customers
)
SELECT * FROM ranked WHERE rn = 1;
```

### Semi-Structured Data (VARIANT/JSON)

```sql
-- Access JSON fields
SELECT raw_json:field_name::string as field_value
FROM table_with_json;

-- Nested access
SELECT raw_json:nested.field::number as nested_value
FROM table_with_json;

-- Flatten arrays
SELECT f.value::string as array_element
FROM table_with_json,
LATERAL FLATTEN(input => raw_json:array_field) f;
```

## Delta Lake Features

### Time Travel

```sql
-- Query historical version
SELECT * FROM catalog.schema.table VERSION AS OF 5;

-- Query as of timestamp
SELECT * FROM catalog.schema.table TIMESTAMP AS OF '2024-01-01';

-- View table history
DESCRIBE HISTORY catalog.schema.table;

-- Restore to previous version
RESTORE TABLE catalog.schema.table TO VERSION AS OF 5;
```

### Merge (Upsert)

```sql
MERGE INTO target_table AS target
USING source_table AS source
ON target.id = source.id
WHEN MATCHED THEN
    UPDATE SET
        target.name = source.name,
        target.updated_at = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT (id, name, created_at, updated_at)
    VALUES (source.id, source.name, current_timestamp(), current_timestamp());
```

### Table Maintenance

```sql
-- Optimize table (compact small files)
OPTIMIZE catalog.schema.table;

-- Z-Order for query optimization
OPTIMIZE catalog.schema.table ZORDER BY (date, customer_id);

-- Vacuum old files (default 7 days retention)
VACUUM catalog.schema.table;
```

## Medallion Architecture

### Bronze Layer (Raw)
- Raw data exactly as ingested from sources
- No transformations applied
- Includes metadata: ingestion timestamp, source system

### Silver Layer (Cleaned)
- Cleaned, deduplicated, validated data
- Consistent schema and data types
- Business rules applied

### Gold Layer (Marts)
- Business-ready aggregated data
- Optimized for specific use cases
- Denormalized for query performance

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| Table or view not found | Wrong path or no access | Check full 3-level path: `catalog.schema.table` |
| Warehouse is stopped | Auto-stopped after idle | Will auto-start on query, or start manually |
| Connection timeout | SQL Warehouse cold start | Wait for warehouse to fully start up |
| Access denied | Missing permissions | Check USAGE on catalog/schema, SELECT on table |

## Key Rules

1. **Always use 3-level namespace** - `catalog.schema.table` for clarity
2. **Set context explicitly** - Use `USE CATALOG` and `USE SCHEMA`
3. **Understand mart organization** - Gold layer for business queries
4. **Use Delta features** - Time travel for debugging, OPTIMIZE + ZORDER for performance
5. **Check permissions early** - `SHOW GRANTS` to debug access issues