---
title: Data Loading
description: "Skill for loading various types of datasets (CSV, Parquet, JSON, Excel, SQL) into code cells for analysis. Covers efficient loading strategies, handling large files, and format-specific options."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-29T16:00:00Z"
default: true
category: core
version: "1.0.0"
active: true
---

# Data Loading

You are an expert at loading data files into pandas DataFrames for analysis. You help users efficiently load datasets of various formats and sizes.

**Note**: Use `grep`, `glob`, `files-read`, and `files-summarize` tools for your internal understanding of data files—not for data analysis in notebooks. This rule covers loading datasets into code cells for analysis.

## Key Rules

1. **Always preview before full load** - Use `nrows` parameter to sample large files first
2. **Check file size first** - Large files need different strategies
3. **Specify dtypes when known** - Prevents mixed type issues and reduces memory
4. **Handle encoding explicitly** - UTF-8 isn't always the answer
5. **Use Parquet for intermediate storage** - Faster and smaller than CSV
6. **Close database connections** - Use context managers or explicit close

## Loading Data by Format

### CSV Files
```python
import pandas as pd

# Basic load
df = pd.read_csv('data/file.csv')

# With common options
df = pd.read_csv('data/file.csv',
    encoding='utf-8',           # or 'latin-1', 'cp1252'
    sep=',',                    # or ';', '\t', '|'
    header=0,                   # row number for header
    skiprows=0,                 # rows to skip at start
    na_values=['NA', 'N/A', ''], # treat as NaN
    parse_dates=['date_col'],   # parse date columns
    dtype={'col': str},         # force column types
    low_memory=False            # for large files with mixed types
)

# Preview large files without loading entirely
df = pd.read_csv('data/file.csv', nrows=1000)  # First 1000 rows
```

### Parquet Files
```python
# Standard load (recommended for large datasets)
df = pd.read_parquet('data/file.parquet')

# With PyArrow for better performance
df = pd.read_parquet('data/file.parquet', engine='pyarrow')

# Read specific columns only (memory efficient)
df = pd.read_parquet('data/file.parquet', columns=['col1', 'col2'])

# Read from directory of parquet files
df = pd.read_parquet('data/partitioned_data/')
```

### Excel Files
```python
# Basic load (first sheet)
df = pd.read_excel('data/file.xlsx')

# Specific sheet
df = pd.read_excel('data/file.xlsx', sheet_name='Sheet2')
df = pd.read_excel('data/file.xlsx', sheet_name=1)  # By index

# All sheets (returns dict of DataFrames)
dfs = pd.read_excel('data/file.xlsx', sheet_name=None)

# With options
df = pd.read_excel('data/file.xlsx',
    header=0,
    skiprows=2,
    usecols='A:F',  # or [0, 1, 2] for column indices
    dtype={'ID': str}
)
```

### JSON Files
```python
# Standard JSON (list of records)
df = pd.read_json('data/file.json')

# JSON Lines format (one JSON object per line)
df = pd.read_json('data/file.jsonl', lines=True)

# Nested JSON - may need normalization
import json
with open('data/file.json') as f:
    data = json.load(f)
df = pd.json_normalize(data, record_path=['nested', 'path'])
```

### SQL/SQLite Files
```python
import sqlite3

conn = sqlite3.connect('data/database.db')

# List tables
tables = pd.read_sql("SELECT name FROM sqlite_master WHERE type='table'", conn)

# Read table
df = pd.read_sql('SELECT * FROM table_name', conn)

# Read with query
df = pd.read_sql('SELECT col1, col2 FROM table WHERE condition', conn)

conn.close()
```

### Feather Files
```python
# Fast binary format (good for intermediate storage)
df = pd.read_feather('data/file.feather')
```

### Pickle Files

**SECURITY WARNING**: Pickle files can execute arbitrary code when loaded. Only load pickle files from completely trusted sources.

```python
# Load pickled DataFrame
df = pd.read_pickle('data/file.pkl')
```

## Handling Large Files

### Memory-Efficient Loading

```python
# Chunked reading for very large files
chunk_size = 100_000
chunks = []
for chunk in pd.read_csv('data/large_file.csv', chunksize=chunk_size):
    # Process each chunk
    processed = chunk[chunk['value'] > 0]  # Example filter
    chunks.append(processed)
df = pd.concat(chunks, ignore_index=True)
```

### Optimizing Data Types

```python
def optimize_dtypes(df):
    """Reduce memory usage by optimizing data types."""
    for col in df.columns:
        col_type = df[col].dtype

        if col_type == 'object':
            # Convert to category if low cardinality
            if df[col].nunique() / len(df) < 0.5:
                df[col] = df[col].astype('category')

        elif col_type == 'int64':
            # Downcast integers
            df[col] = pd.to_numeric(df[col], downcast='integer')

        elif col_type == 'float64':
            # Downcast floats
            df[col] = pd.to_numeric(df[col], downcast='float')

    return df
```

### Using Dask for Very Large Files

```python
import dask.dataframe as dd

# Load large CSV with Dask
ddf = dd.read_csv('data/very_large_file.csv')

# Perform operations (lazy evaluation)
result = ddf[ddf['value'] > 0].groupby('category').sum()

# Compute when needed
df = result.compute()
```

## Common Loading Issues and Solutions

### Encoding Errors
```python
# Try different encodings
for encoding in ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']:
    try:
        df = pd.read_csv('data/file.csv', encoding=encoding)
        print(f"Success with {encoding}")
        break
    except UnicodeDecodeError:
        continue
```

### Mixed Data Types Warning
```python
# Specify dtypes explicitly
df = pd.read_csv('data/file.csv',
                 dtype={'problematic_col': str},
                 low_memory=False)
```

### Date Parsing Issues
```python
# Custom date format
df = pd.read_csv('data/file.csv',
                 parse_dates=['date_col'],
                 date_format='%d/%m/%Y')

# Post-load conversion
df['date_col'] = pd.to_datetime(df['date_col'], format='%d/%m/%Y', errors='coerce')
```

### Delimiter Detection
```python
import csv

# Auto-detect delimiter
with open('data/file.csv', 'r') as f:
    sample = f.read(4096)
    dialect = csv.Sniffer().sniff(sample)
    delimiter = dialect.delimiter

df = pd.read_csv('data/file.csv', sep=delimiter)
```

## Data Preview Workflow

### Step 1: Check File Info
```python
import os
from pathlib import Path

filepath = 'data/example.csv'
file_info = {
    'name': Path(filepath).name,
    'size_bytes': os.path.getsize(filepath),
    'size_mb': os.path.getsize(filepath) / (1024 * 1024),
    'extension': Path(filepath).suffix
}
print(f"File: {file_info['name']}")
print(f"Size: {file_info['size_mb']:.2f} MB")
```

### Step 2: Load Sample
```python
# Load a sample first
df = pd.read_csv('data/example.csv', nrows=1000)

# Basic info
print(f"Shape: {df.shape}")
print(f"\nColumns:\n{df.dtypes}")
print(f"\nFirst rows:\n{df.head()}")
print(f"\nMemory usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
```

### Step 3: Full Load with Optimizations
```python
# Based on preview, load with appropriate options
df = pd.read_csv('data/example.csv',
    dtype={'id': 'int32', 'category': 'category'},
    parse_dates=['date'],
    usecols=['id', 'category', 'date', 'value']  # Only needed columns
)
```

## File Format Recommendations

| Use Case | Recommended Format |
|----------|-------------------|
| Data exchange | CSV (universal), Parquet (efficient) |
| Large datasets | Parquet |
| Preserving data types | Parquet, Feather |
| Speed (read/write) | Feather, Parquet |
| Human readable | CSV, JSON |
| Excel users | XLSX |
| Archive/backup | Parquet (compressed) |
