"""
MCP Handlers - Tornado HTTP handlers for MCP API endpoints.

Provides REST API for managing MCP server connections and tool calls.
"""
import json
import logging
import traceback
from typing import Dict, Any, Callable, Coroutine

import tornado
from jupyter_server.base.handlers import APIHandler
from .mcp_service.service import get_mcp_service, MCPConnectionService
from .oauth_token_store import get_oauth_token_store

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class MCPBaseHandler(APIHandler):
    """Base handler with common MCP utilities.

    Provides:
    - _get_service(): Get singleton MCP service instance
    - _json_response(): Send JSON response with status code
    - _error_response(): Send error JSON response
    - _handle_request(): Wrapper with standard error handling
    """

    def _get_service(self) -> MCPConnectionService:
        """Get the MCP connection service singleton."""
        return get_mcp_service()

    def _json_response(self, data: Dict[str, Any], status: int = 200):
        """Send JSON response with optional status code."""
        self.set_status(status)
        self.finish(json.dumps(data))

    def _error_response(self, error: str, status: int = 500):
        """Send error response as JSON."""
        self.set_status(status)
        self.finish(json.dumps({'error': error}))

    async def _handle_request(self, handler_fn: Callable[[], Coroutine]):
        """Wrap async handler with standard error handling.

        Catches:
        - json.JSONDecodeError -> 400
        - ValueError -> 404
        - Exception -> 500
        """
        try:
            await handler_fn()
        except json.JSONDecodeError as e:
            self._error_response(f'Invalid JSON: {e}', 400)
        except ValueError as e:
            self._error_response(str(e), 404)
        except Exception as e:
            logger.error(f"Handler error: {e}")
            logger.error(traceback.format_exc())
            self._error_response(str(e), 500)


class MCPServersHandler(MCPBaseHandler):
    """Handler for managing MCP server configurations."""

    @tornado.web.authenticated
    async def get(self):
        """Get all configured MCP servers."""
        await self._handle_request(self._get_servers)

    async def _get_servers(self):
        """Build list of all servers with status and OAuth info."""
        service = self._get_service()
        token_store = get_oauth_token_store()
        configs = service.load_all_configs()

        servers = []
        for server_id, config in configs.items():
            server_info = {
                **config,
                'status': service.get_connection_status(server_id),
                'enabled': config.get('enabled', True)
            }

            if server_id in service.tools_cache:
                server_info['toolCount'] = len(service.tools_cache[server_id])

            is_oauth = config.get('isOAuthIntegration', False) or token_store.is_oauth_server(server_id)
            if is_oauth:
                server_info['isOAuthIntegration'] = True
                integration_id = token_store.get_integration_id(server_id)
                if integration_id:
                    server_info['integrationId'] = integration_id

            servers.append(server_info)

        self._json_response({'servers': servers})
    
    @tornado.web.authenticated
    async def post(self):
        """Save a new MCP server configuration."""
        await self._handle_request(self._save_server)

    async def _save_server(self):
        """Validate and save new server configuration."""
        data = json.loads(self.request.body.decode('utf-8'))

        error = self._validate_server_config(data)
        if error:
            self._error_response(error, 400)
            return

        saved_config = self._get_service().save_server_config(data)
        self._json_response({'success': True, 'server': saved_config})

    def _validate_server_config(self, data: Dict[str, Any]) -> str:
        """Validate server config, return error message or empty string."""
        if 'name' not in data:
            return 'Server name is required'

        connection_type = data.get('type', 'command')
        data['type'] = connection_type

        if connection_type == 'command' and 'command' not in data:
            return 'Command is required for command-based MCP'
        if connection_type in ['http', 'sse'] and 'url' not in data:
            return 'URL is required for HTTP/SSE MCP'
        if connection_type not in ['command', 'http', 'sse']:
            return f'Invalid connection type: {connection_type}'

        return ''


class MCPServerHandler(MCPBaseHandler):
    """Handler for individual MCP server operations."""

    @tornado.web.authenticated
    async def delete(self, server_id: str):
        """Delete an MCP server configuration."""
        await self._handle_request(lambda: self._delete_server(server_id))

    async def _delete_server(self, server_id: str):
        """Delete server config by ID."""
        success = self._get_service().delete_server_config(server_id)
        if success:
            self._json_response({'success': True, 'message': f'Server {server_id} deleted'})
        else:
            self._error_response('Server not found', 404)

    @tornado.web.authenticated
    async def put(self, server_id: str):
        """Update an MCP server configuration."""
        await self._handle_request(lambda: self._update_server(server_id))

    async def _update_server(self, server_id: str):
        """Update existing server config."""
        data = json.loads(self.request.body.decode('utf-8'))
        service = self._get_service()

        config = service.get_server_config(server_id)
        if not config:
            self._error_response('Server not found', 404)
            return

        config.update(data)
        config['id'] = server_id
        saved_config = service.save_server_config(config)
        self._json_response({'success': True, 'server': saved_config})


class MCPConnectHandler(MCPBaseHandler):
    """Handler for connecting to MCP servers."""

    @tornado.web.authenticated
    async def post(self):
        """Connect to a specific MCP server."""
        server_id = None
        try:
            data = json.loads(self.request.body.decode('utf-8'))
            server_id = data.get('server_id')

            if not server_id:
                self._error_response('server_id is required', 400)
                return

            logger.info(f"[MCP] Connecting to server: {server_id}")
            server_info = await self._get_service().connect(server_id)
            logger.info(f"[MCP] Connected to {server_id}")
            self._json_response({'success': True, 'server': server_info})

        except json.JSONDecodeError as e:
            logger.error(f"[MCP] Invalid JSON: {e}")
            self._error_response(f'Invalid JSON: {e}', 400)
        except ValueError as e:
            logger.error(f"[MCP] ValueError for {server_id}: {e}")
            self.set_status(404)
            self.finish(json.dumps({
                'error': str(e), 'errorType': 'ValueError', 'serverId': server_id
            }))
        except RuntimeError as e:
            logger.error(f"[MCP] RuntimeError for {server_id}: {e}")
            self.set_status(500)
            self.finish(json.dumps({
                'error': str(e), 'errorType': 'RuntimeError', 'serverId': server_id,
                'details': 'Check server logs for detailed error information'
            }))
        except Exception as e:
            logger.error(f"[MCP] Unexpected error for {server_id}: {e}\n{traceback.format_exc()}")
            self.set_status(500)
            self.finish(json.dumps({
                'error': str(e), 'errorType': type(e).__name__, 'serverId': server_id,
                'details': 'An unexpected error occurred'
            }))


class MCPDisconnectHandler(MCPBaseHandler):
    """Handler for disconnecting from MCP servers."""

    @tornado.web.authenticated
    async def post(self, server_id: str):
        """Disconnect from a specific MCP server."""
        await self._handle_request(lambda: self._disconnect(server_id))

    async def _disconnect(self, server_id: str):
        """Disconnect from server by ID."""
        success = await self._get_service().disconnect(server_id)
        if success:
            self._json_response({'success': True, 'message': f'Disconnected from server {server_id}'})
        else:
            self._error_response('Server not found or not connected', 404)


class MCPToolsHandler(MCPBaseHandler):
    """Handler for listing MCP tools."""

    @tornado.web.authenticated
    async def get(self, server_id: str):
        """Get available tools from a connected MCP server."""
        await self._handle_request(lambda: self._list_tools(server_id))

    async def _list_tools(self, server_id: str):
        """List tools for a specific server."""
        tools = await self._get_service().list_tools(server_id)
        self._json_response({'tools': tools})


class MCPAllToolsHandler(MCPBaseHandler):
    """Handler for getting all tools from all connected servers."""

    @tornado.web.authenticated
    async def get(self):
        """Get all tools from all connected MCP servers."""
        await self._handle_request(self._get_all_tools)

    async def _get_all_tools(self):
        """Get all tools from all connected servers."""
        tools = await self._get_service().get_all_tools()
        self._json_response({'tools': tools})


class MCPToolCallHandler(MCPBaseHandler):
    """Handler for calling MCP tools."""

    @tornado.web.authenticated
    async def post(self):
        """Call a tool on an MCP server."""
        await self._handle_request(self._call_tool)

    async def _call_tool(self):
        """Parse request and call tool."""
        data = json.loads(self.request.body.decode('utf-8'))

        server_id = data.get('server_id')
        tool_name = data.get('tool_name')
        arguments = data.get('arguments', {})

        if not server_id or not tool_name:
            self._error_response('server_id and tool_name are required', 400)
            return

        self._inject_google_email(server_id, arguments)

        result = await self._get_service().call_tool(server_id, tool_name, arguments)
        self._json_response({'success': True, 'result': result})

    def _inject_google_email(self, server_id: str, arguments: Dict[str, Any]):
        """Inject user_google_email for Google OAuth servers if missing.

        Workaround for google_workspace_mcp requiring this even in --single-user mode.
        See: https://github.com/taylorwilsdon/google_workspace_mcp/issues/338
        """
        token_store = get_oauth_token_store()
        if not token_store.is_oauth_server(server_id):
            return
        if token_store.get_integration_id(server_id) != 'google':
            return
        if 'user_google_email' in arguments:
            return

        oauth_env = token_store.get_tokens(server_id)
        if oauth_env and 'USER_GOOGLE_EMAIL' in oauth_env:
            arguments['user_google_email'] = oauth_env['USER_GOOGLE_EMAIL']


class MCPServerEnableHandler(MCPBaseHandler):
    """Handler for enabling MCP servers."""

    @tornado.web.authenticated
    async def post(self, server_id: str):
        """Enable an MCP server."""
        await self._handle_request(lambda: self._enable_server(server_id))

    async def _enable_server(self, server_id: str):
        """Enable server by ID."""
        success = self._get_service().enable_server(server_id)
        if success:
            self._json_response({'success': True, 'message': f'Server {server_id} enabled'})
        else:
            self._error_response('Server not found', 404)


class MCPServerDisableHandler(MCPBaseHandler):
    """Handler for disabling MCP servers."""

    @tornado.web.authenticated
    async def post(self, server_id: str):
        """Disable an MCP server."""
        await self._handle_request(lambda: self._disable_server(server_id))

    async def _disable_server(self, server_id: str):
        """Disable server by ID."""
        success = self._get_service().disable_server(server_id)
        if success:
            self._json_response({'success': True, 'message': f'Server {server_id} disabled'})
        else:
            self._error_response('Server not found', 404)


class MCPToolEnableHandler(MCPBaseHandler):
    """Handler for enabling/disabling individual MCP tools."""

    @tornado.web.authenticated
    async def put(self, server_id: str, tool_name: str):
        """Update enabled/disabled state for a specific tool."""
        await self._handle_request(lambda: self._update_tool(server_id, tool_name))

    async def _update_tool(self, server_id: str, tool_name: str):
        """Enable or disable a specific tool."""
        data = json.loads(self.request.body.decode('utf-8'))
        enabled = data.get('enabled', True)

        success = self._get_service().update_tool_enabled(server_id, tool_name, enabled)
        if success:
            state = 'enabled' if enabled else 'disabled'
            self._json_response({'success': True, 'message': f'Tool {tool_name} {state}'})
        else:
            self._error_response('Server not found', 404)


class MCPConfigFileHandler(MCPBaseHandler):
    """Handler for managing the entire MCP config file."""

    @tornado.web.authenticated
    async def get(self):
        """Get the raw JSON config file content."""
        await self._handle_request(self._get_config_file)

    async def _get_config_file(self):
        """Get and validate config file content."""
        content = self._get_service().get_config_file_content()

        if not content:
            content = json.dumps({'mcpServers': {}}, indent=2)

        try:
            json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(f"Config file not valid JSON: {e}")
            content = json.dumps({'mcpServers': {}}, indent=2)

        self.set_header('Content-Type', 'application/json; charset=utf-8')
        self.finish(content)

    @tornado.web.authenticated
    async def put(self):
        """Update the entire config file with diff detection."""
        await self._handle_request(self._update_config_file)

    async def _update_config_file(self):
        """Update config file from request body."""
        content = self.request.body.decode('utf-8')
        logger.info(f"[MCP] Updating config file ({len(content)} chars)")

        result = self._get_service().update_config_file(content)
        logger.info(f"[MCP] Config updated: {json.dumps(result)}")
        self._json_response(result)
