try:
    from ._version import __version__
except ImportError:
    import warnings
    warnings.warn("Importing 'signalpilot_ai_internal' outside a proper installation.")
    __version__ = "dev"

import json
import logging
import os
import subprocess
import threading
import traceback
import uuid
from datetime import datetime
from pathlib import Path

from .handlers import setup_handlers
from .mcp_server_manager import autostart_mcp_servers
from .signalpilot_home import get_signalpilot_home
from signalpilot_ai_internal.db_config.factory import build_kernel_env, normalize_db_name
from signalpilot_ai_internal.db_config.constants import SUPPORTED_TYPES


def _get_database_env_vars():
    """Build environment variables dictionary from database configurations."""
    env_vars = {}
    try:
        home = get_signalpilot_home()
        for config in home.get_database_configs():
            db_name = config.get('name', '')
            if not db_name:
                continue
            prefix = normalize_db_name(db_name)
            env_vars.update(build_kernel_env(config, prefix))
    except Exception:
        pass
    return env_vars


def _setup_kernel_env_injection(server_app):
    """
    Hook into the kernel provisioner to inject database env vars at kernel start.

    This monkey-patches the LocalProvisioner's pre_launch method which is called
    before every kernel process launch, including restarts.
    """
    log = server_app.log

    try:
        from jupyter_client.provisioning import LocalProvisioner

        # Check if already patched
        if hasattr(LocalProvisioner, '_signalpilot_patched'):
            log.info("[signalpilot_ai_internal] LocalProvisioner already patched")
            return

        # Store the original method
        original_pre_launch = LocalProvisioner.pre_launch

        async def patched_pre_launch(self, **kwargs):
            """Wrapper that injects database env vars before launching kernel process."""
            # Get database env vars
            db_env_vars = _get_database_env_vars()

            if db_env_vars:
                # Get or create the env dict
                env = kwargs.get('env')
                if env is None:
                    env = os.environ.copy()
                else:
                    env = dict(env)

                # Inject database env vars
                env.update(db_env_vars)
                kwargs['env'] = env

            # Call original method
            return await original_pre_launch(self, **kwargs)

        # Patch at class level
        LocalProvisioner.pre_launch = patched_pre_launch
        LocalProvisioner._signalpilot_patched = True

        log.info("[signalpilot_ai_internal] Kernel env injection hook installed on LocalProvisioner.pre_launch")

    except Exception as e:
        log.warning(f"[signalpilot_ai_internal] Could not install kernel env injection hook: {e}")
        log.warning(traceback.format_exc())
        log.warning("[signalpilot_ai_internal] Database env vars will be set at runtime instead")


def _configure_kernel_env_vars(log):
    """
    Configure kernel specs with database environment variables.

    This directly adds env vars to kernel.json's 'env' field, which is
    simpler and more reliable than using a custom provisioner.
    """
    try:
        # Get database env vars
        db_env_vars = _get_database_env_vars()

        if not db_env_vars:
            log.info("[signalpilot_ai_internal] No database configurations found, skipping kernel env setup")
            return

        log.info(f"[signalpilot_ai_internal] Found {len(db_env_vars)} database env vars to inject")

        # Get list of kernel specs
        result = subprocess.run(
            ['jupyter', 'kernelspec', 'list', '--json'],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            log.warning(f"[signalpilot_ai_internal] Could not list kernel specs: {result.stderr}")
            return

        specs = json.loads(result.stdout)

        for name, info in specs.get('kernelspecs', {}).items():
            kernel_json_path = Path(info['resource_dir']) / 'kernel.json'

            if not kernel_json_path.exists():
                continue

            try:
                with open(kernel_json_path, 'r') as f:
                    kernel_json = json.load(f)

                # Get or create env dict
                if 'env' not in kernel_json:
                    kernel_json['env'] = {}

                # Check if env vars are already set (compare a sample key)
                sample_key = list(db_env_vars.keys())[0] if db_env_vars else None
                if sample_key and kernel_json['env'].get(sample_key) == db_env_vars.get(sample_key):
                    log.info(f"[signalpilot_ai_internal] Kernel '{name}' env vars already up to date")
                    continue

                # Add database env vars
                kernel_json['env'].update(db_env_vars)

                # Try to write back
                try:
                    with open(kernel_json_path, 'w') as f:
                        json.dump(kernel_json, f, indent=2)
                    log.info(f"[signalpilot_ai_internal] Updated kernel '{name}' with database env vars")

                except PermissionError:
                    log.warning(
                        f"[signalpilot_ai_internal] No permission to modify kernel '{name}'. "
                        "Database env vars will be set at runtime instead."
                    )

            except Exception as e:
                log.warning(f"[signalpilot_ai_internal] Could not configure kernel '{name}': {e}")

    except Exception as e:
        log.warning(f"[signalpilot_ai_internal] Error configuring kernel env vars: {e}")


def _reconcile_db_configs(log):
    """
    Reconcile db.toml entries on startup.

    For entries added manually (e.g. via the admin portal), fills in missing
    metadata fields (id, createdAt, updatedAt) and attempts to pull the
    database schema in a background thread.
    """
    try:
        home = get_signalpilot_home()
        config = home.read_db_config()
        dirty = False

        # Track entries that need a schema pull
        needs_schema = []

        for db_type in SUPPORTED_TYPES:
            entries = config.get(db_type, [])
            for entry in entries:
                name = entry.get("name", "")
                if not name:
                    continue

                # Generate deterministic ID if missing (matches ConfigConverter.to_frontend)
                if not entry.get("id"):
                    entry["id"] = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{name}-{db_type}"))
                    dirty = True

                now = datetime.now().isoformat()

                if not entry.get("createdAt"):
                    entry["createdAt"] = now
                    dirty = True

                if not entry.get("updatedAt"):
                    entry["updatedAt"] = now
                    dirty = True

                # Queue schema pull for entries without schema data
                if not entry.get("database_schema"):
                    needs_schema.append((db_type, name, {**entry, "type": db_type}))

        if dirty:
            home.write_db_config(config)
            log.info("[signalpilot_ai_internal] Reconciled db.toml — filled in missing metadata fields")

        # Pull schemas in background so startup isn't blocked
        if needs_schema:
            log.info(
                f"[signalpilot_ai_internal] {len(needs_schema)} database(s) missing schema — "
                "pulling in background"
            )
            thread = threading.Thread(
                target=_pull_schemas_background,
                args=(needs_schema,),
                daemon=True,
            )
            thread.start()

    except Exception as e:
        log.warning(f"[signalpilot_ai_internal] db.toml reconciliation failed (non-fatal): {e}")


def _pull_schemas_background(entries):
    """Pull database schemas for entries that are missing them. Runs in a daemon thread."""
    logger = logging.getLogger("signalpilot_ai_internal.reconcile")

    for db_type, name, config in entries:
        try:
            if db_type == "snowflake":
                # Snowflake uses its own connector, not SQLAlchemy
                logger.info(f"[reconcile] Skipping Snowflake schema pull for '{name}' (requires interactive session)")
                continue

            from signalpilot_ai_internal.schema_service.sqlalchemy.handlers import SQLAlchemySchemaHandler

            handler = SQLAlchemySchemaHandler.__new__(SQLAlchemySchemaHandler)
            handler.db_type = db_type if db_type != "postgres" else "postgresql"
            result = handler.extract_schema(config)

            if result:
                schema_json = json.dumps(result)
                now = datetime.now().isoformat()

                home = get_signalpilot_home()
                home.update_database_config(db_type, name, {
                    "database_schema": schema_json,
                    "schema_last_updated": now,
                    "updatedAt": now,
                })
                logger.info(f"[reconcile] Pulled schema for '{name}' ({db_type})")

        except Exception as e:
            logger.debug(f"[reconcile] Could not pull schema for '{name}' ({db_type}): {e}")


def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": "signalpilot-ai-internal"
    }]


def _jupyter_server_extension_points():
    return [{
        "module": "signalpilot_ai_internal"
    }]


def _load_jupyter_server_extension(server_app):
    """Registers the API handler to receive HTTP requests from the frontend extension.

    Parameters
    ----------
    server_app: jupyterlab.labapp.LabApp
        JupyterLab application instance
    """
    setup_handlers(server_app.web_app)
    name = "signalpilot_ai_internal"
    server_app.log.info(f"Registered {name} server extension")

    # Reconcile db.toml — fill missing fields, pull schemas in background
    _reconcile_db_configs(server_app.log)

    # Hook into kernel manager to inject database env vars at kernel start
    _setup_kernel_env_injection(server_app)

    # Auto-start configured MCP servers (like signalpilot-mcp)
    try:
        autostart_mcp_servers(server_app.root_dir)
        server_app.log.info("MCP servers auto-start completed")
    except Exception as e:
        server_app.log.warning(f"Failed to auto-start MCP servers: {e}")
