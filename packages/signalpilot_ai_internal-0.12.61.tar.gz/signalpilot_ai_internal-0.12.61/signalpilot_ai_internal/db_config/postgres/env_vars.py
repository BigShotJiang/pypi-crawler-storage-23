"""PostgreSQL environment variable builder."""

from signalpilot_ai_internal.db_config.base.env_vars import BaseEnvVarBuilder
from signalpilot_ai_internal.db_config.postgres.url_builder import PostgresURLBuilder


class PostgresEnvVarBuilder(BaseEnvVarBuilder):
    """Builds environment variables for PostgreSQL."""

    URL_BUILDER_CLASS = PostgresURLBuilder
