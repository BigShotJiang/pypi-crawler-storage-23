"""Factory for database configuration builders."""

import re
from typing import Any, Dict, Type

from signalpilot_ai_internal.db_config.base.env_vars import BaseEnvVarBuilder
from signalpilot_ai_internal.db_config.base.url_builder import BaseURLBuilder
from signalpilot_ai_internal.db_config.databricks.env_vars import DatabricksEnvVarBuilder
from signalpilot_ai_internal.db_config.databricks.url_builder import DatabricksURLBuilder
from signalpilot_ai_internal.db_config.mysql.env_vars import MySQLEnvVarBuilder
from signalpilot_ai_internal.db_config.mysql.url_builder import MySQLURLBuilder
from signalpilot_ai_internal.db_config.postgres.env_vars import PostgresEnvVarBuilder
from signalpilot_ai_internal.db_config.postgres.url_builder import PostgresURLBuilder
from signalpilot_ai_internal.db_config.snowflake.env_vars import SnowflakeEnvVarBuilder
from signalpilot_ai_internal.db_config.snowflake.url_builder import SnowflakeURLBuilder

URL_BUILDERS: Dict[str, Type[BaseURLBuilder]] = {
    "postgres": PostgresURLBuilder,
    "postgresql": PostgresURLBuilder,
    "mysql": MySQLURLBuilder,
    "databricks": DatabricksURLBuilder,
    "snowflake": SnowflakeURLBuilder,
}

ENV_VAR_BUILDERS: Dict[str, Type[BaseEnvVarBuilder]] = {
    "postgres": PostgresEnvVarBuilder,
    "postgresql": PostgresEnvVarBuilder,
    "mysql": MySQLEnvVarBuilder,
    "databricks": DatabricksEnvVarBuilder,
    "snowflake": SnowflakeEnvVarBuilder,
}


def get_url_builder(db_type: str) -> BaseURLBuilder:
    """Get URL builder instance for database type."""
    builder_class = URL_BUILDERS.get(db_type.lower())
    if not builder_class:
        raise ValueError(f"Unsupported database type: {db_type}")
    return builder_class()


def get_env_var_builder(db_type: str) -> BaseEnvVarBuilder:
    """Get env var builder instance for database type."""
    builder_class = ENV_VAR_BUILDERS.get(db_type.lower())
    if not builder_class:
        raise ValueError(f"Unsupported database type: {db_type}")
    return builder_class()


def build_connection_url(config: Dict[str, Any]) -> str:
    """Build SQLAlchemy connection URL from config."""
    db_type = config.get("type", "")
    builder = get_url_builder(db_type)
    return builder.build(config)


def build_kernel_env(config: Dict[str, Any], prefix: str) -> Dict[str, str]:
    """Build kernel environment variables from config."""
    db_type = config.get("type", "")
    builder = get_env_var_builder(db_type)
    return builder.build_kernel_env(config, prefix)


def detect_db_type(url: str) -> str:
    """Detect database type from connection URL."""
    url_lower = url.lower()
    if url_lower.startswith("postgresql://") or url_lower.startswith("postgres://"):
        return "postgresql"
    if url_lower.startswith("mysql://") or url_lower.startswith("mysql+"):
        return "mysql"
    if url_lower.startswith("databricks://"):
        return "databricks"
    if url_lower.startswith("snowflake://"):
        return "snowflake"
    return "postgresql"


def normalize_db_name(name: str) -> str:
    """Normalize database name to env var prefix."""
    return re.sub(r"[^A-Z0-9]", "_", name.upper())


build_url = build_connection_url
