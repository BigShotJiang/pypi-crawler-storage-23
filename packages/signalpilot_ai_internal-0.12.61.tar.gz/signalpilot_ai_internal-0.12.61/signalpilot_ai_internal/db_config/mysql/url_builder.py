"""MySQL URL builder."""

from signalpilot_ai_internal.db_config.base.url_builder import StandardURLBuilder


class MySQLURLBuilder(StandardURLBuilder):
    """Builds MySQL SQLAlchemy connection URLs."""

    DRIVER = "mysql+pymysql"
    DEFAULT_PORT = "3306"
    URL_PREFIX = "mysql://"
    URL_PREFIX_FIX = "mysql+pymysql://"
