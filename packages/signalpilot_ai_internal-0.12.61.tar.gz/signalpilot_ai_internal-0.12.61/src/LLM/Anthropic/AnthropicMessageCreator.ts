import Anthropic from '@anthropic-ai/sdk';
import { useSnippetStore } from '@/stores/snippetStore';
import { getWorkspaceContext } from '@/stores/appStore';
import { useSettingsStore } from '@/stores/settingsStore';
import { KernelPreviewUtils } from '@/utils/kernelPreview';
import { getSkillsContainer, TOOL_SEARCH_CONFIG } from '@/LLM';
import { DatabaseStateService, DatabaseType } from '@/stores/databaseStore';
import { getEnvVarPrefix } from '@/utils/databaseEnvVars';
import { useChatStore } from '@/stores/chat/chatStore';
import { useChatMessagesStore } from '@/stores/chatMessages';
import { debuggerService } from '@/Services/DebuggerService';

export interface IMessageCreationParams {
  client: Anthropic;
  modelName: string;
  systemPrompt: string;
  systemPromptAskMode: string;
  systemPromptFastMode: string;
  systemPromptWelcome: string;
  isFastMode: boolean;
  toolBlacklist: string[];
  mode: 'agent' | 'ask' | 'fast' | 'welcome';
  tools: any[];
  autoRun: boolean;
  systemPromptMessages?: string[];
  fetchNotebookState?: () => Promise<string>;
  notebookContextManager?: any;
  notebookId?: string;
  abortSignal: AbortSignal;
  errorLogger?: (message: any) => Promise<void>;
  customHeaders?: Record<string, string>;
}

export interface IPreparedMessages {
  initialMessages: any[];
  filteredHistory: any[];
  availableTools: any[];
  systemPrompt: string;
  extraSystemMessages: any[];
}

/**
 * Handles message preparation and stream creation for Anthropic API
 */
export class AnthropicMessageCreator {
  /**
   * Prepares messages and creates a stream
   */
  static async createMessageStream(
    params: IMessageCreationParams,
    filteredHistory: any[],
    normalizeMessageContent: (
      messages: any[],
      errorLogger?: (message: any) => Promise<void>
    ) => any[]
  ): Promise<any> {
    const perfStart = performance.now();
    console.log('[PERF] AnthropicMessageCreator.createMessageStream - START');

    const prepared = await this.prepareMessages(
      params,
      filteredHistory,
      normalizeMessageContent
    );
    const messages = [...prepared.initialMessages, ...prepared.filteredHistory];
    // Use claude-opus-4-5 for welcome messages only
    const modelToUse =
      params.mode === 'welcome' && messages.length === 1
        ? 'claude-opus-4-5'
        : params.modelName;

    console.log('[AnthropicMessageCreator] Using model:', modelToUse);

    const perfBeforeApiCall = performance.now();
    console.log(
      `[PERF] AnthropicMessageCreator.createMessageStream - Making API call (${(perfBeforeApiCall - perfStart).toFixed(2)}ms elapsed)`
    );

    // Prepare container with skills if available
    const skillsContainer = await getSkillsContainer();

    // Debug: Log skills container
    if (skillsContainer) {
      console.log(
        '[DEBUG] Skills container:',
        JSON.stringify(skillsContainer, null, 2)
      );
    } else {
      console.log('[DEBUG] No skills container - skills disabled');
    }

    // Add code execution tool (required for beta API)
    // TODO: Disabled - terminal execution now handled by MCP terminal-execute tool
    // const codeExecutionTool = {
    //   type: 'code_execution_20250825',
    //   name: 'code_execution'
    // };
    const webSearchTool = {
      type: 'web_search_20250305',
      name: 'web_search',
      max_uses: 5
    };
    const finalTools = [...prepared.availableTools, webSearchTool];
    console.log('[DEBUG] Added web search tool and prepared tools for API');

    // Debug: Log final API parameters
    console.log('[DEBUG] Final API call parameters:');
    console.log('- Model:', modelToUse);
    console.log('- Beta headers:', TOOL_SEARCH_CONFIG.betaHeaders);
    console.log(
      '- Container parameter:',
      skillsContainer ? 'INCLUDED' : 'NOT INCLUDED'
    );
    console.log('- Tools count:', finalTools.length);

    // Emit debug event with raw data
    debuggerService.emitLLMRequest({
      model: modelToUse,
      input: [...prepared.initialMessages, ...prepared.filteredHistory],
      tools: finalTools,
      systemPrompt: [
        {
          text: prepared.systemPrompt,
          type: 'text',
          cache_control: { type: 'ephemeral' }
        },
        ...prepared.extraSystemMessages
      ],
      mode: params.mode
    });

    return params.client.beta.messages.stream(
      {
        model: modelToUse,
        messages: [...prepared.initialMessages, ...prepared.filteredHistory],
        tools: finalTools.length > 0 ? finalTools : undefined,
        max_tokens: 4096,
        system: [
          {
            text: prepared.systemPrompt,
            type: 'text',
            cache_control: {
              type: 'ephemeral'
            }
          },
          ...prepared.extraSystemMessages
        ] as Anthropic.Beta.Messages.BetaTextBlockParam[],
        betas: TOOL_SEARCH_CONFIG.betaHeaders,
        // TODO: Disabled - terminal execution now handled by MCP terminal-execute tool
        // ...(skillsContainer && { container: skillsContainer as any }),
        tool_choice:
          finalTools.length > 0
            ? {
                type: 'auto',
                // Disable parallel tool use for welcome mode to prevent race conditions
                // during notebook opening (e.g., open_notebook + other tools simultaneously)
                disable_parallel_tool_use: params.mode === 'welcome'
              }
            : undefined
      } as any,
      {
        signal: params.abortSignal,
        headers: {
          ...(params.customHeaders || {}),
          'no-cors': 'true',
          'sec-fetch-mode': 'no-cors',
          mode: 'no-cors'
        }
      }
    );
  }

  /**
   * Prepares all messages and configuration for the API call
   */
  private static async prepareMessages(
    params: IMessageCreationParams,
    filteredHistory: any[],
    normalizeMessageContent: (
      messages: any[],
      errorLogger?: (message: any) => Promise<void>
    ) => any[]
  ): Promise<IPreparedMessages> {
    // Get notebook context
    const contextCellsContent = await this.getNotebookContext(params);

    // Prepare initial messages
    const initialMessages = this.prepareInitialMessages(contextCellsContent);

    // Normalize messages
    const normalizedInitialMessages = normalizeMessageContent(
      initialMessages,
      params.errorLogger
    );
    const normalizedFilteredHistory = normalizeMessageContent(
      filteredHistory,
      params.errorLogger
    );

    // Determine system prompt
    const systemPrompt = this.determineSystemPrompt(params);

    // Filter tools for fast mode
    const availableTools = this.filterTools(params);

    // Prepare extra system messages
    const extraSystemMessages = await this.prepareExtraSystemMessages(params);

    return {
      initialMessages: normalizedInitialMessages,
      filteredHistory: normalizedFilteredHistory,
      availableTools,
      systemPrompt,
      extraSystemMessages
    };
  }

  /**
   * Gets notebook context if available
   */
  private static async getNotebookContext(
    params: IMessageCreationParams
  ): Promise<string> {
    try {
      if (params.notebookContextManager && params.notebookId) {
        return params.notebookContextManager.formatContextAsMessage(
          params.notebookId
        );
      }
    } catch (error) {
      await params.errorLogger?.({
        message: 'Error getting notebook context',
        error: error instanceof Error ? error.message : error,
        notebookPath: params.notebookId,
        notebookContextManager: !!params.notebookContextManager
      });
    }
    return '';
  }

  /**
   * Prepares initial messages with context
   */
  private static prepareInitialMessages(contextCellsContent: string): any[] {
    const initialMessages = [];

    if (contextCellsContent && contextCellsContent.trim() !== '') {
      initialMessages.push({
        role: 'user',
        content: contextCellsContent
      });
    }

    return initialMessages;
  }

  /**
   * Determines which system prompt to use
   */
  private static determineSystemPrompt(params: IMessageCreationParams): string {
    let basePrompt: string;

    if (params.mode === 'ask') {
      basePrompt = params.systemPromptAskMode;
    } else if (params.mode === 'fast') {
      basePrompt = params.systemPromptFastMode;
    } else if (params.mode === 'welcome') {
      basePrompt = params.systemPromptWelcome;
    } else {
      basePrompt = params.systemPrompt;
    }

    // Add auto-run mode instructions if enabled
    if (params.autoRun) {
      basePrompt +=
        '\n\nYou are in auto-run mode. Do not wait or confirm steps with the user unless you hit a critical decision point. Continue until the problem is solved.';
    }

    return basePrompt;
  }

  /**
   * Filters tools based on fast mode settings and auto-run mode
   */
  private static filterTools(params: IMessageCreationParams): any[] {
    let filteredTools = params.tools;

    // Filter out blacklisted tools
    if (params.toolBlacklist.length > 0) {
      filteredTools = filteredTools.filter(
        tool => tool.name && !params.toolBlacklist.includes(tool.name)
      );
    }

    return filteredTools;
  }

  /**
   * Prepares extra system messages
   */
  private static async prepareExtraSystemMessages(
    params: IMessageCreationParams
  ): Promise<any[]> {
    const perfStart = performance.now();
    console.log('[PERF] prepareExtraSystemMessages - START');

    const extraSystemMessages: any[] = [];

    // Add system prompt messages
    const perfSystemPrompt = performance.now();
    if (params.systemPromptMessages) {
      extraSystemMessages.push(
        ...params.systemPromptMessages.map(msg => ({
          text: msg,
          type: 'text'
        }))
      );
    }
    console.log(
      `[PERF] prepareExtraSystemMessages - System prompts added (${(performance.now() - perfSystemPrompt).toFixed(2)}ms)`
    );

    // Add workspace context for welcome mode (notebooks only — LLM should use glob/grep for file discovery)
    const perfWorkspace = performance.now();
    if (params.mode === 'welcome') {
      const workspaceContext = getWorkspaceContext();
      if (workspaceContext && workspaceContext.welcome_context) {
        extraSystemMessages.push({
          type: 'text',
          text: `Workspace Context (notebook list only — use terminal-glob to discover data files):\n\n${workspaceContext.welcome_context}`
        });
        console.log(
          '[AnthropicMessageCreator] Added workspace context to welcome mode system messages'
        );
      }
    }
    console.log(
      `[PERF] prepareExtraSystemMessages - Workspace context added (${(performance.now() - perfWorkspace).toFixed(2)}ms)`
    );

    // Add rules context based on mode (three-mode rules system)
    const perfSnippets = performance.now();
    const allRules = useSnippetStore.getState().snippets;
    const insertedSnippets = useSnippetStore.getState().getInsertedSnippets();

    // 1. Inject ALWAYS APPLY rules (full content) - only active rules
    const alwaysRules = allRules.filter(
      r => r.mode === 'always' && r.active !== false
    );
    if (alwaysRules.length > 0) {
      const alwaysContent = alwaysRules
        .map(
          r => `=== Rule: ${r.title} ===\n${r.content}\n=== End ${r.title} ===`
        )
        .join('\n\n');

      extraSystemMessages.push({
        type: 'text',
        text: `<rules_always_apply>\nThe following rules ALWAYS apply to this conversation:\n\n${alwaysContent}\n</rules_always_apply>`
      });
      console.log(
        `[AnthropicMessageCreator] Added ${alwaysRules.length} always-apply rules`
      );
    }

    // 2. Inject INTELLIGENT rules as hints (filename + description + file path) - only active rules
    const intelligentRules = allRules.filter(
      r => r.mode === 'intelligent' && r.active !== false
    );
    if (intelligentRules.length > 0) {
      const hints = intelligentRules
        .map(r => `- "${r.filename}": ${r.description}`)
        .join('\n');

      extraSystemMessages.push({
        type: 'text',
        text: `<rules_available>
You can fetch additional context using the rules-get_rules tool.
- Fetch 1-3 rules per call (max 3)
- Session limit: 5 rules total
- After calling get_rules, the full rule content will be available in your next response
- Rule content appears in the <rules_fetched> section of your context

IMPORTANT: Use ONLY the filename exactly as shown (without .md extension, without path).
Rules are stored in: ~/SignalPilotHome/user-rules/

Available rules (use the quoted filename exactly):
${hints}
</rules_available>`
      });
      console.log(
        `[AnthropicMessageCreator] Added ${intelligentRules.length} intelligent rule hints`
      );
    }

    // 2b. Inject previously fetched rules from this session
    // Extract rule filenames from both chatStore state AND message history (for persistence across refresh)
    const storeRuleFilenames = useChatStore
      .getState()
      .getFetchedRuleFilenames();

    // Scan message history for rules-get_rules tool results to extract rule filenames
    const historyRuleFilenames: string[] = [];
    const llmHistory = useChatMessagesStore.getState().llmHistory;
    for (const msg of llmHistory) {
      if (msg.role === 'user' && Array.isArray(msg.content)) {
        for (const block of msg.content as any[]) {
          if (
            block.type === 'tool_result' &&
            typeof block.content === 'string'
          ) {
            try {
              const result = JSON.parse(block.content);
              // Check for loaded_rule_filenames (new format) or loaded_rule_ids (legacy)
              if (result.success && result.loaded_rule_filenames) {
                historyRuleFilenames.push(...result.loaded_rule_filenames);
              } else if (result.success && result.loaded_rule_ids) {
                // Legacy format - rule_ids were filename-like identifiers
                historyRuleFilenames.push(...result.loaded_rule_ids);
              }
            } catch {
              // Not JSON or not a rules result, skip
            }
          }
        }
      }
    }

    // Combine and deduplicate, limit to last 5
    const allUniqueRuleFilenames = [
      ...new Set([...storeRuleFilenames, ...historyRuleFilenames])
    ];
    const totalRulesFetched = allUniqueRuleFilenames.length;
    const SESSION_RULE_LIMIT = 10;
    const limitedRuleFilenames = allUniqueRuleFilenames.slice(
      -SESSION_RULE_LIMIT
    );
    const truncatedCount = totalRulesFetched - limitedRuleFilenames.length;

    if (limitedRuleFilenames.length > 0) {
      const fetchedRules = allRules.filter(r =>
        limitedRuleFilenames.includes(r.filename)
      );
      if (fetchedRules.length > 0) {
        const fetchedContent = fetchedRules
          .map(
            r =>
              `<rule filename="${r.filename}" title="${r.title}" description="${r.description}">\n${r.content}\n</rule>`
          )
          .join('\n\n');

        // Build the rules section with limit info if truncated
        let rulesText = `<rules_fetched>\nThe following rules were fetched earlier in this conversation:\n\n${fetchedContent}`;

        if (truncatedCount > 0) {
          rulesText += `\n\n<rules_limit_info>
Note: ${truncatedCount} older rule(s) were truncated due to the session limit of ${SESSION_RULE_LIMIT} rules.
Only the ${SESSION_RULE_LIMIT} most recently fetched rules are included above.
If you need a previously fetched rule that is no longer available, you can fetch it again using rules-get_rules.
</rules_limit_info>`;
        }

        rulesText += '\n</rules_fetched>';

        extraSystemMessages.push({
          type: 'text',
          text: rulesText
        });
        console.log(
          `[AnthropicMessageCreator] Added ${fetchedRules.length} previously fetched rules (total: ${totalRulesFetched}, truncated: ${truncatedCount})`
        );
      }
    }

    // 3. Inject MANUALLY inserted snippets (via @-mention)
    if (insertedSnippets.length > 0) {
      const snippetsContext = insertedSnippets
        .map(
          snippet =>
            `Snippet Title: ${snippet.title}\nSnippet Description: ${snippet.description ? `${snippet.description}\n` : ''} === Begin ${snippet.title} Content === \n\n${snippet.content}\n\n=== END ${snippet.title} Content ===`
        )
        .join('\n\n');

      extraSystemMessages.push({
        type: 'text',
        text: `The user has inserted the following code snippets for context:\n\n${snippetsContext}`
      });
    }
    console.log(
      `[PERF] prepareExtraSystemMessages - Rules added (${(performance.now() - perfSnippets).toFixed(2)}ms)`
    );

    // For welcome mode, skip notebook summary and kernel variables
    // but still include database configs
    if (params.mode === 'welcome') {
      console.log(
        '[AnthropicMessageCreator] Welcome mode - skipping notebook state and kernel variables'
      );

      // Add only database configurations for welcome mode
      const dbConfigs = this.getDatabaseConfigsString();
      if (dbConfigs) {
        extraSystemMessages.push({
          type: 'text',
          text: dbConfigs
        });
        console.log(
          '[AnthropicMessageCreator] Added database configs to welcome mode'
        );
      }
    } else {
      // Add notebook state (non-welcome modes)
      const perfNotebookState = performance.now();
      if (params.fetchNotebookState) {
        try {
          console.log(
            '[PERF] prepareExtraSystemMessages - Starting fetchNotebookState() call'
          );
          const perfBeforeFetch = performance.now();
          const notebookState = await params.fetchNotebookState();
          const perfAfterFetch = performance.now();
          console.log(
            `[PERF] prepareExtraSystemMessages - fetchNotebookState() returned (${(perfAfterFetch - perfBeforeFetch).toFixed(2)}ms)`
          );

          if (notebookState) {
            const perfBeforePush = performance.now();
            extraSystemMessages.push({
              type: 'text',
              text: `This is the current notebook summary with edit history: ${notebookState}`
            });
            console.log(
              `[PERF] prepareExtraSystemMessages - Notebook state pushed to messages (${(performance.now() - perfBeforePush).toFixed(2)}ms, state length: ${notebookState.length} chars)`
            );
          }
        } catch (error) {
          await params.errorLogger?.({
            message: 'Error fetching notebook state',
            error: error instanceof Error ? error.message : error,
            fetchNotebookState: !!params.fetchNotebookState
          });
        }
      }
      console.log(
        `[PERF] prepareExtraSystemMessages - Notebook state added (${(performance.now() - perfNotebookState).toFixed(2)}ms total)`
      );

      // Add kernel variables and objects preview (non-welcome modes)
      const perfKernelPreview = performance.now();
      try {
        const kernelPreview =
          await KernelPreviewUtils.getLimitedKernelPreview();
        console.log('KERNEL PREVIEW:', kernelPreview);

        const dburl = useSettingsStore.getState().databaseUrl;

        if (kernelPreview) {
          extraSystemMessages.push({
            type: 'text',
            text: `Current Kernel Variables and Objects Preview:\n\n${kernelPreview.replace(dburl, '<DB_URL>')}`
          });
        }
      } catch (error) {
        console.warn(
          '[AnthropicMessageCreator] Error getting kernel preview:',
          error
        );
        await params.errorLogger?.({
          message: 'Error getting kernel preview',
          error: error instanceof Error ? error.message : error
        });
      }
      console.log(
        `[PERF] prepareExtraSystemMessages - Kernel preview added (${(performance.now() - perfKernelPreview).toFixed(2)}ms)`
      );
    }

    const perfEnd = performance.now();
    console.log(
      `[PERF] prepareExtraSystemMessages - COMPLETE (${(perfEnd - perfStart).toFixed(2)}ms total)`
    );

    return extraSystemMessages;
  }

  /**
   * Get database configurations string for welcome mode
   * Returns a lean summary - detailed connection patterns are in database rules
   */
  private static getDatabaseConfigsString(): string {
    const dbConfigs = DatabaseStateService.getState().configurations;
    if (dbConfigs.length === 0) {
      return '';
    }

    let dbString = '=== AVAILABLE DATABASES ===\n';
    dbConfigs.forEach(db => {
      const prefix = getEnvVarPrefix(db.name);
      let line = `- ${db.name} (${db.type}) - env prefix: ${prefix}_`;

      // For Databricks, include auth type so LLM knows which connection pattern to use
      if (db.type === DatabaseType.Databricks) {
        const creds = db.credentials as { authType?: string };
        const authType = creds?.authType || 'pat';
        line += ` [auth: ${authType}]`;
      }

      dbString += line + '\n';
    });
    dbString +=
      '\nEnvironment variables are set in the kernel. ';
    dbString +=
      'Use `rules-get_rules` with the database type (e.g., "postgres", "snowflake") for connection patterns.\n';
    dbString += '=== END DATABASES ===\n';
    return dbString;
  }
}
