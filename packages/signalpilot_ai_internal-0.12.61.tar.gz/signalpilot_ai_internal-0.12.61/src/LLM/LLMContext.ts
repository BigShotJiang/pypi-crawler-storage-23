/**
 * LLMContext - Single source of truth for all context gathering
 *
 * All context is gathered through addContext() which branches into
 * simple, single-purpose methods. This file centralizes all the scattered
 * context sources into one readable location.
 */

import { useChatMessagesStore } from '../stores/chatMessages';
import { DatabaseStateService, DatabaseType } from '../stores/databaseStore';
import { getWorkspaceContext } from '../stores/appStore';
import { useSettingsStore } from '../stores/settingsStore';
import {
  getDatabaseEnvVarNames,
  getEnvVarPrefix
} from '../utils/databaseEnvVars';
import { useSnippetStore } from '../stores/snippetStore';
import { KernelPreviewUtils } from '../utils/kernelPreview';
import { NotebookContextManager } from '../Notebook/NotebookContextManager';
import { ToolService } from './ToolService';
import { ConfigService } from '../Config/ConfigService';
import { ChatMode, ILLMContext } from './LLMTypes';
import { getContentManager } from '../stores/servicesStore';

// Project memory file path
const PROJECT_MEMORY_PATH = 'SIGNALPILOT.md';

// Cache TTL in milliseconds (30 seconds)
const PROJECT_MEMORY_CACHE_TTL_MS = 30000;

// ═══════════════════════════════════════════════════════════════
// MAIN CLASS
// ═══════════════════════════════════════════════════════════════

/**
 * LLMContextGatherer - Centralizes all context gathering for LLM requests
 */
export class LLMContextGatherer {
  private toolService: ToolService;
  private notebookContextManager: NotebookContextManager;
  private projectMemoryCache: { content: string | null; timestamp: number } | null = null;

  constructor(
    toolService: ToolService,
    notebookContextManager: NotebookContextManager
  ) {
    this.toolService = toolService;
    this.notebookContextManager = notebookContextManager;
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN ENTRY POINT
  // ═══════════════════════════════════════════════════════════════

  /**
   * Gather all context needed for an LLM request.
   * This is the ONLY method external code should call.
   */
  async addContext(
    notebookId: string | null,
    mode: ChatMode,
    systemPromptMessages: string[] = []
  ): Promise<ILLMContext> {
    console.log(
      '[LLMContext] Gathering context for mode:',
      mode,
      'notebookId:',
      notebookId
    );
    const perfStart = performance.now();

    // Gather all context in parallel where possible with individual logging
    console.log('[LLMContext] Starting parallel context gathering...');
    const [
      notebookSummary,
      kernelVariables,
      workspaceContext,
      userSnippets,
      userSelectedCells
    ] = await Promise.all([
      this.getNotebookSummary(notebookId).then(r => {
        console.log('[LLMContext] notebookSummary done');
        return r;
      }),
      this.getKernelVariables().then(r => {
        console.log('[LLMContext] kernelVariables done');
        return r;
      }),
      Promise.resolve(this.getWorkspaceContext(mode)).then(r => {
        console.log('[LLMContext] workspaceContext done');
        return r;
      }),
      Promise.resolve(this.getUserSnippets()).then(r => {
        console.log('[LLMContext] userSnippets done');
        return r;
      }),
      Promise.resolve(this.getUserSelectedCells(notebookId)).then(r => {
        console.log('[LLMContext] userSelectedCells done');
        return r;
      })
    ]);
    console.log('[LLMContext] All parallel context gathered');

    console.log('[LLMContext] Getting system prompt...');
    const systemPrompt = await this.getSystemPrompt(mode, systemPromptMessages);
    console.log(
      '[LLMContext] System prompt loaded, length:',
      systemPrompt?.length || 0
    );

    const context: ILLMContext = {
      // Core context
      systemPrompt,
      conversationHistory: this.getConversationHistory(),

      // Dynamic context
      notebookSummary,
      notebookCells: '', // Included in notebookSummary
      kernelVariables,
      databaseConfigs: this.getDatabaseConfigs(),
      workspaceContext,
      userSnippets,
      userSelectedCells,

      // Metadata
      notebookId,
      mode,
      autoRun: useSettingsStore.getState().autoRun
    };

    const perfEnd = performance.now();
    console.log(
      `[LLMContext] Context gathered in ${(perfEnd - perfStart).toFixed(2)}ms`
    );

    return context;
  }

  // ═══════════════════════════════════════════════════════════════
  // CONTEXT ADDERS - Each does ONE thing
  // ═══════════════════════════════════════════════════════════════

  /**
   * Build the complete notebook state string for inclusion in API requests
   * This combines notebook summary and database configs
   */
  buildNotebookStateString(context: ILLMContext): string {
    let result = '';

    if (context.notebookSummary) {
      result += context.notebookSummary;
    }

    if (context.databaseConfigs) {
      result += context.databaseConfigs;
    }

    return result;
  }

  /**
   * Build the complete context string for debugging/logging
   */
  buildFullContextString(context: ILLMContext): string {
    const parts: string[] = [];

    if (context.systemPrompt) {
      parts.push('=== SYSTEM PROMPT ===\n' + context.systemPrompt);
    }

    if (context.notebookSummary) {
      parts.push(context.notebookSummary);
    }

    if (context.kernelVariables) {
      parts.push(context.kernelVariables);
    }

    if (context.databaseConfigs) {
      parts.push(context.databaseConfigs);
    }

    if (context.workspaceContext) {
      parts.push(context.workspaceContext);
    }

    if (context.userSnippets) {
      parts.push(context.userSnippets);
    }

    if (context.userSelectedCells) {
      parts.push(context.userSelectedCells);
    }

    return parts.join('\n\n');
  }

  /**
   * Get the conversation history from Zustand store
   */
  private getConversationHistory(): any[] {
    return useChatMessagesStore.getState().llmHistory || [];
  }

  /**
   * Get the system prompt based on mode
   */
  private async getSystemPrompt(
    mode: ChatMode,
    additionalMessages: string[]
  ): Promise<string> {
    try {
      const config = await ConfigService.getConfig();

      let basePrompt = '';
      switch (mode) {
        case 'ask':
          basePrompt = config.claude_ask_mode.system_prompt;
          break;
        case 'fast':
          basePrompt = config.fast_mode.system_prompt;
          break;
        case 'welcome':
          basePrompt = config.welcome_mode.system_prompt;
          break;
        default:
          basePrompt = config.claude.system_prompt;
      }

      // Append additional system prompt messages
      if (additionalMessages.length > 0) {
        basePrompt += '\n\n' + additionalMessages.join('\n\n');
      }

      // Append project memory if it exists
      const projectMemory = await this.getProjectMemory();
      if (projectMemory) {
        basePrompt += '\n\n' + projectMemory;
      }

      return basePrompt;
    } catch (error) {
      console.error('[LLMContext] Error loading system prompt:', error);
      return 'You are a helpful AI assistant for data science and notebook development.';
    }
  }

  /**
   * Read project memory from SIGNALPILOT.md in project root if it exists.
   * Caches result for PROJECT_MEMORY_CACHE_TTL_MS to avoid repeated file reads.
   */
  private async getProjectMemory(): Promise<string | null> {
    const now = Date.now();

    // Return cached value if still valid
    if (this.projectMemoryCache && now - this.projectMemoryCache.timestamp < PROJECT_MEMORY_CACHE_TTL_MS) {
      console.log('[LLMContext] Using cached project memory');
      return this.projectMemoryCache.content;
    }

    try {
      const contentManager = getContentManager();
      if (!contentManager) {
        this.projectMemoryCache = { content: null, timestamp: now };
        return null;
      }

      const file = await contentManager.get(PROJECT_MEMORY_PATH);
      if (file && file.content && typeof file.content === 'string') {
        console.log('[LLMContext] Loaded project memory from', PROJECT_MEMORY_PATH);
        const content = `=== PROJECT MEMORY ===\n\n${file.content}\n\n=== END PROJECT MEMORY ===`;
        this.projectMemoryCache = { content, timestamp: now };
        return content;
      }
      this.projectMemoryCache = { content: null, timestamp: now };
      return null;
    } catch (error) {
      // File doesn't exist - this is expected for new projects
      console.log('[LLMContext] No project memory file found (this is normal)');
      this.projectMemoryCache = { content: null, timestamp: now };
      return null;
    }
  }

  /**
   * Get notebook summary and cell information
   */
  private async getNotebookSummary(notebookId: string | null): Promise<string> {
    if (!notebookId) return '';

    try {
      // Ensure the tool service is using the correct notebook context
      this.toolService.setCurrentNotebookId(notebookId);

      const notebookSummary =
        await this.toolService.notebookTools?.getNotebookSummary(notebookId);

      if (!notebookSummary) return '';

      let summaryClean = '=== SUMMARY OF CELLS IN NOTEBOOK ===\n\n';

      notebookSummary.forEach((cell: any) => {
        if (cell.id === 'planning_cell') {
          summaryClean += '- SAGE PLANNING CELL -\n';
          summaryClean += `cell_index: ${cell.index}, cell_id: ${cell.id}, summary: ${cell.summary}, cell_type: ${cell.cell_type}, next_step_string: ${cell.next_step_string}, current_step_string: ${cell.current_step_string}, empty: ${cell.empty}\n`;
          summaryClean += '- END SAGE PLANNING CELL -';
        } else {
          summaryClean += `cell_id: ${cell.id}, summary: ${cell.summary}, cell_index: ${cell.index}, cell_type: ${cell.cell_type}, empty: ${cell.empty}`;
        }
        summaryClean += '\n\n';
      });

      summaryClean += '=== END SUMMARY OF CELLS IN NOTEBOOK ===\n\n';

      return summaryClean;
    } catch (error) {
      console.warn('[LLMContext] Error getting notebook summary:', error);
      return '';
    }
  }

  /**
   * Get current kernel variables and objects
   */
  private async getKernelVariables(): Promise<string> {
    try {
      const preview = await KernelPreviewUtils.getLimitedKernelPreview();
      if (!preview) return '';
      return preview;
    } catch (error) {
      console.warn('[LLMContext] Error getting kernel preview:', error);
      return '';
    }
  }

  /**
   * Get database configurations - lean summary with env var names
   * Detailed connection patterns are in database rules (postgres, mysql, snowflake, databricks)
   */
  private getDatabaseConfigs(): string {
    const dbConfigs = DatabaseStateService.getState().configurations;
    if (dbConfigs.length === 0) return '';

    let dbString = '=== DATABASE CONFIGURATIONS ===\n';

    dbConfigs.forEach(db => {
      const prefix = getEnvVarPrefix(db.name);
      dbString += `\nDatabase: ${db.name} (${db.type})\n`;
      dbString += `database_id: ${db.name}\n`;
      dbString += `Environment variable prefix: ${prefix}_\n`;

      // For Databricks, include auth type so LLM knows which connection pattern to use
      if (db.type === DatabaseType.Databricks) {
        const creds = db.credentials as { authType?: string };
        const authType = creds?.authType || 'pat';
        dbString += `Auth type: ${authType}\n`;
      }

      // List actual env var names
      const envVarNames = getDatabaseEnvVarNames(db);
      dbString += 'Available env vars: ' + envVarNames.join(', ') + '\n';
    });

    dbString += '\n=== END DATABASE CONFIGURATIONS ===\n';
    dbString +=
      '\nUse `rules-get_rules` with database type for connection patterns.\n';

    return dbString;
  }

  /**
   * Get workspace context (only for welcome mode)
   */
  private getWorkspaceContext(mode: ChatMode): string {
    if (mode !== 'welcome') return '';

    const context = getWorkspaceContext();
    if (!context?.welcome_context) return '';

    return `=== WORKSPACE CONTEXT ===\n\n${context.welcome_context}\n\n=== END WORKSPACE CONTEXT ===`;
  }

  // ═══════════════════════════════════════════════════════════════
  // UTILITY METHODS
  // ═══════════════════════════════════════════════════════════════

  /**
   * Get user-inserted code snippets
   */
  private getUserSnippets(): string {
    const snippets = useSnippetStore.getState().getInsertedSnippets();
    if (snippets.length === 0) return '';

    let result = '=== USER SNIPPETS ===\n\n';
    snippets.forEach(snippet => {
      result += `Title: ${snippet.title}\n${snippet.content}\n\n`;
    });
    result += '=== END USER SNIPPETS ===';

    return result;
  }

  /**
   * Get user-selected cells from NotebookContextManager
   */
  private getUserSelectedCells(notebookId: string | null): string {
    if (!notebookId) return '';
    return this.notebookContextManager.formatContextAsMessage(notebookId);
  }
}
