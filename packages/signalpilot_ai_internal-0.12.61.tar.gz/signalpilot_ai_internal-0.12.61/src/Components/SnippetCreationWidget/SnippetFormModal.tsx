import * as React from 'react';
// @ts-ignore - createPortal types may not be available in all environments
import { createPortal } from 'react-dom';
import { Button, Form, Modal } from 'react-bootstrap';
import { ISnippetFormProps } from './types';
import { RuleMode } from '../../stores/snippetStore';
import { EditorView, keymap, drawSelection, dropCursor, rectangularSelection, highlightActiveLine, highlightSpecialChars } from '@codemirror/view';
import { EditorState } from '@codemirror/state';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import { markdown } from '@codemirror/lang-markdown';
import { syntaxHighlighting, defaultHighlightStyle, indentOnInput, bracketMatching, indentUnit } from '@codemirror/language';
import { highlightSelectionMatches, searchKeymap } from '@codemirror/search';
import { jupyterTheme } from '@jupyterlab/codemirror';

// Mode icons as SVG components
// Always Apply icon - Lightning bolt
const AlwaysIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 10V3L4 14h7v7l9-11h-7z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Apply Intelligently icon - Lightbulb
const IntelligentIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Apply Manually icon - Cursor/pointer
const ManualIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Validation helpers
const estimateTokens = (text: string): number => Math.ceil(text.length / 4);

/**
 * Sanitize title to filename.
 *
 * IMPORTANT: This MUST match the backend logic in signalpilot_home.py UserRulesManager._sanitize_filename()
 * If you change this function, you MUST also update the backend version to match.
 *
 * Backend (Python):
 *   filename = re.sub(r'[^\w\s-]', '', title.lower())
 *   filename = re.sub(r'[-\s]+', '-', filename).strip('-')
 *   return filename[:50]
 */
const sanitizeFilename = (title: string): string => {
  // Step 1: Lowercase and remove special characters (keep word chars, whitespace, hyphens)
  let filename = title.toLowerCase().replace(/[^\w\s-]/g, '');
  // Step 2: Replace sequences of whitespace/hyphens with single hyphen, then strip leading/trailing hyphens
  filename = filename.replace(/[-\s]+/g, '-').replace(/^-+|-+$/g, '');
  // Step 3: Limit length to 50 characters
  return filename.slice(0, 50);
};

// Validation constants
const MAX_TITLE_TOKENS = 50;
const MAX_DESCRIPTION_TOKENS = 250;
const CONTENT_TOKEN_WARNING = 1000;

const MODE_OPTIONS: {
  value: RuleMode;
  label: string;
  icon: React.ReactNode;
  description: string;
  shortDescription: string;
}[] = [
  {
    value: 'always',
    label: 'Always',
    icon: <AlwaysIcon />,
    description: 'Always included in every conversation',
    shortDescription: 'Every request'
  },
  {
    value: 'intelligent',
    label: 'Auto',
    icon: <IntelligentIcon />,
    description: 'AI decides when to fetch this rule',
    shortDescription: 'When relevant'
  },
  {
    value: 'manual',
    label: 'Manual',
    icon: <ManualIcon />,
    description: 'Only included when you @mention it',
    shortDescription: 'On demand'
  }
];

/**
 * Modal component for creating/editing snippets
 */
export function SnippetFormModal({
  title,
  description,
  content,
  mode,
  isEditing,
  existingSnippets,
  editingSnippetFilename,
  disableTitleEdit,
  onSave,
  onClose,
  onTitleChange,
  onDescriptionChange,
  onContentChange,
  onModeChange
}: ISnippetFormProps): JSX.Element {
  // Use local React state to prevent cursor jumping
  const [localTitle, setLocalTitle] = React.useState(title);
  const [localDescription, setLocalDescription] = React.useState(description);
  const [localContent, setLocalContent] = React.useState(content);
  const [localMode, setLocalMode] = React.useState<RuleMode>(mode);

  // CodeMirror state
  const [showCodeMirror, setShowCodeMirror] = React.useState(false);
  const [codeMirrorContent, setCodeMirrorContent] = React.useState('');
  const editorRef = React.useRef<HTMLDivElement>(null);
  const editorViewRef = React.useRef<EditorView | null>(null);

  // Update local state when props change (e.g., when editing a different snippet)
  React.useEffect(() => {
    setLocalTitle(title);
  }, [title]);

  React.useEffect(() => {
    setLocalDescription(description);
  }, [description]);

  React.useEffect(() => {
    setLocalContent(content);
  }, [content]);

  React.useEffect(() => {
    setLocalMode(mode);
  }, [mode]);

  // Initialize CodeMirror when overlay opens
  React.useEffect(() => {
    if (showCodeMirror && editorRef.current && !editorViewRef.current) {
      const updateListener = EditorView.updateListener.of(update => {
        if (update.docChanged) {
          setCodeMirrorContent(update.state.doc.toString());
        }
      });

      const startState = EditorState.create({
        doc: codeMirrorContent,
        extensions: [
          // Core editing features
          highlightSpecialChars(),
          history(),
          drawSelection(),
          dropCursor(),
          rectangularSelection(),
          highlightActiveLine(),
          highlightSelectionMatches(),

          // Markdown language support
          markdown(),
          syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
          bracketMatching(),
          indentOnInput(),
          indentUnit.of('  '),

          // Keybindings
          keymap.of([
            indentWithTab,
            ...defaultKeymap,
            ...searchKeymap,
            ...historyKeymap
          ]),

          // Theme and settings
          jupyterTheme,
          updateListener,
          EditorView.theme({
            '&': {
              height: '100%',
              fontSize: '13px'
            },
            '.cm-content': {
              padding: '12px 16px',
              fontFamily: 'var(--jp-code-font-family)'
            },
            '.cm-focused': {
              outline: 'none'
            },
            '.cm-editor': {
              height: '100%'
            },
            '.cm-scroller': {
              overflow: 'auto'
            }
          }),
          EditorView.lineWrapping
        ]
      });

      editorViewRef.current = new EditorView({
        state: startState,
        parent: editorRef.current
      });

      // Focus the editor after creation
      setTimeout(() => {
        if (editorViewRef.current) {
          editorViewRef.current.focus();
        }
      }, 50);
    }

    return () => {
      if (editorViewRef.current) {
        editorViewRef.current.destroy();
        editorViewRef.current = null;
      }
    };
  }, [showCodeMirror]);

  // Handle opening CodeMirror
  const handleOpenCodeMirror = () => {
    setCodeMirrorContent(localContent);
    setShowCodeMirror(true);
  };

  // Handle applying CodeMirror changes
  const handleApplyCodeMirror = () => {
    handleContentChange(codeMirrorContent);
    setShowCodeMirror(false);
  };

  // Handle canceling CodeMirror
  const handleCancelCodeMirror = () => {
    setShowCodeMirror(false);
  };

  // Handle local state changes and notify parent
  const handleTitleChange = (value: string) => {
    setLocalTitle(value);
    onTitleChange(value);
  };

  const handleDescriptionChange = (value: string) => {
    setLocalDescription(value);
    onDescriptionChange(value);
  };

  const handleContentChange = (value: string) => {
    setLocalContent(value);
    onContentChange(value);
  };

  const handleModeChange = (newMode: RuleMode) => {
    setLocalMode(newMode);
    onModeChange(newMode);
  };

  // Validation computed values
  const titleTokens = estimateTokens(localTitle);
  const descriptionTokens = estimateTokens(localDescription);
  const contentTokens = estimateTokens(localContent);

  // Check for duplicate title (by comparing sanitized filenames)
  const newFilename = sanitizeFilename(localTitle);
  const isDuplicateTitle = React.useMemo(() => {
    if (!newFilename) return false;
    return existingSnippets.some(snippet => {
      // Skip the current snippet being edited
      if (
        editingSnippetFilename &&
        snippet.filename === editingSnippetFilename
      ) {
        return false;
      }
      return snippet.filename === newFilename;
    });
  }, [newFilename, existingSnippets, editingSnippetFilename]);

  const isTitleValid =
    localTitle.trim().length > 0 &&
    titleTokens <= MAX_TITLE_TOKENS &&
    (disableTitleEdit || !isDuplicateTitle);
  const isDescriptionValid =
    localDescription.trim().length > 0 &&
    descriptionTokens <= MAX_DESCRIPTION_TOKENS;
  const isContentWarning = contentTokens > CONTENT_TOKEN_WARNING;
  const canSave = isTitleValid && localContent.trim() && isDescriptionValid;

  // Handle form submission with Enter key
  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      if (canSave) {
        onSave();
      }
    }
  };

  return (
    <>
      <Modal
        show={true}
        onHide={onClose}
        backdrop="static"
        keyboard={true}
        enforceFocus={!showCodeMirror}
        onKeyDown={handleKeyDown}
        dialogClassName="sage-ai-rule-edit-fullscreen"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isEditing ? 'Edit Rule' : 'Create New Rule'}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body className="sage-ai-rule-form-body">
          <Form className="sage-ai-rule-form">
            {/* Name field */}
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                value={localTitle}
                onChange={e => handleTitleChange(e.target.value)}
                placeholder="Enter rule name..."
                autoFocus={!disableTitleEdit}
                disabled={disableTitleEdit}
                isInvalid={
                  !disableTitleEdit &&
                  localTitle.trim().length > 0 &&
                  (titleTokens > MAX_TITLE_TOKENS || isDuplicateTitle)
                }
              />
              <div
                className={`sage-ai-field-hint ${!disableTitleEdit && (titleTokens > MAX_TITLE_TOKENS || isDuplicateTitle) ? 'error' : ''}`}
              >
                {disableTitleEdit ? (
                  <span>Name cannot be changed for default rules</span>
                ) : isDuplicateTitle ? (
                  <span>A rule with this name already exists</span>
                ) : (
                  <>
                    ~{titleTokens}/{MAX_TITLE_TOKENS} tokens
                    {titleTokens > MAX_TITLE_TOKENS && ' (too long)'}
                  </>
                )}
              </div>
            </Form.Group>

            {/* Description field */}
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                value={localDescription}
                onChange={e => handleDescriptionChange(e.target.value)}
                placeholder="Brief description (used for AI hints)..."
                isInvalid={
                  localDescription.trim().length > 0 &&
                  descriptionTokens > MAX_DESCRIPTION_TOKENS
                }
              />
              <div
                className={`sage-ai-field-hint ${descriptionTokens > MAX_DESCRIPTION_TOKENS ? 'error' : ''}`}
              >
                ~{descriptionTokens}/{MAX_DESCRIPTION_TOKENS} tokens
                {descriptionTokens > MAX_DESCRIPTION_TOKENS && ' (too long)'}
              </div>
            </Form.Group>

            {/* Content field - flex-grow to fill space */}
            <Form.Group className="mb-3 sage-ai-rule-content-group">
              <div className="sage-ai-rule-content-label-row">
                <Form.Label>Content</Form.Label>
                <button
                  type="button"
                  className="sage-ai-edit-markdown-link"
                  onClick={handleOpenCodeMirror}
                >
                  Edit as markdown
                </button>
              </div>
              <Form.Control
                as="textarea"
                className="sage-ai-rule-content-textarea"
                value={localContent}
                onChange={e => handleContentChange(e.target.value)}
                placeholder="Your code, markdown, or text content..."
              />
              <div
                className={`sage-ai-field-hint ${isContentWarning ? 'warning' : ''}`}
              >
                ~{contentTokens.toLocaleString()} tokens
                {isContentWarning && ` (large rules may impact performance)`}
              </div>
            </Form.Group>

            {/* Mode selector - horizontal boxes at bottom */}
            <Form.Group className="mb-3">
              <Form.Label>Injection Mode</Form.Label>
              <div className="sage-ai-mode-selector-horizontal">
                {MODE_OPTIONS.map(option => (
                  <button
                    key={option.value}
                    type="button"
                    className={`sage-ai-mode-box ${localMode === option.value ? 'selected' : ''}`}
                    data-mode={option.value}
                    onClick={() => handleModeChange(option.value)}
                  >
                    <span className="sage-ai-mode-box-icon">{option.icon}</span>
                    <span className="sage-ai-mode-box-label">
                      {option.label}
                    </span>
                    <span className="sage-ai-mode-box-desc">
                      {option.shortDescription}
                    </span>
                  </button>
                ))}
              </div>
            </Form.Group>
          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={onSave}
            disabled={!canSave}
            title={
              !canSave
                ? !localTitle.trim()
                  ? 'Name is required'
                  : isDuplicateTitle
                    ? 'A rule with this name already exists'
                    : titleTokens > MAX_TITLE_TOKENS
                      ? `Name must be ${MAX_TITLE_TOKENS} tokens or less`
                      : !localDescription.trim()
                        ? 'Description is required'
                        : descriptionTokens > MAX_DESCRIPTION_TOKENS
                          ? `Description must be ${MAX_DESCRIPTION_TOKENS} tokens or less`
                          : !localContent.trim()
                            ? 'Content is required'
                            : `${isEditing ? 'Update' : 'Save'} rule (Ctrl+Enter)`
                : `${isEditing ? 'Update' : 'Save'} rule (Ctrl+Enter)`
            }
          >
            {isEditing ? 'Update' : 'Save'}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* CodeMirror full-screen overlay - rendered via portal to document.body */}
      {showCodeMirror && createPortal(
        <div className="sage-ai-codemirror-overlay">
          <div className="sage-ai-codemirror-header">
            <span className="sage-ai-codemirror-title">Edit Content</span>
            <div className="sage-ai-codemirror-actions">
              <Button variant="secondary" onClick={handleCancelCodeMirror}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleApplyCodeMirror}>
                Apply
              </Button>
            </div>
          </div>
          <div className="sage-ai-codemirror-editor" ref={editorRef} />
        </div>,
        document.body
      )}
    </>
  );
}
