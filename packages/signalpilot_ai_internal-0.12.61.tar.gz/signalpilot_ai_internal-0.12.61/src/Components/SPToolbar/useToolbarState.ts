import { useState, useEffect } from 'react';
import { NotebookPanel } from '@jupyterlab/notebook';
import { IKernelConnection } from '@jupyterlab/services/lib/kernel/kernel';

export interface ToolbarState {
  kernelName: string;
  kernelStatus: string;
  cellType: string;
  isKernelBusy: boolean;
}

export function useToolbarState(panel: NotebookPanel): ToolbarState {
  const [kernelName, setKernelName] = useState('No Kernel');
  const [kernelStatus, setKernelStatus] = useState('idle');
  const [cellType, setCellType] = useState('code');

  useEffect(() => {
    const sessionContext = panel.sessionContext;

    // --- Kernel name + status ---
    const updateKernelInfo = () => {
      const name =
        sessionContext.kernelDisplayName ||
        sessionContext.session?.kernel?.name ||
        'No Kernel';
      setKernelName(name);
    };

    const handleStatusChanged = (
      _sender: IKernelConnection,
      status: string
    ) => {
      setKernelStatus(status);
    };

    const connectKernelSignals = () => {
      const kernel = sessionContext.session?.kernel;
      if (kernel) {
        kernel.statusChanged.connect(handleStatusChanged);
        setKernelStatus(kernel.status);
      }
      updateKernelInfo();
    };

    const handleKernelChanged = () => {
      // Disconnect from old kernel if any
      const kernel = sessionContext.session?.kernel;
      if (kernel) {
        kernel.statusChanged.disconnect(handleStatusChanged);
      }
      // Reconnect to new kernel after short delay
      setTimeout(connectKernelSignals, 100);
    };

    // --- Cell type ---
    const handleActiveCellChanged = () => {
      const activeCell = panel.content.activeCell;
      if (activeCell) {
        setCellType(activeCell.model.type);
      }
    };

    // Initial state
    connectKernelSignals();
    handleActiveCellChanged();

    // Connect signals
    sessionContext.kernelChanged.connect(handleKernelChanged);
    sessionContext.statusChanged.connect((_sender, status) => {
      setKernelStatus(status);
    });
    panel.content.activeCellChanged.connect(handleActiveCellChanged);

    // Wait for session to be ready, then update
    void sessionContext.ready.then(() => {
      connectKernelSignals();
    });

    return () => {
      const kernel = sessionContext.session?.kernel;
      if (kernel) {
        kernel.statusChanged.disconnect(handleStatusChanged);
      }
      sessionContext.kernelChanged.disconnect(handleKernelChanged);
      panel.content.activeCellChanged.disconnect(handleActiveCellChanged);
    };
  }, [panel]);

  return {
    kernelName,
    kernelStatus,
    cellType,
    isKernelBusy: kernelStatus === 'busy'
  };
}
