import React, { useState, useRef, useEffect, useCallback } from 'react';
import { NotebookPanel, NotebookActions } from '@jupyterlab/notebook';
import { ChevronDownIcon } from './ToolbarIcons';

interface CellTypeDropdownProps {
  panel: NotebookPanel;
  cellType: string;
}

const CELL_TYPES = [
  { value: 'code', label: 'Code' },
  { value: 'markdown', label: 'Markdown' },
  { value: 'raw', label: 'Raw' }
] as const;

const displayLabel = (type: string): string => {
  const found = CELL_TYPES.find(ct => ct.value === type);
  return found ? found.label : 'Code';
};

export const CellTypeDropdown: React.FC<CellTypeDropdownProps> = ({
  panel,
  cellType
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleSelect = useCallback(
    (type: string) => {
      NotebookActions.changeCellType(panel.content, type as any);
      setIsOpen(false);
    },
    [panel]
  );

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  return (
    <div className="sp-toolbar-dropdown" ref={containerRef}>
      <button
        className="sp-toolbar-dropdown-trigger"
        onClick={() => setIsOpen(!isOpen)}
        title="Cell type"
      >
        <span>{displayLabel(cellType)}</span>
        <ChevronDownIcon size={12} />
      </button>
      {isOpen && (
        <div className="sp-toolbar-dropdown-menu">
          {CELL_TYPES.map(ct => (
            <button
              key={ct.value}
              className={`sp-toolbar-dropdown-item ${
                ct.value === cellType ? 'sp-toolbar-dropdown-item--active' : ''
              }`}
              onClick={() => handleSelect(ct.value)}
            >
              {ct.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
