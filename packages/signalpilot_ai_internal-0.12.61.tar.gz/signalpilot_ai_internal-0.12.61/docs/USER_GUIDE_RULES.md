# Rules System User Guide

This guide explains how to use the Rules system in Sage Agent to customize AI behavior and provide domain-specific context.

---

## Overview

Rules are reusable pieces of context, instructions, or templates that help the AI assistant understand your preferences, coding standards, domain knowledge, and workflows.

The Rules system supports **three application modes** that control when and how each rule is used:

| Mode | Icon | When Applied | Best For |
|------|------|--------------|----------|
| **Always** | Infinity (∞) | Every conversation automatically | Core conventions, style guides, coding standards |
| **Auto** | Brain (🧠) | AI decides when relevant | Domain knowledge, playbooks, specialized instructions |
| **Manual** | Pointer (👆) | Only when you @mention it | Niche rules, situational context, rarely used templates |

---

## Creating Rules

1. Open the **Rules** panel in the Sage Agent sidebar
2. Click the **+** button to create a new rule
3. Fill in the form:
   - **Title**: A short, descriptive name
   - **Description**: Brief summary (required, max 50 words) - used as hints for Auto mode
   - **When to Apply**: Select one of the three modes
   - **Content**: The full rule content (markdown, code, or instructions)
4. Click **Save**

---

## Application Modes Explained

### Always Mode (∞)

Rules in Always mode are automatically included in every conversation. Use this for:

- Coding style guides (e.g., "Always use TypeScript strict mode")
- Project conventions (e.g., "Use snake_case for database columns")
- Important constraints (e.g., "Never expose API keys in code")

**Token Budget:** Always-apply rules share a total budget of ~2,000 tokens across all rules.

### Auto Mode (🧠)

Rules in Auto mode show the AI a hint (title + description). The AI decides whether to fetch the full content based on relevance to your question.

Use this for:
- Domain-specific knowledge (e.g., database schemas, API documentation)
- Specialized workflows (e.g., deployment procedures, testing strategies)
- Reference materials (e.g., company policies, technical specifications)

**How it works:**
1. The AI sees a summary of available Auto rules (title + description)
2. When relevant, the AI uses the `get_rules` tool to request rules by ID
3. The tool returns only a reference (rule IDs) - the full content is injected into the AI's context on the next response
4. Fetched rules persist for the entire conversation thread (even after page refresh)
5. Only the **last 5 fetched rules** are kept in context - older rules are automatically truncated

**Limits per thread:**
- Maximum **5 rules** in context at a time (most recent)
- Maximum 20,000 tokens total for fetched rules
- If more than 5 rules are fetched, the AI is informed which rules were truncated and can re-fetch them if needed

### Manual Mode (👆)

Rules in Manual mode are only included when you explicitly mention them using the `@` symbol in your message.

Use this for:
- Rarely used templates
- Situational context
- Optional guidelines

**How to use:**
1. Type `@` in the chat input
2. Select "Rules" from the context menu
3. Choose the rule you want to include
4. The rule content will be added to your message

---

## Token Budgets

To ensure efficient AI responses, the Rules system enforces token limits:

| Budget Type | Limit | Description |
|-------------|-------|-------------|
| Always-apply rules | ~2,000 tokens | Combined budget for all Always mode rules |
| Auto-mode hints | ~300 tokens | Space for rule summaries shown to AI |
| Session fetched rules | 20,000 tokens | Maximum content fetched via get_rules per thread |
| Rules in context | 5 rules | Only the 5 most recently fetched rules are kept in context |

The form shows approximate token counts to help you stay within limits.

---

## Best Practices

### Choosing the Right Mode

| If the rule... | Use |
|----------------|-----|
| Applies to every conversation | Always |
| Applies to specific domains/tasks | Auto |
| Is rarely needed or very specific | Manual |

### Writing Effective Rules

1. **Keep Always rules concise** - They're included every time, so brevity matters
2. **Write clear descriptions for Auto rules** - The AI uses these to decide relevance
3. **Use structured formats** - Markdown headings, bullet points, and code blocks improve clarity
4. **Include examples** - Show the AI what you expect with concrete examples
5. **Be specific** - Vague rules produce vague results

### Example Rules

**Always Mode - Coding Standard:**
```markdown
## TypeScript Standards

- Use strict mode
- Prefer interfaces over type aliases
- Always handle errors explicitly
- Use async/await instead of .then()
```

**Auto Mode - Database Reference:**
```markdown
## Customer Database Schema

### customers table
- id: UUID (primary key)
- email: VARCHAR(255) (unique)
- created_at: TIMESTAMP
- subscription_tier: ENUM('free', 'pro', 'enterprise')

### orders table
- id: UUID (primary key)
- customer_id: UUID (foreign key -> customers)
- total_amount: DECIMAL(10,2)
- status: ENUM('pending', 'completed', 'cancelled')
```

**Manual Mode - Release Checklist:**
```markdown
## Release Checklist

1. Run full test suite
2. Update CHANGELOG.md
3. Bump version in package.json
4. Create git tag
5. Deploy to staging
6. Verify staging deployment
7. Deploy to production
8. Verify production deployment
9. Announce in #releases channel
```

---

## Troubleshooting

### "Session limit reached" message
You've fetched more than 5 Auto rules in this conversation. The AI will automatically keep only the 5 most recently fetched rules in context. Older rules are truncated but can be re-fetched if needed. The AI is informed about truncated rules and can decide to re-fetch them.

### "Token limit reached" error
The combined content of fetched rules exceeds 20,000 tokens. Consider:
- Breaking large rules into smaller, focused rules
- Using Manual mode for very large references
- Starting a new thread

### Rule not appearing in @mention menu
Only Manual mode rules appear in the @mention autocomplete. Always and Auto rules are handled automatically.

### Changes not taking effect
Rules are cached at the start of each conversation. Start a new thread to pick up changes to rule content.

### Rules persist after page refresh
Fetched Auto rules are extracted from the conversation history, so they persist even after refreshing the page. Only the 5 most recently fetched rules are kept in context.
