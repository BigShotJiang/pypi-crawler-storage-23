c.ServerApp.tornado_settings = {'headers': {'Content-Security-Policy': "frame-ancestors *"}}
