# etl

Data wrangling utilities: smoothing, cross-correlation, JSON with complex numbers,
time conversions, and more.

```{eval-rst}
.. automodule:: matviz.etl
   :members:
   :show-inheritance:
```
