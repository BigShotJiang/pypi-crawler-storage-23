# circle_utils

Smallest enclosing circle and convex hull area for complex-valued point sets.

```{eval-rst}
.. automodule:: matviz.circle_utils
   :members: cmake_circle, cmake_circle2, cget_area
   :show-inheritance:
```
