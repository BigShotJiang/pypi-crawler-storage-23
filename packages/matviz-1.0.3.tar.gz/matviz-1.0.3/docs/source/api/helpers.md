# helpers

Convenience module that imports everything into a MATLAB-like environment.
Import with `from matviz.helpers import *` to get all matviz functions plus
common NumPy, Matplotlib, and SciPy imports.

```{eval-rst}
.. automodule:: matviz.helpers
   :members:
   :show-inheritance:
```
