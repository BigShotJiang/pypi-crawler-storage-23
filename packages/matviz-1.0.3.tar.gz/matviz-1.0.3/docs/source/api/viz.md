# viz

Visualization functions for matplotlib: plot ranges, streamgraphs, log-fitting,
polar grids, complex number plotting, and more.

```{eval-rst}
.. automodule:: matviz.viz
   :members:
   :show-inheritance:
```
