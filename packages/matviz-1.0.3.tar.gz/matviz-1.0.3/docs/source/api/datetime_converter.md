# datetime_converter

Reversible timestamp-to-integer codec for datetime, numpy.datetime64, and pandas.Timestamp.

```{eval-rst}
.. automodule:: matviz.datetime_converter
   :members:
   :show-inheritance:
```
