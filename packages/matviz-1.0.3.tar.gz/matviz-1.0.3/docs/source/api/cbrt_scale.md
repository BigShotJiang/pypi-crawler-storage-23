# cbrt_scale

Custom matplotlib scale for cube-root axis scaling.

```{eval-rst}
.. automodule:: matviz.cbrt_scale
   :members:
   :show-inheritance:
```
