# doctools

PDF utilities for extracting images and compressing PDFs.

```{eval-rst}
.. automodule:: matviz.doctools
   :members:
   :show-inheritance:
```
