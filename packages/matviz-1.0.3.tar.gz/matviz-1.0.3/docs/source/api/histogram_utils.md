# histogram_utils

Smart 1D and 2D histograms with automatic binning using Scott's normal reference rule.

```{eval-rst}
.. automodule:: matviz.histogram_utils
   :members: nhist, ndhist
   :show-inheritance:
```
