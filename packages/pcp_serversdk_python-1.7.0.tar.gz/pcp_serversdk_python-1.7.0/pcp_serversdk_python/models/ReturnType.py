from enum import Enum


class ReturnType(str, Enum):
    FULL = "FULL"
    PARTIAL = "PARTIAL"
