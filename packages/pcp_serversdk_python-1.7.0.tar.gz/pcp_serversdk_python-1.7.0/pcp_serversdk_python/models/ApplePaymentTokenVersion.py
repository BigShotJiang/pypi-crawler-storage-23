from enum import Enum


class ApplePaymentTokenVersion(str, Enum):
    EC_V1 = "EC_V1"
