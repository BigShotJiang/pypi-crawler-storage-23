"""WickServer — lifecycle manager for the wick_go agent server.

    from wick_deep_agent import WickServer

    # Zero-config start (no agents pre-loaded, add via API):
    server = WickServer(port=8003)

    # Inline agent config (no YAML file needed):
    server = WickServer(port=8003, agents={
        "default": {
            "name": "Ollama Local",
            "model": "ollama:llama3.1:8b",
            "system_prompt": "You are a helpful assistant.",
        }
    })

    server.build()
    server.start()
    server.wait_ready()
    server.stop()

    # Or as a context manager:
    with WickServer(port=8003) as srv:
        print(srv.status())
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from .model import ModelDef


STATE_DIR = Path.home() / ".wick_deep_agent"
DEFAULT_PID_FILE = STATE_DIR / "wick_go.pid"
DEFAULT_LOG_FILE = STATE_DIR / "wick_go.log"

_PACKAGE_DIR = Path(__file__).resolve().parent
_BIN_NAME = "wick_go.exe" if sys.platform == "win32" else "wick_go"
_BUNDLED_BINARY = _PACKAGE_DIR / "bin" / _BIN_NAME


class _ConfigEncoder(json.JSONEncoder):
    """JSON encoder that serializes ModelDef as a placeholder proxy spec."""

    def default(self, o: Any) -> Any:
        if isinstance(o, ModelDef):
            # Placeholder — callback_url is filled in by _rewrite_proxy_models()
            return {"provider": "proxy", "model": o.name}
        return super().default(o)


class WickServer:
    """Manages the wick_go server process.

    Config resolution (first match wins):
        1. ``config="/path/to/agents.yaml"`` — explicit file path
        2. ``agents={...}`` — Python dict, auto-written to a temp file
        3. ``WICK_CONFIG`` env var
        4. No config — server starts with zero agents (add via REST API)
    """

    def __init__(
        self,
        binary: str | None = None,
        config: str | None = None,
        agents: dict[str, Any] | None = None,
        defaults: dict[str, Any] | None = None,
        port: int = 8000,
        host: str = "0.0.0.0",
        env: dict[str, str] | None = None,
        log_file: str | None = None,
        tools: list | None = None,
    ) -> None:
        self.port = port
        self.host = host
        self.extra_env = env or {}
        self.log_path = Path(log_file) if log_file else DEFAULT_LOG_FILE

        self._agents = agents
        self._defaults = defaults
        self.binary = self._resolve_binary(binary)
        self.config = self._resolve_config(config, agents, defaults)

        self._log_fh: Any = None
        self._owns_config = config is None and agents is not None
        self._tools = tools
        self._tool_server: Any = None  # Optional[ToolServer]

    # -- Resolution ----------------------------------------------------------

    @staticmethod
    def _resolve_binary(explicit: str | None) -> str:
        if explicit:
            return explicit
        from_env = os.environ.get("WICK_GO_BINARY")
        if from_env:
            return from_env
        # Bundled binary (pip install)
        if _BUNDLED_BINARY.exists() and os.access(str(_BUNDLED_BINARY), os.X_OK):
            return str(_BUNDLED_BINARY)
        # Dev mode — adjacent server/ dir
        dev_binary = _PACKAGE_DIR.parent / "server" / _BIN_NAME
        if dev_binary.exists():
            return str(dev_binary)
        raise FileNotFoundError(
            "wick_go binary not found. Install a platform wheel, "
            "set WICK_GO_BINARY, or pass binary= explicitly."
        )

    @staticmethod
    def _resolve_config(
        explicit: str | None,
        agents: dict[str, Any] | None,
        defaults: dict[str, Any] | None,
    ) -> str:
        # 1. Explicit file path
        if explicit:
            return explicit

        # 2. Inline agents dict → write temp config (JSON is valid YAML)
        if agents is not None:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            cfg_path = STATE_DIR / "agents.json"
            config_data: dict[str, Any] = {"agents": agents}
            if defaults:
                config_data["defaults"] = defaults
            cfg_path.write_text(json.dumps(config_data, indent=2, cls=_ConfigEncoder))
            return str(cfg_path)

        # 3. Environment variable
        from_env = os.environ.get("WICK_CONFIG")
        if from_env:
            return from_env

        # 4. No config — write an empty config so server starts clean
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        cfg_path = STATE_DIR / "agents.json"
        cfg_path.write_text(json.dumps({"agents": {}}, indent=2))
        return str(cfg_path)

    # -- Build ---------------------------------------------------------------

    @staticmethod
    def build(source_dir: str | None = None) -> None:
        """Compile the Go server binary (dev mode)."""
        src = Path(source_dir) if source_dir else (_PACKAGE_DIR.parent / "server")
        if not (src / "main.go").exists():
            raise FileNotFoundError(f"main.go not found in {src}")

        result = subprocess.run(
            ["go", "build", "-o", _BIN_NAME, "."],
            cwd=str(src),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"go build failed:\n{result.stderr}")

    # -- Start / Stop --------------------------------------------------------

    def _collect_models_from_agents(self) -> list[ModelDef]:
        """Scan agent configs for ModelDef instances in the 'model' field."""
        models: list[ModelDef] = []
        if not self._agents:
            return models
        seen: set[str] = set()
        for agent_cfg in self._agents.values():
            m = agent_cfg.get("model")
            if isinstance(m, ModelDef) and m.name not in seen:
                models.append(m)
                seen.add(m.name)
        return models

    def _rewrite_proxy_models(self) -> None:
        """Replace ModelDef references in agent configs with proxy provider spec."""
        if not self._agents or not self._tool_server:
            return
        callback_url = self._tool_server.callback_url
        for agent_cfg in self._agents.values():
            m = agent_cfg.get("model")
            if isinstance(m, ModelDef):
                agent_cfg["model"] = {
                    "provider": "proxy",
                    "model": m.name,
                    "callback_url": callback_url,
                }
        # Rewrite the config file with resolved model specs
        self.config = self._resolve_config(None, self._agents, self._defaults)

    def start(self) -> int:
        """Start the server in the background. Returns the PID."""
        # Collect custom model handlers from agent configs
        models = self._collect_models_from_agents()

        # Start the tool/model sidecar server before the Go binary
        if (self._tools or models) and self._tool_server is None:
            from .tool import ToolServer

            self._tool_server = ToolServer(
                tools=self._tools or [],
                models=models,
            )
            self._tool_server.start()

        # Rewrite agent configs to inject proxy provider specs
        if models:
            self._rewrite_proxy_models()

        info = self.status()
        if info["running"]:
            return info["pid"]

        STATE_DIR.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        env["PORT"] = str(self.port)
        env["HOST"] = self.host
        env.update(self.extra_env)

        self._log_fh = open(self.log_path, "a")  # noqa: SIM115
        proc = subprocess.Popen(
            [self.binary, "-config", self.config],
            env=env,
            stdout=self._log_fh,
            stderr=subprocess.STDOUT,
        )
        # Close parent's copy — the child inherited the fd.
        self._log_fh.close()
        self._log_fh = None

        DEFAULT_PID_FILE.write_text(str(proc.pid))
        return proc.pid

    def register_tools(self) -> None:
        """Register external tools with the running Go server."""
        if not self._tool_server or not self._tool_server.is_alive:
            return

        import requests as _requests

        url = f"http://localhost:{self.port}/agents/tools/register"
        for td in self._tool_server.tool_defs:
            schema = td.to_schema(self._tool_server.callback_url)
            resp = _requests.post(url, json=schema, timeout=5)
            resp.raise_for_status()

    def stop(self) -> None:
        """Stop the server and tool sidecar."""
        # Stop tool server first
        if self._tool_server is not None:
            self._tool_server.stop()
            self._tool_server = None

        if not DEFAULT_PID_FILE.exists():
            return

        try:
            pid = int(DEFAULT_PID_FILE.read_text().strip())
        except (ValueError, OSError):
            DEFAULT_PID_FILE.unlink(missing_ok=True)
            return

        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(50):
                os.kill(pid, 0)
                time.sleep(0.1)
            # Still alive after 5s — force kill
            os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass  # already dead or not ours
        finally:
            DEFAULT_PID_FILE.unlink(missing_ok=True)

    def restart(self, build: bool = True, timeout: int = 10) -> int:
        """Stop, optionally rebuild, and start the server. Returns the new PID."""
        self.stop()
        if build:
            self.build()
        pid = self.start()
        if not self.wait_ready(timeout=timeout):
            raise RuntimeError(
                f"Server did not become ready after restart on port {self.port}. "
                f"Check logs: {self.log_path}"
            )
        return pid

    def status(self) -> dict[str, Any]:
        """Return {running, pid, url}."""
        pid: int | None = None
        running = False

        if DEFAULT_PID_FILE.exists():
            try:
                pid = int(DEFAULT_PID_FILE.read_text().strip())
                os.kill(pid, 0)
                running = True
            except (ValueError, ProcessLookupError, PermissionError):
                DEFAULT_PID_FILE.unlink(missing_ok=True)
                pid = None

        return {
            "running": running,
            "pid": pid,
            "url": f"http://{self.host}:{self.port}" if running else None,
        }

    # -- Health check --------------------------------------------------------

    def wait_ready(self, timeout: int = 10) -> bool:
        """Poll /health until the server responds or timeout."""
        import requests as _requests

        url = f"http://localhost:{self.port}/health"
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r = _requests.get(url, timeout=2)
                if r.status_code == 200:
                    return True
            except Exception:
                pass
            time.sleep(0.5)
        return False

    # -- Logs ----------------------------------------------------------------

    def logs(self, n: int = 50) -> str:
        """Return the last n lines of the log file."""
        if not self.log_path.exists():
            return ""
        lines = self.log_path.read_text().splitlines()
        return "\n".join(lines[-n:])

    # -- Context manager -----------------------------------------------------

    def __enter__(self) -> WickServer:
        self.start()
        if not self.wait_ready():
            self.stop()
            raise RuntimeError(
                f"Server did not become ready on port {self.port}. "
                f"Check logs: {self.log_path}"
            )
        self.register_tools()
        return self

    def __exit__(self, *exc: object) -> None:
        self.stop()
