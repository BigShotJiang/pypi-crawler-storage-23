from cs_models.resources.NCTAlertHistory.models import NCTAlertHistoryModel

__all__ = ["NCTAlertHistoryModel"]
