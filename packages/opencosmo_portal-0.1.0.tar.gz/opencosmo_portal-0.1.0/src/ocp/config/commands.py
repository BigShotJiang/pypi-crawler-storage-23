"""Configuration management commands for the OpenCosmo CLI."""

import click

from ocp.config.store import (
    delete_profile,
    get_current_profile,
    list_profiles,
    save_profile,
    set_current_profile,
)


@click.group()
def config() -> None:
    """Manage CLI configuration and profiles."""
    pass


@config.command("list")
def list_cmd() -> None:
    """List all configured profiles."""
    profiles = list_profiles()
    current = get_current_profile()

    if not profiles:
        click.echo("No profiles configured.")
        return

    click.echo("Profiles:")
    for name, cfg in profiles.items():
        marker = "*" if name == current else " "
        click.echo(f"  {marker} {name}: {cfg['api_url']}")

    click.echo()
    click.echo("(* = current profile)")


@config.command("add-profile")
@click.argument("name")
@click.argument("api_url")
def add_profile(name: str, api_url: str) -> None:
    """Add a new profile.

    NAME is the profile name (e.g., 'dev', 'prod').
    API_URL is the base URL for the OpenCosmo API.
    """
    profiles = list_profiles()

    if name in profiles:
        click.confirm(
            f"Profile '{name}' already exists. Overwrite?",
            abort=True,
        )

    save_profile(name, api_url)
    click.echo(f"Profile '{name}' saved.")


@config.command("set-profile")
@click.argument("name")
def set_profile(name: str) -> None:
    """Set the default profile.

    NAME is the profile to use by default.
    """
    try:
        set_current_profile(name)
        click.echo(f"Default profile set to '{name}'.")
    except ValueError as e:
        raise click.ClickException(str(e))


@config.command("remove-profile")
@click.argument("name")
def remove_profile(name: str) -> None:
    """Remove a profile.

    NAME is the profile to remove. Cannot remove the current profile.
    """
    try:
        delete_profile(name)
        click.echo(f"Profile '{name}' removed.")
    except ValueError as e:
        raise click.ClickException(str(e))


@config.command("show")
@click.argument("name", required=False)
@click.pass_context
def show(ctx: click.Context, name: str | None) -> None:
    """Show profile configuration.

    NAME is the profile to show. Shows current profile if not specified.
    """
    from ocp.config.store import get_profile

    profile_name = name or ctx.obj.get("profile") or get_current_profile()

    try:
        profile = get_profile(profile_name)
        click.echo(f"Profile: {profile_name}")
        click.echo(f"API URL: {profile['api_url']}")
    except ValueError as e:
        raise click.ClickException(str(e))
