"""Configuration storage and profile management for the OpenCosmo CLI."""

import json
import os
from pathlib import Path
from typing import Any, TypedDict


class ProfileConfig(TypedDict):
    """Configuration for a single profile."""

    api_url: str


class Config(TypedDict):
    """Root configuration structure."""

    current_profile: str
    profiles: dict[str, ProfileConfig]


# Default configuration directory
CONFIG_DIR = Path.home() / ".opencosmo"
CONFIG_FILE = CONFIG_DIR / "config.json"
TOKENS_DIR = CONFIG_DIR / "tokens"

# Default configuration
DEFAULT_CONFIG: Config = {
    "current_profile": "default",
    "profiles": {
        "default": {"api_url": "http://localhost:8000"},
    },
}

# Environment variable for API URL override
ENV_API_URL = "OPENCOSMO_API_URL"


def ensure_config_dir() -> None:
    """Ensure the configuration directory exists with proper permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKENS_DIR.mkdir(parents=True, exist_ok=True)

    # Set directory permissions to 700 (owner only)
    os.chmod(CONFIG_DIR, 0o700)
    os.chmod(TOKENS_DIR, 0o700)


def load_config() -> Config:
    """Load configuration from disk.

    Returns:
        Configuration dictionary. Returns default config if file doesn't exist.
    """
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG.copy()

    with open(CONFIG_FILE) as f:
        config: dict[str, Any] = json.load(f)

    # Ensure required keys exist
    if "current_profile" not in config:
        config["current_profile"] = "default"
    if "profiles" not in config:
        config["profiles"] = DEFAULT_CONFIG["profiles"].copy()

    return config  # type: ignore[return-value]


def save_config(config: Config) -> None:
    """Save configuration to disk.

    Args:
        config: Configuration dictionary to save.
    """
    ensure_config_dir()

    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    # Set file permissions to 600 (owner read/write only)
    os.chmod(CONFIG_FILE, 0o600)


def get_current_profile() -> str:
    """Get the name of the currently active profile.

    Returns:
        Profile name.
    """
    config = load_config()
    return config["current_profile"]


def set_current_profile(profile_name: str) -> None:
    """Set the current active profile.

    Args:
        profile_name: Name of the profile to activate.

    Raises:
        ValueError: If profile doesn't exist.
    """
    config = load_config()

    if profile_name not in config["profiles"]:
        raise ValueError(f"Profile '{profile_name}' does not exist")

    config["current_profile"] = profile_name
    save_config(config)


def get_profile(profile_name: str | None = None) -> ProfileConfig:
    """Get configuration for a specific profile.

    Args:
        profile_name: Profile name. Uses current profile if None.

    Returns:
        Profile configuration.

    Raises:
        ValueError: If profile doesn't exist.
    """
    config = load_config()
    name = profile_name or config["current_profile"]

    if name not in config["profiles"]:
        raise ValueError(f"Profile '{name}' does not exist")

    return config["profiles"][name]


def save_profile(profile_name: str, api_url: str) -> None:
    """Create or update a profile.

    Args:
        profile_name: Name of the profile.
        api_url: API base URL for this profile.
    """
    config = load_config()
    config["profiles"][profile_name] = {"api_url": api_url}
    save_config(config)


def delete_profile(profile_name: str) -> None:
    """Delete a profile.

    Args:
        profile_name: Name of the profile to delete.

    Raises:
        ValueError: If profile doesn't exist or is the current profile.
    """
    config = load_config()

    if profile_name not in config["profiles"]:
        raise ValueError(f"Profile '{profile_name}' does not exist")

    if profile_name == config["current_profile"]:
        raise ValueError(f"Cannot delete the current profile '{profile_name}'")

    del config["profiles"][profile_name]
    save_config(config)

    # Also delete tokens for this profile
    tokens_file = TOKENS_DIR / f"{profile_name}.json"
    if tokens_file.exists():
        tokens_file.unlink()


def list_profiles() -> dict[str, ProfileConfig]:
    """List all configured profiles.

    Returns:
        Dictionary of profile name to configuration.
    """
    config = load_config()
    return config["profiles"]


def get_api_url(profile_name: str | None = None) -> str:
    """Get the API URL for a profile.

    Environment variable OPENCOSMO_API_URL takes precedence if set.

    Args:
        profile_name: Profile name. Uses current profile if None.

    Returns:
        API base URL.
    """
    # Environment variable override
    env_url = os.environ.get(ENV_API_URL)
    if env_url:
        return env_url.rstrip("/")

    profile = get_profile(profile_name)
    return profile["api_url"].rstrip("/")
