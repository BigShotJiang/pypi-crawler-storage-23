"""Configuration management for the OpenCosmo CLI."""

from ocp.config.store import (
    CONFIG_DIR,
    get_api_url,
    get_current_profile,
    get_profile,
    list_profiles,
    save_profile,
    set_current_profile,
)

__all__ = [
    "CONFIG_DIR",
    "get_api_url",
    "get_current_profile",
    "get_profile",
    "list_profiles",
    "save_profile",
    "set_current_profile",
]
