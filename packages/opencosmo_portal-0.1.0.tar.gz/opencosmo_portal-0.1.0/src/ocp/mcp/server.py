"""Local stdio MCP server that proxies to the remote OpenCosmo API."""

import json
import logging
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx
import mcp.types as mcp_types
from mcp.server.lowlevel.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

from ocp import __version__
from ocp.mcp.api_client import AsyncAPIClient

logger = logging.getLogger(__name__)


# ==================== Types ====================


class TaskInfo:
    """Cached task metadata for dynamic tool generation."""

    def __init__(
        self,
        slug: str,
        name: str,
        description: str | None,
        input_schema: dict[str, Any],
    ) -> None:
        self.slug = slug
        self.name = name
        self.description = description
        self.input_schema = input_schema
        self.tool_name = f"run_{slug.replace('-', '_')}"


# ==================== Tool Schemas ====================

_LIST_TASKS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {},
}

_GET_RUN_STATUS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_LIST_RUNS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "limit": {
            "type": "integer",
            "description": "Maximum number of runs to return (1-100)",
            "default": 20,
            "minimum": 1,
            "maximum": 100,
        },
        "status": {
            "type": "string",
            "description": ("Filter by status (pending, running, succeeded, failed, cancelled)"),
        },
    },
}

_CANCEL_RUN_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_GET_RUN_RESULTS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_GET_RUN_LOGS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}


# ==================== Server Setup ====================


def _create_server(profile: str) -> Server:
    """Create and configure the MCP server with tool handlers.

    Args:
        profile: CLI profile name for authentication.

    Returns:
        Configured MCP Server instance.
    """
    # Closure-scoped state shared between lifespan and handlers
    task_cache: list[TaskInfo] = []
    client_ref: list[AsyncAPIClient | None] = [None]

    @asynccontextmanager
    async def server_lifespan(server: Server) -> AsyncIterator[dict[str, Any]]:
        """Create async client on startup, fetch tasks, close on shutdown."""
        client = AsyncAPIClient(profile)
        client_ref[0] = client

        try:
            resp = await client.get("/api/v1/tasks")
            if resp.status_code == 200:
                data = resp.json()
                for t in data.get("tasks", []):
                    task_cache.append(
                        TaskInfo(
                            slug=t["slug"],
                            name=t["name"],
                            description=t.get("description"),
                            input_schema=t.get("input_schema", {}),
                        )
                    )
                logger.info("Loaded %d tasks", len(task_cache))
            else:
                logger.warning("Failed to fetch tasks: HTTP %d", resp.status_code)
        except Exception:
            logger.exception("Failed to fetch tasks on startup")

        try:
            yield {}
        finally:
            await client.close()
            client_ref[0] = None

    server = Server(
        "opencosmo-local",
        version=__version__,
        instructions=(
            "OpenCosmo local MCP server. Provides tools to query cosmological "
            "simulation data, submit analysis tasks, and monitor task runs. "
            "Use list_tasks to discover available tasks, then use the "
            "corresponding run_<task> tool to submit."
        ),
        lifespan=server_lifespan,
    )

    def _get_client() -> AsyncAPIClient:
        """Get the shared async client from the lifespan closure."""
        client = client_ref[0]
        if client is None:
            raise RuntimeError("MCP server not initialized")
        return client

    # ==================== list_tools ====================

    @server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
    async def handle_list_tools() -> list[mcp_types.Tool]:
        """Return all available tools: static + dynamic per-task."""
        static_tools = [
            mcp_types.Tool(
                name="list_tasks",
                description="List all available tasks you can run.",
                inputSchema=_LIST_TASKS_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_status",
                description=("Get the current status of a task run, including stage progress."),
                inputSchema=_GET_RUN_STATUS_SCHEMA,
            ),
            mcp_types.Tool(
                name="list_runs",
                description=("List your recent task runs with optional status filtering."),
                inputSchema=_LIST_RUNS_SCHEMA,
            ),
            mcp_types.Tool(
                name="cancel_run",
                description="Cancel an active task run.",
                inputSchema=_CANCEL_RUN_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_results",
                description="Get result files for a completed task run.",
                inputSchema=_GET_RUN_RESULTS_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_logs",
                description="Get execution logs for a task run.",
                inputSchema=_GET_RUN_LOGS_SCHEMA,
            ),
        ]

        dynamic_tools = [
            mcp_types.Tool(
                name=task.tool_name,
                description=task.description or task.name,
                inputSchema=task.input_schema,
            )
            for task in task_cache
        ]

        return static_tools + dynamic_tools

    # ==================== call_tool ====================

    @server.call_tool()  # type: ignore[untyped-decorator]
    async def handle_call_tool(
        name: str, arguments: dict[str, Any] | None
    ) -> mcp_types.CallToolResult:
        """Dispatch tool calls to API handlers."""
        args = arguments or {}
        client = _get_client()

        try:
            if name == "list_tasks":
                return await _handle_list_tasks(client)
            elif name == "get_run_status":
                return await _handle_get_run_status(client, args)
            elif name == "list_runs":
                return await _handle_list_runs(client, args)
            elif name == "cancel_run":
                return await _handle_cancel_run(client, args)
            elif name == "get_run_results":
                return await _handle_get_run_results(client, args)
            elif name == "get_run_logs":
                return await _handle_get_run_logs(client, args)
            elif name.startswith("run_"):
                return await _handle_dynamic_submit(client, name, args)
            else:
                return _error_result(f"Unknown tool: {name}")
        except RuntimeError as e:
            return _error_result(str(e))
        except httpx.RequestError as e:
            logger.exception("Network error during tool call: %s", name)
            return _error_result(f"Network error: {e}")
        except Exception as e:
            logger.exception("Tool call failed: %s", name)
            return _error_result(f"Internal error: {e}")

    return server


# ==================== Tool Handlers ====================


async def _handle_list_tasks(
    client: AsyncAPIClient,
) -> mcp_types.CallToolResult:
    """Fetch and return the task list from the API."""
    resp = await client.get("/api/v1/tasks")
    if resp.status_code != 200:
        return _error_result(f"Failed to list tasks (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_dynamic_submit(
    client: AsyncAPIClient,
    tool_name: str,
    args: dict[str, Any],
) -> mcp_types.CallToolResult:
    """Submit a task via a dynamic run_{slug} tool."""
    slug = tool_name.removeprefix("run_").replace("_", "-")
    resp = await client.post(
        f"/api/v1/tasks/{slug}",
        json={"input_data": args},
    )
    if resp.status_code == 404:
        return _error_result(f"Task not found: {slug}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to task: {slug}")
    if resp.status_code >= 400:
        detail = _extract_error(resp)
        return _error_result(f"Task submission failed: {detail}")
    return _json_result(resp.json())


async def _handle_get_run_status(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run status from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")

    resp = await client.get(f"/api/v1/runs/{run_id}")
    if resp.status_code == 404:
        return _error_result(f"Run not found: {run_id}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to run: {run_id}")
    if resp.status_code >= 400:
        return _error_result(f"Failed to get run status (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_list_runs(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """List runs from API."""
    params: dict[str, Any] = {}
    if "limit" in args:
        params["limit"] = min(max(args["limit"], 1), 100)
    if "status" in args:
        params["status"] = args["status"]

    resp = await client.get("/api/v1/runs", params=params)
    if resp.status_code >= 400:
        return _error_result(f"Failed to list runs (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_cancel_run(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Cancel a run via API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")

    resp = await client.delete(f"/api/v1/runs/{run_id}")
    if resp.status_code == 404:
        return _error_result(f"Run not found: {run_id}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to run: {run_id}")
    if resp.status_code >= 400:
        return _error_result(f"Failed to cancel run (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_get_run_results(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run results from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")

    resp = await client.get(f"/api/v1/runs/{run_id}/results")
    if resp.status_code == 404:
        return _error_result(f"Run not found: {run_id}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to run: {run_id}")
    if resp.status_code >= 400:
        return _error_result(f"Failed to get results (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_get_run_logs(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run logs from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")

    resp = await client.get(f"/api/v1/runs/{run_id}/logs")
    if resp.status_code == 404:
        return _error_result(f"Run not found: {run_id}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to run: {run_id}")
    if resp.status_code >= 400:
        return _error_result(f"Failed to get logs (HTTP {resp.status_code})")
    return _json_result(resp.json())


# ==================== Response Helpers ====================


def _json_result(data: Any) -> mcp_types.CallToolResult:
    """Wrap API response data as a successful MCP CallToolResult.

    Args:
        data: Serializable data.

    Returns:
        CallToolResult with JSON text content.
    """
    return mcp_types.CallToolResult(
        content=[
            mcp_types.TextContent(
                type="text",
                text=json.dumps(data, default=str),
            )
        ],
    )


def _error_result(message: str) -> mcp_types.CallToolResult:
    """Create an error MCP CallToolResult.

    Args:
        message: Error message.

    Returns:
        CallToolResult with isError=True.
    """
    return mcp_types.CallToolResult(
        content=[mcp_types.TextContent(type="text", text=message)],
        isError=True,
    )


def _extract_error(resp: httpx.Response) -> str:
    """Extract error detail from an API error response.

    Args:
        resp: HTTP error response.

    Returns:
        Human-readable error string.
    """
    try:
        data = resp.json()
        detail = data.get("detail", "")
        if isinstance(detail, dict):
            return str(detail.get("message", detail))
        return str(detail) or resp.text
    except Exception:
        return resp.text


# ==================== Entry Point ====================


async def run_stdio_server(profile: str, log_file: str | None = None) -> None:
    """Run the MCP server over stdio transport.

    Args:
        profile: CLI profile for authentication.
        log_file: Optional path to write diagnostic logs.
    """
    # Configure logging to stderr or file (never stdout — reserved for MCP)
    if log_file:
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s %(name)s %(levelname)s %(message)s",
        )
    else:
        logging.basicConfig(
            stream=sys.stderr,
            level=logging.WARNING,
            format="%(name)s: %(message)s",
        )

    server = _create_server(profile)

    init_options = InitializationOptions(
        server_name="opencosmo-local",
        server_version=__version__,
        capabilities=server.get_capabilities(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        ),
    )

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)
