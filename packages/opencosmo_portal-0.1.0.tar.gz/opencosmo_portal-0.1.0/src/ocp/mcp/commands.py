"""MCP server commands for the OpenCosmo Portal CLI."""

import click


@click.group()
def mcp() -> None:
    """Local MCP server for AI assistants."""


@mcp.command()
@click.option(
    "--log-file",
    type=click.Path(),
    default=None,
    help="Write server logs to a file (stderr is used by default)",
)
@click.pass_context
def start(ctx: click.Context, log_file: str | None) -> None:
    """Start a local stdio MCP server.

    This server connects to the remote OpenCosmo API using your stored
    credentials. It exposes tasks and runs as MCP tools for AI assistants
    like Claude Desktop.

    The server communicates via stdin/stdout using the MCP stdio transport.
    Configure it in Claude Desktop with:

    \b
        {
          "mcpServers": {
            "opencosmo": {
              "command": "ocp",
              "args": ["mcp", "start"]
            }
          }
        }
    """
    from ocp.auth.tokens import load_tokens

    profile = ctx.obj.get("profile")

    # Verify authentication before starting
    tokens = load_tokens(profile)
    if tokens is None:
        raise click.ClickException(
            f"Not authenticated for profile '{profile}'. Run 'ocp auth login' first."
        )

    # Import here to keep CLI startup fast
    import anyio

    from ocp.mcp.server import run_stdio_server

    anyio.run(run_stdio_server, profile, log_file)
