"""Local MCP server for AI assistants."""
