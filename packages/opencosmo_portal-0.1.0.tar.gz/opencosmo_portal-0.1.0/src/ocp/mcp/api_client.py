"""Async HTTP API client for the local MCP server."""

import logging
from typing import Any

import httpx

from ocp.auth.tokens import (
    StoredTokens,
    has_refresh_token,
    is_token_expired,
    load_tokens,
    save_tokens,
)
from ocp.config.store import get_api_url

logger = logging.getLogger(__name__)

# Client ID for CLI application (same as sync APIClient)
CLIENT_ID = "opencosmo-python"


class AsyncAPIClient:
    """Async HTTP client with automatic token refresh.

    Async counterpart to cli.utils.api.APIClient, designed for the MCP
    server's anyio-based event loop. Reads stored tokens from disk and
    refreshes them transparently when they expire.
    """

    def __init__(self, profile: str, timeout: float = 30.0) -> None:
        """Initialize async API client.

        Args:
            profile: CLI profile name for token lookup and API URL.
            timeout: Request timeout in seconds.
        """
        self.profile = profile
        self.base_url = get_api_url(profile)
        self._client = httpx.AsyncClient(timeout=timeout)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncAPIClient":
        """Context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Context manager exit."""
        await self.close()

    async def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers, refreshing the token if needed.

        Returns:
            Headers dict with Authorization and X-Client-Type.

        Raises:
            RuntimeError: If not authenticated or token refresh fails.
        """
        tokens = load_tokens(self.profile)

        if tokens is None:
            raise RuntimeError(
                f"Not authenticated for profile '{self.profile}'. Run 'ocp auth login' first."
            )

        if is_token_expired(tokens):
            if not has_refresh_token(tokens):
                raise RuntimeError(
                    "Token expired and no refresh token available. "
                    "Run 'ocp auth login' to re-authenticate."
                )
            refresh_token = tokens["refresh_token"]
            assert refresh_token is not None  # Checked by has_refresh_token
            tokens = await self._refresh_token(refresh_token)

        return {
            "Authorization": f"Bearer {tokens['access_token']}",
            "X-Client-Type": "mcp",
        }

    async def _refresh_token(self, refresh_token: str) -> StoredTokens:
        """Refresh the access token.

        Args:
            refresh_token: Current refresh token.

        Returns:
            Updated stored tokens.

        Raises:
            RuntimeError: If refresh request fails.
        """
        try:
            response = await self._client.post(
                f"{self.base_url}/api/v1/auth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": CLIENT_ID,
                },
            )
        except httpx.RequestError as e:
            raise RuntimeError(f"Token refresh failed: {e}")

        if response.status_code != 200:
            raise RuntimeError("Token refresh failed. Run 'ocp auth login' to re-authenticate.")

        data = response.json()
        new_refresh = data.get("refresh_token") or refresh_token

        save_tokens(
            access_token=data["access_token"],
            expires_in=data["expires_in"],
            refresh_token=new_refresh,
            profile=self.profile,
        )

        # Re-read from disk to get the canonical StoredTokens
        result = load_tokens(self.profile)
        assert result is not None
        return result

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make an authenticated GET request.

        Args:
            path: API path (e.g., '/api/v1/tasks').
            **kwargs: Additional arguments for httpx.

        Returns:
            HTTP response.

        Raises:
            RuntimeError: On auth failure.
        """
        headers = await self._get_auth_headers()
        return await self._client.get(f"{self.base_url}{path}", headers=headers, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make an authenticated POST request.

        Args:
            path: API path.
            **kwargs: Additional arguments for httpx.

        Returns:
            HTTP response.

        Raises:
            RuntimeError: On auth failure.
        """
        headers = await self._get_auth_headers()
        return await self._client.post(f"{self.base_url}{path}", headers=headers, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make an authenticated DELETE request.

        Args:
            path: API path.
            **kwargs: Additional arguments for httpx.

        Returns:
            HTTP response.

        Raises:
            RuntimeError: On auth failure.
        """
        headers = await self._get_auth_headers()
        return await self._client.delete(f"{self.base_url}{path}", headers=headers, **kwargs)
