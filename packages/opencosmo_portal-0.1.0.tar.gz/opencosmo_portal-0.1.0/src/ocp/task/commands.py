"""Task management commands for the OpenCosmo CLI."""

import json
from typing import Any, cast

import click

from ocp.task.interactive import build_input_from_schema, display_schema_info
from ocp.utils.api import APIClient, check_response
from ocp.utils.errors import TaskNotFoundError
from ocp.utils.output import output
from ocp.utils.schema import flatten_schema, reconstruct_input


@click.group()
def task() -> None:
    """Manage tasks."""
    pass


@task.command("list")
@click.option("--category", "-c", help="Filter by category")
@click.pass_context
def list_tasks(ctx: click.Context, category: str | None) -> None:
    """List available tasks.

    Shows all tasks you have permission to run.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get("/api/v1/tasks")
        check_response(response, "Tasks")

        data = response.json()
        tasks = data.get("tasks", [])

        # Filter by category if specified
        if category:
            tasks = [t for t in tasks if t.get("category", "").lower() == category.lower()]

        if ctx.obj.get("format") == "json":
            output(ctx, tasks)
        else:
            if not tasks:
                if category:
                    click.echo(f"No tasks found in category '{category}'.")
                else:
                    click.echo("No tasks available.")
                return

            columns = [
                ("slug", "SLUG"),
                ("name", "NAME"),
                ("category", "CATEGORY"),
            ]
            output(ctx, tasks, columns)


@task.command()
@click.argument("slug")
@click.pass_context
def info(ctx: click.Context, slug: str) -> None:
    """Show task details and input schema.

    SLUG is the task identifier (e.g., 'example-query').
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get(f"/api/v1/tasks/{slug}")

        if response.status_code == 404:
            raise TaskNotFoundError(slug)
        check_response(response, "Task")

        task_data = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, task_data)
        else:
            click.echo(f"Task: {task_data['name']}")
            click.echo(f"Slug: {task_data['slug']}")
            click.echo(f"Category: {task_data.get('category', 'general')}")

            if task_data.get("description"):
                click.echo()
                click.echo(task_data["description"])

            click.echo()

            if task_data.get("input_schema"):
                flat, _ = flatten_schema(task_data["input_schema"])
                display_schema_info(cast(dict[str, Any], flat))


@task.command("run")
@click.argument("slug")
@click.option(
    "--input",
    "-i",
    "input_json",
    help='JSON input data (e.g., \'{"field": "value"}\')',
)
@click.option(
    "--file",
    "-f",
    "input_file",
    type=click.Path(exists=True),
    help="Read input from JSON file",
)
@click.option(
    "--no-interactive",
    is_flag=True,
    help="Disable interactive prompts (requires --input or --file)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be submitted without actually running",
)
@click.pass_context
def run_task(
    ctx: click.Context,
    slug: str,
    input_json: str | None,
    input_file: str | None,
    no_interactive: bool,
    dry_run: bool,
) -> None:
    """Run a task.

    SLUG is the task identifier (e.g., 'example-query').

    Without options, runs in interactive mode prompting for each field.

    Examples:

        ocp task run example-query

        ocp task run example-query -i '{"field": "value"}'

        ocp task run example-query -f input.json
    """
    # Load input data
    input_data: dict[str, Any] = {}

    if input_file:
        with open(input_file) as f:
            input_data = json.load(f)
    elif input_json:
        input_data = json.loads(input_json)
    elif no_interactive:
        raise click.ClickException(
            "--no-interactive requires --input or --file to provide input data"
        )

    with APIClient(profile=ctx.obj.get("profile")) as client:
        # Get task info for schema
        response = client.get(f"/api/v1/tasks/{slug}")

        if response.status_code == 404:
            raise TaskNotFoundError(slug)
        check_response(response, "Task")

        task_data = response.json()

        # Flatten schema for CLI display and input collection
        schema = task_data.get("input_schema", {})
        flat_schema, mappings = flatten_schema(schema) if schema.get("properties") else (schema, [])

        # Interactive mode: build input from schema
        if not input_json and not input_file and not no_interactive:
            click.echo(f"Submitting task: {task_data['name']}")
            click.echo()

            if task_data.get("description"):
                click.echo(task_data["description"])
                click.echo()

            if flat_schema.get("properties"):
                input_data = build_input_from_schema(cast(dict[str, Any], flat_schema))
            else:
                click.echo("This task has no input parameters.")

        # Dry run: show what would be submitted
        if dry_run:
            click.echo()
            click.echo("Dry run - would submit:")
            click.echo(json.dumps({"input_data": input_data}, indent=2))
            return

        # Confirm submission
        if not input_json and not input_file:
            click.echo()
            click.echo("Input data:")
            click.echo(json.dumps(input_data, indent=2))
            click.echo()

            if not click.confirm("Submit this task?"):
                click.echo("Cancelled.")
                return

        # Reconstruct nested input from flat CLI input before submitting
        if mappings:
            input_data = reconstruct_input(input_data, mappings)

        # Submit task
        response = client.post(
            f"/api/v1/tasks/{slug}",
            json={"input_data": input_data},
        )
        check_response(response, "Task submission")

        result = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, result)
        else:
            click.echo()
            click.echo(click.style("Task submitted successfully!", fg="green"))
            click.echo(f"Run ID: {result['run_id']}")
            click.echo(f"Status: {result['status']}")
            if result.get("message"):
                click.echo(f"Message: {result['message']}")
            if result.get("external_run_url"):
                click.echo(f"View run: {result['external_run_url']}")
            click.echo()
            click.echo(f"Track progress with: ocp run status {result['run_id']}")
