"""Task management module for the OpenCosmo CLI."""
