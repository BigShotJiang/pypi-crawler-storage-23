"""Interactive task submission using JSON Schema."""

from typing import Any

import click

from ocp.utils.output import strip_latex


def prompt_for_field(
    name: str,
    schema: dict[str, Any],
    required: bool = False,
) -> Any:
    """Generate a prompt for a single field based on its JSON Schema.

    Args:
        name: Field name.
        schema: JSON Schema for the field.
        required: Whether the field is required.

    Returns:
        User-provided value or None for optional fields.
    """
    field_type = schema.get("type", "string")
    description = schema.get("description", "")
    default = schema.get("default")
    title = strip_latex(schema.get("title", name))

    # Build prompt text
    prompt_text = title
    if description:
        click.echo(f"  {click.style(description, dim=True)}")

    # Handle enum (choice)
    if "enum" in schema:
        enum_values = schema["enum"]
        enum_display = schema.get("enum_display", enum_values)

        click.echo(f"\n{title}:")
        for i, (val, display) in enumerate(zip(enum_values, enum_display), 1):
            marker = "*" if val == default else " "
            click.echo(f"  {marker}{i}. {display}")

        if not required and default is None:
            click.echo("   0. (skip)")

        while True:
            choice = click.prompt(
                "Select",
                type=int,
                default=enum_values.index(default) + 1 if default in enum_values else None,
            )

            if choice == 0 and not required:
                return None
            if 1 <= choice <= len(enum_values):
                return enum_values[choice - 1]
            click.echo(f"Please enter a number between 1 and {len(enum_values)}")

    # Handle boolean
    if field_type == "boolean":
        if not required and default is None:
            # Allow skipping
            result = click.prompt(
                prompt_text,
                type=click.Choice(["y", "n", "skip"]),
                default="skip",
            )
            if result == "skip":
                return None
            return result == "y"
        return click.confirm(prompt_text, default=default)

    # Handle integer
    if field_type == "integer":
        min_val = schema.get("minimum")
        max_val = schema.get("maximum")

        type_obj: Any = int
        if min_val is not None or max_val is not None:
            type_obj = click.IntRange(min=min_val, max=max_val)

        if not required:
            value = click.prompt(
                prompt_text,
                type=str,
                default=str(default) if default is not None else "",
            )
            if value == "":
                return None
            return int(value)

        return click.prompt(prompt_text, type=type_obj, default=default)

    # Handle number (float)
    if field_type == "number":
        if not required:
            value = click.prompt(
                prompt_text,
                type=str,
                default=str(default) if default is not None else "",
            )
            if value == "":
                return None
            return float(value)

        return click.prompt(prompt_text, type=float, default=default)

    # Handle array
    if field_type == "array":
        click.echo(f"\n{title} (comma-separated list):")
        if description:
            click.echo(f"  {click.style(description, dim=True)}")

        default_str = ",".join(str(v) for v in default) if default else ""
        value = click.prompt(
            "Values",
            default=default_str,
        )
        if not value:
            return [] if required else None

        items_schema = schema.get("items", {})
        items_type = items_schema.get("type", "string")

        values = [v.strip() for v in value.split(",")]

        if items_type == "integer":
            return [int(v) for v in values]
        elif items_type == "number":
            return [float(v) for v in values]
        return values

    # Default: string
    if not required:
        value = click.prompt(prompt_text, default=default or "", show_default=bool(default))
        return value if value else None

    return click.prompt(prompt_text, default=default, show_default=bool(default))


def _format_display_value(value: Any, field_schema: dict[str, Any]) -> str:
    """Format a value for display in the parameter table.

    Args:
        value: The raw value to display.
        field_schema: JSON Schema for the field.

    Returns:
        Human-readable display string.
    """
    if value is None:
        return click.style("-", dim=True)

    # Show enum_display label instead of raw value
    if "enum" in field_schema:
        enum_values = field_schema["enum"]
        enum_display = field_schema.get("enum_display", enum_values)
        if value in enum_values:
            idx = enum_values.index(value)
            return str(enum_display[idx])

    display = str(value)
    if len(display) > 30:
        display = display[:27] + "..."
    return display


def _display_parameter_table(
    fields: list[tuple[str, dict[str, Any], bool]],
    values: dict[str, Any],
    is_default: dict[str, bool],
) -> None:
    """Render the numbered parameter table.

    Args:
        fields: List of (name, schema, required) tuples.
        values: Current values for each field.
        is_default: Whether each field still has its default value.
    """
    # Compute column widths
    names = [strip_latex(schema.get("title", name)) for name, schema, _ in fields]
    name_width = max(len(n) for n in names) + 2  # +2 for req marker + space
    val_strs = [_format_display_value(values.get(name), schema) for name, schema, _ in fields]
    val_width = max((len(click.unstyle(v)) for v in val_strs), default=10)
    val_width = max(val_width, 6)

    click.echo()
    # Header
    header = f"  {'#':>3}  {'Parameter':<{name_width}}  {'Value':<{val_width}}  Description"
    click.echo(click.style(header, bold=True))
    click.echo(f"  {'─' * 3}  {'─' * name_width}  {'─' * val_width}  {'─' * 30}")

    for i, (name, schema, required) in enumerate(fields, 1):
        title = strip_latex(schema.get("title", name))
        description = schema.get("description", "")

        req_marker = click.style("*", fg="red") if required else " "
        display_name = f"{req_marker}{title}"

        val = _format_display_value(values.get(name), schema)
        if is_default.get(name):
            val = click.style("·", dim=True) + val
        else:
            val = " " + val

        desc = description[:40] + "..." if len(description) > 43 else description

        # Pad using unstyle'd lengths for correct alignment
        name_pad = name_width - len(click.unstyle(display_name))
        val_pad = val_width + 1 - len(click.unstyle(val))
        dim_desc = click.style(desc, dim=True)
        line = f"  {i:>3}  {display_name}{' ' * name_pad}"
        line += f"  {val}{' ' * val_pad}  {dim_desc}"
        click.echo(line)

    click.echo()
    req = click.style("*", fg="red")
    dot = click.style("·", dim=True)
    click.echo(f"  {req} = required, {dot} = default value")


def build_input_from_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Build input data interactively from a JSON Schema.

    Shows a table of all parameters with their current values and lets
    the user select which ones to edit by number.

    Args:
        schema: JSON Schema with 'properties' and 'required' keys.

    Returns:
        Dictionary of user-provided values.
    """
    properties = schema.get("properties", {})
    required_fields = set(schema.get("required", []))

    # Build sorted field list: by propertyOrder array, then required first, then alphabetical
    property_order = schema.get("propertyOrder", [])
    order_map = {name: i for i, name in enumerate(property_order)}

    fields: list[tuple[str, dict[str, Any], bool]] = []
    for name, field_schema in properties.items():
        if name.startswith("_"):
            continue
        fields.append((name, field_schema, name in required_fields))

    fields.sort(key=lambda f: (order_map.get(f[0], 999), f[2] is False, f[0]))

    # Initialize values from defaults
    values: dict[str, Any] = {}
    is_default: dict[str, bool] = {}
    for name, field_schema, _ in fields:
        default = field_schema.get("default")
        if default is not None:
            values[name] = default
            is_default[name] = True
        else:
            is_default[name] = False

    # Display table and prompt loop
    while True:
        _display_parameter_table(fields, values, is_default)
        click.echo()

        choice = click.prompt(
            "Enter parameter number to edit (or Enter to submit)",
            type=str,
            default="",
            show_default=False,
        )

        if choice == "":
            # Validate that all required fields have values
            missing = [
                strip_latex(fields[i][1].get("title", fields[i][0]))
                for i, (name, _, required) in enumerate(fields)
                if required and name not in values
            ]
            if missing:
                click.echo(
                    click.style(f"Required parameters not set: {', '.join(missing)}", fg="red")
                )
                continue
            break

        try:
            idx = int(choice)
        except ValueError:
            click.echo(click.style(f"Please enter a number between 1 and {len(fields)}", fg="red"))
            continue

        if idx < 1 or idx > len(fields):
            click.echo(click.style(f"Please enter a number between 1 and {len(fields)}", fg="red"))
            continue

        name, field_schema, required = fields[idx - 1]
        click.echo()
        value = prompt_for_field(name, field_schema, required=required)
        if value is not None:
            values[name] = value
            is_default[name] = False
        elif name in values and not required:
            del values[name]
            is_default[name] = False

    return values


def display_schema_info(schema: dict[str, Any]) -> None:
    """Display a readable summary of a JSON Schema.

    Args:
        schema: JSON Schema to display.
    """
    properties = schema.get("properties", {})
    required_fields = set(schema.get("required", []))

    if schema.get("title"):
        click.echo(f"Schema: {schema['title']}")
    if schema.get("description"):
        click.echo(f"  {schema['description']}")

    click.echo()
    click.echo("Parameters:")

    for field_name, field_schema in sorted(properties.items()):
        if field_name.startswith("_"):
            continue

        is_required = field_name in required_fields
        req_marker = click.style("*", fg="red") if is_required else " "

        field_type = field_schema.get("type", "string")
        if isinstance(field_type, list):
            field_type = " | ".join(str(t) for t in field_type)

        click.echo(f"  {req_marker} {click.style(field_name, bold=True)} ({field_type})")

        # Build description: prepend title if it differs from field_name
        title = strip_latex(field_schema.get("title", ""))
        description = field_schema.get("description")
        if title and title != field_name:
            desc_parts = [title]
            if description:
                desc_parts.append(description)
            click.echo(f"      {click.style(': '.join(desc_parts), dim=True)}")
        elif description:
            click.echo(f"      {click.style(description, dim=True)}")

        if "enum" in field_schema:
            enum_values = field_schema["enum"]
            enum_display = field_schema.get("enum_display")
            if enum_display and len(enum_display) == len(enum_values):
                values = ", ".join(f"{v} ({d})" for v, d in zip(enum_values, enum_display))
            else:
                values = ", ".join(str(v) for v in enum_values)
            click.echo(f"      Options: [{values}]")

        if field_schema.get("default") is not None:
            click.echo(f"      Default: {field_schema['default']}")

    click.echo()
    click.echo(f"  {click.style('*', fg='red')} = required")
