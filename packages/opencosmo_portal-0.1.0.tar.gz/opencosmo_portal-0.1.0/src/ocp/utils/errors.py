"""CLI error classes for the OpenCosmo Portal CLI."""

import click


class CLIError(click.ClickException):
    """Base CLI error with styled output."""

    def format_message(self) -> str:
        """Format error message with styling."""
        return click.style(f"Error: {self.message}", fg="red")


class NotAuthenticatedError(CLIError):
    """User is not authenticated."""

    def __init__(self, profile: str | None = None) -> None:
        """Initialize not authenticated error.

        Args:
            profile: Profile name that is not authenticated.
        """
        self.profile = profile
        msg = "Not authenticated"
        if profile:
            msg = f"Not authenticated for profile '{profile}'"
        msg += ". Run 'ocp auth login' to authenticate."
        super().__init__(msg)


class TokenExpiredError(CLIError):
    """Authentication token has expired and cannot be refreshed."""

    def __init__(self) -> None:
        """Initialize token expired error."""
        super().__init__(
            "Authentication token has expired. Run 'ocp auth login' to re-authenticate."
        )


class APIError(CLIError):
    """API request failed."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        detail: str | None = None,
    ) -> None:
        """Initialize API error.

        Args:
            message: Error message.
            status_code: HTTP status code.
            detail: Additional error detail from API.
        """
        self.status_code = status_code
        self.detail = detail

        parts = [message]
        if status_code:
            parts.append(f"(HTTP {status_code})")
        if detail:
            parts.append(f": {detail}")

        super().__init__(" ".join(parts))


class ProfileNotFoundError(CLIError):
    """Profile does not exist."""

    def __init__(self, profile: str) -> None:
        """Initialize profile not found error.

        Args:
            profile: Name of the missing profile.
        """
        super().__init__(
            f"Profile '{profile}' not found. Run 'ocp config list' to see available profiles."
        )


class TaskNotFoundError(CLIError):
    """Task does not exist."""

    def __init__(self, slug: str) -> None:
        """Initialize task not found error.

        Args:
            slug: Task slug that was not found.
        """
        super().__init__(f"Task '{slug}' not found. Run 'ocp task list' to see available tasks.")


class RunNotFoundError(CLIError):
    """Run does not exist."""

    def __init__(self, run_id: str) -> None:
        """Initialize run not found error.

        Args:
            run_id: Run ID that was not found.
        """
        super().__init__(f"Run '{run_id}' not found. Run 'ocp run list' to see your runs.")
