"""JSON Schema flattening and reconstruction utilities for CLI display."""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypedDict


class FlatPropertySchema(TypedDict, total=False):
    """JSON Schema for a single flat property."""

    type: str
    description: str
    enum: list[Any]
    enum_display: list[str]
    default: Any
    minimum: float
    maximum: float
    exclusiveMinimum: float
    exclusiveMaximum: float
    minLength: int
    maxLength: int
    pattern: str
    format: str
    title: str


class FlatJsonSchema(TypedDict, total=False):
    """A flattened JSON Schema with no nested objects."""

    type: str  # Always "object"
    properties: dict[str, FlatPropertySchema]
    required: list[str]
    title: str
    description: str


@dataclass
class ParameterMapping:
    """Maps a flat parameter name back to its nested path."""

    flat_name: str
    path: list[str]
    required: bool


# ==================== Schema Flattening ====================


def flatten_schema(
    schema: dict[str, Any],
) -> tuple[FlatJsonSchema, list[ParameterMapping]]:
    """Flatten a nested JSON Schema into a flat JSON Schema.

    Uses path-based names joined with ``_``. Single-segment paths use the
    property name directly; multi-segment paths join all segments.

    Args:
        schema: The JSON Schema to flatten.

    Returns:
        Tuple of (flat_schema, mappings) where:
        - flat_schema: A valid flat JSON Schema with no nested objects
        - mappings: List of ParameterMapping for reconstruction

    Raises:
        ValueError: If flattening produces duplicate names.
    """
    flat_properties: dict[str, Any] = {}
    flat_required: list[str] = []
    mappings: list[ParameterMapping] = []

    def collect_properties(
        obj_schema: dict[str, Any],
        path: list[str],
        parent_required: bool,
    ) -> None:
        properties = obj_schema.get("properties", {})
        required_fields = set(obj_schema.get("required", []))

        for prop_name, prop_schema in properties.items():
            current_path = path + [prop_name]
            prop_type = prop_schema.get("type", "string")
            is_required = parent_required and (prop_name in required_fields)

            if prop_type == "object" and "properties" in prop_schema:
                # Recurse into nested objects
                collect_properties(prop_schema, current_path, is_required)
            else:
                # Leaf property - generate flat name from path
                flat_name = "_".join(current_path)

                if flat_name in flat_properties:
                    existing = next(m for m in mappings if m.flat_name == flat_name)
                    raise ValueError(
                        f"Duplicate flattened name '{flat_name}' from paths "
                        f"{existing.path} and {current_path}"
                    )

                flat_prop = {k: v for k, v in prop_schema.items()}
                flat_properties[flat_name] = flat_prop

                if is_required:
                    flat_required.append(flat_name)

                mappings.append(
                    ParameterMapping(
                        flat_name=flat_name,
                        path=current_path,
                        required=is_required,
                    )
                )

    # Start collection from root
    root_required = True  # Root level required fields are always considered required
    collect_properties(schema, [], root_required)

    # Build flat schema
    flat_schema: FlatJsonSchema = {
        "type": "object",
        "properties": flat_properties,
    }
    if flat_required:
        flat_schema["required"] = flat_required

    # Preserve other root-level schema properties
    if "title" in schema:
        flat_schema["title"] = schema["title"]
    if "description" in schema:
        flat_schema["description"] = schema["description"]

    return flat_schema, mappings


# ==================== Input Reconstruction ====================


def create_reconstructor(
    mappings: list[ParameterMapping],
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create a function that reconstructs the nested object from flat parameters.

    Args:
        mappings: List of ParameterMapping from flatten_schema.

    Returns:
        Function that takes flat dict and returns nested dict.
    """

    def reconstruct(flat_input: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}

        for mapping in mappings:
            if mapping.flat_name not in flat_input:
                continue

            value = flat_input[mapping.flat_name]
            if value is None and not mapping.required:
                continue

            # Navigate/create nested structure
            current = result
            for key in mapping.path[:-1]:
                if key not in current:
                    current[key] = {}
                current = current[key]

            current[mapping.path[-1]] = value

        return result

    return reconstruct


def reconstruct_input(
    flat_input: dict[str, Any],
    mappings: list[ParameterMapping],
) -> dict[str, Any]:
    """Reconstruct nested input from flat input using mappings.

    Convenience function that calls create_reconstructor internally.

    Args:
        flat_input: Flat parameter dict from user.
        mappings: List of ParameterMapping from flatten_schema.

    Returns:
        Nested dict structure.
    """
    reconstructor = create_reconstructor(mappings)
    return reconstructor(flat_input)
