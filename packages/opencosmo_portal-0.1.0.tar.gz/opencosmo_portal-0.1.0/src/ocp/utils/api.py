"""HTTP API client with automatic token refresh for the OpenCosmo CLI."""

from typing import Any

import httpx

from ocp.auth.tokens import (
    has_refresh_token,
    is_token_expired,
    load_tokens,
    save_tokens,
)
from ocp.config.store import get_api_url, get_current_profile
from ocp.utils.errors import APIError, NotAuthenticatedError, TokenExpiredError

# Client ID for CLI application
CLIENT_ID = "opencosmo-python"


class APIClient:
    """HTTP client with automatic token refresh."""

    def __init__(self, profile: str | None = None, timeout: float = 30.0) -> None:
        """Initialize API client.

        Args:
            profile: Profile name. Uses current profile if None.
            timeout: Request timeout in seconds.
        """
        self.profile = profile or get_current_profile()
        self.base_url = get_api_url(self.profile)
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @property
    def client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(timeout=self.timeout)
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "APIClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()

    def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers, refreshing token if needed.

        Returns:
            Headers dict with Authorization.

        Raises:
            NotAuthenticatedError: If not authenticated.
            TokenExpiredError: If token expired and cannot be refreshed.
        """
        tokens = load_tokens(self.profile)

        if tokens is None:
            raise NotAuthenticatedError(self.profile)

        # Check if token needs refresh
        if is_token_expired(tokens):
            if not has_refresh_token(tokens):
                raise TokenExpiredError()

            # Refresh the token
            refresh_token = tokens["refresh_token"]
            assert refresh_token is not None  # Checked by has_refresh_token
            refreshed = self._refresh_token(refresh_token)
            access_token = refreshed["access_token"]
        else:
            access_token = tokens["access_token"]

        return {
            "Authorization": f"Bearer {access_token}",
            "X-Client-Type": "python",
        }

    def _refresh_token(self, refresh_token: str) -> dict[str, Any]:
        """Refresh the access token.

        Args:
            refresh_token: Refresh token.

        Returns:
            New token response.

        Raises:
            TokenExpiredError: If refresh fails.
        """
        try:
            response = self.client.post(
                f"{self.base_url}/api/v1/auth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": CLIENT_ID,
                },
            )

            if response.status_code != 200:
                raise TokenExpiredError()

            data = response.json()

            # Save new tokens
            # Use 'or' instead of default arg since response may have explicit null
            new_refresh_token = data.get("refresh_token") or refresh_token
            save_tokens(
                access_token=data["access_token"],
                expires_in=data["expires_in"],
                refresh_token=new_refresh_token,
                profile=self.profile,
            )

            return {
                "access_token": data["access_token"],
                "refresh_token": new_refresh_token,
            }

        except httpx.RequestError as e:
            raise APIError(f"Token refresh failed: {e}")

    def request(
        self,
        method: str,
        path: str,
        *,
        authenticated: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an API request.

        Args:
            method: HTTP method.
            path: API path (e.g., '/api/v1/tasks').
            authenticated: Whether to include auth headers.
            **kwargs: Additional arguments for httpx.

        Returns:
            HTTP response.

        Raises:
            APIError: On request failure.
            NotAuthenticatedError: If auth required but not authenticated.
        """
        url = f"{self.base_url}{path}"

        headers = kwargs.pop("headers", {})
        if authenticated:
            headers.update(self._get_auth_headers())

        try:
            response = self.client.request(method, url, headers=headers, **kwargs)
            return response
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {e}")

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a GET request.

        Args:
            path: API path.
            **kwargs: Additional arguments.

        Returns:
            HTTP response.
        """
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a POST request.

        Args:
            path: API path.
            **kwargs: Additional arguments.

        Returns:
            HTTP response.
        """
        return self.request("POST", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a DELETE request.

        Args:
            path: API path.
            **kwargs: Additional arguments.

        Returns:
            HTTP response.
        """
        return self.request("DELETE", path, **kwargs)


def get_client(ctx_obj: dict[str, Any]) -> APIClient:
    """Get an API client from Click context.

    Args:
        ctx_obj: Click context obj dict.

    Returns:
        Configured API client.
    """
    profile = ctx_obj.get("profile")
    return APIClient(profile=profile)


def check_response(response: httpx.Response, resource: str = "Resource") -> None:
    """Check response status and raise appropriate error.

    Args:
        response: HTTP response.
        resource: Resource name for error messages.

    Raises:
        APIError: On error responses.
    """
    if response.status_code == 401:
        raise NotAuthenticatedError()
    elif response.status_code == 404:
        raise APIError(f"{resource} not found", status_code=404)
    elif response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise APIError("Request failed", status_code=response.status_code, detail=detail)
