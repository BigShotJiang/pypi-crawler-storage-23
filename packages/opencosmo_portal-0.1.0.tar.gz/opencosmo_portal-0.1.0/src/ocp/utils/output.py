"""Output formatting utilities for the OpenCosmo CLI."""

import json
import re
from datetime import UTC, datetime
from typing import Any

import click


def strip_latex(text: str) -> str:
    """Strip LaTeX formatting for plain-text CLI display.

    Converts inline math like ``\\(M_{tot}\\)`` to ``M_tot``.

    Args:
        text: Text potentially containing LaTeX markup.

    Returns:
        Plain-text version of the string.
    """
    text = text.replace("\\(", "").replace("\\)", "")
    text = re.sub(r"(?<!\\)[{}]", "", text)
    return text


def format_json(data: Any) -> str:
    """Format data as pretty-printed JSON.

    Args:
        data: Data to format.

    Returns:
        JSON string.
    """
    return json.dumps(data, indent=2, default=str)


def format_table(
    rows: list[dict[str, Any]],
    columns: list[tuple[str, str]],
    empty_message: str = "No data.",
) -> str:
    """Format data as an ASCII table.

    Args:
        rows: List of row dictionaries.
        columns: List of (key, header) tuples defining columns.
        empty_message: Message to show when rows is empty.

    Returns:
        Formatted table string.
    """
    if not rows:
        return empty_message

    # Calculate column widths
    widths: dict[str, int] = {}
    for key, header in columns:
        widths[key] = len(header)
        for row in rows:
            value = str(row.get(key, ""))
            widths[key] = max(widths[key], len(value))

    # Build header
    header_parts = []
    for key, header in columns:
        header_parts.append(header.ljust(widths[key]))
    header_line = "  ".join(header_parts)

    # Build rows
    row_lines = []
    for row in rows:
        row_parts = []
        for key, _ in columns:
            value = str(row.get(key, ""))
            row_parts.append(value.ljust(widths[key]))
        row_lines.append("  ".join(row_parts))

    return header_line + "\n" + "\n".join(row_lines)


def output(
    ctx: click.Context,
    data: Any,
    columns: list[tuple[str, str]] | None = None,
    empty_message: str = "No data.",
) -> None:
    """Output data in the format specified by context.

    Args:
        ctx: Click context with 'format' in obj.
        data: Data to output (dict or list of dicts).
        columns: Column definitions for table format.
        empty_message: Message for empty data.
    """
    fmt = ctx.obj.get("format", "table")

    if fmt == "json":
        click.echo(format_json(data))
    else:
        if isinstance(data, list) and columns:
            click.echo(format_table(data, columns, empty_message))
        elif isinstance(data, dict):
            # Format single item as key-value pairs
            for key, value in data.items():
                click.echo(f"{key}: {value}")
        else:
            click.echo(str(data))


def format_datetime(dt: datetime | str | None) -> str:
    """Format a datetime for display.

    Args:
        dt: Datetime object or ISO string.

    Returns:
        Formatted string or empty string if None.
    """
    if dt is None:
        return ""

    if isinstance(dt, str):
        try:
            parsed = datetime.fromisoformat(dt.replace("Z", "+00:00"))
            return parsed.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            return dt

    return dt.strftime("%Y-%m-%d %H:%M:%S")


def format_relative_time(dt: datetime | str | None) -> str:
    """Format a datetime as relative time (e.g., '2 hours ago').

    Args:
        dt: Datetime object or ISO string. Assumed to be UTC if no timezone.

    Returns:
        Relative time string or empty string if None.
    """
    if dt is None:
        return ""

    parsed: datetime
    if isinstance(dt, str):
        try:
            # Handle "Z" suffix for UTC
            parsed = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt
    else:
        parsed = dt

    # If no timezone info, assume UTC (server returns UTC timestamps)
    if parsed.tzinfo is None:
        now = datetime.now(UTC).replace(tzinfo=None)
    else:
        now = datetime.now(parsed.tzinfo)

    diff = now - parsed

    seconds = diff.total_seconds()

    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 604800:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    else:
        return format_datetime(parsed)


def status_color(status: str) -> str:
    """Get the color for a status string.

    Args:
        status: Status value.

    Returns:
        Click color name.
    """
    colors = {
        "pending": "yellow",
        "running": "blue",
        "succeeded": "green",
        "failed": "red",
        "cancelled": "magenta",
        "completed": "green",
    }
    return colors.get(status.lower(), "white")


def styled_status(status: str) -> str:
    """Format a status with color.

    Args:
        status: Status value.

    Returns:
        Styled status string.
    """
    return click.style(status, fg=status_color(status))
