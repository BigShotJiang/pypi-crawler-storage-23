"""Run management commands for the OpenCosmo CLI."""

import time
from typing import Any

import click

from ocp.utils.api import APIClient, check_response
from ocp.utils.errors import RunNotFoundError
from ocp.utils.output import (
    format_relative_time,
    output,
    styled_status,
)


@click.group()
def run() -> None:
    """Manage task runs."""
    pass


@run.command("list")
@click.option(
    "--status",
    "-s",
    "filter_status",
    type=click.Choice(["pending", "running", "succeeded", "failed", "cancelled"]),
    help="Filter by status",
)
@click.option(
    "--include-archived",
    is_flag=True,
    help="Include archived runs",
)
@click.option(
    "--limit",
    "-n",
    default=20,
    type=click.IntRange(1, 100),
    help="Maximum number of runs to show (default: 20)",
)
@click.pass_context
def list_runs(
    ctx: click.Context,
    filter_status: str | None,
    include_archived: bool,
    limit: int,
) -> None:
    """List your task runs.

    Shows recent runs with their status and creation time.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        params: dict[str, Any] = {"limit": limit}
        if filter_status:
            params["status"] = filter_status
        if include_archived:
            params["include_archived"] = "true"

        response = client.get("/api/v1/runs", params=params)
        check_response(response, "Runs")

        data = response.json()
        runs = data.get("runs", [])

        if ctx.obj.get("format") == "json":
            output(ctx, runs)
        else:
            if not runs:
                click.echo("No runs found.")
                return

            # Format for display
            for r in runs:
                r["created"] = format_relative_time(r.get("created_at"))
                r["status_display"] = styled_status(r["status"])

            # Print table manually to support colored status
            click.echo(f"{'RUN ID':<38} {'STATUS':<12} {'TASK':<20} {'CREATED':<15}")
            for r in runs:
                click.echo(
                    f"{r['run_id']:<38} {r['status_display']:<21} "  # Extra space for ANSI codes
                    f"{r['task_slug']:<20} {r['created']:<15}"
                )

            click.echo()
            click.echo(f"Total: {data.get('total', len(runs))} runs")


@run.command()
@click.argument("run_id")
@click.option(
    "--watch",
    "-w",
    is_flag=True,
    help="Watch for status changes until completion",
)
@click.option(
    "--interval",
    default=5,
    type=int,
    help="Polling interval in seconds for --watch (default: 5)",
)
@click.pass_context
def status(ctx: click.Context, run_id: str, watch: bool, interval: int) -> None:
    """Get run status and progress.

    RUN_ID is the run identifier returned from task submission.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        while True:
            response = client.get(f"/api/v1/runs/{run_id}")

            if response.status_code == 404:
                raise RunNotFoundError(run_id)
            check_response(response, "Run")

            run_data = response.json()

            if ctx.obj.get("format") == "json":
                output(ctx, run_data)
                if not watch or run_data["status"] in ("succeeded", "failed", "cancelled"):
                    break
            else:
                # Clear screen if watching
                if watch:
                    click.clear()

                click.echo(f"Run: {run_data['run_id']}")
                click.echo(f"Task: {run_data['task_name']} ({run_data['task_slug']})")
                click.echo(f"Status: {styled_status(run_data['status'])}")

                if run_data.get("current_stage"):
                    click.echo(f"Current stage: {run_data['current_stage']}")

                click.echo(f"Created: {format_relative_time(run_data.get('created_at'))}")

                if run_data.get("completed_at"):
                    click.echo(f"Completed: {format_relative_time(run_data['completed_at'])}")

                if run_data.get("external_run_url"):
                    click.echo(f"View run: {run_data['external_run_url']}")

                # Show stages
                stages = run_data.get("stages", [])
                if stages:
                    click.echo()
                    click.echo("Stages:")
                    for stage in stages:
                        status_str = styled_status(stage["status"])
                        click.echo(f"  {stage['name']}: {status_str}")
                        if stage.get("message"):
                            click.echo(f"    {stage['message']}")

                # Check if done
                if run_data["status"] in ("succeeded", "failed", "cancelled"):
                    if not watch:
                        break

                    click.echo()
                    if run_data["status"] == "succeeded":
                        click.echo(click.style("Run completed successfully!", fg="green"))
                        click.echo(f"Get results with: ocp run results {run_id}")
                    elif run_data["status"] == "failed":
                        click.echo(click.style("Run failed.", fg="red"))
                        click.echo(f"Get logs with: ocp run logs {run_id}")
                    break

                if not watch:
                    break

            # Poll again
            if watch:
                time.sleep(interval)


@run.command()
@click.argument("run_id")
@click.pass_context
def logs(ctx: click.Context, run_id: str) -> None:
    """Get run execution logs.

    RUN_ID is the run identifier.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get(f"/api/v1/runs/{run_id}/logs")

        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Logs")

        logs_list = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, logs_list)
        else:
            if not logs_list:
                click.echo("No logs available.")
                return

            for log_entry in logs_list:
                timestamp = log_entry.get("time", "")
                code = log_entry.get("code", "")
                description = log_entry.get("description", "")
                click.echo(f"[{timestamp}] {code}: {description}")


@run.command()
@click.argument("run_id")
@click.pass_context
def results(ctx: click.Context, run_id: str) -> None:
    """Get run results.

    RUN_ID is the run identifier. Only available for completed runs.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get(f"/api/v1/runs/{run_id}/results")

        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Results")

        data = response.json()

        if data is None:
            click.echo("Results not available yet. Run may still be in progress.")
            return

        if ctx.obj.get("format") == "json":
            output(ctx, data)
        else:
            files = data.get("files", [])
            if not files:
                click.echo("No result files available.")
                return

            if data.get("message"):
                click.echo(f"Message: {data['message']}")
                click.echo()

            click.echo("Result files:")
            for f in files:
                size = f.get("size_bytes", 0)
                size_str = _format_size(size)
                click.echo(f"  {f.get('name', f.get('local_path', 'unknown'))} ({size_str})")
                if f.get("url"):
                    click.echo(f"    URL: {f['url']}")

            click.echo()
            total = data.get("total_bytes", 0)
            click.echo(f"Total size: {_format_size(total)}")

            if data.get("expires_at"):
                click.echo(f"Expires: {data['expires_at']}")


@run.command()
@click.argument("run_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def cancel(ctx: click.Context, run_id: str, yes: bool) -> None:
    """Cancel a running task.

    RUN_ID is the run identifier.
    """
    if not yes:
        if not click.confirm(f"Cancel run {run_id}?"):
            click.echo("Cancelled.")
            return

    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.delete(f"/api/v1/runs/{run_id}")

        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Cancel")

        data = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, data)
        else:
            click.echo(click.style("Run cancelled.", fg="yellow"))
            if data.get("message"):
                click.echo(data["message"])


@run.command()
@click.argument("run_id")
@click.pass_context
def archive(ctx: click.Context, run_id: str) -> None:
    """Archive a completed run.

    RUN_ID is the run identifier. Archived runs are hidden from the default list.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.post(f"/api/v1/runs/{run_id}/archive")

        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Archive")

        data = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, data)
        else:
            click.echo("Run archived.")
            if data.get("message"):
                click.echo(data["message"])


def _format_size(size_bytes: int) -> str:
    """Format byte size as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"
