"""User commands for the OpenCosmo CLI."""
