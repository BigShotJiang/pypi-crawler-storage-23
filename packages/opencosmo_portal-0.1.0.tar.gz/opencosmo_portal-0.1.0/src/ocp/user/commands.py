"""User commands for the OpenCosmo CLI."""

import click

from ocp.utils.api import APIClient, check_response
from ocp.utils.output import format_datetime, output


@click.command()
@click.pass_context
def whoami(ctx: click.Context) -> None:
    """Show authenticated user information.

    Displays your user profile including permissions, groups, and linked identities.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get("/api/v1/users/me")
        check_response(response, "User")

        user = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, user)
        else:
            click.echo(f"User ID: {user['id']}")
            click.echo(f"Name: {user.get('name') or '(not set)'}")
            click.echo(f"Email: {user.get('email') or '(not set)'}")
            click.echo()

            if user.get("permissions"):
                click.echo("Permissions:")
                for perm in user["permissions"]:
                    click.echo(f"  - {perm}")
            else:
                click.echo("Permissions: none")

            click.echo()

            if user.get("groups"):
                click.echo(f"Groups: {len(user['groups'])}")
            else:
                click.echo("Groups: none")

            click.echo()
            click.echo(f"Created: {format_datetime(user.get('created_at'))}")
            if user.get("last_login_at"):
                click.echo(f"Last login: {format_datetime(user['last_login_at'])}")

            if user.get("identities"):
                click.echo()
                click.echo("Linked identities:")
                for identity in user["identities"]:
                    email = identity.get("email") or "(no email)"
                    click.echo(f"  - {identity['provider']}: {email}")
