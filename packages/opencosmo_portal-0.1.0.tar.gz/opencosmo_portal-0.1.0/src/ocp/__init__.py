"""OpenCosmo CLI - Command-line interface for the OpenCosmo platform."""

__version__ = "0.1.0"
