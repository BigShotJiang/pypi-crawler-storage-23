"""Token storage and management for the OpenCosmo CLI."""

import json
import os
import time
from pathlib import Path
from typing import Any, TypedDict, cast

from ocp.config.store import TOKENS_DIR, ensure_config_dir, get_current_profile


class StoredTokens(TypedDict):
    """Structure for stored authentication tokens."""

    access_token: str
    refresh_token: str | None
    expires_at: float  # Unix timestamp


# Buffer time (seconds) before expiration to trigger refresh
EXPIRY_BUFFER = 300  # 5 minutes


def get_tokens_file(profile: str | None = None) -> Path:
    """Get the tokens file path for a profile.

    Args:
        profile: Profile name. Uses current profile if None.

    Returns:
        Path to the tokens file.
    """
    name = profile or get_current_profile()
    return TOKENS_DIR / f"{name}.json"


def load_tokens(profile: str | None = None) -> StoredTokens | None:
    """Load stored tokens for a profile.

    Args:
        profile: Profile name. Uses current profile if None.

    Returns:
        Stored tokens or None if not authenticated.
    """
    tokens_file = get_tokens_file(profile)

    if not tokens_file.exists():
        return None

    with open(tokens_file) as f:
        data: Any = json.load(f)
        return cast(StoredTokens, data)


def save_tokens(
    access_token: str,
    expires_in: int,
    refresh_token: str | None = None,
    profile: str | None = None,
) -> None:
    """Save authentication tokens for a profile.

    Args:
        access_token: JWT access token.
        expires_in: Token lifetime in seconds.
        refresh_token: Optional refresh token.
        profile: Profile name. Uses current profile if None.
    """
    ensure_config_dir()

    tokens: StoredTokens = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_at": time.time() + expires_in,
    }

    tokens_file = get_tokens_file(profile)

    with open(tokens_file, "w") as f:
        json.dump(tokens, f, indent=2)

    # Set file permissions to 600 (owner read/write only)
    os.chmod(tokens_file, 0o600)


def delete_tokens(profile: str | None = None) -> bool:
    """Delete stored tokens for a profile.

    Args:
        profile: Profile name. Uses current profile if None.

    Returns:
        True if tokens were deleted, False if no tokens existed.
    """
    tokens_file = get_tokens_file(profile)

    if tokens_file.exists():
        tokens_file.unlink()
        return True

    return False


def is_token_expired(tokens: StoredTokens) -> bool:
    """Check if tokens are expired or about to expire.

    Args:
        tokens: Stored tokens.

    Returns:
        True if tokens should be refreshed.
    """
    return time.time() >= (tokens["expires_at"] - EXPIRY_BUFFER)


def has_refresh_token(tokens: StoredTokens) -> bool:
    """Check if tokens include a refresh token.

    Args:
        tokens: Stored tokens.

    Returns:
        True if refresh token is available.
    """
    return bool(tokens.get("refresh_token"))


def get_access_token(profile: str | None = None) -> str | None:
    """Get the current access token if valid.

    Does not attempt to refresh - use APIClient for auto-refresh.

    Args:
        profile: Profile name. Uses current profile if None.

    Returns:
        Access token or None if not available or expired.
    """
    tokens = load_tokens(profile)

    if tokens is None:
        return None

    if is_token_expired(tokens) and not has_refresh_token(tokens):
        return None

    return tokens["access_token"]


def get_token_expiry(profile: str | None = None) -> float | None:
    """Get the token expiration timestamp.

    Args:
        profile: Profile name. Uses current profile if None.

    Returns:
        Unix timestamp of expiration or None if not authenticated.
    """
    tokens = load_tokens(profile)
    return tokens["expires_at"] if tokens else None
