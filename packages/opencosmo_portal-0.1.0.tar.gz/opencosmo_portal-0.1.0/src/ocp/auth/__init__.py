"""Authentication module for the OpenCosmo CLI."""
