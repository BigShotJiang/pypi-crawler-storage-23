"""OAuth PKCE authentication flow for the OpenCosmo CLI."""

import base64
import hashlib
import http.server
import secrets
import socketserver
import threading
import urllib.parse
import webbrowser
from dataclasses import dataclass, field
from typing import Any, cast

import httpx

from ocp.auth.tokens import save_tokens
from ocp.config.store import get_api_url
from ocp.utils.api import CLIENT_ID


@dataclass
class AuthResult:
    """Result from OAuth callback."""

    code: str | None = None
    state: str | None = None
    error: str | None = None


@dataclass
class OAuthFlow:
    """Manages the OAuth PKCE authentication flow."""

    profile: str
    base_url: str = field(init=False)
    local_port: int = 8080
    code_verifier: str = field(init=False)
    code_challenge: str = field(init=False)
    state: str = field(init=False)
    _auth_result: AuthResult = field(default_factory=AuthResult, init=False)
    _server_stop: threading.Event = field(default_factory=threading.Event, init=False)

    def __post_init__(self) -> None:
        """Initialize OAuth parameters."""
        self.base_url = get_api_url(self.profile)
        self.code_verifier, self.code_challenge = self._generate_pkce()
        self.state = secrets.token_urlsafe(16)

    @staticmethod
    def _generate_pkce() -> tuple[str, str]:
        """Generate PKCE code_verifier and code_challenge.

        Returns:
            Tuple of (code_verifier, code_challenge).
        """
        # Generate random verifier (43-128 chars, URL-safe)
        code_verifier = secrets.token_urlsafe(48)

        # Generate S256 challenge
        digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
        code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

        return code_verifier, code_challenge

    @property
    def redirect_uri(self) -> str:
        """Get the redirect URI for this flow."""
        return f"http://localhost:{self.local_port}"

    @property
    def authorization_url(self) -> str:
        """Build the authorization URL."""
        params = {
            "client_id": CLIENT_ID,
            "redirect_uri": self.redirect_uri,
            "state": self.state,
            "code_challenge": self.code_challenge,
            "code_challenge_method": "S256",
        }
        return f"{self.base_url}/api/v1/auth/authorize?{urllib.parse.urlencode(params)}"

    def _create_callback_handler(self) -> type[http.server.BaseHTTPRequestHandler]:
        """Create HTTP handler class for OAuth callback."""
        flow = self

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            """HTTP handler for OAuth callback."""

            def do_GET(self) -> None:
                """Handle GET request (OAuth callback)."""
                parsed = urllib.parse.urlparse(self.path)
                params = urllib.parse.parse_qs(parsed.query)

                if "code" in params:
                    flow._auth_result.code = params["code"][0]
                    flow._auth_result.state = params.get("state", [None])[0]
                    self._send_success_response()
                elif "error" in params:
                    flow._auth_result.error = params.get("error_description", params["error"])[0]
                    self._send_error_response(flow._auth_result.error or "Unknown error")
                else:
                    flow._auth_result.error = "No code or error in callback"
                    self._send_error_response(flow._auth_result.error)

                flow._server_stop.set()

            def _send_success_response(self) -> None:
                """Send success HTML response."""
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                html = """<!DOCTYPE html>
<html>
<head><title>Authentication Successful</title></head>
<body style="font-family: system-ui; text-align: center; padding: 50px;">
    <h1>Authentication Successful</h1>
    <p>You can close this window and return to the terminal.</p>
</body>
</html>"""
                self.wfile.write(html.encode())

            def _send_error_response(self, error: str) -> None:
                """Send error HTML response."""
                self.send_response(400)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                html = f"""<!DOCTYPE html>
<html>
<head><title>Authentication Failed</title></head>
<body style="font-family: system-ui; text-align: center; padding: 50px;">
    <h1>Authentication Failed</h1>
    <p>{error}</p>
</body>
</html>"""
                self.wfile.write(html.encode())

            def log_message(self, format: str, *args: object) -> None:
                """Suppress HTTP server logs."""
                pass

        return CallbackHandler

    def start_callback_server(self) -> socketserver.TCPServer:
        """Start local HTTP server for OAuth callback.

        Returns:
            TCP server instance.
        """
        socketserver.TCPServer.allow_reuse_address = True
        server = socketserver.TCPServer(("", self.local_port), self._create_callback_handler())
        thread = threading.Thread(target=server.serve_forever)
        thread.daemon = True
        thread.start()
        return server

    def wait_for_callback(self, timeout: float = 300.0) -> AuthResult:
        """Wait for the OAuth callback.

        Args:
            timeout: Timeout in seconds (default: 5 minutes).

        Returns:
            Authentication result.
        """
        self._server_stop.wait(timeout=timeout)
        return self._auth_result

    def exchange_code(self) -> dict[str, Any]:
        """Exchange authorization code for tokens.

        Returns:
            Token response with access_token, refresh_token, expires_in.

        Raises:
            ValueError: If exchange fails.
        """
        if not self._auth_result.code:
            raise ValueError("No authorization code available")

        if self._auth_result.state != self.state:
            raise ValueError(
                f"State mismatch: expected {self.state}, got {self._auth_result.state}"
            )

        response = httpx.post(
            f"{self.base_url}/api/v1/auth/token",
            json={
                "grant_type": "authorization_code",
                "code": self._auth_result.code,
                "code_verifier": self.code_verifier,
                "client_id": CLIENT_ID,
                "redirect_uri": self.redirect_uri,
            },
            timeout=30.0,
        )

        if response.status_code != 200:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise ValueError(f"Token exchange failed: {detail}")

        return cast(dict[str, Any], response.json())


def run_login_flow(
    profile: str,
    no_browser: bool = False,
    local_port: int = 8080,
) -> bool:
    """Run the complete OAuth login flow.

    Args:
        profile: Profile to authenticate.
        no_browser: If True, print URL instead of opening browser.
        local_port: Port for callback server.

    Returns:
        True if authentication succeeded.

    Raises:
        Exception: On authentication failure.
    """
    flow = OAuthFlow(profile=profile, local_port=local_port)

    # Start callback server
    server = flow.start_callback_server()

    try:
        # Open browser or print URL
        if no_browser:
            print(f"\nOpen this URL in your browser:\n{flow.authorization_url}\n")
        else:
            webbrowser.open(flow.authorization_url)

        # Wait for callback
        result = flow.wait_for_callback()

        if result.error:
            raise ValueError(f"Authentication failed: {result.error}")

        if not result.code:
            raise ValueError("No authorization code received (timeout?)")

        # Exchange code for tokens
        tokens = flow.exchange_code()

        # Save tokens
        save_tokens(
            access_token=str(tokens["access_token"]),
            expires_in=int(tokens["expires_in"]),
            refresh_token=str(tokens["refresh_token"]) if tokens.get("refresh_token") else None,
            profile=profile,
        )

        return True

    finally:
        server.shutdown()
