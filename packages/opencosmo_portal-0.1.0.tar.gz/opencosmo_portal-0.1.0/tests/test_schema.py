"""Tests for CLI schema flattening and reconstruction utilities."""

from typing import Any

from ocp.utils.schema import ParameterMapping, flatten_schema, reconstruct_input

# ==================== Flatten Schema Tests ====================


class TestFlattenSchema:
    """Tests for flatten_schema function."""

    def test_flat_schema_unchanged(self):
        """Flat schema should pass through unchanged."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name"],
        }
        flat, mappings = flatten_schema(schema)

        assert flat["properties"]["name"]["type"] == "string"
        assert flat["properties"]["age"]["type"] == "integer"
        assert "name" in flat["required"]
        assert len(mappings) == 2

    def test_nested_schema_flattens_to_path_names(self):
        """Nested schema should flatten using path-based names."""
        schema = {
            "type": "object",
            "properties": {
                "user": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                    },
                    "required": ["name"],
                },
            },
            "required": ["user"],
        }
        flat, mappings = flatten_schema(schema)

        assert "user_name" in flat["properties"]
        assert "user_email" in flat["properties"]
        assert "user" not in flat["properties"]
        # user_name is required because both user and name are required
        assert "user_name" in flat.get("required", [])
        # user_email is not required because it's not in user.required
        assert "user_email" not in flat.get("required", [])

    def test_path_names_avoid_collision(self):
        """Path-based names prevent collisions from duplicate leaf names."""
        schema = {
            "type": "object",
            "properties": {
                "user": {
                    "type": "object",
                    "properties": {"id": {"type": "string"}},
                },
                "order": {
                    "type": "object",
                    "properties": {"id": {"type": "string"}},
                },
            },
        }
        flat, mappings = flatten_schema(schema)

        assert "user_id" in flat["properties"]
        assert "order_id" in flat["properties"]

    def test_required_propagation(self):
        """Field is required only if ALL ancestors are required."""
        schema = {
            "type": "object",
            "properties": {
                "optional_parent": {
                    "type": "object",
                    "properties": {
                        "required_child": {"type": "string"},
                    },
                    "required": ["required_child"],
                },
            },
            # optional_parent is NOT required
        }
        flat, _ = flatten_schema(schema)

        # required_child should NOT be required in flat schema
        # because optional_parent is not required
        assert "optional_parent_required_child" not in flat.get("required", [])

    def test_deep_nesting(self):
        """Test deeply nested schema flattening."""
        schema = {
            "type": "object",
            "properties": {
                "a": {
                    "type": "object",
                    "properties": {
                        "b": {
                            "type": "object",
                            "properties": {
                                "c": {
                                    "type": "object",
                                    "properties": {
                                        "value": {"type": "string"},
                                    },
                                },
                            },
                        },
                    },
                },
            },
        }
        flat, mappings = flatten_schema(schema)

        assert "a_b_c_value" in flat["properties"]
        assert len(mappings) == 1
        assert mappings[0].path == ["a", "b", "c", "value"]

    def test_preserves_property_metadata(self):
        """Flattening should preserve property metadata."""
        schema = {
            "type": "object",
            "properties": {
                "count": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "description": "Number of items",
                    "default": 10,
                },
            },
        }
        flat, _ = flatten_schema(schema)

        assert flat["properties"]["count"]["type"] == "integer"
        assert flat["properties"]["count"]["minimum"] == 1
        assert flat["properties"]["count"]["maximum"] == 100
        assert flat["properties"]["count"]["description"] == "Number of items"
        assert flat["properties"]["count"]["default"] == 10

    def test_preserves_root_metadata(self):
        """Flattening should preserve root-level schema metadata."""
        schema = {
            "type": "object",
            "title": "Query Parameters",
            "description": "Parameters for the query",
            "properties": {
                "name": {"type": "string"},
            },
        }
        flat, _ = flatten_schema(schema)

        assert flat["title"] == "Query Parameters"
        assert flat["description"] == "Parameters for the query"

    def test_empty_schema(self):
        """Empty schema should return empty flat schema."""
        schema: dict[str, Any] = {"type": "object", "properties": {}}
        flat, mappings = flatten_schema(schema)

        assert flat["properties"] == {}
        assert "required" not in flat
        assert mappings == []


# ==================== Reconstruct Input Tests ====================


class TestReconstructInput:
    """Tests for reconstruct_input function."""

    def test_simple_reconstruction(self):
        """Simple flat input reconstructs to nested."""
        mappings = [
            ParameterMapping(flat_name="name", path=["user", "name"], required=True),
            ParameterMapping(flat_name="email", path=["user", "email"], required=False),
        ]
        flat_input = {"name": "Alice", "email": "alice@example.com"}

        result = reconstruct_input(flat_input, mappings)

        assert result == {
            "user": {
                "name": "Alice",
                "email": "alice@example.com",
            }
        }

    def test_skip_missing_optional(self):
        """Missing optional fields should not appear in output."""
        mappings = [
            ParameterMapping(flat_name="name", path=["name"], required=True),
            ParameterMapping(flat_name="age", path=["age"], required=False),
        ]
        flat_input = {"name": "Bob"}  # age not provided

        result = reconstruct_input(flat_input, mappings)

        assert result == {"name": "Bob"}
        assert "age" not in result

    def test_deep_nesting(self):
        """Deeply nested paths reconstruct correctly."""
        mappings = [
            ParameterMapping(
                flat_name="value",
                path=["a", "b", "c", "value"],
                required=True,
            ),
        ]
        flat_input = {"value": 42}

        result = reconstruct_input(flat_input, mappings)

        assert result == {"a": {"b": {"c": {"value": 42}}}}

    def test_multiple_siblings(self):
        """Multiple fields in same parent reconstruct correctly."""
        mappings = [
            ParameterMapping(flat_name="first", path=["name", "first"], required=True),
            ParameterMapping(flat_name="last", path=["name", "last"], required=True),
            ParameterMapping(flat_name="age", path=["age"], required=False),
        ]
        flat_input = {"first": "John", "last": "Doe", "age": 30}

        result = reconstruct_input(flat_input, mappings)

        assert result == {
            "name": {"first": "John", "last": "Doe"},
            "age": 30,
        }

    def test_skip_none_optional(self):
        """None values for optional fields should be skipped."""
        mappings = [
            ParameterMapping(flat_name="name", path=["name"], required=True),
            ParameterMapping(flat_name="age", path=["age"], required=False),
        ]
        flat_input = {"name": "Alice", "age": None}

        result = reconstruct_input(flat_input, mappings)

        assert result == {"name": "Alice"}
        assert "age" not in result

    def test_keep_none_required(self):
        """None values for required fields should be kept."""
        mappings = [
            ParameterMapping(flat_name="name", path=["name"], required=True),
        ]
        flat_input = {"name": None}

        result = reconstruct_input(flat_input, mappings)

        assert result == {"name": None}


# ==================== Round Trip Tests ====================


def _extract_subschema(schema: dict[str, Any], prefix: str) -> dict[str, Any]:
    """Extract sub-schema at a dot-separated prefix path (test helper).

    Inlined from app.utils.schema to avoid cross-package dependency.
    """
    parts = prefix.split(".")
    current = schema
    for i, part in enumerate(parts):
        properties = current.get("properties")
        if not isinstance(properties, dict) or part not in properties:
            traversed = ".".join(parts[:i])
            context = f" (after '{traversed}')" if traversed else ""
            raise ValueError(f"input_prefix '{prefix}': '{part}' not found in properties{context}")
        current = properties[part]
    return current


def _nest_under_prefix(data: dict[str, Any], prefix: str) -> dict[str, Any]:
    """Wrap a dict under nested keys from a dot-separated prefix (test helper).

    Inlined from app.utils.schema to avoid cross-package dependency.
    """
    result = data
    for part in reversed(prefix.split(".")):
        result = {part: result}
    return result


class TestRoundTrip:
    """Test flatten then reconstruct returns original structure."""

    def test_flat_roundtrip(self):
        """Flat schema roundtrips correctly."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "count": {"type": "integer"},
            },
        }
        flat, mappings = flatten_schema(schema)

        original_input = {"name": "test", "count": 42}
        reconstructed = reconstruct_input(original_input, mappings)

        assert reconstructed == original_input

    def test_nested_roundtrip(self):
        """Nested schema roundtrips correctly via path-based names."""
        schema = {
            "type": "object",
            "properties": {
                "query": {
                    "type": "object",
                    "properties": {
                        "dataset": {"type": "string"},
                        "format": {"type": "string"},
                    },
                },
            },
        }
        _, mappings = flatten_schema(schema)

        flat_input = {"query_dataset": "cosmos1", "query_format": "hdf5"}
        reconstructed = reconstruct_input(flat_input, mappings)

        assert reconstructed == {
            "query": {
                "dataset": "cosmos1",
                "format": "hdf5",
            }
        }

    def test_full_pipeline_roundtrip(self):
        """Full pipeline: extract -> flatten -> reconstruct -> nest."""
        full_schema = {
            "type": "object",
            "properties": {
                "input": {
                    "type": "object",
                    "properties": {
                        "params": {
                            "type": "object",
                            "properties": {
                                "simulation": {"type": "string"},
                                "filters": {
                                    "type": "object",
                                    "properties": {
                                        "mass_min": {"type": "number"},
                                    },
                                },
                            },
                            "required": ["simulation"],
                        },
                    },
                },
            },
        }
        prefix = "input.params"

        # Extract and flatten
        sub = _extract_subschema(full_schema, prefix)
        flat, mappings = flatten_schema(sub)

        assert "simulation" in flat["properties"]
        assert "filters_mass_min" in flat["properties"]

        # User submits flat input
        flat_input = {"simulation": "SIM_A", "filters_mass_min": 1e10}

        # Reconstruct and nest
        reconstructed = reconstruct_input(flat_input, mappings)
        nested = _nest_under_prefix(reconstructed, prefix)

        assert nested == {
            "input": {
                "params": {
                    "simulation": "SIM_A",
                    "filters": {"mass_min": 1e10},
                }
            }
        }
