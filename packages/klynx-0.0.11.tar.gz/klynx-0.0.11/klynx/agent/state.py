"""
Klynx Agent - 状态定义
AgentState TypedDict 用于 LangGraph StateGraph 状态管理
"""

from typing import TypedDict, List, Annotated, Dict, Any
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages


class AgentState(TypedDict):
    """全局状态"""
    # 消息历史（支持追加/覆盖/RemoveMessage 删除）
    messages: Annotated[List[BaseMessage], add_messages]
    
    # 环境快照 - 每次 LLM 运行前动态更新
    env_snapshot: str
    
    # 待执行的工具调用
    pending_tool_calls: List[Dict[str, Any]]
    
    # 迭代计数器
    iteration_count: int
    
    # 工作目录
    working_dir: str
    
    # 任务完成状态
    task_completed: bool
    
    # 最后动作类型: "think" | "observe" | "act"
    last_action: str
    
    # 连续空回复计数
    empty_response_count: int
    
    # Token 使用统计
    total_tokens: int
    prompt_tokens: int
    completion_tokens: int
    
    # 总任务目标（通常由用户输入初始化，可在执行过程中通过 update_task_state 更新）
    overall_goal: str
    
    # 当前任务目标（可由模型通过 <task_goal> 或 update_task_state 更新）
    current_task: str
    
    # 上下文摘要（当历史过长时）
    context_summary: str
    
    # 最大上下文长度（token数）
    max_context_tokens: int
    
    # 进度摘要 - 记录已完成的关键操作
    progress_summary: str
    
    # 任务类型: "ask" | "thinking"
    task_type: str
    
    # 上下文变量 - 存储历史对话和文档读取的内容
    context: str
    
    # 用户原始输入
    user_input: str
    
    # DeepSeek 思考内容 - 存储模型的 reasoning_content
    reasoning_content: str
    
    # 上下文是否已被总结
    context_summarized: bool
    
    # KLYNX.md 文档内容（由 load_context 节点填充）
    klynx_docs: str
    
    # 项目规则（由 init 节点从 .klynx/.rules 加载）
    project_rules: str
    
    # summary 节点的总结内容
    summary_content: str

    # 无工具调用且已给出文本答复时的直接结束标记
    ended_without_tools: bool

    # 是否进入“候选完成”状态（由 attempt_completion 触发，待 verify_completion 裁决）
    completion_candidate: bool

    # attempt_completion 提交的结果文本（用于完成校验）
    completion_candidate_result: str

    # 完成校验结果: "accept" | "retry" | "clarify"
    verification_decision: str

    # 是否需要用户确认后再继续（例如遇到登录墙需要切换方案）
    needs_user_confirmation: bool

    # 需要向用户提出的澄清/确认问题
    clarification_question: str

    # 当前会话已加载的技能名称列表
    loaded_skill_names: List[str]

    # 通过 load_skill 注入上下文的 SKILL.md 内容
    skill_context: str

    # TUI 交互指南是否已加载（由 activate_tui_mode 工具触发）
    tui_guide_loaded: bool
    
    # 是否将思考内容添加到上下文 (由 invoke 参数控制)
    thinking_context: bool

    # Appended system prompt (append-only, never replaces core prompt)
    system_prompt_append: str
