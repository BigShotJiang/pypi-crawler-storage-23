"""
Kepler Wind - 量化数据API

优雅的量化数据访问接口，按资产分类，每个资产提供截面和时序查询方法。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/db")

    # 高层 API
    >>> w.universe.members("HS300")           # 当前成分股
    >>> w.index.history("000001.SH")          # 历史数据
    >>> w.calendar.dates                      # 交易日历

    # 底层 ORM
    >>> table = w.aindexeodprices
    >>> df = w.query(table).filter(table.trade_dt >= "20240101").to_df()
"""

from kepler.wind.wind import Wind, get_wind

__all__ = [
    'Wind',
    'get_wind',
]
