"""
Wind 门面类 - 统一入口

继承 DataBase，提供高层 API 和底层 ORM 访问。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/db")

    # 高层 API
    >>> w.index.history("000001.SH")

    # 底层 ORM
    >>> w.query(w.aindexeodprices).filter(...).to_df()
"""

from typing import Optional

from kepler.atlas import DataBase
from sqlalchemy import create_engine

from kepler.wind.db import ConfigManager, set_db
from kepler.wind.pulse import CalendarAPI
from kepler.wind.universe import UniverseAPI
from kepler.wind.index import IndexAPI
from kepler.wind.returns import ReturnsAPI
from kepler.wind.industry import IndustryAPI
from kepler.wind.fund import FundAPI


class Wind(DataBase):
    """量化数据统一入口

    继承 DataBase，同时提供：
    - 高层 API：w.index, w.universe 等
    - 底层 ORM：w.query(), w.aindexeodprices 等

    Args:
        url: 数据库连接URL，如 "mysql+pymysql://user:pass@host:3306/db"
             如果为 None，则从配置文件 ~/.kepler/wind/wind.toml 读取
        schema: 数据库schema，MySQL 通常为 None，PostgreSQL 为 "public"

    Examples:
        >>> w = Wind()  # 从配置文件读取
        >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/wind")

        # 高层 API
        >>> w.universe.members("HS300")
        >>> w.index.history("000001.SH")

        # 底层 ORM
        >>> table = w.aindexeodprices
        >>> df = w.query(table).filter(table.trade_dt >= "20240101").to_df()
    """

    def __init__(self, url: Optional[str] = None, schema: Optional[str] = None):
        # 获取数据库配置
        if url is None:
            config = ConfigManager()
            db_config = config.get_database_config()
            if db_config is None or db_config['engine'] is None:
                config_path = config.config_file
                raise ValueError(
                    f"数据库未配置。请设置配置文件 {config_path}:\n"
                    f"```toml\n"
                    f"[wind]\n"
                    f"engine = \"mysql+pymysql://user:pass@host:3306/db\"\n"
                    f"schema = \"\"\n"
                    f"```\n"
                    f"或在 Wind 初始化时传入 url 参数:\n"
                    f"  w = Wind(url='mysql+pymysql://user:pass@host:3306/db')"
                )
            url = db_config['engine']
            schema = db_config['schema']

        # 初始化 DataBase
        engine = create_engine(url)
        super().__init__(engine, schema)

        # 设置全局数据库连接（供 pulse.py 等模块使用）
        set_db(self)

        # 初始化高层 API（传入 self 作为 db）
        self._calendar = CalendarAPI(self)
        self._universe = UniverseAPI(self)
        self._index = IndexAPI(self)
        self._returns = ReturnsAPI(self)
        self._industry = IndustryAPI(self)
        self._fund = FundAPI(self)

    @property
    def calendar(self) -> CalendarAPI:
        """交易日历 API"""
        return self._calendar

    @property
    def universe(self) -> UniverseAPI:
        """股票池 API"""
        return self._universe

    @property
    def index(self) -> IndexAPI:
        """指数 API"""
        return self._index

    @property
    def returns(self) -> ReturnsAPI:
        """收益率 API"""
        return self._returns

    @property
    def industry(self) -> IndustryAPI:
        """行业 API"""
        return self._industry

    @property
    def fund(self) -> FundAPI:
        """基金 API"""
        return self._fund


# 全局单例（延迟初始化）
_wind: Optional[Wind] = None


def get_wind() -> Wind:
    """获取全局 Wind 实例"""
    global _wind
    if _wind is None:
        _wind = Wind()
    return _wind


__all__ = ['Wind', 'get_wind']
