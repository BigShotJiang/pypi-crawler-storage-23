"""
指数模块

提供指数数据的截面和时序查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.index.history("000001.SH")              # 时序：指数历史数据
    >>> w.index.weight("000300.SH")               # 权重：指数成分权重
"""

from functools import lru_cache
from typing import Optional, Union, List, Set

import pandas as pd


class IndexAPI:
    """指数 API

    提供指数数据的截面和时序查询功能。
    """

    def __init__(self, db):
        self.db = db

    def history(
        self,
        codes: Union[str, List[str], Set[str]],
        start: str = "20010101",
        end: str = "20990101"
    ) -> pd.DataFrame:
        """时序：指数历史数据（自动识别指数类型）

        自动根据代码识别指数类型：
        - .SI 结尾 → 申万指数
        - CI 开头 → 中信指数
        - 88 开头 → Wind行业指数
        - 其他 → 普通指数

        Args:
            codes: 指数代码，支持单个或多个
            start: 开始日期
            end: 结束日期

        Returns:
            DataFrame with columns: sid, trade_dt, open, high, low, close, volume, amount

        Examples:
            >>> w.index.history("000001.SH")           # 普通指数
            >>> w.index.history("801010.SI")           # 申万指数
            >>> w.index.history("CI005001.WI")         # 中信指数
            >>> w.index.history(["000001.SH", "000300.SH"])
        """
        start = str(start).replace("-", "")
        end = str(end).replace("-", "")

        # 标准化代码为集合
        if isinstance(codes, str):
            code_set = {codes}
        else:
            code_set = set(codes)

        # 根据代码自动分类指数
        sw_codes = {c for c in code_set if c.endswith(".SI")}
        zx_codes = {c for c in code_set if c.startswith("CI")}
        wind_codes = {c for c in code_set if c.startswith("88")}
        normal_codes = code_set - sw_codes - zx_codes - wind_codes

        # 分别查询各类指数
        dfs = []
        if normal_codes:
            dfs.append(self._query_normal(normal_codes, start, end))
        if sw_codes:
            dfs.append(self._query_sw(sw_codes, start, end))
        if zx_codes:
            dfs.append(self._query_zx(zx_codes, start, end))
        if wind_codes:
            dfs.append(self._query_wind(wind_codes, start, end))

        # 合并结果
        if dfs:
            df = pd.concat(dfs, axis=0, ignore_index=True)
            df = df.sort_values(['trade_dt', 'sid']).reset_index(drop=True)
            return df
        else:
            return pd.DataFrame(columns=['sid', 'trade_dt', 'open', 'high', 'low', 'close', 'volume', 'amount'])

    def _query_normal(self, codes: Set[str], start: str, end: str) -> pd.DataFrame:
        """查询普通指数"""
        table = self.db.aindexeodprices
        return self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_dq_open.label("open"),
            table.s_dq_high.label("high"),
            table.s_dq_low.label("low"),
            table.s_dq_close.label("close"),
            table.s_dq_volume.label("volume"),
            table.s_dq_amount.label("amount"),
        ).filter(
            table.trade_dt >= start,
            table.trade_dt <= end,
            table.s_info_windcode.in_(list(codes))
        ).to_df()

    def _query_sw(self, codes: Set[str], start: str, end: str) -> pd.DataFrame:
        """查询申万指数"""
        table = self.db.aswsindexeod
        return self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_dq_open.label("open"),
            table.s_dq_high.label("high"),
            table.s_dq_low.label("low"),
            table.s_dq_close.label("close"),
            table.s_dq_volume.label("volume"),
            table.s_dq_amount.label("amount"),
        ).filter(
            table.trade_dt >= start,
            table.trade_dt <= end,
            table.s_info_windcode.in_(list(codes))
        ).to_df()

    def _query_zx(self, codes: Set[str], start: str, end: str) -> pd.DataFrame:
        """查询中信指数"""
        table = self.db.aindexindustrieseodcitics
        return self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_dq_open.label("open"),
            table.s_dq_high.label("high"),
            table.s_dq_low.label("low"),
            table.s_dq_close.label("close"),
            table.s_dq_volume.label("volume"),
            table.s_dq_amount.label("amount"),
        ).filter(
            table.trade_dt >= start,
            table.trade_dt <= end,
            table.s_info_windcode.in_(list(codes))
        ).to_df()

    def _query_wind(self, codes: Set[str], start: str, end: str) -> pd.DataFrame:
        """查询Wind行业指数"""
        table = self.db.aindexwindindustrieseod
        return self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_dq_open.label("open"),
            table.s_dq_high.label("high"),
            table.s_dq_low.label("low"),
            table.s_dq_close.label("close"),
            table.s_dq_volume.label("volume"),
            table.s_dq_amount.label("amount"),
        ).filter(
            table.trade_dt >= start,
            table.trade_dt <= end,
            table.s_info_windcode.in_(list(codes))
        ).to_df()

    def weight(
        self,
        index: str,
        date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取指数成分权重

        Args:
            index: 指数代码
            date: 交易日期，None 表示最新

        Returns:
            DataFrame with columns: sid, weight

        Examples:
            >>> w.index.weight("000300.SH")
            >>> w.index.weight("000300.SH", date="20240101")
        """
        import datetime as dt

        if date is None:
            date = dt.date.today().strftime("%Y%m%d")
        else:
            date = str(date).replace("-", "")

        # 调整到最近的交易日
        date = self.db.calendar.adjust(date, direction="prev")

        df = self._get_weight_all(index).copy()
        df = df[df["trade_dt"] <= date]

        if df.empty:
            return pd.DataFrame()

        # 取最近一个交易日的权重
        t = df.trade_dt.iloc[0]
        df = df[df["trade_dt"] == t]
        df = df.drop(columns=["trade_dt"])

        return df.reset_index(drop=True)

    @lru_cache(maxsize=32)
    def _get_weight_all(self, index: str) -> pd.DataFrame:
        """获取指数所有历史权重"""
        # 沪深300用自由流通权重表
        if index == "000300.SH":
            table = self.db.aindexhs300freeweight
            index_code = "399300.SZ"
        else:
            table = self.db.aindexweight
            index_code = index

        df = self.db.query(
            table.s_con_windcode.label("sid"),
            table.i_weight.label("weight"),
            table.trade_dt
        ).filter(
            table.s_info_windcode == index_code
        ).order_by(
            table.trade_dt.desc()
        ).to_df()

        df["weight"] = df["weight"] / 100.0
        return df


__all__ = ['IndexAPI']
