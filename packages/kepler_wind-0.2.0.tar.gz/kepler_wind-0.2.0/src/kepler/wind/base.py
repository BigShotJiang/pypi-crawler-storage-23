"""
基础类模块

提供 API 基础抽象类。
"""

from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import List, Set, Union

import pandas as pd

from kepler.wind.db import WIND_DB


class BaseAPI(ABC):
    """API 基础抽象类

    提供通用的数据库查询功能。
    """

    def __init__(self, database=None):
        self.db = database or WIND_DB

    @abstractmethod
    def get_table_name(self) -> str:
        """获取表名，子类必须实现"""
        pass

    def get_table(self):
        """获取数据库表对象"""
        table_name = self.get_table_name()
        return getattr(self.db, table_name.lower())

    def filter_by_codes(self, query, code_column: str, codes: Union[str, List[str], Set[str]]):
        """根据代码过滤查询结果"""
        table = self.get_table()
        code_attr = getattr(table, code_column)

        if isinstance(codes, str):
            return query.filter(code_attr == codes)
        elif isinstance(codes, Iterable):
            return query.filter(code_attr.in_(codes))
        else:
            raise ValueError(f"codes must be str or Iterable, got {type(codes)}")

    def filter_by_date_range(self, query, date_column: str, begin_dt: str, end_dt: str):
        """根据日期范围过滤查询结果"""
        table = self.get_table()
        date_attr = getattr(table, date_column)
        return query.filter(date_attr >= begin_dt, date_attr <= end_dt)

    def filter_current(self, query, current_column: str = "cur_sign"):
        """只查询当前有效的记录"""
        table = self.get_table()
        current_attr = getattr(table, current_column)
        return query.filter(current_attr == "1")


__all__ = ['BaseAPI']
