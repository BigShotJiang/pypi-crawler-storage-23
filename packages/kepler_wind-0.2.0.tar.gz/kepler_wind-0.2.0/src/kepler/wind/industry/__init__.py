"""
行业模块

提供行业分类的截面和时序查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.industry.on("20240101")                  # 截面：某日所有股票行业
    >>> w.industry.of("000001.SZ")                 # 单股行业
"""

from functools import lru_cache
from typing import Optional, Union, List, Set

import pandas as pd


class IndustryAPI:
    """行业 API

    提供行业分类的截面和时序查询功能。
    """

    def __init__(self, db):
        self.db = db

    def on(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]] = None,
        level: int = 1,
        source: str = "zx"
    ) -> pd.DataFrame:
        """截面：某日所有股票的行业分类

        Args:
            date: 交易日期
            sid: 股票代码（可选，用于筛选）
            level: 行业级别 (1, 2, 3)
            source: 数据源 ("zx" 中信, "wind" Wind)

        Returns:
            DataFrame: sid → industry

        Examples:
            >>> w.industry.on("20240101")
            >>> w.industry.on("20240101", level=2)
        """
        date = str(date).replace("-", "")

        if source == "zx":
            return self._get_zx_industry(date, sid, level)
        elif source == "wind":
            return self._get_wind_industry(date, sid, level)
        else:
            raise ValueError(f"Unknown source: {source}")

    def of(
        self,
        sid: Union[str, List[str], Set[str]],
        date: Optional[str] = None,
        level: int = 1,
        source: str = "zx"
    ) -> pd.DataFrame:
        """获取股票的行业分类

        Args:
            sid: 股票代码
            date: 交易日期，None 表示当前
            level: 行业级别
            source: 数据源

        Returns:
            DataFrame

        Examples:
            >>> w.industry.of("000001.SZ")
            >>> w.industry.of("000001.SZ", date="20240101")
        """
        if date is None:
            date = "20990101"
        return self.on(date, sid=sid, level=level, source=source)

    def _get_zx_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]],
        level: int
    ) -> pd.DataFrame:
        """中信行业分类"""
        df = self._get_zx_all(level).copy()

        # 过滤日期
        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=4)
    def _get_zx_all(self, level: int) -> pd.DataFrame:
        """获取所有中信行业数据"""
        table = self.db.ashareindustriesclasscitics
        code_table = self.db.ashareindustriescode

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt,
            table.remove_dt.label("out_dt"),
            code_table.industriesname.label("ind")
        ).filter(
            code_table.levelnum == level,
            table.citics_ind_code == code_table.industriescode
        ).to_df()

        return df

    def _get_wind_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]],
        level: int
    ) -> pd.DataFrame:
        """Wind行业分类"""
        df = self._get_wind_all(level).copy()

        # 过滤日期
        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=4)
    def _get_wind_all(self, level: int) -> pd.DataFrame:
        """获取所有Wind行业数据"""
        table = self.db.ashareindustriesclass
        code_table = self.db.ashareindustriescode

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt,
            table.remove_dt.label("out_dt"),
            code_table.industriesname.label("ind")
        ).filter(
            code_table.levelnum == level,
            table.wind_ind_code == code_table.industriescode
        ).to_df()

        return df


__all__ = ['IndustryAPI']
