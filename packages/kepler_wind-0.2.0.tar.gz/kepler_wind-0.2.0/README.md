# Kepler Wind

优雅的量化数据访问接口，基于 Wind 金融终端数据库。

## 安装

```bash
pip install kepler-wind
```

## 快速开始

```python
from kepler.wind import Wind

w = Wind()
```

## API 设计

按资产分类，每个资产提供截面和时序查询方法。

### 股票池

```python
# 当前成分股
w.universe.members("HS300")

# 历史成分股
w.universe.at("HS300", "20240101")

# 完整变更历史
w.universe.history("HS300")

# 支持的指数
w.universe.members("A")        # 全A股
w.universe.members("ZZ500")    # 中证500
w.universe.members("MSCI")     # MSCI
```

### 指数

```python
# 历史数据（自动识别指数类型）
w.index.history("000001.SH")                    # 普通指数
w.index.history("801010.SI")                    # 申万指数
w.index.history("CI005001.WI")                  # 中信指数
w.index.history("884001.WI")                    # Wind行业指数
w.index.history(["000001.SH", "801010.SI"])     # 混合查询

# 成分权重
w.index.weight("000300.SH")
w.index.weight("000300.SH", date="20240101")
```

### 收益率

```python
# 截面：某日所有股票收益率
w.returns.on("20240101")

# 时序：日收益率
w.returns.daily("000001.SZ")
w.returns.daily(["000001.SZ", "000002.SZ"])

# 时序：月收益率
w.returns.monthly("000001.SZ")
```

### 行业

```python
# 截面：某日所有股票行业
w.industry.on("20240101")
w.industry.on("20240101", level=2)  # 二级行业

# 单股行业
w.industry.of("000001.SZ")
w.industry.of("000001.SZ", date="20240101")
```

### 基金

```python
# 历史净值
w.fund.history("000001.OF")

# 筛选基金
w.fund.filter(type="股票型")
```

## 迁移指南

从旧版本迁移到新版本的 API 对照：

### 股票池

| 旧 API | 新 API |
|--------|--------|
| `universe_A()` | `w.universe.members("A")` |
| `universe_A(cur_sign=False)` | `w.universe.history("A")` |
| `universe_normal("HS300")` | `w.universe.members("HS300")` |
| `universe_normal("HS300", cur_sign=False)` | `w.universe.at("HS300", date)` |
| `universe_msci()` | `w.universe.members("MSCI")` |
| `Universe("HS300")` | `w.universe.members("HS300")` |
| `get_all_normal_index("HS300")` | `w.universe.members("HS300")` |
| `get_all_msci()` | `w.universe.members("MSCI")` |
| `get_all_stk()` | `w.universe.members("A")` |
| `get_all_hk("HS300")` | `w.universe.members("HK")` |

### 指数

| 旧 API | 新 API |
|--------|--------|
| `get_index_data("000001.SH")` | `w.index.history("000001.SH")` |
| `get_index_data(["000001.SH", "801010.SI"])` | `w.index.history(["000001.SH", "801010.SI"])` |
| `get_index_data_tmp(codes, "zx")` | `w.index.history(codes)` (自动识别) |
| `get_index_weight("000300.SH")` | `w.index.weight("000300.SH")` |
| `get_index_weight("000300.SH", "20240101")` | `w.index.weight("000300.SH", date="20240101")` |

### 收益率

| 旧 API | 新 API |
|--------|--------|
| `get_daily_ret("000001.SZ")` | `w.returns.daily("000001.SZ")` |
| `get_daily_ret(["000001.SZ", "000002.SZ"])` | `w.returns.daily(["000001.SZ", "000002.SZ"])` |
| `get_monthly_ret("000001.SZ")` | `w.returns.monthly("000001.SZ")` |

### 行业

| 旧 API | 新 API |
|--------|--------|
| `get_industry("20240101")` | `w.industry.on("20240101")` |
| `get_industry("20240101", sid="000001.SZ")` | `w.industry.of("000001.SZ", date="20240101")` |
| `get_industry("20240101", level=2)` | `w.industry.on("20240101", level=2)` |
| `get_industry_hk("20240101")` | `w.industry.on("20240101", source="wind")` |
| `get_industry_windhk("20240101", level=2)` | `w.industry.on("20240101", level=2, source="wind")` |

### 基金

| 旧 API | 新 API |
|--------|--------|
| `get_fund_nav("000001.OF")` | `w.fund.history("000001.OF")` |
| `get_fund_nav(["000001.OF", "000002.OF"])` | `w.fund.history(["000001.OF", "000002.OF"])` |
| `get_fund_list()` | `w.fund.filter()` |
| `get_fund_filter("股票型")` | `w.fund.filter(type="股票型")` |

## 配置

### 方式一：配置文件

配置文件位于 `~/.kepler/wind/wind.toml`：

```toml
[wind]
engine = "mysql+pymysql://user:pass@host:3306/db"
schema = ""  # MySQL 留空，PostgreSQL 填 "public"
```

### 方式二：代码传入

```python
from kepler.wind import Wind

# MySQL
w = Wind(url="mysql+pymysql://user:pass@host:3306/wind")

# PostgreSQL
w = Wind(url="postgresql://user:pass@host:5432/db", schema="public")
```

## 依赖

- kepler-atlas >= 0.1.5
- kepler-pulse >= 0.1.8
- pandas
- sqlalchemy

## License

MIT
