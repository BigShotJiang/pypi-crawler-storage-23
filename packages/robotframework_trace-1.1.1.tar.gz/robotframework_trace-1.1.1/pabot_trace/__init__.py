from .PabotTraceReporter import PabotTraceReporter as pabot_trace

__all__ = ["pabot_trace"]
__version__ = "1.1.1"
