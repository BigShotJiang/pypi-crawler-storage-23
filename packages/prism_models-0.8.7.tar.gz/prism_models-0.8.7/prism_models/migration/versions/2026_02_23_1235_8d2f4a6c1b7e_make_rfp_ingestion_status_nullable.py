"""Make rfp ingestion_status nullable

Revision ID: 8d2f4a6c1b7e
Revises: f4c6b7d2a1e9
Create Date: 2026-02-23 12:35:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8d2f4a6c1b7e'
down_revision: Union[str, Sequence[str], None] = 'f4c6b7d2a1e9'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.alter_column(
        'rfp',
        'ingestion_status',
        existing_type=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            name='rfpingestionstatus',
            native_enum=False,
        ),
        nullable=True,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.execute("UPDATE rfp SET ingestion_status = 'PENDING' WHERE ingestion_status IS NULL")
    op.alter_column(
        'rfp',
        'ingestion_status',
        existing_type=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            name='rfpingestionstatus',
            native_enum=False,
        ),
        nullable=False,
    )

