"""Add ingestion_status to rfp

Revision ID: f4c6b7d2a1e9
Revises: 16c2a9de1d3f
Create Date: 2026-02-23 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f4c6b7d2a1e9'
down_revision: Union[str, Sequence[str], None] = '16c2a9de1d3f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column(
        'rfp',
        sa.Column(
            'ingestion_status',
            sa.Enum(
                'PENDING',
                'PROCESSING',
                'COMPLETED',
                name='rfpingestionstatus',
                native_enum=False,
            ),
            nullable=True,
            server_default='PENDING',
        ),
    )
    op.create_index(op.f('rfp_ingestion_status_idx'), 'rfp', ['ingestion_status'], unique=False)
    op.alter_column('rfp', 'ingestion_status', server_default=None)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f('rfp_ingestion_status_idx'), table_name='rfp')
    op.drop_column('rfp', 'ingestion_status')

