"""Add question_type to rfpqna

Revision ID: b1a2c3d4e5f6
Revises: 8d2f4a6c1b7e
Create Date: 2026-02-24 11:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b1a2c3d4e5f6'
down_revision: Union[str, Sequence[str], None] = '8d2f4a6c1b7e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('rfpqna', sa.Column('question_type', sa.String(length=255), nullable=True))
    op.add_column('rfpqna', sa.Column('relevant_department', sa.String(length=255), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('rfpqna', 'relevant_department')
    op.drop_column('rfpqna', 'question_type')
