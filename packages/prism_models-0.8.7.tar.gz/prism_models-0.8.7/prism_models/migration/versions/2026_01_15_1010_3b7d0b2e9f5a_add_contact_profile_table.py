"""Add contact_profile table

Revision ID: 3b7d0b2e9f5a
Revises: 147509a82af8
Create Date: 2026-01-15 10:10:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


# revision identifiers, used by Alembic.
revision: str = "3b7d0b2e9f5a"
down_revision: Union[str, Sequence[str], None] = "147509a82af8"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.create_table(
        "contact_profile",
        sa.Column("contact_id", sa.Integer(), nullable=False),
        sa.Column("profile_id", sa.Integer(), nullable=False),
        sa.Column("assigned_by_contact_id", sa.Integer(), nullable=True),
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["assigned_by_contact_id"],
            ["contact.id"],
            name=op.f("contact_profile_assigned_by_contact_id_fkey"),
            ondelete="SET NULL",
        ),
        sa.ForeignKeyConstraint(
            ["contact_id"],
            ["contact.id"],
            name=op.f("contact_profile_contact_id_fkey"),
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["profile_id"],
            ["profile.id"],
            name=op.f("contact_profile_profile_id_fkey"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("contact_profile_pkey")),
        sa.UniqueConstraint("contact_id", "profile_id", name="uq_contact_profile"),
    )
    op.create_index(
        op.f("contact_profile_assigned_by_contact_id_idx"),
        "contact_profile",
        ["assigned_by_contact_id"],
        unique=False,
    )
    op.create_index(op.f("contact_profile_contact_id_idx"), "contact_profile", ["contact_id"], unique=False)
    op.create_index(op.f("contact_profile_id_idx"), "contact_profile", ["id"], unique=False)
    op.create_index(op.f("contact_profile_profile_id_idx"), "contact_profile", ["profile_id"], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f("contact_profile_profile_id_idx"), table_name="contact_profile")
    op.drop_index(op.f("contact_profile_id_idx"), table_name="contact_profile")
    op.drop_index(op.f("contact_profile_contact_id_idx"), table_name="contact_profile")
    op.drop_index(op.f("contact_profile_assigned_by_contact_id_idx"), table_name="contact_profile")
    op.drop_table("contact_profile")
