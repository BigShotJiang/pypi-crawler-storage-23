"""set policy_agent display_name to Policy Agent

Revision ID: f2c7a1d4e9b0
Revises: 9d3f2e4b7a11
Create Date: 2026-02-09 12:35:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "f2c7a1d4e9b0"
down_revision: Union[str, Sequence[str], None] = "9d3f2e4b7a11"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    conn = op.get_bind()
    conn.execute(
        sa.text(
            """
            UPDATE agent AS a
            SET display_name = 'Policy Agent',
                updated_at = now()
            WHERE a.name = 'policy_agent'
              AND a.display_name IS DISTINCT FROM 'Policy Agent'
              AND NOT EXISTS (
                  SELECT 1
                  FROM agent AS a2
                  WHERE a2.display_name = 'Policy Agent'
                    AND a2.id <> a.id
              )
            """
        )
    )


def downgrade() -> None:
    """Downgrade schema."""
    conn = op.get_bind()
    conn.execute(
        sa.text(
            """
            UPDATE agent AS a
            SET display_name = 'MSA Main Agent',
                updated_at = now()
            WHERE a.name = 'policy_agent'
              AND a.display_name = 'Policy Agent'
              AND NOT EXISTS (
                  SELECT 1
                  FROM agent AS a2
                  WHERE a2.display_name = 'MSA Main Agent'
                    AND a2.id <> a.id
              )
            """
        )
    )
