"""add workbook_name to rfpqna

Revision ID: 6c4f7f1b9d2a
Revises: 907a4961c5a5
Create Date: 2026-02-09 15:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '6c4f7f1b9d2a'
down_revision: Union[str, Sequence[str], None] = '907a4961c5a5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('rfpqna', sa.Column('workbook_name', sa.String(length=255), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('rfpqna', 'workbook_name')
