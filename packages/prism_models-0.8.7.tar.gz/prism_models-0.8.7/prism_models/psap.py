"""PSAP (Public Safety Answering Point) boundary models."""

from datetime import datetime

from geoalchemy2 import Geometry
from sqlalchemy import BigInteger, Index, Integer, Text
from sqlalchemy.orm import Mapped, mapped_column

from prism_models.base import Base


class PSAPBoundary(Base):
    """PSAP service area boundary with PostGIS geometry.

    Contains official PSAP records with service area polygons from the
    National 911 GIS database.
    """

    __tablename__ = "psap_boundaries"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    objectid: Mapped[int | None] = mapped_column(Integer, unique=True, nullable=True)
    psap_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    psap_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    fcc_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    state_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    telephone: Mapped[str | None] = mapped_column(Text, nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    address2: Mapped[str | None] = mapped_column(Text, nullable=True)
    city: Mapped[str | None] = mapped_column(Text, nullable=True)
    state: Mapped[str | None] = mapped_column(Text, nullable=True)
    zip: Mapped[str | None] = mapped_column(Text, nullable=True)
    county: Mapped[str | None] = mapped_column(Text, nullable=True)
    fips: Mapped[str | None] = mapped_column(Text, nullable=True)
    web: Mapped[str | None] = mapped_column(Text, nullable=True)
    update_date: Mapped[str | None] = mapped_column(Text, nullable=True)

    # PostGIS geometry column - MultiPolygon in EPSG:3857 (Web Mercator)
    boundary: Mapped[bytes] = mapped_column(
        Geometry(geometry_type="MULTIPOLYGON", srid=3857),
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(nullable=False, server_default="now()")

    __table_args__ = (
        Index("idx_psap_boundaries_boundary", "boundary", postgresql_using="gist"),
        Index("idx_psap_boundaries_state", "state"),
        Index("idx_psap_boundaries_city", "city"),
        Index("idx_psap_boundaries_objectid", "objectid"),
    )


__all__ = ["PSAPBoundary"]
