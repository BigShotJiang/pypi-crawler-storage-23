---
name: prowlarr-tagdetails
description: Skills related to tagdetails in Prowlarr.
tags: [prowlarr, tagdetails]
---

# Prowlarr Tagdetails Skill

This skill provides tools for managing tagdetails within Prowlarr.

## Capabilities

- Access tagdetails resources
