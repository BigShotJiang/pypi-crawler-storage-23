---
name: sonarr-calendar
description: Skills related to calendar in Sonarr.
tags: [sonarr, calendar]
---

# Sonarr Calendar Skill

This skill provides tools for managing calendar within Sonarr.

## Capabilities

- Access calendar resources
