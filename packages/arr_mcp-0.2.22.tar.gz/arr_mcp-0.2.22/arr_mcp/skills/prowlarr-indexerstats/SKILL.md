---
name: prowlarr-indexerstats
description: Skills related to indexerstats in Prowlarr.
tags: [prowlarr, indexerstats]
---

# Prowlarr Indexerstats Skill

This skill provides tools for managing indexerstats within Prowlarr.

## Capabilities

- Access indexerstats resources
