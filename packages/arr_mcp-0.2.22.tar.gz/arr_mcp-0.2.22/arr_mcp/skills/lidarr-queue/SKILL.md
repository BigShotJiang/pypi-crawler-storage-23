---
name: lidarr-queue
description: "Generated skill for Queue operations. Contains 10 tools."
tags: [lidarr, queue]
---

### Overview
This skill handles operations related to Queue.

### Available Tools
- `get_blocklist`: No description
  - **Parameters**:
    - `page` (int)
    - `pageSize` (int)
    - `sortKey` (str)
    - `sortDirection` (str)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `delete_blocklist_id`: No description
  - **Parameters**:
    - `id` (int)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `delete_blocklist_bulk`: No description
  - **Parameters**:
    - `data` (Dict)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `delete_queue_id`: No description
  - **Parameters**:
    - `id` (int)
    - `removeFromClient` (bool)
    - `blocklist` (bool)
    - `skipRedownload` (bool)
    - `changeCategory` (bool)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `delete_queue_bulk`: No description
  - **Parameters**:
    - `data` (Dict)
    - `removeFromClient` (bool)
    - `blocklist` (bool)
    - `skipRedownload` (bool)
    - `changeCategory` (bool)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `get_queue`: No description
  - **Parameters**:
    - `page` (int)
    - `pageSize` (int)
    - `sortKey` (str)
    - `sortDirection` (str)
    - `includeUnknownArtistItems` (bool)
    - `includeArtist` (bool)
    - `includeAlbum` (bool)
    - `artistIds` (List)
    - `protocol` (str)
    - `quality` (List)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `post_queue_grab_id`: No description
  - **Parameters**:
    - `id` (int)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `post_queue_grab_bulk`: No description
  - **Parameters**:
    - `data` (Dict)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `get_queue_details`: No description
  - **Parameters**:
    - `artistId` (int)
    - `albumIds` (List)
    - `includeArtist` (bool)
    - `includeAlbum` (bool)
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)
- `get_queue_status`: No description
  - **Parameters**:
    - `lidarr_base_url` (str)
    - `lidarr_api_key` (Optional[str])
    - `lidarr_verify` (bool)

### Usage Instructions
1. Review the tool available in this skill.
2. Call the tool with the required parameters.

### Error Handling
- Ensure all required parameters are provided.
- Check return values for error messages.
