---
name: prowlarr-customfilter
description: Skills related to customfilter in Prowlarr.
tags: [prowlarr, customfilter]
---

# Prowlarr Customfilter Skill

This skill provides tools for managing customfilter within Prowlarr.

## Capabilities

- Access customfilter resources
