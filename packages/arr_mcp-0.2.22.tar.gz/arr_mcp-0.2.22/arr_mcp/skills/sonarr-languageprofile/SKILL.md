---
name: sonarr-languageprofile
description: Skills related to languageprofile in Sonarr.
tags: [sonarr, languageprofile]
---

# Sonarr Languageprofile Skill

This skill provides tools for managing languageprofile within Sonarr.

## Capabilities

- Access languageprofile resources
