---
name: sonarr-language
description: Skills related to language in Sonarr.
tags: [sonarr, language]
---

# Sonarr Language Skill

This skill provides tools for managing language within Sonarr.

## Capabilities

- Access language resources
