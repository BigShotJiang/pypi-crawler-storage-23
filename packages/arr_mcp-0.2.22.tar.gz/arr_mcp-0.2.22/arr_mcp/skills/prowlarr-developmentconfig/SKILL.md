---
name: prowlarr-developmentconfig
description: Skills related to developmentconfig in Prowlarr.
tags: [prowlarr, developmentconfig]
---

# Prowlarr Developmentconfig Skill

This skill provides tools for managing developmentconfig within Prowlarr.

## Capabilities

- Access developmentconfig resources
