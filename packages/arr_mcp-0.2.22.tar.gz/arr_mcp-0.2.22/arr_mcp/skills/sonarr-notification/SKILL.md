---
name: sonarr-notification
description: Skills related to notification in Sonarr.
tags: [sonarr, notification]
---

# Sonarr Notification Skill

This skill provides tools for managing notification within Sonarr.

## Capabilities

- Access notification resources
