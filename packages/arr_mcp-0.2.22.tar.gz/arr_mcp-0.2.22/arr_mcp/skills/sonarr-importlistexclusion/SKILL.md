---
name: sonarr-importlistexclusion
description: Skills related to importlistexclusion in Sonarr.
tags: [sonarr, importlistexclusion]
---

# Sonarr Importlistexclusion Skill

This skill provides tools for managing importlistexclusion within Sonarr.

## Capabilities

- Access importlistexclusion resources
