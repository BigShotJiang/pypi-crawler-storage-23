---
name: radarr-moviefolder
description: Skills related to moviefolder in Radarr.
tags: [radarr, moviefolder]
---

# Radarr Moviefolder Skill

This skill provides tools for managing moviefolder within Radarr.

## Capabilities

- Access moviefolder resources
