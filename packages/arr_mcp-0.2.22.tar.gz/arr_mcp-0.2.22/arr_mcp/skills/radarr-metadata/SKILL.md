---
name: radarr-metadata
description: Skills related to metadata in Radarr.
tags: [radarr, metadata]
---

# Radarr Metadata Skill

This skill provides tools for managing metadata within Radarr.

## Capabilities

- Access metadata resources
