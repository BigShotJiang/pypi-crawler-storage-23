---
name: sonarr-delayprofile
description: Skills related to delayprofile in Sonarr.
tags: [sonarr, delayprofile]
---

# Sonarr Delayprofile Skill

This skill provides tools for managing delayprofile within Sonarr.

## Capabilities

- Access delayprofile resources
