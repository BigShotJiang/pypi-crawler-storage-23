---
name: radarr-hostconfig
description: Skills related to hostconfig in Radarr.
tags: [radarr, hostconfig]
---

# Radarr Hostconfig Skill

This skill provides tools for managing hostconfig within Radarr.

## Capabilities

- Access hostconfig resources
