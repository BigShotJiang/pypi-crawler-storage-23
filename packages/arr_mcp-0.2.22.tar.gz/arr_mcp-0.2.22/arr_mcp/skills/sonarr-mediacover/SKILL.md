---
name: sonarr-mediacover
description: Skills related to mediacover in Sonarr.
tags: [sonarr, mediacover]
---

# Sonarr Mediacover Skill

This skill provides tools for managing mediacover within Sonarr.

## Capabilities

- Access mediacover resources
