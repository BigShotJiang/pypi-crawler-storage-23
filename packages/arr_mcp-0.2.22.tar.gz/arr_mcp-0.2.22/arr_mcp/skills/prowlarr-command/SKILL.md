---
name: prowlarr-command
description: Skills related to command in Prowlarr.
tags: [prowlarr, command]
---

# Prowlarr Command Skill

This skill provides tools for managing command within Prowlarr.

## Capabilities

- Access command resources
