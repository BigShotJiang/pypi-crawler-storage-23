---
name: prowlarr-log
description: Skills related to log in Prowlarr.
tags: [prowlarr, log]
---

# Prowlarr Log Skill

This skill provides tools for managing log within Prowlarr.

## Capabilities

- Access log resources
