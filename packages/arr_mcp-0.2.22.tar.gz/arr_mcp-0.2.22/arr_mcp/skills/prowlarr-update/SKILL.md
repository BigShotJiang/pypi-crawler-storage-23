---
name: prowlarr-update
description: Skills related to update in Prowlarr.
tags: [prowlarr, update]
---

# Prowlarr Update Skill

This skill provides tools for managing update within Prowlarr.

## Capabilities

- Access update resources
