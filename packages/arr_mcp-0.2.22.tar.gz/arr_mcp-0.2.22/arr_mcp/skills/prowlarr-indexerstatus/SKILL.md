---
name: prowlarr-indexerstatus
description: Skills related to indexerstatus in Prowlarr.
tags: [prowlarr, indexerstatus]
---

# Prowlarr Indexerstatus Skill

This skill provides tools for managing indexerstatus within Prowlarr.

## Capabilities

- Access indexerstatus resources
