---
name: prowlarr-downloadclientconfig
description: Skills related to downloadclientconfig in Prowlarr.
tags: [prowlarr, downloadclientconfig]
---

# Prowlarr Downloadclientconfig Skill

This skill provides tools for managing downloadclientconfig within Prowlarr.

## Capabilities

- Access downloadclientconfig resources
