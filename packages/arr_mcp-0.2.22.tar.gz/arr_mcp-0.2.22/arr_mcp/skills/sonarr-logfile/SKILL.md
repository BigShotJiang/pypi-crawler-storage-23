---
name: sonarr-logfile
description: Skills related to logfile in Sonarr.
tags: [sonarr, logfile]
---

# Sonarr Logfile Skill

This skill provides tools for managing logfile within Sonarr.

## Capabilities

- Access logfile resources
