---
name: sonarr-task
description: Skills related to task in Sonarr.
tags: [sonarr, task]
---

# Sonarr Task Skill

This skill provides tools for managing task within Sonarr.

## Capabilities

- Access task resources
