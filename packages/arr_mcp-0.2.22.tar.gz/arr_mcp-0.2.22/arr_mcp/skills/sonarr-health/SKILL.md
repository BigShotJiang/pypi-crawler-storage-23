---
name: sonarr-health
description: Skills related to health in Sonarr.
tags: [sonarr, health]
---

# Sonarr Health Skill

This skill provides tools for managing health within Sonarr.

## Capabilities

- Access health resources
