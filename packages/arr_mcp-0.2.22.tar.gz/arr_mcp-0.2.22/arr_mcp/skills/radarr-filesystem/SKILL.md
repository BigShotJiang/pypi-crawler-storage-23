---
name: radarr-filesystem
description: Skills related to filesystem in Radarr.
tags: [radarr, filesystem]
---

# Radarr Filesystem Skill

This skill provides tools for managing filesystem within Radarr.

## Capabilities

- Access filesystem resources
