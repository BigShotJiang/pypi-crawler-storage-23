---
name: prowlarr-staticresource
description: Skills related to staticresource in Prowlarr.
tags: [prowlarr, staticresource]
---

# Prowlarr Staticresource Skill

This skill provides tools for managing staticresource within Prowlarr.

## Capabilities

- Access staticresource resources
