---
name: sonarr-parse
description: Skills related to parse in Sonarr.
tags: [sonarr, parse]
---

# Sonarr Parse Skill

This skill provides tools for managing parse within Sonarr.

## Capabilities

- Access parse resources
