---
name: sonarr-releaseprofile
description: Skills related to releaseprofile in Sonarr.
tags: [sonarr, releaseprofile]
---

# Sonarr Releaseprofile Skill

This skill provides tools for managing releaseprofile within Sonarr.

## Capabilities

- Access releaseprofile resources
