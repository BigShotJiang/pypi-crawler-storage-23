---
name: sonarr-queuedetails
description: Skills related to queuedetails in Sonarr.
tags: [sonarr, queuedetails]
---

# Sonarr Queuedetails Skill

This skill provides tools for managing queuedetails within Sonarr.

## Capabilities

- Access queuedetails resources
