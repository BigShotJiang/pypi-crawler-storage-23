---
name: sonarr-apiinfo
description: Skills related to apiinfo in Sonarr.
tags: [sonarr, apiinfo]
---

# Sonarr Apiinfo Skill

This skill provides tools for managing apiinfo within Sonarr.

## Capabilities

- Access apiinfo resources
