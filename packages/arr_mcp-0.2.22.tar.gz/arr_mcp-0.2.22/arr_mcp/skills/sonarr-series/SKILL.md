---
name: sonarr-series
description: Skills related to series in Sonarr.
tags: [sonarr, series]
---

# Sonarr Series Skill

This skill provides tools for managing series within Sonarr.

## Capabilities

- Access series resources
