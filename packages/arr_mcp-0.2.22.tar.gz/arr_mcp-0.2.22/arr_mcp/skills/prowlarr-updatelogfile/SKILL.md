---
name: prowlarr-updatelogfile
description: Skills related to updatelogfile in Prowlarr.
tags: [prowlarr, updatelogfile]
---

# Prowlarr Updatelogfile Skill

This skill provides tools for managing updatelogfile within Prowlarr.

## Capabilities

- Access updatelogfile resources
