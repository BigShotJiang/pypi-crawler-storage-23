---
name: sonarr-downloadclientconfig
description: Skills related to downloadclientconfig in Sonarr.
tags: [sonarr, downloadclientconfig]
---

# Sonarr Downloadclientconfig Skill

This skill provides tools for managing downloadclientconfig within Sonarr.

## Capabilities

- Access downloadclientconfig resources
