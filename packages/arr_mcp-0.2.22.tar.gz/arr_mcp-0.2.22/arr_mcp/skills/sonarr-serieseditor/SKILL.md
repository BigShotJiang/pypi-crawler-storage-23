---
name: sonarr-serieseditor
description: Skills related to serieseditor in Sonarr.
tags: [sonarr, serieseditor]
---

# Sonarr Serieseditor Skill

This skill provides tools for managing serieseditor within Sonarr.

## Capabilities

- Access serieseditor resources
