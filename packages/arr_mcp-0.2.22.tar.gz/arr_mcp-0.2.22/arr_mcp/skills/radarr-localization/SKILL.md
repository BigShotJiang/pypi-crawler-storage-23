---
name: radarr-localization
description: Skills related to localization in Radarr.
tags: [radarr, localization]
---

# Radarr Localization Skill

This skill provides tools for managing localization within Radarr.

## Capabilities

- Access localization resources
