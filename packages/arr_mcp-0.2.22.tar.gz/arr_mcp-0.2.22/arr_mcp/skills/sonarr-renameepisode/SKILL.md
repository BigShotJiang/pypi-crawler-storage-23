---
name: sonarr-renameepisode
description: Skills related to renameepisode in Sonarr.
tags: [sonarr, renameepisode]
---

# Sonarr Renameepisode Skill

This skill provides tools for managing renameepisode within Sonarr.

## Capabilities

- Access renameepisode resources
