---
name: prowlarr-localization
description: Skills related to localization in Prowlarr.
tags: [prowlarr, localization]
---

# Prowlarr Localization Skill

This skill provides tools for managing localization within Prowlarr.

## Capabilities

- Access localization resources
