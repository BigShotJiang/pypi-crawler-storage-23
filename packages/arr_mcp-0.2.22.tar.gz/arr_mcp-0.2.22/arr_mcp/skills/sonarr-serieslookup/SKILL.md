---
name: sonarr-serieslookup
description: Skills related to serieslookup in Sonarr.
tags: [sonarr, serieslookup]
---

# Sonarr Serieslookup Skill

This skill provides tools for managing serieslookup within Sonarr.

## Capabilities

- Access serieslookup resources
