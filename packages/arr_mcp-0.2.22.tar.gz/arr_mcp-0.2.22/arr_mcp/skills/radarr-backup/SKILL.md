---
name: radarr-backup
description: Skills related to backup in Radarr.
tags: [radarr, backup]
---

# Radarr Backup Skill

This skill provides tools for managing backup within Radarr.

## Capabilities

- Access backup resources
