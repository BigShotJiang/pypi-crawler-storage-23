---
name: sonarr-diskspace
description: Skills related to diskspace in Sonarr.
tags: [sonarr, diskspace]
---

# Sonarr Diskspace Skill

This skill provides tools for managing diskspace within Sonarr.

## Capabilities

- Access diskspace resources
