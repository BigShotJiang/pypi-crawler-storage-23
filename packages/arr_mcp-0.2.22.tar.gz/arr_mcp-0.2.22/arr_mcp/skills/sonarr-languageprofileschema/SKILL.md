---
name: sonarr-languageprofileschema
description: Skills related to languageprofileschema in Sonarr.
tags: [sonarr, languageprofileschema]
---

# Sonarr Languageprofileschema Skill

This skill provides tools for managing languageprofileschema within Sonarr.

## Capabilities

- Access languageprofileschema resources
