---
name: prowlarr-application
description: Skills related to application in Prowlarr.
tags: [prowlarr, application]
---

# Prowlarr Application Skill

This skill provides tools for managing application within Prowlarr.

## Capabilities

- Access application resources
