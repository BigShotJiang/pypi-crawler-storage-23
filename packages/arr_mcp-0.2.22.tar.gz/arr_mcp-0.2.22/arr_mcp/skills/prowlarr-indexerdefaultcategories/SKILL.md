---
name: prowlarr-indexerdefaultcategories
description: Skills related to indexerdefaultcategories in Prowlarr.
tags: [prowlarr, indexerdefaultcategories]
---

# Prowlarr Indexerdefaultcategories Skill

This skill provides tools for managing indexerdefaultcategories within Prowlarr.

## Capabilities

- Access indexerdefaultcategories resources
