---
name: sonarr-qualityprofileschema
description: Skills related to qualityprofileschema in Sonarr.
tags: [sonarr, qualityprofileschema]
---

# Sonarr Qualityprofileschema Skill

This skill provides tools for managing qualityprofileschema within Sonarr.

## Capabilities

- Access qualityprofileschema resources
