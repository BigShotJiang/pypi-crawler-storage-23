---
name: sonarr-seriesfolder
description: Skills related to seriesfolder in Sonarr.
tags: [sonarr, seriesfolder]
---

# Sonarr Seriesfolder Skill

This skill provides tools for managing seriesfolder within Sonarr.

## Capabilities

- Access seriesfolder resources
