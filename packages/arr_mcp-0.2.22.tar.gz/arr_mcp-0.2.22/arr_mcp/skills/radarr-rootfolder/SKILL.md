---
name: radarr-rootfolder
description: Skills related to rootfolder in Radarr.
tags: [radarr, rootfolder]
---

# Radarr Rootfolder Skill

This skill provides tools for managing rootfolder within Radarr.

## Capabilities

- Access rootfolder resources
