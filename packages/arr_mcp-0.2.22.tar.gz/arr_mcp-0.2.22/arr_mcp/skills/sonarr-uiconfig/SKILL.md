---
name: sonarr-uiconfig
description: Skills related to uiconfig in Sonarr.
tags: [sonarr, uiconfig]
---

# Sonarr Uiconfig Skill

This skill provides tools for managing uiconfig within Sonarr.

## Capabilities

- Access uiconfig resources
