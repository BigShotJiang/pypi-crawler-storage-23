---
name: radarr-metadataconfig
description: Skills related to metadataconfig in Radarr.
tags: [radarr, metadataconfig]
---

# Radarr Metadataconfig Skill

This skill provides tools for managing metadataconfig within Radarr.

## Capabilities

- Access metadataconfig resources
