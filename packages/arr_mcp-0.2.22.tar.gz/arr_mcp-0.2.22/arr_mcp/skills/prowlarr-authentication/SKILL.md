---
name: prowlarr-authentication
description: Skills related to authentication in Prowlarr.
tags: [prowlarr, authentication]
---

# Prowlarr Authentication Skill

This skill provides tools for managing authentication within Prowlarr.

## Capabilities

- Access authentication resources
