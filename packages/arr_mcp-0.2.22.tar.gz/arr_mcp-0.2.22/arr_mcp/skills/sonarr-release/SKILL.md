---
name: sonarr-release
description: Skills related to release in Sonarr.
tags: [sonarr, release]
---

# Sonarr Release Skill

This skill provides tools for managing release within Sonarr.

## Capabilities

- Access release resources
