"""Porto Data CLI - Single source of truth for all validation logic."""

from importlib.metadata import version

# Must match [project] name in pyproject.toml (PyPI distribution name)
__version__ = version("gruncellka-porto-data")
