# CHANGELOG

<!-- version list -->

## v2.3.0 (2026-02-22)

### Features

- Up init
  ([`5d08131`](https://github.com/PyMoX-fr/GC7/commit/5d0813160991fc76cabd4da8739074ae8da0c0f5))


## v2.2.0 (2026-02-22)


## v2.1.0 (2026-02-22)


## v2.0.0 (2026-02-22)


## v1.3.0 (2026-02-22)

### Features

- Minor
  ([`87fd766`](https://github.com/PyMoX-fr/GC7/commit/87fd766f95e5e84243a5b7da15856337e3a7498c))


## v1.2.18 (2026-02-22)


## v1.2.17 (2026-02-22)

### Bug Fixes

- Corr
  ([`38ac301`](https://github.com/PyMoX-fr/GC7/commit/38ac301618445c3c444bf4c6dae9efeb37ba4d33))


## v1.2.16 (2026-02-22)

### Bug Fixes

- 16 ([`a84aac3`](https://github.com/PyMoX-fr/GC7/commit/a84aac35663d24e6bfa417e46b5cf9fc693aa0fd))


## v1.2.15 (2026-02-22)

### Bug Fixes

- Try bold in desc
  ([`fa26ca7`](https://github.com/PyMoX-fr/GC7/commit/fa26ca732e34414cf6022c20a8afd8bca3dae566))


## v1.2.14 (2026-02-22)


## v1.2.13 (2026-02-22)

### Bug Fixes

- 12 ou 13 ?
  ([`55c3be6`](https://github.com/PyMoX-fr/GC7/commit/55c3be6d3e7e0e791ec44b820ca45fd26c2615e9))

- 13 !!!
  ([`f8da2c9`](https://github.com/PyMoX-fr/GC7/commit/f8da2c9a2184955147e3d5ff0857bd55ad6cca88))

- Net ([`202ed3b`](https://github.com/PyMoX-fr/GC7/commit/202ed3b18373b25770fb6e96473cbea630f67a76))

- Reset version
  ([`ba4f203`](https://github.com/PyMoX-fr/GC7/commit/ba4f2037a567aad7053a40b5d8fe4396e0da8f3e))


## v1.2.11 (2026-02-22)


## v1.2.10 (2026-02-22)


## v1.2.9 (2026-02-22)


## v1.2.8 (2026-02-22)


## v1.2.7 (2026-02-22)

### Bug Fixes

- Up ([`7ce7669`](https://github.com/PyMoX-fr/GC7/commit/7ce7669308f80460b658e76a088c8032b6c6c73e))


## v1.2.6 (2026-02-22)

### Bug Fixes

- Up wkf
  ([`7c3ef4a`](https://github.com/PyMoX-fr/GC7/commit/7c3ef4a96263f0fcaab34a1fadd11f8f68d0c6b5))


## v1.2.5 (2026-02-22)

### Bug Fixes

- Simple push
  ([`2ae2c28`](https://github.com/PyMoX-fr/GC7/commit/2ae2c287a4cbe6137a5a3987f7cf20716a4aabca))


## v1.2.4 (2026-02-22)

### Bug Fixes

- Corr 4
  ([`f1cc6dd`](https://github.com/PyMoX-fr/GC7/commit/f1cc6dd54081fcf1d7487e5a74a9d9337ac1564e))

- Corr wkf
  ([`30300ad`](https://github.com/PyMoX-fr/GC7/commit/30300ad371575f4aba697814acf70bd5e1b98acb))

- Dorr 3
  ([`624cc93`](https://github.com/PyMoX-fr/GC7/commit/624cc93e7611be3c20d9291461750f759230882d))


## v1.2.3 (2026-02-22)

### Bug Fixes

- Change tree
  ([`73f32e9`](https://github.com/PyMoX-fr/GC7/commit/73f32e913a11ed04717505641e99967ca2cf0ff4))

- Corr
  ([`c2e4773`](https://github.com/PyMoX-fr/GC7/commit/c2e4773322928f6e1687f631ac6d49670a13ffa7))

- Corr2
  ([`6d5a2b8`](https://github.com/PyMoX-fr/GC7/commit/6d5a2b855c6dac8179e53e3a27b5e6c81cd0640d))


## v1.2.2 (2026-02-22)


## v1.2.1 (2026-02-22)


## v1.2.0 (2026-02-22)

### Features

- Doc ([`e387fa2`](https://github.com/PyMoX-fr/GC7/commit/e387fa2f4972b8f41a2d0da6817492e4c171e4de))


## v1.1.4 (2026-02-22)

### Bug Fixes

- Env ([`ef9160c`](https://github.com/PyMoX-fr/GC7/commit/ef9160ccd945a3d6ec5eae0d3cce316dc97f460e))


## v1.1.3 (2026-02-22)

### Bug Fixes

- Up doc
  ([`8e73a89`](https://github.com/PyMoX-fr/GC7/commit/8e73a894f9107fd18b3d37434098e232ae3f734c))


## v1.1.2 (2026-02-22)

### Bug Fixes

- Nett
  ([`c60008d`](https://github.com/PyMoX-fr/GC7/commit/c60008dabc4f5a9f51d706580e85a0b8dcc2fe02))


## v1.1.1 (2026-02-22)

### Bug Fixes

- Up doc
  ([`ae02335`](https://github.com/PyMoX-fr/GC7/commit/ae0233522a176f7c8f2e30748248819332f4cd00))


## v1.1.0 (2026-02-21)

### Features

- Rappel semantic prefix
  ([`fa16eed`](https://github.com/PyMoX-fr/GC7/commit/fa16eed6f5825244b002125e39940c28692f7cb8))


## v1.0.6 (2025-08-04)

### Bug Fixes

- Try 1.0.6
  ([`2738278`](https://github.com/PyMoX-fr/GC7/commit/2738278da8c7c33dac1ada54b33dafb04ca4a859))


## v1.0.5 (2025-08-03)

### Bug Fixes

- Try v5
  ([`a3054f8`](https://github.com/PyMoX-fr/GC7/commit/a3054f8608157acf7cfb1c98af8b68bf646c44a8))


## v1.0.4 (2025-08-03)

### Bug Fixes

- Set local dev for tokens()
  ([`3183e15`](https://github.com/PyMoX-fr/GC7/commit/3183e15b25687c51da31870827091a5e81f756ff))


## v1.0.3 (2025-08-03)


## v1.0.2 (2025-08-03)


## v1.0.1 (2025-08-03)

### Bug Fixes

- Set hello()
  ([`03efc80`](https://github.com/PyMoX-fr/GC7/commit/03efc8032804e20feadba5fd246e07c1bc133b4b))


## v1.0.0 (2025-08-03)

- Initial Release
