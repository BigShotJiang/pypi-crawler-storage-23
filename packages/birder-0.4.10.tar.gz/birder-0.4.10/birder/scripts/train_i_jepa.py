"""
I-JEPA (Image-based Joint-Embedding Predictive Architecture), adapted from
https://github.com/facebookresearch/ijepa/blob/main/src/train.py

Paper "Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture",
https://arxiv.org/abs/2301.08243

Changes from original:
* Per epoch weight decay scheduling (instead of per step)
"""

# Reference license: Attribution-NonCommercial 4.0 International

import argparse
import logging
import math
import sys
import time
from collections.abc import Callable
from collections.abc import Iterator
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.amp
import torch.nn.functional as F
import torchinfo
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from torchvision.datasets.folder import pil_loader  # Slower but Handles external dataset quirks better
from tqdm import tqdm

from birder.common import cli
from birder.common import fs_ops
from birder.common import training_cli
from birder.common import training_utils
from birder.common.lib import format_duration
from birder.common.lib import get_mim_network_name
from birder.common.lib import get_network_name
from birder.conf import settings
from birder.data.dataloader.webdataset import make_wds_loader
from birder.data.datasets.directory import make_image_dataset
from birder.data.datasets.directory import tv_loader
from birder.data.datasets.fake import FakeDataWithPaths
from birder.data.datasets.webdataset import make_wds_dataset
from birder.data.datasets.webdataset import prepare_wds_args
from birder.data.datasets.webdataset import wds_args_from_info
from birder.data.transforms.classification import get_rgb_stats
from birder.model_registry import Task
from birder.model_registry import registry
from birder.net.base import MaskedTokenOmissionMixin
from birder.net.base import get_signature
from birder.net.ssl.base import get_ssl_signature
from birder.net.ssl.i_jepa import I_JEPA
from birder.net.ssl.i_jepa import MultiBlockMasking
from birder.net.ssl.i_jepa import VisionTransformerPredictor
from birder.net.ssl.i_jepa import apply_masks
from birder.net.ssl.i_jepa import repeat_interleave_batch

logger = logging.getLogger(__name__)


class TrainCollator:
    def __init__(
        self,
        mask_generator: Callable[[int], tuple[list[torch.Tensor], list[torch.Tensor]]],
    ) -> None:
        self.mask_generator = mask_generator

    def __call__(self, batch: Any) -> tuple[torch.Tensor, list[torch.Tensor], list[torch.Tensor]]:
        B = len(batch)
        collated_batch = torch.utils.data.default_collate(batch)
        enc_masks, pred_masks = self.mask_generator(B)

        return (collated_batch, enc_masks, pred_masks)


# pylint: disable=too-many-locals,too-many-branches,too-many-statements
def train(args: argparse.Namespace) -> None:
    #
    # Initialize
    #
    device, device_id, disable_tqdm = training_utils.init_training(args, logger)

    if args.size is None:
        args.size = registry.get_default_size(args.network)

    logger.info(f"Using size={args.size}")

    batch_size: int = args.batch_size
    grad_accum_steps: int = args.grad_accum_steps
    logger.debug(f"Effective batch size = {batch_size * grad_accum_steps * args.world_size}")

    begin_epoch = 1
    epochs = args.epochs + 1
    args.stop_epoch = training_utils.normalize_stop_epoch(epochs, args.stop_epoch)

    #
    # Initialize network
    #
    model_dtype: torch.dtype = getattr(torch, args.model_dtype)
    sample_shape = (batch_size, args.channels, *args.size)  # B, C, H, W
    encoder_name = get_network_name(args.network, tag="i-jepa")
    if args.tag is not None:
        encoder_name = f"{encoder_name}-{args.tag}"

    network_name = get_mim_network_name("i_jepa", encoder=args.network, tag=args.tag)

    if args.model_config is not None:
        model_config = args.model_config.copy()
        model_config.update({"drop_path_rate": 0.0})
    else:
        model_config = {"drop_path_rate": 0.0}

    backbone = registry.net_factory(args.network, 0, sample_shape[1], config=model_config, size=args.size)
    num_special_tokens = backbone.num_special_tokens
    target_backbone = registry.net_factory(args.network, 0, sample_shape[1], config=model_config, size=args.size)
    encoder = I_JEPA(backbone)
    target_encoder = I_JEPA(target_backbone)
    target_encoder.load_state_dict(encoder.state_dict())

    mask_size = (args.size[0] // encoder.backbone.max_stride, args.size[1] // encoder.backbone.max_stride)
    predictor = VisionTransformerPredictor(
        mask_size,
        encoder.backbone.embedding_size,
        predictor_embed_dim=args.predictor_embed_dim,
        mlp_dim=4 * args.predictor_embed_dim,
        num_heads=args.predictor_num_heads,
        depth=args.predictor_depth,
        drop_path_rate=0.0,
    )

    net = torch.nn.ModuleDict(
        {
            "encoder": encoder,
            "target_encoder": target_encoder,
            "predictor": predictor,
        }
    )
    net.task = encoder.task

    if args.resume_epoch is not None:
        begin_epoch = args.resume_epoch + 1
        net, training_states = fs_ops.load_simple_checkpoint(
            device, net, network_name, epoch=args.resume_epoch, strict=not args.non_strict_weights
        )
        encoder = net["encoder"]
        target_encoder = net["target_encoder"]
        predictor = net["predictor"]

    else:
        training_states = fs_ops.TrainingStates.empty()

    assert isinstance(encoder.backbone, MaskedTokenOmissionMixin)
    assert isinstance(net, torch.nn.Module)

    net.to(device, dtype=model_dtype)
    if args.fast_matmul is True or args.amp is True:
        torch.set_float32_matmul_precision("high")

    # Compile network
    if args.compile is True:
        # encoder = torch.compile(encoder)  # Dynamic sequence length not handled well by dynamo
        target_encoder = torch.compile(target_encoder, fullgraph=args.compile_fullgraph)
        # predictor = torch.compile(predictor)

    #
    # Data
    #
    rgb_stats = get_rgb_stats(args.rgb_mode, args.rgb_mean, args.rgb_std)
    logger.debug(f"Using RGB stats: {rgb_stats}")

    mask_generator = MultiBlockMasking(
        mask_size,
        enc_mask_scale=(0.85, 1.0),
        pred_mask_scale=(0.15, 0.2),
        aspect_ratio=(0.75, 1.5),
        n_enc=1,
        n_pred=4,
        min_keep=10,  # math.ceil(mask_size[0] * mask_size[1] / 25.6),
        allow_overlap=False,
    )
    mask_collator = TrainCollator(mask_generator)
    training_transform = training_utils.get_training_transform(args)
    if args.use_fake_data is True:
        logger.warning("Using fake data")
        training_dataset = FakeDataWithPaths(
            10000, (args.channels, *args.size), num_classes=10, transform=training_transform
        )

    elif args.wds is True:
        wds_path: str | list[str]
        if args.wds_info is not None:
            wds_path, dataset_size = wds_args_from_info(args.wds_info, args.wds_split)
            if args.wds_size is not None:
                dataset_size = args.wds_size
        else:
            wds_path, dataset_size = prepare_wds_args(args.data_path[0], args.wds_size, device)

        training_dataset = make_wds_dataset(
            wds_path,
            dataset_size=dataset_size,
            shuffle=True,
            samples_names=True,
            transform=training_transform,
            img_loader=args.img_loader,
            cls_key=None,
            cache_dir=args.wds_cache_dir,
        )

    else:
        training_dataset = make_image_dataset(
            args.data_path,
            {},
            transforms=training_transform,
            loader=pil_loader if args.img_loader == "pil" else tv_loader,
        )

    logger.info(f"Using device {device}:{device_id}")
    logger.info(f"Training dataset has {len(training_dataset):,} samples")

    # Data loaders and samplers
    virtual_epoch_mode = args.steps_per_epoch is not None
    train_sampler, _ = training_utils.get_samplers(
        args, training_dataset, validation_dataset=None, infinite=virtual_epoch_mode
    )

    if args.wds is True:
        training_loader = make_wds_loader(
            training_dataset,
            batch_size,
            num_workers=args.num_workers,
            prefetch_factor=args.prefetch_factor,
            collate_fn=mask_collator,
            world_size=args.world_size,
            pin_memory=True,
            drop_last=args.drop_last,
            shuffle=args.wds_extra_shuffle,
            infinite=virtual_epoch_mode,
        )

    else:
        training_loader = DataLoader(
            training_dataset,
            batch_size=batch_size,
            sampler=train_sampler,
            num_workers=args.num_workers,
            prefetch_factor=args.prefetch_factor,
            collate_fn=mask_collator,
            pin_memory=True,
            drop_last=args.drop_last,
        )

    if virtual_epoch_mode is True:
        optimizer_steps_per_epoch = args.steps_per_epoch
        epoch_num_batches = args.steps_per_epoch * grad_accum_steps
        epoch_samples = epoch_num_batches * batch_size * args.world_size
        logger.debug(f"Virtual epoch has {epoch_samples:,} samples")
    else:
        optimizer_steps_per_epoch = math.ceil(len(training_loader) / grad_accum_steps)
        epoch_num_batches = len(training_loader)
        epoch_samples = len(training_dataset)

    last_batch_idx = epoch_num_batches - 1
    last_accum_steps = epoch_num_batches % grad_accum_steps
    if last_accum_steps == 0:
        last_accum_steps = grad_accum_steps

    last_accum_start_idx = epoch_num_batches - last_accum_steps
    logger.debug(
        f"Epoch has {epoch_num_batches} iterations ({optimizer_steps_per_epoch} steps), "
        f"virtual mode={virtual_epoch_mode}"
    )

    #
    # Loss criteria, optimizer, learning rate scheduler and training parameter groups
    #

    # Learning rate scaling
    lr = training_utils.scale_lr(args)

    # Training parameter groups
    custom_keys_weight_decay = training_utils.get_wd_custom_keys(args)
    parameters = training_utils.optimizer_parameter_groups(
        net,
        args.wd,
        base_lr=lr,
        norm_weight_decay=args.norm_wd,
        custom_keys_weight_decay=custom_keys_weight_decay,
        custom_layer_weight_decay=args.custom_layer_wd,
        layer_decay=args.layer_decay,
        layer_decay_min_scale=args.layer_decay_min_scale,
        layer_decay_no_opt_scale=args.layer_decay_no_opt_scale,
        bias_lr=args.bias_lr,
        custom_layer_lr_scale=args.custom_layer_lr_scale,
    )

    if args.lr_scheduler_update == "epoch":
        step_update = False
        scheduler_steps_per_epoch = 1
    elif args.lr_scheduler_update == "step":
        step_update = True
        scheduler_steps_per_epoch = optimizer_steps_per_epoch
    else:
        raise ValueError("Unsupported lr_scheduler_update")

    # Optimizer and learning rate scheduler
    optimizer = training_utils.get_optimizer(parameters, lr, args)
    scheduler = training_utils.get_scheduler(optimizer, scheduler_steps_per_epoch, args)
    if args.compile_opt is True:
        optimizer.step = torch.compile(optimizer.step, fullgraph=False)

    # Momentum and weight decay schedule
    momentum_schedule = training_utils.cosine_scheduler(0.996, 1.0, args.epochs, 0, epoch_num_batches)
    if args.wd_end is not None:
        wd_schedule = training_utils.cosine_scheduler(args.wd, args.wd_end, args.epochs, 0, 1)
    else:
        wd_schedule = None

    # Gradient scaler and AMP related tasks
    scaler, amp_dtype = training_utils.get_amp_scaler(args.amp, args.amp_dtype)

    # Load states
    if args.load_states is True:
        optimizer.load_state_dict(training_states.optimizer_state)
        scheduler.load_state_dict(training_states.scheduler_state)
        if scaler is not None:
            scaler.load_state_dict(training_states.scaler_state)

    elif args.load_scheduler is True:
        scheduler.load_state_dict(training_states.scheduler_state)
        last_lrs = scheduler.get_last_lr()
        for g, last_lr in zip(optimizer.param_groups, last_lrs):
            g["lr"] = last_lr

    last_lr = float(max(scheduler.get_last_lr()))
    if args.plot_lr is True:
        logger.info("Fast forwarding scheduler...")
        optimizer.step()
        lrs = []
        for _ in range(begin_epoch, epochs):
            for _ in range(scheduler_steps_per_epoch):
                lrs.append(float(max(scheduler.get_last_lr())))
                scheduler.step()

        plt.plot(
            np.linspace(begin_epoch, epochs, scheduler_steps_per_epoch * (epochs - begin_epoch), endpoint=False), lrs
        )
        plt.show()
        raise SystemExit(0)

    #
    # Distributed (DDP)
    #

    # There is no backpropagation through the teacher
    for p in target_encoder.parameters():
        p.requires_grad_(False)

    encoder_without_ddp = encoder
    encoder_no_sync_cm = nullcontext
    predictor_no_sync_cm = nullcontext
    # predictor_without_ddp = predictor
    if args.distributed is True:
        encoder = torch.nn.parallel.DistributedDataParallel(
            encoder,
            device_ids=[args.local_rank],
            find_unused_parameters=args.find_unused_parameters,
            broadcast_buffers=not args.no_broadcast_buffers,
        )
        predictor = torch.nn.parallel.DistributedDataParallel(
            predictor, device_ids=[args.local_rank], broadcast_buffers=not args.no_broadcast_buffers
        )
        encoder_no_sync_cm = encoder.no_sync
        predictor_no_sync_cm = predictor.no_sync
        encoder_without_ddp = encoder.module
        # predictor_without_ddp = predictor.module

    model_to_save = net
    if args.compile is True and hasattr(model_to_save["target_encoder"], "_orig_mod") is True:
        model_to_save["target_encoder"] = model_to_save["target_encoder"]._orig_mod  # pylint: disable=protected-access

    #
    # Misc
    #

    # Print network summary
    net_for_info = encoder_without_ddp.backbone
    if args.compile is True and hasattr(encoder_without_ddp, "_orig_mod") is True:
        net_for_info = encoder_without_ddp._orig_mod.backbone  # pylint: disable=protected-access

    if args.no_summary is False:
        summary = torchinfo.summary(
            net_for_info,
            device=device,
            input_size=sample_shape,
            dtypes=[model_dtype],
            col_names=["input_size", "output_size", "kernel_size", "num_params"],
            depth=4,
            verbose=0,
        )
        if training_utils.is_global_primary(args) is True:
            # Write to stderr, same as all the logs
            print(summary, file=sys.stderr)

    # Training logs
    training_log_path = training_utils.training_log_path(network_name, device, args.experiment)
    logger.info(f"Logging training run at {training_log_path}")
    summary_writer = SummaryWriter(training_log_path)

    signature = get_ssl_signature(input_shape=sample_shape)
    backbone_signature = get_signature(input_shape=sample_shape, num_outputs=0)
    file_handler: logging.Handler = logging.NullHandler()
    if training_utils.is_global_primary(args) is True:
        summary_writer.flush()
        fs_ops.write_config(network_name, net_for_info, signature=signature, rgb_stats=rgb_stats)
        file_handler = training_utils.setup_file_logging(training_log_path.joinpath("training.log"))
        training_utils.write_training_args_json(training_log_path, args)
        training_utils.write_training_data_json(training_log_path, {"training_samples": len(training_dataset)})

    #
    # Training loop
    #
    if virtual_epoch_mode is True:
        train_iter = iter(training_loader)

    running_loss = training_utils.SmoothedValue()

    logger.info(f"Starting training with learning rate of {last_lr}")
    for epoch in range(begin_epoch, args.stop_epoch):
        tic = time.time()
        net.train()

        # Clear metrics
        running_loss.clear()

        if args.distributed is True or virtual_epoch_mode is True:
            train_sampler.set_epoch(epoch)

        if wd_schedule is not None:
            wd = wd_schedule[epoch - 1]
            for param_group in optimizer.param_groups:
                if param_group["weight_decay"] > 0:
                    param_group["weight_decay"] = wd

            logger.info(f"Updated wd to: {wd}")

        progress = tqdm(
            desc=f"Epoch {epoch}/{epochs-1}",
            total=epoch_samples,
            leave=False,
            disable=disable_tqdm,
            unit="samples",
            initial=0,
        )

        # Zero the parameter gradients
        optimizer.zero_grad()

        epoch_start = time.time()
        start_time = epoch_start
        last_idx = -1
        batch_iter: Iterator[tuple[int, Any]]
        if virtual_epoch_mode is True:
            batch_iter = ((i, next(train_iter)) for i in range(epoch_num_batches))
        else:
            batch_iter = enumerate(training_loader)

        for i, ((_, images, _), enc_masks, pred_masks) in batch_iter:
            global_iter = ((epoch - 1) * epoch_num_batches) + i
            images = images.to(device, dtype=model_dtype, non_blocking=True)
            enc_masks = [m.to(device, non_blocking=True) for m in enc_masks]
            pred_masks = [m.to(device, non_blocking=True) for m in pred_masks]

            optimizer_update = (i == last_batch_idx) or ((i + 1) % grad_accum_steps == 0)
            encoder_sync_context = encoder_no_sync_cm if optimizer_update is False else nullcontext
            predictor_sync_context = predictor_no_sync_cm if optimizer_update is False else nullcontext
            if i >= last_accum_start_idx:
                effective_accum_steps = last_accum_steps
            else:
                effective_accum_steps = grad_accum_steps

            # Forward and backward
            with encoder_sync_context(), predictor_sync_context():
                with torch.amp.autocast("cuda", enabled=args.amp, dtype=amp_dtype):
                    # Target encoder
                    with torch.no_grad():
                        h = target_encoder(images)
                        h = h[:, num_special_tokens:, :]  # Remove special tokens
                        h = F.layer_norm(h, (h.size(-1),))
                        h = apply_masks(h, pred_masks)
                        h = repeat_interleave_batch(h, batch_size, repeat=len(enc_masks))

                    # Context encoder
                    # NOTE: When enc_masks > 1, this implementation is not as efficient as the original,
                    # as we run through the stem over and over with the same input.
                    z = torch.concat([encoder(images, enc_mask) for enc_mask in enc_masks], dim=0)
                    z = z[:, num_special_tokens:, :]  # Remove special tokens
                    z = predictor(z, enc_masks, pred_masks)

                    raw_loss = F.smooth_l1_loss(z, h)

                loss = raw_loss / effective_accum_steps
                if scaler is not None:
                    scaler.scale(loss).backward()
                else:
                    loss.backward()

            if optimizer_update is True:
                if scaler is not None:
                    if args.clip_grad_norm is not None:
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(net.parameters(), args.clip_grad_norm)

                    scaler.step(optimizer)
                    scaler.update()
                else:
                    if args.clip_grad_norm is not None:
                        torch.nn.utils.clip_grad_norm_(net.parameters(), args.clip_grad_norm)

                    optimizer.step()

                optimizer.zero_grad()
                if step_update is True:
                    scheduler.step()

            if optimizer_update is True:
                # EMA update for the target encoder
                with torch.no_grad():
                    m = momentum_schedule[global_iter]
                    torch._foreach_lerp_(  # pylint: disable=protected-access
                        list(target_encoder.parameters()), list(encoder.parameters()), weight=1 - m
                    )

            # Statistics
            running_loss.update(raw_loss.detach())

            # Write statistics
            if (i + 1) % args.log_interval == 0 or i == last_batch_idx:
                time_now = time.time()
                time_cost = time_now - start_time
                iters_processed_in_interval = i - last_idx
                rate = iters_processed_in_interval * (batch_size * args.world_size) / time_cost

                avg_time_per_iter = time_cost / iters_processed_in_interval
                remaining_iters_in_epoch = last_batch_idx - i
                estimated_time_to_finish_epoch = remaining_iters_in_epoch * avg_time_per_iter

                start_time = time_now
                last_idx = i
                cur_lr = float(max(scheduler.get_last_lr()))

                running_loss.synchronize_between_processes(device)
                with training_utils.single_handler_logging(logger, file_handler, enabled=not disable_tqdm) as log:
                    log.info(
                        f"[Trn] Epoch {epoch}/{epochs-1}, iter {i+1}/{last_batch_idx+1}  "
                        f"Loss: {running_loss.avg:.4f}  "
                        f"Elapsed: {format_duration(time_now-epoch_start)}  "
                        f"ETA: {format_duration(estimated_time_to_finish_epoch)}  "
                        f"T: {time_cost:.1f}s  "
                        f"R: {rate:.1f} samples/s  "
                        f"LR: {cur_lr:.4e}"
                    )

                if training_utils.is_global_primary(args) is True:
                    summary_writer.add_scalars(
                        "loss",
                        {"training": running_loss.avg},
                        ((epoch - 1) * epoch_samples) + ((i + 1) * batch_size * args.world_size),
                    )

            # Update progress bar
            progress.update(n=batch_size * args.world_size)

        progress.close()

        # Epoch training metrics
        logger.info(f"[Trn] Epoch {epoch}/{epochs-1} training_loss: {running_loss.global_avg:.4f}")

        # Learning rate scheduler update
        if step_update is False:
            scheduler.step()
        if last_lr != float(max(scheduler.get_last_lr())):
            last_lr = float(max(scheduler.get_last_lr()))
            logger.info(f"Updated learning rate to: {last_lr}")

        # Checkpoint model
        if epoch % args.save_frequency == 0:
            training_utils.save_training_checkpoint(
                args,
                network_name,
                epoch,
                model_to_save,
                signature,
                {},
                rgb_stats,
                optimizer,
                scheduler,
                scaler,
                None,
            )
            training_utils.save_training_checkpoint(
                args,
                encoder_name,
                epoch,
                model_to_save["encoder"].backbone,
                backbone_signature,
                {},
                rgb_stats,
                optimizer=None,
                scheduler=None,
                scaler=None,
                model_base=None,
            )
            if args.keep_last is not None and training_utils.is_global_primary(args) is True:
                fs_ops.clean_checkpoints(network_name, args.keep_last)
                fs_ops.clean_checkpoints(encoder_name, args.keep_last)

        # Epoch timing
        toc = time.time()
        logger.info(f"Total time: {format_duration(toc - tic)}")
        logger.info("---")

    summary_writer.close()

    # Checkpoint model
    training_utils.save_training_checkpoint(
        args,
        network_name,
        epoch,
        model_to_save,
        signature,
        {},
        rgb_stats,
        optimizer,
        scheduler,
        scaler,
        None,
    )
    training_utils.save_training_checkpoint(
        args,
        encoder_name,
        epoch,
        model_to_save["encoder"].backbone,
        backbone_signature,
        {},
        rgb_stats,
        optimizer=None,
        scheduler=None,
        scaler=None,
        model_base=None,
    )

    training_utils.shutdown_distributed_mode(args)


def get_args_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        allow_abbrev=False,
        description="Pre-train model",
        epilog=(
            "Usage examples\n"
            "==============\n"
            "torchrun --nproc_per_node=2 -m birder.scripts.train_i_jepa \\\n"
            "    --network vit_reg4_b16 \\\n"
            "    --opt adamw \\\n"
            "    --lr 0.001 \\\n"
            "    --lr-scheduler cosine \\\n"
            "    --lr-cosine-min 1e-6 \\\n"
            "    --warmup-epochs 40 \\\n"
            "    --batch-size 128 \\\n"
            "    --wd 0.04 \\\n"
            "    --wd-end 0.4 \\\n"
            "    --norm-wd 0 \\\n"
            "    --bias-weight-decay 0 \\\n"
            "    --amp \\\n"
            "    --compile \\\n"
            "    --compile-opt \\\n"
            "    --data-path data/training data/raw_data\n"
        ),
        formatter_class=cli.ArgumentHelpFormatter,
    )
    parser.add_argument("-n", "--network", type=str, help="the neural network to use")
    parser.add_argument("-t", "--tag", type=str, help="add model tag")
    parser.add_argument(
        "--model-config",
        action=cli.FlexibleDictAction,
        help=(
            "override the model default configuration, accepts key-value pairs or JSON "
            "('drop_path_rate=0.2' or '{\"units\": [3, 24, 36, 3], \"dropout\": 0.2}'"
        ),
    )
    parser.add_argument("--predictor-embed-dim", type=int, default=384, help="predictor embedding dimension")
    parser.add_argument("--predictor-num-heads", type=int, default=12, help="predictor number of heads")
    parser.add_argument("--predictor-depth", type=int, default=12, help="predictor number of layers")
    training_cli.add_optimization_args(parser)
    training_cli.add_lr_wd_args(parser, wd_end=True)
    training_cli.add_lr_scheduler_args(parser)
    training_cli.add_training_schedule_args(parser, default_epochs=300)
    training_cli.add_batch_norm_args(parser)
    training_cli.add_input_args(parser)
    training_cli.add_data_aug_args(parser, default_level=1, default_min_scale=0.35, default_re_prob=0.0)
    training_cli.add_dataloader_args(parser, default_drop_last=True)
    training_cli.add_precision_args(parser)
    training_cli.add_compile_args(parser)
    training_cli.add_checkpoint_args(parser)
    training_cli.add_distributed_args(parser)
    training_cli.add_logging_and_debug_args(parser, default_log_interval=100)
    training_cli.add_training_data_args(parser, unsupervised=True)

    return parser


def validate_args(args: argparse.Namespace) -> None:
    args.data_path = [str(p) for p in args.data_path]
    args.size = cli.parse_size(args.size)

    # This will capture the common argument mistakes
    training_cli.common_args_validation(args)

    # Script specific checks
    if registry.exists(args.network, task=Task.IMAGE_CLASSIFICATION, net_type=MaskedTokenOmissionMixin) is False:
        raise cli.ValidationError(f"--network {args.network} not supported, see list-models tool for available options")


def args_from_dict(**kwargs: Any) -> argparse.Namespace:
    parser = get_args_parser()
    parser.set_defaults(**kwargs)
    args = parser.parse_args([])
    validate_args(args)

    return args


def main() -> None:
    parser = get_args_parser()
    args = parser.parse_args()
    validate_args(args)

    if settings.MODELS_DIR.exists() is False:
        logger.info(f"Creating {settings.MODELS_DIR} directory...")
        settings.MODELS_DIR.mkdir(parents=True, exist_ok=True)

    if args.wds_cache_dir is not None and Path(args.wds_cache_dir).exists() is False:
        logger.info(f"Creating {args.wds_cache_dir} directory...")
        Path(args.wds_cache_dir).mkdir(parents=True, exist_ok=True)

    train(args)


if __name__ == "__main__":
    logger = logging.getLogger(getattr(__spec__, "name", __name__))
    main()
