"""Shared constants for openadapt-evals."""

# 12 harder WAA task IDs used for demo-conditioned evaluation
HARDER_TASK_IDS = [
    "04d9aeaf-7bed-4024-bedb-e10e6f00eb7f-WOS",
    "0a0faba3-5580-44df-965d-f562a99b291c-WOS",
    "0bf05a7d-b28b-44d2-955a-50b41e24012a-WOS",
    "0e763496-b6bb-4508-a427-fad0b6c3e195-WOS",
    "4bcb1253-a636-4df4-8cb0-a35c04dfef31-WOS",
    "70745df8-f2f5-42bd-8074-fbc10334fcc5-2-WOS",
    "8b1ce5f2-59d2-4dcc-b0b0-666a714b9a14-WOS",
    "e2b5e914-ffe1-44d2-8e92-58f8c5d92bb2-WOS",
    "ec71221e-ac43-46f9-89b8-ee7d80f7e1c5-WOS",
    "fba2c100-79e8-42df-ae74-b592418d54f4-WOS",
    "INF-0d95d28a-9587-433b-a805-1fbe5467d598-WOS",
    "INF-5ac2891a-eacd-4954-b339-98abba077adb-WOS",
]
