"""Collection of debug functions."""

# standard library
import re
import sys
from pathlib import Path
from typing import TypedDict

# third party
import matplotlib as mpl
import numpy as np

# local
from .constants import PKG_PATH

__all__ = (
    "get_debug",
    "print_debug",
)


_v_match: re.Match[str] | None = re.search(
    r"^__version__\s*=\s*[\'\"]([^\'\"]*)[\'\"]",
    (PKG_PATH / "__init__.py").read_text(),
    re.MULTILINE,
)
_v: str = _v_match.group(1) if _v_match is not None else "0.0.0"


class DebugDict(TypedDict):
    """TypedDict that stores typing information for ``get_debug()``."""

    pkg_path: Path
    version: str
    python_version: str
    python_platform: str
    np_version: str
    mpl_version: str


def get_debug() -> DebugDict:
    """Get debug info."""
    return {
        "version": _v,
        "python_version": ".".join(map(str, sys.version_info)),
        "np_version": np.__version__,
        "mpl_version": mpl.__version__,
        "pkg_path": PKG_PATH,
        "python_platform": sys.platform,
    }


def print_debug() -> None:
    """Print debug info."""
    for k, v in get_debug().items():
        print(f"{k:19} {v!r}")  # noqa: T201
