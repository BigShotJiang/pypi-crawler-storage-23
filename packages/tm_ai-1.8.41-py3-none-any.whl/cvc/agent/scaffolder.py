"""
cvc.agent.scaffolder — Deterministic project scaffolding engine.

Instead of asking the LLM to create files one-by-one, this module runs
the *official* CLI scaffolding commands for each tech stack (e.g.
``uv init``, ``npx create-next-app``, ``cargo init``, ``flutter create``).
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("cvc.agent.scaffolder")


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ScaffoldRecipe:
    """One recipe = prerequisite check + ordered shell commands."""

    prerequisite: str  # Tool name to check (e.g. "uv", "node", "cargo")
    commands: list[str]  # Shell commands to run sequentially
    post_files: dict[str, str] = field(default_factory=dict)  # Extra files to create (path → content)
    install_hint: str = ""  # Shown when prerequisite is missing


@dataclass
class ScaffoldResult:
    success: bool
    output: str  # Combined stdout/stderr from all commands
    files_created: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Recipes
# ---------------------------------------------------------------------------

SCAFFOLD_RECIPES: dict[str, ScaffoldRecipe] = {
    # ── Web Applications ──────────────────────────────────────────────
    "React with TypeScript (Vite)": ScaffoldRecipe(
        prerequisite="node",
        commands=[
            "npm create vite@latest . -- --template react-ts",
            "npm install",
        ],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Next.js (React framework)": ScaffoldRecipe(
        prerequisite="node",
        commands=["npx create-next-app@latest . --yes"],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Vue 3 with Vite": ScaffoldRecipe(
        prerequisite="node",
        commands=[
            "npm create vite@latest . -- --template vue-ts",
            "npm install",
        ],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Angular with TypeScript": ScaffoldRecipe(
        prerequisite="node",
        commands=["npx @angular/cli@latest new app --directory . --skip-git --defaults"],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "SvelteKit": ScaffoldRecipe(
        prerequisite="node",
        commands=[
            "npx sv create . --template minimal --types ts --no-install",
            "npm install",
        ],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Flask web app": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add flask"],
        post_files={
            "app.py": (
                "from flask import Flask\n\n"
                "app = Flask(__name__)\n\n\n"
                '@app.route("/")\n'
                "def index():\n"
                '    return "Hello, World!"\n'
            ),
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Django web app": ScaffoldRecipe(
        prerequisite="uv",
        commands=[
            "uv init",
            "uv add django",
            "uv run django-admin startproject config .",
        ],
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "FastAPI with Jinja2 templates": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", 'uv add "fastapi[standard]" jinja2'],
        post_files={
            "app.py": (
                "from fastapi import FastAPI\n\n"
                "app = FastAPI()\n\n\n"
                '@app.get("/")\n'
                "def root():\n"
                '    return {"message": "Hello, World!"}\n'
            ),
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),

    # ── API / Backend ─────────────────────────────────────────────────
    "FastAPI REST API": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", 'uv add "fastapi[standard]"'],
        post_files={
            "app.py": (
                "from fastapi import FastAPI\n\n"
                "app = FastAPI()\n\n\n"
                '@app.get("/")\n'
                "def root():\n"
                '    return {"message": "Hello, World!"}\n'
            ),
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Flask REST API": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add flask flask-cors"],
        post_files={
            "app.py": (
                "from flask import Flask\nfrom flask_cors import CORS\n\n"
                "app = Flask(__name__)\nCORS(app)\n\n\n"
                '@app.route("/")\n'
                "def index():\n"
                '    return {"message": "Hello, World!"}\n'
            ),
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Express.js API": ScaffoldRecipe(
        prerequisite="node",
        commands=["npm init -y", "npm install express cors"],
        post_files={
            "index.js": (
                'const express = require("express");\n'
                'const cors = require("cors");\n\n'
                "const app = express();\n"
                "app.use(cors());\n"
                "app.use(express.json());\n\n"
                'app.get("/", (req, res) => {\n'
                '  res.json({ message: "Hello, World!" });\n'
                "});\n\n"
                "const PORT = process.env.PORT || 3000;\n"
                "app.listen(PORT, () => {\n"
                '  console.log(`Server running on port ${PORT}`);\n'
                "});\n"
            ),
        },
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Gin HTTP API": ScaffoldRecipe(
        prerequisite="go",
        commands=[
            "go mod init project",
            "go get github.com/gin-gonic/gin",
        ],
        post_files={
            "main.go": (
                'package main\n\nimport "github.com/gin-gonic/gin"\n\n'
                "func main() {\n"
                "\tr := gin.Default()\n"
                '\tr.GET("/", func(c *gin.Context) {\n'
                '\t\tc.JSON(200, gin.H{"message": "Hello, World!"})\n'
                "\t})\n"
                '\tr.Run(":8080")\n'
                "}\n"
            ),
        },
        install_hint="Install Go from https://go.dev/dl/",
    ),
    "Actix-web API": ScaffoldRecipe(
        prerequisite="cargo",
        commands=[
            "cargo init",
            "cargo add actix-web serde tokio --features tokio/full,serde/derive",
        ],
        install_hint="Install Rust from https://rustup.rs/",
    ),
    "ASP.NET Core Web API": ScaffoldRecipe(
        prerequisite="dotnet",
        commands=["dotnet new webapi"],
        install_hint="Install .NET SDK from https://dotnet.microsoft.com/download",
    ),

    # ── CLI Tools ─────────────────────────────────────────────────────
    "Click CLI app": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add click"],
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Typer CLI app": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add typer"],
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Commander.js CLI": ScaffoldRecipe(
        prerequisite="node",
        commands=["npm init -y", "npm install commander"],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Go CLI with cobra": ScaffoldRecipe(
        prerequisite="go",
        commands=[
            "go mod init project",
            "go get github.com/spf13/cobra@latest",
        ],
        install_hint="Install Go from https://go.dev/dl/",
    ),
    "Rust CLI with clap": ScaffoldRecipe(
        prerequisite="cargo",
        commands=["cargo init", "cargo add clap --features derive"],
        install_hint="Install Rust from https://rustup.rs/",
    ),

    # ── Library / Package ─────────────────────────────────────────────
    "Python library with pyproject.toml": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init --lib"],
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "TypeScript npm package": ScaffoldRecipe(
        prerequisite="node",
        commands=[
            "npm init -y",
            "npm install -D typescript @types/node",
            "npx tsc --init",
        ],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Rust library crate": ScaffoldRecipe(
        prerequisite="cargo",
        commands=["cargo init --lib"],
        install_hint="Install Rust from https://rustup.rs/",
    ),
    "Go library module": ScaffoldRecipe(
        prerequisite="go",
        commands=["go mod init project"],
        install_hint="Install Go from https://go.dev/dl/",
    ),

    # ── AI Agent / Chatbot ────────────────────────────────────────────
    "OpenAI chat agent": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add openai python-dotenv"],
        post_files={
            ".env.example": "OPENAI_API_KEY=sk-...\n",
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "LangChain agent": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add langchain langchain-openai python-dotenv"],
        post_files={
            ".env.example": "OPENAI_API_KEY=sk-...\n",
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "AutoGen multi-agent": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add autogen-agentchat"],
        post_files={
            ".env.example": "OPENAI_API_KEY=sk-...\n",
        },
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    "Vercel AI SDK bot": ScaffoldRecipe(
        prerequisite="node",
        commands=[
            "npx create-next-app@latest . --yes",
            "npm install ai @ai-sdk/openai",
        ],
        post_files={
            ".env.example": "OPENAI_API_KEY=sk-...\n",
        },
        install_hint="Install Node.js from https://nodejs.org/",
    ),

    # ── Mobile Application ────────────────────────────────────────────
    "React Native (Expo)": ScaffoldRecipe(
        prerequisite="node",
        commands=["npx create-expo-app@latest ."],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Flutter app": ScaffoldRecipe(
        prerequisite="flutter",
        commands=["flutter create ."],
        install_hint="Install Flutter from https://docs.flutter.dev/get-started/install",
    ),

    # ── Desktop Application ───────────────────────────────────────────
    "Electron desktop app": ScaffoldRecipe(
        prerequisite="node",
        commands=["npm init -y", "npm install electron --save-dev"],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "Tauri desktop app": ScaffoldRecipe(
        prerequisite="node",
        commands=["npm create tauri-app@latest . -- --template vanilla-ts --manager npm --yes"],
        install_hint="Install Node.js from https://nodejs.org/",
    ),
    "PyQt6 desktop app": ScaffoldRecipe(
        prerequisite="uv",
        commands=["uv init", "uv add pyqt6"],
        install_hint="Install uv: pip install uv  (or see https://docs.astral.sh/uv/)",
    ),
    ".NET MAUI cross-platform app": ScaffoldRecipe(
        prerequisite="dotnet",
        commands=["dotnet new maui"],
        install_hint="Install .NET SDK from https://dotnet.microsoft.com/download",
    ),
}


# ---------------------------------------------------------------------------
# Prerequisite checking
# ---------------------------------------------------------------------------

def check_prerequisite(tool: str) -> bool:
    """Return True if *tool* is found on PATH."""
    return shutil.which(tool) is not None


def _install_hint_for(tool: str) -> str:
    """Return a user-friendly install instruction for common tools."""
    hints = {
        "uv": "pip install uv  (or see https://docs.astral.sh/uv/)",
        "node": "https://nodejs.org/",
        "cargo": "https://rustup.rs/",
        "go": "https://go.dev/dl/",
        "flutter": "https://docs.flutter.dev/get-started/install",
        "dotnet": "https://dotnet.microsoft.com/download",
    }
    return hints.get(tool, f"Install '{tool}' and make sure it's on your PATH.")


# ---------------------------------------------------------------------------
# Shell runner (mirrors executor._bash pattern)
# ---------------------------------------------------------------------------

def _run_shell(command: str, workspace: Path, timeout: int = 300) -> tuple[int, str]:
    """Run a single shell command in *workspace* and return (exit_code, output)."""
    if sys.platform == "win32":
        utf8_prefix = (
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
            "$OutputEncoding = [System.Text.Encoding]::UTF8; "
        )
        shell_cmd = [
            "powershell", "-NoProfile", "-NonInteractive",
            "-Command", utf8_prefix + command,
        ]
    else:
        shell_cmd = ["bash", "-c", command]

    try:
        result = subprocess.run(
            shell_cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=str(workspace),
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
    except subprocess.TimeoutExpired:
        return 1, f"Command timed out after {timeout}s: {command}"
    except FileNotFoundError as exc:
        return 1, f"Shell not found: {exc}"

    parts: list[str] = []
    if result.stdout:
        parts.append(result.stdout.strip())
    if result.stderr:
        parts.append(result.stderr.strip())
    return result.returncode, "\n".join(parts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_scaffold(
    workspace: Path,
    stack_id: str,
    *,
    on_command: "callable | None" = None,
) -> ScaffoldResult:
    """
    Execute the scaffold recipe for *stack_id* in *workspace*.

    Parameters
    ----------
    workspace : Path
        Directory to scaffold into (must already exist).
    stack_id : str
        Key into ``SCAFFOLD_RECIPES`` — matches the second element of each
        ``stack_map`` tuple in ``chat.py``.
    on_command : callable, optional
        ``on_command(cmd, index, total)`` — called before each command runs
        so the UI can display progress.

    Returns
    -------
    ScaffoldResult
    """
    recipe = SCAFFOLD_RECIPES.get(stack_id)
    if recipe is None:
        return ScaffoldResult(
            success=False,
            output=f"No scaffold recipe found for '{stack_id}'. Falling back to AI-assisted scaffolding.",
        )

    # ── Prerequisite check ────────────────────────────────────────────
    if not check_prerequisite(recipe.prerequisite):
        hint = recipe.install_hint or _install_hint_for(recipe.prerequisite)
        return ScaffoldResult(
            success=False,
            output=(
                f"Required tool '{recipe.prerequisite}' is not installed.\n"
                f"Install it: {hint}"
            ),
        )

    # ── Run commands ──────────────────────────────────────────────────
    all_output: list[str] = []
    total = len(recipe.commands)
    for idx, cmd in enumerate(recipe.commands, 1):
        if on_command:
            on_command(cmd, idx, total)
        logger.info("scaffold cmd %d/%d: %s", idx, total, cmd)
        exit_code, output = _run_shell(cmd, workspace)
        if output:
            all_output.append(output)
        if exit_code != 0:
            all_output.append(f"\n✗ Command failed (exit {exit_code}): {cmd}")
            return ScaffoldResult(success=False, output="\n".join(all_output))

    # ── Write post-scaffold files ─────────────────────────────────────
    for rel_path, content in recipe.post_files.items():
        target = workspace / rel_path
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")

    # ── Collect created files ─────────────────────────────────────────
    created: list[str] = []
    try:
        for entry in sorted(workspace.rglob("*")):
            rel = entry.relative_to(workspace)
            parts = rel.parts
            if any(
                p in (".git", ".cvc", "node_modules", "__pycache__", ".venv", "venv", "target")
                for p in parts
            ):
                continue
            if entry.is_file():
                created.append(str(rel))
    except OSError:
        pass

    return ScaffoldResult(
        success=True,
        output="\n".join(all_output),
        files_created=created,
    )
