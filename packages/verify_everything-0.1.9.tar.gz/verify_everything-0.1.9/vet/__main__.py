import sys

from vet.cli.main import main

sys.exit(main())
