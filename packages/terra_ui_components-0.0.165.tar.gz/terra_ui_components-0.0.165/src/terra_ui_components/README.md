# Terra UI Widgets

For usage in Jupyter Notebooks and other frameworks that support ipywidgets.

These are AnyWidget (https://anywidget.dev/) wrappers over the components found in 'src/components'
