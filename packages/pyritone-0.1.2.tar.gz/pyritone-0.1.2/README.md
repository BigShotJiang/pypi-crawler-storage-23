# pyritone

`pyritone` is the Python client for the Py-Ritone Fabric bridge.

## Install

```bash
pip install pyritone
```

## Fastest Working Sync Example

```python
from pyritone import PyritoneClient

with PyritoneClient() as client:
    print(client.ping())
    dispatch = client.build_file("schematics/base.schem", 100, 70, 100)
    print(dispatch)
```

## Fastest Working Async Example

```python
import asyncio
from pyritone import AsyncPyritoneClient


async def main() -> None:
    client = AsyncPyritoneClient()
    await client.connect()
    try:
        print(await client.ping())
        dispatch = await client.build_file("schematics/base.schem", 100, 70, 100)
        print(dispatch)
    finally:
        await client.close()


asyncio.run(main())
```

## Docs

- Full docs index: `python/docs/index.md`
- Quickstart: `python/docs/quickstart.md`
- Sync client guide: `python/docs/sync-client.md`
- Async client guide: `python/docs/async-client.md`
- Settings API: `python/docs/settings-api.md`
- Tasks/events/waiting: `python/docs/tasks-events-and-waiting.md`
- Errors/troubleshooting: `python/docs/errors-and-troubleshooting.md`
- CLI usage: `python/docs/cli.md`
- Command docs:
  - `python/docs/commands/navigation.md`
  - `python/docs/commands/world.md`
  - `python/docs/commands/build.md`
  - `python/docs/commands/control.md`
  - `python/docs/commands/info.md`
  - `python/docs/commands/waypoints.md`
  - `python/docs/commands/aliases.md`
- Raw Baritone appendix: `python/docs/baritone-commands.md`

## Public API Map

- Clients:
  - `PyritoneClient`
  - `AsyncPyritoneClient`
- Low-level methods:
  - `ping`, `status_get`, `execute`, `cancel`, `next_event`, `wait_for_task`
- Command wrappers:
  - All top-level Baritone commands exposed as methods.
- Local schematic helpers:
  - `build_file(path, *coords, base_dir=None)`
  - `build_file_wait(path, *coords, base_dir=None)`
- Settings namespace:
  - Sync: `client.settings.allowPlace = True`
  - Async: `await client.settings.allowPlace.set(True)`

## Auto-Discovery (Zero-Setup)

By default, `pyritone` discovers bridge metadata from:

- `<minecraft>/config/pyritone_bridge/bridge-info.json`

Override precedence:

1. Explicit constructor args
2. Environment variables: `PYRITONE_BRIDGE_INFO`, `PYRITONE_TOKEN`, `PYRITONE_HOST`, `PYRITONE_PORT`
3. Auto-discovered bridge info file
