from django.apps import AppConfig


class MinidebconfConfig(AppConfig):
    name = 'minidebconf'
