import register.admin.accommodation
import register.admin.address
import register.admin.attendee
import register.admin.childcare
import register.admin.food
import register.admin.queue
