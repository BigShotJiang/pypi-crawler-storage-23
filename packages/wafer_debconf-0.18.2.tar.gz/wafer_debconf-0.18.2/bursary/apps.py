from django.apps import AppConfig


class BursaryConfig(AppConfig):
    name = 'bursary'
