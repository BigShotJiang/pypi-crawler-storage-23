#!/bin/bash
# Run E2E tests against the Go server
#
# Usage:
#   ./scripts/run_e2e_tests.sh [options]
#
# Options:
#   --skip-server-check    Skip checking if server is running
#   --api-url URL          Override API URL (default: http://localhost:8080)
#   --mcp-url URL          Override MCP URL (default: http://localhost:8081/mcp)
#   --skip-mcp             Skip MCP tests

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Default values (aligned with Go E2E tests and CI)
API_URL="${BASE_URL:-http://localhost:8080}"
MCP_URL="${MCP_URL:-http://localhost:8081/mcp}"
SKIP_SERVER_CHECK=false
SKIP_MCP=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-server-check)
            SKIP_SERVER_CHECK=true
            shift
            ;;
        --api-url)
            API_URL="$2"
            shift 2
            ;;
        --mcp-url)
            MCP_URL="$2"
            shift 2
            ;;
        --skip-mcp)
            SKIP_MCP=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

echo -e "${GREEN}Context Surfaces - E2E Test Runner${NC}"
echo "========================================"
echo ""
echo "API URL: $API_URL"
echo "MCP URL: $MCP_URL"
echo ""

# Check if server is running
if [ "$SKIP_SERVER_CHECK" = false ]; then
    echo -e "${YELLOW}Checking if server is running...${NC}"

    if curl -s -f "$API_URL/health" > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Server is running${NC}"
    else
        echo -e "${RED}✗ Server is not running at $API_URL${NC}"
        echo ""
        echo "Please start the server first:"
        echo "  cd .. && make run"
        echo ""
        echo "Or skip this check with:"
        echo "  ./scripts/run_e2e_tests.sh --skip-server-check"
        exit 1
    fi
    echo ""
fi

# Set environment variables
export BASE_URL="$API_URL"
export MCP_URL="$MCP_URL"

if [ "$SKIP_MCP" = true ]; then
    export SKIP_MCP_TESTS="true"
fi

# Run tests
echo -e "${YELLOW}Running E2E tests...${NC}"
echo ""

pytest tests/test_e2e.py \
    -v \
    -m e2e \
    --tb=short \
    --log-cli-level=INFO \
    "$@"

EXIT_CODE=$?

echo ""
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}✓ All E2E tests passed!${NC}"
else
    echo -e "${RED}✗ Some E2E tests failed${NC}"
fi

exit $EXIT_CODE
