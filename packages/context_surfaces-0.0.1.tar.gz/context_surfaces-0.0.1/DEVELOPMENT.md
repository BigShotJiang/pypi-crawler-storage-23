# Development Guide

## Project Structure

```
python-client/
├── src/
│   └── context_surfaces/
│       ├── __init__.py           # Public API exports
│       ├── client.py             # Main HTTP client
│       ├── mcp_client.py         # MCP protocol client
│       ├── models.py             # Pydantic models
│       ├── exceptions.py         # Custom exceptions
│       └── cli.py                # CLI tool
├── tests/
│   ├── __init__.py
│   └── test_models.py            # Model tests
├── examples/
│   ├── basic_workflow.py         # Complete workflow example
│   └── error_handling.py         # Error handling patterns
├── pyproject.toml                # Project configuration
├── Makefile                      # Development commands
├── README.md                     # User documentation
└── DEVELOPMENT.md                # This file
```

## Setup

### Prerequisites

- Python 3.11+
- [uv](https://github.com/astral-sh/uv) (recommended) or pip

### Installation

```bash
# Clone the repository
git clone https://github.com/redislabsdev/cloud-context-engine.git
cd cloud-context-engine/python-client

# Install with uv (recommended)
uv sync

# Or with pip
pip install -e .
```

## Development Workflow

### Running Tests

```bash
# Run all tests
make test

# Run with coverage
make test-cov

# Run specific test file
pytest tests/test_models.py

# Run with verbose output
pytest -v
```

### Code Quality

```bash
# Run linting
make lint

# Format code
make format

# Type checking
make type-check

# Run all checks
make check
```

### Building

```bash
# Build distribution packages
make build

# Clean build artifacts
make clean
```

## Code Style

### Type Hints

All code must have complete type hints:

```python
async def create_admin_key(
    self,
    request: CreateAdminKeyRequest,
) -> AdminAPIKey:
    """Create an admin API key."""
    ...
```

### Docstrings

Use Google-style docstrings:

```python
def example_function(param1: str, param2: int) -> bool:
    """Short description.

    Longer description if needed.

    Args:
        param1: Description of param1
        param2: Description of param2

    Returns:
        Description of return value

    Raises:
        ValueError: When something is wrong

    Example:
        ```python
        result = example_function("test", 42)
        ```
    """
    ...
```

### Error Handling

Always use specific exception types:

```python
try:
    result = await client.get_context_surface(surface_id, admin_key=key)
except NotFoundError:
    # Handle not found
    ...
except AuthenticationError:
    # Handle auth error
    ...
except APIError as e:
    # Handle generic API error
    logger.error(f"API error: {e.status_code}")
    ...
```

### Async/Await

All I/O operations must be async:

```python
async def fetch_data(self) -> dict[str, Any]:
    """Fetch data asynchronously."""
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.json()
```

## Testing Guidelines

### Unit Tests

Test individual components in isolation:

```python
def test_create_admin_key_request():
    """Test creating a valid admin key request."""
    request = CreateAdminKeyRequest(
        name="Test",
        owner="user123",
    )
    assert request.key_type == KeyType.ADMIN
```

### Integration Tests

Test with a running server (mark with `@pytest.mark.integration`):

```python
@pytest.mark.integration
async def test_full_workflow():
    """Test complete workflow with real server."""
    async with ContextSurfacesClient() as client:
        admin_key = await client.create_admin_key(...)
        assert admin_key.key
```

### Mocking

Use `respx` for mocking HTTP requests:

```python
import respx
from httpx import Response

@respx.mock
async def test_with_mock():
    """Test with mocked HTTP."""
    respx.get("http://api/health").mock(
        return_value=Response(200, json={"status": "ok"})
    )
    # Test code here
```

## Release Process

1. Update version in `pyproject.toml`
2. Update CHANGELOG.md
3. Run all tests: `make check`
4. Build: `make build`
5. Tag release: `git tag v0.1.0`
6. Push: `git push --tags`
7. Publish: `make publish`

## Contributing

1. Create a feature branch
2. Make changes with tests
3. Run `make check` to ensure quality
4. Submit pull request
5. Wait for CI to pass
6. Request review

## Troubleshooting

### Import Errors

If you get import errors, ensure the package is installed in editable mode:

```bash
uv pip install -e .
```

### Type Checking Failures

Run mypy with verbose output:

```bash
mypy --show-error-codes src
```

### Test Failures

Run with verbose output and stop on first failure:

```bash
pytest -vx
```
