"""Tests for URL resolution helpers."""

import pytest

from context_surfaces.url_config import resolve_url


class TestResolveUrl:
    """Test resolve_url function."""

    def test_explicit_value_takes_precedence(self):
        """Test that explicit value overrides config value."""
        result = resolve_url(
            explicit_value="http://explicit.example.com",
            config_value="http://config.example.com",
        )
        assert result == "http://explicit.example.com"

    def test_config_value_used_when_no_explicit_value(self):
        """Test that config value is used when explicit value is None."""
        result = resolve_url(
            explicit_value=None,
            config_value="http://config.example.com",
        )
        assert result == "http://config.example.com"

    def test_trailing_slash_removed_for_root(self):
        """Test that trailing slash is removed from root URL."""
        result = resolve_url(
            explicit_value="http://example.com/",
            config_value="http://config.example.com/",
        )
        assert result == "http://example.com"

    def test_trailing_slash_removed_from_root_config_value(self):
        """Test that trailing slash is removed from root config value URL."""
        result = resolve_url(
            explicit_value=None,
            config_value="http://config.example.com/",
        )
        assert result == "http://config.example.com"

    def test_path_component_gets_trailing_slash(self):
        """Test that URL path components get trailing slash for proper joining."""
        result = resolve_url(
            explicit_value="http://example.com/api/v1",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/api/v1/"

    def test_path_with_trailing_slash_preserved(self):
        """Test that URL path with trailing slash is preserved."""
        result = resolve_url(
            explicit_value="http://example.com/api/v1/",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/api/v1/"

    def test_https_url_accepted(self):
        """Test that HTTPS URLs are accepted."""
        result = resolve_url(
            explicit_value="https://example.com",
            config_value="http://config.example.com",
        )
        assert result == "https://example.com"

    def test_whitespace_stripped(self):
        """Test that whitespace is stripped from URLs."""
        result = resolve_url(
            explicit_value="  http://example.com  ",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com"

    def test_empty_string_raises_error(self):
        """Test that empty string raises ValueError."""
        with pytest.raises(ValueError, match="URL cannot be empty"):
            resolve_url(
                explicit_value="",
                config_value="http://config.example.com",
            )

    def test_whitespace_only_raises_error(self):
        """Test that whitespace-only string raises ValueError."""
        with pytest.raises(ValueError, match="URL cannot be empty"):
            resolve_url(
                explicit_value="   ",
                config_value="http://config.example.com",
            )

    def test_invalid_protocol_raises_error(self):
        """Test that URL without http/https raises ValueError."""
        with pytest.raises(ValueError, match="URL must start with http:// or https://"):
            resolve_url(
                explicit_value="ftp://example.com",
                config_value="http://config.example.com",
            )

    def test_no_protocol_raises_error(self):
        """Test that URL without protocol raises ValueError."""
        with pytest.raises(ValueError, match="URL must start with http:// or https://"):
            resolve_url(
                explicit_value="example.com",
                config_value="http://config.example.com",
            )

    def test_keyword_only_arguments(self):
        """Test that function requires keyword arguments."""
        with pytest.raises(TypeError):
            resolve_url(  # type: ignore
                "http://example.com",
                "http://config.example.com",
            )

    def test_localhost_url_accepted(self):
        """Test that localhost URLs are accepted."""
        result = resolve_url(
            explicit_value="http://localhost:8080",
            config_value="http://config.example.com",
        )
        assert result == "http://localhost:8080"

    def test_ip_address_url_accepted(self):
        """Test that IP address URLs are accepted."""
        result = resolve_url(
            explicit_value="http://192.168.1.1:8080",
            config_value="http://config.example.com",
        )
        assert result == "http://192.168.1.1:8080"

    def test_single_level_path_gets_trailing_slash(self):
        """Test that single-level path gets trailing slash."""
        result = resolve_url(
            explicit_value="http://example.com/api",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/api/"

    def test_multi_level_path_gets_trailing_slash(self):
        """Test that multi-level path gets trailing slash."""
        result = resolve_url(
            explicit_value="http://example.com/context-surfaces/api/v1",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/context-surfaces/api/v1/"

    def test_url_with_port_and_path(self):
        """Test URL with port and path gets trailing slash."""
        result = resolve_url(
            explicit_value="http://localhost:8080/api",
            config_value="http://config.example.com",
        )
        assert result == "http://localhost:8080/api/"

    def test_url_with_query_string_preserved(self):
        """Test that query strings are preserved."""
        result = resolve_url(
            explicit_value="http://example.com/api?version=1",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/api/?version=1"

    def test_url_with_fragment_preserved(self):
        """Test that URL fragments are preserved."""
        result = resolve_url(
            explicit_value="http://example.com/docs#section",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/docs/#section"

    def test_root_url_without_trailing_slash(self):
        """Test that root URL without trailing slash stays clean."""
        result = resolve_url(
            explicit_value="http://example.com",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com"

    def test_ensure_trailing_slash_false_preserves_path(self):
        """Test that ensure_trailing_slash=False preserves exact path."""
        result = resolve_url(
            explicit_value="http://example.com/mcp",
            config_value="http://config.example.com",
            ensure_trailing_slash=False,
        )
        assert result == "http://example.com/mcp"

    def test_ensure_trailing_slash_false_with_multi_level_path(self):
        """Test that ensure_trailing_slash=False works with multi-level paths."""
        result = resolve_url(
            explicit_value="http://example.com/api/v1",
            config_value="http://config.example.com",
            ensure_trailing_slash=False,
        )
        assert result == "http://example.com/api/v1"

    def test_ensure_trailing_slash_true_adds_slash(self):
        """Test that ensure_trailing_slash=True adds trailing slash to paths."""
        result = resolve_url(
            explicit_value="http://example.com/api",
            config_value="http://config.example.com",
            ensure_trailing_slash=True,
        )
        assert result == "http://example.com/api/"

    def test_ensure_trailing_slash_default_is_true(self):
        """Test that default behavior adds trailing slash."""
        result = resolve_url(
            explicit_value="http://example.com/api",
            config_value="http://config.example.com",
        )
        assert result == "http://example.com/api/"

    def test_ensure_trailing_slash_false_removes_existing_slash(self):
        """Test that ensure_trailing_slash=False removes trailing slash."""
        result = resolve_url(
            explicit_value="http://example.com/mcp/",
            config_value="http://config.example.com",
            ensure_trailing_slash=False,
        )
        assert result == "http://example.com/mcp"
