"""Tests for CLI audit logger."""

import tempfile
from pathlib import Path

import pytest

from context_surfaces.cli.services.audit_logger import AuditLogger


@pytest.fixture
def temp_log_dir():
    """Create a temporary directory for logs."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def audit_logger(temp_log_dir):
    """Create an audit logger with temporary directory."""
    log_file = temp_log_dir / "audit.log"
    return AuditLogger(log_file=log_file)


class TestAuditLogger:
    """Test audit logger functionality."""

    def test_init_creates_directory(self, temp_log_dir):
        """Test that initialization creates the log directory."""
        log_dir = temp_log_dir / "subdir"
        log_file = log_dir / "audit.log"
        assert not log_dir.exists()

        AuditLogger(log_file=log_file)

        assert log_dir.exists()

    def test_log_operation(self, audit_logger, temp_log_dir):
        """Test logging an operation."""
        audit_logger.log_operation(
            user="test_user", action="test_action", status="success", detail="test detail"
        )

        # Check log file exists
        log_file = temp_log_dir / "audit.log"
        assert log_file.exists()

        # Check log content
        content = log_file.read_text()
        assert "test_user" in content
        assert "test_action" in content
        assert "success" in content
        assert "test detail" in content

    def test_log_redacts_admin_api_keys(self, audit_logger, temp_log_dir):
        """Test that admin API keys are redacted in logs."""
        audit_logger.log_operation(
            user="test_user",
            action="create_key",
            status="success",
            api_key="cs_admin_1234567890abcdef",
        )

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should not contain the full key
        assert "cs_admin_1234567890abcdef" not in content
        # Should contain redacted version
        assert "[REDACTED]" in content

    def test_log_redacts_agent_api_keys(self, audit_logger, temp_log_dir):
        """Test that agent API keys are redacted in logs."""
        audit_logger.log_operation(
            user="test_user",
            action="create_key",
            status="success",
            api_key="cs_agent_abcdef1234567890",
        )

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should not contain the full key
        assert "cs_agent_abcdef1234567890" not in content
        # Should contain redacted version
        assert "[REDACTED]" in content

    def test_log_multiple_operations(self, audit_logger, temp_log_dir):
        """Test logging multiple operations."""
        audit_logger.log_operation(user="test_user", action="action1", status="success")
        audit_logger.log_operation(
            user="test_user", action="action2", status="failed", error="test error"
        )
        audit_logger.log_operation(user="test_user", action="action3", status="success")

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # All operations should be logged
        assert "action1" in content
        assert "action2" in content
        assert "action3" in content
        assert "test error" in content

    def test_log_with_user_info(self, audit_logger, temp_log_dir):
        """Test logging with user information."""
        audit_logger.log_operation(
            user="testuser", action="login", status="success", ip="192.168.1.1"
        )

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        assert "testuser" in content
        assert "192.168.1.1" in content

    def test_log_file_permissions(self, audit_logger, temp_log_dir):
        """Test that log file has secure permissions."""
        audit_logger.log_operation(user="test_user", action="test", status="success")

        log_file = temp_log_dir / "audit.log"
        assert log_file.exists()

        # Log file should be readable/writable by owner only
        assert log_file.stat().st_mode & 0o777 == 0o600

    def test_log_includes_timestamp(self, audit_logger, temp_log_dir):
        """Test that log entries include timestamps."""
        audit_logger.log_operation(user="test_user", action="test", status="success")

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should contain ISO 8601 timestamp pattern (YYYY-MM-DD)
        import re

        assert re.search(r"\d{4}-\d{2}-\d{2}", content)

    def test_log_includes_log_level(self, audit_logger, temp_log_dir):
        """Test that log entries include log level."""
        audit_logger.log_operation(user="test_user", action="test", status="success")

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should contain log level (INFO, ERROR, etc.)
        assert "[INFO]" in content

    def test_log_error_status(self, audit_logger, temp_log_dir):
        """Test logging operations with error status."""
        audit_logger.log_operation(
            user="test_user",
            action="failed_action",
            status="failed",
            level="ERROR",
            error="Something went wrong",
        )

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        assert "failed_action" in content
        assert "failed" in content
        assert "Something went wrong" in content
        assert "[ERROR]" in content

    def test_log_redacts_keys_in_nested_data(self, audit_logger, temp_log_dir):
        """Test that API keys are redacted even in nested data structures."""
        audit_logger.log_operation(
            user="test_user",
            action="test",
            status="success",
            data={"key": "cs_admin_secret123", "nested": {"agent_key": "cs_agent_secret456"}},
        )

        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should not contain the full keys
        assert "cs_admin_secret123" not in content
        assert "cs_agent_secret456" not in content
        # Should contain redacted version
        assert "[REDACTED]" in content

    def test_concurrent_logging(self, audit_logger, temp_log_dir):
        """Test that concurrent logging is thread-safe."""
        import threading

        def log_many():
            for i in range(10):
                audit_logger.log_operation(user="test_user", action=f"action_{i}", status="success")

        # Create multiple threads
        threads = [threading.Thread(target=log_many) for _ in range(5)]

        # Start all threads
        for t in threads:
            t.start()

        # Wait for all threads
        for t in threads:
            t.join()

        # Check that all operations were logged
        log_file = temp_log_dir / "audit.log"
        content = log_file.read_text()

        # Should have 50 log entries (5 threads * 10 operations)
        lines = content.strip().split("\n")
        assert len(lines) >= 50
