"""Tests for Pydantic models."""

from datetime import datetime

import pytest
from pydantic import ValidationError

from context_surfaces.models import (
    AdminAPIKey,
    AgentAPIKey,
    ContextSurface,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    KeyType,
    Pagination,
    RedisConnectionConfig,
    UpdateContextSurfaceRequest,
)


class TestKeyType:
    """Tests for KeyType enum."""

    def test_key_types(self):
        """Test key type values."""
        assert KeyType.ADMIN == "admin"
        assert KeyType.AGENT == "agent"


class TestCreateAdminKeyRequest:
    """Tests for CreateAdminKeyRequest model."""

    def test_valid_request(self):
        """Test creating a valid admin key request."""
        request = CreateAdminKeyRequest(
            name="Test Admin",
            owner="user123",
            description="Test description",
            metadata={"env": "test"},
        )
        assert request.name == "Test Admin"
        assert request.owner == "user123"
        assert request.key_type == KeyType.ADMIN

    def test_invalid_key_type(self):
        """Test that agent key type is rejected."""
        with pytest.raises(ValidationError):
            CreateAdminKeyRequest(
                name="Test",
                owner="user123",
                key_type=KeyType.AGENT,  # Should fail
            )

    def test_required_fields(self):
        """Test that required fields are enforced."""
        with pytest.raises(ValidationError):
            CreateAdminKeyRequest()  # Missing required fields


class TestCreateAgentKeyRequest:
    """Tests for CreateAgentKeyRequest model."""

    def test_valid_request(self):
        """Test creating a valid agent key request."""
        request = CreateAgentKeyRequest(
            name="Test Agent",
            description="Test description",
            metadata={"purpose": "testing"},
        )
        assert request.name == "Test Agent"
        assert request.description == "Test description"

    def test_optional_fields(self):
        """Test that optional fields work."""
        request = CreateAgentKeyRequest(name="Test")
        assert request.description is None
        assert request.expires_at is None
        assert request.metadata == {}
        assert request.access_tags is None

    def test_access_tags_valid(self):
        """Test creating a request with valid access tags (multi-value format)."""
        request = CreateAgentKeyRequest(
            name="Tenant Agent",
            access_tags={"tenant": ["acme"], "department": ["sales"]},
        )
        assert request.name == "Tenant Agent"
        assert request.access_tags == {"tenant": ["acme"], "department": ["sales"]}

    def test_access_tags_multi_value(self):
        """Test creating a request with multi-value access tags."""
        request = CreateAgentKeyRequest(
            name="Multi-Tenant Agent",
            access_tags={"tenant": ["acme", "globex"], "department": ["sales", "marketing"]},
        )
        assert request.access_tags == {
            "tenant": ["acme", "globex"],
            "department": ["sales", "marketing"],
        }

    def test_access_tags_empty_dict(self):
        """Test creating a request with empty access tags dict."""
        request = CreateAgentKeyRequest(
            name="Test Agent",
            access_tags={},
        )
        assert request.access_tags == {}

    def test_access_tags_single_tag(self):
        """Test creating a request with a single access tag."""
        request = CreateAgentKeyRequest(
            name="Single Tag Agent",
            access_tags={"user_id": ["123"]},
        )
        assert request.access_tags == {"user_id": ["123"]}

    def test_access_tags_serialization(self):
        """Test that access tags serialize correctly to JSON."""
        request = CreateAgentKeyRequest(
            name="Test Agent",
            access_tags={"tenant": ["acme"], "region": ["us-west"]},
        )
        data = request.model_dump()
        assert data["access_tags"] == {"tenant": ["acme"], "region": ["us-west"]}

    def test_access_tags_none_serialization(self):
        """Test that None access tags serialize correctly."""
        request = CreateAgentKeyRequest(name="Test Agent")
        data = request.model_dump()
        assert data["access_tags"] is None


class TestCreateContextSurfaceRequest:
    """Tests for CreateContextSurfaceRequest model."""

    def test_valid_request(self):
        """Test creating a valid context surface request."""
        data_model = {
            "entities": [
                {"name": "Customer", "fields": []},
                {"name": "Order", "fields": []},
            ]
        }
        request = CreateContextSurfaceRequest(
            name="Test Surface",
            description="Test description",
            data_model=data_model,
            redis_instance_id="redis-1",
            metadata={"version": "1.0"},
        )
        assert request.name == "Test Surface"
        assert request.data_model == data_model
        assert request.redis_instance_id == "redis-1"

    def test_without_data_model(self):
        """Test that data_model is optional."""
        request = CreateContextSurfaceRequest(name="Test")
        assert request.data_model is None
        assert request.redis_instance_id is None


class TestUpdateContextSurfaceRequest:
    """Tests for UpdateContextSurfaceRequest model."""

    def test_partial_update(self):
        """Test that all fields are optional."""
        request = UpdateContextSurfaceRequest(name="New Name")
        assert request.name == "New Name"
        assert request.description is None
        assert request.data_model is None

    def test_full_update(self):
        """Test updating all fields."""
        data_model = {
            "entities": [
                {"name": "Customer", "fields": []},
                {"name": "Order", "fields": []},
                {"name": "Product", "fields": []},
            ]
        }
        request = UpdateContextSurfaceRequest(
            name="New Name",
            description="New description",
            data_model=data_model,
            metadata={"version": "2.0"},
        )
        assert request.name == "New Name"
        assert request.data_model == data_model
        assert len(request.data_model["entities"]) == 3


class TestAdminAPIKey:
    """Tests for AdminAPIKey model."""

    def test_valid_admin_key(self):
        """Test creating a valid admin API key."""
        key = AdminAPIKey(
            id="key-123",
            name="Admin Key",
            owner="user123",
            key="secret-key",
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        assert key.key_type == KeyType.ADMIN
        assert key.id == "key-123"


class TestAgentAPIKey:
    """Tests for AgentAPIKey model."""

    def test_valid_agent_key(self):
        """Test creating a valid agent API key."""
        key = AgentAPIKey(
            id="key-456",
            name="Agent Key",
            owner="user123",
            key="secret-key",
            context_surface_id="ce-789",
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        assert key.key_type == KeyType.AGENT
        assert key.context_surface_id == "ce-789"


class TestContextSurface:
    """Tests for ContextSurface model."""

    def test_valid_context_surface(self):
        """Test creating a valid context surface."""
        surface = ContextSurface(
            id="ce-123",
            name="Test Surface",
            owner="user123",
            tools=["tool1", "tool2"],
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        assert surface.id == "ce-123"
        assert len(surface.tools) == 2


class TestPagination:
    """Tests for Pagination model."""

    def test_valid_pagination(self):
        """Test creating valid pagination."""
        pagination = Pagination(
            page=1,
            page_size=20,
            total_count=100,
            total_pages=5,
            has_next=True,
            has_prev=False,
        )
        assert pagination.page == 1
        assert pagination.has_next is True


class TestRedisConnectionConfig:
    """Tests for RedisConnectionConfig model."""

    def test_redis_connection_config_given_minimal_config_when_created_then_has_defaults(
        self,
    ):
        # Given
        addr = "localhost:6379"

        # When
        config = RedisConnectionConfig(addr=addr)

        # Then
        assert config.addr == addr
        assert config.username == ""
        assert config.password == ""
        assert config.db == 0
        assert config.tls_enabled is False
        assert config.ca_cert is None
        assert config.pool_size == 10
        assert config.min_idle_conns == 2

    def test_redis_connection_config_given_username_when_created_then_includes_username(
        self,
    ):
        # Given
        addr = "redis.example.com:6379"
        username = "myuser"
        password = "mypass"

        # When
        config = RedisConnectionConfig(
            addr=addr,
            username=username,
            password=password,
        )

        # Then
        assert config.addr == addr
        assert config.username == username
        assert config.password == password

    def test_redis_connection_config_given_full_config_when_created_then_all_fields_set(
        self,
    ):
        # Given
        addr = "redis-cloud.example.com:16379"
        username = "acl-user"
        password = "secure-pass"
        db = 5
        tls_enabled = True
        ca_cert = "-----BEGIN CERTIFICATE-----..."
        pool_size = 20
        min_idle_conns = 5

        # When
        config = RedisConnectionConfig(
            addr=addr,
            username=username,
            password=password,
            db=db,
            tls_enabled=tls_enabled,
            ca_cert=ca_cert,
            pool_size=pool_size,
            min_idle_conns=min_idle_conns,
        )

        # Then
        assert config.addr == addr
        assert config.username == username
        assert config.password == password
        assert config.db == db
        assert config.tls_enabled == tls_enabled
        assert config.ca_cert == ca_cert
        assert config.pool_size == pool_size
        assert config.min_idle_conns == min_idle_conns

    def test_redis_connection_config_given_empty_username_when_created_then_is_valid(
        self,
    ):
        # Given
        addr = "localhost:6379"
        username = ""

        # When
        config = RedisConnectionConfig(addr=addr, username=username)

        # Then
        assert config.username == ""
