"""Tests for unified client."""

import os
from unittest.mock import patch

import pytest
import respx
from httpx import Response

from context_surfaces import ContextField, ContextModel
from context_surfaces.unified_client import UnifiedClient


# Test models for import_data tests
class TestCustomer(ContextModel):
    """Test customer model."""

    __redis_key_template__ = "customer:{id}"
    id: int = ContextField(description="ID", is_key_component=True)
    email: str = ContextField(description="Email")


class TestProduct(ContextModel):
    """Test product model."""

    __redis_key_template__ = "product:{id}"
    id: int = ContextField(description="ID", is_key_component=True)
    name: str = ContextField(description="Name")


@pytest.fixture
def unified_client():
    """Create a unified client for testing."""
    return UnifiedClient(
        api_url="http://localhost:8080",
        mcp_url="http://localhost:8081",
    )


class TestUnifiedClientInit:
    """Test unified client initialization."""

    def test_init_with_defaults(self):
        """Test initialization with default values."""
        with patch.dict(os.environ, {}, clear=False):
            for var in ["CTX_API_URL", "CTX_MCP_URL"]:
                if var in os.environ:
                    del os.environ[var]
            client = UnifiedClient()
            assert client.api_url == "https://cloud.redis.io/context-surfaces/"
            assert client.mcp_url == "https://gcp-us-east4.context-surfaces.redis.io/mcp"
            assert client.timeout == 30.0

    def test_init_with_custom_urls(self):
        """Test initialization with custom URLs."""
        client = UnifiedClient(
            api_url="https://api.example.com",
            mcp_url="https://mcp.example.com",
        )
        assert client.api_url == "https://api.example.com"
        assert client.mcp_url == "https://mcp.example.com"

    def test_init_uses_ctx_env_vars(self):
        """Test initialization from CTX_* env vars when URL args are omitted."""
        with patch.dict(
            "os.environ",
            {
                "CTX_API_URL": "https://api-env.example.com",
                "CTX_MCP_URL": "https://mcp-env.example.com/mcp",
            },
        ):
            client = UnifiedClient()
            assert client.api_url == "https://api-env.example.com"
            assert client.mcp_url == "https://mcp-env.example.com/mcp"


class TestUnifiedClientAdminOperations:
    """Test admin operations through unified client."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_admin_key(self, unified_client):
        """Test creating admin key through unified client."""
        mock_response = {
            "id": "key_123",
            "name": "test-admin",
            "owner": "test-owner",
            "key": "cs_admin_newkey123",
            "key_type": "admin",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.post("http://localhost:8080/api/v1/keys").mock(
            return_value=Response(201, json=mock_response)
        )

        async with unified_client:
            result = await unified_client.create_admin_key("test-admin", "test-owner")
            assert result.name == "test-admin"
            assert result.key == "cs_admin_newkey123"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_context_surface(self, unified_client):
        """Test creating context surface through unified client."""
        admin_key = "cs_admin_test123"

        mock_response = {
            "id": "surface_123",
            "name": "test-surface",
            "description": "Test surface",
            "owner": "test-owner",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.post("http://localhost:8080/api/v1/context-surfaces").mock(
            return_value=Response(201, json=mock_response)
        )

        async with unified_client:
            result = await unified_client.create_context_surface(
                admin_key, "test-surface", description="Test surface"
            )
            assert result.name == "test-surface"


class TestUnifiedClientMCPOperations:
    """Test MCP operations through unified client."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_tools(self, unified_client):
        """Test listing tools through unified client."""
        agent_key = "cs_agent_test456"

        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "tools": [
                    {
                        "name": "search_user_by_text",
                        "description": "Search users",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"query": {"type": "string"}},
                            "required": ["query"],
                        },
                    },
                ],
            },
        }

        respx.post("http://localhost:8081").mock(return_value=Response(200, json=mock_response))

        async with unified_client:
            tools = await unified_client.list_tools(agent_key)
            assert len(tools) == 1
            assert tools[0]["name"] == "search_user_by_text"

    @pytest.mark.asyncio
    @respx.mock
    async def test_query_tool(self, unified_client):
        """Test calling tool through unified client."""
        agent_key = "cs_agent_test456"

        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {"type": "text", "text": '{"users": []}'},
                ],
            },
        }

        respx.post("http://localhost:8081").mock(return_value=Response(200, json=mock_response))

        async with unified_client:
            result = await unified_client.query_tool(
                agent_key, "search_user_by_text", {"query": "test"}
            )
            assert "content" in result


class TestUnifiedClientContextManager:
    """Test unified client as async context manager."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test using unified client as async context manager."""
        async with UnifiedClient(api_url="http://localhost:8080") as client:
            assert client is not None
            assert client.api_url == "http://localhost:8080"


class TestImportData:
    """Test import_data method."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_import_data_success(self, unified_client):
        """Test successful import of ContextModel instances."""
        mock_response = {"imported": 2, "failed": 0, "errors": []}

        respx.post("http://localhost:8080/api/v1/context-surfaces/test-engine/data").mock(
            return_value=Response(200, json=mock_response)
        )

        records = [
            TestCustomer(id=1, email="john@example.com"),
            TestCustomer(id=2, email="jane@example.com"),
        ]

        async with unified_client:
            result = await unified_client.import_data(
                admin_key="test-key",
                context_surface_id="test-engine",
                records=records,
            )

            assert result.imported == 2
            assert result.failed == 0
            assert result.errors == []

    @pytest.mark.asyncio
    @respx.mock
    async def test_import_data_verifies_api_call(self, unified_client):
        """Test that import_data calls API with correct parameters."""
        mock_response = {"imported": 1, "failed": 0, "errors": []}

        route = respx.post("http://localhost:8080/api/v1/context-surfaces/test-engine/data").mock(
            return_value=Response(200, json=mock_response)
        )

        records = [TestCustomer(id=1, email="john@example.com")]

        async with unified_client:
            await unified_client.import_data(
                admin_key="test-key",
                context_surface_id="test-engine",
                records=records,
            )

            # Verify the request was made with correct payload
            assert route.called
            request = route.calls[0].request
            assert request.headers["X-API-Key"] == "test-key"

            import json

            body = json.loads(request.content)
            assert body["entity"] == "TestCustomer"
            assert len(body["records"]) == 1
            assert body["records"][0]["id"] == 1
            assert body["records"][0]["email"] == "john@example.com"

    @pytest.mark.asyncio
    async def test_import_data_empty_records(self, unified_client):
        """Test that empty records raises ValueError."""
        async with unified_client:
            with pytest.raises(ValueError, match="records cannot be empty"):
                await unified_client.import_data(
                    admin_key="test-key",
                    context_surface_id="test-engine",
                    records=[],
                )

    @pytest.mark.asyncio
    async def test_import_data_mixed_types(self, unified_client):
        """Test that mixed record types raises ValueError."""
        records = [
            TestCustomer(id=1, email="john@example.com"),
            TestProduct(id=1, name="Widget"),  # Different type!
        ]

        async with unified_client:
            with pytest.raises(ValueError, match="same ContextModel type"):
                await unified_client.import_data(
                    admin_key="test-key",
                    context_surface_id="test-engine",
                    records=records,
                )

    @pytest.mark.asyncio
    @respx.mock
    async def test_import_data_with_options(self, unified_client):
        """Test that options are passed to API."""
        mock_response = {"imported": 1, "failed": 0, "errors": []}

        route = respx.post("http://localhost:8080/api/v1/context-surfaces/test-engine/data").mock(
            return_value=Response(200, json=mock_response)
        )

        records = [TestCustomer(id=1, email="john@example.com")]

        async with unified_client:
            await unified_client.import_data(
                admin_key="test-key",
                context_surface_id="test-engine",
                records=records,
                on_conflict="skip",
                on_error="fail_fast",
            )

            import json

            body = json.loads(route.calls[0].request.content)
            assert body["options"]["on_conflict"] == "skip"
            assert body["options"]["on_error"] == "fail_fast"

    @pytest.mark.asyncio
    @respx.mock
    async def test_import_data_partial_success(self, unified_client):
        """Test handling of partial success response."""
        mock_response = {
            "imported": 1,
            "failed": 1,
            "errors": [{"index": 1, "record_id": "2", "error": "validation failed"}],
        }

        respx.post("http://localhost:8080/api/v1/context-surfaces/test-engine/data").mock(
            return_value=Response(200, json=mock_response)
        )

        records = [
            TestCustomer(id=1, email="john@example.com"),
            TestCustomer(id=2, email="invalid"),
        ]

        async with unified_client:
            result = await unified_client.import_data(
                admin_key="test-key",
                context_surface_id="test-engine",
                records=records,
            )

            assert result.imported == 1
            assert result.failed == 1
            assert len(result.errors) == 1
            assert result.errors[0].index == 1
            assert result.errors[0].error == "validation failed"

    @pytest.mark.asyncio
    async def test_import_data_not_initialized(self):
        """Test that import_data raises RuntimeError when client not initialized."""
        client = UnifiedClient()

        with pytest.raises(RuntimeError, match="Client not initialized"):
            await client.import_data(
                admin_key="test-key",
                context_surface_id="test-engine",
                records=[TestCustomer(id=1, email="test@example.com")],
            )
