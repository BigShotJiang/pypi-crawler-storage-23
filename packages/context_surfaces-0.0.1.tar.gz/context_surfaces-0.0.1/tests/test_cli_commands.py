"""Tests for CLI commands using Typer's CliRunner."""

import logging
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from context_surfaces.cli.main import app
from context_surfaces.cli.services.audit_logger import AuditLogger
from context_surfaces.cli.services.credential_manager import CredentialManager


@pytest.fixture(autouse=True)
def disable_logging():
    """Disable logging during tests to avoid file handler issues with CliRunner."""
    # Disable all logging to avoid stderr issues with CliRunner
    logging.disable(logging.CRITICAL)
    yield
    # Re-enable logging after test
    logging.disable(logging.NOTSET)


@pytest.fixture
def runner():
    """Create a CLI runner."""
    return CliRunner()


@pytest.fixture
def temp_config_dir():
    """Create a temporary directory for config."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def mock_audit_logger():
    """Create a mock audit logger that doesn't write to files."""
    mock_logger = MagicMock(spec=AuditLogger)
    mock_logger.log_operation = MagicMock()
    mock_logger.log_auth = MagicMock()
    return mock_logger


class TestVersionCommand:
    """Test version command."""

    def test_version_command(self, runner):
        """Test that version command shows version info."""
        result = runner.invoke(app, ["version"])

        assert result.exit_code == 0
        assert "Context Surfaces CLI" in result.stdout
        from context_surfaces import __version__

        assert __version__ in result.stdout


class TestConfigCommands:
    """Test config commands."""

    def test_config_show_default(self, runner, temp_config_dir):
        """Test showing default configuration."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["config", "show"])

        assert result.exit_code == 0
        # The output is a table with "Api Url" field (note: capitalized in table)
        assert (
            "Api Url" in result.stdout
            or "api_url" in result.stdout
            or "localhost:8080" in result.stdout
        )

    def test_config_list_profiles(self, runner, temp_config_dir):
        """Test listing all profiles."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["config", "list"])

        assert result.exit_code == 0
        # Should show at least the default profile
        assert "development" in result.stdout or "Profiles" in result.stdout

    def test_config_set_value(self, runner, temp_config_dir):
        """Test setting a configuration value."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["config", "set", "api_url", "https://api.example.com"])

        assert result.exit_code == 0
        assert "api_url" in result.stdout or "success" in result.stdout.lower()

    def test_config_with_profile_option(self, runner, temp_config_dir):
        """Test using --profile option."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["--profile", "production", "config", "show"])

        assert result.exit_code == 0

    def test_config_with_output_json(self, runner, temp_config_dir):
        """Test using --output json option."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["--output", "json", "config", "show"])

        assert result.exit_code == 0
        # Should be valid JSON or contain JSON-like output
        assert "{" in result.stdout or "api_url" in result.stdout


class TestAuthCommands:
    """Test auth commands."""

    def test_auth_login_admin_key(self, runner, temp_config_dir, mock_audit_logger, monkeypatch):
        """Test storing an admin API key."""
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_config_dir)
        monkeypatch.setattr(CredentialManager, "CREDENTIALS_FILE", temp_config_dir / "credentials.enc")

        with (
            patch("context_surfaces.cli.main.Path.home") as mock_home,
            patch("context_surfaces.cli.main.AuditLogger") as mock_audit_cls,
            patch("keyring.set_password"),
            patch("keyring.delete_password"),
        ):
            mock_home.return_value = temp_config_dir
            mock_audit_cls.return_value = mock_audit_logger

            result = runner.invoke(
                app,
                ["auth", "login", "test-admin", "--type", "admin"],
                input="cs_admin_test123\n",
                catch_exceptions=False,
            )

        assert result.exit_code == 0
        assert "stored" in result.stdout.lower() or "✓" in result.stdout

    def test_auth_login_agent_key(self, runner, temp_config_dir, mock_audit_logger, monkeypatch):
        """Test storing an agent API key."""
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_config_dir)
        monkeypatch.setattr(CredentialManager, "CREDENTIALS_FILE", temp_config_dir / "credentials.enc")

        with (
            patch("context_surfaces.cli.main.Path.home") as mock_home,
            patch("context_surfaces.cli.main.AuditLogger") as mock_audit_cls,
            patch("keyring.set_password"),
            patch("keyring.delete_password"),
        ):
            mock_home.return_value = temp_config_dir
            mock_audit_cls.return_value = mock_audit_logger

            result = runner.invoke(
                app,
                ["auth", "login", "test-agent", "--type", "agent"],
                input="cs_agent_test456\n",
                catch_exceptions=False,
            )

        assert result.exit_code == 0
        assert "stored" in result.stdout.lower() or "✓" in result.stdout

    def test_auth_list_keys(self, runner, temp_config_dir):
        """Test listing stored API keys."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir

            result = runner.invoke(app, ["auth", "list"])

        assert result.exit_code == 0
        # Should show message about no keys or list keys
        assert "No API keys" in result.stdout or "Name" in result.stdout

    def test_auth_logout(self, runner, temp_config_dir, mock_audit_logger, monkeypatch):
        """Test clearing authentication (keys and session)."""
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_config_dir)
        monkeypatch.setattr(CredentialManager, "CREDENTIALS_FILE", temp_config_dir / "credentials.enc")

        with (
            patch("context_surfaces.cli.main.Path.home") as mock_home,
            patch("context_surfaces.cli.main.AuditLogger") as mock_audit_cls,
            patch("keyring.set_password"),
            patch("keyring.get_password", return_value=None),
            patch("keyring.delete_password"),
        ):
            mock_home.return_value = temp_config_dir
            mock_audit_cls.return_value = mock_audit_logger

            # Use --force to skip confirmation (nothing to clear is OK)
            result = runner.invoke(
                app,
                ["auth", "logout", "--force"],
            )

        # Should show "Nothing to clear" since no credentials stored
        assert result.exit_code == 0
        assert "Nothing to clear" in result.stdout or "Logged out" in result.stdout


class TestGlobalOptions:
    """Test global CLI options."""

    def test_help_option(self, runner):
        """Test --help option."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "Context Surfaces CLI" in result.stdout
        assert "Commands" in result.stdout

    def test_no_color_option(self, runner, temp_config_dir):
        """Test --no-color option."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["--no-color", "version"])

        assert result.exit_code == 0

    def test_debug_option(self, runner, temp_config_dir):
        """Test --debug option."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(app, ["--debug", "version"])

        assert result.exit_code == 0

    def test_invalid_command(self, runner):
        """Test that invalid commands show helpful error."""
        result = runner.invoke(app, ["invalid-command"])

        assert result.exit_code != 0
        # Typer outputs errors to stderr, and the runner combines them
        # Check both stdout and stderr for the error message
        output = result.stdout + (result.stderr or "")
        assert "No such command" in output or "invalid-command" in output or result.exit_code == 2


class TestAgentCommands:
    """Test agent commands."""

    def test_agent_create_access_tags_invalid_json(self, runner, temp_config_dir):
        """Test that invalid JSON for access-tags shows error."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(
                app,
                [
                    "agent",
                    "create",
                    "--engine-id",
                    "ce-123",
                    "--name",
                    "Test Agent",
                    "--access-tags",
                    "not-valid-json",
                ],
            )

        # Should fail with JSON parse error
        assert result.exit_code != 0
        output = result.stdout + (result.stderr or "")
        assert "Invalid JSON" in output or "BadParameter" in output or result.exit_code == 2

    def test_agent_create_access_tags_not_object(self, runner, temp_config_dir):
        """Test that non-object JSON for access-tags shows error."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(
                app,
                [
                    "agent",
                    "create",
                    "--engine-id",
                    "ce-123",
                    "--name",
                    "Test Agent",
                    "--access-tags",
                    '["array", "not", "object"]',
                ],
            )

        # Should fail because access-tags must be an object
        assert result.exit_code != 0
        output = result.stdout + (result.stderr or "")
        assert (
            "must be a JSON object" in output or "BadParameter" in output or result.exit_code == 2
        )

    def test_agent_create_access_tags_non_string_values(self, runner, temp_config_dir):
        """Test that non-string/non-list values in access-tags shows error."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(
                app,
                [
                    "agent",
                    "create",
                    "--engine-id",
                    "ce-123",
                    "--name",
                    "Test Agent",
                    "--access-tags",
                    '{"tenant": 123}',
                ],
            )

        # Should fail because values must be strings or lists of strings
        assert result.exit_code != 0
        output = result.stdout + (result.stderr or "")
        assert "must be strings" in output or "BadParameter" in output or result.exit_code == 2

    def test_agent_create_access_tags_non_string_in_list(self, runner, temp_config_dir):
        """Test that non-string items in access-tags lists shows error."""
        with patch("context_surfaces.cli.main.Path.home") as mock_home:
            mock_home.return_value = temp_config_dir
            result = runner.invoke(
                app,
                [
                    "agent",
                    "create",
                    "--engine-id",
                    "ce-123",
                    "--name",
                    "Test Agent",
                    "--access-tags",
                    '{"tenant": ["acme", 123]}',
                ],
            )

        # Should fail because list items must be strings
        assert result.exit_code != 0
        output = result.stdout + (result.stderr or "")
        assert "must be strings" in output or "BadParameter" in output or result.exit_code == 2


class TestErrorHandling:
    """Test error handling in CLI commands."""

    def test_invalid_profile(self, runner, temp_config_dir):
        """Test using a non-existent profile."""
        config_path = temp_config_dir / "config.yaml"
        result = runner.invoke(
            app,
            ["--profile", "nonexistent", "--config", str(config_path), "config", "show"],
        )
        assert result.exit_code == 1
        assert "Profile 'nonexistent' not found" in result.stdout
        assert "Available profiles:" in result.stdout

    def test_config_show_with_invalid_profile_env(self, runner, temp_config_dir):
        """Test config show with invalid profile from environment."""
        config_path = temp_config_dir / "config.yaml"
        with patch.dict("os.environ", {"CTX_PROFILE": "invalid"}):
            result = runner.invoke(
                app,
                ["--config", str(config_path), "config", "show"],
            )
            assert result.exit_code == 1
            assert "Profile 'invalid' not found" in result.stdout
