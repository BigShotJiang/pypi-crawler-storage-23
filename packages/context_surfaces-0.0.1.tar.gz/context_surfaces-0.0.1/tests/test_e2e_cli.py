"""E2E tests for CLI workflow against QA environment.

This test validates the complete user journey:
1. Configure CLI (login handled by ctxctl_session fixture)
2. Create admin key (via gateway with session auth)
3. Register Redis instance
4. Create surface from Python models file
5. Create agent key
6. List MCP tools
7. Call MCP tool with arguments
"""

import json
import subprocess
from pathlib import Path

import pytest

from .e2e_config import (
    CTX_API_URL,
    CTX_MCP_URL,
    get_redis_config,
)


@pytest.mark.e2e
def test_cli_workflow_from_models_to_mcp_tools(ctxctl_session: None, tmp_path: Path) -> None:
    """Test complete CLI workflow from Python models to calling MCP tools.

    This test runs against the QA environment:
    - Login via SM QA (handled by ctxctl_session fixture)
    - Admin key creation via SM gateway (session auth)
    - All other operations via CCE API (admin key auth)
    """
    redis_addr, _, redis_username, redis_password = get_redis_config()

    admin_key = None
    redis_instance_id = None
    surface_id = None
    agent_key = None

    try:
        # Step 1: Configure CLI to use CCE API URL for admin key operations
        print("\n=== Step 1: Configuring CLI ===")
        result = subprocess.run(
            ["ctxctl", "config", "set", "api_url", CTX_API_URL],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to set api_url: {result.stderr}"

        result = subprocess.run(
            ["ctxctl", "config", "set", "mcp_url", CTX_MCP_URL],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to set mcp_url: {result.stderr}"
        print("✓ CLI configured for QA environment")

        # Step 2: Create admin key (uses session auth via SM gateway)
        print("\n=== Step 2: Creating admin key ===")
        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "admin",
                "create",
                "--name",
                "E2E CLI Admin",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to create admin key: {result.stderr}"
        admin_data = json.loads(result.stdout)
        admin_key = admin_data["key"]
        print(f"✓ Admin key created: {admin_data['id']}")

        # Step 3: Register Redis instance
        print("\n=== Step 3: Registering Redis instance ===")
        redis_create_cmd = [
            "ctxctl",
            "--output",
            "json",
            "redis",
            "create",
            "--name",
            "E2E CLI Redis",
            "--addr",
            redis_addr,
            "--db",
            "0",
            "--tls",  # Redis Cloud uses TLS
            "--admin-key",
            admin_key,
        ]
        if redis_username:
            redis_create_cmd.extend(["--username", redis_username])
        if redis_password:
            redis_create_cmd.extend(["--password", redis_password])

        result = subprocess.run(
            redis_create_cmd,
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to register Redis: {result.stderr}"
        redis_data = json.loads(result.stdout)
        redis_instance_id = redis_data["id"]
        print(f"✓ Redis instance registered: {redis_instance_id}")

        # Step 4: Create surface from Python models file
        print("\n=== Step 4: Creating surface from Python models ===")
        # Path is relative to the repository root (where the test is run from)
        models_file = Path("src/context_surfaces/examples/reddish_models.py")
        if not models_file.exists():
            # Try from python-client directory
            models_file = Path("../src/context_surfaces/examples/reddish_models.py")
        assert models_file.exists(), f"Models file not found: {models_file}"

        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "surface",
                "create",
                "--name",
                "E2E Reddish Surface",
                "--description",
                "Context surface for E2E testing",
                "--models",
                str(models_file),
                "--redis-instance-id",
                redis_instance_id,
                "--admin-key",
                admin_key,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to create surface: {result.stderr}"
        surface_data = json.loads(result.stdout)
        surface_id = surface_data["id"]
        tools = surface_data["tools"]
        print(f"✓ Context surface created: {surface_id}")
        print(f"✓ Auto-generated {len(tools)} tools")

        # Verify expected tools were generated
        expected_tools = [
            "get_customer_by_id",
            "search_customer_by_text",
            "filter_customer_by_account_status",
            "get_order_by_id",
            "filter_order_by_customer_id",
        ]
        for tool in expected_tools:
            assert tool in tools, f"Expected tool '{tool}' not found in {tools}"

        # Step 5: Create agent key
        print("\n=== Step 5: Creating agent key ===")
        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "agent",
                "create",
                "--surface-id",
                surface_id,
                "--name",
                "E2E Agent",
                "--admin-key",
                admin_key,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to create agent key: {result.stderr}"
        agent_data = json.loads(result.stdout)
        agent_key = agent_data["key"]
        print(f"✓ Agent key created: {agent_data['id']}")

        # Step 6: List MCP tools
        print("\n=== Step 6: Listing MCP tools ===")
        result = subprocess.run(
            ["ctxctl", "--output", "json", "tools", "list", "--agent-key", agent_key],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to list tools: {result.stderr}"
        tools_list = json.loads(result.stdout)
        assert len(tools_list) > 0, "No tools returned"
        print(f"✓ Listed {len(tools_list)} MCP tools")

        # Step 7a: Call an MCP tool with --args-file
        print("\n=== Step 7a: Calling MCP tool with --args-file ===")
        args_file = tmp_path / "search_args.json"
        args_file.write_text(json.dumps({"query": "john", "limit": 10}))

        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "tools",
                "call",
                "search_customer_by_text",
                "--agent-key",
                agent_key,
                "--args-file",
                str(args_file),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to call tool with --args-file: {result.stderr}"
        tool_result = json.loads(result.stdout)
        print(f"✓ Tool called successfully with --args-file: {len(tool_result)} results")

        # Step 7b: Call an MCP tool with --args JSON string
        print("\n=== Step 7b: Calling MCP tool with --args JSON ===")
        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "tools",
                "call",
                "search_customer_by_text",
                "--agent-key",
                agent_key,
                "--args",
                '{"query": "john", "limit": 5}',
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to call tool with --args: {result.stderr}"
        tool_result = json.loads(result.stdout)
        print(f"✓ Tool called successfully with --args: {len(tool_result)} results")

        # Step 7c: Call an MCP tool with direct CLI arguments
        print("\n=== Step 7c: Calling MCP tool with direct CLI arguments ===")
        result = subprocess.run(
            [
                "ctxctl",
                "--output",
                "json",
                "tools",
                "call",
                "search_customer_by_text",
                "--agent-key",
                agent_key,
                "--query",
                "john",
                "--limit",
                "3",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        assert result.returncode == 0, f"Failed to call tool with direct args: {result.stderr}"
        tool_result = json.loads(result.stdout)
        print(f"✓ Tool called successfully with direct CLI args: {len(tool_result)} results")

    finally:
        print("\n=== Cleanup ===")
        if surface_id and admin_key:
            subprocess.run(
                ["ctxctl", "surface", "delete", surface_id, "--admin-key", admin_key, "--confirm"],
                check=False,
            )
        if redis_instance_id and admin_key:
            subprocess.run(
                [
                    "ctxctl",
                    "redis",
                    "delete",
                    redis_instance_id,
                    "--admin-key",
                    admin_key,
                    "--confirm",
                ],
                check=False,
            )
        print("✓ Cleanup complete")
