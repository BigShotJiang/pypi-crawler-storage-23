"""Unit tests for CLI argument parsing."""

from context_surfaces.cli.main import _extract_output_format_from_args, _parse_extra_cli_arguments
from context_surfaces.cli.services import OutputFormat


def test_parse_extra_cli_arguments_simple() -> None:
    """Test parsing simple string arguments."""
    args = ["--query", "john", "--name", "doe"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"query": "john", "name": "doe"}


def test_parse_extra_cli_arguments_numbers() -> None:
    """Test parsing numeric arguments."""
    args = ["--limit", "10", "--offset", "5"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"limit": 10, "offset": 5}


def test_parse_extra_cli_arguments_booleans() -> None:
    """Test parsing boolean arguments."""
    args = ["--active", "true", "--deleted", "false"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"active": True, "deleted": False}


def test_parse_extra_cli_arguments_flags() -> None:
    """Test parsing flag arguments (no value)."""
    # Note: --debug is a global CLI option and gets filtered out
    args = ["--verbose", "--dry-run"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"verbose": True, "dry-run": True}


def test_parse_extra_cli_arguments_mixed() -> None:
    """Test parsing mixed argument types."""
    args = ["--query", "john", "--limit", "10", "--active", "true", "--verbose"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"query": "john", "limit": 10, "active": True, "verbose": True}


def test_parse_extra_cli_arguments_json_array() -> None:
    """Test parsing JSON array arguments."""
    args = ["--ids", '["1", "2", "3"]']
    result = _parse_extra_cli_arguments(args)
    assert result == {"ids": ["1", "2", "3"]}


def test_parse_extra_cli_arguments_json_object() -> None:
    """Test parsing JSON object arguments."""
    args = ["--filter", '{"status": "active", "limit": 10}']
    result = _parse_extra_cli_arguments(args)
    assert result == {"filter": {"status": "active", "limit": 10}}


def test_parse_extra_cli_arguments_empty() -> None:
    """Test parsing empty arguments."""
    args: list[str] = []
    result = _parse_extra_cli_arguments(args)
    assert result == {}


def test_parse_extra_cli_arguments_float() -> None:
    """Test parsing float arguments."""
    args = ["--price", "19.99", "--discount", "0.15"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"price": 19.99, "discount": 0.15}


def test_parse_extra_cli_arguments_null() -> None:
    """Test parsing null arguments."""
    args = ["--value", "null"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"value": None}


def test_parse_extra_cli_arguments_filters_global_options() -> None:
    """Test that global CLI options are filtered out and not passed to tools."""
    # Global options like --output, --profile, --debug should be filtered
    args = ["--query", "test", "--output", "json", "--limit", "10", "--profile", "prod", "--debug"]
    result = _parse_extra_cli_arguments(args)
    # Only tool-specific options should be in the result
    assert result == {"query": "test", "limit": 10}
    # Global options should NOT be present
    assert "output" not in result
    assert "profile" not in result
    assert "debug" not in result


def test_parse_extra_cli_arguments_filters_short_global_options() -> None:
    """Test that short form global CLI options are also filtered out."""
    args = ["--query", "test", "-o", "json", "--limit", "10", "-p", "prod"]
    result = _parse_extra_cli_arguments(args)
    assert result == {"query": "test", "limit": 10}
    assert "o" not in result
    assert "p" not in result


def test_extract_output_format_json() -> None:
    """Test extracting --output json from args."""
    args = ["--query", "test", "--output", "json"]
    result = _extract_output_format_from_args(args)
    assert result == OutputFormat.JSON


def test_extract_output_format_yaml() -> None:
    """Test extracting --output yaml from args."""
    args = ["--output", "yaml", "--limit", "10"]
    result = _extract_output_format_from_args(args)
    assert result == OutputFormat.YAML


def test_extract_output_format_table() -> None:
    """Test extracting --output table from args."""
    args = ["--output", "table"]
    result = _extract_output_format_from_args(args)
    assert result == OutputFormat.TABLE


def test_extract_output_format_short_option() -> None:
    """Test extracting -o json from args."""
    args = ["--query", "test", "-o", "json"]
    result = _extract_output_format_from_args(args)
    assert result == OutputFormat.JSON


def test_extract_output_format_not_present() -> None:
    """Test when --output is not in args."""
    args = ["--query", "test", "--limit", "10"]
    result = _extract_output_format_from_args(args)
    assert result is None


def test_extract_output_format_case_insensitive() -> None:
    """Test that output format extraction is case insensitive."""
    args = ["--output", "JSON"]
    result = _extract_output_format_from_args(args)
    assert result == OutputFormat.JSON
