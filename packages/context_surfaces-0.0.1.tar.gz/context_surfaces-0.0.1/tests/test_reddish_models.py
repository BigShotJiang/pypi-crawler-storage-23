"""Tests for Reddish example models."""

import json
from pathlib import Path

from context_surfaces.context_model import export_data_model
from context_surfaces.examples.reddish_models import (
    Customer,
    Order,
    Policy,
    Restaurant,
)


class TestReddishModels:
    """Test Reddish example models."""

    def test_customer_model_structure(self):
        """Test Customer model has correct fields."""
        fields = Customer.get_index_fields()
        field_names = {f["name"] for f in fields}

        assert "id" in field_names
        assert "tenant_id" in field_names
        assert "email" in field_names
        assert "phone" in field_names
        assert "account_status" in field_names
        assert "customer_tier" in field_names
        assert "city" in field_names
        assert "lifetime_value" in field_names

    def test_customer_relationships(self):
        """Test Customer has correct relationships."""
        relationships = Customer.get_relationships()
        assert len(relationships) == 1
        assert relationships[0]["name"] == "orders"
        # Note: Type annotation is Any to satisfy mypy, but the relationship still works
        assert relationships[0]["target"] == "Any"

    def test_order_model_structure(self):
        """Test Order model has correct fields."""
        fields = Order.get_index_fields()
        field_names = {f["name"] for f in fields}

        assert "id" in field_names
        assert "tenant_id" in field_names
        assert "customer_id" in field_names
        assert "restaurant_id" in field_names
        assert "status" in field_names
        assert "order_total" in field_names
        assert "special_instructions" in field_names

    def test_order_relationships(self):
        """Test Order has correct relationships."""
        relationships = Order.get_relationships()
        assert len(relationships) == 2

        rel_names = {r["name"] for r in relationships}
        assert "customer" in rel_names
        assert "restaurant" in rel_names

    def test_restaurant_model_structure(self):
        """Test Restaurant model has correct fields."""
        fields = Restaurant.get_index_fields()
        field_names = {f["name"] for f in fields}

        assert "id" in field_names
        assert "name" in field_names
        assert "cuisine_type" in field_names
        assert "rating" in field_names
        assert "status" in field_names

    def test_policy_model_structure(self):
        """Test Policy model has correct fields."""
        fields = Policy.get_index_fields()
        field_names = {f["name"] for f in fields}

        assert "id" in field_names
        assert "category" in field_names
        assert "priority" in field_names
        assert "content_embedding" in field_names
        assert "title" in field_names

    def test_policy_vector_index(self):
        """Test Policy has vector index configured correctly."""
        fields = Policy.get_index_fields()
        embedding_field = next(f for f in fields if f["name"] == "content_embedding")

        assert len(embedding_field["redis_indices"]) == 1
        vector_idx = embedding_field["redis_indices"][0]
        assert vector_idx["type"] == "vector"
        assert vector_idx["vector_dim"] == 1536
        assert vector_idx["distance_metric"] == "cosine"

    def test_export_matches_example_datamodel(self):
        """Test that exported data model matches example_datamodel.json structure."""
        # Export the data model
        data_model = export_data_model(
            title="Reddish Support Agent API",
            description="Comprehensive Reddish support system with vector-indexed policies and intelligent assistance",
            entities=[Customer, Order, Restaurant, Policy],
        )

        # Load the example data model
        example_path = Path(__file__).parent.parent.parent / "example_datamodel.json"
        with open(example_path) as f:
            expected = json.load(f)

        # Compare top-level structure
        assert data_model["title"] == expected["title"]
        assert data_model["description"] == expected["description"]
        assert data_model["entity_count"] == expected["entity_count"]
        assert len(data_model["entities"]) == len(expected["entities"])

        # Compare each entity
        for expected_entity in expected["entities"]:
            # Find matching entity in exported data
            exported_entity = next(
                e for e in data_model["entities"] if e["name"] == expected_entity["name"]
            )

            # Compare entity metadata
            assert exported_entity["description"] == expected_entity["description"]
            assert exported_entity["redis_key_template"] == expected_entity["redis_key_template"]

            # Compare fields
            assert len(exported_entity["fields"]) == len(expected_entity["fields"])
            for expected_field in expected_entity["fields"]:
                exported_field = next(
                    f for f in exported_entity["fields"] if f["name"] == expected_field["name"]
                )

                assert exported_field["type"] == expected_field["type"]
                assert exported_field["description"] == expected_field["description"]
                assert exported_field["is_key_component"] == expected_field["is_key_component"]
                assert exported_field["redis_indices"] == expected_field["redis_indices"]

            # Compare relationships
            assert len(exported_entity["relationships"]) == len(expected_entity["relationships"])
            for expected_rel in expected_entity["relationships"]:
                exported_rel = next(
                    r for r in exported_entity["relationships"] if r["name"] == expected_rel["name"]
                )

                assert exported_rel["target"] == expected_rel["target"]
                assert exported_rel["description"] == expected_rel["description"]
                assert exported_rel["source_field"] == expected_rel["source_field"]
