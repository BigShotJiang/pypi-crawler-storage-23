"""Tests for CLI configuration manager."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from context_surfaces.cli.services.config_manager import (
    ConfigManager,
    LogLevel,
    OutputFormat,
    ProfileConfig,
)


@pytest.fixture
def temp_config_dir():
    """Create a temporary directory for config."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def config_manager(temp_config_dir):
    """Create a config manager with temporary directory."""
    config_path = temp_config_dir / "config.yaml"
    return ConfigManager(config_path=config_path)


class TestProfileConfig:
    """Test ProfileConfig model."""

    def test_default_values(self):
        """Test that ProfileConfig has correct defaults."""
        config = ProfileConfig()
        assert config.api_url == "https://cloud.redis.io/context-surfaces"
        assert config.mcp_url == "https://gcp-us-east4.context-surfaces.redis.io/mcp"
        assert config.redis_cloud_url == "https://cloud.redis.io/"
        assert config.default_output_format == OutputFormat.TABLE
        assert config.color_output is True
        assert config.log_level == LogLevel.INFO
        assert config.timeout == 30

    def test_custom_values(self):
        """Test creating ProfileConfig with custom values."""
        config = ProfileConfig(
            api_url="https://api.example.com",
            mcp_url="https://api.example.com/mcp",
            default_output_format=OutputFormat.JSON,
            color_output=False,
            log_level=LogLevel.DEBUG,
            timeout=60,
        )
        assert config.api_url == "https://api.example.com"
        assert config.mcp_url == "https://api.example.com/mcp"
        assert config.default_output_format == OutputFormat.JSON
        assert config.color_output is False
        assert config.log_level == LogLevel.DEBUG
        assert config.timeout == 60

    def test_timeout_validation(self):
        """Test that timeout is validated."""
        # Valid timeout
        config = ProfileConfig(timeout=30)
        assert config.timeout == 30

        # Invalid timeout (too low)
        with pytest.raises(ValueError):
            ProfileConfig(timeout=0)

        # Invalid timeout (too high)
        with pytest.raises(ValueError):
            ProfileConfig(timeout=400)


class TestConfigManager:
    """Test ConfigManager functionality."""

    def test_init_creates_directory(self, temp_config_dir):
        """Test that initialization creates the config directory."""
        config_dir = temp_config_dir / "subdir"
        assert not config_dir.exists()

        config_path = config_dir / "config.yaml"
        manager = ConfigManager(config_path=config_path)
        # Directory is created when saving config
        manager.save_config(manager.load_config())

        assert config_dir.exists()

    def test_default_profile(self, config_manager):
        """Test that default profile is 'development'."""
        config = config_manager.load_config()
        assert config.default_profile == "development"

    def test_get_default_values(self, config_manager):
        """Test getting default configuration values."""
        assert config_manager.get("api_url") == "https://cloud.redis.io/context-surfaces"
        assert config_manager.get("mcp_url") == "https://gcp-us-east4.context-surfaces.redis.io/mcp"
        assert config_manager.get("default_output_format") == OutputFormat.TABLE
        assert config_manager.get("color_output") is True
        assert config_manager.get("log_level") == LogLevel.INFO
        assert config_manager.get("timeout") == 30

    def test_set_and_get_value(self, config_manager):
        """Test setting and getting configuration values."""
        config_manager.set("api_url", "https://api.example.com")
        assert config_manager.get("api_url") == "https://api.example.com"

    def test_set_saves_to_file(self, config_manager):
        """Test that set() saves configuration to file."""
        config_manager.set("api_url", "https://api.example.com")

        # Read the file directly
        config_file = config_manager.config_path
        assert config_file.exists()

        with open(config_file) as f:
            data = yaml.safe_load(f)

        assert data["profiles"]["development"]["api_url"] == "https://api.example.com"

    def test_list_profiles(self, config_manager):
        """Test listing all profiles."""
        # Set values in different profiles
        config_manager.set("api_url", "https://dev.example.com", profile="development")
        config_manager.set("api_url", "https://staging.example.com", profile="staging")
        config_manager.set("api_url", "https://prod.example.com", profile="production")

        profiles = config_manager.list_profiles()

        assert "development" in profiles
        assert "staging" in profiles
        assert "production" in profiles

        # Verify the values were set correctly
        assert config_manager.get("api_url", profile="development") == "https://dev.example.com"
        assert config_manager.get("api_url", profile="staging") == "https://staging.example.com"
        assert config_manager.get("api_url", profile="production") == "https://prod.example.com"

    def test_get_with_cli_override(self, config_manager):
        """Test that CLI value overrides config value."""
        config_manager.set("api_url", "https://config.example.com")

        # CLI value should override
        value = config_manager.get("api_url", cli_value="https://cli.example.com")
        assert value == "https://cli.example.com"

    def test_get_with_env_var(self, config_manager):
        """Test that environment variable overrides config value."""
        config_manager.set("api_url", "https://config.example.com")

        with patch.dict("os.environ", {"CTX_API_URL": "https://env.example.com"}):
            value = config_manager.get("api_url")
            assert value == "https://env.example.com"

    def test_get_hierarchy_cli_over_env(self, config_manager):
        """Test that CLI value overrides environment variable."""
        with patch.dict("os.environ", {"CTX_API_URL": "https://env.example.com"}):
            value = config_manager.get("api_url", cli_value="https://cli.example.com")
            assert value == "https://cli.example.com"

    def test_get_nonexistent_key_raises_error(self, config_manager):
        """Test that getting a non-existent key raises ValueError."""
        with pytest.raises(ValueError, match="Invalid config key"):
            config_manager.get("nonexistent_key")

    def test_switch_profile(self, config_manager):
        """Test switching between profiles."""
        config_manager.set("api_url", "https://dev.example.com", profile="development")
        config_manager.set("api_url", "https://prod.example.com", profile="production")

        # Default is development
        assert config_manager.get("api_url") == "https://dev.example.com"

        # Get from production profile explicitly
        assert config_manager.get("api_url", profile="production") == "https://prod.example.com"

        # Change default profile
        config_manager._config.default_profile = "production"
        assert config_manager.get("api_url") == "https://prod.example.com"

    def test_config_file_permissions(self, config_manager):
        """Test that config file has appropriate permissions."""
        config_manager.set("api_url", "https://api.example.com")

        config_file = config_manager.config_path
        assert config_file.exists()
        # Config file should be readable by owner (not as strict as credentials)
        assert config_file.stat().st_mode & 0o400 == 0o400


class TestConfigManagerProfileManagement:
    """Test profile management functionality."""

    def test_create_profile_with_defaults(self, config_manager):
        """Test creating a new profile with default values."""
        config_manager.create_profile("custom")

        # Verify profile was created
        profiles = config_manager.list_profiles()
        assert "custom" in profiles

        # Verify it has default values
        assert (
            config_manager.get("api_url", profile="custom")
            == "https://cloud.redis.io/context-surfaces"
        )
        assert config_manager.get("timeout", profile="custom") == 30

    def test_create_profile_from_base(self, config_manager):
        """Test creating a profile based on another profile."""
        # Modify production profile
        config_manager.set("api_url", "https://prod.example.com", profile="production")
        config_manager.set("timeout", 60, profile="production")

        # Create new profile based on production
        config_manager.create_profile("qa", base_profile="production")

        # Verify it copied the values
        assert config_manager.get("api_url", profile="qa") == "https://prod.example.com"
        assert config_manager.get("timeout", profile="qa") == 60

    def test_create_profile_already_exists(self, config_manager):
        """Test that creating an existing profile raises error."""
        with pytest.raises(ValueError, match="already exists"):
            config_manager.create_profile("development")

    def test_create_profile_invalid_base(self, config_manager):
        """Test that creating profile with invalid base raises error."""
        with pytest.raises(ValueError, match=r"Base profile .* not found"):
            config_manager.create_profile("custom", base_profile="nonexistent")

    def test_delete_profile(self, config_manager):
        """Test deleting a profile."""
        # Create a profile
        config_manager.create_profile("temporary")
        assert "temporary" in config_manager.list_profiles()

        # Delete it
        config_manager.delete_profile("temporary")
        assert "temporary" not in config_manager.list_profiles()

    def test_delete_nonexistent_profile(self, config_manager):
        """Test that deleting nonexistent profile raises error."""
        with pytest.raises(ValueError, match="not found"):
            config_manager.delete_profile("nonexistent")

    def test_delete_default_profile(self, config_manager):
        """Test that deleting default profile raises error."""
        config = config_manager.load_config()
        default_profile = config.default_profile

        with pytest.raises(ValueError, match="Cannot delete default profile"):
            config_manager.delete_profile(default_profile)

    def test_get_profile_config(self, config_manager):
        """Test getting complete profile configuration."""
        profile_config = config_manager.get_profile_config("development")

        assert profile_config.api_url == "https://cloud.redis.io/context-surfaces"
        assert profile_config.timeout == 30
        assert profile_config.log_level == LogLevel.INFO

    def test_get_profile_config_nonexistent(self, config_manager):
        """Test that getting nonexistent profile raises error."""
        with pytest.raises(ValueError, match="not found"):
            config_manager.get_profile_config("nonexistent")


class TestConfigManagerValidation:
    """Test configuration validation."""

    def test_validate_valid_config(self, config_manager):
        """Test that valid config passes validation."""
        assert config_manager.validate() is True

    def test_validate_invalid_default_profile(self, config_manager):
        """Test that invalid default_profile fails validation."""
        config = config_manager.load_config()
        config.default_profile = "nonexistent"
        config_manager._config = config

        with pytest.raises(ValueError, match=r"Default profile .* not found"):
            config_manager.validate()

    def test_url_validation_on_profile_creation(self):
        """Test URL validation when creating ProfileConfig."""
        # Valid URLs
        ProfileConfig(api_url="http://localhost:8080")
        ProfileConfig(api_url="https://api.example.com")

        # Invalid URL - no protocol
        with pytest.raises(ValueError, match="must start with http"):
            ProfileConfig(api_url="api.example.com")

        # Invalid URL - empty
        with pytest.raises(ValueError, match="cannot be empty"):
            ProfileConfig(api_url="")


class TestConfigManagerReset:
    """Test configuration reset functionality."""

    def test_reset_specific_profile(self, config_manager):
        """Test resetting a specific profile to defaults."""
        # Modify development profile
        config_manager.set("api_url", "https://custom.example.com", profile="development")
        config_manager.set("timeout", 120, profile="development")

        # Reset it
        config_manager.reset(profile="development")

        # Verify it's back to defaults
        assert (
            config_manager.get("api_url", profile="development")
            == "https://cloud.redis.io/context-surfaces"
        )
        assert config_manager.get("timeout", profile="development") == 30

    def test_reset_entire_config(self, config_manager):
        """Test resetting entire configuration."""
        # Modify multiple profiles
        config_manager.set("api_url", "https://dev.example.com", profile="development")
        config_manager.set("api_url", "https://prod.example.com", profile="production")

        # Reset everything
        config_manager.reset()

        # Verify all back to defaults
        assert (
            config_manager.get("api_url", profile="development")
            == "https://cloud.redis.io/context-surfaces"
        )
        # Production has custom defaults
        assert (
            config_manager.get("api_url", profile="production")
            == "https://context-surfaces.example.com"
        )

    def test_reset_nonexistent_profile(self, config_manager):
        """Test that resetting nonexistent profile raises error."""
        with pytest.raises(ValueError, match="not found"):
            config_manager.reset(profile="nonexistent")


class TestConfigManagerFileHandling:
    """Test configuration file loading and error handling."""

    def test_load_empty_file(self, temp_config_dir):
        """Test loading an empty config file."""
        config_path = temp_config_dir / "config.yaml"
        config_path.write_text("")

        manager = ConfigManager(config_path=config_path)
        config = manager.load_config()

        # Should use defaults
        assert config.default_profile == "development"
        assert "development" in config.profiles

    def test_load_invalid_yaml(self, temp_config_dir):
        """Test loading invalid YAML raises error."""
        config_path = temp_config_dir / "config.yaml"
        config_path.write_text("invalid: yaml: content: [")

        manager = ConfigManager(config_path=config_path)

        with pytest.raises(ValueError, match="Invalid YAML"):
            manager.load_config()

    def test_load_invalid_config_structure(self, temp_config_dir):
        """Test loading config with invalid structure."""
        config_path = temp_config_dir / "config.yaml"
        # Invalid timeout value
        config_path.write_text("""
default_profile: development
profiles:
  development:
    api_url: https://cloud.redis.io/context-surfaces
    timeout: 500
""")

        manager = ConfigManager(config_path=config_path)

        with pytest.raises(ValueError, match="Failed to load config"):
            manager.load_config()

    def test_save_without_config(self, config_manager):
        """Test that saving without loading raises error."""
        manager = ConfigManager(config_path=config_manager.config_path)
        # Don't load config

        with pytest.raises(ValueError, match="No config to save"):
            manager.save_config()
