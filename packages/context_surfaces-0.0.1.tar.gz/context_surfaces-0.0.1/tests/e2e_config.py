"""Shared configuration and helpers for E2E tests."""

import os
from typing import NoReturn

import pytest

_IN_CI = os.getenv("CI", "").lower() in ("true", "1", "yes")

# =============================================================================
# Environment URLs (shared across E2E tests, aligned with Go E2E tests and CI)
# =============================================================================

SM_QA_URL = os.getenv("SM_URL", "https://app-sm.k8s-mw.sm-qa.qa.redislabs.com")
CTX_API_URL = os.getenv("BASE_URL", "")
SM_GATEWAY_URL = f"{SM_QA_URL}/context-surfaces"
CTX_MCP_URL = os.getenv("MCP_URL", f"{CTX_API_URL}/mcp")


def skip_or_fail(msg: str) -> NoReturn:
    """Skip the test locally, fail in CI so missing config is never silent."""
    if _IN_CI:
        pytest.fail(msg)
    else:
        pytest.skip(msg)


# =============================================================================
# E2E credentials
# =============================================================================


def get_e2e_credentials() -> tuple[str, str]:
    """Get SM QA credentials from environment variables."""
    username = os.getenv("SM_EMAIL")
    password = os.getenv("SM_PASSWORD")

    if not username or not password:
        skip_or_fail(
            "SM_EMAIL and SM_PASSWORD environment variables required. "
            "Set these to your SM QA credentials to run E2E tests."
        )

    return username, password


# =============================================================================
# Data Redis (redis-data) configuration for E2E tests
# =============================================================================


def get_redis_config() -> tuple[str, str, str, str]:
    """Get Redis data configuration from environment variables.

    Returns:
        Tuple of (server_addr, client_addr, username, password):
        - server_addr: Address for CCE server to connect (may be Docker network address)
        - client_addr: Address for test client to connect (host-accessible address)
        - username: Redis ACL username (empty string if not set)
        - password: Redis password
    """
    addr = os.getenv("REDIS_DATA_ADDR")
    username = os.getenv("REDIS_DATA_USERNAME", "")
    password = os.getenv("REDIS_DATA_PASSWORD", "")

    if not addr:
        skip_or_fail(
            "REDIS_DATA_ADDR environment variable required. "
            "Set this to a Redis Cloud instance address (host:port) to run E2E tests."
        )

    client_addr = os.getenv("REDIS_DATA_TEST_CLIENT_ADDR", addr)

    return addr, client_addr, username, password
