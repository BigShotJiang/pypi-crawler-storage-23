"""Tests for MCP client."""

import os
from unittest.mock import patch

import pytest
import respx
from httpx import Response

from context_surfaces.exceptions import MCPError
from context_surfaces.mcp_client import MCPClient


@pytest.fixture
def mcp_client():
    """Create an MCP client for testing."""
    return MCPClient(
        mcp_url="http://localhost:8081/mcp",
        agent_key="cs_agent_test123",
    )


class TestMCPClientInit:
    """Test MCP client initialization."""

    def test_init_with_defaults(self):
        """Test initialization with default values."""
        with patch.dict(os.environ, {}, clear=False):
            if "CTX_MCP_URL" in os.environ:
                del os.environ["CTX_MCP_URL"]
            client = MCPClient(agent_key="cs_agent_test123")
            assert client.mcp_url == "https://gcp-us-east4.context-surfaces.redis.io/mcp"
            assert client.agent_key == "cs_agent_test123"
            assert client.timeout == 30.0

    def test_init_uses_ctx_mcp_url_env_var(self):
        """Test initialization from CTX_MCP_URL when URL argument is omitted."""
        with patch.dict("os.environ", {"CTX_MCP_URL": "https://mcp-env.example.com/mcp"}):
            client = MCPClient(agent_key="cs_agent_test123")
            assert client.mcp_url == "https://mcp-env.example.com/mcp"

    def test_init_with_custom_values(self):
        """Test initialization with custom values."""
        client = MCPClient(
            mcp_url="https://api.example.com/mcp",
            agent_key="cs_agent_custom",
            timeout=60,
        )
        assert client.mcp_url == "https://api.example.com/mcp"
        assert client.agent_key == "cs_agent_custom"
        assert client.timeout == 60


class TestMCPClientListTools:
    """Test listing MCP tools."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_tools_success(self, mcp_client):
        """Test successful tool listing."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "tools": [
                    {
                        "name": "search_user_by_text",
                        "description": "Search users by text",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "query": {"type": "string"},
                            },
                            "required": ["query"],
                        },
                    },
                    {
                        "name": "get_user_by_id",
                        "description": "Get user by ID",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "integer"},
                            },
                            "required": ["id"],
                        },
                    },
                ],
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        tools = await mcp_client.list_tools()

        assert len(tools) == 2
        assert tools[0]["name"] == "search_user_by_text"
        assert tools[1]["name"] == "get_user_by_id"

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_tools_error_response(self, mcp_client):
        """Test handling of error response when listing tools."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32600,
                "message": "Invalid request",
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        with pytest.raises(MCPError, match="MCP error"):
            await mcp_client.list_tools()

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_tools_http_error(self, mcp_client):
        """Test handling of HTTP error when listing tools."""
        respx.post("http://localhost:8081/mcp").mock(
            return_value=Response(500, text="Internal Server Error")
        )

        await mcp_client.connect()
        with pytest.raises(MCPError):
            await mcp_client.list_tools()


class TestMCPClientCallTool:
    """Test calling MCP tools."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_call_tool_success(self, mcp_client):
        """Test successful tool call."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": '{"users": [{"id": 1, "name": "Alice"}]}',
                    }
                ],
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        result = await mcp_client.call_tool(
            "search_user_by_text",
            {"query": "Alice"},
        )

        assert "content" in result
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"

    @pytest.mark.asyncio
    @respx.mock
    async def test_call_tool_with_empty_arguments(self, mcp_client):
        """Test calling tool with empty arguments."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [{"type": "text", "text": "{}"}],
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        result = await mcp_client.call_tool("list_all_users", {})

        assert "content" in result

    @pytest.mark.asyncio
    @respx.mock
    async def test_call_tool_error_response(self, mcp_client):
        """Test handling of error response when calling tool."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32602,
                "message": "Invalid params",
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        with pytest.raises(MCPError, match="MCP error calling"):
            await mcp_client.call_tool("search_user_by_text", {})

    @pytest.mark.asyncio
    @respx.mock
    async def test_call_tool_validation_error(self, mcp_client):
        """Test handling of validation error when calling tool."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32602,
                "message": "Validation error: missing required field",
            },
        }

        respx.post("http://localhost:8081/mcp").mock(return_value=Response(200, json=mock_response))

        await mcp_client.connect()
        with pytest.raises(MCPError):
            await mcp_client.call_tool("search_user_by_text", {})


class TestMCPClientContextManager:
    """Test MCP client as async context manager."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test using MCP client as async context manager."""
        async with MCPClient(agent_key="cs_agent_test123") as client:
            assert client is not None
            assert client.agent_key == "cs_agent_test123"

    @pytest.mark.asyncio
    @respx.mock
    async def test_context_manager_with_request(self):
        """Test making requests within context manager."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": []},
        }

        respx.post("https://gcp-us-east4.context-surfaces.redis.io/mcp").mock(
            return_value=Response(200, json=mock_response)
        )

        with patch.dict(os.environ, {}, clear=False):
            if "CTX_MCP_URL" in os.environ:
                del os.environ["CTX_MCP_URL"]
            async with MCPClient(agent_key="cs_agent_test123") as client:
                tools = await client.list_tools()
                assert tools == []


class TestMCPClientHeaders:
    """Test MCP client request headers."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_api_key_header_included(self, mcp_client):
        """Test that X-API-Key header is included in requests."""
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": []},
        }

        route = respx.post("http://localhost:8081/mcp").mock(
            return_value=Response(200, json=mock_response)
        )

        await mcp_client.connect()
        await mcp_client.list_tools()

        # Check that the request included the X-API-Key header
        assert route.called
        request = route.calls.last.request
        assert "X-API-Key" in request.headers
        assert request.headers["X-API-Key"] == "cs_agent_test123"


class TestMCPURLPathJoining:
    """Test that MCP URLs preserve exact paths without trailing slashes."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_mcp_url_preserves_path_without_trailing_slash(self):
        """Test that MCP URL with /mcp path is preserved without trailing slash."""
        mcp_client = MCPClient(
            mcp_url="http://localhost:8081/mcp",
            agent_key="cs_agent_test123",
        )

        # Verify mcp_url preserves exact path (no trailing slash)
        assert mcp_client.mcp_url == "http://localhost:8081/mcp"

        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": [{"name": "test_tool"}]},
        }

        # Mock the MCP endpoint - httpx will POST to the base URL directly
        respx.post("http://localhost:8081/mcp").mock(
            return_value=Response(200, json=mock_response)
        )

        await mcp_client.connect()
        tools = await mcp_client.list_tools()
        assert len(tools) == 1

    @pytest.mark.asyncio
    @respx.mock
    async def test_mcp_url_with_multi_level_path(self):
        """Test MCP URL with multiple path levels preserves exact path."""
        mcp_client = MCPClient(
            mcp_url="http://api.example.com/services/mcp/v1",
            agent_key="cs_agent_test123",
        )

        # Verify mcp_url preserves exact path (no trailing slash)
        assert mcp_client.mcp_url == "http://api.example.com/services/mcp/v1"

        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": []},
        }

        # Mock the deep path endpoint
        respx.post("http://api.example.com/services/mcp/v1").mock(
            return_value=Response(200, json=mock_response)
        )

        await mcp_client.connect()
        tools = await mcp_client.list_tools()
        assert tools == []

    @pytest.mark.asyncio
    @respx.mock
    async def test_mcp_url_with_context_surfaces_path(self):
        """Test MCP URL with context-surfaces path preserves exact path."""
        mcp_client = MCPClient(
            mcp_url="https://gcp-us-east4.context-surfaces.redis.io/mcp",
            agent_key="cs_agent_test123",
        )

        # Verify mcp_url preserves exact path (no trailing slash)
        assert mcp_client.mcp_url == "https://gcp-us-east4.context-surfaces.redis.io/mcp"

        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"content": [{"type": "text", "text": "Success"}]},
        }

        # Mock the production-like URL
        respx.post("https://gcp-us-east4.context-surfaces.redis.io/mcp").mock(
            return_value=Response(200, json=mock_response)
        )

        await mcp_client.connect()
        result = await mcp_client.call_tool("test_tool", {})
        assert result["content"][0]["text"] == "Success"
