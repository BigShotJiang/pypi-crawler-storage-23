"""Comprehensive tests for ContextModel, ContextField, and ContextRelationship."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from context_surfaces.context_model import (
    ContextField,
    ContextModel,
    ContextRelationship,
    export_data_model,
)


class TestContextField:
    """Test ContextField functionality."""

    def test_basic_field_creation(self):
        """Test creating a basic field with description."""

        class TestModel(ContextModel):
            name: str = ContextField(description="Test name")

        model = TestModel(name="test")
        assert model.name == "test"

    def test_field_with_default(self):
        """Test field with default value."""

        class TestModel(ContextModel):
            name: str = ContextField(description="Test name", default="default")

        model = TestModel()
        assert model.name == "default"

    def test_field_with_default_factory(self):
        """Test field with default factory."""

        class TestModel(ContextModel):
            tags: list[str] = ContextField(description="Tags", default_factory=list)

        model = TestModel()
        assert model.tags == []
        assert isinstance(model.tags, list)

    def test_field_with_index(self):
        """Test field with index metadata."""

        class TestModel(ContextModel):
            email: str = ContextField(description="Email", index="text")

        fields = TestModel.get_index_fields()
        email_field = next(f for f in fields if f["name"] == "email")
        assert len(email_field["redis_indices"]) == 1
        assert email_field["redis_indices"][0]["type"] == "text"

    def test_field_with_multiple_indices(self):
        """Test field with multiple index types."""

        class TestModel(ContextModel):
            status: str = ContextField(description="Status", index=["tag", "text"])

        fields = TestModel.get_index_fields()
        status_field = next(f for f in fields if f["name"] == "status")
        assert len(status_field["redis_indices"]) == 2
        index_types = [idx["type"] for idx in status_field["redis_indices"]]
        assert "tag" in index_types
        assert "text" in index_types

    def test_field_with_vector_index(self):
        """Test field with vector index and required vector_dim."""

        class TestModel(ContextModel):
            embedding: list[float] = ContextField(
                description="Embedding",
                index="vector",
                vector_dim=1536,
                distance_metric="cosine",
                default_factory=list,
            )

        fields = TestModel.get_index_fields()
        embedding_field = next(f for f in fields if f["name"] == "embedding")
        assert len(embedding_field["redis_indices"]) == 1
        vector_idx = embedding_field["redis_indices"][0]
        assert vector_idx["type"] == "vector"
        assert vector_idx["vector_dim"] == 1536
        assert vector_idx["distance_metric"] == "cosine"

    def test_vector_index_requires_vector_dim(self):
        """Test that vector index requires vector_dim."""
        with pytest.raises(ValueError, match="vector_dim is required"):

            class TestModel(ContextModel):
                embedding: list[float] = ContextField(
                    description="Embedding",
                    index="vector",
                    default_factory=list,
                )

    def test_field_with_text_options(self):
        """Test field with text-specific options."""

        class TestModel(ContextModel):
            title: str = ContextField(
                description="Title",
                index="text",
                weight=2.0,
                no_stem=True,
            )

        fields = TestModel.get_index_fields()
        title_field = next(f for f in fields if f["name"] == "title")
        text_idx = title_field["redis_indices"][0]
        assert text_idx["weight"] == 2.0
        assert text_idx["no_stem"] is True

    def test_field_with_numeric_options(self):
        """Test field with numeric-specific options."""

        class TestModel(ContextModel):
            price: float = ContextField(
                description="Price",
                index="numeric",
                sortable=True,
            )

        fields = TestModel.get_index_fields()
        price_field = next(f for f in fields if f["name"] == "price")
        numeric_idx = price_field["redis_indices"][0]
        assert numeric_idx["sortable"] is True

    def test_field_is_key_component(self):
        """Test field marked as key component."""

        class TestModel(ContextModel):
            id: int = ContextField(
                description="ID",
                is_key_component=True,
            )

        fields = TestModel.get_index_fields()
        id_field = next(f for f in fields if f["name"] == "id")
        assert id_field["is_key_component"] is True


class TestContextRelationship:
    """Test ContextRelationship functionality."""

    def test_basic_relationship(self):
        """Test creating a basic relationship."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User who placed order",
                source_field="user_id",
            )

        # Verify relationship is registered
        assert "user" in Order.relationship_fields()

    def test_relationship_not_in_model_fields(self):
        """Test that relationships don't appear in Pydantic model fields."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        # Relationship should not be in model_fields
        assert "user" not in Order.model_fields
        assert "user_id" in Order.model_fields

    def test_relationship_instance_access_returns_none(self):
        """Test that accessing relationship on instance returns None."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        assert order.user is None

    def test_relationship_class_access_returns_descriptor(self):
        """Test that accessing relationship on class returns descriptor."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        # Class access should return the relationship
        assert isinstance(Order.user, ContextRelationship)

    def test_relationship_cannot_be_set(self):
        """Test that relationship fields cannot be set directly."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        # Pydantic will raise ValueError for unknown field
        with pytest.raises((AttributeError, ValueError)):
            order.user = User(id=123)

    def test_list_relationship(self):
        """Test relationship with list type."""

        class Product(ContextModel):
            id: int = ContextField(description="Product ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            product_ids: list[int] = ContextField(
                description="Product IDs",
                default_factory=list,
            )
            products: list[Product] = ContextRelationship(
                description="Products in order",
                source_field="product_ids",
            )

        # Verify relationship is registered
        assert "products" in Order.relationship_fields()

    def test_get_relationships_metadata(self):
        """Test extracting relationship metadata."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Product(ContextModel):
            id: int = ContextField(description="Product ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            product_ids: list[int] = ContextField(
                description="Product IDs",
                default_factory=list,
            )
            user: User = ContextRelationship(
                description="Customer who placed order",
                source_field="user_id",
            )
            products: list[Product] = ContextRelationship(
                description="Products in order",
                source_field="product_ids",
            )

        relationships = Order.get_relationships()
        assert len(relationships) == 2

        user_rel = next(r for r in relationships if r["name"] == "user")
        assert user_rel["target"] == "User"
        assert user_rel["description"] == "Customer who placed order"
        assert user_rel["source_field"] == "user_id"

        products_rel = next(r for r in relationships if r["name"] == "products")
        assert products_rel["target"] == "Product"
        assert products_rel["description"] == "Products in order"
        assert products_rel["source_field"] == "product_ids"


class TestContextModel:
    """Test ContextModel functionality."""

    def test_model_dump_excludes_relationships(self):
        """Test that model_dump excludes relationship fields."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        dumped = order.model_dump()

        # Regular fields should be present
        assert "id" in dumped
        assert "user_id" in dumped

        # Relationship fields should be excluded
        assert "user" not in dumped

    def test_to_entity_dict_basic(self):
        """Test exporting entity to dictionary."""

        class Customer(ContextModel):
            """Customer entity."""

            __redis_key_template__ = "customer:{id}"

            id: int = ContextField(
                description="Customer ID",
                is_key_component=True,
            )
            email: str = ContextField(
                description="Email address",
                index="text",
            )

        entity_dict = Customer.to_entity_dict()

        assert entity_dict["name"] == "Customer"
        assert entity_dict["description"] == "Customer entity."
        assert entity_dict["redis_key_template"] == "customer:{id}"
        assert len(entity_dict["fields"]) == 2
        assert len(entity_dict["relationships"]) == 0

    def test_to_entity_dict_with_relationships(self):
        """Test exporting entity with relationships."""

        class User(ContextModel):
            """User entity."""

            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            """Order entity."""

            __redis_key_template__ = "order:{id}"

            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="Customer",
                source_field="user_id",
            )

        entity_dict = Order.to_entity_dict()

        assert len(entity_dict["relationships"]) == 1
        rel = entity_dict["relationships"][0]
        assert rel["name"] == "user"
        assert rel["target"] == "User"
        assert rel["description"] == "Customer"
        assert rel["source_field"] == "user_id"

    def test_to_entity_dict_default_template(self):
        """Test that default Redis key template is generated."""

        class Product(ContextModel):
            """Product entity."""

            id: int = ContextField(description="Product ID")

        entity_dict = Product.to_entity_dict()
        assert entity_dict["redis_key_template"] == "product:{id}"

    def test_get_index_fields_type_conversion(self):
        """Test that field types are correctly converted to strings."""

        class TestModel(ContextModel):
            int_field: int = ContextField(description="Int field")
            str_field: str = ContextField(description="Str field")
            float_field: float = ContextField(description="Float field")
            list_field: list[str] = ContextField(
                description="List field",
                default_factory=list,
            )
            list_float_field: list[float] = ContextField(
                description="List of floats",
                default_factory=list,
            )

        fields = TestModel.get_index_fields()
        field_types = {f["name"]: f["type"] for f in fields}

        assert field_types["int_field"] == "int"
        assert field_types["str_field"] == "str"
        assert field_types["float_field"] == "float"
        assert field_types["list_field"] == "list[str]"
        assert field_types["list_float_field"] == "list[float]"

    def test_model_validation_works(self):
        """Test that Pydantic validation still works."""

        class TestModel(ContextModel):
            id: int = ContextField(description="ID")
            email: str = ContextField(description="Email")

        # Valid data
        model = TestModel(id=1, email="test@example.com")
        assert model.id == 1
        assert model.email == "test@example.com"

        # Invalid data - wrong type
        with pytest.raises(ValidationError):
            TestModel(id="not_an_int", email="test@example.com")

    def test_model_with_optional_fields(self):
        """Test model with optional fields."""

        class TestModel(ContextModel):
            id: int = ContextField(description="ID")
            optional_field: str | None = ContextField(
                description="Optional field",
                default=None,
            )

        model = TestModel(id=1)
        assert model.optional_field is None

        model2 = TestModel(id=2, optional_field="value")
        assert model2.optional_field == "value"

    def test_inheritance(self):
        """Test that ContextModel supports inheritance."""

        class BaseEntity(ContextModel):
            id: int = ContextField(description="ID", is_key_component=True)

        class Customer(BaseEntity):
            email: str = ContextField(description="Email")

        customer = Customer(id=1, email="test@example.com")
        assert customer.id == 1
        assert customer.email == "test@example.com"

        fields = Customer.get_index_fields()
        assert len(fields) == 2
        field_names = {f["name"] for f in fields}
        assert "id" in field_names
        assert "email" in field_names


class TestExportDataModel:
    """Test export_data_model function."""

    def test_export_single_entity(self):
        """Test exporting a single entity."""

        class Customer(ContextModel):
            """Customer entity."""

            __redis_key_template__ = "customer:{id}"

            id: int = ContextField(description="Customer ID")

        data_model = export_data_model(
            title="Test API",
            description="Test description",
            entities=[Customer],
        )

        assert data_model["title"] == "Test API"
        assert data_model["description"] == "Test description"
        assert data_model["entity_count"] == 1
        assert len(data_model["entities"]) == 1
        assert data_model["entities"][0]["name"] == "Customer"

    def test_export_multiple_entities(self):
        """Test exporting multiple entities."""

        class Customer(ContextModel):
            """Customer entity."""

            id: int = ContextField(description="Customer ID")

        class Order(ContextModel):
            """Order entity."""

            id: int = ContextField(description="Order ID")

        data_model = export_data_model(
            title="E-commerce API",
            description="E-commerce data model",
            entities=[Customer, Order],
        )

        assert data_model["entity_count"] == 2
        assert len(data_model["entities"]) == 2
        entity_names = {e["name"] for e in data_model["entities"]}
        assert "Customer" in entity_names
        assert "Order" in entity_names

    def test_export_with_custom_templates(self):
        """Test exporting with custom Redis key templates."""

        class Customer(ContextModel):
            """Customer entity."""

            __redis_key_template__ = "cust:{id}"

            id: int = ContextField(description="Customer ID")

        class Order(ContextModel):
            """Order entity."""

            __redis_key_template__ = "order:{customer_id}:{id}"

            id: int = ContextField(description="Order ID")

        data_model = export_data_model(
            title="Test API",
            description="Test",
            entities=[Customer, Order],
        )

        customer_entity = next(e for e in data_model["entities"] if e["name"] == "Customer")
        order_entity = next(e for e in data_model["entities"] if e["name"] == "Order")

        assert customer_entity["redis_key_template"] == "cust:{id}"
        assert order_entity["redis_key_template"] == "order:{customer_id}:{id}"


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_relationship_with_no_source_field(self):
        """Test relationship without source_field."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user: User = ContextRelationship(description="User")

        relationships = Order.get_relationships()
        user_rel = relationships[0]
        assert user_rel["source_field"] == ""

    def test_model_with_no_docstring(self):
        """Test model without docstring."""

        class NoDocModel(ContextModel):
            id: int = ContextField(description="ID")

        entity_dict = NoDocModel.to_entity_dict()
        assert entity_dict["description"] == ""

    def test_field_without_index(self):
        """Test field without any index."""

        class TestModel(ContextModel):
            name: str = ContextField(description="Name")

        fields = TestModel.get_index_fields()
        name_field = next(f for f in fields if f["name"] == "name")
        assert name_field["redis_indices"] == []

    def test_field_without_description_in_field_info(self):
        """Test field where description might be None."""

        class TestModel(ContextModel):
            id: int = ContextField(description="ID")

        fields = TestModel.get_index_fields()
        # All our fields have descriptions, but test the fallback
        assert all(isinstance(f["description"], str) for f in fields)

    def test_text_index_default_weight(self):
        """Test that default weight is included in output."""

        class TestModel(ContextModel):
            name: str = ContextField(
                description="Name",
                index="text",
                # weight=1.0 is default, should be included
            )

        fields = TestModel.get_index_fields()
        name_field = next(f for f in fields if f["name"] == "name")
        text_idx = name_field["redis_indices"][0]
        # Default weight should be in the output
        assert text_idx["weight"] == 1.0

    def test_text_index_no_stem_false(self):
        """Test that no_stem=False is not included in output."""

        class TestModel(ContextModel):
            name: str = ContextField(
                description="Name",
                index="text",
                no_stem=False,  # Default, should not appear
            )

        fields = TestModel.get_index_fields()
        name_field = next(f for f in fields if f["name"] == "name")
        text_idx = name_field["redis_indices"][0]
        assert "no_stem" not in text_idx

    def test_numeric_index_sortable_false(self):
        """Test that sortable=False is not included in output."""

        class TestModel(ContextModel):
            count: int = ContextField(
                description="Count",
                index="numeric",
                sortable=False,  # Default, should not appear
            )

        fields = TestModel.get_index_fields()
        count_field = next(f for f in fields if f["name"] == "count")
        numeric_idx = count_field["redis_indices"][0]
        assert "sortable" not in numeric_idx

    def test_model_post_init_cleans_relationships(self):
        """Test that model_post_init removes relationship fields from __dict__."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        # Relationship should not be in __dict__
        assert "user" not in order.__dict__

    def test_get_type_string_with_optional(self):
        """Test type string conversion with Optional types."""

        class TestModel(ContextModel):
            optional_str: str | None = ContextField(
                description="Optional string",
                default=None,
            )

        fields = TestModel.get_index_fields()
        optional_field = next(f for f in fields if f["name"] == "optional_str")
        # Should extract the non-None type
        assert optional_field["type"] == "str"

    def test_relationship_inheritance(self):
        """Test that relationships are inherited from parent classes."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class BaseOrder(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        class ExtendedOrder(BaseOrder):
            notes: str = ContextField(description="Notes", default="")

        # Child should inherit parent's relationships
        assert "user" in ExtendedOrder.relationship_fields()
        relationships = ExtendedOrder.get_relationships()
        assert len(relationships) == 1
        assert relationships[0]["name"] == "user"

    def test_relationship_descriptor_set_raises_error(self):
        """Test that RelationshipDescriptor.__set__ raises AttributeError."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        # Try to set via descriptor - should raise AttributeError
        with pytest.raises((AttributeError, ValueError)):
            # This will go through Pydantic's __setattr__ first
            order.user = User(id=123)

    def test_model_dump_with_exclude_set(self):
        """Test model_dump with existing exclude set."""

        class User(ContextModel):
            id: int = ContextField(description="User ID")

        class Order(ContextModel):
            id: int = ContextField(description="Order ID")
            user_id: int = ContextField(description="User ID")
            secret: str = ContextField(description="Secret", default="secret")
            user: User = ContextRelationship(
                description="User",
                source_field="user_id",
            )

        order = Order(id=1, user_id=123)
        # Dump with exclude set
        dumped = order.model_dump(exclude={"secret"})

        assert "id" in dumped
        assert "user_id" in dumped
        assert "secret" not in dumped
        assert "user" not in dumped

    def test_vector_index_with_euclidean_distance(self):
        """Test vector index with euclidean distance metric."""

        class TestModel(ContextModel):
            embedding: list[float] = ContextField(
                description="Embedding",
                index="vector",
                vector_dim=768,
                distance_metric="euclidean",
                default_factory=list,
            )

        fields = TestModel.get_index_fields()
        embedding_field = next(f for f in fields if f["name"] == "embedding")
        vector_idx = embedding_field["redis_indices"][0]
        assert vector_idx["distance_metric"] == "euclidean"

    def test_optional_relationship_in_string_annotation(self):
        """Test relationship with Optional type in string annotation."""
        from context_surfaces.context_model import _get_target_name

        # Test string annotation with Optional
        result = _get_target_name("Product | None")
        assert result == "Product"

        # Test string annotation with list
        result = _get_target_name("list[Product]")
        assert result == "Product"

        # Test plain string
        result = _get_target_name("Product")
        assert result == "Product"

    def test_primary_index_type(self):
        """Test field with primary index type."""

        class TestModel(ContextModel):
            id: int = ContextField(
                description="ID",
                index="primary",
                is_key_component=True,
            )

        fields = TestModel.get_index_fields()
        id_field = next(f for f in fields if f["name"] == "id")
        assert len(id_field["redis_indices"]) == 1
        assert id_field["redis_indices"][0]["type"] == "primary"

    def test_tag_index_type(self):
        """Test field with tag index type."""

        class TestModel(ContextModel):
            status: str = ContextField(
                description="Status",
                index="tag",
            )

        fields = TestModel.get_index_fields()
        status_field = next(f for f in fields if f["name"] == "status")
        assert len(status_field["redis_indices"]) == 1
        assert status_field["redis_indices"][0]["type"] == "tag"
