"""Tests for CLI output data models."""

import json

import pytest
import yaml
from pydantic import ValidationError

from context_surfaces.cli.models.output import (
    JsonOutput,
    TableColumn,
    TableOutput,
    TableRow,
    TextOutput,
    YamlOutput,
)


class TestTextOutput:
    """Test TextOutput model."""

    def test_basic_text(self):
        """Test basic text output."""
        output = TextOutput(text="Hello, World!")
        assert output.to_string() == "Hello, World!"
        assert output.get_data() == "Hello, World!"

    def test_text_with_style(self):
        """Test text output with style (style is metadata, not in string)."""
        output = TextOutput(text="Success!", style="bold green")
        assert output.to_string() == "Success!"
        assert output.style == "bold green"


class TestJsonOutput:
    """Test JsonOutput model."""

    def test_json_from_dict(self):
        """Test JSON output from dictionary."""
        data = {"name": "Alice", "age": 30}
        output = JsonOutput(data=data)

        json_str = output.to_string()
        parsed = json.loads(json_str)

        assert parsed == data
        assert output.get_data() == data

    def test_json_from_list(self):
        """Test JSON output from list."""
        data = [{"id": 1}, {"id": 2}]
        output = JsonOutput(data=data)

        json_str = output.to_string()
        parsed = json.loads(json_str)

        assert parsed == data

    def test_json_with_custom_indent(self):
        """Test JSON output with custom indentation."""
        data = {"key": "value"}
        output = JsonOutput(data=data, indent=4)

        json_str = output.to_string()
        assert "    " in json_str  # 4-space indent

    def test_json_with_sorted_keys(self):
        """Test JSON output with sorted keys."""
        data = {"z": 1, "a": 2, "m": 3}
        output = JsonOutput(data=data, sort_keys=True)

        json_str = output.to_string()
        # Keys should appear in alphabetical order
        assert json_str.index('"a"') < json_str.index('"m"') < json_str.index('"z"')


class TestYamlOutput:
    """Test YamlOutput model."""

    def test_yaml_from_dict(self):
        """Test YAML output from dictionary."""
        data = {"name": "Alice", "age": 30}
        output = YamlOutput(data=data)

        yaml_str = output.to_string()
        parsed = yaml.safe_load(yaml_str)

        assert parsed == data
        assert output.get_data() == data

    def test_yaml_from_list(self):
        """Test YAML output from list."""
        data = [{"id": 1}, {"id": 2}]
        output = YamlOutput(data=data)

        yaml_str = output.to_string()
        parsed = yaml.safe_load(yaml_str)

        assert parsed == data


class TestTableColumn:
    """Test TableColumn model."""

    def test_basic_column(self):
        """Test basic column definition."""
        col = TableColumn(header="Name", key="name")
        assert col.header == "Name"
        assert col.key == "name"
        assert col.justify == "left"

    def test_column_with_style(self):
        """Test column with custom style."""
        col = TableColumn(
            header="Status",
            key="status",
            style="bold green",
            justify="center",
        )
        assert col.style == "bold green"
        assert col.justify == "center"


class TestTableRow:
    """Test TableRow model."""

    def test_row_from_dict(self):
        """Test row from dictionary."""
        row = TableRow(data={"name": "Alice", "age": 30})
        col = TableColumn(header="Name", key="name")

        value = row.get_value(col, 0)
        assert value == "Alice"

    def test_row_from_list(self):
        """Test row from list."""
        row = TableRow(data=["Alice", 30])
        col = TableColumn(header="Name")

        value = row.get_value(col, 0)
        assert value == "Alice"

    def test_row_get_value_with_none(self):
        """Test getting value that is None."""
        row = TableRow(data={"name": None})
        col = TableColumn(header="Name", key="name")

        value = row.get_value(col, 0)
        assert value == ""

    def test_row_get_value_missing_key(self):
        """Test getting value for missing key."""
        row = TableRow(data={"name": "Alice"})
        col = TableColumn(header="Age", key="age")

        value = row.get_value(col, 0)
        assert value == ""


class TestTableOutput:
    """Test TableOutput model."""

    def test_basic_table(self):
        """Test basic table creation."""
        columns = [
            TableColumn(header="Name", key="name"),
            TableColumn(header="Age", key="age"),
        ]
        rows = [
            TableRow(data={"name": "Alice", "age": 30}),
            TableRow(data={"name": "Bob", "age": 25}),
        ]

        table = TableOutput(columns=columns, rows=rows)

        assert len(table.columns) == 2
        assert len(table.rows) == 2

    def test_table_to_string(self):
        """Test table to string conversion."""
        columns = [
            TableColumn(header="Name", key="name"),
            TableColumn(header="Age", key="age"),
        ]
        rows = [
            TableRow(data={"name": "Alice", "age": "30"}),
        ]

        table = TableOutput(columns=columns, rows=rows)
        table_str = table.to_string()

        assert "Name" in table_str
        assert "Age" in table_str
        assert "Alice" in table_str
        assert "30" in table_str

    def test_table_get_data(self):
        """Test getting underlying data from table."""
        columns = [
            TableColumn(header="Name", key="name"),
            TableColumn(header="Age", key="age"),
        ]
        rows = [
            TableRow(data={"name": "Alice", "age": 30}),
            TableRow(data={"name": "Bob", "age": 25}),
        ]

        table = TableOutput(columns=columns, rows=rows)
        data = table.get_data()

        assert len(data) == 2
        assert data[0] == {"name": "Alice", "age": 30}
        assert data[1] == {"name": "Bob", "age": 25}

    def test_table_from_dicts(self):
        """Test creating table from list of dicts."""
        data = [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 25},
        ]

        table = TableOutput.from_dicts(data)

        assert len(table.columns) == 2
        assert len(table.rows) == 2
        assert table.columns[0].header == "Name"
        assert table.columns[1].header == "Age"

    def test_table_from_dicts_with_custom_columns(self):
        """Test creating table with specific columns."""
        data = [
            {"name": "Alice", "age": 30, "city": "NYC"},
            {"name": "Bob", "age": 25, "city": "LA"},
        ]

        table = TableOutput.from_dicts(data, columns=["name", "city"])

        assert len(table.columns) == 2
        assert table.columns[0].key == "name"
        assert table.columns[1].key == "city"

    def test_table_from_dicts_with_title(self):
        """Test creating table with title and caption."""
        data = [{"name": "Alice"}]

        table = TableOutput.from_dicts(
            data,
            title="Users",
            caption="Total: 1 user",
        )

        assert table.title == "Users"
        assert table.caption == "Total: 1 user"

    def test_table_from_dict(self):
        """Test creating table from single dict (key-value pairs)."""
        data = {"name": "Alice", "age": 30}

        table = TableOutput.from_dict(data)

        assert len(table.columns) == 2
        assert table.columns[0].header == "Key"
        assert table.columns[1].header == "Value"
        assert len(table.rows) == 2

    def test_table_from_empty_list(self):
        """Test creating table from empty list."""
        table = TableOutput.from_dicts([])

        assert len(table.columns) == 0
        assert len(table.rows) == 0

    def test_table_with_title_in_string(self):
        """Test that title appears in string representation."""
        columns = [TableColumn(header="Name", key="name")]
        rows = [TableRow(data={"name": "Alice"})]

        table = TableOutput(columns=columns, rows=rows, title="Users Table")
        table_str = table.to_string()

        assert "Users Table" in table_str

    def test_table_with_caption_in_string(self):
        """Test that caption appears in string representation."""
        columns = [TableColumn(header="Name", key="name")]
        rows = [TableRow(data={"name": "Alice"})]

        table = TableOutput(columns=columns, rows=rows, caption="Total: 1")
        table_str = table.to_string()

        assert "Total: 1" in table_str


class TestPydanticValidation:
    """Test Pydantic validation features."""

    def test_json_output_indent_validation(self):
        """Test that JsonOutput validates indent range."""
        # Valid indent values
        JsonOutput(data={"key": "value"}, indent=0)
        JsonOutput(data={"key": "value"}, indent=4)
        JsonOutput(data={"key": "value"}, indent=8)

        # Invalid indent values should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            JsonOutput(data={"key": "value"}, indent=-1)
        assert "greater than or equal to 0" in str(exc_info.value)

        with pytest.raises(ValidationError) as exc_info:
            JsonOutput(data={"key": "value"}, indent=10)
        assert "less than or equal to 8" in str(exc_info.value)

    def test_table_column_justify_validation(self):
        """Test that TableColumn validates justify values."""
        # Valid justify values
        TableColumn(header="Test", justify="left")
        TableColumn(header="Test", justify="center")
        TableColumn(header="Test", justify="right")

        # Invalid justify value should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            TableColumn(header="Test", justify="invalid")  # type: ignore
        # Literal types produce different error message than pattern validation
        assert "literal_error" in str(exc_info.value) or "Input should be" in str(exc_info.value)

    def test_table_column_overflow_validation(self):
        """Test that TableColumn validates overflow values."""
        # Valid overflow values
        TableColumn(header="Test", overflow="fold")
        TableColumn(header="Test", overflow="crop")
        TableColumn(header="Test", overflow="ellipsis")

        # Invalid overflow value should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            TableColumn(header="Test", overflow="invalid")  # type: ignore
        # Literal types produce different error message than pattern validation
        assert "literal_error" in str(exc_info.value) or "Input should be" in str(exc_info.value)

    def test_pydantic_model_dump(self):
        """Test that Pydantic models can be serialized."""
        output = TextOutput(text="Hello", style="bold")

        # Test model_dump
        data = output.model_dump()
        assert data == {"text": "Hello", "style": "bold"}

        # Test model_dump_json
        json_str = output.model_dump_json()
        assert json.loads(json_str) == {"text": "Hello", "style": "bold"}

    def test_pydantic_model_validation(self):
        """Test that Pydantic validates required fields."""
        # Missing required field should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            TextOutput()  # Missing 'text' field
        assert "Field required" in str(exc_info.value)

    def test_pydantic_strict_typing(self):
        """Test that Pydantic enforces strict typing."""
        # Integer should NOT be accepted for string field (strict typing)
        with pytest.raises(ValidationError) as exc_info:
            TextOutput(text=123)
        assert "Input should be a valid string" in str(exc_info.value)
