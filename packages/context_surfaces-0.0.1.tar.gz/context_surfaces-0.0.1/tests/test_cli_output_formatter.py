"""Tests for CLI output formatter."""

import json
import re
from io import StringIO

import pytest

from context_surfaces.cli.models.output import (
    JsonOutput,
    TableColumn,
    TableOutput,
    TableRow,
    TextOutput,
    YamlOutput,
)
from context_surfaces.cli.services.output_formatter import OutputFormatter


def strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
    return ansi_escape.sub("", text)


def capture_console_output(formatter: OutputFormatter, func, *args, **kwargs) -> str:
    """Capture output from Rich Console and stdout.

    Rich Console writes to console.file, but JSON output uses plain print()
    which goes to stdout. We need to capture both.
    """
    import sys

    console_output = StringIO()
    stdout_output = StringIO()
    original_file = formatter.console.file
    original_stdout = sys.stdout
    formatter.console.file = console_output
    sys.stdout = stdout_output
    try:
        func(*args, **kwargs)
        # Return stdout first (for JSON), then console output (for other formats)
        return stdout_output.getvalue() + console_output.getvalue()
    finally:
        formatter.console.file = original_file
        sys.stdout = original_stdout


@pytest.fixture
def formatter():
    """Create an output formatter."""
    return OutputFormatter()


@pytest.fixture
def formatter_no_color():
    """Create an output formatter with color disabled."""
    return OutputFormatter(color=False)


class TestOutputFormatterRender:
    """Test output formatter render() method."""

    def test_init_with_color(self):
        """Test initialization with color enabled."""
        formatter = OutputFormatter(color=True)
        assert formatter.color is True

    def test_init_without_color(self):
        """Test initialization with color disabled."""
        formatter = OutputFormatter(color=False)
        assert formatter.color is False

    def test_render_text_output(self, formatter):
        """Test rendering TextOutput."""
        text_output = TextOutput(text="Hello, World!")
        output = capture_console_output(formatter, formatter.render, text_output)

        clean_output = strip_ansi(output).strip()
        assert "Hello, World!" in clean_output

    def test_render_text_output_with_style(self, formatter):
        """Test rendering TextOutput with style."""
        text_output = TextOutput(text="Success!", style="bold green")
        output = capture_console_output(formatter, formatter.render, text_output)

        # Should contain the text (style is in ANSI codes)
        assert "Success!" in output

    def test_render_json_output(self, formatter):
        """Test rendering JsonOutput."""
        data = {"name": "test", "value": 123}
        json_output = JsonOutput(data=data)

        output = capture_console_output(formatter, formatter.render, json_output)
        clean_output = strip_ansi(output).strip()

        # Should be valid JSON
        parsed = json.loads(clean_output)
        assert parsed == data

    def test_render_yaml_output(self, formatter):
        """Test rendering YamlOutput."""
        data = {"name": "test", "value": 123}
        yaml_output = YamlOutput(data=data)

        output = capture_console_output(formatter, formatter.render, yaml_output)
        clean_output = strip_ansi(output).strip()

        # Should be valid YAML
        import yaml

        parsed = yaml.safe_load(clean_output)
        assert parsed == data

    def test_render_table_output(self, formatter):
        """Test rendering TableOutput."""
        columns = [
            TableColumn(header="ID", key="id"),
            TableColumn(header="Name", key="name"),
        ]
        rows = [
            TableRow(data={"id": "1", "name": "Alice"}),
            TableRow(data={"id": "2", "name": "Bob"}),
        ]
        table_output = TableOutput(columns=columns, rows=rows)

        output = capture_console_output(formatter, formatter.render, table_output)

        # Should contain the data
        assert "Alice" in output
        assert "Bob" in output
        assert "1" in output
        assert "2" in output

    def test_render_table_from_dicts(self, formatter):
        """Test rendering TableOutput created from dicts."""
        data = [
            {"id": 1, "name": "Alice"},
            {"id": 2, "name": "Bob"},
        ]
        table_output = TableOutput.from_dicts(data)

        output = capture_console_output(formatter, formatter.render, table_output)

        # Should contain the data
        assert "Alice" in output
        assert "Bob" in output

    def test_render_table_from_dict(self, formatter):
        """Test rendering TableOutput created from a single dict."""
        data = {"name": "test", "value": 123}
        table_output = TableOutput.from_dict(data)

        output = capture_console_output(formatter, formatter.render, table_output)
        clean_output = strip_ansi(output)

        # Should contain keys and values
        assert "name" in clean_output.lower()
        assert "test" in clean_output
        assert "value" in clean_output.lower()
        assert "123" in clean_output

    def test_render_unsupported_type(self, formatter):
        """Test that rendering unsupported type raises TypeError."""

        class UnsupportedOutput:
            pass

        with pytest.raises(TypeError, match="Unsupported output type"):
            formatter.render(UnsupportedOutput())

    def test_render_with_color_disabled(self, formatter_no_color):
        """Test rendering with color disabled."""
        text_output = TextOutput(text="Test", style="bold green")
        output = capture_console_output(formatter_no_color, formatter_no_color.render, text_output)

        # Should contain text without ANSI codes
        assert "Test" in output
        # No ANSI escape sequences
        assert "\x1b[" not in output

    def test_render_nested_data(self, formatter):
        """Test rendering nested data structures."""
        data = {
            "user": {
                "name": "Alice",
                "age": 30,
            },
            "settings": {
                "theme": "dark",
            },
        }

        # JSON should handle nesting
        json_output = JsonOutput(data=data)
        output = capture_console_output(formatter, formatter.render, json_output)
        clean_output = strip_ansi(output).strip()
        parsed = json.loads(clean_output)
        assert parsed["user"]["name"] == "Alice"

        # YAML should handle nesting
        yaml_output = YamlOutput(data=data)
        output = capture_console_output(formatter, formatter.render, yaml_output)
        clean_output = strip_ansi(output).strip()
        import yaml

        parsed = yaml.safe_load(clean_output)
        assert parsed["user"]["name"] == "Alice"

    def test_render_with_none_values(self, formatter):
        """Test rendering data with None values."""
        data = {"name": "test", "value": None}

        # JSON should handle None
        json_output = JsonOutput(data=data)
        output = capture_console_output(formatter, formatter.render, json_output)
        clean_output = strip_ansi(output).strip()
        parsed = json.loads(clean_output)
        assert parsed["value"] is None
