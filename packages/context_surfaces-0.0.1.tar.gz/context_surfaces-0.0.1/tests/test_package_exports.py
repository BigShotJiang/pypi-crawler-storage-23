from context_surfaces import DataImportError, DataImportOptions, DataImportResponse
from context_surfaces.models import (
    DataImportError as ModelDataImportError,
)
from context_surfaces.models import DataImportOptions as ModelDataImportOptions
from context_surfaces.models import DataImportResponse as ModelDataImportResponse


def test_data_import_models_exported_from_package_root() -> None:
    assert DataImportError is ModelDataImportError
    assert DataImportOptions is ModelDataImportOptions
    assert DataImportResponse is ModelDataImportResponse
