"""Tests for Context Surfaces client."""

import os
from unittest.mock import patch

import pytest
import respx
from httpx import Response

from context_surfaces.client import ContextSurfacesClient
from context_surfaces.exceptions import (
    AuthenticationError,
    NotFoundError,
    ValidationError,
)
from context_surfaces.models import (
    AdminAPIKey,
    AgentAPIKey,
    ContextSurface,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    UpdateContextSurfaceRequest,
)


@pytest.fixture
def client():
    """Create a client for testing."""
    return ContextSurfacesClient(
        base_url="http://localhost:8080",
    )


class TestClientInit:
    """Test client initialization."""

    def test_init_with_defaults(self):
        """Test initialization with default values."""
        with patch.dict(os.environ, {}, clear=False):
            if "CTX_API_URL" in os.environ:
                del os.environ["CTX_API_URL"]
            client = ContextSurfacesClient()
            assert client.base_url == "https://cloud.redis.io/context-surfaces/"
            assert client.timeout == 30.0

    def test_init_uses_ctx_api_url_env_var(self):
        """Test initialization from CTX_API_URL when URL argument is omitted."""
        with patch.dict("os.environ", {"CTX_API_URL": "https://env.example.com"}, clear=False):
            client = ContextSurfacesClient()
            assert client.base_url == "https://env.example.com"

    def test_init_with_custom_values(self):
        """Test initialization with custom values."""
        client = ContextSurfacesClient(
            base_url="https://api.example.com",
            timeout=60,
        )
        assert client.base_url == "https://api.example.com"
        assert client.timeout == 60


class TestHealthCheck:
    """Test health check endpoint."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_health_success(self, client):
        """Test successful health check."""
        respx.get("http://localhost:8080/health").mock(
            return_value=Response(200, json={"status": "UP"})
        )

        result = await client.health()
        assert result.status == "UP"

    @pytest.mark.asyncio
    @respx.mock
    async def test_health_failure(self, client):
        """Test health check failure."""
        from context_surfaces.exceptions import APIError

        respx.get("http://localhost:8080/health").mock(
            return_value=Response(500, json={"error": "Internal Server Error"})
        )

        with pytest.raises(APIError):
            await client.health()


class TestAdminKeyOperations:
    """Test admin API key operations."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_admin_key_success(self, client):
        """Test successful admin key creation."""
        request = CreateAdminKeyRequest(
            name="test-admin",
            owner="test-owner",
        )

        mock_response = {
            "id": "key_123",
            "name": "test-admin",
            "owner": "test-owner",
            "key": "cs_admin_newkey123",
            "key_type": "admin",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.post("http://localhost:8080/api/v1/keys").mock(
            return_value=Response(201, json=mock_response)
        )

        result = await client.create_admin_key(request)

        assert isinstance(result, AdminAPIKey)
        assert result.name == "test-admin"
        assert result.key == "cs_admin_newkey123"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_admin_key_validation_error(self, client):
        """Test admin key creation with validation error."""
        request = CreateAdminKeyRequest(
            name="test-admin",
            owner="test-owner",
        )

        respx.post("http://localhost:8080/api/v1/keys").mock(
            return_value=Response(400, json={"error": "Invalid name"})
        )

        with pytest.raises(ValidationError):
            await client.create_admin_key(request)

    @pytest.mark.asyncio
    @respx.mock
    async def test_validate_key_success(self, client):
        """Test successful key validation."""
        respx.post("http://localhost:8080/api/v1/keys/validate").mock(
            return_value=Response(200, json={"valid": True, "key_type": "admin"})
        )

        result = await client.validate_key("cs_admin_test123")
        assert result["valid"] is True
        assert result["key_type"] == "admin"

    @pytest.mark.asyncio
    @respx.mock
    async def test_validate_key_unauthorized(self, client):
        """Test key validation with unauthorized error."""
        respx.post("http://localhost:8080/api/v1/keys/validate").mock(
            return_value=Response(401, json={"error": "Invalid API key"})
        )

        with pytest.raises(AuthenticationError):
            await client.validate_key("invalid_key")


class TestContextSurfaceOperations:
    """Test context surface operations."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_context_surface_success(self, client):
        """Test successful context surface creation."""
        admin_key = "cs_admin_test123"
        request = CreateContextSurfaceRequest(
            name="test-surface",
            description="Test surface",
        )

        mock_response = {
            "id": "engine_123",
            "name": "test-surface",
            "description": "Test surface",
            "owner": "test-owner",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.post("http://localhost:8080/api/v1/context-surfaces").mock(
            return_value=Response(201, json=mock_response)
        )

        result = await client.create_context_surface(request, admin_key=admin_key)

        assert isinstance(result, ContextSurface)
        assert result.name == "test-surface"

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_context_surface_success(self, client):
        """Test successful context surface retrieval."""
        admin_key = "cs_admin_test123"
        mock_response = {
            "id": "engine_123",
            "name": "test-surface",
            "description": "Test surface",
            "owner": "test-owner",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.get("http://localhost:8080/api/v1/context-surfaces/engine_123").mock(
            return_value=Response(200, json=mock_response)
        )

        result = await client.get_context_surface("engine_123", admin_key=admin_key)

        assert isinstance(result, ContextSurface)
        assert result.id == "engine_123"

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_context_surface_not_found(self, client):
        """Test context surface retrieval with not found error."""
        admin_key = "cs_admin_test123"
        respx.get("http://localhost:8080/api/v1/context-surfaces/nonexistent").mock(
            return_value=Response(404, json={"error": "Not found"})
        )

        with pytest.raises(NotFoundError):
            await client.get_context_surface("nonexistent", admin_key=admin_key)

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_context_surface_success(self, client):
        """Test successful context surface update."""
        admin_key = "cs_admin_test123"
        request = UpdateContextSurfaceRequest(
            description="Updated description",
        )

        mock_response = {
            "id": "engine_123",
            "name": "test-surface",
            "description": "Updated description",
            "owner": "test-owner",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }

        respx.put("http://localhost:8080/api/v1/context-surfaces/engine_123").mock(
            return_value=Response(200, json=mock_response)
        )

        result = await client.update_context_surface("engine_123", request, admin_key=admin_key)

        assert isinstance(result, ContextSurface)
        assert result.description == "Updated description"

    @pytest.mark.asyncio
    @respx.mock
    async def test_delete_context_surface_success(self, client):
        """Test successful context surface deletion."""
        admin_key = "cs_admin_test123"
        respx.delete("http://localhost:8080/api/v1/context-surfaces/engine_123").mock(
            return_value=Response(200, json={"message": "deleted"})
        )

        result = await client.delete_context_surface("engine_123", admin_key=admin_key)
        assert result["message"] == "deleted"

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_context_surfaces_success(self, client):
        """Test successful context surface listing."""
        admin_key = "cs_admin_test123"
        mock_response = {
            "context_surfaces": [
                {
                    "id": "engine_1",
                    "name": "surface-1",
                    "owner": "test-owner",
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                },
                {
                    "id": "engine_2",
                    "name": "surface-2",
                    "owner": "test-owner",
                    "created_at": "2024-01-02T00:00:00Z",
                    "updated_at": "2024-01-02T00:00:00Z",
                },
            ],
            "pagination": {
                "page": 1,
                "page_size": 20,
                "total_count": 2,
                "total_pages": 1,
                "has_next": False,
                "has_prev": False,
            },
        }

        respx.get("http://localhost:8080/api/v1/context-surfaces").mock(
            return_value=Response(200, json=mock_response)
        )

        result = await client.list_context_surfaces(admin_key=admin_key)
        assert len(result.context_surfaces) == 2


class TestAgentKeyOperations:
    """Test agent API key operations."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_agent_key_success(self, client):
        """Test successful agent key creation."""
        admin_key = "cs_admin_test123"
        surface_id = "engine_123"
        request = CreateAgentKeyRequest(
            name="test-agent",
        )

        mock_response = {
            "id": "key_456",
            "name": "test-agent",
            "owner": "test-owner",
            "key": "cs_agent_newkey456",
            "key_type": "agent",
            "context_surface_id": "engine_123",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }

        respx.post("http://localhost:8080/api/v1/context-surfaces/engine_123/agent-keys").mock(
            return_value=Response(201, json=mock_response)
        )

        result = await client.create_agent_key(surface_id, request, admin_key=admin_key)

        assert isinstance(result, AgentAPIKey)
        assert result.name == "test-agent"
        assert result.key == "cs_agent_newkey456"


class TestContextManager:
    """Test client as async context manager."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test using client as async context manager."""
        async with ContextSurfacesClient(base_url="http://localhost:8080") as client:
            assert client is not None
            assert client.base_url == "http://localhost:8080"


class TestURLPathJoining:
    """Test that base URLs with paths correctly join with relative URLs."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_base_url_with_path_joins_correctly(self):
        """Test that base URL with path correctly joins with relative endpoints."""
        client = ContextSurfacesClient(base_url="http://localhost:8080/api/v1")

        # Verify base_url has trailing slash after normalization
        assert client.base_url == "http://localhost:8080/api/v1/"

        # Mock the expected fully-qualified URL
        respx.get("http://localhost:8080/api/v1/health").mock(
            return_value=Response(200, json={"status": "UP"})
        )

        # Make request with relative path
        result = await client.health()
        assert result.status == "UP"

    @pytest.mark.asyncio
    @respx.mock
    async def test_base_url_with_context_surfaces_path(self):
        """Test base URL with context-surfaces path joins correctly."""
        client = ContextSurfacesClient(base_url="http://localhost:8080/context-surfaces")

        # Verify base_url has trailing slash
        assert client.base_url == "http://localhost:8080/context-surfaces/"

        # Mock admin key creation endpoint with complete response
        mock_response = {
            "id": "key-123",
            "key": "cs_admin_test123",
            "name": "test-key",
            "owner": "test-user",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        respx.post("http://localhost:8080/context-surfaces/api/v1/keys").mock(
            return_value=Response(200, json=mock_response)
        )

        # Make request with relative path
        result = await client.create_admin_key(
            CreateAdminKeyRequest(name="test-key")
        )
        assert result.key == "cs_admin_test123"

    @pytest.mark.asyncio
    @respx.mock
    async def test_root_base_url_without_path(self):
        """Test that root base URL (without path) still works correctly."""
        client = ContextSurfacesClient(base_url="http://localhost:8080")

        # Verify root URL has no trailing slash
        assert client.base_url == "http://localhost:8080"

        # Mock health endpoint at root
        respx.get("http://localhost:8080/health").mock(
            return_value=Response(200, json={"status": "UP"})
        )

        result = await client.health()
        assert result.status == "UP"

    @pytest.mark.asyncio
    @respx.mock
    async def test_multi_level_path_joins_correctly(self):
        """Test base URL with multiple path levels joins correctly."""
        client = ContextSurfacesClient(base_url="http://api.example.com/services/context-surfaces/v2")

        # Verify base_url has trailing slash
        assert client.base_url == "http://api.example.com/services/context-surfaces/v2/"

        # Mock health check at deep path
        respx.get("http://api.example.com/services/context-surfaces/v2/health").mock(
            return_value=Response(200, json={"status": "UP"})
        )

        result = await client.health()
        assert result.status == "UP"
