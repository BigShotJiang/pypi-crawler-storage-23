"""Pytest configuration and shared fixtures for tests."""

import asyncio
import os
import subprocess

import pytest

from context_surfaces.cli.services.sm_auth import SMAuthService, SMSession

from .e2e_config import SM_QA_URL, get_e2e_credentials

# =============================================================================
# Metadata Redis (redis-metadata)
# Used by Context Surfaces for internal state: API keys, context surfaces, tools, events
# =============================================================================


def get_redis_host_addr() -> str:
    """Get Redis address for direct test connections.

    Uses REDIS_ADDR env var, defaults to localhost:6379.
    This is the address that tests running on the host machine use to connect
    directly to Redis for CCE backend state verification.
    """
    return os.getenv("REDIS_ADDR", "localhost:6379")


# =============================================================================
# Data Redis (redis-data)
# The Redis instance registered via API for user data and context retrieval
# =============================================================================


def get_redis_data_addr() -> str:
    """Get data Redis address for API registration and test data operations.

    Uses REDIS_DATA_ADDR env var, defaults to localhost:6380.
    This address is used both by tests and when registering Redis instances via API.
    """
    return os.getenv("REDIS_DATA_ADDR", "localhost:6380")


def get_redis_data_password() -> str:
    """Get data Redis password for authentication.

    Uses REDIS_DATA_PASSWORD env var, defaults to empty string (no password).
    """
    return os.getenv("REDIS_DATA_PASSWORD", "")


def get_redis_data_username() -> str:
    """Get data Redis username for authentication.

    Uses REDIS_DATA_USERNAME env var, defaults to empty string (default user).
    """
    return os.getenv("REDIS_DATA_USERNAME", "")


@pytest.fixture
def redis_host_addr() -> str:
    """Fixture providing metadata Redis address for direct test connections."""
    return get_redis_host_addr()


@pytest.fixture
def redis_data_addr() -> str:
    """Fixture providing data Redis address for API registration."""
    return get_redis_data_addr()


@pytest.fixture
def redis_data_password() -> str:
    """Fixture providing data Redis password."""
    return get_redis_data_password()


@pytest.fixture
def redis_data_username() -> str:
    """Fixture providing data Redis username."""
    return get_redis_data_username()


# =============================================================================
# SM QA session fixtures
# =============================================================================


@pytest.fixture
def sm_session() -> SMSession:
    """Login to SM QA, yield session, logout on teardown."""
    username, password = get_e2e_credentials()
    auth_service = SMAuthService(SM_QA_URL, timeout=30)

    session = asyncio.run(auth_service.login(username, password))
    yield session
    asyncio.run(auth_service.logout(session))


@pytest.fixture
def ctxctl_session() -> None:
    """Login to SM QA via ctxctl CLI, logout on teardown."""
    username, password = get_e2e_credentials()

    result = subprocess.run(
        [
            "ctxctl",
            "auth",
            "login",
            "--username",
            username,
            "--password",
            password,
            "--redis-cloud-url",
            SM_QA_URL,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, f"Failed to login: {result.stdout}{result.stderr}"
    yield
    subprocess.run(["ctxctl", "auth", "logout", "--session-only", "--force"], check=False)
