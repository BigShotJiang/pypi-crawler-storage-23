"""Tests for CLI credential manager."""

import json
import platform
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from context_surfaces.cli.services.credential_manager import CredentialManager


@pytest.fixture
def temp_creds_dir():
    """Create a temporary directory for credentials."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def cred_manager(temp_creds_dir, monkeypatch):
    """Create a credential manager with temporary directory."""
    # Patch the class attributes to use temp directory
    monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
    monkeypatch.setattr(CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc")
    # Disable keyring by default and provide a password
    return CredentialManager(use_keyring=False, password="test_password")


class TestCredentialManager:
    """Test credential manager functionality."""

    def test_init_creates_directory(self, temp_creds_dir, monkeypatch):
        """Test that initialization creates the config directory."""
        config_dir = temp_creds_dir / "subdir"
        assert not config_dir.exists()

        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(CredentialManager, "CREDENTIALS_FILE", config_dir / "credentials.enc")

        # Create manager without keyring (which triggers directory creation)
        CredentialManager(use_keyring=False, password="test_password")

        assert config_dir.exists()
        if platform.system() != "Windows":
            assert config_dir.stat().st_mode & 0o777 == 0o700

    def test_store_and_get_admin_key_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test storing and retrieving admin key using keyring."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            mock_keyring.set_password = MagicMock()
            mock_keyring.get_password = MagicMock(return_value="cs_admin_test123")
            mock_keyring.errors = MagicMock()

            # Store key
            cred_manager.store_admin_key("test-key", "cs_admin_test123")
            mock_keyring.set_password.assert_called_once_with(
                "context-surfaces", "admin:test-key", "cs_admin_test123"
            )

            # Get key
            key = cred_manager.get_admin_key("test-key")
            assert key == "cs_admin_test123"
            mock_keyring.get_password.assert_called_once_with("context-surfaces", "admin:test-key")

    def test_store_and_get_agent_key_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test storing and retrieving agent key using keyring."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            mock_keyring.set_password = MagicMock()
            mock_keyring.get_password = MagicMock(return_value="cs_agent_test456")
            mock_keyring.errors = MagicMock()

            # Store key
            cred_manager.store_agent_key("test-agent", "cs_agent_test456")
            mock_keyring.set_password.assert_called_once_with(
                "context-surfaces", "agent:test-agent", "cs_agent_test456"
            )

            # Get key
            key = cred_manager.get_agent_key("test-agent")
            assert key == "cs_agent_test456"
            mock_keyring.get_password.assert_called_once_with(
                "context-surfaces", "agent:test-agent"
            )

    def test_delete_admin_key_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test deleting admin key from keyring."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            mock_keyring.delete_password = MagicMock()
            mock_keyring.errors = MagicMock()

            result = cred_manager.delete_key("admin", "test-key")
            mock_keyring.delete_password.assert_called_once_with(
                "context-surfaces", "admin:test-key"
            )
            assert result is True

    def test_delete_agent_key_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test deleting agent key from keyring."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            mock_keyring.delete_password = MagicMock()
            mock_keyring.errors = MagicMock()

            result = cred_manager.delete_key("agent", "test-agent")
            mock_keyring.delete_password.assert_called_once_with(
                "context-surfaces", "agent:test-agent"
            )
            assert result is True

    def test_list_keys_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test listing all keys from keyring."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        # Create metadata file with key names
        metadata_file = temp_creds_dir / ".keyring_metadata.json"
        metadata_file.write_text(json.dumps({"admin": ["key1", "key2"], "agent": ["agent1"]}))

        keys = cred_manager.list_keys()

        assert "admin" in keys
        assert "agent" in keys
        assert "key1" in keys["admin"]
        assert "key2" in keys["admin"]
        assert "agent1" in keys["agent"]

    def test_fallback_to_encrypted_file_when_keyring_fails(self, temp_creds_dir, monkeypatch):
        """Test that credential manager falls back to encrypted file when keyring fails."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager with keyring enabled
        cred_manager = CredentialManager(use_keyring=True, password="test_password")

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            # Make keyring fail
            mock_keyring.errors.KeyringError = Exception
            mock_keyring.set_password = MagicMock(side_effect=Exception("Keyring not available"))

            # Store should succeed using encrypted file fallback
            cred_manager.store_admin_key("test-key", "cs_admin_test123")

            # Get should retrieve from encrypted file
            key = cred_manager.get_admin_key("test-key")
            assert key == "cs_admin_test123"

    def test_encrypted_file_permissions(self, temp_creds_dir, monkeypatch):
        """Test that encrypted credentials file has secure permissions."""
        # Patch the class attributes to use temp directory
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        # Create manager without keyring (uses encrypted file)
        cred_manager = CredentialManager(use_keyring=False, password="test_password")

        # Store a key
        cred_manager.store_admin_key("test-key", "cs_admin_test123")

        creds_file = temp_creds_dir / "credentials.enc"
        assert creds_file.exists()
        # Check file permissions are 0600 (owner read/write only) on non-Windows
        if platform.system() != "Windows":
            assert creds_file.stat().st_mode & 0o777 == 0o600

    def test_get_nonexistent_key_returns_none(self, cred_manager):
        """Test that getting a non-existent key returns None."""
        key = cred_manager.get_admin_key("nonexistent")
        assert key is None

    def test_delete_nonexistent_key_does_not_raise(self, cred_manager):
        """Test that deleting a non-existent key doesn't raise an error."""
        # Should not raise and should return False
        result = cred_manager.delete_key("admin", "nonexistent")
        assert result is False


class TestSMCredentials:
    """Tests for SM credential storage functionality."""

    def test_store_and_get_sm_credentials_encrypted(self, cred_manager):
        """Test storing and retrieving SM credentials using encrypted file."""
        cred_manager.store_sm_credentials("user@example.com", "password123")

        result = cred_manager.get_sm_credentials()
        assert result is not None
        assert result[0] == "user@example.com"
        assert result[1] == "password123"

    def test_store_and_get_sm_credentials_with_profile(self, cred_manager):
        """Test SM credentials are isolated by profile."""
        cred_manager.store_sm_credentials("user1@example.com", "pass1", profile="prod")
        cred_manager.store_sm_credentials("user2@example.com", "pass2", profile="dev")

        prod_creds = cred_manager.get_sm_credentials(profile="prod")
        dev_creds = cred_manager.get_sm_credentials(profile="dev")

        assert prod_creds == ("user1@example.com", "pass1")
        assert dev_creds == ("user2@example.com", "pass2")

    def test_get_sm_credentials_nonexistent_returns_none(self, cred_manager):
        """Test getting non-existent SM credentials returns None."""
        result = cred_manager.get_sm_credentials(profile="nonexistent")
        assert result is None

    def test_delete_sm_credentials(self, cred_manager):
        """Test deleting SM credentials."""
        cred_manager.store_sm_credentials("user@example.com", "password123")

        # Verify stored
        assert cred_manager.get_sm_credentials() is not None

        # Delete
        result = cred_manager.delete_sm_credentials()
        assert result is True

        # Verify deleted
        assert cred_manager.get_sm_credentials() is None

    def test_delete_nonexistent_sm_credentials(self, cred_manager):
        """Test deleting non-existent SM credentials returns False."""
        result = cred_manager.delete_sm_credentials(profile="nonexistent")
        assert result is False

    def test_has_sm_credentials(self, cred_manager):
        """Test checking if SM credentials exist."""
        assert cred_manager.has_sm_credentials() is False

        cred_manager.store_sm_credentials("user@example.com", "password123")
        assert cred_manager.has_sm_credentials() is True

        cred_manager.delete_sm_credentials()
        assert cred_manager.has_sm_credentials() is False

    def test_clear_all(self, cred_manager):
        """Test clearing all credentials."""
        # Store various credentials
        cred_manager.store_sm_credentials("user@example.com", "password123")
        cred_manager.store_admin_key("admin-key", "cs_admin_test123")
        cred_manager.store_agent_key("agent-key", "cs_agent_test456")

        # Verify all stored
        assert cred_manager.has_sm_credentials() is True
        assert cred_manager.get_admin_key("admin-key") is not None
        assert cred_manager.get_agent_key("agent-key") is not None

        # Clear all
        result = cred_manager.clear_all()

        assert result["sm_credentials"] == 1
        assert result["admin_keys"] == 1
        assert result["agent_keys"] == 1

        # Verify all cleared
        assert cred_manager.has_sm_credentials() is False
        assert cred_manager.get_admin_key("admin-key") is None
        assert cred_manager.get_agent_key("agent-key") is None

    def test_store_sm_credentials_with_keyring(self, temp_creds_dir, monkeypatch):
        """Test storing SM credentials using keyring."""
        monkeypatch.setattr(CredentialManager, "CONFIG_DIR", temp_creds_dir)
        monkeypatch.setattr(
            CredentialManager, "CREDENTIALS_FILE", temp_creds_dir / "credentials.enc"
        )

        cred_manager = CredentialManager(use_keyring=True, password="test_password")
        cred_manager._use_keyring = True

        with patch("context_surfaces.cli.services.credential_manager.keyring") as mock_keyring:
            mock_keyring.set_password = MagicMock()
            mock_keyring.get_password = MagicMock(
                return_value=json.dumps({"username": "user@example.com", "password": "pass123"})
            )
            mock_keyring.errors = MagicMock()

            # Store
            cred_manager.store_sm_credentials("user@example.com", "pass123")
            mock_keyring.set_password.assert_called_once()

            # Get
            result = cred_manager.get_sm_credentials()
            assert result == ("user@example.com", "pass123")
