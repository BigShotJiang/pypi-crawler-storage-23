"""End-to-end test for RQE (Redis Query Engine) flow using Python client.

This test validates the complete RQE workflow against QA environment:
1. Login to SM QA and create admin API key via gateway
2. Register Redis instance via CCE API
3. Create context surface with DataModel (auto-generates RQE tools)
4. Verify Redis indices are created
5. Insert test data into Redis
6. Create agent API key
7. Query data via MCP tools (text search, tag filter, range filter, get by ID)
8. Verify results match expected data
9. Cleanup
"""

import asyncio
import json
import os
from typing import TYPE_CHECKING, Any

import httpx
import pytest
import redis.asyncio as redis

if TYPE_CHECKING:
    from context_surfaces.cli.services.sm_auth import SMSession

from context_surfaces import (
    ContextSurfacesClient,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    RedisConnectionConfig,
    RegisterRedisInstanceRequest,
)
from context_surfaces.context_model import export_data_model
from context_surfaces.examples.reddish_models import (
    Customer,
    Order,
    Policy,
    Restaurant,
)
from context_surfaces.mcp_client import MCPClient

from .e2e_config import (
    CTX_API_URL,
    CTX_MCP_URL,
    SM_GATEWAY_URL,
    get_redis_config,
)

pytestmark = pytest.mark.e2e


async def create_admin_key(session: "SMSession", key_name: str) -> str:
    """Create an admin key using an existing SM session.

    Args:
        session: Active SM session
        key_name: Name for the admin key

    Returns:
        The admin API key string
    """
    if "localhost" in CTX_API_URL or "127.0.0.1" in CTX_API_URL:
        admin_key_url = f"{CTX_API_URL}/api/v1/keys"
    else:
        admin_key_url = f"{SM_GATEWAY_URL}/api/v1/keys"

    async with httpx.AsyncClient(
        timeout=30,
        cookies={"JSESSIONID": session.jsessionid},
    ) as client:
        response = await client.post(
            admin_key_url,
            json={"name": key_name, "description": "E2E test admin key"},
            headers={"X-CSRF-Token": session.csrf_token},
        )

        if response.status_code != 201:
            raise RuntimeError(
                f"Failed to create admin key: {response.status_code} - {response.text}"
            )

        admin_key_data = response.json()
        print(f"✓ Admin key created: {admin_key_data['id']}")
        return admin_key_data["key"]


@pytest.fixture
def data_model() -> dict[str, Any]:
    """Generate DataModel from ContextModel classes.

    This uses the Reddish example models (Customer, Order, Restaurant, Policy)
    and exports them to the same JSON structure as example_datamodel.json.
    """
    return export_data_model(
        title="Reddish Support Agent API",
        description="Comprehensive Reddish support system with vector-indexed policies and intelligent assistance",
        entities=[Customer, Order, Restaurant, Policy],
    )


@pytest.mark.asyncio
async def test_rqe_e2e_flow(sm_session: "SMSession", data_model: dict[str, Any]):
    """Test complete RQE flow from context surface creation to MCP tool execution.

    This test runs against the QA environment:
    - Admin key creation via SM gateway (session from fixture)
    - All other operations via CCE API
    """
    redis_server_addr, redis_client_addr, redis_username, redis_password = get_redis_config()

    # Check if TLS should be used (default true for Redis Cloud, can be disabled for local)
    redis_tls = os.getenv("REDIS_DATA_TLS", "true").lower() in ("true", "1", "yes")

    admin_key = None
    redis_instance_id = None
    surface_id = None
    agent_key = None
    redis_client = None

    try:
        # Step 1: Create admin API key via gateway
        print("\n=== Step 1: Create admin API key ===")
        print(f"✓ Logged in as {sm_session.user_email}")
        admin_key = await create_admin_key(sm_session, "E2E Test Admin")

        # Create Redis client for direct data operations (uses client address)
        redis_creds = ""
        if redis_username and redis_password:
            redis_creds = f"{redis_username}:{redis_password}@"
        elif redis_password:
            redis_creds = f":{redis_password}@"
        elif redis_username:
            redis_creds = f"{redis_username}@"
        redis_url = f"redis://{redis_creds}{redis_client_addr}"
        redis_client = redis.from_url(redis_url, decode_responses=True)

        # Step 2: Register Redis instance via CCE API (uses server address)
        print("\n=== Step 2: Registering Redis instance via CCE API ===")
        print(
            f"    Server address: {redis_server_addr}, Client address: {redis_client_addr}, Username: {redis_username or '(default)'}, TLS: {redis_tls}"
        )
        async with ContextSurfacesClient(CTX_API_URL) as client:
            redis_instance = await client.register_redis_instance(
                RegisterRedisInstanceRequest(
                    name="E2E Test Redis Instance",
                    description="Redis instance for E2E RQE testing",
                    connection_config=RedisConnectionConfig(
                        addr=redis_server_addr,
                        username=redis_username,
                        password=redis_password,
                        db=0,
                        tls_enabled=redis_tls,
                        pool_size=10,
                        min_idle_conns=2,
                    ),
                    metadata={"test": "e2e"},
                ),
                admin_key=admin_key,
            )
            redis_instance_id = redis_instance.id
            print(f"✓ Redis instance registered: {redis_instance_id}")

            # Step 3: Create context surface with DataModel
            print("\n=== Step 3: Creating context surface with DataModel ===")
            surface = await client.create_context_surface(
                CreateContextSurfaceRequest(
                    name="E2E Test Surface",
                    description="Context surface for E2E RQE testing",
                    data_model=data_model,
                    redis_instance_id=redis_instance_id,
                ),
                admin_key=admin_key,
            )
            surface_id = surface.id
            print(f"✓ Context surface created: {surface_id}")
            print(f"✓ Generated tools: {surface.tools}")

            # Verify expected tools were generated
            expected_tools = [
                "search_customer_by_text",
                "filter_customer_by_account_status",
                "get_customer_by_id",
                "filter_order_by_customer_id",
                "find_order_by_order_total_range",
                "filter_order_by_status",
                "get_order_by_id",
            ]
            for tool in expected_tools:
                assert tool in surface.tools, f"Expected tool {tool} not found in generated tools"
            print("✓ All expected tools generated")

        # Step 4: Verify Redis indices are created
        print("\n=== Step 4: Verifying Redis indices ===")
        await asyncio.sleep(0.5)  # Wait for indices to be created

        # Check if Customer index exists
        try:
            await redis_client.execute_command("FT.INFO", "idx:customer")
            print("✓ Customer index exists")
        except redis.ResponseError as e:
            pytest.fail(f"Customer index not found: {e}")

        # Check if Order index exists
        try:
            await redis_client.execute_command("FT.INFO", "idx:order")
            print("✓ Order index exists")
        except redis.ResponseError as e:
            pytest.fail(f"Order index not found: {e}")

        # Step 5: Insert test data into Redis
        print("\n=== Step 5: Inserting test data ===")

        # Insert customers (matching Customer model fields)
        customers = [
            {
                "id": 1,
                "email": "john@example.com",
                "phone": "+1-555-0101",
                "account_status": "active",
                "customer_tier": "dashpass",
                "city": "San Francisco",
                "lifetime_value": 1250.50,
            },
            {
                "id": 2,
                "email": "jane@example.com",
                "phone": "+1-555-0102",
                "account_status": "active",
                "customer_tier": "premium",
                "city": "New York",
                "lifetime_value": 850.25,
            },
            {
                "id": 3,
                "email": "bob@example.com",
                "phone": "+1-555-0103",
                "account_status": "suspended",
                "customer_tier": "regular",
                "city": "Los Angeles",
                "lifetime_value": 320.00,
            },
        ]

        for customer in customers:
            key = f"customer:{customer['id']}"
            await redis_client.execute_command("JSON.SET", key, "$", json.dumps(customer))
            print(f"✓ Inserted customer: {key}")

        # Insert orders (matching Order model fields)
        orders = [
            {
                "id": 1,
                "customer_id": 1,
                "restaurant_id": 101,
                "order_total": 99.99,
                "status": "delivered",
                "special_instructions": "Leave at door",
            },
            {
                "id": 2,
                "customer_id": 1,
                "restaurant_id": 102,
                "order_total": 149.50,
                "status": "in_transit",
                "special_instructions": "Ring doorbell",
            },
            {
                "id": 3,
                "customer_id": 2,
                "restaurant_id": 101,
                "order_total": 75.00,
                "status": "delivered",
                "special_instructions": "",
            },
            {
                "id": 4,
                "customer_id": 3,
                "restaurant_id": 103,
                "order_total": 200.00,
                "status": "cancelled",
                "special_instructions": "Call on arrival",
            },
        ]

        for order in orders:
            key = f"order:{order['id']}"
            await redis_client.execute_command("JSON.SET", key, "$", json.dumps(order))
            print(f"✓ Inserted order: {key}")

        # Wait for indices to update
        await asyncio.sleep(0.5)

        # Step 6: Create agent API key
        print("\n=== Step 6: Creating agent API key ===")
        async with ContextSurfacesClient(CTX_API_URL) as client:
            agent_key_obj = await client.create_agent_key(
                surface_id,
                CreateAgentKeyRequest(
                    name="E2E Test Agent", description="Agent key for E2E testing"
                ),
                admin_key=admin_key,
            )
            agent_key = agent_key_obj.key
            print(f"✓ Agent key created: {agent_key_obj.id}")

        # Step 7: Query data via MCP tools
        print("\n=== Step 7: Querying data via MCP tools ===")

        async with MCPClient(mcp_url=CTX_MCP_URL, agent_key=agent_key) as mcp:
            # Test 7a: Search customers by text
            print("\n--- Test 7a: Search customers by text (query='john') ---")
            result = await mcp.call_tool("search_customer_by_text", {"query": "john", "limit": 10})
            print(f"Search result: {result}")

            # Verify we got results and they contain john@example.com
            assert result is not None, "Search should return results"
            result_str = json.dumps(result)
            assert "john@example.com" in result_str, (
                "Search results should contain john@example.com"
            )
            print("✓ Text search verified: found john@example.com")

            # Test 7b: Filter customers by account status
            print("\n--- Test 7b: Filter customers by account_status='active' ---")
            result = await mcp.call_tool(
                "filter_customer_by_account_status", {"value": "active", "limit": 10}
            )
            print(f"Filter result: {result}")

            # Verify we got results and they contain active customers
            assert result is not None, "Filter should return results"
            result_str = json.dumps(result)
            # Should find at least one of the active customers (john or jane)
            has_active_customer = (
                "john@example.com" in result_str or "jane@example.com" in result_str
            )
            assert has_active_customer, "Filter results should contain active customers"
            # Should NOT contain suspended customer
            assert "bob@example.com" not in result_str, (
                "Filter results should not contain suspended customer"
            )
            print("✓ Tag filter verified: found active customers only")

            # Test 7c: Find orders by order_total range
            print("\n--- Test 7c: Find orders by order_total range [50, 150] ---")
            result = await mcp.call_tool(
                "find_order_by_order_total_range",
                {"min_value": 50.0, "max_value": 150.0, "limit": 10},
            )
            print(f"Range result: {result}")

            # Verify we got results with orders in the range [50, 150]
            assert result is not None, "Range query should return results"
            result_str = json.dumps(result)
            # Should find orders with order_total: 99.99, 149.50, 75.00 (all in range)
            # Should NOT find order with 200.00 (out of range)
            assert "200" not in result_str, (
                "Range results should not contain order with total_amount=200"
            )
            print("✓ Range filter verified: found orders in range [50, 150]")

            # Test 7d: Get customer by ID
            print("\n--- Test 7d: Get customer by id='1' ---")
            result = await mcp.call_tool("get_customer_by_id", {"id": "1"})
            print(f"Get result: {result}")

            # Verify we got the specific customer with id=1
            assert result is not None, "Get by ID should return result"
            result_str = json.dumps(result)
            assert "john@example.com" in result_str, (
                "Get by ID should return customer with id=1 (john@example.com)"
            )
            print("✓ Get by ID verified: found customer with id=1")

        print("\n=== ✓ All E2E tests passed! ===")

    finally:
        # Step 8: Cleanup
        print("\n=== Step 8: Cleanup ===")

        if redis_client:
            # Drop Redis indices
            try:
                await redis_client.execute_command("FT.DROPINDEX", "idx:customer")
                print("✓ Dropped customer index")
            except redis.ResponseError:
                pass

            try:
                await redis_client.execute_command("FT.DROPINDEX", "idx:order")
                print("✓ Dropped order index")
            except redis.ResponseError:
                pass

            # Delete test data
            for i in range(1, 4):
                await redis_client.delete(f"customer:{i}")
            for i in range(1, 5):
                await redis_client.delete(f"order:{i}")
            print("✓ Deleted test data")

            await redis_client.aclose()

        # Delete context surface and Redis instance (if created)
        if admin_key:
            try:
                async with ContextSurfacesClient(CTX_API_URL) as client:
                    if surface_id:
                        await client.delete_context_surface(surface_id, admin_key=admin_key)
                        print(f"✓ Deleted context surface: {surface_id}")

                    if redis_instance_id:
                        await client.delete_redis_instance(redis_instance_id, admin_key=admin_key)
                        print(f"✓ Deleted Redis instance: {redis_instance_id}")
            except Exception as e:
                print(f"Warning: Failed to delete resources: {e}")

        print("✓ Cleanup complete")
