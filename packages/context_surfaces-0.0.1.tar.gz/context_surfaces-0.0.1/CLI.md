# Context Surfaces CLI

Enterprise-grade command-line interface for the Context Surfaces.

## Design Principles

### Security First
- **No plaintext credentials in commands**: API keys never appear in shell history
- **Secure credential storage**: Uses OS keyring (macOS Keychain, Windows Credential Manager, Linux Secret Service)
- **Fallback to encrypted config**: AES-256 encrypted config file with user-specific key
- **Environment variable support**: For CI/CD and containerized environments
- **Audit logging**: All operations logged with timestamps and user context
- **Least privilege**: Agent keys used by default, admin keys only when required

### Architecture
- **Thin CLI layer**: Click/Typer for argument parsing, delegates to service layer
- **Service layer**: Business logic in `src/context_surfaces/cli/services/`
- **Credential management**: Separate `CredentialManager` class handles all auth
- **Output formatting**: Structured output (JSON, YAML, table) via `OutputFormatter`
- **Error handling**: Consistent error messages with actionable suggestions

### User Experience
- **Progressive disclosure**: Simple commands for common tasks, advanced options available
- **Helpful defaults**: Sensible defaults from config, environment, or conventions
- **Rich output**: Color-coded tables, progress bars, and status indicators
- **Interactive mode**: Prompts for missing required values (can be disabled with `--non-interactive`)
- **Dry-run support**: Preview operations before execution with `--dry-run`

## Installation

```bash
pip install context-surfaces

# Or with uv
uv pip install context-surfaces

# Verify installation
ctxctl --version
ctxctl --help
```

## Configuration

### Configuration Hierarchy (highest to lowest priority)

1. **Command-line flags**: `--api-url`, `--admin-key`, etc.
2. **Environment variables**: `CTX_API_URL`, `CTX_ADMIN_KEY`, etc.
3. **Config file**: `~/.config/cce/config.yaml` or `CTX_CONFIG_FILE`
4. **OS Keyring**: Stored credentials via `keyring` library
5. **Defaults**: Built-in defaults (localhost URLs)

### Initial Setup

```bash
# Manual configuration
ctxctl config set api_url https://cce.example.com
ctxctl config set mcp-url https://cce.example.com/mcp
ctxctl config set redis_cloud_url https://app.redislabs.com

# Store admin key securely (uses OS keyring)
ctxctl auth login --admin-key <key>

# Or login with Redis Cloud session credentials
ctxctl auth login --username user@example.com --redis-cloud-url https://app.redislabs.com

# Or set via environment (for CI/CD)
export CTX_ADMIN_KEY=<key>
export CTX_API_URL=https://cce.example.com
```

### Configuration File Format

```yaml
# ~/.config/cce/config.yaml
api_url: https://cce.example.com
mcp_url: https://cce.example.com/mcp
redis_cloud_url: https://app.redislabs.com  # Redis Cloud URL for session login
default_output_format: table  # table, json, yaml
color_output: true
log_level: info  # debug, info, warning, error
timeout: 30  # seconds

# Optional: default context for operations
default_context_surface: my-surface-id
default_profile: production  # Supports multiple profiles
```

## Command Structure

```
ctxctl
├── config          # Configuration management
├── auth            # Authentication and credential management
├── admin           # Admin key operations
├── surface         # Context surface CRUD
├── agent           # Agent key operations
├── redis           # Redis instance management
├── tools           # MCP tool operations
└── datamodel       # DataModel operations
```

## Commands

### Global Flags

All commands support these global flags:

```bash
--api-url TEXT          # API base URL (default: from config)
--mcp-url TEXT          # MCP endpoint URL (default: from config)
--admin-key TEXT        # Admin API key (default: from keyring/env)
--output FORMAT         # Output format: table, json, yaml (default: table)
--no-color              # Disable colored output
--verbose, -v           # Verbose output (can be repeated: -vv, -vvv)
--quiet, -q             # Suppress non-error output
--non-interactive       # Disable interactive prompts
--dry-run               # Preview operation without executing
--profile TEXT          # Use specific config profile
--help, -h              # Show help message
```

### 1. Configuration Management

```bash
# Initialize configuration (interactive wizard)
ctxctl config init

# View current configuration
ctxctl config show

# Set configuration value
ctxctl config set <key> <value>
ctxctl config set api-url https://cce.example.com
ctxctl config set default-output-format json

# Get configuration value
ctxctl config get <key>

# List all configuration
ctxctl config list

# Edit configuration file
ctxctl config edit

# Validate configuration
ctxctl config validate

# Reset to defaults
ctxctl config reset [--confirm]

# Profile management
ctxctl config profile create <name>
ctxctl config profile list
ctxctl config profile use <name>
ctxctl config profile delete <name>
```

### 2. Authentication

```bash
# Login with admin key (stores in OS keyring)
ctxctl auth login --admin-key <key>
ctxctl auth login  # Interactive prompt

# Login with Redis Cloud session credentials
ctxctl auth login --username user@example.com --redis-cloud-url https://app.redislabs.com
ctxctl auth login --username user@example.com  # Uses redis_cloud_url from profile config

# Login with agent key
ctxctl auth login --agent-key <key> --surface-id <id>

# Show current authentication status
ctxctl auth status

# Logout (remove stored credentials)
ctxctl auth logout

# Validate current credentials
ctxctl auth validate

# Rotate credentials (create new, delete old)
ctxctl auth rotate --admin-key <old-key>
```

### 3. Admin Key Management

```bash
# Create admin key
ctxctl admin create --name "Production Admin" --owner "ops-team" \
  --description "Admin key for production operations"

# List admin keys (requires admin key)
ctxctl admin list

# Validate admin key
ctxctl admin validate <key>

# Delete admin key (requires different admin key)
ctxctl admin delete <key-id> [--confirm]
```

### 4. Context Surface Management

```bash
# Create context surface
ctxctl surface create --name "My Surface" \
  --description "Production context surface" \
  --tools search,filter,get \
  --redis-instance-id <id>

# Create with DataModel from file
ctxctl surface create --name "My Surface" \
  --datamodel ./datamodel.json \
  --redis-instance-id <id>

# Create with DataModel from Python models
ctxctl surface create --name "My Surface" \
  --datamodel-python ./models.py \
  --redis-instance-id <id>

# List context surfaces
ctxctl surface list [--page 1] [--page-size 20]

# Get context surface details
ctxctl surface get <surface-id>

# Update context surface
ctxctl surface update <surface-id> \
  --name "Updated Name" \
  --description "Updated description" \
  --tools search,filter,get,create

# Delete context surface
ctxctl surface delete <surface-id> [--confirm]

# Show context surface statistics
ctxctl surface stats <surface-id>
```

### 5. Agent Key Management

```bash
# Create agent key for context surface
ctxctl agent create --surface-id <id> \
  --name "Production Agent" \
  --description "Agent for production use"

# Create agent key with access tags for ACL filtering (single tenant)
ctxctl agent create --surface-id <id> \
  --name "Tenant Agent" \
  --access-tags '{"tenant": ["acme"]}'

# Create agent key with multi-value access tags (multiple tenants)
ctxctl agent create --surface-id <id> \
  --name "Multi-Tenant Agent" \
  --access-tags '{"tenant": ["acme", "globex"], "department": ["sales"]}'

# List agent keys for context surface
ctxctl agent list --surface-id <id>

# Get agent key details
ctxctl agent get <key-id>

# Delete agent key
ctxctl agent delete <key-id> [--confirm]

# Test agent key
ctxctl agent test <key> --surface-id <id>
```

**Access Tags:**
- Use `--access-tags` to create agent keys with entity-level ACL filtering
- Format: JSON object with string keys and arrays of string values (e.g., `'{"tenant": ["acme", "globex"]}'`)
- Single-value tags can also be provided as strings for convenience (e.g., `'{"tenant": "acme"}'` is auto-converted to `'{"tenant": ["acme"]}'`)
- Agent keys with access tags only see records that match their tags (OR logic)
- Agent keys without access tags only see public records

### 6. Redis Instance Management

```bash
# Register Redis instance
ctxctl redis create --name "Production Redis" \
  --addr "redis.example.com:6379" \
  --password <password> \
  --db 0 \
  --tls \
  --pool-size 20

# List Redis instances
ctxctl redis list

# Get Redis instance details
ctxctl redis get <instance-id>

# Update Redis instance
ctxctl redis update <instance-id> \
  --name "Updated Name" \
  --pool-size 30

# Delete Redis instance
ctxctl redis delete <instance-id> [--confirm]

# Test Redis connection
ctxctl redis test <instance-id>

# Show Redis instance statistics
ctxctl redis stats <instance-id>
```

### 7. MCP Tool Operations

```bash
# List available tools for agent
ctxctl tools list --agent-key <key>

# Get tool details
ctxctl tools get <tool-name> --agent-key <key>

# Call tool (execute)
ctxctl tools call <tool-name> \
  --agent-key <key> \
  --args '{"query": "search term", "limit": 10}'

# Call tool with args from file
ctxctl tools call <tool-name> \
  --agent-key <key> \
  --args-file ./args.json

# Call tool interactively
ctxctl tools call <tool-name> --agent-key <key> --interactive

# Test tool execution
ctxctl tools test <tool-name> --agent-key <key> --dry-run

# Show tool execution history
ctxctl tools history --agent-key <key> [--limit 50]
```

### 8. DataModel Operations

```bash
# Validate DataModel file
ctxctl datamodel validate ./datamodel.json

# Generate DataModel from Python models
ctxctl datamodel generate ./models.py \
  --output ./datamodel.json \
  --title "My API" \
  --description "API description"

# Show DataModel schema
ctxctl datamodel schema

# Convert DataModel formats
ctxctl datamodel convert ./datamodel.json --output ./datamodel.yaml

# Diff two DataModels
ctxctl datamodel diff ./old.json ./new.json

# Apply DataModel to existing context surface
ctxctl datamodel apply <surface-id> ./datamodel.json [--dry-run]
```

## Output Formats

### Table Format (default)

```bash
$ ctxctl surface list
┏━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ ID                 ┃ Name           ┃ Description              ┃ Tools      ┃
┡━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━┩
│ cs-123             │ My Surface     │ Production surface       │ 12         │
│ cs-456             │ Test Surface   │ Testing environment      │ 8          │
└────────────────────┴────────────────┴──────────────────────────┴────────────┘
```

### JSON Format

```bash
$ ctxctl surface list --output json
{
  "context_surfaces": [
    {
      "id": "cs-123",
      "name": "My Surface",
      "description": "Production surface",
      "tools": ["search", "filter", "get"],
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total_count": 2
  }
}
```

### YAML Format

```bash
$ ctxctl surface get cs-123 --output yaml
id: cs-123
name: My Surface
description: Production surface
tools:
  - search
  - filter
  - get
created_at: '2024-01-15T10:30:00Z'
```

## Security Features

### Credential Storage

1. **OS Keyring (Primary)**
   - macOS: Keychain
   - Windows: Credential Manager
   - Linux: Secret Service (GNOME Keyring, KWallet)

2. **Encrypted Config (Fallback)**
   - AES-256-GCM encryption
   - Key derived from user password + machine ID
   - Stored in `~/.config/cce/credentials.enc`

3. **Environment Variables (CI/CD)**
   - `CTX_ADMIN_KEY`
   - `CTX_AGENT_KEY`
   - `CTX_API_URL`
   - `CTX_MCP_URL`
   - `CTX_REDIS_CLOUD_URL`

### Audit Logging

All operations are logged to `~/.config/cce/audit.log`:

```
2024-01-15T10:30:00Z [INFO] user=ops-team action=surface.create surface_id=cs-123 status=success
2024-01-15T10:31:00Z [INFO] user=ops-team action=agent.create agent_id=agent-456 surface_id=cs-123 status=success
2024-01-15T10:32:00Z [ERROR] user=ops-team action=surface.delete surface_id=cs-789 status=failed error="not found"
```

### Permission Checks

- Admin operations require admin key
- Agent operations require agent key
- Automatic key type detection
- Clear error messages for permission issues

## Error Handling

### User-Friendly Errors

```bash
$ ctxctl surface create --name "Test"
Error: Missing required option: --redis-instance-id

Suggestion: Specify a Redis instance ID with --redis-instance-id <id>
Or list available instances with: ctxctl redis list

$ ctxctl tools call search --agent-key invalid-key
Error: Authentication failed

Suggestion: Verify your agent key with: ctxctl auth validate
Or login again with: ctxctl auth login --agent-key <key>
```

### Exit Codes

- `0`: Success
- `1`: General error
- `2`: Invalid arguments
- `3`: Authentication error
- `4`: Not found error
- `5`: Permission denied
- `6`: Network error
- `7`: Validation error

## Examples

### Complete Workflow

```bash
# 1. Initial setup
ctxctl config init
ctxctl auth login --admin-key <admin-key>

# 2. Register Redis instance
ctxctl redis create --name "Production Redis" \
  --addr "redis.example.com:6379" \
  --password <password> \
  --tls

# 3. Create context surface with DataModel
ctxctl surface create --name "Support Surface" \
  --datamodel ./support-datamodel.json \
  --redis-instance-id <redis-id>

# 4. Create agent key
ctxctl agent create --surface-id <surface-id> \
  --name "Support Agent"

# 5. Test tools
ctxctl tools list --agent-key <agent-key>
ctxctl tools call search_customer_by_text \
  --agent-key <agent-key> \
  --args '{"query": "john", "limit": 10}'
```

### CI/CD Integration

```bash
#!/bin/bash
# deploy.sh

export CTX_ADMIN_KEY="${ADMIN_KEY_SECRET}"
export CTX_API_URL="https://cce.production.example.com"

# Create context surface
SURFACE_ID=$(ctxctl surface create \
  --name "Production Surface" \
  --datamodel ./datamodel.json \
  --redis-instance-id "${REDIS_INSTANCE_ID}" \
  --output json | jq -r '.id')

# Create agent key
AGENT_KEY=$(ctxctl agent create \
  --surface-id "${SURFACE_ID}" \
  --name "Production Agent" \
  --output json | jq -r '.key')

# Store agent key in secrets manager
aws secretsmanager put-secret-value \
  --secret-id cce-agent-key \
  --secret-string "${AGENT_KEY}"
```

## Testing

The CLI includes comprehensive tests:

```bash
# Run all CLI tests
pytest tests/cli/ -v

# Run specific test categories
pytest tests/cli/test_auth.py -v
pytest tests/cli/test_surface.py -v
pytest tests/cli/test_tools.py -v

# Test with real server (E2E)
pytest tests/cli/test_e2e_cli.py -v -m e2e
```

## Implementation Notes

### Directory Structure

```
src/context_surfaces/cli/
├── __init__.py
├── main.py                 # Entry point, CLI app setup
├── commands/               # Command implementations (thin layer)
│   ├── __init__.py
│   ├── config.py
│   ├── auth.py
│   ├── admin.py
│   ├── surface.py
│   ├── agent.py
│   ├── redis.py
│   ├── tools.py
│   └── datamodel.py
├── services/               # Business logic (thick layer)
│   ├── __init__.py
│   ├── credential_manager.py
│   ├── config_manager.py
│   ├── output_formatter.py
│   ├── audit_logger.py
│   ├── surface_service.py
│   ├── agent_service.py
│   ├── redis_service.py
│   ├── tools_service.py
│   └── datamodel_service.py
├── models/                 # CLI-specific models
│   ├── __init__.py
│   └── config.py
└── utils/                  # Utilities
    ├── __init__.py
    ├── validators.py
    ├── formatters.py
    └── helpers.py
```

### Key Dependencies

- `typer`: CLI framework with type hints
- `rich`: Beautiful terminal output
- `keyring`: Secure credential storage
- `cryptography`: Encryption for config fallback
- `pyyaml`: YAML config support
- `click`: Low-level CLI utilities (via typer)
