# Release Process

## Versioning

Versions are derived automatically from git tags using `hatch-vcs` (setuptools-scm). There is **no hardcoded version** in `pyproject.toml`.

**Tag format:** `python-v<MAJOR>.<MINOR>.<PATCH>` (e.g., `python-v0.1.0`, `python-v1.0.0`)

The `python-v` prefix scopes version detection to this package, so tags from other monorepo components are ignored.

## Release (PyPI)

1. Ensure all changes are merged to `main`
2. Tag the release:

```bash
git tag python-v0.2.0
git push origin python-v0.2.0
```

3. The `python-publish.yml` workflow triggers automatically
4. The build job produces the sdist and wheel with version `0.2.0`
5. The `publish-pypi` job publishes to PyPI via trusted publishing (OIDC)

## Dev Builds (JFrog Artifactory)

Every push to `main` and every pull request with python changes publishes a dev version to JFrog Artifactory, but only after both the Python CI and all E2E tests pass.

The CI workflow (`ci.yml`) detects file changes and calls `python-publish.yml` when python-related files are modified. The `python-publish` job depends on the `python` and `e2e` jobs completing successfully before publishing proceeds. The version is derived from the distance to the last `python-v*` tag, e.g., `0.1.0.dev5+gabc1234`.

## Manual Builds

Use `workflow_dispatch` from the GitHub Actions UI to trigger a build and publish manually.

## Initial Setup

Before the first build, a baseline tag must exist so `setuptools-scm` can compute versions:

```bash
git tag python-v0.0.0
git push origin python-v0.0.0
```

### GitHub Environments

| Environment | Purpose | Secrets/Variables |
|-------------|---------|-------------------|
| `pypi` | Production PyPI publishing (OIDC) | None (trusted publishing) |
| `artifactory` | JFrog dev publishing | `ARTIFACTORY_PUSH_USERNAME` (var), `ARTIFACTORY_PUSH_TOKEN` (secret) |

### PyPI Trusted Publishing (OIDC)

Configure at https://pypi.org/manage/account/publishing/:

- **PyPI project name:** `context-surfaces`
- **Owner:** `redislabsdev`
- **Repository:** `cloud-context-engine-pypi`
- **Workflow name:** `python-publish.yml`
- **Environment:** `pypi`
