"""Context Surfaces CLI module.

Imports are lazy to avoid pulling in CLI-only dependencies (typer, rich, …)
when only the core library is installed.
"""

__all__ = ["app"]


def __getattr__(name: str) -> object:
    if name == "app":
        from context_surfaces.cli.main import app

        return app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
