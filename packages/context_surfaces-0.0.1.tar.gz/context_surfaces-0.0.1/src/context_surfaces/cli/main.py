"""Context Surfaces CLI (ctxctl) - Main Application.

A best-in-class Typer CLI following 2024 best practices with:
- Command groups for organization
- Annotated type hints for better documentation
- Async support with proper wrappers
- Dependency injection via Context
- Rich error messages and output
- Global options (--output, --no-color, --profile)
"""

import asyncio
import sys
from collections.abc import Callable
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any, TypeVar

import typer
from rich.console import Console
from rich.panel import Panel
from typing_extensions import ParamSpec

from context_surfaces.cli.models.output import (
    JsonOutput,
    TableOutput,
    YamlOutput,
)
from context_surfaces.cli.services import (
    ConfigManager,
    OutputFormat,
    OutputFormatter,
)
from context_surfaces.cli.services.audit_logger import AuditLogger
from context_surfaces.cli.services.credential_manager import CredentialManager
from context_surfaces.exceptions import ContextSurfacesError

if TYPE_CHECKING:
    from context_surfaces.cli.services.config_manager import ProfileConfig

# Type variables for generic async wrapper
P = ParamSpec("P")
T = TypeVar("T")

# Initialize console for rich output
console = Console()

# Create main app
app = typer.Typer(
    name="ctxctl",
    help="Context Surfaces CLI - Manage context surfaces, Redis instances, and MCP tools",
    add_completion=True,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


# ============================================================================
# Context Object for Dependency Injection
# ============================================================================


class CLIContext:
    """Context object passed between commands for dependency injection.

    Provides access to:
    - ConfigManager: Configuration management
    - CredentialManager: Secure credential storage
    - OutputFormatter: Output formatting (table/json/yaml)
    - AuditLogger: Audit logging
    - Profile settings and global options
    """

    def __init__(
        self,
        config_manager: ConfigManager,
        credential_manager: CredentialManager,
        output_formatter: OutputFormatter,
        audit_logger: AuditLogger,
        profile: str,
        output_format: OutputFormat,
        no_color: bool,
    ) -> None:
        """Initialize CLI context.

        Args:
            config_manager: Configuration manager instance
            credential_manager: Credential manager instance
            output_formatter: Output formatter instance
            audit_logger: Audit logger instance
            profile: Active profile name
            output_format: Output format (table/json/yaml)
            no_color: Whether to disable colored output
        """
        self.config_manager = config_manager
        self.credential_manager = credential_manager
        self.output_formatter = output_formatter
        self.audit_logger = audit_logger
        self.profile = profile
        self.output_format = output_format
        self.no_color = no_color

    def get_profile_config(self) -> Any:
        """Get configuration for the active profile.

        Returns:
            ProfileConfig for the active profile
        """
        config = self.config_manager.load_config()
        return config.profiles.get(self.profile, config.profiles[config.default_profile])


# ============================================================================
# Helper Functions
# ============================================================================


def async_command(func: Callable[P, Any]) -> Callable[P, Any]:
    """Decorator to run async functions in Typer commands.

    Wraps async functions with asyncio.run() for proper async support.
    Handles exceptions and provides rich error messages.

    Example:
        ```python
        @app.command()
        @async_command
        async def my_command(ctx: typer.Context):
            await some_async_operation()
        ```
    """

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> Any:
        try:
            return asyncio.run(func(*args, **kwargs))
        except ContextSurfacesError as e:
            console.print(f"[bold red]Error:[/bold red] {e}", style="red")
            raise typer.Exit(code=1) from e
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user[/yellow]")
            raise typer.Exit(code=130) from None
        except Exception as e:
            console.print(f"[bold red]Unexpected error:[/bold red] {e}", style="red")
            if "--debug" in sys.argv:
                raise
            raise typer.Exit(code=1) from e

    return wrapper


def handle_error(error: Exception, debug: bool = False) -> None:
    """Handle errors with rich formatting.

    Args:
        error: Exception to handle
        debug: Whether to show full traceback
    """
    if isinstance(error, ContextSurfacesError):
        console.print(
            Panel(
                f"[bold red]{type(error).__name__}:[/bold red] {error}",
                title="Error",
                border_style="red",
            )
        )
    else:
        console.print(
            Panel(
                f"[bold red]Unexpected Error:[/bold red] {error}",
                title="Error",
                border_style="red",
            )
        )

    if debug:
        console.print_exception()


def get_cli_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context from Typer context.

    Args:
        ctx: Typer context

    Returns:
        CLIContext instance
    """
    if ctx.obj is None:
        raise RuntimeError("CLI context not initialized")
    # We control the initialization in main_callback() where we always set ctx.obj = CLIContext(...)
    # So we can safely cast here - this is an appropriate use of cast()
    from typing import cast

    return cast("CLIContext", ctx.obj)


# ============================================================================
# Global Callback (runs before all commands)
# ============================================================================


@app.callback()
def main_callback(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            "-p",
            help="Configuration profile to use (development/staging/production)",
            envvar="CTX_PROFILE",
        ),
    ] = None,
    output: Annotated[
        OutputFormat | None,
        typer.Option(
            "--output",
            "-o",
            help="Output format",
            case_sensitive=False,
        ),
    ] = None,
    no_color: Annotated[
        bool,
        typer.Option(
            "--no-color",
            help="Disable colored output",
            envvar="CTX_NO_COLOR",
        ),
    ] = False,
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to config file",
            exists=False,
            dir_okay=False,
        ),
    ] = None,
    debug: Annotated[
        bool,
        typer.Option(
            "--debug",
            help="Enable debug mode with verbose output",
        ),
    ] = False,
) -> None:
    """Context Surfaces CLI - Manage context surfaces, API keys, and tools.

    Global options can be set via:
    - Command-line flags (highest priority)
    - Environment variables (CTX_PROFILE, CTX_NO_COLOR, etc.)
    - Config file (~/.config/ctxctl/config.yaml)
    - Defaults (lowest priority)
    """
    # Initialize config manager
    config_manager = ConfigManager(config_path=config_path)
    config = config_manager.load_config()

    # Determine active profile
    active_profile = profile or config.default_profile
    if active_profile not in config.profiles:
        console.print(
            f"[bold red]Error:[/bold red] Profile '{active_profile}' not found",
            style="red",
        )
        console.print(f"Available profiles: {', '.join(config.profiles.keys())}")
        raise typer.Exit(code=1)

    profile_config = config.profiles[active_profile]

    # Determine output format
    output_format = output or profile_config.default_output_format

    # Determine color setting
    use_color = not no_color and profile_config.color_output

    # Initialize services
    credential_manager = CredentialManager()
    output_formatter = OutputFormatter(color=use_color)
    audit_logger = AuditLogger()

    # Create and store CLI context
    ctx.obj = CLIContext(
        config_manager=config_manager,
        credential_manager=credential_manager,
        output_formatter=output_formatter,
        audit_logger=audit_logger,
        profile=active_profile,
        output_format=output_format,
        no_color=no_color,
    )

    # Set debug mode
    if debug:
        import logging

        logging.basicConfig(level=logging.DEBUG)


# ============================================================================
# Command Groups
# ============================================================================

# Config commands
config_app = typer.Typer(
    name="config",
    help="Manage CLI configuration and profiles",
    no_args_is_help=True,
)
app.add_typer(config_app)

# Auth commands
auth_app = typer.Typer(
    name="auth",
    help="Manage authentication and API keys",
    no_args_is_help=True,
)
app.add_typer(auth_app)

# Admin commands
admin_app = typer.Typer(
    name="admin",
    help="Admin API key management",
    no_args_is_help=True,
)
app.add_typer(admin_app)

# Context surface commands
surface_app = typer.Typer(
    name="surface",
    help="Context surface management",
    no_args_is_help=True,
)
app.add_typer(surface_app)

# Agent commands
agent_app = typer.Typer(
    name="agent",
    help="Agent API key management",
    no_args_is_help=True,
)
app.add_typer(agent_app)

# Redis commands
redis_app = typer.Typer(
    name="redis",
    help="Redis instance management",
    no_args_is_help=True,
)
app.add_typer(redis_app)

# Tools commands
tools_app = typer.Typer(
    name="tools",
    help="MCP tools management and invocation",
    no_args_is_help=True,
)
app.add_typer(tools_app)

# Data model commands
datamodel_app = typer.Typer(
    name="datamodel",
    help="Data model management and validation",
    no_args_is_help=True,
)
app.add_typer(datamodel_app)


# ============================================================================
# Config Commands
# ============================================================================


@config_app.command("show")
def config_show(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            "-p",
            help="Profile to show (defaults to active profile)",
        ),
    ] = None,
) -> None:
    """Show current configuration.

    Displays the active configuration including all settings
    from the specified profile or the currently active profile.

    Example:
        ctxctl config show
        ctxctl config show --profile production
    """
    cli_ctx = get_cli_context(ctx)
    config = cli_ctx.config_manager.load_config()

    # Determine which profile to show
    show_profile = profile or cli_ctx.profile

    if show_profile not in config.profiles:
        console.print(
            f"[bold red]Error:[/bold red] Profile '{show_profile}' not found",
            style="red",
        )
        raise typer.Exit(code=1)

    profile_config = config.profiles[show_profile]

    # Format output
    data = {
        "profile": show_profile,
        "default_profile": config.default_profile,
        "api_url": profile_config.api_url,
        "mcp_url": profile_config.mcp_url,
        "redis_cloud_url": profile_config.redis_cloud_url,
        "output_format": profile_config.default_output_format.value,
        "color_output": profile_config.color_output,
        "log_level": profile_config.log_level.value,
        "timeout": profile_config.timeout,
    }

    # Render based on output format
    output: JsonOutput | YamlOutput | TableOutput
    if cli_ctx.output_format == OutputFormat.JSON:
        output = JsonOutput(data=data)
    elif cli_ctx.output_format == OutputFormat.YAML:
        output = YamlOutput(data=data)
    else:  # TABLE
        output = TableOutput.from_dict(data, title=f"Profile: {show_profile}")

    cli_ctx.output_formatter.render(output)


@config_app.command("list")
def config_list(ctx: typer.Context) -> None:
    """List all available profiles.

    Shows all configured profiles with their basic settings.

    Example:
        ctxctl config list
    """
    cli_ctx = get_cli_context(ctx)
    config = cli_ctx.config_manager.load_config()

    profiles_data = []
    for name, profile_config in config.profiles.items():
        is_default = name == config.default_profile
        is_active = name == cli_ctx.profile

        profiles_data.append(
            {
                "name": name,
                "api_url": profile_config.api_url,
                "default": "✓" if is_default else "",
                "active": "✓" if is_active else "",
            }
        )

    # Render based on output format
    output: JsonOutput | YamlOutput | TableOutput
    if cli_ctx.output_format == OutputFormat.JSON:
        output = JsonOutput(data=profiles_data)
    elif cli_ctx.output_format == OutputFormat.YAML:
        output = YamlOutput(data=profiles_data)
    else:  # TABLE
        output = TableOutput.from_dicts(profiles_data, title="Profiles")

    cli_ctx.output_formatter.render(output)


@config_app.command("set")
def config_set(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Configuration key to set")],
    value: Annotated[str, typer.Argument(help="Configuration value")],
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            "-p",
            help="Profile to modify (defaults to active profile)",
        ),
    ] = None,
) -> None:
    """Set a configuration value.

    Updates a configuration value for the specified profile.

    Example:
        ctxctl config set api_url https://api.example.com
        ctxctl config set timeout 60 --profile production
    """
    cli_ctx = get_cli_context(ctx)
    target_profile = profile or cli_ctx.profile

    try:
        cli_ctx.config_manager.set(key, value, profile=target_profile)
        cli_ctx.config_manager.save_config()
        console.print(f"[green]✓[/green] Set {key}={value} for profile '{target_profile}'")

        # Log the configuration change
        cli_ctx.audit_logger.log_operation(
            user="cli",
            action="config_set",
            status="success",
            profile=target_profile,
            key=key,
        )
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Auth Commands
# ============================================================================


def _resolve_redis_cloud_url(redis_cloud_url: str | None, cli_ctx: "CLIContext") -> str:
    if redis_cloud_url is None:
        config = cli_ctx.config_manager.load_config()
        profile_config = config.profiles[cli_ctx.profile]
        redis_cloud_url = profile_config.redis_cloud_url
    if not redis_cloud_url:
        console.print(
            "[bold red]Error:[/bold red] --redis-cloud-url is required "
            "(or set it in your profile with: ctxctl config set redis_cloud_url <url>)",
        )
        raise typer.Exit(code=1)
    return redis_cloud_url


@auth_app.command("login")
def auth_login(
    ctx: typer.Context,
    key_name: Annotated[
        str | None,
        typer.Argument(help="Name for API key (omit for session login)"),
    ] = None,
    key_type: Annotated[
        str,
        typer.Option(
            "--type",
            "-t",
            help="Key type: admin or agent (only for API key login)",
        ),
    ] = "admin",
    username: Annotated[
        str | None,
        typer.Option(
            "--username",
            "-u",
            help="Username (email). Will prompt if not provided.",
        ),
    ] = None,
    password: Annotated[
        str | None,
        typer.Option(
            "--password",
            "-p",
            help="Password. Will prompt if not provided (recommended).",
        ),
    ] = None,
    redis_cloud_url: Annotated[
        str | None,
        typer.Option(
            "--redis-cloud-url",
            help="Redis Cloud URL (for session login). Falls back to profile config.",
        ),
    ] = None,
) -> None:
    """Authenticate with Redis Cloud.

    [bold]Without arguments:[/bold] Session-based login (prompts for credentials)
    [bold]With key_name:[/bold] Store an API key in secure storage

    [bold]Examples:[/bold]
        ctxctl auth login                           # Session login
        ctxctl auth login -u user@example.com       # Session login with username
        ctxctl auth login my-key --type admin       # Store admin API key
        ctxctl auth login my-agent --type agent     # Store agent API key
    """
    cli_ctx = get_cli_context(ctx)

    if key_name is not None:
        # API key login mode
        _auth_login_api_key(cli_ctx, key_name, key_type)
    else:
        # Session login mode
        resolved_url = _resolve_redis_cloud_url(redis_cloud_url, cli_ctx)
        _auth_login_session(cli_ctx, username, password, resolved_url)


def _auth_login_api_key(cli_ctx: CLIContext, key_name: str, key_type: str) -> None:
    """Handle API key login."""
    # Validate key type
    if key_type not in ["admin", "agent"]:
        console.print(
            "[bold red]Error:[/bold red] Key type must be 'admin' or 'agent'",
            style="red",
        )
        raise typer.Exit(code=1)

    # Prompt for API key (hidden input)
    api_key = typer.prompt(
        f"Enter {key_type} API key",
        hide_input=True,
    )

    # Validate key format
    expected_prefix = f"cs_{key_type}_"
    if not api_key.startswith(expected_prefix):
        console.print(
            f"[bold yellow]Warning:[/bold yellow] Key doesn't start with '{expected_prefix}'",
            style="yellow",
        )
        if not typer.confirm("Continue anyway?"):
            raise typer.Exit(code=0)

    # Store the key
    try:
        if key_type == "admin":
            cli_ctx.credential_manager.store_admin_key(key_name, api_key)
        else:
            cli_ctx.credential_manager.store_agent_key(key_name, api_key)

        console.print(f"[green]✓[/green] Stored {key_type} key '{key_name}' securely")

        # Log the authentication
        cli_ctx.audit_logger.log_auth(
            user="cli",
            action="api_key_login",
            status="success",
            key_name=key_name,
        )
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


def _auth_login_session(
    cli_ctx: CLIContext,
    username: str | None,
    password: str | None,
    redis_cloud_url: str,
) -> None:
    """Handle session-based login."""
    from context_surfaces.cli.services.sm_auth import (
        SMAuthService,
        SMLoginError,
        SMNetworkError,
    )

    # Prompt for credentials if not provided
    if username is None:
        username = typer.prompt("Username (email)")

    if password is None:
        password = typer.prompt("Password", hide_input=True)

    async def _login() -> None:
        try:
            auth_service = SMAuthService(
                redis_cloud_url, timeout=cli_ctx.config_manager.get("timeout")
            )
            session = await auth_service.login(username, password)

            # Save session to profile config
            config = cli_ctx.config_manager.load_config()
            profile_config = config.profiles[cli_ctx.profile]
            profile_config.jsessionid = session.jsessionid
            profile_config.csrf_token = session.csrf_token
            profile_config.redis_cloud_url = session.redis_cloud_url
            profile_config.session_expires_at = session.expires_at
            profile_config.session_user_email = session.user_email
            cli_ctx.config_manager.save_config(config)

            # Store credentials for auto-refresh
            cli_ctx.credential_manager.store_sm_credentials(username, password, cli_ctx.profile)

            console.print(f"[green]✓[/green] Logged in as [bold]{session.user_email}[/bold]")
            console.print(f"  Profile: {cli_ctx.profile}")
            console.print(f"  Redis Cloud URL: {session.redis_cloud_url}")
            if session.expires_at:
                from datetime import datetime

                remaining = session.expires_at - datetime.now()
                minutes = int(remaining.total_seconds() / 60)
                console.print(f"  Session expires in: {minutes} minutes")
            console.print("\n[dim]Credentials stored securely for automatic session refresh.[/dim]")

            # Log the authentication
            cli_ctx.audit_logger.log_auth(
                user=session.user_email,
                action="session_login",
                status="success",
            )

        except SMLoginError as e:
            console.print(f"[bold red]Login failed:[/bold red] {e}")
            cli_ctx.audit_logger.log_auth(
                user=username,
                action="session_login",
                status="failed",
                error=str(e),
            )
            raise typer.Exit(code=1) from e
        except SMNetworkError as e:
            console.print(f"[bold red]Network error:[/bold red] {e}")
            raise typer.Exit(code=1) from e

    import asyncio

    try:
        asyncio.run(_login())
    except typer.Exit:
        raise
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


def _build_items_to_clear(
    cli_ctx: CLIContext,
    profile_config: "ProfileConfig",
    clear_session: bool,
    clear_keys: bool,
) -> list[str]:
    """Build list of items that will be cleared for user confirmation."""
    items: list[str] = []
    if clear_session:
        if profile_config.jsessionid:
            items.append("SM session")
        if cli_ctx.credential_manager.has_sm_credentials(cli_ctx.profile):
            items.append("SM credentials")
    if clear_keys:
        keys = cli_ctx.credential_manager.list_keys()
        admin_count = len(keys.get("admin", []))
        agent_count = len(keys.get("agent", []))
        if admin_count > 0:
            items.append(f"{admin_count} admin key(s)")
        if agent_count > 0:
            items.append(f"{agent_count} agent key(s)")
    return items


def _clear_api_keys(cli_ctx: CLIContext) -> dict[str, int]:
    """Clear all stored API keys and return counts."""
    cleared = {"admin": 0, "agent": 0}
    keys = cli_ctx.credential_manager.list_keys()
    for key_name in keys.get("admin", []):
        if cli_ctx.credential_manager.delete_key("admin", key_name):
            cleared["admin"] += 1
    for key_name in keys.get("agent", []):
        if cli_ctx.credential_manager.delete_key("agent", key_name):
            cleared["agent"] += 1
    return cleared


def _confirm_logout(items_to_clear: list[str], force: bool) -> bool:
    """Confirm logout with user if not forced."""
    if force:
        return True
    console.print("This will clear:")
    for item in items_to_clear:
        console.print(f"  • {item}")
    return typer.confirm("\nContinue?")


def _perform_logout(
    cli_ctx: CLIContext,
    clear_session: bool,
    clear_keys: bool,
) -> dict[str, int]:
    """Perform the actual logout operations."""
    config = cli_ctx.config_manager.load_config()
    profile_config = config.profiles[cli_ctx.profile]

    if clear_session:
        if profile_config.jsessionid:
            profile_config.clear_session()
            cli_ctx.config_manager.save_config(config)
        cli_ctx.credential_manager.delete_sm_credentials(cli_ctx.profile)

    return _clear_api_keys(cli_ctx) if clear_keys else {"admin": 0, "agent": 0}


@auth_app.command("logout")
def auth_logout(
    ctx: typer.Context,
    session_only: Annotated[
        bool,
        typer.Option("--session-only", help="Clear only session and SM credentials"),
    ] = False,
    keys_only: Annotated[
        bool,
        typer.Option("--keys-only", help="Clear only API keys"),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Log out and clear stored credentials.

    By default, clears all authentication:
    - SM session (JSESSIONID, CSRF token)
    - SM credentials (username, password)
    - All stored API keys

    [bold]Examples:[/bold]
        ctxctl auth logout                # Clear everything
        ctxctl auth logout --session-only # Clear only session
        ctxctl auth logout --keys-only    # Clear only API keys
    """
    cli_ctx = get_cli_context(ctx)

    if session_only and keys_only:
        console.print(
            "[bold red]Error:[/bold red] Cannot use --session-only and --keys-only together"
        )
        raise typer.Exit(code=1)

    try:
        config = cli_ctx.config_manager.load_config()
        profile_config = config.profiles[cli_ctx.profile]
        clear_session, clear_keys = not keys_only, not session_only

        items_to_clear = _build_items_to_clear(cli_ctx, profile_config, clear_session, clear_keys)
        if not items_to_clear:
            console.print("[yellow]Nothing to clear[/yellow]")
            return

        if not _confirm_logout(items_to_clear, force):
            raise typer.Exit(code=0)

        user_email = profile_config.session_user_email or "unknown"
        cleared_keys = _perform_logout(cli_ctx, clear_session, clear_keys)

        console.print("[green]✓[/green] Logged out successfully")
        if clear_session:
            console.print("  Cleared SM session and credentials")
        if cleared_keys["admin"] > 0 or cleared_keys["agent"] > 0:
            console.print(
                f"  Cleared {cleared_keys['admin']} admin key(s), {cleared_keys['agent']} agent key(s)"
            )

        cli_ctx.audit_logger.log_auth(user=user_email, action="logout", status="success")
    except typer.Exit:
        raise
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


def _print_session_status(cli_ctx: CLIContext, profile_config: "ProfileConfig") -> None:
    """Print session status section for auth status command."""
    from datetime import datetime

    console.print("\n[bold]Session:[/bold]")
    if not profile_config.jsessionid:
        console.print("  Status: [dim]Not logged in[/dim]")
        return

    status = (
        "[green]Active[/green]"
        if profile_config.has_valid_session()
        else "[yellow]Expired[/yellow]"
    )
    console.print(f"  Status: {status}")

    if profile_config.session_user_email:
        console.print(f"  User: [bold]{profile_config.session_user_email}[/bold]")
    if profile_config.redis_cloud_url:
        console.print(f"  Redis Cloud URL: {profile_config.redis_cloud_url}")

    if profile_config.session_expires_at:
        remaining = profile_config.session_expires_at - datetime.now()
        if remaining.total_seconds() > 0:
            minutes = int(remaining.total_seconds() / 60)
            console.print(f"  Expires: {profile_config.session_expires_at} (in {minutes} minutes)")
        else:
            console.print(f"  Expired: {profile_config.session_expires_at}")

    has_creds = cli_ctx.credential_manager.has_sm_credentials(cli_ctx.profile)
    creds_msg = (
        "[green]Yes[/green] (can auto-refresh)"
        if has_creds
        else "[yellow]No[/yellow] (manual re-login required)"
    )
    console.print(f"  Credentials stored: {creds_msg}")


def _print_api_keys_status(keys: dict[str, list[str]]) -> None:
    """Print API keys status section for auth status command."""
    console.print("\n[bold]API Keys:[/bold]")
    for key_type in ["admin", "agent"]:
        key_list = keys.get(key_type, [])
        if key_list:
            console.print(f"  {key_type}:")
            for key_name in key_list:
                console.print(f"    - {key_name}")
        else:
            console.print(f"  {key_type}: [dim]None[/dim]")


@auth_app.command("status")
def auth_status(ctx: typer.Context) -> None:
    """Show current authentication status.

    Displays information about the current session and stored API keys.

    [bold]Example:[/bold]
        ctxctl auth status
    """
    cli_ctx = get_cli_context(ctx)

    try:
        config = cli_ctx.config_manager.load_config()
        profile_config = config.profiles[cli_ctx.profile]

        console.print(f"\n[bold]Authentication Status[/bold] (profile: {cli_ctx.profile})")
        console.print("━" * 50)

        _print_session_status(cli_ctx, profile_config)
        _print_api_keys_status(cli_ctx.credential_manager.list_keys())

        console.print()
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


@auth_app.command("list")
def auth_list(ctx: typer.Context) -> None:
    """List all stored API keys.

    Shows all API keys stored in secure storage (admin and agent keys).
    Note: The actual key values are never displayed, only their names.

    [bold]Example:[/bold]
        ctxctl auth list
    """
    cli_ctx = get_cli_context(ctx)

    try:
        keys = cli_ctx.credential_manager.list_keys()

        # Format for output
        keys_data = [
            {"name": key_name, "type": key_type}
            for key_type in ["admin", "agent"]
            for key_name in keys.get(key_type, [])
        ]

        if not keys_data:
            console.print("[yellow]No API keys stored[/yellow]")
            return

        # Render based on output format
        output: JsonOutput | YamlOutput | TableOutput
        if cli_ctx.output_format == OutputFormat.JSON:
            output = JsonOutput(data=keys_data)
        elif cli_ctx.output_format == OutputFormat.YAML:
            output = YamlOutput(data=keys_data)
        else:  # TABLE
            output = TableOutput.from_dicts(keys_data, title="Stored API Keys")

        cli_ctx.output_formatter.render(output)
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Agent Commands
# ============================================================================


def _parse_access_tags_json(access_tags_json: str | None) -> dict[str, list[str]] | None:
    """Parse and validate access tags JSON string.

    Access tags support multi-value format: {"tenant": ["acme", "globex"]}

    Args:
        access_tags_json: JSON string of access tags or None

    Returns:
        Parsed dict of access tags (key -> list of values) or None

    Raises:
        typer.BadParameter: If JSON is invalid or not properly formatted
    """
    import json as json_lib

    if not access_tags_json:
        return None

    try:
        parsed = json_lib.loads(access_tags_json)
        if not isinstance(parsed, dict):
            raise typer.BadParameter("access-tags must be a JSON object")

        # Validate and normalize: keys must be strings, values must be lists of strings
        result: dict[str, list[str]] = {}
        for k, v in parsed.items():
            if not isinstance(k, str):
                raise typer.BadParameter("access-tags keys must be strings")

            # Accept both single string and list of strings for backward compatibility
            if isinstance(v, str):
                # Single string: convert to list
                result[k] = [v]
            elif isinstance(v, list):
                # Validate all items in the list are strings
                for i, item in enumerate(v):
                    if not isinstance(item, str):
                        raise typer.BadParameter(
                            f"access-tags values must be strings or lists of strings, "
                            f"got {type(item).__name__} in '{k}[{i}]'"
                        )
                result[k] = v
            else:
                raise typer.BadParameter(
                    f"access-tags values must be strings or lists of strings, "
                    f"got {type(v).__name__} for key '{k}'"
                )
        return result
    except json_lib.JSONDecodeError as e:
        raise typer.BadParameter(f"Invalid JSON for access-tags: {e}") from e


@agent_app.command("create")
def agent_create(
    ctx: typer.Context,
    surface_id: Annotated[str, typer.Option("--surface-id", help="Surface ID")],
    name: Annotated[str, typer.Option("--name", help="Name for the agent key")],
    description: Annotated[
        str | None, typer.Option("--description", help="Optional description")
    ] = None,
    access_tags: Annotated[
        str | None,
        typer.Option(
            "--access-tags",
            help='Access tags for ACL filtering as JSON (e.g., \'{"tenant": ["acme"]}\')',
        ),
    ] = None,
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
) -> None:
    """Create an agent API key for a context surface.

    Example:
        ctxctl agent create --surface-id ce-123 --name "Support Agent"
        ctxctl agent create --surface-id ce-123 --name "Acme Agent" --access-tags '{"tenant": ["acme"]}'
        ctxctl agent create --surface-id ce-123 --name "Multi-Tenant Agent" --access-tags '{"tenant": ["acme", "globex"]}'
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Parse access_tags JSON if provided
    parsed_access_tags = _parse_access_tags_json(access_tags)

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _create() -> None:
        from context_surfaces import ContextSurfacesClient, CreateAgentKeyRequest

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            agent_key_obj = await client.create_agent_key(
                surface_id,
                CreateAgentKeyRequest(
                    name=name,
                    description=description,
                    expires_at=None,
                    metadata={},
                    access_tags=parsed_access_tags,
                ),
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            # Store the key
            cli_ctx.credential_manager.store_agent_key("default", agent_key_obj.key)

            data: dict[str, Any] = {
                "id": agent_key_obj.id,
                "key": agent_key_obj.key,
                "name": agent_key_obj.name,
                "surface_id": agent_key_obj.context_surface_id,
                "created_at": agent_key_obj.created_at.isoformat(),
            }
            if parsed_access_tags:
                data["access_tags"] = parsed_access_tags

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=data)
            else:
                output = TableOutput.from_dict(data, title="Agent Key Created")

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_create())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Tools Commands
# ============================================================================


@tools_app.command("list")
def tools_list(
    ctx: typer.Context,
    agent_key: Annotated[str | None, typer.Option("--agent-key", help="Agent API key")] = None,
) -> None:
    """List available MCP tools for an agent.

    Example:
        ctxctl tools list --agent-key <key>
    """
    cli_ctx = get_cli_context(ctx)

    # Get agent key
    if agent_key is None:
        agent_key = cli_ctx.credential_manager.get_agent_key("default")
        if agent_key is None:
            console.print(
                "[bold red]Error:[/bold red] No agent key provided or stored",
                style="red",
            )
            raise typer.Exit(code=1)

    async def _list() -> None:
        from context_surfaces.mcp_client import MCPClient

        profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]
        mcp_url = profile_config.mcp_url

        async with MCPClient(mcp_url=mcp_url, agent_key=agent_key) as mcp:
            tools = await mcp.list_tools()

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=tools)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=tools)
            else:
                output = TableOutput.from_dicts(tools, title="Available MCP Tools")

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_list())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# Global CLI options that should not be passed to tools as arguments
_GLOBAL_CLI_OPTIONS = frozenset({"output", "o", "profile", "p", "no-color", "config", "c", "debug"})


def _extract_output_format_from_args(extra_args: list[str]) -> OutputFormat | None:
    """Extract --output or -o option from extra CLI arguments.

    Args:
        extra_args: List of extra CLI arguments

    Returns:
        OutputFormat if found, None otherwise
    """
    format_map = {
        "json": OutputFormat.JSON,
        "yaml": OutputFormat.YAML,
        "table": OutputFormat.TABLE,
    }
    i = 0
    while i < len(extra_args):
        arg = extra_args[i]
        if arg in ("--output", "-o"):
            if i + 1 < len(extra_args):
                value = extra_args[i + 1].lower()
                return format_map.get(value)
            break
        i += 1
    return None


def _parse_json_value(value_str: str) -> object:
    """Parse a string value as JSON, falling back to string if invalid."""
    import json

    try:
        return json.loads(value_str)
    except json.JSONDecodeError:
        return value_str


def _skip_global_option(extra_args: list[str], i: int) -> int:
    """Skip a global CLI option and its value if present. Returns new index."""
    if i + 1 < len(extra_args) and not extra_args[i + 1].startswith("-"):
        return i + 2
    return i + 1


def _parse_extra_cli_arguments(extra_args: list[str]) -> dict[str, object]:
    """Parse extra CLI arguments into a dictionary.

    Converts CLI arguments like ['--query', 'john', '--limit', '10']
    into {'query': 'john', 'limit': 10}.

    Filters out global CLI options like --output, --profile, etc.

    Args:
        extra_args: List of extra CLI arguments

    Returns:
        Parsed arguments dictionary
    """
    result: dict[str, object] = {}
    i = 0
    while i < len(extra_args):
        arg = extra_args[i]
        if arg.startswith("--"):
            key = arg[2:]  # Remove '--' prefix
            if key in _GLOBAL_CLI_OPTIONS:
                i = _skip_global_option(extra_args, i)
                continue
            if i + 1 < len(extra_args) and not extra_args[i + 1].startswith("--"):
                result[key] = _parse_json_value(extra_args[i + 1])
                i += 2
            else:
                result[key] = True  # Flag without value
                i += 1
        elif arg.startswith("-") and len(arg) == 2:
            key = arg[1]  # Single character option like -o
            if key in _GLOBAL_CLI_OPTIONS:
                i = _skip_global_option(extra_args, i)
                continue
            i += 1
        else:
            i += 1
    return result


def _parse_tool_arguments(args: str | None, args_file: Path | None) -> dict[str, object]:
    """Parse tool arguments from JSON string or file.

    Args:
        args: JSON string with arguments
        args_file: Path to JSON file with arguments

    Returns:
        Parsed arguments dictionary

    Raises:
        typer.Exit: If JSON parsing fails
    """
    import json
    from typing import cast

    if args is not None:
        try:
            return cast("dict[str, object]", json.loads(args))
        except json.JSONDecodeError as e:
            console.print(f"[bold red]Error:[/bold red] Invalid JSON in --args: {e}", style="red")
            raise typer.Exit(code=1) from e

    if args_file is not None:
        if not args_file.exists():
            console.print(
                f"[bold red]Error:[/bold red] Arguments file not found: {args_file}",
                style="red",
            )
            raise typer.Exit(code=1)
        try:
            return cast("dict[str, object]", json.loads(args_file.read_text()))
        except json.JSONDecodeError as e:
            console.print(
                f"[bold red]Error:[/bold red] Invalid JSON in {args_file}: {e}",
                style="red",
            )
            raise typer.Exit(code=1) from e

    return {}


@tools_app.command(
    "call", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def tools_call(
    ctx: typer.Context,
    tool_name: Annotated[str, typer.Argument(help="Name of the tool to call")],
    agent_key: Annotated[str | None, typer.Option("--agent-key", help="Agent API key")] = None,
    args: Annotated[
        str | None, typer.Option("--args", help="Tool arguments as JSON string")
    ] = None,
    args_file: Annotated[
        Path | None,
        typer.Option("--args-file", help="Path to JSON file with arguments"),
    ] = None,
) -> None:
    """Call an MCP tool with arguments.

    You can pass arguments in three ways:

    1. As individual CLI options:
        ctxctl tools call search_customer_by_text --query john --limit 10

    2. As a JSON string:
        ctxctl tools call search_customer_by_text --args '{"query": "john", "limit": 10}'

    3. From a JSON file:
        ctxctl tools call search_customer_by_text --args-file ./args.json

    Note: Individual CLI options take precedence over --args and --args-file.
    """
    cli_ctx = get_cli_context(ctx)

    # Check for --output in extra args (allows --output after subcommand options)
    output_format_override = _extract_output_format_from_args(ctx.args)
    effective_output_format = output_format_override or cli_ctx.output_format

    # Get agent key
    if agent_key is None:
        agent_key = cli_ctx.credential_manager.get_agent_key("default")
        if agent_key is None:
            console.print(
                "[bold red]Error:[/bold red] No agent key provided or stored",
                style="red",
            )
            raise typer.Exit(code=1)

    # Parse arguments from --args or --args-file
    arguments = _parse_tool_arguments(args, args_file)

    # Parse extra arguments from CLI (e.g., --query john --limit 10)
    # These take precedence over --args and --args-file
    extra_args = _parse_extra_cli_arguments(ctx.args)
    arguments.update(extra_args)

    async def _call() -> None:
        from context_surfaces.mcp_client import MCPClient

        profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]
        mcp_url = profile_config.mcp_url

        async with MCPClient(mcp_url=mcp_url, agent_key=agent_key) as mcp:
            result = await mcp.call_tool(tool_name, arguments)

            # For JSON output, print raw JSON without any formatting
            if effective_output_format == OutputFormat.JSON:
                import json

                print(json.dumps(result, indent=2))
            elif effective_output_format == OutputFormat.YAML:
                output: YamlOutput | TableOutput = YamlOutput(data=result)
                cli_ctx.output_formatter.render(output)
            elif isinstance(result, dict):
                output = TableOutput.from_dict(result, title=f"Tool Result: {tool_name}")
                cli_ctx.output_formatter.render(output)
            else:
                import json

                print(json.dumps(result, indent=2))

    try:
        asyncio.run(_call())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Context Surface Commands
# ============================================================================


@surface_app.command("list")
def surface_list(
    ctx: typer.Context,
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
    page: Annotated[int, typer.Option("--page", help="Page number")] = 1,
    page_size: Annotated[int, typer.Option("--page-size", help="Items per page")] = 20,
) -> None:
    """List all context surfaces for the current account.

    Example:
        ctxctl surface list
        ctxctl surface list --page 2 --page-size 10
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _list() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            response = await client.list_context_surfaces(
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
                page=page,
                page_size=page_size,
            )

            surfaces_data = [
                {
                    "id": surface.id,
                    "name": surface.name,
                }
                for surface in response.context_surfaces
            ]

            if not surfaces_data:
                console.print("[yellow]No context surfaces found[/yellow]")
                return

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=surfaces_data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=surfaces_data)
            else:
                output = TableOutput.from_dicts(
                    surfaces_data,
                    title=f"Context Surfaces (Page {response.pagination.page}/{response.pagination.total_pages})",
                )

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_list())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


@surface_app.command("describe")
def surface_describe(
    ctx: typer.Context,
    surface_id: Annotated[str, typer.Argument(help="Context surface ID")],
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
) -> None:
    """Show detailed information about a context surface.

    Example:
        ctxctl surface describe ce-123
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _describe() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            surface = await client.get_context_surface(
                surface_id,
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            surface_data = {
                "id": surface.id,
                "name": surface.name,
                "description": surface.description or "",
                "redis_instance_id": surface.redis_instance_id or "",
                "tools": ", ".join(surface.tools) if surface.tools else "",
                "created_at": surface.created_at.isoformat(),
                "updated_at": surface.updated_at.isoformat(),
                "metadata": surface.metadata,
            }

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=surface_data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=surface_data)
            else:
                output = TableOutput.from_dict(
                    surface_data,
                    title=f"Context Surface: {surface.name}",
                )

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_describe())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


def parse_context_models_from_file(file_path: Path) -> list[type]:
    """Parse Python file and extract ContextModel classes.

    Args:
        file_path: Path to Python file containing ContextModel classes

    Returns:
        List of ContextModel subclasses found in the file

    Raises:
        ImportError: If the file cannot be imported
        ValueError: If no ContextModel classes are found
    """
    import importlib.util
    import inspect

    from context_surfaces.context_model import ContextModel

    # Load the module
    spec = importlib.util.spec_from_file_location("models", file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {file_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    # Find all ContextModel subclasses
    models = []
    for _name, obj in inspect.getmembers(module):
        if inspect.isclass(obj) and issubclass(obj, ContextModel) and obj is not ContextModel:
            models.append(obj)

    if not models:
        raise ValueError(f"No ContextModel classes found in {file_path}")

    return models


@surface_app.command("delete")
def surface_delete(
    ctx: typer.Context,
    surface_id: Annotated[str, typer.Argument(help="Context surface ID to delete")],
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
    confirm: Annotated[bool, typer.Option("--confirm", help="Skip confirmation prompt")] = False,
) -> None:
    """Delete a context surface.

    Example:
        ctxctl surface delete ce-123 --confirm
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    # Confirm deletion
    if not confirm and not typer.confirm(f"Delete surface '{surface_id}'?"):
        raise typer.Exit(code=0)

    async def _delete() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            await client.delete_context_surface(
                surface_id,
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )
            console.print(f"[green]✓[/green] Surface '{surface_id}' deleted")

    try:
        asyncio.run(_delete())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


def _parse_data_model_from_python(
    models_path: Path,
    name: str,
    description: str | None,
    output_format: OutputFormat,
) -> dict[str, object]:
    """Parse DataModel from Python ContextModel classes.

    Args:
        models_path: Path to Python file with ContextModel classes
        name: Name for the context surface
        description: Optional description
        output_format: Output format (for conditional debug printing)

    Returns:
        DataModel dictionary

    Raises:
        typer.Exit: If parsing fails
    """
    from typing import cast

    if not models_path.exists():
        console.print(
            f"[bold red]Error:[/bold red] Models file not found: {models_path}",
            style="red",
        )
        raise typer.Exit(code=1)

    try:
        from context_surfaces.context_model import export_data_model

        model_classes = parse_context_models_from_file(models_path)
        # Only print debug info if not in JSON/YAML mode (to avoid breaking parseable output)
        if output_format == OutputFormat.TABLE:
            console.print(
                f"[dim]Found {len(model_classes)} ContextModel classes: {[m.__name__ for m in model_classes]}[/dim]"
            )

        return cast(
            "dict[str, object]",
            export_data_model(
                title=name,
                description=description or f"Auto-generated from {models_path.name}",
                entities=model_classes,
            ),
        )
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] Failed to parse models file: {e}", style="red")
        raise typer.Exit(code=1) from e


def _parse_data_model_from_json(datamodel_path: Path) -> dict[str, object]:
    """Parse DataModel from JSON file.

    Args:
        datamodel_path: Path to JSON DataModel file

    Returns:
        DataModel dictionary

    Raises:
        typer.Exit: If parsing fails
    """
    import json
    from typing import cast

    if not datamodel_path.exists():
        console.print(
            f"[bold red]Error:[/bold red] DataModel file not found: {datamodel_path}",
            style="red",
        )
        raise typer.Exit(code=1)

    try:
        return cast("dict[str, object]", json.loads(datamodel_path.read_text()))
    except Exception as e:
        console.print(
            f"[bold red]Error:[/bold red] Failed to parse DataModel JSON: {e}",
            style="red",
        )
        raise typer.Exit(code=1) from e


@surface_app.command("create")
def surface_create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", help="Name for the surface")],
    description: Annotated[
        str | None, typer.Option("--description", help="Optional description")
    ] = None,
    models: Annotated[
        Path | None,
        typer.Option("--models", help="Path to Python file with ContextModel classes"),
    ] = None,
    datamodel: Annotated[
        Path | None, typer.Option("--datamodel", help="Path to JSON DataModel file")
    ] = None,
    redis_instance_id: Annotated[
        str | None, typer.Option("--redis-instance-id", help="Redis instance ID")
    ] = None,
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
) -> None:
    """Create a context surface from Python models or DataModel JSON.

    Example:
        ctxctl surface create --name "Reddish Support" --models ./reddish_models.py --redis-instance-id ri-123
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    # Parse data model
    data_model_dict = None
    if models is not None:
        data_model_dict = _parse_data_model_from_python(
            models, name, description, cli_ctx.output_format
        )
    elif datamodel is not None:
        data_model_dict = _parse_data_model_from_json(datamodel)

    async def _create() -> None:
        from context_surfaces import (
            ContextSurfacesClient,
            CreateContextSurfaceRequest,
        )

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            surface = await client.create_context_surface(
                CreateContextSurfaceRequest(
                    name=name,
                    description=description,
                    data_model=data_model_dict,
                    redis_instance_id=redis_instance_id,
                ),
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            data = {
                "id": surface.id,
                "name": surface.name,
                "description": surface.description,
                "redis_instance_id": surface.redis_instance_id,
                "tools": surface.tools,
                "created_at": surface.created_at.isoformat(),
            }

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=data)
            else:
                output = TableOutput.from_dict(data, title="Context Surface Created")

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_create())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Redis Commands
# ============================================================================


@redis_app.command("list")
def redis_list(
    ctx: typer.Context,
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
) -> None:
    """List all Redis instances for the current account.

    Example:
        ctxctl redis list
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _list() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            response = await client.list_redis_instances(
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            instances_data = [
                {
                    "id": instance.id,
                    "name": instance.name,
                }
                for instance in response.instances
            ]

            if not instances_data:
                console.print("[yellow]No Redis instances found[/yellow]")
                return

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=instances_data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=instances_data)
            else:
                output = TableOutput.from_dicts(
                    instances_data,
                    title=f"Redis Instances ({response.total} total)",
                )

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_list())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


@redis_app.command("describe")
def redis_describe(
    ctx: typer.Context,
    instance_id: Annotated[str, typer.Argument(help="Redis instance ID")],
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
) -> None:
    """Show detailed information about a Redis instance.

    Example:
        ctxctl redis describe ri-123
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _describe() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            instance = await client.get_redis_instance(
                instance_id,
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            instance_data = {
                "id": instance.id,
                "name": instance.name,
                "description": instance.description or "",
                "created_at": instance.created_at.isoformat(),
                "updated_at": instance.updated_at.isoformat(),
                "metadata": instance.metadata,
            }

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=instance_data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=instance_data)
            else:
                output = TableOutput.from_dict(
                    instance_data,
                    title=f"Redis Instance: {instance.name}",
                )

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_describe())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


@redis_app.command("delete")
def redis_delete(
    ctx: typer.Context,
    instance_id: Annotated[str, typer.Argument(help="Redis instance ID to delete")],
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
    confirm: Annotated[bool, typer.Option("--confirm", help="Skip confirmation prompt")] = False,
) -> None:
    """Delete a Redis instance.

    Example:
        ctxctl redis delete ri-123 --confirm
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    # Confirm deletion
    if not confirm and not typer.confirm(f"Delete Redis instance '{instance_id}'?"):
        raise typer.Exit(code=0)

    async def _delete() -> None:
        from context_surfaces import ContextSurfacesClient

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            await client.delete_redis_instance(
                instance_id,
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )
            console.print(f"[green]✓[/green] Redis instance '{instance_id}' deleted")

    try:
        asyncio.run(_delete())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


@redis_app.command("create")
def redis_create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", help="Name for the Redis instance")],
    addr: Annotated[str, typer.Option("--addr", help="Redis address (host:port)")],
    db: Annotated[int, typer.Option("--db", help="Redis database number")] = 0,
    username: Annotated[
        str | None, typer.Option("--username", help="Redis ACL username (Redis 6+)")
    ] = None,
    password: Annotated[str | None, typer.Option("--password", help="Redis password")] = None,
    tls: Annotated[bool, typer.Option("--tls", help="Use TLS connection")] = False,
    admin_key: Annotated[str | None, typer.Option("--admin-key", help="Admin API key")] = None,
    description: Annotated[
        str | None, typer.Option("--description", help="Optional description")
    ] = None,
) -> None:
    """Register a new Redis instance.

    Example:
        ctxctl redis create --name "Production Redis" --addr "localhost:6379" --db 0
        ctxctl redis create --name "ACL Redis" --addr "redis.example.com:6379" --username "myuser" --password "mypass"
    """
    from context_surfaces.cli.services.auth_helper import resolve_auth_with_refresh

    cli_ctx = get_cli_context(ctx)
    profile_config = cli_ctx.config_manager.load_config().profiles[cli_ctx.profile]

    # Resolve authentication (API key or session) with auto-refresh
    auth = resolve_auth_with_refresh(
        admin_key,
        cli_ctx.credential_manager,
        profile_config,
        cli_ctx.config_manager,
        cli_ctx.profile,
    )

    async def _create() -> None:
        from context_surfaces import (
            ContextSurfacesClient,
            RedisConnectionConfig,
            RegisterRedisInstanceRequest,
        )

        api_url = profile_config.api_url

        async with ContextSurfacesClient(api_url) as client:
            redis_instance = await client.register_redis_instance(
                RegisterRedisInstanceRequest(
                    name=name,
                    description=description,
                    connection_config=RedisConnectionConfig(
                        addr=addr,
                        username=username or "",
                        db=db,
                        password=password or "",
                        tls_enabled=tls,
                        ca_cert=None,
                        pool_size=10,
                        min_idle_conns=2,
                    ),
                    metadata={},
                ),
                admin_key=auth.api_key,
                session_id=auth.session_id,
                csrf_token=auth.csrf_token,
            )

            data = {
                "id": redis_instance.id,
                "name": redis_instance.name,
                "vault_path": redis_instance.vault_path,
                "created_at": redis_instance.created_at.isoformat(),
            }

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=data)
            else:
                output = TableOutput.from_dict(data, title="Redis Instance Registered")

            cli_ctx.output_formatter.render(output)

    try:
        asyncio.run(_create())
    except Exception as e:
        handle_error(e)
        raise typer.Exit(code=1) from e


# ============================================================================
# Admin Commands
# ============================================================================


def _check_admin_session_valid(profile_config: Any) -> bool:
    """Check if session is valid for admin operations, print error if not."""
    if not profile_config.has_valid_session():
        console.print(
            "[bold red]Error:[/bold red] Not logged in or session expired.\n"
            "Use 'ctxctl login' to authenticate with SM first."
        )
        return False
    return True


def _handle_admin_response_error(response: Any) -> bool:
    """Handle HTTP error responses for admin operations. Returns True if error occurred."""
    if response.status_code == 401:
        console.print(
            "[bold red]Authentication failed.[/bold red]\n"
            "Your session may have expired. Use 'ctxctl login' to re-authenticate."
        )
        return True

    if response.status_code == 403:
        error_data = response.json()
        console.print(f"[bold red]Forbidden:[/bold red] {error_data.get('error', 'Access denied')}")
        return True

    if response.status_code != 201:
        try:
            error_data = response.json()
            error_msg = error_data.get("error", response.text)
        except Exception:
            error_msg = response.text
        console.print(f"[bold red]Error:[/bold red] {error_msg}")
        return True

    return False


@admin_app.command("create")
def admin_create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", help="Name for the admin key")],
    description: Annotated[
        str | None, typer.Option("--description", help="Optional description")
    ] = None,
) -> None:
    """Create a new admin API key.

    Requires active SM session (use 'ctxctl login' first).
    The owner is automatically set from your SM user ID.

    [bold]Example:[/bold]
        ctxctl login --username user@example.com
        ctxctl admin create --name "My Admin Key"
    """
    cli_ctx = get_cli_context(ctx)

    async def _create() -> None:
        import httpx

        # Get profile config with session credentials
        config = cli_ctx.config_manager.load_config()
        profile_config = config.profiles[cli_ctx.profile]

        if not _check_admin_session_valid(profile_config):
            raise typer.Exit(code=1)

        # Type narrowing: after has_valid_session() we know these are not None
        assert profile_config.jsessionid is not None
        assert profile_config.csrf_token is not None
        assert profile_config.redis_cloud_url is not None

        admin_key_url = f"{profile_config.api_url}/api/v1/keys"

        if cli_ctx.output_format == OutputFormat.TABLE:
            console.print(f"[dim]Creating admin key via {admin_key_url}...[/dim]")

        # Make authenticated request to backend
        # The backend will extract owner from JWT claims
        # We've already verified session is valid, so these are not None
        assert profile_config.jsessionid is not None
        assert profile_config.csrf_token is not None
        async with httpx.AsyncClient(
            timeout=profile_config.timeout,
            cookies={"JSESSIONID": profile_config.jsessionid},
        ) as client:
            response = await client.post(
                admin_key_url,
                json={"name": name, "description": description or ""},
                headers={"X-CSRF-Token": profile_config.csrf_token},
            )

            if _handle_admin_response_error(response):
                raise typer.Exit(code=1)

            admin_key = response.json()
            cli_ctx.credential_manager.store_admin_key(name, admin_key["key"])

            data = {
                "id": admin_key["id"],
                "key": admin_key["key"],
                "name": admin_key["name"],
                "owner": admin_key["owner"],
                "created_at": admin_key["created_at"],
            }

            output: JsonOutput | YamlOutput | TableOutput
            if cli_ctx.output_format == OutputFormat.JSON:
                output = JsonOutput(data=data)
            elif cli_ctx.output_format == OutputFormat.YAML:
                output = YamlOutput(data=data)
            else:
                output = TableOutput.from_dict(data, title="Admin Key Created")

            cli_ctx.output_formatter.render(output)

            if cli_ctx.output_format == OutputFormat.TABLE:
                console.print(
                    "\n[bold yellow]Important:[/bold yellow] Save this key securely! "
                    "It will not be shown again."
                )

    try:
        asyncio.run(_create())
    except Exception as e:
        if not isinstance(e, (typer.Exit, SystemExit)):
            handle_error(e)
            raise typer.Exit(code=1) from e
        raise


# ============================================================================
# Version Command
# ============================================================================


@app.command("version")
def version_command() -> None:
    """Show CLI version information.

    Displays the version of the Context Surfaces CLI.

    Example:
        ctxctl version
    """
    from context_surfaces import __version__

    console.print(
        Panel(
            f"[bold]Context Surfaces CLI[/bold]\n"
            f"Version: {__version__}\n"
            f"Python client for the Context Surfaces API",
            title="Version Info",
            border_style="blue",
        )
    )


if __name__ == "__main__":
    from context_surfaces.cli.entrypoint import cli_main

    cli_main()
