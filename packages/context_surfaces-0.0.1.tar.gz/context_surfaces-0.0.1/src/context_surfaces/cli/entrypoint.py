"""CLI entrypoint for ctxctl.

Registered as a console_script in pyproject.toml so that
`pip install context-surfaces` gives the user a `ctxctl` binary.
"""

from context_surfaces.cli.main import app


def cli_main() -> None:
    """Entry point for the ctxctl CLI."""
    app()
