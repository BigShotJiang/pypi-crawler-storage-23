"""Authentication helper for CLI commands.

Provides unified authentication resolution for CLI commands that need to
call the backend API. Supports both admin API key and session-based authentication.
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import typer
from rich.console import Console

if TYPE_CHECKING:
    from context_surfaces.cli.services.config_manager import ConfigManager, ProfileConfig
    from context_surfaces.cli.services.credential_manager import CredentialManager
    from context_surfaces.cli.services.sm_auth import SMSession

console = Console()
logger = logging.getLogger(__name__)


@dataclass
class AuthCredentials:
    """Authentication credentials for API calls.

    Either api_key OR (session_id AND csrf_token) must be set for valid authentication.
    """

    api_key: str | None = None
    session_id: str | None = None
    csrf_token: str | None = None

    @property
    def is_api_key_auth(self) -> bool:
        """Check if using API key authentication."""
        return self.api_key is not None

    @property
    def is_session_auth(self) -> bool:
        """Check if using session authentication."""
        return self.session_id is not None and self.csrf_token is not None

    @property
    def is_valid(self) -> bool:
        """Check if credentials are valid (have at least one auth method)."""
        return self.is_api_key_auth or self.is_session_auth


def resolve_auth(
    admin_key_arg: str | None,
    credential_manager: "CredentialManager",
    profile_config: "ProfileConfig",
) -> AuthCredentials:
    """Resolve authentication credentials for a CLI command.

    Priority:
    1. Admin key provided as CLI argument (--admin-key)
    2. Stored admin key (from 'ctxctl key store')
    3. Session credentials (from 'ctxctl auth login')
    4. Exit with error message

    Args:
        admin_key_arg: Admin key from CLI argument (--admin-key option)
        credential_manager: Credential manager for stored keys
        profile_config: Current profile configuration with session data

    Returns:
        AuthCredentials with resolved authentication method

    Raises:
        typer.Exit: If no valid authentication is available
    """
    # 1. Check CLI argument
    if admin_key_arg:
        return AuthCredentials(api_key=admin_key_arg)

    # 2. Check stored admin key
    stored_key = credential_manager.get_admin_key("default")
    if stored_key:
        return AuthCredentials(api_key=stored_key)

    # 3. Check session credentials
    if profile_config.has_valid_session():
        return AuthCredentials(
            session_id=profile_config.jsessionid,
            csrf_token=profile_config.csrf_token,
        )

    # 4. No valid authentication - exit with helpful error
    console.print(
        "[bold red]Error:[/bold red] No authentication available.\n\n"
        "Either:\n"
        "  • Run [cyan]ctxctl auth login[/cyan] to authenticate with SM, or\n"
        "  • Provide [cyan]--admin-key <key>[/cyan] argument"
    )
    raise typer.Exit(code=1)


def resolve_auth_with_refresh(
    admin_key_arg: str | None,
    credential_manager: "CredentialManager",
    profile_config: "ProfileConfig",
    config_manager: "ConfigManager",
    profile_name: str,
) -> AuthCredentials:
    """Resolve authentication with automatic session refresh.

    If session is expired but SM credentials are stored, attempts to
    automatically refresh the session.

    Priority:
    1. Admin key provided as CLI argument (--admin-key)
    2. Stored admin key (from 'ctxctl auth login <name> --type admin')
    3. Valid session credentials (from 'ctxctl auth login')
    4. Expired session with stored credentials -> auto-refresh
    5. Exit with error message

    Args:
        admin_key_arg: Admin key from CLI argument (--admin-key option)
        credential_manager: Credential manager for stored keys
        profile_config: Current profile configuration with session data
        config_manager: Config manager for saving refreshed session
        profile_name: Current profile name

    Returns:
        AuthCredentials with resolved authentication method

    Raises:
        typer.Exit: If no valid authentication is available
    """
    # 1. Check CLI argument
    if admin_key_arg:
        return AuthCredentials(api_key=admin_key_arg)

    # 2. Check stored admin key
    stored_key = credential_manager.get_admin_key("default")
    if stored_key:
        return AuthCredentials(api_key=stored_key)

    # 3. Check session credentials
    if profile_config.has_valid_session():
        return AuthCredentials(
            session_id=profile_config.jsessionid,
            csrf_token=profile_config.csrf_token,
        )

    # 4. Session expired - try auto-refresh if credentials are stored
    if profile_config.jsessionid:  # Had a session before
        sm_creds = credential_manager.get_sm_credentials(profile_name)
        if sm_creds and profile_config.redis_cloud_url:
            console.print("[dim]Session expired. Attempting refresh...[/dim]")
            try:
                redis_cloud_url = profile_config.redis_cloud_url
                session = _refresh_session_sync(
                    sm_creds[0],
                    sm_creds[1],
                    redis_cloud_url,
                )
                if session:
                    # Update profile with new session
                    config = config_manager.load_config()
                    profile = config.profiles[profile_name]
                    profile.jsessionid = session.jsessionid
                    profile.csrf_token = session.csrf_token
                    profile.redis_cloud_url = session.redis_cloud_url
                    profile.session_expires_at = session.expires_at
                    profile.session_user_email = session.user_email
                    config_manager.save_config(config)

                    console.print("[green]✓[/green] Session refreshed")
                    return AuthCredentials(
                        session_id=session.jsessionid,
                        csrf_token=session.csrf_token,
                    )
            except Exception as e:
                logger.debug("Auto-refresh failed: %s", e)
                console.print(f"[yellow]Auto-refresh failed:[/yellow] {e}")

    # 5. No valid authentication - exit with helpful error
    console.print(
        "[bold red]Error:[/bold red] No authentication available.\n\n"
        "Either:\n"
        "  • Run [cyan]ctxctl auth login[/cyan] to authenticate with SM, or\n"
        "  • Provide [cyan]--admin-key <key>[/cyan] argument"
    )
    raise typer.Exit(code=1)


def _refresh_session_sync(username: str, password: str, redis_cloud_url: str) -> "SMSession | None":
    """Synchronously refresh session (wrapper for async method).

    Args:
        username: Redis Cloud username
        password: Redis Cloud password
        redis_cloud_url: Redis Cloud URL

    Returns:
        New SMSession or None if refresh failed
    """
    from context_surfaces.cli.services.sm_auth import (
        SMAuthService,
        SMLoginError,
        SMNetworkError,
        SMSession,
    )

    async def _refresh() -> SMSession:
        auth_service = SMAuthService(redis_cloud_url)
        return await auth_service.refresh_session(username, password)

    try:
        return asyncio.run(_refresh())
    except (SMLoginError, SMNetworkError) as e:
        logger.warning("Session refresh failed: %s", e)
        raise


def require_session_auth(profile_config: "ProfileConfig") -> AuthCredentials:
    """Require session authentication only.

    Used for session-only commands like 'ctxctl admin create' where
    admin API key cannot be used (for security reasons).

    Args:
        profile_config: Current profile configuration with session data

    Returns:
        AuthCredentials with session credentials

    Raises:
        typer.Exit: If no valid session is available
    """
    if not profile_config.has_valid_session():
        console.print(
            "[bold red]Error:[/bold red] SM session required.\n\n"
            "Run [cyan]ctxctl auth login[/cyan] to authenticate with SM."
        )
        raise typer.Exit(code=1)

    return AuthCredentials(
        session_id=profile_config.jsessionid,
        csrf_token=profile_config.csrf_token,
    )
