"""Redis Cloud authentication service.

Handles login/logout with Redis Cloud to obtain session credentials.
Internally uses the SM (Subscriptions Manager) API.
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta

import httpx

from context_surfaces import config
from context_surfaces.url_config import resolve_url

logger = logging.getLogger(__name__)


@dataclass
class SMSession:
    """Redis Cloud session credentials."""

    jsessionid: str
    csrf_token: str
    user_email: str
    redis_cloud_url: str
    expires_at: datetime | None = None


class SMAuthError(Exception):
    """Base exception for Redis Cloud authentication errors."""


class SMLoginError(SMAuthError):
    """Raised when login fails."""


class SMNetworkError(SMAuthError):
    """Raised when network error occurs."""


class SMAuthService:
    """Service for authenticating with Redis Cloud.

    Example:
        ```python
        service = SMAuthService("https://app.redislabs.com")
        session = await service.login("user@example.com", "password")
        print(f"Logged in as {session.user_email}")
        ```
    """

    # Default session lifetime (typically 30 minutes)
    DEFAULT_SESSION_LIFETIME = timedelta(minutes=30)

    def __init__(
        self,
        redis_cloud_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize Redis Cloud auth service.

        Args:
            redis_cloud_url: Base URL of the Redis Cloud instance.
                Resolution order: explicit value, CTX_REDIS_CLOUD_URL env var, default URL.
            timeout: Request timeout in seconds
        """
        self._base_url = resolve_url(
            explicit_value=redis_cloud_url,
            config_value=config.redis_cloud_url,
            ensure_trailing_slash=False,  # Direct string concatenation, no base_url joining
        )
        self.timeout = timeout

    async def login(self, username: str, password: str) -> SMSession:
        """Authenticate with Redis Cloud and obtain session credentials.

        Args:
            username: Redis Cloud username (email)
            password: Redis Cloud password

        Returns:
            SMSession with JSESSIONID, CSRF token, and user info

        Raises:
            SMLoginError: If authentication fails
            SMNetworkError: If network error occurs
        """
        logger.info("Logging in to Redis Cloud as %s", username)

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # Step 1: Login to get JSESSIONID
                login_url = f"{self._base_url}/api/v1/login"
                login_data = {
                    "origin": f"{self._base_url}/#",
                    "username": username,
                    "password": password,
                    "auth_mode": "direct",
                }

                login_resp = await client.post(login_url, json=login_data)

                if login_resp.status_code == 401:
                    raise SMLoginError("Invalid username or password")
                if login_resp.status_code != 200:
                    raise SMLoginError(
                        f"Login failed with status {login_resp.status_code}: {login_resp.text}"
                    )

                # Extract JSESSIONID from cookies
                jsessionid = login_resp.cookies.get("JSESSIONID")
                if not jsessionid:
                    raise SMLoginError("No JSESSIONID cookie in login response")

                # Step 2: Get CSRF token (client already has JSESSIONID from login response)
                csrf_url = f"{self._base_url}/api/v1/csrf"
                csrf_resp = await client.get(csrf_url)

                if csrf_resp.status_code != 200:
                    raise SMLoginError(f"Failed to get CSRF token: {csrf_resp.status_code}")

                csrf_data = csrf_resp.json()
                csrf_token = csrf_data.get("csrfToken", {}).get("csrf_token")
                if not csrf_token:
                    raise SMLoginError("No CSRF token in response")

                # Calculate session expiration
                expires_at = datetime.now() + self.DEFAULT_SESSION_LIFETIME

                logger.info("Successfully logged in to Redis Cloud as %s", username)

                return SMSession(
                    jsessionid=jsessionid,
                    csrf_token=csrf_token,
                    user_email=username,
                    redis_cloud_url=self._base_url,
                    expires_at=expires_at,
                )

        except httpx.RequestError as e:
            logger.error("Network error during Redis Cloud login: %s", str(e))
            raise SMNetworkError(f"Failed to connect to Redis Cloud: {e}") from e
        except httpx.TimeoutException as e:
            logger.error("Timeout during Redis Cloud login: %s", str(e))
            raise SMNetworkError(f"Connection to Redis Cloud timed out: {e}") from e

    async def logout(self, session: SMSession) -> None:
        """Logout from Redis Cloud, invalidating the session.

        Args:
            session: Active SM session to invalidate

        Raises:
            SMNetworkError: If network error occurs
        """
        logger.info("Logging out from Redis Cloud as %s", session.user_email)

        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                cookies={"JSESSIONID": session.jsessionid},
            ) as client:
                resp = await client.delete(
                    f"{self._base_url}/api/v1/login",
                    headers={"X-CSRF-Token": session.csrf_token},
                )
                if resp.status_code == 200:
                    logger.info("Successfully logged out from Redis Cloud")
                else:
                    logger.warning("Logout returned status %d", resp.status_code)
        except (httpx.RequestError, httpx.TimeoutException) as e:
            logger.warning("Logout request failed: %s", e)

    async def validate_session(
        self,
        jsessionid: str,
        csrf_token: str,
    ) -> bool:
        """Validate that a session is still active.

        Args:
            jsessionid: Session ID
            csrf_token: CSRF token

        Returns:
            True if session is valid, False otherwise
        """
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                cookies={"JSESSIONID": jsessionid},
            ) as client:
                # Try to get user info to validate session
                resp = await client.get(
                    f"{self._base_url}/api/v1/csrf",
                    headers={"X-CSRF-Token": csrf_token},
                )
                return resp.status_code == 200
        except (httpx.RequestError, httpx.TimeoutException):
            return False

    async def refresh_session(
        self,
        username: str,
        password: str,
    ) -> SMSession:
        """Refresh session using stored credentials.

        This is a convenience method that re-authenticates using stored
        credentials when a session expires.

        Args:
            username: Redis Cloud username (email)
            password: Redis Cloud password

        Returns:
            New SMSession if refresh successful

        Raises:
            SMLoginError: If credentials are invalid
            SMNetworkError: If network error occurs
        """
        logger.info("Refreshing Redis Cloud session for %s", username)
        return await self.login(username, password)
