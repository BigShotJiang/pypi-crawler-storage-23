"""Output formatter for Context Surfaces CLI.

Provides flexible output formatting with support for table, JSON, and YAML formats.
Uses rich library for beautiful table output with colors.

This module handles ONLY the presentation layer (Rich rendering). All business logic
for formatting data is in the cli.models.output module.
"""

from rich.console import Console
from rich.table import Table as RichTable

from context_surfaces.cli.models.output import (
    FormattedOutput,
    JsonOutput,
    TableOutput,
    TextOutput,
    YamlOutput,
)


class OutputFormatter:
    """Renders formatted output using Rich library.

    This class handles ONLY the presentation layer. All business logic for
    formatting data should be in the FormattedOutput data models.

    Supports rendering:
    - TextOutput: Simple text with optional styling
    - JsonOutput: Pretty-printed JSON
    - YamlOutput: Structured YAML
    - TableOutput: Beautiful tables with Rich

    Example:
        ```python
        formatter = OutputFormatter(color=True)

        # Render a text output
        text = TextOutput(text="Success!", style="bold green")
        formatter.render(text)

        # Render a table
        table = TableOutput.from_dicts([{"name": "Alice", "age": 30}])
        formatter.render(table)

        # Render JSON
        json_out = JsonOutput(data={"status": "ok"})
        formatter.render(json_out)
        ```
    """

    def __init__(self, color: bool = True) -> None:
        """Initialize the output formatter.

        Args:
            color: Whether to enable colored output (default: True)
        """
        self.color = color
        self.console = Console(
            force_terminal=color,
            no_color=not color,
            color_system="auto" if color else None,
        )

    def render(self, output: FormattedOutput) -> None:
        """Render a formatted output using Rich.

        Args:
            output: FormattedOutput instance to render

        Raises:
            ValueError: If output type is not supported
        """
        if isinstance(output, TextOutput):
            self._render_text(output)
        elif isinstance(output, JsonOutput):
            self._render_json(output)
        elif isinstance(output, YamlOutput):
            self._render_yaml(output)
        elif isinstance(output, TableOutput):
            self._render_table(output)
        else:
            raise TypeError(f"Unsupported output type: {type(output)}")

    def _render_text(self, output: TextOutput) -> None:
        """Render text output.

        Args:
            output: TextOutput instance
        """
        if output.style:
            self.console.print(output.text, style=output.style)
        else:
            self.console.print(output.text)

    def _render_json(self, output: JsonOutput) -> None:
        """Render JSON output.

        Args:
            output: JsonOutput instance
        """
        json_str = output.to_string()
        # Always use plain print for JSON to ensure it's parseable
        # Rich formatting breaks JSON parsing in scripts
        print(json_str)

    def _render_yaml(self, output: YamlOutput) -> None:
        """Render YAML output.

        Args:
            output: YamlOutput instance
        """
        yaml_str = output.to_string()
        self.console.print(yaml_str)

    def _render_table(self, output: TableOutput) -> None:
        """Render table output.

        Args:
            output: TableOutput instance
        """
        table = RichTable(
            title=output.title,
            caption=output.caption,
            show_header=output.show_header,
            show_lines=output.show_lines,
        )

        # Add columns
        for col in output.columns:
            table.add_column(
                col.header,
                style=col.style,
                justify=col.justify,
                no_wrap=col.no_wrap,
                overflow=col.overflow,
            )

        # Add rows
        for row in output.rows:
            values = [row.get_value(col, i) for i, col in enumerate(output.columns)]
            table.add_row(*values, style=row.style)

        self.console.print(table)
