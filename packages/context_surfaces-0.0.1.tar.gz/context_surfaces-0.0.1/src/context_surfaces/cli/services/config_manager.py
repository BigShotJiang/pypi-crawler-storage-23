"""Configuration manager for Context Surfaces CLI.

Manages configuration with hierarchy: CLI flags > env vars > config file > defaults.
Supports multiple profiles (production, staging, development).
"""

import os
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar

import yaml
from pydantic import BaseModel, Field, field_validator

from context_surfaces.constants import (
    CLI_APP_NAME,
    DEFAULT_API_URL,
    DEFAULT_MCP_URL,
    DEFAULT_REDIS_CLOUD_URL,
)


class LogLevel(str, Enum):
    """Log level enumeration."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class OutputFormat(str, Enum):
    """Output format enumeration."""

    TABLE = "table"
    JSON = "json"
    YAML = "yaml"


class ProfileConfig(BaseModel):
    """Configuration for a single profile."""

    api_url: str = Field(
        default=DEFAULT_API_URL,
        description="API base URL",
    )
    mcp_url: str = Field(
        default=DEFAULT_MCP_URL,
        description="MCP server URL",
    )
    default_output_format: OutputFormat = Field(
        default=OutputFormat.TABLE,
        description="Default output format",
    )
    color_output: bool = Field(
        default=True,
        description="Enable colored output",
    )
    log_level: LogLevel = Field(
        default=LogLevel.INFO,
        description="Logging level",
    )
    timeout: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Request timeout in seconds",
    )

    # Session credentials (for ctxctl login)
    redis_cloud_url: str | None = Field(
        default=DEFAULT_REDIS_CLOUD_URL,
        description="Redis Cloud URL used for login",
    )
    jsessionid: str | None = Field(
        default=None,
        description="Session ID (stored securely)",
    )
    csrf_token: str | None = Field(
        default=None,
        description="CSRF token for authenticated requests",
    )
    session_expires_at: datetime | None = Field(
        default=None,
        description="Session expiration timestamp",
    )
    session_user_email: str | None = Field(
        default=None,
        description="Email of logged-in user",
    )

    @field_validator("api_url", "mcp_url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate URL format."""
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        return v.rstrip("/")

    @field_validator("redis_cloud_url")
    @classmethod
    def validate_redis_cloud_url(cls, v: str | None) -> str | None:
        """Validate Redis Cloud URL format if provided."""
        if v is None:
            return v
        if not v:
            raise ValueError("Redis Cloud URL cannot be empty if provided")
        if not v.startswith(("http://", "https://")):
            raise ValueError("Redis Cloud URL must start with http:// or https://")
        return v.rstrip("/")

    def has_valid_session(self) -> bool:
        """Check if profile has a valid (non-expired) session.

        Returns:
            True if session credentials exist and are not expired
        """
        if not self.jsessionid or not self.csrf_token:
            return False
        if self.session_expires_at is None:
            # No expiration set, assume valid
            return True
        return datetime.now() < self.session_expires_at

    def clear_session(self) -> None:
        """Clear all session credentials."""
        self.jsessionid = None
        self.csrf_token = None
        self.session_expires_at = None
        self.session_user_email = None


class Config(BaseModel):
    """Main configuration model with multiple profiles."""

    default_profile: str = Field(
        default="development",
        description="Default profile to use",
    )
    profiles: dict[str, ProfileConfig] = Field(
        default_factory=lambda: {
            "development": ProfileConfig(),
            "staging": ProfileConfig(
                api_url="https://staging.context-surfaces.example.com",
                mcp_url="https://staging.context-surfaces.example.com/mcp",
            ),
            "production": ProfileConfig(
                api_url="https://context-surfaces.example.com",
                mcp_url="https://context-surfaces.example.com/mcp",
                log_level=LogLevel.WARNING,
            ),
        },
        description="Profile configurations",
    )

    @field_validator("default_profile")
    @classmethod
    def validate_default_profile(cls, v: str) -> str:
        """Validate that default_profile exists in profiles."""
        # Note: This validator runs before profiles is set, so we can't validate here
        # Validation happens in ConfigManager.validate()
        return v


class ConfigManager:
    """Manages CLI configuration with support for profiles and hierarchy.

    Configuration hierarchy (highest to lowest priority):
    1. CLI flags (passed directly to commands)
    2. Environment variables (CTX_API_URL, CTX_MCP_URL, etc.)
    3. Config file (~/.config/ctxctl/config.yaml)
    4. Defaults (built-in defaults)
    """

    # Environment variable mappings
    ENV_VARS: ClassVar[dict[str, str]] = {
        "api_url": "CTX_API_URL",
        "mcp_url": "CTX_MCP_URL",
        "default_output_format": "CTX_OUTPUT_FORMAT",
        "color_output": "CTX_COLOR_OUTPUT",
        "log_level": "CTX_LOG_LEVEL",
        "timeout": "CTX_TIMEOUT",
    }

    def __init__(self, config_path: Path | None = None) -> None:
        """Initialize config manager.

        Args:
            config_path: Path to config file. Defaults to ~/.config/ctxctl/config.yaml
        """
        if config_path is None:
            config_path = Path.home() / ".config" / CLI_APP_NAME / "config.yaml"
        self.config_path = config_path
        self._config: Config | None = None

    def _ensure_config_dir(self) -> None:
        """Create config directory if it doesn't exist."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def load_config(self) -> Config:
        """Load configuration from file.

        Returns:
            Config object loaded from file or defaults if file doesn't exist

        Raises:
            ValueError: If config file is invalid
            yaml.YAMLError: If YAML parsing fails
        """
        if not self.config_path.exists():
            # Return default config if file doesn't exist
            self._config = Config()
            return self._config

        try:
            with open(self.config_path) as f:
                data = yaml.safe_load(f)

            if data is None:
                # Empty file, use defaults
                self._config = Config()
            else:
                self._config = Config(**data)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in config file: {e}") from e
        except Exception as e:
            raise ValueError(f"Failed to load config: {e}") from e
        else:
            return self._config

    def save_config(self, config: Config | None = None) -> None:
        """Save configuration to file.

        Args:
            config: Config object to save. If None, saves current config.

        Raises:
            ValueError: If no config to save
            yaml.YAMLError: If YAML serialization fails
        """
        if config is None:
            config = self._config

        if config is None:
            raise ValueError("No config to save")

        self._ensure_config_dir()

        try:
            with open(self.config_path, "w") as f:
                # Convert to dict for YAML serialization (mode="json" serializes enums as values)
                data = config.model_dump(mode="json")
                yaml.safe_dump(data, f, default_flow_style=False, sort_keys=False)
        except Exception as e:
            raise ValueError(f"Failed to save config: {e}") from e

    def get(
        self,
        key: str,
        profile: str | None = None,
        cli_value: Any = None,
    ) -> Any:
        """Get configuration value with hierarchy.

        Hierarchy (highest to lowest priority):
        1. CLI value (if provided)
        2. Environment variable
        3. Config file
        4. Default

        Args:
            key: Configuration key (e.g., 'api_url', 'timeout')
            profile: Profile name. If None, uses default_profile
            cli_value: Value from CLI flag (highest priority)

        Returns:
            Configuration value

        Raises:
            ValueError: If key is invalid or profile doesn't exist
        """
        # 1. CLI value has highest priority
        if cli_value is not None:
            return cli_value

        # 2. Check environment variable
        env_var = self.ENV_VARS.get(key)
        if env_var:
            env_value = os.getenv(env_var)
            if env_value is not None:
                # Convert to appropriate type
                return self._convert_env_value(key, env_value)

        # 3. Load config from file if not already loaded
        if self._config is None:
            self.load_config()

        # 4. Get from config file or defaults
        if self._config is None:
            raise ValueError("Failed to load config")

        # Determine which profile to use
        if profile is None:
            profile = self._config.default_profile

        if profile not in self._config.profiles:
            raise ValueError(f"Profile '{profile}' not found in config")

        profile_config = self._config.profiles[profile]

        # Get value from profile config
        if not hasattr(profile_config, key):
            raise ValueError(f"Invalid config key: {key}")

        return getattr(profile_config, key)

    def set(
        self,
        key: str,
        value: Any,
        profile: str | None = None,
        save: bool = True,
    ) -> None:
        """Set configuration value.

        Args:
            key: Configuration key (e.g., 'api_url', 'timeout')
            value: Value to set
            profile: Profile name. If None, uses default_profile
            save: Whether to save config to file after setting

        Raises:
            ValueError: If key is invalid or profile doesn't exist
        """
        # Load config if not already loaded
        if self._config is None:
            self.load_config()

        if self._config is None:
            raise ValueError("Failed to load config")

        # Determine which profile to use
        if profile is None:
            profile = self._config.default_profile

        if profile not in self._config.profiles:
            # Create new profile with defaults
            self._config.profiles[profile] = ProfileConfig()

        profile_config = self._config.profiles[profile]

        # Validate key exists
        if not hasattr(profile_config, key):
            raise ValueError(f"Invalid config key: {key}")

        # Set value (Pydantic will validate)
        try:
            setattr(profile_config, key, value)
        except Exception as e:
            raise ValueError(f"Invalid value for {key}: {e}") from e

        # Save if requested
        if save:
            self.save_config()

    def validate(self) -> bool:
        """Validate current configuration.

        Returns:
            True if config is valid

        Raises:
            ValueError: If config is invalid
        """
        if self._config is None:
            self.load_config()

        if self._config is None:
            raise ValueError("No config to validate")

        # Validate default_profile exists
        if self._config.default_profile not in self._config.profiles:
            raise ValueError(
                f"Default profile '{self._config.default_profile}' not found in profiles"
            )

        # Pydantic already validates the model structure
        # Additional custom validation can be added here
        return True

    def reset(self, profile: str | None = None, save: bool = True) -> None:
        """Reset configuration to defaults.

        Args:
            profile: Profile to reset. If None, resets entire config
            save: Whether to save config to file after resetting

        Raises:
            ValueError: If profile doesn't exist
        """
        if profile is None:
            # Reset entire config
            self._config = Config()
        else:
            # Reset specific profile
            if self._config is None:
                self.load_config()

            if self._config is None:
                raise ValueError("Failed to load config")

            if profile not in self._config.profiles:
                raise ValueError(f"Profile '{profile}' not found in config")

            # Reset to default profile config
            self._config.profiles[profile] = ProfileConfig()

        # Save if requested
        if save:
            self.save_config()

    def _convert_env_value(self, key: str, value: str) -> Any:
        """Convert environment variable string to appropriate type.

        Args:
            key: Configuration key
            value: String value from environment variable

        Returns:
            Converted value
        """
        # Boolean conversion
        if key == "color_output":
            return value.lower() in ("true", "1", "yes", "on")

        # Integer conversion
        if key == "timeout":
            try:
                return int(value)
            except ValueError as e:
                raise ValueError(f"Invalid integer value for {key}: {value}") from e

        # Enum conversion
        if key == "log_level":
            try:
                return LogLevel(value.lower())
            except ValueError as e:
                raise ValueError(
                    f"Invalid log level: {value}. "
                    f"Must be one of: {', '.join(e.value for e in LogLevel)}"
                ) from e

        if key == "default_output_format":
            try:
                return OutputFormat(value.lower())
            except ValueError as e:
                raise ValueError(
                    f"Invalid output format: {value}. "
                    f"Must be one of: {', '.join(e.value for e in OutputFormat)}"
                ) from e

        # String values (api_url, mcp_url)
        return value

    def get_profile_config(self, profile: str | None = None) -> ProfileConfig:
        """Get complete profile configuration.

        Args:
            profile: Profile name. If None, uses default_profile

        Returns:
            ProfileConfig object

        Raises:
            ValueError: If profile doesn't exist
        """
        if self._config is None:
            self.load_config()

        if self._config is None:
            raise ValueError("Failed to load config")

        if profile is None:
            profile = self._config.default_profile

        if profile not in self._config.profiles:
            raise ValueError(f"Profile '{profile}' not found in config")

        return self._config.profiles[profile]

    def list_profiles(self) -> list[str]:
        """List all available profiles.

        Returns:
            List of profile names
        """
        if self._config is None:
            self.load_config()

        if self._config is None:
            return []

        return list(self._config.profiles.keys())

    def create_profile(
        self,
        name: str,
        base_profile: str | None = None,
        save: bool = True,
    ) -> None:
        """Create a new profile.

        Args:
            name: Name for the new profile
            base_profile: Profile to copy settings from. If None, uses defaults
            save: Whether to save config to file after creating

        Raises:
            ValueError: If profile already exists or base_profile doesn't exist
        """
        if self._config is None:
            self.load_config()

        if self._config is None:
            raise ValueError("Failed to load config")

        if name in self._config.profiles:
            raise ValueError(f"Profile '{name}' already exists")

        if base_profile is None:
            # Create with defaults
            self._config.profiles[name] = ProfileConfig()
        else:
            if base_profile not in self._config.profiles:
                raise ValueError(f"Base profile '{base_profile}' not found")

            # Copy from base profile
            base_config = self._config.profiles[base_profile]
            self._config.profiles[name] = ProfileConfig(**base_config.model_dump())

        if save:
            self.save_config()

    def delete_profile(self, name: str, save: bool = True) -> None:
        """Delete a profile.

        Args:
            name: Profile name to delete
            save: Whether to save config to file after deleting

        Raises:
            ValueError: If profile doesn't exist or is the default profile
        """
        if self._config is None:
            self.load_config()

        if self._config is None:
            raise ValueError("Failed to load config")

        if name not in self._config.profiles:
            raise ValueError(f"Profile '{name}' not found")

        if name == self._config.default_profile:
            raise ValueError(
                f"Cannot delete default profile '{name}'. Change default_profile first."
            )

        del self._config.profiles[name]

        if save:
            self.save_config()
