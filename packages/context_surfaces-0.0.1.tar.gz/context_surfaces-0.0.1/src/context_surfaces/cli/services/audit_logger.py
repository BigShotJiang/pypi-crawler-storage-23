"""Audit logger for Context Surfaces CLI.

Provides secure audit logging of all CLI operations with log rotation,
structured formatting, and security best practices.
"""

import logging
import re
import threading
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Literal

from context_surfaces.constants import CLI_APP_NAME

# Log levels
LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

# Operation status
OperationStatus = Literal["success", "failed"]


class AuditLoggerError(Exception):
    """Base exception for audit logger errors."""


class AuditLogger:
    """Thread-safe audit logger for CLI operations.

    Features:
    - Structured logging with consistent format
    - Automatic log rotation (10MB max, 5 backup files)
    - Thread-safe operations
    - Security: Never logs actual API keys, only key IDs/names
    - ISO 8601 timestamps
    - Creates log directory if it doesn't exist

    Log format:
        timestamp [level] user=X action=Y resource_id=Z status=success/failed error=...

    Example:
        ```python
        logger = AuditLogger()

        # Log successful operation
        logger.log_success(
            user="ops-team",
            action="surface.create",
            resource_id="surface-123"
        )

        # Log failed operation
        logger.log_failure(
            user="ops-team",
            action="surface.delete",
            resource_id="surface-789",
            error="not found"
        )

        # Log authentication
        logger.log_auth(
            user="ops-team",
            action="login",
            key_id="key-abc123"
        )
        ```
    """

    # Configuration
    LOG_DIR = Path.home() / ".config" / CLI_APP_NAME
    LOG_FILE = LOG_DIR / "audit.log"
    MAX_LOG_SIZE = 10 * 1024 * 1024  # 10MB
    BACKUP_COUNT = 5  # Keep last 5 rotated files

    API_KEY_PATTERN = re.compile(r"cs_(admin|agent)_[a-zA-Z0-9]+")

    def __init__(self, log_file: Path | None = None) -> None:
        """Initialize audit logger.

        Args:
            log_file: Optional custom log file path (defaults to ~/.config/ctxctl/audit.log)
        """
        self._log_file = log_file or self.LOG_FILE
        self._lock = threading.Lock()
        self._logger = self._setup_logger()

    def _setup_logger(self) -> logging.Logger:
        """Set up the rotating file logger.

        Returns:
            Configured logger instance

        Raises:
            AuditLoggerError: If log directory cannot be created
        """
        # Create log directory if it doesn't exist
        try:
            self._log_file.parent.mkdir(parents=True, exist_ok=True)
            # Set secure permissions (owner read/write only)
            self._log_file.parent.chmod(0o700)
        except OSError as e:
            raise AuditLoggerError(f"Failed to create log directory: {e}") from e

        # Create logger
        logger = logging.getLogger(f"{CLI_APP_NAME}.audit.{id(self)}")
        logger.setLevel(logging.DEBUG)
        logger.propagate = False  # Don't propagate to root logger

        # Remove existing handlers to avoid duplicates
        logger.handlers.clear()

        # Create rotating file handler
        try:
            handler = RotatingFileHandler(
                self._log_file,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding="utf-8",
            )
        except OSError as e:
            raise AuditLoggerError(f"Failed to create log file: {e}") from e

        # Set secure permissions on log file (owner read/write only)
        try:
            self._log_file.chmod(0o600)
        except OSError:
            # Best effort - may fail on some systems
            pass

        # Create formatter (we'll format messages ourselves for consistency)
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)

        return logger

    def _sanitize_value(self, value: Any) -> str:
        """Sanitize a value to prevent logging sensitive data.

        Replaces any detected API keys with [REDACTED].

        Args:
            value: Value to sanitize

        Returns:
            Sanitized string value
        """
        str_value = str(value)
        return self.API_KEY_PATTERN.sub("[REDACTED]", str_value)

    def _format_log_entry(
        self,
        level: LogLevel,
        user: str,
        action: str,
        status: OperationStatus,
        **kwargs: Any,
    ) -> str:
        """Format a log entry according to the standard format.

        Args:
            level: Log level
            user: User or key identifier
            action: Action being performed
            status: Operation status (success/failed)
            **kwargs: Additional key-value pairs (resource_id, error, etc.)

        Returns:
            Formatted log entry string
        """
        # ISO 8601 timestamp with UTC timezone
        timestamp = datetime.now(UTC).isoformat()

        # Build key-value pairs
        parts = [
            f"user={self._sanitize_value(user)}",
            f"action={action}",
        ]

        # Add optional fields
        for key, value in kwargs.items():
            if value is not None:
                sanitized = self._sanitize_value(value)
                parts.append(f"{key}={sanitized}")

        # Add status
        parts.append(f"status={status}")

        # Format: timestamp [level] key1=value1 key2=value2 ...
        return f"{timestamp} [{level}] {' '.join(parts)}"

    def log_operation(
        self,
        user: str,
        action: str,
        status: OperationStatus,
        level: LogLevel = "INFO",
        **kwargs: Any,
    ) -> None:
        """Log a CLI operation.

        Args:
            user: User or key identifier (never the actual key)
            action: Action being performed (e.g., "surface.create", "key.delete")
            status: Operation status (success/failed)
            level: Log level (default: INFO)
            **kwargs: Additional context (resource_id, error, etc.)

        Example:
            ```python
            logger.log_operation(
                user="ops-team",
                action="surface.create",
                status="success",
                resource_id="surface-123",
                redis_instance_id="redis-456"
            )
            ```
        """
        with self._lock:
            log_entry = self._format_log_entry(level, user, action, status, **kwargs)

            # Map our log level to Python logging level
            level_map = {
                "DEBUG": logging.DEBUG,
                "INFO": logging.INFO,
                "WARNING": logging.WARNING,
                "ERROR": logging.ERROR,
                "CRITICAL": logging.CRITICAL,
            }
            self._logger.log(level_map[level], log_entry)

    def log_success(
        self,
        user: str,
        action: str,
        level: LogLevel = "INFO",
        **kwargs: Any,
    ) -> None:
        """Log a successful operation.

        Args:
            user: User or key identifier (never the actual key)
            action: Action being performed
            level: Log level (default: INFO)
            **kwargs: Additional context (resource_id, etc.)

        Example:
            ```python
            logger.log_success(
                user="ops-team",
                action="surface.create",
                resource_id="surface-123"
            )
            ```
        """
        self.log_operation(user, action, "success", level, **kwargs)

    def log_failure(
        self,
        user: str,
        action: str,
        error: str,
        level: LogLevel = "ERROR",
        **kwargs: Any,
    ) -> None:
        """Log a failed operation.

        Args:
            user: User or key identifier (never the actual key)
            action: Action being performed
            error: Error message
            level: Log level (default: ERROR)
            **kwargs: Additional context (resource_id, etc.)

        Example:
            ```python
            logger.log_failure(
                user="ops-team",
                action="surface.delete",
                error="not found",
                resource_id="surface-789"
            )
            ```
        """
        self.log_operation(user, action, "failed", level, error=error, **kwargs)

    def log_auth(
        self,
        user: str,
        action: str,
        key_id: str | None = None,
        key_name: str | None = None,
        status: OperationStatus = "success",
        level: LogLevel = "INFO",
        **kwargs: Any,
    ) -> None:
        """Log an authentication-related operation.

        Args:
            user: User identifier
            action: Authentication action (e.g., "login", "logout", "key.create")
            key_id: API key ID (not the actual key)
            key_name: API key name
            status: Operation status (default: success)
            level: Log level (default: INFO)
            **kwargs: Additional context (error, etc.)

        Example:
            ```python
            # Successful login
            logger.log_auth(
                user="ops-team",
                action="login",
                key_id="key-abc123",
                key_name="my-admin-key"
            )

            # Failed authentication
            logger.log_auth(
                user="unknown",
                action="login",
                status="failed",
                error="invalid credentials"
            )
            ```
        """
        # Add key_id and key_name to kwargs if provided
        if key_id is not None:
            kwargs["key_id"] = key_id
        if key_name is not None:
            kwargs["key_name"] = key_name

        self.log_operation(user, action, status, level, **kwargs)

    def close(self) -> None:
        """Close the logger and flush all handlers.

        Should be called when the logger is no longer needed.
        """
        with self._lock:
            for handler in self._logger.handlers:
                handler.close()
            self._logger.handlers.clear()

    def __enter__(self) -> "AuditLogger":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        self.close()
