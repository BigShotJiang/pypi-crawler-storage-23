"""Secure credential manager for Context Surfaces CLI.

Provides secure storage and retrieval of API keys using OS-level keyring
with fallback to AES-256-GCM encrypted config file.
"""

import json
import logging
import os
import platform
import uuid
from pathlib import Path
from typing import Literal

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from context_surfaces.constants import CLI_APP_NAME

try:
    import keyring
    import keyring.errors

    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False

logger = logging.getLogger(__name__)

KeyType = Literal["admin", "agent"]


class CredentialManagerError(Exception):
    """Base exception for credential manager errors."""


class KeyringUnavailableError(CredentialManagerError):
    """Raised when keyring is not available and fallback is disabled."""


class EncryptionError(CredentialManagerError):
    """Raised when encryption/decryption fails."""


class CredentialManager:
    """Secure credential manager with OS keyring and encrypted fallback.

    Security features:
    - Primary: OS-level keyring (macOS Keychain, Windows Credential Manager, Linux Secret Service)
    - Fallback: AES-256-GCM encrypted config file
    - Key derivation: PBKDF2 with machine ID + user password
    - Never logs actual key values, only key IDs
    - Secure file permissions (0600) for encrypted credentials

    Example:
        ```python
        manager = CredentialManager()

        # Store admin key
        manager.store_admin_key("my-admin", "cs_admin_abc123...")

        # Retrieve admin key
        key = manager.get_admin_key("my-admin")

        # List all keys
        keys = manager.list_keys()
        ```
    """

    SERVICE_NAME = "context-surfaces"
    CONFIG_DIR = Path.home() / ".config" / CLI_APP_NAME
    CREDENTIALS_FILE = CONFIG_DIR / "credentials.enc"

    # PBKDF2 parameters
    PBKDF2_ITERATIONS = 600_000  # OWASP recommendation for 2024
    SALT_SIZE = 32  # 256 bits
    KEY_SIZE = 32  # 256 bits for AES-256

    def __init__(
        self,
        use_keyring: bool = True,
        password: str | None = None,
    ) -> None:
        """Initialize credential manager.

        Args:
            use_keyring: Whether to use OS keyring (falls back to encrypted file if unavailable)
            password: Password for encrypted file fallback (prompted if not provided).
                      Can also be set via CTX_CREDENTIAL_PASSWORD environment variable.

        Raises:
            KeyringUnavailableError: If keyring is requested but not available
        """
        self._use_keyring = use_keyring and KEYRING_AVAILABLE
        self._password = password or os.environ.get("CTX_CREDENTIAL_PASSWORD")
        self._machine_id: str | None = None

        if use_keyring and not KEYRING_AVAILABLE:
            logger.debug("Keyring library not available, using encrypted file storage")
            self._use_keyring = False

        if self._use_keyring:
            self._use_keyring = self._probe_keyring()

        if not self._use_keyring:
            self._ensure_config_dir()

        logger.debug("Credential manager initialized (keyring=%s)", self._use_keyring)

    def _probe_keyring(self) -> bool:
        """Test keyring access with a throwaway write/read/delete cycle.

        Returns:
            True if keyring is functional, False otherwise.
        """
        probe_key = "__cce_probe__"
        try:
            keyring.set_password(self.SERVICE_NAME, probe_key, "probe")
            keyring.delete_password(self.SERVICE_NAME, probe_key)
            return True
        except Exception:
            logger.debug("Keyring unavailable on this system, using encrypted file storage")
            return False

    def _get_machine_id(self) -> str:
        """Get or generate a unique machine identifier.

        Returns:
            Machine ID string

        Note:
            This is used as part of the encryption key derivation to ensure
            credentials encrypted on one machine cannot be easily decrypted on another.
        """
        if self._machine_id is not None:
            return self._machine_id

        machine_id_file = self.CONFIG_DIR / ".machine_id"

        if machine_id_file.exists():
            self._machine_id = machine_id_file.read_text().strip()
        else:
            self._machine_id = str(uuid.uuid4())
            self._ensure_config_dir()
            machine_id_file.write_text(self._machine_id)
            if platform.system() != "Windows":
                os.chmod(machine_id_file, 0o600)

        return self._machine_id

    def _derive_key(self, password: str, salt: bytes) -> bytes:
        """Derive encryption key from password and salt using PBKDF2.

        Args:
            password: User password
            salt: Cryptographic salt

        Returns:
            Derived encryption key (32 bytes)
        """
        # Combine password with machine ID for additional security
        machine_id = self._get_machine_id()
        combined = f"{password}:{machine_id}".encode()

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=self.KEY_SIZE,
            salt=salt,
            iterations=self.PBKDF2_ITERATIONS,
            backend=default_backend(),
        )
        derived_key: bytes = kdf.derive(combined)
        return derived_key

    def _get_password(self) -> str:
        """Get password for encryption, prompting if necessary.

        Returns:
            Password string

        Raises:
            CredentialManagerError: If password cannot be obtained
        """
        if self._password is not None:
            return self._password

        # In production, this would prompt the user
        # For now, use a default (should be improved)
        import getpass

        try:
            password = getpass.getpass("Enter password for credential encryption: ")
            if not password:
                raise CredentialManagerError("Password cannot be empty")
            return password
        except (KeyboardInterrupt, EOFError) as e:
            raise CredentialManagerError("Password input cancelled") from e

    def _load_encrypted_credentials(self) -> dict[str, dict[str, str]]:
        """Load and decrypt credentials from file.

        Returns:
            Dictionary of credentials by type and name

        Raises:
            EncryptionError: If decryption fails
        """
        if not self.CREDENTIALS_FILE.exists():
            return {}

        try:
            encrypted_data = self.CREDENTIALS_FILE.read_bytes()

            # Extract salt (first SALT_SIZE bytes)
            if len(encrypted_data) < self.SALT_SIZE:
                raise EncryptionError("Invalid credentials file: too short")

            salt = encrypted_data[: self.SALT_SIZE]
            ciphertext = encrypted_data[self.SALT_SIZE :]

            # Derive key and decrypt
            password = self._get_password()
            key = self._derive_key(password, salt)
            aesgcm = AESGCM(key)

            # Nonce is prepended to ciphertext (12 bytes for GCM)
            nonce = ciphertext[:12]
            encrypted = ciphertext[12:]

            plaintext = aesgcm.decrypt(nonce, encrypted, None)
            credentials_data = json.loads(plaintext.decode("utf-8"))

            # Ensure proper type structure
            if not isinstance(credentials_data, dict):
                raise EncryptionError("Invalid credentials file format")

            credentials: dict[str, dict[str, str]] = {}
            for key_type, keys in credentials_data.items():
                if isinstance(keys, dict):
                    credentials[key_type] = {k: str(v) for k, v in keys.items()}

            logger.debug("Loaded %d credential entries from encrypted file", len(credentials))
            return credentials

        except Exception as e:
            logger.error("Failed to decrypt credentials: %s", str(e))
            raise EncryptionError(f"Failed to decrypt credentials: {e}") from e

    def _ensure_config_dir(self) -> None:
        """Ensure config directory exists with secure permissions."""
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if platform.system() != "Windows":
            os.chmod(self.CONFIG_DIR, 0o700)

    def _save_encrypted_credentials(self, credentials: dict[str, dict[str, str]]) -> None:
        """Encrypt and save credentials to file.

        Args:
            credentials: Dictionary of credentials by type and name

        Raises:
            EncryptionError: If encryption fails
        """
        try:
            self._ensure_config_dir()

            # Generate salt and derive key
            salt = os.urandom(self.SALT_SIZE)
            password = self._get_password()
            key = self._derive_key(password, salt)

            # Encrypt credentials
            aesgcm = AESGCM(key)
            nonce = os.urandom(12)  # 96 bits for GCM
            plaintext = json.dumps(credentials).encode("utf-8")
            ciphertext = aesgcm.encrypt(nonce, plaintext, None)

            # Write: salt + nonce + ciphertext
            encrypted_data = salt + nonce + ciphertext
            self.CREDENTIALS_FILE.write_bytes(encrypted_data)

            # Secure file permissions
            if platform.system() != "Windows":
                os.chmod(self.CREDENTIALS_FILE, 0o600)

            logger.debug("Saved %d credential entries to encrypted file", len(credentials))

        except Exception as e:
            logger.error("Failed to encrypt credentials: %s", str(e))
            raise EncryptionError(f"Failed to encrypt credentials: {e}") from e

    def _keyring_key(self, key_type: KeyType, name: str) -> str:
        """Generate keyring key identifier.

        Args:
            key_type: Type of key (admin or agent)
            name: Key name

        Returns:
            Keyring identifier string
        """
        return f"{key_type}:{name}"

    def store_admin_key(self, name: str, key: str) -> None:
        """Store an admin API key securely.

        Args:
            name: Unique name for the key
            key: The actual API key value

        Raises:
            CredentialManagerError: If storage fails

        Example:
            ```python
            manager.store_admin_key("production", "cs_admin_abc123...")
            ```
        """
        logger.info("Storing admin key: %s", name)  # Never log the actual key

        if self._use_keyring:
            try:
                keyring.set_password(self.SERVICE_NAME, self._keyring_key("admin", name), key)
                self._update_keyring_metadata("admin", name)
                return
            except keyring.errors.KeyringError:
                logger.debug("Keyring write failed, falling back to encrypted file")
                self._use_keyring = False

        credentials = self._load_encrypted_credentials()
        if "admin" not in credentials:
            credentials["admin"] = {}
        credentials["admin"][name] = key
        self._save_encrypted_credentials(credentials)

    def get_admin_key(self, name: str) -> str | None:
        """Retrieve an admin API key.

        Args:
            name: Name of the key to retrieve

        Returns:
            The API key value, or None if not found

        Example:
            ```python
            key = manager.get_admin_key("production")
            if key:
                print("Key found")
            ```
        """
        logger.debug("Retrieving admin key: %s", name)

        if self._use_keyring:
            try:
                return keyring.get_password(self.SERVICE_NAME, self._keyring_key("admin", name))
            except keyring.errors.KeyringError:
                logger.debug("Keyring read failed, falling back to encrypted file")
                self._use_keyring = False

        credentials = self._load_encrypted_credentials()
        return credentials.get("admin", {}).get(name)

    def store_agent_key(self, name: str, key: str) -> None:
        """Store an agent API key securely.

        Args:
            name: Unique name for the key
            key: The actual API key value

        Raises:
            CredentialManagerError: If storage fails

        Example:
            ```python
            manager.store_agent_key("agent-1", "cs_agent_xyz789...")
            ```
        """
        logger.info("Storing agent key: %s", name)  # Never log the actual key

        if self._use_keyring:
            try:
                keyring.set_password(self.SERVICE_NAME, self._keyring_key("agent", name), key)
                self._update_keyring_metadata("agent", name)
                return
            except keyring.errors.KeyringError:
                logger.debug("Keyring write failed, falling back to encrypted file")
                self._use_keyring = False

        credentials = self._load_encrypted_credentials()
        if "agent" not in credentials:
            credentials["agent"] = {}
        credentials["agent"][name] = key
        self._save_encrypted_credentials(credentials)

    def get_agent_key(self, name: str) -> str | None:
        """Retrieve an agent API key.

        Args:
            name: Name of the key to retrieve

        Returns:
            The API key value, or None if not found

        Example:
            ```python
            key = manager.get_agent_key("agent-1")
            if key:
                print("Key found")
            ```
        """
        logger.debug("Retrieving agent key: %s", name)

        if self._use_keyring:
            try:
                return keyring.get_password(self.SERVICE_NAME, self._keyring_key("agent", name))
            except keyring.errors.KeyringError:
                logger.debug("Keyring read failed, falling back to encrypted file")
                self._use_keyring = False

        credentials = self._load_encrypted_credentials()
        return credentials.get("agent", {}).get(name)

    def delete_key(self, key_type: KeyType, name: str) -> bool:
        """Delete a stored API key.

        Args:
            key_type: Type of key (admin or agent)
            name: Name of the key to delete

        Returns:
            True if key was deleted, False if not found

        Example:
            ```python
            if manager.delete_key("admin", "old-key"):
                print("Key deleted")
            ```
        """
        logger.info("Deleting %s key: %s", key_type, name)

        deleted = False

        if self._use_keyring:
            try:
                keyring.delete_password(self.SERVICE_NAME, self._keyring_key(key_type, name))
                self._update_keyring_metadata(key_type, name, delete=True)
                deleted = True
            except keyring.errors.PasswordDeleteError:
                logger.debug("Key not found in OS keyring")
            except keyring.errors.KeyringError:
                logger.debug("Keyring delete failed, falling back to encrypted file")
                self._use_keyring = False

        # Also try encrypted file
        if not self._use_keyring or not deleted:
            credentials = self._load_encrypted_credentials()
            if key_type in credentials and name in credentials[key_type]:
                del credentials[key_type][name]
                self._save_encrypted_credentials(credentials)
                deleted = True

        return deleted

    def list_keys(self) -> dict[str, list[str]]:
        """List all stored API keys.

        Returns:
            Dictionary with 'admin' and 'agent' lists of key names

        Example:
            ```python
            keys = manager.list_keys()
            print(f"Admin keys: {keys['admin']}")
            print(f"Agent keys: {keys['agent']}")
            ```

        Note:
            This only returns key names, not the actual key values.
            Keyring backend may not support listing, so this primarily
            works with encrypted file storage.
        """
        logger.debug("Listing all stored keys")

        result: dict[str, list[str]] = {"admin": [], "agent": []}

        # For encrypted file, we can list all keys
        if not self._use_keyring:
            credentials = self._load_encrypted_credentials()
            result["admin"] = list(credentials.get("admin", {}).keys())
            result["agent"] = list(credentials.get("agent", {}).keys())
        else:
            # Keyring doesn't support listing, so we maintain a metadata file
            metadata_file = self.CONFIG_DIR / ".keyring_metadata.json"
            if metadata_file.exists():
                try:
                    metadata = json.loads(metadata_file.read_text())
                    result["admin"] = metadata.get("admin", [])
                    result["agent"] = metadata.get("agent", [])
                except Exception as e:
                    logger.warning("Failed to read keyring metadata: %s", e)

        logger.debug(
            "Found %d admin keys and %d agent keys", len(result["admin"]), len(result["agent"])
        )
        return result

    def _update_keyring_metadata(self, key_type: KeyType, name: str, delete: bool = False) -> None:
        """Update metadata file for keyring storage.

        Args:
            key_type: Type of key (admin or agent)
            name: Key name
            delete: Whether to delete the entry (vs add)
        """
        if not self._use_keyring:
            return

        metadata_file = self.CONFIG_DIR / ".keyring_metadata.json"
        metadata: dict[str, list[str]] = {"admin": [], "agent": []}

        if metadata_file.exists():
            try:
                metadata = json.loads(metadata_file.read_text())
            except Exception as e:
                logger.warning("Failed to read keyring metadata: %s", e)

        if delete:
            if name in metadata.get(key_type, []):
                metadata[key_type].remove(name)
        elif name not in metadata.get(key_type, []):
            if key_type not in metadata:
                metadata[key_type] = []
            metadata[key_type].append(name)

        try:
            self._ensure_config_dir()
            metadata_file.write_text(json.dumps(metadata, indent=2))
            if platform.system() != "Windows":
                os.chmod(metadata_file, 0o600)
        except Exception as e:
            logger.warning("Failed to update keyring metadata: %s", e)

    # =========================================================================
    # SM Credentials Storage (for session-based authentication)
    # =========================================================================

    def store_sm_credentials(self, username: str, password: str, profile: str = "default") -> None:
        """Store SM credentials securely in keyring.

        Args:
            username: SM username (email)
            password: SM password
            profile: Profile name for credential isolation

        Raises:
            CredentialManagerError: If storage fails

        Example:
            ```python
            manager.store_sm_credentials("user@example.com", "password123")
            ```
        """
        logger.info("Storing SM credentials for profile: %s", profile)

        # Store as JSON to keep username and password together
        credentials_json = json.dumps({"username": username, "password": password})
        keyring_key = f"sm_credentials:{profile}"

        if self._use_keyring:
            try:
                keyring.set_password(self.SERVICE_NAME, keyring_key, credentials_json)
                return
            except keyring.errors.KeyringError:
                logger.debug("Keyring write failed, falling back to encrypted file")
                self._use_keyring = False

        credentials = self._load_encrypted_credentials()
        if "sm_credentials" not in credentials:
            credentials["sm_credentials"] = {}
        credentials["sm_credentials"][profile] = credentials_json
        self._save_encrypted_credentials(credentials)

    def get_sm_credentials(self, profile: str = "default") -> tuple[str, str] | None:
        """Retrieve stored SM credentials.

        Args:
            profile: Profile name for credential isolation

        Returns:
            Tuple of (username, password) or None if not found

        Example:
            ```python
            creds = manager.get_sm_credentials()
            if creds:
                username, password = creds
                print(f"Found credentials for {username}")
            ```
        """
        logger.debug("Retrieving SM credentials for profile: %s", profile)

        keyring_key = f"sm_credentials:{profile}"
        credentials_json: str | None = None

        if self._use_keyring:
            try:
                credentials_json = keyring.get_password(self.SERVICE_NAME, keyring_key)
            except keyring.errors.KeyringError:
                logger.debug("Keyring read failed, falling back to encrypted file")
                self._use_keyring = False

        if credentials_json is None:
            credentials = self._load_encrypted_credentials()
            credentials_json = credentials.get("sm_credentials", {}).get(profile)

        if credentials_json is None:
            return None

        try:
            data = json.loads(credentials_json)
            return (data["username"], data["password"])
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Failed to parse SM credentials: %s", e)
            return None

    def delete_sm_credentials(self, profile: str = "default") -> bool:
        """Delete stored SM credentials.

        Args:
            profile: Profile name for credential isolation

        Returns:
            True if credentials were deleted, False if not found

        Example:
            ```python
            if manager.delete_sm_credentials():
                print("SM credentials deleted")
            ```
        """
        logger.info("Deleting SM credentials for profile: %s", profile)

        keyring_key = f"sm_credentials:{profile}"
        deleted = False

        if self._use_keyring:
            try:
                keyring.delete_password(self.SERVICE_NAME, keyring_key)
                deleted = True
            except keyring.errors.PasswordDeleteError:
                logger.debug("SM credentials not found in OS keyring")
            except keyring.errors.KeyringError:
                logger.debug("Keyring delete failed, falling back to encrypted file")
                self._use_keyring = False

        # Also try encrypted file
        if not self._use_keyring or not deleted:
            credentials = self._load_encrypted_credentials()
            if "sm_credentials" in credentials and profile in credentials["sm_credentials"]:
                del credentials["sm_credentials"][profile]
                self._save_encrypted_credentials(credentials)
                deleted = True

        return deleted

    def has_sm_credentials(self, profile: str = "default") -> bool:
        """Check if SM credentials are stored.

        Args:
            profile: Profile name for credential isolation

        Returns:
            True if credentials exist, False otherwise
        """
        return self.get_sm_credentials(profile) is not None

    def clear_all(self, profile: str = "default") -> dict[str, int]:
        """Clear all stored credentials for a profile.

        Clears:
        - SM credentials (username, password)
        - All admin API keys
        - All agent API keys

        Args:
            profile: Profile name for credential isolation

        Returns:
            Dictionary with counts of deleted items by type

        Example:
            ```python
            result = manager.clear_all()
            print(f"Deleted {result['admin_keys']} admin keys")
            ```
        """
        logger.info("Clearing all credentials for profile: %s", profile)

        result = {
            "sm_credentials": 0,
            "admin_keys": 0,
            "agent_keys": 0,
        }

        # Delete SM credentials
        if self.delete_sm_credentials(profile):
            result["sm_credentials"] = 1

        # Delete all API keys
        keys = self.list_keys()
        for key_name in keys.get("admin", []):
            if self.delete_key("admin", key_name):
                result["admin_keys"] += 1

        for key_name in keys.get("agent", []):
            if self.delete_key("agent", key_name):
                result["agent_keys"] += 1

        logger.info(
            "Cleared credentials: %d SM, %d admin keys, %d agent keys",
            result["sm_credentials"],
            result["admin_keys"],
            result["agent_keys"],
        )

        return result
