"""Data models for CLI output formatting.

These models separate the business logic of formatting data from the presentation
layer (Rich library). This makes the code more testable and follows domain-driven
design principles.
"""

import json
from abc import ABC, abstractmethod
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field


class FormattedOutput(BaseModel, ABC):
    """Base class for formatted output.

    All output types should inherit from this class and implement
    the to_string() method for testing and the get_data() method
    for accessing the underlying data.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @abstractmethod
    def to_string(self) -> str:
        """Convert the formatted output to a string for testing.

        Returns:
            String representation of the formatted output
        """

    @abstractmethod
    def get_data(self) -> Any:
        """Get the underlying data.

        Returns:
            The raw data being formatted
        """


class TextOutput(FormattedOutput):
    """Simple text output."""

    text: str
    style: str | None = None  # Rich style string (e.g., "bold green", "red")

    def to_string(self) -> str:
        """Convert to plain string (without Rich markup)."""
        return self.text

    def get_data(self) -> str:
        """Get the text data."""
        return self.text


class JsonOutput(FormattedOutput):
    """JSON formatted output."""

    data: Any
    indent: int = Field(default=2, ge=0, le=8)
    sort_keys: bool = False

    def to_string(self) -> str:
        """Convert to JSON string."""
        # Convert Pydantic models to dicts
        data_to_serialize: Any
        if isinstance(self.data, BaseModel):
            data_to_serialize = self.data.model_dump(mode="json")
        elif isinstance(self.data, list) and self.data and isinstance(self.data[0], BaseModel):
            data_to_serialize = [item.model_dump(mode="json") for item in self.data]
        else:
            data_to_serialize = self.data

        return json.dumps(data_to_serialize, indent=self.indent, sort_keys=self.sort_keys)

    def get_data(self) -> Any:
        """Get the underlying data."""
        return self.data


class YamlOutput(FormattedOutput):
    """YAML formatted output."""

    data: Any
    default_flow_style: bool = False

    def to_string(self) -> str:
        """Convert to YAML string."""
        # Convert Pydantic models to dicts
        data_to_serialize: Any
        if isinstance(self.data, BaseModel):
            data_to_serialize = self.data.model_dump(mode="json")
        elif isinstance(self.data, list) and self.data and isinstance(self.data[0], BaseModel):
            data_to_serialize = [item.model_dump(mode="json") for item in self.data]
        else:
            data_to_serialize = self.data

        return yaml.dump(
            data_to_serialize,
            default_flow_style=self.default_flow_style,
            sort_keys=False,
        )

    def get_data(self) -> Any:
        """Get the underlying data."""
        return self.data


class TableColumn(BaseModel):
    """Column definition for table output."""

    header: str
    key: str | None = None  # Key to extract from row data (None for index-based)
    style: str | None = None  # Rich style string
    justify: Literal["default", "left", "center", "right", "full"] = "left"
    no_wrap: bool = False
    overflow: Literal["fold", "crop", "ellipsis", "ignore"] = "fold"


class TableRow(BaseModel):
    """Row data for table output."""

    data: dict[str, Any] | list[Any]
    style: str | None = None  # Rich style for entire row

    def get_value(self, column: "TableColumn", index: int) -> str:
        """Get the value for a specific column.

        Args:
            column: Column definition
            index: Column index (used if column.key is None)

        Returns:
            String value for the cell
        """
        if isinstance(self.data, dict):
            if column.key:
                value = self.data.get(column.key, "")
            else:
                # For dict, use index to get nth value
                values = list(self.data.values())
                value = values[index] if index < len(values) else ""
        else:
            # For list, use index
            value = self.data[index] if index < len(self.data) else ""

        return str(value) if value is not None else ""


class TableOutput(FormattedOutput):
    """Table formatted output."""

    columns: list[TableColumn]
    rows: list[TableRow] = Field(default_factory=list)
    title: str | None = None
    caption: str | None = None
    show_header: bool = True
    show_lines: bool = False

    def to_string(self) -> str:
        """Convert to plain text table representation.

        This creates a simple ASCII table for testing purposes.
        """
        lines = []

        # Add title
        if self.title:
            lines.append(self.title)
            lines.append("")

        # Add header
        if self.show_header:
            header_line = " | ".join(col.header for col in self.columns)
            lines.append(header_line)
            lines.append("-" * len(header_line))

        # Add rows
        for row in self.rows:
            values = [row.get_value(col, i) for i, col in enumerate(self.columns)]
            lines.append(" | ".join(values))

        # Add caption
        if self.caption:
            lines.append("")
            lines.append(self.caption)

        return "\n".join(lines)

    def get_data(self) -> list[dict[str, Any]]:
        """Get the underlying data as a list of dicts.

        Returns:
            List of dictionaries representing the table data
        """
        result = []
        for row in self.rows:
            if isinstance(row.data, dict):
                result.append(row.data)
            else:
                # Convert list to dict using column headers
                row_dict = {}
                for i, col in enumerate(self.columns):
                    key = col.key or col.header
                    value = row.data[i] if i < len(row.data) else None
                    row_dict[key] = value
                result.append(row_dict)
        return result

    @classmethod
    def from_dicts(
        cls,
        data: list[dict[str, Any]],
        columns: list[str] | None = None,
        title: str | None = None,
        caption: str | None = None,
    ) -> "TableOutput":
        """Create a TableOutput from a list of dictionaries.

        Args:
            data: List of dictionaries to display
            columns: List of column keys to display (None = all keys from first item)
            title: Optional table title
            caption: Optional table caption

        Returns:
            TableOutput instance
        """
        if not data:
            return cls(columns=[], rows=[], title=title, caption=caption)

        # Determine columns
        if columns is None:
            columns = list(data[0].keys())

        # Create column definitions
        table_columns = [
            TableColumn(header=col.replace("_", " ").title(), key=col) for col in columns
        ]

        # Create rows
        rows = [TableRow(data=item) for item in data]

        return cls(
            columns=table_columns,
            rows=rows,
            title=title,
            caption=caption,
        )

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        title: str | None = None,
        caption: str | None = None,
    ) -> "TableOutput":
        """Create a TableOutput from a single dictionary.

        Args:
            data: Dictionary to display as key-value pairs
            title: Optional table title
            caption: Optional table caption

        Returns:
            TableOutput instance
        """
        # Create two columns: Key and Value
        table_columns = [
            TableColumn(header="Key", key="key"),
            TableColumn(header="Value", key="value"),
        ]

        # Create rows from dict items
        rows = [TableRow(data={"key": k, "value": str(v)}) for k, v in data.items()]

        return cls(
            columns=table_columns,
            rows=rows,
            title=title,
            caption=caption,
        )
