"""Context-aware data model system for exporting structured context as JSON.

This module provides ContextField, ContextRelationship, and ContextModel classes
for defining entities with rich metadata (fields, indices, relationships) that
can be exported as JSON for AI consumption.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, TypeVar, get_args, get_origin

from pydantic import BaseModel, ConfigDict
from pydantic import Field as PydanticField
from pydantic._internal._model_construction import ModelMetaclass

from context_surfaces.constants import (
    ERR_RELATIONSHIP_DESCRIPTOR,
    ERR_RELATIONSHIP_READONLY,
    ERR_VECTOR_DIM_REQUIRED,
    MIN_RELATIONSHIP_ARGS,
)

if TYPE_CHECKING:
    from collections.abc import Callable

T = TypeVar("T")


def ContextField(
    *,
    description: str,
    default: Any = ...,
    default_factory: Callable[[], Any] | None = None,
    # Index options
    index: str | list[str] | None = None,
    is_key_component: bool = False,
    # Vector-specific options
    vector_dim: int | None = None,
    distance_metric: str = "cosine",
    # Text-specific options
    weight: float = 1.0,
    no_stem: bool = False,
    # Numeric-specific options
    sortable: bool = False,
    **kwargs: Any,
) -> Any:
    """Enhanced Field with index metadata.

    Args:
        description: Field description (required)
        default: Default value (use ... for required fields)
        default_factory: Factory function for default value
        index: Index type(s) - can be single string or list
        is_key_component: Whether this field is part of the Redis key
        vector_dim: Required for vector indices
        distance_metric: For vector indices (cosine, euclidean, etc.)
        weight: Text search weight (higher = more important)
        no_stem: Disable stemming for text search
        sortable: Enable sorting for numeric fields
    """
    # Store index metadata in json_schema_extra
    index_metadata: dict[str, Any] = {
        "is_key_component": is_key_component,
    }

    if index:
        index_list = index if isinstance(index, list) else [index]

        # Validate vector fields
        if "vector" in index_list and vector_dim is None:
            raise ValueError(ERR_VECTOR_DIM_REQUIRED)

        index_metadata["index_config"] = {
            "index": index_list,
            "vector_dim": vector_dim,
            "distance_metric": distance_metric,
            "weight": weight,
            "no_stem": no_stem,
            "sortable": sortable,
        }

    # Handle default values
    field_kwargs = {
        "description": description,
        "json_schema_extra": index_metadata,
        **kwargs,
    }

    if default is not ...:
        field_kwargs["default"] = default
    elif default_factory is not None:
        field_kwargs["default_factory"] = default_factory

    return PydanticField(**field_kwargs)


class ContextRelationship:
    """Define a relationship between entities using a descriptor pattern.

    This prevents circular serialization issues by excluding relationships
    from model serialization while preserving them in metadata export.
    """

    def __init__(
        self,
        *,
        description: str,
        source_field: str | None = None,
    ) -> None:
        """Initialize relationship.

        Args:
            description: Description of the relationship
            source_field: Field in this model containing foreign key(s)
                         e.g., "user_id" or "product_ids"
        """
        self.description = description
        self.source_field = source_field
        self.field_name: str | None = None
        self.owner_cls: type | None = None
        self.target_type: Any = None
        self._annotation: Any = None

    def __set_name__(self, owner: type, name: str) -> None:
        """Called when the descriptor is assigned to a class attribute."""
        self.field_name = name
        self.owner_cls = owner

        # Get the type annotation (set by metaclass or from owner.__annotations__)
        if hasattr(self, "_annotation") and self._annotation is not None:
            self.target_type = self._annotation
        elif hasattr(owner, "__annotations__") and name in owner.__annotations__:
            self.target_type = owner.__annotations__[name]

    def __get__(self, instance: Any | None, owner: type) -> Any:
        """Support both class and instance access."""
        if instance is None:
            # Class access - return self
            return self

        # Instance access - return None (relationships aren't auto-loaded)
        return None

    def __set__(self, instance: Any, value: Any) -> None:
        """Prevent setting relationship fields directly."""
        raise AttributeError(ERR_RELATIONSHIP_READONLY % self.field_name)


class RelationshipDescriptor:
    """Wrapper descriptor that delegates to ContextRelationship."""

    def __init__(self, relationship: ContextRelationship) -> None:
        self.relationship = relationship
        self.name: str | None = None

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name
        self.relationship.__set_name__(owner, name)

    def __get__(self, obj: Any, objtype: type | None = None) -> Any:
        if obj is None:
            # Class access - return relationship for resolver registration
            return self.relationship
        # Instance access - delegate to relationship
        owner_type = objtype if objtype is not None else type(obj)
        return self.relationship.__get__(obj, owner_type)

    def __set__(self, obj: Any, value: Any) -> None:
        if self.name is None:
            msg = "Relationship field name not set"
            raise AttributeError(msg)
        raise AttributeError(ERR_RELATIONSHIP_DESCRIPTOR % self.name)


class ContextModelMeta(ModelMetaclass):
    """Metaclass that strips relationship fields before Pydantic processes them.

    This is the key to making relationships work without breaking Pydantic's
    validation and serialization. Also auto-registers all ContextModel subclasses.
    """

    # Global registry of all ContextModel subclasses
    _registry: ClassVar[dict[str, type[ContextModel]]] = {}

    def __new__(
        cls,
        name: str,
        bases: tuple[type, ...],
        namespace: dict[str, Any],
        **kwargs: Any,
    ) -> type:
        # Step 1: Collect relationships from parent classes
        parent_relationships: dict[str, ContextRelationship] = {}
        for base in bases:
            if hasattr(base, "_relationships"):
                parent_relationships.update(base._relationships)

        # Step 2: Extract relationships from current class BEFORE Pydantic sees them
        current_relationships: dict[str, ContextRelationship] = {}
        annotations = namespace.get("__annotations__", {}).copy()

        for field_name in list(annotations.keys()):
            field_value = namespace.get(field_name)
            if isinstance(field_value, ContextRelationship):
                # Store the type annotation for later
                field_value._annotation = annotations[field_name]
                current_relationships[field_name] = field_value

                # CRITICAL: Remove from annotations and namespace
                # so Pydantic doesn't try to validate it
                del annotations[field_name]
                del namespace[field_name]

        # Step 3: Update annotations without relationship fields
        namespace["__annotations__"] = annotations

        # Step 4: Let Pydantic create the model class normally
        model_class = super().__new__(cls, name, bases, namespace, **kwargs)

        # Step 5: Combine parent and current relationships
        all_relationships = {**parent_relationships, **current_relationships}
        model_class._relationships = all_relationships  # type: ignore[attr-defined]

        # Step 6: Add relationship descriptors back to the class
        for field_name, relationship in all_relationships.items():
            descriptor = RelationshipDescriptor(relationship)
            setattr(model_class, field_name, descriptor)
            # Manually call __set_name__ since setattr doesn't trigger it
            descriptor.__set_name__(model_class, field_name)

        # Step 7: Auto-register the model (skip base ContextModel class itself)
        if name != "ContextModel" and any(isinstance(b, ContextModelMeta) for b in bases):
            cls._registry[name] = model_class

        return model_class


class ContextModel(BaseModel, metaclass=ContextModelMeta):
    """Base class for all context-aware entity models.

    Provides:
    - Relationship support via metaclass
    - Index metadata extraction
    - JSON export without circular references

    Class Attributes:
        __redis_key_template__: Optional Redis key template (e.g., "customer:{id}")
                                Defaults to "{classname}:{id}" if not specified
    """

    # Class-level configuration
    __redis_key_template__: str | None = None

    # Pydantic configuration
    model_config = ConfigDict(
        arbitrary_types_allowed=True,  # Allow relationship descriptors
        ignored_types=(ContextRelationship,),  # Ignore relationships in validation
    )

    @classmethod
    def relationship_fields(cls) -> set[str]:
        """Get names of all relationship fields."""
        return set(getattr(cls, "_relationships", {}).keys())

    @classmethod
    def get_all_models(cls) -> list[type[ContextModel]]:
        """Get all registered ContextModel subclasses.

        Returns:
            List of all ContextModel subclasses that have been defined
        """
        return list(ContextModelMeta._registry.values())

    @classmethod
    def get_index_fields(cls) -> list[dict[str, Any]]:
        """Extract index metadata from all fields.

        Returns list of field definitions with index configuration.
        """
        fields = []
        for field_name, field_info in cls.model_fields.items():
            # Get field type
            field_type = field_info.annotation
            type_str = _get_type_string(field_type)

            # Extract metadata from json_schema_extra
            extra = field_info.json_schema_extra
            if not isinstance(extra, dict):
                extra = {}
            is_key_component = extra.get("is_key_component", False)
            index_config_raw = extra.get("index_config", {})
            index_config = index_config_raw if isinstance(index_config_raw, dict) else {}

            # Build redis_indices list
            redis_indices = []
            if index_config and "index" in index_config:
                index_list = index_config["index"]
                if isinstance(index_list, list):
                    for index_type in index_list:
                        if not isinstance(index_type, str):
                            continue
                        index_def: dict[str, Any] = {"type": index_type}

                        # Add type-specific options
                        if index_type == "vector":
                            vector_dim = index_config.get("vector_dim")
                            if vector_dim is not None:
                                index_def["vector_dim"] = vector_dim
                            distance_metric = index_config.get("distance_metric")
                            if distance_metric is not None:
                                index_def["distance_metric"] = distance_metric
                        elif index_type == "text":
                            # Always include weight for text indices
                            weight = index_config.get("weight", 1.0)
                            index_def["weight"] = weight
                            no_stem = index_config.get("no_stem")
                            # Only include no_stem if it's explicitly True (False is the default)
                            if no_stem is True:
                                index_def["no_stem"] = no_stem
                        elif index_type == "numeric":
                            sortable = index_config.get("sortable")
                            # Only include sortable if it's explicitly True (False is the default)
                            if sortable is True:
                                index_def["sortable"] = sortable

                        redis_indices.append(index_def)

            field_dict = {
                "name": field_name,
                "type": type_str,
                "description": field_info.description or "",
                "is_key_component": is_key_component,
                "redis_indices": redis_indices,
            }
            fields.append(field_dict)

        return fields

    @classmethod
    def get_relationships(cls) -> list[dict[str, Any]]:
        """Extract relationship metadata.

        Returns list of relationship definitions.
        """
        relationships = []
        for field_name, rel in getattr(cls, "_relationships", {}).items():
            # Extract target type from annotation
            target_type = rel.target_type
            target_name = _get_target_name(target_type)

            rel_dict = {
                "name": field_name,
                "target": target_name,
                "description": rel.description,
                "source_field": rel.source_field or "",
            }
            relationships.append(rel_dict)

        return relationships

    @classmethod
    def to_entity_dict(cls) -> dict[str, Any]:
        """Export entity as a dictionary matching the OpenAPI schema.

        Returns:
            Dictionary with entity metadata, fields, and relationships
        """
        # Use class attribute if set, otherwise default to {classname}:{id}
        redis_key_template = cls.__redis_key_template__ or f"{cls.__name__.lower()}:{{id}}"

        return {
            "name": cls.__name__,
            "description": cls.__doc__.strip() if cls.__doc__ else "",
            "redis_key_template": redis_key_template,
            "fields": cls.get_index_fields(),
            "relationships": cls.get_relationships(),
        }

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Override to exclude relationship fields from serialization."""
        # Get relationship field names
        rel_fields = self.relationship_fields()

        # Add them to exclude set
        exclude = kwargs.get("exclude", set())
        exclude = exclude | rel_fields if isinstance(exclude, set) else rel_fields

        kwargs["exclude"] = exclude
        return super().model_dump(**kwargs)

    def model_post_init(self, __context: Any) -> None:
        """Clean up relationship defaults from instance dict."""
        for field_name in self.relationship_fields():
            # Remove relationship field from __dict__ if it exists
            self.__dict__.pop(field_name, None)


def _get_type_string(field_type: Any) -> str:
    """Convert Python type annotation to string representation."""
    # Handle Optional types
    origin = get_origin(field_type)
    args = get_args(field_type)

    if origin is list:
        if args:
            inner_type = _get_type_string(args[0])
            return f"list[{inner_type}]"
        return "list"

    # Handle Union types (including Optional)
    if origin is type(None) or (
        hasattr(field_type, "__origin__") and field_type.__origin__ is type(None)
    ):
        return "None"

    # Check for Optional (Union with None)
    if origin is not None and len(args) == MIN_RELATIONSHIP_ARGS and type(None) in args:
        # This is Optional[T]
        non_none_type = args[0] if args[1] is type(None) else args[1]
        return _get_type_string(non_none_type)

    # Basic types
    if hasattr(field_type, "__name__"):
        return str(field_type.__name__)

    # Fallback to string representation
    return str(field_type)


def _get_target_name(target_type: Any) -> str:
    """Extract target entity name from type annotation.

    Handles both runtime types and string annotations (from __future__ import annotations).
    """
    # Handle forward references (strings) - common with __future__ annotations
    if isinstance(target_type, str):
        # Parse string annotations like "list[Product]" -> "Product"
        if target_type.startswith("list[") and target_type.endswith("]"):
            # Extract inner type from "list[T]"
            return target_type[5:-1]
        # Handle Optional/Union types in string form
        if " | None" in target_type:
            # "Product | None" -> "Product"
            return target_type.replace(" | None", "").strip()
        return target_type

    # Handle runtime types
    origin = get_origin(target_type)
    args = get_args(target_type)

    # Handle list[T] -> extract T
    if origin is list and args:
        return _get_target_name(args[0])

    # Handle Union types (including Optional)
    if origin is not None and len(args) >= 2 and type(None) in args:
        # This is Optional[T] or Union[T, None]
        non_none_type = args[0] if args[1] is type(None) else args[1]
        return _get_target_name(non_none_type)

    # Handle classes with __name__
    if hasattr(target_type, "__name__"):
        return str(target_type.__name__)

    # Fallback to string representation
    return str(target_type)


def export_data_model(
    title: str,
    description: str,
    entities: list[type[ContextModel]] | None = None,
) -> dict[str, Any]:
    """Export a complete data model from entity classes.

    Args:
        title: Title for the data model
        description: Description of the data model
        entities: Optional list of ContextModel classes to export.
                  If None, exports all registered ContextModel subclasses.

    Returns:
        Complete data model dictionary matching the OpenAPI schema
    """
    # Use all registered models if entities not specified
    if entities is None:
        entities = ContextModel.get_all_models()

    entity_dicts = []
    for entity_cls in entities:
        entity_dicts.append(entity_cls.to_entity_dict())

    return {
        "title": title,
        "description": description,
        "entity_count": len(entity_dicts),
        "entities": entity_dicts,
    }
