"""MCP client for invoking tools via the Model Context Protocol."""

import logging
from typing import Any, cast

import httpx
from fastmcp import FastMCP

from context_surfaces import config
from context_surfaces.exceptions import MCPError
from context_surfaces.url_config import resolve_url

logger = logging.getLogger(__name__)


class MCPClient:
    """Client for invoking MCP tools via the Context Surfaces.

    This client uses the fastmcp library to communicate with the MCP server
    and invoke tools from a specific surface using an agent API key.

    Example:
        ```python
        async with MCPClient(
            mcp_url="http://localhost:8081/mcp",
            agent_key="your-agent-key"
        ) as mcp:
            # List available tools
            tools = await mcp.list_tools()
            for tool in tools:
                print(f"Tool: {tool.name}")

            # Call a tool
            result = await mcp.call_tool("search_tickets", {"query": "bug"})
            print(result)
        ```
    """

    def __init__(
        self,
        mcp_url: str | None = None,
        agent_key: str | None = None,
        timeout: float = 30.0,
        **httpx_kwargs: Any,
    ) -> None:
        """Initialize the MCP client.

        Args:
            mcp_url: Full URL of the MCP endpoint.
                Resolution order: explicit value, CTX_MCP_URL env var, default URL.
            agent_key: Agent API key for authentication
            timeout: Request timeout in seconds
            **httpx_kwargs: Additional arguments to pass to httpx.AsyncClient
        """
        self.mcp_url = resolve_url(
            explicit_value=mcp_url,
            config_value=config.mcp_url,
            ensure_trailing_slash=False,  # Direct URL usage, no base_url joining
        )
        self.agent_key = agent_key
        self.timeout = timeout
        self._httpx_kwargs = httpx_kwargs
        self._client: httpx.AsyncClient | None = None
        self._mcp: FastMCP | None = None

    async def __aenter__(self) -> "MCPClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def connect(self) -> None:
        """Connect to the MCP server."""
        if self._client is not None:
            return

        # Create HTTP client with API key header
        headers = {}
        if self.agent_key:
            headers["X-API-Key"] = self.agent_key

        self._client = httpx.AsyncClient(
            timeout=self.timeout,
            headers=headers,
            **self._httpx_kwargs,
        )

        # Initialize FastMCP client
        try:
            self._mcp = FastMCP("context-surfaces")
            # Note: FastMCP will use the HTTP client for transport
        except Exception as e:
            await self._client.aclose()
            self._client = None
            raise MCPError(f"Failed to initialize MCP client: {e}") from e

    async def close(self) -> None:
        """Close the MCP client and HTTP connection."""
        if self._client:
            await self._client.aclose()
            self._client = None
        self._mcp = None

    async def list_tools(self) -> list[dict[str, Any]]:
        """List all available tools from the surface.

        Returns:
            List of tool definitions

        Raises:
            MCPError: If the request fails
        """
        if not self._client:
            raise MCPError("Client not connected. Call connect() first.")

        try:
            response = await self._client.post(
                self.mcp_url,
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/list",
                    "params": {},
                },
            )
            response.raise_for_status()
            data = response.json()

            if "error" in data:
                raise MCPError(f"MCP error: {data['error']}")

            result = data.get("result", {})
            tools = result.get("tools", []) if isinstance(result, dict) else []
            return cast("list[dict[str, Any]]", tools)
        except httpx.HTTPError as e:
            raise MCPError(f"HTTP error listing tools: {e}") from e
        except Exception as e:
            raise MCPError(f"Failed to list tools: {e}") from e

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
    ) -> Any:
        """Call a tool via the MCP protocol.

        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments (optional)

        Returns:
            Tool execution result

        Raises:
            MCPError: If the tool call fails

        Example:
            ```python
            result = await mcp.call_tool(
                "search_tickets",
                {"query": "bug", "status": "open"}
            )
            ```
        """
        if not self._client:
            raise MCPError("Client not connected. Call connect() first.")

        try:
            response = await self._client.post(
                self.mcp_url,
                json={
                    "jsonrpc": "2.0",
                    "id": 2,
                    "method": "tools/call",
                    "params": {
                        "name": tool_name,
                        "arguments": arguments or {},
                    },
                },
            )
            response.raise_for_status()
            data = response.json()

            if "error" in data:
                raise MCPError(f"MCP error calling {tool_name}: {data['error']}")

            return data.get("result", {})
        except httpx.HTTPError as e:
            raise MCPError(f"HTTP error calling tool {tool_name}: {e}") from e
        except Exception as e:
            raise MCPError(f"Failed to call tool {tool_name}: {e}") from e

    async def initialize(self) -> dict[str, Any]:
        """Initialize the MCP session.

        Returns:
            Server initialization response

        Raises:
            MCPError: If initialization fails
        """
        if not self._client:
            raise MCPError("Client not connected. Call connect() first.")

        try:
            response = await self._client.post(
                self.mcp_url,
                json={
                    "jsonrpc": "2.0",
                    "id": 0,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {
                            "name": "context-surfaces",
                            "version": "0.1.0",
                        },
                    },
                },
            )
            response.raise_for_status()
            data = response.json()

            if "error" in data:
                raise MCPError(f"MCP initialization error: {data['error']}")

            result = data.get("result", {})
            return cast("dict[str, Any]", result)
        except httpx.HTTPError as e:
            raise MCPError(f"HTTP error during initialization: {e}") from e
        except Exception as e:
            raise MCPError(f"Failed to initialize MCP session: {e}") from e
