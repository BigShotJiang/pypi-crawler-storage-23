"""URL resolution helpers for SDK and CLI clients."""

from urllib.parse import urlparse, urlunparse


def resolve_url(
    *,
    explicit_value: str | None,
    config_value: str,
    ensure_trailing_slash: bool = True,
) -> str:
    """Resolve URL with precedence: explicit arg > config value.

    Args:
        explicit_value: Explicitly provided URL value (highest priority)
        config_value: Config value (from env var or default)
        ensure_trailing_slash: If True, adds trailing slash to non-empty paths for proper
            relative URL joining with httpx base_url. If False, preserves exact path
            for direct/absolute URL usage. Default is True.

    Returns:
        Resolved and normalized URL. Behavior depends on ensure_trailing_slash:
        - True: URLs with paths get trailing slashes (e.g., /api -> /api/)
        - False: URLs preserve exact path (e.g., /mcp stays /mcp)
        Root URLs never get trailing slashes.

    Raises:
        ValueError: If the resolved URL is invalid
    """
    resolved = explicit_value if explicit_value is not None else config_value

    # Validate URL format
    resolved = resolved.strip()
    if not resolved:
        raise ValueError("URL cannot be empty")

    if not resolved.startswith(("http://", "https://")):
        raise ValueError(f"URL must start with http:// or https://, got: {resolved}")

    # Parse URL to validate structure and normalize path
    try:
        parsed = urlparse(resolved)
    except Exception as e:
        raise ValueError(f"Invalid URL format: {e}") from e

    # Validate required components
    if not parsed.scheme or not parsed.netloc:
        raise ValueError(f"URL must have valid scheme and host: {resolved}")

    # Normalize path based on ensure_trailing_slash parameter
    path = parsed.path.rstrip("/")
    if path and ensure_trailing_slash:
        # Add trailing slash for proper relative URL joining (e.g., base/api + /users = base/api/users)
        path = f"{path}/"
    # else: preserve exact path (for direct URLs) or empty/root path (no trailing slash)

    # Reconstruct URL with normalized path
    return urlunparse((
        parsed.scheme,
        parsed.netloc,
        path,
        parsed.params,
        parsed.query,
        parsed.fragment,
    ))
