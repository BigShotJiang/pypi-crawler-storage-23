"""Pydantic models for Context Surfaces API."""

from datetime import datetime
from enum import Enum
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field, field_validator


class KeyType(str, Enum):
    """API key type enumeration."""

    ADMIN = "admin"
    AGENT = "agent"


class BaseAPIKey(BaseModel):
    """Base model for API keys."""

    id: str = Field(..., description="Unique identifier for the API key")
    name: str = Field(..., description="Human-readable name for the key")
    description: str | None = Field(None, description="Optional description")
    owner: str = Field(..., description="Owner identifier (account ID)")
    key_type: KeyType = Field(..., description="Type of API key (admin or agent)")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    expires_at: datetime | None = Field(None, description="Optional expiration timestamp")
    metadata: dict[str, str] = Field(default_factory=dict, description="Custom metadata")

    class Config:
        """Pydantic configuration."""

        json_encoders: ClassVar[dict[type, Any]] = {datetime: lambda v: v.isoformat()}


class AdminAPIKey(BaseAPIKey):
    """Admin API key with full access to context surface management."""

    key: str = Field(..., description="The actual API key value (only returned on creation)")
    key_type: KeyType = Field(default=KeyType.ADMIN, description="Always 'admin'")


class AgentAPIKey(BaseAPIKey):
    """Agent API key scoped to a specific context surface."""

    model_config = ConfigDict(populate_by_name=True)

    key: str = Field(..., description="The actual API key value (only returned on creation)")
    key_type: KeyType = Field(default=KeyType.AGENT, description="Always 'agent'")
    context_surface_id: str = Field(
        ...,
        alias="context_surface_id",
        description="ID of the associated context surface",
    )


class ContextSurface(BaseModel):
    """A context surface - a collection of MCP tools."""

    id: str = Field(..., description="Unique identifier for the context surface")
    name: str = Field(..., description="Human-readable name")
    description: str | None = Field(None, description="Optional description")
    owner: str = Field(..., description="Owner identifier (account ID)")
    tools: list[str] = Field(default_factory=list, description="List of tool names")
    redis_instance_id: str | None = Field(None, description="Redis instance ID for data storage")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    metadata: dict[str, str] = Field(default_factory=dict, description="Custom metadata")

    class Config:
        """Pydantic configuration."""

        json_encoders: ClassVar[dict[type, Any]] = {datetime: lambda v: v.isoformat()}


class Pagination(BaseModel):
    """Pagination metadata."""

    page: int = Field(..., ge=1, description="Current page number")
    page_size: int = Field(..., ge=1, le=100, description="Items per page")
    total_count: int = Field(..., ge=0, description="Total number of items")
    total_pages: int = Field(..., ge=0, description="Total number of pages")
    has_next: bool = Field(..., description="Whether there is a next page")
    has_prev: bool = Field(..., description="Whether there is a previous page")


class CreateAdminKeyRequest(BaseModel):
    """Request model for creating an admin API key.

    Note: The `owner` field is deprecated. When using session authentication
    (via `ctxctl login`), the owner is automatically extracted from JWT claims
    by the backend. The field is kept for backward compatibility with
    existing integrations.
    """

    name: str = Field(..., min_length=1, max_length=255, description="Name for the key")
    description: str | None = Field(None, max_length=1000, description="Optional description")
    owner: str | None = Field(
        default=None,
        min_length=1,
        max_length=255,
        description="Owner identifier (deprecated - extracted from JWT when using session auth)",
    )
    key_type: KeyType = Field(default=KeyType.ADMIN, description="Must be 'admin'")
    metadata: dict[str, str] = Field(default_factory=dict, description="Custom metadata")

    @field_validator("key_type")
    @classmethod
    def validate_key_type(cls, v: KeyType) -> KeyType:
        """Ensure key_type is admin."""
        if v != KeyType.ADMIN:
            raise ValueError("key_type must be 'admin' for admin keys")
        return v


class CreateAgentKeyRequest(BaseModel):
    """Request model for creating an agent API key."""

    name: str = Field(..., min_length=1, max_length=255, description="Name for the key")
    description: str | None = Field(None, max_length=1000, description="Optional description")
    expires_at: datetime | None = Field(None, description="Optional expiration timestamp")
    metadata: dict[str, str] = Field(default_factory=dict, description="Custom metadata")
    access_tags: dict[str, list[str]] | None = Field(
        None,
        description="Access tags for entity-level ACL filtering with multi-value support (e.g., {'tenant': ['acme', 'globex']})",
    )


class CreateContextSurfaceRequest(BaseModel):
    """Request model for creating a context surface.

    Note: Tools are auto-generated from the data_model. You cannot specify tools directly.
    """

    name: str = Field(..., min_length=1, max_length=255, description="Name for the context surface")
    description: str | None = Field(None, max_length=1000, description="Optional description")
    metadata: dict[str, str] = Field(default_factory=dict, description="Custom metadata")
    data_model: dict[str, Any] | None = Field(
        None, description="Optional RQE data model (tools are auto-generated from this)"
    )
    redis_instance_id: str | None = Field(
        None, description="Redis instance ID (required when data_model is provided)"
    )


class UpdateContextSurfaceRequest(BaseModel):
    """Request model for updating a context surface.

    Note: Tools are auto-generated from the data_model. You cannot update tools directly.
    """

    name: str | None = Field(None, min_length=1, max_length=255, description="New name")
    description: str | None = Field(None, max_length=1000, description="New description")
    metadata: dict[str, str] | None = Field(None, description="New metadata")
    data_model: dict[str, Any] | None = Field(
        None, description="New RQE data model (tools are auto-generated from this)"
    )


class ListContextSurfacesResponse(BaseModel):
    """Response model for listing context surfaces."""

    model_config = ConfigDict(populate_by_name=True)

    context_surfaces: list[ContextSurface] = Field(
        ...,
        alias="context_surfaces",
        description="List of context surfaces",
    )
    pagination: Pagination = Field(..., description="Pagination metadata")


class ListAgentKeysResponse(BaseModel):
    """Response model for listing agent keys."""

    agent_keys: list[AgentAPIKey] = Field(..., description="List of agent keys")
    pagination: Pagination = Field(..., description="Pagination metadata")


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(..., description="Health status (UP/DOWN)")
    checks: dict[str, str] = Field(default_factory=dict, description="Individual health checks")


class ErrorResponse(BaseModel):
    """Error response model."""

    error: str = Field(..., description="Error message")


# Redis Instance Models


class RedisConnectionConfig(BaseModel):
    """Redis connection configuration."""

    addr: str = Field(..., description="Redis server address (e.g., 'localhost:6379')")
    username: str = Field(default="", description="Redis ACL username (Redis 6+)")
    password: str = Field(default="", description="Redis authentication password")
    db: int = Field(default=0, ge=0, description="Redis database number")
    tls_enabled: bool = Field(default=False, description="Whether TLS is enabled")
    ca_cert: str | None = Field(None, description="Optional CA certificate for TLS")
    pool_size: int = Field(default=10, ge=1, description="Maximum number of connections")
    min_idle_conns: int = Field(default=2, ge=0, description="Minimum idle connections")


class RegisterRedisInstanceRequest(BaseModel):
    """Request model for registering a Redis instance."""

    name: str = Field(..., min_length=1, max_length=255, description="Instance name")
    description: str | None = Field(None, max_length=1000, description="Optional description")
    connection_config: RedisConnectionConfig = Field(..., description="Connection configuration")
    metadata: dict[str, str] | None = Field(None, description="Optional metadata")


class RedisInstance(BaseModel):
    """Redis instance model."""

    id: str = Field(..., description="Unique identifier")
    name: str = Field(..., description="Instance name")
    description: str | None = Field(None, description="Optional description")
    owner: str = Field(..., description="Owner account ID")
    vault_path: str = Field(..., description="Vault path for credentials")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    metadata: dict[str, str] = Field(default_factory=dict, description="Metadata")

    class Config:
        """Pydantic configuration."""

        json_encoders: ClassVar[dict[type, Any]] = {datetime: lambda v: v.isoformat()}


class ListRedisInstancesResponse(BaseModel):
    """Response model for listing Redis instances."""

    instances: list[RedisInstance] = Field(..., description="List of Redis instances")
    total: int = Field(..., ge=0, description="Total number of instances")


class TestConnectionRequest(BaseModel):
    """Request model for testing Redis connection."""

    connection_config: RedisConnectionConfig = Field(
        ..., description="Connection configuration to test"
    )


class TestConnectionResponse(BaseModel):
    """Response model for connection test."""

    success: bool = Field(..., description="Whether the test was successful")
    message: str | None = Field(None, description="Additional information")
    error: str | None = Field(None, description="Error details if test failed")


# Data Import Models


class DataImportOptions(BaseModel):
    """Options for data import behavior."""

    on_conflict: str = Field(
        default="overwrite",
        description="Behavior when a record key already exists: overwrite, skip, or error",
    )
    on_error: str = Field(
        default="continue",
        description="Behavior when a record fails validation: continue or fail_fast",
    )


class DataImportError(BaseModel):
    """Details about a single record import failure."""

    index: int = Field(..., description="Index of the failed record in the input list")
    record_id: str | None = Field(None, description="ID of the failed record if available")
    error: str = Field(..., description="Error message describing the failure")


class DataImportResponse(BaseModel):
    """Response from data import operation."""

    imported: int = Field(..., ge=0, description="Count of successfully imported records")
    failed: int = Field(..., ge=0, description="Count of failed records")
    errors: list[DataImportError] = Field(
        default_factory=list, description="List of errors for failed records"
    )
