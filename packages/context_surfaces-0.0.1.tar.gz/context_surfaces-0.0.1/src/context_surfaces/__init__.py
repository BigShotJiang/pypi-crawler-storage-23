"""Context Surfaces Client.

Python client for the Context Surfaces API with MCP support.

Quick Start:
    >>> from context_surfaces import ContextSurfacesClient
    >>> async with ContextSurfacesClient("http://api.example.com") as client:
    ...     health = await client.health()

CLI included: after install, run `ctxctl --help`
"""

from importlib.metadata import version as _pkg_version

from context_surfaces.client import ContextSurfacesClient
from context_surfaces.context_model import (
    ContextField,
    ContextModel,
    ContextRelationship,
    export_data_model,
)
from context_surfaces.mcp_client import MCPClient
from context_surfaces.models import (
    AdminAPIKey,
    AgentAPIKey,
    ContextSurface,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    DataImportError,
    DataImportOptions,
    DataImportResponse,
    ListRedisInstancesResponse,
    RedisConnectionConfig,
    RedisInstance,
    RegisterRedisInstanceRequest,
    TestConnectionRequest,
    TestConnectionResponse,
    UpdateContextSurfaceRequest,
)
from context_surfaces.unified_client import UnifiedClient

__version__: str = _pkg_version("context-surfaces")

__all__ = [
    "AdminAPIKey",
    "AgentAPIKey",
    "ContextField",
    "ContextModel",
    "ContextRelationship",
    "ContextSurface",
    "ContextSurfacesClient",
    "CreateAdminKeyRequest",
    "CreateAgentKeyRequest",
    "CreateContextSurfaceRequest",
    "DataImportError",
    "DataImportOptions",
    "DataImportResponse",
    "ListRedisInstancesResponse",
    "MCPClient",
    "RedisConnectionConfig",
    "RedisInstance",
    "RegisterRedisInstanceRequest",
    "TestConnectionRequest",
    "TestConnectionResponse",
    "UnifiedClient",
    "UpdateContextSurfaceRequest",
    "export_data_model",
]
