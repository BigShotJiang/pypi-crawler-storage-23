"""Centralized configuration for Context Surfaces client."""

import os

from context_surfaces.constants import (
    DEFAULT_API_URL,
    DEFAULT_MCP_URL,
    DEFAULT_REDIS_CLOUD_URL,
)


def _get_env_with_fallback(env_var: str, default: str) -> str:
    """Get environment variable value with fallback to default.

    Args:
        env_var: Environment variable name
        default: Default value if env var is not set or empty

    Returns:
        Environment variable value or default
    """
    return os.getenv(env_var) or default


_CONFIG_MAP = {
    "api_url": ("CTX_API_URL", DEFAULT_API_URL),
    "mcp_url": ("CTX_MCP_URL", DEFAULT_MCP_URL),
    "redis_cloud_url": ("CTX_REDIS_CLOUD_URL", DEFAULT_REDIS_CLOUD_URL),
}


def __getattr__(name: str) -> str:
    """Dynamically resolve config values from environment.

    Args:
        name: Config attribute name

    Returns:
        Config value from environment or default

    Raises:
        AttributeError: If config attribute doesn't exist
    """
    if name in _CONFIG_MAP:
        env_var, default = _CONFIG_MAP[name]
        return _get_env_with_fallback(env_var, default)
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
