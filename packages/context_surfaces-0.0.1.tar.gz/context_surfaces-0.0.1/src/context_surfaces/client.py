"""Context Surfaces API client."""

import logging
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from context_surfaces import config
from context_surfaces.constants import (
    ERR_API_ERROR,
    ERR_INVALID_API_KEY,
    ERR_RESOURCE_NOT_FOUND,
    ERR_VALIDATION_ERROR,
    HTTP_BAD_REQUEST,
    HTTP_NOT_FOUND,
    HTTP_UNAUTHORIZED,
    LOG_API_ERROR,
    LOG_AUTH_FAILED,
    LOG_CLIENT_INITIALIZED,
    LOG_NOT_FOUND,
    LOG_REQUEST_DEBUG,
    LOG_REQUEST_SUCCESS,
    LOG_RESPONSE_STATUS,
    LOG_VALIDATION_ERROR,
)
from context_surfaces.exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
)
from context_surfaces.models import (
    AdminAPIKey,
    AgentAPIKey,
    ContextSurface,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    HealthResponse,
    ListAgentKeysResponse,
    ListContextSurfacesResponse,
    ListRedisInstancesResponse,
    RedisInstance,
    RegisterRedisInstanceRequest,
    TestConnectionRequest,
    TestConnectionResponse,
    UpdateContextSurfaceRequest,
)
from context_surfaces.url_config import resolve_url

logger = logging.getLogger(__name__)


class ContextSurfacesClient:
    """High-quality async client for Context Surfaces API.

    This client provides full access to the Context Surfaces API including:
    - Admin API key management
    - Context surface CRUD operations
    - Agent API key management
    - Health checks

    Example:
        ```python
        async with ContextSurfacesClient("http://localhost:8080") as client:
            # Create admin key
            admin_key = await client.create_admin_key(
                CreateAdminKeyRequest(name="My Admin", owner="user123")
            )

            # Create surface
            surface = await client.create_context_surface(
                admin_key.key,
                CreateContextSurfaceRequest(
                    name="Support Tools",
                    tools=["search_tickets", "create_ticket"]
                )
            )

            # Create agent key
            agent_key = await client.create_agent_key(
                admin_key.key,
                surface.id,
                CreateAgentKeyRequest(name="Agent 1")
            )
        ```
    """

    def __init__(
        self,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        **httpx_kwargs: Any,
    ) -> None:
        """Initialize the client.

        Args:
            base_url: Base URL of the Context Surfaces API.
                Resolution order: explicit value, CTX_API_URL env var, default URL.
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts for failed requests
            **httpx_kwargs: Additional arguments to pass to httpx.AsyncClient
        """
        self.base_url = resolve_url(
            explicit_value=base_url,
            config_value=config.api_url,
            ensure_trailing_slash=True,  # Required for httpx base_url joining
        )
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            **httpx_kwargs,
        )
        logger.info(LOG_CLIENT_INITIALIZED, self.base_url)

    async def __aenter__(self) -> "ContextSurfacesClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    def _get_headers(
        self,
        api_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> dict[str, str]:
        """Get request headers with optional API key or session credentials.

        Args:
            api_key: Optional API key for authentication (X-API-Key header)
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Dictionary of HTTP headers
        """
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        elif session_id and csrf_token:
            # Session-based authentication
            headers["Cookie"] = f"JSESSIONID={session_id}"
            headers["X-CSRF-Token"] = csrf_token
        return headers

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def _request(
        self,
        method: str,
        path: str,
        api_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            path: API endpoint path
            api_key: Optional API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication
            json_data: Optional JSON request body
            params: Optional query parameters

        Returns:
            Response JSON data

        Raises:
            AuthenticationError: For 401 responses
            NotFoundError: For 404 responses
            ValidationError: For 400 responses
            APIError: For other error responses
        """
        logger.debug(LOG_REQUEST_DEBUG, method, path)

        # Strip leading slash to make path relative for proper base_url joining
        url = path.lstrip("/")

        response = await self._client.request(
            method=method,
            url=url,
            headers=self._get_headers(api_key, session_id, csrf_token),
            json=json_data,
            params=params,
        )

        logger.debug(LOG_RESPONSE_STATUS, response.status_code)

        if response.status_code == HTTP_UNAUTHORIZED:
            logger.error(LOG_AUTH_FAILED, path)
            raise AuthenticationError(ERR_INVALID_API_KEY)
        if response.status_code == HTTP_NOT_FOUND:
            logger.error(LOG_NOT_FOUND, path)
            raise NotFoundError(ERR_RESOURCE_NOT_FOUND % path)
        if response.status_code == HTTP_BAD_REQUEST:
            error_data = response.json() if response.content else {}
            logger.error(LOG_VALIDATION_ERROR, path, error_data)
            raise ValidationError(error_data.get("error", ERR_VALIDATION_ERROR))
        if response.status_code >= HTTP_BAD_REQUEST:
            error_data = response.json() if response.content else {}
            logger.error(LOG_API_ERROR, response.status_code, path, error_data)
            raise APIError(
                ERR_API_ERROR % response.status_code,
                status_code=response.status_code,
                response=error_data,
            )

        logger.debug(LOG_REQUEST_SUCCESS, path)
        return response.json() if response.content else {}

    # Health Check Methods

    async def health(self) -> HealthResponse:
        """Get basic health status.

        Returns:
            Health response with status

        Example:
            ```python
            health = await client.health()
            print(health.status)  # "UP"
            ```
        """
        data = await self._request("GET", "/health")
        return HealthResponse(**data)

    async def readiness(self) -> HealthResponse:
        """Get readiness status (includes storage health).

        Returns:
            Health response with detailed checks

        Example:
            ```python
            readiness = await client.readiness()
            print(readiness.checks)  # {"storage": "UP", ...}
            ```
        """
        data = await self._request("GET", "/health/readiness")
        return HealthResponse(**data)

    async def liveness(self) -> HealthResponse:
        """Get liveness status.

        Returns:
            Health response

        Example:
            ```python
            liveness = await client.liveness()
            ```
        """
        data = await self._request("GET", "/health/liveness")
        return HealthResponse(**data)

    # Admin API Key Methods

    async def create_admin_key(self, request: CreateAdminKeyRequest) -> AdminAPIKey:
        """Create a new admin API key.

        Admin keys have full access to create/manage context surfaces and generate agent keys.

        Args:
            request: Admin key creation request

        Returns:
            Created admin API key with the key value

        Example:
            ```python
            admin_key = await client.create_admin_key(
                CreateAdminKeyRequest(
                    name="Production Admin",
                    owner="user123",
                    description="Admin key for production",
                    metadata={"env": "prod"}
                )
            )
            print(admin_key.key)  # Save this securely!
            ```
        """
        data = await self._request(
            "POST",
            "/api/v1/keys",
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return AdminAPIKey(**data)

    async def validate_key(self, key: str) -> dict[str, Any]:
        """Validate an API key.

        Args:
            key: API key to validate

        Returns:
            Validation result with owner and key_type

        Example:
            ```python
            result = await client.validate_key("my-api-key")
            print(result["valid"])  # True/False
            print(result["key_type"])  # "admin" or "agent"
            ```
        """
        data = await self._request(
            "POST",
            "/api/v1/keys/validate",
            json_data={"key": key},
        )
        return data

    # Context Surface Methods

    async def create_context_surface(
        self,
        request: CreateContextSurfaceRequest,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> ContextSurface:
        """Create a new context surface.

        Requires authentication via admin API key or session credentials.

        Args:
            request: Context surface creation request
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Created context surface

        Example:
            ```python
            surface = await client.create_context_surface(
                CreateContextSurfaceRequest(
                    name="Customer Support Tools",
                    description="Tools for support agents",
                    tools=["search_tickets", "create_ticket"],
                    metadata={"department": "support"}
                ),
                admin_key=admin_key.key,
            )
            ```
        """
        data = await self._request(
            "POST",
            "/api/v1/context-surfaces",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return ContextSurface(**data)

    async def get_context_surface(
        self,
        surface_id: str,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> ContextSurface:
        """Get a context surface by ID.

        Requires authentication via admin API key or session credentials.

        Args:
            surface_id: Context surface ID
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Context surface

        Example:
            ```python
            surface = await client.get_context_surface("ce-123", admin_key=admin_key.key)
            ```
        """
        data = await self._request(
            "GET",
            f"/api/v1/context-surfaces/{surface_id}",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
        )
        return ContextSurface(**data)

    async def list_context_surfaces(
        self,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> ListContextSurfacesResponse:
        """List all context surfaces with pagination.

        Requires authentication via admin API key or session credentials.

        Args:
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication
            page: Page number (1-indexed)
            page_size: Number of items per page (max 100)

        Returns:
            List of context surfaces with pagination metadata

        Example:
            ```python
            response = await client.list_context_surfaces(admin_key=admin_key.key, page=1, page_size=10)
            for surface in response.context_surfaces:
                print(surface.name)
            ```
        """
        data = await self._request(
            "GET",
            "/api/v1/context-surfaces",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            params={"page": page, "page_size": page_size},
        )
        return ListContextSurfacesResponse(**data)

    async def update_context_surface(
        self,
        surface_id: str,
        request: UpdateContextSurfaceRequest,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> ContextSurface:
        """Update a context surface.

        Requires authentication via admin API key or session credentials.

        Args:
            surface_id: Context surface ID
            request: Update request with fields to change
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Updated context surface

        Example:
            ```python
            surface = await client.update_context_surface(
                "ce-123",
                UpdateContextSurfaceRequest(
                    name="Updated Name",
                    tools=["tool1", "tool2", "tool3"]
                ),
                admin_key=admin_key.key,
            )
            ```
        """
        data = await self._request(
            "PUT",
            f"/api/v1/context-surfaces/{surface_id}",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return ContextSurface(**data)

    async def delete_context_surface(
        self,
        surface_id: str,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> dict[str, str]:
        """Delete a context surface.

        Requires authentication via admin API key or session credentials.

        Args:
            surface_id: Context surface ID
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Success message

        Example:
            ```python
            result = await client.delete_context_surface("ce-123", admin_key=admin_key.key)
            print(result["message"])
            ```
        """
        data = await self._request(
            "DELETE",
            f"/api/v1/context-surfaces/{surface_id}",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
        )
        return data

    # Agent API Key Methods

    async def create_agent_key(
        self,
        surface_id: str,
        request: CreateAgentKeyRequest,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> AgentAPIKey:
        """Create an agent API key for a context surface.

        Agent keys are scoped to a specific context surface and can only invoke
        tools from that context surface via the MCP protocol.

        Requires authentication via admin API key or session credentials.

        Args:
            surface_id: Context surface ID
            request: Agent key creation request
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Created agent API key with the key value

        Example:
            ```python
            agent_key = await client.create_agent_key(
                "ce-123",
                CreateAgentKeyRequest(
                    name="Production Agent",
                    description="Agent for production use",
                    metadata={"env": "prod"}
                ),
                admin_key=admin_key.key,
            )
            print(agent_key.key)  # Save this for MCP client!
            ```
        """
        data = await self._request(
            "POST",
            f"/api/v1/context-surfaces/{surface_id}/agent-keys",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return AgentAPIKey(**data)

    async def list_agent_keys(
        self,
        surface_id: str,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> ListAgentKeysResponse:
        """List all agent keys for a context surface.

        Requires authentication via admin API key or session credentials.

        Args:
            surface_id: Context surface ID
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication
            page: Page number (1-indexed)
            page_size: Number of items per page (max 100)

        Returns:
            List of agent keys with pagination metadata

        Example:
            ```python
            response = await client.list_agent_keys("ce-123", admin_key=admin_key.key)
            for key in response.agent_keys:
                print(key.name)
            ```
        """
        data = await self._request(
            "GET",
            f"/api/v1/context-surfaces/{surface_id}/agent-keys",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            params={"page": page, "page_size": page_size},
        )
        return ListAgentKeysResponse(**data)

    # Redis Instance Methods

    async def register_redis_instance(
        self,
        request: RegisterRedisInstanceRequest,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> RedisInstance:
        """Register a new Redis instance.

        Requires authentication via admin API key or session credentials.

        Args:
            request: Redis instance registration request
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Registered Redis instance

        Example:
            ```python
            from context_surfaces import RedisConnectionConfig, RegisterRedisInstanceRequest

            instance = await client.register_redis_instance(
                RegisterRedisInstanceRequest(
                    name="Production Redis",
                    description="Main Redis instance",
                    connection_config=RedisConnectionConfig(
                        addr="localhost:6379",
                        password="",
                        db=0,
                        tls_enabled=False,
                        pool_size=10,
                        min_idle_conns=2
                    ),
                    metadata={"env": "production"}
                ),
                admin_key=admin_key.key,
            )
            ```
        """
        data = await self._request(
            "POST",
            "/api/v1/redis-instances",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return RedisInstance(**data)

    async def list_redis_instances(
        self,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> ListRedisInstancesResponse:
        """List all Redis instances.

        Requires authentication via admin API key or session credentials.

        Args:
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            List of Redis instances

        Example:
            ```python
            response = await client.list_redis_instances(admin_key=admin_key.key)
            for instance in response.instances:
                print(instance.name)
            ```
        """
        data = await self._request(
            "GET",
            "/api/v1/redis-instances",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
        )
        return ListRedisInstancesResponse(**data)

    async def get_redis_instance(
        self,
        instance_id: str,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> RedisInstance:
        """Get a Redis instance by ID.

        Requires authentication via admin API key or session credentials.

        Args:
            instance_id: Redis instance ID
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Redis instance

        Example:
            ```python
            instance = await client.get_redis_instance("redis-123", admin_key=admin_key.key)
            print(instance.name)
            ```
        """
        data = await self._request(
            "GET",
            f"/api/v1/redis-instances/{instance_id}",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
        )
        return RedisInstance(**data)

    async def delete_redis_instance(
        self,
        instance_id: str,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> None:
        """Delete a Redis instance.

        Requires authentication via admin API key or session credentials.

        Args:
            instance_id: Redis instance ID to delete
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Example:
            ```python
            await client.delete_redis_instance("redis-inst-123", admin_key=admin_key.key)
            ```
        """
        await self._request(
            "DELETE",
            f"/api/v1/redis-instances/{instance_id}",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
        )

    async def test_redis_connection(
        self,
        request: TestConnectionRequest,
        admin_key: str | None = None,
        session_id: str | None = None,
        csrf_token: str | None = None,
    ) -> TestConnectionResponse:
        """Test a Redis connection.

        Requires authentication via admin API key or session credentials.

        Args:
            request: Connection test request
            admin_key: Admin API key for authentication
            session_id: Optional JSESSIONID for session authentication
            csrf_token: Optional CSRF token for session authentication

        Returns:
            Test result

        Example:
            ```python
            from context_surfaces import RedisConnectionConfig, TestConnectionRequest

            result = await client.test_redis_connection(
                TestConnectionRequest(
                    connection_config=RedisConnectionConfig(
                        addr="localhost:6379",
                        password="",
                        db=0
                    )
                ),
                admin_key=admin_key.key,
            )
            print(f"Success: {result.success}")
            ```
        """
        data = await self._request(
            "POST",
            "/api/v1/redis-instances/test-connection",
            api_key=admin_key,
            session_id=session_id,
            csrf_token=csrf_token,
            json_data=request.model_dump(mode="json", exclude_none=True),
        )
        return TestConnectionResponse(**data)
