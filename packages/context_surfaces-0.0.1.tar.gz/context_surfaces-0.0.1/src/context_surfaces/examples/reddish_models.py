"""Reddish Support Agent API data models.

This module defines the complete Reddish support system with vector-indexed
policies and intelligent assistance.
"""

from __future__ import annotations

from typing import Any

from context_surfaces.context_model import (
    ContextField,
    ContextModel,
    ContextRelationship,
)


class Customer(ContextModel):
    """Reddish customer account with comprehensive profile"""

    __redis_key_template__ = "customer:{id}"

    id: int = ContextField(
        description="Unique customer ID",
        is_key_component=True,
    )
    tenant_id: str = ContextField(
        description="Tenant ID for multi-tenant access control",
        index="tag",
    )
    email: str = ContextField(
        description="Customer email address",
        index="text",
        weight=1.0,
        no_stem=True,
    )
    phone: str = ContextField(
        description="Customer phone number",
    )
    account_status: str = ContextField(
        description="active, suspended, banned, flagged",
        index="tag",
    )
    customer_tier: str = ContextField(
        description="regular, premium, dashpass",
    )
    city: str = ContextField(
        description="Primary city for orders",
        index="tag",
    )
    lifetime_value: float = ContextField(
        description="Total amount spent by customer",
    )

    # Relationships
    orders: Any = ContextRelationship(
        description="All orders placed by this customer",
        source_field="customer_id",
    )


class Restaurant(ContextModel):
    """Restaurant/merchant information and performance metrics"""

    __redis_key_template__ = "restaurant:{id}"

    id: int = ContextField(
        description="Unique restaurant ID",
        is_key_component=True,
    )
    name: str = ContextField(
        description="Restaurant name",
        index="text",
        weight=2.0,
    )
    cuisine_type: str = ContextField(
        description="Cuisine category",
        index="tag",
    )
    rating: float = ContextField(
        description="Average customer rating",
    )
    status: str = ContextField(
        description="active, inactive, suspended, closed",
    )

    # Relationships
    orders: Any = ContextRelationship(
        description="All orders from this restaurant",
        source_field="restaurant_id",
    )


class Order(ContextModel):
    """Reddish order with complete lifecycle tracking"""

    __redis_key_template__ = "order:{id}"

    id: int = ContextField(
        description="Unique order ID",
        is_key_component=True,
    )
    tenant_id: str = ContextField(
        description="Tenant ID for multi-tenant access control",
        index="tag",
    )
    customer_id: int = ContextField(
        description="Customer ID who placed order",
        index="tag",
    )
    restaurant_id: int = ContextField(
        description="Restaurant ID fulfilling the order",
        index="tag",
    )
    status: str = ContextField(
        description="Order status: preparing, in_transit, delivered, cancelled",
        index="tag",
    )
    order_total: float = ContextField(
        description="Total order amount",
        index="numeric",
        sortable=True,
    )
    special_instructions: str = ContextField(
        description="Special delivery instructions",
    )

    # Relationships
    customer: Any = ContextRelationship(
        description="Customer who placed order",
        source_field="customer_id",
    )
    restaurant: Any = ContextRelationship(
        description="Restaurant fulfilling the order",
        source_field="restaurant_id",
    )


class Policy(ContextModel):
    """Support policy with vector search capabilities for intelligent assistance"""

    __redis_key_template__ = "policy:{id}"

    id: int = ContextField(
        description="Unique policy ID",
        is_key_component=True,
    )
    category: str = ContextField(
        description="Policy category",
        index="tag",
    )
    priority: str = ContextField(
        description="low, medium, high, critical",
    )
    content_embedding: list[float] = ContextField(
        description="Vector embedding of policy content for semantic search",
        index="vector",
        vector_dim=1536,
        distance_metric="cosine",
        default_factory=list,
    )
    title: str = ContextField(
        description="Policy title",
    )
