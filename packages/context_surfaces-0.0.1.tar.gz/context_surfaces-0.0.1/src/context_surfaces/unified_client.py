"""Unified client that combines API and MCP functionality for easier usage."""

import logging
from typing import Any, Literal

from context_surfaces import config
from context_surfaces.client import ContextSurfacesClient
from context_surfaces.context_model import ContextModel
from context_surfaces.mcp_client import MCPClient
from context_surfaces.models import (
    AdminAPIKey,
    AgentAPIKey,
    ContextSurface,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    DataImportResponse,
)
from context_surfaces.url_config import resolve_url

logger = logging.getLogger(__name__)


class UnifiedClient:
    """Unified client that combines API and MCP functionality.

    This client provides a high-level interface for working with the Context Surfaces,
    combining both the REST API client and MCP client for seamless interaction.

    Example:
        ```python
        async with UnifiedClient(
            api_url="http://localhost:8080",
            mcp_url="http://localhost:8081"
        ) as client:
            # Create admin key
            admin_key = await client.create_admin_key("My Admin", "user@example.com")

            # Create context surface with data model
            surface = await client.create_context_surface(
                admin_key.key,
                "My Context Surface",
                data_model={...}
            )

            # Create agent key
            agent_key = await client.create_agent_key(
                admin_key.key,
                surface.id,
                "My Agent"
            )

            # Query via MCP tools
            results = await client.query_tool(
                agent_key.key,
                "search_customer_by_text",
                {"query": "john", "limit": 10}
            )
        ```
    """

    def __init__(
        self,
        api_url: str | None = None,
        mcp_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the unified client.

        Args:
            api_url: Base URL of the API server.
                Resolution order: explicit value, CTX_API_URL env var, default URL.
            mcp_url: Base URL of the MCP server.
                Resolution order: explicit value, CTX_MCP_URL env var, default URL.
            timeout: Request timeout in seconds
        """
        self.api_url = resolve_url(
            explicit_value=api_url,
            config_value=config.api_url,
            ensure_trailing_slash=True,  # Required for httpx base_url joining
        )
        self.mcp_url = resolve_url(
            explicit_value=mcp_url,
            config_value=config.mcp_url,
            ensure_trailing_slash=False,  # Direct URL usage, no base_url joining
        )
        self.timeout = timeout
        self._api_client: ContextSurfacesClient | None = None
        self._mcp_client: MCPClient | None = None

    async def __aenter__(self) -> "UnifiedClient":
        """Async context manager entry."""
        self._api_client = ContextSurfacesClient(self.api_url, timeout=self.timeout)
        await self._api_client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        if self._api_client:
            await self._api_client.__aexit__(*args)
        if self._mcp_client:
            await self._mcp_client.close()

    async def create_admin_key(
        self,
        name: str,
        owner: str,
        description: str = "",
    ) -> AdminAPIKey:
        """Create an admin API key.

        Args:
            name: Name of the admin key
            owner: Owner of the admin key
            description: Description of the admin key

        Returns:
            Created admin API key
        """
        if not self._api_client:
            raise RuntimeError("Client not initialized. Use 'async with' context manager.")

        return await self._api_client.create_admin_key(
            CreateAdminKeyRequest(name=name, owner=owner, description=description)
        )

    async def create_context_surface(
        self,
        admin_key: str,
        name: str,
        data_model: dict[str, Any] | None = None,
        description: str = "",
    ) -> ContextSurface:
        """Create a context surface.

        Args:
            admin_key: Admin API key for authentication
            name: Name of the context surface
            data_model: Optional data model for auto-generating tools
            description: Description of the context surface

        Returns:
            Created context surface
        """
        if not self._api_client:
            raise RuntimeError("Client not initialized. Use 'async with' context manager.")

        return await self._api_client.create_context_surface(
            CreateContextSurfaceRequest(
                name=name,
                description=description,
                data_model=data_model,
                redis_instance_id=None,
            ),
            admin_key=admin_key,
        )

    async def create_agent_key(
        self,
        admin_key: str,
        surface_id: str,
        name: str,
        description: str = "",
    ) -> AgentAPIKey:
        """Create an agent API key.

        Args:
            admin_key: Admin API key for authentication
            surface_id: ID of the context surface
            name: Name of the agent key
            description: Description of the agent key

        Returns:
            Created agent API key
        """
        if not self._api_client:
            raise RuntimeError("Client not initialized. Use 'async with' context manager.")

        return await self._api_client.create_agent_key(
            surface_id,
            CreateAgentKeyRequest(
                name=name, description=description, expires_at=None, access_tags=None
            ),
            admin_key=admin_key,
        )

    async def query_tool(
        self,
        agent_key: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
    ) -> Any:
        """Query data via an MCP tool.

        Args:
            agent_key: Agent API key for authentication
            tool_name: Name of the tool to call
            arguments: Tool arguments

        Returns:
            Tool execution result
        """
        # Create MCP client if not already created or if agent key changed
        if not self._mcp_client or self._mcp_client.agent_key != agent_key:
            if self._mcp_client:
                await self._mcp_client.close()

            self._mcp_client = MCPClient(
                mcp_url=self.mcp_url,
                agent_key=agent_key,
                timeout=self.timeout,
            )
            await self._mcp_client.connect()

        return await self._mcp_client.call_tool(tool_name, arguments)

    async def list_tools(self, agent_key: str) -> list[dict[str, Any]]:
        """List available tools for a context surface.

        Args:
            agent_key: Agent API key for authentication

        Returns:
            List of available tools
        """
        # Create MCP client if not already created or if agent key changed
        if not self._mcp_client or self._mcp_client.agent_key != agent_key:
            if self._mcp_client:
                await self._mcp_client.close()

            self._mcp_client = MCPClient(
                mcp_url=self.mcp_url,
                agent_key=agent_key,
                timeout=self.timeout,
            )
            await self._mcp_client.connect()

        return await self._mcp_client.list_tools()

    async def import_data(
        self,
        admin_key: str,
        context_surface_id: str,
        records: list[ContextModel],
        on_conflict: Literal["overwrite", "skip", "error"] = "overwrite",
        on_error: Literal["continue", "fail_fast"] = "continue",
    ) -> DataImportResponse:
        """Import ContextModel instances into a context surface.

        This method sends records to the Context Surface REST API for storage
        in the user's Redis instance. Records are validated locally via Pydantic
        before being sent to the server.

        Args:
            admin_key: Admin API key for authentication
            context_surface_id: ID of the context surface to import into
            records: List of ContextModel instances to import.
                     All records must be of the same model type.
            on_conflict: Behavior when a record key already exists:
                         - "overwrite": Replace existing record (default)
                         - "skip": Skip if key exists
                         - "error": Fail the record if key exists
            on_error: Behavior when a record fails validation:
                      - "continue": Skip invalid records, import valid ones (default)
                      - "fail_fast": Stop on first error, no records imported

        Returns:
            DataImportResponse containing:
            - imported: Count of successfully imported records
            - failed: Count of failed records
            - errors: List of DataImportError with details about failures

        Raises:
            ValueError: If records list is empty or contains mixed types
            RuntimeError: If client not initialized (not in async context)
            APIError: If API request fails

        Example:
            >>> from context_surfaces import UnifiedClient, ContextModel, ContextField
            >>>
            >>> class Customer(ContextModel):
            ...     __redis_key_template__ = "customer:{id}"
            ...     id: int = ContextField(description="Customer ID", is_key_component=True)
            ...     email: str = ContextField(description="Email", index="text")
            ...     status: str = ContextField(description="Status", index="tag")
            >>>
            >>> async with UnifiedClient(api_url="http://localhost:8080") as client:
            ...     customers = [
            ...         Customer(id=1, email="john@example.com", status="active"),
            ...         Customer(id=2, email="jane@example.com", status="pending"),
            ...     ]
            ...     result = await client.import_data(
            ...         admin_key="cs_admin_xxx",
            ...         context_surface_id="abc123",
            ...         records=customers,
            ...     )
            ...     print(f"Imported: {result.imported}, Failed: {result.failed}")
            Imported: 2, Failed: 0
        """
        if not self._api_client:
            raise RuntimeError("Client not initialized. Use 'async with' context manager.")

        if not records:
            raise ValueError("records cannot be empty")

        # Verify all records are the same type
        first_type = type(records[0])
        if not all(isinstance(r, first_type) for r in records):
            raise ValueError("All records must be of the same ContextModel type")

        # Infer entity name from the model class
        entity = first_type.__name__

        # Convert ContextModel instances to dicts
        record_dicts = [record.model_dump() for record in records]

        # Build request payload
        payload = {
            "entity": entity,
            "records": record_dicts,
            "options": {
                "on_conflict": on_conflict,
                "on_error": on_error,
            },
        }

        # Call API using the underlying client's _request method
        response = await self._api_client._request(
            "POST",
            f"/api/v1/context-surfaces/{context_surface_id}/data",
            api_key=admin_key,
            json_data=payload,
        )

        return DataImportResponse(**response)
