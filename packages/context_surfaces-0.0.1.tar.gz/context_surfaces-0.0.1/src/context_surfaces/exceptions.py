"""Exceptions for Context Surfaces client."""

from typing import Any


class ContextSurfacesError(Exception):
    """Base exception for all Context Surfaces errors."""


class APIError(ContextSurfacesError):
    """General API error."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict[str, Any] | None = None,
    ) -> None:
        """Initialize API error.

        Args:
            message: Error message
            status_code: HTTP status code
            response: Response data from the API
        """
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}


class AuthenticationError(ContextSurfacesError):
    """Authentication failed (401)."""


class AuthorizationError(ContextSurfacesError):
    """Authorization failed (403)."""


class NotFoundError(ContextSurfacesError):
    """Resource not found (404)."""


class ValidationError(ContextSurfacesError):
    """Request validation failed (400)."""


class RateLimitError(ContextSurfacesError):
    """Rate limit exceeded (429)."""


class ServerError(ContextSurfacesError):
    """Server error (5xx)."""


class MCPError(ContextSurfacesError):
    """MCP protocol error."""


class ConnectionError(ContextSurfacesError):
    """Connection error."""


class TimeoutError(ContextSurfacesError):
    """Request timeout."""
