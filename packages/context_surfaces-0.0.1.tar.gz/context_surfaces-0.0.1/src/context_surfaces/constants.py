"""Constants for Context Surfaces client."""

from http import HTTPStatus

# Default URLs
DEFAULT_API_URL = "https://cloud.redis.io/context-surfaces"
DEFAULT_MCP_URL = "https://gcp-us-east4.context-surfaces.redis.io/mcp"
DEFAULT_REDIS_CLOUD_URL = "https://cloud.redis.io/"

# HTTP Status Codes
HTTP_OK = HTTPStatus.OK
HTTP_BAD_REQUEST = HTTPStatus.BAD_REQUEST
HTTP_UNAUTHORIZED = HTTPStatus.UNAUTHORIZED
HTTP_FORBIDDEN = HTTPStatus.FORBIDDEN
HTTP_NOT_FOUND = HTTPStatus.NOT_FOUND
HTTP_TOO_MANY_REQUESTS = HTTPStatus.TOO_MANY_REQUESTS
HTTP_INTERNAL_SERVER_ERROR = HTTPStatus.INTERNAL_SERVER_ERROR

# Error Messages
ERR_INVALID_API_KEY = "Invalid or missing API key"
ERR_RESOURCE_NOT_FOUND = "Resource not found: %s"
ERR_VALIDATION_ERROR = "Validation error"
ERR_API_ERROR = "API error: %s"
ERR_RELATIONSHIP_READONLY = "Relationships are read-only and cannot be set. Field: %s"
ERR_VECTOR_DIM_REQUIRED = "vector_dim is required for vector index type"
ERR_RELATIONSHIP_DESCRIPTOR = "Relationships cannot be set on instances. Field: %s"

# Logging Messages
LOG_CLIENT_INITIALIZED = "Initialized ContextSurfacesClient with base_url=%s"
LOG_REQUEST_DEBUG = "Making %s request to %s"
LOG_RESPONSE_STATUS = "Response status: %s"
LOG_AUTH_FAILED = "Authentication failed for %s"
LOG_NOT_FOUND = "Resource not found: %s"
LOG_VALIDATION_ERROR = "Validation error for %s: %s"
LOG_API_ERROR = "API error %s for %s: %s"
LOG_REQUEST_SUCCESS = "Request to %s successful"

# MCP Constants
MCP_JSONRPC_VERSION = "2.0"
MCP_METHOD_INITIALIZE = "initialize"
MCP_METHOD_LIST_TOOLS = "tools/list"
MCP_METHOD_CALL_TOOL = "tools/call"

# Context Model Constants
MIN_RELATIONSHIP_ARGS = 2

# CLI Constants
CLI_APP_NAME = "ctxctl"
