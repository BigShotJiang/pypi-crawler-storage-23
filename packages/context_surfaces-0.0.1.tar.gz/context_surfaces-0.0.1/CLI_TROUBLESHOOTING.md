# CLI Troubleshooting Guide

## Common Issues and Solutions

### Issue: "cannot import 'app' from 'context_surfaces.cli'"

**Symptoms:**
```bash
ImportError: cannot import name 'app' from 'context_surfaces.cli'
```

**Causes:**
1. Package not installed in editable mode
2. Running from wrong directory
3. Using wrong Python environment
4. Cached `.pyc` files

**Solutions:**

#### 1. Reinstall the package
```bash
cd python-client
uv pip install -e .
```

#### 2. Force reinstall
```bash
cd python-client
uv pip install -e . --force-reinstall
```

#### 3. Clear Python cache
```bash
cd python-client
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete
uv pip install -e . --force-reinstall
```

#### 4. Verify installation
```bash
# Check package is installed
uv pip list | grep context-surfaces

# Check CLI is available
uv run which cce

# Test import
uv run python -c "from context_surfaces.cli import app; print('Success!')"

# Test CLI
uv run cce --help
```

### Issue: CLI command not found

**Symptoms:**
```bash
cce: command not found
```

**Solutions:**

#### 1. Use `uv run` prefix
```bash
uv run cce --help
```

#### 2. Activate virtual environment
```bash
cd python-client
source .venv/bin/activate  # On Unix/macOS
# or
.venv\Scripts\activate  # On Windows

cce --help
```

#### 3. Use full path
```bash
cd python-client
.venv/bin/cce --help
```

### Issue: Wrong Python environment

**Symptoms:**
- CLI works with `uv run` but not directly
- Import errors when running Python scripts

**Solutions:**

#### 1. Check which Python you're using
```bash
which python
which python3
```

#### 2. Always use `uv run` for consistency
```bash
uv run cce --help
uv run python script.py
```

#### 3. Or activate the virtual environment
```bash
cd python-client
source .venv/bin/activate
```

### Issue: Module not found errors

**Symptoms:**
```bash
ModuleNotFoundError: No module named 'typer'
ModuleNotFoundError: No module named 'rich'
```

**Solutions:**

#### 1. Install the package
```bash
cd python-client
uv pip install -e .
```

#### 2. Or install with dev dependencies
```bash
cd python-client
uv sync
```

## Verification Steps

Run these commands to verify everything is working:

```bash
cd python-client

# 1. Check package installation
uv pip list | grep context-surfaces

# 2. Test import
uv run python -c "from context_surfaces.cli import app; print('✅ Import successful')"

# 3. Test CLI help
uv run cce --help

# 4. Test version command
uv run cce version

# 5. Test config command
uv run cce config --help

# 6. Test auth command
uv run cce auth --help
```

All commands should succeed without errors.

## Running the CLI

### Recommended: Use `uv run`
```bash
uv run cce --help
uv run cce version
uv run cce config show
```

### Alternative: Activate virtual environment
```bash
source .venv/bin/activate
cce --help
cce version
cce config show
```

### Alternative: Use full path
```bash
.venv/bin/cce --help
.venv/bin/cce version
```

## Getting Help

If you're still having issues:

1. Check Python version: `python --version` (should be 3.11+)
2. Check uv version: `uv --version`
3. Reinstall from scratch:
   ```bash
   cd python-client
   rm -rf .venv
   uv venv
   uv pip install -e ".[cli,dev]"
   uv run cce --help
   ```
