# Quick Start Guide

Get started with the Context Surfaces Python client in 5 minutes!

## Prerequisites

- Python 3.11 or higher
- Running Context Surfaces server (default: http://localhost:8080)
- Running MCP server (default: http://localhost:8081)

## Installation

### Option 1: Using uv (Recommended)

```bash
# Install uv if you haven't already
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install the client
cd python-client
uv pip install -e .
```

### Option 2: Using pip

```bash
cd python-client
pip install -e .
```

## Quick Test

### 1. Check Server Health

```bash
# Using CLI
python -m context_surfaces.cli health

# Or using Python
python -c "
import asyncio
from context_surfaces import ContextSurfacesClient

async def main():
    async with ContextSurfacesClient() as client:
        health = await client.health()
        print(f'Status: {health.status}')

asyncio.run(main())
"
```

### 2. Run the Basic Workflow Example

```bash
# Make sure the server is running
python examples/basic_workflow.py
```

This will:
1. Create an admin API key
2. Create a context surface
3. List context surfaces
4. Create an agent API key
5. List agent keys
6. Connect to MCP server
7. List and invoke tools

### 3. Try the CLI

```bash
# Create an admin key
python -m context_surfaces.cli create-admin-key "My Admin" "user123"

# Save the key from the output, then create a context surface
ctxctl surface create \
  --name "Customer Support" \
  --admin-key "your-admin-key-here" \
  --description "Tools for customer support"

# List context surfaces
ctxctl surface list --admin-key "your-admin-key-here"

# Create an agent key
ctxctl agent create \
  --surface-id "surface-id-here" \
  --name "Support Agent" \
  --admin-key "your-admin-key-here"
```

## Your First Script

Create a file `my_first_script.py`:

```python
"""My first Context Surfaces script."""

import asyncio
from context_surfaces import (
    ContextSurfacesClient,
    CreateAdminKeyRequest,
    CreateContextSurfaceRequest,
)

async def main():
    # Connect to the API
    async with ContextSurfacesClient("http://localhost:8080") as client:
        # Create an admin key
        admin_key = await client.create_admin_key(
            CreateAdminKeyRequest(
                name="My First Admin Key",
                owner="me",
                description="Testing the client",
            )
        )
        print(f"✓ Admin Key: {admin_key.key}")

        # Create a context surface
        surface = await client.create_context_surface(
            admin_key.key,
            CreateContextSurfaceRequest(
                name="My First Surface",
                description="My first context surface",
                tools=["tool1", "tool2"],
            ),
        )
        print(f"✓ Surface ID: {surface.id}")
        print(f"✓ Surface Name: {surface.name}")
        print(f"✓ Tools: {surface.tools}")

if __name__ == "__main__":
    asyncio.run(main())
```

Run it:

```bash
python my_first_script.py
```

## Next Steps

1. **Read the full documentation**: See [README.md](README.md)
2. **Explore examples**: Check out the `examples/` directory
3. **Learn error handling**: See `examples/error_handling.py`
4. **Try MCP tools**: See `examples/mcp_tools.py`
5. **Development guide**: See [DEVELOPMENT.md](DEVELOPMENT.md)

## Common Issues

### Server Not Running

```
ConnectionError: Cannot connect to http://localhost:8080
```

**Solution**: Make sure the Context Surfaces server is running:

```bash
# In the main project directory
make run
```

### Import Errors

```
ModuleNotFoundError: No module named 'context_surfaces'
```

**Solution**: Install the package in editable mode:

```bash
uv pip install -e .
# or
pip install -e .
```

### Type Checking Errors

If you see mypy errors, make sure you have the dev dependencies:

```bash
uv sync
```

## Getting Help

- **Documentation**: See [README.md](README.md)
- **Examples**: See `examples/` directory
- **Issues**: Open an issue on GitHub
- **Development**: See [DEVELOPMENT.md](DEVELOPMENT.md)

## What's Next?

Now that you have the basics working, you can:

1. **Create multiple context surfaces** for different use cases
2. **Generate agent keys** for different AI agents
3. **Invoke MCP tools** using the MCP client
4. **Build your own applications** using the client library
5. **Contribute** to the project!

Happy coding! 🚀
