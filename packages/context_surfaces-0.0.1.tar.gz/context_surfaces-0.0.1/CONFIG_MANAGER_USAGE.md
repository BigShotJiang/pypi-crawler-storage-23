# Config Manager Usage Guide

The `ConfigManager` class provides comprehensive configuration management for the Context Surfaces CLI with support for multiple profiles, environment variables, and a clear configuration hierarchy.

## Features

✅ **Multiple Profiles**: Support for development, staging, production, and custom profiles
✅ **Configuration Hierarchy**: CLI flags > env vars > config file > defaults
✅ **YAML Configuration**: Human-readable config file at `~/.config/cce/config.yaml`
✅ **Pydantic Validation**: Full type safety and validation using Pydantic models
✅ **Environment Variables**: Support for `CTX_*` environment variables
✅ **Auto-creation**: Config directory is created automatically if it doesn't exist

## Configuration Schema

### Supported Settings

- `api_url`: API base URL (default: `http://localhost:8080`)
- `mcp_url`: MCP server URL (default: `http://localhost:8080/mcp`)
- `redis_cloud_url`: Redis Cloud URL for session-based login (default: `None`)
- `default_output_format`: Output format - `table`, `json`, or `yaml` (default: `table`)
- `color_output`: Enable colored output (default: `true`)
- `log_level`: Logging level - `debug`, `info`, `warning`, or `error` (default: `info`)
- `timeout`: Request timeout in seconds (default: `30`, range: 1-300)

### Environment Variables

- `CTX_API_URL`: Override API URL
- `CTX_MCP_URL`: Override MCP URL
- `CTX_REDIS_CLOUD_URL`: Override Redis Cloud URL for session login
- `CTX_OUTPUT_FORMAT`: Override output format
- `CTX_COLOR_OUTPUT`: Override color output (true/false)
- `CTX_LOG_LEVEL`: Override log level
- `CTX_TIMEOUT`: Override timeout

## Basic Usage

```python
from context_surfaces.cli.services import ConfigManager

# Initialize config manager (uses ~/.config/cce/config.yaml by default)
manager = ConfigManager()

# Load configuration
config = manager.load_config()

# Get a configuration value (respects hierarchy)
api_url = manager.get("api_url")
print(f"API URL: {api_url}")

# Set a configuration value
manager.set("api_url", "https://api.example.com")

# Save configuration to file
manager.save_config()
```

## Working with Profiles

```python
# List all profiles
profiles = manager.list_profiles()
print(f"Available profiles: {profiles}")

# Get configuration for a specific profile
staging_config = manager.get_profile_config("staging")
print(f"Staging API URL: {staging_config.api_url}")

# Create a new profile
manager.create_profile("custom", base_profile="production")

# Delete a profile
manager.delete_profile("custom")

# Reset a profile to defaults
manager.reset(profile="development")
```

## Configuration Hierarchy

The configuration hierarchy (highest to lowest priority):

1. **CLI flags**: Values passed directly to commands
2. **Environment variables**: `CTX_*` environment variables
3. **Config file**: `~/.config/cce/config.yaml`
4. **Defaults**: Built-in default values

```python
# Example showing hierarchy
import os

# Set environment variable
os.environ["CTX_API_URL"] = "https://env.example.com"

# Get value (env var takes precedence over config file)
url = manager.get("api_url")
print(url)  # https://env.example.com

# CLI value has highest priority
url = manager.get("api_url", cli_value="https://cli.example.com")
print(url)  # https://cli.example.com
```

## Example Config File

```yaml
default_profile: development
profiles:
  development:
    api_url: http://localhost:8080
    mcp_url: http://localhost:8080/mcp
    redis_cloud_url: https://app.redislabs.com
    default_output_format: table
    color_output: true
    log_level: info
    timeout: 30
  staging:
    api_url: https://staging.cce.example.com
    mcp_url: https://staging.cce.example.com/mcp
    redis_cloud_url: https://app.redislabs.com
    default_output_format: table
    color_output: true
    log_level: info
    timeout: 30
  production:
    api_url: https://cce.example.com
    mcp_url: https://cce.example.com/mcp
    redis_cloud_url: https://app.redislabs.com
    default_output_format: json
    color_output: false
    log_level: warning
    timeout: 60
```

## Validation

```python
# Validate configuration
try:
    is_valid = manager.validate()
    print(f"Config is valid: {is_valid}")
except ValueError as e:
    print(f"Config validation failed: {e}")
```

## Error Handling

```python
try:
    manager.set("api_url", "invalid-url")  # Missing http:// or https://
except ValueError as e:
    print(f"Validation error: {e}")

try:
    manager.get("invalid_key")
except ValueError as e:
    print(f"Invalid key: {e}")

try:
    manager.delete_profile("development")  # Can't delete default profile
except ValueError as e:
    print(f"Error: {e}")
```

## Advanced Usage

### Custom Config Path

```python
from pathlib import Path

# Use custom config path
custom_path = Path("/etc/cce/config.yaml")
manager = ConfigManager(config_path=custom_path)
```

### Profile Management

```python
# Create profile from scratch
manager.create_profile("testing")

# Create profile based on existing one
manager.create_profile("qa", base_profile="staging")

# Change default profile
config = manager.load_config()
config.default_profile = "production"
manager.save_config(config)
```

## Type Safety

All configuration values are fully typed using Pydantic:

```python
from context_surfaces.cli.services import (
    ConfigManager,
    LogLevel,
    OutputFormat,
    ProfileConfig,
)

# Type-safe configuration
profile = ProfileConfig(
    api_url="https://api.example.com",
    log_level=LogLevel.DEBUG,
    default_output_format=OutputFormat.JSON,
    timeout=60,
)
```
