"""Example demonstrating error handling patterns."""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from rich.console import Console

from context_surfaces import ContextSurfacesClient, CreateAdminKeyRequest
from context_surfaces.exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
)

console = Console()


async def demonstrate_error_handling() -> None:
    """Demonstrate various error handling scenarios."""
    console.print("[bold cyan]Error Handling Examples[/bold cyan]\n")

    async with ContextSurfacesClient("http://localhost:8080") as client:
        # Example 1: Validation Error
        console.print("[bold]Example 1:[/bold] Validation Error")
        try:
            # Try to create admin key with invalid data
            await client.create_admin_key(
                CreateAdminKeyRequest(
                    name="",  # Empty name should fail validation
                    owner="user123",
                )
            )
        except ValidationError as e:
            console.print(f"[yellow]✓ Caught ValidationError:[/yellow] {e}")
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")

        # Example 2: Authentication Error
        console.print("\n[bold]Example 2:[/bold] Authentication Error")
        try:
            # Try to access protected endpoint with invalid key
            await client.get_surface("invalid-key", "ce-123")
        except AuthenticationError as e:
            console.print(f"[yellow]✓ Caught AuthenticationError:[/yellow] {e}")
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")

        # Example 3: Not Found Error
        console.print("\n[bold]Example 3:[/bold] Not Found Error")
        try:
            # Create a valid admin key first
            admin_key = await client.create_admin_key(
                CreateAdminKeyRequest(
                    name="Test Admin",
                    owner="user123",
                )
            )

            # Try to get non-existent context surface
            await client.get_context_surface("non-existent-id", admin_key=admin_key.key)
        except NotFoundError as e:
            console.print(f"[yellow]✓ Caught NotFoundError:[/yellow] {e}")
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")

        # Example 4: Generic API Error
        console.print("\n[bold]Example 4:[/bold] Generic API Error Handling")
        try:
            # This might fail for various reasons
            await client.create_admin_key(
                CreateAdminKeyRequest(
                    name="Test",
                    owner="user123",
                )
            )
            console.print("[green]✓ Request succeeded[/green]")
        except APIError as e:
            console.print(f"[yellow]API Error:[/yellow] {e}")
            console.print(f"  Status Code: {e.status_code}")
            console.print(f"  Response: {e.response}")
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")

        # Example 5: Retry Logic
        console.print("\n[bold]Example 5:[/bold] Automatic Retry (built-in)")
        console.print(
            "[dim]The client automatically retries failed requests with exponential backoff[/dim]"
        )
        try:
            # Health check should succeed
            health = await client.health()
            console.print(f"[green]✓ Health check succeeded:[/green] {health.status}")
        except Exception as e:
            console.print(f"[red]Health check failed after retries:[/red] {e}")

        # Example 6: Context Manager Cleanup
        console.print("\n[bold]Example 6:[/bold] Context Manager Cleanup")
        console.print("[dim]Using 'async with' ensures proper cleanup even on errors[/dim]")

        try:
            async with ContextSurfacesClient("http://localhost:8080") as _:
                # Simulate an error
                raise ValueError("Simulated error")
        except ValueError:
            console.print("[green]✓ Context manager cleaned up properly despite error[/green]")

        # Example 7: Graceful Degradation
        console.print("\n[bold]Example 7:[/bold] Graceful Degradation")
        try:
            # Try to get context surface, fall back to default behavior
            surface = await client.get_context_surface("some-id", admin_key=admin_key.key)
            console.print(f"Found surface: {surface.name}")
        except NotFoundError:
            console.print("[yellow]Context surface not found, using default configuration[/yellow]")
            # Continue with default behavior
        except Exception as e:
            console.print(f"[red]Unexpected error, cannot continue:[/red] {e}")
            raise

    console.print("\n[bold green]✓ Error handling examples complete![/bold green]")


async def demonstrate_best_practices() -> None:
    """Demonstrate error handling best practices."""
    console.print("\n[bold cyan]Best Practices[/bold cyan]\n")

    # Best Practice 1: Specific exception handling
    console.print("[bold]1. Handle specific exceptions first[/bold]")
    console.print(
        "[dim]   Order: ValidationError → AuthenticationError → NotFoundError → APIError → Exception[/dim]"
    )

    # Best Practice 2: Always use context managers
    console.print("\n[bold]2. Always use async context managers[/bold]")
    console.print("[dim]   async with ContextSurfacesClient(...) as client:[/dim]")

    # Best Practice 3: Log errors appropriately
    console.print("\n[bold]3. Log errors with context[/bold]")
    console.print("[dim]   Include request details, user info, and error context[/dim]")

    # Best Practice 4: Don't swallow exceptions
    console.print("\n[bold]4. Don't swallow exceptions silently[/bold]")
    console.print("[dim]   Always log or re-raise, never use bare 'except: pass'[/dim]")

    # Best Practice 5: Validate input early
    console.print("\n[bold]5. Validate input before making API calls[/bold]")
    console.print("[dim]   Use Pydantic models to catch errors early[/dim]")


if __name__ == "__main__":
    try:
        asyncio.run(demonstrate_error_handling())
        asyncio.run(demonstrate_best_practices())
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"\n[bold red]Fatal error:[/bold red] {e}")
        raise
