# Context Surfaces - Python Examples

This directory contains example scripts demonstrating various features of the Context Surfaces Python client.

## Prerequisites

1. **Context Surfaces server** running on `http://localhost:8080`
2. **MCP server** running on `http://localhost:8081`
3. **Redis server** with RedisJSON and RediSearch modules (for RQE examples)
4. **Python dependencies** installed:
   ```bash
   cd python-client
   pip install -e .
   ```

## Examples

### 1. Basic Workflow (`basic_workflow.py`)

Complete workflow demonstrating:
- Creating admin API keys
- Creating context surfaces
- Creating agent API keys
- Invoking MCP tools

```bash
python examples/basic_workflow.py
```

### 2. MCP Tools (`mcp_tools.py`)

Demonstrates MCP tool invocation with various tool types.

```bash
python examples/mcp_tools.py
```

### 3. Error Handling (`error_handling.py`)

Shows proper error handling patterns when using the client.

```bash
python examples/error_handling.py
```

### 4. Unified Client (`unified_client_example.py`)

Demonstrates the unified client interface for simplified API access.

```bash
python examples/unified_client_example.py
```

### 5. RQE Workflow (`rqe_workflow.py`) ⭐ **NEW**

**Complete end-to-end RQE (Redis Query Engine) workflow** demonstrating:
- Admin API key creation
- Redis instance registration
- Context surface creation with DataModel
- Auto-generation of search/filter/query tools from your data model
- Sample data insertion
- Agent API key creation
- Querying data using auto-generated MCP tools

This example shows how to:
- Define your data model using Python classes (Customer, Order)
- Automatically generate RQE tools (search, filter, range queries, get by ID)
- Insert data into Redis
- Query data using the generated tools

```bash
python examples/rqe_workflow.py
```

**Prerequisites for RQE example:**
- Redis with RedisJSON and RediSearch modules
- Running on `localhost:6379`

**What it demonstrates:**
1. Creates admin API key
2. Registers Redis instance via API
3. Creates context surface with Reddish Customer/Order data model
4. Auto-generates 7+ RQE tools (search_customer_by_text, filter_customer_by_account_status, etc.)
5. Inserts sample customers and orders into Redis
6. Creates agent API key
7. Executes queries:
   - Text search: Find customers by name
   - Tag filter: Filter customers by account status
   - Range query: Find orders by price range
   - Get by ID: Retrieve specific customer
8. Cleans up all resources

**Expected output:**
```
RQE (Redis Query Engine) Workflow Example
Auto-generate search tools from your data model

Step 1: Creating admin API key...
✓ Admin Key: admin_...

Step 2: Registering Redis instance...
✓ Redis Instance: ri_...

Step 3: Creating context surface with DataModel...
✓ Context Surface: ce_...

Auto-Generated RQE Tools:
┌─────────────────────────────────────┬────────┐
│ Tool Name                           │ Type   │
├─────────────────────────────────────┼────────┤
│ search_customer_by_text             │ Search │
│ filter_customer_by_account_status   │ Filter │
│ get_customer_by_id                  │ Get    │
│ filter_order_by_customer_id         │ Filter │
│ find_order_by_order_total_range     │ Find   │
│ filter_order_by_status              │ Filter │
│ get_order_by_id                     │ Get    │
└─────────────────────────────────────┴────────┘

Step 4: Inserting sample data into Redis...
✓ Inserted 3 customers
✓ Inserted 4 orders

Step 5: Creating agent API key...
✓ Agent Key: agent_...

Step 6: Querying data using auto-generated MCP tools...

Query 1: Search customers by text (query='alice')
[... results ...]

✓ RQE workflow completed successfully!
```

## Configuration

All examples use default URLs that can be overridden with environment variables:

```bash
export BASE_URL=http://localhost:8080
export MCP_URL=http://localhost:8081/mcp
export REDIS_ADDR=localhost:6379
```

## Running the Server

To run the Context Surfaces server:

```bash
# From the repository root
make build
./bin/mcp-server
```

## Troubleshooting

**"Connection refused" errors:**
- Ensure the Context Surfaces server is running on port 8080
- Ensure the MCP server is running on port 8081

**"Redis module not found" errors (RQE examples):**
- Ensure Redis has RedisJSON and RediSearch modules installed
- Use Redis Stack or install modules separately

**Import errors:**
- Ensure you've installed the package: `pip install -e .` from the `python-client` directory
