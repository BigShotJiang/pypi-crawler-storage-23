"""Example using the UnifiedClient for simplified interaction with the Context Surfaces.

This example demonstrates how to use the UnifiedClient to:
1. Create an admin key
2. Create a context surface with a data model
3. Create an agent key
4. Query data via MCP tools

The UnifiedClient combines both the REST API client and MCP client for easier usage.
"""

import asyncio
import json

from context_surfaces import UnifiedClient


async def main():
    """Run the unified client example."""

    # Example data model for a simple customer/order system
    data_model = {
        "title": "Customer Order System",
        "description": "Simple customer and order tracking",
        "entity_count": 2,
        "entities": [
            {
                "name": "Customer",
                "description": "Customer entity",
                "redis_key_template": "customer:{id}",
                "fields": [
                    {
                        "name": "id",
                        "type": "int",
                        "description": "Customer ID",
                        "is_key_component": True,
                        "redis_indices": [],
                    },
                    {
                        "name": "email",
                        "type": "str",
                        "description": "Customer email",
                        "is_key_component": False,
                        "redis_indices": [{"type": "text", "weight": 1.0}],
                    },
                    {
                        "name": "account_status",
                        "type": "str",
                        "description": "Account status",
                        "is_key_component": False,
                        "redis_indices": [{"type": "tag"}],
                    },
                ],
                "relationships": [],
            },
            {
                "name": "Order",
                "description": "Order entity",
                "redis_key_template": "order:{id}",
                "fields": [
                    {
                        "name": "id",
                        "type": "int",
                        "description": "Order ID",
                        "is_key_component": True,
                        "redis_indices": [],
                    },
                    {
                        "name": "total_amount",
                        "type": "float",
                        "description": "Order total",
                        "is_key_component": False,
                        "redis_indices": [{"type": "numeric", "sortable": True}],
                    },
                ],
                "relationships": [],
            },
        ],
    }

    # Use the unified client
    async with UnifiedClient(
        api_url="http://localhost:8080", mcp_url="http://localhost:8081"
    ) as client:
        # Step 1: Create admin key
        print("Creating admin key...")
        admin_key = await client.create_admin_key(
            name="Example Admin",
            owner="example@example.com",
            description="Admin key for unified client example",
        )
        print(f"✓ Admin key created: {admin_key.id}")

        # Step 2: Create context surface with data model
        print("\nCreating context surface with data model...")
        surface = await client.create_context_surface(
            admin_key=admin_key.key,
            name="Example Context Surface",
            data_model=data_model,
            description="Example context surface with auto-generated tools",
        )
        print(f"✓ Context surface created: {surface.id}")

        # Step 3: Create agent key
        print("\nCreating agent key...")
        agent_key = await client.create_agent_key(
            admin_key=admin_key.key,
            surface_id=surface.id,
            name="Example Agent",
            description="Agent key for querying data",
        )
        print(f"✓ Agent key created: {agent_key.id}")

        # Step 4: List available tools
        print("\nListing available tools...")
        tools = await client.list_tools(agent_key=agent_key.key)
        print(f"✓ Found {len(tools)} tools:")
        for tool in tools:
            print(f"  - {tool.get('name')}: {tool.get('description', 'No description')}")

        # Step 5: Query data via MCP tools (example - requires data to be inserted first)
        print("\nQuerying data via MCP tools...")
        try:
            # Example: Search customers by text
            result = await client.query_tool(
                agent_key=agent_key.key,
                tool_name="search_customer_by_text",
                arguments={"query": "example", "limit": 10},
            )
            print(f"✓ Search result: {json.dumps(result, indent=2)}")
        except Exception as e:
            print(f"Note: Query failed (expected if no data inserted): {e}")

        print("\n✓ Example completed successfully!")


if __name__ == "__main__":
    asyncio.run(main())
