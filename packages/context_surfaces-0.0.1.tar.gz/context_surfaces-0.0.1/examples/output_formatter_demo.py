"""Demo script for OutputFormatter.

This script demonstrates the various formatting capabilities of the OutputFormatter class
using Pydantic output models.
"""

from datetime import datetime

from context_surfaces.cli.models.output import (
    JsonOutput,
    TableColumn,
    TableOutput,
    TableRow,
    TextOutput,
    YamlOutput,
)
from context_surfaces.cli.services import OutputFormatter
from context_surfaces.models import AdminAPIKey, ContextSurface, KeyType

# Create sample data
admin_key = AdminAPIKey(
    id="key-123",
    name="Production Admin Key",
    description="Main admin key for production",
    owner="user-456",
    key_type=KeyType.ADMIN,
    key="cs_admin_abc123def456",
    created_at=datetime(2024, 1, 15, 10, 30, 0),
    updated_at=datetime(2024, 1, 15, 10, 30, 0),
    metadata={"environment": "production", "team": "platform"},
)

surfaces = [
    ContextSurface(
        id="surface-1",
        name="Customer Support",
        description="Tools for customer support operations",
        owner="user-456",
        tools=["search_tickets", "create_ticket", "update_ticket"],
        created_at=datetime(2024, 1, 10, 9, 0, 0),
        updated_at=datetime(2024, 1, 15, 14, 30, 0),
        metadata={"department": "support"},
    ),
    ContextSurface(
        id="surface-2",
        name="Analytics Surface",
        description="Data analytics and reporting",
        owner="user-789",
        tools=["query_data", "generate_report", "export_csv"],
        created_at=datetime(2024, 1, 12, 11, 15, 0),
        updated_at=datetime(2024, 1, 14, 16, 45, 0),
        metadata={"department": "analytics"},
    ),
]


def main() -> None:
    """Run the demo."""
    print("=" * 80)
    print("OutputFormatter Demo - Using Pydantic Models")
    print("=" * 80)

    # Create formatter with color
    formatter = OutputFormatter(color=True)

    # Demo 1: Text output
    print("\n1. Simple text output:")
    print("-" * 80)
    text_output = TextOutput(text="Welcome to OutputFormatter Demo!", style="bold green")
    formatter.render(text_output)

    # Demo 2: Single object as table
    print("\n2. Single AdminAPIKey as TABLE (with color):")
    print("-" * 80)
    # Convert Pydantic model to dict for TableOutput
    table_output = TableOutput.from_dict(admin_key.model_dump(mode="json"), title="Admin API Key")
    formatter.render(table_output)

    # Demo 3: Single object as JSON
    print("\n3. Single AdminAPIKey as JSON (with color):")
    print("-" * 80)
    json_output = JsonOutput(data=admin_key.model_dump(mode="json"), indent=2)
    formatter.render(json_output)

    # Demo 4: Single object as YAML
    print("\n4. Single AdminAPIKey as YAML (with color):")
    print("-" * 80)
    yaml_output = YamlOutput(data=admin_key.model_dump(mode="json"))
    formatter.render(yaml_output)

    # Demo 5: List of objects as table
    print("\n5. List of Surfaces as TABLE (with color):")
    print("-" * 80)
    surfaces_data = [s.model_dump(mode="json") for s in surfaces]
    table_output = TableOutput.from_dicts(surfaces_data, title="Context Surfaces")
    formatter.render(table_output)

    # Demo 6: List of objects as JSON
    print("\n6. List of Surfaces as JSON (with color):")
    print("-" * 80)
    json_output = JsonOutput(data=surfaces_data, indent=2, sort_keys=True)
    formatter.render(json_output)

    # Demo 7: No color output
    print("\n7. List of Surfaces as TABLE (no color):")
    print("-" * 80)
    formatter_no_color = OutputFormatter(color=False)
    table_output = TableOutput.from_dicts(surfaces_data, title="Context Surfaces (No Color)")
    formatter_no_color.render(table_output)

    # Demo 8: Plain dict as table
    print("\n8. Plain dictionary as TABLE:")
    print("-" * 80)
    data = {
        "status": "healthy",
        "version": "1.0.0",
        "uptime": 3600,
        "active_connections": 42,
    }
    table_output = TableOutput.from_dict(data, title="System Status")
    formatter.render(table_output)

    # Demo 9: Nested structure as YAML
    print("\n9. Nested structure as YAML:")
    print("-" * 80)
    nested_data = {
        "server": {
            "host": "localhost",
            "port": 8080,
            "ssl": True,
        },
        "database": {
            "host": "db.example.com",
            "port": 5432,
            "name": "production",
        },
        "features": ["auth", "mcp", "redis"],
    }
    yaml_output = YamlOutput(data=nested_data)
    formatter.render(yaml_output)

    # Demo 10: Custom table with specific columns
    print("\n10. Custom table with specific formatting:")
    print("-" * 80)
    columns = [
        TableColumn(header="Surface", key="name", justify="left"),
        TableColumn(header="Owner", key="owner", justify="center"),
        TableColumn(header="Tools", key="tool_count", justify="right"),
    ]
    rows = [
        TableRow(
            data={
                "name": s.name,
                "owner": s.owner,
                "tool_count": str(len(s.tools)),
            }
        )
        for s in surfaces
    ]
    table_output = TableOutput(
        columns=columns,
        rows=rows,
        title="Context Surfaces Summary",
        show_header=True,
        show_lines=True,
    )
    formatter.render(table_output)

    print("\n" + "=" * 80)
    print("Demo complete!")
    print("=" * 80)


if __name__ == "__main__":
    main()
