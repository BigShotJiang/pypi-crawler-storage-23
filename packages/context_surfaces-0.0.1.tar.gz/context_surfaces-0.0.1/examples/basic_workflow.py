"""Complete workflow example: Admin key → Context surface → Agent key → MCP tools."""

import asyncio
import sys
from pathlib import Path

# Add parent directory to path for local development
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from context_surfaces import (
    ContextSurfacesClient,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
)
from context_surfaces.mcp_client import MCPClient

console = Console()


async def main() -> None:
    """Run the complete workflow."""
    console.print(
        Panel.fit(
            "[bold cyan]Context Surfaces - Complete Workflow Example[/bold cyan]",
            border_style="cyan",
        )
    )

    # Configuration
    api_url = "http://localhost:8080"
    mcp_url = "http://localhost:8081"

    async with ContextSurfacesClient(api_url) as client:
        # Step 1: Create Admin API Key
        console.print("\n[bold]Step 1:[/bold] Creating admin API key...")
        admin_key = await client.create_admin_key(
            CreateAdminKeyRequest(
                name="Example Admin Key",
                owner="example-user",
                description="Admin key for workflow example",
                metadata={"example": "true", "environment": "development"},
            )
        )
        console.print(f"✓ Admin Key Created: [green]{admin_key.id}[/green]")
        console.print(f"  Key: [dim]{admin_key.key[:20]}...[/dim]")

        # Step 2: Create Context Surface
        # Note: Tools are auto-generated from the data_model (not shown in this example)
        console.print("\n[bold]Step 2:[/bold] Creating context surface...")
        surface = await client.create_context_surface(
            admin_key.key,
            CreateContextSurfaceRequest(
                name="Customer Support Tools",
                description="Tools for customer support agents to manage tickets",
                metadata={
                    "department": "support",
                    "version": "1.0",
                    "team": "customer-success",
                },
            ),
        )
        console.print(f"✓ Context Surface Created: [green]{surface.id}[/green]")
        console.print(f"  Name: {surface.name}")
        console.print(f"  Tools: {len(surface.tools) if surface.tools else 0}")

        # Step 3: List Context Surfaces
        console.print("\n[bold]Step 3:[/bold] Listing all context surfaces...")
        surfaces_response = await client.list_context_surfaces(admin_key.key, page=1, page_size=10)

        table = Table(title="Context Surfaces")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Tools", justify="right", style="yellow")
        table.add_column("Owner", style="magenta")

        for eng in surfaces_response.context_surfaces:
            table.add_row(eng.id, eng.name, str(len(eng.tools)), eng.owner)

        console.print(table)
        console.print(
            f"Total: {surfaces_response.pagination.total_count} "
            f"(Page {surfaces_response.pagination.page}/{surfaces_response.pagination.total_pages})"
        )

        # Step 4: Create Agent API Key
        console.print("\n[bold]Step 4:[/bold] Creating agent API key...")
        agent_key = await client.create_agent_key(
            admin_key.key,
            surface.id,
            CreateAgentKeyRequest(
                name="Support Agent #1",
                description="Agent key for primary support AI assistant",
                metadata={"agent_id": "agent-001", "purpose": "customer_support"},
            ),
        )
        console.print(f"✓ Agent Key Created: [green]{agent_key.id}[/green]")
        console.print(f"  Key: [dim]{agent_key.key[:20]}...[/dim]")
        console.print(f"  Context Surface: {agent_key.context_surface_id}")

        # Step 5: List Agent Keys
        console.print("\n[bold]Step 5:[/bold] Listing agent keys...")
        agent_keys_response = await client.list_agent_keys(admin_key.key, surface.id)
        console.print(f"✓ Found {len(agent_keys_response.agent_keys)} agent key(s)")

        # Step 6: MCP Tool Invocation
        console.print("\n[bold]Step 6:[/bold] Invoking tools via MCP...")
        async with MCPClient(mcp_url=mcp_url, agent_key=agent_key.key) as mcp:
            # Initialize MCP session
            init_result = await mcp.initialize()
            console.print("✓ MCP Session Initialized")
            console.print(f"  Server: {init_result.get('serverInfo', {}).get('name', 'Unknown')}")

            # List available tools
            tools = await mcp.list_tools()
            console.print(f"✓ Available Tools: {len(tools)}")

            tools_table = Table(title="MCP Tools")
            tools_table.add_column("Name", style="cyan")
            tools_table.add_column("Description", style="white")

            for tool in tools[:5]:  # Show first 5 tools
                tools_table.add_row(
                    tool.get("name", "Unknown"), tool.get("description", "No description")[:50]
                )

            console.print(tools_table)

            # Call a tool (example)
            if tools:
                tool_name = tools[0].get("name")
                console.print(f"\n[bold]Calling tool:[/bold] {tool_name}")
                try:
                    result = await mcp.call_tool(tool_name, {})
                    console.print(f"✓ Tool Result: [green]{result}[/green]")
                except Exception as e:
                    console.print(f"[yellow]Note: Tool call failed (expected): {e}[/yellow]")

        # Step 7: Cleanup (optional)
        console.print("\n[bold]Step 7:[/bold] Cleanup (optional)...")
        console.print("[dim]Skipping cleanup to preserve resources for inspection[/dim]")
        console.print(
            f"[dim]To delete: await client.delete_context_surface('{surface.id}', admin_key.key)[/dim]"
        )

    console.print("\n[bold green]✓ Workflow Complete![/bold green]")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        raise
