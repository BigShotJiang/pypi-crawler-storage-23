"""Examples for Context Surfaces Python client."""
