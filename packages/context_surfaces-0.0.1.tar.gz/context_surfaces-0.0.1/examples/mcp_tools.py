"""Example demonstrating MCP tool invocation."""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from rich.console import Console
from rich.json import JSON
from rich.panel import Panel

from context_surfaces import (
    ContextSurfacesClient,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
)
from context_surfaces.mcp_client import MCPClient

console = Console()


async def setup_surface() -> tuple[str, str]:
    """Set up a context surface and return admin key and agent key.

    Returns:
        Tuple of (admin_key, agent_key)
    """
    console.print("[bold]Setting up context surface...[/bold]")

    async with ContextSurfacesClient("http://localhost:8080") as client:
        # Create admin key
        admin_key = await client.create_admin_key(
            CreateAdminKeyRequest(
                name="MCP Example Admin",
                owner="example-user",
            )
        )
        console.print(f"✓ Admin key created: {admin_key.id}")

        # Create context surface
        # Note: Tools are auto-generated from the data_model (not shown in this example)
        surface = await client.create_context_surface(
            admin_key.key,
            CreateContextSurfaceRequest(
                name="Example Tools",
                description="Example tools for demonstration",
            ),
        )
        console.print(f"✓ Context surface created: {surface.id}")

        # Create agent key
        agent_key = await client.create_agent_key(
            admin_key.key,
            surface.id,
            CreateAgentKeyRequest(
                name="MCP Example Agent",
            ),
        )
        console.print(f"✓ Agent key created: {agent_key.id}\n")

        return admin_key.key, agent_key.key


async def demonstrate_mcp_tools(agent_key: str) -> None:
    """Demonstrate MCP tool invocation.

    Args:
        agent_key: Agent API key for authentication
    """
    console.print(
        Panel.fit(
            "[bold cyan]MCP Tool Invocation Example[/bold cyan]",
            border_style="cyan",
        )
    )

    async with MCPClient(
        mcp_url="http://localhost:8081",
        agent_key=agent_key,
    ) as mcp:
        # Step 1: Initialize MCP session
        console.print("\n[bold]Step 1:[/bold] Initialize MCP session")
        init_result = await mcp.initialize()
        console.print(JSON.from_data(init_result, indent=2))

        # Step 2: List available tools
        console.print("\n[bold]Step 2:[/bold] List available tools")
        tools = await mcp.list_tools()
        console.print(f"Found {len(tools)} tools:")
        for i, tool in enumerate(tools, 1):
            console.print(f"  {i}. [cyan]{tool.get('name', 'Unknown')}[/cyan]")
            if desc := tool.get("description"):
                console.print(f"     [dim]{desc}[/dim]")

        # Step 3: Call a tool (calculator example)
        if tools:
            console.print("\n[bold]Step 3:[/bold] Call a tool")
            tool_name = tools[0].get("name", "calculator")

            console.print(f"Calling tool: [cyan]{tool_name}[/cyan]")
            try:
                # Example: calculator tool
                result = await mcp.call_tool(
                    tool_name,
                    {
                        "operation": "add",
                        "a": 10,
                        "b": 32,
                    },
                )
                console.print("[green]✓ Tool result:[/green]")
                console.print(JSON.from_data(result, indent=2))
            except Exception as e:
                console.print(f"[yellow]Note: {e}[/yellow]")
                console.print("[dim]This is expected if the tool doesn't exist on the server[/dim]")

        # Step 4: Call multiple tools
        console.print("\n[bold]Step 4:[/bold] Call multiple tools")
        tool_calls = [
            ("calculator", {"operation": "multiply", "a": 5, "b": 7}),
            ("weather", {"location": "San Francisco"}),
            ("search", {"query": "Python async programming"}),
        ]

        for tool_name, args in tool_calls:
            console.print(f"\nCalling: [cyan]{tool_name}[/cyan]")
            try:
                result = await mcp.call_tool(tool_name, args)
                console.print("[green]✓ Success[/green]")
                console.print(JSON.from_data(result, indent=2))
            except Exception as e:
                console.print(f"[yellow]Failed: {e}[/yellow]")

        # Step 5: Error handling
        console.print("\n[bold]Step 5:[/bold] Error handling")
        try:
            # Try to call non-existent tool
            await mcp.call_tool("non_existent_tool", {})
        except Exception as e:
            console.print(f"[green]✓ Caught expected error:[/green] {e}")


async def main() -> None:
    """Run the MCP tools example."""
    try:
        # Setup
        admin_key, agent_key = await setup_surface()

        # Demonstrate MCP tools
        await demonstrate_mcp_tools(agent_key)

        console.print("\n[bold green]✓ MCP tools example complete![/bold green]")

    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        raise


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"\n[bold red]Fatal error:[/bold red] {e}")
        import traceback

        traceback.print_exc()
