"""Complete RQE (Redis Query Engine) workflow example.

This example demonstrates the full RQE workflow:
1. Create admin API key
2. Register a Redis instance
3. Create a context surface with a DataModel (auto-generates RQE tools)
4. Insert sample data into Redis
5. Create agent API key
6. Query data using auto-generated MCP tools

Prerequisites:
- Context Surfaces server running on http://localhost:8080
- MCP server running on http://localhost:8081
- Redis server running on localhost:6379 with RedisJSON and RediSearch modules

Quick Start with Docker:
    docker-compose --profile simple up --build

Environment Variables:
- REDIS_CLIENT_ADDR: Redis address for client connection (default: localhost:6379)
- REDIS_SERVER_ADDR: Redis address for server connection
  - For 'simple' profile: redis-simple:6379 (default)
  - For 'dev' profile: redis-data:6379
"""

import asyncio
import json
import os
import sys
from pathlib import Path

# Add parent directory to path for local development
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import redis.asyncio as redis
from rich.console import Console
from rich.json import JSON
from rich.panel import Panel
from rich.table import Table

from context_surfaces import (
    ContextSurfacesClient,
    CreateAdminKeyRequest,
    CreateAgentKeyRequest,
    CreateContextSurfaceRequest,
    RedisConnectionConfig,
    RegisterRedisInstanceRequest,
)
from context_surfaces.context_model import export_data_model
from context_surfaces.examples.reddish_models import Customer, Order
from context_surfaces.mcp_client import MCPClient

console = Console()


async def main() -> None:
    """Run the complete RQE workflow."""
    console.print(
        Panel.fit(
            "[bold cyan]RQE (Redis Query Engine) Workflow Example[/bold cyan]\n"
            "[dim]Auto-generate search tools from your data model[/dim]",
            border_style="cyan",
        )
    )

    # Configuration
    api_url = "http://localhost:8080"
    mcp_url = "http://localhost:8081"

    # Redis addresses:
    # - redis_client_addr: Used by this script to connect to Redis (from host machine)
    # - redis_server_addr: Used by the server to connect to Redis (from Docker container)
    #   For 'simple' profile: use 'redis-simple:6379'
    #   For 'dev' profile: use 'redis-data:6379'
    redis_client_addr = os.getenv("REDIS_CLIENT_ADDR", "localhost:6379")
    redis_server_addr = os.getenv("REDIS_SERVER_ADDR", "redis-simple:6379")
    redis_url = f"redis://{redis_client_addr}"

    admin_key = None
    redis_instance_id = None
    surface_id = None
    redis_client = None

    try:
        # Connect to Redis for data insertion
        redis_client = redis.from_url(redis_url, decode_responses=True)

        async with ContextSurfacesClient(api_url) as client:
            # Step 1: Create admin API key
            console.print("\n[bold]Step 1:[/bold] Creating admin API key...")
            admin_key_obj = await client.create_admin_key(
                CreateAdminKeyRequest(
                    name="RQE Example Admin",
                    owner="rqe-example-user",
                    description="Admin key for RQE workflow example",
                )
            )
            admin_key = admin_key_obj.key
            console.print(f"✓ Admin Key: [green]{admin_key_obj.id}[/green]")

            # Step 2: Register Redis instance
            console.print("\n[bold]Step 2:[/bold] Registering Redis instance...")
            console.print(f"[dim]Server will connect to: {redis_server_addr}[/dim]")
            redis_instance = await client.register_redis_instance(
                admin_key,
                RegisterRedisInstanceRequest(
                    name="RQE Example Redis",
                    description="Redis instance for RQE example",
                    connection_config=RedisConnectionConfig(
                        addr=redis_server_addr,  # Server connects from Docker network
                        password="",
                        db=0,
                        tls_enabled=False,
                        pool_size=10,
                        min_idle_conns=2,
                    ),
                    metadata={"example": "rqe_workflow"},
                ),
            )
            redis_instance_id = redis_instance.id
            console.print(f"✓ Redis Instance: [green]{redis_instance_id}[/green]")

            # Step 3: Create context surface with DataModel
            console.print("\n[bold]Step 3:[/bold] Creating context surface with DataModel...")
            console.print("[dim]Using Reddish Customer and Order models[/dim]")

            # Generate DataModel from ContextModel classes
            data_model = export_data_model(
                title="Reddish Support API",
                description="Customer support system with auto-generated search tools",
                entities=[Customer, Order],
            )

            surface = await client.create_context_surface(
                admin_key,
                CreateContextSurfaceRequest(
                    name="RQE Example Surface",
                    description="Context surface with auto-generated RQE tools",
                    data_model=data_model,
                    redis_instance_id=redis_instance_id,
                ),
            )
            surface_id = surface.id
            console.print(f"✓ Surface: [green]{surface_id}[/green]")

            # Display generated tools
            table = Table(title="Auto-Generated RQE Tools", show_header=True)
            table.add_column("Tool Name", style="cyan")
            table.add_column("Type", style="yellow")
            for tool in surface.tools:
                tool_type = (
                    "Search"
                    if "search" in tool
                    else "Filter"
                    if "filter" in tool
                    else "Find"
                    if "find" in tool
                    else "Get"
                )
                table.add_row(tool, tool_type)
            console.print(table)

        # Step 4: Insert sample data
        console.print("\n[bold]Step 4:[/bold] Inserting sample data into Redis...")

        # Wait for indices to be created
        await asyncio.sleep(1)

        # Insert customers
        customers = [
            {
                "id": 1,
                "email": "alice@example.com",
                "phone": "+1-555-0101",
                "account_status": "active",
                "customer_tier": "dashpass",
                "city": "San Francisco",
                "lifetime_value": 1250.50,
            },
            {
                "id": 2,
                "email": "bob@example.com",
                "phone": "+1-555-0102",
                "account_status": "active",
                "customer_tier": "premium",
                "city": "New York",
                "lifetime_value": 850.25,
            },
            {
                "id": 3,
                "email": "charlie@example.com",
                "phone": "+1-555-0103",
                "account_status": "suspended",
                "customer_tier": "regular",
                "city": "Los Angeles",
                "lifetime_value": 320.00,
            },
        ]

        for customer in customers:
            key = f"customer:{customer['id']}"
            await redis_client.execute_command("JSON.SET", key, "$", json.dumps(customer))
        console.print(f"✓ Inserted {len(customers)} customers")

        # Insert orders
        orders = [
            {
                "id": 101,
                "customer_id": 1,
                "restaurant_id": 201,
                "order_total": 45.99,
                "status": "delivered",
                "special_instructions": "Leave at door",
            },
            {
                "id": 102,
                "customer_id": 1,
                "restaurant_id": 202,
                "order_total": 125.50,
                "status": "in_transit",
                "special_instructions": "Ring doorbell",
            },
            {
                "id": 103,
                "customer_id": 2,
                "restaurant_id": 201,
                "order_total": 32.00,
                "status": "delivered",
                "special_instructions": "",
            },
            {
                "id": 104,
                "customer_id": 3,
                "restaurant_id": 203,
                "order_total": 89.99,
                "status": "cancelled",
                "special_instructions": "Call on arrival",
            },
        ]

        for order in orders:
            key = f"order:{order['id']}"
            await redis_client.execute_command("JSON.SET", key, "$", json.dumps(order))
        console.print(f"✓ Inserted {len(orders)} orders")

        # Wait for indices to update
        await asyncio.sleep(1)

        # Step 5: Create agent API key
        console.print("\n[bold]Step 5:[/bold] Creating agent API key...")
        async with ContextSurfacesClient(api_url) as client:
            agent_key_obj = await client.create_agent_key(
                admin_key,
                surface_id,
                CreateAgentKeyRequest(
                    name="RQE Example Agent",
                    description="Agent key for querying RQE tools",
                ),
            )
            agent_key = agent_key_obj.key
            console.print(f"✓ Agent Key: [green]{agent_key_obj.id}[/green]")

        # Step 6: Query data using MCP tools
        console.print("\n[bold]Step 6:[/bold] Querying data using auto-generated MCP tools...")

        async with MCPClient(mcp_url=mcp_url, agent_key=agent_key) as mcp:
            # Query 1: Search customers by text
            console.print("\n[cyan]Query 1:[/cyan] Search customers by text (query='alice')")
            result = await mcp.call_tool("search_customer_by_text", {"query": "alice", "limit": 10})
            console.print(JSON(json.dumps(result, indent=2)))

            # Query 2: Filter customers by account status
            console.print("\n[cyan]Query 2:[/cyan] Filter customers by account_status='active'")
            result = await mcp.call_tool(
                "filter_customer_by_account_status", {"value": "active", "limit": 10}
            )
            console.print(JSON(json.dumps(result, indent=2)))

            # Query 3: Find orders by price range
            console.print("\n[cyan]Query 3:[/cyan] Find orders with total between $30 and $100")
            result = await mcp.call_tool(
                "find_order_by_order_total_range",
                {"min_value": 30.0, "max_value": 100.0, "limit": 10},
            )
            console.print(JSON(json.dumps(result, indent=2)))

            # Query 4: Get customer by ID
            console.print("\n[cyan]Query 4:[/cyan] Get customer by ID=1")
            result = await mcp.call_tool("get_customer_by_id", {"id": "1"})
            console.print(JSON(json.dumps(result, indent=2)))

        console.print("\n[bold green]✓ RQE workflow completed successfully![/bold green]")

    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        raise

    finally:
        # Cleanup
        console.print("\n[bold]Cleanup:[/bold] Removing test data and resources...")

        if redis_client:
            # Drop indices
            try:
                await redis_client.execute_command("FT.DROPINDEX", "idx:customer")
                await redis_client.execute_command("FT.DROPINDEX", "idx:order")
            except Exception:
                pass

            # Delete test data
            for i in [1, 2, 3]:
                await redis_client.delete(f"customer:{i}")
            for i in [101, 102, 103, 104]:
                await redis_client.delete(f"order:{i}")

            await redis_client.aclose()

        # Delete context surface and Redis instance
        if admin_key:
            try:
                async with ContextSurfacesClient(api_url) as client:
                    if surface_id:
                        await client.delete_context_surface(surface_id, admin_key)
                    if redis_instance_id:
                        await client.delete_redis_instance(redis_instance_id, admin_key)
            except Exception:
                pass

        console.print("✓ Cleanup complete")


if __name__ == "__main__":
    asyncio.run(main())
