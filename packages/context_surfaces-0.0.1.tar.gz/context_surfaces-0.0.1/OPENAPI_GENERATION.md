# OpenAPI Code Generation

## Overview

While the current Python client is hand-crafted for maximum quality and control, **using OpenAPI code generation is considered best practice** for ensuring the client stays in sync with the server API.

## Why OpenAPI Generation?

### ✅ Advantages

1. **Guaranteed API Compatibility**: Generated code matches the OpenAPI spec exactly
2. **Automatic Updates**: Regenerate when the API changes
3. **Type Safety**: Models are generated from the spec
4. **Less Manual Work**: No need to manually write request/response models
5. **Documentation**: Generated code includes docstrings from the spec

### ⚠️ Trade-offs

1. **Less Control**: Generated code may not match your preferred style
2. **Boilerplate**: Generated code can be verbose
3. **Customization**: Harder to add custom logic or helpers
4. **Dependencies**: Requires code generation tools

## Current Approach

The current client is **hand-crafted** with these benefits:

- ✅ Clean, Pythonic API design
- ✅ Custom error handling
- ✅ Retry logic with tenacity
- ✅ Rich logging
- ✅ Beautiful CLI with typer
- ✅ Comprehensive examples

## Recommended Hybrid Approach

For production use, we recommend a **hybrid approach**:

### 1. Generate Base Models from OpenAPI

Use `datamodel-code-generator` to generate Pydantic models:

```bash
# Install generator
pip install datamodel-code-generator

# Generate models from swagger.yaml
datamodel-codegen \
  --input ../docs/swagger.yaml \
  --output src/context_surfaces/generated_models.py \
  --output-model-type pydantic_v2.BaseModel \
  --use-standard-collections \
  --use-schema-description
```

### 2. Keep Hand-Crafted Client

Keep the current `ContextSurfacesClient` but use generated models:

```python
# Use generated models for validation
from context_surfaces.generated_models import (
    CreateAdminKeyRequest as GeneratedCreateAdminKeyRequest,
)

# Wrap in our own models for better API
class CreateAdminKeyRequest(GeneratedCreateAdminKeyRequest):
    """Enhanced request model with custom validation."""
    pass
```

### 3. Automated Validation

Add a CI check to ensure models match the spec:

```bash
# In CI pipeline
make generate-models
git diff --exit-code src/context_surfaces/generated_models.py
```

## Alternative: Full Code Generation

For a fully generated client, use `openapi-python-client`:

```bash
# Install
pip install openapi-python-client

# Generate full client
openapi-python-client generate \
  --path ../docs/swagger.yaml \
  --output-path generated-client \
  --overwrite
```

This generates:
- Complete client with all endpoints
- Pydantic models
- Type hints
- Async support

## Implementation Plan

### Phase 1: Add Model Generation (Recommended)

1. Add `datamodel-code-generator` to dev dependencies
2. Create `scripts/generate_models.py`
3. Generate models from `docs/swagger.yaml`
4. Compare with hand-crafted models
5. Add CI check for model drift

### Phase 2: Validation Layer

1. Use generated models for validation
2. Keep hand-crafted models for API surface
3. Add conversion layer if needed

### Phase 3: Full Generation (Optional)

1. Evaluate `openapi-python-client` output
2. Compare with hand-crafted client
3. Decide on migration path

## Current Status

- ✅ Hand-crafted client with full features
- ✅ Comprehensive test suite
- ✅ Production-ready
- 🔲 OpenAPI model generation (recommended next step)
- 🔲 Automated spec validation in CI

## Recommendation

**For this project**, we recommend:

1. **Keep the hand-crafted client** - It's high quality and production-ready
2. **Add OpenAPI model generation** - Use it for validation and drift detection
3. **Add CI checks** - Ensure models stay in sync with the spec
4. **Document the process** - Make it easy to regenerate when the API changes

This gives you the best of both worlds:
- High-quality, maintainable client code
- Guaranteed compatibility with the OpenAPI spec
- Automated validation in CI

## Example: Adding Model Generation

Create `scripts/generate_models.sh`:

```bash
#!/bin/bash
set -e

echo "Generating models from OpenAPI spec..."

datamodel-codegen \
  --input ../docs/swagger.yaml \
  --output src/context_surfaces/generated_models.py \
  --output-model-type pydantic_v2.BaseModel \
  --use-standard-collections \
  --use-schema-description \
  --use-annotated \
  --use-double-quotes \
  --target-python-version 3.11

echo "✓ Models generated successfully"
echo "Review changes with: git diff src/context_surfaces/generated_models.py"
```

Add to `Makefile`:

```makefile
generate-models:
	./scripts/generate_models.sh

check-models: generate-models
	git diff --exit-code src/context_surfaces/generated_models.py || \
		(echo "ERROR: Generated models differ from committed version" && exit 1)
```

Add to CI:

```yaml
- name: Check OpenAPI model sync
  run: |
    cd python-client
    make check-models
```

## Conclusion

While the current hand-crafted client is excellent, adding OpenAPI model generation as a **validation layer** is the best practice for ensuring long-term API compatibility.

The recommended approach:
1. ✅ Keep hand-crafted client (current)
2. ➕ Add OpenAPI model generation for validation
3. ➕ Add CI checks for drift detection
4. ➕ Document regeneration process

This ensures the client stays in sync with the Go server while maintaining code quality.
