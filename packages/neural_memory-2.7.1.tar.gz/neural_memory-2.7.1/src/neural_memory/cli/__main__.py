"""Allow running as python -m neural_memory.cli."""

from neural_memory.cli.main import main

if __name__ == "__main__":
    main()
