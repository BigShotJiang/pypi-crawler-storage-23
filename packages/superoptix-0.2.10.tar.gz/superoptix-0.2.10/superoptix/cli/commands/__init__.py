"""CLI subpackage for Soda."""

from .init import init_project

__all__ = ["init_project", "add_agent"]
