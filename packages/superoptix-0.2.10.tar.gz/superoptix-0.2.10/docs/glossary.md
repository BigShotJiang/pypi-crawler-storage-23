# Glossary

_A list of SuperOptiX terminology will be curated here._ 