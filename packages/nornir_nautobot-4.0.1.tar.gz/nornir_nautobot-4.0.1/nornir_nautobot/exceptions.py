"""Custom exception classes."""


class NornirNautobotException(Exception):
    """Bolierplate code to exception handling."""
