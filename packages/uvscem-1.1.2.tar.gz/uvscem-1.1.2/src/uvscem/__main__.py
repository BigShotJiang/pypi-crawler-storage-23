from uvscem.extension_manager import main

main()
