"""Tests for moss_voice_agent_manager public API completeness.

Each test verifies a previously missing re-export so that consumers never
need to import directly from livekit.* or livekit.plugins.*.
"""


def test_agent_server_is_exported():
    from moss_voice_agent_manager import AgentServer  # noqa: F401

    assert AgentServer is not None


def test_room_io_is_exported():
    from moss_voice_agent_manager import room_io

    assert hasattr(room_io, "RoomOptions")
    assert hasattr(room_io, "AudioInputOptions")


def test_multilingual_model_is_exported():
    from moss_voice_agent_manager import MultilingualModel  # noqa: F401

    assert MultilingualModel is not None


def test_agent_session_is_exported():
    from moss_voice_agent_manager import AgentSession  # noqa: F401

    assert AgentSession is not None


def test_inference_is_exported():
    from moss_voice_agent_manager import inference

    assert hasattr(inference, "LLM")


def test_job_process_is_exported():
    """JobProcess was already present; guard against regression."""
    from moss_voice_agent_manager import JobProcess  # noqa: F401

    assert JobProcess is not None


def test_moss_config_has_voice_agent_name():
    from moss_voice_agent_manager import MossConfig

    assert "voice_agent_name" in MossConfig.model_fields
