# Changelog

All notable changes to moss-voice-agent-manager will be documented in this file.


## [1.0.0-beta.9] - 2026-03-03

### Added
- `AgentServer` re-exported from `moss_voice_agent_manager`
- `AgentSession` re-exported from `moss_voice_agent_manager`
- `inference` module re-exported from `moss_voice_agent_manager`
- `room_io` module re-exported from `moss_voice_agent_manager` (includes `RoomOptions`, `AudioInputOptions`)
- `MultilingualModel` re-exported from `moss_voice_agent_manager` (turn detection)
- `livekit-plugins-turn-detector==1.3.11` added as a dependency
- `voice_agent_name` field added to `MossConfig` — populated from the platform credentials API, eliminating the need for a separate `httpx` call in agent code

---

## [1.0.0-beta.8] - 2026-02-27

### Fixed
- `MossAgentSession.prewarm()` no longer crashes with "no running event loop".
---

## [1.0.0-beta.7] - 2026-02-27

### Added
- `MossAgentSession.prewarm()` static method for use as `prewarm_fnc` in `WorkerOptions` — initializes providers once at worker startup instead of per session
- `ctx` parameter on `MossAgentSession.__init__()` — when provided, reuses prewarmed providers from the worker process instead of creating new ones
- `JobProcess` re-exported from `moss_voice_agent_manager`

### Improved
- Reduced agent session startup latency by supporting the LiveKit prewarm pattern

### Usage
```python
from moss_voice_agent_manager import MossAgentSession, WorkerOptions, cli

async def entrypoint(ctx):
    session = MossAgentSession(userdata=data, ctx=ctx)
    ...

cli.run_app(WorkerOptions(
    entrypoint_fnc=entrypoint,
    prewarm_fnc=MossAgentSession.prewarm,
))
```

---

## [1.0.0-beta.4] - 2026-02-19

### Changed (Complete Rewrite)
Complete architectural rewrite. The SDK is now a runtime agent library instead of a deployment client.

**Old SDK:** Deployment client that uploads code to backend
**New SDK:** Drop-in replacement for LiveKit AgentSession with Moss platform integration

### Added
- `MossAgentSession` - Drop-in replacement for LiveKit AgentSession
- Dynamic configuration fetching from Moss platform API
- Runtime config API endpoint (`/api/voice-agent/get-runtime-config`)
- Voice agent credentials API endpoint (`/api/voice-agent/get-voice-agent`)
- Automatic provider configuration (STT, LLM, TTS)
- Built-in metrics tracking (LLM, TTS, STT, VAD, EOU)
- Diagnostics reporting with performance metrics
- Model/provider name masking for proprietary information
- Auto-initialization of VAD (Voice Activity Detection)
- `py.typed` marker for IDE IntelliSense support

### Configuration
All configuration now comes from environment variables and platform API:

**Required Environment Variables:**
- `MOSS_PROJECT_ID` - Project identifier
- `MOSS_PROJECT_KEY` - Project authentication key
- `MOSS_VOICE_AGENT_ID` - Voice agent identifier

**Optional:**
- `MOSS_PLATFORM_API_URL` - Platform API URL (defaults to production)

### Architecture
- **No fallbacks** - Fails hard if configuration/credentials missing
- **Dynamic models** - Model selection fetched from backend at runtime
- **Secure credentials** - LiveKit credentials fetched from Supabase via API
- **No hardcoded secrets** - All secrets from environment or API

### Removed
- `MossVoiceClient` class (replaced with `MossAgentSession`)
- `deploy()` method (now runtime library, not deployment tool)
- Custom tool source extraction
- Static configuration files

### Migration Guide

**This version is NOT backward compatible.** Complete migration required.

**Before (v1.x - Deployment SDK):**
```python
from moss_voice_agent_manager import MossVoiceClient

client = MossVoiceClient(project_id="...", project_key="...")
client.deploy(
    voice_agent_id="...",
    prompt="...",
    function_tools=[my_tool]
)
```

**After (v1.0.0-beta.4 - Runtime SDK):**
```python
from moss_voice_agent_manager import MossAgentSession

# Set environment variables first
session = MossAgentSession(
    userdata=your_data,
    vad=vad,  # optional
    max_tool_steps=10
)

# Access platform API
api = session.platform_api

# Get metrics
metrics = session.metrics
diagnostics = session.diagnostics
```

## [1.0.0-beta.3] - 2026-02-11

### Changed (Breaking)
- **Removed `agent_id` parameter** from `deploy()` method
- `voice_agent_id` is now used internally as the agent identifier
- **Reordered parameters**: `voice_agent_id` now comes before `prompt` in `deploy()`
- `project_name` parameter now defaults to `voice_agent_id` (previously defaulted to `agent_id`)

### Migration Guide
**Before:**
```python
client.deploy(
    agent_id="my-agent",
    prompt="You are helpful",
    voice_agent_id="agent-uuid"
)
```

**After:**
```python
client.deploy(
    voice_agent_id="agent-uuid",
    prompt="You are helpful"
)
```

## [1.0.0-beta.1] - 2026-02-11

Initial beta release.

### Added
- `MossVoiceClient` for deploying voice agents to LiveKit
- `deploy()` method with custom Python function tools support
- Automatic source code extraction for custom tools
- Project-based authentication (X-Project-Id, X-Project-Key)
- Zero external dependencies (uses Python standard library)

[1.0.0-beta.2]: https://github.com/InferEdge-Inc/moss/releases/tag/moss-voice-agent-manager-v1.0.0-beta.2
[1.0.0-beta.1]: https://github.com/InferEdge-Inc/moss/releases/tag/moss-voice-agent-manager-v1.0.0-beta.1
