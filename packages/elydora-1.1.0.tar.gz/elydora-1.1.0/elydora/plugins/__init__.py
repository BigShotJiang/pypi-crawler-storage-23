"""Elydora agent plugins for AI coding tools."""
