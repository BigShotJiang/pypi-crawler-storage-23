"""Test suite for nexus_mcp."""
