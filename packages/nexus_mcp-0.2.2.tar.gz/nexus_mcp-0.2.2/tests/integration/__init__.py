"""Integration tests — require real CLI binaries installed."""
