"""Nexus MCP - AI CLI Agent MCP Server."""

from importlib.metadata import version

__version__ = version("nexus-mcp")
