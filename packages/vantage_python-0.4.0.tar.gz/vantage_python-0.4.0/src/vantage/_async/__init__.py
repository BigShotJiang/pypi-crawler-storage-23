"""Asynchronous Vantage API client."""

from .client import AsyncClient

__all__ = ["AsyncClient"]
