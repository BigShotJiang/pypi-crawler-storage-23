"""Synchronous Vantage API client."""

from .client import SyncClient

__all__ = ["SyncClient"]
