"""Zip MCP Server - MCP server for Zip API integration."""

from src.app import mcp
from src.server import main

__version__ = "0.1.0"
__all__ = ["main", "mcp"]
