"""Zip MCP Server - Main server implementation."""

from src.app import mcp  # pyright: ignore[reportUnknownVariableType]

# Import tools to register them with the mcp instance
from src.tools import requests  # noqa: F401


def main() -> None:
    """Main entry point for the Zip MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
