import os

BASE_URL = os.environ.get("BASE_URL") or "https://api.ziphq.com"


def get_headers() -> dict[str, str]:
    api_key = os.environ.get("ZIP_API_KEY")
    if not api_key:
        raise ValueError("ZIP_API_KEY is not set")

    return {
        "Zip-Api-Key": api_key,
        "Content-Type": "application/json",
        "Source": "ziphq-mcp",
    }
