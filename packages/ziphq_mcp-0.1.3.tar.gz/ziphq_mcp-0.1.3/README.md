# Zip MCP Server

An MCP (Model Context Protocol) server for integrating with the Zip API, built with [FastMCP](https://github.com/jlowin/fastmcp).

## Installation

```bash
pip install ziphq-mcp
```

Or with uv:

```bash
uv pip install ziphq-mcp
```

## Usage

### With MCP client

Add to your MCP configuration (e.g., `~/.claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "zip": {
      "command": "uv",
      "args": ["run", "--with", "ziphq-mcp", "ziphq-mcp"],
      "env": {
        "ZIP_API_KEY": "your-api-key-here"
      }
    }
  }
}
