from imbue import imbue_common


def test_import():
    assert imbue_common
