// ─── Setup-environment banner ───────────────────────────────────────────────
const setupBanner     = document.getElementById('setupBanner');
const setupLogEl      = document.getElementById('setupLog');
const setupStatusText = document.getElementById('setupStatusText');
const setupToggleBtn  = document.getElementById('setupToggle');
const setupToggleIcon = document.getElementById('setupToggleIcon');
let setupLogOpen = false;

function appendSetupLog(msg) {
  const line = document.createElement('div');
  line.textContent = msg;
  setupLogEl.appendChild(line);
  if (setupLogOpen) setupLogEl.scrollTop = setupLogEl.scrollHeight;
}

setupToggleBtn.addEventListener('click', () => {
  setupLogOpen = !setupLogOpen;
  setupLogEl.classList.toggle('open', setupLogOpen);
  setupToggleIcon.className = setupLogOpen ? 'fas fa-chevron-up' : 'fas fa-chevron-down';
  if (setupLogOpen) setupLogEl.scrollTop = setupLogEl.scrollHeight;
});

// Check current setup status on page load
(async () => {
  try {
    const res = await fetch('/api/setup-status');
    const data = await res.json();
    if (data.status === 'ready') return;  // already done, stay hidden
    if (data.status === 'error') {
      setupBanner.style.display = '';
      setupStatusText.textContent = data.message || 'Setup error';
      return;
    }
    // pending — show banner and replay existing log
    setupBanner.style.display = '';
    (data.log || []).forEach(appendSetupLog);
  } catch (_) { /* server might still be starting */ }
})();

// Listen for live setup progress events
{
  const setupSocket = io();
  setupSocket.on('setup:progress', ({ message }) => {
    setupBanner.style.display = '';
    const last = message.trim();
    setupStatusText.textContent = last.replace(/^[\u{1F000}-\u{1FFFF}\u2600-\u2BFF\s]+/u, '').trim() || last;
    appendSetupLog(message);

    if (message.includes('\u2705') && message.toLowerCase().includes('ready')) {
      setupBanner.classList.add('setup-done');
      setupBanner.querySelector('.setup-spinner').style.display = 'none';
      setupStatusText.textContent = 'Build environment ready — APKs can be compiled directly.';
      // Auto-hide after 6 s
      setTimeout(() => { setupBanner.style.display = 'none'; }, 6000);
      setupSocket.disconnect();
    }
  });
}

// ─── Theme ───────────────────────────────────────────────────────────────────
const themeToggle = document.getElementById('themeToggle');
const themeIcon   = document.getElementById('themeIcon');

function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  themeIcon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
}

setTheme(localStorage.getItem('theme') || 'dark');
themeToggle.addEventListener('click', () => {
  setTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
});

// ─── Source Tab Switching ─────────────────────────────────────────────────────
const sourceBtns = document.querySelectorAll('.source-btn');
const urlTab = document.getElementById('urlTab');
const zipTab = document.getElementById('zipTab');
let activeTab = 'url';

sourceBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    sourceBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeTab = btn.dataset.tab;
    urlTab.style.display = activeTab === 'url' ? '' : 'none';
    zipTab.style.display = activeTab === 'zip' ? '' : 'none';
  });
});

// ─── Color Picker Sync ────────────────────────────────────────────────────────
const colorPicker = document.getElementById('statusBarColor');
const colorHex    = document.getElementById('statusBarColorHex');

colorPicker.addEventListener('input', () => {
  colorHex.value = colorPicker.value;
});
colorHex.addEventListener('input', () => {
  if (/^#[0-9A-Fa-f]{6}$/.test(colorHex.value)) {
    colorPicker.value = colorHex.value;
  }
});

// ─── ZIP Drop Zone ────────────────────────────────────────────────────────────
const dropZone  = document.getElementById('dropZone');
const zipInput  = document.getElementById('zipFile');
const fileInfo  = document.getElementById('fileInfo');
const fileName  = document.getElementById('fileName');
const fileSize  = document.getElementById('fileSize');
const removeFile = document.getElementById('removeFile');

let selectedFile = null;

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

function showFileInfo(file) {
  selectedFile = file;
  fileName.textContent = file.name;
  fileSize.textContent = `(${formatBytes(file.size)})`;
  fileInfo.classList.remove('d-none');
}

function clearFile() {
  selectedFile = null;
  zipInput.value = '';
  fileInfo.classList.add('d-none');
}

zipInput.addEventListener('change', () => {
  if (zipInput.files[0]) showFileInfo(zipInput.files[0]);
});

dropZone.addEventListener('click', () => zipInput.click());

dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));

dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  const file = e.dataTransfer.files[0];
  if (file && file.name.endsWith('.zip')) {
    showFileInfo(file);
  } else {
    showToast('Please drop a .zip file', 'error');
  }
});

removeFile.addEventListener('click', (e) => {
  e.stopPropagation();
  clearFile();
});

// ─── Form Submission ──────────────────────────────────────────────────────────
const buildForm        = document.getElementById('buildForm');
const buildBtn         = document.getElementById('buildBtn');
const progressCard     = document.getElementById('progressCard');
const progressTitle    = document.getElementById('progressTitle');
const progressPercent  = document.getElementById('progressPercent');
const progressBar      = document.getElementById('progressBar');
const buildLog         = document.getElementById('buildLog');
const buildSpinner     = document.getElementById('buildSpinner');
const resultCard       = document.getElementById('resultCard');
const resultTitle      = document.getElementById('resultTitle');
const resultMessage    = document.getElementById('resultMessage');
const resultIcon       = document.getElementById('resultIcon');
const downloadApkBtn   = document.getElementById('downloadApkBtn');
const downloadProjBtn  = document.getElementById('downloadProjectBtn');
const buildAnotherBtn  = document.getElementById('buildAnotherBtn');

let currentBuildId = null;

function setBuilding(state) {
  buildBtn.disabled = state;
  buildBtn.querySelector('.btn-text').classList.toggle('d-none', state);
  buildBtn.querySelector('.btn-loading').classList.toggle('d-none', !state);
}

function appendLog(message) {
  const line = document.createElement('div');
  line.className = 'log-line';
  if (message.includes('✅') || message.includes('success')) line.classList.add('success');
  else if (message.includes('❌') || message.includes('Error') || message.includes('error')) line.classList.add('error');
  else if (message.includes('⚠') || message.includes('warn')) line.classList.add('warn');

  const time = new Date().toLocaleTimeString('en', { hour12: false });
  line.textContent = `[${time}] ${message}`;
  buildLog.appendChild(line);
  buildLog.scrollTop = buildLog.scrollHeight;
}

function setProgress(pct) {
  progressBar.style.width = pct + '%';
  progressPercent.textContent = pct + '%';
}

buildForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  // Validate
  if (activeTab === 'url') {
    const url = document.getElementById('websiteUrl').value.trim();
    if (!url || !url.startsWith('http')) {
      return showToast('Please enter a valid http/https URL', 'error');
    }
  } else {
    if (!selectedFile) return showToast('Please select a ZIP file', 'error');
  }

  // Reset UI
  buildLog.innerHTML = '';
  setProgress(0);
  progressCard.classList.remove('d-none');
  resultCard.classList.add('d-none');
  progressTitle.textContent = 'Building APK…';
  buildSpinner.style.display = '';
  setBuilding(true);
  progressCard.scrollIntoView({ behavior: 'smooth', block: 'start' });

  try {
    let buildId;
    if (activeTab === 'url') {
      buildId = await buildFromUrl();
    } else {
      buildId = await buildFromZip();
    }
    currentBuildId = buildId;
    listenToBuild(buildId);
  } catch (err) {
    showBuildError(err.message || 'Request failed');
  }
});

async function buildFromUrl() {
  const offline = document.querySelector('input[name="urlMode"]:checked').value === 'offline';
  const payload = {
    url: document.getElementById('websiteUrl').value.trim(),
    offline,
    ...collectConfig()
  };
  const resp = await fetch('/api/build-from-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error || `Server error ${resp.status}`);
  }
  const { buildId } = await resp.json();
  return buildId;
}

async function buildFromZip() {
  const fd = new FormData();
  fd.append('zipFile', selectedFile);
  const iconFile = document.getElementById('appIcon').files[0];
  if (iconFile) fd.append('appIcon', iconFile);
  Object.entries(collectConfig()).forEach(([k, v]) => fd.append(k, v));

  const resp = await fetch('/api/build-from-zip', { method: 'POST', body: fd });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error || `Server error ${resp.status}`);
  }
  const { buildId } = await resp.json();
  return buildId;
}

function collectConfig() {
  return {
    appName: document.getElementById('appName').value || 'My App',
    packageName: document.getElementById('packageName').value || 'com.example.myapp',
    versionName: document.getElementById('versionName').value || '1.0.0',
    versionCode: document.getElementById('versionCode').value || '1',
    minSdk: document.getElementById('minSdk').value,
    orientation: document.getElementById('orientation').value,
    enableZoom: document.getElementById('enableZoom').checked,
    fullscreen: document.getElementById('fullscreen').checked,
    allowExternalLinks: document.getElementById('allowExternalLinks').checked,
    statusBarColor: document.getElementById('statusBarColorHex').value || '#000000',
  };
}

// ─── Socket.io Listener ───────────────────────────────────────────────────────
function listenToBuild(buildId) {
  const socket = io();

  socket.on(`build:${buildId}`, (data) => {
    appendLog(data.message);
    if (data.progress != null) setProgress(data.progress);
  });

  socket.on(`build:${buildId}:complete`, (data) => {
    progressTitle.textContent = data.hasApk ? '✅ APK Built!' : '📦 Project Ready!';
    buildSpinner.style.display = 'none';
    setBuilding(false);
    socket.disconnect();
    showResult(data);
  });

  socket.on(`build:${buildId}:error`, (data) => {
    buildSpinner.style.display = 'none';
    progressTitle.textContent = '❌ Build Failed';
    setBuilding(false);
    socket.disconnect();
    showBuildError(data.error);
  });
}

function showResult(data) {
  resultCard.classList.remove('d-none');
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });

  if (data.hasApk) {
    resultIcon.innerHTML = '<i class="fas fa-check-circle fa-4x text-success"></i>';
    resultTitle.textContent = '🎉 APK Built Successfully!';
    resultMessage.textContent = 'Your APK is ready to install on any Android device.';
    downloadApkBtn.href = data.apkUrl;
    downloadApkBtn.classList.remove('d-none');
  } else {
    resultIcon.innerHTML = '<i class="fas fa-box-archive fa-4x text-primary"></i>';
    resultTitle.textContent = 'Android Project Ready';
    resultMessage.textContent =
      'Android SDK was not found on the server. Download the project ZIP and open it in Android Studio to build the APK.';
    downloadApkBtn.classList.add('d-none');
  }

  downloadProjBtn.href = data.projectUrl;
  downloadProjBtn.classList.remove('d-none');
}

function showBuildError(msg) {
  resultCard.classList.remove('d-none');
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
  resultIcon.innerHTML = '<i class="fas fa-circle-xmark fa-4x text-danger"></i>';
  resultTitle.textContent = 'Build Failed';
  resultMessage.textContent = msg;
  downloadApkBtn.classList.add('d-none');
  downloadProjBtn.classList.add('d-none');
}

buildAnotherBtn.addEventListener('click', () => {
  resultCard.classList.add('d-none');
  progressCard.classList.add('d-none');
  setBuilding(false);
  clearFile();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ─── Toast ────────────────────────────────────────────────────────────────────
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  const color = type === 'error' ? '#ef4444' : type === 'success' ? '#22c55e' : '#6e56cf';
  toast.style.cssText = `
    position:fixed; bottom:24px; right:24px; z-index:9999;
    background:${color}; color:white; padding:12px 20px; border-radius:10px;
    font-weight:600; font-size:0.9rem; max-width:320px;
    box-shadow:0 4px 20px rgba(0,0,0,0.3);
    animation: slideIn 0.25s ease;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

// ─── Package Name Auto-format ─────────────────────────────────────────────────
const appNameInput = document.getElementById('appName');
const pkgNameInput = document.getElementById('packageName');
let pkgEdited = false;

pkgNameInput.addEventListener('input', () => { pkgEdited = true; });

appNameInput.addEventListener('input', () => {
  if (!pkgEdited) {
    const slug = appNameInput.value.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'app';
    pkgNameInput.value = `com.example.${slug}`;
  }
});
