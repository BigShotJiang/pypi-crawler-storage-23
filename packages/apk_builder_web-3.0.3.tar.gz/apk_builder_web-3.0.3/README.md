# APK Builder – Web to Android APK Converter

Convert any **website URL** or **ZIP file** containing HTML/CSS/JS into an installable Android APK — with a single `pip install`.

---

## Features

| Feature | Description |
|---|---|
| 🌐 URL → APK | Wrap any live website in a native Android WebView |
| 📦 ZIP → APK | Package your local web app ZIP (must contain `index.html`) |
| ⬇️ Offline mode | Download & bundle a website for offline use |
| ⚙️ Custom config | App name, package ID, version, orientation, status-bar color |
| 🎨 Custom icon | Upload a PNG icon (512×512 recommended) |
| 📲 Dual output | Direct APK download *or* Android Studio project ZIP |
| 🔴 Real-time log | Live build output streamed to the browser |
| 🔧 Auto-setup | JDK 17 & Android SDK downloaded automatically on first run |

---

## Quick Start

### Prerequisites

| Requirement | Notes |
|---|---|
| **Python ≥ 3.9** | [python.org](https://python.org) |
| **Java JDK 17+** | Auto-downloaded if not found |
| **Android SDK** | Auto-downloaded if not found |

> **Java and Android SDK are installed automatically** into `~/.apk-builder/` on first run. You don’t need to install anything manually.

---

### Install & Run

```bash
pip install apk-builder-web
apk-builder
```

The browser opens automatically at **http://localhost:3000**.

**Custom port:**
```bash
apk-builder --port 8080
```

**Don’t open browser automatically:**
```bash
apk-builder --no-open
```

---

### Build an APK

1. Open **http://localhost:3000**
2. Choose **Web URL** or **ZIP File** tab
3. Fill in app name, package name (e.g. `com.yourname.appname`)
4. Click **Build APK**
5. Watch the real-time build log
6. Download the APK or the Android Studio project ZIP

---

## Project Structure

```
apk_builder/
├── server.py              ← Flask + Socket.IO server
├── cli.py                 ← `apk-builder` CLI entry point
├── utils/
│   ├── build_apk.py       ← Android project generator + Gradle runner
│   ├── web_scraper.py     ← Website downloader (offline mode)
│   ├── zip_handler.py     ← ZIP extractor
│   └── env_setup.py       ← Auto-installs JDK & Android SDK
├── public/
│   ├── index.html         ← Web UI
│   ├── style.css
│   └── script.js
├── templates/
│   └── android/           ← Android project template
pyproject.toml
requirements.txt
```

---

## How It Works

1. **On startup** — JDK 17 and Android SDK are checked and auto-downloaded if missing
2. **ZIP/URL source** → web files extracted/downloaded to a temp folder
3. **Android project** created from the template with your app settings applied
4. **Web files** copied into `app/src/main/assets/www/`
5. **MainActivity.java** generated to load `file:///android_asset/www/index.html`
   (or the live URL in online mode)
6. **Gradle** builds the APK
7. APK (or project ZIP) served for download

---

## FAQ

**Q: The APK installs but shows a blank screen.**  
A: Make sure your web app works from `index.html` at the root of the ZIP. All asset paths must be relative (e.g. `./style.css` not `/style.css`).

**Q: I see “Gradle not found” in the log.**  
A: Download the project ZIP, open in Android Studio, and click ▶ Run.

**Q: How do I sign the APK for the Play Store?**  
A: The debug APK is for testing. For release, open the project in Android Studio → Build → Generate Signed Bundle/APK.

**Q: Where are JDK and Android SDK installed?**  
A: In `~/.apk-builder/jdk` and `~/.apk-builder/android-sdk`. Delete that folder to force a re-download.

**Q: Can I run this on a VPS/server?**  
A: Yes. The auto-setup works on Linux servers too. Set the `PORT` env var to change the port:
```bash
PORT=8080 apk-builder --no-open
```

---

## License

MIT


---

## Quick Start

### Prerequisites

| Requirement | Notes |
|---|---|
| **Node.js ≥ 18** | [nodejs.org](https://nodejs.org) |
| **Java JDK 17+** | Required for Gradle |
| **Android SDK** | Part of [Android Studio](https://developer.android.com/studio) |

> **Without Java/Android SDK** the tool still works — it generates an Android Studio project ZIP you can open and build manually.

---

### 1. Install & Run

**Windows:**
```bat
install.bat
```

**macOS / Linux:**
```sh
chmod +x install.sh && ./install.sh
```

**Manual:**
```sh
npm install
node server.js
```

Open **http://localhost:3000** in your browser.

---

### 2. Set up Android SDK (for direct APK building)

1. Install [Android Studio](https://developer.android.com/studio)
2. Open Android Studio → SDK Manager → Install **Android SDK Platform 34**
3. Set `ANDROID_HOME` environment variable:
   - **Windows:** `%LOCALAPPDATA%\Android\Sdk`
   - **macOS:** `~/Library/Android/sdk`
   - **Linux:** `~/Android/Sdk`
4. Add Gradle to PATH (Android Studio bundles it at `<studio>/plugins/gradle/lib/gradle-launcher-*.jar`)

---

### 3. Build an APK

1. Open **http://localhost:3000**
2. Choose **Web URL** or **ZIP File** tab
3. Fill in app name, package name (e.g. `com.yourname.appname`)
4. Click **Build APK**
5. Watch the real-time build log
6. Download the APK or the Android Studio project

---

## Project Structure

```
APK BUILDER/
├── server.js              ← Express + Socket.io server
├── package.json
├── public/
│   ├── index.html         ← Web UI
│   ├── style.css
│   └── script.js
├── utils/
│   ├── buildApk.js        ← Android project generator + Gradle runner
│   ├── webScraper.js      ← Website downloader (offline mode)
│   └── zipHandler.js      ← ZIP extractor
├── templates/
│   └── android/           ← Android project template
│       ├── app/
│       │   ├── build.gradle
│       │   └── src/main/
│       │       ├── AndroidManifest.xml
│       │       ├── assets/www/    ← web files placed here
│       │       ├── java/          ← MainActivity.java (generated)
│       │       └── res/
│       ├── build.gradle
│       ├── settings.gradle
│       ├── gradle.properties
│       └── gradlew / gradlew.bat
├── uploads/               ← Temporary upload storage (auto-created)
└── builds/                ← Build outputs (auto-created)
    └── <buildId>/
        ├── app-debug.apk  ← Built APK (if Gradle available)
        └── project.zip    ← Android Studio project
```

---

## How It Works

1. **ZIP/URL source** → web files extracted/downloaded to a temp folder
2. **Android project** created from the template with app settings applied
3. **Web files** copied into `app/src/main/assets/www/`
4. **MainActivity.java** generated to load `file:///android_asset/www/index.html`
   (or the live URL in online mode)
5. **Gradle** builds the APK if Android SDK is available
6. APK (or project ZIP) served for download

---

## Deploying to Another Machine / Server

```sh
# On the target machine
git clone <this-repo>   # or copy the folder
npm install
node server.js
```

Set `PORT` env var to change the port:
```sh
PORT=8080 node server.js
```

---

## FAQ

**Q: The APK installs but shows a blank screen.**  
A: Make sure your web app works from `index.html` at the root of the ZIP. Paths must be relative.

**Q: I see "Gradle not found" in the log.**  
A: That's fine — download the project ZIP, open in Android Studio, and click ▶ Run.

**Q: How do I sign the APK for release / Play Store?**  
A: The debug APK is self-signed. For release, open the project in Android Studio → Build → Generate Signed Bundle/APK.

**Q: Can I run this on a VPS/server?**  
A: Yes. Without Android SDK on the server, users always get a project ZIP. With Android SDK installed server-side (e.g. via `sdkmanager`), you get full APK builds.

---

## License

MIT
