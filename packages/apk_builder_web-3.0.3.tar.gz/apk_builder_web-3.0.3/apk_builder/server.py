import os
import re
import uuid
import threading
import tempfile
from pathlib import Path

from flask import Flask, request, jsonify, send_from_directory
from flask_socketio import SocketIO
from flask_cors import CORS
from werkzeug.utils import secure_filename

from .utils.build_apk import create_project, build
from .utils.web_scraper import download_site
from .utils.zip_handler import extract
from .utils.env_setup import ensure_build_env, setup_status

# ── Data root resolution ──────────────────────────────────────────────────────
def _data_root() -> Path:
    """Return the directory that contains templates/ and public/."""
    pkg_dir = Path(__file__).parent
    # Installed inside the package (e.g. bundled wheel)
    if (pkg_dir / "templates").is_dir():
        return pkg_dir
    # Dev / editable install — repo root is one level up
    return pkg_dir.parent

DATA_ROOT = _data_root()
PUBLIC_DIR = DATA_ROOT / "public"

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=None)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

PORT = int(os.environ.get("PORT", 3000))
TMP_BASE = tempfile.gettempdir()
IS_CLOUD = bool(os.environ.get("RENDER") or os.environ.get("RAILWAY_ENVIRONMENT"))

if IS_CLOUD:
    UPLOADS_DIR = Path(TMP_BASE) / "apkbuilder-uploads"
    BUILDS_DIR = Path(TMP_BASE) / "apkbuilder-builds"
else:
    UPLOADS_DIR = DATA_ROOT / "uploads"
    BUILDS_DIR = DATA_ROOT / "builds"

UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
BUILDS_DIR.mkdir(parents=True, exist_ok=True)

# In-memory build registry
builds: dict = {}

ALLOWED_EXTENSIONS = {".zip", ".png", ".jpg", ".jpeg", ".svg", ".gif"}
MAX_FILE_SIZE = 200 * 1024 * 1024  # 200 MB

# ── Background environment bootstrap ──────────────────────────────────────────
_setup_log: list = []  # store messages so late-joining clients can see them

def _bootstrap_env() -> None:
    """Run once at server startup in a background thread."""
    def _log(msg: str) -> None:
        _setup_log.append(msg)
        socketio.emit("setup:progress", {"message": msg})

    _log("🔧 Checking build prerequisites…")
    ensure_build_env(_log)

threading.Thread(target=_bootstrap_env, daemon=True).start()


# ── Helpers ───────────────────────────────────────────────────────────────────

def send_progress(build_id: str, message: str, progress: int | None = None) -> None:
    data: dict = {"buildId": build_id, "message": message}
    if progress is not None:
        data["progress"] = progress
    socketio.emit(f"build:{build_id}", data)
    if build_id in builds:
        builds[build_id]["log"].append(message)
        if progress is not None:
            builds[build_id]["progress"] = progress


def parse_config(data: dict) -> dict:
    return {
        "appName": (data.get("appName") or "My App")[:50],
        "packageName": sanitize_package_name(data.get("packageName") or "com.example.myapp"),
        "versionName": data.get("versionName") or "1.0.0",
        "versionCode": max(1, int(data.get("versionCode") or 1)),
        "minSdk": int(data.get("minSdk") or 21),
        "orientation": (
            data.get("orientation")
            if data.get("orientation") in ("unspecified", "portrait", "landscape")
            else "unspecified"
        ),
        "enableZoom": data.get("enableZoom") not in ("false", False),
        "fullscreen": data.get("fullscreen") in ("true", True),
        "allowExternalLinks": data.get("allowExternalLinks") in ("true", True),
        "statusBarColor": (
            data.get("statusBarColor")
            if _valid_color(data.get("statusBarColor"))
            else "#000000"
        ),
    }


def _valid_color(color: str | None) -> bool:
    return bool(color and re.match(r"^#[0-9A-Fa-f]{6}$", color))


def sanitize_package_name(name: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_.]", "_", name)
    clean = re.sub(r"^[^a-zA-Z]", "p", clean)
    parts = [p for p in clean.split(".") if p]
    valid = [(f"p{p}" if not p[0].isalpha() else p) for p in parts]
    if len(valid) < 2:
        valid.append("app")
    return ".".join(valid)


def find_index_html(directory: str) -> Path | None:
    root = Path(directory)
    if (root / "index.html").exists():
        return root / "index.html"
    for child in root.iterdir():
        if child.is_dir():
            found = find_index_html(str(child))
            if found:
                return found
    return None


# ── Socket.io ─────────────────────────────────────────────────────────────────

@socketio.on("connect")
def on_connect():
    print(f"Client connected: {request.sid}")


# ── Static file serving ───────────────────────────────────────────────────────

@app.route("/")
def serve_index():
    return send_from_directory(str(PUBLIC_DIR), "index.html")


@app.route("/<path:filename>")
def serve_static(filename: str):
    # Let Flask-SocketIO handle its own namespace (socket.io/ path, not our local file)
    if filename.startswith("socket.io/"):
        from flask import abort
        abort(404)
    return send_from_directory(str(PUBLIC_DIR), filename)


@app.route("/builds/<path:filename>")
def serve_builds(filename: str):
    # Prevent path traversal
    safe = filename.replace("..", "").lstrip("/")
    return send_from_directory(str(BUILDS_DIR), safe)


# ── Build from URL ────────────────────────────────────────────────────────────

@app.route("/api/build-from-url", methods=["POST"])
def build_from_url():
    data = request.get_json() or {}
    url: str = data.get("url", "")
    if not url or not url.startswith("http"):
        return jsonify({"error": "A valid http/https URL is required"}), 400

    build_id = str(uuid.uuid4())
    builds[build_id] = {"id": build_id, "status": "running", "progress": 0, "log": [], "type": "url"}

    def run():
        try:
            config = parse_config(data)
            offline = data.get("offline")
            send_progress(build_id, f"🌐 Starting build for: {url}", 5)

            web_dir = None
            if offline:
                send_progress(build_id, "⬇️  Downloading website for offline packaging…", 10)
                web_dir = download_site(url, build_id, lambda msg: send_progress(build_id, msg))
                config["loadType"] = "local"
            else:
                config["loadType"] = "url"
                config["loadUrl"] = url
                send_progress(build_id, "🔗 Configuring WebView to load URL at runtime…", 20)

            send_progress(build_id, "📁 Creating Android project structure…", 35)
            project_dir = create_project(build_id, config, web_dir, str(BUILDS_DIR))

            send_progress(build_id, "🔨 Attempting Gradle build…", 50)
            result = build(project_dir, build_id, lambda msg: send_progress(build_id, msg), str(BUILDS_DIR))

            if web_dir:
                import shutil
                shutil.rmtree(web_dir, ignore_errors=True)

            _emit_complete(build_id, result)
        except Exception as e:
            _emit_error(build_id, e)

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"buildId": build_id})


# ── Build from ZIP ────────────────────────────────────────────────────────────

@app.route("/api/build-from-zip", methods=["POST"])
def build_from_zip():
    if "zipFile" not in request.files:
        return jsonify({"error": "A ZIP file is required"}), 400

    zip_file = request.files["zipFile"]
    icon_file = request.files.get("appIcon")

    zip_ext = Path(zip_file.filename or "").suffix.lower()
    if zip_ext not in ALLOWED_EXTENSIONS:
        return jsonify({"error": f"File type {zip_ext} is not allowed"}), 400

    build_id = str(uuid.uuid4())
    builds[build_id] = {"id": build_id, "status": "running", "progress": 0, "log": [], "type": "zip"}

    zip_path = str(UPLOADS_DIR / f"{build_id}-{secure_filename(zip_file.filename or 'upload.zip')}")
    zip_file.save(zip_path)

    icon_path: str | None = None
    if icon_file and icon_file.filename:
        icon_ext = Path(icon_file.filename).suffix.lower()
        if icon_ext in ALLOWED_EXTENSIONS:
            icon_path = str(UPLOADS_DIR / f"{build_id}-icon{icon_ext}")
            icon_file.save(icon_path)

    # Capture form data before thread starts (request context ends)
    form_data = dict(request.form)

    def run():
        import shutil
        try:
            config = parse_config({k: (v[0] if isinstance(v, list) else v) for k, v in form_data.items()})
            config["loadType"] = "local"
            if icon_path:
                config["iconFilePath"] = icon_path

            send_progress(build_id, "📦 Extracting ZIP file…", 10)
            web_dir = extract(zip_path, build_id)

            index_html = find_index_html(web_dir)
            if not index_html:
                raise Exception(
                    "No index.html found in the ZIP. "
                    "Ensure your web app has index.html at the root or in a subfolder."
                )

            rel_dir = str(Path(index_html).parent.relative_to(web_dir))
            if rel_dir and rel_dir != ".":
                send_progress(build_id, f"📂 Found index.html in subfolder: {rel_dir}", 20)
                config["indexSubDir"] = rel_dir

            send_progress(build_id, "📁 Creating Android project structure…", 35)
            project_dir = create_project(build_id, config, web_dir, str(BUILDS_DIR))

            send_progress(build_id, "🔨 Attempting Gradle build…", 50)
            result = build(project_dir, build_id, lambda msg: send_progress(build_id, msg), str(BUILDS_DIR))

            shutil.rmtree(web_dir, ignore_errors=True)
            Path(zip_path).unlink(missing_ok=True)
            if icon_path:
                Path(icon_path).unlink(missing_ok=True)

            _emit_complete(build_id, result)
        except Exception as e:
            Path(zip_path).unlink(missing_ok=True)
            if icon_path:
                Path(icon_path).unlink(missing_ok=True)
            _emit_error(build_id, e)

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"buildId": build_id})


# ── Status / list endpoints ───────────────────────────────────────────────────

@app.route("/api/status/<build_id>")
def get_status(build_id: str):
    b = builds.get(build_id)
    if not b:
        return jsonify({"error": "Build not found"}), 404
    return jsonify(b)


@app.route("/api/builds")
def list_builds():
    return jsonify([
        {"id": b["id"], "status": b["status"], "progress": b["progress"], "type": b["type"]}
        for b in builds.values()
    ])


@app.route("/api/setup-status")
def api_setup_status():
    """Returns the current state of the auto-environment bootstrap."""
    status = setup_status()
    status["log"] = _setup_log
    return jsonify(status)


# ── Emit helpers ──────────────────────────────────────────────────────────────

def _emit_complete(build_id: str, result: dict) -> None:
    if result.get("apkPath"):
        builds[build_id]["status"] = "success"
        send_progress(build_id, "✅ APK built successfully!", 100)
        socketio.emit(f"build:{build_id}:complete", {
            "buildId": build_id,
            "apkUrl": f"/builds/{build_id}/{Path(result['apkPath']).name}",
            "projectUrl": f"/builds/{build_id}/project.zip",
            "hasApk": True,
        })
    else:
        builds[build_id]["status"] = "partial"
        send_progress(build_id, "📦 Project ZIP is ready. Open in Android Studio to build the APK.", 100)
        socketio.emit(f"build:{build_id}:complete", {
            "buildId": build_id,
            "projectUrl": f"/builds/{build_id}/project.zip",
            "hasApk": False,
        })


def _emit_error(build_id: str, err: Exception) -> None:
    print(f"Build error: {err}")
    builds[build_id]["status"] = "error"
    builds[build_id]["error"] = str(err)
    send_progress(build_id, f"❌ Error: {err}")
    socketio.emit(f"build:{build_id}:error", {"buildId": build_id, "error": str(err)})


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    print(f"\n🚀 APK Builder is running → http://localhost:{PORT}\n")
    socketio.run(app, host="0.0.0.0", port=PORT, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
