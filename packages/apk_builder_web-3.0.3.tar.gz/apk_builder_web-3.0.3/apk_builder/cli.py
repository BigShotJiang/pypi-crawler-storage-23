#!/usr/bin/env python3
"""
APK Builder CLI – starts the web server and optionally opens the browser.
"""
import os
import sys
import time
import threading
import webbrowser


def main() -> None:
    args = sys.argv[1:]

    if "--help" in args or "-h" in args:
        print(
            "\n  APK Builder – Web to Android APK Converter\n"
            "\n  Usage:\n"
            "    apk-builder [options]\n"
            "\n  Options:\n"
            "    --port <n>   Port to listen on (default: 3000)\n"
            "    --no-open    Don't open the browser automatically\n"
            "    --help       Show this help message\n"
            "    --version    Show version\n"
            "\n  Examples:\n"
            "    apk-builder\n"
            "    apk-builder --port 8080\n"
            "    apk-builder --no-open\n"
        )
        sys.exit(0)

    if "--version" in args or "-v" in args:
        try:
            from importlib.metadata import version
            print(version("apk-builder-web"))
        except Exception:
            from apk_builder import __version__
            print(__version__)
        sys.exit(0)

    port = 3000
    if "--port" in args:
        idx = args.index("--port")
        if idx + 1 < len(args):
            try:
                port = int(args[idx + 1])
            except ValueError:
                print(f"Invalid port: {args[idx + 1]}", file=sys.stderr)
                sys.exit(1)

    no_open = "--no-open" in args

    os.environ["PORT"] = str(port)

    url = f"http://localhost:{port}"

    if not no_open:
        def _open_later():
            time.sleep(1.5)
            webbrowser.open(url)
        threading.Thread(target=_open_later, daemon=True).start()

    print(f"\n  ✅  APK Builder is running!")
    print(f"  🌐  Open: {url}\n")

    from apk_builder.server import socketio, app
    socketio.run(app, host="0.0.0.0", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
