import zipfile
import tempfile
from pathlib import Path


def extract(zip_path: str, build_id: str) -> str:
    """
    Extract a ZIP file to a temporary directory.
    Returns the path of the extracted web root.
    """
    dest_dir = Path(tempfile.gettempdir()) / f"apkbuilder-zip-{build_id}"
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Security: prevent path traversal attacks in ZIP entries
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.namelist():
            member_path = (dest_dir / member).resolve()
            if not str(member_path).startswith(str(dest_dir.resolve())):
                raise ValueError(f"Unsafe ZIP entry detected: {member}")
        zf.extractall(str(dest_dir))

    # If the ZIP extracted into a single subfolder (common pattern),
    # return that subfolder as the web root.
    entries = [e for e in dest_dir.iterdir() if not e.name.startswith(".")]
    if len(entries) == 1 and entries[0].is_dir():
        sub_dir = entries[0]
        if (sub_dir / "index.html").exists():
            return str(sub_dir)

    return str(dest_dir)
