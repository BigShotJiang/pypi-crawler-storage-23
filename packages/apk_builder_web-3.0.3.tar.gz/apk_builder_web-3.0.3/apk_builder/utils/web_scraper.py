import re
import tempfile
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

MAX_ASSETS = 200
TIMEOUT_S = 15
HEADERS = {"User-Agent": "Mozilla/5.0 (APK-Builder/1.0)"}


def download_site(site_url: str, build_id: str, on_progress) -> str:
    """
    Download a site to a local directory for offline packaging.
    Returns the local directory path.
    """
    tmp_dir = Path(tempfile.gettempdir()) / f"apkbuilder-{build_id}"
    tmp_dir.mkdir(parents=True, exist_ok=True)

    base = urlparse(site_url)
    visited: set = set()
    asset_count = 0

    on_progress(f"⬇️  Fetching: {site_url}")

    html = _fetch_text(site_url)
    (tmp_dir / "index.html").write_text(_rewrite_html(html, base), encoding="utf-8")
    on_progress("✅ HTML page downloaded")

    # Parse and collect assets using stdlib html.parser (no extra deps for parsing)
    try:
        from bs4 import BeautifulSoup  # type: ignore
        soup = BeautifulSoup(html, "html.parser")
        asset_urls = _collect_assets_bs4(soup, site_url)
    except ImportError:
        asset_urls = _collect_assets_regex(html, site_url)

    on_progress(f"📎 Found {len(asset_urls)} assets to download")

    asset_list = list(asset_urls)
    i = 0
    while i < len(asset_list):
        if asset_count >= MAX_ASSETS:
            on_progress(f"⚠️  Asset limit ({MAX_ASSETS}) reached, skipping remaining")
            break

        asset_url = asset_list[i]
        i += 1

        if not asset_url or asset_url in visited:
            continue
        visited.add(asset_url)

        try:
            local_path = _url_to_local_path(asset_url, tmp_dir, base)
            local_path.parent.mkdir(parents=True, exist_ok=True)

            is_text = bool(re.search(r"\.(css|js|svg|html?)$", asset_url, re.I))
            if is_text:
                content = _fetch_text(asset_url)
                if asset_url.lower().endswith(".css"):
                    for cu in _extract_css_urls(content, asset_url):
                        if asset_count < MAX_ASSETS and cu not in visited:
                            asset_list.append(cu)
                    content = _rewrite_css(content, asset_url, base)
                local_path.write_text(content, encoding="utf-8")
            else:
                local_path.write_bytes(_fetch_binary(asset_url))

            asset_count += 1
        except Exception:
            on_progress(f"⚠️  Could not download: {asset_url.split('/')[-1]}")

    on_progress(f"✅ Downloaded {asset_count} assets")
    return str(tmp_dir)


# ── Asset collection ──────────────────────────────────────────────────────────

def _collect_assets_bs4(soup, site_url: str) -> set:
    asset_urls: set = set()

    for tag in soup.find_all("link", rel="stylesheet"):
        href = tag.get("href")
        if href:
            r = _resolve_url(href, site_url)
            if r:
                asset_urls.add(r)

    for tag in soup.find_all("script", src=True):
        r = _resolve_url(tag["src"], site_url)
        if r:
            asset_urls.add(r)

    for tag in soup.find_all("img", src=True):
        if not tag["src"].startswith("data:"):
            r = _resolve_url(tag["src"], site_url)
            if r:
                asset_urls.add(r)

    for tag in soup.find_all(style=True):
        style = tag.get("style", "")
        m = re.search(r"url\(['\"]?([^'\")\s]+)['\"]?\)", style)
        if m and not m.group(1).startswith("data:"):
            r = _resolve_url(m.group(1), site_url)
            if r:
                asset_urls.add(r)

    for tag in soup.find_all("link", rel=re.compile(r"icon")):
        href = tag.get("href")
        if href:
            r = _resolve_url(href, site_url)
            if r:
                asset_urls.add(r)

    return asset_urls


def _collect_assets_regex(html: str, site_url: str) -> set:
    """Fallback asset collection using regex (no BeautifulSoup)."""
    asset_urls: set = set()
    patterns = [
        r'<link[^>]+href=["\']([^"\']+)["\']',
        r'<script[^>]+src=["\']([^"\']+)["\']',
        r'<img[^>]+src=["\']([^"\']+)["\']',
        r'url\(["\']?([^"\')\s]+)["\']?\)',
    ]
    for pat in patterns:
        for m in re.finditer(pat, html, re.I):
            href = m.group(1)
            if href and not href.startswith("data:"):
                r = _resolve_url(href, site_url)
                if r:
                    asset_urls.add(r)
    return asset_urls


# ── URL helpers ───────────────────────────────────────────────────────────────

def _resolve_url(href: str, base: str) -> str | None:
    if not href:
        return None
    try:
        return urljoin(base, href)
    except Exception:
        return None


def _url_to_local_path(asset_url: str, tmp_dir: Path, base) -> Path:
    try:
        parsed = urlparse(asset_url)
        rel = parsed.path.lstrip("/")
        if not rel or rel.endswith("/"):
            rel = rel + "index.html"
        rel = re.sub(r"[?#].*$", "", rel)
        rel = rel.replace("..", "_")
        return tmp_dir / Path(rel)
    except Exception:
        safe = re.sub(r"[^a-zA-Z0-9._-]", "_", asset_url)[-100:]
        return tmp_dir / "assets" / safe


def _rewrite_html(html: str, base) -> str:
    origin = f"{base.scheme}://{base.netloc}"
    escaped = re.escape(origin)
    return re.sub(
        rf'(href|src|action)=["\']({escaped})(/[^"\']*)?["\']',
        lambda m: f'{m.group(1)}=".{m.group(3) or "/"}"',
        html,
        flags=re.IGNORECASE,
    )


def _rewrite_css(css: str, css_url: str, base) -> str:
    def replacer(m):
        href = m.group(1)
        if href.startswith("data:") or href.startswith("#"):
            return m.group(0)
        abs_url = _resolve_url(href, css_url)
        if not abs_url:
            return m.group(0)
        try:
            path = urlparse(abs_url).path
            return f'url("/{path.lstrip("/")}")'
        except Exception:
            return m.group(0)

    return re.sub(r"url\(['\"]?([^'\")\s]+)['\"]?\)", replacer, css, flags=re.IGNORECASE)


def _extract_css_urls(css: str, css_url: str) -> list:
    urls = []
    for m in re.finditer(r"url\(['\"]?([^'\")\s]+)['\"]?\)", css, re.IGNORECASE):
        href = m.group(1)
        if not href.startswith("data:") and not href.startswith("#"):
            abs_url = _resolve_url(href, css_url)
            if abs_url:
                urls.append(abs_url)
    return urls


# ── HTTP helpers ──────────────────────────────────────────────────────────────

def _fetch_text(url: str) -> str:
    resp = requests.get(url, timeout=TIMEOUT_S, headers=HEADERS)
    resp.raise_for_status()
    return resp.text


def _fetch_binary(url: str) -> bytes:
    resp = requests.get(url, timeout=TIMEOUT_S, headers=HEADERS, stream=True)
    resp.raise_for_status()
    return resp.content
