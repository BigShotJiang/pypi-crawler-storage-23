"""
Automatic environment bootstrap.

On first run this module:
  1. Downloads JDK 17 (Eclipse Temurin) if Java is not already on the system.
  2. Downloads Android command-line tools and installs:
       build-tools;34.0.0
       platforms;android-34
  Everything is stored under ~/.apk-builder/ so it survives across runs
  and never touches system-wide settings.
"""

import os
import shutil
import zipfile
import tarfile
import platform
import subprocess
import threading
from pathlib import Path

import requests

# ── Storage layout ────────────────────────────────────────────────────────────
BASE_DIR = Path.home() / ".apk-builder"
JDK_DIR  = BASE_DIR / "jdk"
SDK_DIR  = BASE_DIR / "android-sdk"

_JDK_MARKER = JDK_DIR  / ".jdk-ready"
_SDK_MARKER = SDK_DIR  / ".sdk-ready"

# ── SDK packages to install ───────────────────────────────────────────────────
SDK_PACKAGES = ["build-tools;34.0.0", "platforms;android-34"]

# ── Android cmdline-tools download URLs (version 11.0 / build 11076708) ─────
_CMDTOOLS_URLS = {
    "Windows": "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip",
    "Darwin":  "https://dl.google.com/android/repository/commandlinetools-mac-11076708_latest.zip",
    "Linux":   "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip",
}

# ── Global cache ──────────────────────────────────────────────────────────────
_lock        = threading.Lock()
_cached_env: dict | None = None  # set once setup is complete
_setup_error: str | None = None  # set if setup fails


def ensure_build_env(on_progress=None) -> dict:
    """
    Ensure JDK 17 and Android SDK are available.
    Downloads them to ~/.apk-builder/ on first call; cached afterwards.

    Returns an os.environ-like dict enriched with JAVA_HOME / ANDROID_HOME /
    ANDROID_SDK_ROOT so it can be passed directly to subprocess.run(env=...).
    """
    global _cached_env, _setup_error
    log = on_progress or (lambda _: None)

    with _lock:
        if _cached_env is not None:
            return _cached_env

        BASE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            java_home   = _ensure_jdk(log)
            android_home = _ensure_android_sdk(java_home, log)

            env = dict(os.environ)
            env["JAVA_OPTS"] = "-Xmx1g"

            if java_home:
                env["JAVA_HOME"] = str(java_home)
                env["PATH"] = str(java_home / "bin") + os.pathsep + env.get("PATH", "")

            if android_home:
                env["ANDROID_HOME"]     = str(android_home)
                env["ANDROID_SDK_ROOT"] = str(android_home)

            _cached_env = env
            log("✅ Build environment is ready")
            return env

        except Exception as exc:
            _setup_error = str(exc)
            log(f"⚠️  Environment setup error: {exc}")
            # Return plain env so builds can still attempt with whatever is on PATH
            _cached_env = dict(os.environ)
            return _cached_env


def setup_status() -> dict:
    """Return current setup status for the /api/setup-status endpoint."""
    if _setup_error:
        return {"status": "error", "message": _setup_error}
    if _cached_env is not None:
        return {"status": "ready"}
    return {"status": "pending"}


# ── JDK ───────────────────────────────────────────────────────────────────────

def _ensure_jdk(log) -> Path | None:
    """Returns the JAVA_HOME Path if we manage our own JDK, else None (use system)."""
    # Check system Java first
    if _java_ok(None):
        log("☕ Java found in system PATH — skipping JDK download")
        return None

    if _JDK_MARKER.exists():
        home = _find_jdk_home()
        if home and _java_ok(home):
            log(f"☕ Using cached JDK: {home}")
            return home
        # Marker exists but JDK is gone — re-download
        _JDK_MARKER.unlink(missing_ok=True)

    log("☕ Java not found. Downloading JDK 17 (Eclipse Temurin)…")
    _download_jdk(log)
    home = _find_jdk_home()
    if not home:
        raise RuntimeError("JDK download succeeded but JAVA_HOME directory not found.")
    _JDK_MARKER.touch()
    return home


def _java_ok(java_home: Path | None) -> bool:
    cmd = str(java_home / "bin" / ("java.exe" if platform.system() == "Windows" else "java")) \
          if java_home else "java"
    try:
        r = subprocess.run([cmd, "-version"], capture_output=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False


def _download_jdk(log) -> None:
    os_map   = {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}
    arch_map = {"AMD64": "x64", "x86_64": "x64", "arm64": "aarch64", "aarch64": "aarch64", "ARM64": "aarch64"}

    os_name = os_map.get(platform.system(), "linux")
    arch    = arch_map.get(platform.machine(), "x64")

    api = (
        f"https://api.adoptium.net/v3/assets/latest/17/hotspot"
        f"?os={os_name}&architecture={arch}&image_type=jdk"
    )
    log("⬇️  Fetching JDK 17 download URL from Adoptium…")
    resp = requests.get(api, timeout=30)
    resp.raise_for_status()
    assets = resp.json()

    if not assets:
        raise RuntimeError("Adoptium API returned no JDK 17 assets for this platform.")

    pkg          = assets[0]["binary"]["package"]
    download_url = pkg["link"]
    filename     = pkg["name"]
    log(f"⬇️  Downloading {filename} (~{pkg.get('size', 0) // 1024 // 1024} MB)…")

    JDK_DIR.mkdir(parents=True, exist_ok=True)
    archive = JDK_DIR / filename
    _download_with_progress(download_url, archive, log)

    log("📦 Extracting JDK…")
    if filename.endswith(".zip"):
        with zipfile.ZipFile(str(archive), "r") as zf:
            zf.extractall(str(JDK_DIR))
    else:
        with tarfile.open(str(archive), "r:gz") as tf:
            tf.extractall(str(JDK_DIR))

    archive.unlink(missing_ok=True)
    log("✅ JDK 17 installed")


def _find_jdk_home() -> Path | None:
    if not JDK_DIR.exists():
        return None
    for entry in sorted(JDK_DIR.iterdir()):
        if entry.is_dir() and (entry / "bin").exists():
            return entry
    return None


# ── Android SDK ───────────────────────────────────────────────────────────────

def _ensure_android_sdk(java_home: Path | None, log) -> Path | None:
    # Skip if ANDROID_HOME already set and looks valid
    existing = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if existing and (Path(existing) / "build-tools").exists():
        log(f"🤖 Android SDK found at {existing}")
        return Path(existing)

    if _SDK_MARKER.exists() and (SDK_DIR / "build-tools").exists():
        log(f"🤖 Using cached Android SDK: {SDK_DIR}")
        return SDK_DIR

    # Need Java to run sdkmanager
    if not _java_ok(java_home):
        log("⚠️  No Java available — skipping Android SDK auto-install (APK build won't be possible)")
        return None

    system = platform.system()
    url    = _CMDTOOLS_URLS.get(system)
    if not url:
        log(f"⚠️  No Android SDK download URL for platform: {system}")
        return None

    log("🤖 Android SDK not found. Downloading command-line tools…")
    SDK_DIR.mkdir(parents=True, exist_ok=True)

    cmdtools_zip = SDK_DIR / "cmdline-tools.zip"
    _download_with_progress(url, cmdtools_zip, log)

    log("📦 Extracting Android SDK tools…")
    extract_tmp = SDK_DIR / "_tmp_cmdtools"
    if extract_tmp.exists():
        shutil.rmtree(str(extract_tmp))
    extract_tmp.mkdir()

    with zipfile.ZipFile(str(cmdtools_zip), "r") as zf:
        zf.extractall(str(extract_tmp))
    cmdtools_zip.unlink(missing_ok=True)

    # Zip extracts as cmdline-tools/ — place at cmdline-tools/latest/
    extracted = extract_tmp / "cmdline-tools"
    dest      = SDK_DIR / "cmdline-tools" / "latest"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        shutil.rmtree(str(dest))
    shutil.move(str(extracted), str(dest))
    shutil.rmtree(str(extract_tmp))

    sdkmgr = _sdkmanager_path()
    if not sdkmgr.exists():
        log(f"⚠️  sdkmanager not found at expected path: {sdkmgr}")
        return None
    if platform.system() != "Windows":
        os.chmod(str(sdkmgr), 0o755)

    sub_env = dict(os.environ)
    sub_env["ANDROID_HOME"]     = str(SDK_DIR)
    sub_env["ANDROID_SDK_ROOT"] = str(SDK_DIR)
    if java_home:
        sub_env["JAVA_HOME"] = str(java_home)
        sub_env["PATH"]      = str(java_home / "bin") + os.pathsep + sub_env.get("PATH", "")

    # Accept all licenses
    log("📄 Accepting Android SDK licenses…")
    subprocess.run(
        [str(sdkmgr), f"--sdk_root={SDK_DIR}", "--licenses"],
        input="y\n" * 20, text=True, capture_output=True,
        env=sub_env, timeout=120,
    )

    # Install required SDK packages
    log(f"⬇️  Installing SDK packages: {', '.join(SDK_PACKAGES)}")
    result = subprocess.run(
        [str(sdkmgr), f"--sdk_root={SDK_DIR}"] + SDK_PACKAGES,
        capture_output=True, text=True, env=sub_env, timeout=600,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "")[:300]
        log(f"⚠️  SDK package install warning: {err}")
    else:
        log("✅ Android SDK installed (build-tools 34.0.0 + platform android-34)")

    _SDK_MARKER.touch()
    return SDK_DIR


def _sdkmanager_path() -> Path:
    name = "sdkmanager.bat" if platform.system() == "Windows" else "sdkmanager"
    return SDK_DIR / "cmdline-tools" / "latest" / "bin" / name


# ── Download helper ───────────────────────────────────────────────────────────

def _download_with_progress(url: str, dest: Path, log) -> None:
    with requests.get(url, stream=True, timeout=60) as resp:
        resp.raise_for_status()
        total      = int(resp.headers.get("content-length", 0))
        downloaded = 0
        last_pct   = -1

        with open(str(dest), "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct       = int(downloaded / total * 100)
                        milestone = (pct // 25) * 25   # report at 0 / 25 / 50 / 75 / 100
                        if milestone > last_pct:
                            last_pct = milestone
                            mb_done  = downloaded / 1024 / 1024
                            mb_total = total      / 1024 / 1024
                            log(f"  ↓ {mb_done:.0f} / {mb_total:.0f} MB  ({pct}%)")
