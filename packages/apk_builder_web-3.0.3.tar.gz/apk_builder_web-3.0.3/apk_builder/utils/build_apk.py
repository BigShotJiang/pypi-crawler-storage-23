import os
import re
import shutil
import zipfile
import platform
import subprocess
from pathlib import Path

# ── Template directory resolution ─────────────────────────────────────────────
def _template_dir() -> Path:
    pkg_dir = Path(__file__).parent.parent  # apk_builder/
    # Installed inside the package
    if (pkg_dir / "templates").is_dir():
        return pkg_dir / "templates" / "android"
    # Dev / editable install — repo root
    return pkg_dir.parent / "templates" / "android"

TEMPLATE_DIR = _template_dir()


# ── createProject ─────────────────────────────────────────────────────────────

def create_project(build_id: str, config: dict, web_dir: str | None, builds_dir: str) -> str:
    """
    Creates a complete Android project in <builds_dir>/<build_id>/project/
    then packages it as project.zip.  Returns projectDir path.
    """
    build_dir = Path(builds_dir) / build_id
    project_dir = build_dir / "project"

    build_dir.mkdir(parents=True, exist_ok=True)

    if project_dir.exists():
        shutil.rmtree(project_dir)
    shutil.copytree(str(TEMPLATE_DIR), str(project_dir))

    # Java source directory based on package name
    pkg_parts = config["packageName"].split(".")
    java_dir = project_dir / "app" / "src" / "main" / "java" / Path(*pkg_parts)
    java_dir.mkdir(parents=True, exist_ok=True)

    _generate_sources(project_dir, java_dir, config)

    # Copy web content
    if config.get("loadType") == "local" and web_dir:
        assets_www = project_dir / "app" / "src" / "main" / "assets" / "www"
        assets_www.mkdir(parents=True, exist_ok=True)
        shutil.copytree(web_dir, str(assets_www), dirs_exist_ok=True)

        if config.get("indexSubDir"):
            sub_src = assets_www / config["indexSubDir"]
            index_dst = assets_www / "index.html"
            index_src = sub_src / "index.html"
            if not index_dst.exists() and index_src.exists():
                for item in sub_src.iterdir():
                    dst = assets_www / item.name
                    if not dst.exists():
                        if item.is_dir():
                            shutil.copytree(str(item), str(dst))
                        else:
                            shutil.copy2(str(item), str(dst))

    # Copy custom icon
    if config.get("iconFilePath") and Path(config["iconFilePath"]).exists():
        _copy_icon(config["iconFilePath"], project_dir)

    _zip_project(project_dir, build_dir / "project.zip")
    return str(project_dir)


# ── generateSources ────────────────────────────────────────────────────────────

def _generate_sources(project_dir: Path, java_dir: Path, config: dict) -> None:
    tvars = _build_template_vars(config)

    text_files = [
        "settings.gradle",
        "app/build.gradle",
        "app/src/main/AndroidManifest.xml",
        "app/src/main/res/values/strings.xml",
        "app/src/main/res/values/colors.xml",
        "app/src/main/res/values/themes.xml",
    ]

    for rel in text_files:
        file_path = project_dir / Path(rel)
        if file_path.exists():
            content = file_path.read_text(encoding="utf-8")
            content = _apply_vars(content, tvars)
            file_path.write_text(content, encoding="utf-8")

    # Generate MainActivity.java
    (java_dir / "MainActivity.java").write_text(
        _generate_main_activity(config, tvars), encoding="utf-8"
    )

    # Remove placeholder java directory
    placeholder = project_dir / "app" / "src" / "main" / "java" / "PACKAGE_PLACEHOLDER"
    if placeholder.exists():
        shutil.rmtree(str(placeholder))


def _build_template_vars(config: dict) -> dict:
    return {
        "{{APP_NAME}}": config["appName"],
        "{{PACKAGE_NAME}}": config["packageName"],
        "{{VERSION_NAME}}": config["versionName"],
        "{{VERSION_CODE}}": str(config["versionCode"]),
        "{{MIN_SDK}}": str(config["minSdk"]),
        "{{TARGET_SDK}}": "34",
        "{{COMPILE_SDK}}": "34",
        "{{STATUS_BAR_COLOR}}": config["statusBarColor"],
        "{{ORIENTATION}}": config["orientation"],
    }


def _apply_vars(content: str, tvars: dict) -> str:
    for key, value in tvars.items():
        content = content.replace(key, value)
    return content


# ── generateMainActivity ───────────────────────────────────────────────────────

def _generate_main_activity(config: dict, tvars: dict) -> str:
    pkg = config["packageName"]
    load_type = config.get("loadType", "local")
    load_url = config.get("loadUrl", "file:///android_asset/www/index.html")
    enable_zoom = config.get("enableZoom", True)
    fullscreen = config.get("fullscreen", False)
    ext_links = config.get("allowExternalLinks", False)

    load_url_line = (
        f'webView.loadUrl("{load_url}");'
        if load_type == "url"
        else 'webView.loadUrl("file:///android_asset/www/index.html");'
    )

    fullscreen_imports = (
        "\nimport android.view.View;\nimport android.view.WindowManager;"
        if fullscreen else ""
    )

    fullscreen_code = (
        """
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );"""
        if fullscreen else ""
    )

    ext_links_import = (
        "\nimport android.content.Intent;\nimport android.net.Uri;"
        if ext_links else ""
    )

    if ext_links:
        web_view_client_class = f"""
        webView.setWebViewClient(new WebViewClient() {{
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {{
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {{
                    boolean isSameHost = Uri.parse(url).getHost() != null
                        && Uri.parse(url).getHost().equals(Uri.parse("{load_url}").getHost());
                    if (!isSameHost) {{
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    }}
                }}
                return false;
            }}
        }});"""
    else:
        web_view_client_class = "\n        webView.setWebViewClient(new WebViewClient());"

    zoom_str = str(enable_zoom).lower()

    return f"""package {pkg};

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;{fullscreen_imports}{ext_links_import}

public class MainActivity extends Activity {{

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);{fullscreen_code}
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom({zoom_str});
        settings.setBuiltInZoomControls({zoom_str});
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
{web_view_client_class}

        if (savedInstanceState != null) {{
            webView.restoreState(savedInstanceState);
        }} else {{
            {load_url_line}
        }}
    }}

    @Override
    protected void onSaveInstanceState(Bundle outState) {{
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }}

    @Override
    public void onBackPressed() {{
        if (webView.canGoBack()) {{
            webView.goBack();
        }} else {{
            super.onBackPressed();
        }}
    }}
}}
"""


# ── copyIcon ───────────────────────────────────────────────────────────────────

def _copy_icon(icon_src: str, project_dir: Path) -> None:
    densities = [
        ("mipmap-mdpi",    48),
        ("mipmap-hdpi",    72),
        ("mipmap-xhdpi",   96),
        ("mipmap-xxhdpi",  144),
        ("mipmap-xxxhdpi", 192),
    ]
    try:
        from PIL import Image  # type: ignore
        img = Image.open(icon_src).convert("RGBA")
        for name, size in densities:
            dest_dir = project_dir / "app" / "src" / "main" / "res" / name
            dest_dir.mkdir(parents=True, exist_ok=True)
            resized = img.resize((size, size), Image.LANCZOS)
            resized.save(str(dest_dir / "ic_launcher.png"), "PNG")
    except ImportError:
        # Pillow not installed — copy as-is to all densities
        for name, _ in densities:
            dest_dir = project_dir / "app" / "src" / "main" / "res" / name
            dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(icon_src, str(dest_dir / "ic_launcher.png"))


# ── zipProject ────────────────────────────────────────────────────────────────

def _zip_project(project_dir: Path, output_path: Path) -> None:
    with zipfile.ZipFile(str(output_path), "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for file_path in project_dir.rglob("*"):
            if file_path.is_file():
                arc_name = Path(project_dir.name) / file_path.relative_to(project_dir)
                zf.write(str(file_path), str(arc_name))


# ── build (Gradle) ────────────────────────────────────────────────────────────

def build(project_dir: str, build_id: str, on_progress, builds_dir: str) -> dict:
    """
    Ensures JDK + Android SDK are present, then builds the APK with Gradle.
    Returns dict with apkPath (or None) and projectZipPath.
    """
    from .env_setup import ensure_build_env

    project_path = Path(project_dir)
    build_dir = Path(builds_dir) / build_id
    project_zip_path = build_dir / "project.zip"

    on_progress("🔧 Checking build environment…")
    build_env = ensure_build_env(on_progress)

    gradle_cmd = _detect_gradle(project_path)

    if not gradle_cmd:
        on_progress("⚠️  Gradle wrapper not found. Skipping APK build – project ZIP is ready for Android Studio.")
        return {"apkPath": None, "projectZipPath": str(project_zip_path)}

    on_progress(f"🔨 Running Gradle assembleDebug…")

    try:
        result = subprocess.run(
            gradle_cmd + ["assembleDebug"],
            cwd=str(project_path),
            capture_output=True,
            text=True,
            timeout=600,
            env=build_env,
        )

        output = result.stdout + "\n" + result.stderr
        for line in output.split("\n"):
            line = line.strip()
            if line and not line.startswith("Note:"):
                on_progress(line)

        apk_src = _find_built_apk(project_path)
        if not apk_src:
            raise RuntimeError("Gradle build succeeded but no APK was found in build outputs.")

        apk_dest = build_dir / "app-debug.apk"
        shutil.copy2(str(apk_src), str(apk_dest))
        on_progress("📱 APK saved: app-debug.apk")
        return {"apkPath": str(apk_dest), "projectZipPath": str(project_zip_path)}

    except subprocess.TimeoutExpired:
        on_progress("⚠️  Gradle build timed out after 10 minutes.")
        on_progress("📦 Project ZIP is still available for manual build in Android Studio.")
        return {"apkPath": None, "projectZipPath": str(project_zip_path)}
    except Exception as err:
        on_progress(f"⚠️  Gradle build failed: {str(err)[:600]}")
        on_progress("📦 Project ZIP is still available for manual build in Android Studio.")
        return {"apkPath": None, "projectZipPath": str(project_zip_path)}


def _find_built_apk(project_dir: Path) -> Path | None:
    candidates = [
        project_dir / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk",
        project_dir / "app" / "build" / "outputs" / "apk" / "release" / "app-release-unsigned.apk",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _detect_gradle(project_dir: Path) -> list | None:
    is_win = platform.system() == "Windows"
    wrapper_cmd = project_dir / ("gradlew.bat" if is_win else "gradlew")

    if wrapper_cmd.exists():
        if is_win:
            # batch files must be run via cmd.exe on Windows
            return ["cmd", "/c", str(wrapper_cmd)]
        os.chmod(str(wrapper_cmd), 0o755)
        return [str(wrapper_cmd)]

    try:
        subprocess.run(["gradle", "--version"], capture_output=True, timeout=5)
        return ["gradle"]
    except Exception:
        return None
