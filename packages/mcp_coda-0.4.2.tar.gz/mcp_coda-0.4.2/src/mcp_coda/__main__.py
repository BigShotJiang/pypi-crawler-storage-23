"""Allow running with `python -m mcp_coda`."""

from mcp_coda import main

main()
