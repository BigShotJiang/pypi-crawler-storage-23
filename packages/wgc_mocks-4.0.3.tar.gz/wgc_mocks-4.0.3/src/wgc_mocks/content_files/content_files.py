# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from os import path


def get_content_template_path(filename):
    """
    Get content template path.

    :param str filename: file name.
    :rtype: str
    :return: path to template file.
    """
    return path.join(path.dirname(__file__), filename)
