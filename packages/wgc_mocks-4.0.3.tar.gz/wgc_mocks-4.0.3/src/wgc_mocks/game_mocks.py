﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import base64
import datetime
import mimetypes
import os
import re
import asyncio
import ssl
import string
import uuid
import warnings
import random
import socket
import glob
import json
from copy import deepcopy
from logging import getLogger
from typing import List

from packaging.version import Version
from os import path, makedirs
from pathlib import Path
from time import time
from urllib.parse import parse_qs, unquote

import xmltodict
from aiohttp import web
from linqp import Linqp

from clippy.helpers.file_downloader import download_file
from wgc_core.config import WGCConfig
from wgc_core.file_templates import get_file_template
from wgc_helpers.regex_helper import RegexHelper
from wgc_helpers.requirements_helper import RequirementHelper
from wgc_helpers.response_builder import ResponseBuilder
from wgc_core.logger import get_logger
from wgc_helpers.metadata_helper import GameMetadataProtocol
from wgc_helpers.certificate import CertificatesHelper
from wgc_mocks.agate import SteamExternalPaymentCommit, SteamExternalPaymentInit
from wgc_mocks.chubapi.get_game_resources import ArsenalGetGameResources
from wgc_mocks.chubapi.chub_content_handlers import ArsenalGetPage, ArsenalGetContent, ArsenalGetDetailedContent
from wgc_mocks.routes import *  # noqa: F405,F403
from wgc_mocks.websocket_handler import WebSocketView
from wgc_mocks.wgcps.commerce_fetch_product_list_personal import CommerceFetchProductListPersonal
from wgc_mocks.wgcps.commerce_fetch_product_list import CommerceFetchProductList
from wgc_mocks.wgcps.fetch_client_payment_methods import FetchClientPaymentMethods
from wgc_mocks.wgcps.fetch_product_personal import FetchProductPersonal
from wgc_mocks.wgcps.fetch_product_price import FetchProductPrice
from wgc_mocks.wgcps.fetch_storefront_categories_v2 import CommerceFetchStorefrontCategoriesV2
from wgc_mocks.wgcps.fetch_storefront_categories_v7 import CommerceFetchStorefrontCategoriesV7
from wgc_mocks.wgcps.get_account_tsv_method import GetAccountTsvMethod
from wgc_mocks.wgcps.get_geo_data import GetGeoData
from wgc_mocks.wgcps.get_player_data import GetPlayerData
from wgc_mocks.wgcps.purchase_product_commit import PurchaseProductCommit
from wgc_mocks.wgcps.purchase_product_prepare import PurchaseProductPrepare
from wgc_mocks.wgni.methods.account.create_tfa_email_v3 import CreateTFAEmailV3
from wgc_mocks.wgcps.purchase_zero_product_prepare import PurchaseZeroProductPrepare
from wgc_mocks.wgcps.redeem_bonus_code_v3 import RedeemBonusCodeV3
from wgc_mocks.wgcps.set_billing_address import SetBillingAddress
from wgc_mocks.wgcps.steam_integration import SteamIntegrationFetchProductListPersonal, \
    SteamIntegrationExternalPaymentInit, SteamIntegrationExternalPaymentCommit
from wgc_mocks.wgni import WGNIUsersDB
from wgc_mocks.wgni.methods.account.account_merge import AccountMerge
from wgc_mocks.wgni.methods.account.account_merge_status import AccountMergeStatus
from wgc_mocks.wgni.methods.personal.validate_nickname import ValidateNickname
from wgc_mocks.wgni.methods.personal.validate_nickname_token import ValidateNicknameToken
from wgc_mocks.wgni.methods.registration.demo_challege import RegistrationChallenge
from wgc_mocks.wgni.methods.personal import Personal, PasswordReset, CredentialsBasicCreateChallenge, \
    CredentialsBasicCreate, CredentialsBasicCreateStatus, CheckCredentialsTicketStatus, CredentialsBasicActivate, \
    CheckCredentialsActivateTicketStatus, CheckNickname, ChangeNickname, CheckNameUpdateTicketStatus, LoginDomains, \
    ChangeStateNickname, ChangeStateNicknameStatus, CredentialsExternalSteam, CredentialsExternalSteamBindStatus, \
    PersonalRealm, PersonalPredict, PersonalPredictStatus
from wgc_mocks.wgni.methods.registration.create_external_steam import CreateExternalSteam
from wgc_mocks.wgni.methods.registration.create_external_steam_status import CreateExternalSteamStatus
from wgc_mocks.wgni.methods.registration.settings import SettingsView
from wgc_third_party import get_third_party_path
from wgc_helpers.os_helper import OSHelper
from wgc_helpers.sevenzip import SevenZipHelper
from wgc_mocks.content_files.content_files import get_content_template_path
from wgc_helpers.torrents_helper import TorrentsHelper
from wgc_mocks.aiomock import AioMock, MockedRequest, MockedResponse
from wgc_mocks.wgni.methods.account import CreateToken1ByOauth, CreateToken1Status, CreateOauthTokenV3, \
    OauthTokenStatusV3, OauthTokenStatusV2, GetChallenge, GetOauthTokenInfo, RevokeToken, AccountInfoV3, \
    AccountInfoToken, AccountTeleport, AccountTeleportStatus, AccountInfoV2, CreateOauthTokenV2, AccountAdd, \
    AccountAddStatus, CreateIDTokenV3, CreateIDTokenV3Status
from wgc_mocks.wgni.methods.account.get_challenge_old import GetChallengeOld
from wgc_mocks.wgni.methods.captcha import Captcha
from wgc_mocks.wgni.methods.game import TicketIssue, TicketConsume, SignGame
from wgc_mocks.wgni.methods.registration import Registration, CreateTicket, GetTicketChallenge, \
    CheckRegistrationTicketStatus, CheckBasicAccountStatus, CreateDemoAccount, CheckDemoStatus, CreateBasicAccount
from wgc_mocks.wgni.methods.registration.check_account_activation_status import CheckAccountActivationStatus
from wgc_mocks.wgni.methods.registration.check_account_activation_status_token import CheckAccountActivationStatusToken
from wgc_mocks.wgcps import GetLoginSession, GetItems
from wgc_mocks.wgcps.fetch_notifications import FetchNotificationList
from wgc_mocks.wgcps.get_full_inventory import GetFullInventory
from wgc_mocks.wgcps.get_game_page_category import GetGamePageCategory
from wgc_mocks.wgcps.get_product import GetProduct
from wgc_mocks.wgcps.incomming_notifications import IncomingNotification
from wgc_mocks.wgcps.redeem_bonus_code_v1_v2 import RedeemBonusCode
from wgc_mocks.wgni.methods.game.sign_token import SignToken
from wgc_mocks.wgcps.update_notifications import UpdateNotification
from wgc_mocks.wgni.methods.personal import Signature, SignatureToken

log = get_logger()
log_distribute = getLogger('distribute')
mimetypes.add_type('application/zip', '.7z')

latest_metadata_protocol_version = Version(WGCConfig.games.metadata_last_version)


def get_meta_version_from_protocol_version(protocol_version):
    protocol_version = str(protocol_version).replace('.', '')
    return protocol_version.ljust(15 - len(protocol_version), '0')


def get_latest_metadata_version():
    return get_meta_version_from_protocol_version(latest_metadata_protocol_version)


class Default(dict):
    def __missing__(self, key):
        return ''


class GameMocks(object):
    item_type = "vehicle"
    item_size = '601x300'
    left_premium_banner_url = 'https://google.com/'
    right_premium_banner_url = 'https://google.com/'
    add_utm_mark = False
    invalid_meta_app_id = None
    actual_game_center_version = False
    hostname = socket.gethostname()
    WGCConfig.init_free_ports()
    public_ip = '195.242.151.17'
    private_ip = WGCConfig.ip_address
    cert = get_third_party_path('server.crt')
    key = get_third_party_path('server.key')
    CertificatesHelper.generate_ssl_signed_cert(
        hostname, public_ip, private_ip, cert, key, 'WGC Automation')
    CertificatesHelper.install_certificate(cert, 'WGC Automation')
    host_https = f'{WGCConfig.ip_address}:{WGCConfig.mocks.https_port}'
    host_http = f'{WGCConfig.ip_address}:{WGCConfig.mocks.http_port}'
    
    download_mock = AioMock(WGCConfig.ip_address, WGCConfig.mocks.http_port)
    sslcontext = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    sslcontext.set_ciphers("DEFAULT:@SECLEVEL=1")
    sslcontext.load_cert_chain(cert, key)
    mock = AioMock(WGCConfig.ip_address, WGCConfig.mocks.https_port, sslcontext)
    
    game_update_url = 'https://%s/' % host_https
    wowp_update_url = 'https://%s/' % host_https
    wows_update_url = 'https://%s/' % host_https
    ss_url = 'https://%s/statistic/' % host_https
    game_custom_webseed = web_seed_url = WGCConfig.web_seed_url
    integrity_custom_webseed = game_custom_webseed
    wrong_web_seed = None
    local_wgc_patch = True
    wgc_publisher_id = None
    actual_game_version = '2.1'
    possible_versions = ['0', '1.1', '2.1']
    available_preload_ids = ['WOT.RU.PRODUCTION']
    possible_parts = ['minisd', 'locale', 'fullsd', 'fullhd', 'dlc1', 'dlc-dl2', 'dlc_dl3', 'd4', 'D5']
    secret = None
    cookie_samesite = 'None'
    setup_cookies_if_present_in_request = True
    cookie_exp_short = datetime.datetime.now()
    cookie_exp_long = datetime.datetime.now()
    cookie_exp_long_reset = False
    in_game_overlay = False
    report_session_id = ''
    premium_spectate_url = f'https://{host_https}/overlay/'
    game_custom_torrents = {}
    game_custom_torrent_hashes = {}
    news_production = False
    is_tool = False
    extended_public_games = []
    list_reuse_patches = []
    storefront_name_for_dd = 'wgc_game_shop'
    count_volume = 0
    get_game_patch_timeout = 0
    get_wgc_patch_sleep = 0
    country_legal = 'NO_RESTRICTIONS'
    stated_country = 'UA'
    country_code = 'UA'
    shop_data_source = 'platform'
    content_layout_name = 'wgc_auto_test'
    game_custom_patches = {}
    news_messages = {}
    cn360qr_state = None
    min_supported_os = 'Win7'
    custom_app_id_news_messages = None
    user_notifications = None
    integrity_custom_torrents = None
    wgc_web_seed = WGCConfig.share_builds_folder
    main_news_link = "https://worldoftanks.ru/ru/news/wgc-client/special-offers/warhammer/"
    content_service_host = 'https://%s' % host_https
    regular_news_link = f"{content_service_host}/custom_mock/"
    wgc_content_service = 'https://%s/cs_wgc/' % host_https
    eu_content_service = 'https://%s/cs_eu/' % host_https
    dev1_content_service = 'https://%s/cs_dev1/' % host_https
    dev2_content_service = 'https://%s/cs_dev2/' % host_https
    max_unpacking_threads_value = 8
    multiplier_unpacking_threads_value = 0.5
    amount_download_size = 0
    unpacked_size = 5000000
    download_size_when_stop_fail = 0
    count_hash_failed = 0
    download_size_when_start_fail = 0
    wgcps_content_enabled = True
    arsenal_qsg_enabled = False
    game_cs_map = {'WOT': wgc_content_service,
                   'WOWP': 'http://wguscs-wowp%(region)s.wargaming.net/',
                   'WOWS': 'http://wguscs-wows%(region)s.wargaming.net/',
                   'EU': eu_content_service,
                   'DEV1': dev1_content_service,
                   'DEV2': dev2_content_service}
    records_limit = 500
    item_finishing_property = None
    item_image_overridden = None
    item_background_image = 'https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_bg.jpeg'
    item_price_property = 1002.2
    item_promotion_text = None
    item_show_custom_package_content = False
    item_display_media_map = {
        "image_main": True,
        "image_2_1_shop": True,
        "image_2_1_overriden": True,
        "image_2_1": True,
        "image_1_1_shop": True,
        "image_1_1": True,
        "image_1_1_overriden": True,
        "background_image": True
    }
    item_package_content = ('<ul class=\"b-unordered-list\">\r\n<li><span class=\"b-icon-nation flag flag__usa '
                            'mceNonEditable\">&zwnj;</span>&nbsp;ИС-6;</li><li>слот.</li></ul>')
    _mocked_requests = []
    need_update = False
    dev1_agreement = 'dev1_eula'
    api_lang_aliases = None
    enable_miniclient_hd = False
    enable_wgc_update = False
    enable_wgc_ct_update = False
    mandatory_account_email = False
    demo_accounts_enabled = False
    stop_supporting = False
    integrity_black_list = {}
    support_languages = 'RU,EN'
    default_language = 'RU'
    default_content_language = 'en'
    content_source = 'Content Service'
    game_executable = 'dummy_game.exe'
    game_pages_targeting = True
    installer_check_version = WGCConfig.wgc_build
    buy_game = False
    steam_game_first_autorun = False
    title_id = 'alice.game'
    replace_loc_str = 'replace_loc_str'
    replace_loc = False
    custom_field = None
    installed_game_news_layout = False
    installed_game_15_layout = False
    show_age_ratings = False
    install_game_main_news_layout = False
    news_layout_support_login = True
    news_layout_external_link = True
    news_show_inside = True
    regular_news_show_inside = True
    installed_game_from_json = False
    required_space_sd = 250
    required_space_hd = 400
    preload_active = False
    activate_to_install_preload_patches = False
    activate_preinstall_patches = False
    show_agreement_before_launch = False
    show_steam_game_agreements = True
    keep_patches_interval = 7  # days
    environment_name = 'CIS'
    time_between_request = 0
    realm_to_remove_from_meta = None
    metadata_request_timeout = 0
    game_is_actual = False
    game_name = 'wot'
    wgni_client_id = WGCConfig.wgni_client_id
    enable_login_tag = True
    latest_response = '<nodata/>'
    open_dd_url = 'https://agdd-wgt1.wgtest.net'
    wgc_metadata_is_actual = False
    game_metadata_is_actual = False
    force_update_metadata = False
    wgc_ct_update_meta = False
    count_of_update_meta_ct = 0
    missing_alias_flag = False
    redirect_us_url = ''
    custom_client_type = ''
    redirect_application_id = ''
    category_id = None
    post_step_cmd = ''
    post_step_args = ''
    pre_step_cmd = ''
    pre_step_args = ''
    download_template = \
        'http://%s/download?file=%s/content_files/%s' % \
        (host_http, str(Path(__file__).parent).replace('\\', '/'), '%s')
    wgc_api_custom_relative_path = None
    # timeouts
    get_full_inventory_timeout = 1
    get_game_page_category_timeout = 0
    create_oauth_token_timeout = 0
    create_id_token_timeout = 0
    
    sizes = {'wot_1.1_ru_locale.wgpkg': '81371',
             'wot_1.1_dlc1.wgpkg': '15526433',
             'wot_1.1_dlc-dl2.wgpkg': '27531505',
             'wot_1.1_dlc_dl3.wgpkg': '1865863',
             'wot_1.1_d4.wgpkg': '4844913',
             'wot_1.1_D5.wgpkg': '5402591',
             'wot_2.1-1.1_dlc1.wgpkg': '15526433',
             'wot_2.1-1.1_dlc-dl2.wgpkg': '203167119',
             'wot_2.1-1.1_dlc_dl3.wgpkg': '247292',
             'wot_2.1-1.1_d4.wgpkg': '100131941',
             'wot_2.1-1.1_D5.wgpkg': '219573',
             'wot_3.1-2.1_dlc1.wgpkg': '82628',
             'wot_3.1-2.1_dlc-dl2.wgpkg': '100026813',
             'wot_3.1-2.1_dlc_dl3.wgpkg': '30894635',
             'wot_3.1-2.1_d4.wgpkg': '1000138',
             'wot_3.1-2.1_D5.wgpkg': '1000130',
             'wot_1.1_minisd.wgpkg': '18690800',
             'wot_1.1_locale_ru.wgpkg': '81371',
             'wot_1.1_locale_en.wgpkg': '115823',
             'wot_1.1_fullsd.wgpkg': '499528',
             'wot_1.1_fullhd.wgpkg': '14891319',
             'wot_1.1_en_locale.wgpkg': '115823',
             'wot_2.1_1.1_en_locale.wgpkg': '20815',
             'wot_2.1_1.1_fullhd.wgpkg': '33218',
             'wot_2.1_1.1_fullsd.wgpkg': '105656',
             'wot_2.1_1.1_locale_en.wgpkg': '20815',
             'wot_2.1_1.1_locale_ru.wgpkg': '17377',
             'wot_2.1_1.1_minisd.wgpkg': '862458',
             'wot_2.1_1.1_ru_locale.wgpkg': '17377',
             'wot_3.1_2.1_en_locale.wgpkg': '19167',
             'wot_3.1_2.1_fullhd.wgpkg': '500824',
             'wot_3.1_2.1_fullsd.wgpkg': '17760205',
             'wot_3.1_2.1_locale_en.wgpkg': '19167',
             'wot_3.1_2.1_locale_ru.wgpkg': '7822',
             'wot_3.1_2.1_minisd.wgpkg': '21899443',
             'wot_3.1_2.1_ru_locale.wgpkg': '7822'}
    
    @classmethod
    def reinit_default_attrs(cls):
        cls.game_custom_webseed = cls.web_seed_url = WGCConfig.web_seed_url
        cls.integrity_custom_webseed = cls.game_custom_webseed
        
        if WGCConfig.mocks.secure_content_service:
            host_content = f'https://{cls.host_https}'
        else:
            host_content = f'http://{cls.host_http}'
        cls.content_service_host = host_content
        cls.wgc_content_service = f'{host_content}/cs_wgc/'
        cls.eu_content_service = f'{host_content}/cs_eu/'
        cls.dev1_content_service = f'{host_content}/cs_dev1/'
        cls.dev2_content_service = f'{host_content}/cs_dev2/'
        cls.installer_check_version = WGCConfig.wgc_build
        
        cls.game_update_url = 'https://%s/' % cls.host_https
        cls.wowp_update_url = 'https://%s/' % cls.host_https
        cls.wows_update_url = 'https://%s/' % cls.host_https
        cls.ss_url = 'https://%s/statistic/' % cls.host_https
        cls.download_template = \
            'http://%s/download?file=%s/content_files/%s' % \
            (cls.host_http,
             str(Path(__file__).parent).replace('\\', '/'), '%s')
        cls.game_cs_map = {
            'WOT': cls.wgc_content_service,
            'WOWP': 'http://wguscs-wowp%(region)s.wargaming.net/',
            'WOWS': 'http://wguscs-wows%(region)s.wargaming.net/',
            'EU': cls.eu_content_service,
            'DEV1': cls.dev1_content_service,
            'DEV2': cls.dev2_content_service
        }
        cls.premium_spectate_url = f'https://{cls.host_https}/daily_deals/'
    
    @classmethod
    def _get_patch_chains(cls, part, version):
        """
        Create patch chain for current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        chains = {'0': [{part: '1.1'}, {part: '2.1-1.1'}],
                  '1.1': [{part: '2.1-1.1'}],
                  '2.1': [],
                  '3.1': []}
        return chains[version]
    
    @classmethod
    def _get_patch_chains_client(cls, part, version):
        """
        Create patch chain for current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        chains = {'0': [{part: '77.7'}],
                  '77.7': [],
                  '100': []}
        return chains[version]
    
    @classmethod
    def _get_patch_chains_client3(cls, part, version):
        """
        Create patch chain for current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        chains = {'0': [{part: '88.8'}],
                  '88.8': [],
                  '100': []}
        return chains[version]
    
    @classmethod
    def _get_patch_chains_client_2(cls, part, version):
        """
        Create patch chain for current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        chains = {'0': [{part: '1.1'}, {part: '2.1-1.1'}],
                  '1.1': [{part: '2.1-1.1'}],
                  '2.1': [],
                  '3.1': []}
        return chains[version]
    
    @classmethod
    def _get_preload_patch_chains(cls, part, version):
        """
        Create patch chain for preload current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        chains = {'2.1': [{part: '3.1-2.1'}],
                  '3.1': []}
        return chains[version]
    
    @classmethod
    def _get_integrity_chains(cls, part, version):
        """
        Create integrity chain for current part and version.

        :param str part: name of current part.
        :param str version: current version.
        :rtype: list[dict]
        :return: prepared list with chain information.
        """
        last = []
        if cls.activate_to_install_preload_patches or cls.activate_preinstall_patches:
            last = [{part: '2.1'}]
        chains = {'0': [],
                  '1.1': [{part: '1.1'}],
                  '2.1': [{part: '2.1'}],
                  '3.1': last,
                  '': [{part: '2.1'}]}
        return chains[version]
    
    @classmethod
    async def get_statistic(cls, request):
        """
        Callback for /statistic
        """
        return web.Response(status=200, text='SUCCESS')
    
    @classmethod
    async def get_game_patch(cls, request):
        await asyncio.sleep(cls.get_game_patch_timeout)
        return cls._get_game_patch(request)
    
    @classmethod
    async def get_game_patch_empty(cls, request):
        content = """
        <protocol name="patches_chain" version="1.11">
            <parts_info> </parts_info>
            <delay_preload>False</delay_preload>
            <web_seeds> </web_seeds>
            <meta_need_update>False</meta_need_update>
            <version_name>x.x.x.x</version_name>
        </protocol>"""
        return web.Response(text=content, content_type='text/xml')
    
    @classmethod
    async def get_game_patch_409(cls, request):
        text = '<error><code>111</code><description>' \
               'version_from is greater than latest version for client part' \
               '</description></error>'
        return web.Response(status=409, text=text)
    
    @classmethod
    async def get_game_patch_client(cls, request):
        game = 'wot'
        lang = request.query.get('lang').lower()
        patches_type_ = 'install'
        protocol_version = request.query.get('protocol_version')
        result = []
        part = 'client'
        actual_game_version = '77.7'
        current_version = request.query.get('%s_current_version' % part)
        torrent_hashes = cls.game_custom_torrent_hashes
        
        if current_version:
            result.extend(cls._get_patch_chains_client(part, current_version))
        
        if Version(request.query.get('metadata_protocol_version')) > \
                latest_metadata_protocol_version:
            return web.Response(content_type='text/xml', status=400,
                                text='<error>Protocol metadata not implemented.</error>')
        
        if request.query.get('metadata_version') == \
                get_meta_version_from_protocol_version(
                    latest_metadata_protocol_version):
            actual_version = \
                None if len(result) else actual_game_version
            meta_update_flag = False
        else:
            result = []
            actual_version = actual_game_version
            meta_update_flag = True
        
        text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=cls.web_seed_url,
            actual_version=actual_version,
            meta_need_update=meta_update_flag, lang=lang,
            custom_torrents=cls.game_custom_torrents,
            custom_webseed=cls.game_custom_webseed,
            custom_patches=cls.game_custom_patches,
            type_=patches_type_, protocol_version=protocol_version,
            unpacked_size=cls.unpacked_size, sizes=cls.sizes,
            torrent_hashes=torrent_hashes, secret=cls.secret)
        return web.Response(content_type='text/xml', text=text, status=200)
    
    @classmethod
    async def get_game_patch_client_2_version(cls, request):
        game = 'wot'
        lang = request.query.get('lang').lower()
        patches_type_ = 'install'
        protocol_version = request.query.get('protocol_version')
        result = []
        part = 'client'
        actual_game_version = '2.1'
        current_version = request.query.get('%s_current_version' % part)
        torrent_hashes = cls.game_custom_torrent_hashes
        
        if current_version:
            result.extend(cls._get_patch_chains_client_2(part, current_version))
        
        if Version(request.query.get('metadata_protocol_version')) > \
                latest_metadata_protocol_version:
            return web.Response(content_type='text/xml', status=400,
                                text='<error>Protocol metadata not implemented.</error>')
        
        if request.query.get('metadata_version') == \
                get_meta_version_from_protocol_version(
                    latest_metadata_protocol_version):
            actual_version = \
                None if len(result) else actual_game_version
            meta_update_flag = False
        else:
            result = []
            actual_version = actual_game_version
            meta_update_flag = True
        
        text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=cls.web_seed_url,
            actual_version=actual_version,
            meta_need_update=meta_update_flag, lang=lang,
            custom_torrents=cls.game_custom_torrents,
            custom_webseed=cls.game_custom_webseed,
            custom_patches=cls.game_custom_patches,
            type_=patches_type_, protocol_version=protocol_version,
            unpacked_size=cls.unpacked_size, sizes=cls.sizes,
            torrent_hashes=torrent_hashes, secret=cls.secret)
        return web.Response(content_type='text/xml', text=text, status=200)
    
    @classmethod
    async def get_game_patch_client_multivolume(cls, request):
        game = 'wot'
        lang = request.query.get('lang').lower()
        patches_type_ = 'install'
        protocol_version = request.query.get('protocol_version')
        result = []
        part = 'client:%s' % cls.count_volume
        actual_game_version = '77.7'
        current_version = request.query.get('client_current_version')
        torrent_hashes = cls.game_custom_torrent_hashes
        if current_version:
            result.extend(cls._get_patch_chains_client(part, current_version))
        
        if Version(request.query.get('metadata_protocol_version')) > \
                latest_metadata_protocol_version:
            return web.Response(content_type='text/xml', status=400,
                                text='<error>Protocol metadata not implemented.</error>')
        
        if request.query.get('metadata_version') == \
                get_meta_version_from_protocol_version(
                    latest_metadata_protocol_version):
            actual_version = \
                None if len(result) else actual_game_version
            meta_update_flag = False
        else:
            result = []
            actual_version = actual_game_version
            meta_update_flag = True
        
        text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=cls.web_seed_url,
            actual_version=actual_version,
            meta_need_update=meta_update_flag, lang=lang,
            custom_torrents=cls.game_custom_torrents,
            custom_webseed=cls.game_custom_webseed,
            custom_patches=cls.game_custom_patches,
            type_=patches_type_, protocol_version=protocol_version,
            unpacked_size=cls.unpacked_size, sizes=cls.sizes,
            torrent_hashes=torrent_hashes, secret=cls.secret)
        return web.Response(content_type='text/xml', text=text, status=200)
    
    @classmethod
    async def get_game_patch_client_multivolume2(cls, request):
        game = 'wot'
        lang = request.query.get('lang').lower()
        patches_type_ = 'install'
        protocol_version = request.query.get('protocol_version')
        result = []
        part = 'client:%s' % cls.count_volume
        actual_game_version = '88.8'
        current_version = request.query.get('client_current_version')
        torrent_hashes = cls.game_custom_torrent_hashes
        if current_version:
            result.extend(cls._get_patch_chains_client3(part, current_version))
        
        if Version(request.query.get('metadata_protocol_version')) > \
                latest_metadata_protocol_version:
            return web.Response(content_type='text/xml', status=400,
                                text='<error>Protocol metadata not implemented.</error>')
        
        if request.query.get('metadata_version') == \
                get_meta_version_from_protocol_version(
                    latest_metadata_protocol_version):
            actual_version = \
                None if len(result) else actual_game_version
            meta_update_flag = False
        else:
            result = []
            actual_version = actual_game_version
            meta_update_flag = True
        
        text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=cls.web_seed_url,
            actual_version=actual_version,
            meta_need_update=meta_update_flag, lang=lang,
            custom_torrents=cls.game_custom_torrents,
            custom_webseed=cls.game_custom_webseed,
            custom_patches=cls.game_custom_patches,
            type_=patches_type_, protocol_version=protocol_version,
            unpacked_size=cls.unpacked_size, sizes=cls.sizes,
            torrent_hashes=torrent_hashes, secret=cls.secret)
        return web.Response(content_type='text/xml', text=text, status=200)
    
    @classmethod
    def _get_game_patch(cls, request):
        """
        Callback for /api/v1/patches_chain path
        """
        resp = web.Response(content_type='text/xml', status=200)
        game = 'wot'
        lang = request.query.get('lang').lower()
        patches_type_ = 'install'
        protocol_version = request.query.get('protocol_version')
        metadata_protocol_version = request.query.get('metadata_protocol_version')
        game_id = request.query.get('game_id')
        
        torrent_hashes = WGCConfig.test_data.torrent_hashes
        torrent_hashes.update(cls.game_custom_torrent_hashes)
        
        if Version(metadata_protocol_version) > \
                latest_metadata_protocol_version:
            resp.set_status(400)
            resp.text = 'Protocol metadata not implemented.'
            log.warning('%s metadata protocol version is higher than latest metadata protocol version %s' %
                        (metadata_protocol_version, latest_metadata_protocol_version))
            return resp
        
        if cls.game_is_actual:
            resp.text = ResponseBuilder.generate_for_patch(
                request,
                [], game=game, web_seed_url=cls.web_seed_url,
                actual_version='2.1',
                meta_need_update=False, lang=lang,
                custom_torrents=cls.game_custom_torrents,
                custom_webseed=cls.game_custom_webseed,
                custom_patches=cls.game_custom_patches,
                type_=patches_type_, protocol_version=protocol_version,
                unpacked_size=cls.unpacked_size, sizes=cls.sizes,
                torrent_hashes=torrent_hashes, secret=cls.secret,
                publisher_id=cls.wgc_publisher_id)
        else:
            result = []
            parts_map = {}
            parts = []
            for param, val in request.query.items():
                if param.endswith('_current_version'):
                    part = param.split('_current_version')[0]
                    parts_map[part] = val
                    parts.append(part)
            parts.reverse()
            preload_available = cls.preload_active and min(parts_map.values()) == cls.actual_game_version \
                                and not cls.activate_to_install_preload_patches
            if preload_available:
                patches_type_ = 'preload'
            for part in parts:
                current_version = parts_map.get(part)
                if preload_available:
                    if cls.preload_active and not cls.activate_to_install_preload_patches \
                            and current_version == cls.actual_game_version and game_id in cls.available_preload_ids:
                        result.extend(cls._get_preload_patch_chains(
                            part, current_version))
                elif cls.activate_to_install_preload_patches and current_version == cls.actual_game_version \
                        and game_id in cls.available_preload_ids:
                    result.extend(cls._get_preload_patch_chains(
                        part, current_version))
                else:
                    result.extend(cls._get_patch_chains(part, current_version))
            
            if cls.game_metadata_is_actual:
                actual_version = cls.actual_game_version
                meta_update_flag = False
            else:
                if request.query.get('metadata_version') == \
                        get_meta_version_from_protocol_version(
                            metadata_protocol_version):
                    actual_version = \
                        None if len(result) else cls.actual_game_version
                    meta_update_flag = False
                else:
                    result = []
                    actual_version = cls.actual_game_version
                    meta_update_flag = True
            
            if patches_type_ == 'preload':
                actual_version = cls.actual_game_version
            if cls.activate_to_install_preload_patches:
                patches_type_ = 'install'
                actual_version = '3.1'
            if cls.activate_preinstall_patches:
                patches_type_ = 'preinstall'
                actual_version = '2.1'
            
            if cls.force_update_metadata:
                result = []
                actual_version = cls.actual_game_version
                meta_update_flag = True
            
            resp.text = ResponseBuilder.generate_for_patch(
                request,
                result, game=game, web_seed_url=cls.web_seed_url,
                actual_version=actual_version,
                meta_need_update=meta_update_flag, lang=lang,
                custom_torrents=cls.game_custom_torrents,
                custom_webseed=cls.game_custom_webseed,
                custom_patches=cls.game_custom_patches,
                type_=patches_type_, protocol_version=protocol_version,
                unpacked_size=cls.unpacked_size, sizes=cls.sizes,
                torrent_hashes=torrent_hashes,
                secret=cls.secret, publisher_id=cls.wgc_publisher_id)
        return resp
    
    @classmethod
    async def get_game_patch_change_url(cls, request):
        resp = cls._get_game_patch(request)
        if not request.path.startswith('/new_us/'):
            if request.query.get('game_id') not in ['WOT.PT.RELEASE', 'INCORRECT.APP.ID']:
                patch_content = xmltodict.parse(resp.text)
                del patch_content['protocol']['patches_chain']
                info = {}
                if cls.redirect_us_url != '':
                    info['redirect_url'] = cls.redirect_us_url
                if cls.redirect_application_id != '':
                    info['redirect_application_id'] = cls.redirect_application_id
                patch_content['protocol']['changed_game_info'] = info
                resp.text = xmltodict.unparse(patch_content)
        return resp
    
    @classmethod
    async def get_metadata_chain_id_change2(cls, request):
        resp = web.Response(content_type='text/html', status=200)
        guid = request.query.get('guid')
        chain_id = request.query.get('chain_id')
        protocol_version = Version(request.query.get('protocol_version'))
        
        if chain_id not in ['unknown', 'sd3_hd3']:
            return await cls.get_metadata_for_one_part(request)
        
        if protocol_version > latest_metadata_protocol_version:
            resp.set_status(400)
            resp.text = '<error>Protocol metadata not implemented.</error>'
            return resp
        resp.text = get_file_template(WGCConfig.games.metadata_one_part_file).format_map(
            Default({'app_id': guid,
                     'wgc_publisher_id': WGCConfig.wgc_publisher,
                     'game_name': 'World of Tanks Multivolumes',
                     'metadata_version': get_meta_version_from_protocol_version(
                         latest_metadata_protocol_version),
                     'chain_id': chain_id,
                     'part': 'client',
                     'wgni_url': WGCConfig.wgni_url,
                     'wgni_client_id': cls.wgni_client_id,
                     'cs_url_eu': cls.wgc_content_service,
                     'integrity': 'false',
                     'protocol_version': protocol_version}))
        return resp
    
    @classmethod
    async def get_wgc_patch_change_url(cls, request):
        resp = cls._get_wgc_patch(request)
        patch_content = xmltodict.parse(resp.text)
        del patch_content['protocol']['patches_chain']
        patch_content['protocol']['redirect_url'] = cls.redirect_us_url
        resp.text = xmltodict.unparse(patch_content)
        return resp
    
    @classmethod
    async def get_patch_invalid_url(cls, request):
        await asyncio.sleep(3)
        raise ZeroDivisionError
    
    @classmethod
    async def get_integrity(cls, request):
        """
        Callback for /api/v1/integrity_check and /api/v2/integrity_check
        """
        part_lang = 'ru'
        resp = web.Response(status=200, content_type='text/xml')
        for key, val in request.query.items():
            if key.endswith('_lang'):
                part_lang = val.lower()
        if not request.query.get('chain_id'):
            resp.set_status(400)
            resp.text = """<error><code>101</code><description>
            chain_id: This field is required.</description></error>"""
            return resp
        torrent_hashes = WGCConfig.test_data.torrent_hashes
        torrent_hashes.update(cls.game_custom_torrent_hashes)
        resp.content_type = 'text/xml'
        resp.set_status(200)
        result = []
        protocol_version = request.query.get('protocol_version')
        
        for part in cls.possible_parts:
            check_version = request.query.get('%s_check_version' % part)
            if check_version is not None:
                result.extend(
                    cls._get_integrity_chains(part, check_version))
        
        resp.text = ResponseBuilder.generate_for_integrity(
            result, web_seed=cls.integrity_custom_webseed, lang=part_lang,
            integrity_custom_torrents=cls.integrity_custom_torrents,
            black_list=cls.integrity_black_list,
            protocol_version=protocol_version, torrents_hashes=torrent_hashes,
            secret=cls.secret)
        return resp
    
    @classmethod
    async def get_metadata_invalid(cls, request):
        resp = cls._get_metadata(request)
        resp.text = resp.text + 'test'
        return resp
    
    @classmethod
    async def get_metadata_outdated(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['@version'] = '5.17'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_stop_support_game(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['generated_section']['stop_supporting'] = True
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata(cls, request):
        await asyncio.sleep(GameMocks.metadata_request_timeout)
        return cls._get_metadata(request)
    
    @classmethod
    async def get_metadata_duplicated_node(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        protocol_inner = deepcopy(metadata_content['protocol'])
        metadata_content['protocol']['protocol'] = protocol_inner
        del metadata_content['protocol']['predefined_section']
        del metadata_content['protocol']['protocol']['version']
        del metadata_content['protocol']['protocol']['generated_section']
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_modified_driver_versions(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['video_drivers']['video_driver'][0][
            '@min_version'] = "99.99.99.4229"
        metadata_content['protocol']['predefined_section']['video_drivers']['video_driver'][1][
            '@min_version'] = "99.99.99.4229"
        metadata_content['protocol']['predefined_section']['video_drivers']['video_driver'][2][
            '@min_version'] = "99.99.99.4229"
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_only_eula_present(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'] = {
            '@id': 'wot_ru',
            '@default': 'true',
            'platform_realm_id': 'ru',
            'game_id': 'wot',
            'common_agreements': {
                'agreement': {'@id': 'ru_eula'}},
            'content_service_url': 'http://wguscs-wotru.wargaming.net',
            'features': {'feature': {'@id': 'game_pages_targeting', '@enabled': 'true'}}
        }
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_only_pp_present(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'] = {
            '@id': 'wot_ru',
            '@default': 'true',
            'platform_realm_id': 'ru',
            'game_id': 'wot',
            'content_service_url': 'http://wguscs-wotru.wargaming.net',
            'features': {'feature': {'@id': 'game_pages_targeting', '@enabled': 'true'}}
        }
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_old_agreement(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['@version'] = '5.11'
        for index, val in enumerate(metadata_content['protocol']['realms_settings']['instances']['instance']):
            del metadata_content['protocol']['realms_settings']['instances']['instance'][index]['agreement_documents']
        metadata_content['protocol']['agreement_documents'] = {'document': [
            {'@id': 'eula', '@version': '3', 'link': [
                {'@xml:lang': 'en', '#text': 'https://agreements.wargaming.net/en/'},
                {'@xml:lang': 'ru', '#text': 'https://agreements.wargaming.net/ru/'}
            ]},
            {'@id': 'privacy', '@version': '3', 'link': [
                {'@xml:lang': 'en', '#text': 'https://agreements.wargaming.net/en/'},
                {'@xml:lang': 'ru', '#text': 'https://agreements.wargaming.net/ru/'}
            ]}]}
        content = \
            xmltodict.unparse(metadata_content)
        resp.text = content
        return resp
    
    @classmethod
    async def get_metadata_prescence(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        for index, val in enumerate(
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance']):
            metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'][
                index]['agreement_documents']['document'][0]['#text'] = \
                'https://agreements.wargaming.net/($wgc_language)/'
            metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'][
                index]['agreement_documents']['document'][1]['#text'] = \
                'https://agreements.wargaming.net/($wgc_language)/'
        
        content = \
            xmltodict.unparse(metadata_content)
        resp.text = content
        return resp
    
    @classmethod
    async def get_broken_metadata(cls, request):
        resp = web.Response(content_type='text/xml', status=200)
        resp.text = """
        <protocol name="app_metadata">
            <app_id>WOT.RU.PRODUCTION</app_id>
            <metadata_version>2016000000</metadata_version>
            <default_language>RU</default_language>
            <mutex_name>wgc_mutex</mutex_name>
            <metadata language="RU">
            </metadata>
        </protocol>
        """
        return resp
    
    @classmethod
    async def get_meta_remove_dev2(cls, request):
        resp = GameMocks._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        del metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'][2]
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    def _get_metadata(cls, req):
        """
        Callback for /api/v1/metadata
        """
        resp = web.Response(content_type='text/xml', status=400)
        game_id = cls.invalid_meta_app_id or req.query.get('guid')
        protocol_version = Version(req.query.get('protocol_version'))
        if game_id and game_id in GameMetadataProtocol.game_id_map:
            resp.set_status(200)
            if protocol_version > latest_metadata_protocol_version:
                resp.set_status(400)
                resp.text = 'Protocol metadata not implemented.'
                return resp
            
            game_metadata_version = get_meta_version_from_protocol_version(
                protocol_version)
            
            params = {'metadata_version': game_metadata_version,
                      'wgc_publisher_id': cls.wgc_publisher_id or WGCConfig.wgc_publisher,
                      'required_space_sd': cls.required_space_sd,
                      'required_space_hd': cls.required_space_hd,
                      'keep_patches_interval': cls.keep_patches_interval,
                      'wgni_url': WGCConfig.wgni_url,
                      'environment_name': cls.environment_name,
                      'min_supported_os': cls.min_supported_os,
                      'wgni_client_id': cls.wgni_client_id,
                      'content_source': cls.content_source,
                      'supported_languages': cls.support_languages,
                      'default_language': cls.default_language,
                      'game_executable': cls.game_executable,
                      'cs_url_eu': cls.game_cs_map.get('EU'),
                      'cs_url_dev1': cls.game_cs_map.get('DEV1'),
                      'cs_url_dev2': cls.game_cs_map.get('DEV2'),
                      'dev1_agreement': cls.dev1_agreement,
                      'api_lang_aliases': cls.api_lang_aliases,
                      'login_enabled': str(cls.enable_login_tag).lower(),
                      'mandatory_account_email': str(cls.mandatory_account_email).lower(),
                      'wgc_api_custom_relative_path': cls.wgc_api_custom_relative_path,
                      'game_pages_targeting': str(cls.game_pages_targeting).lower(),
                      'buy_game': str(cls.buy_game).lower(),
                      'steam_game_first_autorun': str(cls.steam_game_first_autorun).lower(),
                      'extended_public_games': cls.extended_public_games,
                      'show_agreement_before_launch': str(cls.show_agreement_before_launch).lower(),
                      'show_steam_game_agreements': str(cls.show_steam_game_agreements).lower(),
                      'title_id': cls.title_id,
                      'is_tool': str(cls.is_tool).lower(),
                      'premium_spectate_url': cls.premium_spectate_url,
                      'in_game_overlay': str(cls.in_game_overlay).lower(),
                      'demo_accounts_enabled': str(cls.demo_accounts_enabled).lower(),
                      'stop_supporting': cls.stop_supporting}
            
            content = str(GameMetadataProtocol(game_id, protocol_version, params))
            if WGCConfig.all_dlc_available:
                content = content.replace('selected_by_default="false', 'selected_by_default="true')
            resp.text = content
        else:
            resp.set_status(404)
            resp.text = '<?xml version="1.0" encoding="UTF-8"?>' \
                        '<error><code>103</code><description></description></error>'
        return resp
    
    @classmethod
    async def get_metadata_unpacking_threads(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['max_unpacking_threads_ssd'] = \
            cls.max_unpacking_threads_value
        metadata_content['protocol']['predefined_section']['max_unpacking_threads_hdd'] = \
            cls.max_unpacking_threads_value
        resp.text = \
            xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_multiplier(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['max_unpacking_threads_ssd'] = \
            str(cls.max_unpacking_threads_value)
        metadata_content['protocol']['predefined_section']['multiplier_unpacking_threads_ssd'] = \
            str(cls.multiplier_unpacking_threads_value)
        metadata_content['protocol']['predefined_section']['multiplier_unpacking_threads_hdd'] = \
            str(cls.multiplier_unpacking_threads_value)
        metadata_content['protocol']['predefined_section']['max_unpacking_threads_hdd'] = \
            str(cls.max_unpacking_threads_value)
        resp.text = \
            xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_fullhd(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        data = [{'@id': 'minisd', '@integrity': 'true'},
                {'@id': 'locale', '@integrity': 'true',
                 '@install_mode_app_type': 'sandbox', '@lang': 'true'},
                {'@id': 'fullsd', '@integrity': 'true', '@app_type': 'sd'},
                {'@id': 'fullhd', '@integrity': 'true', '@app_type': 'hd'}]
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][
            1]['client_parts']['client_part'] = data
        data2 = [{'@id': 'minisd', '@integrity': 'true'},
                 {'@id': 'locale', '@integrity': 'true',
                  '@install_mode_app_type': 'sandbox', '@lang': 'true'},
                 {'@id': 'fullsd', '@integrity': 'true', '@app_type': 'sd'}]
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][
            0]['client_parts']['client_part'] = data2
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_chain_id_change(cls, request):
        resp = web.Response(content_type='text/xml', status=200)
        chain_id = request.query.get('chain_id')
        protocol_version = Version(request.query.get('protocol_version'))
        guid = request.query.get('guid')
        if protocol_version <= latest_metadata_protocol_version:
            metadata_version = get_meta_version_from_protocol_version(
                latest_metadata_protocol_version)
        else:
            resp.set_status(400)
            resp.text = '<error>Protocol metadata not implemented.</error>'
            return resp
        if chain_id != 'sd3_hd3' and chain_id != 'unknown':
            metadata_version = '777'
        resp.text = get_file_template(WGCConfig.games.metadata_one_part_file).format_map(
            Default({'app_id': guid,
                     'wgc_publisher_id': WGCConfig.wgc_publisher,
                     'game_name': 'World of Tanks Multivolumes',
                     'metadata_version': metadata_version,
                     'chain_id': chain_id,
                     'wgni_url': WGCConfig.wgni_url,
                     'wgni_client_id': cls.wgni_client_id,
                     'cs_url_eu': cls.wgc_content_service,
                     'part': 'client',
                     'integrity': 'false',
                     'protocol_version': protocol_version}))
        return resp
    
    @classmethod
    async def get_metadata_without_instances_login_enabled_absent(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        del metadata_content['protocol']['predefined_section']['realms_settings']['instances']
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_patches_invalid(cls, request):
        response_content = """
                    <protocol name="patches_chain">
                        <patches_chain>
                        <web_seeds>
                            <url threads="20">
                                http://wds.wargaming.net/games/wot_VA17l1Vbq8Kkyu/np/
                            </url>
                        </web_seeds>
                        <meta_need_update>False</meta_need_update>
                        <private_ptp_enabled>False</private_ptp_enabled>
                        <version_name>0.9.13.7770</version_name>
                        </patches_chain>
                    </protocol>
                    """
        return web.Response(status=200, content_type='text/xml', text=response_content)
    
    @classmethod
    async def get_metadata_with_x86_redist(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
            'required_redistributables'] = [
            {'value': {'#text': 'vc2015_x64', '@elevation_required': False, '@arch': 'x64'}},
            {'value': {'#text': 'vc2015', '@elevation_required': False, '@arch': 'x86'}}
        ]
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
            'required_redistributables'] = [
            {'value': {'#text': 'vc2015_x64', '@elevation_required': False, '@arch': 'x64'}},
            {'value': {'#text': 'vc2015', '@elevation_required': False, '@arch': 'x86'}}
        ]
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_redist(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
            'required_redistributables'] = {'value': 'dx90c'}
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
            'required_redistributables'] = {'value': 'dx90c'}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_redist_elavation(cls, request):
        resp = cls._get_metadata(request)
        if request.qeuery.get('guid') not in ['WOWP.RU.PRODUCTION']:
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                'required_redistributables'] = {'value': {'@elevation_required': 'true', '#text': 'dx90c'}}
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
                'required_redistributables'] = {'value': {'@elevation_required': 'true', '#text': 'dx90c'}}
            resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_redist_hd(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
            'required_redistributables'] = {'value': 'dx90c'}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_custom_build_step(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['post_install_action'] = {
            'executable': [{'#text': 'poststep.exe', '@args': cls.post_step_args, '@arch': 'x64', '@emul': 'none'},
                           {'#text': 'poststep_x86.exe', '@args': cls.post_step_args, '@arch': 'x86', '@emul': 'none'},
                           # noqa
                           {'#text': 'poststep.exe.wgpkg', '@args': cls.post_step_args}]}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_redist_and_build_step(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['post_install_action'] = {
            'executable': [{'#text': 'poststep.exe', '@args': cls.post_step_args, '@arch': 'x64', '@emul': 'none'},
                           {'#text': 'poststep_x86.exe', '@args': cls.post_step_args, '@arch': 'x86', '@emul': 'none'},
                           # noqa
                           {'#text': 'poststep.exe.wgpkg', '@args': cls.post_step_args}]}
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
            'required_redistributables'] = {'value': 'dx90c'}
        metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
            'required_redistributables'] = {'value': 'dx90c'}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_custom_pre_step(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['pre_uninstall_action'] = {
            'executable': [{'#text': 'poststep.exe', '@args': cls.pre_step_args, '@arch': 'x64', '@emul': 'none'},
                           {'#text': 'poststep_x86.exe', '@args': cls.pre_step_args, '@arch': 'x86', '@emul': 'none'},
                           # noqa
                           {'#text': 'poststep.exe.wgpkg', '@args': cls.pre_step_args}]}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_with_shortcut_name_param(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['shortcut_name'] = 'Game for test'
        metadata_content['protocol']['predefined_section']['realms_settings'][
            'instances']['instance'][1]['uninstall_survey_url_suffix'] = 'test_for_test'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_503(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid').startswith('WOWS.NA'):
            resp.content_type = 'text/html'
            resp.set_status(503)
            resp.text = ''
        return resp
    
    @classmethod
    async def get_metadata_503_wot_ru(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid').startswith('WOT.RU'):
            resp.content_type = 'text/html'
            resp.set_status(503)
            resp.text = ''
        return resp
    
    @classmethod
    async def get_metadata_with_fs_name_param(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['fs_name'] = 'FS Game for test'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_chain_id_change_import(cls, request):
        resp = web.Response(content_type='text/xml', status=200)
        chain_id = request.query.get('chain_id')
        protocol_version = Version(request.query.get('protocol_version'))
        guid = request.query.get('guid')
        if protocol_version <= latest_metadata_protocol_version:
            file_template = WGCConfig.games.metadata_one_part_file
            metadata_version = get_meta_version_from_protocol_version(
                protocol_version)
        else:
            resp.set_status(400)
            resp.text = '<error>Protocol metadata not implemented.</error>'
            return resp
        if chain_id == 'sd3_hd3':
            metadata_version = '777'
        resp.text = get_file_template(file_template).format_map(Default(
            {'app_id': guid,
             'wgc_publisher_id': WGCConfig.wgc_publisher,
             'game_name': 'World of Tanks Multivolumes',
             'metadata_version': metadata_version,
             'chain_id': chain_id,
             'part': 'client',
             'integrity': 'false',
             'wgni_url': WGCConfig.wgni_url,
             'wgni_client_id': cls.wgni_client_id,
             'cs_url_eu': cls.wgc_content_service,
             'protocol_version': protocol_version}))
        return resp
    
    @classmethod
    async def get_metadata_another_alias(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid') == 'WOT.RU.PRODUCTION':
            index = 7 if WGCConfig.all_dlc_available else 2
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['client_types']['@default'] = \
                'new'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0]['final_app_type'] = \
                'new'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                '@id'] = 'new'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                '@aliases'] = 'sd'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                'client_parts']['client_part'][index]['@app_type'] = 'new'
            metadata_content['protocol']['predefined_section']['localization']['item'][20][
                '@id'] = 'NEW__NAME'
            metadata_content['protocol']['predefined_section']['localization']['item'][21][
                '@id'] = 'NEW__SHORT_NAME'
            metadata_content['protocol']['predefined_section']['localization']['item'][22][
                '@id'] = 'NEW__DESCRIPTION'
            metadata_content['protocol']['predefined_section']['localization']['item'][23][
                '@id'] = 'NEW__LOCALE__TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][24][
                '@id'] = 'NEW__LOCALE__INTERRUPTED_MESSAGE'
            metadata_content['protocol']['predefined_section']['localization']['item'][25][
                '@id'] = 'NEW__LOCALE__INFO_BEFORE_INSTALL_TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][26][
                '@id'] = 'NEW__LOCALE__INFO_BEFORE_INSTALL_TEXT'
            metadata_content['protocol']['predefined_section']['localization']['item'][27][
                '@id'] = 'NEW__LOCALE__INFO_AFTER_INSTALL_TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][28][
                '@id'] = 'NEW__LOCALE__INFO_AFTER_INSTALL_TEXT'
            resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_custom_cliet_type(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid') == 'WOT.RU.PRODUCTION':
            index = 7 if WGCConfig.all_dlc_available else 2
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['client_types']['@default'] = \
                cls.custom_client_type
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0]['final_app_type'] = \
                cls.custom_client_type
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                '@id'] = cls.custom_client_type
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                '@aliases'] = 'sd'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                'client_parts']['client_part'][index]['@app_type'] = cls.custom_client_type
            metadata_content['protocol']['predefined_section']['localization']['item'][20][
                '@id'] = f'{cls.custom_client_type.upper()}__NAME'
            metadata_content['protocol']['predefined_section']['localization']['item'][21][
                '@id'] = f'{cls.custom_client_type.upper()}__SHORT_NAME'
            metadata_content['protocol']['predefined_section']['localization']['item'][22][
                '@id'] = f'{cls.custom_client_type.upper()}__DESCRIPTION'
            metadata_content['protocol']['predefined_section']['localization']['item'][23][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][24][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__INTERRUPTED_MESSAGE'
            metadata_content['protocol']['predefined_section']['localization']['item'][25][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__INFO_BEFORE_INSTALL_TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][26][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__INFO_BEFORE_INSTALL_TEXT'
            metadata_content['protocol']['predefined_section']['localization']['item'][27][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__INFO_AFTER_INSTALL_TITLE'
            metadata_content['protocol']['predefined_section']['localization']['item'][28][
                '@id'] = f'{cls.custom_client_type.upper()}__LOCALE__INFO_AFTER_INSTALL_TEXT'
            resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_missing_alias(cls, request):
        resp = cls._get_metadata(request)
        if cls.missing_alias_flag:
            cls.force_update_metadata = False
            if request.query.get('guid') == 'WOT.RU.PRODUCTION':
                metadata_content = xmltodict.parse(resp.text)
                metadata_content['protocol']['predefined_section']['client_types'][
                    '@default'] = \
                    'new'
                metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                    '@id'] = 'new'
                metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                    '@aliases'] = 'sd'
                metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                    'client_parts']['client_part'][2]['@app_type'] = 'new'
                metadata_content['protocol']['predefined_section']['localization']['item'][20][
                    '@id'] = 'NEW__NAME'
                metadata_content['protocol']['predefined_section']['localization']['item'][21][
                    '@id'] = 'NEW__SHORT_NAME'
                metadata_content['protocol']['predefined_section']['localization']['item'][22][
                    '@id'] = 'NEW__DESCRIPTION'
                metadata_content['protocol']['predefined_section']['localization']['item'][23][
                    '@id'] = 'NEW__LOCALE__TITLE'
                metadata_content['protocol']['predefined_section']['localization']['item'][24][
                    '@id'] = 'NEW__LOCALE__INTERRUPTED_MESSAGE'
                metadata_content['protocol']['predefined_section']['localization']['item'][25][
                    '@id'] = 'NEW__LOCALE__INFO_BEFORE_INSTALL_TITLE'
                metadata_content['protocol']['predefined_section']['localization']['item'][26][
                    '@id'] = 'NEW__LOCALE__INFO_BEFORE_INSTALL_TEXT'
                metadata_content['protocol']['predefined_section']['localization']['item'][27][
                    '@id'] = 'NEW__LOCALE__INFO_AFTER_INSTALL_TITLE'
                metadata_content['protocol']['predefined_section']['localization']['item'][28][
                    '@id'] = 'NEW__LOCALE__INFO_AFTER_INSTALL_TEXT'
                resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_upper_str(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid') == 'WOT.RU.PRODUCTION':
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['default_language'] = 'RU'
            metadata_content['protocol']['predefined_section']['supported_languages'] = 'ru,en'
            resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_underscore_supported_languages(cls, request):
        resp = cls._get_metadata(request)
        if request.query.get('guid') == 'WOT.NA.PRODUCTION':
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['default_language'] = 'ES_AR'
            metadata_content['protocol']['predefined_section']['supported_languages'] = 'PT_BR,ES_AR'
            content = xmltodict.unparse(metadata_content).encode('utf-8')
            content = content.decode('utf-8').replace('bg', 'es_ar')
            content = content.replace('fr', 'pt_br')
            resp.text = content
        return resp
    
    @classmethod
    async def get_metadata_for_one_part(cls, request):
        guid = request.query.get('guid')
        resp = web.Response(status=200, content_type='text/xml')
        protocol_version = Version(request.query.get('protocol_version'))
        
        if protocol_version <= latest_metadata_protocol_version:
            file_template = WGCConfig.games.metadata_one_part_file
            metadata_version = get_meta_version_from_protocol_version(
                latest_metadata_protocol_version)
        else:
            resp.set_status(400)
            resp.text = '<error>Protocol metadata not implemented.</error>'
            return
        resp.text = get_file_template(file_template).format_map(Default(
            {'app_id': guid,
             'game_name': 'World of Tanks',
             'wgc_publisher_id': WGCConfig.wgc_publisher,
             'metadata_version': metadata_version,
             'chain_id': 'sd3_hd3',
             'part': 'client',
             'integrity': 'false',
             'wgni_url': WGCConfig.wgni_url,
             'wgni_client_id': cls.wgni_client_id,
             'cs_url_eu': cls.wgc_content_service,
             'protocol_version': protocol_version}))
        return resp
    
    @classmethod
    async def get_metadata_for_one_part_with_integrity(cls, request):
        guid = request.query.get('guid')
        resp = web.Response(content_type='text/xml', status=200)
        protocol_version = Version(request.query.get('protocol_version'))
        
        if protocol_version <= latest_metadata_protocol_version:
            file_template = WGCConfig.games.metadata_one_part_file
            metadata_version = get_meta_version_from_protocol_version(
                latest_metadata_protocol_version)
        else:
            resp.set_status(400)
            resp.text = '<error>Protocol metadata not implemented.</error>'
            return resp
        resp.text = get_file_template(file_template).format_map(Default(
            {'app_id': guid,
             'wgc_publisher_id': WGCConfig.wgc_publisher,
             'game_name': 'World of Tanks',
             'metadata_version': metadata_version,
             'chain_id': 'sd3_hd3',
             'part': 'client',
             'integrity': 'true',
             'wgni_url': WGCConfig.wgni_url,
             'wgni_client_id': cls.wgni_client_id,
             'cs_url_eu': cls.wgc_content_service,
             'protocol_version': protocol_version}))
        return resp
    
    @classmethod
    async def get_metadata_with_another_alias(cls, request):
        resp = cls._get_metadata(request)
        if GameMocks.need_update:
            metadata_content = xmltodict.parse(resp.text)
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][0][
                '@id'] = 'SD'
            metadata_content['protocol']['predefined_section']['client_types']['client_type'][1][
                '@id'] = 'HD'
            resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_incorrect_default_lang(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['default_language'] = 'KR'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_incorrect_default_exec(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        if GameMocks.custom_field == 1:
            metadata_content['protocol']['predefined_section']['executables'] = {'executable': ''}
        if GameMocks.custom_field == 2:
            metadata_content['protocol']['predefined_section']['executables'] = {'executable': [
                'dummy_game.exe', 'dummy_game.exe']}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_wrong_protocol(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['@version'] = 'wrong_protocol'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_patch_empty_seed(cls, request):
        resp = cls._get_game_patch(request)
        content = xmltodict.parse(resp.text)
        content['protocol']['patches_chain']['web_seeds'] = ''
        xml_content = xmltodict.unparse(content, pretty=True)
        resp.text = xml_content
        return resp
    
    @classmethod
    async def get_patch_empty_version_name(cls, request):
        resp = cls._get_game_patch(request)
        content = xmltodict.parse(resp.text)
        content['protocol']['patches_chain']['version_name'] = ''
        xml_content = xmltodict.unparse(content, pretty=True)
        resp.text = xml_content
        return resp
    
    @classmethod
    async def get_metadata_change_and_update_part(cls, request):
        resp = web.Response(status=200, content_type='text/xml')
        chain_id = request.query.get('chain_id')
        guid = request.query.get('guid')
        protocol_version = request.query.get('protocol_version')
        if chain_id == 'sd7_hd7':
            metadata_version = '777'
            part = 'minisd'
        else:
            metadata_version = get_meta_version_from_protocol_version(5.9)
            part = 'client'
        params = {'app_id': guid,
                  'game_name': 'World of Tanks Multivolumes',
                  'metadata_version': metadata_version,
                  'wgc_publisher_id': WGCConfig.wgc_publisher,
                  'chain_id': chain_id,
                  'part': part,
                  'integrity': 'false',
                  'wgni_url': WGCConfig.wgni_url,
                  'wgni_client_id': cls.wgni_client_id,
                  'cs_url_eu': cls.wgc_content_service,
                  'protocol_version': protocol_version,
                  'supported_languages': GameMocks.support_languages}
        resp.text = get_file_template(WGCConfig.games.metadata_one_part_file).format_map(
            Default(params))
        return resp
    
    @classmethod
    async def get_wgc_patch(cls, request):
        if cls.get_wgc_patch_sleep > 0:
            await asyncio.sleep(cls.get_wgc_patch_sleep)
        return cls._get_wgc_patch(request)
    
    @classmethod
    async def get_wgc_patch_ct(cls, request):
        if cls.get_wgc_patch_sleep > 0:
            await asyncio.sleep(cls.get_wgc_patch_sleep)
        return cls._get_wgc_patch(request)
    
    @classmethod
    def _get_wgc_patch(cls, request):
        resp = web.Response(content_type='text/xml', status=200)
        current_version = request.query.get('win32_current_version') or request.query.get('win64_current_version')
        protocol_version = request.query.get('protocol_version')
        arch_to_update = 'win32' if request.query.get('win32_current_version') else 'win64'
        patch_ext = 'wgpkg'
        if cls.enable_wgc_update:
            current_version = '0'
        if cls.enable_wgc_ct_update:
            current_version = '0'
        
        if WGCConfig.wgc_publisher == 'steam':
            game = 'wgcs'
        else:
            game = 'wgc'
        
        result = []
        game_id = request.query.get('game_id')
        if game_id.startswith('WGC.'):
            publisher_id = 'wargaming'
        elif game_id.startswith('WGCS.'):
            publisher_id = 'steam'
        else:
            publisher_id = 'qihoo'
        patch_dir = f'{game}_{WGCConfig.wgc_build}_{WGCConfig.wgc_region}'
        
        patch_name = f'{game}_{WGCConfig.wgc_build}_{arch_to_update}'
        patch_destination = path.join(WGCConfig.cache_patch_folder, f'{patch_name}.{patch_ext}')
        torrent_name = f'{patch_dir}.torrent'
        torrent_destination = path.join(WGCConfig.cache_patch_folder, torrent_name)
        
        part = 'win32'
        if request.query.get('win64_current_version'):
            part = 'win64'
        
        if cls.local_wgc_patch:
            web_seed = cls.wrong_web_seed or f'http://{GameMocks.host_http}/' \
                                             f'download?file={path.dirname(WGCConfig.cache_patch_folder)}/'
        else:
            web_seed = f'{cls.wgc_web_seed}{WGCConfig.wgc_branch}/' \
                       f'{WGCConfig.wgc_build}/{WGCConfig.wgc_publisher}/patch/'
        torrent_seed = f'{web_seed}{patch_dir}/'
        torrent_map = {part: {WGCConfig.wgc_build: f'{torrent_seed}{torrent_name}'}}
        patch_map = {part: {WGCConfig.wgc_build: f'{patch_dir}\\{patch_name}'}}
        
        if not cls.local_wgc_patch:
            torrent_link = f'{torrent_seed}{torrent_name}'
            if OSHelper.is_web_path_exist(torrent_link):
                makedirs(path.join(WGCConfig.temp_folder, 'tmp_torrent'), exist_ok=True)
                download_file(torrent_link, path.join(WGCConfig.temp_folder, 'tmp_torrent', 'file'))
                torrent_hashes = {torrent_link.split('/')[-1]: OSHelper.get_file_sha256(path.join(
                    WGCConfig.temp_folder, 'tmp_torrent', 'file'))}
                OSHelper.remove_file_or_directory(path.join(WGCConfig.temp_folder, 'tmp_torrent'))
        
        if cls.local_wgc_patch and not path.exists(torrent_destination) and path.exists(patch_destination):
            torrent = path.join(path.dirname(WGCConfig.cache_patch_folder), torrent_name)
            TorrentsHelper.generate_torrent_with_maketorrent(path.dirname(patch_destination), torrent_path=torrent)
            OSHelper.move_file_or_directory(torrent, path.join(path.dirname(patch_destination), torrent_name))
        
        if cls.local_wgc_patch and path.isfile(torrent_destination):
            torrent_hashes = {torrent_name: OSHelper.get_file_sha256(torrent_destination)}
        elif cls.local_wgc_patch and not path.isfile(torrent_destination):
            torrent_hashes = {torrent_name: WGCConfig.test_data.torrent_hashes['wot_1.1_ru.torrent']}
        
        if Version(current_version) < Version(WGCConfig.wgc_build):
            result.extend([{part: WGCConfig.wgc_build}])
        elif Version(current_version) == Version(WGCConfig.wgc_build):
            pass
        else:
            resp.set_status(409)
            resp.text = f'<error><code>111</code><description>' \
                        f'version_from is greater than latest version for {part} part' \
                        f'</description></error>'
            return resp
        
        actual_version = None if len(result) else WGCConfig.wgc_build
        
        if cls.country_code:
            resp.headers['Country-Code'] = cls.country_code
        
        if cls.actual_game_center_version:
            actual_version = current_version
            result = []
        
        resp.text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=web_seed,
            actual_version=actual_version,
            meta_need_update=False,
            custom_webseed=web_seed,
            custom_torrents=torrent_map, custom_patches=patch_map,
            protocol_version=protocol_version, torrent_hashes=torrent_hashes,
            secret=cls.secret, extension=patch_ext, publisher_id=publisher_id)
        return resp
    
    @classmethod
    async def get_wgc_empty_dir_patch(cls, request):
        resp = web.Response(content_type='text/xml', status=200)
        current_version = request.query.get('win32_current_version') or request.query.get('win64_current_version')
        protocol_version = request.query.get('protocol_version')
        patch_ext = 'wgpkg'
        if cls.enable_wgc_update:
            current_version = '0'
        if cls.enable_wgc_ct_update:
            current_version = '0'
        if WGCConfig.wgc_publisher == 'steam':
            game = 'wgcs'
        else:
            game = 'wgc'
        # game = 'wgc' if WGCConfig.wgc_publisher != 'steam' else 'wgcs'
        result = []
        part = 'win32'
        if request.query.get('win64_current_version'):
            part = 'win64'
        
        if Version(current_version) < Version(WGCConfig.wgc_build):
            result.extend([{part: WGCConfig.wgc_build}])
        elif Version(current_version) == Version(WGCConfig.wgc_build):
            pass
        else:
            resp.set_status(409)
            resp.text = f'<error><code>111</code><description>' \
                        f'version_from is greater than latest version for {part} part' \
                        f'</description></error>'
            return resp
        
        actual_version = None if len(result) else WGCConfig.wgc_build
        if cls.country_code:
            resp.headers['Country-Code'] = cls.country_code
        resp.text = ResponseBuilder.generate_for_patch(
            request,
            result, game=game, web_seed_url=cls.game_custom_webseed,
            actual_version=actual_version,
            meta_need_update=False,
            custom_webseed=cls.game_custom_webseed,
            custom_torrents=cls.game_custom_torrents, custom_patches=cls.game_custom_patches,
            protocol_version=protocol_version, torrent_hashes=cls.game_custom_torrent_hashes,
            secret=cls.secret, extension=patch_ext)
        return resp
    
    @classmethod
    async def torrent_hash_fail(cls, request):
        resp = await cls.base_download_file(request)
        path_ = request.query.get('file', '').rstrip('/')
        if not path_.endswith('torrent'):
            if cls.download_size_when_start_fail < cls.amount_download_size < \
                    cls.download_size_when_stop_fail:
                resp.text = b'a' * len(resp.text)
                
    @classmethod
    async def distribute_file(cls, req):
        """
        Falcon sink method to response with file content.
        Note: file param should be defined.
        """
        resp = web.Response(status=404)
        resp.text = ''
        resp.body = ''
        path_ = unquote(req.query.get('file', '').rstrip('/'))
        path_ = path_.replace('/', os.sep)
        if path.isfile(path_):
            resp.set_status(200)
            file_mime = mimetypes.guess_type(path_)[0]
            if file_mime:
                resp.content_type = file_mime
            connection = req.headers.get('CONNECTION', '')
            if connection:
                resp.headers['CONNECTION'] = connection
            with open(path_, 'rb') as file_:
                if cls.time_between_request > 0:
                    await asyncio.sleep(cls.time_between_request)
                if req.http_range.stop:
                    http_range = req.http_range
                    file_.seek(http_range.start)
                    size = http_range.stop - http_range.start
                    resp.set_status(206)
                    data = file_.read(size)
                    content_length = len(data or '')
                    resp.body = data
                    resp.headers['Content-Range'] = f'bytes {http_range.start}-{http_range.stop - 1}/{size}'
                else:
                    data = file_.read()
                    content_length = len(data or '')
                    resp.body = data
            log_distribute.debug('FILE %s, content_length=%s' % (path_, content_length))
            resp.headers['Content-Length'] = str(content_length)
        else:
            log_distribute.debug(f'404 not found: {path_}')
            log_distribute.debug(f'{path.dirname(path_)}: exists={path.exists(path_)}')
        return resp
    
    @classmethod
    async def download_file(cls, request):
        return await cls.base_download_file(request)
    
    @classmethod
    async def base_download_file(cls, request):
        resp = await cls.distribute_file(request)
        if resp.content_length:
            cls.amount_download_size += resp.content_length
        return resp
    
    @classmethod
    async def redist(cls, request):
        redist = request.match_info.get('redist')
        dx_src = f'http://lx-dwd.pershastudia.com/test_artifacts/test_data/{redist}'
        dx_dst = path.join(path.dirname(WGCConfig.temp_folder), redist)
        if not path.isfile(dx_dst):
            OSHelper.copy(dx_src, dx_dst)
            webseed = 'http://%s/download?file=%s/' % (
                GameMocks.host_http, path.dirname(WGCConfig.temp_folder).replace('\\', '/'))
            torrent_path = \
                TorrentsHelper.generate_torrent_file(
                    [dx_dst], webseed,
                    created_by='WGC QA Tests')
            OSHelper.copy(torrent_path, path.join(path.dirname(WGCConfig.temp_folder), f'{redist}.torrent'))
        torrent_path = path.join(path.dirname(WGCConfig.temp_folder), f'{redist}.torrent')
        query = request.query.copy()
        query.update(file=str(torrent_path.replace('\\', '/')))
        request._cache['query'] = query
        return await cls.distribute_file(request)
    
    @classmethod
    def redirect_404(cls, request):
        return web.Response(text='Not found', status=404)
    
    @classmethod
    def redirect_429(cls, request):
        return web.Response(text='', status=429)
    
    @classmethod
    def redirect_503(cls, request):
        return web.Response(text='', status=503)
    
    @classmethod
    def redirect_not_exists(cls, request):
        raise ZeroDivisionError
    
    @classmethod
    async def monitor_events(cls, request):
        data = await request.json()
        event_name = data.get('event_name')
        instance_id = data.get('instance_id')  # noqa
        hw_id = data.get('hw_id')  # noqa
        if event_name == 'report_uploaded':
            cls.report_session_id = data.get('data').get('server_session_id')
        return web.json_response({"status": "ok"})
    
    @classmethod
    async def cn360_login(cls, request):
        await asyncio.sleep(2)
        token = '319061402015bfe644de8a6387a234197d5aae6e0ced6abe06'
        state = request.query.get('state')
        base_64 = base64.b64encode(f"--login-cn360 --token {token} --state {state}".encode()).decode()
        with open(path.join(path.dirname(__file__), 'cn360_login.html'), 'r', encoding='utf-8') as fp:
            content = fp.read() % base_64
            resp = web.Response(text=content, status=200, content_type='text/html')
            return resp
    
    @classmethod
    async def redirect(cls, request):
        if WGCConfig.wgc_publisher == 'steam':
            prefix = 'wgcs'
        else:
            prefix = 'wgc'
        if 'installer.wgpkg' in request.path:
            patch = path.join(WGCConfig.cached_folder, 'patch',
                              f'{prefix}_{WGCConfig.wgc_build}_'
                              f'{WGCConfig.wgc_patch_arch}.wgpkg').replace(path.sep, '/')
            if path.isfile(patch):
                raise web.HTTPMovedPermanently(f'http://{cls.host_http}/download?file={patch}')
            else:
                patch = f'{WGCConfig.wgc_patch_folder}{prefix}_{WGCConfig.wgc_build}_{WGCConfig.wgc_patch_arch}.wgpkg'
                raise web.HTTPMovedPermanently(patch)
        elif 'installer_x64.wgpkg' in request.path:
            patch = path.join(WGCConfig.cached_folder, 'patch',
                              f'{prefix}_{WGCConfig.wgc_build}_win64.wgpkg').replace(path.sep, '/')
            if path.isfile(patch):
                raise web.HTTPMovedPermanently(f'http://{cls.host_http}/download?file={patch}')
            else:
                patch = f'{WGCConfig.wgc_patch_folder}{prefix}_{WGCConfig.wgc_build}_win64.wgpkg'
                raise web.HTTPMovedPermanently(patch)
        elif 'check_version' in request.path:
            return web.Response(status=200, text=cls.installer_check_version)
        elif request.match_info.get('redist') == 'dx90c':
            file_to_share = get_third_party_path('dx_redist.exe')
            file_download_url = f'http://{cls.host_http}/download?file={file_to_share.replace(path.sep, "/")}'
            torrent_path = TorrentsHelper.generate_torrent_file(
                file_path=[file_to_share],
                webseed=file_download_url,
                created_by='WGC Mock'
            )
            torrent_url_path = torrent_path.replace(path.sep, '/')
            raise web.HTTPMovedPermanently(f'http://{cls.host_http}/download?file={torrent_url_path}')
        else:
            return web.Response(status=404, text="Not found")
    
    @classmethod
    async def not_installed_game(cls, request):
        return cls._not_installed_game(request)
    
    @classmethod
    async def get_content_dlc(cls, request):
        return cls._get_content_dlc(request)
    
    @classmethod
    def _get_content_dlc(cls, request):
        data = {
            'status': 'ok',
            'data': [{"dlc_id": "dlc_dl3",
                      'small_image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                                     '25/27/2527ac24-8f79-4c45-9443-097feaa83593/tiger_small_image.jpg',
                      'image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                               'b9/fe/b9fefa1a-1571-46c6-b233-af6e86197fb2/tiger_image.jpg',
                      'button_link': 'https://www.google.com.ua/?hl=ru',
                      'button_name': 'HELLO',
                      'title': 'dlc_dl3 title',
                      'description': 'dlc_dl3 description'},
                     {"dlc_id": "dlc1",
                      'small_image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                                     '25/27/2527ac24-8f79-4c45-9443-097feaa83593/tiger_small_image.jpg',
                      'image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                               'b9/fe/b9fefa1a-1571-46c6-b233-af6e86197fb2/tiger_image.jpg',
                      'button_link': 'https://www.google.com.ua/?hl=ru',
                      'button_name': 'HELLO',
                      'title': 'dlc1 title',
                      'description': 'dlc1 description'},
                     {"dlc_id": "dlc-dl2",
                      'small_image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                                     '25/27/2527ac24-8f79-4c45-9443-097feaa83593/tiger_small_image.jpg',
                      'image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                               'b9/fe/b9fefa1a-1571-46c6-b233-af6e86197fb2/tiger_image.jpg',
                      'button_link': 'https://www.google.com.ua/?hl=ru',
                      'button_name': 'HELLO',
                      'title': 'dlc-dl2 title',
                      'description': 'dlc-dl2 description'},
                     {"dlc_id": "d4",
                      'small_image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                                     '25/27/2527ac24-8f79-4c45-9443-097feaa83593/tiger_small_image.jpg',
                      'image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                               'b9/fe/b9fefa1a-1571-46c6-b233-af6e86197fb2/tiger_image.jpg',
                      'button_link': 'https://www.google.com.ua/?hl=ru',
                      'button_name': 'HELLO',
                      'title': 'd4 title',
                      'description': 'd4 description'},
                     {"dlc_id": "D5",
                      'small_image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                                     '25/27/2527ac24-8f79-4c45-9443-097feaa83593/tiger_small_image.jpg',
                      'image': 'http://static.wguscs-wotkis73.kdo.space/filer_public/'
                               'b9/fe/b9fefa1a-1571-46c6-b233-af6e86197fb2/tiger_image.jpg',
                      'button_link': 'https://www.google.com.ua/?hl=ru',
                      'button_name': 'HELLO',
                      'title': 'D5 title',
                      'description': 'D5 description'},
                     ]
        }
        return web.json_response(data, status=200, content_type='application/json')
    
    @classmethod
    async def not_installed_game_without_sys_req(cls, request):
        resp = cls._not_installed_game(request)
        content = json.loads(resp.text)
        content['data']['promo'] = {}
        content['data']['install']['pages'][0]['system_requirements'] = []
        content['data']['install']['pages'][0]['media']['media_type'] = 'video'
        content['data']['install']['pages'][0]['media']['video'] = {
            "source": "youtube",
            "type": "video",
            "id": "_MYYai6qyuE"
        }
        return web.json_response(content, status=200, content_type='application/json')

    @classmethod
    async def not_installed_game_empty(cls, request):
        resp = cls._not_installed_game(request)
        content = json.loads(resp.text)
        content['data']['install']['pages'] = []
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    def _not_installed_game(cls, request):
        promo = {
            'action_button_name': "BUY-BUY",
            'description': "ALICE is a fast-paced hack-and-slash demo game "
                           "that will challenge your skill in brutal and "
                           "satisfying combat against countless enemies and larger "
                           "than life bosses.",
            'image': "http://dwd.pershastudia.org/test_artifacts/test_data/cs_images/alice-image.jpg",
            'logo': "http://dwd.pershastudia.org/test_artifacts/test_data/cs_images/alice-logo.png",
            'action_link': {
                'url': "https://www.google.com/search?q=alice+in+wonderland",
                'support_login': True
            }
        }
        
        with open(path.join(path.dirname(
                __file__), 'not_installed_game.json'), 'r', encoding='utf-8') as fp:
            content = json.loads(fp.read())
        if request.query.get('gameid') == 'ALICE.EU.PRODUCTION':
            content['data']['promo'] = promo
            content['data']['promo']['system_requirements'] = content['data']['install']['pages'][0][
                'system_requirements']
        if not cls.show_age_ratings:
            content['data']['age_ratings'] = []
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def features_highlight(cls, request):
        content = {
            'status': 'ok',
            'data': {
                'features_highlight': [
                    {
                        'logo': "http://static.wguscs-wotkis75.kdo.space/filer_public/"
                                "0a/44/0a44f04d-408f-4dac-9918-b3bc8697e10e/icon_premium.svg",
                        'title': "De ce îl folosim?",
                        'description': "Există o mulţime de variaţii disponibile ale pasajelor Lorem Ipsum, "
                                       "dar majoritatea lor au suferit alterări într-o oarecare măsură prin "
                                       "infiltrare de elemente de umor, sau de cuvinte luate aleator, "
                                       "care nu sunt câtuşi de puţin credibile. Daca vreţi să fol",
                        'link': "http://wikipedia.org",
                        'full_description': ""
                    }
                ]
            }}
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def quick_start(cls, request):
        available = ['ru', 'be', 'kk', 'uk']
        current = request.query.get('lang')
        if current.lower() not in available:
            current = 'ru'
        content = {
            'status': 'ok',
            'data': {
                'available_locales': available,
                'name': 'TEST',
                'current_locale': current,
                'view_type': 1,
                'folders': [{
                    'title': 'Testing',
                    'image': cls.download_template % 'big_qsg.jpg',
                    'items': []
                }]
            }
        }
        
        for news in range(7):
            content['data']['folders'][0]['items'].append(
                {'media_type': 'photo',
                 'name': 'Lorem ipsum',
                 'small_image': cls.download_template % 'small_qsg.jpg',
                 'big_image': cls.download_template % 'big_qsg.jpg',
                 'video': None,
                 'title': 'Lorem ipsum',
                 'description': 'Lorem ipsum dolor sit amet, consectetur '
                                'adipiscing elit, sed do eiusmod tempor '
                                'incididunt ut labore et dolore magna aliqua. '
                                'Ut enim ad minim veniam, quis nostrud '
                                'exercitation ullamco laboris nisi ut aliquip '
                                'ex ea commodo consequat.'})
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def showroom_without_ru(cls, request):
        resp = cls._content_showroom(request)
        content = json.loads(resp.text)
        del content['data']['showcase'][0]['instances'][0]
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def content_showroom(cls, request):
        return cls._content_showroom(request)
    
    @classmethod
    def _content_showroom(cls, request):
        query = parse_qs(request.query_string)
        showcase_products = query.get('showcase_products', [])
        showcase_products = showcase_products if isinstance(
            showcase_products, list) else [showcase_products]
        wgcps_game_images = {'BOB': {'logo': 'bob_logo.png',
                                     'tile': 'bob_tile.jpg',
                                     'art': 'bob_art.jpg'},
                             'ALICE': {'logo': 'alice_logo.png',
                                       'tile': 'alice_tile.jpg',
                                       'art': 'alice_art.jpg'}}
        
        products = Linqp(WGNIUsersDB._products).where(
            lambda x: x.available_for_non_auth).select_all()
        free_products = [f'{p.application_id}@{p.update_url}' for p in products]
        showcase_products.extend(free_products)
        
        mock_url = cls.game_update_url
        wowp_update_url = cls.wowp_update_url
        wows_update_url = cls.wows_update_url
        content = \
            {
                'status': 'ok',
                'data': {
                    'banners': [],
                    'showcase': [
                        {'instances': [
                            {'update_service_url': mock_url,
                             'name': 'CIS',
                             'application_id': 'WOT.RU.PRODUCTION'},
                            {'update_service_url': mock_url,
                             'name': 'Europe',
                             'application_id': 'WOT.EU.PRODUCTION'},
                            {'update_service_url': mock_url,
                             'name': 'North America',
                             'application_id': 'WOT.NA.PRODUCTION'},
                            {'update_service_url': mock_url,
                             'name': 'Asia',
                             'application_id': 'WOT.SG.PRODUCTION'}
                        ],
                            'logo': cls.download_template % 'wot_logo.png',
                            'game_name': "WOT",
                            'background_tile': cls.download_template % 'wot_tile.jpg',
                            'hover_tile': cls.download_template % 'wot_art.jpg',
                            'sort': 3},
                        {'instances': [
                            {'update_service_url': wowp_update_url,
                             'name': 'CIS',
                             'application_id': 'WOWP.RU.PRODUCTION'},
                            {'update_service_url': wowp_update_url,
                             'name': 'Europe',
                             'application_id': 'WOWP.EU.PRODUCTION'},
                            {'update_service_url': wowp_update_url,
                             'name': 'North America',
                             'application_id': 'WOWP.NA.PRODUCTION'},
                            {'update_service_url': wowp_update_url,
                             'name': 'Asia',
                             'application_id': 'WOWP.SG.PRODUCTION'}
                        ],
                            'logo': cls.download_template % 'wowp_logo.png',
                            'game_name': "WOWP",
                            'background_tile': cls.download_template % 'wowp_tile.jpg',
                            'hover_tile': cls.download_template % 'wowp_art.jpg',
                            'sort': 2},
                        {'instances': [
                            {'update_service_url': wows_update_url,
                             'name': 'CIS',
                             'application_id': 'WOWS.RU.PRODUCTION'},
                            {'update_service_url': wows_update_url,
                             'name': 'Europe',
                             'application_id': 'WOWS.EU.PRODUCTION'},
                            {'update_service_url': wows_update_url,
                             'name': 'North America',
                             'application_id': 'WOWS.NA.PRODUCTION'},
                            {'update_service_url': wows_update_url,
                             'name': 'Asia',
                             'application_id': 'WOWS.SG.PRODUCTION'}
                        ],
                            'logo': cls.download_template % 'wows_logo.png',
                            'game_name': "WOWS",
                            'background_tile': cls.download_template % 'wows_tile.jpg',
                            'hover_tile': cls.download_template % 'wows_art.jpg',
                            'sort': 1}]}}
        
        if showcase_products:
            games = {}
            for game in showcase_products:
                game_id, update_url = game.split('@')
                if game_id in GameMetadataProtocol.game_id_map:
                    game_name, realm, _ = game_id.split('.')[:3]
                    games.setdefault(game_name, [])
                    games[game_name].append({'update_service_url': update_url,
                                             'name': realm,
                                             'application_id': game_id})
            
            products = []
            for game_name, game_data in games.items():
                if game_name not in ['WOT', 'WOWP', 'WOWS']:
                    products.append(
                        {'instances': game_data,
                         'game_name': game_name,
                         'logo': cls.download_template % wgcps_game_images.get(game_name.upper(), {}).get('logo'),
                         'background_tile': cls.download_template % wgcps_game_images.get(game_name.upper(), {}).get(
                             'tile'),
                         
                         'hover_tile': cls.download_template % wgcps_game_images.get(game_name.upper(), {}).get('art'),
                         'sort': 1})
            
            content['data']['showcase'] += products
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def content_showroom_ct(cls, request):
        mock_url = cls.game_update_url
        content = {
            'status': 'ok',
            'data':
                {'banners': [],
                 'showcase': [
                     {'instances': [
                         {'update_service_url': mock_url,
                          'realm_id': 'RU',
                          'application_id': 'WOT.RU.PRODUCTION'},
                         {'update_service_url': mock_url,
                          'realm_id': 'EU',
                          'application_id': 'WOT.EU.PRODUCTION'},
                         {'update_service_url': mock_url,
                          'realm_id': 'NA',
                          'application_id': 'WOT.NA.PRODUCTION'},
                         {'update_service_url': mock_url,
                          'realm_id': 'ASIA',
                          'application_id': 'WOT.SG.PRODUCTION'}
                     ],
                         'logo': cls.download_template % 'wot_logo.png',
                         'background_tile': cls.download_template % 'wot_tile.jpg',
                         'hover_tile': cls.download_template % 'wot_art.jpg',
                         'sort': 3}]}}
        return web.json_response(content, status=200, content_type='application/json')
    
    @classmethod
    async def content_user_notifications(cls, request):
        return cls._content_user_notifications(request)
    
    @classmethod
    async def content_news_notifications(cls, request):
        return cls._content_news_notifications(request)
    
    @classmethod
    def _content_user_notifications(cls, request):
        notifications = [] or cls.user_notifications
        data = {
            "status": "ok",
            "meta": {
                "language": request.query.get('lang')},
            "data": {
                "notifications": notifications
            }
        }
        return web.json_response(data)
    
    @classmethod
    def _content_news_notifications(cls, request):
        news = []
        for message, link in cls.news_messages.items():
            RequirementHelper.append_requirement('LLR.2.77')
            news.append({
                "message": message,
                "link": link
            })
        app_id = lang = 'NULL'
        if cls.custom_app_id_news_messages is None:
            data = dict(request.query)
            if 'publisher_id' in data.keys():
                del data['publisher_id']
            if 'wgc_publisher_id' in data.keys():
                del data['wgc_publisher_id']
            for k, v in data.items():
                app_id = k
                lang = v.lower()
        else:
            RequirementHelper.append_requirement('LLR.2.77')
            app_id = cls.custom_app_id_news_messages
            lang = 'ru'
        result = {
            "status": "ok",
            "data": {
                app_id: {
                    lang: {
                        "news": news
                    }
                }
            }
        }
        return web.json_response(result, status=200)
    
    @classmethod
    async def content_resources(cls, request):
        return cls._content_resources(request)
    
    @classmethod
    def _content_resources(cls, request):
        response = {
            'status': 'ok',
            'data': {
                "resources": [
                    {"size": 742577,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('icon.ico')),
                     "url": cls.download_template % 'icon.ico',
                     "name": "icon"
                     },
                    {"size": 8095,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('small_logo.png')),
                     "url": cls.download_template % 'small_logo.png',
                     "name": "small_logo"
                     },
                    {"size": 34378,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_disabled.png')),
                     "url": cls.download_template % 'tray_menu_icon_disabled.png',
                     "name": "tray_menu_icon_disabled"
                     },
                    {"size": 35217,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_hover.png')),
                     "url": cls.download_template % 'tray_menu_icon_hover.png',
                     "name": "tray_menu_icon_hover"
                     },
                    {"size": 34727,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_normal.png')),
                     "url": cls.download_template % 'tray_menu_icon_normal.png',
                     "name": "tray_menu_icon_normal"
                     },
                    {"size": 117624,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('notification_icon.png')),
                     "url": cls.download_template % 'notification_icon.png',
                     "name": "notification_icon"
                     },
                    {"size": 181043,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('background.jpg')),
                     "url": cls.download_template % 'background.jpg',
                     "name": "background"
                     },
                    {"size": 36868,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('background_blurred.jpg')),
                     "url": cls.download_template % 'background_blurred.jpg',
                     "name": "background_blurred"
                     },
                    {"size": 1152,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('game.css')),
                     "url": cls.download_template % 'game.css',
                     "name": "game_css"}]}}
        return web.json_response(response, status=200, content_type='application/json', headers={
            'etag': '77431f5fcf1c5eeb372c91896c06c15a'})
    
    @classmethod
    async def custom_mock(cls, request):
        await asyncio.sleep(.7)
        custom_survey = 'wgc://run/take-survey/?url=https%3A%2F%2F127.0.0.1%3A7771%2Fcustom_survey%2F&dump-wgc-info'
        if GameMocks.news_production:
            with open(path.join(path.dirname(
                    __file__), 'news_prod.html'), 'r', encoding='utf-8') as fp:
                content = fp.read()
        else:
            with open(path.join(path.dirname(
                    __file__), 'wgc_news.html'), 'r', encoding='utf-8') as fp:
                content = fp.read() % {'open_dd': GameMocks.open_dd_url, 'custom_survey': custom_survey}
        resp = web.Response(text=content, status=200, content_type='text/html')
        exp_date = (datetime.datetime.now() + datetime.timedelta(seconds=120)).strftime(
            "%a, %d %b %Y %H:%M:%S -0000")
        if request.cookies.get('cookie_exp_short') is None:
            resp.set_cookie('cookie_exp_short', str(random.random()),
                            expires=exp_date, httponly=True)
        if request.cookies.get('cookie_exp_long') is None:
            result = ''.join([random.choice(
                string.ascii_letters + string.digits) for _ in range(32)])
            resp.set_cookie('cookie_exp_long', result, expires=exp_date, httponly=True)
        return resp
    
    @classmethod
    async def custom_survey(cls, request):
        with open(path.join(path.dirname(__file__), 'custom_survey', 'index.html'), 'r', encoding='utf-8') as fp:
            content = fp.read()
        return web.Response(text=content, status=200, content_type='text/html')
    
    @classmethod
    async def daily_deals(cls, request):
        with open(path.join(path.dirname(__file__), 'daily_deals', 'index.html'), 'r', encoding='utf-8') as fp:
            content = fp.read()
        return web.Response(text=content, status=200, content_type='text/html')
    
    @classmethod
    async def cn360js(cls, request):
        with open(path.join(path.dirname(__file__), 'cn360.js'), 'r', encoding='utf-8') as fp:
            content = fp.read()
        return web.Response(text=content, status=200, content_type='application/javascript')
    
    @classmethod
    async def cn360qr_js(cls, request):
        with open(path.join(path.dirname(__file__), 'cn360qr.js'), 'r', encoding='utf-8') as fp:
            content = fp.read()
        return web.Response(text=content, status=200, content_type='application/javascript')
    
    @classmethod
    async def cn360qr(cls, request):
        state = request.query.get('state')
        if not state:
            return web.Response(text="Error 'state' missing.", status=400)
        
        cls.cn360qr_state = state
        token = '319061402015bfe644de8a6387a234197d5aae6e0ced6abe06'
        base_64 = base64.b64encode(f"--login-cn360 --token {token} --state {state}".encode()).decode()
        login_link = f"wgc360://run/?cmd={base_64}"

        try:
            template_path = path.join(path.dirname(__file__), 'cn360qr.html')
            with open(template_path, 'r', encoding='utf-8') as fp:
                content = fp.read() % login_link
        except FileNotFoundError:
            return web.Response(text="Error: template file not found.", status=500)
        except KeyError:
            return web.Response(text="Error: the template is missing a placeholder {login_link}.", status=500)
        return web.Response(text=content, status=200, content_type='text/html')
    
    @classmethod
    async def daily_deals_js(cls, request):
        with open(path.join(path.dirname(__file__), 'daily_deals', 'index.js'), 'r', encoding='utf-8') as fp:
            content = fp.read() % cls.storefront_name_for_dd
        return web.Response(text=content, status=200, content_type='application/javascript')
    
    @classmethod
    async def overlay(cls, request):
        with open(path.join(path.dirname(__file__), 'overlay', 'index.html'), 'r', encoding='utf-8') as fp:
            content = fp.read() % str(uuid.uuid4())
        return web.Response(text=content, status=200, content_type='text/html')
    
    @classmethod
    async def overlay_js(cls, request):
        with open(path.join(path.dirname(__file__), 'overlay', 'overlay.js'), 'r', encoding='utf-8') as fp:
            content = fp.read() % cls.storefront_name_for_dd
        return web.Response(text=content, status=200, content_type='application/javascript')

    @classmethod
    async def content_installed_game(cls, request):
        return cls._content_installed_game(request)

    @classmethod
    def _content_installed_game(cls, request):
        gallery = [
            {
                "type": "video",
                "url": "https://youtube.com/watch?v=d8bCu5iMtBw"
            },
            {
                "type": "image",
                "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item2.jpeg"
            },
            {
                "type": "image",
                "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item3.jpeg"
            },
            {
                "type": "image",
                "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item4.jpeg"
            }
        ]
        media = {
            "image_main": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_main.png",
            "image_2_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_2_1_shop.png",
            "image_2_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_2_1_overriden.png",
            "image_2_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_2_1.png",
            "image_1_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_1_1_shop.png",
            "image_1_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_1_1.png",
            "image_1_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/image_1_1_overriden.png",
            "background_image": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_bg.jpeg"
        }
        if cls.item_size == '300x300':
            media = {
                "image_main": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_2_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_2_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_2_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_1_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_1_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "image_1_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png",
                "background_image": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/300х300.png"
            }
        if cls.item_size == '248x215':
            media = {
                "image_main": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_2_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_2_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_2_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_1_1_shop": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_1_1": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "image_1_1_overriden": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png",
                "background_image": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/248x215.png"
            }
        for k, v in cls.item_display_media_map.items():
            if not v:
                del media[k]
        
        if cls.installed_game_from_json:
            with open(path.join(path.dirname(
                    __file__), 'installed_game.json'), 'r', encoding='utf-8') as fp:
                response = json.loads(fp.read() % WGCConfig.mocks.https_port)
        else:
            shop_list_content = [
                {
                    "name": "PREMIUM ITEM 1",
                    "image": 'https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_grid.png',
                    "link": f"https://{GameMocks.host_https}/shop/wot/premium/10120/",
                    "starting": int(time()) - 1,
                    "promotion_text": cls.item_promotion_text,
                    "nation": "",
                    'item_id': 999999,
                    "gallery": gallery,
                    "entitlements": [{
                        "vehicle_type": "heavyTank",
                        "type": cls.item_type,
                        "quantity": 0,
                        "nation": "usa",
                        "name": "PREMIUM ITEM 1",
                        "level": 8,
                        "crew_level": 100,
                        "compensation": 10600,
                        "cd": "9217",
                        "bonus_slot": 0,
                        "bonus_general": False,
                        "bonus_crew": 1,
                        "action_name": "PREMIUM ITEM 1",
                        "action_id": 4517
                    }],
                    "package_content_html": cls.item_package_content,
                    "show_custom_package_content": cls.item_show_custom_package_content,
                    "sale_price": None,
                    "price": cls.item_price_property,
                    "finishing": cls.item_finishing_property,
                    "currency": "UAH",
                    "big_image": None,
                    "description": "Test",
                    "background_image": cls.item_background_image,
                    "image_overridden": cls.item_image_overridden,
                    "media": media
                },
                {
                    "image": 'https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_grid.png',
                    "link": f"https://{GameMocks.host_https}/shop/wot/premium/10120/",
                    "name": "PREMIUM ITEM 2",
                    "starting": int(time()) - 1,
                    "promotion_text": cls.item_promotion_text,
                    "nation": "",
                    'item_id': 999999,
                    "gallery": gallery,
                    "entitlements": [{
                        "vehicle_type": "heavyTank",
                        "type": cls.item_type,
                        "quantity": 0,
                        "nation": "usa",
                        "name": "PREMIUM ITEM 2",
                        "level": 8,
                        "crew_level": 100,
                        "compensation": 10600,
                        "cd": "9217",
                        "bonus_slot": 0,
                        "bonus_general": False,
                        "bonus_crew": 1,
                        "action_name": "PREMIUM ITEM 2",
                        "action_id": 4517
                    }],
                    "package_content_html": cls.item_package_content,
                    "show_custom_package_content": cls.item_show_custom_package_content,
                    "sale_price": None,
                    "price": cls.item_price_property,
                    "finishing": cls.item_finishing_property,
                    "currency": "UAH",
                    "big_image": None,
                    "description": "Test",
                    "background_image": cls.item_background_image,
                    "image_overridden": cls.item_image_overridden,
                    "media": media
                }]
            item_settings = {
                "item_background_color": "#ffffff",
                "data_source": cls.shop_data_source,
                "main_item_background": cls.download_template % 'left_prem.png',
                "secondary_item_background": cls.download_template % 'right_prem.png'
            }
            if request.query.get('lang', '').lower() == 'pl':
                item_settings = None
                shop_list_content = None
            included_info = ["age_ratings"] if cls.show_age_ratings else None
            response = {'status': 'ok',
                        'data': {
                            "info": {
                                "shop": {
                                    "item_settings": item_settings,
                                    "number_of_items": 2,
                                    "items": shop_list_content
                                },
                                'age_ratings': [{
                                    "image": {
                                        "url": "https://lx-dwd.pershastudia.com/test_artifacts/test_data/"
                                               "cs_images/age_rating_414x200.png",
                                        "width": 414,
                                        "height": 200
                                    },
                                    "link": "http://legal.eu.wargaming.net/?EULA"
                                }],
                                "server_current_time": int(time()),
                                "layout_name": cls.content_layout_name,
                                "social_links": [{"link": "http://www.google.com", "id": "facebook"}],
                                "available_locales": [
                                    "ru", "en", 'pl', 'pt_br'
                                ],
                                "external_links": [{"text": "Forum", "link": "http://www.google.com"},
                                                   {"text": "Not Forum", "link": "http://www.google.com"}],
                                "quick_start": True,
                                "patch_notes": None,
                                "news_show_inside": cls.news_show_inside,
                                "current_locale": cls.default_language,
                            },
                            "layout": {
                                "content": [
                                    {
                                        "content": [
                                            {
                                                "content": {
                                                    "image": cls.download_template % 'main.jpg',
                                                    "link": cls.main_news_link,
                                                    "text_line1": "Wargaming Game Center",
                                                    "text_line2": "Let's get ready to Rumble!",
                                                    "show_inside": not cls.news_layout_external_link
                                                    
                                                },
                                                "margin": [
                                                    0,
                                                    0,
                                                    3,
                                                    0
                                                ],
                                                "name": "news_main",
                                                "size": 76.6,
                                                "type": "block",
                                                "included_info": included_info
                                            },
                                            {
                                                "content": [
                                                    {
                                                        "content": {
                                                            "image": cls.download_template % 'left_prem.png',
                                                            "title": None,
                                                            "link": {
                                                                "add_utm_mark": cls.add_utm_mark,
                                                                "url": cls.left_premium_banner_url
                                                            }
                                                        },
                                                        "margin": [
                                                            0,
                                                            3.52,
                                                            0,
                                                            0
                                                        ],
                                                        "name": "content_banner",
                                                        "size": 48.24,
                                                        "type": "block"
                                                    },
                                                    {
                                                        "content": {
                                                            "image": cls.download_template % 'right_prem.png',
                                                            "title": None,
                                                            "link": {
                                                                "add_utm_mark": cls.add_utm_mark,
                                                                "url": cls.right_premium_banner_url
                                                            }
                                                        },
                                                        "margin": [
                                                            0,
                                                            0,
                                                            0,
                                                            0
                                                        ],
                                                        "name": "content_banner",
                                                        "size": 48.24,
                                                        "type": "block"
                                                    }
                                                ],
                                                "margin": [
                                                    0,
                                                    0,
                                                    0,
                                                    0
                                                ],
                                                "size": 20.4,
                                                "type": "hlayout"
                                            }
                                        ],
                                        "margin": [
                                            0,
                                            1.431,
                                            0,
                                            0
                                        ],
                                        "size": 43.558,
                                        "type": "vlayout"
                                    },
                                    {
                                        "content": [
                                            {
                                                "content": {
                                                    "link": "http://www.google.com",
                                                    "text": "Спасибо что обратили внимание"
                                                },
                                                "margin": [
                                                    0,
                                                    0,
                                                    3,
                                                    0
                                                ],
                                                "name": "support_message",
                                                "size": 40.77,
                                                "type": "block"
                                            },
                                            {
                                                "external": cls.wgcps_content_enabled,
                                                "margin": [
                                                    0,
                                                    0,
                                                    0,
                                                    0
                                                ],
                                                "name": "shop_list",
                                                "size": 56.23,
                                                "type": "block"
                                            }
                                        ],
                                        "margin": [
                                            0,
                                            0,
                                            0,
                                            0
                                        ],
                                        "size": 23.31,
                                        "type": "vlayout"
                                    },
                                    {
                                        "content": [
                                            {
                                                "content": [],
                                                "margin": [
                                                    0,
                                                    0,
                                                    4.5,
                                                    0
                                                ],
                                                "name": "news_list",
                                                "size": 59.44,
                                                "type": "block"
                                            },
                                            {
                                                "content": {
                                                    "image": cls.download_template % 'secondary.jpg',
                                                    "video": {
                                                        "id": "99840211",
                                                        "source": "vimeo",
                                                        "type": "video"
                                                    }
                                                },
                                                "margin": [
                                                    0,
                                                    0,
                                                    0,
                                                    0
                                                ],
                                                "name": "news_banner",
                                                "size": 36.05,
                                                "type": "block"
                                            }
                                        ],
                                        "margin": [
                                            0,
                                            0,
                                            0,
                                            1.431
                                        ],
                                        "size": 30.266,
                                        "type": "vlayout"
                                    }
                                ],
                                "margin": [
                                    0,
                                    0,
                                    0,
                                    0
                                ],
                                "size": 100,
                                "type": "hlayout"
                            }
                        }}
            if cls.installed_game_news_layout:
                response = {'status': 'ok',
                            'data': {
                                "info": {
                                    "shop": {
                                        "item_settings": {
                                            "item_background_color": "#ffffff",
                                            "data_source": cls.shop_data_source,
                                            "main_item_background": cls.download_template % 'left_prem.png',
                                            "secondary_item_background": cls.download_template % 'right_prem.png'
                                        },
                                        "number_of_items": 2,
                                        "items": shop_list_content
                                    },
                                    "age_ratings": {
                                        "image": {
                                            "url": "https://lx-dwd.pershastudia.com/test_artifacts/"
                                                   "test_data/cs_images/age_rating_414x200.png",
                                            "width": 414,
                                            "height": 200
                                        },
                                        "link": "http://legal.eu.wargaming.net/?EULA"
                                    },
                                    "available_locales": [
                                        "ru",
                                        "en",
                                    ],
                                    "quick_start": True,
                                    "social_links": [{"link": "http://www.google.com", "id": "facebook"}],
                                    "external_links": [
                                        {"text": "Forum", "link": "http://www.google.com"},
                                        {"text": "Not Forum", "link": "http://www.google.com"}],
                                    "current_locale": "ru",
                                    "server_current_time": int(time()),
                                    "layout_name": cls.content_layout_name,
                                    "news_show_inside": cls.news_show_inside,
                                    "patch_notes": None,
                                },
                                "layout": {
                                    "content": [
                                        {
                                            "content": [
                                                {
                                                    "included_info": included_info,
                                                    "name": "news_carousel",
                                                    "type": "block",
                                                    "content": [
                                                        {
                                                            "show_inside": not cls.news_layout_external_link,
                                                            "image": "http://static.wguscs-wotkis74.kdo.space/filer_public/e4/63/e4639a0b-6d64-4c7c-83a2-e6eeab181151/1.png",
                                                            "link": "https://worldoftanks.ru/ru/news/",
                                                            "support_login": cls.news_layout_support_login,
                                                            "title": "News Autmation 1",
                                                        },
                                                        {
                                                            "show_inside": not cls.news_layout_external_link,
                                                            "image": "http://static.wguscs-wotkis74.kdo.space/filer_public/b4/a6/b4a674a8-17fb-4b94-a568-214d49ff9185/2.png",
                                                            "link": "https://worldoftanks.ru/ru/news/",
                                                            "support_login": cls.news_layout_support_login,
                                                            "title": "News Autmation 2",
                                                        }
                                                    ],
                                                    "margin": [0, 0, 3, 0],
                                                    "size": 68.589
                                                },
                                                {
                                                    "content": [
                                                        {
                                                            "name": "news_minor",
                                                            "type": "block",
                                                            "content": {
                                                                "support_login": cls.news_layout_support_login,
                                                                "text_line1": "News Test Automation minor news text",
                                                                "image": "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/carusel_background.png",
                                                                "link": "https://worldoftanks.ru/ru/news/",
                                                                "show_inside": not cls.news_layout_external_link,
                                                                "text_line2": "automation",
                                                            },
                                                            "style_class": "news_minor_text_right",
                                                            "extended_type_name": "news_minor_left",
                                                            "margin": [0, 2.537, 0, 0],
                                                            "size": 48.73
                                                        },
                                                        {
                                                            "name": "news_minor",
                                                            "type": "block",
                                                            "content": {
                                                                "support_login": cls.news_layout_support_login,
                                                                "text_line1": "News Test Automation minor news text",
                                                                "image": "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/carusel_background.png",
                                                                "link": "https://worldoftanks.ru/ru/news/",
                                                                "show_inside": not cls.news_layout_external_link,
                                                                "text_line2": "automation",
                                                            },
                                                            "style_class": "news_minor_text_right",
                                                            "extended_type_name": "news_minor_right",
                                                            "margin": [0, 0, 0, 0],
                                                            "size": 48.73
                                                        }
                                                    ],
                                                    "margin": [0, 0, 0, 0],
                                                    "type": "hlayout",
                                                    "size": 28.411
                                                }
                                            ],
                                            "margin": [0, 1.431, 0, 0],
                                            "type": "vlayout",
                                            "size": 68.299
                                        },
                                        {
                                            "content": [],
                                            "margin": [0, 0, 0, 0],
                                            "type": "block",
                                            "name": "news_list",
                                            "size": 30.266
                                        }
                                    ],
                                    "type": "hlayout",
                                    "margin": [0, 0, 0, 0],
                                    "size": 100
                                }
                            }}
            
            if cls.installed_game_15_layout:
                response = {
                    'status': 'ok',
                    'data': {
                        "info": {
                            'age_ratings': [{
                                "image": {
                                    "url": "https://lx-dwd.pershastudia.com/test_artifacts/test_data/"
                                           "cs_images/age_rating_414x200.png",
                                    "width": 414,
                                    "height": 200
                                },
                                "link": "http://legal.eu.wargaming.net/?EULA"
                            }],
                            "shop": {
                                "item_settings": item_settings,
                                "number_of_items": 2,
                                "items": shop_list_content
                            },
                            "server_current_time": int(time()),
                            "layout_name": cls.content_layout_name,
                            "social_links": [{"link": "http://www.google.com", "id": "facebook"}],
                            "available_locales": [
                                "ru", "en", 'pl', 'pt_br'
                            ],
                            "external_links": [{"text": "Forum", "link": "http://www.google.com"},
                                               {"text": "Not Forum", "link": "http://www.google.com"}],
                            "quick_start": True,
                            "patch_notes": None,
                            "news_show_inside": cls.news_show_inside,
                            "current_locale": cls.default_language,
                        },
                        "layout": {
                            "content": [
                                {
                                    "content": [
                                        {
                                            "included_info": included_info,
                                            "name": "news_main",
                                            "type": "block",
                                            "content": {
                                                "text_line1": 'Automation Major News',
                                                "support_login": cls.news_layout_support_login,
                                                "image": "http://lx-dwd.pershastudia.com/test_artifacts/test_data"
                                                         "/cs_images/carusel_background.png",
                                                "link": cls.main_news_link,
                                                "show_inside": not cls.news_layout_external_link,
                                                "text_line2": 'automation'
                                            },
                                            "margin": [
                                                0,
                                                0,
                                                3,
                                                0
                                            ],
                                            "size": 51.29,
                                            "extended_type_name": "news_main_801x286"
                                        },
                                        {
                                            "content": [
                                                {
                                                    "name": "shop_list",
                                                    "type": "block",
                                                    "extended_type_name": "shop_extended_image",
                                                    "style_class": "shop_extended_image",
                                                    "external": True,
                                                    "margin": [
                                                        0,
                                                        2.096,
                                                        0,
                                                        0
                                                    ],
                                                    "size": 63.772
                                                },
                                                {
                                                    "content": [
                                                        {
                                                            "name": "placeholder",
                                                            "type": "block",
                                                            "content": [
                                                            
                                                            ],
                                                            "margin": [
                                                                0,
                                                                0,
                                                                6.103,
                                                                0
                                                            ],
                                                            "size": 46.9485,
                                                            "extended_type_name": "content_banner1_228x100"
                                                        },
                                                        {
                                                            "name": "placeholder",
                                                            "type": "block",
                                                            "content": [
                                                            
                                                            ],
                                                            "margin": [
                                                                0,
                                                                0,
                                                                0,
                                                                0
                                                            ],
                                                            "size": 46.9485,
                                                            "extended_type_name": "content_banner2_228x100"
                                                        }
                                                    ],
                                                    "type": "vlayout",
                                                    "margin": [
                                                        0,
                                                        0,
                                                        0,
                                                        0
                                                    ],
                                                    "size": 34.132
                                                }
                                            ],
                                            "margin": [0, 0, 0, 0],
                                            "type": "hlayout",
                                            "size": 45.71
                                        }
                                    ],
                                    "margin": [0, 1.431, 0, 0],
                                    "type": "vlayout",
                                    "size": 68.303
                                },
                                {
                                    "content": [],
                                    "margin": [0, 0, 0, 0],
                                    "type": "block",
                                    "name": "news_list",
                                    "size": 30.266
                                }
                            ],
                            "margin": [0, 0, 0, 0],
                            "type": "hlayout",
                            "size": 100
                        }}}
            if 'category_id' in request.query.keys():
                response['status'] = 'errors'
                response['errors'] = [
                    {
                        'text': "null category is not found, returns default category",
                        'code': "not_found",
                        'parameter': "category_id"
                    }
                ]
            titles = ["Вы не поверите что обнаружили у...", "Скидки 80% на гречку", "Бесплатная раздача на 1XBet",
                      "Как бросить пить за неделю..", "НЛО на позняках похитило...", "Как начать пить за 1день.."]
            for news in range(15):
                if not cls.installed_game_news_layout:
                    if not cls.installed_game_15_layout:
                        response['data']['layout']['content'][2]['content'][0]['content'].append(
                            {"finishing": None,
                             "id": random.randint(0, 9999999999),
                             "link": cls.regular_news_link,
                             "pinned": False,
                             "starting": None,
                             "title": titles[random.randint(0, 5)],
                             "type": "basic",
                             "show_inside": cls.regular_news_show_inside})
                    else:
                        response['data']['layout']['content'][1]['content'].append(
                            {"finishing": None,
                             "id": random.randint(0, 9999999999),
                             "link": cls.regular_news_link,
                             "pinned": False,
                             "starting": None,
                             "title": titles[random.randint(0, 5)],
                             "type": "basic",
                             "show_inside": cls.regular_news_show_inside})
                else:
                    if cls.install_game_main_news_layout:
                        response['data']['layout']['content'][0]['content'][0] = {
                            "included_info": included_info,
                            "name": "news_main",
                            "type": "block",
                            "content": {
                                "text_line1": 'Automation Major News',
                                "support_login": cls.news_layout_support_login,
                                "image": "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/carusel_background.png",
                                "link": cls.main_news_link,
                                "show_inside": not cls.news_layout_external_link,
                                "text_line2": 'automation'
                            },
                            "margin": [0, 0, 3, 0],
                            "size": 76.6
                        }
                    else:
                        if cls.news_layout_support_login is None:
                            try:
                                del response['data']['layout']['content'][0]['content'][0]['content'][0][
                                    'support_login']
                                del response['data']['layout']['content'][0]['content'][0]['content'][1][
                                    'support_login']
                            except KeyError:
                                pass
                    response['data']['layout']['content'][1]['content'].append(
                        {"finishing": None,
                         "id": random.randint(0, 9999999999),
                         "link": f"{cls.content_service_host}/custom_mock/",
                         "pinned": False,
                         "starting": None,
                         "title": titles[random.randint(0, 5)],
                         "type": "basic",
                         "show_inside": True})
        
        return web.json_response(response, status=200, content_type='application/json')
    
    @classmethod
    def add_content_service_routes(cls, mock_instance):
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/resources/',
                                lambda *a, **kw: cls.content_resources(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/showroom/',
                                lambda *a, **kw: cls.content_showroom(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/dlc/',
                                lambda *a, **kw: cls.get_content_dlc(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/user_notifications/',
                                lambda *a, **kw: cls.content_user_notifications(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/notifications/',
                                lambda *a, **kw: cls.content_news_notifications(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/not_installed_game/',
                                lambda *a, **kw: cls.not_installed_game(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/quick_start/',
                                lambda *a, **kw: cls.quick_start(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/features_highlight/',
                                lambda *a, **kw: cls.features_highlight(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/installed_game/',
                                lambda *a, **kw: cls.content_installed_game(*a, **kw))  # noqa
        mock_instance.add_route(r'/incorrect/api/v{api_version:\d{2}}/content/installed_game/',
                                lambda *a, **kw: cls.incorrect_req(*a, **kw))  # noqa
        mock_instance.add_route(r'/custom_mock/', lambda *a, **kw: cls.custom_mock(*a, **kw))
        mock_instance.add_route(r'/daily_deals/', lambda *a, **kw: cls.daily_deals(*a, **kw))
        mock_instance.add_route(r'/daily_deals/index.js', lambda *a, **kw: cls.daily_deals_js(*a, **kw))
        mock_instance.add_route(r'/custom_survey/', lambda *a, **kw: cls.custom_survey(*a, **kw))
        mock_instance.add_route(r'/overlay/', lambda *a, **kw: cls.overlay(*a, **kw))
        mock_instance.add_route(r'/overlay/overlay.js', lambda *a, **kw: cls.overlay_js(*a, **kw))

    @classmethod
    def add_chub_routes(cls, mock_instance):
        mock_instance.add_route(get_content_route, ArsenalGetContent)
        mock_instance.add_route(get_game_resources_route, ArsenalGetGameResources)
        mock_instance.add_route(get_page_route, ArsenalGetPage)
        mock_instance.add_route(get_detailed_content, ArsenalGetDetailedContent)
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/resources/',
                                lambda *a, **kw: cls.content_resources(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/showroom/',
                                lambda *a, **kw: cls.content_showroom(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/dlc/',
                                lambda *a, **kw: cls.get_content_dlc(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/user_notifications/',
                                lambda *a, **kw: cls.content_user_notifications(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/notifications/',
                                lambda *a, **kw: cls.content_news_notifications(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/not_installed_game/',
                                lambda *a, **kw: cls.not_installed_game(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/quick_start/',
                                lambda *a, **kw: cls.quick_start(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/features_highlight/',
                                lambda *a, **kw: cls.features_highlight(*a, **kw))  # noqa
        mock_instance.add_route(r'/cs_{realm:\w{2,6}}/api/v{api_version:\d{2}}/content/installed_game/',
                                lambda *a, **kw: cls.content_installed_game(*a, **kw))  # noqa
        mock_instance.add_route(r'/incorrect/api/v{api_version:\d{2}}/content/installed_game/',
                                lambda *a, **kw: cls.incorrect_req(*a, **kw))  # noqa
        mock_instance.add_route(r'/custom_mock/', lambda *a, **kw: cls.custom_mock(*a, **kw))
        mock_instance.add_route(r'/daily_deals/', lambda *a, **kw: cls.daily_deals(*a, **kw))
        mock_instance.add_route(r'/daily_deals/index.js', lambda *a, **kw: cls.daily_deals_js(*a, **kw))
        mock_instance.add_route(r'/custom_survey/', lambda *a, **kw: cls.custom_survey(*a, **kw))
        mock_instance.add_route(r'/overlay/', lambda *a, **kw: cls.overlay(*a, **kw))
        mock_instance.add_route(r'/overlay/overlay.js', lambda *a, **kw: cls.overlay_js(*a, **kw))
    
    @classmethod
    def enable(cls):
        """
        Enable default game mocks.
        """
        warnings.filterwarnings("ignore")
        log.debug('Enable game mocks.')
        # lambda is needed for further monkey patching
        cls.mock.add_route(r'/monitor', lambda *a, **kw: cls.monitor_events(*a, **kw))
        cls.mock.add_route(r'/api/profile/authorize', lambda *a, **kw: cls.cn360_login(*a, **kw))
        cls.mock.add_route('/api/profile/cn360.js', lambda *a, **kw: cls.cn360js(*a, **kw))
        cls.mock.add_route('/api/profile/cn360qr/cn360qr.js', lambda *a, **kw: cls.cn360qr_js(*a, **kw))
        cls.mock.add_route('/api/profile/cn360qr', lambda *a, **kw: cls.cn360qr(*a, **kw))
        cls.mock.add_route(r'/api/v1/metadata/', lambda *a, **kw: cls.get_metadata(*a, **kw))
        cls.mock.add_route(r'/new_us/api/v1/metadata/', lambda *a, **kw: cls.get_metadata(*a, **kw))
        cls.mock.add_route(r'/api/v2/metadata/', lambda *a, **kw: cls.get_metadata(*a, **kw))
        cls.mock.add_route(r'/new_us/api/v2/metadata/', lambda *a, **kw: cls.get_metadata(*a, **kw))
        cls.mock.add_route(r'/api/v1/patches_chain/', lambda *a, **kw: cls.get_game_patch(*a, **kw))
        cls.mock.add_route(r'/new_us/api/v1/patches_chain/', lambda *a, **kw: cls.get_game_patch(*a, **kw))
        cls.mock.add_route(r'/api/v2/integrity_check/', lambda *a, **kw: cls.get_integrity(*a, **kw))
        cls.mock.add_route(r'/new_us/api/v2/integrity_check/', lambda *a, **kw: cls.get_integrity(*a, **kw))
        cls.mock.add_route(r'/wgc/api/v1/wgc_update/', lambda *a, **kw: cls.get_wgc_patch(*a, **kw))
        cls.mock.add_route(r'/wgc_ct/api/v1/wgc_update/', lambda *a, **kw: cls.get_wgc_patch(*a, **kw))
        cls.mock.add_route(r'/new_us/wgc/api/v1/wgc_update/', lambda *a, **kw: cls.get_wgc_patch(*a, **kw))
        cls.mock.add_route(r'/incorrect/api/v1/patches_chain/', lambda *a, **kw: cls.incorrect_req(*a, **kw))
        cls.mock.add_route(r'/statistic/wgc/{event:\w{1,50}}', lambda *a, **kw: cls.get_statistic(*a, **kw))
        cls.mock.add_route(r'/statistic/realm_{realm:\w{2,6}}/v2/{event:\w{1,50}}',
                           lambda *a, **kw: cls.get_statistic(*a, **kw))
        cls.mock.add_route(r'/statistic_ct/wgc/{event:\w{1,50}}', lambda *a, **kw: cls.get_statistic(*a, **kw))
        cls.mock.add_route(r'/statistic_ct/v2/{event:\w{1,50}}', lambda *a, **kw: cls.get_statistic(*a, **kw))
        cls.mock.add_route(r'/statistic/v2/{event:\w{1,50}}', lambda *a, **kw: cls.get_statistic(*a, **kw))
        cls.add_content_service_routes(cls.mock)
        cls.add_content_service_routes(cls.download_mock)
        
        cls.mock.add_route(captcha_route, Captcha)
        cls.mock.add_route(account_add_route, AccountAdd)
        cls.mock.add_route(account_merge, AccountMerge)
        cls.mock.add_route(account_merge_status, AccountMergeStatus)
        cls.mock.add_route(tfa_email_code_create_route, CreateTFAEmailV3)
        cls.mock.add_route(account_add_status_route, AccountAddStatus)
        cls.mock.add_route(token1_create_route, CreateToken1ByOauth)
        cls.mock.add_route(token1_status_route, CreateToken1Status)
        cls.mock.add_route(token_id_create_route, CreateIDTokenV3)
        cls.mock.add_route(token_id_status_route, CreateIDTokenV3Status)
        cls.mock.add_route(oauth_token_v3_route, CreateOauthTokenV3)
        cls.mock.add_route(oauth_token_v2_route, CreateOauthTokenV2)
        cls.mock.add_route(oauth_token_status_v3_route, OauthTokenStatusV3)
        cls.mock.add_route(oauth_token_status_v2_route, OauthTokenStatusV2)
        cls.mock.add_route(oauth_token_challenge_create_route, GetChallenge)
        cls.mock.add_route(oauth_token_challenge_old_route, GetChallengeOld)
        cls.mock.add_route(oauth_token_verify_route, GetOauthTokenInfo)
        cls.mock.add_route(revoke_token_route, RevokeToken)
        cls.mock.add_route(account_info_v3_route, AccountInfoV3)
        cls.mock.add_route(account_info_v2_route, AccountInfoV2)
        cls.mock.add_route(account_info_token_route, AccountInfoToken)
        cls.mock.add_route(ticket_issue_route, TicketIssue)
        cls.mock.add_route(ticket_consume_route, TicketConsume)
        cls.mock.add_route(sign_game_route, SignGame)
        cls.mock.add_route(sign_token_route, SignToken)
        cls.mock.add_route(registration_route, Registration)
        cls.mock.add_route(settings_view_route, SettingsView)
        cls.mock.add_route(create_external_steam_route, CreateExternalSteam)
        cls.mock.add_route(create_external_steam_status_route, CreateExternalSteamStatus)
        cls.mock.add_route(create_ticket_route, CreateTicket)
        cls.mock.add_route(get_ticket_challenge_route, GetTicketChallenge)
        cls.mock.add_route(check_registration_ticket_status_route, CheckRegistrationTicketStatus)
        cls.mock.add_route(registration_challenge_route, RegistrationChallenge)
        cls.mock.add_route(create_basic_account_route, CreateBasicAccount)
        cls.mock.add_route(check_basic_account_status_route, CheckBasicAccountStatus)
        cls.mock.add_route(check_account_activation_status_route, CheckAccountActivationStatus)
        cls.mock.add_route(check_account_activation_status_token_route, CheckAccountActivationStatusToken)
        cls.mock.add_route(registration_demo_challenge_route, RegistrationChallenge)
        cls.mock.add_route(create_demo_account_route, CreateDemoAccount)
        cls.mock.add_route(check_demo_status_route, CheckDemoStatus)
        
        # WGNP mocks
        cls.mock.add_route(personal_route, Personal)
        cls.mock.add_route(personal_realm_route, PersonalRealm)
        cls.mock.add_route(password_reset_route, PasswordReset)
        cls.mock.add_route(credentials_external_steam_bind_status_route, CredentialsExternalSteamBindStatus)
        cls.mock.add_route(credentials_external_steam_route, CredentialsExternalSteam)
        cls.mock.add_route(credentials_basic_create_challenge_route, CredentialsBasicCreateChallenge)
        cls.mock.add_route(credentials_basic_create_route, CredentialsBasicCreate)
        cls.mock.add_route(credentials_basic_create_status_route, CredentialsBasicCreateStatus)
        cls.mock.add_route(check_credentials_ticket_status_route, CheckCredentialsTicketStatus)
        cls.mock.add_route(credentials_basic_activate_route, CredentialsBasicActivate)
        cls.mock.add_route(check_credentials_activate_ticket_status_route, CheckCredentialsActivateTicketStatus)
        cls.mock.add_route(check_nickname_route, CheckNickname)
        cls.mock.add_route(change_nickname_route, ChangeNickname)
        cls.mock.add_route(check_name_update_ticket_status_route, CheckNameUpdateTicketStatus)
        cls.mock.add_route(change_state_nickname_route, ChangeStateNickname)
        cls.mock.add_route(change_state_nickname_status_route, ChangeStateNicknameStatus)
        cls.mock.add_route(account_teleport_route, AccountTeleport)
        cls.mock.add_route(account_teleport_status_route, AccountTeleportStatus)
        cls.mock.add_route(personal_predict_route, PersonalPredict)
        cls.mock.add_route(personal_predict_status_route, PersonalPredictStatus)
        cls.mock.add_route(signature_route, Signature)
        cls.mock.add_route(signature_token_route, SignatureToken)
        cls.mock.add_route(login_domains_route, LoginDomains)
        cls.mock.add_route(validate_nickname_route, ValidateNickname)
        cls.mock.add_route(validate_nickname_status_route, ValidateNicknameToken)
        
        # WGCPS
        cls.mock.add_route(login_session_route, GetLoginSession)
        cls.mock.add_route(get_items_route, GetItems)
        cls.mock.add_route(steam_external_payment_init_route, SteamExternalPaymentInit)
        cls.mock.add_route(steam_external_payment_commit_route, SteamExternalPaymentCommit)
        cls.mock.add_route(commerce_fetch_product_list_route, CommerceFetchProductList)
        cls.mock.add_route(commerce_fetch_product_list_personal_route, CommerceFetchProductListPersonal)
        cls.mock.add_route(commerce_fetch_storefront_categories_v2_route, CommerceFetchStorefrontCategoriesV2)
        cls.mock.add_route(commerce_fetch_storefront_categories_v7_route, CommerceFetchStorefrontCategoriesV7)
        cls.mock.add_route(fetch_client_payment_methods_route, FetchClientPaymentMethods)
        
        cls.mock.add_route(get_geo_data_route, GetGeoData)
        cls.mock.add_route(get_player_data_route, GetPlayerData)
        cls.mock.add_route(set_billing_address_route, SetBillingAddress)
        cls.mock.add_route(get_account_tsv_method_route, GetAccountTsvMethod)
        cls.mock.add_route(purchase_product_prepare_v2_route, PurchaseProductPrepare)
        cls.mock.add_route(purchase_product_prepare_v3_route, PurchaseProductPrepare)
        cls.mock.add_route(purchase_product_prepare_v7_route, PurchaseProductPrepare)
        cls.mock.add_route(purchase_zero_product_prepare_route, PurchaseZeroProductPrepare)
        cls.mock.add_route(purchase_product_commit_route, PurchaseProductCommit)
        cls.mock.add_route(redeem_bonus_code_v1_route, RedeemBonusCode)
        cls.mock.add_route(redeem_bonus_code_v2_route, RedeemBonusCode)
        cls.mock.add_route(get_full_inventory_route, GetFullInventory)
        cls.mock.add_route(get_product_route, GetProduct)
        cls.mock.add_route(get_game_page_categories_route, GetGamePageCategory)
        cls.mock.add_route(fetch_notification_list_route, FetchNotificationList)
        cls.mock.add_route(incoming_notification_route, IncomingNotification)
        cls.mock.add_route(update_notification_route, UpdateNotification)
        cls.mock.add_route(fetch_product_price_route, FetchProductPrice)
        cls.mock.add_route(fetch_product_personal_route, FetchProductPersonal)
        cls.mock.add_route(redeem_bonus_code_v3_route, RedeemBonusCodeV3)
        
        # CHUBAPI
        cls.add_chub_routes(cls.mock)
        cls.add_chub_routes(cls.download_mock)
        
        # Other
        cls.download_mock.add_route('/websocket/{websocket_path:.*}', WebSocketView)
        cls.download_mock.add_route('/download', lambda *a, **kw: cls.download_file(*a, **kw))
        cls.download_mock.add_route('/api/get_artifacts', lambda *a, **kw: cls.get_artifacts(*a, **kw))
        cls.download_mock.add_route('/wds/{redist}', lambda *a, **kw: cls.redirect(*a, **kw))
        cls.download_mock.add_route('/wds/{realm}/{redist}', lambda *a, **kw: cls.redirect(*a, **kw))
        cls.download_mock.add_route('/wds_not_found/{redist}', lambda *a, **kw: cls.redirect_not_exists(*a, **kw))
        cls.download_mock.add_route('/wds_404/{redist}', lambda *a, **kw: cls.redirect_404(*a, **kw))
        cls.download_mock.add_route('/wds_429/{redist}', lambda *a, **kw: cls.redirect_429(*a, **kw))
        cls.download_mock.add_route('/wds_503/{redist}', lambda *a, **kw: cls.redirect_503(*a, **kw))
        cls.download_mock.add_route('/redist/{redist}', lambda *a, **kw: cls.redist(*a, **kw))
        
        cls.download_mock.add_route('/fetchProductListPersonal/', SteamIntegrationFetchProductListPersonal)
        cls.download_mock.add_route('/steamExternalPaymentInit/', SteamIntegrationExternalPaymentInit)
        cls.download_mock.add_route('/steamExternalPaymentCommit/', SteamIntegrationExternalPaymentCommit)
        
        cls.download_mock.add_route('/custom_mock/', lambda *a, **kw: cls.custom_mock(*a, **kw))
        cls.download_mock.add_route('/daily_deals/', lambda *a, **kw: cls.daily_deals(*a, **kw))
        cls.download_mock.add_route('/daily_deals/index.js', lambda *a, **kw: cls.daily_deals_js(*a, **kw))

        cls.mock.start()
        cls.download_mock.start()
        log.debug('Game mocks were enabled.')
    
    @classmethod
    async def incorrect_req(cls, request):
        return web.Response(status=503)
    
    @classmethod
    def disable(cls):
        """
        Disable default game mocks.
        """
        if cls.mock._is_running:
            log.debug('Disable game mocks.')
            cls.mock.stop()
            cls.download_mock.stop()
            log.debug('Game mocks were disabled.')
    
    @classmethod
    def clear_requests(cls):
        """
        Clears requests.
        """
        cls.mock.mocked_requests = []
        cls.mock.mocked_response = []
        cls.download_mock.mocked_requests = []
        cls.download_mock.mocked_response = []
    
    @classmethod
    def find_response(cls, url_path='/*', query=None, index_greater=None) -> List[MockedResponse]:
        """
        Find specific response by params value and path.

        :param int index_greater: all requests index in array greater that index_greater.
        :param str url_path: relative uri path.
        :param query: query function.
        :return: list of MockedResponse.
        """
        url_path = RegexHelper.convert_wildcard_to_regex(url_path)
        linq = Linqp(
            cls.mock.mocked_response).where(lambda x: re.match(url_path, x.path))
        if query:
            linq = linq.where(query)
        if index_greater:
            linq = linq.where(lambda x: x.event_number > index_greater)
        return linq.select_all()
    
    @classmethod
    def find_requests(cls, url_path='/*', query=None, index_greater=None) -> List[MockedRequest]:
        """
        Find specific requests by params value and path.

        :param int index_greater: all requests index in array greater that index_greater.
        :param str url_path: relative uri path.
        :param query: query function.
        :return: list of MockedRequest.
        """
        if url_path and url_path.startswith('/statistic/'):
            RequirementHelper.append_requirement('INT.5.1')
        if url_path and url_path.startswith('/cs_'):
            RequirementHelper.append_requirement('INT.3.1')
        if url_path and url_path.startswith('/api/v1/patches_chain') or url_path.startswith(
                '/wgc/api/v1/patches_chain'):
            RequirementHelper.append_requirement('INT.2.1')
        if url_path and url_path.startswith('/api/v1/metadata'):
            RequirementHelper.append_requirement('INT.2.2')
        if url_path and url_path.startswith('/api/v1/integrity'):
            RequirementHelper.append_requirement('INT.2.3')
        url_path = RegexHelper.convert_wildcard_to_regex(url_path)
        linq = Linqp(
            cls.mock.mocked_requests).where(lambda x: re.match(url_path, x.path))
        if query:
            linq = linq.where(query)
        if index_greater:
            linq = linq.where(lambda x: x.event_number > index_greater)
        return linq.select_all()
    
    @classmethod
    def find_download_requests(cls, url_path='/*', query=None, index_greater=None) -> List[MockedRequest]:
        """
        Find specific requests by params value and path.

        :param int index_greater: all requests index in array greater that index_greater.
        :param str url_path: relative uri path.
        :param query: query function.
        :return: list of MockedRequest.
        """
        url_path = RegexHelper.convert_wildcard_to_regex(url_path)
        linq = Linqp(
            cls.download_mock.mocked_requests).where(lambda x: re.match(url_path, x.path))
        if query:
            linq = linq.where(query)
        if index_greater:
            linq = linq.where(lambda x: x.event_number > index_greater)
        return linq.select_all()
    
    @classmethod
    async def get_artifacts(cls, request):
        storage = path.join(WGCConfig.temp_folder, 'wgc_meta_files')
        output = path.join(WGCConfig.temp_folder, 'mock_files.7z')
        if not path.isdir(storage):
            makedirs(storage, exist_ok=True)
            version_xml = path.join(WGCConfig.application.folder,
                                    WGCConfig.application.version_file)
            preferences_xml = path.join(WGCConfig.application.folder,
                                        WGCConfig.application.preferences_file)
            wgc_info = path.join(WGCConfig.application.folder,
                                 WGCConfig.application.wgc_info_file)
            if path.isfile(preferences_xml):
                OSHelper.copy(preferences_xml, path.join(
                    storage, WGCConfig.application.preferences_file))
            if path.isfile(version_xml):
                OSHelper.copy(version_xml, path.join(
                    storage, WGCConfig.application.version_file))
            if path.isfile(wgc_info):
                OSHelper.copy(wgc_info, path.join(
                    storage, WGCConfig.application.wgc_info_file))
            if glob.glob(WGCConfig.games.folder + '\\*'):
                SevenZipHelper.zip_folder(WGCConfig.games.folder,
                                          path.join(storage, 'game.zip'), archive_type='zip')
            SevenZipHelper.zip_folder(storage, output, archive_type='zip')
        if path.isfile(output):
            request.query['file'] = str(output.replace('\\', '/'))
            return cls.distribute_file(request)
        return web.Response(status=404, text='Not found')
    
    @classmethod
    async def get_metadata_two_custom_agreements(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'][3]['common_agreements'] = {'agreement': {'@id': 'ru_eula'}}
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'][3]['custom_agreements'] = {
            'agreement': [{'@id': 'dev1_eula', '@url': 'https://agreements.wargaming.net/dev1/',
                           '@show_before_launch': 'true'},
                          {'@id': 'dev1_2_eula', '@url': 'https://agreements.wargaming.net/dev1_2/',
                           '@show_before_launch': 'true'}]}
        resp.text = xmltodict.unparse(metadata_content)
        return resp

    @classmethod
    async def get_metadata_remove_realm(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        idx_to_remove = []
        for index, ins in enumerate(
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance']):
            if ins['platform_realm_id'] == cls.realm_to_remove_from_meta:
                idx_to_remove.append(index)
        for index in idx_to_remove:
            metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'].pop(index)
        resp.text = xmltodict.unparse(metadata_content)
        return resp

    @classmethod
    async def get_metadata_all_wot(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        for index, ins in enumerate(
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance']):
            if ins['game_id'] != 'wot':
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'][index][
                    'game_id'] = 'wot'
        resp.text = xmltodict.unparse(metadata_content)
        return resp

    @classmethod
    async def get_remove_dev2_realm_all_wot(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        idx_to_remove = []
        for index, ins in enumerate(
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance']):
            if ins['platform_realm_id'] == 'dev2':
                idx_to_remove.append(index)
        for index in idx_to_remove:
            metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'].pop(index)
        for index, ins in enumerate(
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance']):
            if ins['game_id'] != 'wot':
                metadata_content['protocol']['predefined_section']['realms_settings']['instances']['instance'][index][
                    'game_id'] = 'wot'
        resp.text = xmltodict.unparse(metadata_content)
        return resp
    
    @classmethod
    async def get_metadata_custom_agreement_for_installation(cls, request):
        resp = cls._get_metadata(request)
        metadata_content = xmltodict.parse(resp.text)
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'][1]['common_agreements'] = {'agreement': {'@id': 'ru_eula'}}
        metadata_content['protocol']['predefined_section']['realms_settings']['instances'][
            'instance'][1]['custom_agreements'] = {
            'agreement': [{'@id': 'dev1_eula', '@url': 'https://agreements.wargaming.net/dev1/',
                           '@show_before_launch': 'true'},
                          {'@id': 'dev1_2_eula', '@url': 'https://agreements.wargaming.net/dev1_2/',
                           '@show_before_launch': 'true'}]}
        resp.text = xmltodict.unparse(metadata_content)
        return resp
