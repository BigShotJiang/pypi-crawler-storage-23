﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import json
import selectors
import traceback
from asyncio import CancelledError
from multiprocessing import Queue
from queue import Empty
from threading import Thread
from json import JSONDecodeError
from time import time
from urllib import parse

from aiohttp import web
from aiohttp.web_exceptions import HTTPMovedPermanently, HTTPFound, HTTPNotFound, HTTPBadRequest
from aiohttp.web_middlewares import middleware
from aiohttp.web_response import Response
from requests import Session

from clippy.helpers.waiter import Waiter
from wgc_core.exceptions import WGCException, MissingParamException
from wgc_core.logger import get_logger

log = get_logger('wgc')
mocks_log = get_logger('mocks')
distribute = get_logger('distribute')


class AioMock(object):
    mocked_requests = []
    mocked_response = []

    def __init__(self, host='127.0.0.1', port=7771, sslcontext=None,
                 enable_franz_callback=False):
        """
        :param str host: hostname and port divided by colon.
        """
        log.debug('Initializing mock at address: %s' % host)
        self._is_running = False
        self._is_franz_running = False
        self._is_testhide_running = False
        self.host = host
        self.port = port
        self.enable_franz_callback = enable_franz_callback
        self.sslcontext = sslcontext
        self.application = web.Application(middlewares=[self.middleware])
        selector = selectors.SelectSelector()
        loop = asyncio.SelectorEventLoop(selector)
        self.loop = loop
        self.queue = Queue()
        self.thread_main = None
        self.count_errors = 0
        self._routing_table = []
        self.queue_frz = Queue()
        self.thread_franz = None
        log.debug('Mock was initialized successfully.')

    def cancel(self, request):
        try:
            request.task.cancel()
        except BaseException as e:
            log.error(f'Cancelling request HTTP: {request.path} -> {e}')

    @middleware
    async def middleware(self, request, handler):
        try:
            resp = await handler(request)
            await self.log_finished_request(request, resp)
            return resp
        except MissingParamException as e:
            log.error(f'[AioMock][middleware] Missing param error: {e}')
            raise HTTPBadRequest(text=str(e))
        except HTTPMovedPermanently as e:
            await self.log_finished_request(request, None)
            raise HTTPFound(e.location)
        except OSError as e:
            log.error(f'OSError: request HTTP: {request.path} -> {e}')
            self.cancel(request)
        except ZeroDivisionError:
            await self.log_finished_request(request, None)
            self.cancel(request)
            return
        except HTTPNotFound:
            await self.log_finished_request(request, None)
            log.error(f'[AioMock][middleware][HTTPNotFound]: {request.path}')
            self.cancel(request)
        except CancelledError:
            self.cancel(request)
        except BaseException as e:
            log.error(f'HTTP: {request.url} -> {e.__class__} {e}')
            tb = ''.join(traceback.format_tb(e.__traceback__))
            log.error(tb)
            self.cancel(request)

    async def log_finished_request(self, request, resp):
        if request.method == 'GET':
            params = dict(request.query)
        else:
            if request.content_type == 'application/json':
                if request.body_exists:
                    try:
                        params = await request.json()
                    except BaseException as e:
                        self.cancel(request)
                        mocks_log.error(f'HTTP: {request.path} -> {e.__class__} {e}')
                        params = {}
                else:
                    params = {}
            else:
                try:
                    post_data = await request.text()
                    try:
                        params = json.loads(post_data)
                    except JSONDecodeError:
                        params = dict(parse.parse_qsl(post_data))
                except BaseException as e:
                    self.cancel(request)
                    mocks_log.error(f'HTTP: {request.path} -> {e.__class__} {e}')
                    params = {}
        if self._is_franz_running and self.enable_franz_callback and '/statistic/v2/' in request.path:
            try:
                self.queue_frz.put({'json': params, 'headers': dict(request.headers), 'path': request.path},
                                   timeout=30)
            except Exception as e:
                log.error(e)
        event_num = len(self.mocked_requests) + 1
        request = MockedRequest(event_num, request.path, params, request.remote,
                                dict(request.headers), dict(request.cookies), request.method)
        self.mocked_requests.append(request)
        if resp is not None and request.path != '/download' and isinstance(resp, Response):
            self.mocked_response.append(
                MockedResponse(request.path, dict(resp.headers), resp.cookies, resp.body, resp.status))
            try:
                data = {
                    "request": {
                        "id": event_num,
                        "remote": str(request.ip),
                        "params": params,
                        "method": request.method,
                        "path": request.path,
                        "headers": dict(request.headers)
                    },
                    "response": {
                        "data": resp.text,
                        "headers": dict(resp.headers),
                        "cookies": dict(resp.cookies),
                        "status": resp.status
                    }
                }
                mocks_log.debug(json.dumps(data))
            except UnicodeDecodeError:
                pass
            except AttributeError:
                pass
        elif request.path == '/download' and isinstance(resp, Response):
            distribute.debug(f'{event_num}. {request.method} {request.path} {dict(request.headers)}')
    
    def franz_callback(self):
        session = Session()
        while self._is_franz_running:
            try:
                request = self.queue_frz.get(timeout=10)
                if not self._is_franz_running:
                    self.queue_frz.close()
                uri = request['path'].replace('/statistic/', '/')
                host = 'https://wgusst-wgcasia.wargaming.net'
                for retry in range(3):
                    try:
                        resp = session.post(host + uri, json=request['json'])
                        log.info(f'{host + uri} return {resp.status_code}')
                        break
                    except Exception as e:
                        log.error(f'FRANZ: {host + uri} with {e}')
                        continue
            except Empty:
                pass
            except Exception as e:
                log.error(e)
        self.thread_franz = None

    def add_route(self, path, handler, method='*'):
        """
        Adds sink.

        :param str method: HTTP method.
        :param path: router path.
        :param handler: handler for HTTP request.
        """
        # lambda is needed for further monkey patching
        if path not in self._routing_table:
            if not path.endswith('/'):
                self.application.router.add_route(method, path + '/', handler)
                self.application.router.add_route(method, path, handler)
            else:
                self.application.router.add_route(method, path, handler)
                self.application.router.add_route(method, path[:-1], handler)
            self._routing_table.append(path)

    async def prepare_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.set_debug(True)
        runner_https = web.AppRunner(self.application)
        try:
            await runner_https.setup()
            site_https = web.TCPSite(runner_https, self.host, int(self.port),
                                     ssl_context=self.sslcontext, shutdown_timeout=120, backlog=200)
            await site_https.start()
            while self._is_running:
                await asyncio.sleep(1)
        except BaseException as e:
            log.error(e)
        finally:
            log.debug('finally cleanup http mock server')
            try:
                await runner_https.cleanup()
            except BaseException:
                pass

    def start_server(self):
        try:
            self.loop.run_until_complete(self.prepare_loop())
        except BaseException as e:
            log.error(e)
        finally:
            log.debug('close loop http mock server')
            if not self.loop._closed:
                self.loop.run_until_complete(self.loop.shutdown_asyncgens())

    def start(self):
        """
        Starts mock service.
        """

        if self._is_running:
            raise WGCException(f'MockService is already running on host {self.host}, port={self.port}.')

        log.debug(f'Starting mocks on host {self.host}, port={self.port}.')

        if not self._is_running:
            self.thread_main = Thread(target=self.start_server)
            self.thread_main.daemon = True
            self._is_running = True
            self.thread_main.start()
        if self.enable_franz_callback and not self._is_franz_running:
            self.thread_franz = Thread(target=self.franz_callback)
            self._is_franz_running = True
            self.thread_franz.daemon = True
            self.thread_franz.start()
        log.debug('Mock was started successfully.')

    def stop(self):
        """
        Stops mock service.
        """
        log.debug(f'Stopping mocks on host {self.host}, port={self.port}.')
        Waiter.poll(5, lambda: self.queue_frz.qsize() == 0)
        self._is_running = False
        if self.thread_main is not None:
            self.thread_main.join(timeout=1)
        if self.thread_franz is not None:
            self._is_franz_running = False
            self.thread_franz.join(timeout=3)
        log.debug('Mock was stopped successfully.')


class MockedRequest(object):
    """
    Class for common request parameters.

    :param str path_: uri path in request.
    :param dict params: parameters in request.
    """

    def __init__(self, event_number, path_, params, ip, headers, cookies, method):
        self.path = path_
        self.params = params
        self.timestamp = time()
        self.ip = ip
        self.headers = headers
        self.cookies = cookies
        self.method = method
        self.event_number = event_number

    def __str__(self):
        return f'<Request "{self.path}">'

    def __repr__(self):
        return self.__str__()


class MockedResponse(object):
    """
    Class for common response parameters.

    :param str path_: uri path in request.
    :param dict params: parameters in request.
    """

    def __init__(self, path_, headers, cookies, body, status):
        self.path = path_
        self.timestamp = time()
        self.headers = headers
        self.cookies = cookies
        self.body = body
        self.status = status

    def __str__(self):
        return f'<Response for "{self.path}">'

    def __repr__(self):
        return self.__str__()
    
    def json(self):
        try:
            return json.loads(self.body)
        except Exception:
            return {}
