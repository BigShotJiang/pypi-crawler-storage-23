const isObject = (obj) => {
    return Object.prototype.toString.call(obj) === '[object Object]';
};

const eventIds = [
    '01787ea1-c852-1301-abbe-b86c99406428',
    '01787ea1-c852-1301-abbe-b86c99406429',
    '01787ea1-c852-1301-abbe-b86c99406430',
    '01787ea1-c852-1301-abbe-b86c99406431'
];

// Listening response from WGC
window.addEventListener("message", (event) => {
    const wgcEvent = isObject(event.data) ? event.data : null;

    if (
        wgcEvent && wgcEvent.src === 'wgc' &&
        eventIds.includes(wgcEvent.id)
    ) {
        console.log('[Iframe] Response from WGC', wgcEvent)
    }
}, false);

function requestOpenDialogWithIframe() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const state = urlParams.get('state');
    window.top.postMessage(
        {
            id: eventIds[3],
            event: 'openDialogWithIframe',
            args: {
                url: 'https://127.0.0.1:7771/api/profile/cn360qr/?state=' + state // test page with Login button
                //url: 'https://profile.wg.360.cn/api/profile/authorize/?state='+state // general china login page
                //url: 'https://worldoftanks.eu' // some website
                //url: 'https://openapi.360.cn/oauth2/authorize?client_id=48d04429e606a7a6f40697a45f111f0a&response_type=code&redirect_uri=https://wgn.wggames.cn/id/signin/external/&scope=basic&display=wot&relogin=360.cn' // redirect from china login page
                //url: 'https://i.360.cn/oauth/loginByOauth?c=weixin&type=pop&destUrl=https%3A%2F%2Fopenapi.360.cn%2F&f=pcw_wargame&r=1694517593555' // wechat qr code
                //url: 'https://i.360.cn/oauth/loginByOauth?c=qq&type=pop&destUrl=https%3A%2F%2Fopenapi.360.cn%2F&f=pcw_wargame&r=1694519801533' // qq qr code
                //url: 'https://i.360.cn/oauth/loginByOauth?c=Sina&type=pop&destUrl=https%3A%2F%2Fopenapi.360.cn%2F&f=pcw_wargame&r=1694520011775' // weibo qr code
                //url: 'https://shorturl.at/msvDG' // redirect
                //url: 'https://api.weibo.com/oauth2/authorize?client_id=3977697501&redirect_uri=http%3A%2F%2Fi.360.cn%2Foauth%2Fcallback%3Fc%3DSina%26type%3Dpop%26destUrl%3Dhttp%253A%252F%252Fi.360.cn&response_type=code&state=6f6a851fdc9ff638a96f30651d26eb60&forcelogin=true###' // link from partners
            }
        },
        '*'
    );
};