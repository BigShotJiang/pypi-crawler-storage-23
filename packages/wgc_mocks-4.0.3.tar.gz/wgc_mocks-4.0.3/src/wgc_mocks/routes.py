# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

# WGNI
captcha_route = r'/realm_{realm:\w{2,6}}/id/captcha/{captcha_id}/'
tfa_email_code_create_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/oauth/token/tfa/email/'
token1_create_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/token1/'
token1_status_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/token1/{token}/'
token_id_create_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/idtoken/'
token_id_status_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/idtoken/{token}/'
oauth_token_v3_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/oauth/token/'
oauth_token_v2_route = r'/realm_{realm:\w{2,6}}/id/api/v2/account/credentials/create/oauth/token/'
oauth_token_status_v3_route = (r'/realm_{realm:\w{2,6}}/id/api/v3/account/credentials/create/oauth/token/{grant:(['
                               r'a-zA-Z0-9-]+)}/{token:\w{32}}/')
oauth_token_status_v2_route = (r'/realm_{realm:\w{2,6}}/id/api/v2/account/credentials/create/oauth/token/{grant:(['
                               r'a-zA-Z0-9-]+)}/{token:\w{32}}/')
oauth_token_challenge_create_route = (r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/account/credentials/create/'
                                      r'oauth/token/challenge/create/')
oauth_token_challenge_old_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/account/credentials/create/' \
                                  r'oauth/token/challenge/'
account_add_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/add/'
account_add_status_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/add/{token}/{gamerealm:\w{2,6}}/{nickname}'
oauth_token_verify_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/account/credentials/verify/oauth/token/'
revoke_token_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/account/credentials/revoke/oauth/token/'
account_info_v3_route = r'/realm_{realm:\w{2,6}}/id/api/v3/account/info/'
account_info_v2_route = r'/realm_{realm:\w{2,6}}/id/api/v2/account/info/'
account_merge = r'/realm_{realm:\w{2,6}}/id/api/v3/account/merge/'
account_merge_status = r'/realm_{realm:\w{2,6}}/id/api/v3/account/merge/{token}/'
account_info_token_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/account/info/{token}/'
# Game
ticket_issue_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/game/ticket/issue/'
ticket_consume_route = r'/realm_{realm:\w{2,6}}/id/api/v{version:\d{1,2}}/game/ticket/consume/'
sign_game_route = r'/realm_{realm:\w{2,6}}/id/signin/game/'
sign_token_route = r'/realm_{realm:\w{2,6}}/id/signin/token/'

# WGNR
registration_route = r'/realm_{realm:\w{2,6}}/registration/'
settings_view_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/settings/'
create_external_steam_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/external/steam/'
create_external_steam_status_route = (
    r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/external/steam/status/{'
    r'token}/')
create_ticket_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/ticket/'
get_ticket_challenge_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/ticket/challenge/'
check_registration_ticket_status_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/ticket/' \
                                         r'status/{token}/'
registration_challenge_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/basic/challenge/'
create_basic_account_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/basic/'
check_basic_account_status_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/basic/' \
                                   r'status/{token}/'
check_account_activation_status_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/' \
                                        r'{account_id}/activation/'
check_account_activation_status_token_route = (r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/{'
                                               r'account_id}/activation/status/{token}/')
registration_demo_challenge_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/demo/' \
                                    r'challenge/'
create_demo_account_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/demo/'
check_demo_status_route = r'/realm_{realm:\w{2,6}}/registration/api/v{version:\d{1,2}}/account/demo/status/{token}/'

# WGNP
personal_route = r'/realm_{realm:\w{2,6}}/personal/'
personal_realm_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/realm/'
password_reset_route = r'/realm_{realm:\w{2,6}}/personal/password_reset/new/'
credentials_external_steam_bind_status_route = (r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/'
                                                r'credentials/external/steam/bind/status/{token}')
credentials_external_steam_route = r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/' \
                                   r'external/steam/'
credentials_basic_create_challenge_route = (
    r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/basic/create'
    r'/challenge/')
credentials_basic_create_route = r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/' \
                                 r'basic/create/'
credentials_basic_create_status_route = (
    r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/basic/create'
    r'/status/{token}/')
check_credentials_ticket_status_route = (r'/realm_{realm:\w{2,6}}/personal/api/v2/account/credentials/basic/status/{'
                                         r'token}/')
credentials_basic_activate_route = r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/' \
                                   r'basic/activate/'
check_credentials_activate_ticket_status_route = (
    r'/realm_{realm:\w{2,6}}/personal/api/v{version:\d{1,2}}/account/credentials/basic'
    r'/activate/status/{token}/')
check_nickname_route = r'/realm_{realm:\w{2,6}}/personal/account/nicknames/{nickname}/'
change_nickname_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/name/update/'
check_name_update_ticket_status_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/name/update/status/{token}/'
change_state_nickname_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/name/update/state/'
change_state_nickname_status_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/name/update/state/status/{token}/'
account_teleport_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/teleport/'
account_teleport_status_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/teleport/status/{token}/'
personal_predict_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/teleport/predict/'
personal_predict_status_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/teleport/predict/status/{token}/'
signature_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/signature/'
signature_token_route = r'/realm_{realm:\w{2,6}}/personal/api/v2/account/signature/{token}/'
login_domains_route = r'/realm_{realm:\w{2,6}}/personal/account/logindomains/'
validate_nickname_route = r'/realm_{realm:\w{2,6}}/personal/api/v3/account/nicknames/validate/'
validate_nickname_status_route = r'/realm_{realm:\w{2,6}}/personal/api/v3/account/nicknames/validate/status/{token}/'

# Auth API
login_session_route = r'/realm_{realm:\w{2,6}}/auth/api/v1/loginSession/'
get_items_route = r'/realm_{realm:\w{2,6}}/shop/api/v1/getItems/'

# Commerce API
steam_external_payment_init_route = r'/realm_{realm:\w{2,6}}/commerce/api/v{version:\d{1,2}}/steamExternalPaymentInit/'
steam_external_payment_commit_route = r'/realm_{realm:\w{2,6}}/commerce/api/v{version:\d{1,2}}/steamExternalPaymentCommit/'
commerce_fetch_product_list_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/fetchProductList/'
commerce_fetch_product_list_personal_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/fetchProductListPersonal/'
commerce_fetch_storefront_categories_v2_route = r'/realm_{realm:\w{2,6}}/commerce/api/v2/fetchStorefrontCategories/'
commerce_fetch_storefront_categories_v7_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/fetchStorefrontCategories/'
fetch_client_payment_methods_route = r'/realm_{realm:\w{2,6}}/commerce/api/v{version:\d{1,2}}/fetchClientPaymentMethods/'
fetch_product_price_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/fetchProductPrice/'
fetch_product_personal_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/fetchProductPricePersonal/'

# Accounts API
get_geo_data_route = r'/realm_{realm:\w{2,6}}/accounts/api/v1/getGeoData/'
set_billing_address_route = r'/realm_{realm:\w{2,6}}/accounts/api/v1/setBillingAddress/'
get_account_tsv_method_route = r'/realm_{realm:\w{2,6}}/accounts/api/v{version:\d{1,2}}/getAccountTsvMethod/'
get_player_data_route = r'/realm_{realm:\w{2,6}}/accounts/api/v1/getPlayerData/'

# Commerce API
purchase_product_prepare_v2_route = r'/realm_{realm:\w{2,6}}/commerce/api/v2/purchaseProductPrepare/'
purchase_product_prepare_v3_route = r'/realm_{realm:\w{2,6}}/commerce/api/v3/purchaseProductPrepare/'
purchase_product_prepare_v7_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/purchaseProductPrepare/'
purchase_zero_product_prepare_route = r'/realm_{realm:\w{2,6}}/commerce/api/v7/purchaseZeroPriceProduct/'
purchase_product_commit_route = r'/realm_{realm:\w{2,6}}/commerce/api/v{version:\d{1,2}}/purchaseProductCommit/'

# Platform API
redeem_bonus_code_v1_route = r'/realm_{realm:\w{2,6}}/platform/api/v1/redeemBonusCode'
redeem_bonus_code_v2_route = r'/realm_{realm:\w{2,6}}/platform/api/v2/redeemBonusCode'
redeem_bonus_code_v3_route = r'/realm_{realm:\w{2,6}}/platform/api/v3/redeemBonusCode'
get_full_inventory_route = r'/realm_{realm:\w{2,6}}/platform/api/v1/getFullInventory/'

# Product API
get_product_route = r'/realm_{realm:\w{2,6}}/product/{product_id}'

# Rules API
get_game_page_categories_route = r'/realm_{realm:\w{2,6}}/rules/api/v1/getGamePageCategories/'

# Notifications API
fetch_notification_list_route = r'/realm_{realm:\w{2,6}}/notifications/api/v1/fetch/'
incoming_notification_route = r'/realm_{realm:\w{2,6}}/notifications/api/v1/incoming/'
update_notification_route = r'/realm_{realm:\w{2,6}}/notifications/api/v1/update/'

# CHUBAPI
feed_route = r'/api/v{version:[12]}/feed'
get_content_route = r'/api/v{version:[12]}/getContent'
get_game_resources_route = r'/api/v{version:[12]}/getGameResources'
get_page_route = r'/api/v{version:[12]}/getPage'
get_detailed_content = r'/api/v{version:[12]}/getDetailedContent'
