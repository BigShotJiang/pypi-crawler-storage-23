﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import uuid

from aiohttp import web, ClientSession, TCPConnector, ContentTypeError

from wgc_core.exceptions import MissingParamException
from wgc_core.logger import get_logger
from wgc_mocks.wgni.storage import WGNIUsersDB

log = get_logger()


class SteamExternalPaymentCommit(web.View):
    """
    External payment commit endpoint.
    """
    
    async def _on_post(self):
        data = await self.request.json()
        
        title = data.get('title')
        
        if not title:
            raise MissingParamException('Missing required param: "title"')
        
        steam_order_id = data.get("body").get("steam_order_id")
        transaction_id = data.get("body").get("transaction_id")
        
        account = WGNIUsersDB.get_account_by_steam_order_id(steam_order_id)
        
        from wgc_helpers.steam_helper import SteamHelper
        key = '7D280FB3CFD94600BBECE06A4E9E85CC'
        data = {
            'key': key,
            'orderid': steam_order_id,
            'appid': SteamHelper.app_id,
        }

        connector = TCPConnector(limit=50, verify_ssl=False)
        async with ClientSession(connector=connector) as session:
            async with session.post('https://partner.steam-api.com/ISteamMicroTxnSandbox/FinalizeTxn/v2/',
                                    data=data) as resp:
                try:
                    result = await resp.json()
                    print(result)
                    log.debug(f'https://partner.steam-api.com/ISteamMicroTxnSandbox/FinalizeTxn/v2/ - return '
                              f'{resp.status} with\n{result}')
                    if resp.status != 200 and result.get('response').get('result') != 'OK':
                        return web.json_response({
                            "status": "error", "data": {
                                "header": {"message-id": "94359179-3e7b-489c-9bdd-eaa04030ce03",
                                           "tracking-id": "3bd6c36a-7dd1-490e-92ab-84e5c2925c8d"}},
                            "errors": [
                                {"code": "platform_error",
                                 "context": {
                                     "result_code": "AUTOMATION_STEAM_INTEGRATION_ERROR"}
                                 }]}, status=500)
                except ContentTypeError:
                    result = await resp.text()
                    print(result)
                    log.debug(f'https://partner.steam-api.com/ISteamMicroTxnSandbox/FinalizeTxn/v2/ - return '
                              f'{resp.status} with\n{result}')
                    return web.json_response({
                        "status": "error", "data": {
                            "header": {"message-id": "94359179-3e7b-489c-9bdd-eaa04030ce03",
                                       "tracking-id": "3bd6c36a-7dd1-490e-92ab-84e5c2925c8d"}},
                        "errors": [
                            {"code": "platform_error",
                             "context": {
                                 "result_code": "AUTOMATION_STEAM_INTEGRATION_ERROR"}
                             }]}, status=500)
                
                orderid = result.get('response').get('params').get('orderid')
                transid = result.get('response').get('params').get('transid')  # noqa
        
        resp = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": str(uuid.uuid4()),
                    "tracking-id": account.current_log_Id or str(uuid.uuid4())
                },
                "body": {
                    "order_id": account.agate_order_id,
                    "steam_order_id": int(orderid),
                    "transaction_id": transaction_id
                }}}
        return web.json_response(resp)
    
    async def post(self):
        return await self._on_post()
