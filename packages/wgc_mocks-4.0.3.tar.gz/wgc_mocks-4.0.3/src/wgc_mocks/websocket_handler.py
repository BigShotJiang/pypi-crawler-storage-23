﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
from os import path

from aiohttp import web, WSMsgType

from wgc_core.logger import get_logger

log = get_logger(__name__)


class WebSocketView(web.View):

    async def get(self):
        from wgc_client import WGCClient
        ws = web.WebSocketResponse(max_msg_size=10 * 1024 * 1024)
        ws_id = self.request.path

        try:
            await ws.prepare(self.request)
        except ConnectionResetError:
            log.error(f'ConnectionResetError: [on_closed_connection] ws_id={ws_id}')
            WGCClient.websocket_clients[ws_id] = None
            return ws
        
        if WGCClient.websocket_clients[ws_id] is None:
            WGCClient.websocket_clients[ws_id] = {'ws': ws, 'messages_storage': {}}
            log.debug(f'Client {ws_id} connection was successfully established')
            with open(path.join(path.dirname(__file__), 'client', 'inject.js'), 'r', encoding='utf-8') as \
                    inject_file:
                inject_file_content = inject_file.read()
                
                if ws_id in WGCClient.websocket_clients.keys():
                    consumer_task = asyncio.ensure_future(
                        WGCClient.websocket_clients[ws_id]['ws'].send_str(
                            f'000000{inject_file_content}, "__INJECTED__"'))
                    done, pending = await asyncio.wait(
                        [consumer_task],
                        return_when=asyncio.FIRST_COMPLETED)
    
                    for task in pending:
                        task.cancel()
                else:
                    log.error(f'Key ERROR {ws_id} not in websocket_clients dict. Connection maybe lost.')
        try:
            async for msg_raw in ws:
                if msg_raw.type == WSMsgType.TEXT:
                    if msg_raw.data == 'close':
                        await ws.close()
                        log.debug(f'WS close message given, closing websocket connection [{ws_id}].')
                    else:
                        message = msg_raw.data
                        prefix_length = 6
                        msg_key, msg_value = \
                            message[:prefix_length], message[prefix_length:]
                        if msg_value == u'__INJECTED__':
                            log.debug(f'Injection was successful [{self.request.path}].')
                        else:
                            try:
                                WGCClient.websocket_clients[ws_id]['messages_storage'][msg_key] = msg_value
                            except TypeError:
                                pass
                elif msg_raw.type == WSMsgType.ERROR:
                    log.error(f'Received WSMsgType.ERROR message [{ws_id}].')
                    break
                elif msg_raw.type == WSMsgType.CLOSED:
                    log.error(f'Received WSMsgType.CLOSED message [{ws_id}].')
                    break
        except asyncio.CancelledError:
            pass
        except BaseException as e:
            log.exception(f'websocket -> {ws_id} {e}')
        finally:
            # Log close code and reason for debugging
            close_code = ws.close_code
            close_reason = getattr(ws, 'close_reason', None) or 'N/A'
            log.debug(f'[WS DEBUG] Client [{ws_id}] CLOSED - code: {close_code}, reason: {close_reason}')
            log.debug(f'Client [{ws_id}] connection was closed. Close code: {close_code}, reason: {close_reason}')
            
            WGCClient.websocket_clients[ws_id] = None
            WGCClient.websocket_closed_connection[ws_id] += 1
            try:
                await ws.close()
            except BaseException as e:
                log.exception(f'websocket -> {ws_id} {e}')
        return ws
