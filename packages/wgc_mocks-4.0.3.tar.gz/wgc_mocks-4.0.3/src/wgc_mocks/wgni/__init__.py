# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

# flake8: noqa
from .storage import WGNIUsersDB
