﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import io
import string

from aiohttp import web
from PIL import Image, ImageDraw, ImageFont

from wgc_core.file_templates import get_file_template


class Captcha(web.View):
    """
    Captcha class.
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        captcha_id = self.request.match_info.get('captcha_id')
        if captcha_id.lower() == 'universal_captcha':
            data = get_file_template('hacked_captcha.png', as_bytes=True)
        else:
            captcha = ''.join([letter for letter in captcha_id if
                               letter in string.digits][:6])
            background_image = get_file_template('captcha.png', as_bytes=True)
            im = Image.open(io.BytesIO(background_image))

            draw = ImageDraw.Draw(im)
            font = ImageFont.truetype('arial', size=27)
            draw.text((50, 25), captcha, font=font, fill='black')
            im_fp = io.BytesIO()
            im.save(im_fp, 'png')
            im_content = im_fp.getvalue()
            im_fp.close()
            data = im_content
        return web.Response(status=200, content_type='image/png', body=data)

    async def get(self):
        return self._on_get()
