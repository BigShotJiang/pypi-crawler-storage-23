﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.config import WGCConfig


class CreateTicket(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-ticket
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """

        # region cookies parsing
        wgni_sessionid = self.request.cookies.get('wgnr_sessionid')  # noqa
        # endregion

        # region params parsing
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        pow_ = params.get('pow')
        # endregion

        if not pow_:
            return web.json_response({'errors': {'pow': ['required']}}, status=400)

        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/registration/api/v{version}/ticket/status/' \
                         f'{token}/?expiry_time=1234.0'
        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()
