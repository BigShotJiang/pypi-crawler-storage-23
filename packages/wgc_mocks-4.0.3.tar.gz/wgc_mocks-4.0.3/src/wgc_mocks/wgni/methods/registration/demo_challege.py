﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import string
import random
from time import time

from aiohttp import web
from wgc_mocks.wgni.storage import WGNIUsersDB


class RegistrationChallenge(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/master/#v2-account-demo-challenge
    """

    ip_asks = {}
    ban_timeout = 1

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        type_ = self.request.query.get('type')
        # endregion
        sessionid = WGNIUsersDB.generate_session_id()
        if WGNIUsersDB.use_captcha_on_registration:
            if WGNIUsersDB.use_real_captcha:
                challenge_result = ''.join(random.choice(string.digits) for _ in range(32))
            else:
                challenge_result = None
            WGNIUsersDB.set_challenge_result_for_wgni_session(
                sessionid, challenge_result=challenge_result)
            challenge_result = challenge_result or 'universal_captcha'
            data = {
                'captcha': {
                    'url': f'/id/captcha/{challenge_result}',
                    'token': challenge_result,
                    'type': 'captcha'
                }}
        else:
            if type_ == 'captcha':
                if WGNIUsersDB.use_real_captcha:
                    challenge_result = ''.join(random.choice(string.digits) for _ in range(32))
                else:
                    challenge_result = None
                WGNIUsersDB.set_challenge_result_for_wgni_session(
                    sessionid, challenge_result=challenge_result)
                challenge_result = challenge_result or 'universal_captcha'
                data = {
                    'captcha': {
                        'url': f'/id/captcha/{challenge_result}',
                        'token': challenge_result,
                        'type': 'captcha'
                    }}
            else:
                WGNIUsersDB.set_challenge_result_for_wgni_session(
                    sessionid, challenge_result=None)
                data = {
                    'pow': {
                        'timestamp': int(time()),
                        'complexity': WGNIUsersDB.pow_complexity,
                        'type': 'pow',
                        'algorithm': {
                            'version': 1,
                            'resource': 'wgnr',
                            'name': 'hashcash',
                            'extension': ''
                        },
                        'random_string': ''.join(random.choice(
                            string.ascii_letters) for _ in range(16))
                    }}
        return web.json_response(data, status=200, headers={'HTTP_X_WG_CHALLENGE_KEY': sessionid,
                                                            'Set-Cookie': f'wgnr_sessionid={sessionid}'})

    async def get(self):
        await asyncio.sleep(1.5)
        return self._on_get()
