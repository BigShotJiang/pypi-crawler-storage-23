﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses
from wgc_core.config import WGCConfig


class CreateBasicAccount(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-account-basic
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        await asyncio.sleep(1.5)
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())

        ticket = params.get('ticket')
        login = params.get('login')
        password = params.get('password')
        name = params.get('name')
        pow_ = params.get('pow')  # noqa
        bonus = params.get('bonus')  # noqa
        tid = params.get('tid')
        game = params.get('game')  # noqa
        sid = params.get('sid')  # noqa
        game_realm = params.get('game_realm') or region
        # endregion

        if not login:
            return web.json_response({
                "errors": {
                    "login": [
                        "required"
                    ]
                }
            }, status=400)

        if not password:
            return web.json_response({
                "errors": {
                    "password": [
                        "required"
                    ]
                }
            }, status=400)

        if len(password) < 7:
            return web.json_response({
                "errors": {
                    "password": [
                        "min_length"
                    ]
                }
            }, status=400)

        if len(password) > 20:
            return web.json_response({
                "errors": {
                    "password": [
                        "max_length"
                    ]
                }
            }, status=400)

        if not password.strip(password[0]):
            return web.json_response({
                "errors": {
                    "password": [
                        "weak_password"
                    ]
                }
            }, status=400)

        if not name:
            return web.json_response({
                "errors": {
                    "name": [
                        "required"
                    ]
                }
            }, status=400)

        account_by_login = WGNIUsersDB.get_account_by_username(login, game_realm)
        errors = {}
        if account_by_login:
            errors['login'] = ['already_taken']

        account_by_name = WGNIUsersDB.get_account_by_nickname(name, game_realm)
        if account_by_name:
            errors['name'] = ['already_taken']

        token = WGNIUsersDB.create_ticket(ticket=ticket, errors=errors)
        if not account_by_login and not account_by_name:
            WGNIUsersDB.add_account(login, password, name, token,
                                    AccountStatuses.NOT_ACTIVATED, tid,
                                    realm=game_realm)
        version = self.request.match_info.get('version')
        ticket_address = \
            f'{WGCConfig.wgni_url}/realm_{region}/registration/api/v{version}/account/basic/status/{token}/?' \
            f'game_realm={game_realm}'
        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()
