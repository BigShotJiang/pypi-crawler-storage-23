﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CheckBasicAccountStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-account-basic-status-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """

        token = self.request.match_info.get('token')
        account = WGNIUsersDB.get_account_by_background_task(token)
        ticket = WGNIUsersDB.get_ticket_by_background_task(token)

        if not account:
            return web.json_response({"errors": ticket.errors}, status=409)

        if account and ticket:
            return web.json_response({'account_id': account.id,
                                      'token': ticket.id}, status=200)
        return web.json_response({'errors': {'ticket': ['invalid']}}, status=409)

    async def get(self):
        return self._on_get()
