﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import random
import string

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses


class CreateDemoAccount(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/master/#v2-account-demo
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        await asyncio.sleep(WGNIUsersDB.demo_create_timeout)
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())

        ticket = params.get('ticket')
        login = params.get('login')
        password = params.get('password')
        requested_for = params.get('requested_for')
        game = params.get('game')  # noqa
        name = params.get('name')
        game_realm = params.get('game_realm') or region
        # endregion

        errors = {}
        if not login:
            errors['login'] = ['required']

        if not password:
            errors['password'] = ['required']

        if not requested_for:
            errors['requested_for'] = ['required']

        if errors:
            return web.json_response({'errors': errors}, status=400)

        token = WGNIUsersDB.create_ticket(ticket=ticket)
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/registration/api/v{version}/account/demo/status/' \
                         f'{token}/?expiry_time=1234.0'

        account = {}
        while not account:
            name = name or 'Player_%s' % ''.join([random.choice(
                string.digits) for _ in range(10)])
            account = WGNIUsersDB.add_account(
                login, password, name, token, AccountStatuses.ACTIVATED, realm=game_realm)
        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()
