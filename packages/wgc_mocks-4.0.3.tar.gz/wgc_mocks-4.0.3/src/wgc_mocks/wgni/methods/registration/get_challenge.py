﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import string
import random
from time import time

from aiohttp import web
from wgc_mocks.wgni.storage import WGNIUsersDB


class GetTicketChallenge(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-ticket-challenge
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """

        sessionid = WGNIUsersDB.generate_session_id()
        WGNIUsersDB.set_challenge_result_for_wgnr_session(sessionid,
                                                          challenge_result=None)
        data = {
            'pow': {
                'timestamp': int(time()),
                'complexity': 1,
                'type': 'pow',
                'algorithm': {
                    'version': 1,
                    'resource': 'wgnr',
                    'name': 'hashcash',
                    'extension': ''
                },
                'random_string': ''.join(random.choice(
                    string.ascii_letters) for _ in range(16))
            }}
        resp = web.json_response(data, status=200)
        resp.set_cookie('wgnr_sessionid', sessionid)
        return resp

    async def get(self):
        return self._on_get()
