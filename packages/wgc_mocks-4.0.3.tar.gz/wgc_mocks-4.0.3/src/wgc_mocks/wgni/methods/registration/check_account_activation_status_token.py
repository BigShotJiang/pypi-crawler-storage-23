﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CheckAccountActivationStatusToken(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-account-account-id-activation-status-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """

        account_id = self.request.match_info.get('account_id')
        account = WGNIUsersDB.get_account_by_account_id(account_id)

        if not account:
            return web.json_response({"__all__": ["account_not_found"]}, status=409)
        return web.json_response({"activated": bool(account.status)}, status=200)

    async def get(self):
        return self._on_get()
