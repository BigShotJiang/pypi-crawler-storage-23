﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses
from wgc_core.config import WGCConfig


class CreateExternalSteam(web.View):
	"""
	https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-account-external-steam
	"""

	async def _on_post(self):
		# region params parsing
		region = self.request.match_info.get('realm')
		if self.request.content_type == 'application/json' and self.request.body_exists:
			params = await self.request.json()
		else:
			params = dict(await self.request.post())

		game_id = params.get('game_id')
		auth_session_ticket = params.get('auth_session_ticket')
		tid = params.get('tid')
		login = params.get('login', '')
		password = params.get('password', '')
		name = params.get('name')
		game_realm = params.get('game_realm') or region

		# endregion

		token = WGNIUsersDB.create_ticket()
		if name:
			account = WGNIUsersDB.get_account_by_nickname(name, game_realm)
			if account:
				return web.json_response({
					"errors": {
						"name": [
							"forbidden"
						]
					}
				}, status=400)
			WGNIUsersDB.add_account(
				login, password, name, token, AccountStatuses.ACTIVATED, tid,
				realm=game_realm, auth_session_ticket=auth_session_ticket, steam_game_id=game_id)
		version = self.request.match_info.get('version')
		ticket_address = \
			f'{WGCConfig.wgni_url}/realm_{region}/registration/api/v{version}/account/external/steam/status/{token}/?' \
			f'game_realm={game_realm}'
		return web.json_response({}, status=202, headers={'Location': ticket_address})

	async def post(self):
		return await self._on_post()
