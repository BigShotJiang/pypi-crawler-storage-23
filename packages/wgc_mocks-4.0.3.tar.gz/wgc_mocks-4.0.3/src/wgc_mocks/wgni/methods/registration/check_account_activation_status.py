﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.config import WGCConfig


class CheckAccountActivationStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-account-account-id-activation
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """

        region = self.request.match_info.get('realm')
        account_id = self.request.match_info.get('account_id')
        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/registration/api/v{version}/account/{account_id}/' \
                         f'activation/status/{token}/?expiry_time=1234.0'
        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def get(self):
        return self._on_get()
