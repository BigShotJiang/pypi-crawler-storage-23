﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class SettingsView(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/development/#v3-settings
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        data = {
            "registration": {
                "minor_restrictions": bool(WGNIUsersDB.registration_adult_check),
                "externals": [
                    "facebook",
                    "google"
                ],
                "korean_restrictions": True,
                "allowed_countries": WGNIUsersDB.allowed_countries
            },
            "common": {
                "country_code": WGNIUsersDB.detected_country_code,
            }
        }
        if WGNIUsersDB.registration_adult_check is not None:
            data['common']['adult_age'] = WGNIUsersDB.registration_adult_check
        return web.json_response(data, status=200)
    
    async def post(self):
        return await self._on_post()
