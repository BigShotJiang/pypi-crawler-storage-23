﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from time import time

from aiohttp import web
import jwt

from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses
from wgc_core.config import WGCConfig


class OauthTokenStatusV2(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-credentials-create-oauth-token-token
    """
    
    def _on_get(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        token = self.request.match_info.get('token')
        grant_type = self.request.match_info.get('grant')
        region = self.request.match_info.get('realm')
        account = WGNIUsersDB.get_account_by_oauth_token(token)

        if not account:
            return web.json_response({
                "error": "invalid_grant",
                "error_description": "account_not_found"}, status=400)
        
        if account.status != AccountStatuses.ACTIVATED:
            return web.json_response({
                "error": "invalid_grant",
                "error_description": "account_not_activated"}, status=400)
        
        iat = int(time())
        expires_in = 3600
        id_token_data = {'iss': '%s/realm_%s/' % (WGCConfig.wgni_url, region),
                         'sub': account.id,
                         'aud': account.client_id,
                         'iat': iat,
                         'exp': iat + expires_in,
                         'email': account.username,
                         'login': account.username,
                         'email_verified': bool(account.status),
                         'nickname': account.nickname,
                         'country_legal': GameMocks.country_legal,
                         'stated_country': GameMocks.stated_country,
                         'game_fields': account.game_fields}
        if '@demo.wgc' in account.username:
            del id_token_data['email']
            del id_token_data['email_verified']
        
        realm_from = 'ru'
        realm_to = 'eu'
        answer = 'eu'
        if account.teleport_account and account.teleport_request_data:
            realm_to = account.teleport_request_data.get('realm')
            answer = realm_to
        if not account.teleport_request_data:
            realm_from = ''
            realm_to = ''
            answer = None
        id_token_data['teleport_info'] = {
            "from": realm_from, "to": realm_to, "answer": answer}

        if grant_type == 'external-steam' or 'external-steam' in account.requested_grant_types:
            id_token_data['steam_uid'] = WGNIUsersDB.get_steam_id()
        
        id_token = jwt.encode(id_token_data, 'secret', algorithm='HS256')
        scopes = WGNIUsersDB.custom_scopes or account.scopes
        data = {
            "access_token": token,
            "token_type": "Bearer",
            "expires_in": expires_in,
            "scope": ' '.join(scopes),
            "id_token": id_token
        }
        if grant_type == 'access-token':
            data['additional_token'] = {"access_token": token,
                                        "expires_in": expires_in,
                                        "scope": ' '.join(scopes),
                                        'token_type': 'Bearer'}
        return web.json_response(data, status=200)
    
    async def get(self):
        return self._on_get()
