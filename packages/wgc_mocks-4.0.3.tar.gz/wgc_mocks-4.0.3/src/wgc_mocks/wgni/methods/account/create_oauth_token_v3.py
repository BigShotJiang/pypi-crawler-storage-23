﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import asyncio
from math import ceil
from time import time

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.logger import get_logger
from wgc_core.config import WGCConfig

log = get_logger(__name__)


class CreateOauthTokenV3(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-credentials-create-oauth-token
    """

    available_grand_types = ['urn:wargaming:params:oauth:grant-type:basic',
                             'urn:wargaming:params:oauth:grant-type:external-china360',
                             'urn:wargaming:params:oauth:grant-type:token1',
                             'urn:wargaming:params:oauth:grant-type:external-steam',
                             'urn:wargaming:params:oauth:grant-type:access-token',
                             'refresh_token']
    valid_client_ids = [WGCConfig.wgni_client_id]
    client_secret = 'something'
    scopes = ['openid', 'openid.email', 'account.country_legal', 'read',
              'account.stated_country', 'account.game_fields',
              'account.credentials.add_account', 'account.persona',
              'account.credentials.oauth_long_lived_token.create',
              'account.credentials.additional_token.create',
              'account.credentials.token1.create', "account.signature",
              'account.steam.uid', 'openid.login', 'account.basic.update',
              'account.externals.bind', "account.name.update",
              'account.external.google.access_token', 'account.youtube_tokens.uid', 'account.teleport',
              'persona.default_accounts', 'account.minors', 'persona.persona_default']
    game_ids = ['wot', 'wowp', 'wows', 'exc', '1080820']

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region cookies parsing
        wgni_sessionid = self.request.headers.get('X-WG-CHALLENGE-KEY') or self.request.cookies.get('wgni_sessionid')
        log.debug(f'X-WG-CHALLENGE-KEY={wgni_sessionid}')
        # endregion
        # region params parsing
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
            
        email_code = params.get('email_code')
        twofactor_email_session_code = params.get('twofactor_email_session_code')
        twofactor_token = params.get('twofactor_token')
        
        client_id = params.get('client_id')
        client_secret = params.get('client_secret')
        grant_type = params.get('grant_type')
        account_id = params.get('account_id')
        username = params.get('username')
        password = params.get('password')
        
        otp_code = params.get('otp_code')  # noqa
        backup_code = params.get('backup_code')  # noqa
        token = params.get('token')  # noqa
        game_id = params.get('game_id')
        auth_session_ticket = params.get('auth_session_ticket')
        type_ = params.get('type')  # noqa
        scope = params.get('scope')
        tid = params.get('tid')
        sauth_json = params.get('sauth_json')  # noqa
        pow_ = params.get('pow')
        captcha = params.get('captcha')
        captcha_22 = params.get('captcha_22')
        access_token = params.get('access_token')
        exchange_code = params.get('exchange_code')
        game_realm = params.get('game_realm') or region
        tokens_to_remove = params.get('tokens_to_remove')  # noqa
        create_additional_token = params.get('create_additional_token')  # noqa
        # endregion

        from wgc_mocks.game_mocks import GameMocks
        await asyncio.sleep(GameMocks.create_oauth_token_timeout)
        user_account = None  # noqa

        if scope:
            scope = scope.split()

        if not grant_type:
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {grant_type} '
                                      'parameter.'}, status=400)

        if grant_type not in self.available_grand_types:
            return web.json_response(
                {'error': 'unsupported_grant_type'}, status=400)

        if client_id:
            if WGNIUsersDB.use_two_factor_auth and client_id not in self.valid_client_ids:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Unsupported twofactor type."
                    }, status=400)

            if client_id not in self.valid_client_ids or \
                    (client_secret and client_secret != self.client_secret):
                return web.json_response(
                    {'error': 'invalid_client'}, status=400)

        if client_id.startswith('unauthorized'):
            return web.json_response(
                {'error': 'unauthorized_client'}, status=400)

        if scope and not set(scope).issubset(self.scopes):
            return web.json_response(
                {'error': 'invalid_scope'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                (not username or not password):
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {username|password} '
                                      'parameter.'}, status=400)

        #  Two-factor Auth
        if WGNIUsersDB.use_two_factor_auth and not twofactor_token and not WGNIUsersDB.use_email_code:
            return web.json_response(
                {
                    "error": "invalid_grant",
                    "error_description": "twofactor_required",
                    "twofactor_token": WGNIUsersDB.generate_session_id(),
                }, status=400)
                
        if WGNIUsersDB.use_two_factor_auth and not twofactor_token and WGNIUsersDB.use_email_code:
            token_two = WGNIUsersDB.generate_session_id()
            from hashlib import sha256
            return web.json_response(
                {
                    "error": "invalid_grant",
                    "error_description": "twofactor_required",
                    "twofactor_types": [
                        "otp",
                        "backup_code",
                        "email_code"
                    ],
                    "twofactor_token": token_two,
                    "twofactor_email_session_code": WGNIUsersDB.default_email_code,
                    "twofactor_request_hash": sha256(token_two.encode('utf-8')).hexdigest()
                }, status=400)

        if WGNIUsersDB.use_two_factor_auth and twofactor_token:
            user_account = WGNIUsersDB.get_account_by_username(username, game_realm)
            if otp_code is None and backup_code is None and email_code is None:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Either otp_code or backup_code parameter must be passed."
                    }, status=400)

            if otp_code and backup_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "otp_code and backup_code parameters must not be passed together."
                    }, status=400)

            if otp_code and user_account and user_account.otp_code != otp_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Invalid otp_code parameter value."
                    }, status=400)

            if backup_code and user_account and user_account.backup_code != backup_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Invalid backup_code parameter value."
                    }, status=400)
            
            if email_code and user_account and user_account.email_code != email_code:
                return web.json_response(
                    {
                        "error": "invalid_grant",
                        "error_description": "twofactor_invalid",
                        "twofactor_token": twofactor_token,
                        "twofactor_error": "code_invalid"
                    }, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:token1' and \
                not account_id:
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {account_id|token} '
                                      'parameter.'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                username:
            user_account = WGNIUsersDB.get_account_by_username(username, game_realm)
            if not user_account or user_account.password != password:
                return web.json_response(
                    {'error': 'invalid_grant',
                     'error_description': 'account_not_found'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                wgni_sessionid:
            challenge_result = \
                WGNIUsersDB.get_challenge_result_from_wgni_session(
                    wgni_sessionid)
            if (wgni_sessionid not in WGNIUsersDB._wgni_sessions) or \
                    (captcha and challenge_result and
                     WGNIUsersDB.use_real_captcha and
                     captcha != challenge_result):
                return web.json_response(
                    {'error': 'challenge_invalid'}, status=400)

            elif not pow_ and not captcha and not captcha_22:
                return web.json_response(
                    {'error': 'challenge_required'}, status=400)

        if grant_type == \
                'urn:wargaming:params:oauth:grant-type:external-steam':
            if game_id not in self.game_ids:
                return web.json_response(
                    {'error': 'invalid_request',
                     'error_description': 'Invalid game_id, '
                                          'auth_session_ticket parameters '
                                          'values.'}, status=400)

            elif not game_id or not auth_session_ticket:
                return web.json_response(
                    {'error': 'unsupported_grant_type',
                     'error_description': 'Request is missing '
                                          '{game_id|auth_session_ticket} '
                                          'parameter.'}, status=400)

        expires_in = 3600
        if grant_type == 'urn:wargaming:params:oauth:grant-type:access-token':
            user_account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:token1':
            user_account = WGNIUsersDB.get_account_by_token1(params.get('token'))
        
        if grant_type == 'urn:wargaming:params:oauth:grant-type:external-steam':
            user_account = WGNIUsersDB.get_account_by_steam_auth(auth_session_ticket, game_realm)
            
        if grant_type == 'urn:wargaming:params:oauth:grant-type:external-china360':
            user_account = WGNIUsersDB.get_account_by_cn360_auth()
            scope = 'account.name.update account.stated_country account.youtube_tokens.uid ' \
                    'account.credentials.oauth_long_lived_token.create account.credentials.additional_token.create ' \
                    'openid account.teleport account.signature account.credentials.token1.create ' \
                    'account.external.google.access_token account.country_legal account.game_fields ' \
                    'openid.email openid.login read'.split()
            
        if tokens_to_remove:
            tokens_to_remove = tokens_to_remove.split()
            for token_to in tokens_to_remove:
                user = WGNIUsersDB.get_account_by_any_token(token_to)
                if user:
                    user.oauth_token = None
                    user.oauth_token_exp_time = None
                    user.additional_token = None
                    user.additional_token_exp_time = None

        short_grant_type = grant_type.split(":")[-1]

        if user_account:
            user_account.requested_grant_types.append(short_grant_type)
            if WGNIUsersDB.persona_enabled:
                persona_account = WGNIUsersDB.get_persona_by_persona_id(user_account.persona_id)
                for account in persona_account.accounts:
                    account.scopes = scope
                    account.client_id = client_id
                    account.exchange_code = exchange_code
                    new_oauth_token = WGNIUsersDB.generate_oauth_token()
                    account.oauth_token = new_oauth_token
                    account.oauth_token_exp_time = ceil(time() + expires_in)
                    if grant_type == "urn:wargaming:params:oauth:grant-type:access-token":
                        account.additional_token = WGNIUsersDB.generate_oauth_token()
                        account.additional_token_exp_time = ceil(time() + expires_in)
            else:
                user_account.scopes = scope
                user_account.client_id = client_id
                user_account.exchange_code = exchange_code
                user_account.oauth_token = WGNIUsersDB.generate_oauth_token()
                user_account.oauth_token_exp_time = ceil(time() + expires_in)
                if grant_type == "urn:wargaming:params:oauth:grant-type:access-token":
                    user_account.additional_token = WGNIUsersDB.generate_oauth_token()
                    user_account.additional_token_exp_time = ceil(time() + expires_in)
                    
            token_url = user_account.oauth_token
            user_account.tid = tid
        else:
            token_url = WGNIUsersDB.generate_oauth_token()
        prepare_url = f'{short_grant_type}/{token_url}'
        ticket_address = (f'{WGCConfig.wgni_url}/realm_{region}/id/api/v3/account/'
                          f'credentials/create/oauth/token/{prepare_url}/')
        resp = web.json_response({}, status=202, headers={'Location': ticket_address})
        return resp

    async def post(self):
        return await self._on_post()
