﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.logger import get_logger
from wgc_mocks.wgni.storage import WGNIUsersDB

log = get_logger(__name__)


class CreateTFAEmailV3(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-credentials-create-oauth-token-tfa-email
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        twofactor_request_hash = params.get('twofactor_request_hash')
        twofactor_token = params.get('twofactor_token')
        
        if not twofactor_request_hash:
            return web.json_response({
                "errors": {
                    "twofactor_request_hash": [
                        "This field is required."
                    ]
                }
            }, status=400)
        if not twofactor_token:
            return web.json_response({
                "errors": {
                    "twofactor_token": [
                        "This field is required."
                    ]
                }
            }, status=400)
        WGNIUsersDB.default_email_code = str(int(WGNIUsersDB.default_email_code) + 1)
        return web.json_response(
            {
                "twofactor_email_session_code": WGNIUsersDB.default_email_code
            }, status=200)
    
    async def post(self):
        return await self._on_post()
