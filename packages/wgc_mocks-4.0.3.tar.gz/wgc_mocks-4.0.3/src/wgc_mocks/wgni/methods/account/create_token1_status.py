﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CreateToken1Status(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-credentials-create-token1-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        token = self.request.match_info.get('token')
        account = WGNIUsersDB.get_account_by_background_task(token)
        if not account:
            return web.json_response({}, status=401)
        return web.json_response({'token': account.token1, 'account_id': account.id}, status=200)

    async def get(self):
        return self._on_get()
