﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class AccountMerge(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-merge
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        tokens = params.get('tokens', '').split(',')
        region = self.request.match_info.get('realm')
        # endregion
        
        await asyncio.sleep(1.5)
        
        exchange_code = None  # noqa
        if authorization:
            short_access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(short_access_token)
            if not account:
                return web.json_response(
                    {'errors': ['invalid access token']}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        
        current_logged_in = WGNIUsersDB.get_account_by_oauth_token(tokens[0])
        linked_logged_in = WGNIUsersDB.get_account_by_oauth_token(tokens[1])
        if current_logged_in is None:
            return web.json_response({'errors': ['invalid access token for current logged in user. '
                                                 'Do you link the same account?']}, status=409)
        if linked_logged_in is None:
            return web.json_response({'errors': ['invalid access token for linked in user. '
                                                 'Not found account by token']}, status=409)
        current_persona = WGNIUsersDB.get_persona_by_persona_id(current_logged_in.persona_id)
        linked_persona = WGNIUsersDB.get_persona_by_persona_id(linked_logged_in.persona_id)
        linked_persona.accounts.extend(current_persona.accounts)
        
        token_status_id = \
            WGNIUsersDB.set_teleport_background_task_for_username(account.username, region)
        
        return web.json_response({}, status=202, headers={'Location': '%s/%s/' % (
            str(self.request.url).rstrip('/'), token_status_id)})

    async def post(self):
        return await self._on_post()
