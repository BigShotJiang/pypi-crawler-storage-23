﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni.storage import WGNIUsersDB


class AccountTeleportStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/feature-wgnwn-7308/api/index.html#personal-api-v2-account-teleport-status-token
    """
    
    def _on_get(self):
        """
        Method for further monkey patching.
        """
        token = self.request.match_info.get('token')
        region = self.request.match_info.get('realm')
        account = WGNIUsersDB.get_account_by_teleport_background_task(token)
        if not account:
            return web.json_response({}, status=401)
        
        if account.teleport_request_data.get('realm') == 'ru':
            return web.json_response({}, status=200)
        
        if not account.completed:
            return web.json_response({
                "status": "account_is_incomplete",
                "error_data": {
                    "completion_url": f"{WGCConfig.wgni_url}/realm_{region}/personal/credentials/basic/"}},
                status=409)
        
        new_nickname = f'new_{account.nickname}' if WGNIUsersDB.create_new_nickname_on_teleport else account.nickname
        password = account.teleport_request_data.get('password') or account.password
        login = account.teleport_request_data.get('login') or account.username
        new_account = WGNIUsersDB.add_account(
            login, password, new_nickname,
            realm=account.teleport_request_data.get('realm'),
            auth_session_ticket=account.steam_auth_session_ticket)
        if new_account == {}:
            return web.json_response(
                {"status": "account_basic_already_exists", "error_data": {}},
                status=409)

        new_account.teleport_account = new_account
        new_account.teleport_request_data = account.teleport_request_data
        
        data = {
            "new_wgid": new_account.id,
            "free_rename": False,
            "source_name": account.nickname,
            "target_name": new_nickname,
            "external_status": {
                "egs": True,
                "steam": True,
                "google": True,
                "vkontakte": False,
                "twitch": False,
            },
            "game_accounts": {
                "moo": True
            },
            "token1": account.token1
        }
        account.teleport_account = new_account
        new_account.token1 = account.token1

        return web.json_response({'status': "in_progress", "data": data, "state": 401,
                                  "target_realm": account.teleport_request_data.get('realm')}, status=200)
    
    async def get(self):
        await asyncio.sleep(1)
        return self._on_get()
