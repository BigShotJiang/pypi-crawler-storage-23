﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from time import time

from aiohttp import web
import jwt

from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses
from wgc_core.config import WGCConfig


class OauthTokenStatusV3(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-credentials-create-oauth-token-token
    """
    
    def _on_get(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        token = self.request.match_info.get('token')
        grant_type = self.request.match_info.get('grant')
        region = self.request.match_info.get('realm')
        user_account = WGNIUsersDB.get_account_by_any_token(token)

        if not user_account:
            return web.json_response({
                "error": "invalid_grant",
                "error_description": "account_not_found"}, status=400)
        
        if user_account.status != AccountStatuses.ACTIVATED:
            return web.json_response({
                "error": "invalid_grant",
                "error_description": "account_not_activated"}, status=400)
        
        persona = WGNIUsersDB.get_persona_by_persona_id(user_account.persona_id)
        result_data = []
        steam_id = None
        for index, account in enumerate(persona.accounts):
            if WGNIUsersDB.persona_available_realms:
                if account.realm not in WGNIUsersDB.persona_available_realms:
                    for i, acc in enumerate(WGNIUsersDB.accounts_list):
                        if acc.id == account.id:
                            WGNIUsersDB.accounts_list.pop(i)
                    persona.accounts.pop(index)
                    continue
            if account.oauth_token is not None:
                iat = int(time())
                expires_in = 3600
                if WGNIUsersDB.persona_available_realms:
                    persona_accounts = [{'name': x.nickname, 'game_realm': x.realm, 'id': x.id} for x in
                                        persona.accounts if x.realm in WGNIUsersDB.persona_available_realms]
                else:
                    persona_accounts = [{'name': x.nickname, 'game_realm': x.realm, 'id': x.id} for x in
                                        persona.accounts]
                id_token_data = {'iss': '%s/realm_%s/' % (WGCConfig.wgni_url, region),
                                 'sub': account.id,
                                 'aud': account.client_id,
                                 'iat': iat,
                                 'exp': iat + expires_in,
                                 'email': account.username,
                                 'login': account.username,
                                 'email_verified': bool(account.status),
                                 'nickname': account.nickname,
                                 'country_legal': GameMocks.country_legal,
                                 'stated_country': GameMocks.stated_country,
                                 'game_fields': account.game_fields,
                                 'game_realm': account.realm,
                                 'default_accounts': account.default_accounts,
                                 'persona': {
                                     'persona_conflicted': WGNIUsersDB.persona_conflicted,
                                     'persona_id': persona.persona_id,
                                     'accounts': persona_accounts
                                 },
                                 }
                if account.steam_restrictions:
                    id_token_data['steam_restrictions'] = account.steam_restrictions
                if account.steam_bound:
                    id_token_data['steam_uid'] = WGCConfig.steam.steam_id
                if '@demo.wgc' in account.username:
                    del id_token_data['email']
                    del id_token_data['email_verified']
                if 'persona.persona_default' in account.scopes:
                    id_token_data['persona_default'] = account.persona_default
                
                realm_from = 'ru'
                realm_to = 'eu'
                answer = 'eu'
                if account.teleport_account and account.teleport_request_data:
                    realm_to = account.teleport_request_data.get('realm')
                    answer = realm_to
                if not account.teleport_request_data:
                    realm_from = ''
                    realm_to = ''
                    answer = None
                id_token_data['teleport_info'] = {
                    "from": realm_from, "to": realm_to, "answer": answer}

                if grant_type == 'external-steam' or 'external-steam' in account.requested_grant_types or steam_id:
                    id_token_data['steam_uid'] = WGNIUsersDB.get_steam_id()
                    steam_id = WGNIUsersDB.get_steam_id()
                
                id_token = jwt.encode(id_token_data, 'secret', algorithm='HS256')
                scopes = WGNIUsersDB.custom_scopes or account.scopes
                data = {
                    "access_token": account.oauth_token,
                    "token_type": "Bearer",
                    "expires_in": expires_in,
                    "scope": ' '.join(scopes),
                    "id_token": id_token,
                    'user': account.id
                }
                if grant_type == 'access-token':
                    data['additional_token'] = {"access_token": account.additional_token,
                                                "expires_in": expires_in,
                                                "scope": ' '.join(scopes),
                                                'token_type': 'Bearer'}
                if WGNIUsersDB.persona_enabled:
                    result_data.append(data)
                else:
                    if account.id == user_account.id:
                        result_data.append(data)
        return web.json_response(result_data, status=200)
    
    async def get(self):
        return self._on_get()
