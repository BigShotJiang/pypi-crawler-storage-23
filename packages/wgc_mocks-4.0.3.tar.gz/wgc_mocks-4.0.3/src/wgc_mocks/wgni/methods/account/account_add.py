﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni import WGNIUsersDB


class AccountAdd(web.View):

    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-info-token
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        region = self.request.match_info.get('realm')
        realm = params.get('game_realm')
        nickname = params.get('name')
        access_token, exchange_code = \
            (authorization.split()[-1].split(':') + [None])[:2]
        if exchange_code:
            account = WGNIUsersDB.get_account_by_any_token(access_token)
            if account:
                ticket_address = (f'{WGCConfig.wgni_url}/realm_{region}/id/api/v3/account/'
                                  f'add/{account.oauth_token}/{realm}/{nickname}')
                return web.json_response({}, status=202, headers={'Location': ticket_address})
        return web.json_response(
            {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)

    async def post(self):
        return await self._on_post()
