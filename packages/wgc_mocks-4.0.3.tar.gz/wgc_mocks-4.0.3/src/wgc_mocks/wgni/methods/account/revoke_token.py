﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class RevokeToken(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-credentials-revoke-oauth-token
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        client_id = params.get('client_id')  # noqa
        client_secret = params.get('client_secret')  # noqa
        token = params.get('token')
        token_type_hint = params.get('token_type_hint')  # noqa
        # endregion

        if not token:
            return web.json_response({
                'error': 'invalid_request',
                'error_description': 'Missing token parameter.'}, status=400)

        account = WGNIUsersDB.get_account_by_oauth_token(token)
        if account:
            WGNIUsersDB.revoke_oauth_token_by_username(account.username, account.realm)
        
        return web.json_response({}, status=200)

    async def post(self):
        return await self._on_post()
