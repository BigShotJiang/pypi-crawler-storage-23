# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class AccountMergeStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-merge
    """
    
    async def _on_get(self):
        """
        Method for further monkey patching.
        """
        token = self.request.match_info.get('token')  # noqa
        return web.json_response({}, status=200)
    
    async def get(self):
        return await self._on_get()
