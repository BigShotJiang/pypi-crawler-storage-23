﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class AccountTeleport(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/feature-wgnwn-7308/api/index.html#personal-api-v2-account-teleport
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        realm = params.get('realm')
        login = params.get('login')
        password = params.get('password')
        # endregion
        
        await asyncio.sleep(1.5)
        
        exchange_code = None  # noqa
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        region = self.request.match_info.get('realm')
        account = WGNIUsersDB.get_account_by_oauth_token(access_token)
        if not account:
            return web.json_response(
                {'errors': ['invalid access token']}, status=401)
        
        token1 = WGNIUsersDB.generate_token1()
        WGNIUsersDB.set_token1_for_username(account.username, region, token1)
        account.teleport_request_data = {'realm': realm, 'login': login, 'password': password, 'token1': token1}
        token = \
            WGNIUsersDB.set_teleport_background_task_for_username(account.username, region)
        return web.json_response({}, status=202, headers={'Location': '%s/status/%s/' % (
            str(self.request.url).rstrip('/'), token)})

    async def post(self):
        return await self._on_post()
