﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.logger import get_logger
from wgc_core.config import WGCConfig

log = get_logger(__name__)


class CreateIDTokenV3(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/wgni-4406/#api-v3-account-credentials-create-idtoken
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        region = self.request.match_info.get('realm')
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        fields = params.get('fields')
        # endregion

        from wgc_mocks.game_mocks import GameMocks
        await asyncio.sleep(GameMocks.create_id_token_timeout)
        user_account = None  # noqa
        
        acc_token, exchange_code = \
            (authorization.split()[-1].split(':') + [None])[:2]
        if exchange_code:
            account = WGNIUsersDB.get_account_by_any_token(acc_token)
            if account:
                account.id_token_fields = fields
                ticket_address = (f'{WGCConfig.wgni_url}/realm_{region}/id/api/v3/account/'
                                  f'credentials/create/idtoken/{account.oauth_token}/')
                return web.json_response({}, status=202, headers={'Location': ticket_address})
        return web.json_response(
            {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)

    async def post(self):
        return await self._on_post()
