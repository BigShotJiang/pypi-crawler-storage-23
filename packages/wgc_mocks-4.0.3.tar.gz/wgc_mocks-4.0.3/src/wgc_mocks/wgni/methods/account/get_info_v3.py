﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.logger import get_logger
from wgc_mocks.wgni.storage import WGNIUsersDB

log = get_logger(__name__)


class AccountInfoV3(web.View):

    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v3-account-info
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        access_token = params.get('access_token')
        fields = params.get('fields').split(',')
        # endregion

        if not authorization:
            return web.json_response({}, status=401)
        else:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response({}, status=401)
        
        persona = WGNIUsersDB.get_persona_by_persona_id(account.persona_id)
        result_data = []
        for account in persona.accounts:
            if WGNIUsersDB.persona_available_realms:
                if account.realm not in WGNIUsersDB.persona_available_realms:
                    continue
            data = {'sub': account.id}
            if 'country_legal' in fields:
                data['country_legal'] = GameMocks.country_legal
            if 'stated_country' in fields:
                data['stated_country'] = GameMocks.stated_country
            if 'id' in fields:
                data['sub'] = account.id
            if 'nickname' in fields:
                data['nickname'] = account.nickname
            if 'age' in fields:
                data['age'] = {
                    "minor": None,
                    "group": []
                }
            if 'steam_uid' in fields:
                data['steam_uid'] = WGNIUsersDB.get_steam_id()
            if 'game_fields' in fields:
                data['game_fields'] = account.game_fields
            if 'game_realm' in fields:
                data['game_realm'] = account.realm
            if account.steam_restrictions:
                data['steam_restrictions'] = account.steam_restrictions
            if 'default_accounts' in fields:
                data['default_accounts'] = account.default_accounts
            if 'persona' in fields:
                if WGNIUsersDB.persona_available_realms:
                    persona_accounts = [{'name': x.nickname, 'game_realm': x.realm, 'id': x.id} for x in
                                        persona.accounts if x.realm in WGNIUsersDB.persona_available_realms]
                else:
                    persona_accounts = [{'name': x.nickname, 'game_realm': x.realm, 'id': x.id} for x in
                                        persona.accounts]
                data['persona'] = {
                    'persona_conflicted': WGNIUsersDB.persona_conflicted,
                    'persona_id': persona.persona_id,
                    'accounts': persona_accounts
                }
    
            if 'teleport_info' in fields:
                realm_from = 'ru'
                realm_to = 'eu'
                answer = 'eu'
                if account.teleport_account and account.teleport_request_data:
                    realm_to = account.teleport_request_data.get('realm')
                    answer = realm_to
                if not account.teleport_request_data:
                    realm_from = ''
                    realm_to = ''
                    answer = None
                data['teleport_info'] = {
                    "from": realm_from, "to": realm_to, "answer": answer}
    
            if not WGNIUsersDB.without_email_info:
                if 'email' in fields and '@demo.wgc' not in account.username:
                    data['email'] = account.username
                if 'login' in fields:
                    data['login'] = account.username
                if 'email_verified' in fields:
                    data['email_verified'] = bool(account.status)
            result_data.append(data)
        return web.json_response(result_data, status=200)

    async def post(self):
        return await self._on_post()
