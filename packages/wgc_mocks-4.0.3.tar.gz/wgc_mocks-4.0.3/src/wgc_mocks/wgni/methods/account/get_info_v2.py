﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.logger import get_logger
from wgc_mocks.wgni.storage import WGNIUsersDB

log = get_logger(__name__)


class AccountInfoV2(web.View):

    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-info
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        access_token = params.get('access_token')
        fields = params.get('fields')
        # endregion

        if not authorization:
            return web.json_response({}, status=401)
        else:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            log.debug(f'[ACCOUNT INFO] access_token={access_token}, exchange_code={exchange_code}')
            log.debug(f'[ACCOUNT] account={account}')
            if not account:
                log.debug('[ACCOUNT INFO FAILED] No account found by oauth token.')
                return web.json_response({}, status=401)

        if not fields:
            fields = ['sub']
        else:
            fields = fields.split(',')

        data = {'sub': account.id}
        if 'country_legal' in fields:
            data['country_legal'] = GameMocks.country_legal
        if 'stated_country' in fields:
            data['stated_country'] = GameMocks.stated_country
        if 'id' in fields:
            data['sub'] = account.id
        if 'nickname' in fields:
            data['nickname'] = account.nickname
        if 'age' in fields:
            data['age'] = {
                "minor": None,
                "group": []
            }
        if 'steam_uid' in fields:
            data['steam_uid'] = WGNIUsersDB.get_steam_id()
        if 'game_fields' in fields:
            data['game_fields'] = account.game_fields

        if 'teleport_info' in fields:
            realm_from = 'ru'
            realm_to = 'eu'
            answer = 'eu'
            if account.teleport_account and account.teleport_request_data:
                realm_to = account.teleport_request_data.get('realm')
                answer = realm_to
            if not account.teleport_request_data:
                realm_from = ''
                realm_to = ''
                answer = None
            data['teleport_info'] = {
                "from": realm_from, "to": realm_to, "answer": answer}

        if not WGNIUsersDB.without_email_info:
            if 'email' in fields and '@demo.wgc' not in account.username:
                data['email'] = account.username
            if 'login' in fields:
                data['login'] = account.username
            if 'email_verified' in fields:
                data['email_verified'] = bool(account.status)

        return web.json_response(data, status=200)

    async def post(self):
        return await self._on_post()
