﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import asyncio
from math import ceil
from time import time

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.logger import get_logger
from wgc_core.config import WGCConfig

log = get_logger(__name__)


class CreateOauthTokenV2(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-credentials-create-oauth-token
    """

    available_grand_types = ['urn:wargaming:params:oauth:grant-type:basic',
                             'urn:wargaming:params:oauth:grant-type:external-china360',
                             'urn:wargaming:params:oauth:grant-type:token1',
                             'urn:wargaming:params:oauth:grant-type:external-steam',
                             'urn:wargaming:params:oauth:grant-type:access-token',
                             'refresh_token']
    valid_client_ids = [WGCConfig.wgni_client_id]
    client_secret = 'something'
    scopes = ['openid', 'openid.email', 'account.country_legal', 'read',
              'account.stated_country', 'account.game_fields',
              'account.credentials.add_account', 'account.persona',
              'account.credentials.oauth_long_lived_token.create',
              'account.credentials.additional_token.create',
              'account.credentials.token1.create', 'account.signature',
              'account.steam.uid', 'openid.login', 'account.basic.update',
              'account.externals.bind', "account.name.update", 'account.minors',
              'account.external.google.access_token', 'account.youtube_tokens.uid', 'account.teleport']
    game_ids = ['wot', 'wowp', 'wows', 'exc', '1080820']

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region cookies parsing
        wgni_sessionid = self.request.headers.get('X-WG-CHALLENGE-KEY') or self.request.cookies.get('wgni_sessionid')
        log.debug(f'X-WG-CHALLENGE-KEY={wgni_sessionid}')
        # endregion
        # region params parsing
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        client_id = params.get('client_id')
        client_secret = params.get('client_secret')
        grant_type = params.get('grant_type')
        account_id = params.get('account_id')
        username = params.get('username')
        password = params.get('password')
        twofactor_token = params.get('twofactor_token')
        otp_code = params.get('otp_code')  # noqa
        backup_code = params.get('backup_code')  # noqa
        token = params.get('token')  # noqa
        game_id = params.get('game_id')
        auth_session_ticket = params.get('auth_session_ticket')
        type_ = params.get('type')  # noqa
        scope = params.get('scope')
        tid = params.get('tid')
        sauth_json = params.get('sauth_json')  # noqa
        pow_ = params.get('pow')
        captcha = params.get('captcha')
        captcha_22 = params.get('captcha_22')
        access_token = params.get('access_token')
        exchange_code = params.get('exchange_code')
        game_realm = params.get('game_realm')  # noqa
        tokens_to_remove = params.get('tokens_to_remove')  # noqa
        # endregion

        from wgc_mocks.game_mocks import GameMocks
        await asyncio.sleep(GameMocks.create_oauth_token_timeout)
        account = None  # noqa

        if scope:
            scope = scope.split()

        if not grant_type:
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {grant_type} '
                                      'parameter.'}, status=400)

        if grant_type not in self.available_grand_types:
            return web.json_response(
                {'error': 'unsupported_grant_type'}, status=400)

        if client_id:
            if WGNIUsersDB.use_two_factor_auth and client_id not in self.valid_client_ids:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Unsupported twofactor type."
                    }, status=400)

            if client_id not in self.valid_client_ids or \
                    (client_secret and client_secret != self.client_secret):
                return web.json_response(
                    {'error': 'invalid_client'}, status=400)

        if client_id.startswith('unauthorized'):
            return web.json_response(
                {'error': 'unauthorized_client'}, status=400)

        if scope and not set(scope).issubset(self.scopes):
            return web.json_response(
                {'error': 'invalid_scope'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                (not username or not password):
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {username|password} '
                                      'parameter.'}, status=400)

        #  Two-factor Auth
        if WGNIUsersDB.use_two_factor_auth and not twofactor_token:
            return web.json_response(
                {
                    "error": "invalid_grant",
                    "error_description": "twofactor_required",
                    "twofactor_token": WGNIUsersDB.generate_session_id(),
                }, status=400)

        if WGNIUsersDB.use_two_factor_auth and twofactor_token:

            account = WGNIUsersDB.get_account_by_username(username, region)
            if otp_code is None and backup_code is None:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Either otp_code or backup_code parameter must be passed."
                    }, status=400)

            if otp_code and backup_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "otp_code and backup_code parameters must not be passed together."
                    }, status=400)

            if otp_code and account and account.otp_code != otp_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Invalid otp_code parameter value."
                    }, status=400)

            if backup_code and account and account.backup_code != backup_code:
                return web.json_response(
                    {
                        "error": "invalid_request",
                        "error_description": "Invalid backup_code parameter value."
                    }, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:token1' and \
                not account_id:
            return web.json_response(
                {'error': 'unsupported_grant_type',
                 'error_description': 'Request is missing {account_id|token} '
                                      'parameter.'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                username:
            account = WGNIUsersDB.get_account_by_username(username, region)
            if not account or account.password != password:
                return web.json_response(
                    {'error': 'invalid_grant',
                     'error_description': 'account_not_found'}, status=400)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:basic' and \
                wgni_sessionid:
            challenge_result = \
                WGNIUsersDB.get_challenge_result_from_wgni_session(
                    wgni_sessionid)
            if (wgni_sessionid not in WGNIUsersDB._wgni_sessions) or \
                    (captcha and challenge_result and
                     WGNIUsersDB.use_real_captcha and
                     captcha != challenge_result):
                return web.json_response(
                    {'error': 'challenge_invalid'}, status=400)

            elif not pow_ and not captcha and not captcha_22:
                return web.json_response(
                    {'error': 'challenge_required'}, status=400)

        if grant_type == \
                'urn:wargaming:params:oauth:grant-type:external-steam':
            if game_id not in self.game_ids:
                return web.json_response(
                    {'error': 'invalid_request',
                     'error_description': 'Invalid game_id, '
                                          'auth_session_ticket parameters '
                                          'values.'}, status=400)

            elif not game_id or not auth_session_ticket:
                return web.json_response(
                    {'error': 'unsupported_grant_type',
                     'error_description': 'Request is missing '
                                          '{game_id|auth_session_ticket} '
                                          'parameter.'}, status=400)

        oauth_token = access_token or WGNIUsersDB.generate_oauth_token()

        if grant_type == 'urn:wargaming:params:oauth:grant-type:access-token':
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if grant_type == 'urn:wargaming:params:oauth:grant-type:token1':
            account = WGNIUsersDB.get_account_by_token1(params.get('token'))
        
        if grant_type == 'urn:wargaming:params:oauth:grant-type:external-steam':
            account = WGNIUsersDB.get_account_by_steam_auth(region=region)
            
        if grant_type == 'urn:wargaming:params:oauth:grant-type:external-china360':
            account = WGNIUsersDB.get_account_by_cn360_auth()
            scope = 'account.name.update account.stated_country account.youtube_tokens.uid account.signature ' \
                    'account.credentials.oauth_long_lived_token.create account.credentials.additional_token.create ' \
                    'openid account.teleport account.credentials.token1.create account.external.google.access_token ' \
                    'account.country_legal account.minors account.game_fields openid.email openid.login read'.split()
        
        expires_in = 3600
        short_grant_type = grant_type.split(":")[-1]
        if account:
            account.scopes = scope
            account.oauth_token = oauth_token
            account.client_id = client_id
            account.oauth_token_exp_time = ceil(time() + expires_in)
            account.exchange_code = exchange_code
            account.requested_grant_types.append(short_grant_type)

        prepare_url = f'{short_grant_type}/{oauth_token}'
        ticket_address = (f'{WGCConfig.wgni_url}/realm_{region}/id/api/v2/account/'
                          f'credentials/create/oauth/token/{prepare_url}/')
        resp = web.json_response({}, status=202, headers={'Location': ticket_address})
        if account:
            account.tid = tid
        
        return resp

    async def post(self):
        return await self._on_post()
