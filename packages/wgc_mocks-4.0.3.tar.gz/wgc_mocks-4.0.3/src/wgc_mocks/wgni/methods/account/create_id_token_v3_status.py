﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from time import time

import jwt
from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_core.logger import get_logger
from wgc_mocks.wgni.storage import WGNIUsersDB

log = get_logger(__name__)


class CreateIDTokenV3Status(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/wgni-4406/#api-v3-account-credentials-create-idtoken-token
    """
    
    async def _on_get(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        region = self.request.match_info.get('realm')
        token = self.request.match_info.get('token')  # noqa
        account = WGNIUsersDB.get_account_by_any_token(token)
        if account is None:
            return web.json_response({}, status=409)
        iat = int(time())
        expires_in = 3600
        fields = account.id_token_fields
        id_token_data = {
            'iss': '%s/realm_%s/' % (WGCConfig.wgni_url, region),
            'sub': account.id,
            'aud': account.client_id,
            'iat': iat,
            'exp': iat + expires_in,
            'nickname': account.nickname,
            'game_realm': account.realm,
        }
        if fields is not None:
            for field in fields.split(','):
                id_token_data[field] = getattr(account, field, None)
        id_token = jwt.encode(id_token_data, 'secret', algorithm='HS256')
        account.id_token = id_token
        return web.json_response({'idtoken': id_token}, status=200)
    
    async def get(self):
        return await self._on_get()
