﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from time import time

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetOauthTokenInfo(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-credentials-verify-oauth-token
    """

    async def _on_get(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        access_token = self.request.query.get('access_token')
        # endregion
        exchange_code = None
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        if account.oauth_token_exp_time < time():
            return web.json_response({}, status=401)
        scopes = WGNIUsersDB.custom_scopes or account.scopes
        return web.json_response({'scope': scopes,
                                  'expires_at': account.oauth_token_exp_time,
                                  'account_id': account.id,
                                  'client_id': account.client_id}, status=200)

    async def get(self):
        return await self._on_get()
