﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web
from wgc_mocks.wgni import WGNIUsersDB


class AccountAddStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-account-info-token
    """
    
    async def _on_get(self):
        """
        Method for further monkey patching.
        """
        game_realm = self.request.match_info.get('gamerealm')
        nickname = self.request.match_info.get('nickname')
        token = self.request.match_info.get('token')
        user_account = WGNIUsersDB.get_account_by_any_token(token)
        new_account = WGNIUsersDB.add_account(
            user_account.username, user_account.password, nickname, realm=game_realm)
        if user_account.steam_bound:
            new_account.steam_bound = True
        persona = WGNIUsersDB.get_persona_by_persona_id(user_account.persona_id)
        result_data = []
        for index, account in enumerate(persona.accounts):
            result_data.append({'name': account.nickname, 'game_realm': account.realm, 'id': account.id})

        data = {
            "accounts": result_data,
            "created": {
                "id": new_account.id,
                "game_realm": game_realm,
                "name": nickname
            }
        }
        WGNIUsersDB.persona_available_realms = []
        return web.json_response(data, status=200)
    
    async def get(self):
        return await self._on_get()
