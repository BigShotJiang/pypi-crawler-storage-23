﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from base64 import b64decode

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_helpers.encrypt_helper import EncryptHelper


class TicketConsume(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-game-ticket-consume
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        game_ticket = params.get('game_ticket')  # noqa
        token_secret = params.get('token_secret')  # noqa

        if WGNIUsersDB.external_account:
            token1 = WGNIUsersDB.generate_token1()
            if WGNIUsersDB.external_account.username:
                account = WGNIUsersDB.set_token1_for_username(
                    WGNIUsersDB.external_account.username, WGNIUsersDB.external_account.realm, token1)
                WGNIUsersDB.external_account = account
            else:
                WGNIUsersDB.external_account.token1 = token1
            token_encrypted = EncryptHelper.b64aes_ctr_encode(b64decode(token_secret), str(token1))
            return web.json_response({
                "account_id": WGNIUsersDB.external_account.id,
                "token_encrypted": token_encrypted.decode('utf-8'),
                "authentication_method": "external:facebook",
            }, status=200)
        else:
            return web.json_response({}, status=202)

    async def post(self):
        return await self._on_post()
