# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class SignToken(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#signin-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        return web.json_response({})

    async def get(self):
        return self._on_get()
