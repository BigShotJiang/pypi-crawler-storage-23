# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class SignGame(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#signin-game
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        return web.json_response({}, status=302, headers={'Location': 'https://ru.wargaming.net/id/signin/'})

    async def get(self):
        return self._on_get()
