﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class TicketIssue(web.View):
    """
    https://rtd.wargaming.net/docs/wgni/en/latest/#api-v2-game-ticket-issue
    """

    def _on_post(self):
        """
        Method for further monkey patching.
        """
        ticket = WGNIUsersDB.generate_ticket()
        return web.json_response({
            "game_ticket": ticket,
            "expires_in": 1800}, status=201)

    async def post(self):
        return self._on_post()
