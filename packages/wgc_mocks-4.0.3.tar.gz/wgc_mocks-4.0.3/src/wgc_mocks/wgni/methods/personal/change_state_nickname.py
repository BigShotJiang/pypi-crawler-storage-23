﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.config import WGCConfig


class ChangeStateNickname(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/master/api/index.html#personal-api-v2-account-name-update-state
    """
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        region = self.request.match_info.get('realm')
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
        else:
            return web.json_response({}, status=401)

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        token = WGNIUsersDB.create_ticket()
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v2/account/name/update/' \
                         f'state/status/{token}/'
        return web.json_response({}, status=202, headers={
            'Location': ticket_address, 'HTTP_X_NP_TRACKING_ID': "01HSB0P36QGSEAH814RP6PWS17"})

    async def post(self):
        return await self._on_post()
