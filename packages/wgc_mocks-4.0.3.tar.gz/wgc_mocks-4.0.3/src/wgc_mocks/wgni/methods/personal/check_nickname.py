﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import random
import string

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CheckNickname(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/stable/#account-nicknames-nickname
    """

    def _check_nickname(self, nickname, realm, suggestions=False):
        """
        Checks is specified nickname already exist or not.

        :param str nickname: nickname.
        :param bool suggestions: indicates is suggestions needed.
        :rtype: dict
        :return: dict that could be converted to response json.
        """
        response = {}
        result = WGNIUsersDB.get_account_by_nickname(nickname, realm)
        if result:
            response['spa_id'] = None if WGNIUsersDB.personal_account_banned else result.id
            if suggestions:
                suggestions = []
                for _ in range(5):
                    suggestions.append(
                        '%s_%s' %
                        (nickname,
                         ''.join(
                             random.choice(string.digits) for _ in range(4))))
                response['suggestions'] = suggestions
                response['banned'] = WGNIUsersDB.personal_account_banned
        else:
            response['banned'] = WGNIUsersDB.personal_account_banned
            response['spa_id'] = None

        return response

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        # TODO: Seems that this method is obsolete.
        suggestions = self.request.query.get('suggestions')
        nickname = self.request.match_info.get('nickname')
        # endregion

        if not nickname:
            return web.json_response({}, status=409)
        region = self.request.match_info.get('realm')
        nickame_response = self._check_nickname(nickname, region, bool(suggestions))
        return web.json_response(nickame_response, status=200)

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        nickname = self.request.match_info.get('nickname')
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        suggestions = params.get('suggestions')
        # endregion

        if not nickname:
            return web.json_response({}, status=409)

        nickame_response = self._check_nickname(nickname, region, bool(suggestions))
        return web.json_response(nickame_response, status=200)

    async def get(self):
        return self._on_get()

    async def post(self):
        return await self._on_post()
