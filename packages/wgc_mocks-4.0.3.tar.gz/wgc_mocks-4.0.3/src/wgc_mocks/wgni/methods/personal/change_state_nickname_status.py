# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class ChangeStateNicknameStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/master/api/index.html#personal-api-v2-account-name-update-state-status-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        data = {"extras": {"available": True,
                           "sources": [["wgc", "gold", 2500], ["wot", "gold", 2500], ["wotb", "gold", 2500],
                                       ["wows", "gold", 3500]]}}
        return web.json_response(data, status=200)

    async def get(self):
        return self._on_get()
