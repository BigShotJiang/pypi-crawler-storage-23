﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import json

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CheckNameUpdateTicketStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnr/en/latest/#v2-ticket-status-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        data = \
            json.dumps({'errors': {'__all__': ['generic']}})
        token = self.request.match_info.get('token')
        resp = web.json_response(data, status=409)

        ticket = WGNIUsersDB.get_ticket_by_background_task(token)
        if ticket:
            return web.json_response({'ticket': ticket.id}, status=200)
        return resp

    async def get(self):
        return self._on_get()
