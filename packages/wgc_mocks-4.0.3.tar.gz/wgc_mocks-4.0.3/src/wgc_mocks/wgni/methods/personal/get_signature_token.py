# -*- coding: utf-8 -*-

__author__ = 'p_poddubnyak@wargaming.net'

from aiohttp import web


class SignatureToken(web.View):

    """
    https://rtd.wargaming.net/docs/wgnp/en/latest/api/index.html#account-signature-api-v2
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        return web.json_response({}, status=200)

    async def get(self):
        return self._on_get()
