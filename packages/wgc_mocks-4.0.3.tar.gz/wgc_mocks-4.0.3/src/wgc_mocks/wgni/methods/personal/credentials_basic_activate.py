﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB, AccountStatuses
from wgc_core.config import WGCConfig


class CredentialsBasicActivate(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/stable/#personal-api-v2-account-credentials-basic-activate
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        code = params.get('code')
        game = params.get('game')  # noqa
        # endregion

        if not code:
            return web.json_response({'errors': {'code': ['required']}}, status=400)

        exchange_code = None
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        if account.activation_code and account.activation_code != code:
            return web.json_response({'errors': {'__all__': [
                'incorrect_confirmation_code']}}, status=400)

        account.username = account.pending_username
        account.password = account.pending_password
        account.status = AccountStatuses.ACTIVATED
        account.pending_username = None
        account.pending_password = None
        account.activation_code = None
        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/credentials/' \
                         f'basic/activate/status/{token}/'

        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()
