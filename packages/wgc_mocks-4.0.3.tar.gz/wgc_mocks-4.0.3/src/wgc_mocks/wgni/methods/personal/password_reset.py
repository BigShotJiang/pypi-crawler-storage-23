# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class PasswordReset(web.View):
    """
    PasswordReset class.
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        return web.json_response({'password': 'reset'}, status=200)

    async def get(self):
        return self._on_get()
