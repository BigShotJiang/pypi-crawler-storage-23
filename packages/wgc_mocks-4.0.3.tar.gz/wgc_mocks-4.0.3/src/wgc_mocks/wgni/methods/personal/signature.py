﻿# -*- coding: utf-8 -*-

__author__ = 'p_poddubnyak@wargaming.net'

from aiohttp import web
import json

from wgc_mocks.wgni.storage import WGNIUsersDB


class Signature(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/latest/api/index.html#account-signature-api-v2
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = json.loads(await self.request.text())
        document_url = params.get('documents_url')
        # endregion

        exchange_code = None  # noqa
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        if not document_url:
            return web.json_response(
                {'errors': {'documents_url': ['required']}}, status=400)
        region = self.request.match_info.get('realm')
        account = WGNIUsersDB.get_account_by_oauth_token(access_token)
        if not account:
            return web.json_response(
                {'errors': ['invalid access token']}, status=401)
        token1 = WGNIUsersDB.generate_token1()
        WGNIUsersDB.set_token1_for_username(account.username, region, token1)
        token = \
            WGNIUsersDB.set_background_task_for_username(account.username, region)
        return web.json_response({}, status=202, headers={'Location': '%s/%s/' % (
            str(self.request.url).rstrip('/'), token)})

    async def post(self):
        return await self._on_post()
