# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class PersonalRealm(web.View):
	"""
	Personal class.
	"""

	def _on_get(self):
		"""
		Method for further monkey patching.
		"""
		region = self.request.match_info.get('realm')
		region = region.replace('cis', 'ru').replace('na', 'us').replace('asia', 'sg')
		return web.json_response({
			"realm": region,
			"country": 'UA'
		}, status=200)

	async def get(self):
		return self._on_get()
