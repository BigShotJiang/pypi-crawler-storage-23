﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import string
import random

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class ValidateNicknameToken(web.View):
	"""
	Personal class.
	"""

	def _check_nickname(self, nickname, realm, suggestions=False):
		"""
		Checks is specified nickname already exist or not.

		:param str nickname: nickname.
		:param bool suggestions: indicates is suggestions needed.
		:rtype: dict
		:return: dict that could be converted to response json.
		"""

		response = {}
		result = WGNIUsersDB.get_account_by_nickname(nickname, realm)
		if result:
			response['available'] = False
			if not WGNIUsersDB.personal_account_banned:
				response['exist'] = True
			if suggestions:
				suggestions = []
				for _ in range(5):
					suggestions.append('%s_%s' % (nickname, ''.join(random.choice(string.digits) for _ in range(4))))
				response['suggestions'] = suggestions

		else:
			if not WGNIUsersDB.personal_account_banned:
				response['available'] = True
				response['suggestions'] = []
				response['exist'] = False

		return response

	def _on_get(self):
		"""
		Method for further monkey patching.
		"""
		nickname = self.request.query.get('nickname')
		game_realm = self.request.query.get('game_realm')
		suggestions = self.request.query.get('suggestions')
		use_pattern = self.request.query.get('use_pattern') # noqa
		if not nickname:
			return web.json_response({}, status=409)
		nickname_response = self._check_nickname(nickname, game_realm, bool(suggestions))
		return web.json_response(nickname_response, status=200)

	async def get(self):
		return self._on_get()
