# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web


class Personal(web.View):
    """
    Personal class.
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        return web.json_response({'data': 'Nothing personal!'}, status=200)

    async def get(self):
        return self._on_get()
