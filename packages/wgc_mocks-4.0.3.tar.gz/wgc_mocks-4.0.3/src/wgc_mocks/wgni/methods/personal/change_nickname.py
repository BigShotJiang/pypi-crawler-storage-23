﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from time import time

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.config import WGCConfig


class ChangeNickname(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/latest/#personal-api-v2-account-name-update
    """

    available_costs = ['full',
                       'backyard_free_renaming',
                       'demo_free_first_renaming']

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region params parsing
        region = self.request.match_info.get('realm')
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        name = params.get('name')
        cost = params.get('cost')
        game = params.get('game')
        via = params.get('via')  # noqa
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
        else:
            return web.json_response({}, status=401)

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        errors = {}
        if not name:
            errors['name'] = ['required']

        if not cost:
            errors['cost'] = ['required']
        elif cost not in self.available_costs:
            errors['cost'] = ['invalid']

        if not game:
            errors['game'] = ['required']

        if errors:
            return web.json_response({'errors': errors}, status=400)

        account.nickname = name
        account.nickname_will_be_changed = time() + WGNIUsersDB.change_nickname_after
        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/name/update/' \
                         f'status/{token}/'
        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()
