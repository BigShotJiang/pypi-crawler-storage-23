﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni import WGNIUsersDB


class ValidateNickname(web.View):
	"""
	Personal class.
	"""

	async def _on_post(self):
		"""
		Method for further monkey patching.
		"""
		region = self.request.match_info.get('realm')
		if self.request.content_type == 'application/json' and self.request.body_exists:
			params = await self.request.json()
		else:
			params = dict(await self.request.post())
		suggestions = params.get('suggestions')
		use_pattern = params.get('use_pattern')
		game_realm = params.get('game_realm')
		nickname = params.get('nickname')
		token = WGNIUsersDB.generate_oauth_token()
		ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v3/account/nicknames/validate/status' \
						 f'/{token}/?suggestions={suggestions}&use_pattern={use_pattern}&game_realm={game_realm}&' \
						 f'nickname={nickname}'
		return web.json_response({}, status=202, headers={'Location': ticket_address})

	async def post(self):
		return await self._on_post()
