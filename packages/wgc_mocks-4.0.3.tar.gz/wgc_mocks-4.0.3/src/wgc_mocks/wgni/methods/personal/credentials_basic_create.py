﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import random
import string

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB
from wgc_core.config import WGCConfig


class CredentialsBasicCreate(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/master/api/index.html#personal-api-v2-account-credentials-basic-create
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        # region cookies parsing
        wgnp_sessionid = self.request.cookies.get('wgnp_sessionid')
        # endregion

        # region params parsing
        await asyncio.sleep(1.5)
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        type_ = self.request.query.get('type')
        login = params.get('login')
        password = params.get('password')
        game = params.get('game')  # noqa
        pow_ = params.get('pow')
        captcha = params.get('captcha')
        # endregion

        region = self.request.match_info.get('realm')
        exchange_code = None
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        errors = {}
        if not login:
            errors['login'] = ['required']

        if WGNIUsersDB.get_account_by_username(login, region):
            errors['login'] = ['forbidden']

        if len(login) < 7:
            errors['login'] = ['min_length']
        elif len(login) > 40:
            errors['login'] = ['max_length']

        if not password:
            errors['password'] = ['required']

        if len(password) < 7:
            errors['password'] = ['min_length']
        elif len(password) > 20:
            errors['password'] = ['max_length']

        if not password.strip(password[0]):
            errors['password'] = ['weak_password']

        challenge_result = \
            WGNIUsersDB.get_challenge_result_from_wgnp_session(wgnp_sessionid)

        if type_ == 'captcha':
            challenge = captcha
            if not challenge:
                errors['captcha'] = ['required']
            elif challenge != challenge_result:
                errors['captcha'] = ['invalid']
        else:
            challenge = pow_
            if not challenge:
                errors['pow'] = ['required']

        if errors:
            return web.json_response({'errors': errors}, status=400)

        account.pending_username = login
        account.pending_password = password
        if WGNIUsersDB.use_real_activation_code:
            activation_code = ''.join(random.choice(string.digits) for
                                      _ in range(4))
        else:
            activation_code = None

        account.activation_code = activation_code
        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/credentials/' \
                         f'basic/create/status/{token}/'

        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def post(self):
        return await self._on_post()

    def _on_get(self):
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')
        # endregion

        region = self.request.match_info.get('realm')
        exchange_code = None
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]

        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
        else:
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)

        if not account:
            return web.json_response({}, status=401)

        token = WGNIUsersDB.create_ticket()
        version = self.request.match_info.get('version')
        ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/credentials/' \
                         f'basic/create/status/{token}/'

        return web.json_response({}, status=202, headers={'Location': ticket_address})

    async def get(self):
        return self._on_get()
