﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import json

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CredentialsExternalSteamBindStatus(web.View):
	"""
	https://rtd.wargaming.net/docs/wgnp/en/master/api/index.html#personal-api-v2-account-credentials-external-steam-bind-status-token
	"""

	def _on_get(self):
		data = \
			json.dumps({'errors': {'__all__': ['external_already_bound']}})
		token = self.request.match_info.get('token')
		ticket = WGNIUsersDB.get_ticket_by_background_task(token)

		region = self.request.match_info.get('realm')

		if ticket:
			account = WGNIUsersDB.get_account_by_username(ticket.email, region)
			if not account:
				return web.json_response({}, status=401)

			account.steam_bound = True
			return web.json_response({}, status=200)
		return web.json_response(data, status=409)

	async def get(self):
		return self._on_get()
