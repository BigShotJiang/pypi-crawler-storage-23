﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
from time import time

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni import WGNIUsersDB


class PersonalPredictStatus(web.View):
    """
    Personal class.
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        token = self.request.match_info.get('token')
        account = WGNIUsersDB.get_account_by_predict_background_task(token)
        region = self.request.match_info.get('realm')
        
        if not account:
            return web.json_response({}, status=401)
        if WGNIUsersDB.predicted_realm is not None:
            predicted_realm = WGNIUsersDB.predicted_realm
        else:
            predicted_realm = account.teleport_request_data.get('realm') if account.teleport_request_data else 'eu'
            
        if WGNIUsersDB.predicted_timer is not None and account.predict_started_time is None:
            account.predict_started_time = time()
        
        if predicted_realm == 'ru':
            return web.json_response({
                "status": 'answered',
                "error_data": {"choice": "ru"}}, status=409)
        
        if not account.completed:
            return web.json_response({
                "status": "account_is_incomplete", "predicted_realm": predicted_realm, "clans": [],
                "error_data": {
                    "completion_url": f"{WGCConfig.wgni_url}/realm_{region}/personal/credentials/basic/"
                }},
                status=409)

        status = 'processed'
        new_account = account.teleport_account
        if account.teleport_status is None or account.teleport_account is None:
            account.teleport_status = 'predicted'

            return web.json_response({
                "predicted_realm": predicted_realm,
                "clans": [
                    {
                        "status": "active",
                        "game": "wot",
                        "id": 14000022229,
                        "name": "teleport_clan1"
                    },
                    {
                        "status": "active",
                        "game": "wotb",
                        "id": 14000022228,
                        "name": "teleport_clan2"
                    },
                    {
                        "status": "active",
                        "game": "wows",
                        "id": 14000022227,
                        "name": "teleport_clan3"
                    },
                    {
                        "status": "active",
                        "game": "wot",
                        "id": 14000022226,
                        "name": "teleport_clan4"
                    },
                    {
                        "status": "active",
                        "game": "wot",
                        "id": 14000022225,
                        "name": "teleport_clan5"
                    }
                ]
            }, status=200)
        elif account.teleport_status == 'predicted':
            account.teleport_status = 'predicted2'
            return web.json_response(
                {"status": "in_progress", "error_data": {"progress": {
                    "data": {"new_wgid": 550021028, "source_email": account.username,
                             "target_email": new_account.username, "free_rename": False,
                             "source_name": account.nickname, "target_name": new_account.nickname,
                             "external_status": {"email": True, "oldspa": False, "steam": True, "newspa": False},
                             "game_accounts": {}}, "target_realm": predicted_realm, "state": 401}}}, status=409)
        elif account.teleport_status == 'predicted2':
            if WGNIUsersDB.predicted_timer is not None:
                if int(time() - account.predict_started_time) > WGNIUsersDB.predicted_timer:
                    account.teleport_status = 'processed'
            else:
                account.teleport_status = 'processed'
            return web.json_response(
                {"status": "in_progress", "error_data": {"progress": {
                    "data": {"new_wgid": 550021028, "source_email": account.username,
                             "target_email": new_account.username, "free_rename": False,
                             "source_name": account.nickname, "target_name": new_account.nickname,
                             "external_status": {"email": True, "oldspa": False, "steam": True, "newspa": False},
                             "game_accounts": {}}, "target_realm": predicted_realm, "state": 401}}}, status=409)
        else:
            error_data = {
                "progress": {
                    "data": {
                        "new_wgid": new_account.id, "free_rename": False,
                        "source_name": account.nickname,
                        "target_name": new_account.nickname,
                        "external_status": {
                            "email": True, "oldspa": False, "newspa": False
                        },
                        "game_accounts": {},
                        "token1": account.token1
                    },
                    "target_realm": predicted_realm,
                    "state": 900}
            }
            return web.json_response({
                "status": status,
                "error_data": error_data}, status=409)

    async def get(self):
        await asyncio.sleep(WGNIUsersDB.predict_timeout)
        return self._on_get()
