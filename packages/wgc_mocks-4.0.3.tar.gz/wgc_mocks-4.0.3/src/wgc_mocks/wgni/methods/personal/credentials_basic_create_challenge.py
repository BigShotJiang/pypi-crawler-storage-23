﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import string
import random
from time import time

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CredentialsBasicCreateChallenge(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/stable/#personal-api-v2-account-credentials-basic-create-challenge
    """

    ip_asks = {}
    ban_timeout = 1

    def _on_get(self):
        """
        Method for further monkey patching.
        """

        # region params parsing
        type_ = self.request.query.get('type')
        # endregion

        if self.ip_asks.get(self.request.remote):
            if time() - self.ban_timeout <= self.ip_asks[self.request.remote]:
                return web.json_response({'errors_codes': {'__all__': ['banned']}}, status=400)

        self.ip_asks[self.request.remote] = time()
        sessionid = WGNIUsersDB.generate_session_id()

        if type_ == 'captcha':
            if WGNIUsersDB.use_real_captcha:
                challenge_result = ''.join(random.choice(string.digits) for
                                           _ in range(6))
            else:
                challenge_result = None
            WGNIUsersDB.set_challenge_result_for_wgnp_session(
                sessionid, challenge_result=challenge_result)
            data = {
                'captcha': {
                    'url': '/id/captcha/%s' % (challenge_result or
                                               'universal_captcha'),
                    'token': '',
                    'type': 'captcha'
                }}
        else:
            # TODO: update when pow counting will be done
            WGNIUsersDB.set_challenge_result_for_wgnp_session(
                sessionid, challenge_result=None)
            data = {
                'pow': {
                    'timestamp': int(time()),
                    'complexity': 3,
                    'type': 'pow',
                    'algorithm': {
                        'version': 1,
                        'resourse': 'wgnp',
                        'name': 'hashcash',
                        'extension': ''
                    },
                    'random_string': ''.join(random.choice(
                        string.ascii_letters) for _ in range(16))
                }}
        resp = web.json_response(data, status=200)
        resp.set_cookie('wgnp_sessionid', sessionid)
        return resp

    async def get(self):
        return self._on_get()
