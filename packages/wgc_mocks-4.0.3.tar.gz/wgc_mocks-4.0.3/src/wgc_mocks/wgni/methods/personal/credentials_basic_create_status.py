﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class CredentialsBasicCreateStatus(web.View):
    """
    https://rtd.wargaming.net/docs/wgnp/en/stable/#personal-api-v2-account-credentials-basic-create-status-token
    """

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        token = self.request.match_info.get('token')
        ticket = WGNIUsersDB.get_ticket_by_background_task(token)
        return web.json_response({'login': ticket.email, 'state': 'email_activated'}, status=200)

    async def get(self):
        return self._on_get()
