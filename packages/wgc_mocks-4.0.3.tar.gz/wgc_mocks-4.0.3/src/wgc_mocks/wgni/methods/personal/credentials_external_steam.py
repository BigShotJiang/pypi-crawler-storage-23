﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni.storage import WGNIUsersDB


class CredentialsExternalSteam(web.View):
	"""
	https://rtd.wargaming.net/docs/wgnp/en/master/api/index.html#personal-api-v2-account-credentials-external-steam
	"""

	async def _on_post(self):
		# region headers parsing
		authorization = self.request.headers.get('AUTHORIZATION')

		# endregion

		# region params parsing
		if self.request.content_type == 'application/json' and self.request.body_exists:
			params = await self.request.json()
		else:
			params = dict(await self.request.post())
		game_id = params.get('game_id')
		auth_session_ticket = params.get('auth_session_ticket')

		region = self.request.match_info.get('realm')

		exchange_code = None
		if authorization:
			access_token, exchange_code = \
				(authorization.split()[-1].split(':') + [None])[:2]

		if exchange_code:
			account = WGNIUsersDB.get_account_by_long_lived_token(
				access_token, exchange_code)
		else:
			account = WGNIUsersDB.get_account_by_oauth_token(access_token)

		if not account:
			return web.json_response({}, status=401)

		if not game_id:
			return web.json_response({'errors': {"game_id": ["required"]}}, status=400)

		if not auth_session_ticket:
			return web.json_response({'errors': {"auth_session_ticket": ["required"]}}, status=400)

		account.steam_auth_session_ticket = auth_session_ticket
		account.steam_game_id = game_id
		token = WGNIUsersDB.create_ticket(email=account.username)
		version = self.request.match_info.get('version')
		ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/credentials/' \
						 f'external/steam/bind/status/{token}/'

		return web.json_response({}, status=202, headers={'Location': ticket_address})

	async def post(self):
		return await self._on_post()

	async def delete(self):
		return self._on_delete()

	def _on_delete(self):
		# region headers parsing
		authorization = self.request.headers.get('AUTHORIZATION')

		# endregion

		region = self.request.match_info.get('realm')

		exchange_code = None
		if authorization:
			access_token, exchange_code = \
				(authorization.split()[-1].split(':') + [None])[:2]

		if exchange_code:
			account = WGNIUsersDB.get_account_by_long_lived_token(
				access_token, exchange_code)
		else:
			account = WGNIUsersDB.get_account_by_oauth_token(access_token)

		if not account:
			return web.json_response({}, status=401)

		token = WGNIUsersDB.create_ticket()
		version = self.request.match_info.get('version')
		ticket_address = f'{WGCConfig.wgni_url}/realm_{region}/personal/api/v{version}/account/credentials/' \
						 f'external/steam/unbind/status/{token}/'

		return web.json_response({}, status=202, headers={'Location': ticket_address})
