﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import operator
import uuid
import random
import string
import base64
from math import ceil
from time import time
import json
from copy import deepcopy

from linqp import Linqp

from wgc_core.config import WGCConfig
from wgc_helpers.requirements_helper import RequirementHelper
from wgc_core.logger import get_logger

log = get_logger(__name__)
products_log = get_logger('products')


class WGNException(Exception):
    """
    Class represent WGNI and WGNR exceptions.
    """


class WGCPSException(Exception):
    """
    Class represent WGCPS exceptions.
    """


class AccountStatuses:
    NOT_ACTIVATED = 0
    ACTIVATED = 1


class NotificationAction:
    MESSAGE_SHOWN = '0'
    MESSAGE_CLOSE = '1'
    MESSAGE_CONFIRM = '2'
    CLICK_BTN_1 = '3'
    CLICK_BTN_2 = '4'
    CLICK_BTN_3 = '5'
    CLICK_BTN_4 = '6'
    OTHER = '9'


class NotificationType:
    NEWS = '1'
    ANONYMOUS = '2'
    AUTHORIZED = '3'


class NotificationView:
    MODAL = '0'
    TRAY = '1'
    WAC = '2'
    WGC_MENU = '3'


class Storefront:
    
    def __init__(self):
        self.wgc_showcase = []
        self.wgc_games_install = []
        self.wgc_game_shop = []
        self.wgc_game_shop_dd = []
        self.test_storefront = []
        self.wgc_buy_game = []
    
    def __getitem__(self, item):
        return getattr(self, item, None)
    
    def clear_storefront(self):
        self.wgc_showcase.clear()
        self.wgc_games_install.clear()
        self.wgc_game_shop.clear()
        self.wgc_buy_game.clear()
        self.wgc_game_shop_dd.clear()
        self.test_storefront.clear()
    
    def __str__(self):
        return f'wgc_showcase = {self.wgc_showcase}, ' \
               f'wgc_games_install={self.wgc_games_install} ' \
               f'wgc_game_shop={self.wgc_game_shop} ' \
               f'wgc_game_shop_dd={self.wgc_game_shop_dd} ' \
               f'wgc_buy_game={self.wgc_buy_game}'


class Inventory(object):
    
    def __init__(self, shared_currency_free_xp, shared_currency_gold,
                 wot_credits, wot_crystal, wows_gold, premium, premium_plus, wows_credits):
        self.shared_currency_free_xp = shared_currency_free_xp
        self.shared_currency_gold = shared_currency_gold
        self.wot_credits = wot_credits
        self.wows_gold = wows_gold
        self.premium = premium
        self.premium_plus = premium_plus
        self.wot_crystal = wot_crystal
        self.wows_credits = wows_credits
    
    def __str__(self):
        return (f'shared_currency_free_xp={self.shared_currency_free_xp}, '
                f'shared_currency_gold={self.shared_currency_gold}, '
                f'wot_credits={self.wot_credits}, wows_gold={self.wows_gold}, '
                f'premium={self.premium}, premium_plus={self.premium_plus}, '
                f'wot_crystal={self.wot_crystal}, wows_credits={self.wows_credits}')
    
    
class PersonaAccount(object):
    def __init__(self, persona_id, username, realm):
        self.accounts = []
        self.realm = realm
        self.persona_id = persona_id
        self.persona_link = None
        self.username = username  # john_doe@somewhere.com
    
    def __str__(self):
        return f'<persona_id="{self.persona_id}" realm={self.realm} username="{self.username}">'
    
    def __repr__(self):
        return self.__str__()
    
    def search_account_by_username(self, username, realm, steam_auth_session_ticket):
        """
        Search in included accounts on personal account by username and realm.

        :param str realm: realm.
        :param str username: username.
        :param str steam_auth_session_ticket: steam_auth_session_ticket
        :rtype: UserAccount
        :return: account.
        """
        account = Linqp(self.accounts).where(
            lambda x: (x.username.lower() == username.lower() or
                       x.steam_auth_session_ticket == steam_auth_session_ticket) and x.realm == realm).select_all()
        if account:
            return account[0]
        
    def search_account_by_id(self, account_id):
        """
        Search in included accounts on personal account by account_id and realm.

        :param str account_id: account_id.
        :rtype: UserAccount
        :return: account.
        """
        account = Linqp(self.accounts).where(
            lambda x: x.id == account_id).select_all()
        if account:
            return account[0]


class UserAccount:
    
    def __init__(self, account_id, username, password,
                 nickname='simple_nickname', background_task=None,
                 account_status=AccountStatuses.ACTIVATED, tid=None,
                 shared_currency_free_xp=0, shared_currency_gold=0,
                 wot_credits=0, wot_crystal=0, wows_gold=0, premium=0, wows_credits=0,
                 realm='cis', notifications=None, otp_code=None,
                 backup_code=None, premium_plus=0, auth_session_ticket=None, steam_game_id=None,
                 game_fields=None, teleport_status=None, address=None, scopes=None, persona_id=None,
                 steam_restrictions=None, default_accounts=None, persona_default=None, email_code=None):
        self.id = account_id  # 44526
        self.persona_id = persona_id
        self.username = username  # john_doe@somewhere.com
        self.password = password  # secret
        self.nickname = nickname  # simple_nickname
        self.steam_restrictions = steam_restrictions
        self.game_fields = game_fields or {'some_new_game_attr': 'some_new_value'}
        self.id_token_fields = None
        self.id_token = None
        self.nickname_will_be_changed = 0
        self.teleport_request_data = None
        self.teleport_status = teleport_status
        self.teleport_account = None
        self.predict_started_time = None
        self.token1 = None  # 94958424
        self.completed = True
        self.oauth_token_list = []
        self.oauth_token = None  # 9c46754984374a1cb187f20c79565fc2
        self.oauth_token_exp_time = None  # 1490366961.0
        self.additional_token = None  # 9c46754984374a1cb187f20c79565fc2
        self.additional_token_exp_time = None  # 1490366961.0
        self.exchange_code = None  # fdbZs6CrqbwlMPfdbZs6CrqbwlMPfdbZ
        self.client_id = None  # lQBa5PrkTpSYcEOqdktRnblI1mcv6DEVV5JB4m4f
        self.background_task = background_task  # a4ffd5c9a30f73p424a9a878ae646fe9c
        self.background_task_teleport = background_task  # a4ffd5c9a30f73p424a9a878ae646fe9c
        self.background_task_predict = []  # a4ffd5c9a30f73p424a9a878ae646fe9c
        self.tid = tid  # 13894322072530782000
        self.status = account_status  # 1
        self.activation_code = None  # 5467
        self.birthdate = '01/04/1988'
        self.stated_country = 'UA'
        self.pending_username = None  # john_doe@somewhere.com
        self.pending_password = None  # new_secret
        self.steam_auth_session_ticket = auth_session_ticket
        self.steam_game_id = steam_game_id
        self.agate_order_id = None
        self.steam_order_id = None
        self.requested_grant_types = []
        self.default_accounts = default_accounts
        self.persona_default = persona_default
        self.realm = realm
        initial_scopes = ['account.external.google.access_token', 'account.youtube_tokens.uid', 'openid.login',
                          'account.country_legal', 'account.teleport', 'account.stated_country', 'account.game_fields',
                          'account.credentials.token1.create', 'openid.email', 'read', 'account.name.update',
                          'account.credentials.oauth_long_lived_token.create', 'account.signature', 'account.minors',
                          'account.credentials.additional_token.create', 'openid', 'account.basic.update',
                          'account.credentials.add_account', 'account.persona', 'persona.default_accounts']

        self.scopes = scopes or initial_scopes
        self.otp_code = otp_code
        self.steam_bound = True if self.steam_auth_session_ticket else False
        self.backup_code = backup_code
        self.email_code = email_code
        self.storefront = Storefront()
        self.current_log_Id = None
        self.order_product_id = None
        self.next_action = None
        self.address = address or {}
        self.order_product_code = None
        self.order_id = None
        self.inventory = Inventory(
            shared_currency_free_xp, shared_currency_gold,
            wot_credits, wot_crystal, wows_gold, premium, premium_plus, wows_credits)
        self.notifications = notifications or []
    
    def __str__(self):
        return (f'<account_id="{self.id}" realm={self.realm} username="{self.username}" password="{self.password}" '
                f'nickname="{self.nickname}" oauth_token="{self.oauth_token}">')
    
    def __repr__(self):
        return self.__str__()


class WGNTicket:
    
    def __init__(self, id_, errors, email):
        self.id = id_
        self.errors = errors
        self.email = email


class IconType:
    info = 'info'
    error = 'error'
    question = 'question'
    warning = 'warning'


class WGNotification:
    class CommandID:
        OPEN_LINK = 'OPEN_LINK'
    
    def __init__(self, title, text, state='unread', priority='medium',
                 body_text='OK', body_text2='OK', icon_type=IconType.question,
                 command_id=CommandID.OPEN_LINK, link='http://google.com', created_at=None,
                 expired_at=None, negative_id=False, tag=None):
        RequirementHelper.append_requirement('LLR.2.78')
        self.title = title
        self.text = text
        self.tag = tag
        self.state = state
        self.notification_id = random.randint(1111111111111111, 9999999999999999)
        if negative_id:
            self.notification_id = - self.notification_id
        self.body_text = body_text
        self.body_text2 = body_text2
        self.priority = priority
        self.command_id = command_id
        self.link = link
        self.icon_type = icon_type
        self.created_at = created_at or ceil(time())
        self.expired_at = expired_at or ceil(time() + 30 * 24 * 60 * 60)
    
    def json(self) -> dict:
        result = {'notification_id': self.notification_id,
                  'mbox': 'wgc',
                  "message": {
                      'title': self.title,
                      'text': self.text,
                      'priority': self.priority,
                      'icon_type': self.icon_type,
                      'alert_params': {
                          'actions_order': ['confirm', 'close'],
                          'actions': {"confirm": {
                              "text": self.body_text,
                              "command_id": self.command_id,
                              "arguments": {
                                  "link": self.link,
                              }},
                              'close': {'text': self.body_text2,
                                        "command_id": self.command_id,
                                        "arguments": {
                                            "link": self.link,
                                        }
                                        },
                              'retry': {'text': 'Retry'}}}},
                  "created_at": self.created_at}
        if self.expired_at:
            result['expires_at'] = self.expired_at
        if self.tag:
            result['tag'] = self.tag
        return result


class WGTrayModalNotification:
    overridden_icon = "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/override_icon.png"
    hero_image = "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/hero_image.png"
    
    def __init__(self, created_at=None, expired_at=None, remind_time=10, schema_version=3.0,
                 overridden_icon=overridden_icon, hero_image=hero_image, negative_id=False,
                 mbox='wgc', title_id=None, modal_buttons=None,
                 tray_buttons: list = None, menu_action: str = 'no_action',
                 balloon_action: str = 'no_action', play_game_id: str = 'ALICE.RU.PRODUCTION',
                 clipboard_data: str = 'clipboard data', redeem_code: str = 'code-to-redeem', show_only_tray=False,
                 show_only_modal=False):
        RequirementHelper.append_requirement('LLR.2.78')
        modal_buttons = modal_buttons or ['open_link']
        tray_buttons = tray_buttons or ['play_game', 'remind_later']
        self.notification_id = random.randint(1111111111111111, 9999999999999999)
        if negative_id:
            self.notification_id = - self.notification_id
        self.created_at = ceil(time()) or created_at
        self.remind_time = remind_time
        self.schema_version = float(schema_version)
        self.overridden_icon = overridden_icon
        self.hero_image = hero_image
        self.mbox = mbox
        self.title_id = title_id
        self.modal_buttons = modal_buttons
        self.tray_buttons = tray_buttons
        self.menu_action = menu_action
        self.balloon_actions = balloon_action
        self.play_game_id = play_game_id
        self.clipboard_data = clipboard_data
        self.redeem_code = redeem_code
        self.show_only_tray = show_only_tray
        self.show_only_modal = show_only_modal
        self.expired_at = expired_at or ceil(time() + 30 * 24 * 60 * 60)
    
    def json(self) -> dict:
        buttons_3_0 = [
            {
                "text": "PLAY",
                "command_id": "PLAY",
                "arguments": {
                    "game_application_id": "ALICE.RU.PRODUCTION"
                }
            },
            {
                "text": "Remind",
                "command_id": "REMIND_LATER",
                "arguments": {
                    "remind_time": self.remind_time
                }
            },
            {
                "text": "Close",
                "command_id": "CLOSE"
                
            },
            {
                "text": "Open",
                "command_id": "OPEN_LINK",
                "arguments": {
                    "link": "http://www.google.com"
                }
            }
        ]
        buttons_5_0 = {
            "play_game": {
                "text": "Play ALICE.RU.PRODUCTION",
                "highlighted": True,
                "command": "play_game"
            },
            "remind_later": {
                "text": "Remind later",
                "command": "remind_later"
            },
            "open_link": {
                "text": "Open link",
                "command": "link_inf"
            },
            "redeem_code": {
                "text": "Redeem code",
                "command": "redeem_code"
            },
            "copy": {
                "text": "Copy to buffer",
                "command": "copy"
            },
            "close": {
                "text": "Close",
                "command": "close"
            }
        }
        menu_actions_5_0 = {
            "open_alert": {"activate": {
                                  "command": "open_alert"
                              }},
            "open_link": {"activate": {
                                  "command": "link_menu"
                              }},
            "no_action": {"activate": {}}
        }
        balloon_actions_5_0 = {
            "open_link": {"activate": {
                                  "command": "link_menu"
                              }},
            "no_action": {"activate": {}}
        }
        commands = {
            "remind_later": {
                "command_id": "REMIND_LATER",
                "arguments": {
                    "remind_time": self.remind_time
                }
            },
            "play_game": {
                "command_id": "PLAY",
                "arguments": {
                    "game_application_id": self.play_game_id
                }
            },
            "open_alert": {
                "command_id": "REF_ALERT"
            },
            "close": {
                "command_id": "CLOSE"
            },
            "redeem_code": {
                "command_id": "REDEEM_WG_CODE",
                "arguments": {
                    "text_data": self.redeem_code
                }
            },
            "copy": {
                "command_id": "COPY_TO_BUFFER",
                "arguments": {
                    "text_data": self.clipboard_data
                }
            },
            "link_menu": {
                "command_id": "OPEN_LINK",
                "arguments": {
                    "link": "http://www.google.com"
                }
            },
            "link_inf": {
                "command_id": "OPEN_LINK",
                "arguments": {
                    "link": "http://www.google.com"
                }
            }
        }
        if self.schema_version == 5.0:
            tray_buttons_list = [buttons_5_0[item] for item in self.tray_buttons if item in buttons_5_0]
            modal_buttons_list = [buttons_5_0[item] for item in self.modal_buttons if item in buttons_5_0]
        else:
            tray_buttons_list = []
            modal_buttons_list = []
        buttons = buttons_3_0 if self.schema_version != 5.0 else tray_buttons_list
        result = {'state': 'unread',
                  "tag": '146855360:146851913:146855361',
                  'notification_id': self.notification_id,
                  'mbox': self.mbox,
                  "message": {
                      "schema_version": str(self.schema_version),
                      "menu_balloon_params": {
                          "title": "Test Automation Title",
                          "text": "Test Automation text " * 5,
                          "priority": "medium",
                          "overridden_icon": self.overridden_icon,
                          "menu_actions": {
                              "close": {
                              },
                              "activate": {
                                  "command_id": "REF_ALERT"
                              }
                          },
                          "hero_image": self.hero_image,
                          "buttons": buttons,
                          "balloon_actions": {
                              "close": {
                        
                              },
                              "activate": {
                        
                              }
                          }
                      },
                      "icon_type": "question",
                      "alert_params": {
                          "title": "Test Automation Alert notification",
                          "text": "Test Automation notification text " * 5,
                
                          "actions_order": [
                              "confirm",
                              "close"
                          ],
                          "actions": {
                              "confirm": {
                                  "text": "Test Automation Confirm",
                                  "command_id": "OPEN_LINK",
                                  "arguments": {
                                      "link": "https://ru.wargaming.net/ru/"
                                  }
                              },
                              "close": {
                                  "text": "Test Automation Close"
                              }
                          }
                      }
                  },
                  "created_at": self.created_at}
        if self.expired_at:
            result['expires_at'] = self.expired_at
        if self.schema_version == 2.0:
            result['message']['overridden_icon'] = result['message']['menu_balloon_params']['overridden_icon']
            del result['message']['menu_balloon_params']['overridden_icon']
        if self.schema_version >= 5.0:
            result['message']['menu_balloon_params']['hero_image_position'] = 'top'
            del result['message']['menu_balloon_params']['balloon_actions']
            result['message']['commands'] = commands
            result['message']['title_id'] = self.title_id
            result['message']['alert_params'] = {
                "title": "Test Automation Alert notification",
                "text": "Some Text",
                "image": "https://content-wg.gcdn.co/prm/2023/WoT/wgc/PRMP-32807/wgc_modal.jpg",
                "buttons": modal_buttons_list
            }
            if self.menu_action in menu_actions_5_0:
                result['message']['menu_balloon_params']['menu_actions'] = menu_actions_5_0[self.menu_action]
            if self.balloon_actions in balloon_actions_5_0:
                result['message']['menu_balloon_params']['balloon_actions'] = balloon_actions_5_0[self.balloon_actions]
            if self.show_only_modal:
                del result['message']['menu_balloon_params']
            if self.show_only_tray:
                del result['message']['alert_params']
        return result


class WGTrayNotification:
    class CommandID:
        OPEN_LINK = 'OPEN_LINK'
    
    def __init__(self, title, text, state='unread',
                 priority='high',
                 icon_type=IconType.info, command_id=CommandID.OPEN_LINK,
                 link='http://google.com', created_at=None, expired_at=None,
                 negative_id=False, tag=None):
        RequirementHelper.append_requirement('LLR.2.78')
        self.title = title
        self.text = text
        self.tag = tag
        self.state = state
        self.notification_id = random.randint(1111111111111111, 9999999999999999)
        if negative_id:
            self.notification_id = - self.notification_id
        self.priority = priority
        self.icon_type = icon_type
        self.created_at = ceil(time()) or created_at
        self.command_id = command_id
        self.link = link
        self.expired_at = expired_at or ceil(time() + 30 * 24 * 60 * 60)
    
    def json(self) -> dict:
        result = {'state': self.state,
                  'notification_id': self.notification_id,
                  'mbox': 'wgc',
                  "message": {
                      "schema_version": "2.0",
                      "title": self.title,
                      'priority': self.priority,
                      'icon_type': self.icon_type,
                      'menu_balloon_params': {
                          'text': self.text,
                          'menu_actions': {"close": {},
                                           "activate": {
                                               "command_id": self.command_id,
                                               "arguments": {
                                                   "link": self.link,
                                               }},
                                           },
                          "balloon_actions": {
                              "activate": {
                                  "command_id": "REF_ALERT"
                              },
                              "close": {}
                          },
                          "buttons": {
                              "button_1": {
                                  "button_name": "Play now",
                                  "button_command_id": "play"},
                              "button_2": {
                                  "button_name": "Cancel",
                                  "button_command_id": "close"}},
                          "buttons_order": ["button_1", "button_2"]}},
                  "created_at": self.created_at}
        if self.expired_at:
            result['expires_at'] = self.expired_at
        if self.tag:
            result['tag'] = self.tag
        return result


class WGNewsNotification:
    
    def __init__(self, messages):
        RequirementHelper.append_requirement('LLR.2.77')
        self.messages = messages
    
    def json(self) -> dict:
        news = []
        for message, link in self.messages.items():
            news.append({
                "message": message,
                "link": link
            })
        result = {
            "status": "ok",
            "data": {
                "WOT.RU.PRODUCTION": {
                    "ru": {
                        "news": news
                    }
                }
            }
        }
        return result


class WGProduct:
    buy_item_wgc_meta = {
        "background_image": {
            "mediatype": "image",
            "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_bg.jpeg",
            "preview_url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_bg.jpeg"
        },
        "grid_image": {
            "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_grid.png",
            "mediatype": "image",
            "preview_url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_item_grid.png"
        },
        "set_grid_image": {
            "url": "https://dwd.pershastudia.com/users/a_pogorelyy/products_grid_images_def/2x1_set.png",
            "mediatype": "image",
            "preview_url": "https://dwd.pershastudia.com/users/a_pogorelyy/products_grid_images_def/2x1_set.png"
        },
        "name": None,
        "original_image": {
            "mediatype": "image",
            "url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_original.png",
            "preview_url": "https://dwd.pershastudia.com/test_artifacts/test_data/cs_images/prem_original.png"
        },
        "description": None,
        "url": "https://127.0.0.1:7771/shop/wot/gold/13858/",
        "package_content": [
            "Золото",
            "Энтайтлмент"
        ],
        "automatic_package_content": None
    }
    
    buy_game_wgc_meta = {
        "grid_image": {
            "mediatype": "image",
            "url": "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/alice-logo.png",
            "preview_url": "http://lx-dwd.pershastudia.com/test_artifacts/test_data/cs_images/alice-logo.png"
        },
        "name": "Alice in Wonderworld",
        "url": "https://asia.wargaming.net/shop/twa/premium/PRODUCT_14PA/",
        "package_content": [
            "<ul><li>Buy Alice in Wonderworld!</li></ul>"
        ]
    }
    
    template = {
        "applied_promotions": [],
        "coupons": [
            "coupon!"
        ],
        "friendly_name": None,
        "name": None,
        "categories": [],
        "language": None,
        "metadata": {
            "pss": {},
            "wgc": {
                "application_id": None,
                "update_url": None,
            },
            'wgcps': {
                'prerequisites': {
                    'spa_flag_enabled': True,
                    'spa_game_code': None,
                    '@type': "Jsonb"
                }
            }
        },
        "payment_group": [],
        "client_payment_method_ids": [
        ],
        "price": {},
        "price_type": None,
        "giftable": False,
        "product_code": None,
        "product_id": None,
        "purchasable": True,
        "rewards": [
            ""
        ],
        "tags": [],
        "title_code": None,
        "visible": True
    }
    
    def __init__(
            self,
            friendly_name,
            language,
            application_id=None,
            update_url=None,
            product_code=None,
            title_code=None,
            title=None,
            spa_game_code=None,
            buy_game=False,
            available_for_non_auth=False,
            hard_link_id_hash=True,
            buy_item=False,
            secret=None,
            minimal_info=False,
            link_id=None,
            client_payment_method_ids=None,
            name=None,
            strong_product_code=False,
            tags=None,
            price_type='fixed',
            price=1734.5,
            discount_pct=33,
            limited_quantity=None,
            applied_promotions=None,
            with_discount_amount=True,
            storefront_category="premium",
            offer_labels=None,
            discount_type='percent',
            filter_properties=None,
            variable_price=None,
            quantity=1,
            purchase_restriction_reason=None,
            description=None,
            size_in_grid=None,
            set_id=None,
            set_name=None,
            rank=None,
    ):
        self.applied_promotions = applied_promotions or []
        self.limited_quantity = limited_quantity  # {"promotion_code": "test_promo_22", "purchase_allowed": true,
        # "personal_count": 0, "personal_limit": 5, "common_limit": 4, "common_count": 0}}
        self.strong_product_code = strong_product_code
        self.price_type = price_type.lower()
        self.variable_price = variable_price
        self.purchase_restriction_reason = purchase_restriction_reason
        self.quantity = quantity
        self.coupons = []
        self.size_in_grid = size_in_grid
        self.set_id = self.set_id = int(set_id) if set_id is not None else None
        self.set_name = set_name
        self.rank = self.rank = int(rank) if rank is not None else None
        if description is not None:
            self.description = description
        else:
            self.description = ("<p>However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                ""
                                "DESCRIPTION CONTINUE...."
                                "However you can purchase a special in-game currency: Gold. It can ease "
                                "your progress along the Tech Tree. Gold is a great opportunity to make "
                                "playing the game even more enjoyable and reach the desired target "
                                "much faster. "
                                "</p>")
        self.name = name or friendly_name
        self.offer_labels = offer_labels or []
        self.hard_link_id_hash = hard_link_id_hash
        self.friendly_name = friendly_name
        self.language = language.replace('_', '-')
        self.storefront_category = storefront_category
        self.filter_properties = filter_properties or []
        self.minimal_info = minimal_info
        self.application_id = application_id
        self.spa_game_code = spa_game_code
        if not buy_game and not spa_game_code:
            self.spa_game_code = application_id.split('.')[0].lower()
        self.update_url = update_url
        self.secret = secret
        self.payment_group = []
        self.price = price
        self.discount_pct = discount_pct
        self.discount_type = discount_type
        self.discount_amount = self.price * self.discount_pct / 100
        
        self.buy_game = buy_game
        self.buy_item = buy_item
        uniq_code = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
        self.product_code = (product_code or 'ALICE_GAME') + ('_' + uniq_code) * (not self.strong_product_code)
        self.product_id = str(uuid.uuid4())
        self.purchasable = True
        self.rewards = []
        self.tags = tags or []
        self.client_payment_method_ids = client_payment_method_ids
        self.title_code = title_code or "sg.wgc"
        self.title = title or "WGC"
        self.visible = True
        self.custom_link_id = link_id
        self.available_for_non_auth = available_for_non_auth
        self.with_discount_amount = with_discount_amount
        if storefront_category == 'premium':
            self.categories = [{"code": f"game_{storefront_category}", "order": 0},
                               {"code": f"wg_{storefront_category}", "order": 0}]
        elif storefront_category == 'gold':
            self.categories = [{"code": random.choice(
                ["default", "internet_plus", "by_sms", "by_coupon", "by_phone"]), "order": 0}]
        else:
            self.categories = [{"code": storefront_category, "order": 0}]
    
    def __str__(self):
        return self.json
    
    def __repr__(self):
        return '<%s@%s>' % (self.application_id, self.update_url)
    
    @property
    def json(self) -> str:
        result = deepcopy(self.template)
        buy_item_wgc_meta = deepcopy(self.buy_item_wgc_meta)
        result['applied_promotions'] = self.applied_promotions
        result['friendly_name'] = self.friendly_name
        result['name'] = self.name
        result['categories'] = self.categories
        result['language'] = self.language
        result['tags'] = self.tags
        result['price_type'] = self.price_type
        if self.price_type == 'ZERO':
            result['price']['real_price'] = {
                "currency_code": "UAH",
                "amount": "0",
                "original_amount": "0"
            }
        else:
            amount = str(self.price - self.discount_amount)
            result['price']['real_price'] = {
                "currency_code": "UAH",
                "amount": amount,
                "original_amount": str(self.price),
                "discount": {
                    "amount": str(self.discount_amount),
                    "pct": self.discount_pct
                }
            }
            
        if self.price_type.lower() == 'variable':
            result['variable_price'] = self.variable_price
            
        if not self.with_discount_amount:
            del result['price']['real_price']['discount']
            result['price']['real_price']['amount'] = str(self.price)
        else:
            result['discounts'] = [
                {
                    'item_type': "currency",
                    'code': "UAH",
                    'amount': str(self.discount_amount),
                    'discount_type': self.discount_type,
                    'pct': self.discount_pct,
                    'source': "promo"
                }
            ]
        
        if self.buy_game:
            self.buy_game_wgc_meta['package_content'][0] = self.friendly_name
            result['metadata']['wgc'] = self.buy_game_wgc_meta
            result['client_payment_method_ids'] = self.client_payment_method_ids or [82, 83, 84, 85, 86]
            del result['metadata']['wgcps']
        elif self.buy_item:
            buy_item_wgc_meta['package_content'] = []
            text = '<span class="bonus mceNonEditable" data-mce-contenteditable="false">-25%</span>'
            for i in range(10):
                buy_item_wgc_meta['package_content'].append(f'{text} {self.friendly_name} {i}')
            result['metadata']['wgc'] = buy_item_wgc_meta
            result['metadata']['wgc']['description'] = self.description
            result['metadata']['wgc']['name'] = self.friendly_name
            result['client_payment_method_ids'] = self.client_payment_method_ids or [82, 83, 84, 85, 86]
            del result['metadata']['wgcps']
            if self.minimal_info:
                if 'description' in result['metadata']['wgc'].keys():
                    del result['metadata']['wgc']['description']
        
        else:
            result['metadata']['wgc']['application_id'] = self.application_id
            result['metadata']['wgc']['update_url'] = self.update_url
            if self.secret is not None:
                result['metadata']['wgc']['secret'] = self.secret
            result['metadata']['wgcps']['prerequisites']['spa_game_code'] = self.spa_game_code
        result['product_code'] = self.product_code
        result['product_id'] = self.product_id
        result['title_code'] = self.title_code
        result['metadata']['wgc']['show_timer'] = bool(self.applied_promotions)
        result['metadata']['wgc']['offer_labels'] = self.offer_labels
        result['metadata']['wgc']['discount_showing_in'] = self.discount_type
        result['metadata']['wgc']['size_in_grid'] = self.size_in_grid
        result['metadata']['wgc']['set_id'] = self.set_id
        result['metadata']['wgc']['set_name'] = self.set_name
        result['metadata']['wgc']['rank'] = self.rank

        if self.purchase_restriction_reason:
            result['purchase_restriction_reason'] = self.purchase_restriction_reason
            result['purchasable'] = False
            result['product_type'] = 'loot_box'
        representation_items = [
            {
                "data": {
                    "code": "title"
                },
                "order": 3,
                "entity": "localization"
            },
            {
                "data": {
                    "value": 5
                },
                "order": 1,
                "entity": "amount"
            },
            {
                "data": {
                    "code": "style"
                },
                "order": 2,
                "entity": "system_text"
            }
        ]
        if self.storefront_category == 'vehicles':
            result['filter_properties'] = self.filter_properties
        if self.price_type == 'ZERO' or self.storefront_category == 'vehicles':
            result['entitlements'] = [{
                'code': "style_2d_01",
                'amount': 5,
                'order': 1,
                'compensation': {
                    'type': "NONE",
                    'amount': 0
                },
                'expiration': "0",
                'metadata': {}
            }]
            result['metadata']['wgc']['automatic_package_content'] = {
                "groups": [
                    {
                        "items": [
                            {
                                "order": 1,
                                "entity_code": "style_2d_01",
                                "content_type": "entitlement",
                                "content_order": 1,
                                "representation_items": representation_items
                            }
                        ],
                        "order": 1
                    }
                ],
                "context": {
                    "entitlement": {
                        "style_2d_01": {
                            "1": {
                                "title": "Style 2d uk"
                            }
                        }
                    }
                }
            }
        return json.dumps(result)
    
    @property
    def link_id(self) -> str:
        if self.custom_link_id is not None:
            return self.custom_link_id
        if self.hard_link_id_hash:
            link = f'{self.friendly_name} {self.language} {self.application_id} ' \
                   f'{self.update_url} {self.product_code} {self.buy_game}'
        else:
            link = f'{self.friendly_name} {self.language} {self.application_id} ' \
                   f'{self.update_url}'
        return base64.b64encode(link.encode()).decode()


class WGNIUsersDB(object):
    strong_check_language = False
    registration_adult_check = None
    accounts_list = []
    persona_list = []
    _products = []
    _titles = {}
    
    # Example {'a4ffd5c9a30f73p424a9a878ae646fe9': '111111'}
    _wgni_sessions = {}
    
    # Example {'a4ffd5c9a30f73p424a9a878ae646fe9': '111111'}
    _wgnr_sessions = {}
    
    # Example {'a4ffd5c9a30f73p424a9a878ae646fe9': '111111'}
    _wgnp_sessions = {}
    
    # Example {'nD4yi36wsqsSGxQpzPt5EY8itsz6lyYo': WGNTicket}
    _tickets = {}
    external_account = None
    create_new_nickname_on_teleport = False
    do_not_request_steam_api = False
    cache_products = 60
    change_nickname_after = 1
    use_real_captcha = False
    use_captcha_on_registration = False
    personal_account_banned = False
    use_two_factor_auth = False
    use_email_code = False
    default_email_code = '12345678'
    without_email_info = False
    demo_create_timeout = 1.5
    custom_scopes = []
    predicted_realm = None
    predicted_timer = None
    prepare_product_timeout = 0
    steam_account_for_oauth = None
    predict_timeout = 1
    variable_price_min = 200
    commerce_check_required = False
    commerce_account_status = 'disabled'  # Allowed:   enabled, disabled, not_bound
    commerce_method = 'tsv.otp'  # Allowed:   tsv.otp, password
    prepare_check_required = False
    prepare_account_status = 'disabled'  # Allowed:   enabled, disabled, not_bound
    prepare_method = 'tsv.otp'  # Allowed:   tsv.otp, password
    payments_methods_available = True
    
    redirect_url_present = True
    linked_methods = ['igp_credit_card_ab', 'credit_card_adyen', 'igp_qiwi']
    allowed_countries = ["BY"]
    detected_country_code = "BY"
    
    redirect_url = f'https://localhost/external/payment/'
    action_code_create_binding = None
    pay_pay = False
    commit_3ds2 = False
    commit_3ds1 = False
    billing_info_available = True
    billing_mandatory = False
    billing_applicable = True
    pow_complexity = 3
    use_real_activation_code = False
    persona_conflicted = False
    email = 'test_user@somewhere.com'
    password = 'Passw0rd'
    nickname = 'simple_nickname'
    region = 'DEV1'
    persona_enabled = True
    single_realm = False
    persona_available_realms = []
    
    wgn_realm_map = {'main': ['cis', 'eu', 'asia'], 'dev': ['dev1', 'dev2'], 'cn360': ['cn360']}
    wgn_realm_values = ['cis', 'eu', 'asia', 'dev1', 'dev2']
    
    default_auth_steam_ticket = "140000005dd35b31cbb26e9b5331b243010010018f44fa62180000000100000002000000fc91c75" \
                                "e4a828e4d1460000002000000d000000050000000040000005331b24301001001f47d1000d7615e" \
                                "b25533870a000000009144fa6211f4156301009b890500050080151500000081151500000082151" \
                                "5000000831515000000f85b1f0000000000dbdb068c26571ab56eca57b1e835b73f071e429adc68" \
                                "230c55066d3e33202560941a0ffad829c4c960e3d6cffeb97fb3f41d1a693e75069e8db4ece1151" \
                                "71f33c42d63ff75bfd6770d2a001750251ba5d7c93b2932313fc5fec91508396d5ede0f3d84b2f5" \
                                "b3d3b473e3a08f53d702df173b47233b5f10ef20557400076608090000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000000000" \
                                "0000000000000000000000000000000000000000000000000000000000000000000000000"
    
    @classmethod
    def get_steam_id(cls):
        return WGCConfig.steam.steam_id
    
    @classmethod
    def clear_accounts(cls):
        """
        Clear accounts list.
        """
        cls.accounts_list.clear()
        cls.persona_list.clear()
    
    @classmethod
    def get_logged_in_account(cls, realm):
        personas = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.realm == realm and a.oauth_token is not None).select_all()).select_all()
        persona_acc_sorted = []
        for persona in personas:
            accounts = sorted(persona.accounts,
                              key=lambda x: x.oauth_token_exp_time is not None and x.oauth_token_exp_time, reverse=True)
            if accounts:
                persona_acc_sorted.append(accounts[0])
        accounts = sorted(persona_acc_sorted,
                          key=lambda x: x.oauth_token_exp_time is not None and x.oauth_token_exp_time, reverse=True)
        if accounts:
            return accounts[0]
    
    @classmethod
    def change_nickname_for_username(cls, username, new_nickname, realm):
        """
        Change nickname for selected username.

        :param str realm: realm.
        :param str new_nickname: new nickname.
        :param str username: username.
        """
        account = cls.get_account_by_username(username, realm)  # type: UserAccount
        if account:
            account.nickname = new_nickname
            
    @classmethod
    def change_username(cls, username: str, new_username: str, realm):
        """
        Change username for selected username.

        :param str realm: realm.
        :param str new_username: new username.
        :param str username: username.
        """
        account = cls.get_account_by_username(username, realm)  # type: UserAccount
        if account:
            account.username = new_username
    
    @classmethod
    def get_notification_by_id(cls, account_id, realm, id_):
        account = cls.get_account_by_account_id(account_id)
        result = None
        if account:
            notification = Linqp(account.notifications).where(
                lambda x: x.get('notification_id') == id_).select_all()
            if notification:
                result = notification[0]
        return result
    
    @classmethod
    def add_notification_for_account(cls, account, notification):
        account.notifications.append(notification.json())
    
    @classmethod
    def delete_notification_by_id(cls, account_id, realm, id_):
        account = cls.get_account_by_account_id(account_id)
        notification = cls.get_notification_by_id(account_id, realm, id_)
        result = None
        if account:
            account.notifications.pop(account.notifications.index(notification))
        return result
    
    @classmethod
    def delete_user_notifications(cls, account_id, realm):
        account = cls.get_account_by_account_id(account_id)
        result = None
        if account:
            account.notifications = []
        return result
    
    @classmethod
    def change_password_for_username(cls, username, new_password, realm):
        """
        Change password for selected username.

        :param str realm: realm.
        :param str new_password: new password.
        :param str username: username.
        """
        account = cls.get_account_by_username(username, realm)  # type: UserAccount
        if account:
            account.password = new_password
    
    @classmethod
    def add_account(cls, username, password, nickname=None,
                    background_task=None,
                    account_status=AccountStatuses.ACTIVATED, tid=None,
                    shared_currency_free_xp=0, shared_currency_gold=0,
                    wot_credits=0, wot_crystal=0, wows_gold=0, premium=0,
                    realm='dev1', notifications=None, premium_plus=0, wows_credits=0,
                    auth_session_ticket=None, steam_game_id=None, teleport_status=None,
                    steam_restrictions=None, default_accounts=None, persona_default=None) -> UserAccount:
        """
        Add account to storage.

        :param int premium_plus: premium_plus value.
        :param list notifications: list of notifications.
        :param str realm: realm.
        :param int premium: days of premium
        :param int wows_gold: gold balance.
        :param int wot_crystal: crystal balance.
        :param int wot_credits: credits balance.
        :param int shared_currency_gold: shared_currency_gold balance.
        :param int shared_currency_free_xp: free_xp balance.
        :param str username: username.
        :param str password: password.
        :param str nickname: nickname.
        :param str background_task: background task.
        :param int account_status: account status.
        :param str tid: tid.
        :rtype: dict
        :return: created account info.
        """
        counter = 0
        account_id = None
        default_accounts = default_accounts or {}
        persona_default = persona_default or False
        nickname = nickname or cls.nickname
        if username:
            if any((account.username.lower() == username.lower() and account.realm == realm for account in cls.accounts_list)):
                return {}
        else:
            if any((account.nickname.lower() == nickname.lower() and account.realm == realm for account in cls.accounts_list)):
                return {}
        while not account_id or (counter < 100 and any(
                (account.id == account_id for account in
                 cls.accounts_list))):
            account_id = random.randint(10000, 99999)
            counter += 1
        
        account = UserAccount(account_id, username, password, nickname,
                              background_task, account_status, tid,
                              shared_currency_free_xp, shared_currency_gold,
                              wot_credits, wot_crystal, wows_gold, premium, wows_credits, realm,
                              notifications, premium_plus=premium_plus,
                              auth_session_ticket=auth_session_ticket,
                              steam_game_id=steam_game_id, teleport_status=teleport_status,
                              steam_restrictions=steam_restrictions, default_accounts=default_accounts,
                              persona_default=persona_default)
        log.debug('Add Account: %s' % account)
        account.default_accounts = {
            "wot": {"account_id": account.id, "game_realm": account.realm},
            "wows": {"account_id": account.id, "game_realm": account.realm}
        }
        cls.accounts_list.append(account)
        cls.migrate_accounts()
        account = cls.get_account_by_account_id(account_id)
        return account
    
    @classmethod
    def activate_account_by_username(cls, username, realm):
        """
        Activate account by username.

        :param str realm: realm.
        :param str username: username.
        """
        account = cls.get_account_by_username(username, realm)  # type: UserAccount
        if not account:
            raise WGNException(
                'Account by username: %s not found in database.' % username)
        account.status = AccountStatuses.ACTIVATED
        return account
    
    @classmethod
    def delete_account_by_username(cls, username, realm):
        """
        Delete account by username.

        :param str realm: realm.
        :param str username: username.
        :rtype: bool
        :return: flag that indicates was operation successful or not.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: x.username.lower() == username.lower() and Linqp(x.accounts).where(
                lambda a: a.realm == realm).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: x.username.lower() == username.lower() and x.realm == realm).select_all()
            if account:
                persona[0].accounts.pop(persona[0].accounts.index(account[0]))
                for index, val in enumerate(cls.accounts_list):
                    if val.id == account[0].id:
                        cls.accounts_list.pop(index)
                return True
        return False
    
    @classmethod
    def migrate_accounts(cls):
        for account in cls.accounts_list:
            for realm_instance in cls.wgn_realm_map.keys():
                if account.realm in cls.wgn_realm_map.get(realm_instance):
                    persona_account = cls.get_personal_account_by_username(account.username, realm_instance)
                    if persona_account:
                        if persona_account.search_account_by_username(
                                account.username, account.realm, account.steam_auth_session_ticket) is None:
                            account.persona_id = persona_account.persona_id
                            account.default_accounts = persona_account.accounts[0].default_accounts
                            account.persona_default = False
                            persona_account.accounts.append(deepcopy(account))
                    else:
                        persona_id = random.randint(1000000, 9999999)
                        persona_account = PersonaAccount(persona_id, account.username, realm_instance)
                        account.persona_id = persona_account.persona_id
                        account.persona_default = True
                        persona_account.accounts.append(deepcopy(account))
                        cls.persona_list.append(persona_account)
    
    @classmethod
    def get_personal_account_by_username(cls, username, realm):
        """
        Get personal account by username.

        :param str realm: realm.
        :param str username: username.
        :rtype: PersonaAccount
        :return: account info.
        """
        if username is None:
            return
        account = Linqp(cls.persona_list).where(
            lambda x: x.username.lower() == username.lower() and x.realm == realm).select_all()
        if account:
            return account[0]
    
    @classmethod
    def get_account_by_username(cls, username, realm):
        """
        Get account by username.

        :param str realm: realm.
        :param str username: username.
        :rtype: UserAccount
        :return: account info.
        """
        if realm in cls.wgn_realm_map.keys():
            persona = Linqp(cls.persona_list).where(
                lambda x: x.username.lower() == username.lower() and x.realm == realm).select_all()
        else:
            persona = Linqp(cls.persona_list).where(
                lambda x: x.username.lower() == username.lower() and Linqp(x.accounts).where(
                    lambda a: a.realm == realm).select_all()).select_all()
        if persona:
            if realm in cls.wgn_realm_map.keys():
                account = Linqp(persona[0].accounts).where(
                    lambda x: x.username.lower() == username.lower()).select_all()
            else:
                account = Linqp(persona[0].accounts).where(
                    lambda x: x.username.lower() == username.lower() and x.realm == realm).select_all()
            if account:
                return account[0]
    
    @classmethod
    def get_account_by_steam_auth(cls, auth_session_ticket=None, region=None):
        """
        Get account by username.

        :param str auth_session_ticket: auth_session_ticket.
        :param region : realm.
        :rtype: UserAccount
        :return: account info.
        """
        if cls.steam_account_for_oauth is not None:
            return cls.steam_account_for_oauth
        if region in cls.wgn_realm_values:
            persona = Linqp(cls.persona_list).where(
                lambda x: Linqp(x.accounts).where(
                    lambda a: a.realm == region and ((auth_session_ticket is not None and a.steam_auth_session_ticket == auth_session_ticket) or a.steam_bound or a.username == '')).select_all()).select_all()  # noqa
        else:
            persona = Linqp(cls.persona_list).where(
                lambda x: Linqp(x.accounts).where(
                    lambda a: ((auth_session_ticket is not None and a.steam_auth_session_ticket == auth_session_ticket) or a.steam_bound or a.username == '')).select_all()).select_all()  # noqa
        if persona:
            if region in cls.wgn_realm_values:
                account = Linqp(persona[0].accounts).where(lambda x: ((auth_session_ticket is not None and x.steam_auth_session_ticket == auth_session_ticket) or x.steam_bound) and x.realm == region).select_all()  # noqa
            else:
                account = Linqp(persona[0].accounts).where(lambda x: ((auth_session_ticket is not None and x.steam_auth_session_ticket == auth_session_ticket) or x.steam_bound)).select_all()  # noqa
            if account:
                return account[0]

    @classmethod
    def get_account_by_cn360_auth(cls):
        """
        Get account by username.
        :rtype: UserAccount
        :return: account info.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.realm == 'cn360').select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(lambda x: x.realm == 'cn360').select_all()
            if account:
                return account[0]
    
    @classmethod
    def get_account_by_account_id(cls, account_id):
        """
        Get account by account_id.

        :param str|int account_id: account_id.
        :rtype: UserAccount
        :return: account info.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.id == int(account_id)).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: x.id == int(account_id)).select_all()
            if account:
                return account[0]
    
    @classmethod
    def get_account_by_steam_order_id(cls, steam_order_id):
        """
        Get account by steam_order_id.

        :param int steam_order_id: steam_order_id.
        :rtype: UserAccount
        :return: account info.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.steam_order_id == steam_order_id).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: x.steam_order_id == steam_order_id).select_all()
            if account:
                return account[0]
    
    @classmethod
    def is_account_logged_in(cls, account_id, realm):
        account = cls.get_account_by_account_id(account_id)
        if account:
            if account.oauth_token and account.oauth_token_exp_time > time():
                return True
            if account.token1:
                return True
        return False
    
    @classmethod
    def get_account_by_nickname(cls, nickname, realm):
        """
        Get account by nickname.

        :param str realm: realm.
        :param str nickname: nickname.
        :rtype: UserAccount
        :return: account info.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.nickname.lower() == nickname.lower() and a.realm == realm).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: x.nickname.lower() == nickname.lower() and x.realm == realm).select_all()
            if account:
                return account[0]
    
    @classmethod
    def set_background_task_for_username(cls, username, realm, background_task=None):
        """
        Set background task for username.

        :param str realm: realm.
        :param str username: username.
        :param str background_task: background task.
        :rtype: str
        :return: background task.
        """
        background_task = background_task or cls.create_ticket()
        if username:
            account = cls.get_account_by_username(username, realm)  # type: UserAccount
        else:
            account = WGNIUsersDB.get_account_by_steam_auth()
        account.background_task = background_task
        return background_task
    
    @classmethod
    def set_predict_background_task_for_username(cls, username, realm, background_task=None):
        """
        Set background task for username.

        :param str realm: realm.
        :param str username: username.
        :param str background_task: background task.
        :rtype: str
        :return: background task.
        """
        background_task = background_task or cls.create_ticket()
        if username:
            account = cls.get_account_by_username(username, realm)  # type: UserAccount
        else:
            account = WGNIUsersDB.get_account_by_steam_auth()
        account.background_task_predict.append(background_task)
        return background_task
    
    @classmethod
    def set_teleport_background_task_for_username(cls, username, realm, background_task=None):
        """
        Set background task for username.

        :param str realm: realm.
        :param str username: username.
        :param str background_task: background task.
        :rtype: str
        :return: background task.
        """
        background_task = background_task or cls.create_ticket()
        if username:
            account = cls.get_account_by_username(username, realm)  # type: UserAccount
        else:
            account = WGNIUsersDB.get_account_by_steam_auth()
        account.background_task_teleport = background_task
        return background_task
    
    @classmethod
    def get_account_by_parameter(cls, parameter_name, parameter_value, operation=None):
        """
        Get account by parameter_name and parameter_value.

        :param str|int parameter_value: parameter value.
        :param str parameter_name: parameter name.
        :param operation: python operator function.
        :rtype: UserAccount
        :return: account info.
        """
        
        operation = operation or operator.eq
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: operation(getattr(a, parameter_name), parameter_value)).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: operation(getattr(x, parameter_name), parameter_value)).select_all()
            if account:
                return account[0]
    
    @classmethod
    def get_account_by_background_task(cls, background_task):
        """
        Get account by background_task.

        :param str background_task: background task.
        :rtype: UserAccount
        :return: account info.
        """
        return cls.get_account_by_parameter('background_task', background_task)
    
    @classmethod
    def get_account_by_predict_background_task(cls, background_task):
        """
        Get account by background_task.

        :param str background_task: background task.
        :rtype: UserAccount
        :return: account info.
        """
        return cls.get_account_by_parameter(
            'background_task_predict', background_task, operator.contains)
            
    @classmethod
    def get_account_by_teleport_background_task(cls, background_task):
        """
        Get account by background_task.

        :param str background_task: background task.
        :rtype: UserAccount
        :return: account info.
        """
        return cls.get_account_by_parameter('background_task_teleport', background_task)
    
    @classmethod
    def get_ticket_by_background_task(cls, background_task):
        """
        Get ticket by background_task.

        :param str background_task: background task.
        :rtype: WGNTicket
        :return: ticket.
        """
        return cls._tickets.get(background_task)
    
    @classmethod
    def generate_token1(cls):
        """
        Generate token1 for username.

        :rtype: int
        :return: token1.
        """
        return int(''.join([random.choice(string.digits) for _ in range(8)]))
    
    @classmethod
    def set_token1_for_username(cls, username, realm, token1=None):
        """
        Set token1 value for username.

        :param str realm: realm.
        :param int token1: token1 value.
        :param str username: username.
        :rtype: UserAccount
        :return: account info.
        """
        if username:
            account = cls.get_account_by_username(username, realm)  # type: UserAccount
        else:
            account = WGNIUsersDB.get_account_by_steam_auth()
        if account:
            token1 = token1 or cls.generate_token1()
            account.token1 = token1
        return account
    
    @classmethod
    def generate_session_id(cls):
        """
        Generate sessionid.

        :rtype: str
        :return: wgni sessionid.
        """
        result = ''.join([random.choice(
            string.ascii_letters + string.digits) for _ in range(32)])
        return result
    
    @classmethod
    def generate_ticket(cls):
        """
        Generate ticket.

        :rtype: str
        :return: ticket.
        """
        result = ''.join([random.choice(
            string.ascii_letters + string.digits) for _ in range(16)])
        return result
    
    @classmethod
    def generate_oauth_token(cls):
        """
        Generate oauth token for username.

        :rtype: str
        :return: oauth token.
        """
        return cls.generate_session_id()
    
    @classmethod
    def set_additional_token_token_for_username(
            cls, username, realm, additional_token, client_id, expires_in=3600, exchange_code=None):
        """
        Set additional_token for username.

        :param str realm: realm.
        :param str username: username.
        :param str additional_token: additional_token.
        :param str client_id: client id.
        :param int expires_in: expires in.
        :param str exchange_code: exchange code.
        :rtype: UserAccount
        :return: account info.
        """
        account = cls.get_account_by_username(username, realm)  # type: UserAccount
        if account:
            account.additional_token = additional_token
            account.client_id = client_id
            account.additional_token_exp_time = ceil(time() + expires_in)
            account.exchange_code = exchange_code
        return account
    
    @classmethod
    def get_account_by_token1(cls, token1):
        """
        Get account by token1.

        :param str token1: token1.
        :rtype: UserAccount
        :return: user account.
        """
        return cls.get_account_by_parameter('token1', int(token1))
    
    @classmethod
    def get_persona_by_persona_id(cls, persona_id):
        """
        Get persona by persona_id.

        :param str persona_id: persona_id.
        :rtype: PersonaAccount
        :return: persona info.
        """
        persona = Linqp(cls.persona_list).where(lambda x: x.persona_id == persona_id).select_all()
        if persona:
            return persona[0]
    
    @classmethod
    def get_account_by_any_token(cls, token):
        return cls.get_account_by_oauth_token(token) or cls.get_account_by_additional_token_token(token)
    
    @classmethod
    def get_account_by_oauth_token(cls, token):
        """
        Get account by oauth token.

        :param str token: token.
        :rtype: UserAccount
        :return: account info.
        """
        return cls.get_account_by_parameter('oauth_token', token)
    
    @classmethod
    def get_account_by_additional_token_token(cls, additional_token):
        """
        Get account by additional_token.

        :param str additional_token: additional_token.
        :rtype: UserAccount
        :return: account info.
        """
        return cls.get_account_by_parameter('additional_token', additional_token)
    
    @classmethod
    def revoke_oauth_token_by_username(cls, username, realm):
        """
        Revoke oauth token by username.

        :param str realm: realm.
        :param str username: username.
        """
        account = cls.get_account_by_username(username, realm)
        if account:
            account.oauth_token = None
    
    @classmethod
    def get_account_by_long_lived_token(cls, token, exchange_code):
        """
        Get account by oauth token.

        :param str token: token.
        :param str exchange_code: exchange code.
        :rtype: UserAccount
        :return: user account.
        """
        persona = Linqp(cls.persona_list).where(
            lambda x: Linqp(x.accounts).where(
                lambda a: a.oauth_token == token).select_all()).select_all()
        if persona:
            account = Linqp(persona[0].accounts).where(
                lambda x: x.oauth_token == token).where(
                lambda x: x.exchange_code == exchange_code).select_all()
            if account:
                return account[0]
    
    @classmethod
    def set_challenge_result_for_wgni_session(
            cls, wgni_session_id, challenge_result=None):
        """
        Sets oauth token and challenge result for wgni session.

        :param str wgni_session_id: wgni session.
        :param str challenge_result: challenge result.
        """
        cls._wgni_sessions[wgni_session_id] = challenge_result
    
    @classmethod
    def set_challenge_result_for_wgnr_session(
            cls, wgnr_session_id, challenge_result=None):
        """
        Sets oauth token and challenge result for wgnr session.

        :param str wgnr_session_id: wgnr session.
        :param str challenge_result: challenge result.
        """
        cls._wgnr_sessions[wgnr_session_id] = challenge_result
    
    @classmethod
    def set_challenge_result_for_wgnp_session(
            cls, wgnp_session_id, challenge_result=None):
        """
        Sets oauth token and challenge result for wgnp session.

        :param str wgnp_session_id: wgnp session.
        :param str challenge_result: challenge result.
        """
        cls._wgnp_sessions[wgnp_session_id] = challenge_result
    
    @classmethod
    def create_ticket(cls, token=None, ticket=None, errors=None, email=None):
        """
        Set completion_url for created token.

        :param str email: email for activate.
        :param str token: background task id.
        :param str ticket: ticket.
        :param dict errors: errors e.g. {'name': ['already_taken']}
        :rtype: str
        :return: token
        """
        token = token or ''.join([random.choice(
            string.ascii_letters + string.digits) for _ in range(32)])
        ticket_id = ticket or int(''.join([random.choice(string.digits)
                                           for _ in range(11)]))
        cls._tickets[token] = WGNTicket(ticket_id, errors, email)
        return token
    
    @classmethod
    def get_challenge_result_from_wgni_session(cls, wgni_session_id):
        """
        Gets oauth token and chellenge result from wgni session.

        :param str wgni_session_id: wgni session.
        :rtype: dict
        :return: oauth token and challenge result.
        """
        return cls._wgni_sessions.get(wgni_session_id, None)
    
    @classmethod
    def get_challenge_result_from_wgnp_session(cls, wgnp_session_id):
        """
        Gets oauth token and challenge result from wgnp session.

        :param str wgnp_session_id: wgnp session.
        :rtype: dict
        :return: oauth token and challenge result.
        """
        return cls._wgnp_sessions.get(wgnp_session_id, None)
    
    @classmethod
    def get_product_uris_by_account_id_and_storefront(
            cls, account_id, storefront, title=None):
        """
        Gets product uris list by account id.

        :param int account_id: account id.
        :param str storefront: storefront.
        :rtype: list[str]
        :return: product uris list.
        """
        account = cls.get_account_by_account_id(account_id)
        result = []
        if account:
            if storefront and storefront in ['wgc_buy_game']:
                if title is None:
                    return []
                filtered = WGNIUsersDB._titles.get(title, [])
                for link in account.storefront[storefront]:
                    if link in filtered:
                        result.append(link)
            else:
                if storefront == 'WGC_STOREFRONT':
                    storefront = 'wgc_game_shop'
                result = account.storefront[storefront] or []
        return result
    
    @classmethod
    def get_products_for_non_auth_users(cls, storefront=None):
        """
        Gets product uris list by account id.
        :rtype: list[WGProduct]
        :return: product uris list.
        """
        if storefront == 'default_storefront_id':
            return Linqp(cls._products).where(
                lambda x: not x.buy_game and x.buy_item).select_all()
        elif storefront in ['wgc_showcase', 'wgc_games_install']:
            return Linqp(cls._products).where(lambda x: x.available_for_non_auth and not x.buy_game and not x.buy_item).select_all()
        elif storefront == 'wgc_game_shop':
            return Linqp(cls._products).where(
                lambda x: x.available_for_non_auth and not x.buy_game and x.buy_item).select_all()
        elif storefront == 'wgc_buy_game':
            return Linqp(cls._products).where(
                lambda x: x.available_for_non_auth and x.buy_game and not x.buy_item).select_all()
        else:
            return []
    
    @classmethod
    def get_products_by_account_id_and_storefront(
            cls, account_id, storefront, language, title=None):
        """
        Gets product uris list by account id.

        :param int account_id: account id.
        :param str storefront: storefront.
        :rtype: list[WGProduct]
        :return: product uris list.
        """
        account = cls.get_account_by_account_id(account_id)
        result = []
        if account:
            if storefront and storefront in ['wgc_buy_game']:
                if title is None:
                    return []
                filtered = WGNIUsersDB._titles.get(title, [])
                for link in account.storefront[storefront]:
                    if link in filtered:
                        result.append(link)
            else:
                if storefront == 'WGC_STOREFRONT':
                    storefront = 'wgc_game_shop'
                result = account.storefront[storefront] or []
        final_result = []
        for link in result:
            product = cls.get_product_by_link_id(link)
            if cls.strong_check_language:
                if product.language == language:
                    final_result.append(product)
            else:
                final_result.append(product)
        return final_result
    
    @classmethod
    def clear_storefront(cls, account_id):
        """
        Clear storefront for account id.

        :param int account_id: account id.
        """
        account = cls.get_account_by_account_id(account_id)
        if account:
            account.storefront.clear_storefront()
    
    @classmethod
    def add_product(
            cls,
            friendly_name: str,
            language: str,
            application_id: str = None,
            update_url: str = None,
            product_code: str = None,
            title_code: str = None,
            title: str = None,
            name=None,
            buy_game=False,
            available_for_non_auth=False,
            hard_link_id_hash=True,
            buy_item=False,
            secret=None,
            minimal_info=False,
            link_id=None,
            client_payment_method_ids=None,
            strong_product_code=False,
            tags=None,
            price_type='FIXED',
            limited_quantity=None,
            applied_promotions=None,
            with_discount_amount=True,
            price=1734.5,
            discount_pct=33,
            storefront_category="premium",
            offer_labels=None,
            discount_type='percent',
            filter_properties=None,
            variable_price=None,
            spa_game_code=None,
            quantity=1,
            purchase_restriction_reason=None,
            description=None,
            size_in_grid=None,
            set_id=None,
            set_name=None,
            rank=None
    ) -> WGProduct:
        """
        Add product to list of products.
        """
        product = WGProduct(
            friendly_name,
            language,
            application_id,
            update_url,
            product_code,
            title_code=title_code,
            buy_game=buy_game,
            available_for_non_auth=available_for_non_auth,
            name=name,
            hard_link_id_hash=hard_link_id_hash,
            buy_item=buy_item,
            secret=secret,
            minimal_info=minimal_info,
            link_id=link_id,
            client_payment_method_ids=client_payment_method_ids,
            strong_product_code=strong_product_code,
            tags=tags,
            price_type=price_type,
            limited_quantity=limited_quantity,
            applied_promotions=applied_promotions,
            with_discount_amount=with_discount_amount,
            storefront_category=storefront_category,
            title=title,
            price=price,
            discount_pct=discount_pct,
            offer_labels=offer_labels,
            discount_type=discount_type,
            filter_properties=filter_properties,
            spa_game_code=spa_game_code,
            variable_price=variable_price,
            quantity=quantity,
            purchase_restriction_reason=purchase_restriction_reason,
            description=description,
            size_in_grid=size_in_grid,
            set_id=set_id,
            set_name=set_name,
            rank=rank
        )
        cls._products.append(product)
        return product
    
    @classmethod
    def clear_products(cls):
        """
        Clears products list.
        """
        cls._products.clear()
    
    @classmethod
    def get_product_by_link_id(cls, link_id: str) -> 'WGProduct':
        """
        Gets product by given link id.
        """
        product = Linqp(cls._products).where(
            lambda x: x.link_id == link_id).select_all()
        if product:
            return product[0]
    
    @classmethod
    def get_product_by_id(cls, product_id: str) -> 'WGProduct':
        """
        Gets product by given link id.
        """
        product = Linqp(cls._products).where(
            lambda x: x.product_id == product_id).select_all()
        if product:
            return product[0]
    
    @classmethod
    def get_product_by_query(cls, query) -> 'WGProduct':
        """
        Gets product by given query.
        """
        product = Linqp(cls._products).where(query).select_all()
        if product:
            return product[0]
    
    @classmethod
    def get_products_by_query(cls, query) -> '[WGProduct]':
        """
        Gets product by given query.
        """
        return Linqp(cls._products).where(query).select_all()
    
    @classmethod
    def add_entitlements(cls,
                         account_id: int,
                         storefront_id: str,
                         product_link_id: str,
                         title: str = None,
                         storefront_name=None):
        """
        Add product link id to storefront by account id.

        storefront_name can be either "view" or "install".
        """
        storefront_map = {'view': 'wgc_showcase',
                          'install': 'wgc_games_install',
                          'shop': 'wgc_game_shop',
                          'buy': 'wgc_buy_game'}
        if storefront_name is None:
            storefront_name = storefront_map.get(storefront_id)
        account = cls.get_account_by_account_id(account_id)
        if account:
            storefront = account.storefront[storefront_name]
            if storefront is None:
                raise WGCPSException(
                    'Incorrect storefront name specified: %s can be one of %s' %
                    (storefront_name, storefront_map.keys()))
            storefront.append(product_link_id)
            if storefront_name == 'wgc_buy_game' and title:
                if title not in WGNIUsersDB._titles.keys():
                    WGNIUsersDB._titles[title] = [product_link_id]
                else:
                    WGNIUsersDB._titles[title].append(product_link_id)
