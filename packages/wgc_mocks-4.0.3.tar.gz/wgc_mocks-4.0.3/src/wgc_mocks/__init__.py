﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from wgc_mocks.game_mocks import GameMocks, \
    get_meta_version_from_protocol_version, Default, \
    latest_metadata_protocol_version

__all__ = ['GameMocks',
           'get_meta_version_from_protocol_version',
           'Default',
           'latest_metadata_protocol_version']
