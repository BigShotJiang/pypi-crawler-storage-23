const isObject = (obj) => {
    return Object.prototype.toString.call(obj) === '[object Object]';
};

const eventIds = [
    '01787ea1-c852-1301-abbe-b86c99406428',
    '01787ea1-c852-1301-abbe-b86c99406429',
    '01787ea1-c852-1301-abbe-b86c99406430',
    '01787ea1-c852-1301-abbe-b86c99406431',
    '01787ea1-c852-1301-abbe-b86c99406432'
];

// Listening response from WGC
window.addEventListener("message", (event) => {
    const wgcEvent = isObject(event.data) ? event.data : null;

    if (
        wgcEvent && wgcEvent.src === 'wgc' &&
        eventIds.includes(wgcEvent.id)
    ) {
        console.log('[Iframe] Response from WGC', wgcEvent)
    }
}, false);

function requestCloseDialogWithIframe() {
    window.top.postMessage(
        {
            id: eventIds[4],
            event: 'closeDialogWithIframe'
        },
        '*'
    );
};


function getSpaID() {
	var btn = document.getElementById('spaidbtn');
	btn.textContent = top.window.wgc.auth.currentUser.spaId;
};