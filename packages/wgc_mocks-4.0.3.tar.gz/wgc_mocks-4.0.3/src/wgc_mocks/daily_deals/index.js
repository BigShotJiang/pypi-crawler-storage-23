const isObject = (obj) => {
    return Object.prototype.toString.call(obj) === '[object Object]';
};

const eventIds = [
    '01787ea1-c852-1301-abbe-b86c99406428',
    '0179374e-ad6c-de38-fde2-0c2261cf8dd0',
    '01787ea1-c852-1301-abbe-b86c99406429',
    '01787ea1-c852-1301-abbe-b86c99406430',
    '01787ea1-b834-1301-aeb3-126c98433431',
    '01787ea1-b834-1301-aeb3-126c98433432',
    '01787ea1-b834-1301-aeb3-126c98433433',
];

// Listening response from WGC
window.addEventListener("message", (event) => {
    const wgcEvent = isObject(event.data) ? event.data : null;

    if (
        wgcEvent && wgcEvent.src === 'wgc' &&
        eventIds.includes(wgcEvent.id)
    ) {
        console.log(`[Iframe] Event ${wgcEvent.event} with args ${JSON.stringify(wgcEvent.args)}`, )
    }
}, false);


function requestLogin() {
    window.top.postMessage(
        {
            id: eventIds[0],
            event: 'login',
            args: {
                realmId: 'dev1',
            }
        },
        '*'
    );
}

function requestPurchase() {
    window.top.postMessage(
        {
            id: eventIds[1],
            event: 'purchase',
            args: {
                itemId: 'BUY_WOT_ITEM',
                storefrontId: '%s'
            }
        },
        '*'
    );
}

function requestGetAuthRealmId() {
    window.top.postMessage(
        {
            id: eventIds[2],
            event: 'getAuthRealmId',
        },
        '*'
    );
}

function requestYTAuth() {
    window.top.postMessage(
        {
            id: eventIds[4],
            event: 'startYouTubeAuth',
            args: {
                urlParams: "openid https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile"
            }
        },
        '*'
    );
}

function cancelYTAuth() {
    window.top.postMessage(
        {
            id: eventIds[6],
            event: 'cancelYouTubeAuth',
        },
        '*'
    );
}

function requestCloseOverlay() {
    window.top.postMessage(
        {
            id: eventIds[3],
            event: 'closeOverlay',
        },
        '*'
    );
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}
