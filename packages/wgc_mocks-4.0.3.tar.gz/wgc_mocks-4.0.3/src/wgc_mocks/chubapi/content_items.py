﻿# -*- coding: utf-8 -*-

__author__ = 'l_sidorov@wargaming.net'

from datetime import datetime


class ContentItems(object):

    @classmethod
    def news_mock(
            cls,
            tile='',
            author=None,
            category_id=7,
            category_title='Updates',
            highlight=False,
            pin_until=None,
            starting_at=None,
            finishing_at=None,
            title='MAIN ONE CUSTOM MOCK',
            subtitle=None,
            preview_image_name='wot_logo.png',
            preview_icon=None,
            content_source_host=None,
            description='',
            metadata=None,
            hide_title=False,
            support_login=False,
            title_position=None,
            context=None,
            exclude_feed=False
    ):
        from wgc_mocks import GameMocks
        return {
            "tile": str(tile),
            "source": "ITEMS",
            "content": [
                {
                    "id": "1",
                    "author": author,
                    "category": {
                        "id": category_id,
                        "title": category_title
                    },
                    "type": 'news',
                    "highlight": highlight,
                    "published_at": datetime.utcnow().isoformat(timespec='microseconds'),
                    "pin_until": pin_until,
                    "starting_at": starting_at,
                    "finishing_at": finishing_at,
                    "title": title,
                    "subtitle": subtitle,
                    "preview": GameMocks.download_template % preview_image_name,
                    "preview_icon": GameMocks.download_template % preview_icon,
                    "source": content_source_host or f"{GameMocks.content_service_host}/custom_mock/",
                    "description": description,
                    "metadata": metadata,
                    "additional_properties": {
                        "arsenal": {
                            "hide_title": hide_title,
                            "support_login": support_login,
                            "title_position": title_position
                        }
                    },
                    "code": title + '_code',
                    "context": context,
                    "exclude_feed": exclude_feed
                }
            ]
        }