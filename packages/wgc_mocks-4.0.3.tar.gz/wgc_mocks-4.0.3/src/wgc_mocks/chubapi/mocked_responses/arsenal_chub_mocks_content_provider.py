﻿# -*- coding: utf-8 -*-

__author__ = 'l_sidorov@wargaming.net'

import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _read_from_json(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as fp:
            content = fp.read()
            return json.loads(content)
    except FileNotFoundError:
        return {"error": f"File not found: {os.path.basename(file_path)}"}
    except json.JSONDecodeError:
        return {"error": f"Invalid JSON in: {os.path.basename(file_path)}"}
    except Exception as e:
        return {"error": f"Unexpected error reading {os.path.basename(file_path)}: {str(e)}"}


def _get_localized_file_path(directory, filename_prefix, locale):
    """
    Helper to resolve the file path with locale fallback.
    Tries {filename_prefix}_{locale}.json
    Falls back to {filename_prefix}_en.json if the specific locale doesn't exist.
    """
    base_path = os.path.dirname(os.path.abspath(__file__))

    # Try requested locale
    target_file = f"{filename_prefix}_{locale}.json"
    target_path = os.path.join(base_path, directory, target_file)

    if os.path.exists(target_path):
        return target_path

    # Fallback to 'en'
    fallback_file = f"{filename_prefix}_en.json"
    return os.path.join(base_path, directory, fallback_file)


def wgc_page_code(value: str) -> bool:
    return (
        'WGC' in value
        and 'wargaming' in value
        and 'installedGame' in value
    )


def encode_header(header: dict) -> str:
    return base64.b64encode(
        json.dumps(header).encode("utf-8")
    ).decode("utf-8")


def match_provider(value: str, rules):
    for predicate, provider in rules:
        if predicate(value):
            return provider
    return None


# --- Provider Classes ---

class ArsenalInstalledGame:
    installed_game_mocks = "installed_game_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.installed_game_mocks,
            "installed_game_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.installed_game_mocks,
            "installed_game_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        file_path = _get_localized_file_path(
            cls.installed_game_mocks,
            "installed_game_get_content",
            locale
        )
        content = _read_from_json(file_path)

        # Remove the "Game guide" menu item if QSG is disabled
        from wgc_mocks import GameMocks
        if not GameMocks.arsenal_qsg_enabled:
            if isinstance(content, dict) and "menu_items" in content:
                content["menu_items"] = [
                    item for item in content["menu_items"]
                    if item.get("title") != "Game guide"
                ]
        # Use dynamic locale from GameMocks.default_content_language
        if isinstance(content, dict):
            content["current_locale"] = GameMocks.default_content_language.lower()
        return content


class ArsenalMainPage:
    main_page_mocks = "main_page_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.main_page_mocks,
            "arsenal_main_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.main_page_mocks,
            "arsenal_main_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        file_path = _get_localized_file_path(
            cls.main_page_mocks,
            "arsenal_main_get_content",
            locale
        )
        return _read_from_json(file_path)


class ArsenalNotInstalledPage:
    not_installed_page_mocks = "not_installed_game_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.not_installed_page_mocks,
            "not_installed_game_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.not_installed_page_mocks,
            "not_installed_game_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        file_path = _get_localized_file_path(
            cls.not_installed_page_mocks,
            "not_installed_game_get_content",
            locale
        )
        return _read_from_json(file_path)


class ArsenalPreInstalledPage:
    preinstalled_page_mocks = "preinstalled_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.preinstalled_page_mocks,
            "preinstalled_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.preinstalled_page_mocks,
            "preinstalled_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        from wgc_mocks import GameMocks

        file_path = _get_localized_file_path(
            cls.preinstalled_page_mocks,
            "preinstalled_get_content",
            locale
        )
        content = _read_from_json(file_path)

        if not GameMocks.show_age_ratings:
            for tile in content.get("tiles", []):
                if "additional_content" in tile and "age_ratings_group" in tile["additional_content"]:
                    del tile["additional_content"]["age_ratings_group"]

        return content


class ArsenalPageQSG:
    qsg_get_page_mocks = "quick_start_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.qsg_get_page_mocks,
            "quick_start_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.qsg_get_page_mocks,
            "quick_start_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        file_path = _get_localized_file_path(
            cls.qsg_get_page_mocks,
            "quick_start_get_content",
            locale
        )
        return _read_from_json(file_path)


class ArsenalGetDetailedContentQSG:
    get_detailed_content_qsg = "qsg_get_detailed_content_json"

    @classmethod
    def get_content(cls):
        from wgc_mocks import GameMocks
        if not GameMocks.arsenal_qsg_enabled:
            return {}

        mocked_response = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.get_detailed_content_qsg,
            "qsg_get_detailed_content.json"
        )
        return _read_from_json(mocked_response)


class WGCInstalledGamePageChub:
    wgc_installed_game_mocks = "wgc_installed_game_json"

    @classmethod
    def get_header(cls):
        decoded_header = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.wgc_installed_game_mocks,
            "wgc_installed_game_header_decoded.json"
        )
        return _read_from_json(decoded_header)

    @classmethod
    def get_page(cls):
        get_page_mock = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            cls.wgc_installed_game_mocks,
            "wgc_installed_game_get_page.json"
        )
        return _read_from_json(get_page_mock)

    @classmethod
    def get_content(cls, locale="en"):
        file_path = _get_localized_file_path(
            cls.wgc_installed_game_mocks,
            "wgc_installed_game_get_content",
            locale
        )
        return _read_from_json(file_path)
