# -*- coding: utf-8 -*-

import base64
import copy
import json
import os
import re
import urllib.request
import datetime
from urllib.parse import urlparse, urlencode

# ==========================================
# CONFIGURATION
# ==========================================

URLS = [
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=eu.wgc.arsenalMain",
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=WOT.EU.PRODUCTION.notInstalledGame",
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=eu.wot.InstalledGame",
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=sg.wgcshop.installedgame",
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=eu.wot.preInstalled",
    "https://chubapi-kis121.wgtest.net/api/v1/getPage?page=WGC.wargaming.WOT.RU.PRODUCTION.eu.wot.installedgame"
]

GET_CONTENT_API_VERSION = "v2"
# Target locales for raw dumps.
# Note: The 'widgets' folder will strictly contain ONLY 'en' based on logic below.
TARGET_LOCALES = ["en", "bg", "ru", "fr"]
ALL_WIDGETS_DIR = "widgets"

# Widgets that require the metadata patch
PATCH_TARGET_WIDGETS = ["custom_slider_info", "game_info"]

# The new metadata to inject
NEW_METADATA = {
    "logo": "https://gcdn-wguscs.wgcdn.co/wguscs-kis74-wot/filer_public/69/de/69ded2fa-5857-47c3-b292-17c72bcd4e1a/biglogo.svg",
    "realmInfo": {
        "RU": {
            "button": {
                "uri": "WGC:LS1pbnN0YWxsIC1nIFdPVC5SVS5QUk9EVUNUSU9OQGh0dHBzOi8vMTI3LjAuMC4xOjc3NzE=",
                "name": "Game Page"
            },
            "age_ratings": [
                {
                    "link": "https://pegi.info/what-do-the-labels-mean",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-eu-wot/filer_public/2e/5d/2e5dacd7-159b-42ba-9046-39f8128896ed/age_rating_pegi_all_oct22_414x200.png",
                        "width": 414,
                        "height": 200
                    },
                    "countryCode": ["FR"]
                },
                {
                    "link": "http://www.esrb.org/ratings/ratings_guide.aspx",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-us-wot/filer_public/28/05/28059fa3-08e3-40f9-92a1-8111938dbb50/teen_icon_esrb.png",
                        "width": 146,
                        "height": 88
                    },
                    "countryCode": ["UA"]
                },
                {
                    "link": "http://www.culturadigital.br/",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-us-wot/filer_public/f3/71/f3713a4c-5ac3-45b8-a577-cce15046caeb/64px-djctq_-_10svg.png",
                        "width": 64,
                        "height": 64
                    },
                    "countryCode": ["LU"]
                }
            ]
        }
    }
}

# ==========================================
# GLOBAL STATE
# ==========================================
installed_game_counter = {}
preinstalled_counter = {}
seen_guids = set()  # Changed to set for faster lookup
global_patch_count = 0


def log(msg, indent=0, level="INFO"):
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    spacer = "  " * indent
    print(f"[{timestamp}] [{level:<4}] {spacer}{msg}")


def save_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def extract_tile_ids(tiles_field):
    tile_ids = []
    if not tiles_field:
        return tile_ids

    for item in tiles_field:
        if isinstance(item, list):
            tile_ids.extend(str(t) for t in item if t)
        elif item:
            tile_ids.append(str(item))
    return tile_ids


def collect_recursive_tile_ids(widget):
    collected_ids = set()

    if "tiles" in widget and widget["tiles"]:
        collected_ids.update(extract_tile_ids(widget["tiles"]))

    if "localization_tile" in widget and widget["localization_tile"]:
        collected_ids.add(str(widget["localization_tile"]))

    if "groups" in widget and isinstance(widget["groups"], list):
        for group in widget["groups"]:
            if "widgets" in group and isinstance(group["widgets"], list):
                for sub_widget in group["widgets"]:
                    collected_ids.update(collect_recursive_tile_ids(sub_widget))

    return list(collected_ids)


def sanitize_filename(filename):
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    filename = filename.replace('.', '_')
    return filename.strip('_')


def extract_page_name(url):
    if 'page=' in url:
        match = re.search(r'page=([^&]+)', url)
        if match:
            return match.group(1)
    return "unknown_page"


def get_server_from_url(url):
    parsed = urlparse(url)
    hostname = parsed.hostname
    if hostname:
        match = re.search(r'kis(\d+)', hostname)
        if match:
            return match.group(1)
    return "121"


def build_content_url(page_url, view_code, locale):
    server_num = get_server_from_url(page_url)
    base_url = f"https://chubapi-kis{server_num}.wgtest.net/api/{GET_CONTENT_API_VERSION}/getContent"
    params = {
        "view_code": view_code,
        "locale": locale,
        "country_code": "UA"
    }
    return f"{base_url}?{urlencode(params)}"


def get_page_type_and_dirs(page_name):
    page_name_lower = page_name.lower()

    if 'notinstalledgame' in page_name_lower:
        page_type = 'not_installed_game'
        base_dir = 'not_installed_game_json'
        prefix = 'not_installed_game'
    elif 'installedgame' in page_name_lower:
        page_type = 'installed_game'
        if page_type in installed_game_counter:
            installed_game_counter[page_type] += 1
        else:
            installed_game_counter[page_type] = 1

        if installed_game_counter[page_type] > 1:
            base_dir = f'installed_game_json_{installed_game_counter[page_type]}'
            prefix = f'installed_game_{installed_game_counter[page_type]}'
        else:
            base_dir = 'installed_game_json'
            prefix = 'installed_game'
    elif 'arsenalmain' in page_name_lower:
        page_type = 'arsenal_main'
        base_dir = 'main_page_json'
        prefix = 'arsenal_main'
    elif 'preinstalled' in page_name_lower:
        page_type = 'preinstalled'
        if page_type in preinstalled_counter:
            preinstalled_counter[page_type] += 1
        else:
            preinstalled_counter[page_type] = 1

        if preinstalled_counter[page_type] > 1:
            base_dir = f'preinstalled_json_{preinstalled_counter[page_type]}'
            prefix = f'preinstalled_{preinstalled_counter[page_type]}'
        else:
            base_dir = 'preinstalled_json'
            prefix = 'preinstalled'
    elif 'quick_start' in page_name_lower:
        page_type = 'quick_start'
        base_dir = 'quick_start_json'
        prefix = 'quick_start'
    else:
        safe_page_name = sanitize_filename(page_name)
        page_type = safe_page_name
        base_dir = safe_page_name
        prefix = safe_page_name

    OUTPUT_DIR = base_dir

    PAGE_BODY_FILE = f"{prefix}_get_page.json"
    HEADER_FILE = f"{prefix}_header_decoded.json"

    return {
        'page_name': page_name,
        'page_type': page_type,
        'output_dir': OUTPUT_DIR,
        'page_body_path': os.path.join(OUTPUT_DIR, PAGE_BODY_FILE),
        'content_prefix': os.path.join(OUTPUT_DIR, f"{prefix}_get_content"),
        'header_path': os.path.join(OUTPUT_DIR, HEADER_FILE),
        'prefix': prefix
    }


def fetch_page_and_header(url, paths):
    log(f"Fetching page data from: {url}", indent=1)

    try:
        with urllib.request.urlopen(url) as response:
            headers = dict(response.getheaders())
            page_data = json.loads(response.read().decode("utf-8"))
        log("Page data fetched successfully.", indent=2)
    except Exception as e:
        log(f"Failed to fetch page data: {e}", indent=2, level="ERROR")
        raise e

    decoded_header = {}
    header_key = "x-content-update"

    if header_key in headers:
        try:
            decoded = base64.b64decode(headers[header_key], altchars="-_", validate=True)
            decoded_header = json.loads(decoded.decode("utf-8"))
            log("Header 'x-content-update' decoded successfully.", indent=2)
        except Exception:
            decoded_header = {"error": "Header decode failed"}
            log("Header 'x-content-update' failed to decode.", indent=2, level="WARN")
    else:
        log("Header 'x-content-update' not found.", indent=2)

    save_json(page_data, paths['page_body_path'])
    save_json(decoded_header, paths['header_path'])
    log(f"Saved raw page body to: {paths['page_body_path']}", indent=2)

    return page_data, decoded_header


def fetch_content_for_locale(page_url, page_data, paths, locale):
    view_code = page_data.get("view_code")
    if not view_code:
        page_name = paths['page_name']
        if '.' in page_name:
            domain, category, page = page_name.split('.')
            view_code = f"{domain}.{category}.{page}.{domain}"
        else:
            view_code = f"{sanitize_filename(page_name)}_view"

    content_url = build_content_url(page_url, view_code, locale)
    log(f"Fetching content for locale '{locale}'...", indent=2)

    try:
        with urllib.request.urlopen(content_url) as response:
            content_data = json.loads(response.read().decode("utf-8"))

        save_path = f"{paths['content_prefix']}_{locale}.json"
        save_json(content_data, save_path)
        log(f"Success. Saved to: {save_path}", indent=3)
        return content_data

    except Exception as e:
        log(f"Failed to fetch content for locale '{locale}': {e}", indent=3, level="ERROR")
        return None


def apply_content_patch(content_data, widget_identifier):
    """
    Applies the logic to update metadata and code if the widget identifier matches target widgets.
    """
    if not any(target in widget_identifier for target in PATCH_TARGET_WIDGETS):
        return content_data, 0

    updates_made = 0
    if "tiles" in content_data and isinstance(content_data["tiles"], list):
        for tile in content_data["tiles"]:
            if isinstance(tile, dict) and "content" in tile and isinstance(tile["content"], list):
                for item in tile["content"]:
                    item["metadata"] = NEW_METADATA
                    item["code"] = "WOT.RU.PRODUCTION"
                    updates_made += 1

    return content_data, updates_made


def split_by_guid(page_data, content_data_map, header_data, paths, all_widgets_dir, page_name, page_url):
    global global_patch_count
    widgets = page_data.get("widgets", [])
    header_tiles = header_data.get("tiles", {})

    log(f"Splitting {len(widgets)} widgets...", indent=1)

    widget_files = []
    skipped_count = 0
    server_num = get_server_from_url(page_url)

    for i, widget in enumerate(widgets, 1):
        # Ignore menu_items
        widget = copy.deepcopy(widget)
        widget.pop("menu_items", None)

        guid = widget.get("guid") or widget.get("code", "unknown_widget")

        # --- DUPLICATE CHECK START ---
        if guid in seen_guids:
            # If we have seen this GUID before (globally), skip it completely
            # This ensures only ONE copy exists in the widgets folder
            log(f"Widget {i}: '{guid}' already processed. Skipping duplicate.", indent=2, level="SKIP")
            skipped_count += 1
            continue

        # Mark as seen
        seen_guids.add(guid)
        # --- DUPLICATE CHECK END ---

        # Get tiles for this widget
        widget_tiles = collect_recursive_tile_ids(widget)

        # 1. Save Page Data
        page_copy_for_combined = copy.deepcopy(page_data)
        page_copy_for_combined["widgets"] = [widget]
        save_json(
            page_copy_for_combined,
            os.path.join(all_widgets_dir, f"{guid}_get_page.json")
        )

        # 2. Save Header Data
        header_copy = copy.deepcopy(header_data)
        header_copy["tiles"] = {
            k: v for k, v in header_tiles.items()
            if k in widget_tiles
        }
        save_json(
            header_copy,
            os.path.join(all_widgets_dir, f"{guid}_header.json")
        )

        # 3. Process Content (ONLY EN FOR WIDGETS DIR)
        saved_locales = []
        for locale, content_data in content_data_map.items():

            # --- FILTER: Only save 'en' to the widgets folder ---
            if locale != "en":
                continue

            if not content_data:
                continue

            content_tiles = content_data.get("tiles", [])
            content_copy = copy.deepcopy(content_data)

            content_copy["tiles"] = [
                t for t in content_tiles
                if str(t.get("tile") if isinstance(t, dict) else t) in widget_tiles
            ]

            # --- PATCHING LOGIC HERE ---
            content_copy, updates = apply_content_patch(content_copy, guid)

            if updates > 0:
                global_patch_count += 1
                log(f"Widget {i}: [PATCH APPLIED] Updated {updates} items in '{guid}'", indent=3, level="SUCC")

            save_json(
                content_copy,
                os.path.join(all_widgets_dir, f"{guid}_get_content_{locale}.json")
            )
            saved_locales.append(locale)

        widget_files.append({
            "original_guid": guid,
            "unique_guid": guid,  # No longer renamed
            "page_name": page_name,
            "page_type": paths["page_type"],
            "server": f"kis{server_num}",
            "locales": saved_locales
        })

    return widget_files, skipped_count


def process_single_url(url, all_widgets_dir):
    page_name = extract_page_name(url)
    server_num = get_server_from_url(url)

    log(f"START Processing URL: {page_name}", level="MAIN")
    log(f"Server: kis{server_num} | URL: {url}", indent=1)

    paths = get_page_type_and_dirs(page_name)
    if not os.path.exists(paths['output_dir']):
        os.makedirs(paths['output_dir'])
        log(f"Created directory: {paths['output_dir']}", indent=1)

    try:
        # 1. Fetch Page
        page_data, header_data = fetch_page_and_header(url, paths)

        # 2. Identify Locales
        available_locales = page_data.get("available_locales", ["en"])
        locales = [l for l in available_locales if l in TARGET_LOCALES]

        log(f"Locales detected on page: {available_locales}", indent=1)
        log(f"Locales to fetch (Raw Dumps): {locales}", indent=1)

        # 3. Fetch Content for Target Locales (All requested locales fetched for raw dumps)
        content_data_map = {}
        for locale in locales:
            c_data = fetch_content_for_locale(url, page_data, paths, locale)
            if c_data:
                content_data_map[locale] = c_data

        # 4. Split and Patch (Only 'en' saved to widgets dir, duplicates skipped)
        widget_files, skipped_count = split_by_guid(page_data, content_data_map, header_data, paths, all_widgets_dir,
                                                    page_name, url)

        log(f"Completed processing {page_name}.", indent=1, level="DONE")
        log(f"New Widgets Saved: {len(widget_files)} | Duplicates Skipped: {skipped_count}", indent=2)
        print("-" * 80)

        return {
            'url': url,
            'page_name': page_name,
            'page_type': paths['page_type'],
            'server': f"kis{server_num}",
            'output_dir': paths['output_dir'],
            'widget_files': widget_files,
            'widget_count': len(widget_files),
            'skipped_count': skipped_count,
            'view_code': page_data.get("view_code", "unknown")
        }
    except Exception as e:
        log(f"Critical failure processing URL: {e}", indent=1, level="FAIL")
        print("-" * 80)
        raise e


def process_multiple_urls(urls):
    print("=" * 80)
    log(f"BATCH EXTRACTION STARTING | {len(urls)} URLs configured", level="INIT")
    log(f"Raw Output Dumps:  ./[page_type]_json/", indent=1)
    log(f"Widget Output Dir: ./{ALL_WIDGETS_DIR}/ (Unique Widgets Only)", indent=1)
    print("=" * 80)

    global installed_game_counter, preinstalled_counter, seen_guids, global_patch_count
    installed_game_counter = {}
    preinstalled_counter = {}
    seen_guids = set()
    global_patch_count = 0

    os.makedirs(ALL_WIDGETS_DIR, exist_ok=True)

    all_widget_files = []
    results = []
    total_skipped = 0

    for i, url in enumerate(urls, 1):
        try:
            result = process_single_url(url, ALL_WIDGETS_DIR)
            all_widget_files.extend(result['widget_files'])
            total_skipped += result['skipped_count']
            results.append(result)
        except Exception as e:
            results.append({
                'url': url,
                'error': str(e),
                'success': False,
                'page_name': extract_page_name(url),  # Try to extract even on fail
                'page_type': "ERROR"
            })

    # ==========================
    # FINAL REPORT
    # ==========================
    print("\n" + "=" * 80)
    log("BATCH PROCESSING COMPLETED", level="END")
    print("=" * 80)

    success_count = len([r for r in results if 'error' not in r])

    # Summary Table
    print(f"\n{'-' * 80}")
    print(f"{'STATUS':<8} | {'PAGE NAME':<35} | {'NEW':<8} | {'SKIPPED'}")
    print(f"{'-' * 80}")

    for result in results:
        if 'error' in result:
            print(f"{'FAIL':<8} | {result['page_name']:<35} | {'0':<8} | -")
            log(f"Failure reason for {result['page_name']}: {result['error']}", indent=1, level="ERR")
        else:
            print(f"{'OK':<8} | {result['page_name']:<35} | {result['widget_count']:<8} | {result['skipped_count']}")

    print(f"{'-' * 80}\n")

    print(f"Total URLs Processed:   {success_count}/{len(urls)}")
    print(f"Total Unique Widgets:   {len(seen_guids)}")
    print(f"Total Skipped Duplicates: {total_skipped}")
    print(f"Total Patches Applied:  {global_patch_count}")
    print(f"Widgets Directory:      {os.path.abspath(ALL_WIDGETS_DIR)}")
    print("=" * 80)

    return results


def main():
    if not URLS:
        print("No URLs configured in the script.")
        return

    process_multiple_urls(URLS)


if __name__ == "__main__":
    main()