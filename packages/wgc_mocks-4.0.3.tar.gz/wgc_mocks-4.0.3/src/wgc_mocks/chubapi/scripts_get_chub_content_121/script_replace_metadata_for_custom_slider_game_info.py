import json
import os

# Configuration
WIDGETS_DIR = "widgets"
TARGET_FILES = [
    "custom_slider_info_get_content.json",
    "game_info_get_content.json"
]

NEW_METADATA = {
    "logo": "https://gcdn-wguscs.wgcdn.co/wguscs-kis74-wot/filer_public/69/de/69ded2fa-5857-47c3-b292-17c72bcd4e1a/biglogo.svg",
    "realmInfo": {
        "RU": {
            "button": {
                "uri": "WGC:LS1pbnN0YWxsIC1nIFdPVC5SVS5QUk9EVUNUSU9OQGh0dHBzOi8vMTI3LjAuMC4xOjc3NzE=",
                "name": "Game Page"
            },
            "age_ratings": [
                {
                    "link": "https://pegi.info/what-do-the-labels-mean",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-eu-wot/filer_public/2e/5d/2e5dacd7-159b-42ba-9046-39f8128896ed/age_rating_pegi_all_oct22_414x200.png",
                        "width": 414,
                        "height": 200
                    },
                    "countryCode": ["FR"]
                },
                {
                    "link": "http://www.esrb.org/ratings/ratings_guide.aspx",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-us-wot/filer_public/28/05/28059fa3-08e3-40f9-92a1-8111938dbb50/teen_icon_esrb.png",
                        "width": 146,
                        "height": 88
                    },
                    "countryCode": ["UA"]
                },
                {
                    "link": "http://www.culturadigital.br/",
                    "image": {
                        "url": "https://gcdn-wguscs.wgcdn.co/wguscs-us-wot/filer_public/f3/71/f3713a4c-5ac3-45b8-a577-cce15046caeb/64px-djctq_-_10svg.png",
                        "width": 64,
                        "height": 64
                    },
                    "countryCode": ["LU"]
                }
            ]
        }
    }
}


def update_single_file(filename):
    file_path = os.path.join(WIDGETS_DIR, filename)

    if not os.path.exists(file_path):
        print(f"[SKIP] File not found: {file_path}")
        return

    print(f"Processing {filename}...", end=" ")

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        updated_count = 0

        # Traverse tiles -> content
        if "tiles" in data and isinstance(data["tiles"], list):
            for tile in data["tiles"]:
                if "content" in tile and isinstance(tile["content"], list):
                    for item in tile["content"]:
                        # 1. Replace Metadata
                        item["metadata"] = NEW_METADATA

                        # 2. Update Code
                        item["code"] = "WOT.RU.PRODUCTION"

                        updated_count += 1

        # Save changes
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        print(f"Done. Updated {updated_count} items.")

    except Exception as e:
        print(f"\n[ERROR] Failed to process {filename}: {e}")


def main():
    if not os.path.exists(WIDGETS_DIR):
        print(f"Directory '{WIDGETS_DIR}' does not exist.")
        return

    print(f"Starting update for {len(TARGET_FILES)} files...")
    print("-" * 40)

    for filename in TARGET_FILES:
        update_single_file(filename)

    print("-" * 40)
    print("All tasks completed.")


if __name__ == "__main__":
    main()