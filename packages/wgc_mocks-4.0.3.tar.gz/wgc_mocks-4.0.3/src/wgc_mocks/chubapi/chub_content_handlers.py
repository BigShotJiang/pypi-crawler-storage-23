﻿# -*- coding: utf-8 -*-

__author__ = 'l_sidorov@wargaming.net'

import base64
import json

from aiohttp import web

from wgc_mocks.chubapi.mocked_responses.arsenal_chub_mocks_content_provider import WGCInstalledGamePageChub, \
    ArsenalMainPage, ArsenalInstalledGame, ArsenalPreInstalledPage, ArsenalNotInstalledPage, \
    ArsenalGetDetailedContentQSG, ArsenalPageQSG


def wgc_page_code(value: str) -> bool:
    return (
        'WGC' in value
        and 'wargaming' in value
        and 'installedGame' in value
    )


def encode_header(header: dict) -> str:
    return base64.b64encode(
        json.dumps(header).encode("utf-8")
    ).decode("utf-8")


def match_provider(value: str, rules):
    for predicate, provider in rules:
        if predicate(value):
            return provider
    return None


class ArsenalGetPage(web.View):

    PAGE_RULES = [
        (wgc_page_code, WGCInstalledGamePageChub),
        (lambda v: 'arsenalmain' in v.lower(), ArsenalMainPage),
        (lambda v: 'notinstalledgame' in v.lower(), ArsenalNotInstalledPage),
        (lambda v: 'installedgame' in v.lower(), ArsenalInstalledGame),
        (lambda v: 'preinstalled' in v.lower(), ArsenalPreInstalledPage),
        (lambda v: 'quick_start' in v.lower(), ArsenalPageQSG),
    ]

    def _on_get(self):
        page = self.request.query.get('page')
        if not page:
            raise web.HTTPNotFound()

        provider = match_provider(page, self.PAGE_RULES)
        if not provider:
            raise web.HTTPNotFound()

        page_data = provider.get_page()
        header = provider.get_header()

        if header:
            return web.json_response(
                page_data,
                headers={'X-Content-Update': encode_header(header)}
            )

        return web.json_response(page_data)

    async def get(self):
        return self._on_get()


class ArsenalGetContent(web.View):

    CONTENT_RULES = [
        (wgc_page_code, WGCInstalledGamePageChub),
        (lambda v: 'arsenalmain' in v.lower(), ArsenalMainPage),
        (lambda v: 'notinstalledgame' in v.lower(), ArsenalNotInstalledPage),
        (lambda v: 'installedgame' in v.lower(), ArsenalInstalledGame),
        (lambda v: 'preinstalled' in v.lower(), ArsenalPreInstalledPage),
        (lambda v: 'quick_start' or 'qsg' in v.lower(), ArsenalPageQSG),
    ]

    def _handle(self):
        view_code = self.request.query.get('view_code')
        locale = self.request.query.get('locale', 'en')

        if not view_code:
            raise web.HTTPNotFound()

        provider = match_provider(view_code, self.CONTENT_RULES)
        if not provider:
            raise web.HTTPNotFound()

        # Pass locale to the provider
        content = provider.get_content(locale=locale)
        header = provider.get_header()

        return web.json_response(
            content,
            headers={'X-Content-Update': encode_header(header)}
        )

    def _on_get(self):
        return self._handle()

    def _on_head(self):
        return self._handle()

    async def get(self):
        return self._on_get()

    async def head(self):
        return self._on_head()


class ArsenalGetDetailedContent(web.View):

    def _on_get(self):
        response = ArsenalGetDetailedContentQSG.get_content()

        if "error" in response:
            raise web.HTTPNotFound(text=response["error"])

        return web.json_response(response)

    async def get(self):
        return self._on_get()
