﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_helpers.os_helper import OSHelper
from wgc_mocks.content_files.content_files import get_content_template_path


class ArsenalGetGameResources(web.View):
    
    def _on_get(self):
        from wgc_mocks.game_mocks import GameMocks
        response = {
            'status': 'ok',
            'data': {
                "resources": [
                    {"size": 742577,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('icon.ico')),
                     "url": GameMocks.download_template % 'icon.ico',
                     "name": "icon"
                     },
                    {"size": 8095,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('small_logo.png')),
                     "url": GameMocks.download_template % 'small_logo.png',
                     "name": "small_logo"
                     },
                    {"size": 34378,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_disabled.png')),
                     "url": GameMocks.download_template % 'tray_menu_icon_disabled.png',
                     "name": "tray_menu_icon_disabled"
                     },
                    {"size": 35217,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_hover.png')),
                     "url": GameMocks.download_template % 'tray_menu_icon_hover.png',
                     "name": "tray_menu_icon_hover"
                     },
                    {"size": 34727,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('tray_menu_icon_normal.png')),
                     "url": GameMocks.download_template % 'tray_menu_icon_normal.png',
                     "name": "tray_menu_icon_normal"
                     },
                    {"size": 117624,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('notification_icon.png')),
                     "url": GameMocks.download_template % 'notification_icon.png',
                     "name": "notification_icon"
                     },
                    {"size": 181043,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('background.jpg')),
                     "url": GameMocks.download_template % 'background.jpg',
                     "name": "background"
                     },
                    {"size": 36868,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('background_blurred.jpg')),
                     "url": GameMocks.download_template % 'background_blurred.jpg',
                     "name": "background_blurred"
                     },
                    {"size": 1152,
                     "hash": OSHelper.get_file_sha1(get_content_template_path('game.css')),
                     "url": GameMocks.download_template % 'game.css',
                     "name": "game_css"}]}}
        return web.json_response(response, status=200, content_type='application/json', headers={
            'etag': '77431f5fcf1c5eeb372c91896c06c15a'})
    
    async def get(self):
        return self._on_get()
