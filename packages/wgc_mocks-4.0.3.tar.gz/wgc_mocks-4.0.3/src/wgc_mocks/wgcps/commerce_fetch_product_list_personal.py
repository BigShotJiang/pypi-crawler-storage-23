﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import uuid
from time import time

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni.storage import WGNIUsersDB


class CommerceFetchProductListPersonal(web.View):
    """
    https://wgcps.asia.wots.iv/doc/#operation/fetchProductList2
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion
        
        await asyncio.sleep(1)
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await asyncio.wait_for(self.request.json(), timeout=15)
        else:
            params = dict(await self.request.post())
        
        account_id = params.get('account_id')
        country = params.get('body').get('country', 'UA')  # noqa
        title = params.get('title')  # noqa
        language = params.get('body').get('language')
        storefront = params.get('body').get('storefront')
        storefront_category = params.get('body').get('storefront_category')
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {params}')
        if not storefront:
            raise MissingParamException(f'Missing required param: "storefront": {self.request.path} -> {params}')
        if not language:
            raise MissingParamException(f'Missing required param: "language": {self.request.path} -> {params}')
        
        # endregion
        region = self.request.match_info.get('realm')
        
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
        if not authorization or not account or account_id == 0:
            return web.json_response(
                {
                    "status": "error",
                    "errors": [
                        {
                            "code": "unauthorized"
                        }
                    ]}, status=401)
        
        items = []
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        products = WGNIUsersDB.get_products_for_non_auth_users(storefront)
        
        for product in products:
            product_json = {
                'product_id': product.product_id,
                'product_code': product.product_code,
                'product_url': f'https://{WGCConfig.wgcps_host}/realm_'
                               f'{region}/product/{product.link_id}',
                'coupon_codes': ['coupon!']
            }
            if product.limited_quantity:
                product_json['limited_quantity'] = product.limited_quantity
                if product_json['limited_quantity']['personal_count'] >= product_json['limited_quantity'][
                    'personal_limit'] or product_json['limited_quantity']['common_count'] \
                        >= product_json['limited_quantity']['common_limit']:
                    product_json['limited_quantity']['purchase_allowed'] = False
            items.append(product_json)
        
        products = \
            WGNIUsersDB.get_products_by_account_id_and_storefront(
                account_id, storefront, language, title) or []
        
        meta = {'time': time()}
        log_id = str(uuid.uuid4())
        tracking_id = str(uuid.uuid4())
        account.current_log_Id = tracking_id

        for product in products:
            product_json = {
                'product_id': product.product_id,
                'product_code': product.product_code,
                'product_url': f'https://{WGCConfig.wgcps_host}/realm_'
                               f'{region}/product/{product.link_id}',
                'coupon_codes': ['coupon!']
            }
            if product.limited_quantity:
                product_json['limited_quantity'] = product.limited_quantity
                if product_json['limited_quantity']['personal_count'] >= product_json['limited_quantity'][
                    'personal_limit'] or product_json['limited_quantity']['common_count'] \
                        >= product_json['limited_quantity']['common_limit']:
                    product_json['limited_quantity']['purchase_allowed'] = False
            if storefront_category:
                if product.storefront_category == storefront_category:
                    items.append(product_json)
            else:
                items.append(product_json)
        data = {
            'status': 'ok',
            'meta': meta,
            'data': {
                "header": {"message-id": log_id,
                           "tracking-id": account.current_log_Id},
                "body": {'items': items,
                         'etag': '15a704e7d41934b797e914ca87d642c092c17e71bc570f5aed1d282ae1ce3250'}
            }
        }
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
