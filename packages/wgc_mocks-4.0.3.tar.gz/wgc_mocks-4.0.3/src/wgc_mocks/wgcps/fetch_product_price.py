﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_core.exceptions import MissingParamException


class FetchProductPrice(web.View):
    """
    https://wgcps-wgs11.wgtest.net/commerce/api/v3/fetchProductPrice
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await asyncio.wait_for(self.request.json(), timeout=15)
        else:
            params = dict(await self.request.post())
        
        country = params.get('body').get('country')
        platform = params.get('body').get('platform')
        title = params.get('title')  # noqa
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {params}')
        if not country:
            raise MissingParamException(f'Missing required param: "country": {self.request.path} -> {params}')
        if not platform:
            raise MissingParamException(f'Missing required param: "platform": {self.request.path} -> {params}')
        
        data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": "56cc6455-7456-4fd1-9f6e-d72c75fa0313",
                    "tracking-id": "01HTFEAHZ0WHCWM5CF11MJQHHQ"
                },
                "body": {
                    "price": {
                        "real_price": {
                            "currency_code": "PLN",
                            "amount": "9.93",
                            "original_amount": "9.93",
                            "discount": {"amount": "0.00", "pct": "0"}
                        },
                        "virtual_prices": []
                    },
                    "rewards": [],
                    "discounts": [],
                    "coupon_codes": [],
                    "client_payment_method_ids": [
                        82,
                        83,
                        84,
                        85,
                        86
                    ],
                    "payment_limit": {
                        "currency_code": "PLN",
                        "total_limit_amount": "20.00",
                        "available_amount": "20.00"
                    }
                }
            }
        }
        
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
