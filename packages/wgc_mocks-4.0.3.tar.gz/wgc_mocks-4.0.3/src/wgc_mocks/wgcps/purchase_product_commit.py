﻿# -*- coding: utf-8 -*-

__author__ = "n_kovganko@wargaming.net"

import uuid

from aiohttp import web

from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni.storage import WGNIUsersDB


class PurchaseProductCommit(web.View):

    async def _on_post(self):
        authorization = self.request.headers.get("AUTHORIZATION")  # noqa
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(":") + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401
            )
        data = await self.request.json()
        title = data.get("title")

        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {data}')
        
        account_id = data.get("account_id")
        body = data.get("body")
        if not title:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "title",
                            "text": "title is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "account_id is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not body:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "body",
                            "text": "body is required parameter"
                        }
                    }
                ]
            }, status=400)
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        transaction_id = body.get("transaction_id")
        order_id = body.get("order_id")
        binding_id = body.get("binding_id")  # noqa
        browser_info = body.get("browser_info")  # noqa
        product_code = body.get("browser_info").get('code')  # noqa

        accept_header = body.get("browser_info").get('accept_header')  # noqa
        user_agent = body.get("browser_info").get('user_agent')  # noqa
        color_depth = body.get("browser_info").get('color_depth')  # noqa
        java_enabled = body.get("browser_info").get('java_enabled')  # noqa
        language = body.get("browser_info").get('language')  # noqa
        screen_height = body.get("browser_info").get('screen_height')  # noqa
        screen_width = body.get("browser_info").get('screen_width')  # noqa
        time_zone_offset = body.get("browser_info").get('time_zone_offset')  # noqa

        purchaser_ip = body.get("purchaser").get('ip_address')  # noqa
        purchaser_wgid = body.get("purchaser").get('wgid')  # noqa
        
        if WGNIUsersDB.prepare_account_status == 'enabled':
            tsv_method = body.get("tsv").get('method')  # noqa
            tsv_type = body.get("tsv").get('type')  # noqa
            tsv_code = body.get("tsv").get('code')  # noqa

        message_id = str(uuid.uuid4())
        resp_data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": message_id,
                    "tracking-id": account.current_log_Id
                },
                "body": {
                    'transaction_id': transaction_id,
                    'order_id': order_id,
                }
            }
        }
        if WGNIUsersDB.commit_3ds1 or WGNIUsersDB.commit_3ds2:
            resp_data['data']['body']['next_action'] = {'code': "3ds_required"}
            if WGNIUsersDB.redirect_url_present:
                resp_data['data']['body']['next_action']['redirect_url'] = WGNIUsersDB.redirect_url
        from wgc_mocks.game_mocks import GameMocks
        product = WGNIUsersDB.get_product_by_query(lambda x: x.product_code == account.order_product_code)
        if product:
            if product.limited_quantity:
                product.limited_quantity['personal_count'] += 1
                product.limited_quantity['common_count'] += 1
            else:
                product_install = WGNIUsersDB.add_product(
                    product.friendly_name, product.language, product.application_id,
                    GameMocks.game_update_url, title_code=title, product_code="INSTALL_ALICE_GAME",
                    hard_link_id_hash=product.hard_link_id_hash)
                WGNIUsersDB.add_entitlements(account_id, "install", product_install.link_id)
        return web.json_response(resp_data)

    async def post(self):
        return await self._on_post()
