﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetLoginSession(web.View):
    """
    https://confluence.wargaming.net/pages/viewpage.action?pageId=510928482
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion

        access_token, exchange_code = \
            (authorization.split()[-1].split(':') + [None])[:2]
        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
            if account:
                return web.json_response(
                    {'status': 'ok',
                     'meta': {'account_id': account.id}}
                )
        return web.json_response(
            {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)

    async def post(self):
        return await self._on_post()
