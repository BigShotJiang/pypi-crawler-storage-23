﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class GetPlayerData(web.View):
    """
    https://confluence.wargaming.net/pages/viewpage.action?pageId=2179758726
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion
        
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response({'status': 'error',
                                          "data": {}, "errors": [{"code": "unauthorized"}]},
                                         status=401)
        else:
            return web.json_response({'status': 'error',
                                      "data": {}, "errors": [{"code": "unauthorized"}]},
                                     status=401)

        account_id = params.get('account_id')
        title_code = params.get('title_code')
        # endregion
        
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "Missing account_id parameter"
                        }
                    }
                ]
            }, status=400)
        
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        
        if not title_code:
            data = {
                "status": "ok",
                "data": [
                    {
                        "title_code": "sg.wows",
                        "dataset": [
                            {"tag": "data-platform.player-data-item-entitlement.v1",
                             "value": {"code": "premium", "value": account.inventory.premium * 24 * 60 * 60}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "gold", "value": str(account.inventory.wows_gold)}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "credits", "value": "0"}},
                            {"tag": "data-platform.player-data-item-custom.v1",
                             "value": {"code": "wows_premium", "value": str(account.inventory.premium * 24 * 60 * 60)}}
                        ]
                    },
                    {
                        "title_code": "sg.wot",
                        "dataset": [
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "gold", "value": str(account.inventory.shared_currency_gold)}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "crystal", "value": str(account.inventory.wot_crystal)}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "free_xp", "value": str(account.inventory.shared_currency_free_xp)}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "credits", "value": str(account.inventory.wot_credits)}},
                            {"tag": "data-platform.player-data-item-entitlement.v1",
                             "value": {"code": "premium", "value": account.inventory.premium * 24 * 60 * 60}},
                            {"tag": "data-platform.player-data-item-entitlement.v1",
                             "value": {"code": "premium_plus", "value": account.inventory.premium_plus * 24 * 60 * 60}}
                        ]
                    },
                    {
                        "title_code": "sg.wotb",
                        "dataset": [
                            {"tag": "data-platform.player-data-item-entitlement.v1",
                             "value": {"code": "premium", "value": account.inventory.premium * 24 * 60 * 60}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "gold", "value": str(account.inventory.wows_gold)}},
                            {"tag": "data-platform.player-data-item-virtual-currency.v1",
                             "value": {"code": "credits", "value": "0"}},
                            {"tag": "data-platform.player-data-item-custom.v1",
                             "value": {"code": "wows_premium", "value": str(account.inventory.premium * 24 * 60 * 60)}}
                        ]
                    },
                ]
            }
        else:
            data = {
                "status": "ok",
                'wgid': account.id,
                'data': [
                    {'dataset': [
                        {
                            '@tag': 'data-platform.player-data-item-virtual-currency.v1',
                            'value': {'code': 'gold', 'value': str(account.inventory.shared_currency_gold)}},
                        {
                            '@tag': 'data-platform.player-data-item-virtual-currency.v1',
                            'value': {'code': 'crystal', 'value': str(account.inventory.wot_crystal)}},
                        {
                            '@tag': 'data-platform.player-data-item-virtual-currency.v1',
                            'value': {'code': 'free_xp', 'value': str(account.inventory.shared_currency_free_xp)}},
                        {
                            '@tag': 'data-platform.player-data-item-virtual-currency.v1',
                            'value': {'code': 'credits', 'value': str(account.inventory.wot_credits)}},
                        {
                            '@tag': 'data-platform.player-data-item-entitlement.v1',
                            'value': {'code': 'premium', 'value': account.inventory.premium * 24 * 60 * 60}},
                        {
                            '@tag': 'data-platform.player-data-item-entitlement.v1',
                            'value': {'code': 'premium_plus', 'value': account.inventory.premium_plus * 24 * 60 * 60}}
                    ],
                        'title_code': title_code}
                ]
            }
        
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
