﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class IncomingNotification(web.View):
    """
    https://stash.wargaming.net/projects/WDSS/repos/wgcps/browse/docs/api-reference/README.md?at=refs%2Fheads%2Ftask%2FWGCPS-181#h3-post-notifications-fetch
    """

    async def _on_get(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        params = self.request.query
        account_id = params.get('account_id')  # noqa
        # endregion
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        exist_notification = 0
        if account:
            if account.notifications:
                exist_notification = 1
        return web.Response(text=str(exist_notification), status=200)

    async def get(self):
        return await self._on_get()
