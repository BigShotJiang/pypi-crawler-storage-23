# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from os import path
import json

from aiohttp import web


class CommerceFetchStorefrontCategoriesV2(web.View):
    """
    https://wgcps.asia.wots.iv/commerce/api/v2/fetchStorefrontCategories
    """
    
    async def _on_post(self):
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        language = params.get('body').get('language')
        storefront = params.get('body').get('storefront')
        
        if not language or not storefront:
            return web.json_response({'error': 'Missing some required parameters.'}, status=400)

        with open(path.join(path.dirname(__file__), 'vehicles._filter.json'), 'r') as fp:
            categories = json.load(fp)
        data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": "aa2a28c8-0d63-4362-8e2a-9ce0b3f8b0d3",
                    "tracking-id": "01GZJZD9SWP9QGPMHFG9RF53FB"
                },
                "body": {
                    "categories": categories
                }
            }
        }
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
