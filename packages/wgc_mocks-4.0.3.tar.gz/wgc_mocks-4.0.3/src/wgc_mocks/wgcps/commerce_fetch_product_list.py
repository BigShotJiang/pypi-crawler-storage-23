﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import uuid

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni.storage import WGNIUsersDB


class CommerceFetchProductList(web.View):
    """
    https://wgcps.asia.wots.iv/doc/#operation/fetchProductList2
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion
        
        await asyncio.sleep(1)
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())

        country = params.get('body').get('country', 'UA')
        title = params.get('title')  # noqa
        language = params.get('body').get('language')
        storefront = params.get('body').get('storefront')
        # endregion
        region = self.request.match_info.get('realm')

        products = WGNIUsersDB.get_products_for_non_auth_users(storefront)
        items = []
        for product in products:
            product_json = {
                'product_id': product.product_id,
                'product_code': product.product_code,
                'product_url': f'https://{WGCConfig.wgcps_host}/realm_'
                               f'{region}/product/{product.link_id}',
                'coupon_codes': ['coupon!']
            }
            if product.limited_quantity:
                product_json['limited_quantity'] = product.limited_quantity
                if product_json['limited_quantity']['personal_count'] >= product_json['limited_quantity'][
                    'personal_limit'] or product_json['limited_quantity']['common_count'] >= product_json[
                        'limited_quantity']['common_limit']:
                    product_json['limited_quantity']['purchase_allowed'] = False
            items.append(product_json)
            
        return web.json_response(
            {'status': 'error',
             'meta': {"language": language, "country": country},
             "data": {
                 'body': {"items": items},
                 "header": {"message-id": str(uuid.uuid4()), "tracking-id": str(uuid.uuid4())},
             }}, status=200)

    async def post(self):
        return await self._on_post()
