﻿# -*- coding: utf-8 -*-

import warnings

import aiohttp
from aiohttp import web, ClientSession

from wgc_core.logger import get_logger

warnings.filterwarnings("ignore", category=DeprecationWarning)
application = web.Application()
routes = web.RouteTableDef()

apiKey = '937f0f98-c571-4448-b9dc-7b6bff2a5cf7'  # this API key is used for a
# specific example server, storefront and title
HEADERS = {'SERVER-API-KEY': apiKey}
HOST = "https://agate-proxy.wgprod.net"
# HOST = "http://10.149.21.171:8080"

log = get_logger()

session_timeout = aiohttp.ClientTimeout(total=None, sock_connect=15, sock_read=15)


class SteamIntegrationFetchProductListPersonal(web.View):
    """
    External payment endpoint.
    """

    async def post(self):
        if self.request.content_type == 'application/json' and self.request.body_exists:
            data = await self.request.json()
        else:
            data = dict(await self.request.post())
        async with ClientSession(timeout=session_timeout) as session:
            try:
                response = await session.post(
                    f'{HOST}/fetchProductListPersonal/', json=data, timeout=15)
                async with response:
                    response_json = await response.json()
                    log.debug(f"product list fetch reply = {response_json}")
                    tracking_id = response.headers.get('tracking-id')
                    message_id = response.headers.get('message-id')
                    headers = {'tracking-id': tracking_id, 'message-id': message_id}
                    return web.json_response(
                        response_json, status=response.status,
                        headers=headers, reason=response.reason)
            except Exception as err:
                log.error(err)
                return web.json_response({'error': 'internal server error', 'context': str(err)}, status=500)


class SteamIntegrationExternalPaymentInit(web.View):
    """
    External payment init endpoint.
    """

    async def post(self):
        if self.request.content_type == 'application/json' and self.request.body_exists:
            data = await self.request.json()
        else:
            data = dict(await self.request.post())
        async with ClientSession(timeout=session_timeout) as session:
            try:
                response_init = await session.post(
                    f'{HOST}/steamExternalPaymentInit/', json=data, timeout=15)
                async with response_init:
                    init_json = await response_init.json()
                    log.debug(f"payment init reply = {init_json}")
                    tracking_id = response_init.headers.get('tracking-id')
                    message_id = response_init.headers.get('message-id')
                    headers = {'tracking-id': tracking_id, 'message-id': message_id}
                    return web.json_response(
                        init_json, status=response_init.status,
                        headers=headers, reason=response_init.reason)
            except Exception as err:
                log.error(err)
                return web.json_response({'error': 'internal server error', 'context': str(err)}, status=500)


class SteamIntegrationExternalPaymentCommit(web.View):
    """
    External payment commit endpoint.
    """

    async def post(self):
        if self.request.content_type == 'application/json' and self.request.body_exists:
            data = await self.request.json()
        else:
            data = dict(await self.request.post())
        async with ClientSession(timeout=session_timeout) as session:
            try:
                response_commit = await session.post(
                    f'{HOST}/steamExternalPaymentCommit/', json=data, timeout=15)
                async with response_commit:
                    commit_json = await response_commit.json()
                    log.debug(f"payment commit reply = {commit_json}")
                    tracking_id = response_commit.headers.get('tracking-id')
                    message_id = response_commit.headers.get('message-id')
                    headers = {'tracking-id': tracking_id, 'message-id': message_id}
                    return web.json_response(
                        commit_json, status=response_commit.status,
                        headers=headers, reason=response_commit.reason)
            except Exception as err:
                log.error(err)
                return web.json_response({'error': 'internal server error', 'context': str(err)}, status=500)
