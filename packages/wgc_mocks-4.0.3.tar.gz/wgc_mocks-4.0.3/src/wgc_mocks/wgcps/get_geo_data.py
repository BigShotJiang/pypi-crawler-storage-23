﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class GetGeoData(web.View):
    """
    https://stash.wargaming.net/projects/WDSS/repos/wgcps/browse/src/wgcps/accounts/v1/api.py#161
    """
    postal_codes = {'04203': {
        "country": "UA", "postal_code": "04203", "place_name": "Kyiv",
        "state_name": "Kyiv", "state_code": "KY", "province_name": "Kyivskaya",
        "province_code": "071", "community_name": "", "community_code": ""}}

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())

        postal_code = params.get('postal_code')
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response({'status': 'error',
                                          "data": {}, "errors": [{"code": "unauthorized"}]},
                                         status=401)
        else:
            return web.json_response({'status': 'error',
                                      "data": {}, "errors": [{"code": "unauthorized"}]},
                                     status=401)

        return web.json_response({"status": "ok", "data": self.postal_codes.get(postal_code, {})})

    async def post(self):
        return await self._on_post()
