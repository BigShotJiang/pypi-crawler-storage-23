﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import uuid

from aiohttp import web

from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni.storage import WGNIUsersDB


class GetAccountTsvMethod(web.View):
    """
    https://wgcps.asia.wots.iv/doc/#operation/getAccountTsvMethod
    """
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')
        title = params.get('title')  # noqa
        
        if not account_id:
            raise MissingParamException(f'Missing required param: "account_id": {self.request.path} -> {params}')
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {params}')
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {'status': 'error',
                     "errors": [{"code": "unauthorized"}]}, status=401
                )
        else:
            return web.json_response(
                {'status': 'error',
                 "errors": [{"code": "required", 'context': {
                         'parameter': 'Authorization', 'text': 'Header Authorization is not found.'}}]}, status=401
            )
        if not account_id:
            return web.json_response(
                    {'status': 'error',
                     "errors": [{"code": "required", 'context': {
                         'parameter': 'account_id', 'text': 'Message\'s field account_id is not found.'}}]}, status=400
            )
        log_id = str(uuid.uuid4())
        account = WGNIUsersDB.get_account_by_account_id(account_id)

        data = {"status": "ok", "data": {
            "header": {
                "message-id": log_id,
                "tracking-id": account.current_log_Id
            },
            "body": {
                "method": WGNIUsersDB.commerce_method,
                "mandatory": WGNIUsersDB.commerce_check_required,
                "status": WGNIUsersDB.commerce_account_status,
                "management_url": f"https://asia.wgnwn.wgns.iv/personal/"
                                  f"security_management/?feature_id=igp&method={WGNIUsersDB.commerce_method}"}}}
        return web.json_response(data)

    async def post(self):
        return await self._on_post()
