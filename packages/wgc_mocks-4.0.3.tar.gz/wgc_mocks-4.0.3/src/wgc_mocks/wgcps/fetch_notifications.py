﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class FetchNotificationList(web.View):
    """
    https://stash.wargaming.net/projects/WDSS/repos/wgcps/browse/docs/api-reference/README.md?at=refs%2Fheads%2Ftask%2FWGCPS-181#h3-post-notifications-fetch
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')
        language = params.get('language')
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response({'status': 'error',
                                          'meta': {"language": "en", "country": language},
                                          "data": {"product_uris": []}, "errors": [{"code": "unauthorized"}]},
                                         status=401)
        else:
            return web.json_response(
                {'status': 'error',
                 'meta': {"language": "en", "country": language},
                 "data": {"product_uris": []}, "errors": [{"code": "unauthorized"}]}, status=401
            )

        account = WGNIUsersDB.get_account_by_account_id(account_id)
        if not account:
            return web.json_response(
                {'status': 'error',
                 'meta': {"language": "en", "country": language},
                 "data": {"product_uris": []}, "errors": [{"code": "account not found"}]}
            )
        return web.json_response({
            "status": "ok",
            "meta": {
                "language": language},
            "data": {
                "notifications": account.notifications
            }
        })

    async def post(self):
        return await self._on_post()
