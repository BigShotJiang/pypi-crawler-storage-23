﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni import WGNIUsersDB


class UpdateNotification(web.View):
    """
    https://stash.wargaming.net/projects/WDSS/repos/wgcps/browse/docs/api-reference/README.md?at=refs%2Fheads%2Ftask%2FWGCPS-181#h3-post-notifications-fetch
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')
        set_read = params.get('set_read')
        set_incoming = params.get('set_incoming')
        # endregion
        region = self.request.match_info.get('realm')

        account = WGNIUsersDB.get_account_by_account_id(account_id)
        if not account:
            return web.json_response({'error': 'account not found'}, status=404)

        for id_ in set_read:
            notification = WGNIUsersDB.get_notification_by_id(account_id, region, id_)
            if not notification:
                return web.json_response({'error': 'notification id not found'}, status=404)
            notification['state'] = 'read'
            WGNIUsersDB.delete_notification_by_id(account_id, region, id_)
        if set_incoming == 0:
            WGNIUsersDB.delete_user_notifications(account_id, region)
        return web.json_response({"status": "ok"}, status=200)

    async def post(self):
        return await self._on_post()
