﻿# -*- coding: utf-8 -*-

__author__ = "n_kovganko@wargaming.net"

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class RedeemBonusCode(web.View):

    async def _on_post(self):
        authorization = self.request.headers.get("AUTHORIZATION")  # noqa
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(":") + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401
            )
        data = await self.request.json()
        code = data.get("code")
        account_id = data.get("account_id")
        language = data.get("language")
        if not code:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "code",
                            "text": "code is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "account_id is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not language:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "language",
                            "text": "language is required parameter"
                        }
                    }
                ]
            }, status=400)
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        account.inventory.premium += 30
        account.inventory.shared_currency_gold += 5000
        
        resp_data = {
            "status": "ok",
            "data": {
                "code_description": 'BONUS CODE TEST description with кириллица'
            }
        }
        return web.json_response(resp_data)

    async def post(self):
        return await self._on_post()
