﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetGamePageCategory(web.View):
    """
    https://confluence.wargaming.net/pages/viewpage.action?pageId=828899825
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        await asyncio.sleep(GameMocks.get_game_page_category_timeout)

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')
        game = params.get('game')
        target = params.get('target')
        # endregion
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        access_token, exchange_code = \
            (authorization.split()[-1].split(':') + [None])[:2]
        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)

        account = WGNIUsersDB.get_account_by_account_id(account_id)
        if not account:
            return web.json_response(
                {'status': 'error',
                 'errors': [{'code': "invalid", 'context': {'text': 'account not found'}}]}, status=400
            )
        if not game:
            return web.json_response(
                {'status': 'error',
                 'errors': [{'code': "invalid", 'context': {'text': 'game not found'}}]}, status=400
            )
        if not target:
            return web.json_response(
                {'status': 'error',
                 'errors': [{'code': "invalid", 'context': {'text': 'target not found'}}]}, status=400
            )
        return web.json_response({'status': "ok", 'data': {'categories': [GameMocks.category_id]}})

    async def post(self):
        return await self._on_post()
