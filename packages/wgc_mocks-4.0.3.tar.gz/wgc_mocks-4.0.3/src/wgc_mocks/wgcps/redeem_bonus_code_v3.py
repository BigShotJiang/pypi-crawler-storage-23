﻿# -*- coding: utf-8 -*-

__author__ = "n_kovganko@wargaming.net"

from aiohttp import web

from wgc_core.config import WGCConfig
from wgc_mocks.wgni.storage import WGNIUsersDB


class RedeemBonusCodeV3(web.View):
    
    async def _on_post(self):
        authorization = self.request.headers.get("AUTHORIZATION")  # noqa
        region = self.request.match_info.get("realm")
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(":") + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401
            )
        data = await self.request.json()
        code = data.get("code")
        country = data.get("country")
        account_id = data.get("account_id")
        language = data.get("language")
        if not code:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "code",
                            "text": "code is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "account_id is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not language:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "language",
                            "text": "language is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not country:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "language",
                            "text": "country is required parameter"
                        }
                    }
                ]
            }, status=400)
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        account.inventory.premium += 30
        account.inventory.shared_currency_gold += 5000
        result = []
        products = [WGNIUsersDB.get_product_by_link_id(link) for link in account.storefront.wgc_buy_game]
        if products:
            for product in products:
                result.append({
                    "product_code": product.product_code,
                    "product_url": f'https://{WGCConfig.wgcps_host}/realm_{region}/product/{product.link_id}',
                    "quantity": product.quantity,
                    "title_code": product.title_code,
                    "title": product.title,
                    "game_access": [
                        {
                            "game_code": product.spa_game_code
                        }
                    ]
                })
        products = [WGNIUsersDB.get_product_by_link_id(link) for link in account.storefront.wgc_game_shop]
        if products:
            for product in products:
                result.append({
                    "product_code": product.product_code,
                    "product_url": f'https://{WGCConfig.wgcps_host}/realm_{region}/product/{product.link_id}',
                    "quantity": product.quantity,
                    "title_code": product.title_code,
                    "title": product.title,
                })
        resp_data = {
            "status": "ok",
            "data": {
                "bonuses_description": 'BONUS CODE TEST description with кириллица'
                                       '\n1\n2\n3\n4\n5\n6\n7\n8\n9\n10\ntest',
                "bonuses_products": result
            }
        }
        return web.json_response(resp_data)
    
    async def post(self):
        return await self._on_post()
