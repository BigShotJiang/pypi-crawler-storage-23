﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
from datetime import datetime, timedelta

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetFullInventory(web.View):
    """
    https://rtd.wargaming.net/docs/mag/en/latest/#getfullinventory
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks import GameMocks
        await asyncio.sleep(GameMocks.get_full_inventory_timeout)
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion

        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')
        # endregion
        region = self.request.match_info.get('realm')
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        if not account:
            return web.json_response({'error': 'account not found.'}, status=400)
        access_token, exchange_code = \
            (authorization.split()[-1].split(':') + [None])[:2]
        if exchange_code:
            account = WGNIUsersDB.get_account_by_long_lived_token(
                access_token, exchange_code)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        timestamp = datetime.now().timestamp() + 24 * 60 * 60 * account.inventory.premium
        if region != 'asia':
            return web.json_response({"status": "ok", "data": {
                "currencies": [{"title_code": "ru.shared_currency", "currency_code": "free_xp",
                                "amount": str(account.inventory.shared_currency_free_xp)},
                               {"title_code": "ru.shared_currency", "currency_code": "gold",
                                "amount": str(account.inventory.shared_currency_gold)},
                               {"title_code": "ru.wot", "currency_code": "credits",
                                "amount": str(account.inventory.wot_credits)},
                               {"title_code": "ru.wot", "currency_code": "crystal",
                                "amount": str(account.inventory.wot_crystal)},
                               {"title_code": "ru.wows", "currency_code": "brass", "amount": "4"},
                               {"title_code": "ru.wows", "currency_code": "coal", "amount": "2"},
                               {"title_code": "ru.wows", "currency_code": "eventum_1", "amount": "111"},
                               {"title_code": "ru.wows", "currency_code": "eventum_2", "amount": "999"},
                               {"title_code": "ru.wows", "currency_code": "gold",
                                "amount": str(account.inventory.wows_gold)},
                               {"title_code": "ru.wows", "currency_code": "molybdenum", "amount": "13333"},
                               {"title_code": "ru.wows", "currency_code": "credits", "amount": str(
                                   account.inventory.wows_credits)},
                               {"title_code": "ru.wows", "currency_code": "saltpeter", "amount": "4444"},
                               {"title_code": "ru.wows", "currency_code": "steel", "amount": "1444"}],
                "entitlements": [
                    {
                        "expiration_date": (datetime.now() + timedelta(days=1)).timestamp(),
                        "entitlement_code": "premium",
                        "amount": str(account.inventory.premium * 24 * 60 * 60)
                    },
                    {
                        "expiration_date": (datetime.now() + timedelta(days=1)).timestamp(),
                        "entitlement_code": "premium_plus",
                        "amount": str(account.inventory.premium_plus * 24 * 60 * 60)
                    }],
                'goods': [
                    {
                        'amount': str(timestamp),
                        'value_code': "wows_premium_expiry_time",
                        'type_code': 'wows'}],
                'at': datetime.now().timestamp()
            }})
        else:
            return web.json_response({"status": "ok", "data": {
                "currencies": [{"title_code": "sg.wot", "currency_code": "free_xp",
                                "amount": str(account.inventory.shared_currency_free_xp)},
                               {"title_code": "sg.wot", "currency_code": "gold",
                                "amount": str(account.inventory.shared_currency_gold)},
                               {"title_code": "sg.wot", "currency_code": "credits",
                                "amount": str(account.inventory.wot_credits)},
                               {"title_code": "sg.wot", "currency_code": "crystal",
                                "amount": str(account.inventory.wot_crystal)},
                               {"title_code": "sg.wows", "currency_code": "brass", "amount": "4"},
                               {"title_code": "sg.wows", "currency_code": "coal", "amount": "2"},
                               {"title_code": "sg.wows", "currency_code": "eventum_1", "amount": "111"},
                               {"title_code": "sg.wows", "currency_code": "eventum_2", "amount": "999"},
                               {"title_code": "sg.wows", "currency_code": "gold",
                                "amount": str(account.inventory.wows_gold)},
                               {"title_code": "sg.wows", "currency_code": "silver", "amount": str(
                                   account.inventory.wot_credits)},
                               {"title_code": "sg.wows", "currency_code": "credits", "amount": str(
                                   account.inventory.wows_credits)},
                               {"title_code": "sg.wows", "currency_code": "molybdenum", "amount": "13333"},
                               {"title_code": "sg.wows", "currency_code": "saltpeter", "amount": "4444"},
                               {"title_code": "sg.wows", "currency_code": "steel", "amount": "1444"}],
                "entitlements": [{"expiration_date": (datetime.now() +
                                                      timedelta(days=1)).timestamp(),
                                  "entitlement_code": "premium",
                                  "amount": str(account.inventory.premium * 24 * 60 * 60)},
                                 {
                                     "expiration_date": (datetime.now() + timedelta(days=1)).timestamp(),
                                     "entitlement_code": "premium_plus",
                                     "amount": str(account.inventory.premium_plus * 24 * 60 * 60)}
                                 ],
                'goods': [
                    {
                        'amount': str(timestamp),
                        'value_code': "wows_premium_expiry_time",
                        'type_code': 'wows'}],
                'at': datetime.now().timestamp()
            }})

    async def post(self):
        return await self._on_post()
