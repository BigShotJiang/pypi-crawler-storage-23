﻿# -*- coding: utf-8 -*-

__author__ = "n_kovganko@wargaming.net"

import asyncio
import uuid

from aiohttp import web

from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni.storage import WGNIUsersDB


class PurchaseZeroProductPrepare(web.View):
    
    async def _on_post(self):
        authorization = self.request.headers.get("AUTHORIZATION")  # noqa
        await asyncio.sleep(WGNIUsersDB.prepare_product_timeout)
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(":") + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401
            )
        data = await self.request.json()
        title = data.get("title")
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {data}')
        
        account_id = data.get("account_id")
        body = data.get("body")
        if not title:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "title",
                            "text": "title is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "account_id is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not body:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "body",
                            "text": "body is required parameter"
                        }
                    }
                ]
            }, status=400)
        
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        storefront = body.get("product").get('storefront')  # noqa
        product_code = body.get("product").get('code')
        transaction_id = body.get("transaction_id")
        message_id = str(uuid.uuid4())
        order_id = str(uuid.uuid4())

        account.order_product_code = product_code
        account.order_id = order_id
        product = WGNIUsersDB.get_product_by_query(lambda x: x.product_code == product_code)
        account.order_product_id = product.product_id
        
        if WGNIUsersDB.billing_mandatory and not account.address:
            return web.json_response({
                "status": "error",
                "data": {
                    "header": {"message-id": "1d93fe1e-9df7-4f02-b1a1-d58e93d832ee",
                               "tracking-id": "d9f755df-cefc-4dc5-9f25-02e65ead2f74"}}, "errors": [
                    {"code": "platform_error", "context": {"result_code": "ADDRESS_REQUIRED_BUT_NOT_EXIST"}}]},
                status=500)
        
        resp_data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": message_id,
                    "tracking-id": account.current_log_Id
                },
                "body": {
                    'transaction_id': transaction_id,
                    'order_id': order_id,
                }
            }
        }
        return web.json_response(resp_data)
    
    async def post(self):
        return await self._on_post()
