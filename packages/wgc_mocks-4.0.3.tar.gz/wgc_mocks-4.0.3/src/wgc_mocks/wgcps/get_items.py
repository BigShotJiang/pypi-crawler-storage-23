﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import datetime

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetItems(web.View):
    """
    https://confluence.wargaming.net/display/PLATFORM/Get+premium+shop+items+-+API
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        from wgc_mocks.game_mocks import GameMocks
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        account_id = params.get('account_id')  # noqa
        game = params.get('game')  # noqa
        country = params.get('country')
        language = params.get('language')
        limit = params.get('limit')  # noqa
        # endregion

        region = self.request.match_info.get('realm')
        if WGNIUsersDB.is_account_logged_in(account_id, region):
            text1 = 'ITEM AUTH1'
            text2 = 'ITEM AUTH2'
        else:
            text1 = 'ITEM NOT AUTH1'
            text2 = 'ITEM NOT AUTH2'

        package_content_html = """<ul>
            <li><span class="b-icon-nation flag flag__ukraine mceNonEditable" data-mce-contenteditable="false">&zwnj;</span>
            &nbsp;Red Stag</li>
            <li><span class="bonus mceNonEditable" data-mce-contenteditable="false">бонус</span> 0.5 Captain Morgan</li>
            <li><span class="bonus mceNonEditable" data-mce-contenteditable="false">бонус</span> Уникальные способности</li>
            <li><span class="package-list_count mceNonEditable" data-mce-contenteditable="false">25&times;</span>КРЕПКИЙ КОФЕ;</li>
            <li><span class="bonus mceNonEditable" data-mce-contenteditable="false">БОНУС</span> задача на x5 опыта (15 раз).</li>
            </ul>"""

        return web.json_response({
            "status": "ok",
            "meta": {
                "language": language[0],
                "country": country,
            },
            "data": [
                {
                    "id": 0,
                    "name": text1,
                    "description": "Some description",
                    "is_exclusive": False,
                    "is_limited": False,
                    "premium_shop_url": "https://ru.wargaming.net/shop/wot/premium/10120/",
                    "package_content_html": package_content_html,
                    "media": {
                        "image_1_1": GameMocks.download_template % 'item1_1.png',
                        "image_2_1": GameMocks.download_template % 'item1_2.png',
                        "image_main": GameMocks.download_template % 'item1_3.png',
                    },
                    "promotion": {
                        "end_datetime": (datetime.datetime.now() +
                                         datetime.timedelta(days=1)).strftime(
                            '%Y-%m-%d %H:%M:%S'),
                        "sale_price": {"UAH": "75"},
                        "promotion_text": "SALE",
                        "show_sale_label": True,
                    },
                    "entitlements": [{
                        "cd": "",
                        "bonus_general": False,
                        "name": "",
                        "quantity": 0,
                        "crew_level": 0,
                        "compensation": 0,
                        "type": "other",
                    }],
                    "price": {
                        "UAH": "100"
                    },
                    "gallery": []
                },
                {
                    "id": 1,
                    "name": text2,
                    "description": "Some description",
                    "is_exclusive": False,
                    "is_limited": False,
                    "premium_shop_url": "https://ru.wargaming.net/shop/wot/premium/10120/",
                    "package_content_html": package_content_html,
                    "media": {
                        "image_1_1": GameMocks.download_template % 'item2_1.png',
                        "image_2_1": GameMocks.download_template % 'item2_2.png',
                        "image_main": GameMocks.download_template % 'item2_3.png',
                    },
                    "entitlements": [{
                        "cd": "",
                        "bonus_general": False,
                        "name": "",
                        "quantity": 0,
                        "crew_level": 0,
                        "compensation": 0,
                        "type": "other",
                    }],
                    "promotion": {
                        "end_datetime": (datetime.datetime.now() +
                                         datetime.timedelta(days=1)).strftime(
                            '%Y-%m-%d %H:%M:%S'),
                        "sale_price": {"UAH": "75"},
                        "promotion_text": "",
                        "show_sale_label": True,
                    },
                    "price": {
                        "UAH": "100"
                    },
                    "gallery": []
                }
            ]
        })

    async def post(self):
        return await self._on_post()
