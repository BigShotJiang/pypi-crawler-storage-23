﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.exceptions import MissingParamException


class CommerceFetchStorefrontCategories(web.View):
    """
    https://wgcps.asia.wots.iv/commerce/api/v1/fetchStorefrontCategories
    """
    
    async def _on_post(self):
        data = await self.request.json()
        title = data.get('title')
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {data}')
        
        data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": "6a1c7399-f83b-4364-b9e1-77a731b89b73",
                    "tracking-id": "01GXATS3S2P96K4EXEV8Y0PVXY"
                },
                "body": {
                    "categories": [
                        {
                            "code": "gold",
                            "sort_number": 2,
                            "activation_status": "active",
                            "metadata": {
                                "category_icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Purchase via Online Payment",
                                        "value": "Purchase via Online Payment"
                                    }
                                }
                            }
                        },
                        {
                            "code": "main",
                            "sort_number": 16,
                            "activation_status": "active",
                            "metadata": {
                                "background": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Featured",
                                        "value": "Featured"
                                    }
                                }
                            }
                        },
                        {
                            "code": "by_sms",
                            "parent_code": "gold",
                            "sort_number": 5,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "PURCHASE VIA MOBILE PAYMENT",
                                        "value": "PURCHASE VIA MOBILE PAYMENT"
                                    }
                                }
                            }
                        },
                        {
                            "code": "by_cash",
                            "parent_code": "gold",
                            "sort_number": 7,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Purchase by cahs",
                                        "value": "Purchase by cahs"
                                    }
                                }
                            }
                        },
                        {
                            "code": "default",
                            "parent_code": "gold",
                            "sort_number": 4,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/e1348cca9d48cbfa5364c834398d5e00.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Purchase via Online Payment",
                                        "value": "Purchase via Online Payment"
                                    }
                                }
                            }
                        },
                        {
                            "code": "premium",
                            "sort_number": 1,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Premium Account",
                                        "value": "Premium Account"
                                    }
                                }
                            }
                        },
                        {
                            "code": "by_phone",
                            "parent_code": "gold",
                            "sort_number": 3,
                            "activation_status": "active",
                            "metadata": {
                                "category_icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/6acfe574826e2355052170f5f007caca.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/6acfe574826e2355052170f5f007caca.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/6acfe574826e2355052170f5f007caca.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/6acfe574826e2355052170f5f007caca.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Purchase via Phone Call",
                                        "value": "Purchase via Phone Call"
                                    }
                                }
                            }
                        },
                        {
                            "code": "vehicles",
                            "sort_number": 15,
                            "activation_status": "active",
                            "metadata": {
                                "background": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/66415c439c1802381a90a4f2908526e7.jpeg"
                                        }
                                    }
                                },
                                "filter_properties": {
                                    "@type": "JsonB",
                                    "content": [
                                        {
                                            "caption": {
                                                "@type": "LocString",
                                                "data": {
                                                    "cs": "V\u0161echny n\u00e1rody",
                                                    "de": "Alle Nationen",
                                                    "en": "All nations",
                                                    "es": "Todas las naciones",
                                                    "fr": "Toutes les nations",
                                                    "hu": "\u00d6sszes nemzet",
                                                    "it": "Tutte le nazioni",
                                                    "pl": "Wszystkie narodowo\u015bci",
                                                    "ru": "\u0412\u0441\u0435 \u043d\u0430\u0446\u0438\u0438",
                                                    "tr": "T\u00fcm \u00fclkeler",
                                                    "uk": "\u0423\u0441\u0456 \u043d\u0430\u0446\u0456\u0457",
                                                    "value": "All nations"
                                                }
                                            },
                                            "filter_property_code": {
                                                "@type": "String",
                                                "data": "nation"
                                            },
                                            "filter_property_type": {
                                                "@type": "String",
                                                "data": "enum"
                                            },
                                            "icon": {
                                                "@type": "String",
                                                "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/ef268eacb67bfc4c0c0f7383eced4b7c.png"
                                            },
                                            "localizations": {
                                                "@type": "JsonB",
                                                "content": [
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "ussr"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/04618c3cef10fa7a7d58fc15f418932e.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "SSSR",
                                                                "de": "UdSSR",
                                                                "en": "U.S.S.R.",
                                                                "es": "U.R.S.S.",
                                                                "fr": "URSS",
                                                                "hu": "Szovjetuni\u00f3",
                                                                "it": "URSS",
                                                                "pl": "ZSRR",
                                                                "ru": "\u0421\u0421\u0421\u0420",
                                                                "tr": "S.S.C.B.",
                                                                "uk": "\u0421\u0420\u0421\u0420",
                                                                "value": "U.S.S.R."
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "germany"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/43991fd8e254ffed0f71642f02861ff1.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "N\u011bmecko",
                                                                "de": "Deutschland",
                                                                "en": "Germany",
                                                                "es": "Alemania",
                                                                "fr": "Allemagne",
                                                                "hu": "N\u00e9metorsz\u00e1g",
                                                                "it": "Germania",
                                                                "pl": "Niemcy",
                                                                "ru": "\u0413\u0435\u0440\u043c\u0430\u043d\u0438\u044f",
                                                                "tr": "Almanya",
                                                                "uk": "\u041d\u0456\u043c\u0435\u0447\u0447\u0438\u043d\u0430",
                                                                "value": "Germany"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "usa"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/1ba16e84576127250991b7e756e118b7.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "USA",
                                                                "de": "USA",
                                                                "en": "U.S.A.",
                                                                "es": "EE.UU.",
                                                                "fr": "USA",
                                                                "hu": "Egyes\u00fclt \u00c1llamok",
                                                                "it": "USA",
                                                                "pl": "USA",
                                                                "ru": "\u0421\u0428\u0410",
                                                                "tr": "A.B.D.",
                                                                "uk": "\u0421\u0428\u0410",
                                                                "value": "U.S.A."
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "france"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/cbf9de33c966d0b43e3bb70c4505ac91.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "Francie",
                                                                "de": "Frankreich",
                                                                "en": "France",
                                                                "es": "Francia",
                                                                "fr": "France",
                                                                "hu": "Franciaorsz\u00e1g",
                                                                "it": "Francia",
                                                                "pl": "Francja",
                                                                "ru": "\u0424\u0440\u0430\u043d\u0446\u0438\u044f",
                                                                "tr": "Fransa",
                                                                "uk": "\u0424\u0440\u0430\u043d\u0446\u0456\u044f",
                                                                "value": "France"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "uk"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/015f23001d630b45cdfe111d5b12a534.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "Brit\u00e1nie",
                                                                "de": "Vereinigtes K\u00f6nigreich",
                                                                "en": "United Kingdom",
                                                                "es": "Reino Unido",
                                                                "fr": "Royaume-Uni",
                                                                "hu": "Egyes\u00fclt Kir\u00e1lys\u00e1g",
                                                                "it": "Regno Unito",
                                                                "pl": "Zjednoczone Kr\u00f3lestwo",
                                                                "ru": "\u0412\u0435\u043b\u0438\u043a\u043e\u0431\u0440\u0438\u0442\u0430\u043d\u0438\u044f",
                                                                "tr": "Birle\u015fik Krall\u0131k",
                                                                "uk": "\u0412\u0435\u043b\u0438\u043a\u043e\u0431\u0440\u0438\u0442\u0430\u043d\u0456\u044f",
                                                                "value": "United Kingdom"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "china"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/5638b29067d294f687700c903549ab3c.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u010c\u00edna",
                                                                "de": "China",
                                                                "en": "China",
                                                                "es": "China",
                                                                "fr": "Chine",
                                                                "hu": "K\u00edna",
                                                                "it": "Cina",
                                                                "pl": "Chiny",
                                                                "ru": "\u041a\u0438\u0442\u0430\u0439",
                                                                "tr": "\u00c7in",
                                                                "uk": "\u041a\u0438\u0442\u0430\u0439",
                                                                "value": "China"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "japan"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/60b20ecf9bfb822228e12c1262f47c2d.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "Japonsko",
                                                                "de": "Japan",
                                                                "en": "Japan",
                                                                "es": "Jap\u00f3n",
                                                                "fr": "Japon",
                                                                "hu": "Jap\u00e1n",
                                                                "it": "Giappone",
                                                                "pl": "Japonia",
                                                                "ru": "\u042f\u043f\u043e\u043d\u0438\u044f",
                                                                "tr": "Japonya",
                                                                "uk": "\u042f\u043f\u043e\u043d\u0456\u044f",
                                                                "value": "Japan"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "czech"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/910121ff8fd1a6678bb01ef53ba3e561.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u010ceskoslovensko",
                                                                "de": "\u010cSR",
                                                                "en": "Czechoslovakia",
                                                                "es": "Checoslovaquia",
                                                                "fr": "Tch\u00e9coslovaquie",
                                                                "hu": "Csehszlov\u00e1kia",
                                                                "it": "Cecoslovacchia",
                                                                "pl": "Czechos\u0142owacja",
                                                                "ru": "\u0427\u0435\u0445\u043e\u0441\u043b\u043e\u0432\u0430\u043a\u0438\u044f",
                                                                "tr": "\u00c7ekoslovakya",
                                                                "uk": "\u0427\u0435\u0445\u043e\u0441\u043b\u043e\u0432\u0430\u043a\u0456\u044f",
                                                                "value": "Czechoslovakia"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "sweden"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/45b436855b4ad40fb6054021c4381217.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u0160v\u00e9dsko",
                                                                "de": "Schweden",
                                                                "en": "Sweden",
                                                                "es": "Suecia",
                                                                "fr": "Su\u00e8de",
                                                                "hu": "Sv\u00e9dorsz\u00e1g",
                                                                "it": "Svezia",
                                                                "pl": "Szwecja",
                                                                "ru": "\u0428\u0432\u0435\u0446\u0438\u044f",
                                                                "tr": "\u0130sve\u00e7",
                                                                "uk": "\u0428\u0432\u0435\u0446\u0456\u044f",
                                                                "value": "Sweden"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "poland"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/69a9f8767eded4a988e6b9282d0434d3.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "Polsko",
                                                                "de": "Polen",
                                                                "en": "Poland",
                                                                "es": "Polonia",
                                                                "fr": "Pologne",
                                                                "hu": "Lengyelorsz\u00e1g",
                                                                "it": "Polonia",
                                                                "pl": "Polska",
                                                                "ru": "\u041f\u043e\u043b\u044c\u0448\u0430",
                                                                "tr": "Polonya",
                                                                "uk": "\u041f\u043e\u043b\u044c\u0449\u0430",
                                                                "value": "Poland"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "italy"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/97cfcfae632bf8bb948a6697fcb3c590.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "It\u00e1lie",
                                                                "de": "Italien",
                                                                "en": "Italy",
                                                                "es": "Italia",
                                                                "fr": "Italie",
                                                                "hu": "Olaszorsz\u00e1g",
                                                                "it": "Italia",
                                                                "pl": "W\u0142ochy",
                                                                "ru": "\u0418\u0442\u0430\u043b\u0438\u044f",
                                                                "tr": "\u0130talya",
                                                                "uk": "\u0406\u0442\u0430\u043b\u0456\u044f",
                                                                "value": "Italy"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            "caption": {
                                                "@type": "LocString",
                                                "data": {
                                                    "cs": "V\u0161echny typy",
                                                    "de": "Alle Typen",
                                                    "en": "All types",
                                                    "es": "Todos los tipos",
                                                    "fr": "Tous les types",
                                                    "hu": "\u00d6sszes t\u00edpus",
                                                    "it": "Tutti i tipi",
                                                    "pl": "Wszystkie typy",
                                                    "ru": "\u0412\u0441\u0435 \u0442\u0438\u043f\u044b",
                                                    "tr": "T\u00fcm t\u00fcrler",
                                                    "uk": "\u0423\u0441\u0456 \u0442\u0438\u043f\u0438",
                                                    "value": "All types"
                                                }
                                            },
                                            "filter_property_code": {
                                                "@type": "String",
                                                "data": "type"
                                            },
                                            "filter_property_type": {
                                                "@type": "String",
                                                "data": "enum"
                                            },
                                            "icon": {
                                                "@type": "String",
                                                "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/820a4d7fc355305575d49035d0762a4d.png"
                                            },
                                            "localizations": {
                                                "@type": "JsonB",
                                                "content": [
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "lightTank"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/ca0c837cd1a68af37d43fd0acea1db64.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "Lehk\u00e9 tanky",
                                                                "de": "Leichte Panzer",
                                                                "en": "Light tanks",
                                                                "es": "Carros ligeros",
                                                                "fr": "Chars l\u00e9gers",
                                                                "hu": "K\u00f6nny\u0171 tankok",
                                                                "it": "Corazzati leggeri",
                                                                "pl": "Czo\u0142gi lekkie",
                                                                "ru": "\u041b\u0451\u0433\u043a\u0438\u0435 \u0442\u0430\u043d\u043a\u0438",
                                                                "tr": "Hafif tanklar",
                                                                "uk": "\u041b\u0435\u0433\u043a\u0456 \u0442\u0430\u043d\u043a\u0438",
                                                                "value": "Light tanks"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "mediumTank"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/307665ec037b1708cf9b57a9d3859f84.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "St\u0159edn\u00ed tanky",
                                                                "de": "Mittlere Panzer",
                                                                "en": "Medium tanks",
                                                                "es": "Carros medios",
                                                                "fr": "Chars moyens",
                                                                "hu": "K\u00f6zepes tankok",
                                                                "it": "Corazzati medi",
                                                                "pl": "Czo\u0142gi \u015brednie",
                                                                "ru": "\u0421\u0440\u0435\u0434\u043d\u0438\u0435 \u0442\u0430\u043d\u043a\u0438",
                                                                "tr": "Orta tanklar",
                                                                "uk": "\u0421\u0435\u0440\u0435\u0434\u043d\u0456\u00a0\u0442\u0430\u043d\u043a\u0438",
                                                                "value": "Medium tanks"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "heavyTank"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/aa9126b0f4884155531382e4b9ca1250.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "T\u011b\u017ek\u00e9 tanky",
                                                                "de": "Schwere Panzer",
                                                                "en": "Heavy tanks",
                                                                "es": "Carros pesados",
                                                                "fr": "Chars lourds",
                                                                "hu": "Neh\u00e9z tankok",
                                                                "it": "Corazzati pesanti",
                                                                "pl": "Czo\u0142gi ci\u0119\u017ckie",
                                                                "ru": "\u0422\u044f\u0436\u0451\u043b\u044b\u0435 \u0442\u0430\u043d\u043a\u0438",
                                                                "tr": "A\u011f\u0131r tanklar",
                                                                "uk": "\u0412\u0430\u0436\u043a\u0456\u00a0\u0442\u0430\u043d\u043a\u0438",
                                                                "value": "Heavy tanks"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "AT-SPG"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/f0207546e8dc22c2c760352b16d8fe29.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "St\u00edha\u010d tank\u016f",
                                                                "de": "Jagdpanzer",
                                                                "en": "Tank destroyer",
                                                                "es": "Anticarro",
                                                                "fr": "Chasseur de chars",
                                                                "hu": "P\u00e1nc\u00e9lvad\u00e1szok",
                                                                "it": "Cacciacarrii",
                                                                "pl": "Niszczyciel czo\u0142g\u00f3w",
                                                                "ru": "\u041f\u0422-\u0421\u0410\u0423",
                                                                "tr": "Tank avc\u0131s\u0131",
                                                                "uk": "\u041f\u0422-\u0421\u0410\u0423",
                                                                "value": "Tank destroyer"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "SPG"
                                                        },
                                                        "icon": {
                                                            "@type": "String",
                                                            "data": "https://catoolwebdav-net-cdn.gcdn.co/catool/4c6fc4217332f769c7b77db5cbbc9a46.png"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "D\u011blost\u0159electvo",
                                                                "de": "SFL",
                                                                "en": "SPG",
                                                                "es": "AAP",
                                                                "fr": "Canon automoteur",
                                                                "hu": "\u00d6nj\u00e1r\u00f3 l\u00f6vegek",
                                                                "it": "A-SMV",
                                                                "pl": "Dzia\u0142o samobie\u017cne",
                                                                "ru": "\u0421\u0410\u0423",
                                                                "tr": "KMT",
                                                                "uk": "\u0421\u0410\u0423",
                                                                "value": "SPG"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            "caption": {
                                                "@type": "LocString",
                                                "data": {
                                                    "cs": "I\u2013X v\u0161echny \u00farovn\u011b",
                                                    "de": "Alle Stufen (I\u2013X)",
                                                    "en": "I-X All Tiers",
                                                    "es": "Todos los niveles (I-X)",
                                                    "fr": "Tous les rangs, I \u00e0 X",
                                                    "hu": "I-X \u00d6sszes Szint",
                                                    "it": "I-X Tutti i livelli",
                                                    "pl": "I-X Wszystkie poziomy",
                                                    "ru": "I-X \u0412\u0441\u0435 \u0443\u0440\u043e\u0432\u043d\u0438",
                                                    "tr": "I-X T\u00fcm Seviyeler",
                                                    "uk": "I-X\u00a0\u0423\u0441\u0456 \u0440\u0456\u0432\u043d\u0456",
                                                    "value": "I-X All Tiers"
                                                }
                                            },
                                            "filter_property_code": {
                                                "@type": "String",
                                                "data": "level"
                                            },
                                            "filter_property_type": {
                                                "@type": "String",
                                                "data": "enum"
                                            },
                                            "localizations": {
                                                "@type": "JsonB",
                                                "content": [
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "1"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 I",
                                                                "de": "Stufe\u00a0I",
                                                                "en": "Tier I",
                                                                "es": "Nivel I",
                                                                "fr": "Rang I",
                                                                "hu": "I. Szint",
                                                                "it": "Livello I",
                                                                "pl": "Poziom I",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c I",
                                                                "tr": "Seviye I",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0I",
                                                                "value": "Tier I"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "2"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 II",
                                                                "de": "Stufe\u00a0II",
                                                                "en": "Tier II",
                                                                "es": "Nivel II",
                                                                "fr": "Rang II",
                                                                "hu": "II. Szint",
                                                                "it": "Livello II",
                                                                "pl": "Poziom II",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c II",
                                                                "tr": "Seviye II",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0II",
                                                                "value": "Tier II"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "3"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 III",
                                                                "de": "Stufe\u00a0III",
                                                                "en": "Tier III",
                                                                "es": "Nivel III",
                                                                "fr": "Rang III",
                                                                "hu": "III. Szint",
                                                                "it": "Livello III",
                                                                "pl": "Poziom III",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c III",
                                                                "tr": "Seviye III",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0III",
                                                                "value": "Tier III"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "4"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 IV",
                                                                "de": "Stufe\u00a0IV",
                                                                "en": "Tier IV",
                                                                "es": "Nivel IV",
                                                                "fr": "Rang IV",
                                                                "hu": "IV. Szint",
                                                                "it": "Livello IV",
                                                                "pl": "Poziom IV",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c IV",
                                                                "tr": "Seviye IV",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0IV",
                                                                "value": "Tier IV"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "5"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 V",
                                                                "de": "Stufe\u00a0V",
                                                                "en": "Tier V",
                                                                "es": "Nivel V",
                                                                "fr": "Rang V",
                                                                "hu": "V. Szint",
                                                                "it": "Livello V",
                                                                "pl": "Poziom V",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c V",
                                                                "tr": "Seviye V",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0V",
                                                                "value": "Tier V"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "6"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 VI",
                                                                "de": "Stufe\u00a0VI",
                                                                "en": "Tier VI",
                                                                "es": "Nivel VI",
                                                                "fr": "Rang VI",
                                                                "hu": "VI. Szint",
                                                                "it": "Livello VI",
                                                                "pl": "Poziom VI",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c VI",
                                                                "tr": "Seviye VI",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0VI",
                                                                "value": "Tier VI"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "7"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 VII",
                                                                "de": "Stufe\u00a0VII",
                                                                "en": "Tier VII",
                                                                "es": "Nivel VII",
                                                                "fr": "Rang VII",
                                                                "hu": "VII. Szint",
                                                                "it": "Livello VII",
                                                                "pl": "Poziom VII",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c VII",
                                                                "tr": "Seviye VII",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0VII",
                                                                "value": "Tier VII"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "8"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 VIII",
                                                                "de": "Stufe\u00a0VIII",
                                                                "en": "Tier VIII",
                                                                "es": "Nivel VIII",
                                                                "fr": "Rang VIII",
                                                                "hu": "VIII. Szint",
                                                                "it": "Livello VIII",
                                                                "pl": "Poziom VIII",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c VIII",
                                                                "tr": "Seviye VIII",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0VIII",
                                                                "value": "Tier VIII"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "9"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 IX",
                                                                "de": "Stufe\u00a0IX",
                                                                "en": "Tier IX",
                                                                "es": "Nivel IX",
                                                                "fr": "Rang IX",
                                                                "hu": "IX. Szint",
                                                                "it": "Livello IX",
                                                                "pl": "Poziom IX",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c IX",
                                                                "tr": "Seviye IX",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0IX",
                                                                "value": "Tier IX"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "filter_property_value": {
                                                            "@type": "String",
                                                            "data": "10"
                                                        },
                                                        "text": {
                                                            "@type": "LocString",
                                                            "data": {
                                                                "cs": "\u00darove\u0148 X",
                                                                "de": "Stufe\u00a0X",
                                                                "en": "Tier X",
                                                                "es": "Nivel X",
                                                                "fr": "Rang X",
                                                                "hu": "X. Szint",
                                                                "it": "Livello X",
                                                                "pl": "Poziom X",
                                                                "ru": "\u0423\u0440\u043e\u0432\u0435\u043d\u044c X",
                                                                "tr": "Seviye X",
                                                                "uk": "\u0420\u0456\u0432\u0435\u043d\u044c\u00a0X",
                                                                "value": "Tier X"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Aircraft",
                                        "value": "Aircraft"
                                    }
                                }
                            }
                        },
                        {
                            "code": "by_coupon",
                            "parent_code": "gold",
                            "sort_number": 8,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "By by coupon",
                                        "value": "By by coupon"
                                    }
                                }
                            }
                        },
                        {
                            "code": "wg_premium",
                            "parent_code": "premium",
                            "sort_number": 14,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/f3ba7efa692be4c78d8ac897e1af229b.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/f3ba7efa692be4c78d8ac897e1af229b.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/f3ba7efa692be4c78d8ac897e1af229b.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/f3ba7efa692be4c78d8ac897e1af229b.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Wargaming Premium Account",
                                        "value": "Wargaming Premium Account"
                                    }
                                }
                            }
                        },
                        {
                            "code": "game_premium",
                            "parent_code": "premium",
                            "sort_number": 13,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/d39b3eb1bb14183f9a0067c177033c59.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/d39b3eb1bb14183f9a0067c177033c59.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/d39b3eb1bb14183f9a0067c177033c59.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/d39b3eb1bb14183f9a0067c177033c59.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "World of Tanks Premium Account",
                                        "value": "World of Tanks Premium Account"
                                    }
                                }
                            }
                        },
                        {
                            "code": "canon_premium",
                            "sort_number": 23,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Canon Premium",
                                        "value": "Canon Premium"
                                    }
                                }
                            }
                        },
                        {
                            "code": "internet_plus",
                            "parent_code": "gold",
                            "sort_number": 6,
                            "activation_status": "active",
                            "metadata": {
                                "icon": {
                                    "@type": "LocMedia",
                                    "data": {
                                        "mediatype": "image",
                                        "preview_url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        },
                                        "url": {
                                            "en": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png",
                                            "value": "https://catoolwebdav-net-cdn.gcdn.co/catool/790e5619eab3455d6580eedf1aa8e2d0.png"
                                        }
                                    }
                                },
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "PURCHASE VIA MOBILE PAYMENT",
                                        "value": "PURCHASE VIA MOBILE PAYMENT"
                                    }
                                }
                            }
                        },
                        {
                            "code": "aircraft_premium",
                            "sort_number": 21,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Aircraft Premium",
                                        "value": "Aircraft Premium"
                                    }
                                }
                            }
                        },
                        {
                            "code": "vehicles_premium",
                            "sort_number": 19,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Vehicles Premium",
                                        "value": "Vehicles Premium"
                                    }
                                }
                            }
                        },
                        {
                            "code": "warships_premium",
                            "sort_number": 22,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Warships Premium",
                                        "value": "Warships Premium"
                                    }
                                }
                            }
                        },
                        {
                            "code": "customizations_premium",
                            "sort_number": 20,
                            "activation_status": "active",
                            "metadata": {
                                "name": {
                                    "@type": "LocString",
                                    "data": {
                                        "en": "Customizations Premium",
                                        "value": "Customizations Premium"
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        }
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
