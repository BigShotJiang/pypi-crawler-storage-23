﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class FetchClientPaymentMethods(web.View):
    """
    https://wgcps.asia.wots.iv/doc/#operation/fetchClientPaymentMethods
    """

    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        methods = []
        if WGNIUsersDB.payments_methods_available:
            methods = [
                        {
                            "id": 82,
                            "name": "igp_CreditCard",
                            "description": "Visa, MasterCard, Maestro, МИР",
                            "priority": 2,
                            "multiple_bindings": True,
                            "icons": [
                                {
                                    "image_type": "notification",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/PNG_RU_igp_CreditCard.png"
                                },
                                {
                                    "image_type": "one_click_payment",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/RU_igp_CreditCard.svg"
                                },
                                {
                                    "image_type": "purchase",
                                    "image_url": "https://static-pss-ru.wgcdn.co/shop/media/blank.png"
                                }
                            ]
                        },
                        {
                            "id": 83,
                            "name": "igp_Card Wargaming",
                            "description": "Wargaming card",
                            "priority": 5,
                            "multiple_bindings": True,
                            "icons": [
                                {
                                    "image_type": "notification",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/PNG_wg-card.png"
                                },
                                {
                                    "image_type": "one_click_payment",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/wg-card.svg"
                                },
                                {
                                    "image_type": "purchase",
                                    "image_url": "https://static-pss-ru.wgcdn.co/shop/media/groups/8c/fb/8cfb4bfb21dc499aa69cae0788188ab8.svg"
                                }
                            ]
                        },
                        {
                            "id": 84,
                            "name": "igp_Paypal",
                            "description": "PayPal",
                            "priority": 4,
                            "multiple_bindings": False,
                            "icons": [
                                {
                                    "image_type": "notification",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/PNG_igp_Paypal.png"
                                },
                                {
                                    "image_type": "one_click_payment",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/igp_Paypal.svg"
                                },
                                {
                                    "image_type": "purchase",
                                    "image_url": "https://static-pss-ru.wgcdn.co/shop/media/groups/9c/8e/9c8e92025c7f4348a48fa659baff41bc.svg"
                                }
                            ]
                        },
                        {
                            "id": 85,
                            "name": "igp_QIWI Wallet",
                            "description": "QIWI",
                            "priority": 3,
                            "multiple_bindings": False,
                            "icons": [
                                {
                                    "image_type": "notification",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/PNG_igp_QIWI_Wallet.png"
                                },
                                {
                                    "image_type": "one_click_payment",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/igp_QIWI_Wallet.svg"
                                },
                                {
                                    "image_type": "purchase",
                                    "image_url": "https://static-pss-ru.wgcdn.co/shop/media/groups/37/d0/37d06a452ea44200b6302aab806edbf5.svg"
                                }
                            ]
                        },
                        {
                            "id": 86,
                            "name": "igp_YooMoney",
                            "description": "ЮMoney кошелек",
                            "priority": 6,
                            "multiple_bindings": False,
                            "icons": [
                                {
                                    "image_type": "notification",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/PNG_igp_YooMoney.png"
                                },
                                {
                                    "image_type": "one_click_payment",
                                    "image_url": "https://catoolwebdav-net-cdn.gcdn.co/pga/group_icons/ru/igp_YooMoney.svg"
                                },
                                {
                                    "image_type": "purchase",
                                    "image_url": "https://static-pss-ru.wgcdn.co/shop/media/groups/6b/ce/6bce8d96a9624d01abf07be74a4ddb63.svg"
                                }
                            ]
                        }
                    ]
        data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": "eceb2963-88b5-4fd7-b6f3-251210be4e1d",
                    "tracking-id": "75f5e7ae-cd27-40b8-9eb7-a1a89878b594"
                },
                "body": {
                    "methods": methods,
                    "binding_management_url": "https://asia.wgnwn.wgns.iv/shop/binding/"
                }
            }
        }

        return web.json_response(data)

    async def post(self):
        return await self._on_post()
