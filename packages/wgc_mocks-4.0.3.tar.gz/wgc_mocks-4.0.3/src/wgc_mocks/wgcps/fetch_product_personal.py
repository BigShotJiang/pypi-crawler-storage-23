﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio

from aiohttp import web

from wgc_core.exceptions import MissingParamException


class FetchProductPersonal(web.View):
    """
    https://wgcps-wgs11.wgtest.net/commerce/api/v7/fetchProductPersonal
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await asyncio.wait_for(self.request.json(), timeout=15)
        else:
            params = dict(await self.request.post())
        
        country = params.get('body').get('country')
        platform = params.get('body').get('platform')
        title = params.get('title')  # noqa

        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {params}')
        if not country:
            raise MissingParamException(f'Missing required param: "country": {self.request.path} -> {params}')
        if not platform:
            raise MissingParamException(f'Missing required param: "platform": {self.request.path} -> {params}')
        
        data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": "01J8MT26GH31KFCFMBMEYT9MR3",
                    "tracking-id": "01J8MT26GH31KFCFMBMEYT9MR3"
                },
                "body": {
                    "price": {
                        "real_price": {
                            "currency_code": "PLN",
                            "amount": "0.23",
                            "original_amount": "0.23",
                            "discount": {
                                "amount": "0.00",
                                "pct": "0"
                            }
                        },
                        "virtual_prices": []
                    },
                    "rewards": [],
                    "discounts": [],
                    "coupon_codes": [],
                    "client_payment_method_ids": [
                        82,
                        83,
                        84,
                        85,
                        86
                    ],
                    # "payment_limit": {
                    #     "currency_code": "PLN",
                    #     "total_limit_amount": "5.00",
                    #     "available_amount": "0.00"
                    # }
                }
            }
        }
        
        return web.json_response(data)
    
    async def post(self):
        return await self._on_post()
