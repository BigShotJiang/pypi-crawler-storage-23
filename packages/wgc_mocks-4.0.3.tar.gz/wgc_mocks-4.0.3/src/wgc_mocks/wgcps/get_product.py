﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import json
from os import path

from aiohttp import web

from wgc_mocks.wgni.storage import WGNIUsersDB


class GetProduct(web.View):

    def _on_get(self):
        """
        Method for further monkey patching.
        """
        product_id = self.request.match_info.get('product_id')
        product = WGNIUsersDB.get_product_by_link_id(product_id)
        if not product:
            return web.json_response({}, status=404)
        if 'wgc_shop_product_id' in product_id:
            with open(path.join(path.dirname(
                    __file__), 'shop_product.json'), 'r', encoding='utf-8') as fp:
                content = fp.read()
                json_content = json.loads(content)
                json_content['product_code'] = product.product_code
                json_content['price']['real_price']['amount'] = str(product.price - product.discount_amount)
                json_content['price']['real_price']['original_amount'] = str(product.price)
                return web.json_response(json_content,
                                         headers={'Cache-Control': f'public, max-age={WGNIUsersDB.cache_products}'})
        elif 'shop_limited_product_id' in product_id:
            with open(path.join(path.dirname(
                    __file__), 'shop_limited_product.json'), 'r', encoding='utf-8') as fp:
                content = fp.read()
                json_content = json.loads(content)
                json_content['product_code'] = product.product_code
                json_content['price']['real_price']['amount'] = str(product.price - product.discount_amount)
                json_content['price']['real_price']['original_amount'] = str(product.price)
                return web.json_response(json_content,
                                         headers={'Cache-Control': f'public, max-age={WGNIUsersDB.cache_products}'})
        else:
            return web.json_response(json.loads(product.json),
                                     headers={'Cache-Control': f'public, max-age={WGNIUsersDB.cache_products}'})

    async def get(self):
        return self._on_get()
