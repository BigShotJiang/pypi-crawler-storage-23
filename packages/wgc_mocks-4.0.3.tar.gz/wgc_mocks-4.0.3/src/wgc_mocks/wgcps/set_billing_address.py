﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from aiohttp import web

from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni import WGNIUsersDB


class SetBillingAddress(web.View):
    """
    https://stash.wargaming.net/projects/WDSS/repos/wgcps/browse/src/wgcps/accounts/v1/api.py#161
    """
    
    async def _on_post(self):
        """
        Method for further monkey patching.
        """
        # region headers parsing
        authorization = self.request.headers.get('AUTHORIZATION')  # noqa
        # endregion
        
        # region params parsing
        if self.request.content_type == 'application/json' and self.request.body_exists:
            params = await self.request.json()
        else:
            params = dict(await self.request.post())
        
        account_id = params.get('account_id')
        address = params.get('address')
        title = params.get('title')
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {params}')
        # endregion

        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(':') + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response({'status': 'error',
                                          "data": {}, "errors": [{"code": "unauthorized"}]},
                                         status=401)
        else:
            return web.json_response({'status': 'error',
                                      "data": {}, "errors": [{"code": "unauthorized"}]},
                                     status=401)
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        account.address = address
        
        return web.json_response({"status": "ok", "data": {
            "header": {"message-id": "d11b48d9-d37f-4c1c-80ae-fc8c99b5672c",
                       "tracking-id": "086bd6d2-42c2-46f2-85f1-8a4f7efa80c8"},
            "body": {}}})
    
    async def post(self):
        return await self._on_post()
