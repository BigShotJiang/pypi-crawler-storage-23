﻿# -*- coding: utf-8 -*-

__author__ = "n_kovganko@wargaming.net"

import asyncio
import uuid
from datetime import datetime

from aiohttp import web

from wgc_core.exceptions import MissingParamException
from wgc_mocks.wgni.storage import WGNIUsersDB


class PurchaseProductPrepare(web.View):
    
    async def _on_post(self):
        authorization = self.request.headers.get("AUTHORIZATION")  # noqa
        await asyncio.sleep(WGNIUsersDB.prepare_product_timeout)
        if authorization:
            access_token, exchange_code = \
                (authorization.split()[-1].split(":") + [None])[:2]
            account = WGNIUsersDB.get_account_by_oauth_token(access_token)
            if not account:
                return web.json_response(
                    {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401)
        else:
            return web.json_response(
                {"status": "error", "errors": [{"code": "unauthorized"}]}, status=401
            )
        data = await self.request.json()
        title = data.get("title")
        
        if not title:
            raise MissingParamException(f'Missing required param: "title": {self.request.path} -> {data}')
        
        account_id = data.get("account_id")
        body = data.get("body")
        if not title:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "title",
                            "text": "title is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not account_id:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "account_id",
                            "text": "account_id is required parameter"
                        }
                    }
                ]
            }, status=400)
        if not body:
            return web.json_response({
                "status": "error",
                "errors": [
                    {
                        "code": "invalid",
                        "context": {
                            "parameter": "body",
                            "text": "body is required parameter"
                        }
                    }
                ]
            }, status=400)
        
        account = WGNIUsersDB.get_account_by_account_id(account_id)
        expected_price = body.get("expected_price")
        amount = expected_price.get("amount")
        currency_code = expected_price.get("currency_code")
        product_code = body.get("product").get('code')
        language = body.get('purchaser').get('language')
        transaction_id = body.get("transaction_id")
        message_id = str(uuid.uuid4())
        order_id = str(uuid.uuid4())
        client_payment_method_id = body.get("client_payment_method_id")
        from wgc_mocks.game_mocks import GameMocks
        
        product = WGNIUsersDB.get_product_by_query(lambda x: x.product_code == product_code)
        if WGNIUsersDB.strong_check_language:
            if product.language != language:
                return web.json_response({
                    "status": "error",
                    "data": {
                        "header": {
                            "message-id": "3cc78f2d-26b8-4e83-b4cb-06494ddcb1ff",
                            "tracking-id": "01H1VWTGAB6A58EW5VXJAKH277"
                        }
                    },
                    "errors": [
                        {
                            "code": "platform_error",
                            "context": {
                                "result_code": "BAD_REQUEST"
                            }
                        }
                    ]
                }, status=500)
        
        last_activity_date = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        # next actions:
        next_pay = {
            'action_code': 'pay',
            'client_payment_method_id': client_payment_method_id,
            'bindings': [
                {
                    'binding_id': 60000581,
                    'last_activity_date': last_activity_date,
                    'binding_info': {
                        'source': "bank_card",
                        'card_number': "1234567890123456",
                        'expiration_date': "12/24",
                        'card_type': "visa",
                        'image_url': "https://webdav-wgs.wdo.io/pga/binding_icons/wgs11/bank_card_mastercard.svg"
                    }
                },
            ]
        }
        
        next_redirect = {
            'action_code': 'redirect',
            'client_payment_method_id': None,
            'bindings': [],
            'redirect_url': 'https://wgs11.wgtest.net/shop/external/payment/braintree/paypal/'
        }
        
        next_binding = {
            'action_code': 'create_binding',
            'client_payment_method_id': None,
            'bindings': [],
            'redirect_url': 'https://wgs11.wgtest.net/shop/external/payment/braintree/paypal/'
        }
        
        next_choose_payment_group = {
            'action_code': 'choose_payment_group',
            'client_payment_method_id': None,
            'bindings': [],
            'redirect_url': None
        }
        if WGNIUsersDB.action_code_create_binding is None:
            if account.next_action is None:
                next_action = next_choose_payment_group
                account.next_action = 'choose_payment_group'
            elif account.next_action not in [None, 'choose_payment_group'] and \
                    WGNIUsersDB.prepare_account_status == 'disabled' and WGNIUsersDB.prepare_check_required:
                next_action = next_redirect
                account.next_action = 'redirect'
            else:
                next_action = next_pay
                account.next_action = 'pay'
        else:
            if account.next_action is None:
                next_action = next_choose_payment_group
                account.next_action = 'choose_payment_group'
            else:
                next_action = next_binding
                account.next_action = 'create_binding'
        
        if product and product.price_type.lower() not in ['zero', 'variable'] and str(
                product.price - product.discount_amount) != amount:
            return web.json_response({
                "status": "error", "data": {
                    "header": {"message-id": "94359179-3e7b-489c-9bdd-eaa04030ce03",
                               "tracking-id": "3bd6c36a-7dd1-490e-92ab-84e5c2925c8d"}},
                "errors": [
                    {"code": "platform_error",
                     "context": {
                         "result_code": "EXPECTED_PRICE_MISMATCH"}
                     }]}, status=500)
        
        if product and product.price_type.lower() == 'variable' and body.get('product').get(
                'quantity') < WGNIUsersDB.variable_price_min:
            return web.json_response({
                "status": "error", "data": {
                    "header": {"message-id": "90bafb14-e9c7-4397-b9a4-f5534bb74785",
                               "tracking-id": "01HTPWCWM90D39W9F07H60QR3C"}},
                "errors": [
                    {"code": "platform_error",
                     "context": {
                         "result_code": "PRODUCT_NOT_ALLOWED"}}]}, status=500)
        
        account.order_product_code = product_code
        billing_address = {
            "management_url": f"https://{GameMocks.host_https}/personal/"
                              f"security_management/?feature_id=igp&method={WGNIUsersDB.prepare_method}",
            "mandatory": WGNIUsersDB.billing_mandatory,
            "applicable": WGNIUsersDB.billing_applicable
        }
        
        if account.address:
            billing_address['address'] = account.address
        
        if WGNIUsersDB.billing_mandatory and not account.address:
            return web.json_response({
                "status": "error",
                "data": {
                    "header": {"message-id": "1d93fe1e-9df7-4f02-b1a1-d58e93d832ee",
                               "tracking-id": "d9f755df-cefc-4dc5-9f25-02e65ead2f74"}}, "errors": [
                    {"code": "platform_error", "context": {"result_code": "ADDRESS_REQUIRED_BUT_NOT_EXIST"}}]},
                status=500)
        
        available_bindings = [
            {
                'client_payment_method_id': client_payment_method_id,
                'bindings': [
                    {
                        "binding_id": 40241952,
                        "last_activity_date": last_activity_date,
                        "binding_info": {
                            "source": "paypal",
                            "email": account.username,
                            "image_url": "https://webdav-wgs.wdo.io/pga/binding_icons/wgs11/paypal_default.svg"
                        }
                    }
                ]
            }]
        
        resp_data = {
            "status": "ok",
            "data": {
                "header": {
                    "message-id": message_id,
                    "tracking-id": account.current_log_Id
                },
                "body": {
                    'transaction_id': transaction_id,
                    'order_id': order_id,
                    'price': {
                        'currency_code': currency_code,
                        'amount': amount
                    },
                    'tsv': {
                        'account_status': WGNIUsersDB.prepare_account_status,
                        'method': WGNIUsersDB.prepare_method,
                        'mandatory_check': WGNIUsersDB.prepare_check_required,
                        'management_url': f"https://{GameMocks.host_https}/personal/"
                                          f"security_management/?feature_id=igp&method={WGNIUsersDB.prepare_method}"
                    },
                    'next_action': next_action
                }
            }
        }
        if account.next_action == 'pay':
            resp_data['data']['body']['available_bindings'] = available_bindings
        if WGNIUsersDB.redirect_url_present:
            resp_data['data']['body']['next_action']['redirect_url'] = WGNIUsersDB.redirect_url
        if WGNIUsersDB.billing_info_available:
            resp_data['data']['body']['billing_address'] = billing_address
        return web.json_response(resp_data)
    
    async def post(self):
        return await self._on_post()
