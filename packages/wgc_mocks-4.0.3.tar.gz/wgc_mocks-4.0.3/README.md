# wgc-mocks

Full mock server for the WGC QA framework. Emulates all external services that Wargaming Game Center communicates with, including authentication (WGNI), commerce (WGCPS), content (CHUB API), and Steam integration.

## Architecture

```
GameMocks (aiohttp async server)
├── HTTP  :8888
├── HTTPS :7771
│
├── WGNI (Wargaming Network Identity)
│   ├── OAuth token create/verify/revoke
│   ├── Account info (v2, v3)
│   ├── Two-factor authentication
│   ├── Challenge/captcha
│   └── Game ticket issue/consume
│
├── WGNR (Registration)
│   ├── Basic account creation
│   ├── Demo account creation
│   ├── Steam registration
│   └── Account activation
│
├── WGNP (Personal)
│   ├── Nickname change/validation
│   ├── Teleport (realm transfer)
│   ├── Signature management
│   └── Credentials management
│
├── WGCPS (Commerce)
│   ├── Product list (personal/global)
│   ├── Storefront categories
│   ├── Purchase prepare/commit
│   ├── Payment methods
│   ├── Bonus code redemption
│   ├── Notifications
│   └── Game page categories
│
├── CHUB API (Content)
│   ├── Content feed
│   ├── Game resources
│   └── Pages
│
├── Agate (Steam)
│   ├── Steam external payment init
│   └── Steam external payment commit
│
└── Update Service
    ├── Game patches / metadata
    └── Torrent files
```

## Usage

```python
from wgc_mocks import GameMocks

# Start mock server
await GameMocks.start()

# Mock handlers are swappable for testing error scenarios:
original = GameMocks.get_game_patch
async def error_handler(request):
    return web.Response(status=503)
GameMocks.get_game_patch = error_handler

# Restore
GameMocks.get_game_patch = original
```

### WGNIUsersDB — in-memory user database

```python
from wgc_mocks.wgni import WGNIUsersDB

# User management for mock auth
WGNIUsersDB.create_user(email='test@test.com', password='pass123')
user = WGNIUsersDB.get_user_by_email('test@test.com')
```

## Key Features

- **Hot-swappable handlers** — replace any mock handler in fixtures to simulate errors
- **Self-signed HTTPS** — supports both HTTP and HTTPS with bundled certificates
- **WebSocket proxy** — forwards WebSocket messages between test and WGC
- **Stateful** — maintains user sessions, tokens, purchase state across requests
- **60+ API routes** mocked across WGNI, WGCPS, CHUB, and Agate

## Install

```bash
pip install wgc-mocks
```

## Dependencies

- `wgc-core` — config, logger, exceptions
- `wgc-helpers` — OS helpers, encryption, certificates
- `wgc-clippy` — utilities
- `aiohttp` — async HTTP server
- `nest-asyncio` — nested event loop support
