# dagster-docker-swarm — Standalone Package Plan

## Context

We have a production-tested `SwarmRunLauncher` that launches Dagster runs as Docker Swarm services. This fills a gap in the Dagster ecosystem — there's been an open request since 2022 (dagster-io/dagster#7048) with no official solution. The only existing community attempt (`dagster-swarm` on PyPI) is an empty stub with zero implemented methods.

This plan creates a standalone `uv`-managed Python package called `dagster-docker-swarm` that can be published to PyPI.

## Package Structure

```
dagster-docker-swarm/
├── pyproject.toml
├── README.md
├── LICENSE                              # Apache-2.0
├── src/
│   └── dagster_docker_swarm/
│       ├── __init__.py                  # Public API + DagsterLibraryRegistry
│       ├── _version.py                  # __version__ = "0.1.0"
│       ├── run_launcher.py              # SwarmRunLauncher (core)
│       └── container_context.py         # SwarmContainerContext (config merging)
└── tests/
    ├── __init__.py
    ├── conftest.py                      # Shared fixtures
    ├── test_run_launcher.py             # Unit tests for launcher
    └── test_container_context.py        # Unit tests for config merging
```

## Step 1: Project Initialisation

```bash
mkdir dagster-docker-swarm && cd dagster-docker-swarm
uv init --lib --package dagster-docker-swarm
```

Then replace the generated `pyproject.toml` with:

### `pyproject.toml`

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "dagster-docker-swarm"
version = "0.1.0"
description = "A Dagster run launcher that executes pipeline runs as Docker Swarm services"
readme = "README.md"
license = { text = "Apache-2.0" }
requires-python = ">=3.10"
authors = [
    { name = "Your Name", email = "you@example.com" },
]
classifiers = [
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "License :: OSI Approved :: Apache Software License",
    "Operating System :: OS Independent",
]
dependencies = [
    "dagster>=1.9.0",
    "docker>=7.0.0",
    "docker-image-py>=0.1.12",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "ruff>=0.4",
]

[project.urls]
Homepage = "https://github.com/YOURORG/dagster-docker-swarm"
Repository = "https://github.com/YOURORG/dagster-docker-swarm"
Issues = "https://github.com/YOURORG/dagster-docker-swarm/issues"

[tool.hatch.build.targets.wheel]
packages = ["src/dagster_docker_swarm"]

[tool.ruff]
line-length = 120
target-version = "py310"

[tool.ruff.lint]
select = ["E", "F", "I", "W"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

## Step 2: Source Files

### `src/dagster_docker_swarm/_version.py`

```python
__version__ = "0.1.0"
```

### `src/dagster_docker_swarm/__init__.py`

```python
from dagster_docker_swarm._version import __version__
from dagster_docker_swarm.container_context import SwarmContainerContext
from dagster_docker_swarm.run_launcher import SwarmRunLauncher

__all__ = [
    "__version__",
    "SwarmContainerContext",
    "SwarmRunLauncher",
]

try:
    from dagster_shared.libraries import DagsterLibraryRegistry

    DagsterLibraryRegistry.register("dagster-docker-swarm", __version__)
except ImportError:
    # dagster_shared may not be available in older dagster versions
    pass
```

### `src/dagster_docker_swarm/container_context.py`

This provides hierarchical config merging so that per-code-location overrides can extend or replace instance-level config.

```python
from typing import Any, Dict, List, NamedTuple, Optional


class SwarmContainerContext(NamedTuple):
    """Hierarchical configuration context for Swarm services.

    Allows instance-level config (dagster.yaml) to be extended or overridden
    by per-code-location config. Merge rules:
      - registry: code-location replaces instance entirely
      - env_vars, networks: lists are concatenated
      - mounts: lists are concatenated
      - service_kwargs: shallow dict merge (code-location keys win)
    """

    registry: Optional[Dict[str, str]] = None
    env_vars: List[str] = []
    networks: List[str] = []
    mounts: List[Dict[str, Any]] = []
    service_kwargs: Dict[str, Any] = {}

    def merge(self, other: "SwarmContainerContext") -> "SwarmContainerContext":
        return SwarmContainerContext(
            registry=other.registry if other.registry is not None else self.registry,
            env_vars=[*self.env_vars, *other.env_vars],
            networks=[*self.networks, *other.networks],
            mounts=[*self.mounts, *other.mounts],
            service_kwargs={**self.service_kwargs, **other.service_kwargs},
        )
```

### `src/dagster_docker_swarm/run_launcher.py`

```python
import logging
from typing import Optional

import dagster._check as check
import docker
from dagster._config import Array, Field, Permissive, StringSource
from dagster._core.launcher.base import (
    CheckRunHealthResult,
    LaunchRunContext,
    ResumeRunContext,
    RunLauncher,
    WorkerStatus,
)
from dagster._core.storage.dagster_run import DagsterRun
from dagster._core.storage.tags import DOCKER_IMAGE_TAG
from dagster._core.utils import parse_env_var
from dagster._grpc.types import ExecuteRunArgs, ResumeRunArgs
from dagster._serdes import ConfigurableClass
from dagster._serdes.config_class import ConfigurableClassData
from docker.types import DriverConfig, Mount, RestartPolicy, ServiceMode
from docker_image import reference

logger = logging.getLogger("dagster_docker_swarm")

SWARM_SERVICE_ID_TAG = "swarm/service_id"

SWARM_CONFIG_SCHEMA = {
    "image": Field(StringSource, is_required=False),
    "registry": Field(
        {"url": Field(StringSource), "username": Field(StringSource), "password": Field(StringSource)},
        is_required=False,
    ),
    "env_vars": Field([str], is_required=False),
    "network": Field(StringSource, is_required=False),
    "networks": Field(Array(StringSource), is_required=False),
    "mounts": Field([Permissive()], is_required=False),
    "service_kwargs": Field(Permissive(), is_required=False),
}


class SwarmRunLauncher(RunLauncher, ConfigurableClass):
    """Launches Dagster runs as Docker Swarm services.

    Each run gets a dedicated Swarm service with replicas=1 and
    restart_policy=none, ensuring one-shot execution semantics.

    Requires the Dagster daemon to have access to the Docker socket.

    Example dagster.yaml:

        run_launcher:
          module: dagster_docker_swarm
          class: SwarmRunLauncher
          config:
            image: my-registry/my-dagster-image:latest
            networks:
              - my_dagster_network
            env_vars:
              - DAGSTER_POSTGRES_HOST
              - DAGSTER_POSTGRES_DB
            mounts:
              - target: /data
                source: my_nfs_volume
                type: volume
                driver_config:
                  Name: local
                  Options:
                    type: nfs
                    o: "addr=nfs-server,rw"
                    device: ":/exports/data"
    """

    def __init__(
        self,
        inst_data: Optional[ConfigurableClassData] = None,
        image=None,
        registry=None,
        env_vars=None,
        network=None,
        networks=None,
        mounts=None,
        service_kwargs=None,
    ):
        self._inst_data = inst_data
        self.image = image
        self.registry = registry
        self.env_vars = env_vars
        self.mounts = mounts
        self.service_kwargs = service_kwargs

        if network:
            self.networks = [network]
        elif networks:
            self.networks = networks
        else:
            self.networks = []

        super().__init__()

        logger.info(
            "SwarmRunLauncher initialized",
            extra={
                "image": self.image,
                "networks": self.networks,
                "registry_configured": self.registry is not None,
                "mount_count": len(self.mounts) if self.mounts else 0,
            },
        )

    @property
    def inst_data(self):
        return self._inst_data

    @classmethod
    def config_type(cls):
        return SWARM_CONFIG_SCHEMA

    @classmethod
    def from_config_value(cls, inst_data, config_value):
        return cls(inst_data=inst_data, **config_value)

    @property
    def supports_resume_run(self):
        return True

    @property
    def supports_check_run_worker_health(self):
        return True

    def _get_client(self):
        logger.debug("Creating Docker client from environment")
        client = docker.client.from_env()
        if self.registry:
            logger.debug("Logging in to registry %s", self.registry["url"])
            client.login(
                registry=self.registry["url"],
                username=self.registry["username"],
                password=self.registry["password"],
            )
        return client

    def _get_docker_image(self, job_code_origin):
        docker_image = job_code_origin.repository_origin.container_image
        if docker_image:
            logger.debug("Using image from code origin: %s", docker_image)
        else:
            docker_image = self.image
            if docker_image:
                logger.debug("Using image from launcher config: %s", docker_image)
        if not docker_image:
            raise Exception("No docker image specified by the instance config or repository")
        try:
            reference.Reference.parse(docker_image)
        except Exception as e:
            raise Exception(f"Docker image name {docker_image} is not correctly formatted") from e
        return docker_image

    def _get_service(self, run):
        if not run:
            return None
        service_id = run.tags.get(SWARM_SERVICE_ID_TAG)
        if not service_id:
            logger.debug("No service ID tag found for run %s", run.run_id)
            return None
        try:
            service = self._get_client().services.get(service_id)
            logger.debug("Found Swarm service %s for run %s", service_id, run.run_id)
            return service
        except docker.errors.NotFound:
            logger.warning("Swarm service %s not found for run %s", service_id, run.run_id)
            return None
        except docker.errors.APIError:
            logger.exception("Docker API error looking up service %s for run %s", service_id, run.run_id)
            return None

    def _launch_service_with_command(self, run, docker_image, command):
        service_name = f"dagster-run-{run.run_id[:8]}"
        logger.info(
            "Launching Swarm service for run %s (job: %s, image: %s, service: %s)",
            run.run_id, run.job_name, docker_image, service_name,
        )

        env_vars = self.env_vars or []
        docker_env = dict([parse_env_var(env_var) for env_var in env_vars])
        docker_env["DAGSTER_RUN_JOB_NAME"] = run.job_name
        logger.debug("Resolved %d environment variables for run %s", len(docker_env), run.run_id)

        client = self._get_client()

        labels = {"dagster/run_id": run.run_id, "dagster/job_name": run.job_name}

        mounts = []
        for m in (self.mounts or []):
            driver_config = None
            if m.get("driver_config"):
                driver_config = DriverConfig(
                    name=m["driver_config"]["Name"],
                    options=m["driver_config"].get("Options", {}),
                )
            mounts.append(Mount(
                target=m["target"],
                source=m["source"],
                type=m.get("type", "volume"),
                driver_config=driver_config,
            ))
        if mounts:
            logger.debug("Configured %d mount(s) for run %s", len(mounts), run.run_id)

        service_kwargs = dict(self.service_kwargs or {})
        if service_kwargs:
            logger.debug("Passing additional service_kwargs: %s", list(service_kwargs.keys()))

        try:
            service = client.services.create(
                image=docker_image,
                command=command,
                env=[f"{k}={v}" for k, v in docker_env.items()],
                labels=labels,
                name=service_name,
                mounts=mounts,
                networks=self.networks,
                mode=ServiceMode("replicated", replicas=1),
                restart_policy=RestartPolicy(condition="none"),
                **service_kwargs,
            )
        except docker.errors.APIError:
            logger.exception(
                "Failed to create Swarm service for run %s (image: %s)",
                run.run_id, docker_image,
            )
            raise

        logger.info(
            "Created Swarm service %s for run %s",
            service.id, run.run_id,
        )

        self._instance.report_engine_event(
            message=f"Launching run as Swarm service {service.id} with image {docker_image}",
            dagster_run=run,
            cls=self.__class__,
        )

        self._instance.add_run_tags(
            run.run_id,
            {SWARM_SERVICE_ID_TAG: service.id, DOCKER_IMAGE_TAG: docker_image},
        )

    def launch_run(self, context: LaunchRunContext) -> None:
        run = context.dagster_run
        logger.info("launch_run called for run %s (job: %s)", run.run_id, run.job_name)
        job_code_origin = check.not_none(context.job_code_origin)
        docker_image = self._get_docker_image(job_code_origin)
        command = ExecuteRunArgs(
            job_origin=job_code_origin,
            run_id=run.run_id,
            instance_ref=self._instance.get_ref(),
        ).get_command_args()
        self._launch_service_with_command(run, docker_image, command)

    def resume_run(self, context: ResumeRunContext) -> None:
        run = context.dagster_run
        logger.info("resume_run called for run %s (job: %s)", run.run_id, run.job_name)
        job_code_origin = check.not_none(context.job_code_origin)
        docker_image = self._get_docker_image(job_code_origin)
        command = ResumeRunArgs(
            job_origin=job_code_origin,
            run_id=run.run_id,
            instance_ref=self._instance.get_ref(),
        ).get_command_args()
        self._launch_service_with_command(run, docker_image, command)

    def check_run_worker_health(self, run: DagsterRun):
        service_id = run.tags.get(SWARM_SERVICE_ID_TAG)
        if not service_id:
            logger.debug("No service ID tag for run %s, returning NOT_FOUND", run.run_id)
            return CheckRunHealthResult(WorkerStatus.NOT_FOUND, msg="No Swarm service ID tag for run.")

        service = self._get_service(run)
        if service is None:
            return CheckRunHealthResult(WorkerStatus.NOT_FOUND, msg=f"Could not find Swarm service {service_id}.")

        tasks = service.tasks()
        if not tasks:
            logger.warning("No tasks found for service %s (run %s)", service_id, run.run_id)
            return CheckRunHealthResult(WorkerStatus.NOT_FOUND, msg="No tasks for Swarm service")

        latest_task = sorted(tasks, key=lambda t: t["UpdatedAt"], reverse=True)[0]
        state = latest_task["Status"]["State"]
        logger.debug(
            "Health check for run %s: service=%s, task_state=%s, task_count=%d",
            run.run_id, service_id, state, len(tasks),
        )

        if state == "running":
            return CheckRunHealthResult(WorkerStatus.RUNNING)
        elif state == "complete":
            logger.info("Run %s completed, removing service %s", run.run_id, service_id)
            try:
                service.remove()
            except Exception:
                logger.warning("Failed to remove completed service %s", service_id, exc_info=True)
            return CheckRunHealthResult(WorkerStatus.SUCCESS)
        elif state in ("failed", "rejected", "orphaned", "shutdown"):
            msg = latest_task["Status"].get("Message", f"Task state: {state}")
            logger.error(
                "Run %s failed: service=%s, state=%s, message=%s",
                run.run_id, service_id, state, msg,
            )
            try:
                service.remove()
            except Exception:
                logger.warning("Failed to remove errored service %s", service_id, exc_info=True)
            return CheckRunHealthResult(WorkerStatus.FAILED, msg=msg)

        # Task is in a transitional state (pending, assigned, preparing, etc.)
        logger.debug("Run %s in transitional state: %s", run.run_id, state)
        return CheckRunHealthResult(WorkerStatus.RUNNING)

    def terminate(self, run_id):
        run = self._instance.get_run_by_id(run_id)
        if not run or run.is_finished:
            logger.debug("Terminate called for run %s but run is already finished or not found", run_id)
            return False

        logger.info("Terminating run %s", run_id)
        self._instance.report_run_canceling(run)

        service = self._get_service(run)
        if not service:
            self._instance.report_engine_event(
                message="Unable to find Swarm service to send termination request to.",
                dagster_run=run,
                cls=self.__class__,
            )
            logger.warning("Cannot terminate run %s: Swarm service not found", run_id)
            return False

        service_id = run.tags.get(SWARM_SERVICE_ID_TAG)
        try:
            service.remove()
            logger.info("Removed Swarm service %s for terminated run %s", service_id, run_id)
        except docker.errors.APIError:
            logger.exception("Failed to remove Swarm service %s for run %s", service_id, run_id)
            raise
        return True
```

## Step 3: Tests

### `tests/__init__.py`

Empty file.

### `tests/conftest.py`

```python
from unittest.mock import MagicMock, patch

import pytest


def make_mock_run(run_id="abc12345-def6-7890-abcd-ef1234567890", job_name="my_job", tags=None, is_finished=False):
    """Create a mock DagsterRun."""
    run = MagicMock()
    run.run_id = run_id
    run.job_name = job_name
    run.tags = tags or {}
    run.is_finished = is_finished
    return run


def make_mock_job_code_origin(container_image=None):
    """Create a mock job code origin."""
    origin = MagicMock()
    origin.repository_origin.container_image = container_image
    return origin


@pytest.fixture
def mock_docker_client():
    """Patch docker.client.from_env and return the mock client."""
    with patch("docker.client.from_env") as mock_from_env:
        client = MagicMock()
        mock_from_env.return_value = client
        yield client
```

### `tests/test_run_launcher.py`

```python
from unittest.mock import MagicMock, patch

import docker.errors
import pytest

from dagster_docker_swarm.run_launcher import SwarmRunLauncher, SWARM_SERVICE_ID_TAG
from tests.conftest import make_mock_run, make_mock_job_code_origin


class TestSwarmRunLauncherInit:
    def test_defaults(self):
        launcher = SwarmRunLauncher()
        assert launcher.image is None
        assert launcher.registry is None
        assert launcher.env_vars is None
        assert launcher.networks == []
        assert launcher.mounts is None
        assert launcher.service_kwargs is None

    def test_single_network_becomes_list(self):
        launcher = SwarmRunLauncher(network="my-net")
        assert launcher.networks == ["my-net"]

    def test_networks_list(self):
        launcher = SwarmRunLauncher(networks=["net-a", "net-b"])
        assert launcher.networks == ["net-a", "net-b"]

    def test_network_takes_precedence_over_networks(self):
        launcher = SwarmRunLauncher(network="single", networks=["a", "b"])
        assert launcher.networks == ["single"]


class TestGetDockerImage:
    def test_image_from_code_origin(self):
        launcher = SwarmRunLauncher(image="fallback:latest")
        origin = make_mock_job_code_origin(container_image="origin:v1")
        assert launcher._get_docker_image(origin) == "origin:v1"

    def test_image_from_config_fallback(self):
        launcher = SwarmRunLauncher(image="config:latest")
        origin = make_mock_job_code_origin(container_image=None)
        assert launcher._get_docker_image(origin) == "config:latest"

    def test_no_image_raises(self):
        launcher = SwarmRunLauncher()
        origin = make_mock_job_code_origin(container_image=None)
        with pytest.raises(Exception, match="No docker image specified"):
            launcher._get_docker_image(origin)

    def test_invalid_image_raises(self):
        launcher = SwarmRunLauncher()
        origin = make_mock_job_code_origin(container_image="INVALID:::image")
        with pytest.raises(Exception, match="not correctly formatted"):
            launcher._get_docker_image(origin)


class TestCheckRunWorkerHealth:
    def _make_launcher(self, mock_docker_client):
        with patch("docker.client.from_env", return_value=mock_docker_client):
            return SwarmRunLauncher()

    def test_no_service_id_tag(self, mock_docker_client):
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "NOT_FOUND"

    def test_service_not_found(self, mock_docker_client):
        mock_docker_client.services.get.side_effect = docker.errors.NotFound("gone")
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "NOT_FOUND"

    def test_task_running(self, mock_docker_client):
        service = MagicMock()
        service.tasks.return_value = [
            {"Status": {"State": "running"}, "UpdatedAt": "2025-01-01T00:00:00Z"},
        ]
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "RUNNING"

    def test_task_complete_removes_service(self, mock_docker_client):
        service = MagicMock()
        service.tasks.return_value = [
            {"Status": {"State": "complete"}, "UpdatedAt": "2025-01-01T00:00:00Z"},
        ]
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "SUCCESS"
        service.remove.assert_called_once()

    def test_task_failed(self, mock_docker_client):
        service = MagicMock()
        service.tasks.return_value = [
            {"Status": {"State": "failed", "Message": "OOM killed"}, "UpdatedAt": "2025-01-01T00:00:00Z"},
        ]
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "FAILED"
        assert "OOM killed" in result.msg

    def test_transitional_state_treated_as_running(self, mock_docker_client):
        service = MagicMock()
        service.tasks.return_value = [
            {"Status": {"State": "preparing"}, "UpdatedAt": "2025-01-01T00:00:00Z"},
        ]
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "RUNNING"

    def test_picks_latest_task(self, mock_docker_client):
        service = MagicMock()
        service.tasks.return_value = [
            {"Status": {"State": "failed", "Message": "old"}, "UpdatedAt": "2025-01-01T00:00:00Z"},
            {"Status": {"State": "running"}, "UpdatedAt": "2025-01-02T00:00:00Z"},
        ]
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        result = launcher.check_run_worker_health(run)
        assert result.status.name == "RUNNING"


class TestTerminate:
    def _make_launcher_with_instance(self, mock_docker_client):
        with patch("docker.client.from_env", return_value=mock_docker_client):
            launcher = SwarmRunLauncher()
            launcher._instance = MagicMock()
            return launcher

    def test_terminate_finished_run(self, mock_docker_client):
        launcher = self._make_launcher_with_instance(mock_docker_client)
        run = make_mock_run(is_finished=True)
        launcher._instance.get_run_by_id.return_value = run
        assert launcher.terminate(run.run_id) is False

    def test_terminate_no_service(self, mock_docker_client):
        mock_docker_client.services.get.side_effect = docker.errors.NotFound("gone")
        launcher = self._make_launcher_with_instance(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        launcher._instance.get_run_by_id.return_value = run
        assert launcher.terminate(run.run_id) is False

    def test_terminate_success(self, mock_docker_client):
        service = MagicMock()
        mock_docker_client.services.get.return_value = service
        launcher = self._make_launcher_with_instance(mock_docker_client)
        run = make_mock_run(tags={SWARM_SERVICE_ID_TAG: "svc-123"})
        launcher._instance.get_run_by_id.return_value = run
        assert launcher.terminate(run.run_id) is True
        service.remove.assert_called_once()
```

### `tests/test_container_context.py`

```python
from dagster_docker_swarm.container_context import SwarmContainerContext


class TestSwarmContainerContext:
    def test_merge_env_vars_concatenated(self):
        base = SwarmContainerContext(env_vars=["A=1", "B=2"])
        override = SwarmContainerContext(env_vars=["C=3"])
        merged = base.merge(override)
        assert merged.env_vars == ["A=1", "B=2", "C=3"]

    def test_merge_networks_concatenated(self):
        base = SwarmContainerContext(networks=["net-a"])
        override = SwarmContainerContext(networks=["net-b"])
        merged = base.merge(override)
        assert merged.networks == ["net-a", "net-b"]

    def test_merge_registry_override_replaces(self):
        base = SwarmContainerContext(registry={"url": "old", "username": "u", "password": "p"})
        override = SwarmContainerContext(registry={"url": "new", "username": "u2", "password": "p2"})
        merged = base.merge(override)
        assert merged.registry["url"] == "new"

    def test_merge_registry_none_keeps_base(self):
        base = SwarmContainerContext(registry={"url": "old", "username": "u", "password": "p"})
        override = SwarmContainerContext()
        merged = base.merge(override)
        assert merged.registry["url"] == "old"

    def test_merge_service_kwargs_shallow_merge(self):
        base = SwarmContainerContext(service_kwargs={"a": 1, "b": 2})
        override = SwarmContainerContext(service_kwargs={"b": 99, "c": 3})
        merged = base.merge(override)
        assert merged.service_kwargs == {"a": 1, "b": 99, "c": 3}

    def test_merge_mounts_concatenated(self):
        base = SwarmContainerContext(mounts=[{"target": "/a", "source": "vol_a"}])
        override = SwarmContainerContext(mounts=[{"target": "/b", "source": "vol_b"}])
        merged = base.merge(override)
        assert len(merged.mounts) == 2

    def test_defaults(self):
        ctx = SwarmContainerContext()
        assert ctx.registry is None
        assert ctx.env_vars == []
        assert ctx.networks == []
        assert ctx.mounts == []
        assert ctx.service_kwargs == {}
```

## Step 4: README.md

```markdown
# dagster-docker-swarm

A [Dagster](https://dagster.io) run launcher that executes pipeline runs as
Docker Swarm services.

## Installation

pip install dagster-docker-swarm

## Configuration

Add to your `dagster.yaml`:

    run_launcher:
      module: dagster_docker_swarm
      class: SwarmRunLauncher
      config:
        image: my-registry/my-dagster-image:latest
        networks:
          - my_dagster_network
        env_vars:
          - DAGSTER_POSTGRES_HOST
          - DAGSTER_POSTGRES_DB
          - DAGSTER_CURRENT_IMAGE
        mounts:
          - target: /data
            source: shared_data
            type: volume

## Features

- Launches each Dagster run as an isolated Swarm service (replicas=1, restart=none)
- Run resume support for interrupted runs
- Health checking via Swarm task state inspection
- Automatic service cleanup on completion or failure
- Private registry authentication
- NFS and custom volume driver mounts
- Passthrough `service_kwargs` for advanced Swarm service configuration

## Requirements

- Docker Swarm mode enabled (`docker swarm init`)
- Dagster daemon must have access to the Docker socket
- `DAGSTER_CURRENT_IMAGE` env var set on the daemon/webserver if not specifying `image` in config
```

## Step 5: LICENSE

Use the standard Apache-2.0 license text.

## Verification

```bash
# In the new repo:
uv sync --all-extras
uv run pytest tests/ -v
uv run ruff check src/ tests/
uv build
```

To test the built package in your dagster deployment:
```bash
uv pip install dist/dagster_docker_swarm-0.1.0-py3-none-any.whl
```

Then configure `dagster.yaml` as shown in the README and verify a run launches as a Swarm service.
