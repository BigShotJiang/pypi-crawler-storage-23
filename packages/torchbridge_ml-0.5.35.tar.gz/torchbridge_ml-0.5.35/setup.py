"""
Build Script for TorchBridge

Package metadata is defined in pyproject.toml (PEP 621).
This file exists only for compatibility with tools that require setup.py.
"""

from setuptools import setup

setup()
