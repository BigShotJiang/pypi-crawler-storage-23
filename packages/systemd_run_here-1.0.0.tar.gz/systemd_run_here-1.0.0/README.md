# systemd-run-here
Start a systemd service, display the log output directly in the shell

This is unreviewed AI-generated code, but I have used in on my machine. Liable to change in interface.

## Installation
```
pipx install systemd-run-here
```

## Usage
`systemd-run-here --user backup.service`

## Motivation
This systemd job was failing. I want to run it and see the output now rather than go through a silly run / logs cycle.

## Alternatives and prior work
You could run `journalctl` in the backgroound following.

## About me
I am [@readwithai](https://x.com/readwithai). I make tools for reading and agency with and without Obsidian and AI. I also make a stream of small tools like this related to my work.

If you are interested in reading or note taking or Obsidian, check out my blog at [readwithai.substack.com](http://readwithai.substack.com/).

If you are interested in a stream of tools, you can [follow me on GitHub](https://github.com/talwrii) or [follow me on X](https://x.com/readwithai).

