#!/usr/bin/env python3
"""
systemd-run-here - Start a systemd service and follow its logs live in the terminal.
Exits with failure if the service fails.
"""

import argparse
import subprocess
import sys
import time

RED   = "\033[31m"
DIM   = "\033[2m"
RESET = "\033[0m"

def service_result(unit, user=False):
    """Get the Result= property of a service after it runs."""
    cmd = ["systemctl"]
    if user:
        cmd.append("--user")
    cmd += ["show", "--property=Result", unit]
    result = subprocess.run(cmd, capture_output=True, text=True)
    for line in result.stdout.splitlines():
        if line.startswith("Result="):
            return line.partition("=")[2].strip()
    return None

def wait_for_finish(unit, user=False, poll_interval=0.5):
    """Poll until the service is no longer activating/running (for oneshot/simple)."""
    while True:
        cmd = ["systemctl"]
        if user:
            cmd.append("--user")
        cmd += ["show", "--property=ActiveState", "--property=SubState", unit]
        result = subprocess.run(cmd, capture_output=True, text=True)
        props = {}
        for line in result.stdout.splitlines():
            k, _, v = line.partition("=")
            props[k] = v
        active = props.get("ActiveState", "")
        sub = props.get("SubState", "")
        if active in ("failed", "inactive") or (active == "active" and sub == "exited"):
            break
        time.sleep(poll_interval)

def main():
    parser = argparse.ArgumentParser(
        prog="systemd-run-here",
        description="Start a systemd service and follow its logs live in the terminal.",
    )
    parser.add_argument("unit", help="Service unit name (e.g. backup-home.service)")
    parser.add_argument("--user", action="store_true", help="Use --user systemd instance")
    args = parser.parse_args()

    unit = args.unit
    if not unit.endswith(".service"):
        unit += ".service"

    # Build base systemctl/journalctl commands
    ctl = ["systemctl", "--user"] if args.user else ["systemctl"]
    jctl = ["journalctl", "--user"] if args.user else ["journalctl"]

    # Start following logs before starting the service so we catch everything
    journal = subprocess.Popen(
        jctl + ["-u", unit, "-f", "-n", "0"],
    )

    # Small delay to ensure journalctl is ready
    time.sleep(0.3)

    print(f"{DIM}▶ starting {unit}{RESET}", file=sys.stderr)

    try:
        subprocess.run(ctl + ["start", unit], check=True)
    except subprocess.CalledProcessError:
        print(f"{RED}✗ systemctl start failed{RESET}", file=sys.stderr)
        journal.terminate()
        sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n{DIM}Interrupted{RESET}", file=sys.stderr)
        journal.terminate()
        sys.exit(130)

    # Wait for service to finish
    try:
        wait_for_finish(unit, user=args.user)
    except KeyboardInterrupt:
        print(f"\n{DIM}Interrupted{RESET}", file=sys.stderr)
        journal.terminate()
        sys.exit(130)

    # Give journalctl a moment to flush remaining output
    time.sleep(0.5)
    journal.terminate()

    # Check result
    result = service_result(unit, user=args.user)
    if result and result != "success":
        print(f"{RED}✗ service exited with result: {result}{RESET}", file=sys.stderr)
        sys.exit(1)

# ---
# I am @readwithai. I make tools for reading and agency with and without obsidian and AI.
# I also make a stream of small tools like this related to my work.
#
# If you are interested in reading or note taking or Obsidian, check out my blog at
# http://readwithai.substack.com/
#
# If you are interested in a stream of tools, you can follow me on GitHub:
# https://github.com/talwrii
# or follow me on X: https://x.com/readwithai

if __name__ == "__main__":
    main()