Utilities
*********

This section shows general objects and helper functions that are used with this package.


.. note::
    This BalderHub project doesn't have any utilities.


Optical Heart Beat Simulation
=============================

.. autoclass:: balderhub.heart.lib.utils.optical_simulation.TkinterOpticalHeartBeatSimulation
    :members:

.. autoclass:: balderhub.heart.lib.utils.optical_simulation.Command
    :members:

.. autoclass:: balderhub.heart.lib.utils.optical_simulation.ColorConfiguration
    :members:
