Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================

.. note::
    This package does not provide any scenario features

.. autoclass:: balderhub.heart.lib.scenario_features.HeartBeatFeature
    :members:

.. autoclass:: balderhub.heart.lib.scenario_features.StrapDockingFeature
    :members:

Setup Features
==============

.. note::
    This package does not provide any setup features.

.. autoclass:: balderhub.heart.lib.setup_features.OpticalHeartBeatFeature
    :members:
