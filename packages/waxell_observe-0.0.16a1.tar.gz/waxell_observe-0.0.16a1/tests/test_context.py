"""Unit tests for WaxellContext lifecycle (async and sync)."""

import json
import threading

import pytest
import httpx
import respx

from waxell_observe.client import WaxellObserveClient
from waxell_observe.context import WaxellContext
from waxell_observe.errors import PolicyViolationError
from waxell_observe.instrumentors._context_var import _current_context


BASE_URL = "http://test.waxell.dev"


@pytest.fixture
def client():
    """Pre-configured test client."""
    return WaxellObserveClient(api_url=BASE_URL, api_key="wax_sk_test123")


@pytest.fixture
def mock_lifecycle():
    """Mock all observe lifecycle endpoints for full context test."""
    with respx.mock:
        respx.post(f"{BASE_URL}/api/v1/observe/policy-check/").mock(
            return_value=httpx.Response(200, json={"action": "allow", "reason": ""})
        )
        respx.post(f"{BASE_URL}/api/v1/observe/runs/start/").mock(
            return_value=httpx.Response(
                201,
                json={
                    "run_id": "run-ctx-1",
                    "workflow_id": "wf-1",
                    "started_at": "2026-01-01T00:00:00Z",
                },
            )
        )
        respx.post(url__regex=r".*/runs/.*/llm-calls/$").mock(
            return_value=httpx.Response(
                202, json={"recorded": 1, "governance": {"action": "allow"}}
            )
        )
        respx.post(url__regex=r".*/runs/.*/steps/$").mock(
            return_value=httpx.Response(
                202, json={"recorded": 1, "governance": {"action": "allow"}}
            )
        )
        respx.post(url__regex=r".*/runs/.*/scores/$").mock(
            return_value=httpx.Response(202, json={"recorded": 1})
        )
        respx.post(url__regex=r".*/runs/.*/spans/$").mock(
            return_value=httpx.Response(202, json={"recorded": 1})
        )
        respx.post(url__regex=r".*/runs/.*/complete/$").mock(
            return_value=httpx.Response(
                200, json={"run_id": "run-ctx-1", "duration": 1.5}
            )
        )
        yield


class TestContextLifecycle:
    @pytest.mark.asyncio
    async def test_context_lifecycle(self, client, mock_lifecycle):
        """Full lifecycle: enter, record LLM call, record step, set result, exit."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=True,
        ) as ctx:
            ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
            ctx.record_step("retrieve", {"data": "value"})
            ctx.set_result({"answer": "42"})

        assert ctx.run_id == "run-ctx-1"

    @pytest.mark.asyncio
    async def test_context_no_policy_check(self, client, mock_lifecycle):
        """enforce_policy=False skips the policy-check endpoint."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.set_result({"ok": True})

        # The policy-check route should NOT have been called
        policy_calls = [
            call for call in respx.calls if "/policy-check/" in str(call.request.url)
        ]
        assert len(policy_calls) == 0

    @pytest.mark.asyncio
    async def test_context_policy_blocked(self, client):
        """Policy block raises PolicyViolationError on enter."""
        with respx.mock:
            respx.post(f"{BASE_URL}/api/v1/observe/policy-check/").mock(
                return_value=httpx.Response(
                    200, json={"action": "block", "reason": "Budget exceeded"}
                )
            )

            with pytest.raises(PolicyViolationError, match="Budget exceeded"):
                async with WaxellContext(
                    agent_name="test-agent",
                    client=client,
                    enforce_policy=True,
                ) as ctx:
                    pass  # Should not reach here

    @pytest.mark.asyncio
    async def test_context_records_llm_calls(self, client, mock_lifecycle):
        """LLM calls are buffered and flushed on exit."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
            ctx.record_llm_call(model="gpt-4o", tokens_in=200, tokens_out=100)

        # Verify llm-calls endpoint was called
        llm_calls = [
            call for call in respx.calls if "/llm-calls/" in str(call.request.url)
        ]
        assert len(llm_calls) == 1  # Single batch call

    @pytest.mark.asyncio
    async def test_context_records_steps(self, client, mock_lifecycle):
        """Steps are buffered and flushed on exit."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.record_step("step1", {"data": "value"})

        # Verify steps endpoint was called
        step_calls = [
            call for call in respx.calls if "/steps/" in str(call.request.url)
        ]
        assert len(step_calls) == 1

    @pytest.mark.asyncio
    async def test_context_set_result(self, client, mock_lifecycle):
        """set_result includes result in complete_run."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.set_result({"answer": "42"})

        # Verify complete endpoint was called
        complete_calls = [
            call for call in respx.calls if "/complete/" in str(call.request.url)
        ]
        assert len(complete_calls) == 1

    @pytest.mark.asyncio
    @pytest.mark.xfail(reason="session_id not yet included in metadata payload")
    async def test_context_session_id(self, client, mock_lifecycle):
        """session_id is included in start_run metadata."""
        async with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
            session_id="sess_abc123",
        ) as ctx:
            pass

        # Find the start_run call and check metadata
        start_calls = [
            call for call in respx.calls if "/runs/start/" in str(call.request.url)
        ]
        assert len(start_calls) == 1
        import json

        body = json.loads(start_calls[0].request.content)
        assert body["metadata"]["session_id"] == "sess_abc123"

    @pytest.mark.asyncio
    async def test_context_exception_handling(self, client, mock_lifecycle):
        """Exception during execution still completes the run with error status."""
        with pytest.raises(ValueError, match="test error"):
            async with WaxellContext(
                agent_name="test-agent",
                client=client,
                enforce_policy=False,
            ) as ctx:
                raise ValueError("test error")

        # Verify complete endpoint was called with error status
        complete_calls = [
            call for call in respx.calls if "/complete/" in str(call.request.url)
        ]
        assert len(complete_calls) == 1

        body = json.loads(complete_calls[0].request.content)
        assert body["status"] == "error"
        assert "test error" in body["error"]


# ===================================================================
# Sync context manager tests
# ===================================================================


class TestSyncContextLifecycle:
    """Mirror of TestContextLifecycle using sync ``with`` statement."""

    def test_sync_context_lifecycle(self, client, mock_lifecycle):
        """Full lifecycle: enter, record LLM call, record step, set result, exit."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=True,
        ) as ctx:
            ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
            ctx.record_step("retrieve", {"data": "value"})
            ctx.set_result({"answer": "42"})

        assert ctx.run_id == "run-ctx-1"

        # Verify HTTP calls
        start_calls = [c for c in respx.calls if "/runs/start/" in str(c.request.url)]
        complete_calls = [c for c in respx.calls if "/complete/" in str(c.request.url)]
        assert len(start_calls) == 1
        assert len(complete_calls) == 1

    def test_sync_context_no_policy_check(self, client, mock_lifecycle):
        """enforce_policy=False skips the policy-check endpoint."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.set_result({"ok": True})

        policy_calls = [
            call for call in respx.calls if "/policy-check/" in str(call.request.url)
        ]
        assert len(policy_calls) == 0

    def test_sync_context_policy_blocked(self, client):
        """Policy block raises PolicyViolationError on enter."""
        with respx.mock:
            respx.post(f"{BASE_URL}/api/v1/observe/policy-check/").mock(
                return_value=httpx.Response(
                    200, json={"action": "block", "reason": "Budget exceeded"}
                )
            )
            respx.post(f"{BASE_URL}/api/v1/observe/runs/start/").mock(
                return_value=httpx.Response(
                    201,
                    json={
                        "run_id": "run-blocked",
                        "workflow_id": "wf-b",
                        "started_at": "2026-01-01T00:00:00Z",
                    },
                )
            )
            respx.post(url__regex=r".*/runs/.*/complete/$").mock(
                return_value=httpx.Response(200, json={"run_id": "run-blocked"})
            )

            with pytest.raises(PolicyViolationError, match="Budget exceeded"):
                with WaxellContext(
                    agent_name="test-agent",
                    client=client,
                    enforce_policy=True,
                ) as ctx:
                    pass  # Should not reach here

    def test_sync_context_records_llm_calls(self, client, mock_lifecycle):
        """LLM calls are buffered and flushed on exit."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
            ctx.record_llm_call(model="gpt-4o", tokens_in=200, tokens_out=100)

        llm_calls = [
            call for call in respx.calls if "/llm-calls/" in str(call.request.url)
        ]
        assert len(llm_calls) == 1  # Single batch call

    def test_sync_context_records_steps(self, client, mock_lifecycle):
        """Steps are buffered and flushed on exit."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.record_step("step1", {"data": "value"})

        step_calls = [
            call for call in respx.calls if "/steps/" in str(call.request.url)
        ]
        assert len(step_calls) == 1

    def test_sync_context_set_result(self, client, mock_lifecycle):
        """set_result includes result in complete_run."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.set_result({"answer": "42"})

        complete_calls = [
            call for call in respx.calls if "/complete/" in str(call.request.url)
        ]
        assert len(complete_calls) == 1

    def test_sync_context_exception_handling(self, client, mock_lifecycle):
        """Exception during execution still completes the run with error status."""
        with pytest.raises(ValueError, match="test error"):
            with WaxellContext(
                agent_name="test-agent",
                client=client,
                enforce_policy=False,
            ) as ctx:
                raise ValueError("test error")

        complete_calls = [
            call for call in respx.calls if "/complete/" in str(call.request.url)
        ]
        assert len(complete_calls) == 1

        body = json.loads(complete_calls[0].request.content)
        assert body["status"] == "error"
        assert "test error" in body["error"]

    def test_sync_contextvar_set_in_calling_thread(self, client, mock_lifecycle):
        """CRITICAL: ContextVar must be set in the calling thread, not a worker."""
        captured_thread = None
        captured_ctx = None

        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            captured_thread = threading.current_thread()
            captured_ctx = _current_context.get()

        # The context must be the WaxellContext instance
        assert captured_ctx is ctx
        # Must be on the calling thread
        assert captured_thread == threading.current_thread()
        # After exit, context should be cleared
        assert _current_context.get() is None

    def test_sync_context_scores_and_spans(self, client, mock_lifecycle):
        """Scores and behavior spans are flushed on exit."""
        with WaxellContext(
            agent_name="test-agent",
            client=client,
            enforce_policy=False,
        ) as ctx:
            ctx.record_score("accuracy", 0.95)
            ctx.record_tool_call(
                name="search",
                input={"q": "test"},
                output={"results": []},
            )

        score_calls = [c for c in respx.calls if "/scores/" in str(c.request.url)]
        span_calls = [c for c in respx.calls if "/spans/" in str(c.request.url)]
        assert len(score_calls) == 1
        assert len(span_calls) == 1
