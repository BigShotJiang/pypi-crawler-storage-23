"""Unit tests for WaxellObserveClient and waxell_observe.types."""

import pytest

import waxell_observe.client as client_module
from waxell_observe.client import WaxellObserveClient
from waxell_observe.types import PolicyCheckResult, PromptInfo, RunInfo


# ---------------------------------------------------------------------------
# Fixture: reset global config between tests
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_global_config():
    """Reset global config after each test to prevent state leakage."""
    old = client_module._global_config
    yield
    client_module._global_config = old


# ---------------------------------------------------------------------------
# Client initialization
# ---------------------------------------------------------------------------


class TestClientInit:
    def test_init_with_explicit_args(self):
        """Client initialized with explicit api_url and api_key uses those values."""
        client = WaxellObserveClient(api_url="http://test:8001", api_key="test-key")

        assert client.config.api_url == "http://test:8001"
        assert client.config.api_key == "test-key"

    def test_configure_sets_global_config(self):
        """configure() class method sets global config for all future instances."""
        WaxellObserveClient.configure(
            api_url="http://configured:9000", api_key="configured-key"
        )

        config = WaxellObserveClient.get_config()
        assert config is not None
        assert config.api_url == "http://configured:9000"
        assert config.api_key == "configured-key"

    def test_is_configured_after_configure(self):
        """is_configured() returns True after configure() with valid values."""
        WaxellObserveClient.configure(
            api_url="http://configured:9000", api_key="configured-key"
        )

        assert WaxellObserveClient.is_configured() is True

    def test_is_configured_false_before_configure(self):
        """is_configured() returns False when no global config is set."""
        client_module._global_config = None

        assert WaxellObserveClient.is_configured() is False

    def test_get_config_returns_correct_values(self):
        """get_config() returns ObserveConfig with the values passed to configure()."""
        WaxellObserveClient.configure(
            api_url="http://myhost:8080", api_key="my-secret-key"
        )

        config = WaxellObserveClient.get_config()
        assert config.api_url == "http://myhost:8080"
        assert config.api_key == "my-secret-key"
        assert config.is_configured is True


# ---------------------------------------------------------------------------
# Types: RunInfo
# ---------------------------------------------------------------------------


class TestRunInfo:
    def test_basic_construction(self):
        """RunInfo can be constructed with run_id, workflow_id, started_at."""
        info = RunInfo(
            run_id="run-abc",
            workflow_id="wf-123",
            started_at="2026-02-13T12:00:00Z",
        )

        assert info.run_id == "run-abc"
        assert info.workflow_id == "wf-123"
        assert info.started_at == "2026-02-13T12:00:00Z"


# ---------------------------------------------------------------------------
# Types: PolicyCheckResult
# ---------------------------------------------------------------------------


class TestPolicyCheckResult:
    def test_allow_action(self):
        """PolicyCheckResult with action='allow' has allowed=True, blocked=False."""
        result = PolicyCheckResult(action="allow")

        assert result.allowed is True
        assert result.blocked is False
        assert result.should_retry is False

    def test_block_action(self):
        """PolicyCheckResult with action='block' has blocked=True, allowed=False."""
        result = PolicyCheckResult(action="block")

        assert result.blocked is True
        assert result.allowed is False
        assert result.should_retry is False

    def test_warn_action(self):
        """PolicyCheckResult with action='warn' is considered allowed."""
        result = PolicyCheckResult(action="warn")

        assert result.allowed is True
        assert result.blocked is False

    def test_throttle_action(self):
        """PolicyCheckResult with action='throttle' is considered blocked."""
        result = PolicyCheckResult(action="throttle")

        assert result.blocked is True
        assert result.allowed is False

    def test_retry_action(self):
        """PolicyCheckResult with action='retry' has should_retry=True."""
        result = PolicyCheckResult(action="retry")

        assert result.should_retry is True
        assert result.allowed is False
        assert result.blocked is False

    def test_default_fields(self):
        """PolicyCheckResult defaults: empty reason, empty metadata, empty evaluations."""
        result = PolicyCheckResult(action="allow")

        assert result.reason == ""
        assert result.metadata == {}
        assert result.evaluations == []


# ---------------------------------------------------------------------------
# Types: PromptInfo
# ---------------------------------------------------------------------------


class TestPromptInfo:
    def test_compile_text_template(self):
        """compile() replaces {{variable}} placeholders in text content."""
        prompt = PromptInfo(
            name="greeting",
            version=1,
            prompt_type="text",
            content="Hello, {{name}}! Welcome to {{place}}.",
        )

        rendered = prompt.compile(name="Alice", place="Wonderland")

        assert rendered == "Hello, Alice! Welcome to Wonderland."

    def test_compile_chat_template(self):
        """compile() replaces {{variable}} in chat message content fields."""
        prompt = PromptInfo(
            name="chat-greeting",
            version=1,
            prompt_type="chat",
            content=[
                {"role": "system", "content": "You are a {{role}}."},
                {"role": "user", "content": "Help me with {{task}}."},
            ],
        )

        rendered = prompt.compile(role="assistant", task="coding")

        assert isinstance(rendered, list)
        assert len(rendered) == 2
        assert rendered[0]["content"] == "You are a assistant."
        assert rendered[1]["content"] == "Help me with coding."

    def test_compile_no_variables(self):
        """compile() with no variables returns content unchanged."""
        prompt = PromptInfo(
            name="static",
            version=1,
            prompt_type="text",
            content="No placeholders here.",
        )

        rendered = prompt.compile()

        assert rendered == "No placeholders here."

    def test_compile_missing_variable_left_intact(self):
        """compile() leaves unreplaced {{placeholders}} in place."""
        prompt = PromptInfo(
            name="partial",
            version=1,
            prompt_type="text",
            content="Hello, {{name}}! Your id is {{id}}.",
        )

        rendered = prompt.compile(name="Bob")

        assert rendered == "Hello, Bob! Your id is {{id}}."

    def test_default_fields(self):
        """PromptInfo defaults: empty config dict and empty labels list."""
        prompt = PromptInfo(
            name="test",
            version=1,
            prompt_type="text",
            content="hello",
        )

        assert prompt.config == {}
        assert prompt.labels == []
