"""One-line initialization for waxell-observe.

Usage::

    import waxell_observe
    waxell_observe.init(api_key="wax_sk_...")

This single call:
  1. Checks the WAXELL_OBSERVE kill switch
  2. Configures the HTTP client
  3. Initializes OTel tracing (if installed)
  4. Auto-instruments installed AI/ML libraries (OpenAI, Anthropic, etc.)
  5. Auto-instruments installed infrastructure libraries (Redis, PostgreSQL, HTTP, etc.)
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

_initialized: bool = False


def init(
    api_key: str = "",
    api_url: str = "",
    capture_content: bool = False,
    instrument: list[str] | None = None,
    instrument_infra: bool = True,
    infra_libraries: list[str] | None = None,
    infra_exclude: list[str] | None = None,
    resource_attributes: dict | None = None,
    debug: bool = False,
    prompt_guard: bool = False,
    prompt_guard_server: bool = False,
    prompt_guard_action: str = "block",
) -> None:
    """Initialize waxell-observe in a single call.

    Args:
        api_key: Waxell API key (``wax_sk_...``). Falls back to
            ``WAXELL_API_KEY`` env var.
        api_url: Waxell API URL. Falls back to ``WAXELL_API_URL`` env var.
        capture_content: Include prompt/response content in traces.
        instrument: Explicit list of AI/ML libraries to auto-instrument
            (e.g. ``["openai", "anthropic"]``). ``None`` means auto-detect
            all installed libraries.
        instrument_infra: Enable auto-instrumentation of infrastructure
            libraries (HTTP clients, databases, caches, queues). Falls back
            to ``WAXELL_INSTRUMENT_INFRA`` env var. Default ``True``.
        infra_libraries: Only instrument these specific infra libraries
            (e.g. ``["redis", "httpx"]``). ``None`` means auto-detect all.
        infra_exclude: Instrument all infra libraries except these
            (e.g. ``["celery", "grpc"]``). Falls back to
            ``WAXELL_INFRA_EXCLUDE`` env var (comma-delimited).
        resource_attributes: Custom OTel resource attributes applied to all
            spans (e.g. ``{"deployment.environment": "production"}``).
        debug: Enable debug logging and console span export.
        prompt_guard: Enable client-side prompt guard (regex PII/credential/injection
            detection). Falls back to ``WAXELL_PROMPT_GUARD`` env var.
        prompt_guard_server: Also check server-side guard service (ML-powered
            detection via Presidio + HuggingFace). Falls back to
            ``WAXELL_PROMPT_GUARD_SERVER`` env var.
        prompt_guard_action: Action when violations are found: ``"block"`` (raise
            error), ``"warn"`` (log and continue), ``"redact"`` (replace with
            ``##TYPE##`` and continue). Falls back to
            ``WAXELL_PROMPT_GUARD_ACTION`` env var.
    """
    global _initialized

    # ---- Kill switch (checked first) ----
    kill = os.environ.get("WAXELL_OBSERVE", "").lower()
    if kill in ("false", "0", "no"):
        logger.debug("WAXELL_OBSERVE disabled -- skipping init")
        return

    # ---- Idempotency guard ----
    if _initialized:
        logger.debug("waxell_observe.init() already called -- skipping")
        return

    # ---- Configure HTTP client ----
    if api_key:
        from waxell_observe.client import WaxellObserveClient

        WaxellObserveClient.configure(
            api_url=api_url or os.environ.get("WAXELL_API_URL", ""),
            api_key=api_key,
        )

    # ---- Initialize OTel tracing ----
    try:
        from waxell_observe.tracing import init_tracing

        init_tracing(
            api_key=api_key or None,
            api_url=api_url or None,
            debug=debug,
            capture_content=capture_content,
            resource_attributes=resource_attributes,
        )
    except Exception as exc:
        logger.warning(
            "OTel tracing initialization failed (HTTP path still active): %s",
            exc,
        )

    # ---- Auto-instrument installed libraries ----
    try:
        from waxell_observe.instrumentors import instrument_all

        results = instrument_all(libraries=instrument)
        logger.debug("Auto-instrumentation results: %s", results)
    except Exception as exc:
        logger.warning(
            "Auto-instrumentation failed (manual tracing still works): %s",
            exc,
        )

    # ---- Auto-instrument infrastructure libraries (Redis, HTTP, DB, etc.) ----
    _infra_enabled = instrument_infra and os.environ.get(
        "WAXELL_INSTRUMENT_INFRA", ""
    ).lower() not in ("false", "0", "no")

    if _infra_enabled:
        # Support env var exclude list: WAXELL_INFRA_EXCLUDE=celery,grpc
        _env_exclude = os.environ.get("WAXELL_INFRA_EXCLUDE", "")
        _exclude = infra_exclude or (
            [x.strip() for x in _env_exclude.split(",") if x.strip()] or None
        )
        try:
            from waxell_observe.instrumentors._infra import (
                instrument_infra as _do_infra,
            )

            infra_results = _do_infra(libraries=infra_libraries, exclude=_exclude)
            logger.debug("Infrastructure instrumentation results: %s", infra_results)
        except Exception as exc:
            logger.warning(
                "Infrastructure instrumentation failed (agent tracing still works): %s",
                exc,
            )

    # ---- Configure prompt guard ----
    guard_enabled = prompt_guard or os.environ.get(
        "WAXELL_PROMPT_GUARD", ""
    ).lower() in ("true", "1", "yes")
    guard_server = prompt_guard_server or os.environ.get(
        "WAXELL_PROMPT_GUARD_SERVER", ""
    ).lower() in ("true", "1", "yes")
    guard_action = (
        prompt_guard_action
        if prompt_guard_action != "block"
        else (os.environ.get("WAXELL_PROMPT_GUARD_ACTION", "block").lower())
    )

    if guard_enabled:
        try:
            from waxell_observe.instrumentors._guard import configure as configure_guard

            configure_guard(
                enabled=True,
                server=guard_server,
                action=guard_action,
            )
            logger.debug(
                "Prompt guard enabled: server=%s action=%s",
                guard_server,
                guard_action,
            )
        except Exception as exc:
            logger.warning("Prompt guard configuration failed: %s", exc)

    _initialized = True

    # Log a single INFO line so users know what's instrumented
    try:
        from waxell_observe.__about__ import __version__
        from waxell_observe.instrumentors import _REGISTRY, _registry_loaded

        active = []
        if _registry_loaded:
            active = [n for n, inst in _REGISTRY.items() if inst.is_instrumented()]
        active_str = ", ".join(sorted(active)) if active else "none"
        logger.info(
            "waxell-observe: initialized (v%s) — %d instrumentors active [%s]",
            __version__,
            len(active),
            active_str,
        )
    except Exception:
        logger.debug("waxell_observe initialized")


def shutdown() -> None:
    """Shut down waxell-observe: flush traces and remove instrumentation."""
    global _initialized

    # Flush and stop the background collector
    try:
        from waxell_observe.instrumentors._collector import _collector

        _collector.shutdown()
    except Exception as exc:
        logger.debug("Error during background collector shutdown: %s", exc)

    # Shut down tracing
    try:
        from waxell_observe.tracing import shutdown_tracing

        shutdown_tracing()
    except Exception as exc:
        logger.debug("Error during tracing shutdown: %s", exc)

    # Remove infrastructure instrumentation
    try:
        from waxell_observe.instrumentors._infra import uninstrument_infra

        uninstrument_infra()
    except Exception as exc:
        logger.debug("Error during infra uninstrumentation: %s", exc)

    # Remove AI/ML library instrumentation
    try:
        from waxell_observe.instrumentors import uninstrument_all

        uninstrument_all()
    except Exception as exc:
        logger.debug("Error during uninstrumentation: %s", exc)

    _initialized = False
    logger.debug("waxell_observe shut down")
