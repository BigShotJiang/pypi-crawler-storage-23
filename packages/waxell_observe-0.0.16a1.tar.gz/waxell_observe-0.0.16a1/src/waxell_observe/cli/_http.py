"""Shared HTTP helper for wax CLI API calls."""
from typing import Optional

import click
import httpx

from ._config import WaxConfig, get_config_from_context


def api_get(ctx: click.Context, path: str, params: Optional[dict] = None) -> dict:
    """Make authenticated GET to observe query API.

    Args:
        ctx: Click context with config
        path: API path (e.g., '/v1/observe/query/runs/')
        params: Optional query parameters

    Returns:
        Parsed JSON response

    Raises:
        click.ClickException on auth/connection errors
    """
    config = get_config_from_context(ctx)
    return _request("GET", config, path, params=params)


def api_post(ctx: click.Context, path: str, json: Optional[dict] = None) -> dict:
    """Make authenticated POST."""
    config = get_config_from_context(ctx)
    return _request("POST", config, path, json=json)


def api_delete(ctx: click.Context, path: str) -> dict:
    """Make authenticated DELETE."""
    config = get_config_from_context(ctx)
    return _request("DELETE", config, path)


def api_patch(ctx: click.Context, path: str, json: Optional[dict] = None) -> dict:
    """Make authenticated PATCH."""
    config = get_config_from_context(ctx)
    return _request("PATCH", config, path, json=json)


def _request(
    method: str,
    config: WaxConfig,
    path: str,
    params: Optional[dict] = None,
    json: Optional[dict] = None,
) -> dict:
    """Make an authenticated HTTP request."""
    url = f"{config.api_url}/api{path}"
    headers = {"Authorization": f"Bearer {config.api_key}"}

    is_local = config.api_url.startswith("http://localhost") or config.api_url.startswith("http://127.0.0.1")

    try:
        with httpx.Client(timeout=30.0, verify=not is_local) as client:
            response = client.request(
                method,
                url,
                params=params,
                json=json,
                headers=headers,
            )

            if response.status_code == 401:
                raise click.ClickException(
                    "Authentication failed. Run 'wax login' to re-authenticate."
                )
            if response.status_code == 403:
                raise click.ClickException(
                    "Permission denied. Your API key may not have access to this resource."
                )

            response.raise_for_status()
            if response.status_code == 204:
                return {}
            return response.json()

    except httpx.ConnectError:
        raise click.ClickException(
            f"Could not connect to {config.api_url}. "
            f"{'Is your local server running?' if is_local else 'Check your internet connection.'}"
        )
    except httpx.HTTPStatusError as e:
        raise click.ClickException(
            f"API error {e.response.status_code}: {e.response.text[:200]}"
        )
    except httpx.RequestError as e:
        raise click.ClickException(f"Connection error: {e}")
