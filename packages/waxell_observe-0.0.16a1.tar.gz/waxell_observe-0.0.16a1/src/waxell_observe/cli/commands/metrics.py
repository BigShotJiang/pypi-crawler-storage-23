"""Metrics dashboard commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    fmt_tokens,
    fmt_duration,
    pct_color,
    trend_arrow,
)
from rich.table import Table
from rich.panel import Panel


@click.group()
def metrics():
    """Metrics dashboard and analytics."""
    pass


@metrics.command("overview")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def metrics_overview(ctx, hours: int, output_format: str):
    """Show key metrics overview dashboard."""
    data = api_get(ctx, "/v1/observe/query/dashboard/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    print_header("Metrics Dashboard", f"Last {hours}h")

    total_runs = data.get("total_runs", data.get("total_executions", 0))
    error_rate = data.get("error_rate", 0)
    error_pct = error_rate * 100 if error_rate < 1 else error_rate
    total_cost = data.get("total_cost", 0)
    avg_cost = data.get("avg_cost_per_run", data.get("avg_cost", 0))
    total_tokens_val = data.get("total_tokens", 0)
    active_users = data.get("active_users", 0)
    avg_duration_val = data.get("avg_duration", 0)

    # Trends (if available)
    runs_trend = data.get("runs_trend")
    cost_trend = data.get("cost_trend")
    error_trend = data.get("error_trend")

    err_color = pct_color(error_pct, warn=5, danger=15)

    kpi_text = (
        f"[bold]Executions:[/bold]  {fmt_number(total_runs)} {trend_arrow(runs_trend)}\n"
        f"[bold]Error Rate:[/bold]  [{err_color}]{error_pct:.1f}%[/{err_color}] {trend_arrow(error_trend)}\n"
        f"[bold]Total Cost:[/bold]  {fmt_cost(total_cost)} {trend_arrow(cost_trend)}\n"
        f"[bold]Avg Cost/Run:[/bold] {fmt_cost(avg_cost)}\n"
        f"[bold]Total Tokens:[/bold] {fmt_tokens(total_tokens_val)}\n"
        f"[bold]Avg Duration:[/bold] {fmt_duration(avg_duration_val)}\n"
        f"[bold]Active Users:[/bold] {fmt_number(active_users)}"
    )
    console.print(Panel(kpi_text, title="Key Metrics", border_style="cyan"))
    console.print()

    # Top agents sub-table
    top_agents = data.get("top_agents", [])
    if top_agents:
        agent_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        agent_table.add_column("Agent", style="bold")
        agent_table.add_column("Runs", justify="right")
        agent_table.add_column("Error Rate", justify="right")
        agent_table.add_column("Cost", justify="right")
        agent_table.add_column("Avg Duration", justify="right")

        for agent in top_agents:
            a_err = agent.get("error_rate", 0)
            a_err_pct = a_err * 100 if a_err < 1 else a_err
            a_err_color = pct_color(a_err_pct, warn=5, danger=15)

            agent_table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(agent.get("runs", agent.get("executions", 0))),
                f"[{a_err_color}]{a_err_pct:.1f}%[/{a_err_color}]",
                fmt_cost(agent.get("cost", 0)),
                fmt_duration(agent.get("avg_duration", 0)),
            )

        console.print(agent_table)
        console.print()


@metrics.command("costs")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def metrics_costs(ctx, hours: int, output_format: str):
    """Show cost breakdown by model."""
    data = api_get(ctx, "/v1/observe/query/costs/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    models = data.get("models", data.get("model_costs", data.get("by_model", [])))
    if not models:
        print_warning("No cost data found for the selected period.")
        return

    total_cost = data.get("total_cost", sum(m.get("cost", m.get("total_cost", 0)) for m in models))

    print_header("Cost Breakdown by Model", f"Last {hours}h | Total: {fmt_cost(total_cost)}")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Calls", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Share", justify="right")
    table.add_column("Tokens", justify="right")

    for model in models:
        cost = model.get("cost", model.get("total_cost", 0))
        pct = (cost / total_cost * 100) if total_cost > 0 else 0

        table.add_row(
            model.get("model", model.get("model_name", "unknown")),
            fmt_number(model.get("calls", model.get("call_count", 0))),
            fmt_cost(cost),
            f"{pct:.1f}%",
            fmt_tokens(model.get("tokens", model.get("total_tokens", 0))),
        )

    console.print(table)
    console.print()


@metrics.command("by-agent")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def metrics_by_agent(ctx, hours: int, output_format: str):
    """Show per-agent metric breakdown."""
    data = api_get(ctx, "/v1/observe/query/runs/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    runs_data = data.get("runs", [])
    if not runs_data:
        print_warning("No run data found for the selected period.")
        return

    # Aggregate by agent
    agent_metrics: dict = {}
    for run in runs_data:
        agent_name = run.get("agent_name", run.get("agent", "unknown"))
        if agent_name not in agent_metrics:
            agent_metrics[agent_name] = {
                "runs": 0,
                "errors": 0,
                "cost": 0.0,
                "tokens": 0,
                "total_duration": 0.0,
            }

        metrics_entry = agent_metrics[agent_name]
        metrics_entry["runs"] += 1
        if run.get("status") in ("failed", "error"):
            metrics_entry["errors"] += 1
        metrics_entry["cost"] += run.get("cost", 0)
        metrics_entry["tokens"] += run.get("total_tokens", 0)
        metrics_entry["total_duration"] += run.get(
            "duration", run.get("duration_seconds", 0)
        )

    print_header("Metrics by Agent", f"Last {hours}h | {len(agent_metrics)} agents")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Agent", style="bold")
    table.add_column("Runs", justify="right")
    table.add_column("Error Rate", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("Avg Duration", justify="right")

    # Sort by runs descending
    sorted_agents = sorted(
        agent_metrics.items(), key=lambda x: x[1]["runs"], reverse=True
    )

    for name, m in sorted_agents:
        err_pct = (m["errors"] / m["runs"] * 100) if m["runs"] > 0 else 0
        avg_dur = m["total_duration"] / m["runs"] if m["runs"] > 0 else 0
        err_color = pct_color(err_pct, warn=5, danger=15)

        table.add_row(
            name,
            fmt_number(m["runs"]),
            f"[{err_color}]{err_pct:.1f}%[/{err_color}]",
            fmt_cost(m["cost"]),
            fmt_tokens(m["tokens"]),
            fmt_duration(avg_dur),
        )

    console.print(table)
    console.print()
