"""Cost analytics commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    fmt_tokens,
)
from rich.table import Table
from rich.panel import Panel


@click.group()
def costs():
    """Cost analytics and budget tracking."""
    pass


@costs.command("summary")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def costs_summary(ctx, hours: int, output_format: str):
    """Show cost summary with model and agent breakdown."""
    data = api_get(ctx, "/v1/observe/query/costs/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    total_cost = data.get("total_cost", 0)

    print_header("Cost Summary", f"Last {hours}h")

    # Total cost panel
    console.print(
        Panel(
            f"[bold]{fmt_cost(total_cost)}[/bold]",
            title="Total Cost",
            border_style="cyan",
        )
    )
    console.print()

    # By model breakdown
    models = data.get("models", data.get("model_costs", data.get("by_model", [])))
    if models:
        model_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        model_table.add_column("Model", style="bold")
        model_table.add_column("Calls", justify="right")
        model_table.add_column("Cost", justify="right")
        model_table.add_column("Share", justify="right")
        model_table.add_column("", min_width=20)

        for model in models:
            cost = model.get("cost", model.get("total_cost", 0))
            pct = (cost / total_cost * 100) if total_cost > 0 else 0
            bar_width = 20
            filled = int((pct / 100) * bar_width)
            bar = f"[cyan]{'█' * filled}[/cyan][dim]{'░' * (bar_width - filled)}[/dim]"

            model_table.add_row(
                model.get("model", model.get("model_name", "unknown")),
                fmt_number(model.get("calls", model.get("call_count", 0))),
                fmt_cost(cost),
                f"{pct:.1f}%",
                bar,
            )

        console.print(model_table)
        console.print()

    # By agent breakdown
    agents = data.get("agents", data.get("agent_costs", data.get("by_agent", [])))
    if agents:
        agent_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        agent_table.add_column("Agent", style="bold")
        agent_table.add_column("Runs", justify="right")
        agent_table.add_column("Cost", justify="right")
        agent_table.add_column("Share", justify="right")
        agent_table.add_column("", min_width=20)

        for agent in agents:
            cost = agent.get("cost", agent.get("total_cost", 0))
            pct = (cost / total_cost * 100) if total_cost > 0 else 0
            bar_width = 20
            filled = int((pct / 100) * bar_width)
            bar = f"[green]{'█' * filled}[/green][dim]{'░' * (bar_width - filled)}[/dim]"

            agent_table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(agent.get("runs", agent.get("run_count", 0))),
                fmt_cost(cost),
                f"{pct:.1f}%",
                bar,
            )

        console.print(agent_table)
        console.print()


@costs.command("by-model")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def costs_by_model(ctx, hours: int, output_format: str):
    """Show detailed cost breakdown by model with share bars."""
    data = api_get(ctx, "/v1/observe/query/models/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    models = data.get("models", data.get("model_breakdown", []))
    if not models:
        print_warning("No model cost data found for the selected period.")
        return

    total_cost = sum(m.get("cost", m.get("total_cost", 0)) for m in models)

    print_header(
        "Cost by Model", f"Last {hours}h | Total: {fmt_cost(total_cost)}"
    )

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Calls", justify="right")
    table.add_column("Tokens In", justify="right")
    table.add_column("Tokens Out", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Share", justify="right")
    table.add_column("", min_width=20)

    for model in models:
        cost = model.get("cost", model.get("total_cost", 0))
        pct = (cost / total_cost * 100) if total_cost > 0 else 0
        bar_width = 20
        filled = int((pct / 100) * bar_width)
        bar = f"[cyan]{'█' * filled}[/cyan][dim]{'░' * (bar_width - filled)}[/dim]"

        table.add_row(
            model.get("model", model.get("model_name", "unknown")),
            fmt_number(model.get("calls", model.get("call_count", 0))),
            fmt_tokens(model.get("tokens_in", model.get("input_tokens", 0))),
            fmt_tokens(model.get("tokens_out", model.get("output_tokens", 0))),
            fmt_cost(cost),
            f"{pct:.1f}%",
            bar,
        )

    console.print(table)
    console.print()


@costs.command("by-agent")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def costs_by_agent(ctx, hours: int, output_format: str):
    """Show cost breakdown by agent."""
    data = api_get(ctx, "/v1/observe/query/billing/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    agents = data.get("agents", data.get("agent_costs", data.get("by_agent", [])))
    if not agents:
        print_warning("No agent cost data found for the selected period.")
        return

    total_cost = data.get(
        "total_cost",
        sum(a.get("cost", a.get("total_cost", 0)) for a in agents),
    )

    print_header(
        "Cost by Agent", f"Last {hours}h | Total: {fmt_cost(total_cost)}"
    )

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Agent", style="bold")
    table.add_column("Runs", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Avg Cost/Run", justify="right")
    table.add_column("Share", justify="right")
    table.add_column("", min_width=20)

    for agent in agents:
        cost = agent.get("cost", agent.get("total_cost", 0))
        runs = agent.get("runs", agent.get("run_count", 0))
        avg = cost / runs if runs > 0 else 0
        pct = (cost / total_cost * 100) if total_cost > 0 else 0
        bar_width = 20
        filled = int((pct / 100) * bar_width)
        bar = f"[green]{'█' * filled}[/green][dim]{'░' * (bar_width - filled)}[/dim]"

        table.add_row(
            agent.get("name", agent.get("agent_name", "unknown")),
            fmt_number(runs),
            fmt_cost(cost),
            fmt_cost(avg),
            f"{pct:.1f}%",
            bar,
        )

    console.print(table)
    console.print()
