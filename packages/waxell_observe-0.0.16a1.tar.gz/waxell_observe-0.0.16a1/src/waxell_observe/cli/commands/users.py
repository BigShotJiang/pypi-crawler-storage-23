"""Organization user management commands."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
)


def _normalize_items(data, key: str = "users"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("results", data.get("items", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return str(ts)[:16]


@click.group()
def users():
    """Manage organization users."""


@users.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def users_list(ctx, fmt: str):
    """List all users in the organization."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data, "users")

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No users found.")
        return

    print_header("Organization Users", f"{len(items)} users")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Email", style="bold")
    table.add_column("Name")
    table.add_column("Role")
    table.add_column("Teams")
    table.add_column("Last Login")
    table.add_column("Status", justify="center")

    for u in items:
        # Determine status
        is_active = u.get("is_active", u.get("active", True))
        status = "active" if is_active else "inactive"

        # Teams
        user_teams = u.get("teams", [])
        if isinstance(user_teams, list):
            if user_teams and isinstance(user_teams[0], dict):
                teams_str = ", ".join(t.get("name", str(t)) for t in user_teams[:3])
            else:
                teams_str = ", ".join(str(t) for t in user_teams[:3])
            if len(user_teams) > 3:
                teams_str += f" +{len(user_teams) - 3}"
        else:
            teams_str = str(user_teams) if user_teams else "-"

        table.add_row(
            u.get("email", "-"),
            u.get("name", u.get("full_name", u.get("first_name", "-"))),
            u.get("role", u.get("primary_role", "-")),
            teams_str,
            _short_ts(u.get("last_login")),
            status_dot(status),
        )

    console.print(table)
    console.print()


@users.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def users_show(ctx, id: str, fmt: str):
    """Show user details."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data, "users")

    user = None
    for u in items:
        if (str(u.get("id", "")) == id
                or u.get("email", "").lower() == id.lower()):
            user = u
            break

    if not user:
        print_warning(f'User "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(user, indent=2))
        return

    print_header(f"User: {user.get('email', '-')}")

    is_active = user.get("is_active", user.get("active", True))
    status = "active" if is_active else "inactive"

    lines = [
        f"[bold]Email:[/bold]      {user.get('email', '-')}",
        f"[bold]Name:[/bold]       {user.get('name', user.get('full_name', '-'))}",
        f"[bold]ID:[/bold]         {user.get('id', '-')}",
        f"[bold]Role:[/bold]       {user.get('role', user.get('primary_role', '-'))}",
        f"[bold]Status:[/bold]     {status_dot(status)} {status}",
        f"[bold]Last Login:[/bold] {_short_ts(user.get('last_login'))}",
        f"[bold]Joined:[/bold]     {_short_ts(user.get('date_joined', user.get('created_at')))}",
    ]

    # Teams
    user_teams = user.get("teams", [])
    if user_teams:
        lines.append("")
        lines.append("[bold]Teams:[/bold]")
        for t in user_teams:
            if isinstance(t, dict):
                lines.append(f"  - {t.get('name', str(t))} ({t.get('role', 'member')})")
            else:
                lines.append(f"  - {t}")

    # Permissions
    permissions = user.get("permissions", [])
    if permissions:
        lines.append("")
        perm_display = ", ".join(str(p) for p in permissions[:15])
        if len(permissions) > 15:
            perm_display += f" ... and {len(permissions) - 15} more"
        lines.append(f"[bold]Permissions:[/bold] {perm_display}")

    console.print(Panel("\n".join(lines), border_style="cyan"))
    console.print()
