"""API key management commands for wax CLI."""
import json
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get, api_post, api_delete
from .._display import (
    console,
    loading_spinner,
    print_header,
    print_success,
    print_error,
    print_warning,
    status_dot,
)


def _mask_key(key: str) -> str:
    """Mask an API key for display."""
    if not key or len(key) < 12:
        return "****"
    return f"{key[:8]}...{key[-4:]}"


@click.group()
def keys():
    """Manage API keys.

    API keys are used to authenticate requests to the Waxell API.
    Secret keys (wax_sk_*) can access all API endpoints.
    Publishable keys (wax_pk_*) can only access public endpoints.
    """
    pass


@keys.command("list")
@click.option(
    "--format", "fmt", type=click.Choice(["table", "json"]), default="table",
    help="Output format",
)
@click.pass_context
def list_keys(ctx, fmt: str):
    """List all API keys."""
    try:
        data = api_get(ctx, "/v1/api-keys/")
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    print_header("API Keys", "Your authentication keys")

    keys_list = data.get("keys", data.get("results", data if isinstance(data, list) else []))
    if not keys_list:
        print_warning("No API keys found")
        return

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Key", style="cyan")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Last Used")
    table.add_column("Created")

    for key in keys_list:
        is_active = key.get("is_active", True)
        status_str = "active" if is_active else "revoked"
        key_type = (
            "secret"
            if key.get("key_prefix", "").startswith("wax_sk")
            else "publishable"
        )

        table.add_row(
            key.get("name", "-"),
            _mask_key(
                key.get("key_prefix", "") + "..."
                if key.get("key_prefix")
                else "-"
            ),
            key_type,
            f"{status_dot(status_str)} {status_str}",
            (
                key.get("last_used_at", "Never")[:10]
                if key.get("last_used_at")
                else "Never"
            ),
            (
                key.get("created_at", "-")[:10]
                if key.get("created_at")
                else "-"
            ),
        )

    console.print(table)
    console.print()


@keys.command("create")
@click.option("--name", prompt=True, help="Name for this API key")
@click.option(
    "--type",
    "key_type",
    type=click.Choice(["secret", "publishable"]),
    default="secret",
    help="Key type (secret for full access, publishable for public endpoints)",
)
@click.option(
    "--scopes",
    help="Comma-separated list of scopes (e.g., agents:read,runs:read)",
)
@click.option(
    "--format", "fmt", type=click.Choice(["text", "json"]), default="text",
    help="Output format",
)
@click.pass_context
def create_key(ctx, name: str, key_type: str, scopes: Optional[str], fmt: str):
    """Create a new API key.

    The full key will only be shown once, so save it securely.
    """
    payload = {
        "name": name,
        "key_type": key_type,
    }
    if scopes:
        payload["scopes"] = [s.strip() for s in scopes.split(",")]

    try:
        with loading_spinner("Creating API key...") as progress:
            progress.add_task("Creating API key...", total=None)
            data = api_post(ctx, "/v1/api-keys/", json=payload)
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    console.print()
    console.print(
        Panel(
            f"[bold green]API key created successfully![/bold green]\n\n"
            f"[bold]Name:[/bold] {data.get('name', '-')}\n"
            f"[bold]Type:[/bold] {key_type}\n\n"
            f"[bold red]Secret Key (save this - shown only once):[/bold red]\n"
            f"[cyan]{data.get('key', data.get('secret_key', '-'))}[/cyan]",
            title="New API Key",
            border_style="green",
        )
    )
    console.print()
    console.print(
        "[bold yellow]Warning:[/bold yellow] This key will not be shown again. Save it securely!"
    )
    console.print()


@keys.command("show")
@click.argument("key_id")
@click.option(
    "--format", "fmt", type=click.Choice(["text", "json"]), default="text",
    help="Output format",
)
@click.pass_context
def show_key(ctx, key_id: str, fmt: str):
    """Show details for an API key (masked)."""
    try:
        data = api_get(ctx, f"/v1/api-keys/{key_id}/")
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    print_header(f"API Key: {data.get('name', key_id)}")

    is_active = data.get("is_active", True)
    status_str = "active" if is_active else "revoked"
    key_type = (
        "secret"
        if data.get("key_prefix", "").startswith("wax_sk")
        else "publishable"
    )

    info = []
    info.append(f"[bold]Name:[/bold]       {data.get('name', '-')}")
    info.append(f"[bold]Key Prefix:[/bold] {_mask_key(data.get('key_prefix', ''))}")
    info.append(f"[bold]Type:[/bold]       {key_type}")
    info.append(f"[bold]Status:[/bold]     {status_dot(status_str)} {status_str}")
    info.append(
        f"[bold]Created:[/bold]    "
        f"{data.get('created_at', '-')[:10] if data.get('created_at') else '-'}"
    )
    info.append(
        f"[bold]Last Used:[/bold]  "
        f"{data.get('last_used_at', 'Never')[:10] if data.get('last_used_at') else 'Never'}"
    )

    if data.get("scopes"):
        info.append("")
        info.append("[bold cyan]Scopes:[/bold cyan]")
        for scope in data.get("scopes", []):
            info.append(f"  - {scope}")

    console.print(Panel("\n".join(info), title="Key Details", border_style="cyan"))
    console.print()


@keys.command("revoke")
@click.argument("key_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def revoke_key(ctx, key_id: str, yes: bool):
    """Revoke an API key.

    Revoked keys cannot be used for authentication. This cannot be undone.
    """
    if not yes:
        if not click.confirm(f"Revoke API key '{key_id}'? This cannot be undone."):
            return

    try:
        with loading_spinner("Revoking API key...") as progress:
            progress.add_task("Revoking API key...", total=None)
            api_delete(ctx, f"/v1/api-keys/{key_id}/")
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    print_success(f"API key '{key_id}' revoked")


@keys.command("rotate")
@click.argument("key_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.option(
    "--format", "fmt", type=click.Choice(["text", "json"]), default="text",
    help="Output format",
)
@click.pass_context
def rotate_key(ctx, key_id: str, yes: bool, fmt: str):
    """Rotate an API key (generate new secret, keep permissions).

    The old key will stop working immediately.
    """
    if not yes:
        if not click.confirm(
            f"Rotate API key '{key_id}'? The old key will stop working immediately."
        ):
            return

    try:
        with loading_spinner("Rotating API key...") as progress:
            progress.add_task("Rotating API key...", total=None)
            data = api_post(ctx, f"/v1/api-keys/{key_id}/rotate/")
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    console.print()
    console.print(
        Panel(
            f"[bold green]API key rotated successfully![/bold green]\n\n"
            f"[bold red]New Secret Key (save this - shown only once):[/bold red]\n"
            f"[cyan]{data.get('key', data.get('secret_key', '-'))}[/cyan]",
            title="Rotated API Key",
            border_style="green",
        )
    )
    console.print()
    console.print(
        "[bold yellow]Warning:[/bold yellow] The old key is now invalid. "
        "Update your applications."
    )
    console.print()
