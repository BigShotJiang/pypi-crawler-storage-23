"""Team management commands."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
)


def _normalize_items(data):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get("results", data.get("items", data.get("teams", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return str(ts)[:10]


@click.group()
def teams():
    """Manage teams in your organization."""


@teams.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def teams_list(ctx, fmt: str):
    """List all teams."""
    data = api_get(ctx, "/v1/observe/query/access/")

    # Access data may be a composite response
    if isinstance(data, dict):
        items = data.get("teams", data.get("results", []))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No teams found.")
        return

    print_header("Teams", f"{len(items)} teams")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Team Name", style="bold")
    table.add_column("Members", justify="right")
    table.add_column("Description")
    table.add_column("Created")

    for t in items:
        member_count = t.get("member_count", t.get("members_count", len(t.get("members", []))))
        table.add_row(
            t.get("name", "-"),
            fmt_number(member_count),
            str(t.get("description", "-"))[:50],
            _short_ts(t.get("created_at", t.get("created"))),
        )

    console.print(table)
    console.print()


@teams.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def teams_show(ctx, id: str, fmt: str):
    """Show team details."""
    data = api_get(ctx, "/v1/observe/query/access/")

    if isinstance(data, dict):
        items = data.get("teams", data.get("results", []))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []

    team = None
    for t in items:
        if str(t.get("id", "")) == id or t.get("name", "").lower() == id.lower():
            team = t
            break

    if not team:
        print_warning(f'Team "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(team, indent=2))
        return

    print_header(f"Team: {team.get('name', '-')}")

    lines = [
        f"[bold]Name:[/bold]        {team.get('name', '-')}",
        f"[bold]ID:[/bold]          {team.get('id', '-')}",
        f"[bold]Description:[/bold] {team.get('description', '-')}",
        f"[bold]Created:[/bold]     {_short_ts(team.get('created_at', team.get('created')))}",
    ]

    console.print(Panel("\n".join(lines), border_style="cyan"))

    # Member list
    members = team.get("members", [])
    if members:
        console.print()
        member_table = Table(
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            title="Members",
        )
        member_table.add_column("Name", style="bold")
        member_table.add_column("Email")
        member_table.add_column("Role")

        for m in members:
            if isinstance(m, dict):
                name = m.get("name", m.get("full_name", "-"))
                email = m.get("email", "-")
                role = m.get("role", m.get("team_role", "-"))
            else:
                name = str(m)
                email = "-"
                role = "-"
            member_table.add_row(name, email, role)

        console.print(member_table)

    console.print()
