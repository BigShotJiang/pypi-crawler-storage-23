"""Configuration management commands for wax CLI."""
import click
from rich.panel import Panel
from rich.table import Table

from .._config import (
    get_config_from_context,
    save_config,
    list_profiles,
    get_config_path,
)
from .._display import (
    console,
    print_header,
    print_success,
    print_error,
    print_warning,
)


@click.group(name="config")
def config():
    """Manage CLI configuration.

    View and update wax CLI settings like API URL and credentials.
    Configuration is stored in ~/.waxell/config.
    """
    pass


@config.command("show")
@click.option("--profile", default=None, help="Profile to show (default: active profile)")
@click.pass_context
def config_show(ctx, profile: str):
    """Show current configuration for the active profile."""
    try:
        cfg = get_config_from_context(ctx, profile=profile)
    except ValueError as e:
        print_error(str(e))
        raise SystemExit(1)

    # Mask the API key for display
    masked_key = _mask_key(cfg.api_key)

    info_lines = []
    info_lines.append(f"[bold]Profile:[/bold]    {cfg.profile}")
    info_lines.append(f"[bold]API URL:[/bold]    {cfg.api_url}")
    info_lines.append(f"[bold]API Key:[/bold]    {masked_key}")
    if cfg.domain_url:
        info_lines.append(f"[bold]Domain URL:[/bold] {cfg.domain_url}")
    info_lines.append("")
    info_lines.append(f"[dim]Config file: {get_config_path()}[/dim]")

    console.print()
    console.print(
        Panel(
            "\n".join(info_lines),
            title=f"Configuration [{cfg.profile}]",
            border_style="cyan",
        )
    )
    console.print()


@config.command("set")
@click.argument("key", type=click.Choice(["api_url", "api_key", "domain_url"]))
@click.argument("value")
@click.option("--profile", default=None, help="Profile to update (default: active profile)")
@click.pass_context
def config_set(ctx, key: str, value: str, profile: str):
    """Set a configuration value.

    KEY must be one of: api_url, api_key, domain_url.
    """
    try:
        cfg = get_config_from_context(ctx, profile=profile)
    except ValueError:
        # No existing config; resolve profile name manually
        global_profile = ctx.obj.get("profile") if ctx.obj else None
        is_local = ctx.obj.get("local", False) if ctx.obj else False
        if profile is None:
            if global_profile:
                profile = global_profile
            elif is_local:
                profile = "local"
            else:
                profile = "default"
        cfg = None

    target_profile = profile or (cfg.profile if cfg else "default")

    # Build updated config values
    api_url = cfg.api_url if cfg else "https://api.waxell.dev"
    api_key = cfg.api_key if cfg else ""
    domain_url = cfg.domain_url if cfg else None

    if key == "api_url":
        api_url = value
    elif key == "api_key":
        api_key = value
    elif key == "domain_url":
        domain_url = value

    if not api_key:
        print_error("Cannot save config without an API key. Run 'wax login' first.")
        raise SystemExit(1)

    save_config(target_profile, api_url, api_key, domain_url=domain_url)
    print_success(f"Set [bold]{key}[/bold] in profile [bold]{target_profile}[/bold]")


@config.command("profiles")
def config_profiles():
    """List all configured profiles."""
    profiles = list_profiles()

    if not profiles:
        print_warning("No profiles configured. Run 'wax login' to get started.")
        return

    print_header("Configured Profiles")

    table = Table(
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
    )
    table.add_column("Profile", style="bold")
    table.add_column("API URL")
    table.add_column("API Key", style="dim")

    for p in profiles:
        table.add_row(
            p["name"],
            p["api_url"],
            p["api_key"],
        )

    console.print(table)
    console.print()
    console.print(f"[dim]Config file: {get_config_path()}[/dim]")
    console.print()


def _mask_key(key: str) -> str:
    """Mask an API key for display."""
    if not key or len(key) < 12:
        return "****"
    return f"{key[:8]}...{key[-4:]}"
