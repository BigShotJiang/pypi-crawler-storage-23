"""Trace explorer commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_duration,
    fmt_number,
)
from rich.table import Table
from rich.tree import Tree


@click.group()
def traces():
    """Trace explorer for distributed execution tracing."""
    pass


@traces.command("list")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--agent", default=None, help="Filter by agent name.")
@click.option("--limit", type=int, default=50, help="Maximum traces to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def traces_list(ctx, hours: int, agent: str, limit: int, output_format: str):
    """List recent traces."""
    params: dict = {"hours": hours}
    if agent:
        params["agent"] = agent

    data = api_get(ctx, "/v1/observe/query/runs/", params=params)

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    runs_data = data.get("runs", [])
    if not runs_data:
        print_warning("No traces found for the selected period.")
        return

    # Derive trace info from runs
    runs_data = runs_data[:limit]
    print_header("Traces", f"Last {hours}h | {len(runs_data)} traces")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Trace ID", style="bold", max_width=14)
    table.add_column("Agent")
    table.add_column("Operation")
    table.add_column("Duration", justify="right")
    table.add_column("Status")
    table.add_column("Spans", justify="right")

    for run in runs_data:
        trace_id = str(
            run.get("trace_id", run.get("run_id", run.get("id", "")))
        )[:12]
        run_status = run.get("status", "unknown")

        # Estimate span count from steps + llm_calls
        steps = run.get("steps", [])
        llm_calls = run.get("llm_calls", [])
        span_count = max(1, len(steps) + len(llm_calls))
        if isinstance(run.get("span_count"), int):
            span_count = run["span_count"]

        table.add_row(
            trace_id,
            run.get("agent_name", run.get("agent", "-")),
            run.get("workflow_name", run.get("workflow", run.get("operation", "-"))),
            fmt_duration(run.get("duration", run.get("duration_seconds", 0))),
            f"{status_dot(run_status)} {run_status}",
            fmt_number(span_count),
        )

    console.print(table)
    console.print()


@traces.command("show")
@click.argument("trace_id")
@click.pass_context
def traces_show(ctx, trace_id: str):
    """Show a trace with hierarchical span tree."""
    data = api_get(ctx, "/v1/observe/query/runs/", params={"run_id": trace_id})

    runs_data = data.get("runs", [])
    if not runs_data:
        print_warning(f"Trace '{trace_id}' not found.")
        return

    run = runs_data[0]
    run_status = run.get("status", "unknown")
    duration = run.get("duration", run.get("duration_seconds", 0))

    print_header(f"Trace: {trace_id}")

    # Build span tree
    tree = Tree(
        f"[bold cyan]{run.get('agent_name', run.get('agent', 'root'))}[/bold cyan] "
        f"{status_dot(run_status)} {fmt_duration(duration)}"
    )

    # Add steps as child spans
    steps = run.get("steps", [])
    for step in steps:
        step_status = step.get("status", "unknown")
        step_dur = fmt_duration(step.get("duration", 0))
        step_name = step.get("name", step.get("step_name", "step"))
        tree.add(
            f"[bold]{step_name}[/bold] "
            f"{status_dot(step_status)} {step_dur}"
        )

    # Add LLM calls as child spans
    llm_calls = run.get("llm_calls", [])
    for call in llm_calls:
        model = call.get("model", "unknown")
        tokens_in = call.get("tokens_in", call.get("input_tokens", 0))
        tokens_out = call.get("tokens_out", call.get("output_tokens", 0))
        cost = call.get("cost", 0)
        tree.add(
            f"[yellow]llm:[/yellow] {model} "
            f"[dim]in={tokens_in} out={tokens_out} ${cost:.4f}[/dim]"
        )

    console.print(tree)
    console.print()

    # Additional metadata
    context = run.get("context", run.get("metadata", {}))
    if context:
        console.print("[bold]Metadata:[/bold]")
        console.print_json(json.dumps(context, indent=2))
        console.print()
