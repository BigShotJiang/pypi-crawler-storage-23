"""Feature detection for OpenTelemetry.

Provides graceful fallback when OTel packages are not installed.
All tracing operations degrade to no-ops without import errors.
"""

import json
import logging
from contextlib import contextmanager

logger = logging.getLogger(__name__)

_HAS_OTEL = False

try:
    from opentelemetry import trace  # noqa: F401
    from opentelemetry.sdk.trace import TracerProvider  # noqa: F401
    from opentelemetry.sdk.trace.export import (  # noqa: F401
        BatchSpanProcessor,
        SimpleSpanProcessor,
        SpanExporter,
        SpanExportResult,
    )
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (  # noqa: F401
        OTLPSpanExporter,
    )
    from opentelemetry.sdk.trace.export import ConsoleSpanExporter  # noqa: F401
    from opentelemetry.sdk.resources import Resource  # noqa: F401
    from opentelemetry.trace import SpanKind, StatusCode, Status  # noqa: F401

    _HAS_OTEL = True
except ImportError:
    pass

_HAS_OTEL_LOGS = False

if _HAS_OTEL:
    try:
        from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler  # noqa: F401
        from opentelemetry.sdk._logs.export import BatchLogRecordProcessor  # noqa: F401
        from opentelemetry.exporter.otlp.proto.http._log_exporter import (  # noqa: F401
            OTLPLogExporter,
        )

        _HAS_OTEL_LOGS = True
    except ImportError:
        pass


# Module-level provider reference, set by init_tracing()
_provider = None


class NoOpSpan:
    """No-op span for use when OTel is not available."""

    def set_attribute(self, key, value):
        pass

    def add_event(self, name, attributes=None):
        pass

    def set_status(self, status, description=None):
        pass

    def record_exception(self, exception, attributes=None):
        pass

    def end(self, end_time=None):
        pass

    def get_span_context(self):
        return None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class NoOpTracer:
    """No-op tracer for use when OTel is not available."""

    def start_span(self, name, **kwargs):
        return NoOpSpan()

    @contextmanager
    def start_as_current_span(self, name, **kwargs):
        yield NoOpSpan()


def get_tracer(name="waxell.observe"):
    """Get a tracer instance.

    Returns a real OTel tracer if a provider has been initialized,
    otherwise returns a NoOpTracer.
    """
    if _HAS_OTEL and _provider is not None:
        return _provider.get_tracer(name)
    return NoOpTracer()


def _safe_attr(val):
    """Sanitize a value for use as an OTel span attribute.

    OTel attributes must be str, bool, int, float, bytes,
    or sequences of these types.
    """
    if isinstance(val, (str, bool, int, float, bytes)):
        return val
    if isinstance(val, (list, tuple)):
        return [v for v in val if isinstance(v, (str, bool, int, float, bytes))]
    if isinstance(val, dict):
        return json.dumps(val, default=str)
    return str(val)
