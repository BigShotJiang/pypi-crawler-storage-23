"""HuggingFace Transformers auto-instrumentor for waxell-observe.

Monkey-patches ``transformers.Pipeline.__call__`` and
``transformers.GenerationMixin.generate`` to emit OTel spans and record
to the Waxell HTTP API for local model inference tracking.

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Text generation pipeline tasks that should use start_llm_span
_TEXT_GENERATION_TASKS = frozenset({
    "text-generation",
    "text2text-generation",
    "summarization",
    "translation",
    "conversational",
})


class TransformersInstrumentor(BaseInstrumentor):
    """Instrumentor for HuggingFace Transformers local inference.

    Patches ``Pipeline.__call__`` for high-level pipeline inference and
    ``GenerationMixin.generate`` for low-level model generation.

    This instruments LOCAL inference via the ``transformers`` library,
    NOT the HuggingFace Hub API client (which is handled by
    ``HuggingFaceInstrumentor``).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import transformers  # noqa: F401
        except ImportError:
            logger.debug("transformers package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Transformers instrumentation")
            return False

        patched = False

        # Patch Pipeline.__call__
        try:
            wrapt.wrap_function_wrapper(
                "transformers",
                "Pipeline.__call__",
                _pipeline_call_wrapper,
            )
            patched = True
            logger.debug("Patched transformers.Pipeline.__call__")
        except Exception as exc:
            logger.debug("Could not patch transformers.Pipeline.__call__: %s", exc)

        # Patch GenerationMixin.generate
        try:
            wrapt.wrap_function_wrapper(
                "transformers.generation.utils",
                "GenerationMixin.generate",
                _generate_wrapper,
            )
            patched = True
            logger.debug("Patched transformers.GenerationMixin.generate")
        except Exception as exc:
            logger.debug("Could not patch transformers.GenerationMixin.generate: %s", exc)

        if not patched:
            logger.debug("Could not find any Transformers methods to patch")
            return False

        self._instrumented = True
        logger.debug("HuggingFace Transformers instrumented (Pipeline.__call__ + GenerationMixin.generate)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import transformers

            # Restore Pipeline.__call__
            method = getattr(transformers.Pipeline, "__call__", None)
            if method is not None and hasattr(method, "__wrapped__"):
                transformers.Pipeline.__call__ = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        try:
            from transformers.generation import utils as gen_utils

            method = getattr(gen_utils.GenerationMixin, "generate", None)
            if method is not None and hasattr(method, "__wrapped__"):
                gen_utils.GenerationMixin.generate = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("HuggingFace Transformers uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Transformers objects
# ---------------------------------------------------------------------------


def _get_pipeline_model_name(pipeline_instance) -> str:
    """Extract model name from a Transformers Pipeline instance.

    Tries ``pipeline.model.config.name_or_path`` then
    ``pipeline.model.name_or_path``, falling back to
    ``"transformers-local"``.
    """
    try:
        model = getattr(pipeline_instance, "model", None)
        if model is not None:
            config = getattr(model, "config", None)
            if config is not None:
                name = getattr(config, "name_or_path", None)
                if name and isinstance(name, str):
                    return name

            # Some models store it directly
            name = getattr(model, "name_or_path", None)
            if name and isinstance(name, str):
                return name
    except Exception:
        pass

    return "transformers-local"


def _get_pipeline_task(pipeline_instance) -> str:
    """Extract the task name from a Pipeline instance (e.g. 'text-generation')."""
    try:
        task = getattr(pipeline_instance, "task", None)
        if task and isinstance(task, str):
            return task
    except Exception:
        pass
    return "unknown"


def _get_generate_model_name(instance) -> str:
    """Extract model name from a GenerationMixin (model) instance.

    Tries ``instance.config.name_or_path`` then ``instance.name_or_path``.
    """
    try:
        config = getattr(instance, "config", None)
        if config is not None:
            name = getattr(config, "name_or_path", None)
            if name and isinstance(name, str):
                return name

        name = getattr(instance, "name_or_path", None)
        if name and isinstance(name, str):
            return name
    except Exception:
        pass

    return "transformers-local"


def _count_input_tokens(kwargs) -> int:
    """Count input tokens from input_ids tensor in kwargs."""
    try:
        input_ids = kwargs.get("input_ids")
        if input_ids is None:
            return 0

        # input_ids is typically a tensor with shape (batch, seq_len)
        shape = getattr(input_ids, "shape", None)
        if shape is not None and len(shape) >= 2:
            return int(shape[-1])
        elif shape is not None and len(shape) == 1:
            return int(shape[0])

        # Fallback: try len
        return len(input_ids)
    except Exception:
        return 0


def _count_output_tokens(output) -> int:
    """Count output tokens from generate() output tensor.

    The output can be a tensor (batch, seq_len) or a GenerateOutput object
    with a ``sequences`` attribute.
    """
    try:
        # GenerateOutput objects have a sequences attribute
        sequences = getattr(output, "sequences", None)
        if sequences is not None:
            shape = getattr(sequences, "shape", None)
            if shape is not None and len(shape) >= 2:
                return int(shape[-1])
            elif shape is not None and len(shape) == 1:
                return int(shape[0])
            return len(sequences)

        # Plain tensor output
        shape = getattr(output, "shape", None)
        if shape is not None and len(shape) >= 2:
            return int(shape[-1])
        elif shape is not None and len(shape) == 1:
            return int(shape[0])

        return len(output)
    except Exception:
        return 0


def _extract_pipeline_response_preview(result) -> str:
    """Extract a preview of the pipeline output for logging."""
    try:
        if isinstance(result, list) and result:
            first = result[0]
            if isinstance(first, dict):
                # text-generation: [{"generated_text": "..."}]
                text = first.get("generated_text", "")
                if not text:
                    # summarization: [{"summary_text": "..."}]
                    text = first.get("summary_text", "")
                if not text:
                    # translation: [{"translation_text": "..."}]
                    text = first.get("translation_text", "")
                if text:
                    return str(text)[:500]
            elif isinstance(first, list) and first:
                # Batch results: [[{"generated_text": "..."}]]
                inner = first[0]
                if isinstance(inner, dict):
                    text = inner.get("generated_text", inner.get("summary_text", ""))
                    if text:
                        return str(text)[:500]
        elif isinstance(result, dict):
            for key in ("generated_text", "summary_text", "translation_text"):
                text = result.get(key, "")
                if text:
                    return str(text)[:500]
        elif isinstance(result, str):
            return result[:500]
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _pipeline_call_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``transformers.Pipeline.__call__``."""
    try:
        from ..tracing.spans import start_llm_span, start_step_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    task = _get_pipeline_task(instance)
    model = _get_pipeline_model_name(instance)
    is_text_gen = task in _TEXT_GENERATION_TASKS

    try:
        if is_text_gen:
            span = start_llm_span(model=model, provider_name="huggingface_local")
        else:
            span = start_step_span(step_name=f"pipeline.{task}")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if is_text_gen:
                span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
                span.set_attribute(WaxellAttributes.LLM_MODEL, model)
                span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_pipeline(result, model, task, args, kwargs)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``transformers.GenerationMixin.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_generate_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_local")
    except Exception:
        return wrapped(*args, **kwargs)

    tokens_in = _count_input_tokens(kwargs)

    try:
        output = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_out = _count_output_tokens(output)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_generate(output, model, tokens_in, kwargs)
        except Exception:
            pass

        return output
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_pipeline(
    result, model: str, task: str, args: tuple, kwargs: dict
) -> None:
    """Record a Transformers pipeline call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    # Extract prompt preview from positional arg or kwargs
    prompt_preview = ""
    if args:
        first_arg = args[0]
        if isinstance(first_arg, str):
            prompt_preview = first_arg[:500]
        elif isinstance(first_arg, list) and first_arg:
            if isinstance(first_arg[0], str):
                prompt_preview = first_arg[0][:500]
            elif isinstance(first_arg[0], dict):
                prompt_preview = str(first_arg[0].get("content", ""))[:500]

    response_preview = _extract_pipeline_response_preview(result)

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"transformers.pipeline.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_generate(
    output, model: str, tokens_in: int, kwargs: dict
) -> None:
    """Record a Transformers generate call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_out = _count_output_tokens(output)

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "task": "transformers.generate",
        "prompt_preview": f"[{model} generate]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
