"""Retell AI voice agents auto-instrumentor for waxell-observe.

Monkey-patches ``retell.RetellClient.call.create``,
``retell.RetellClient.agent.create``, and related methods to emit OTel
spans and record to the Waxell HTTP API.

Retell AI provides a platform for building conversational voice AI agents
with low-latency, human-like interactions. The SDK uses a REST client
pattern with nested resource accessors (client.call, client.agent).

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class RetellInstrumentor(BaseInstrumentor):
    """Instrumentor for the Retell AI SDK (``retell-sdk`` package).

    Patches ``RetellClient.call.create``, ``RetellClient.call.retrieve``,
    ``RetellClient.agent.create``, and ``RetellClient.agent.retrieve``
    for call lifecycle and agent configuration observability.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import retell  # noqa: F401
        except ImportError:
            logger.debug("retell package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Retell instrumentation")
            return False

        patched = False

        # Patch call.create
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.call",
                "CallResource.create",
                _call_create_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch retell CallResource.create: %s", exc)

        # Patch call.retrieve
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.call",
                "CallResource.retrieve",
                _call_retrieve_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch retell CallResource.retrieve: %s", exc)

        # Patch agent.create
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.agent",
                "AgentResource.create",
                _agent_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch retell AgentResource.create: %s", exc)

        # Patch agent.retrieve
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.agent",
                "AgentResource.retrieve",
                _agent_retrieve_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch retell AgentResource.retrieve: %s", exc)

        # Patch call.create_web_call (browser-based calls)
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.call",
                "CallResource.create_web_call",
                _call_create_web_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch retell CallResource.create_web_call: %s", exc)

        # Patch call.create_phone_call (phone-based calls)
        try:
            wrapt.wrap_function_wrapper(
                "retell.resources.call",
                "CallResource.create_phone_call",
                _call_create_phone_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch retell CallResource.create_phone_call: %s", exc)

        if not patched:
            logger.debug("Could not find Retell methods to patch")
            return False

        self._instrumented = True
        logger.debug("Retell AI instrumented (call.create + call.retrieve + agent.create + agent.retrieve)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore call resource methods
        try:
            from retell.resources.call import CallResource

            for attr in ("create", "retrieve", "create_web_call", "create_phone_call"):
                method = getattr(CallResource, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(CallResource, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore agent resource methods
        try:
            from retell.resources.agent import AgentResource

            for attr in ("create", "retrieve"):
                method = getattr(AgentResource, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(AgentResource, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Retell AI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _call_create_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``CallResource.create`` -- creates a Retell voice call."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_id = kwargs.get("agent_id", "") or ""
    call_type = "retell.call"

    try:
        span = start_agent_span(
            agent_name=f"retell.call:{agent_id or 'unknown'}",
            workflow_name="retell_voice_call",
        )
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "call.create")
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))

        # Extract additional call parameters
        from_number = kwargs.get("from_number", "") or ""
        to_number = kwargs.get("to_number", "") or ""
        if from_number:
            span.set_attribute("waxell.retell.from_number", str(from_number))
        if to_number:
            span.set_attribute("waxell.retell.to_number", str(to_number))

        metadata = kwargs.get("metadata", None)
        if metadata and isinstance(metadata, dict):
            span.set_attribute("waxell.retell.metadata_keys", ",".join(str(k) for k in metadata.keys()))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.time() - start_time
            span.set_attribute("waxell.retell.api_latency_seconds", round(latency, 3))
            _set_call_result_attributes(span, result, agent_id, call_type)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _call_create_web_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``CallResource.create_web_call`` -- browser-based call."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_id = kwargs.get("agent_id", "") or ""

    try:
        span = start_agent_span(
            agent_name=f"retell.web_call:{agent_id or 'unknown'}",
            workflow_name="retell_web_call",
        )
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "call.create_web_call")
        span.set_attribute("waxell.retell.call_type", "web")
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.time() - start_time
            span.set_attribute("waxell.retell.api_latency_seconds", round(latency, 3))
            _set_call_result_attributes(span, result, agent_id, "web")
        except Exception:
            pass
        return result
    finally:
        span.end()


def _call_create_phone_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``CallResource.create_phone_call`` -- phone-based call."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_id = kwargs.get("agent_id", "") or ""

    try:
        span = start_agent_span(
            agent_name=f"retell.phone_call:{agent_id or 'unknown'}",
            workflow_name="retell_phone_call",
        )
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "call.create_phone_call")
        span.set_attribute("waxell.retell.call_type", "phone")
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))

        from_number = kwargs.get("from_number", "") or ""
        to_number = kwargs.get("to_number", "") or ""
        if from_number:
            span.set_attribute("waxell.retell.from_number", str(from_number))
        if to_number:
            span.set_attribute("waxell.retell.to_number", str(to_number))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.time() - start_time
            span.set_attribute("waxell.retell.api_latency_seconds", round(latency, 3))
            _set_call_result_attributes(span, result, agent_id, "phone")
        except Exception:
            pass
        return result
    finally:
        span.end()


def _call_retrieve_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``CallResource.retrieve`` -- retrieves call details."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    call_id = kwargs.get("call_id", "") or (args[0] if args else "")

    try:
        span = start_step_span(step_name="retell.call.retrieve")
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "call.retrieve")
        if call_id:
            span.set_attribute("waxell.retell.call_id", str(call_id))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_retrieve_result_attributes(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_create_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AgentResource.create`` -- creates a Retell agent."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = kwargs.get("agent_name", "") or ""
    llm_websocket_url = kwargs.get("llm_websocket_url", "") or ""

    try:
        span = start_step_span(step_name=f"retell.agent.create:{agent_name or 'unnamed'}")
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "agent.create")
        if agent_name:
            span.set_attribute("waxell.retell.agent_name", str(agent_name))
        if llm_websocket_url:
            span.set_attribute("waxell.retell.llm_websocket_url", str(llm_websocket_url)[:200])

        voice_id = kwargs.get("voice_id", "") or ""
        if voice_id:
            span.set_attribute("waxell.retell.voice_id", str(voice_id))

        language = kwargs.get("language", "") or ""
        if language:
            span.set_attribute("waxell.retell.language", str(language))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_create_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_retrieve_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AgentResource.retrieve`` -- retrieves agent details."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_id = kwargs.get("agent_id", "") or (args[0] if args else "")

    try:
        span = start_step_span(step_name="retell.agent.retrieve")
        span.set_attribute("waxell.agent.framework", "retell")
        span.set_attribute("waxell.retell.operation", "agent.retrieve")
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_retrieve_result_attributes(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_call_result_attributes(span, result, agent_id: str, call_type: str) -> None:
    """Set result attributes for call creation."""
    call_id = ""
    try:
        call_id = getattr(result, "call_id", "") or ""
        if not call_id:
            call_id = getattr(result, "id", "") or ""
        if call_id:
            span.set_attribute("waxell.retell.call_id", str(call_id))

        status = getattr(result, "call_status", "") or getattr(result, "status", "") or ""
        if status:
            span.set_attribute("waxell.retell.call_status", str(status))

        # Duration from completed calls
        duration = getattr(result, "duration_ms", None)
        if duration is not None:
            span.set_attribute("waxell.retell.duration_ms", int(duration))

        # Transcript if available
        transcript = getattr(result, "transcript", "") or ""
        if transcript:
            span.set_attribute("waxell.retell.transcript_preview", str(transcript)[:200])

        # Latency metrics
        e2e_latency = getattr(result, "e2e_latency", None)
        if e2e_latency is not None:
            span.set_attribute("waxell.retell.e2e_latency_ms", float(e2e_latency))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "agent:retell.call",
                output={
                    "agent_id": agent_id,
                    "call_id": str(call_id),
                    "call_type": call_type,
                },
            )
    except Exception:
        pass


def _set_retrieve_result_attributes(span, result) -> None:
    """Set result attributes for call retrieval."""
    try:
        call_id = getattr(result, "call_id", "") or ""
        if call_id:
            span.set_attribute("waxell.retell.call_id", str(call_id))

        status = getattr(result, "call_status", "") or ""
        if status:
            span.set_attribute("waxell.retell.call_status", str(status))

        duration = getattr(result, "duration_ms", None)
        if duration is not None:
            span.set_attribute("waxell.retell.duration_ms", int(duration))

        transcript = getattr(result, "transcript", "") or ""
        if transcript:
            span.set_attribute("waxell.retell.transcript_preview", str(transcript)[:200])

        disconnection_reason = getattr(result, "disconnection_reason", "") or ""
        if disconnection_reason:
            span.set_attribute("waxell.retell.disconnection_reason", str(disconnection_reason))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:retell.call.retrieve",
                output={"call_id": str(call_id) if call_id else ""},
            )
    except Exception:
        pass


def _set_agent_create_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes for agent creation."""
    try:
        agent_id = getattr(result, "agent_id", "") or ""
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:retell.agent.create",
                output={"agent_name": agent_name},
            )
    except Exception:
        pass


def _set_agent_retrieve_result_attributes(span, result) -> None:
    """Set result attributes for agent retrieval."""
    try:
        agent_id = getattr(result, "agent_id", "") or ""
        if agent_id:
            span.set_attribute("waxell.retell.agent_id", str(agent_id))

        agent_name = getattr(result, "agent_name", "") or ""
        if agent_name:
            span.set_attribute("waxell.retell.agent_name", str(agent_name))

        voice_id = getattr(result, "voice_id", "") or ""
        if voice_id:
            span.set_attribute("waxell.retell.voice_id", str(voice_id))

        llm_websocket_url = getattr(result, "llm_websocket_url", "") or ""
        if llm_websocket_url:
            span.set_attribute("waxell.retell.llm_websocket_url", str(llm_websocket_url)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:retell.agent.retrieve",
                output={"agent_id": str(agent_id) if agent_id else ""},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
