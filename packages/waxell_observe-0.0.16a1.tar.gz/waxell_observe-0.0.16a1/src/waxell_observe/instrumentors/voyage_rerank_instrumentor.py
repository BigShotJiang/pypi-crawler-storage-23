"""Voyage AI Reranker auto-instrumentor for waxell-observe.

Monkey-patches ``voyageai.Client.rerank`` and ``voyageai.AsyncClient.rerank``
to emit step spans tracking reranking operations via the Voyage AI API.

The Voyage AI reranker rescores documents by relevance to a query.
Token counts are extracted from ``result.total_tokens`` or
``result.usage.total_tokens`` (newer SDK).

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VoyageRerankInstrumentor(BaseInstrumentor):
    """Instrumentor for the Voyage AI reranker (``voyageai`` package).

    Patches ``Client.rerank`` and ``AsyncClient.rerank`` to emit
    step spans for reranking operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import voyageai  # noqa: F401
        except ImportError:
            logger.debug("voyageai package not installed -- skipping rerank instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Voyage rerank instrumentation")
            return False

        patched = False

        # Sync client: voyageai.Client.rerank
        try:
            wrapt.wrap_function_wrapper(
                "voyageai",
                "Client.rerank",
                _sync_rerank_wrapper,
            )
            patched = True
            logger.debug("Voyage AI sync rerank patched")
        except Exception:
            pass

        # Async client: voyageai.AsyncClient.rerank
        try:
            wrapt.wrap_function_wrapper(
                "voyageai",
                "AsyncClient.rerank",
                _async_rerank_wrapper,
            )
            logger.debug("Voyage AI async rerank patched")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find Voyage AI rerank methods to patch")
            return False

        self._instrumented = True
        logger.debug("Voyage AI rerank instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import voyageai

            for cls_name in ("Client", "AsyncClient"):
                cls = getattr(voyageai, cls_name, None)
                if cls is not None:
                    method = getattr(cls, "rerank", None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        cls.rerank = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Voyage AI rerank uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_tokens(result):
    """Extract total token count from a Voyage rerank result."""
    # Try result.total_tokens (older SDK)
    tokens = getattr(result, "total_tokens", 0)
    if tokens:
        return tokens
    # Try result.usage.total_tokens (newer SDK)
    usage = getattr(result, "usage", None)
    if usage:
        tokens = getattr(usage, "total_tokens", 0)
        if tokens:
            return tokens
    return 0


def _extract_results(result):
    """Extract the results list from a Voyage rerank response."""
    results = getattr(result, "results", None)
    if results is not None:
        return results
    if isinstance(result, dict):
        return result.get("results", [])
    return []


def _extract_top_score(results):
    """Extract the top relevance score from rerank results."""
    if not results:
        return None
    first = results[0]
    score = getattr(first, "relevance_score", None)
    if score is not None:
        return float(score)
    score = getattr(first, "score", None)
    if score is not None:
        return float(score)
    if isinstance(first, dict):
        score = first.get("relevance_score", first.get("score"))
        if score is not None:
            return float(score)
    return None


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_rerank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``voyageai.Client.rerank``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "rerank-2")
    query = kwargs.get("query", args[0] if args else "")
    documents = kwargs.get("documents", args[1] if len(args) > 1 else [])
    documents_count = len(documents) if isinstance(documents, list) else 0
    top_k = kwargs.get("top_k", None)

    try:
        span = start_step_span(step_name="voyage.rerank")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results = _extract_results(result)
            results_count = len(results)
            top_score = _extract_top_score(results)
            tokens = _extract_tokens(result)

            span.set_attribute("waxell.rerank.model", model)
            span.set_attribute("waxell.rerank.query", str(query)[:200])
            span.set_attribute("waxell.rerank.documents_count", documents_count)
            span.set_attribute("waxell.rerank.results_count", results_count)
            if top_k is not None:
                span.set_attribute("waxell.rerank.top_k", top_k)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
            if tokens:
                span.set_attribute("waxell.rerank.total_tokens", tokens)
        except Exception as attr_exc:
            logger.debug("Failed to set Voyage rerank span attributes: %s", attr_exc)

        try:
            _record_http_voyage_rerank(
                model, query, documents_count, results_count, top_score, tokens
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_rerank_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``voyageai.AsyncClient.rerank``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "rerank-2")
    query = kwargs.get("query", args[0] if args else "")
    documents = kwargs.get("documents", args[1] if len(args) > 1 else [])
    documents_count = len(documents) if isinstance(documents, list) else 0
    top_k = kwargs.get("top_k", None)

    try:
        span = start_step_span(step_name="voyage.rerank")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results = _extract_results(result)
            results_count = len(results)
            top_score = _extract_top_score(results)
            tokens = _extract_tokens(result)

            span.set_attribute("waxell.rerank.model", model)
            span.set_attribute("waxell.rerank.query", str(query)[:200])
            span.set_attribute("waxell.rerank.documents_count", documents_count)
            span.set_attribute("waxell.rerank.results_count", results_count)
            if top_k is not None:
                span.set_attribute("waxell.rerank.top_k", top_k)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
            if tokens:
                span.set_attribute("waxell.rerank.total_tokens", tokens)
        except Exception as attr_exc:
            logger.debug("Failed to set Voyage async rerank span attributes: %s", attr_exc)

        try:
            _record_http_voyage_rerank(
                model, query, documents_count, results_count, top_score, tokens
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_voyage_rerank(
    model: str,
    query: str,
    documents_count: int = 0,
    results_count: int = 0,
    top_score: float | None = None,
    tokens: int = 0,
) -> None:
    """Record a Voyage AI rerank call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "rerank:voyage",
        "prompt_preview": f"rerank query: {query[:200]}",
        "response_preview": f"{results_count} result(s) from {documents_count} doc(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
