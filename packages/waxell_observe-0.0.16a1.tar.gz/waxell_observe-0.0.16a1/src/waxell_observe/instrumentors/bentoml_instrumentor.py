"""BentoML auto-instrumentor for waxell-observe.

Monkey-patches BentoML's Runner.predict and Service API handlers to emit
LLM call and step spans for BentoML model serving.

BentoML patterns:
  - ``bentoml.Runner`` wraps a model for inference via ``.predict.run()``
  - ``bentoml.Service`` defines API endpoints via decorators
  - Runners have a ``name`` and a ``models`` list with ``tag`` attributes

Cost is always 0.0 for local BentoML inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class BentoMLInstrumentor(BaseInstrumentor):
    """Instrumentor for BentoML (``bentoml`` package).

    Patches ``Runner.__init__`` to wrap predict methods, and
    ``Service.__init__`` to wrap API handlers.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import bentoml  # noqa: F401
        except ImportError:
            logger.debug("bentoml package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping BentoML instrumentation")
            return False

        patched = False

        # Patch Runner.__init__ to intercept runner creation and wrap predict
        try:
            wrapt.wrap_function_wrapper(
                "bentoml",
                "Runner.__init__",
                _runner_init_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch bentoml.Runner.__init__: %s", exc)

        # Patch bentoml.runner (factory function if available)
        try:
            wrapt.wrap_function_wrapper(
                "bentoml",
                "runner",
                _runner_factory_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch bentoml.runner: %s", exc)

        # Patch Service.__init__ to intercept service creation
        try:
            wrapt.wrap_function_wrapper(
                "bentoml",
                "Service.__init__",
                _service_init_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch bentoml.Service.__init__: %s", exc)

        if not patched:
            logger.debug("Could not find any BentoML methods to patch")
            return False

        self._instrumented = True
        logger.debug("BentoML instrumented (Runner + Service)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import bentoml

            for attr in ("__init__",):
                for cls_name in ("Runner", "Service"):
                    cls = getattr(bentoml, cls_name, None)
                    if cls is None:
                        continue
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)

            if hasattr(bentoml, "runner"):
                func = getattr(bentoml, "runner")
                if hasattr(func, "__wrapped__"):
                    bentoml.runner = func.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("BentoML uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting BentoML metadata
# ---------------------------------------------------------------------------


def _get_runner_name(instance) -> str:
    """Extract the runner name from a BentoML Runner instance."""
    try:
        return str(getattr(instance, "name", "unknown-runner"))
    except Exception:
        return "unknown-runner"


def _get_model_tag(instance) -> str:
    """Extract the model tag from a BentoML Runner instance."""
    try:
        models = getattr(instance, "models", [])
        if models:
            tag = getattr(models[0], "tag", None)
            if tag:
                return str(tag)
    except Exception:
        pass
    return ""


def _get_service_name(instance) -> str:
    """Extract the service name from a BentoML Service instance."""
    try:
        return str(getattr(instance, "name", "unknown-service"))
    except Exception:
        return "unknown-service"


def _describe_input(args, kwargs) -> str:
    """Create a brief description of the input for span attributes."""
    parts = []
    try:
        for i, arg in enumerate(args):
            if hasattr(arg, "shape"):
                parts.append(f"arg{i}:shape={list(arg.shape)}")
            elif isinstance(arg, (list, tuple)):
                parts.append(f"arg{i}:len={len(arg)}")
            else:
                parts.append(f"arg{i}:{type(arg).__name__}")
    except Exception:
        pass
    return ", ".join(parts)[:500]


# ---------------------------------------------------------------------------
# Runner wrapper functions
# ---------------------------------------------------------------------------


def _runner_init_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``bentoml.Runner.__init__`` to attach predict wrappers."""
    result = wrapped(*args, **kwargs)

    # After init, wrap the predict runnable method if it exists
    try:
        _wrap_runner_predict(instance)
    except Exception as exc:
        logger.debug("Could not wrap runner predict methods: %s", exc)

    return result


def _runner_factory_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``bentoml.runner()`` factory function."""
    runner = wrapped(*args, **kwargs)

    try:
        _wrap_runner_predict(runner)
    except Exception as exc:
        logger.debug("Could not wrap runner predict methods: %s", exc)

    return runner


def _wrap_runner_predict(runner_instance) -> None:
    """Wrap predict methods on a Runner instance after creation."""

    # BentoML runners expose methods as Runnable method handles
    for method_name in ("predict", "generate", "__call__"):
        method = getattr(runner_instance, method_name, None)
        if method is None:
            continue

        # Check if it has a .run() method (BentoML runner method pattern)
        run_method = getattr(method, "run", None)
        if run_method is not None and not hasattr(run_method, "__waxell_wrapped__"):
            original_run = run_method

            def make_wrapper(orig, runner, mname):
                def _predict_run_wrapper(*args, **kwargs):
                    return _run_predict(orig, runner, mname, args, kwargs)
                _predict_run_wrapper.__waxell_wrapped__ = True
                _predict_run_wrapper.__wrapped__ = orig
                return _predict_run_wrapper

            try:
                method.run = make_wrapper(original_run, runner_instance, method_name)
            except Exception:
                pass


def _run_predict(original_run, runner_instance, method_name, args, kwargs):
    """Execute runner predict with tracing."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return original_run(*args, **kwargs)

    runner_name = _get_runner_name(runner_instance)
    model_tag = _get_model_tag(runner_instance)
    model_name = model_tag or runner_name

    try:
        span = start_llm_span(model=model_name, provider_name="bentoml")
    except Exception:
        return original_run(*args, **kwargs)

    start_time = time.monotonic()

    try:
        result = original_run(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            input_desc = _describe_input(args, kwargs)

            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.bentoml.runner_name", runner_name)
            span.set_attribute("waxell.bentoml.method", method_name)
            span.set_attribute("waxell.bentoml.latency_s", latency)

            if model_tag:
                span.set_attribute("waxell.bentoml.model_tag", model_tag)
            if input_desc:
                span.set_attribute("waxell.bentoml.input_shape", input_desc)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_bentoml(runner_name, model_tag, method_name)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Service wrapper functions
# ---------------------------------------------------------------------------


def _service_init_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``bentoml.Service.__init__`` to trace service creation."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract service name from args
    service_name = "unknown"
    if args:
        service_name = str(args[0]) if args[0] else "unknown"
    service_name = kwargs.get("name", service_name)

    try:
        span = start_step_span(step_name=f"bentoml.service.init:{service_name}")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.bentoml.service_name", str(service_name))

            # Count runners if provided
            runners = kwargs.get("runners", [])
            if runners:
                span.set_attribute("waxell.bentoml.runner_count", len(runners))
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_bentoml(
    runner_name: str, model_tag: str, method: str
) -> None:
    """Record a BentoML inference call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_tag or runner_name,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"bentoml.{method}",
        "prompt_preview": f"runner={runner_name}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
