"""Pinecone auto-instrumentor for waxell-observe.

Monkey-patches Pinecone's ``Index`` methods to emit OTel spans and record
to the Waxell HTTP API via the dual-path recording pattern.

Patched methods:
  - ``pinecone.data.index.Index.query``  (retrieval span)
  - ``pinecone.data.index.Index.fetch``  (retrieval span)
  - ``pinecone.data.index.Index.upsert`` (tool span)
  - ``pinecone.data.index.Index.delete`` (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's vector DB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PineconeInstrumentor(BaseInstrumentor):
    """Instrumentor for the Pinecone Python SDK (``pinecone`` package).

    Patches ``Index.query``, ``Index.fetch``, ``Index.upsert``, and
    ``Index.delete`` to emit OTel spans and record retrieval/tool events
    to the Waxell observability backend.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pinecone.data.index  # noqa: F401
        except ImportError:
            logger.debug("pinecone package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping Pinecone instrumentation"
            )
            return False

        wrapt.wrap_function_wrapper(
            "pinecone.data.index",
            "Index.query",
            _query_wrapper,
        )

        wrapt.wrap_function_wrapper(
            "pinecone.data.index",
            "Index.fetch",
            _fetch_wrapper,
        )

        wrapt.wrap_function_wrapper(
            "pinecone.data.index",
            "Index.upsert",
            _upsert_wrapper,
        )

        wrapt.wrap_function_wrapper(
            "pinecone.data.index",
            "Index.delete",
            _delete_wrapper,
        )

        self._instrumented = True
        logger.debug("Pinecone Index instrumented (query, fetch, upsert, delete)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import pinecone.data.index as mod

            if hasattr(mod.Index.query, "__wrapped__"):
                mod.Index.query = mod.Index.query.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.Index.fetch, "__wrapped__"):
                mod.Index.fetch = mod.Index.fetch.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.Index.upsert, "__wrapped__"):
                mod.Index.upsert = mod.Index.upsert.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.Index.delete, "__wrapped__"):
                mod.Index.delete = mod.Index.delete.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Pinecone Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Pinecone ``Index.query``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    top_k = kwargs.get("top_k", None)
    namespace = kwargs.get("namespace", "")

    # Build a query string from the vector argument for span labelling.
    # Pinecone query uses a dense vector; we don't store the raw floats.
    query_preview = f"pinecone.query(top_k={top_k}, namespace={namespace!r})"

    try:
        span = start_retrieval_span(query=query_preview, source="pinecone")
    except Exception:
        return wrapped(*args, **kwargs)

    matches_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            matches = getattr(response, "matches", None)
            if matches is not None:
                matches_count = len(matches)

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute(
                "waxell.retrieval.top_k", top_k if top_k is not None else 0
            )
            span.set_attribute("waxell.retrieval.matches_count", matches_count)
            if namespace:
                span.set_attribute("waxell.retrieval.namespace", namespace)
        except Exception as attr_exc:
            logger.debug("Failed to set Pinecone query span attributes: %s", attr_exc)

        try:
            _record_pinecone_retrieval(
                query=query_preview,
                top_k=top_k,
                namespace=namespace,
                matches_count=matches_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _fetch_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Pinecone ``Index.fetch``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    ids = kwargs.get("ids", args[0] if args else [])
    namespace = kwargs.get("namespace", "")
    ids_count = len(ids) if ids else 0
    query_preview = f"pinecone.fetch(ids_count={ids_count}, namespace={namespace!r})"

    try:
        span = start_retrieval_span(query=query_preview, source="pinecone")
    except Exception:
        return wrapped(*args, **kwargs)

    fetched_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            vectors = getattr(response, "vectors", None)
            fetched_count = len(vectors) if vectors else 0

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute("waxell.retrieval.top_k", ids_count)
            span.set_attribute("waxell.retrieval.matches_count", fetched_count)
            if namespace:
                span.set_attribute("waxell.retrieval.namespace", namespace)
        except Exception as attr_exc:
            logger.debug("Failed to set Pinecone fetch span attributes: %s", attr_exc)

        try:
            _record_pinecone_retrieval(
                query=query_preview,
                top_k=ids_count,
                namespace=namespace,
                matches_count=fetched_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _upsert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Pinecone ``Index.upsert``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # vectors can be a positional arg or keyword arg
    vectors = kwargs.get("vectors", args[0] if args else [])
    namespace = kwargs.get("namespace", "")
    vectors_count = len(vectors) if vectors else 0

    try:
        span = start_tool_span(tool_name="pinecone.upsert", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "upsert")
            span.set_attribute("waxell.vectordb.vectors_count", vectors_count)
            if namespace:
                span.set_attribute("waxell.retrieval.namespace", namespace)
        except Exception as attr_exc:
            logger.debug("Failed to set Pinecone upsert span attributes: %s", attr_exc)

        try:
            _record_pinecone_write(
                operation="upsert",
                vectors_count=vectors_count,
                namespace=namespace,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Pinecone ``Index.delete``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    ids = kwargs.get("ids", args[0] if args else [])
    namespace = kwargs.get("namespace", "")
    delete_all = kwargs.get("delete_all", False)
    vectors_count = len(ids) if ids else (0 if not delete_all else -1)

    try:
        span = start_tool_span(tool_name="pinecone.delete", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "delete")
            span.set_attribute("waxell.vectordb.vectors_count", vectors_count)
            if namespace:
                span.set_attribute("waxell.retrieval.namespace", namespace)
            if delete_all:
                span.set_attribute("waxell.vectordb.delete_all", True)
        except Exception as attr_exc:
            logger.debug("Failed to set Pinecone delete span attributes: %s", attr_exc)

        try:
            _record_pinecone_write(
                operation="delete",
                vectors_count=vectors_count,
                namespace=namespace,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_pinecone_retrieval(
    query: str,
    top_k: int | None,
    namespace: str,
    matches_count: int,
) -> None:
    """Record a Pinecone retrieval operation to the context path.

    Vector DB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector (no auto-run is created
    for vector DB ops).
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        # Build a minimal documents list from the match count for the API contract.
        # We don't have the actual document content at this recording point,
        # so we emit placeholder entries that satisfy the list[dict] type.
        documents = [{"id": f"match_{i}"} for i in range(matches_count)]
        ctx.record_retrieval(
            query=query,
            source="pinecone",
            documents=documents,
            top_k=top_k,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_pinecone_write(
    operation: str,
    vectors_count: int,
    namespace: str,
) -> None:
    """Record a Pinecone write operation (upsert/delete) to the context path.

    Write operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"pinecone.{operation}",
            input={"vectors_count": vectors_count, "namespace": namespace},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
