"""Marqo auto-instrumentor for waxell-observe.

Monkey-patches the Marqo Python client to emit OTel spans for
vector search, document insertion, and document deletion.

Patched methods:
  - ``marqo.index.Index.search``           (retrieval span)
  - ``marqo.index.Index.add_documents``    (tool span)
  - ``marqo.index.Index.delete_documents`` (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's Marqo calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MarqoInstrumentor(BaseInstrumentor):
    """Instrumentor for the Marqo Python client (``marqo`` package).

    Patches ``Index.search``, ``Index.add_documents``, and
    ``Index.delete_documents`` to emit OTel spans and record
    retrieval/tool events to the Waxell observability backend.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import marqo.index  # noqa: F401
        except ImportError:
            logger.debug("marqo package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Marqo instrumentation")
            return False

        patched_any = False

        try:
            wrapt.wrap_function_wrapper(
                "marqo.index",
                "Index.search",
                _search_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch marqo.index.Index.search")

        try:
            wrapt.wrap_function_wrapper(
                "marqo.index",
                "Index.add_documents",
                _add_documents_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch marqo.index.Index.add_documents")

        try:
            wrapt.wrap_function_wrapper(
                "marqo.index",
                "Index.delete_documents",
                _delete_documents_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch marqo.index.Index.delete_documents")

        if not patched_any:
            logger.debug("Could not patch any Marqo methods")
            return False

        self._instrumented = True
        logger.debug("Marqo Index instrumented (search, add_documents, delete_documents)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import marqo.index as mod

            index_cls = getattr(mod, "Index", None)
            if index_cls is not None:
                for method_name in ("search", "add_documents", "delete_documents"):
                    method = getattr(index_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(index_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Marqo Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_index_name(instance) -> str:
    """Extract the index name from the Marqo Index instance."""
    try:
        name = getattr(instance, "index_name", None)
        if name is not None:
            return str(name)
        # Some versions use .name
        name = getattr(instance, "name", None)
        if name is not None:
            return str(name)
    except Exception:
        pass
    return ""


def _truncate_query(query: str, max_len: int = 200) -> str:
    """Truncate a query string to a maximum length for span labels."""
    if not isinstance(query, str):
        return str(query)[:max_len]
    if len(query) <= max_len:
        return query
    return query[:max_len] + "..."


def _extract_search_results_count(response) -> int:
    """Extract the number of hits from a Marqo search response.

    Marqo returns a dict with ``hits`` (list) and optionally
    ``processingTimeMs``.
    """
    try:
        if isinstance(response, dict):
            hits = response.get("hits", [])
            if isinstance(hits, list):
                return len(hits)
        # Attribute-based access
        hits = getattr(response, "hits", None)
        if hits is not None and isinstance(hits, list):
            return len(hits)
    except Exception:
        pass
    return 0


def _extract_processing_time(response) -> int:
    """Extract processing time in ms from a Marqo search response."""
    try:
        if isinstance(response, dict):
            return int(response.get("processingTimeMs", 0))
    except (TypeError, ValueError):
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Marqo ``Index.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # search(q, searchable_attributes=..., limit=..., ...)
    query = args[0] if args else kwargs.get("q", "")
    limit = kwargs.get("limit", 10)
    index_name = _get_index_name(instance)
    truncated_query = _truncate_query(str(query))

    query_preview = f"marqo.search(index={index_name!r}, q={truncated_query!r}, limit={limit})"

    try:
        span = start_retrieval_span(query=query_preview, source="marqo")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            hits_count = _extract_search_results_count(response)
            processing_time = _extract_processing_time(response)

            span.set_attribute("waxell.retrieval.source", "marqo")
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if index_name:
                span.set_attribute("db.marqo.index", index_name)
            if limit:
                span.set_attribute("waxell.retrieval.top_k", int(limit))
            if processing_time:
                span.set_attribute("db.marqo.processing_time_ms", processing_time)
        except Exception as attr_exc:
            logger.debug("Failed to set Marqo search span attributes: %s", attr_exc)

        try:
            _record_marqo_retrieval(
                query=query_preview,
                index_name=index_name,
                hits_count=hits_count if "hits_count" in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _add_documents_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Marqo ``Index.add_documents``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # add_documents(documents, ...) -- documents is first positional arg
    documents = args[0] if args else kwargs.get("documents", [])
    doc_count = len(documents) if isinstance(documents, (list, tuple)) else 0
    index_name = _get_index_name(instance)

    try:
        span = start_tool_span(tool_name="marqo.add_documents", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "add_documents")
            span.set_attribute("waxell.vectordb.vectors_count", doc_count)
            if index_name:
                span.set_attribute("db.marqo.index", index_name)

            # Extract error info from response if available
            if isinstance(response, dict):
                errors = response.get("errors", False)
                if errors:
                    span.set_attribute("db.marqo.has_errors", True)
                items = response.get("items", [])
                if isinstance(items, list):
                    span.set_attribute("db.marqo.items_processed", len(items))
        except Exception as attr_exc:
            logger.debug("Failed to set Marqo add_documents span attributes: %s", attr_exc)

        try:
            _record_marqo_write(
                operation="add_documents",
                index_name=index_name,
                vectors_count=doc_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _delete_documents_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Marqo ``Index.delete_documents``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # delete_documents(ids, ...) -- ids is first positional arg
    ids = args[0] if args else kwargs.get("ids", [])
    ids_count = len(ids) if isinstance(ids, (list, tuple)) else 0
    index_name = _get_index_name(instance)

    try:
        span = start_tool_span(tool_name="marqo.delete_documents", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "delete_documents")
            span.set_attribute("waxell.vectordb.vectors_count", ids_count)
            if index_name:
                span.set_attribute("db.marqo.index", index_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Marqo delete_documents span attributes: %s", attr_exc)

        try:
            _record_marqo_write(
                operation="delete_documents",
                index_name=index_name,
                vectors_count=ids_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_marqo_retrieval(
    query: str,
    index_name: str,
    hits_count: int,
) -> None:
    """Record a Marqo retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"hit_{i}"} for i in range(hits_count)]
        ctx.record_retrieval(
            query=query,
            source="marqo",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_marqo_write(
    operation: str,
    index_name: str,
    vectors_count: int,
) -> None:
    """Record a Marqo write operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"marqo.{operation}",
            input={"index": index_name, "vectors_count": vectors_count},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
