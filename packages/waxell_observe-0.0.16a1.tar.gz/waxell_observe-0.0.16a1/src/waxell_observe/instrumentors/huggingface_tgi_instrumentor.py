"""HuggingFace Text Generation Inference auto-instrumentor for waxell-observe.

Monkey-patches ``text_generation.Client.generate`` and
``text_generation.Client.chat`` (sync), and
``text_generation.AsyncClient.generate`` and
``text_generation.AsyncClient.chat`` (async) to emit OTel spans and record
to the Waxell HTTP API.

Also tries ``huggingface_hub.InferenceClient.text_generation`` and
``huggingface_hub.InferenceClient.chat_completion`` as a fallback path
for users who use the huggingface_hub InferenceClient directly.

The ``text_generation`` SDK returns objects/dicts with:
  - ``generated_text``          -- the completion text
  - ``details.generated_tokens`` -- output token count
  - ``details.prefill``         -- list of prefill tokens (input)
  - ``details.finish_reason``   -- finish reason string

Cost is always 0.0 for self-hosted TGI inference.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class HuggingFaceTGIInstrumentor(BaseInstrumentor):
    """Instrumentor for HuggingFace Text Generation Inference.

    Patches ``text_generation.Client.generate``,
    ``text_generation.Client.chat``,
    ``text_generation.AsyncClient.generate``, and
    ``text_generation.AsyncClient.chat``.

    Also patches ``huggingface_hub.InferenceClient.text_generation``
    and ``huggingface_hub.InferenceClient.chat_completion`` if available.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        has_tgi = False
        has_hf_hub = False

        try:
            import text_generation  # noqa: F401
            has_tgi = True
        except ImportError:
            logger.debug("text_generation package not installed")

        try:
            import huggingface_hub  # noqa: F401
            has_hf_hub = True
        except ImportError:
            logger.debug("huggingface_hub package not installed")

        if not has_tgi and not has_hf_hub:
            logger.debug(
                "Neither text_generation nor huggingface_hub installed "
                "-- skipping HuggingFace TGI instrumentation"
            )
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping HuggingFace TGI instrumentation")
            return False

        patched = False

        # Patch text_generation.Client (sync)
        if has_tgi:
            for attr, wrapper in [
                ("Client.generate", _sync_generate_wrapper),
                ("Client.chat", _sync_chat_wrapper),
            ]:
                try:
                    wrapt.wrap_function_wrapper(
                        "text_generation",
                        attr,
                        wrapper,
                    )
                    patched = True
                except Exception as exc:
                    logger.debug("Could not patch text_generation.%s: %s", attr, exc)

            # Patch text_generation.AsyncClient (async)
            for attr, wrapper in [
                ("AsyncClient.generate", _async_generate_wrapper),
                ("AsyncClient.chat", _async_chat_wrapper),
            ]:
                try:
                    wrapt.wrap_function_wrapper(
                        "text_generation",
                        attr,
                        wrapper,
                    )
                    patched = True
                except Exception as exc:
                    logger.debug("Could not patch text_generation.%s: %s", attr, exc)

        # Patch huggingface_hub.InferenceClient
        if has_hf_hub:
            for attr, wrapper in [
                ("InferenceClient.text_generation", _sync_hf_text_generation_wrapper),
                ("InferenceClient.chat_completion", _sync_hf_chat_completion_wrapper),
            ]:
                try:
                    wrapt.wrap_function_wrapper(
                        "huggingface_hub",
                        attr,
                        wrapper,
                    )
                    patched = True
                except Exception as exc:
                    logger.debug("Could not patch huggingface_hub.%s: %s", attr, exc)

        if not patched:
            logger.debug("Could not find any HuggingFace TGI methods to patch")
            return False

        self._instrumented = True
        logger.debug("HuggingFace TGI instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import text_generation

            for cls_name in ("Client", "AsyncClient"):
                cls = getattr(text_generation, cls_name, None)
                if cls is None:
                    continue
                for attr in ("generate", "chat"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)  # type: ignore[attr-defined]
        except ImportError:
            pass

        try:
            import huggingface_hub

            for attr in ("text_generation", "chat_completion"):
                method = getattr(huggingface_hub.InferenceClient, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(
                        huggingface_hub.InferenceClient, attr, method.__wrapped__
                    )  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("HuggingFace TGI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from TGI responses
# ---------------------------------------------------------------------------


def _extract_tgi_data(response, request_model: str) -> dict:
    """Extract model, tokens, cost, and content from a TGI response.

    TGI responses can be objects with attributes or plain dicts.
    Returns a dict with keys: model, tokens_in, tokens_out, cost,
    finish_reason, content.
    """
    model = request_model
    tokens_in = 0
    tokens_out = 0
    finish_reason = ""
    content = ""

    if response is None:
        return {
            "model": model,
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "finish_reason": "",
            "content": "",
        }

    # Handle dict responses
    if isinstance(response, dict):
        content = response.get("generated_text", "")
        details = response.get("details", {})
        if isinstance(details, dict):
            tokens_out = details.get("generated_tokens", 0) or 0
            prefill = details.get("prefill", [])
            if isinstance(prefill, list):
                tokens_in = len(prefill)
            finish_reason = details.get("finish_reason", "") or ""
        return {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": 0.0,
            "finish_reason": finish_reason,
            "content": content,
        }

    # Handle object responses (text_generation SDK returns objects)
    content = getattr(response, "generated_text", "") or ""

    details = getattr(response, "details", None)
    if details is not None:
        tokens_out = getattr(details, "generated_tokens", 0) or 0

        prefill = getattr(details, "prefill", None)
        if isinstance(prefill, list):
            tokens_in = len(prefill)

        finish_reason = str(getattr(details, "finish_reason", "") or "")

    return {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Self-hosted inference is always free
        "finish_reason": finish_reason,
        "content": content,
    }


def _extract_chat_data(response, request_model: str) -> dict:
    """Extract data from a TGI chat response.

    Chat responses typically have:
      - response.choices[0].message.content (OpenAI-compatible)
      - response.usage.prompt_tokens / response.usage.completion_tokens
    Or dict-based equivalents.
    """
    model = request_model
    tokens_in = 0
    tokens_out = 0
    finish_reason = ""
    content = ""

    if response is None:
        return {
            "model": model,
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "finish_reason": "",
            "content": "",
        }

    if isinstance(response, dict):
        usage = response.get("usage", {})
        if isinstance(usage, dict):
            tokens_in = usage.get("prompt_tokens", 0) or 0
            tokens_out = usage.get("completion_tokens", 0) or 0

        choices = response.get("choices", [])
        if choices and isinstance(choices, list):
            first = choices[0]
            if isinstance(first, dict):
                finish_reason = first.get("finish_reason", "") or ""
                msg = first.get("message", {})
                if isinstance(msg, dict):
                    content = msg.get("content", "") or ""

        return {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": 0.0,
            "finish_reason": finish_reason,
            "content": content,
        }

    # Object-based response
    usage = getattr(response, "usage", None)
    if usage is not None:
        tokens_in = getattr(usage, "prompt_tokens", 0) or 0
        tokens_out = getattr(usage, "completion_tokens", 0) or 0

    choices = getattr(response, "choices", [])
    if choices:
        first = choices[0]
        finish_reason = str(getattr(first, "finish_reason", "") or "")
        msg = getattr(first, "message", None)
        if msg is not None:
            content = getattr(msg, "content", "") or ""

    return {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "finish_reason": finish_reason,
        "content": content,
    }


def _get_model_from_instance(instance) -> str:
    """Try to extract model name from a TGI client instance.

    The text_generation.Client stores the server URL, not the model name.
    We try common attribute paths and fall back to a default.
    """
    for attr in ("model_id", "model", "model_name"):
        try:
            val = getattr(instance, attr, None)
            if val and isinstance(val, str):
                return val
        except Exception:
            continue

    # Try to get from the base URL / server info
    try:
        base_url = getattr(instance, "base_url", None)
        if base_url and isinstance(base_url, str):
            return f"tgi:{base_url.split('/')[-1]}"
    except Exception:
        pass

    return "huggingface-tgi"


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``text_generation.Client.generate``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_tgi_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="generate")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``text_generation.Client.chat``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_chat_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="chat", is_chat=True)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``text_generation.AsyncClient.generate``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_tgi_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="generate")
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``text_generation.AsyncClient.chat``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_chat_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="chat", is_chat=True)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# huggingface_hub InferenceClient wrappers
# ---------------------------------------------------------------------------


def _sync_hf_text_generation_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``huggingface_hub.InferenceClient.text_generation``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_tgi_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="text_generation")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_hf_chat_completion_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``huggingface_hub.InferenceClient.chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="huggingface_tgi")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_chat_data(response, model)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tgi(response, model, kwargs, task="chat_completion", is_chat=True)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict) -> None:
    """Set OTel span attributes from extracted TGI data."""
    from ..tracing.attributes import GenAIAttributes, WaxellAttributes

    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, data["model"])
    if data["finish_reason"]:
        span.set_attribute(
            GenAIAttributes.RESPONSE_FINISH_REASONS, [data["finish_reason"]]
        )
    span.set_attribute(WaxellAttributes.LLM_MODEL, data["model"])
    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(
        WaxellAttributes.LLM_TOTAL_TOKENS,
        data["tokens_in"] + data["tokens_out"],
    )
    span.set_attribute(WaxellAttributes.LLM_COST, 0.0)


def _record_http_tgi(
    response, request_model: str, kwargs: dict, task: str = "generate",
    is_chat: bool = False,
) -> None:
    """Record a TGI LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    if is_chat:
        data = _extract_chat_data(response, request_model)
    else:
        data = _extract_tgi_data(response, request_model)

    # Extract prompt preview
    prompt_preview = ""
    if is_chat:
        messages = kwargs.get("messages", [])
        if messages and isinstance(messages, list):
            first = messages[0]
            if isinstance(first, dict):
                prompt_preview = str(first.get("content", ""))[:500]
    else:
        prompt = kwargs.get("prompt", "")
        if not prompt and args_has_positional(kwargs):
            prompt = ""
        if prompt:
            prompt_preview = str(prompt)[:500]

    call_data = {
        "model": data["model"],
        "tokens_in": data["tokens_in"],
        "tokens_out": data["tokens_out"],
        "cost": 0.0,
        "task": f"huggingface_tgi.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": str(data["content"])[:500] if data["content"] else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def args_has_positional(kwargs: dict) -> bool:
    """Check if kwargs indicate positional args were passed."""
    return False  # Helper to avoid referencing outer scope


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
