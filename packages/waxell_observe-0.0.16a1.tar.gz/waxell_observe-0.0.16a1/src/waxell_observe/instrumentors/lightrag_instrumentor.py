"""LightRAG auto-instrumentor for waxell-observe.

Monkey-patches LightRAG query and insert methods to emit retrieval and
step spans.

Patched methods:
  - ``lightrag.LightRAG.query``    (retrieval span)
  - ``lightrag.LightRAG.aquery``   (retrieval span, async)
  - ``lightrag.LightRAG.insert``   (step span)
  - ``lightrag.LightRAG.ainsert``  (step span, async)

All wrapper code is wrapped in try/except -- never breaks the user's LightRAG calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LightragInstrumentor(BaseInstrumentor):
    """Instrumentor for LightRAG.

    Patches ``LightRAG.query`` and ``LightRAG.insert`` methods, plus their
    async variants, to emit retrieval and step spans respectively.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import lightrag  # noqa: F401
        except ImportError:
            logger.debug("lightrag package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping LightRAG instrumentation")
            return False

        patched_any = False

        # --- LightRAG.query (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "lightrag",
                "LightRAG.query",
                _sync_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch LightRAG.query: %s", exc)

        # --- LightRAG.aquery (async) ---
        try:
            wrapt.wrap_function_wrapper(
                "lightrag",
                "LightRAG.aquery",
                _async_query_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch LightRAG.aquery: %s", exc)

        # --- LightRAG.insert (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "lightrag",
                "LightRAG.insert",
                _sync_insert_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch LightRAG.insert: %s", exc)

        # --- LightRAG.ainsert (async) ---
        try:
            wrapt.wrap_function_wrapper(
                "lightrag",
                "LightRAG.ainsert",
                _async_insert_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch LightRAG.ainsert: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any LightRAG methods")
            return False

        self._instrumented = True
        logger.debug("LightRAG instrumented (query, aquery, insert, ainsert)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import lightrag as lightrag_mod

            rag_cls = getattr(lightrag_mod, "LightRAG", None)
            if rag_cls is not None:
                for method_name in ("query", "aquery", "insert", "ainsert"):
                    method = getattr(rag_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(rag_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LightRAG uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _extract_mode(args, kwargs) -> str:
    """Extract the search mode (naive/local/global/hybrid) from args.

    LightRAG.query typically takes (query, param=QueryParam) where
    QueryParam has a mode attribute.
    """
    try:
        # Check kwargs first
        param = kwargs.get("param")
        if param is not None and hasattr(param, "mode"):
            return str(param.mode)

        # Check second positional arg
        if len(args) > 1 and hasattr(args[1], "mode"):
            return str(args[1].mode)
    except Exception:
        pass
    return "unknown"


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for LightRAG.query -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    mode = _extract_mode(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="lightrag")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.mode", mode)
            span.set_attribute("waxell.retrieval.operation", "query")
            if result is not None:
                result_preview = _truncate(str(result), max_len=200)
                span.set_attribute("waxell.retrieval.result_preview", result_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set LightRAG query span attributes: %s", attr_exc)

        try:
            _record_lightrag_retrieval(query=query_preview, mode=mode)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_insert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for LightRAG.insert -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract document info
    doc_preview = ""
    try:
        if args:
            doc = args[0]
            if isinstance(doc, str):
                doc_preview = _truncate(doc, max_len=200)
            elif isinstance(doc, (list, tuple)):
                doc_preview = f"[{len(doc)} documents]"
    except Exception:
        pass

    try:
        span = start_step_span(step_name="lightrag.insert")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.lightrag.operation", "insert")
            if doc_preview:
                span.set_attribute("waxell.lightrag.doc_preview", doc_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set LightRAG insert span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "lightrag_insert",
                    output={"doc_preview": doc_preview},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_query_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for LightRAG.aquery -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    mode = _extract_mode(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="lightrag")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.mode", mode)
            span.set_attribute("waxell.retrieval.operation", "query")
            if result is not None:
                result_preview = _truncate(str(result), max_len=200)
                span.set_attribute("waxell.retrieval.result_preview", result_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set LightRAG async query span attributes: %s", attr_exc)

        try:
            _record_lightrag_retrieval(query=query_preview, mode=mode)
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_insert_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for LightRAG.ainsert -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    doc_preview = ""
    try:
        if args:
            doc = args[0]
            if isinstance(doc, str):
                doc_preview = _truncate(doc, max_len=200)
            elif isinstance(doc, (list, tuple)):
                doc_preview = f"[{len(doc)} documents]"
    except Exception:
        pass

    try:
        span = start_step_span(step_name="lightrag.ainsert")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.lightrag.operation", "insert")
            if doc_preview:
                span.set_attribute("waxell.lightrag.doc_preview", doc_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set LightRAG async insert span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "lightrag_insert",
                    output={"doc_preview": doc_preview},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_lightrag_retrieval(
    query: str,
    mode: str = "unknown",
) -> None:
    """Record a LightRAG retrieval operation to the context path.

    LightRAG retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="lightrag",
        )
