"""Lakera Guard auto-instrumentor for waxell-observe.

Monkey-patches lakera_guard.LakeraGuard.check to emit guardrail
evaluation spans tracking prompt injection, PII, toxicity, and
unknown link detections.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LakeraGuardInstrumentor(BaseInstrumentor):
    """Instrumentor for Lakera Guard (``lakera-guard`` package).

    Patches LakeraGuard.check (the primary detection method).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import lakera_guard  # noqa: F401
        except ImportError:
            logger.debug("lakera_guard not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Lakera Guard instrumentation")
            return False

        patched = False

        # Patch LakeraGuard.check (main detection method)
        try:
            wrapt.wrap_function_wrapper(
                "lakera_guard",
                "LakeraGuard.check",
                _lakera_check_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch LakeraGuard.check: %s", exc)

        # Try alternate import path for classify
        try:
            wrapt.wrap_function_wrapper(
                "lakera_guard",
                "LakeraGuard.classify",
                _lakera_classify_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch LakeraGuard.classify: %s", exc)

        if not patched:
            logger.debug("Could not find Lakera Guard methods to patch")
            return False

        self._instrumented = True
        logger.debug("Lakera Guard instrumented (LakeraGuard.check + classify)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from lakera_guard import LakeraGuard

            if hasattr(LakeraGuard.check, "__wrapped__"):
                LakeraGuard.check = LakeraGuard.check.__wrapped__
            if hasattr(getattr(LakeraGuard, "classify", None), "__wrapped__"):
                LakeraGuard.classify = LakeraGuard.classify.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Lakera Guard uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _lakera_check_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``LakeraGuard.check`` -- main detection call."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="lakera_guard",
            framework="lakera_guard",
        )
        span.set_attribute("waxell.guardrail.method", "check")
    except Exception:
        return wrapped(*args, **kwargs)

    # Record input text length (not content -- security)
    try:
        prompt = kwargs.get("prompt") or (args[0] if args else None)
        if prompt and isinstance(prompt, str):
            span.set_attribute("waxell.guardrail.input_length", len(prompt))
    except Exception:
        pass

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_lakera_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _lakera_classify_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``LakeraGuard.classify`` -- classification call."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="lakera_guard",
            framework="lakera_guard",
        )
        span.set_attribute("waxell.guardrail.method", "classify")
    except Exception:
        return wrapped(*args, **kwargs)

    # Record input text length (not content -- security)
    try:
        prompt = kwargs.get("prompt") or (args[0] if args else None)
        if prompt and isinstance(prompt, str):
            span.set_attribute("waxell.guardrail.input_length", len(prompt))
    except Exception:
        pass

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_lakera_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_lakera_result(span, result) -> None:
    """Extract Lakera Guard results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    flagged = False
    detected_categories = []

    try:
        # result.flagged is the top-level flag
        flagged = bool(getattr(result, "flagged", False))
    except Exception:
        pass

    # Extract detected categories from results
    try:
        results = getattr(result, "results", None)
        if results:
            for item in results:
                categories = getattr(item, "categories", None)
                if categories and isinstance(categories, dict):
                    for cat_name, cat_flagged in categories.items():
                        if cat_flagged:
                            detected_categories.append(cat_name)
                elif categories:
                    # categories might be an object with attributes
                    for attr_name in dir(categories):
                        if not attr_name.startswith("_"):
                            try:
                                val = getattr(categories, attr_name)
                                if val is True:
                                    detected_categories.append(attr_name)
                            except Exception:
                                pass
    except Exception:
        pass

    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, not flagged)
        span.set_attribute(
            WaxellAttributes.GUARDRAIL_ACTION,
            "fail" if flagged else "pass",
        )
        span.set_attribute("waxell.guardrail.flagged", flagged)
        if detected_categories:
            span.set_attribute(
                "waxell.guardrail.detected_categories",
                ",".join(detected_categories),
            )
        span.set_attribute(
            "waxell.guardrail.detected_count", len(detected_categories)
        )
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_lakera(flagged, detected_categories)
    except Exception:
        pass


def _record_http_lakera(flagged: bool, detected_categories: list) -> None:
    """Record a Lakera Guard check to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "guardrail:lakera_guard",
            output={
                "passed": not flagged,
                "action": "fail" if flagged else "pass",
                "flagged": flagged,
                "detected_categories": detected_categories,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
