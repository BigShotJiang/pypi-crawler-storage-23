"""HuggingFace auto-instrumentor for waxell-observe.

Monkey-patches ``huggingface_hub.InferenceClient`` methods for API calls
to HuggingFace Inference Endpoints:
  - ``text_generation`` / ``chat_completion`` (sync)
  - ``async_*`` variants via ``AsyncInferenceClient``

Local ``transformers.pipeline`` is NOT instrumented here as it doesn't
produce token-level usage data that maps to cost.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class HuggingFaceInstrumentor(BaseInstrumentor):
    """Instrumentor for the HuggingFace Hub library (``huggingface_hub`` package).

    Patches ``InferenceClient.chat_completion`` and
    ``AsyncInferenceClient.chat_completion``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import huggingface_hub  # noqa: F401
        except ImportError:
            logger.debug("huggingface_hub package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping HuggingFace instrumentation")
            return False

        # Patch chat_completion (primary method for LLM calls)
        try:
            wrapt.wrap_function_wrapper(
                "huggingface_hub",
                "InferenceClient.chat_completion",
                _sync_chat_wrapper,
            )
        except Exception:
            logger.debug("Could not patch InferenceClient.chat_completion")

        # Patch text_generation as well
        try:
            wrapt.wrap_function_wrapper(
                "huggingface_hub",
                "InferenceClient.text_generation",
                _sync_text_gen_wrapper,
            )
        except Exception:
            logger.debug("Could not patch InferenceClient.text_generation")

        # Patch async variants
        try:
            wrapt.wrap_function_wrapper(
                "huggingface_hub",
                "AsyncInferenceClient.chat_completion",
                _async_chat_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncInferenceClient.chat_completion")

        self._instrumented = True
        logger.debug("HuggingFace InferenceClient instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import huggingface_hub

            for attr in ("chat_completion", "text_generation"):
                method = getattr(huggingface_hub.InferenceClient, attr, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(huggingface_hub.InferenceClient, attr, method.__wrapped__)

            method = getattr(huggingface_hub.AsyncInferenceClient, "chat_completion", None)
            if method and hasattr(method, "__wrapped__"):
                huggingface_hub.AsyncInferenceClient.chat_completion = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("HuggingFace InferenceClient uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``InferenceClient.chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", getattr(instance, "model", None) or "unknown")

    try:
        span = start_llm_span(model=model, provider_name="huggingface")
    except Exception:
        return wrapped(*args, **kwargs)

    start = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        elapsed_ms = (time.monotonic() - start) * 1000
        try:
            # HuggingFace ChatCompletionOutput has usage property
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model) or model
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = []
            choices = getattr(response, "choices", None)
            if choices:
                for c in choices:
                    fr = getattr(c, "finish_reason", None)
                    if fr:
                        finish_reasons.append(fr)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_hf(response, model, kwargs, "chat_completion")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_text_gen_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``InferenceClient.text_generation``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", getattr(instance, "model", None) or "unknown")

    try:
        span = start_llm_span(model=model, provider_name="huggingface")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # text_generation can return a string or TextGenerationOutput
            response_text = ""
            tokens_in = 0
            tokens_out = 0

            if isinstance(response, str):
                response_text = response
            else:
                response_text = getattr(response, "generated_text", str(response))
                details = getattr(response, "details", None)
                if details:
                    tokens_out = getattr(details, "generated_tokens", 0) or 0

            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_hf_text_gen(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncInferenceClient.chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", getattr(instance, "model", None) or "unknown")

    try:
        span = start_llm_span(model=model, provider_name="huggingface")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model) or model
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_hf(response, model, kwargs, "chat_completion")
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_hf(response, request_model: str, kwargs: dict, task: str) -> None:
    """Record a HuggingFace chat call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    usage = getattr(response, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
    response_model = getattr(response, "model", request_model) or request_model
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first_msg = messages[0] if messages else {}
        if isinstance(first_msg, dict):
            prompt_preview = str(first_msg.get("content", ""))[:500]

    response_preview = ""
    choices = getattr(response, "choices", None)
    if choices:
        msg = getattr(choices[0], "message", None)
        if msg:
            content = getattr(msg, "content", None)
            if content:
                response_preview = str(content)[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": f"huggingface.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_hf_text_gen(response, request_model: str, kwargs: dict) -> None:
    """Record a HuggingFace text_generation call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    prompt = kwargs.get("prompt", "")
    if isinstance(prompt, str):
        prompt_preview = prompt[:500]
    else:
        prompt_preview = str(prompt)[:500]

    response_preview = ""
    if isinstance(response, str):
        response_preview = response[:500]
    else:
        response_preview = str(getattr(response, "generated_text", response))[:500]

    call_data = {
        "model": request_model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "huggingface.text_generation",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
