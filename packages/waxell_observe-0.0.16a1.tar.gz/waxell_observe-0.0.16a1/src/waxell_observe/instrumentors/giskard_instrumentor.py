"""Giskard auto-instrumentor for waxell-observe.

Monkey-patches ``giskard.scan()`` and ``giskard.Suite.run()`` to emit
evaluation spans tracking vulnerability counts, severity levels, and
test pass/fail rates.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GiskardInstrumentor(BaseInstrumentor):
    """Instrumentor for the Giskard ML testing framework (``giskard`` package).

    Patches giskard.scan() and Suite.run().
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import giskard  # noqa: F401
        except ImportError:
            logger.debug("giskard not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Giskard instrumentation")
            return False

        patched = False

        # Patch giskard.scan (main vulnerability scanner)
        try:
            wrapt.wrap_function_wrapper(
                "giskard",
                "scan",
                _scan_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch giskard.scan: %s", exc)

        # Patch giskard.Suite.run (test suite execution)
        try:
            wrapt.wrap_function_wrapper(
                "giskard",
                "Suite.run",
                _suite_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch giskard.Suite.run: %s", exc)

        # Try alternate path: giskard.testing.test
        try:
            wrapt.wrap_function_wrapper(
                "giskard.testing",
                "test",
                _test_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch giskard.testing.test: %s", exc)

        if not patched:
            logger.debug("Could not find Giskard methods to patch")
            return False

        self._instrumented = True
        logger.debug("Giskard instrumented (scan + Suite.run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import giskard

            if hasattr(giskard.scan, "__wrapped__"):
                giskard.scan = giskard.scan.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import giskard

            if hasattr(giskard.Suite.run, "__wrapped__"):
                giskard.Suite.run = giskard.Suite.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from giskard import testing

            if hasattr(testing.test, "__wrapped__"):
                testing.test = testing.test.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Giskard uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _scan_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``giskard.scan`` -- vulnerability scanning."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="giskard.scan")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "giskard")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_scan_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _suite_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``giskard.Suite.run`` -- test suite execution."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    suite_name = ""
    try:
        suite_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        suite_name = "UnknownSuite"

    try:
        span = start_step_span(step_name="giskard.test")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "giskard")
        span.set_attribute("waxell.eval.suite_name", str(suite_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_suite_result(span, result, suite_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _test_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``giskard.testing.test`` -- individual test execution."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="giskard.test")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "giskard")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_test_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_scan_result(span, result) -> None:
    """Extract scan results and set span attributes."""

    vulnerabilities_count = 0
    severity_counts: dict[str, int] = {}

    # Try to extract vulnerabilities from scan result
    try:
        issues = getattr(result, "issues", None) or getattr(result, "vulnerabilities", None)
        if issues is not None:
            if isinstance(issues, (list, tuple)):
                vulnerabilities_count = len(issues)
                for issue in issues:
                    try:
                        severity = str(getattr(issue, "severity", "unknown")).lower()
                        severity_counts[severity] = severity_counts.get(severity, 0) + 1
                    except Exception:
                        pass
            elif hasattr(issues, "__len__"):
                vulnerabilities_count = len(issues)
    except Exception:
        pass

    # Try to extract from to_dataframe() if available
    if vulnerabilities_count == 0:
        try:
            to_df = getattr(result, "to_dataframe", None) or getattr(result, "to_pandas", None)
            if callable(to_df):
                df = to_df()
                vulnerabilities_count = len(df)
        except Exception:
            pass

    try:
        span.set_attribute("waxell.eval.vulnerabilities_count", vulnerabilities_count)
        if severity_counts:
            severity_summary = ", ".join(f"{k}={v}" for k, v in severity_counts.items())
            span.set_attribute("waxell.eval.severity_breakdown", severity_summary)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_scan(result, vulnerabilities_count, severity_counts)
    except Exception:
        pass


def _record_suite_result(span, result, suite_name: str) -> None:
    """Extract test suite results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    tests_passed = 0
    tests_failed = 0
    total_tests = 0

    # Try to extract test results
    try:
        results_list = getattr(result, "results", None)
        if results_list is not None:
            if isinstance(results_list, (list, tuple)):
                total_tests = len(results_list)
                for r in results_list:
                    try:
                        passed = getattr(r, "passed", None)
                        if passed is None:
                            passed = getattr(r, "is_passed", None)
                            if callable(passed):
                                passed = passed()
                        if passed:
                            tests_passed += 1
                        else:
                            tests_failed += 1
                    except Exception:
                        pass
            elif isinstance(results_list, dict):
                total_tests = len(results_list)
                for key, r in results_list.items():
                    try:
                        passed = getattr(r, "passed", None)
                        if passed is None:
                            passed = getattr(r, "is_passed", None)
                            if callable(passed):
                                passed = passed()
                        if passed:
                            tests_passed += 1
                        else:
                            tests_failed += 1
                    except Exception:
                        pass
    except Exception:
        pass

    pass_rate = 0.0
    try:
        if total_tests > 0:
            pass_rate = tests_passed / total_tests
    except Exception:
        pass

    try:
        span.set_attribute("waxell.eval.tests_passed", tests_passed)
        span.set_attribute("waxell.eval.tests_failed", tests_failed)
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, total_tests)
        span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, pass_rate)
        span.set_attribute(WaxellAttributes.EVAL_PASSED, tests_passed)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_suite(suite_name, tests_passed, tests_failed, total_tests, pass_rate)
    except Exception:
        pass


def _record_test_result(span, result) -> None:
    """Extract individual test result and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    passed = False
    try:
        passed = bool(getattr(result, "passed", False))
    except Exception:
        pass

    try:
        span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_test(result, passed)
    except Exception:
        pass


def _record_http_scan(result, vulnerabilities_count: int,
                      severity_counts: dict[str, int]) -> None:
    """Record a Giskard scan to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:giskard.scan",
            output={
                "framework": "giskard",
                "vulnerabilities_count": vulnerabilities_count,
                "severity_breakdown": severity_counts,
                "result_preview": str(result)[:500],
            },
        )


def _record_http_suite(suite_name: str, tests_passed: int, tests_failed: int,
                       total_tests: int, pass_rate: float) -> None:
    """Record a Giskard suite run to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:giskard.suite",
            output={
                "framework": "giskard",
                "suite_name": suite_name,
                "tests_passed": tests_passed,
                "tests_failed": tests_failed,
                "total_tests": total_tests,
                "pass_rate": pass_rate,
            },
        )


def _record_http_test(result, passed: bool) -> None:
    """Record a Giskard test to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:giskard.test",
            output={
                "framework": "giskard",
                "passed": passed,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
