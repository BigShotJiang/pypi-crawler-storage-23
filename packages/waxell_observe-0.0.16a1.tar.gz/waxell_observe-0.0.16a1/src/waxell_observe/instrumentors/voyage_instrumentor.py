"""Voyage AI auto-instrumentor for waxell-observe.

Monkey-patches Voyage AI's Client.embed and AsyncClient.embed to emit
embedding spans tracking remote embedding generation via the Voyage API.

The ``voyageai`` package provides a simple interface for computing embeddings
using Voyage AI models. Token counts are extracted from ``result.total_tokens``
or ``result.usage.total_tokens`` (newer SDK).

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VoyageInstrumentor(BaseInstrumentor):
    """Instrumentor for the Voyage AI Python SDK (``voyageai`` package).

    Patches ``Client.embed`` and ``AsyncClient.embed`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import voyageai  # noqa: F401
        except ImportError:
            logger.debug("voyageai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Voyage AI instrumentation")
            return False

        patched = False

        # Sync client: voyageai.Client.embed
        try:
            wrapt.wrap_function_wrapper(
                "voyageai",
                "Client.embed",
                _sync_embed_wrapper,
            )
            patched = True
            logger.debug("Voyage AI sync embed patched")
        except Exception:
            pass

        # Async client: voyageai.AsyncClient.embed
        try:
            wrapt.wrap_function_wrapper(
                "voyageai",
                "AsyncClient.embed",
                _async_embed_wrapper,
            )
            logger.debug("Voyage AI async embed patched")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find Voyage AI embed methods to patch")
            return False

        self._instrumented = True
        logger.debug("Voyage AI embed instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import voyageai

            for cls_name in ("Client", "AsyncClient"):
                cls = getattr(voyageai, cls_name, None)
                if cls is not None:
                    method = getattr(cls, "embed", None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        cls.embed = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Voyage AI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_texts(args, kwargs):
    """Extract texts from embed call arguments."""
    texts = kwargs.get("texts", kwargs.get("input", args[0] if args else []))
    return texts


def _extract_tokens(result):
    """Extract total token count from a Voyage embed result."""
    # Try result.total_tokens (older SDK)
    tokens = getattr(result, "total_tokens", 0)
    if tokens:
        return tokens
    # Try result.usage.total_tokens (newer SDK)
    usage = getattr(result, "usage", None)
    if usage:
        tokens = getattr(usage, "total_tokens", 0)
        if tokens:
            return tokens
    return 0


def _extract_dimensions(result):
    """Extract embedding dimensions from a Voyage embed result."""
    embeddings = getattr(result, "embeddings", None)
    if embeddings and isinstance(embeddings, list) and len(embeddings) > 0:
        first = embeddings[0]
        if isinstance(first, list):
            return len(first)
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``voyageai.Client.embed``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "voyage-3")
    texts = _extract_texts(args, kwargs)
    input_count = len(texts) if isinstance(texts, list) else 1

    try:
        span = start_embedding_span(
            model=model,
            provider_name="voyage",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = _extract_tokens(result)
            dimensions = _extract_dimensions(result)
            cost = estimate_embedding_cost(model, tokens, "voyage")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set Voyage embed span attributes: %s", attr_exc)

        try:
            _record_http_voyage_embed(model, input_count, tokens, dimensions, cost)
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_embed_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``voyageai.AsyncClient.embed``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "voyage-3")
    texts = _extract_texts(args, kwargs)
    input_count = len(texts) if isinstance(texts, list) else 1

    try:
        span = start_embedding_span(
            model=model,
            provider_name="voyage",
            input_count=input_count,
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = _extract_tokens(result)
            dimensions = _extract_dimensions(result)
            cost = estimate_embedding_cost(model, tokens, "voyage")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set Voyage async embed span attributes: %s", attr_exc)

        try:
            _record_http_voyage_embed(model, input_count, tokens, dimensions, cost)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_voyage_embed(
    model: str, input_count: int, tokens: int = 0, dimensions: int = 0, cost: float = 0.0
) -> None:
    """Record a Voyage AI embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embedding:voyage",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
