"""ExLlamaV2 auto-instrumentor for waxell-observe.

Monkey-patches ``exllamav2.generator.ExLlamaV2BaseGenerator.generate_simple``
and ``exllamav2.generator.ExLlamaV2StreamingGenerator.generate_simple``
to emit OTel spans and record to the Waxell HTTP API.

ExLlamaV2 is a highly optimized local inference engine for GPTQ/EXL2 models.
The ``generate_simple`` method returns a plain string of generated text.

Model name is extracted from ``generator.model.config.model_dir``.

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ExLlamaV2Instrumentor(BaseInstrumentor):
    """Instrumentor for the ExLlamaV2 library (``exllamav2`` package).

    Patches ``ExLlamaV2BaseGenerator.generate_simple`` and
    ``ExLlamaV2StreamingGenerator.generate_simple``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import exllamav2  # noqa: F401
        except ImportError:
            logger.debug("exllamav2 package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping ExLlamaV2 instrumentation")
            return False

        patched = False

        # Patch ExLlamaV2BaseGenerator.generate_simple
        try:
            wrapt.wrap_function_wrapper(
                "exllamav2.generator",
                "ExLlamaV2BaseGenerator.generate_simple",
                _sync_generate_simple_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug(
                "Could not patch exllamav2 ExLlamaV2BaseGenerator.generate_simple: %s", exc
            )

        # Patch ExLlamaV2StreamingGenerator.generate_simple
        try:
            wrapt.wrap_function_wrapper(
                "exllamav2.generator",
                "ExLlamaV2StreamingGenerator.generate_simple",
                _sync_streaming_generate_simple_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug(
                "Could not patch exllamav2 ExLlamaV2StreamingGenerator.generate_simple: %s",
                exc,
            )

        if not patched:
            logger.debug("Could not find any ExLlamaV2 generator methods to patch")
            return False

        self._instrumented = True
        logger.debug("ExLlamaV2 instrumented (generate_simple on base + streaming)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import exllamav2.generator as gen_mod

            for cls_name in (
                "ExLlamaV2BaseGenerator",
                "ExLlamaV2StreamingGenerator",
            ):
                cls = getattr(gen_mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "generate_simple", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "generate_simple", method.__wrapped__)  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ExLlamaV2 uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from ExLlamaV2 generator
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from an ExLlamaV2 generator instance.

    Tries ``generator.model.config.model_dir`` and falls back through
    several attribute paths.
    """
    try:
        model = getattr(instance, "model", None)
        if model is not None:
            config = getattr(model, "config", None)
            if config is not None:
                model_dir = getattr(config, "model_dir", None)
                if model_dir and isinstance(model_dir, str):
                    return model_dir
    except Exception:
        pass

    # Try direct config attribute
    try:
        config = getattr(instance, "config", None)
        if config is not None:
            model_dir = getattr(config, "model_dir", None)
            if model_dir and isinstance(model_dir, str):
                return model_dir
    except Exception:
        pass

    return "exllamav2-local"


def _estimate_token_count(text: str) -> int:
    """Rough token count estimate when exact counts are not available.

    Uses a simple heuristic of ~4 characters per token (English text average).
    Returns 0 for empty/None text.
    """
    if not text:
        return 0
    return max(1, len(text) // 4)


def _extract_settings_data(kwargs: dict) -> dict:
    """Extract token-related settings from ExLlamaV2 generation kwargs.

    ExLlamaV2 ``generate_simple`` takes ``prompt``, ``gen_settings``,
    ``num_tokens`` (max output tokens), and ``seed`` as parameters.
    """
    max_tokens = kwargs.get("num_tokens", 0) or 0
    return {
        "max_tokens": max_tokens,
    }


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_simple_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ExLlamaV2BaseGenerator.generate_simple``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="exllamav2")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Extract prompt from args/kwargs
            prompt = ""
            if args:
                prompt = str(args[0]) if args[0] else ""
            elif "prompt" in kwargs:
                prompt = str(kwargs["prompt"]) if kwargs["prompt"] else ""

            # generate_simple returns a string
            output_text = str(result) if result else ""
            tokens_in = _estimate_token_count(prompt)
            tokens_out = _estimate_token_count(output_text)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_exllamav2(result, model, args, kwargs, generator_type="base")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_streaming_generate_simple_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ExLlamaV2StreamingGenerator.generate_simple``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="exllamav2")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            prompt = ""
            if args:
                prompt = str(args[0]) if args[0] else ""
            elif "prompt" in kwargs:
                prompt = str(kwargs["prompt"]) if kwargs["prompt"] else ""

            output_text = str(result) if result else ""
            tokens_in = _estimate_token_count(prompt)
            tokens_out = _estimate_token_count(output_text)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_exllamav2(result, model, args, kwargs, generator_type="streaming")
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_exllamav2(
    result, request_model: str, args: tuple, kwargs: dict,
    generator_type: str = "base",
) -> None:
    """Record an ExLlamaV2 call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    # Extract prompt
    prompt = ""
    if args:
        prompt = str(args[0]) if args[0] else ""
    elif "prompt" in kwargs:
        prompt = str(kwargs["prompt"]) if kwargs["prompt"] else ""

    output_text = str(result) if result else ""
    tokens_in = _estimate_token_count(prompt)
    tokens_out = _estimate_token_count(output_text)

    call_data = {
        "model": request_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "task": f"exllamav2.generate_simple ({generator_type})",
        "prompt_preview": prompt[:500] if prompt else "",
        "response_preview": output_text[:500] if output_text else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
