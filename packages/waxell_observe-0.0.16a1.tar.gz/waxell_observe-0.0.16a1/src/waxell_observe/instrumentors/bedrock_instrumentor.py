"""AWS Bedrock auto-instrumentor for waxell-observe.

Monkey-patches ``botocore.client.BaseClient._make_api_call`` to intercept
Bedrock Runtime ``Converse`` and ``InvokeModel`` operations, emitting
OTel spans and recording to the Waxell HTTP API.

Bedrock Converse response format:
  - ``response['usage']['inputTokens']`` / ``outputTokens``
  - ``response['stopReason']``
  - ``response['output']['message']['content'][0]['text']``

Titan Embedding (via InvokeModel) response format:
  - ``body['embedding']``          — vector (list of floats)
  - ``body['inputTextTokenCount']`` — input token count

When the model ID contains an embedding model pattern (e.g.
``amazon.titan-embed-text-v2``), an embedding span is created instead
of an LLM span.

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Operations we instrument on bedrock-runtime
_BEDROCK_OPERATIONS = {"Converse", "ConverseStream", "InvokeModel", "InvokeModelWithResponseStream"}

# Model ID patterns that indicate an embedding model (checked via substring match)
_EMBEDDING_MODEL_PATTERNS = {"embed", "titan-embed", "cohere-embed"}


class BedrockInstrumentor(BaseInstrumentor):
    """Instrumentor for AWS Bedrock Runtime via boto3/botocore.

    Patches ``BaseClient._make_api_call`` and filters to bedrock-runtime
    operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import botocore.client  # noqa: F401
        except ImportError:
            logger.debug("botocore not installed -- skipping Bedrock instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Bedrock instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "botocore.client",
                "BaseClient._make_api_call",
                _api_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch botocore: %s", exc)
            return False

        self._instrumented = True
        logger.debug("Bedrock Runtime instrumented via botocore")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import botocore.client as mod

            if hasattr(mod.BaseClient._make_api_call, "__wrapped__"):
                mod.BaseClient._make_api_call = mod.BaseClient._make_api_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Bedrock Runtime uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_bedrock_runtime(instance) -> bool:
    """Check if the botocore client is a bedrock-runtime client."""
    try:
        service_model = getattr(instance, "_service_model", None)
        if service_model:
            service_name = getattr(service_model, "service_name", "")
            return service_name == "bedrock-runtime"
        # Fallback: check endpoint URL
        endpoint = getattr(instance, "_endpoint", None)
        if endpoint:
            host = str(getattr(endpoint, "host", ""))
            return "bedrock-runtime" in host or "bedrock" in host
    except Exception:
        pass
    return False


def _extract_model_from_kwargs(api_params: dict) -> str:
    """Extract the model ID from Bedrock API parameters."""
    return api_params.get("modelId", "unknown")


def _is_embedding_model(model_id: str) -> bool:
    """Check if the model ID indicates an embedding model."""
    model_lower = model_id.lower()
    return any(pattern in model_lower for pattern in _EMBEDDING_MODEL_PATTERNS)


def _extract_converse_usage(response: dict) -> tuple[int, int]:
    """Extract tokens from Converse response."""
    usage = response.get("usage", {})
    return usage.get("inputTokens", 0), usage.get("outputTokens", 0)


def _extract_converse_text(response: dict) -> str:
    """Extract text from Converse response."""
    try:
        output = response.get("output", {})
        message = output.get("message", {})
        content = message.get("content", [])
        if content and isinstance(content, list):
            return content[0].get("text", "")
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


def _api_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseClient._make_api_call``.

    Only instruments bedrock-runtime Converse/InvokeModel operations.
    All other API calls pass through untouched.
    """
    # args[0] = operation_name, args[1] = api_params
    operation_name = args[0] if args else kwargs.get("operation_name", "")
    api_params = args[1] if len(args) > 1 else kwargs.get("api_params", {})

    # Only instrument bedrock-runtime operations we care about
    if operation_name not in _BEDROCK_OPERATIONS or not _is_bedrock_runtime(instance):
        return wrapped(*args, **kwargs)

    # --- Prompt guard for Converse ---
    _guard_error = None
    if operation_name == "Converse":
        try:
            from ._guard import check_prompt, PromptGuardError

            messages = api_params.get("messages", [])
            guard_messages = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", [])
                text = ""
                if isinstance(content, list) and content:
                    text = content[0].get("text", "")
                elif isinstance(content, str):
                    text = content
                guard_messages.append({"role": role, "content": text})

            model = _extract_model_from_kwargs(api_params)
            guard_result = check_prompt(guard_messages, model=model)
            if guard_result:
                if not guard_result.passed and guard_result.action == "block":
                    _guard_error = PromptGuardError(guard_result)
        except Exception:
            pass
    if _guard_error is not None:
        raise _guard_error

    model = _extract_model_from_kwargs(api_params)

    # --- Embedding model branch (InvokeModel with embedding model) ---
    if operation_name == "InvokeModel" and _is_embedding_model(model):
        try:
            from ..tracing.spans import start_embedding_span
            from ..tracing.attributes import WaxellAttributes
            from ..cost import estimate_embedding_cost
        except Exception:
            return wrapped(*args, **kwargs)

        try:
            span = start_embedding_span(model=model, provider_name="bedrock", input_count=1)
        except Exception:
            return wrapped(*args, **kwargs)

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise
        else:
            dimensions = 0
            tokens = 0
            cost = 0.0
            try:
                import json
                import io

                body = response.get("body", b"")
                if hasattr(body, "read"):
                    body_bytes = body.read()
                    # Reset stream for user
                    response["body"] = io.BytesIO(body_bytes)
                    body_json = json.loads(body_bytes)
                    embedding = body_json.get("embedding", [])
                    dimensions = len(embedding)
                    tokens = body_json.get("inputTextTokenCount", 0) or 0

                cost = estimate_embedding_cost(model, tokens, "bedrock")

                span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
                span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
                span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
                span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, 1)
                span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
            except Exception as attr_exc:
                logger.debug("Failed to set embedding span attributes: %s", attr_exc)

            try:
                _record_http_bedrock_embed(model, tokens, dimensions, cost)
            except Exception:
                pass

            return response
        finally:
            span.end()

    # --- Standard LLM span branch ---
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_llm_span(model=model, provider_name="bedrock")
    except Exception:
        return wrapped(*args, **kwargs)

    # Streaming operations (ConverseStream, InvokeModelWithResponseStream)
    if operation_name in ("ConverseStream", "InvokeModelWithResponseStream"):
        try:
            response = wrapped(*args, **kwargs)
            try:
                from ._stream_wrappers import BedrockStreamWrapper
                # Wrap the EventStream inside the response dict
                if isinstance(response, dict) and "stream" in response:
                    response["stream"] = BedrockStreamWrapper(response["stream"], span, model)
                else:
                    # Unexpected format -- end span to avoid leak
                    span.end()
            except Exception:
                try:
                    span.end()
                except Exception:
                    pass
            return response
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if operation_name == "Converse":
                tokens_in, tokens_out = _extract_converse_usage(response)
                stop_reason = response.get("stopReason", "")
            elif operation_name == "InvokeModel":
                # InvokeModel returns raw bytes -- response format varies by model
                tokens_in, tokens_out = 0, 0
                stop_reason = ""
                try:
                    import json
                    body = response.get("body", b"")
                    if hasattr(body, "read"):
                        body_bytes = body.read()
                        # Reset stream for user
                        import io
                        response["body"] = io.BytesIO(body_bytes)
                        body_json = json.loads(body_bytes)
                        # Try common patterns
                        usage = body_json.get("usage", {})
                        tokens_in = usage.get("input_tokens", usage.get("prompt_tokens", 0))
                        tokens_out = usage.get("output_tokens", usage.get("completion_tokens", 0))
                        stop_reason = body_json.get("stop_reason", "")
                except Exception:
                    pass
            else:
                tokens_in, tokens_out = 0, 0
                stop_reason = ""

            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reasons = [stop_reason] if stop_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_bedrock(response, model, operation_name, api_params)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_bedrock(response: dict, model: str, operation: str, api_params: dict) -> None:
    """Record a Bedrock LLM call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    if operation == "Converse":
        tokens_in, tokens_out = _extract_converse_usage(response)
    else:
        tokens_in, tokens_out = 0, 0

    cost = estimate_cost(model, tokens_in, tokens_out)

    # Prompt preview from Converse messages
    prompt_preview = ""
    if operation == "Converse":
        messages = api_params.get("messages", [])
        if messages:
            content = messages[0].get("content", [])
            if isinstance(content, list) and content:
                prompt_preview = str(content[0].get("text", ""))[:500]
            elif isinstance(content, str):
                prompt_preview = content[:500]

    response_preview = ""
    if operation == "Converse":
        response_preview = _extract_converse_text(response)[:500]

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": operation,
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool use + decisions from Converse response
    try:
        if operation == "Converse":
            output = response.get("output", {})
            message = output.get("message", {})
            content = message.get("content", [])
            tool_calls = []
            for block in content:
                if "toolUse" in block:
                    tool = block["toolUse"]
                    tool_calls.append({
                        "name": tool.get("name", "unknown"),
                        "input": tool.get("input", {}),
                        "id": tool.get("toolUseId", ""),
                    })
            if tool_calls:
                from ._auto_decision import record_tool_decisions

                # Bedrock Converse uses toolConfig.tools[].toolSpec.name
                available = []
                tool_config = api_params.get("toolConfig", {})
                for t in tool_config.get("tools", []):
                    spec = t.get("toolSpec", {})
                    if "name" in spec:
                        available.append(spec["name"])
                record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code


def _record_http_bedrock_embed(model: str, tokens: int, dimensions: int, cost: float) -> None:
    """Record a Bedrock embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "bedrock.embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
