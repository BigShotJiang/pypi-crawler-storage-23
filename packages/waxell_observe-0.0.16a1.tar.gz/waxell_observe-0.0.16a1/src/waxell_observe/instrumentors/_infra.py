"""Auto-instrument standard infrastructure libraries via OpenTelemetry.

This module activates standard OTel instrumentors for infrastructure libraries
(HTTP clients, databases, caches, message queues, etc.) so that agent traces
include everything the agent touches — not just LLM calls.

Works in two scenarios:
  A) User has no OTel setup — we instrument everything for them.
  B) User already has OTel — their instrumentors are already active (our call
     is a safe no-op due to OTel's singleton guard), and their spans already
     flow into Waxell via _hook_global_provider().
"""

from __future__ import annotations

import importlib
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Comma-delimited URL patterns to exclude from HTTP instrumentors.
# Prevents the tracing system from tracing itself.
_HTTP_EXCLUDED_URLS = "api/v1/observe,api/v1/policy,api/health"

# Registry of OTel instrumentors to activate.
# Format: (instrumentor_module, class_name, target_library, instrument_kwargs)
#
# target_library is the import name used to detect if the library is installed.
# instrument_kwargs are passed to instrumentor.instrument(**kwargs).
_INFRA_INSTRUMENTORS = [
    # ---- HTTP Clients ----
    # Note: httpx does not support excluded_urls — we filter in WaxellSpanProcessor instead
    ("opentelemetry.instrumentation.httpx", "HTTPXClientInstrumentor", "httpx", {}),
    ("opentelemetry.instrumentation.requests", "RequestsInstrumentor", "requests",
     {"excluded_urls": _HTTP_EXCLUDED_URLS}),
    ("opentelemetry.instrumentation.urllib3", "URLLib3Instrumentor", "urllib3",
     {"excluded_urls": _HTTP_EXCLUDED_URLS}),
    ("opentelemetry.instrumentation.aiohttp_client", "AioHttpClientInstrumentor", "aiohttp", {}),

    # ---- Databases ----
    ("opentelemetry.instrumentation.psycopg2", "Psycopg2Instrumentor", "psycopg2", {}),
    ("opentelemetry.instrumentation.psycopg", "PsycopgInstrumentor", "psycopg", {}),
    ("opentelemetry.instrumentation.asyncpg", "AsyncPGInstrumentor", "asyncpg", {}),
    ("opentelemetry.instrumentation.aiopg", "AiopgInstrumentor", "aiopg", {}),
    ("opentelemetry.instrumentation.sqlalchemy", "SQLAlchemyInstrumentor", "sqlalchemy", {}),
    ("opentelemetry.instrumentation.pymongo", "PymongoInstrumentor", "pymongo", {}),
    ("opentelemetry.instrumentation.pymysql", "PyMySQLInstrumentor", "pymysql", {}),
    ("opentelemetry.instrumentation.mysqlclient", "MySQLClientInstrumentor", "MySQLdb", {}),
    ("opentelemetry.instrumentation.pymssql", "PyMSSQLInstrumentor", "pymssql", {}),
    ("opentelemetry.instrumentation.sqlite3", "SQLite3Instrumentor", "sqlite3", {}),
    ("opentelemetry.instrumentation.elasticsearch", "ElasticsearchInstrumentor", "elasticsearch", {}),
    ("opentelemetry.instrumentation.cassandra", "CassandraInstrumentor", "cassandra", {}),
    ("opentelemetry.instrumentation.tortoiseorm", "TortoiseORMInstrumentor", "tortoise", {}),

    # ---- Caching ----
    ("opentelemetry.instrumentation.redis", "RedisInstrumentor", "redis", {}),
    ("opentelemetry.instrumentation.pymemcache", "PymemcacheInstrumentor", "pymemcache", {}),

    # ---- Message Queues & Task Brokers ----
    ("opentelemetry.instrumentation.celery", "CeleryInstrumentor", "celery", {}),
    ("opentelemetry.instrumentation.kafka", "KafkaInstrumentor", "kafka", {}),
    ("opentelemetry.instrumentation.confluent_kafka", "ConfluentKafkaInstrumentor", "confluent_kafka", {}),
    ("opentelemetry.instrumentation.pika", "PikaInstrumentor", "pika", {}),
    ("opentelemetry.instrumentation.aio_pika", "AioPikaInstrumentor", "aio_pika", {}),
    ("opentelemetry.instrumentation.aiokafka", "AIOKafkaInstrumentor", "aiokafka", {}),
    ("opentelemetry.instrumentation.remoulade", "RemouladeInstrumentor", "remoulade", {}),

    # ---- Cloud / RPC ----
    ("opentelemetry.instrumentation.botocore", "BotocoreInstrumentor", "botocore", {}),
    ("opentelemetry.instrumentation.boto3sqs", "Boto3SQSInstrumentor", "boto3", {}),
    ("opentelemetry.instrumentation.grpc", "GrpcInstrumentorClient", "grpc", {}),
]

# Active instrumentor instances, keyed by target library name.
# Used for clean uninstrumentation on shutdown.
_active: dict[str, object] = {}


def instrument_infra(
    libraries: Optional[list[str]] = None,
    exclude: Optional[list[str]] = None,
) -> dict[str, bool]:
    """Detect and instrument installed infrastructure libraries.

    Args:
        libraries: If set, only instrument these specific libraries (allowlist).
            Uses target library import names (e.g. ``["redis", "httpx"]``).
        exclude: If set, instrument everything except these (blocklist).
            Mutually exclusive with ``libraries`` — if both set, ``libraries`` wins.

    Returns:
        Dict mapping library name to whether it was successfully instrumented.
        Libraries that aren't installed are silently skipped (not in results).
    """
    results: dict[str, bool] = {}

    for module_path, class_name, lib_name, kwargs in _INFRA_INSTRUMENTORS:
        # Apply allowlist filter
        if libraries is not None and lib_name not in libraries:
            continue

        # Apply blocklist filter
        if exclude is not None and lib_name in exclude:
            continue

        # Check if the target library is installed
        try:
            importlib.import_module(lib_name)
        except ImportError:
            continue  # Target lib not installed — skip silently

        # Check if the instrumentor package is installed and activate it
        try:
            mod = importlib.import_module(module_path)
            instrumentor_cls = getattr(mod, class_name)
            instrumentor = instrumentor_cls()
            instrumentor.instrument(**kwargs)
            _active[lib_name] = instrumentor
            results[lib_name] = True
            logger.debug("Instrumented %s via %s", lib_name, class_name)
        except Exception as exc:
            logger.debug("Failed to instrument %s: %s", lib_name, exc)
            results[lib_name] = False

    return results


def uninstrument_infra() -> None:
    """Remove all infrastructure instrumentation.

    Called during shutdown to cleanly remove monkey-patches.
    """
    for lib_name, instrumentor in list(_active.items()):
        try:
            instrumentor.uninstrument()
        except Exception:
            logger.debug("Failed to uninstrument %s", lib_name, exc_info=True)
    _active.clear()
