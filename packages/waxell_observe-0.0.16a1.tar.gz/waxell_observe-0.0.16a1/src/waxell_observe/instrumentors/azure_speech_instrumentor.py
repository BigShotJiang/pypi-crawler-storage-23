"""Azure Cognitive Services Speech auto-instrumentor for waxell-observe.

Monkey-patches Azure Speech SDK methods to emit OTel step spans for
speech-to-text (STT) operations:
  - ``azure.cognitiveservices.speech.SpeechRecognizer.recognize_once``       -- sync STT
  - ``azure.cognitiveservices.speech.SpeechRecognizer.recognize_once_async`` -- async (returns Future, wraps .get())

The Azure Speech SDK returns ``SpeechRecognitionResult`` objects:
  - ``result.text``       -- recognized transcript
  - ``result.reason``     -- RecognitionReason enum (e.g. RecognizedSpeech)
  - ``result.duration``   -- duration in ticks (100ns units)

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AzureSpeechInstrumentor(BaseInstrumentor):
    """Instrumentor for the Azure Cognitive Services Speech SDK.

    Patches ``SpeechRecognizer.recognize_once`` (sync) and
    ``SpeechRecognizer.recognize_once_async`` (async via Future).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import azure.cognitiveservices.speech  # noqa: F401
        except ImportError:
            logger.debug("azure.cognitiveservices.speech not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Azure Speech instrumentation")
            return False

        patched = False

        # Patch SpeechRecognizer.recognize_once (sync)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechRecognizer.recognize_once",
                _sync_recognize_once_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure SpeechRecognizer.recognize_once: %s", exc)

        # Patch SpeechRecognizer.recognize_once_async (returns Future)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechRecognizer.recognize_once_async",
                _async_recognize_once_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure SpeechRecognizer.recognize_once_async: %s", exc)

        if not patched:
            logger.debug("Could not find any Azure Speech methods to patch")
            return False

        self._instrumented = True
        logger.debug("Azure Speech-to-Text instrumented (recognize_once + recognize_once_async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import azure.cognitiveservices.speech as mod

            cls = getattr(mod, "SpeechRecognizer", None)
            if cls is not None:
                for attr in ("recognize_once", "recognize_once_async"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Azure Speech-to-Text uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Azure Speech results
# ---------------------------------------------------------------------------


def _extract_stt_data(result, recognizer=None) -> dict:
    """Extract transcript, reason, duration, language from result."""
    data = {
        "transcript": "",
        "reason": "",
        "duration_ms": 0.0,
        "language": "",
    }

    if result is None:
        return data

    try:
        data["transcript"] = getattr(result, "text", "") or ""
    except Exception:
        pass

    try:
        reason = getattr(result, "reason", None)
        if reason is not None:
            data["reason"] = str(reason)
    except Exception:
        pass

    try:
        # Azure duration is in ticks (100ns units), convert to ms
        duration_ticks = getattr(result, "duration", 0) or 0
        if duration_ticks:
            data["duration_ms"] = duration_ticks / 10_000.0  # 100ns -> ms
    except Exception:
        pass

    # Try to extract language from the recognizer's speech config
    if recognizer is not None:
        try:
            speech_config = getattr(recognizer, "_speech_config", None)
            if speech_config is None:
                speech_config = getattr(recognizer, "properties", None)
            if speech_config is not None:
                lang = getattr(speech_config, "speech_recognition_language", None)
                if lang:
                    data["language"] = str(lang)
        except Exception:
            pass

    return data


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


def _sync_recognize_once_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SpeechRecognizer.recognize_once``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="azure.stt.recognize")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(result, recognizer=instance)
            _set_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Azure Speech span attributes: %s", attr_exc)

        try:
            _record_stt_call("azure.stt.recognize", data, latency)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper (wraps Future.get())
# ---------------------------------------------------------------------------


def _async_recognize_once_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``SpeechRecognizer.recognize_once_async``.

    ``recognize_once_async`` returns an Azure ``ResultFuture``. We wrap
    the future's ``.get()`` method so the span covers the full
    recognition duration.
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="azure.stt.recognize")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        future = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    # Wrap the future's .get() to capture the result
    original_get = future.get

    def _wrapped_get(*get_args, **get_kwargs):
        try:
            result = original_get(*get_args, **get_kwargs)
        except Exception as exc:
            _record_error(span, exc)
            span.end()
            raise
        else:
            latency = time.monotonic() - t0
            try:
                data = _extract_stt_data(result, recognizer=instance)
                _set_span_attributes(span, data, latency)
            except Exception as attr_exc:
                logger.debug("Failed to set Azure Speech async span attributes: %s", attr_exc)

            try:
                _record_stt_call("azure.stt.recognize", data, latency)
            except Exception:
                pass

            return result
        finally:
            span.end()

    try:
        future.get = _wrapped_get
    except Exception:
        # If we can't wrap .get(), end span and return original future
        span.end()

    return future


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes for an Azure Speech STT operation."""
    if data["language"]:
        span.set_attribute("waxell.azure_speech.language", data["language"])
    if data["reason"]:
        span.set_attribute("waxell.azure_speech.reason", data["reason"])
    if data["transcript"]:
        span.set_attribute("waxell.azure_speech.transcript_preview", data["transcript"][:500])
    if data["duration_ms"]:
        span.set_attribute("waxell.azure_speech.duration_ms", round(data["duration_ms"], 2))
    span.set_attribute("waxell.azure_speech.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_stt_call(task: str, data: dict, latency: float) -> None:
    """Record an Azure Speech STT call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": "azure-speech-stt",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[azure stt, language={data.get('language', 'auto')}]",
        "response_preview": str(data.get("transcript", ""))[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
