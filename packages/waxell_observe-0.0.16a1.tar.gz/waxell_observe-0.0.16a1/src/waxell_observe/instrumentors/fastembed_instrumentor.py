"""FastEmbed auto-instrumentor for waxell-observe.

Monkey-patches ``fastembed.TextEmbedding.embed``, ``query_embed``, and
``passage_embed`` to emit embedding spans tracking local embedding
generation.

Qdrant's FastEmbed is a lightweight CPU-first embedding library that
provides local embedding generation without API calls. Since inference
is local, cost is always 0.0.

Note: ``embed()``, ``query_embed()``, and ``passage_embed()`` return
generators. The wrappers consume and re-yield while tracking metadata.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FastEmbedInstrumentor(BaseInstrumentor):
    """Instrumentor for the FastEmbed library (``fastembed`` package).

    Patches ``TextEmbedding.embed``, ``TextEmbedding.query_embed``, and
    ``TextEmbedding.passage_embed`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import fastembed  # noqa: F401
        except ImportError:
            logger.debug("fastembed package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping FastEmbed instrumentation")
            return False

        patched = False

        # TextEmbedding.embed
        try:
            wrapt.wrap_function_wrapper(
                "fastembed",
                "TextEmbedding.embed",
                _sync_embed_wrapper,
            )
            patched = True
            logger.debug("FastEmbed TextEmbedding.embed patched")
        except Exception:
            pass

        # TextEmbedding.query_embed
        try:
            wrapt.wrap_function_wrapper(
                "fastembed",
                "TextEmbedding.query_embed",
                _sync_query_embed_wrapper,
            )
            logger.debug("FastEmbed TextEmbedding.query_embed patched")
        except Exception:
            pass

        # TextEmbedding.passage_embed
        try:
            wrapt.wrap_function_wrapper(
                "fastembed",
                "TextEmbedding.passage_embed",
                _sync_passage_embed_wrapper,
            )
            logger.debug("FastEmbed TextEmbedding.passage_embed patched")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find FastEmbed TextEmbedding.embed to patch")
            return False

        self._instrumented = True
        logger.debug("FastEmbed instrumented (embed + query_embed + passage_embed)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import fastembed

            for method_name in ("embed", "query_embed", "passage_embed"):
                method = getattr(fastembed.TextEmbedding, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(
                        fastembed.TextEmbedding,
                        method_name,
                        method.__wrapped__,
                    )
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("FastEmbed uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a TextEmbedding instance."""
    try:
        name = getattr(instance, "model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    try:
        name = getattr(instance, "_model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    try:
        name = getattr(instance, "model", None)
        if name:
            return str(name)
    except Exception:
        pass

    return "fastembed"


def _get_dimensions_from_array(arr) -> int:
    """Extract dimensions from a numpy array or list."""
    try:
        if hasattr(arr, "shape"):
            return int(arr.shape[-1]) if len(arr.shape) > 0 else 0
        if isinstance(arr, list):
            return len(arr)
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``TextEmbedding.embed``.

    embed() returns a generator yielding numpy arrays. We consume the
    generator, emit a span with the full count, then re-yield the results.
    """
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)

    # Count inputs -- first positional arg is the texts
    texts = args[0] if args else kwargs.get("documents", kwargs.get("texts", []))
    if isinstance(texts, str):
        input_count = 1
    elif isinstance(texts, list):
        input_count = len(texts)
    else:
        # Could be a generator; we can't know the count upfront
        input_count = 0

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="fastembed",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        generator = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    # Consume the generator to collect results and extract metadata
    try:
        collected = list(generator)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            actual_count = len(collected)
            dimensions = _get_dimensions_from_array(collected[0]) if collected else 0

            if input_count == 0:
                input_count = actual_count

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
        except Exception as attr_exc:
            logger.debug("Failed to set FastEmbed span attributes: %s", attr_exc)

        try:
            _record_http_fastembed(model_name, input_count, dimensions)
        except Exception:
            pass

        # Re-yield the collected results as a generator
        return iter(collected)
    finally:
        span.end()


def _sync_query_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``TextEmbedding.query_embed``.

    query_embed() embeds a single query string and returns a generator.
    """
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)
    input_count = 1

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="fastembed",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        generator = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    try:
        collected = list(generator)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = _get_dimensions_from_array(collected[0]) if collected else 0

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception:
            pass

        try:
            _record_http_fastembed(model_name, input_count, dimensions)
        except Exception:
            pass

        return iter(collected)
    finally:
        span.end()


def _sync_passage_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``TextEmbedding.passage_embed``.

    passage_embed() embeds passage texts and returns a generator.
    """
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)

    texts = args[0] if args else kwargs.get("texts", kwargs.get("passages", []))
    if isinstance(texts, str):
        input_count = 1
    elif isinstance(texts, list):
        input_count = len(texts)
    else:
        input_count = 0

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="fastembed",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        generator = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    try:
        collected = list(generator)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            actual_count = len(collected)
            dimensions = _get_dimensions_from_array(collected[0]) if collected else 0

            if input_count == 0:
                input_count = actual_count

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception:
            pass

        try:
            _record_http_fastembed(model_name, input_count, dimensions)
        except Exception:
            pass

        return iter(collected)
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_fastembed(
    model: str, input_count: int, dimensions: int = 0
) -> None:
    """Record a FastEmbed embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding:fastembed",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
