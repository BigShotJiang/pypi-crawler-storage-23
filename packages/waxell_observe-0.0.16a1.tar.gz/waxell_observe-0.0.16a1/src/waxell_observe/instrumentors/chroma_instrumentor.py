"""ChromaDB auto-instrumentor for waxell-observe.

Monkey-patches ChromaDB's Collection methods to emit OTel spans and record
to the Waxell HTTP API.

Patched methods:
  - Collection.query  (retrieval span)
  - Collection.get    (retrieval span)
  - Collection.add    (tool span)
  - Collection.delete (tool span)
  - Collection.update (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's ChromaDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# All method paths that this instrumentor patches.
# Used by uninstrument() to restore originals via __wrapped__.
_PATCHED_METHODS = [
    ("chromadb.api.models.Collection", "Collection.query"),
    ("chromadb.api.models.Collection", "Collection.get"),
    ("chromadb.api.models.Collection", "Collection.add"),
    ("chromadb.api.models.Collection", "Collection.delete"),
    ("chromadb.api.models.Collection", "Collection.update"),
]


class ChromaInstrumentor(BaseInstrumentor):
    """Instrumentor for the ChromaDB Python SDK (``chromadb`` package).

    Patches Collection query/get for retrieval spans and add/delete/update
    for tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import chromadb  # noqa: F401
        except ImportError:
            logger.debug("chromadb package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping ChromaDB instrumentation"
            )
            return False

        patched = False

        try:
            wrapt.wrap_function_wrapper(
                "chromadb.api.models.Collection",
                "Collection.query",
                _query_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Collection.query: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "chromadb.api.models.Collection",
                "Collection.get",
                _get_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Collection.get: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "chromadb.api.models.Collection",
                "Collection.add",
                _add_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Collection.add: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "chromadb.api.models.Collection",
                "Collection.delete",
                _delete_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Collection.delete: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "chromadb.api.models.Collection",
                "Collection.update",
                _update_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Collection.update: %s", exc)

        if not patched:
            logger.debug("Could not find any ChromaDB Collection methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "ChromaDB Collection instrumented (query, get, add, delete, update)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        import importlib

        method_map = {
            "query": "_query_wrapper",
            "get": "_get_wrapper",
            "add": "_add_wrapper",
            "delete": "_delete_wrapper",
            "update": "_update_wrapper",
        }

        try:
            mod = importlib.import_module("chromadb.api.models.Collection")
            cls = getattr(mod, "Collection", None)
            if cls is not None:
                for method_name in method_map:
                    try:
                        method = getattr(cls, method_name, None)
                        if method is not None and hasattr(method, "__wrapped__"):
                            setattr(cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]
                    except Exception:
                        pass
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ChromaDB Collection uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Retrieval wrappers
# ---------------------------------------------------------------------------


def _query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Collection.query (vector similarity search)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract query text or embeddings for the span label
    query_texts = kwargs.get("query_texts")
    query_embeddings = kwargs.get("query_embeddings")
    n_results = kwargs.get("n_results", 10)

    if query_texts:
        query_label = (
            str(query_texts[0]) if isinstance(query_texts, list) else str(query_texts)
        )
    elif query_embeddings is not None:
        query_label = "<embedding vector>"
    else:
        # ChromaDB also accepts positional args: query_texts is first
        query_label = str(args[0]) if args else "<unknown>"

    try:
        span = start_retrieval_span(query=query_label, source="chroma")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Count results -- chromadb returns a QueryResult dict with "ids" key
            results_count = 0
            if response is not None:
                ids = (
                    response.get("ids")
                    if isinstance(response, dict)
                    else getattr(response, "ids", None)
                )
                if ids is not None:
                    if isinstance(ids, list) and len(ids) > 0:
                        # ids is a list of lists (one per query)
                        if isinstance(ids[0], list):
                            results_count = sum(len(sublist) for sublist in ids)
                        else:
                            results_count = len(ids)

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute("waxell.retrieval.results_count", results_count)
            span.set_attribute("waxell.retrieval.n_results", n_results)
            if query_texts:
                span.set_attribute(
                    "waxell.retrieval.query_count",
                    len(query_texts) if isinstance(query_texts, list) else 1,
                )
        except Exception as attr_exc:
            logger.debug("Failed to set ChromaDB query span attributes: %s", attr_exc)

        try:
            _record_retrieval(query_label, results_count, n_results)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _get_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Collection.get (fetch by IDs or filter)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # get() is typically a lookup by id/where filter rather than semantic search
    ids = kwargs.get("ids") or (args[0] if args else None)
    where = kwargs.get("where")

    if ids is not None:
        query_label = f"get ids={str(ids)[:200]}"
    elif where is not None:
        query_label = f"get where={str(where)[:200]}"
    else:
        query_label = "get"

    try:
        span = start_retrieval_span(query=query_label, source="chroma")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = 0
            if response is not None:
                resp_ids = (
                    response.get("ids")
                    if isinstance(response, dict)
                    else getattr(response, "ids", None)
                )
                if resp_ids is not None:
                    results_count = len(resp_ids)

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute("waxell.retrieval.results_count", results_count)
        except Exception as attr_exc:
            logger.debug("Failed to set ChromaDB get span attributes: %s", attr_exc)

        try:
            _record_retrieval(query_label, results_count, limit=None)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Write operation wrappers
# ---------------------------------------------------------------------------


def _add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Collection.add (insert documents/embeddings)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Count documents being added
    ids = kwargs.get("ids") or (args[0] if args else None)
    doc_count = len(ids) if isinstance(ids, list) else 1

    try:
        span = start_tool_span(tool_name="chroma.add", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.documents_written", doc_count)
            span.set_attribute("waxell.vectordb.operation", "add")
        except Exception as attr_exc:
            logger.debug("Failed to set ChromaDB add span attributes: %s", attr_exc)

        try:
            _record_write_op("add", doc_count)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Collection.delete (remove documents by IDs or filter)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    ids = kwargs.get("ids") or (args[0] if args else None)
    doc_count = len(ids) if isinstance(ids, list) else 0

    try:
        span = start_tool_span(tool_name="chroma.delete", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.documents_written", doc_count)
            span.set_attribute("waxell.vectordb.operation", "delete")
        except Exception as attr_exc:
            logger.debug("Failed to set ChromaDB delete span attributes: %s", attr_exc)

        try:
            _record_write_op("delete", doc_count)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _update_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Collection.update (update existing documents)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    ids = kwargs.get("ids") or (args[0] if args else None)
    doc_count = len(ids) if isinstance(ids, list) else 1

    try:
        span = start_tool_span(tool_name="chroma.update", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.documents_written", doc_count)
            span.set_attribute("waxell.vectordb.operation", "update")
        except Exception as attr_exc:
            logger.debug("Failed to set ChromaDB update span attributes: %s", attr_exc)

        try:
            _record_write_op("update", doc_count)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording helpers
# ---------------------------------------------------------------------------


def _record_retrieval(query: str, results_count: int, limit: int | None) -> None:
    """Record a ChromaDB retrieval to the HTTP path (context or collector)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=str(query),
            source="chroma",
            results_count=results_count,
        )


def _record_write_op(operation: str, doc_count: int) -> None:
    """Record a ChromaDB write operation to the context (if active)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        try:
            ctx.record_tool_call(
                name=f"chroma.{operation}",
                input={"doc_count": doc_count},
                tool_type="vectordb",
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
