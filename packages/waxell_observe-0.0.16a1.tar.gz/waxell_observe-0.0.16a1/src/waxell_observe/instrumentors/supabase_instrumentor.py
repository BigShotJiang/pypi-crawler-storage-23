"""Supabase pgvector auto-instrumentor for waxell-observe.

Monkey-patches Supabase Client methods to detect vector similarity search
operations and emit retrieval spans.

Patched methods:
  - ``supabase.Client.rpc``               (retrieval span, similarity search RPCs)
  - ``supabase.Client.table().select``     (retrieval span, vector search via select)
  - ``supabase._async.client.AsyncClient.rpc``  (retrieval span, async similarity search)

Non-vector operations are passed through without any span creation.
All wrapper code is wrapped in try/except -- never breaks the user's Supabase calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# RPC function names that typically indicate vector similarity search.
_SIMILARITY_RPC_NAMES = {
    "match_documents",
    "match_vectors",
    "similarity_search",
    "vector_search",
    "match_embeddings",
    "hybrid_search",
}


def _is_similarity_rpc(fn_name: str) -> bool:
    """Return True if the RPC function name suggests a vector similarity search."""
    if not fn_name or not isinstance(fn_name, str):
        return False
    fn_lower = fn_name.lower()
    # Check known function names
    if fn_lower in _SIMILARITY_RPC_NAMES:
        return True
    # Check partial matches for common patterns
    if "match" in fn_lower or "similarity" in fn_lower or "vector" in fn_lower:
        return True
    return False


class SupabaseInstrumentor(BaseInstrumentor):
    """Instrumentor for Supabase pgvector operations.

    Patches ``Client.rpc`` for RPC-based similarity search calls and
    ``Client.table`` select chains for vector-based queries.
    Only creates retrieval spans for operations that look like vector
    similarity searches.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import supabase  # noqa: F401
        except ImportError:
            logger.debug("supabase package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Supabase instrumentation")
            return False

        patched_any = False

        # --- Sync Client.rpc ---
        try:
            wrapt.wrap_function_wrapper(
                "supabase",
                "Client.rpc",
                _sync_rpc_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch supabase Client.rpc: %s", exc)

        # --- Sync Client.table (to intercept vector select chains) ---
        try:
            wrapt.wrap_function_wrapper(
                "supabase",
                "Client.table",
                _sync_table_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch supabase Client.table: %s", exc)

        # --- Async Client.rpc (may not exist in all versions) ---
        try:
            wrapt.wrap_function_wrapper(
                "supabase._async.client",
                "AsyncClient.rpc",
                _async_rpc_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch supabase AsyncClient.rpc: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any Supabase methods")
            return False

        self._instrumented = True
        logger.debug("Supabase instrumented (Client.rpc, Client.table, AsyncClient.rpc)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore sync Client
        try:
            import supabase

            client_cls = getattr(supabase, "Client", None)
            if client_cls is not None:
                for method_name in ("rpc", "table"):
                    method = getattr(client_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(client_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore async Client
        try:
            from supabase._async.client import AsyncClient

            method = getattr(AsyncClient, "rpc", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AsyncClient.rpc = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Supabase uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


def _extract_rpc_params(args, kwargs) -> tuple[str, dict]:
    """Extract RPC function name and params from call args."""
    fn_name = ""
    params = {}
    if args:
        fn_name = str(args[0]) if args[0] else ""
    else:
        fn_name = str(kwargs.get("fn", ""))

    if len(args) > 1:
        params = args[1] if isinstance(args[1], dict) else {}
    else:
        params = kwargs.get("params", {})

    return fn_name, params


def _extract_vector_metadata(params: dict) -> dict:
    """Extract vector search metadata from RPC parameters."""
    metadata = {}
    try:
        if isinstance(params, dict):
            # Common parameter names for vector similarity search RPCs
            query_embedding = params.get("query_embedding") or params.get("embedding")
            if query_embedding and isinstance(query_embedding, (list, tuple)):
                metadata["vector_dimensions"] = len(query_embedding)

            match_count = params.get("match_count") or params.get("limit") or params.get("k")
            if match_count is not None:
                metadata["match_count"] = int(match_count)

            threshold = params.get("match_threshold") or params.get("similarity_threshold") or params.get("threshold")
            if threshold is not None:
                metadata["similarity_threshold"] = float(threshold)

            table_name = params.get("table_name") or params.get("collection")
            if table_name:
                metadata["table_name"] = str(table_name)
    except Exception:
        pass
    return metadata


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_rpc_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for supabase Client.rpc -- only instruments similarity search RPCs."""
    fn_name, params = _extract_rpc_params(args, kwargs)
    if not _is_similarity_rpc(fn_name):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    vector_meta = _extract_vector_metadata(params)

    try:
        span = start_retrieval_span(query=_truncate(fn_name), source="supabase")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "postgresql")
            span.set_attribute("waxell.retrieval.operation", "rpc_similarity_search")
            span.set_attribute("waxell.retrieval.rpc_function", fn_name)
            if "vector_dimensions" in vector_meta:
                span.set_attribute("waxell.retrieval.vector_dimensions", vector_meta["vector_dimensions"])
            if "match_count" in vector_meta:
                span.set_attribute("waxell.retrieval.match_count", vector_meta["match_count"])
            if "similarity_threshold" in vector_meta:
                span.set_attribute("waxell.retrieval.similarity_threshold", vector_meta["similarity_threshold"])
            if "table_name" in vector_meta:
                span.set_attribute("waxell.retrieval.table_name", vector_meta["table_name"])
        except Exception as attr_exc:
            logger.debug("Failed to set Supabase rpc span attributes: %s", attr_exc)

        try:
            _record_supabase_retrieval(
                query=fn_name,
                operation="rpc_similarity_search",
                metadata=vector_meta,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_table_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for supabase Client.table -- records table name for downstream select instrumentation.

    This wrapper captures the table name being accessed. The actual span creation
    happens at the select/execute level, but we record context here.
    """
    table_name = ""
    if args:
        table_name = str(args[0]) if args[0] else ""
    else:
        table_name = str(kwargs.get("table_name", ""))

    try:
        result = wrapped(*args, **kwargs)
    except Exception:
        raise
    else:
        # Attach table name metadata to the query builder for downstream use
        try:
            if result is not None and table_name:
                result._waxell_table_name = table_name  # type: ignore[attr-defined]
        except Exception:
            pass
        return result


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_rpc_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for supabase AsyncClient.rpc -- only instruments similarity search RPCs."""
    fn_name, params = _extract_rpc_params(args, kwargs)
    if not _is_similarity_rpc(fn_name):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    vector_meta = _extract_vector_metadata(params)

    try:
        span = start_retrieval_span(query=_truncate(fn_name), source="supabase")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "postgresql")
            span.set_attribute("waxell.retrieval.operation", "rpc_similarity_search")
            span.set_attribute("waxell.retrieval.rpc_function", fn_name)
            if "vector_dimensions" in vector_meta:
                span.set_attribute("waxell.retrieval.vector_dimensions", vector_meta["vector_dimensions"])
            if "match_count" in vector_meta:
                span.set_attribute("waxell.retrieval.match_count", vector_meta["match_count"])
            if "similarity_threshold" in vector_meta:
                span.set_attribute("waxell.retrieval.similarity_threshold", vector_meta["similarity_threshold"])
            if "table_name" in vector_meta:
                span.set_attribute("waxell.retrieval.table_name", vector_meta["table_name"])
        except Exception as attr_exc:
            logger.debug("Failed to set Supabase async rpc span attributes: %s", attr_exc)

        try:
            _record_supabase_retrieval(
                query=fn_name,
                operation="rpc_similarity_search",
                metadata=vector_meta,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_supabase_retrieval(
    query: str,
    operation: str = "similarity_search",
    metadata: dict | None = None,
) -> None:
    """Record a Supabase vector retrieval operation to the context path.

    Supabase vector retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        results_count = 0
        if metadata and "match_count" in metadata:
            results_count = metadata["match_count"]
        ctx.record_retrieval(
            query=query,
            source="supabase",
            results_count=results_count,
        )
