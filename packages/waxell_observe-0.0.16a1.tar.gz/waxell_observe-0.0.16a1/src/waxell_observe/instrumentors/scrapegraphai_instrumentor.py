"""ScrapeGraphAI auto-instrumentor for waxell-observe.

Monkey-patches ``scrapegraphai`` graph classes to emit OTel tool spans
for web scraping operations commonly used in RAG pipelines:
  - ``SmartScraperGraph.run``  -- single page extraction via LLM
  - ``SearchGraph.run``        -- search + extract
  - ``SpeechGraph.run``        -- scrape + text-to-speech

These are HTTP-based tool operations, not LLM calls, so all spans use
``start_tool_span()`` instead of ``start_llm_span()``.

Cost is tracked externally by the underlying LLM provider, so cost is
always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ScrapeGraphAIInstrumentor(BaseInstrumentor):
    """Instrumentor for the ScrapeGraphAI library (``scrapegraphai`` package).

    Patches ``SmartScraperGraph.run``, ``SearchGraph.run``, and
    ``SpeechGraph.run``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import scrapegraphai  # noqa: F401
        except ImportError:
            logger.debug("scrapegraphai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping ScrapeGraphAI instrumentation")
            return False

        patched = False

        # Patch SmartScraperGraph.run
        try:
            wrapt.wrap_function_wrapper(
                "scrapegraphai.graphs.smart_scraper_graph",
                "SmartScraperGraph.run",
                _smart_scraper_graph_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch SmartScraperGraph.run: %s", exc)

        # Patch SearchGraph.run
        try:
            wrapt.wrap_function_wrapper(
                "scrapegraphai.graphs.search_graph",
                "SearchGraph.run",
                _search_graph_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch SearchGraph.run: %s", exc)

        # Patch SpeechGraph.run
        try:
            wrapt.wrap_function_wrapper(
                "scrapegraphai.graphs.speech_graph",
                "SpeechGraph.run",
                _speech_graph_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch SpeechGraph.run: %s", exc)

        if not patched:
            logger.debug("Could not find any ScrapeGraphAI graph classes to patch")
            return False

        self._instrumented = True
        logger.debug(
            "ScrapeGraphAI instrumented (SmartScraperGraph + SearchGraph + SpeechGraph)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        _restore = [
            ("scrapegraphai.graphs.smart_scraper_graph", "SmartScraperGraph"),
            ("scrapegraphai.graphs.search_graph", "SearchGraph"),
            ("scrapegraphai.graphs.speech_graph", "SpeechGraph"),
        ]

        for module_path, cls_name in _restore:
            try:
                import importlib

                mod = importlib.import_module(module_path)
                cls = getattr(mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "run", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "run", method.__wrapped__)
            except (ImportError, AttributeError, TypeError):
                pass

        self._instrumented = False
        logger.debug("ScrapeGraphAI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from ScrapeGraphAI graph instances/responses
# ---------------------------------------------------------------------------


def _truncate(value: str, max_len: int = 200) -> str:
    """Truncate a string for safe span attribute storage."""
    if not value or not isinstance(value, str):
        return ""
    return value[:max_len]


def _extract_graph_type(instance) -> str:
    """Extract the graph class name from the instance."""
    try:
        if instance is not None:
            return instance.__class__.__name__
    except Exception:
        pass
    return "unknown"


def _extract_prompt(instance, kwargs: dict) -> str:
    """Extract the user prompt from a graph instance or kwargs."""
    try:
        prompt = getattr(instance, "prompt", None)
        if prompt and isinstance(prompt, str):
            return prompt
    except Exception:
        pass

    prompt = kwargs.get("prompt", "")
    if prompt and isinstance(prompt, str):
        return prompt

    return ""


def _extract_source(instance, kwargs: dict) -> str:
    """Extract the source URL from a graph instance or kwargs."""
    try:
        source = getattr(instance, "source", None)
        if source and isinstance(source, str):
            return source
    except Exception:
        pass

    source = kwargs.get("source", "")
    if source and isinstance(source, str):
        return source

    return ""


def _extract_result_preview(response) -> str:
    """Extract a short content preview from a ScrapeGraphAI response.

    Responses can be dicts, strings, or objects with various structures.
    """
    if response is None:
        return ""

    try:
        # String response
        if isinstance(response, str):
            return response[:500]

        # Dict response -- look for common keys
        if isinstance(response, dict):
            # Try to serialize the dict for preview
            import json

            try:
                preview = json.dumps(response, default=str, ensure_ascii=False)
                return preview[:500]
            except Exception:
                return str(response)[:500]

        # Object with text/content attribute
        for attr in ("text", "content", "result"):
            val = getattr(response, attr, None)
            if val and isinstance(val, str):
                return val[:500]

        # Fallback to str representation
        return str(response)[:500]

    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _smart_scraper_graph_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SmartScraperGraph.run``."""
    return _graph_run_wrapper(
        wrapped, instance, args, kwargs, tool_name="scrapegraphai.SmartScraperGraph.run"
    )


def _search_graph_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SearchGraph.run``."""
    return _graph_run_wrapper(
        wrapped, instance, args, kwargs, tool_name="scrapegraphai.SearchGraph.run"
    )


def _speech_graph_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SpeechGraph.run``."""
    return _graph_run_wrapper(
        wrapped, instance, args, kwargs, tool_name="scrapegraphai.SpeechGraph.run"
    )


def _graph_run_wrapper(wrapped, instance, args, kwargs, *, tool_name: str):
    """Shared sync wrapper for all ScrapeGraphAI graph ``.run()`` methods."""
    graph_type = _extract_graph_type(instance)
    prompt = _extract_prompt(instance, kwargs)
    source = _extract_source(instance, kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name=tool_name, tool_type="web_scraper")
        span.set_attribute("waxell.scrapegraphai.graph_type", graph_type)
        if prompt:
            span.set_attribute("waxell.scrapegraphai.prompt", _truncate(prompt))
        if source:
            span.set_attribute("waxell.scrapegraphai.source", _truncate(source))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            preview = _extract_result_preview(response)
            if preview:
                span.set_attribute("waxell.scrapegraphai.result_preview", preview)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name=tool_name,
                graph_type=graph_type,
                prompt=prompt,
                source=source,
                response=response,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tool_call(
    tool_name: str,
    graph_type: str,
    prompt: str,
    source: str,
    response,
) -> None:
    """Record a ScrapeGraphAI tool call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    preview = _extract_result_preview(response)

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output = {}
        if preview:
            output["preview"] = preview
        if graph_type:
            output["graph_type"] = graph_type

        ctx.record_tool_call(
            name=tool_name,
            input={"prompt": _truncate(prompt), "source": _truncate(source)},
            output=output,
            tool_type="web_scraper",
            status="ok",
        )
    else:
        # Fall back to collector with an LLM-call-shaped dict
        call_data = {
            "model": "scrapegraphai",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "task": tool_name,
            "prompt_preview": _truncate(prompt),
            "response_preview": preview,
        }
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
