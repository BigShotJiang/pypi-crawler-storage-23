"""HuggingFace Text Embeddings Inference (TEI) auto-instrumentor for waxell-observe.

Monkey-patches ``huggingface_hub.InferenceClient.feature_extraction`` and
``huggingface_hub.InferenceClient.sentence_similarity`` to emit embedding
spans tracking remote embedding generation via TEI endpoints.

HuggingFace TEI is a high-performance inference server for embedding models.
Users typically interact with it through the ``huggingface_hub`` InferenceClient.
Cost is 0.0 for self-hosted TEI endpoints, but may vary for HF Inference API.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TEIInstrumentor(BaseInstrumentor):
    """Instrumentor for HuggingFace Text Embeddings Inference via huggingface_hub.

    Patches ``InferenceClient.feature_extraction`` and
    ``InferenceClient.sentence_similarity`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import huggingface_hub  # noqa: F401
        except ImportError:
            logger.debug("huggingface_hub package not installed -- skipping TEI instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping TEI instrumentation")
            return False

        patched = False

        # Patch InferenceClient.feature_extraction
        try:
            wrapt.wrap_function_wrapper(
                "huggingface_hub",
                "InferenceClient.feature_extraction",
                _sync_feature_extraction_wrapper,
            )
            patched = True
            logger.debug("InferenceClient.feature_extraction patched")
        except Exception as exc:
            logger.debug("Failed to patch InferenceClient.feature_extraction: %s", exc)

        # Patch InferenceClient.sentence_similarity
        try:
            wrapt.wrap_function_wrapper(
                "huggingface_hub",
                "InferenceClient.sentence_similarity",
                _sync_sentence_similarity_wrapper,
            )
            patched = True
            logger.debug("InferenceClient.sentence_similarity patched")
        except Exception as exc:
            logger.debug("Failed to patch InferenceClient.sentence_similarity: %s", exc)

        if not patched:
            logger.debug("Could not find any TEI methods to patch")
            return False

        self._instrumented = True
        logger.debug("TEI instrumented (feature_extraction + sentence_similarity)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import huggingface_hub

            for attr in ("feature_extraction", "sentence_similarity"):
                method = getattr(huggingface_hub.InferenceClient, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(
                        huggingface_hub.InferenceClient, attr, method.__wrapped__
                    )  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("TEI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_from_instance(instance) -> str:
    """Try to extract model name from an InferenceClient instance."""
    for attr in ("model", "model_id", "model_name"):
        try:
            val = getattr(instance, attr, None)
            if val and isinstance(val, str):
                return val
        except Exception:
            continue
    return "tei-unknown"


def _get_endpoint_url(instance) -> str:
    """Try to extract the TEI endpoint URL from an InferenceClient instance."""
    for attr in ("api_url", "base_url", "model"):
        try:
            val = getattr(instance, attr, None)
            if val and isinstance(val, str) and val.startswith("http"):
                return val
        except Exception:
            continue
    return ""


def _extract_dimensions(result) -> int:
    """Extract embedding dimensions from a feature_extraction result.

    The result is typically a numpy array or nested list of floats.
    """
    try:
        import numpy as np
        if isinstance(result, np.ndarray):
            return result.shape[-1] if result.ndim > 1 else result.shape[0]
    except ImportError:
        pass

    if isinstance(result, list):
        if len(result) == 0:
            return 0
        first = result[0]
        if isinstance(first, list):
            return len(first)
        elif isinstance(first, (int, float)):
            return len(result)

    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_feature_extraction_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``InferenceClient.feature_extraction``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or _get_model_from_instance(instance)
    endpoint_url = _get_endpoint_url(instance)

    # Extract input text
    text = args[0] if args else kwargs.get("text", "")
    if isinstance(text, str):
        input_count = 1
    elif isinstance(text, list):
        input_count = len(text)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model,
            provider_name="huggingface_tei",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = _extract_dimensions(result)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
            if endpoint_url:
                span.set_attribute("waxell.embedding.endpoint_url", endpoint_url)
        except Exception as attr_exc:
            logger.debug("Failed to set TEI feature_extraction span attributes: %s", attr_exc)

        try:
            _record_http_tei_embed(model, input_count, dimensions, endpoint_url, "feature_extraction")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_sentence_similarity_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``InferenceClient.sentence_similarity``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or _get_model_from_instance(instance)
    endpoint_url = _get_endpoint_url(instance)

    # sentence_similarity takes sentence and other_sentences
    sentence = args[0] if args else kwargs.get("sentence", "")
    other_sentences = args[1] if len(args) > 1 else kwargs.get("other_sentences", [])
    input_count = 1 + (len(other_sentences) if isinstance(other_sentences, list) else 1)

    try:
        span = start_embedding_span(
            model=model,
            provider_name="huggingface_tei",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # sentence_similarity returns similarity scores, not raw embeddings
            dimensions = 0

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
            if endpoint_url:
                span.set_attribute("waxell.embedding.endpoint_url", endpoint_url)
        except Exception as attr_exc:
            logger.debug("Failed to set TEI sentence_similarity span attributes: %s", attr_exc)

        try:
            _record_http_tei_embed(model, input_count, 0, endpoint_url, "sentence_similarity")
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_tei_embed(
    model: str, input_count: int, dimensions: int = 0,
    endpoint_url: str = "", task: str = "feature_extraction"
) -> None:
    """Record a TEI embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    endpoint_preview = f", endpoint={endpoint_url[:80]}" if endpoint_url else ""
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"embedding:tei.{task}",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}{endpoint_preview}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
