"""Elasticsearch auto-instrumentor for waxell-observe.

Monkey-patches the Elasticsearch Python client to emit OTel spans for
search operations, with special handling for knn/vector search.

Patched methods:
  - ``elasticsearch.Elasticsearch.search``      (retrieval span; knn-aware)
  - ``elasticsearch.Elasticsearch.knn_search``   (retrieval span; older API)

When the ``knn`` parameter is present in a search() call, the span operation
is recorded as ``knn_search`` rather than ``search``.

All wrapper code is wrapped in try/except -- never breaks the user's Elasticsearch calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ElasticsearchInstrumentor(BaseInstrumentor):
    """Instrumentor for the Elasticsearch Python client.

    Patches ``Elasticsearch.search`` and ``Elasticsearch.knn_search``
    (if available) to emit retrieval spans with vector search awareness.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import elasticsearch  # noqa: F401
        except ImportError:
            logger.debug("elasticsearch package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Elasticsearch instrumentation")
            return False

        wrapt.wrap_function_wrapper(
            "elasticsearch",
            "Elasticsearch.search",
            _search_wrapper,
        )

        # knn_search() exists in older versions of the client (7.x, early 8.x)
        try:
            wrapt.wrap_function_wrapper(
                "elasticsearch",
                "Elasticsearch.knn_search",
                _knn_search_wrapper,
            )
        except Exception:
            logger.debug("Elasticsearch.knn_search not found -- skipping (newer client uses search(knn=...))")

        self._instrumented = True
        logger.debug("Elasticsearch instrumented (search, knn_search)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import elasticsearch

            if hasattr(elasticsearch.Elasticsearch.search, "__wrapped__"):
                elasticsearch.Elasticsearch.search = elasticsearch.Elasticsearch.search.__wrapped__  # type: ignore[attr-defined]
            knn_search = getattr(elasticsearch.Elasticsearch, "knn_search", None)
            if knn_search is not None and hasattr(knn_search, "__wrapped__"):
                elasticsearch.Elasticsearch.knn_search = knn_search.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Elasticsearch uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Elasticsearch ``Elasticsearch.search``.

    Detects knn parameter to distinguish vector search from text search.
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Detect whether this is a knn vector search
    knn = kwargs.get("knn")
    index = kwargs.get("index", args[0] if args else "")
    is_knn = knn is not None
    operation = "knn_search" if is_knn else "search"

    # Extract knn-specific parameters
    knn_field = ""
    k_value = 0
    num_candidates = 0
    if is_knn and isinstance(knn, dict):
        knn_field = knn.get("field", "")
        k_value = knn.get("k", 0)
        num_candidates = knn.get("num_candidates", 0)

    query_preview = f"elasticsearch.{operation}(index={index!r}"
    if is_knn:
        query_preview += f", knn_field={knn_field!r}, k={k_value}"
    query_preview += ")"

    try:
        span = start_retrieval_span(query=query_preview, source="elasticsearch")
    except Exception:
        return wrapped(*args, **kwargs)

    hits_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Response is a dict with hits.total.value and hits.hits
            took_ms = 0
            if isinstance(response, dict):
                took_ms = response.get("took", 0)
                hits_obj = response.get("hits", {})
                if isinstance(hits_obj, dict):
                    hits_list = hits_obj.get("hits", [])
                    hits_count = len(hits_list) if isinstance(hits_list, list) else 0
                    total = hits_obj.get("total", {})
                    if isinstance(total, dict):
                        total_value = total.get("value", hits_count)
                    else:
                        total_value = hits_count
            else:
                # ObjectApiResponse or similar -- try attribute access
                try:
                    body = response.body if hasattr(response, "body") else response
                    if isinstance(body, dict):
                        took_ms = body.get("took", 0)
                        hits_obj = body.get("hits", {})
                        if isinstance(hits_obj, dict):
                            hits_list = hits_obj.get("hits", [])
                            hits_count = len(hits_list) if isinstance(hits_list, list) else 0
                except Exception:
                    pass

            span.set_attribute("waxell.retrieval.source", "elasticsearch")
            span.set_attribute("waxell.retrieval.operation", operation)
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if index:
                span.set_attribute("db.elasticsearch.index", str(index))
            if took_ms:
                span.set_attribute("db.elasticsearch.took_ms", took_ms)
            if is_knn:
                if knn_field:
                    span.set_attribute("db.elasticsearch.knn_field", knn_field)
                if k_value:
                    span.set_attribute("waxell.retrieval.top_k", k_value)
                if num_candidates:
                    span.set_attribute("db.elasticsearch.num_candidates", num_candidates)
        except Exception as attr_exc:
            logger.debug("Failed to set Elasticsearch search span attributes: %s", attr_exc)

        try:
            _record_elasticsearch_retrieval(
                query=query_preview,
                operation=operation,
                index=str(index) if index else "",
                hits_count=hits_count,
                took_ms=took_ms if 'took_ms' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _knn_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Elasticsearch ``Elasticsearch.knn_search`` (older API)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    index = kwargs.get("index", args[0] if args else "")
    knn = kwargs.get("knn", {})

    knn_field = ""
    k_value = 0
    num_candidates = 0
    if isinstance(knn, dict):
        knn_field = knn.get("field", "")
        k_value = knn.get("k", 0)
        num_candidates = knn.get("num_candidates", 0)

    query_preview = f"elasticsearch.knn_search(index={index!r}, field={knn_field!r}, k={k_value})"

    try:
        span = start_retrieval_span(query=query_preview, source="elasticsearch")
    except Exception:
        return wrapped(*args, **kwargs)

    hits_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            took_ms = 0
            if isinstance(response, dict):
                took_ms = response.get("took", 0)
                hits_obj = response.get("hits", {})
                if isinstance(hits_obj, dict):
                    hits_list = hits_obj.get("hits", [])
                    hits_count = len(hits_list) if isinstance(hits_list, list) else 0
            else:
                try:
                    body = response.body if hasattr(response, "body") else response
                    if isinstance(body, dict):
                        took_ms = body.get("took", 0)
                        hits_obj = body.get("hits", {})
                        if isinstance(hits_obj, dict):
                            hits_list = hits_obj.get("hits", [])
                            hits_count = len(hits_list) if isinstance(hits_list, list) else 0
                except Exception:
                    pass

            span.set_attribute("waxell.retrieval.source", "elasticsearch")
            span.set_attribute("waxell.retrieval.operation", "knn_search")
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if index:
                span.set_attribute("db.elasticsearch.index", str(index))
            if took_ms:
                span.set_attribute("db.elasticsearch.took_ms", took_ms)
            if knn_field:
                span.set_attribute("db.elasticsearch.knn_field", knn_field)
            if k_value:
                span.set_attribute("waxell.retrieval.top_k", k_value)
            if num_candidates:
                span.set_attribute("db.elasticsearch.num_candidates", num_candidates)
        except Exception as attr_exc:
            logger.debug("Failed to set Elasticsearch knn_search span attributes: %s", attr_exc)

        try:
            _record_elasticsearch_retrieval(
                query=query_preview,
                operation="knn_search",
                index=str(index) if index else "",
                hits_count=hits_count,
                took_ms=took_ms if 'took_ms' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_elasticsearch_retrieval(
    query: str,
    operation: str,
    index: str,
    hits_count: int,
    took_ms: int,
) -> None:
    """Record an Elasticsearch retrieval operation to the context path.

    Vector DB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"hit_{i}"} for i in range(hits_count)]
        ctx.record_retrieval(
            query=query,
            source="elasticsearch",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
