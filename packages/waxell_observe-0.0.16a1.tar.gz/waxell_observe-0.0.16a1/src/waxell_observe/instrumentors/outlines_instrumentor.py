"""Outlines auto-instrumentor for waxell-observe.

Monkey-patches Outlines' sequence generator adapters to emit OTel spans
and record to the Waxell HTTP API.

Outlines provides structured generation via constrained decoding.  It
supports text, JSON, choice, and regex-based generation modes.  This
instrumentor wraps the common ``SequenceGeneratorAdapter.__call__`` base
class and, as a fallback, the specific adapters for each output type.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OutlinesInstrumentor(BaseInstrumentor):
    """Instrumentor for Outlines (``outlines`` package).

    Patches SequenceGeneratorAdapter.__call__ (and specific subclasses).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import outlines  # noqa: F401
        except ImportError:
            logger.debug("outlines not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Outlines instrumentation")
            return False

        patched = False

        # Attempt 1: Patch the common base adapter __call__
        # outlines.generate.api.SequenceGeneratorAdapter is the base class
        # that all generator adapters inherit from.
        try:
            wrapt.wrap_function_wrapper(
                "outlines.generate.api",
                "SequenceGeneratorAdapter.__call__",
                _generator_call_wrapper,
            )
            patched = True
            logger.debug("Patched outlines.generate.api.SequenceGeneratorAdapter.__call__")
        except Exception as exc:
            logger.debug("Could not patch SequenceGeneratorAdapter.__call__: %s", exc)

        # Attempt 2: Patch specific generator types as fallback
        # These are the generate.text(), generate.json(), generate.choice(),
        # generate.regex() factory functions that create adapters.
        _generators = [
            ("outlines.generate.text", "text", "text"),
            ("outlines.generate.json", "json", "json"),
            ("outlines.generate.choice", "choice", "choice"),
            ("outlines.generate.regex", "regex", "regex"),
        ]
        for module_path, func_name, output_type in _generators:
            try:
                wrapt.wrap_function_wrapper(
                    module_path,
                    func_name,
                    _make_generate_factory_wrapper(output_type),
                )
                patched = True
                logger.debug("Patched %s.%s", module_path, func_name)
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Outlines methods to patch")
            return False

        self._instrumented = True
        logger.debug("Outlines instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore SequenceGeneratorAdapter.__call__
        try:
            from outlines.generate.api import SequenceGeneratorAdapter

            if hasattr(SequenceGeneratorAdapter.__call__, "__wrapped__"):
                SequenceGeneratorAdapter.__call__ = SequenceGeneratorAdapter.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore generate factory functions
        _generators = [
            ("outlines.generate", "text"),
            ("outlines.generate", "json"),
            ("outlines.generate", "choice"),
            ("outlines.generate", "regex"),
        ]
        for module_path, func_name in _generators:
            try:
                import importlib

                mod = importlib.import_module(module_path)
                func = getattr(mod, func_name, None)
                if func and hasattr(func, "__wrapped__"):
                    setattr(mod, func_name, func.__wrapped__)
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("Outlines uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _generator_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``SequenceGeneratorAdapter.__call__`` -- all generation types."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Detect output type from the adapter class name
    output_type = "text"
    try:
        class_name = type(instance).__name__.lower()
        if "json" in class_name:
            output_type = "json"
        elif "choice" in class_name:
            output_type = "choice"
        elif "regex" in class_name:
            output_type = "regex"
    except Exception:
        pass

    # Extract model info
    model_name = "unknown"
    try:
        if hasattr(instance, "model"):
            model_obj = instance.model
            model_name = (
                getattr(model_obj, "model_name", None)
                or getattr(model_obj, "name", None)
                or getattr(model_obj, "model", None)
                or type(model_obj).__name__
            )
            model_name = str(model_name)
    except Exception:
        pass

    # Extract prompt preview from first positional arg
    prompt_preview = ""
    try:
        if args:
            prompt_preview = str(args[0])[:200]
    except Exception:
        pass

    try:
        span = start_step_span(step_name="outlines.generate")
        span.set_attribute("waxell.outlines.output_type", output_type)
        span.set_attribute("waxell.outlines.model", model_name)
        if prompt_preview:
            span.set_attribute("waxell.outlines.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("waxell.outlines.latency_ms", latency_ms)

            # Capture output preview
            output_preview = ""
            try:
                output_preview = str(result)[:500]
            except Exception:
                pass
            if output_preview:
                span.set_attribute("waxell.outlines.output_preview", output_preview)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_outlines(result, model_name, output_type, prompt_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _make_generate_factory_wrapper(output_type: str):
    """Create a wrapper for a specific generate factory function (text/json/choice/regex).

    The factory function returns a generator adapter instance.  We wrap
    the factory so that when the adapter is created, we can tag it with
    the output_type for later identification in __call__.
    """

    def _factory_wrapper(wrapped, instance, args, kwargs):
        try:
            result = wrapped(*args, **kwargs)
        except Exception:
            raise

        # Tag the adapter with the output type so our __call__ wrapper
        # can identify it without relying on class name heuristics.
        try:
            result._waxell_output_type = output_type
        except Exception:
            pass

        return result

    return _factory_wrapper


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_http_outlines(result, model: str, output_type: str, prompt_preview: str) -> None:
    """Record an Outlines generation call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    output_preview = ""
    try:
        output_preview = str(result)[:500]
    except Exception:
        pass

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"outlines.generate:{output_type}",
        "prompt_preview": prompt_preview,
        "response_preview": output_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
