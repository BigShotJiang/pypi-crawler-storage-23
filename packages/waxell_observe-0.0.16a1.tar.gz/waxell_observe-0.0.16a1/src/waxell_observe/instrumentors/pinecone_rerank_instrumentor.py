"""Pinecone Inference Rerank auto-instrumentor for waxell-observe.

Monkey-patches ``Pinecone.inference.rerank`` (via the Inference class) to emit
tool spans tracking reranking operations through the Pinecone Inference API.

Note: The existing ``pinecone_instrumentor.py`` handles vector operations
(Index.query, Index.upsert, etc.).  This instrumentor is SEPARATE and covers
the Inference API reranking endpoint only.

The ``Pinecone.inference`` attribute is a
``pinecone.data.features.inference.inference.Inference`` instance.  The
``rerank()`` method accepts model, query, documents, top_n, return_documents.

Response is a ``RerankResult`` object:
  - ``result.model`` -- model used
  - ``result.data``  -- list of ``RerankResultItem`` with ``.index``, ``.score``, ``.document``
  - ``result.usage.rerank_units`` -- usage units

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PineconeRerankInstrumentor(BaseInstrumentor):
    """Instrumentor for Pinecone Inference reranking (``pinecone`` package).

    Patches ``Inference.rerank`` to emit tool spans for reranking operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pinecone  # noqa: F401
        except ImportError:
            logger.debug("pinecone package not installed -- skipping rerank instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Pinecone rerank instrumentation")
            return False

        patched = False

        # Try the fully-qualified module path first (pinecone v3+)
        try:
            wrapt.wrap_function_wrapper(
                "pinecone.data.features.inference.inference",
                "Inference.rerank",
                _sync_rerank_wrapper,
            )
            patched = True
            logger.debug("Pinecone Inference.rerank patched (pinecone.data.features.inference.inference)")
        except Exception:
            pass

        # Fallback: try alternative module paths for different pinecone versions
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "pinecone",
                    "Inference.rerank",
                    _sync_rerank_wrapper,
                )
                patched = True
                logger.debug("Pinecone Inference.rerank patched (pinecone.Inference)")
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Pinecone Inference.rerank method to patch")
            return False

        self._instrumented = True
        logger.debug("Pinecone Inference rerank instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            # Try fully-qualified module path first
            from pinecone.data.features.inference.inference import Inference

            method = getattr(Inference, "rerank", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Inference.rerank = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Pinecone Inference rerank uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_result_data(result) -> list:
    """Extract the data list from a Pinecone RerankResult."""
    data = getattr(result, "data", None)
    if data is not None and isinstance(data, list):
        return data
    return []


def _extract_scores(data_items) -> list[float]:
    """Extract scores from RerankResult data items."""
    scores = []
    for item in data_items:
        score = getattr(item, "score", None)
        if score is not None:
            scores.append(float(score))
    return scores


def _extract_top_score(data_items) -> float | None:
    """Extract the top (first) relevance score from rerank result data."""
    if not data_items:
        return None
    first = data_items[0]
    score = getattr(first, "score", None)
    if score is not None:
        return float(score)
    if isinstance(first, dict):
        score = first.get("score")
        if score is not None:
            return float(score)
    return None


def _extract_usage(result) -> int:
    """Extract rerank_units from a Pinecone RerankResult.usage."""
    usage = getattr(result, "usage", None)
    if usage is not None:
        units = getattr(usage, "rerank_units", 0)
        if units:
            return int(units)
    return 0


def _extract_model(result, kwargs) -> str:
    """Extract model name from result or kwargs."""
    # Try from result first
    model = getattr(result, "model", None)
    if model:
        return str(model)
    # Fall back to kwargs
    return str(kwargs.get("model", "unknown"))


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_rerank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Inference.rerank``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    query = kwargs.get("query", "")
    documents = kwargs.get("documents", [])
    documents_count = len(documents) if isinstance(documents, list) else 0
    top_n = kwargs.get("top_n", None)

    try:
        span = start_tool_span(tool_name="pinecone.rerank", tool_type="reranker")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data_items = _extract_result_data(result)
            results_count = len(data_items)
            top_score = _extract_top_score(data_items)
            rerank_units = _extract_usage(result)
            result_model = _extract_model(result, kwargs)

            span.set_attribute("waxell.rerank.system", "pinecone")
            span.set_attribute("waxell.rerank.model", result_model)
            span.set_attribute("waxell.rerank.query", str(query)[:200])
            span.set_attribute("waxell.rerank.documents_count", documents_count)
            span.set_attribute("waxell.rerank.results_count", results_count)
            if top_n is not None:
                span.set_attribute("waxell.rerank.top_n", top_n)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
            if rerank_units:
                span.set_attribute("waxell.rerank.rerank_units", rerank_units)
        except Exception as attr_exc:
            logger.debug("Failed to set Pinecone rerank span attributes: %s", attr_exc)

        try:
            _record_http_pinecone_rerank(
                model=result_model if "result_model" in dir() else model,
                query=query,
                documents_count=documents_count,
                results_count=results_count if "results_count" in dir() else 0,
                top_score=top_score if "top_score" in dir() else None,
                rerank_units=rerank_units if "rerank_units" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_pinecone_rerank(
    model: str,
    query: str,
    documents_count: int = 0,
    results_count: int = 0,
    top_score: float | None = None,
    rerank_units: int = 0,
) -> None:
    """Record a Pinecone rerank call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    call_data = {
        "model": model,
        "tokens_in": rerank_units,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "rerank:pinecone",
        "prompt_preview": f"rerank query: {query[:200]}",
        "response_preview": f"{results_count} result(s) from {documents_count} doc(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
