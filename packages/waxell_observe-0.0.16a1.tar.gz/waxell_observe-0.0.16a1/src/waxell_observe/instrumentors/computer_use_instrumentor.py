"""Anthropic Computer Use auto-instrumentor for waxell-observe.

Monkey-patches the Anthropic Python SDK to emit tool spans when computer use
tool calls are detected in API responses (tool type "computer_20241022" or
matching "computer_*" patterns).

Computer use actions include:
  - click (with coordinates)
  - type (with text input)
  - screenshot (captures screen)
  - key (keyboard shortcuts)
  - scroll (with direction and amount)
  - cursor_position (get current position)

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import json
import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Computer use tool type patterns
_COMPUTER_USE_TYPES = ("computer_20241022", "computer_20250124")
_COMPUTER_USE_PREFIX = "computer_"


class ComputerUseInstrumentor(BaseInstrumentor):
    """Instrumentor for Anthropic Computer Use tool calls.

    Patches ``anthropic.resources.messages.Messages.create`` and
    ``anthropic.resources.messages.AsyncMessages.create`` to detect and
    trace computer use tool interactions in responses.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import anthropic  # noqa: F401
        except ImportError:
            logger.debug("anthropic package not installed -- skipping Computer Use instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Computer Use instrumentation")
            return False

        patched = False

        # Patch sync messages.create
        try:
            wrapt.wrap_function_wrapper(
                "anthropic.resources.messages",
                "Messages.create",
                _messages_create_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch anthropic Messages.create for Computer Use: %s", exc)

        # Patch async messages.create
        try:
            wrapt.wrap_function_wrapper(
                "anthropic.resources.messages",
                "AsyncMessages.create",
                _async_messages_create_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch anthropic AsyncMessages.create for Computer Use: %s", exc)

        if not patched:
            logger.debug("Could not find any Anthropic methods to patch for Computer Use")
            return False

        self._instrumented = True
        logger.debug("Anthropic Computer Use instrumented (Messages.create)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import anthropic.resources.messages as msg_mod

            for cls_name in ("Messages", "AsyncMessages"):
                cls = getattr(msg_mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "create", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "create", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Anthropic Computer Use uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for detecting and extracting computer use data
# ---------------------------------------------------------------------------


def _is_computer_use_type(tool_type: str) -> bool:
    """Check if a tool type string matches computer use patterns."""
    if not tool_type:
        return False
    tool_type_lower = tool_type.lower()
    if tool_type_lower in _COMPUTER_USE_TYPES:
        return True
    if tool_type_lower.startswith(_COMPUTER_USE_PREFIX):
        return True
    return False


def _has_computer_use_tools(kwargs) -> bool:
    """Check if the request includes computer use tools in the tools list."""
    tools = kwargs.get("tools", [])
    if not tools:
        return False

    for tool in tools:
        try:
            tool_type = ""
            if isinstance(tool, dict):
                tool_type = tool.get("type", "")
            else:
                tool_type = getattr(tool, "type", "")

            if _is_computer_use_type(str(tool_type)):
                return True
        except Exception:
            continue

    return False


def _extract_computer_use_from_response(response) -> list[dict]:
    """Extract computer use tool calls from an Anthropic response.

    Returns a list of dicts, each with keys:
      - action: str (click, type, screenshot, etc.)
      - coordinates: tuple or None
      - text: str or None
      - screenshot_taken: bool
      - tool_use_id: str
    """
    tool_calls = []

    try:
        content = getattr(response, "content", [])
        if not content:
            return tool_calls

        for block in content:
            block_type = getattr(block, "type", "")
            if block_type != "tool_use":
                continue

            # Check if this tool use is a computer use tool
            tool_name = getattr(block, "name", "")
            tool_type_attr = getattr(block, "type", "")

            # Computer use tool calls have specific names
            # The tool name in responses is the name from the tools list
            # Input contains the action details
            input_data = getattr(block, "input", {})
            if not isinstance(input_data, dict):
                continue

            action = input_data.get("action", "")

            # If this doesn't look like a computer action, check the tool name
            if not action and not _is_computer_use_tool_name(tool_name):
                continue

            if not action and _is_computer_use_tool_name(tool_name):
                action = input_data.get("action", "unknown")

            if not action:
                continue

            call_info = {
                "action": str(action),
                "tool_use_id": str(getattr(block, "id", "")),
                "coordinates": None,
                "text": None,
                "screenshot_taken": action == "screenshot",
            }

            # Extract coordinates for click/move actions
            coordinate = input_data.get("coordinate")
            if coordinate:
                call_info["coordinates"] = coordinate

            # Extract text for type action
            text = input_data.get("text")
            if text:
                call_info["text"] = str(text)[:500]

            # Extract key for key action
            key = input_data.get("key")
            if key:
                call_info["text"] = str(key)

            # Extract scroll details
            scroll_direction = input_data.get("direction")
            scroll_amount = input_data.get("amount")
            if scroll_direction:
                call_info["scroll_direction"] = str(scroll_direction)
            if scroll_amount is not None:
                call_info["scroll_amount"] = scroll_amount

            tool_calls.append(call_info)

    except Exception:
        pass

    return tool_calls


def _is_computer_use_tool_name(name: str) -> bool:
    """Check if a tool name matches common computer use patterns."""
    if not name:
        return False
    name_lower = name.lower()
    return name_lower in ("computer", "computer_use") or name_lower.startswith("computer_")


def _extract_computer_use_from_input(kwargs) -> list[dict]:
    """Extract computer use tool results from input messages.

    When users submit tool results for computer use actions, the messages
    may contain tool_result blocks with screenshots, etc.
    """
    tool_results = []

    messages = kwargs.get("messages", [])
    if not messages:
        return tool_results

    try:
        for msg in messages:
            if not isinstance(msg, dict):
                continue
            if msg.get("role") != "user":
                continue

            content = msg.get("content", [])
            if not isinstance(content, list):
                continue

            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_result":
                    continue

                tool_use_id = block.get("tool_use_id", "")
                result_content = block.get("content", [])

                has_screenshot = False
                if isinstance(result_content, list):
                    for item in result_content:
                        if isinstance(item, dict) and item.get("type") == "image":
                            has_screenshot = True
                            break

                tool_results.append({
                    "tool_use_id": str(tool_use_id),
                    "has_screenshot": has_screenshot,
                })
    except Exception:
        pass

    return tool_results


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _messages_create_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``anthropic.resources.messages.Messages.create``.

    Only emits computer use spans when computer use tools are detected.
    """
    # Check if this request involves computer use
    if not _has_computer_use_tools(kwargs):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "claude")

    try:
        result = wrapped(*args, **kwargs)
    except Exception:
        raise
    else:
        # Extract computer use tool calls from the response
        tool_calls = _extract_computer_use_from_response(result)

        for call in tool_calls:
            try:
                span = start_tool_span(
                    tool_name="computer_use",
                    tool_type="computer_use",
                )

                span.set_attribute("waxell.computer_use.action", call["action"])
                span.set_attribute("waxell.computer_use.model", model)

                if call.get("tool_use_id"):
                    span.set_attribute("waxell.computer_use.tool_use_id", call["tool_use_id"])
                if call.get("coordinates"):
                    span.set_attribute(
                        "waxell.computer_use.coordinates",
                        json.dumps(call["coordinates"]),
                    )
                if call.get("text"):
                    span.set_attribute("waxell.computer_use.text_input", call["text"])
                if call.get("screenshot_taken"):
                    span.set_attribute("waxell.computer_use.screenshot_taken", True)
                if call.get("scroll_direction"):
                    span.set_attribute("waxell.computer_use.scroll_direction", call["scroll_direction"])
                if call.get("scroll_amount") is not None:
                    span.set_attribute("waxell.computer_use.scroll_amount", call["scroll_amount"])

                span.end()
            except Exception:
                pass

        # Record to context
        try:
            if tool_calls:
                _record_http_computer_use(model, tool_calls)
        except Exception:
            pass

        return result


async def _async_messages_create_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``anthropic.resources.messages.AsyncMessages.create``.

    Only emits computer use spans when computer use tools are detected.
    """
    if not _has_computer_use_tools(kwargs):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "claude")

    try:
        result = await wrapped(*args, **kwargs)
    except Exception:
        raise
    else:
        tool_calls = _extract_computer_use_from_response(result)

        for call in tool_calls:
            try:
                span = start_tool_span(
                    tool_name="computer_use",
                    tool_type="computer_use",
                )

                span.set_attribute("waxell.computer_use.action", call["action"])
                span.set_attribute("waxell.computer_use.model", model)

                if call.get("tool_use_id"):
                    span.set_attribute("waxell.computer_use.tool_use_id", call["tool_use_id"])
                if call.get("coordinates"):
                    span.set_attribute(
                        "waxell.computer_use.coordinates",
                        json.dumps(call["coordinates"]),
                    )
                if call.get("text"):
                    span.set_attribute("waxell.computer_use.text_input", call["text"])
                if call.get("screenshot_taken"):
                    span.set_attribute("waxell.computer_use.screenshot_taken", True)
                if call.get("scroll_direction"):
                    span.set_attribute("waxell.computer_use.scroll_direction", call["scroll_direction"])
                if call.get("scroll_amount") is not None:
                    span.set_attribute("waxell.computer_use.scroll_amount", call["scroll_amount"])

                span.end()
            except Exception:
                pass

        try:
            if tool_calls:
                _record_http_computer_use(model, tool_calls)
        except Exception:
            pass

        return result


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_computer_use(model: str, tool_calls: list[dict]) -> None:
    """Record computer use tool calls to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    actions = [c.get("action", "unknown") for c in tool_calls]

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "anthropic.computer_use",
        "prompt_preview": f"actions={actions}",
        "response_preview": json.dumps(tool_calls)[:500] if tool_calls else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name="computer_use",
            input={"actions": actions},
            output={"tool_calls": tool_calls},
            tool_type="computer_use",
            status="ok",
        )
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
