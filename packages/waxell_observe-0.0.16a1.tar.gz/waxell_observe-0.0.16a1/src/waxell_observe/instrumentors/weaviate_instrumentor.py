"""Weaviate v4 auto-instrumentor for waxell-observe.

Monkey-patches Weaviate v4 Python client query methods to emit OTel spans
and record retrieval operations to the Waxell HTTP API.

Patched query methods:
  - near_vector  (vector similarity search)
  - near_text    (text-to-vector similarity search)
  - hybrid       (hybrid BM25 + vector search)
  - bm25         (keyword search)
  - fetch_objects (full object retrieval)

Since Weaviate's internal module structure varies across versions, each patch
is attempted independently. Failures are logged and skipped -- never raised.

All wrapper code is wrapped in try/except -- never breaks the user's queries.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Map of (module_path, class_name, method_name) for each query method.
# Weaviate v4 organises query mixins in separate submodules.
_PATCHES: list[tuple[str, str, str]] = [
    (
        "weaviate.collections.queries.near_vector",
        "_NearVectorQuery",
        "near_vector",
    ),
    (
        "weaviate.collections.queries.near_text",
        "_NearTextQuery",
        "near_text",
    ),
    (
        "weaviate.collections.queries.hybrid",
        "_HybridQuery",
        "hybrid",
    ),
    (
        "weaviate.collections.queries.bm25",
        "_BM25Query",
        "bm25",
    ),
    (
        "weaviate.collections.queries.fetch_objects",
        "_FetchObjectsQuery",
        "fetch_objects",
    ),
]


class WeaviateInstrumentor(BaseInstrumentor):
    """Instrumentor for the Weaviate v4 Python client (``weaviate`` package).

    Patches query mixin methods used by all collection query builders.
    Each patch is attempted independently -- version mismatches on individual
    paths are logged at DEBUG level and skipped without failing the overall
    instrumentation.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import weaviate  # noqa: F401
        except ImportError:
            logger.debug("weaviate package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt  # noqa: F401
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping Weaviate instrumentation"
            )
            return False

        any_patched = False

        for module_path, class_name, method_name in _PATCHES:
            try:
                import wrapt

                wrapper = _make_query_wrapper(method_name)
                wrapt.wrap_function_wrapper(
                    module_path,
                    f"{class_name}.{method_name}",
                    wrapper,
                )
                logger.debug(
                    "Patched Weaviate %s.%s.%s",
                    module_path,
                    class_name,
                    method_name,
                )
                any_patched = True
            except Exception as exc:
                logger.debug(
                    "Could not patch Weaviate %s.%s.%s -- skipping: %s",
                    module_path,
                    class_name,
                    method_name,
                    exc,
                )

        if not any_patched:
            logger.debug(
                "No Weaviate query methods could be patched "
                "(possibly incompatible version)"
            )
            return False

        self._instrumented = True
        logger.debug("Weaviate query methods instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        import importlib

        for module_path, class_name, method_name in _PATCHES:
            try:
                mod = importlib.import_module(module_path)
                cls = getattr(mod, class_name, None)
                if cls is None:
                    continue
                method = getattr(cls, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]
            except Exception as exc:
                logger.debug(
                    "Could not uninstrument Weaviate %s.%s.%s: %s",
                    module_path,
                    class_name,
                    method_name,
                    exc,
                )

        self._instrumented = False
        logger.debug("Weaviate query methods uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper factory
# ---------------------------------------------------------------------------


def _make_query_wrapper(query_type: str):
    """Return a wrapt-compatible wrapper function for the given query type.

    Using a factory so that each wrapper closes over its ``query_type`` name
    and remains a distinct callable (important for wrapt bookkeeping).
    """

    def _query_wrapper(wrapped, instance, args, kwargs):
        """Instrumentation wrapper for a Weaviate query method."""
        try:
            from ..tracing.spans import start_retrieval_span
        except Exception:
            return wrapped(*args, **kwargs)

        # Extract a human-readable query string for the span.
        query_text = _extract_query_text(query_type, args, kwargs)

        try:
            span = start_retrieval_span(query=query_text, source="weaviate")
        except Exception:
            return wrapped(*args, **kwargs)

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise
        else:
            try:
                result_count = _extract_result_count(response)
                span.set_attribute("gen_ai.tool.type", "vector_db")
                span.set_attribute("waxell.retrieval.query_type", query_type)
                span.set_attribute("waxell.retrieval.result_count", result_count)
                span.set_attribute("waxell.retrieval.backend", "weaviate")
            except Exception as attr_exc:
                logger.debug("Failed to set Weaviate span attributes: %s", attr_exc)

            try:
                _record_to_context(query_type, query_text, response)
            except Exception:
                pass

            return response
        finally:
            try:
                span.end()
            except Exception:
                pass

    # Give the wrapper a meaningful name for debugging / profiling tools.
    _query_wrapper.__name__ = f"_weaviate_{query_type}_wrapper"
    return _query_wrapper


# ---------------------------------------------------------------------------
# Helpers: extract query text from positional / keyword args
# ---------------------------------------------------------------------------


def _extract_query_text(query_type: str, args: tuple, kwargs: dict) -> str:
    """Return a short string representing the query for span annotation.

    Each query method has a different first argument:
      - near_vector:   ``near_vector`` kwarg (list[float]) or first positional arg
      - near_text:     ``query`` kwarg (str | list[str]) or first positional arg
      - hybrid:        ``query`` kwarg (str) or first positional arg
      - bm25:          ``query`` kwarg (str) or first positional arg
      - fetch_objects: no meaningful query text; use placeholder
    """
    try:
        if query_type == "near_vector":
            vec = kwargs.get("near_vector") or (args[0] if args else None)
            if vec is not None:
                try:
                    return f"near_vector[{len(vec)}d]"
                except Exception:
                    return "near_vector"
            return "near_vector"

        if query_type in ("near_text", "hybrid", "bm25"):
            query = kwargs.get("query") or (args[0] if args else None)
            if query is not None:
                if isinstance(query, list):
                    combined = " ".join(str(q) for q in query)
                    return combined[:500]
                return str(query)[:500]
            return query_type

        if query_type == "fetch_objects":
            return "fetch_objects"

    except Exception:
        pass

    return query_type


# ---------------------------------------------------------------------------
# Helpers: extract result count from Weaviate response objects
# ---------------------------------------------------------------------------


def _extract_result_count(response) -> int:
    """Return the number of objects in a Weaviate query response.

    Weaviate v4 query results expose objects via ``.objects`` on the
    QueryReturn / QueryNearMediaReturn types.  Handles None gracefully.
    """
    try:
        objects = getattr(response, "objects", None)
        if objects is not None:
            return len(objects)
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Context recording
# ---------------------------------------------------------------------------


def _record_to_context(query_type: str, query_text: str, response) -> None:
    """Record the retrieval call to the active WaxellContext if one exists.

    Uses ``_current_context`` (a ContextVar) to avoid importing the full
    context module at module level.  No-ops silently when no context is set.
    """
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx is None or not getattr(ctx, "run_id", None):
            return

        result_count = _extract_result_count(response)

        # record_retrieval may not exist on older context versions -- guard it.
        record_fn = getattr(ctx, "record_retrieval", None)
        if callable(record_fn):
            record_fn(
                source="weaviate",
                query=query_text,
                result_count=result_count,
                query_type=query_type,
            )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Error recording
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span, setting status to ERROR."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
