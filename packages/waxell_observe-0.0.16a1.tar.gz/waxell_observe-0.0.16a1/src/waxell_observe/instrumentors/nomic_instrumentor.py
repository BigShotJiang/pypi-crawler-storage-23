"""Nomic AI auto-instrumentor for waxell-observe.

Monkey-patches ``nomic.embed.text`` to emit embedding spans tracking
remote embedding generation via the Nomic API.

The ``nomic`` package provides open-source embedding models like
nomic-embed-text-v1.5. Token counts are extracted from
``result["usage"]["total_tokens"]`` and dimensions from the first
embedding vector.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class NomicInstrumentor(BaseInstrumentor):
    """Instrumentor for the Nomic AI Python SDK (``nomic`` package).

    Patches ``nomic.embed.text`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import nomic  # noqa: F401
        except ImportError:
            logger.debug("nomic package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Nomic instrumentation")
            return False

        patched = False

        # Primary: nomic.embed.text
        try:
            wrapt.wrap_function_wrapper(
                "nomic.embed",
                "text",
                _sync_embed_wrapper,
            )
            patched = True
            logger.debug("Nomic embed.text patched")
        except Exception:
            pass

        # Fallback: nomic.embed module-level text function via nomic namespace
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "nomic",
                    "embed.text",
                    _sync_embed_wrapper,
                )
                patched = True
                logger.debug("Nomic embed.text patched via nomic namespace")
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Nomic embed.text method to patch")
            return False

        self._instrumented = True
        logger.debug("Nomic embed instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import nomic.embed as embed_module

            method = getattr(embed_module, "text", None)
            if method is not None and hasattr(method, "__wrapped__"):
                embed_module.text = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Nomic embed uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_texts(args, kwargs):
    """Extract texts from nomic.embed.text call arguments.

    Signature: nomic.embed.text(texts, model=..., task_type=...)
    """
    texts = kwargs.get("texts", args[0] if args else [])
    return texts


def _extract_tokens(result):
    """Extract total token count from a Nomic embed result dict.

    Result format: {"embeddings": [...], "usage": {"prompt_tokens": N, "total_tokens": N}}
    """
    if not isinstance(result, dict):
        return 0
    usage = result.get("usage")
    if not usage or not isinstance(usage, dict):
        return 0
    return usage.get("total_tokens", 0) or 0


def _extract_dimensions(result):
    """Extract embedding dimensions from a Nomic embed result dict."""
    if not isinstance(result, dict):
        return 0
    embeddings = result.get("embeddings")
    if not embeddings or not isinstance(embeddings, list) or len(embeddings) == 0:
        return 0
    first = embeddings[0]
    if isinstance(first, list):
        return len(first)
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``nomic.embed.text``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "nomic-embed-text-v1.5")
    texts = _extract_texts(args, kwargs)
    input_count = len(texts) if isinstance(texts, list) else 1

    try:
        span = start_embedding_span(
            model=model,
            provider_name="nomic",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = _extract_tokens(result)
            dimensions = _extract_dimensions(result)
            cost = estimate_embedding_cost(model, tokens, "nomic")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set Nomic embed span attributes: %s", attr_exc)

        try:
            _record_http_nomic_embed(model, input_count, tokens, dimensions, cost)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_nomic_embed(
    model: str, input_count: int, tokens: int = 0, dimensions: int = 0, cost: float = 0.0
) -> None:
    """Record a Nomic embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embedding:nomic",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
