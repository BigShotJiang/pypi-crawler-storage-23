"""Background collector for LLM calls made outside any WaxellContext.

When an instrumentor intercepts an LLM call and no WaxellContext is active
(i.e. ``_current_context.get()`` returns ``None``), the call data is pushed
into this collector's thread-safe buffer.

A daemon thread flushes the buffer every ``_FLUSH_INTERVAL`` seconds,
grouping the buffered calls into an auto-generated run and recording them
via the globally-configured ``WaxellObserveClient``.

If no client is configured, buffered calls are silently dropped on flush.
"""

from __future__ import annotations

import atexit
import logging
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)

_FLUSH_INTERVAL: float = 5.0  # seconds


class BackgroundCollector:
    """Thread-safe buffer + daemon flusher for context-free LLM calls."""

    def __init__(self, flush_interval: float = _FLUSH_INTERVAL) -> None:
        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._flush_interval = flush_interval
        self._running = False
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def record_call(self, call_data: dict[str, Any]) -> None:
        """Append an LLM call dict to the buffer (thread-safe).

        Lazily starts the background flush thread on first call.
        """
        with self._lock:
            self._buffer.append(call_data)

        # Start background thread on first call (lazy)
        if not self._running:
            self._start()

    def flush(self) -> None:
        """Manually flush all buffered calls to the Waxell API."""
        calls: list[dict[str, Any]]
        with self._lock:
            if not self._buffer:
                return
            calls = list(self._buffer)
            self._buffer.clear()

        self._send(calls)

    def shutdown(self) -> None:
        """Flush remaining calls and stop the background thread."""
        self._running = False
        self.flush()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            self._thread = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _start(self) -> None:
        """Start the background flush daemon thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._flush_loop,
            name="waxell-bg-collector",
            daemon=True,
        )
        self._thread.start()

    def _flush_loop(self) -> None:
        """Background loop: sleep, flush, repeat."""
        while self._running:
            time.sleep(self._flush_interval)
            try:
                self.flush()
            except Exception:
                # Never crash the daemon thread
                pass

    def _send(self, calls: list[dict[str, Any]]) -> None:
        """Create an auto-run and record buffered calls via the HTTP client.

        Uses synchronous client methods (we are in a background thread).
        """
        if not calls:
            return

        try:
            from ..client import WaxellObserveClient

            if not WaxellObserveClient.is_configured():
                logger.debug(
                    "Background collector: client not configured, "
                    "dropping %d buffered LLM call(s)",
                    len(calls),
                )
                return

            client = WaxellObserveClient()

            # Derive auto-run name from the first call's model
            first_model = calls[0].get("model", "unknown")
            auto_name = f"auto:{first_model}"

            # Create a short-lived auto-run
            run_info = client.start_run_sync(
                agent_name=auto_name,
                workflow_name="auto",
                metadata={"auto_collected": True, "call_count": len(calls)},
            )
            if not run_info or not run_info.run_id:
                logger.debug(
                    "Background collector: start_run returned empty run_id, "
                    "dropping %d call(s)",
                    len(calls),
                )
                return

            # Record the calls
            client.record_llm_calls_sync(
                run_id=run_info.run_id,
                calls=calls,
            )

            # Complete the auto-run
            client.complete_run_sync(
                run_id=run_info.run_id,
                status="success",
            )

            logger.debug(
                "Background collector: flushed %d call(s) to auto-run %s",
                len(calls),
                run_info.run_id,
            )

        except Exception as exc:
            # Never propagate errors from background flushing
            logger.debug("Background collector flush error: %s", exc)


# Module-level singleton
_collector = BackgroundCollector()

# Ensure clean shutdown
atexit.register(_collector.shutdown)
