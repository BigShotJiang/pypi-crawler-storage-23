"""Agency Swarm auto-instrumentor for waxell-observe.

Monkey-patches ``agency_swarm.Agency.run`` and ``agency_swarm.Agent.run``
to emit OTel spans and record to the Waxell HTTP API. Also patches
tool execution via ``agency_swarm.tools.BaseTool._run``.

Agency Swarm is a multi-agent orchestration framework where an Agency
coordinates multiple Agents, each with their own tools and communication
channels. The framework supports hierarchical agent structures with
message-passing between agents.

Patched methods:
  - ``agency_swarm.Agency.run``           — agency-level orchestration
  - ``agency_swarm.Agent.run``            — individual agent execution
  - ``agency_swarm.tools.BaseTool._run``  — tool execution within agents

All wrapper code is wrapped in try/except -- never breaks the user's agent runs.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AgencySwarmInstrumentor(BaseInstrumentor):
    """Instrumentor for the Agency Swarm framework (``agency_swarm`` package).

    Patches Agency.run for agency-level orchestration, Agent.run for
    individual agent execution, and BaseTool._run for tool execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import agency_swarm  # noqa: F401
        except ImportError:
            logger.debug("agency_swarm not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Agency Swarm instrumentation")
            return False

        patched = False

        # Patch Agency.run (agency-level orchestration)
        try:
            wrapt.wrap_function_wrapper(
                "agency_swarm",
                "Agency.run",
                _agency_run_wrapper,
            )
            patched = True
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "agency_swarm.agency",
                    "Agency.run",
                    _agency_run_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch Agency.run: %s", exc)

        # Patch Agent.run (individual agent execution)
        try:
            wrapt.wrap_function_wrapper(
                "agency_swarm",
                "Agent.run",
                _agent_run_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "agency_swarm.agents.agent",
                    "Agent.run",
                    _agent_run_wrapper,
                )
            except Exception as exc:
                logger.debug("Failed to patch Agent.run: %s", exc)

        # Patch BaseTool._run (tool execution)
        try:
            wrapt.wrap_function_wrapper(
                "agency_swarm.tools",
                "BaseTool._run",
                _tool_run_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "agency_swarm.tools.base_tool",
                    "BaseTool._run",
                    _tool_run_wrapper,
                )
            except Exception as exc:
                logger.debug("Failed to patch BaseTool._run: %s", exc)

        # Also try to patch BaseTool.run (public entry point)
        try:
            wrapt.wrap_function_wrapper(
                "agency_swarm.tools",
                "BaseTool.run",
                _tool_run_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "agency_swarm.tools.base_tool",
                    "BaseTool.run",
                    _tool_run_wrapper,
                )
            except Exception as exc:
                logger.debug("Failed to patch BaseTool.run: %s", exc)

        if not patched:
            logger.debug("Could not find Agency Swarm methods to patch")
            return False

        self._instrumented = True
        logger.debug("Agency Swarm instrumented (Agency.run + Agent.run + BaseTool._run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument Agency.run
        try:
            import agency_swarm

            agency_cls = getattr(agency_swarm, "Agency", None)
            if agency_cls:
                method = getattr(agency_cls, "run", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    agency_cls.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from agency_swarm.agency import Agency

            method = getattr(Agency, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Agency.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument Agent.run
        try:
            import agency_swarm

            agent_cls = getattr(agency_swarm, "Agent", None)
            if agent_cls:
                method = getattr(agent_cls, "run", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    agent_cls.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from agency_swarm.agents.agent import Agent

            method = getattr(Agent, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Agent.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument BaseTool._run and BaseTool.run
        try:
            from agency_swarm.tools import BaseTool

            for attr in ("_run", "run"):
                method = getattr(BaseTool, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(BaseTool, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            from agency_swarm.tools.base_tool import BaseTool

            for attr in ("_run", "run"):
                method = getattr(BaseTool, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(BaseTool, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Agency Swarm uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Agency Swarm instances
# ---------------------------------------------------------------------------


def _extract_agency_name(instance) -> str:
    """Extract agency name from an Agency Swarm Agency instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        agency_chart = getattr(instance, "agency_chart", None)
        if agency_chart:
            return f"agency({len(agency_chart)}_agents)"
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "agency_swarm.agency"


def _extract_agent_name(instance) -> str:
    """Extract agent name from an Agency Swarm Agent instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        description = getattr(instance, "description", None)
        if description:
            return str(description)[:100]
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "agency_swarm.agent"


def _extract_agent_names(instance) -> str:
    """Extract names of all agents in an Agency."""
    try:
        agents = getattr(instance, "agents", None)
        if agents and isinstance(agents, (list, tuple)):
            names = []
            for agent in agents:
                name = getattr(agent, "name", None)
                if name:
                    names.append(str(name))
            if names:
                return ", ".join(names)
    except Exception:
        pass
    try:
        agency_chart = getattr(instance, "agency_chart", None)
        if agency_chart and isinstance(agency_chart, list):
            names = []
            for entry in agency_chart:
                if isinstance(entry, (list, tuple)):
                    for agent in entry:
                        name = getattr(agent, "name", None)
                        if name and str(name) not in names:
                            names.append(str(name))
                else:
                    name = getattr(entry, "name", None)
                    if name and str(name) not in names:
                        names.append(str(name))
            if names:
                return ", ".join(names)
    except Exception:
        pass
    return ""


def _extract_tool_name(instance) -> str:
    """Extract tool name from an Agency Swarm BaseTool instance."""
    try:
        name = getattr(instance, "name", None) or getattr(type(instance), "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "agency_swarm.tool"


def _extract_message(args, kwargs) -> str:
    """Extract message content from Agency.run or Agent.run arguments."""
    # Agency.run(message=...) or positional first arg
    message = kwargs.get("message", "")
    if not message and args:
        message = args[0] if isinstance(args[0], str) else ""
    return str(message)[:500] if message else ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _agency_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agency.run`` -- agency-level orchestration."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agency_name = _extract_agency_name(instance)
    agent_names = _extract_agent_names(instance)
    message = _extract_message(args, kwargs)

    try:
        span = start_agent_span(
            agent_name=agency_name,
            workflow_name="agency_swarm_agency_run",
        )
        span.set_attribute("waxell.agent.framework", "agency_swarm")
        span.set_attribute("waxell.agent.name", agency_name)
        if agent_names:
            span.set_attribute("waxell.agency_swarm.agent_names", agent_names)
        if message:
            span.set_attribute("waxell.agency_swarm.input_message", message)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agency_result_attributes(span, result, agency_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agent.run`` -- individual agent execution."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    message = _extract_message(args, kwargs)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="agency_swarm_agent_run",
        )
        span.set_attribute("waxell.agent.framework", "agency_swarm")
        span.set_attribute("waxell.agent.name", agent_name)
        if message:
            span.set_attribute("waxell.agency_swarm.input_message", message)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _tool_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseTool._run`` / ``BaseTool.run`` -- tool execution."""
    try:
        from ..tracing.spans import start_tool_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    tool_name = _extract_tool_name(instance)

    try:
        span = start_tool_span(tool_name=tool_name)
        span.set_attribute("waxell.agent.framework", "agency_swarm")
        span.set_attribute("waxell.agency_swarm.tool_name", tool_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_tool_result_attributes(span, result, tool_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_agency_result_attributes(span, result, agency_name: str) -> None:
    """Set result attributes on the span for agency execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.agency_swarm.response_preview", str(result)[:200])
            span.set_attribute("waxell.agency_swarm.status", "success")
        else:
            span.set_attribute("waxell.agency_swarm.status", "completed")
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"agency_swarm:agency:{agency_name}",
                output={"agency_name": agency_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_agent_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for agent execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.agency_swarm.response_preview", str(result)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"agency_swarm:agent:{agent_name}",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_tool_result_attributes(span, result, tool_name: str) -> None:
    """Set result attributes on the span for tool execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.agency_swarm.tool_result_preview", str(result)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"agency_swarm:tool:{tool_name}",
                output={"tool_name": tool_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
