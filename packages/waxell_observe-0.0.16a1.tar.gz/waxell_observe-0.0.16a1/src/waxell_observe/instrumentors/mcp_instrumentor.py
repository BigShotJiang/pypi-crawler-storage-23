"""MCP (Model Context Protocol) auto-instrumentor for waxell-observe.

Monkey-patches ``mcp.client.session.ClientSession.call_tool`` to emit
OTel tool spans and record to the Waxell HTTP API.

MCP tool call pattern:
  - ``session.call_tool(name="tool_name", arguments={...})``
  - Returns ``CallToolResult`` with ``content`` list and ``isError`` flag

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MCPInstrumentor(BaseInstrumentor):
    """Instrumentor for MCP client (``mcp`` package).

    Patches ``ClientSession.call_tool`` to trace MCP tool calls.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import mcp.client.session  # noqa: F401
        except ImportError:
            logger.debug("mcp package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping MCP instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "mcp.client.session",
                "ClientSession.call_tool",
                _call_tool_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch ClientSession.call_tool: %s", exc)
            return False

        self._instrumented = True
        logger.debug("MCP ClientSession.call_tool instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import mcp.client.session as mod

            if hasattr(mod.ClientSession.call_tool, "__wrapped__"):
                mod.ClientSession.call_tool = mod.ClientSession.call_tool.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("MCP ClientSession.call_tool uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _call_tool_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ClientSession.call_tool``.

    MCP call_tool is always async.
    """
    # Extract tool name from args/kwargs
    tool_name = "unknown"
    arguments = {}
    if args:
        tool_name = str(args[0]) if args else "unknown"
        if len(args) > 1:
            arguments = args[1] if isinstance(args[1], dict) else {}
    tool_name = kwargs.get("name", tool_name)
    arguments = kwargs.get("arguments", arguments)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name=tool_name, tool_type="mcp")
        if arguments:
            import json
            try:
                span.set_attribute("waxell.mcp.arguments", json.dumps(arguments)[:1000])
            except Exception:
                pass
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            is_error = getattr(result, "isError", False)
            content = getattr(result, "content", [])

            span.set_attribute("waxell.mcp.is_error", bool(is_error))
            span.set_attribute("waxell.mcp.content_count", len(content))

            # Extract text preview from result content
            result_preview = ""
            for item in content:
                text = getattr(item, "text", None)
                if text:
                    result_preview = str(text)[:500]
                    break

            span.set_attribute("waxell.mcp.result_preview", result_preview)
        except Exception:
            pass

        # Record to context
        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                output = {}
                try:
                    content = getattr(result, "content", [])
                    for item in content:
                        text = getattr(item, "text", None)
                        if text:
                            output["result"] = str(text)[:500]
                            break
                except Exception:
                    pass
                ctx.record_tool_call(
                    name=tool_name,
                    input=arguments,
                    output=output,
                    tool_type="mcp",
                    status="error" if getattr(result, "isError", False) else "ok",
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
