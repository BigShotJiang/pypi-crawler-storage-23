"""Letta (formerly MemGPT) auto-instrumentor for waxell-observe.

Monkey-patches Letta's client ``send_message`` methods to emit OTel spans
and record to the Waxell HTTP API.

Patched methods:
  - letta.client.client.LocalClient.send_message  (agent span)
  - letta.client.client.RESTClient.send_message   (agent span)

All wrapper code is wrapped in try/except -- never breaks the user's Letta calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LettaInstrumentor(BaseInstrumentor):
    """Instrumentor for the Letta framework (``letta`` package).

    Patches LocalClient.send_message and RESTClient.send_message to
    capture agent execution spans with message metadata.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import letta  # noqa: F401
        except ImportError:
            logger.debug("letta package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Letta instrumentation")
            return False

        patched = False

        # Patch LocalClient.send_message
        try:
            wrapt.wrap_function_wrapper(
                "letta.client.client",
                "LocalClient.send_message",
                _send_message_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch LocalClient.send_message: %s", exc)

        # Patch RESTClient.send_message
        try:
            wrapt.wrap_function_wrapper(
                "letta.client.client",
                "RESTClient.send_message",
                _send_message_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch RESTClient.send_message: %s", exc)

        if not patched:
            logger.debug("Could not find any Letta client methods to patch")
            return False

        self._instrumented = True
        logger.debug("Letta instrumented (LocalClient.send_message, RESTClient.send_message)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import importlib

            mod = importlib.import_module("letta.client.client")

            for cls_name in ("LocalClient", "RESTClient"):
                try:
                    cls = getattr(mod, cls_name, None)
                    if cls is not None:
                        method = getattr(cls, "send_message", None)
                        if method is not None and hasattr(method, "__wrapped__"):
                            setattr(cls, "send_message", method.__wrapped__)
                except Exception:
                    pass
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Letta uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _send_message_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``LocalClient.send_message`` / ``RESTClient.send_message``.

    Captures agent execution spans with metadata about the agent and
    response messages.
    """
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract agent_id and message info
    agent_id = ""
    message_text = ""
    client_type = type(instance).__name__ if instance is not None else "unknown"

    try:
        agent_id = str(kwargs.get("agent_id", ""))
        if not agent_id and args:
            agent_id = str(args[0])
    except Exception:
        pass

    try:
        message = kwargs.get("message", "")
        if not message and len(args) > 1:
            message = args[1]
        message_text = str(message)[:200] if message else ""
    except Exception:
        pass

    agent_label = f"letta-agent-{agent_id[:8]}" if agent_id else "letta-agent"

    try:
        span = start_agent_span(
            agent_name=agent_label,
            workflow_name="letta-conversation",
        )
        span.set_attribute("waxell.letta.agent_id", agent_id)
        span.set_attribute("waxell.letta.message_type", "user_message")
        span.set_attribute("waxell.letta.client_type", client_type)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            response_count = 0
            assistant_count = 0
            function_call_count = 0

            if result is not None:
                messages = getattr(result, "messages", None)
                if messages is not None and isinstance(messages, list):
                    response_count = len(messages)
                    for msg in messages:
                        msg_type = getattr(msg, "message_type", None)
                        if msg_type is None:
                            msg_type = getattr(msg, "role", "")
                        msg_type_str = str(msg_type)
                        if "assistant" in msg_type_str.lower():
                            assistant_count += 1
                        elif "function" in msg_type_str.lower() or "tool" in msg_type_str.lower():
                            function_call_count += 1

            span.set_attribute("waxell.letta.response_messages_count", response_count)
            span.set_attribute("waxell.letta.assistant_messages_count", assistant_count)
            span.set_attribute("waxell.letta.function_call_count", function_call_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Letta send_message span attributes: %s", attr_exc)

        try:
            _record_send_message(
                agent_id=agent_id,
                message_preview=message_text,
                response_count=response_count,
                assistant_count=assistant_count,
                function_call_count=function_call_count,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording helpers
# ---------------------------------------------------------------------------


def _record_send_message(
    agent_id: str,
    message_preview: str,
    response_count: int,
    assistant_count: int,
    function_call_count: int,
) -> None:
    """Record a Letta send_message to the HTTP path (context or collector)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        try:
            ctx.record_step(
                "agent:letta.send_message",
                output={
                    "agent_id": agent_id,
                    "message_preview": message_preview,
                    "response_messages_count": response_count,
                    "assistant_messages_count": assistant_count,
                    "function_call_count": function_call_count,
                },
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
