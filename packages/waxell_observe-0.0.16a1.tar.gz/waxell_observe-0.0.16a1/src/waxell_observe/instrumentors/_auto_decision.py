"""Shared auto-decision recording for LLM instrumentors.

When an LLM response contains tool_calls / tool_use / function_calls, the
model made a *decision* to use a tool rather than respond directly. This
module provides a single function that all provider instrumentors call to
auto-record both the decision and the tool calls.

Usage from an instrumentor::

    from ._auto_decision import record_tool_decisions

    # After capturing the LLM response:
    record_tool_decisions(
        tool_calls=[{"name": "web_search", "input": {"q": "..."}}],
        available_tools=["web_search", "calculator"],  # from request kwargs
    )
"""

from __future__ import annotations

import logging
from typing import Any

from ._context_var import _current_context

logger = logging.getLogger(__name__)


def record_tool_decisions(
    tool_calls: list[dict[str, Any]],
    available_tools: list[str] | None = None,
) -> None:
    """Record auto-detected decisions and tool calls from an LLM response.

    Each tool call in the response is recorded as:
    1. A **decision** — "model chose tool X from [available tools]"
    2. A **tool call** — the tool invocation itself

    Args:
        tool_calls: List of dicts with at least ``name`` and optionally
            ``input`` (str or dict) and ``id``.
        available_tools: Names of all tools the model could have chosen from
            (extracted from the request's ``tools`` parameter). If None,
            only the chosen tools are listed.
    """
    ctx = _current_context.get()
    if ctx is None or not tool_calls:
        return

    try:
        chosen_names = [tc["name"] for tc in tool_calls]

        # Record the decision: model selected these tools from the available set
        options = available_tools or chosen_names
        if len(chosen_names) == 1:
            ctx.record_decision(
                name=f"tool_call:{chosen_names[0]}",
                options=options,
                chosen=chosen_names[0],
                reasoning="Auto-detected from LLM tool_calls response",
                instrumentation_type="auto",
            )
        else:
            # Multiple tool calls in one response — record as a single
            # multi-select decision
            ctx.record_decision(
                name="tool_calls",
                options=options,
                chosen=", ".join(chosen_names),
                reasoning=f"Auto-detected {len(chosen_names)} parallel tool calls from LLM response",
                instrumentation_type="auto",
            )

        # Record each tool call
        for tc in tool_calls:
            ctx.record_tool_call(
                name=tc["name"],
                input=tc.get("input", ""),
                tool_type="function",
            )

    except Exception:
        pass  # Never break user code


def extract_tool_names_from_request(kwargs: dict) -> list[str]:
    """Extract available tool names from the request kwargs.

    Works with:
    - OpenAI/Groq/Mistral: ``tools=[{"type":"function", "function":{"name":"..."}}]``
    - Anthropic: ``tools=[{"name":"..."}]``
    - Bedrock: ``toolConfig.tools[].toolSpec.name``
    """
    tools = kwargs.get("tools")
    if not tools:
        return []

    names = []
    for t in tools:
        if isinstance(t, dict):
            # OpenAI/Groq/Mistral format
            func = t.get("function", {})
            if isinstance(func, dict) and "name" in func:
                names.append(func["name"])
            # Anthropic format
            elif "name" in t:
                names.append(t["name"])
        # Pydantic model objects
        elif hasattr(t, "function") and hasattr(t.function, "name"):
            names.append(t.function.name)
        elif hasattr(t, "name"):
            names.append(t.name)

    return names
