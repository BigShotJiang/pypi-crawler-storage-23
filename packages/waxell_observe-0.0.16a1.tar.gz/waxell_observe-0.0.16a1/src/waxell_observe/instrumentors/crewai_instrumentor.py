"""CrewAI auto-instrumentor for waxell-observe.

Monkey-patches ``crewai.Crew.kickoff``, ``crewai.Agent.execute_task``,
and ``crewai.Task.execute_sync`` to emit OTel spans and record to
the Waxell HTTP API.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CrewAIInstrumentor(BaseInstrumentor):
    """Instrumentor for the CrewAI framework (``crewai`` package).

    Patches Crew.kickoff, Agent.execute_task, and Task execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import crewai  # noqa: F401
        except ImportError:
            logger.debug("crewai not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping CrewAI instrumentation")
            return False

        patched = False

        # Patch Crew.kickoff (the main entry point)
        try:
            wrapt.wrap_function_wrapper(
                "crewai",
                "Crew.kickoff",
                _kickoff_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Crew.kickoff: %s", exc)

        # Patch Crew.kickoff_async
        try:
            wrapt.wrap_function_wrapper(
                "crewai",
                "Crew.kickoff_async",
                _kickoff_async_wrapper,
            )
        except Exception:
            pass

        # Patch Agent.execute_task
        try:
            wrapt.wrap_function_wrapper(
                "crewai",
                "Agent.execute_task",
                _agent_execute_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find CrewAI methods to patch")
            return False

        self._instrumented = True
        logger.debug("CrewAI instrumented (Crew.kickoff + Agent.execute_task)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import crewai

            for cls_name, method_name in [
                ("Crew", "kickoff"),
                ("Crew", "kickoff_async"),
                ("Agent", "execute_task"),
            ]:
                cls = getattr(crewai, cls_name, None)
                if cls:
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("CrewAI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _kickoff_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Crew.kickoff``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    crew_name = getattr(instance, "name", None) or "crewai-crew"
    agent_names = []
    try:
        for agent in getattr(instance, "agents", []):
            agent_names.append(getattr(agent, "role", "unknown"))
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=crew_name,
            workflow_name="crew_kickoff",
        )
        span.set_attribute("waxell.crewai.agent_count", len(agent_names))
        span.set_attribute("waxell.crewai.agents", agent_names)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_crew_result(result, crew_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _kickoff_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Crew.kickoff_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    crew_name = getattr(instance, "name", None) or "crewai-crew"

    try:
        span = start_agent_span(
            agent_name=crew_name,
            workflow_name="crew_kickoff_async",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_crew_result(result, crew_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_execute_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agent.execute_task``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_role = getattr(instance, "role", "unknown-agent")
    task_desc = ""
    if args:
        task = args[0]
        task_desc = str(getattr(task, "description", ""))[:200]

    try:
        span = start_step_span(step_name=f"agent:{agent_role}")
        span.set_attribute("waxell.crewai.agent_role", agent_role)
        span.set_attribute("waxell.crewai.task_description", task_desc)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    f"agent:{agent_role}",
                    output={"result_preview": str(result)[:200]},
                )
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_crew_result(result, crew_name: str) -> None:
    """Record crew execution result to context."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "crew_complete",
            output={"crew": crew_name, "result_preview": str(result)[:500]},
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
