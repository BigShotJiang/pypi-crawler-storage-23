"""FalkorDB auto-instrumentor for waxell-observe.

Monkey-patches FalkorDB Graph.query and Graph.ro_query methods to emit
retrieval spans for graph database queries.

Patched methods:
  - ``falkordb.Graph.query``     (retrieval span for Cypher queries)
  - ``falkordb.Graph.ro_query``  (retrieval span for read-only Cypher queries)

All wrapper code is wrapped in try/except -- never breaks the user's FalkorDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FalkorDBInstrumentor(BaseInstrumentor):
    """Instrumentor for the FalkorDB Python driver.

    Patches ``Graph.query`` for read-write queries and ``Graph.ro_query``
    for read-only queries.  All queries get retrieval spans since FalkorDB
    is typically used for graph-based retrieval in agent pipelines.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import falkordb  # noqa: F401
        except ImportError:
            logger.debug("falkordb package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping FalkorDB instrumentation")
            return False

        patched_any = False

        # --- Graph.query ---
        try:
            wrapt.wrap_function_wrapper(
                "falkordb",
                "Graph.query",
                _sync_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch falkordb Graph.query: %s", exc)

        # --- Graph.ro_query (read-only) ---
        try:
            wrapt.wrap_function_wrapper(
                "falkordb",
                "Graph.ro_query",
                _sync_ro_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch falkordb Graph.ro_query: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any falkordb Graph methods")
            return False

        self._instrumented = True
        logger.debug("FalkorDB instrumented (Graph.query, Graph.ro_query)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore Graph.query
        try:
            import falkordb

            graph_cls = getattr(falkordb, "Graph", None)
            if graph_cls is not None:
                method = getattr(graph_cls, "query", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    graph_cls.query = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore Graph.ro_query
        try:
            import falkordb

            graph_cls = getattr(falkordb, "Graph", None)
            if graph_cls is not None:
                method = getattr(graph_cls, "ro_query", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    graph_cls.ro_query = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("FalkorDB uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the Cypher query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", kwargs.get("q", "")))


def _truncate_query(query: str, max_len: int = 200) -> str:
    """Truncate a Cypher query for span labelling."""
    if len(query) > max_len:
        return query[:max_len] + "..."
    return query


def _extract_graph_name(instance) -> str:
    """Extract the graph name from the Graph instance."""
    try:
        if hasattr(instance, "name"):
            return str(instance.name)
        if hasattr(instance, "_name"):
            return str(instance._name)
    except Exception:
        pass
    return ""


def _extract_result_count(response) -> int:
    """Extract result count from a FalkorDB query response."""
    try:
        if hasattr(response, "result_set") and response.result_set is not None:
            return len(response.result_set)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for falkordb Graph.query -- instruments Cypher queries."""
    query = _extract_query(args, kwargs)
    return _sync_query_path(wrapped, instance, args, kwargs, query, read_only=False)


def _sync_ro_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for falkordb Graph.ro_query -- instruments read-only queries."""
    query = _extract_query(args, kwargs)
    return _sync_query_path(wrapped, instance, args, kwargs, query, read_only=True)


def _sync_query_path(wrapped, instance, args, kwargs, query, read_only=False):
    """Handle FalkorDB queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    graph_name = _extract_graph_name(instance)

    try:
        span = start_retrieval_span(query=query_preview, source="falkordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "falkordb")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.source", "falkordb")
            if graph_name:
                span.set_attribute("db.falkordb.graph", graph_name)
            result_count = _extract_result_count(response)
            if result_count:
                span.set_attribute("db.falkordb.result_count", result_count)
            if read_only:
                span.set_attribute("db.falkordb.read_only", True)
        except Exception as attr_exc:
            logger.debug("Failed to set falkordb span attributes: %s", attr_exc)

        try:
            _record_falkordb_retrieval(query=query_preview, graph_name=graph_name)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_falkordb_retrieval(
    query: str,
    graph_name: str = "",
) -> None:
    """Record a FalkorDB retrieval operation to the context path.

    FalkorDB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="falkordb",
        )
