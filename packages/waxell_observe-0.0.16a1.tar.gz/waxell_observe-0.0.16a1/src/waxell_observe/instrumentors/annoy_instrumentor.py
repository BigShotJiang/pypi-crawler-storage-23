"""Annoy auto-instrumentor for waxell-observe.

Monkey-patches Spotify's Annoy library to emit OTel spans for
vector search and index operations.

Patched methods:
  - annoy.AnnoyIndex.get_nns_by_vector  (retrieval span)
  - annoy.AnnoyIndex.get_nns_by_item    (retrieval span)
  - annoy.AnnoyIndex.add_item           (tool span)
  - annoy.AnnoyIndex.build              (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's Annoy calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AnnoyInstrumentor(BaseInstrumentor):
    """Instrumentor for the Annoy library (``annoy`` package).

    Patches ``AnnoyIndex.get_nns_by_vector`` and ``AnnoyIndex.get_nns_by_item``
    for retrieval spans, and ``AnnoyIndex.add_item`` and ``AnnoyIndex.build``
    for tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import annoy  # noqa: F401
        except ImportError:
            logger.debug("annoy package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Annoy instrumentation")
            return False

        patched_any = False

        # Patch AnnoyIndex.get_nns_by_vector (nearest-neighbor retrieval by vector)
        try:
            wrapt.wrap_function_wrapper(
                "annoy",
                "AnnoyIndex.get_nns_by_vector",
                _get_nns_by_vector_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch annoy.AnnoyIndex.get_nns_by_vector: %s", exc)

        # Patch AnnoyIndex.get_nns_by_item (nearest-neighbor retrieval by item id)
        try:
            wrapt.wrap_function_wrapper(
                "annoy",
                "AnnoyIndex.get_nns_by_item",
                _get_nns_by_item_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch annoy.AnnoyIndex.get_nns_by_item: %s", exc)

        # Patch AnnoyIndex.add_item (insert vector)
        try:
            wrapt.wrap_function_wrapper(
                "annoy",
                "AnnoyIndex.add_item",
                _add_item_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch annoy.AnnoyIndex.add_item: %s", exc)

        # Patch AnnoyIndex.build (build the index)
        try:
            wrapt.wrap_function_wrapper(
                "annoy",
                "AnnoyIndex.build",
                _build_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch annoy.AnnoyIndex.build: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any Annoy AnnoyIndex methods")
            return False

        self._instrumented = True
        logger.debug("Annoy AnnoyIndex instrumented (get_nns_by_vector, get_nns_by_item, add_item, build)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import annoy

            cls = getattr(annoy, "AnnoyIndex", None)
            if cls is not None:
                for method_name in ("get_nns_by_vector", "get_nns_by_item", "add_item", "build"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Annoy AnnoyIndex uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_metric(instance) -> str:
    """Extract the distance metric from an AnnoyIndex instance."""
    try:
        metric = getattr(instance, "metric", None)
        if metric is not None:
            return str(metric)
        # Annoy stores the metric as the second constructor arg
        # accessible via f attribute on some builds
        f = getattr(instance, "f", None)
        if f is not None:
            return ""
    except Exception:
        pass
    return ""


def _get_dimension(instance) -> int:
    """Extract the vector dimension from an AnnoyIndex instance."""
    try:
        f = getattr(instance, "f", None)
        if f is not None:
            return int(f)
    except Exception:
        pass
    return 0


def _get_n_items(instance) -> int:
    """Extract the number of items in the index."""
    try:
        n = getattr(instance, "get_n_items", None)
        if callable(n):
            return int(n())
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _get_nns_by_vector_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``AnnoyIndex.get_nns_by_vector``.

    Args layout: index.get_nns_by_vector(vector, n, search_k=-1, include_distances=False)
        vector: list of floats
        n: int, number of nearest neighbors
    Returns: list of item indices, or (indices, distances) if include_distances=True
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    n = 0
    dimension = _get_dimension(instance)
    metric = _get_metric(instance)
    n_items = _get_n_items(instance)

    try:
        if len(args) > 1:
            n = int(args[1])
        n = int(kwargs.get("n", n))
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="annoy.get_nns_by_vector", source="annoy")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Count actual results
            results_count = 0
            if isinstance(result, (list, tuple)):
                if result and isinstance(result[0], (list, tuple)):
                    # (indices, distances) tuple
                    results_count = len(result[0])
                else:
                    results_count = len(result)

            span.set_attribute("waxell.retrieval.source", "annoy")
            span.set_attribute("waxell.retrieval.operation", "get_nns_by_vector")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            span.set_attribute("waxell.retrieval.top_k", n)
            if dimension:
                span.set_attribute("waxell.annoy.dimension", dimension)
            if metric:
                span.set_attribute("waxell.annoy.metric", metric)
            if n_items:
                span.set_attribute("waxell.annoy.n_items", n_items)
        except Exception as attr_exc:
            logger.debug("Failed to set Annoy get_nns_by_vector span attributes: %s", attr_exc)

        try:
            _record_annoy_retrieval(
                query="annoy.get_nns_by_vector",
                results_count=results_count if "results_count" in dir() else 0,
                top_k=n,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _get_nns_by_item_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``AnnoyIndex.get_nns_by_item``.

    Args layout: index.get_nns_by_item(item, n, search_k=-1, include_distances=False)
        item: int, item index
        n: int, number of nearest neighbors
    Returns: list of item indices, or (indices, distances) if include_distances=True
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    n = 0
    item = 0
    dimension = _get_dimension(instance)
    metric = _get_metric(instance)
    n_items = _get_n_items(instance)

    try:
        if args:
            item = int(args[0])
        if len(args) > 1:
            n = int(args[1])
        n = int(kwargs.get("n", n))
    except Exception:
        pass

    try:
        span = start_retrieval_span(query=f"annoy.get_nns_by_item(item={item})", source="annoy")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = 0
            if isinstance(result, (list, tuple)):
                if result and isinstance(result[0], (list, tuple)):
                    results_count = len(result[0])
                else:
                    results_count = len(result)

            span.set_attribute("waxell.retrieval.source", "annoy")
            span.set_attribute("waxell.retrieval.operation", "get_nns_by_item")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            span.set_attribute("waxell.retrieval.top_k", n)
            if dimension:
                span.set_attribute("waxell.annoy.dimension", dimension)
            if metric:
                span.set_attribute("waxell.annoy.metric", metric)
            if n_items:
                span.set_attribute("waxell.annoy.n_items", n_items)
        except Exception as attr_exc:
            logger.debug("Failed to set Annoy get_nns_by_item span attributes: %s", attr_exc)

        try:
            _record_annoy_retrieval(
                query=f"annoy.get_nns_by_item(item={item})",
                results_count=results_count if "results_count" in dir() else 0,
                top_k=n,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _add_item_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``AnnoyIndex.add_item``.

    Args layout: index.add_item(i, vector)
        i: int, item index
        vector: list of floats
    """
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    item_id = 0
    dimension = _get_dimension(instance)

    try:
        if args:
            item_id = int(args[0])
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="annoy.add_item", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "add_item")
            span.set_attribute("waxell.annoy.item_id", item_id)
            if dimension:
                span.set_attribute("waxell.annoy.dimension", dimension)
        except Exception as attr_exc:
            logger.debug("Failed to set Annoy add_item span attributes: %s", attr_exc)

        try:
            _record_annoy_write(
                operation="add_item",
                item_id=item_id,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _build_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``AnnoyIndex.build``.

    Args layout: index.build(n_trees, n_jobs=-1)
        n_trees: int, number of trees to build
    """
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    n_trees = 0
    dimension = _get_dimension(instance)
    n_items = _get_n_items(instance)

    try:
        if args:
            n_trees = int(args[0])
        n_trees = int(kwargs.get("n_trees", n_trees))
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="annoy.build", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "build")
            span.set_attribute("waxell.annoy.n_trees", n_trees)
            if dimension:
                span.set_attribute("waxell.annoy.dimension", dimension)
            if n_items:
                span.set_attribute("waxell.annoy.n_items", n_items)
        except Exception as attr_exc:
            logger.debug("Failed to set Annoy build span attributes: %s", attr_exc)

        try:
            _record_annoy_write(
                operation="build",
                n_trees=n_trees,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_annoy_retrieval(
    query: str,
    results_count: int,
    top_k: int,
) -> None:
    """Record an Annoy retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="annoy",
            results_count=results_count,
            top_k=top_k,
        )


def _record_annoy_write(
    operation: str,
    item_id: int = 0,
    n_trees: int = 0,
) -> None:
    """Record an Annoy write operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"annoy.{operation}",
            input={"item_id": item_id, "n_trees": n_trees},
            tool_type="vectordb",
        )
