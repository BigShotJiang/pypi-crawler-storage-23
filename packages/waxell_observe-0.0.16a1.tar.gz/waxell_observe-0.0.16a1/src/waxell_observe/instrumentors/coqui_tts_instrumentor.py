"""Coqui TTS auto-instrumentor for waxell-observe.

Monkey-patches Coqui TTS methods to emit OTel step spans for
text-to-speech operations:
  - ``TTS.api.TTS.tts``          -- returns audio waveform (numpy array)
  - ``TTS.api.TTS.tts_to_file``  -- saves synthesized audio to file

The Coqui TTS library (``TTS`` package) methods accept:
  - ``text`` (str) -- the text to synthesize (first positional arg)
  - ``language`` (str) -- language code (keyword arg)
  - ``speaker`` (str) -- speaker name for multi-speaker models (keyword arg)
  - ``speaker_wav`` (str) -- path to reference wav for voice cloning

The model name is available on the TTS instance via ``self.model_name``.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CoquiTTSInstrumentor(BaseInstrumentor):
    """Instrumentor for the Coqui TTS library (``TTS`` package).

    Patches ``TTS.api.TTS.tts`` and ``TTS.api.TTS.tts_to_file``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import TTS.api  # noqa: F401
        except ImportError:
            logger.debug("TTS package (Coqui) not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Coqui TTS instrumentation")
            return False

        patched = False

        # Patch TTS.tts (returns waveform)
        try:
            wrapt.wrap_function_wrapper(
                "TTS.api",
                "TTS.tts",
                _sync_tts_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Coqui TTS.tts: %s", exc)

        # Patch TTS.tts_to_file (saves to file)
        try:
            wrapt.wrap_function_wrapper(
                "TTS.api",
                "TTS.tts_to_file",
                _sync_tts_to_file_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Coqui TTS.tts_to_file: %s", exc)

        if not patched:
            logger.debug("Could not find any Coqui TTS methods to patch")
            return False

        self._instrumented = True
        logger.debug("Coqui TTS instrumented (tts + tts_to_file)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from TTS import api as tts_api_module

            cls = getattr(tts_api_module, "TTS", None)
            if cls is not None:
                for attr in ("tts", "tts_to_file"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Coqui TTS uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_tts_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Coqui ``TTS.tts`` (returns audio waveform)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name, text_length, language, speaker = _extract_params(instance, args, kwargs)

    try:
        span = start_step_span(step_name="coqui.tts.generate")
        _set_request_attrs(span, model_name, text_length, language, speaker)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.coqui_tts.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("coqui.tts.tts", model_name, text_length, language, speaker, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_tts_to_file_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Coqui ``TTS.tts_to_file`` (saves to file)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name, text_length, language, speaker = _extract_params(instance, args, kwargs)

    try:
        span = start_step_span(step_name="coqui.tts.generate")
        _set_request_attrs(span, model_name, text_length, language, speaker)
        span.set_attribute("waxell.coqui_tts.output_type", "file")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.coqui_tts.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "coqui.tts.tts_to_file", model_name, text_length, language, speaker, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction helpers
# ---------------------------------------------------------------------------


def _extract_params(instance, args, kwargs) -> tuple:
    """Extract model_name, text_length, language, speaker from Coqui TTS args.

    Coqui TTS methods signature:
      tts(text, speaker=None, language=None, speaker_wav=None, ...)
      tts_to_file(text, file_path=None, speaker=None, language=None, ...)
    """
    model_name = ""
    text_length = 0
    language = ""
    speaker = ""

    try:
        # Get model name from the TTS instance
        model_name = str(getattr(instance, "model_name", "")) or ""
    except Exception:
        pass

    try:
        # text is the first positional argument
        text = ""
        if args:
            text = str(args[0]) if args[0] else ""
        if not text:
            text = str(kwargs.get("text", ""))
        text_length = len(text) if text else 0

        language = str(kwargs.get("language", ""))
        speaker = str(kwargs.get("speaker", ""))
    except Exception:
        pass

    return str(model_name), text_length, str(language), str(speaker)


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_request_attrs(
    span, model_name: str, text_length: int, language: str, speaker: str
) -> None:
    """Set request attributes for a Coqui TTS span."""
    if model_name:
        span.set_attribute("waxell.coqui_tts.model_name", model_name)
    if text_length:
        span.set_attribute("waxell.coqui_tts.text_length", text_length)
    if language:
        span.set_attribute("waxell.coqui_tts.language", language)
    if speaker:
        span.set_attribute("waxell.coqui_tts.speaker", speaker)


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(
    task: str,
    model_name: str,
    text_length: int,
    language: str,
    speaker: str,
    latency: float,
) -> None:
    """Record a Coqui TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_name or "coqui-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[tts text_length={text_length} lang={language} speaker={speaker}]",
        "response_preview": f"[tts model={model_name} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
