"""Vertex AI auto-instrumentor for waxell-observe.

Monkey-patches ``vertexai.generative_models.GenerativeModel.generate_content``
and ``generate_content_async`` to emit OTel spans and record to the
Waxell HTTP API.  Also patches ``ChatSession.send_message`` and
``send_message_async``, ``TextEmbeddingModel.get_embeddings``
for embedding instrumentation, and
``vertexai.preview.vision_models.ImageGenerationModel.generate_images``
for Imagen image generation instrumentation.

Vertex AI response format:
  - ``response.usage_metadata.prompt_token_count``
  - ``response.usage_metadata.candidates_token_count``
  - ``response.candidates[0].finish_reason`` (enum)

Vertex AI embedding response format:
  - Returns list of ``TextEmbedding`` objects, each with ``.values`` (list of floats)

Imagen response format:
  - Returns ``ImageGenerationResponse`` with ``.images`` list of generated images

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VertexAIInstrumentor(BaseInstrumentor):
    """Instrumentor for Google Cloud Vertex AI (``google-cloud-aiplatform`` package).

    Patches ``GenerativeModel.generate_content`` sync and async,
    ``ChatSession.send_message`` sync and async,
    ``TextEmbeddingModel.get_embeddings`` for embedding instrumentation, and
    ``ImageGenerationModel.generate_images`` for Imagen image generation.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import vertexai  # noqa: F401
        except ImportError:
            logger.debug("google-cloud-aiplatform not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Vertex AI instrumentation")
            return False

        # Patch GenerativeModel.generate_content (sync) -- required
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.generative_models",
                "GenerativeModel.generate_content",
                _sync_generate_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch GenerativeModel.generate_content: %s", exc)
            return False

        # Patch GenerativeModel.generate_content_async (async) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.generative_models",
                "GenerativeModel.generate_content_async",
                _async_generate_wrapper,
            )
        except Exception:
            logger.debug("Async generate_content_async not found -- sync-only instrumentation")

        # Patch ChatSession.send_message (sync) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.generative_models",
                "ChatSession.send_message",
                _sync_chat_wrapper,
            )
        except Exception:
            logger.debug("ChatSession.send_message not found -- chat instrumentation skipped")

        # Patch ChatSession.send_message_async (async) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.generative_models",
                "ChatSession.send_message_async",
                _async_chat_wrapper,
            )
        except Exception:
            logger.debug("ChatSession.send_message_async not found -- async chat instrumentation skipped")

        # Patch TextEmbeddingModel.get_embeddings -- optional
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.language_models",
                "TextEmbeddingModel.get_embeddings",
                _sync_embed_wrapper,
            )
        except Exception:
            logger.debug("TextEmbeddingModel.get_embeddings not found -- embedding instrumentation skipped")

        # Patch ImageGenerationModel.generate_images (Imagen) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "vertexai.preview.vision_models",
                "ImageGenerationModel.generate_images",
                _sync_imagen_wrapper,
            )
        except Exception:
            logger.debug("ImageGenerationModel.generate_images not found -- Imagen instrumentation skipped")

        self._instrumented = True
        logger.debug("Vertex AI GenerativeModel + Imagen instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from vertexai.generative_models import GenerativeModel

            if hasattr(GenerativeModel.generate_content, "__wrapped__"):
                GenerativeModel.generate_content = GenerativeModel.generate_content.__wrapped__
            if hasattr(GenerativeModel.generate_content_async, "__wrapped__"):
                GenerativeModel.generate_content_async = GenerativeModel.generate_content_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from vertexai.generative_models import ChatSession

            if hasattr(ChatSession.send_message, "__wrapped__"):
                ChatSession.send_message = ChatSession.send_message.__wrapped__
            if hasattr(ChatSession.send_message_async, "__wrapped__"):
                ChatSession.send_message_async = ChatSession.send_message_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from vertexai.language_models import TextEmbeddingModel

            if hasattr(TextEmbeddingModel.get_embeddings, "__wrapped__"):
                TextEmbeddingModel.get_embeddings = TextEmbeddingModel.get_embeddings.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from vertexai.preview.vision_models import ImageGenerationModel

            if hasattr(ImageGenerationModel.generate_images, "__wrapped__"):
                ImageGenerationModel.generate_images = ImageGenerationModel.generate_images.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Vertex AI GenerativeModel + Imagen uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_vertex_usage(response):
    """Extract token counts from Vertex AI response.usage_metadata."""
    tokens_in, tokens_out = 0, 0
    try:
        meta = getattr(response, "usage_metadata", None)
        if meta:
            tokens_in = getattr(meta, "prompt_token_count", 0) or 0
            tokens_out = getattr(meta, "candidates_token_count", 0) or 0
    except Exception:
        pass
    return tokens_in, tokens_out


def _extract_model_name(instance):
    """Get the model name from the GenerativeModel or ChatSession instance."""
    try:
        # Direct model attribute
        name = getattr(instance, "_model_name", None)
        if name:
            return name
        name = getattr(instance, "_model_id", None)
        if name:
            return name
        name = getattr(instance, "model_name", None)
        if name:
            return name
        # ChatSession wraps a GenerativeModel in _model
        model_ref = getattr(instance, "_model", None)
        if model_ref:
            name = getattr(model_ref, "_model_name", None)
            if name:
                return name
            name = getattr(model_ref, "_model_id", None)
            if name:
                return name
            name = getattr(model_ref, "model_name", None)
            if name:
                return name
    except Exception:
        pass
    return "vertex-unknown"


def _extract_finish_reason(response):
    """Extract finish reason from Vertex AI response."""
    try:
        candidates = getattr(response, "candidates", None)
        if candidates and len(candidates) > 0:
            reason = getattr(candidates[0], "finish_reason", None)
            if reason is not None:
                # finish_reason is an enum in Vertex AI SDK
                return str(reason.name) if hasattr(reason, "name") else str(reason)
    except Exception:
        pass
    return ""


def _extract_text(response):
    """Extract text content from Vertex AI response."""
    try:
        return response.text
    except (ValueError, AttributeError):
        try:
            candidates = getattr(response, "candidates", None)
            if candidates and len(candidates) > 0:
                parts = getattr(candidates[0].content, "parts", [])
                if parts:
                    return getattr(parts[0], "text", "")
        except Exception:
            pass
    return ""


def _build_prompt_preview(args, kwargs):
    """Build a prompt preview string from contents arg."""
    try:
        contents = args[0] if args else kwargs.get("contents", kwargs.get("content", ""))
        if isinstance(contents, str):
            return contents[:500]
        elif isinstance(contents, list):
            return str(contents[0])[:500] if contents else ""
        else:
            return str(contents)[:500]
    except Exception:
        return ""


def _build_messages_for_guard(args, kwargs):
    """Build messages list for prompt guard from contents arg."""
    try:
        contents = args[0] if args else kwargs.get("contents", kwargs.get("content", ""))
        if isinstance(contents, str):
            return [{"role": "user", "content": contents}]
        elif isinstance(contents, list):
            return [{"role": "user", "content": str(c)} for c in contents]
        else:
            return [{"role": "user", "content": str(contents)}]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Wrapper functions -- generate_content
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``GenerativeModel.generate_content``."""
    # --- Prompt guard ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = _build_messages_for_guard(args, kwargs)
        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = _extract_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vertex_ai")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_vertex_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_vertex(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


async def _async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``GenerativeModel.generate_content_async``."""
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = _build_messages_for_guard(args, kwargs)
        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _extract_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vertex_ai")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_vertex_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_vertex(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Wrapper functions -- ChatSession
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ChatSession.send_message``."""
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = _build_messages_for_guard(args, kwargs)
        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = _extract_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vertex_ai")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_vertex_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set chat span attributes: %s", attr_exc)

        try:
            _record_http_vertex(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ChatSession.send_message_async``."""
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = _build_messages_for_guard(args, kwargs)
        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _extract_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vertex_ai")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_vertex_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set async chat span attributes: %s", attr_exc)

        try:
            _record_http_vertex(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_vertex(response, model: str, args: tuple, kwargs: dict) -> None:
    """Record a Vertex AI LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in, tokens_out = _extract_vertex_usage(response)
    cost = estimate_cost(model, tokens_in, tokens_out)

    prompt_preview = _build_prompt_preview(args, kwargs)
    response_preview = _extract_text(response)[:500]

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Embedding wrapper
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``TextEmbeddingModel.get_embeddings``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = _extract_embedding_model_name(instance)

    # Count inputs: get_embeddings takes a list of texts as first arg
    texts = args[0] if args else kwargs.get("texts", [])
    if isinstance(texts, list):
        input_count = len(texts)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name="vertex_ai", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Response is a list of TextEmbedding objects, each with .values
            dimensions = 0
            if response and len(response) > 0:
                values = getattr(response[0], "values", None)
                if values is not None:
                    dimensions = len(values)

            # Estimate tokens from texts
            tokens = 0
            try:
                if isinstance(texts, list):
                    tokens = sum(len(str(t).split()) for t in texts)
                else:
                    tokens = len(str(texts).split())
            except Exception:
                pass

            cost = estimate_embedding_cost(model, tokens, "vertex_ai")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_vertex_embed(response, model, texts)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


def _extract_embedding_model_name(instance):
    """Get the model name from a TextEmbeddingModel instance."""
    try:
        name = getattr(instance, "_model_id", None)
        if name:
            return name
        name = getattr(instance, "_endpoint_name", None)
        if name:
            return name
        name = getattr(instance, "model_name", None)
        if name:
            return name
    except Exception:
        pass
    return "text-embedding-vertex"


def _record_http_vertex_embed(response, model: str, texts) -> None:
    """Record a Vertex AI embedding call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_embedding_cost

    tokens = 0
    try:
        if isinstance(texts, list):
            tokens = sum(len(str(t).split()) for t in texts)
        else:
            tokens = len(str(texts).split())
    except Exception:
        pass

    cost = estimate_embedding_cost(model, tokens, "vertex_ai")

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embedding:vertex_ai",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Imagen (image generation) wrapper
# ---------------------------------------------------------------------------


def _sync_imagen_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ImageGenerationModel.generate_images`` (Imagen)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract generation parameters
    prompt = kwargs.get("prompt", "") or (args[0] if args else "")
    negative_prompt = kwargs.get("negative_prompt", "") or ""
    number_of_images = kwargs.get("number_of_images", 1) or 1
    aspect_ratio = kwargs.get("aspect_ratio", "") or ""
    guidance_scale = kwargs.get("guidance_scale", None)

    # Extract model name from instance
    imagen_model = _extract_imagen_model_name(instance)

    try:
        span = start_step_span(step_name="vertex_ai.imagen.generate")
        span.set_attribute("waxell.vertex_ai.imagen_model", str(imagen_model))
        if prompt:
            prompt_str = str(prompt) if not isinstance(prompt, list) else str(prompt[0])
            span.set_attribute("waxell.vertex_ai.prompt_preview", prompt_str[:200])
        if negative_prompt:
            neg_str = str(negative_prompt) if not isinstance(negative_prompt, list) else str(negative_prompt[0])
            span.set_attribute("waxell.vertex_ai.negative_prompt_preview", neg_str[:200])
        span.set_attribute("waxell.vertex_ai.num_images", int(number_of_images))
        if aspect_ratio:
            span.set_attribute("waxell.vertex_ai.aspect_ratio", str(aspect_ratio))
        if guidance_scale is not None:
            span.set_attribute("waxell.vertex_ai.guidance_scale", float(guidance_scale))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            generation_time = time.time() - start_time
            span.set_attribute("waxell.vertex_ai.generation_time_seconds", round(generation_time, 2))

            # Count output images from the response
            output_images = 0
            try:
                images = getattr(result, "images", None)
                if images is not None:
                    if isinstance(images, list):
                        output_images = len(images)
                    else:
                        output_images = 1
                span.set_attribute("waxell.vertex_ai.output_images", output_images)
            except Exception:
                pass
        except Exception as attr_exc:
            logger.debug("Failed to set Imagen span attributes: %s", attr_exc)

        try:
            _record_http_imagen(result, imagen_model, prompt, number_of_images, kwargs)
        except Exception:
            pass

        return result
    finally:
        try:
            span.end()
        except Exception:
            pass


def _extract_imagen_model_name(instance) -> str:
    """Get the model name from an ImageGenerationModel instance."""
    try:
        name = getattr(instance, "_model_id", None)
        if name:
            return str(name)
        name = getattr(instance, "_model_name", None)
        if name:
            return str(name)
        name = getattr(instance, "model_name", None)
        if name:
            return str(name)
        # Fallback: use the endpoint name
        name = getattr(instance, "_endpoint_name", None)
        if name:
            return str(name)
    except Exception:
        pass
    return "imagen"


def _record_http_imagen(
    response, model: str, prompt: str, number_of_images: int, kwargs: dict,
) -> None:
    """Record a Vertex AI Imagen call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    prompt_preview = ""
    try:
        if isinstance(prompt, str):
            prompt_preview = prompt[:500]
        elif isinstance(prompt, list) and prompt:
            prompt_preview = str(prompt[0])[:500]
        else:
            prompt_preview = str(prompt)[:500]
    except Exception:
        pass

    output_images = 0
    try:
        images = getattr(response, "images", None)
        if images is not None:
            output_images = len(images) if isinstance(images, list) else 1
    except Exception:
        pass

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "imagen:generate",
        "prompt_preview": prompt_preview,
        "response_preview": f"[imagen generated {output_images} image(s)]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
