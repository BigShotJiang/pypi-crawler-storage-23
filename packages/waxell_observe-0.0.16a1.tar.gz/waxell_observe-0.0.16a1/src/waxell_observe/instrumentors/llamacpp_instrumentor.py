"""llama.cpp (llama-cpp-python) auto-instrumentor for waxell-observe.

Monkey-patches ``llama_cpp.Llama.__call__``, ``Llama.create_chat_completion``,
``Llama.create_completion``, and ``Llama.embed`` to emit LLM call and
embedding spans for local GGUF model inference.

Response format for chat completion:
    {
        "id": "chatcmpl-...",
        "object": "chat.completion",
        "model": "path/to/model.gguf",
        "choices": [{"message": {"role": "assistant", "content": "..."}, ...}],
        "usage": {"prompt_tokens": 20, "completion_tokens": 50, "total_tokens": 70}
    }

Response format for embeddings:
    {
        "object": "list",
        "data": [{"object": "embedding", "embedding": [0.1, 0.2, ...], "index": 0}],
        "model": "...",
        "usage": {"prompt_tokens": 10, "total_tokens": 10}
    }

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LlamaCppInstrumentor(BaseInstrumentor):
    """Instrumentor for the llama-cpp-python library (``llama_cpp`` package).

    Patches ``Llama.__call__``, ``Llama.create_chat_completion``,
    ``Llama.create_completion``, and ``Llama.embed``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import llama_cpp  # noqa: F401
        except ImportError:
            logger.debug("llama_cpp package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping llama.cpp instrumentation")
            return False

        patched = False

        # Patch Llama.__call__ (main inference entry point)
        try:
            wrapt.wrap_function_wrapper(
                "llama_cpp",
                "Llama.__call__",
                _sync_call_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch llama_cpp.Llama.__call__: %s", exc)

        # Patch Llama.create_chat_completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_cpp",
                "Llama.create_chat_completion",
                _sync_chat_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch llama_cpp.Llama.create_chat_completion: %s", exc)

        # Patch Llama.create_completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_cpp",
                "Llama.create_completion",
                _sync_completion_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch llama_cpp.Llama.create_completion: %s", exc)

        # Patch Llama.embed (embeddings)
        try:
            wrapt.wrap_function_wrapper(
                "llama_cpp",
                "Llama.embed",
                _sync_embed_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch llama_cpp.Llama.embed: %s", exc)

        if not patched:
            logger.debug("Could not find any llama_cpp.Llama methods to patch")
            return False

        self._instrumented = True
        logger.debug("llama_cpp.Llama instrumented (__call__ + create_chat_completion + create_completion + embed)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import llama_cpp

            for attr in ("__call__", "create_chat_completion", "create_completion", "embed"):
                try:
                    method = getattr(llama_cpp.Llama, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(llama_cpp.Llama, attr, method.__wrapped__)
                except (AttributeError, TypeError):
                    pass
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("llama_cpp.Llama uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from llama-cpp-python responses
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a Llama instance.

    Tries model_path, then metadata, then falls back to default.
    """
    for attr in ("model_path", "model_name"):
        try:
            val = getattr(instance, attr, None)
            if val and isinstance(val, str):
                return val
        except Exception:
            continue

    # Try metadata
    try:
        metadata = getattr(instance, "metadata", None)
        if metadata and isinstance(metadata, dict):
            model_name = metadata.get("general.name", "")
            if model_name:
                return str(model_name)
    except Exception:
        pass

    return "llamacpp-local"


def _extract_usage(response) -> tuple[int, int]:
    """Extract token counts from a llama-cpp-python response dict.

    Returns (tokens_in, tokens_out).
    """
    if not isinstance(response, dict):
        return 0, 0

    try:
        usage = response.get("usage", {})
        if isinstance(usage, dict):
            tokens_in = usage.get("prompt_tokens", 0) or 0
            tokens_out = usage.get("completion_tokens", 0) or 0
            return tokens_in, tokens_out
    except Exception:
        pass

    return 0, 0


def _extract_chat_content(response) -> str:
    """Extract assistant message content from a chat completion response."""
    if not isinstance(response, dict):
        return ""

    try:
        choices = response.get("choices", [])
        if choices and isinstance(choices, list):
            first = choices[0]
            if isinstance(first, dict):
                msg = first.get("message", {})
                if isinstance(msg, dict):
                    content = msg.get("content", "")
                    if content:
                        return str(content)[:500]
    except Exception:
        pass

    return ""


def _extract_completion_text(response) -> str:
    """Extract text from a raw completion response."""
    if not isinstance(response, dict):
        return ""

    try:
        choices = response.get("choices", [])
        if choices and isinstance(choices, list):
            first = choices[0]
            if isinstance(first, dict):
                text = first.get("text", "")
                if text:
                    return str(text)[:500]
    except Exception:
        pass

    return ""


def _extract_model_from_response(response, fallback: str) -> str:
    """Extract model name from a response dict, with fallback."""
    if isinstance(response, dict):
        model = response.get("model", "")
        if model:
            return str(model)
    return fallback


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_call_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``llama_cpp.Llama.__call__``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="llamacpp")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_usage(response)
            response_model = _extract_model_from_response(response, model)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_llamacpp(response, model, kwargs, task="__call__")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``llama_cpp.Llama.create_chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="llamacpp")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_usage(response)
            response_model = _extract_model_from_response(response, model)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_llamacpp(response, model, kwargs, task="create_chat_completion")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_completion_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``llama_cpp.Llama.create_completion``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="llamacpp")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_usage(response)
            response_model = _extract_model_from_response(response, model)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_llamacpp(response, model, kwargs, task="create_completion")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``llama_cpp.Llama.embed`` (embeddings)."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    # Count inputs: embed() accepts input as str or list
    input_data = kwargs.get("input", "")
    if args:
        input_data = args[0]
    if isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name="llamacpp", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = 0
            tokens_in = 0

            if isinstance(response, dict):
                # Standard embedding response format
                data_list = response.get("data", [])
                if data_list and isinstance(data_list, list):
                    first = data_list[0]
                    if isinstance(first, dict):
                        emb = first.get("embedding", [])
                        if emb and isinstance(emb, list):
                            dimensions = len(emb)

                usage = response.get("usage", {})
                if isinstance(usage, dict):
                    tokens_in = usage.get("prompt_tokens", 0) or 0
            elif isinstance(response, list):
                # Raw list of embeddings (older API)
                if response and isinstance(response[0], list):
                    dimensions = len(response[0])
                elif response and isinstance(response[0], (int, float)):
                    dimensions = len(response)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_llamacpp_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_llamacpp(
    response, request_model: str, kwargs: dict, task: str = "create_chat_completion"
) -> None:
    """Record a llama-cpp-python LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in, tokens_out = _extract_usage(response)

    # Extract prompt preview
    prompt_preview = ""
    if task == "create_chat_completion":
        messages = kwargs.get("messages", [])
        if messages and isinstance(messages, list):
            first = messages[0]
            if isinstance(first, dict):
                prompt_preview = str(first.get("content", ""))[:500]
    else:
        prompt = kwargs.get("prompt", "")
        if isinstance(prompt, str):
            prompt_preview = prompt[:500]
        elif isinstance(prompt, list) and prompt:
            prompt_preview = str(prompt[0])[:500]

    # Extract response preview
    if task == "create_chat_completion":
        response_preview = _extract_chat_content(response)
    else:
        response_preview = _extract_completion_text(response)

    response_model = _extract_model_from_response(response, request_model)

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "task": f"llamacpp.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_llamacpp_embed(response, model: str, kwargs: dict) -> None:
    """Record a llama-cpp-python embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in = 0
    if isinstance(response, dict):
        usage = response.get("usage", {})
        if isinstance(usage, dict):
            tokens_in = usage.get("prompt_tokens", 0) or 0

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "llamacpp.embed",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
