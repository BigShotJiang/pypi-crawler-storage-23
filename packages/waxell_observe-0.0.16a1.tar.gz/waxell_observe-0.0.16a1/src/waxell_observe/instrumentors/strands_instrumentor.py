"""AWS Strands Agents auto-instrumentor for waxell-observe.

Monkey-patches ``strands.Agent.__call__`` (or ``strands.agent.Agent.__call__``)
to emit OTel spans and record to the Waxell HTTP API.

AWS Strands Agents is a lightweight agent framework that uses Agent.__call__
as the primary execution entry point.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class StrandsInstrumentor(BaseInstrumentor):
    """Instrumentor for AWS Strands Agents (``strands-agents`` package).

    Patches Agent.__call__ for agent execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import strands  # noqa: F401
        except ImportError:
            logger.debug("strands not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Strands instrumentation")
            return False

        patched = False

        # Try patching strands.Agent.__call__ (top-level import)
        try:
            wrapt.wrap_function_wrapper(
                "strands",
                "Agent.__call__",
                _agent_call_wrapper,
            )
            patched = True
        except Exception:
            pass

        # Also try strands.agent.Agent.__call__ (submodule import)
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "strands.agent",
                    "Agent.__call__",
                    _agent_call_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch strands.agent.Agent.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find Strands Agent methods to patch")
            return False

        self._instrumented = True
        logger.debug("Strands Agents instrumented (Agent.__call__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import strands

            agent_cls = getattr(strands, "Agent", None)
            if agent_cls and hasattr(agent_cls.__call__, "__wrapped__"):
                agent_cls.__call__ = agent_cls.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import strands.agent as agent_mod

            if hasattr(agent_mod.Agent.__call__, "__wrapped__"):
                agent_mod.Agent.__call__ = agent_mod.Agent.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Strands Agents uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _agent_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agent.__call__`` -- Strands agent execution."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "strands.agent"

    # Extract model info
    model_name = ""
    try:
        model = getattr(instance, "model", None)
        if model:
            model_name = str(getattr(model, "model_id", None) or getattr(model, "model_name", None) or model)
    except Exception:
        pass

    # Extract tool info
    tool_names = []
    try:
        tools = getattr(instance, "tools", None) or {}
        if isinstance(tools, dict):
            tool_names = list(tools.keys())[:20]
        elif isinstance(tools, (list, tuple)):
            for t in tools:
                name = getattr(t, "name", None) or type(t).__name__
                tool_names.append(name)
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="strands_agent_call",
        )
        if model_name:
            span.set_attribute("waxell.strands.model", model_name)
        if tool_names:
            span.set_attribute("waxell.strands.tools", tool_names)
            span.set_attribute("waxell.strands.tool_count", len(tool_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span."""
    try:
        # Strands returns an AgentResult with message, stop_reason, etc.
        message = getattr(result, "message", None)
        stop_reason = getattr(result, "stop_reason", "")

        if stop_reason:
            span.set_attribute("waxell.strands.stop_reason", str(stop_reason))
        if message:
            content = getattr(message, "content", None)
            if content:
                span.set_attribute("waxell.strands.response_preview", str(content)[:200])
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                message = getattr(result, "message", None)
                if message:
                    content = getattr(message, "content", "")
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"strands:{agent_name}",
                output={"result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
