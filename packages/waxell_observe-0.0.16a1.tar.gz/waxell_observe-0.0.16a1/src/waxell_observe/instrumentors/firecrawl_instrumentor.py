"""Firecrawl auto-instrumentor for waxell-observe.

Monkey-patches ``firecrawl.FirecrawlApp`` methods to emit OTel tool spans
for web scraping operations commonly used in RAG pipelines:
  - ``scrape_url``  -- single page scrape
  - ``crawl_url``   -- multi-page crawl
  - ``map_url``     -- sitemap discovery
  - ``search``      -- search + scrape

These are HTTP-based tool operations, not LLM calls, so all spans use
``start_tool_span()`` instead of ``start_llm_span()``.

Cost is tracked externally by Firecrawl billing, so cost is always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FirecrawlInstrumentor(BaseInstrumentor):
    """Instrumentor for the Firecrawl SDK (``firecrawl`` package).

    Patches ``FirecrawlApp.scrape_url``, ``FirecrawlApp.crawl_url``,
    ``FirecrawlApp.map_url``, and ``FirecrawlApp.search``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import firecrawl  # noqa: F401
        except ImportError:
            logger.debug("firecrawl package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Firecrawl instrumentation")
            return False

        patched = False

        # Patch scrape_url
        try:
            wrapt.wrap_function_wrapper(
                "firecrawl",
                "FirecrawlApp.scrape_url",
                _scrape_url_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch firecrawl.FirecrawlApp.scrape_url: %s", exc)

        # Patch crawl_url
        try:
            wrapt.wrap_function_wrapper(
                "firecrawl",
                "FirecrawlApp.crawl_url",
                _crawl_url_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch firecrawl.FirecrawlApp.crawl_url: %s", exc)

        # Patch map_url
        try:
            wrapt.wrap_function_wrapper(
                "firecrawl",
                "FirecrawlApp.map_url",
                _map_url_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch firecrawl.FirecrawlApp.map_url: %s", exc)

        # Patch search
        try:
            wrapt.wrap_function_wrapper(
                "firecrawl",
                "FirecrawlApp.search",
                _search_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch firecrawl.FirecrawlApp.search: %s", exc)

        if not patched:
            logger.debug("Could not find any Firecrawl methods to patch")
            return False

        self._instrumented = True
        logger.debug("Firecrawl FirecrawlApp instrumented (scrape_url + crawl_url + map_url + search)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import firecrawl

            for attr in ("scrape_url", "crawl_url", "map_url", "search"):
                try:
                    method = getattr(firecrawl.FirecrawlApp, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(firecrawl.FirecrawlApp, attr, method.__wrapped__)
                except (AttributeError, TypeError):
                    pass
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Firecrawl FirecrawlApp uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Firecrawl responses
# ---------------------------------------------------------------------------


def _truncate_url(url: str, max_len: int = 200) -> str:
    """Truncate a URL for safe span attribute storage."""
    if not url or not isinstance(url, str):
        return ""
    return url[:max_len]


def _extract_format(kwargs: dict) -> str:
    """Extract the requested response format from kwargs."""
    # Firecrawl params may include formats like 'markdown', 'html', etc.
    params = kwargs.get("params", {})
    if isinstance(params, dict):
        fmt = params.get("formats", params.get("format", ""))
        if isinstance(fmt, list):
            return ",".join(str(f) for f in fmt)
        if fmt:
            return str(fmt)
    return ""


def _extract_result_count(response) -> int:
    """Extract result count from a Firecrawl response.

    Crawl and search responses may contain a list of results.
    """
    if response is None:
        return 0

    try:
        # Dict with various list keys
        if isinstance(response, dict):
            for key in ("data", "results", "links", "urls"):
                if key in response:
                    val = response[key]
                    if isinstance(val, list):
                        return len(val)

            # Single result dict (has content but no list keys)
            if response:
                return 1

        # List response
        if isinstance(response, list):
            return len(response)

        # Object with data attribute
        data = getattr(response, "data", None)
        if isinstance(data, list):
            return len(data)

    except Exception:
        pass

    return 0


def _extract_scrape_preview(response) -> str:
    """Extract a short content preview from a scrape response."""
    if response is None:
        return ""

    try:
        if isinstance(response, dict):
            # Firecrawl returns content in various keys
            for key in ("markdown", "content", "html", "text"):
                content = response.get(key, "")
                if content and isinstance(content, str):
                    return content[:500]
            # Nested in 'data'
            data = response.get("data", {})
            if isinstance(data, dict):
                for key in ("markdown", "content", "html", "text"):
                    content = data.get(key, "")
                    if content and isinstance(content, str):
                        return content[:500]

        # Object with content attribute
        for key in ("markdown", "content", "html", "text"):
            content = getattr(response, key, "")
            if content and isinstance(content, str):
                return content[:500]

    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _scrape_url_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FirecrawlApp.scrape_url``."""
    # Extract URL from args or kwargs
    url = ""
    if args:
        url = str(args[0]) if args[0] else ""
    url = kwargs.get("url", url)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="firecrawl.scrape_url", tool_type="web_scraper")
        span.set_attribute("waxell.firecrawl.url", _truncate_url(url))
        response_format = _extract_format(kwargs)
        if response_format:
            span.set_attribute("waxell.firecrawl.format", response_format)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.firecrawl.result_count", 1)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="firecrawl.scrape_url",
                url=url,
                response=response,
                kwargs=kwargs,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _crawl_url_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FirecrawlApp.crawl_url``."""
    url = ""
    if args:
        url = str(args[0]) if args[0] else ""
    url = kwargs.get("url", url)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="firecrawl.crawl_url", tool_type="web_scraper")
        span.set_attribute("waxell.firecrawl.url", _truncate_url(url))
        response_format = _extract_format(kwargs)
        if response_format:
            span.set_attribute("waxell.firecrawl.format", response_format)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(response)
            span.set_attribute("waxell.firecrawl.result_count", result_count)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="firecrawl.crawl_url",
                url=url,
                response=response,
                kwargs=kwargs,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _map_url_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FirecrawlApp.map_url``."""
    url = ""
    if args:
        url = str(args[0]) if args[0] else ""
    url = kwargs.get("url", url)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="firecrawl.map_url", tool_type="web_scraper")
        span.set_attribute("waxell.firecrawl.url", _truncate_url(url))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(response)
            span.set_attribute("waxell.firecrawl.result_count", result_count)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="firecrawl.map_url",
                url=url,
                response=response,
                kwargs=kwargs,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FirecrawlApp.search``."""
    query = ""
    if args:
        query = str(args[0]) if args[0] else ""
    query = kwargs.get("query", query)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="firecrawl.search", tool_type="web_scraper")
        span.set_attribute("waxell.firecrawl.query", str(query)[:500])
        response_format = _extract_format(kwargs)
        if response_format:
            span.set_attribute("waxell.firecrawl.format", response_format)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(response)
            span.set_attribute("waxell.firecrawl.result_count", result_count)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="firecrawl.search",
                url=query,
                response=response,
                kwargs=kwargs,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tool_call(
    tool_name: str,
    url: str,
    response,
    kwargs: dict,
) -> None:
    """Record a Firecrawl tool call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    result_count = _extract_result_count(response)
    preview = _extract_scrape_preview(response)

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output = {}
        if result_count:
            output["result_count"] = result_count
        if preview:
            output["preview"] = preview

        ctx.record_tool_call(
            name=tool_name,
            input={"url": _truncate_url(url)},
            output=output,
            tool_type="web_scraper",
            status="ok",
        )
    else:
        # Fall back to collector with an LLM-call-shaped dict
        call_data = {
            "model": "firecrawl",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "task": tool_name,
            "prompt_preview": _truncate_url(url),
            "response_preview": preview,
        }
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
