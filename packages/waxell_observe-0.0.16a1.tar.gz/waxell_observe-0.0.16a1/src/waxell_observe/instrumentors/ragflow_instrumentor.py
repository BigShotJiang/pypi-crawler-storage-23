"""RAGFlow auto-instrumentor for waxell-observe.

Monkey-patches RAGFlow SDK client methods for dataset creation, document
parsing, and conversation/chat to emit retrieval and step spans.

Patched methods:
  - ``ragflow.RAGFlow.create_dataset``       (step span)
  - ``ragflow.RAGFlow.list_datasets``         (step span)
  - ``ragflow_sdk.RAGFlow.create_dataset``    (step span, alternative import)
  - ``ragflow.RAGFlow.create_chat``           (retrieval span)
  - ``ragflow_sdk.RAGFlow.create_chat``       (retrieval span, alternative import)

The instrumentor attempts both ``ragflow`` and ``ragflow_sdk`` import
paths since the package naming varies across versions.

All wrapper code is wrapped in try/except -- never breaks the user's RAGFlow calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class RagflowInstrumentor(BaseInstrumentor):
    """Instrumentor for RAGFlow.

    Patches RAGFlow SDK client methods for dataset management, document
    parsing, and chat/conversation to emit step and retrieval spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try both possible import paths
        has_ragflow = False
        ragflow_module = None

        try:
            import ragflow  # noqa: F401
            has_ragflow = True
            ragflow_module = "ragflow"
        except ImportError:
            pass

        if not has_ragflow:
            try:
                import ragflow_sdk  # noqa: F401
                has_ragflow = True
                ragflow_module = "ragflow_sdk"
            except ImportError:
                pass

        if not has_ragflow:
            logger.debug("Neither ragflow nor ragflow_sdk installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping RAGFlow instrumentation")
            return False

        patched_any = False

        # --- RAGFlow.create_dataset (step span) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "RAGFlow.create_dataset",
                _sync_create_dataset_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch RAGFlow.create_dataset: %s", exc)

        # --- RAGFlow.list_datasets (step span) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "RAGFlow.list_datasets",
                _sync_list_datasets_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch RAGFlow.list_datasets: %s", exc)

        # --- RAGFlow.create_chat (retrieval span for chat/conversation) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "RAGFlow.create_chat",
                _sync_create_chat_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch RAGFlow.create_chat: %s", exc)

        # --- Dataset.upload_documents (step span for document parsing) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "DataSet.upload_documents",
                _sync_upload_documents_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch RAGFlow DataSet.upload_documents: %s", exc)

        # --- Dataset.async_parse_documents (step span for parsing) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "DataSet.async_parse_documents",
                _sync_parse_documents_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch RAGFlow DataSet.async_parse_documents: %s", exc)

        # --- Chat.ask (retrieval span for RAG conversation) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "Chat.ask",
                _sync_chat_ask_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch RAGFlow Chat.ask: %s", exc)

        # --- Session.ask (retrieval span for session-based chat) ---
        try:
            wrapt.wrap_function_wrapper(
                ragflow_module,
                "Session.ask",
                _sync_session_ask_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch RAGFlow Session.ask: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any RAGFlow methods")
            return False

        # Store which module was used for uninstrumentation
        self._ragflow_module = ragflow_module
        self._instrumented = True
        logger.debug("RAGFlow instrumented via %s (create_dataset, create_chat, etc.)", ragflow_module)
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        ragflow_module = getattr(self, "_ragflow_module", "ragflow")

        try:
            import importlib
            mod = importlib.import_module(ragflow_module)

            # Restore RAGFlow class methods
            ragflow_cls = getattr(mod, "RAGFlow", None)
            if ragflow_cls is not None:
                for method_name in ("create_dataset", "list_datasets", "create_chat"):
                    method = getattr(ragflow_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(ragflow_cls, method_name, method.__wrapped__)

            # Restore DataSet class methods
            dataset_cls = getattr(mod, "DataSet", None)
            if dataset_cls is not None:
                for method_name in ("upload_documents", "async_parse_documents"):
                    method = getattr(dataset_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(dataset_cls, method_name, method.__wrapped__)

            # Restore Chat class methods
            chat_cls = getattr(mod, "Chat", None)
            if chat_cls is not None:
                method = getattr(chat_cls, "ask", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    chat_cls.ask = method.__wrapped__  # type: ignore[attr-defined]

            # Restore Session class methods
            session_cls = getattr(mod, "Session", None)
            if session_cls is not None:
                method = getattr(session_cls, "ask", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    session_cls.ask = method.__wrapped__  # type: ignore[attr-defined]

        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("RAGFlow uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Step span wrappers (dataset/document operations)
# ---------------------------------------------------------------------------


def _sync_create_dataset_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for RAGFlow.create_dataset -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    dataset_name = ""
    try:
        if args:
            dataset_name = str(args[0]) if args[0] else ""
        else:
            dataset_name = str(kwargs.get("name", ""))
    except Exception:
        pass

    try:
        span = start_step_span(step_name="ragflow.create_dataset")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "create_dataset")
            if dataset_name:
                span.set_attribute("waxell.ragflow.dataset_name", dataset_name)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow create_dataset span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "ragflow_create_dataset",
                    output={"dataset_name": dataset_name},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_list_datasets_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for RAGFlow.list_datasets -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="ragflow.list_datasets")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            count = len(result) if result and isinstance(result, (list, tuple)) else 0
            span.set_attribute("waxell.ragflow.operation", "list_datasets")
            span.set_attribute("waxell.ragflow.dataset_count", count)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow list_datasets span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


def _sync_upload_documents_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DataSet.upload_documents -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    dataset_name = ""
    try:
        if hasattr(instance, "name"):
            dataset_name = str(instance.name)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="ragflow.upload_documents")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "upload_documents")
            if dataset_name:
                span.set_attribute("waxell.ragflow.dataset_name", dataset_name)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow upload_documents span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "ragflow_upload_documents",
                    output={"dataset_name": dataset_name},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_parse_documents_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DataSet.async_parse_documents -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    dataset_name = ""
    try:
        if hasattr(instance, "name"):
            dataset_name = str(instance.name)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="ragflow.parse_documents")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "parse_documents")
            if dataset_name:
                span.set_attribute("waxell.ragflow.dataset_name", dataset_name)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow parse_documents span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "ragflow_parse_documents",
                    output={"dataset_name": dataset_name},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Retrieval span wrappers (chat/conversation)
# ---------------------------------------------------------------------------


def _sync_create_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for RAGFlow.create_chat -- emits retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    chat_name = ""
    try:
        if args:
            chat_name = str(args[0]) if args[0] else ""
        else:
            chat_name = str(kwargs.get("name", ""))
    except Exception:
        pass

    try:
        span = start_retrieval_span(query=chat_name or "create_chat", source="ragflow")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "create_chat")
            if chat_name:
                span.set_attribute("waxell.ragflow.chat_name", chat_name)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow create_chat span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


def _sync_chat_ask_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Chat.ask -- emits retrieval span."""
    query = ""
    try:
        if args:
            query = str(args[0]) if args[0] else ""
        else:
            query = str(kwargs.get("question", kwargs.get("query", "")))
    except Exception:
        pass

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="ragflow")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "chat_ask")

            # Try to extract retrieved chunks and answer
            if result is not None:
                if hasattr(result, "content"):
                    answer_preview = _truncate(str(result.content), max_len=200)
                    span.set_attribute("waxell.retrieval.answer_preview", answer_preview)
                if hasattr(result, "reference") and result.reference:
                    chunks_count = len(result.reference) if isinstance(result.reference, (list, dict)) else 0
                    span.set_attribute("waxell.retrieval.chunks_count", chunks_count)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow chat.ask span attributes: %s", attr_exc)

        try:
            _record_ragflow_retrieval(query=query_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_session_ask_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Session.ask -- emits retrieval span."""
    query = ""
    try:
        if args:
            query = str(args[0]) if args[0] else ""
        else:
            query = str(kwargs.get("question", kwargs.get("query", "")))
    except Exception:
        pass

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="ragflow")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.ragflow.operation", "session_ask")

            if result is not None:
                if hasattr(result, "content"):
                    answer_preview = _truncate(str(result.content), max_len=200)
                    span.set_attribute("waxell.retrieval.answer_preview", answer_preview)
                if hasattr(result, "reference") and result.reference:
                    chunks_count = len(result.reference) if isinstance(result.reference, (list, dict)) else 0
                    span.set_attribute("waxell.retrieval.chunks_count", chunks_count)
        except Exception as attr_exc:
            logger.debug("Failed to set RAGFlow session.ask span attributes: %s", attr_exc)

        try:
            _record_ragflow_retrieval(query=query_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_ragflow_retrieval(
    query: str,
) -> None:
    """Record a RAGFlow retrieval operation to the context path.

    RAGFlow retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="ragflow",
        )
