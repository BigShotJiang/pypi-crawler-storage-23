from ._internal.cli import main

__all__ = ('main',)
