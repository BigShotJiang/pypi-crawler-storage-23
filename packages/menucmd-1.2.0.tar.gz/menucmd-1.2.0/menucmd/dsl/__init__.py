from .parser import build_menus
from .menu_dict import MenuDict

__all__ = ['build_menus', 'menu_dict']