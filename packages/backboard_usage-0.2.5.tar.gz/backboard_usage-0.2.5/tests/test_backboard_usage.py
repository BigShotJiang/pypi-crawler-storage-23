"""
Tests for backboard_usage package. Run with: python -m pytest tests/ -v
Or: python -m unittest tests.test_backboard_usage -v
"""
import unittest
from pathlib import Path


class TestPackageImport(unittest.TestCase):
    def test_import_package(self):
        import backboard_usage
        self.assertTrue(hasattr(backboard_usage, "__version__"))

    def test_version(self):
        import backboard_usage
        self.assertIsInstance(backboard_usage.__version__, str)
        self.assertIn(".", backboard_usage.__version__)


class TestCostEstimate(unittest.TestCase):
    def setUp(self):
        from backboard_usage.cost import estimate_cost
        self.estimate_cost = estimate_cost

    def test_known_model_gpt4o(self):
        cost = self.estimate_cost("openai/gpt-4o", 1000, 500)
        self.assertGreater(cost, 0)
        self.assertLess(cost, 0.01)

    def test_known_model_gpt4o_mini(self):
        cost = self.estimate_cost("openai/gpt-4o-mini", 1000, 500)
        self.assertGreater(cost, 0)
        self.assertLess(cost, 0.001)

    def test_zero_tokens_returns_zero(self):
        self.assertEqual(self.estimate_cost("openai/gpt-4o", 0, 0), 0.0)
        self.assertEqual(self.estimate_cost(None, 100, 100), 0.0)

    def test_unknown_model_uses_fallback(self):
        cost = self.estimate_cost("unknown/model", 1_000_000, 0)
        self.assertGreater(cost, 0)
        self.assertAlmostEqual(cost, 2.0, places=2)

    def test_fuzzy_model_match(self):
        # model string contains known key
        cost = self.estimate_cost("anthropic/claude-3-7-sonnet-20250219", 1000, 1000)
        self.assertGreater(cost, 0)


class TestServer(unittest.TestCase):
    def test_server_module_has_main(self):
        from backboard_usage import server
        self.assertTrue(callable(getattr(server, "main", None)))

    def test_ui_root_exists(self):
        from backboard_usage.server import _ui_root
        root = _ui_root()
        self.assertTrue(root.is_dir(), f"UI root should be a directory: {root}")

    def test_ui_has_index_html(self):
        from backboard_usage.server import _ui_root
        index = _ui_root() / "index.html"
        self.assertTrue(index.exists(), f"index.html should exist at {index}")


if __name__ == "__main__":
    unittest.main()
