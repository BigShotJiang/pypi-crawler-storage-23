"""
UsageTracker — send Backboard usage to the local UI with one line per agent.
"""
import asyncio
import json
import logging
import os

from .cost import estimate_cost

logger = logging.getLogger("backboard_usage")

try:
    import websockets
except ImportError:
    websockets = None

WS_URL = os.environ.get("USAGE_WS_URL", "ws://localhost:8765")
_SERVER_WARNED = False


class UsageTracker:
    """
    Use in your Backboard app to send usage to the local UI.

    Usage:
        tracker = UsageTracker()
        for agent_name, prompt in agents:
            response = await client.add_message(...)
            await tracker.record(response, agent=agent_name)
        await tracker.finish()
    """

    def __init__(self, ws_url: str | None = None):
        self.ws_url = ws_url or WS_URL
        self._ws = None
        self.by_agent: dict = {}
        self.by_model: dict = {}
        self.total_tokens = 0
        self.total_cost = 0.0

    async def _connect(self):
        global _SERVER_WARNED
        if self._ws is not None and getattr(self._ws, "open", True):
            return
        if websockets is None:
            raise RuntimeError("Install websockets: pip install websockets")
        try:
            self._ws = await websockets.connect(self.ws_url)
            _SERVER_WARNED = False
        except Exception:
            self._ws = None
            if not _SERVER_WARNED:
                _SERVER_WARNED = True
                logger.warning(
                    "Usage server not running at %s. Start with: backboard-usage-server",
                    self.ws_url,
                )

    def _extract(self, response, agent: str) -> tuple[int, float, str | None]:
        inp = out = tok = 0
        is_dict = hasattr(response, "get") and callable(getattr(response, "get"))

        def get_val(obj, key, default=0):
            if obj is None:
                return default
            if hasattr(obj, "get"):
                v = obj.get(key, default)
                return v if v is not None else default
            return getattr(obj, key, default) or default

        usage = response.get("usage") if is_dict else getattr(response, "usage", None)
        if usage is not None:
            inp = get_val(usage, "input_tokens")
            out = get_val(usage, "output_tokens")
        else:
            inp = get_val(response, "input_tokens")
            out = get_val(response, "output_tokens")
        tok = get_val(response, "total_tokens") or (inp + out) or 0
        model_name = get_val(response, "model_name") or get_val(response, "model")
        model_provider = get_val(response, "model_provider")
        if not is_dict and hasattr(response, "model"):
            m = response.model
            model_name = model_name or (getattr(m, "name", None) if m else None)
            model_provider = model_provider or (getattr(m, "provider", None) if m else None)
        model = f"{model_provider}/{model_name}" if model_provider and model_name else (model_name or model_provider or "")
        cost = get_val(response, "cost")
        if cost is None or cost == 0:
            cost = estimate_cost(model, inp, out)
        return tok, cost, model or None

    async def record(self, response, agent: str):
        """Call after each add_message. Sends usage to the UI. Falls back to agent name only if extraction fails."""
        try:
            tok, cost, model = self._extract(response, agent)
        except Exception:
            await self.record_manual(agent)
            return
        if tok or cost:
            self.total_tokens += tok
            self.total_cost += cost
            self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
            self.by_agent[agent]["tokens"] += tok
            self.by_agent[agent]["cost"] += cost
            if model:
                self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})
                self.by_model[model]["tokens"] += tok
                self.by_model[model]["cost"] += cost
        else:
            self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
            if model:
                self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})

        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "usage",
                    "agent": agent,
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
            except Exception:
                pass

    async def record_manual(
        self,
        agent: str,
        tokens: int = 0,
        cost: float = 0.0,
        model: str | None = None,
    ):
        """Record usage when the Backboard response shape doesn't match. Use agent name + optional tokens/cost/model."""
        if tokens or cost:
            self.total_tokens += tokens
            self.total_cost += cost
        self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
        self.by_agent[agent]["tokens"] += tokens
        self.by_agent[agent]["cost"] += cost
        if model:
            self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})
            self.by_model[model]["tokens"] += tokens
            self.by_model[model]["cost"] += cost
        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "usage",
                    "agent": agent,
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
            except Exception:
                pass

    async def finish(self):
        """Call at the end of your run."""
        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "done",
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
                await self._ws.close(code=1000)
            except Exception:
                pass
            self._ws = None
            await asyncio.sleep(0.15)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.finish()


def run_with_tracker(async_main):
    """
    Run an async function with a UsageTracker for Streamlit and other sync frameworks.
    Your async_main must accept (tracker, *args, **kwargs). finish() is called automatically.

    Example:
        async def my_flow(tracker, prompt):
            response = await client.add_message(prompt)
            await tracker.record(response, agent="Analyzer")
            return response
        result = run_with_tracker(my_flow)("Hello")
    """
    def sync_wrapper(*args, **kwargs):
        async def _run():
            tracker = UsageTracker()
            try:
                return await async_main(tracker, *args, **kwargs)
            finally:
                await tracker.finish()
        return asyncio.run(_run())
    return sync_wrapper
