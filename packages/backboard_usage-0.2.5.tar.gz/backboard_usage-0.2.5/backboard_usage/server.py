"""
Backboard usage server: WebSocket relay + HTTP server for the usage UI.
Run via: backboard-usage-server
"""
import asyncio
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

import websockets
from websockets.exceptions import ConnectionClosed, ConnectionClosedError

UI_WS_PORT = 8765
UI_HTTP_PORT = 8766
_ws_clients: set = set()
_last_message: str | None = None


def _ui_root() -> Path:
    """Directory containing the built UI (index.html + assets/)."""
    root = Path(__file__).resolve().parent / "ui"
    return root


async def _ws_handler(ws):
    global _last_message
    _ws_clients.add(ws)
    if _last_message:
        try:
            await ws.send(_last_message)
        except Exception:
            pass
    try:
        async for message in ws:
            _last_message = message
            dead = set()
            for client in _ws_clients:
                if client is ws:
                    continue
                try:
                    await client.send(message)
                except Exception:
                    dead.add(client)
            _ws_clients.difference_update(dead)
    except (ConnectionClosed, ConnectionClosedError):
        pass
    finally:
        _ws_clients.discard(ws)


def _run_http():
    ui_root = _ui_root()
    dist_path = ui_root

    def safe_path(base: Path, sub: str) -> Path | None:
        resolved = (base / sub.lstrip("/")).resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            return None
        return resolved if resolved.exists() else None

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            raw = self.path.split("?")[0]
            if raw in ("/", "/index.html"):
                index_file = dist_path / "index.html" if dist_path.exists() else None
                if index_file and index_file.exists():
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(index_file.read_bytes())
                else:
                    self.send_response(404)
                    self.end_headers()
            elif raw in (
                "/backboard-logo-light-sm.svg",
                "/backboard-logo-white.svg",
                "/backboard-logo-dark.svg",
            ):
                name = raw.lstrip("/")
                svg_path = dist_path / name
                if not svg_path.exists() and (dist_path / "assets").exists():
                    svg_path = dist_path / "assets" / name
                if svg_path.exists():
                    self.send_response(200)
                    self.send_header("Content-type", "image/svg+xml")
                    self.end_headers()
                    self.wfile.write(svg_path.read_bytes())
                else:
                    self.send_response(404)
                    self.end_headers()
            elif dist_path.exists():
                file_path = safe_path(dist_path, raw)
                if file_path and file_path.is_file():
                    self.send_response(200)
                    suffix = file_path.suffix.lower()
                    ct = "application/octet-stream"
                    if suffix == ".js":
                        ct = "application/javascript"
                    elif suffix == ".css":
                        ct = "text/css"
                    elif suffix == ".svg":
                        ct = "image/svg+xml"
                    elif suffix in (".ico", ".png", ".jpg", ".jpeg", ".webp"):
                        ct = "image/x-icon" if suffix == "ico" else f"image/{suffix}"
                    self.send_header("Content-type", ct)
                    self.end_headers()
                    self.wfile.write(file_path.read_bytes())
                else:
                    self.send_response(404)
                    self.end_headers()
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args):
            pass

    HTTPServer(("localhost", UI_HTTP_PORT), Handler).serve_forever()


async def _main_async():
    threading.Thread(target=_run_http, daemon=True).start()
    print("Backboard usage server running.")
    print("  Live usage UI: http://localhost:%s" % UI_HTTP_PORT)
    print("  WebSocket:     ws://localhost:%s" % UI_WS_PORT)
    print("  Next: open the URL in your browser, then run your Backboard app.")
    print("  Ctrl+C to stop.\n")
    async with websockets.serve(_ws_handler, "localhost", UI_WS_PORT):
        await asyncio.Future()


def main():
    asyncio.run(_main_async())
