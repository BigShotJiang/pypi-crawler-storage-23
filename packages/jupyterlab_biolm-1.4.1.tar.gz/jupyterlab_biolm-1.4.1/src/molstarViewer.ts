/**
 * Molstar Molecular Viewer Plugin
 *
 * Embeds the Molstar pre-built viewer (https://github.com/molstar/molstar)
 * via CDN — no npm package required.  Supports:
 *  • Loading structures by PDB ID (from RCSB PDB)
 *  • Loading AlphaFold DB structures by UniProt accession
 *  • Loading raw file content (PDB / mmCIF) for document-factory integration
 */
import { PageConfig } from '@jupyterlab/coreutils';
import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ABCWidgetFactory, DocumentRegistry, DocumentWidget, IDocumentWidget } from '@jupyterlab/docregistry';
import { ILauncher } from '@jupyterlab/launcher';
import { Widget } from '@lumino/widgets';
import { Message } from '@lumino/messaging';
import { biolmIcon } from './biolmIcon';

// ─── Loader (singleton) ───────────────────────────────────────────────────────
// Assets are served via the Jupyter server extension proxy to avoid browser CSP
// restrictions that would block direct CDN loads in hosted environments.

/** Override Molstar's hardcoded palette with JupyterLab theme variables. */
const MOLSTAR_JP_THEME_CSS = `
.msp-plugin,
.msp-plugin .msp-layout-left,
.msp-plugin .msp-layout-right,
.msp-plugin .msp-layout-bottom,
.msp-plugin .msp-layout-top,
.msp-plugin .msp-log { background: var(--jp-layout-color2) !important; color: var(--jp-ui-font-color1) !important; }

.msp-plugin .msp-control-row,
.msp-plugin .msp-flex-row,
.msp-plugin .msp-state-image-row,
.msp-plugin .msp-control-current,
.msp-plugin .msp-help-text,
.msp-plugin .msp-help-row,
.msp-plugin .msp-description,
.msp-plugin .msp-row-text,
.msp-plugin .msp-log li { background: var(--jp-layout-color1) !important; color: var(--jp-ui-font-color1) !important; }

.msp-plugin .msp-section-header,
.msp-plugin .msp-control-group-header,
.msp-plugin .msp-current-header { background: var(--jp-layout-color3) !important; color: var(--jp-ui-font-color0) !important; }

.msp-plugin .msp-btn,
.msp-plugin .msp-form-control,
.msp-plugin select,
.msp-plugin input { background: var(--jp-layout-color1) !important; color: var(--jp-ui-font-color1) !important;
  border-color: var(--jp-border-color1) !important; }

.msp-plugin .msp-btn:hover { background: var(--jp-layout-color3) !important; }

.msp-plugin .msp-viewport { background: var(--jp-layout-color0) !important; }

.msp-plugin ::-webkit-scrollbar-track { background-color: var(--jp-layout-color2) !important; }
.msp-plugin ::-webkit-scrollbar-thumb { background-color: var(--jp-border-color1) !important; }
`;

const MOLSTAR_JP_THEME_ID = 'biolm-molstar-jp-theme';

let _molstarPromise: Promise<void> | null = null;

function loadMolstar(): Promise<void> {
  if (_molstarPromise) return _molstarPromise;
  _molstarPromise = new Promise<void>((resolve, reject) => {
    // Already loaded?
    if ((window as any).molstar?.Viewer) { resolve(); return; }

    const staticBase = PageConfig.getBaseUrl() + 'biolm/static/';

    // Inject base stylesheet (idempotent)
    if (!document.querySelector('link[data-biolm-molstar]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.type = 'text/css';
      link.href = staticBase + 'molstar.css';
      link.dataset.biolmMolstar = 'true';
      document.head.appendChild(link);
    }

    // Inject JupyterLab-theme overrides (idempotent)
    if (!document.getElementById(MOLSTAR_JP_THEME_ID)) {
      const style = document.createElement('style');
      style.id = MOLSTAR_JP_THEME_ID;
      style.textContent = MOLSTAR_JP_THEME_CSS;
      document.head.appendChild(style);
    }

    // Inject script
    const script = document.createElement('script');
    script.src = staticBase + 'molstar.js';
    script.async = true;
    script.onload  = () => resolve();
    script.onerror = () => {
      _molstarPromise = null; // allow retry
      reject(new Error('Failed to load Molstar'));
    };
    document.head.appendChild(script);
  });
  return _molstarPromise;
}

// ─── Viewer Widget ────────────────────────────────────────────────────────────

interface MolstarViewerOptions {
  /** Pre-loaded file content (document-open mode). */
  fileContent?: string;
  /** Format hint: 'pdb' | 'mmcif'. Defaults to 'pdb'. */
  format?: string;
}

export class MolstarViewerWidget extends Widget {
  private _viewer: any = null;
  private _viewerEl: HTMLDivElement;
  private _toolbar: HTMLDivElement;
  private _statusEl: HTMLDivElement;
  private _idInput: HTMLInputElement | null = null;
  private _fileContent: string;
  private _format: string;
  private _attached = false;

  constructor(options: MolstarViewerOptions = {}) {
    super();
    this._fileContent = options.fileContent ?? '';
    this._format      = options.format ?? 'pdb';
    this.addClass('biolm-molstar-viewer');
    this._buildUI();
  }

  private _buildUI(): void {
    const root = this.node;
    root.style.cssText =
      'display:flex;flex-direction:column;height:100%;width:100%;overflow:hidden;';

    // ── Toolbar ──────────────────────────────────────────────────────────────
    this._toolbar = document.createElement('div');
    this._toolbar.style.cssText =
      'display:flex;align-items:center;gap:8px;padding:6px 10px;flex-shrink:0;' +
      'background:var(--jp-toolbar-background,#f6f8fa);' +
      'border-bottom:1px solid var(--jp-border-color2,#d0d7de);';

    if (!this._fileContent) {
      // Launcher mode: ID input + action buttons
      const label = document.createElement('span');
      label.textContent = 'PDB ID / UniProt:';
      label.style.cssText =
        'font-size:12px;font-weight:600;white-space:nowrap;' +
        'color:var(--jp-ui-font-color1,#24292f);';

      this._idInput = document.createElement('input');
      this._idInput.type = 'text';
      this._idInput.placeholder = 'e.g. 1CRN or P12345';
      this._idInput.maxLength = 20;
      this._idInput.setAttribute('aria-label', 'PDB ID or UniProt accession');
      this._idInput.style.cssText =
        'padding:3px 6px;border-radius:4px;font-size:12px;width:160px;' +
        'border:1px solid var(--jp-border-color1,#d0d7de);' +
        'background:var(--jp-layout-color1,#fff);' +
        'color:var(--jp-ui-font-color1,#24292f);';
      this._idInput.addEventListener('keydown', (e: KeyboardEvent) => {
        if (e.key === 'Enter') void this._loadPdb();
      });

      const pdbBtn = this._mkBtn('Load PDB', '#238636', () => void this._loadPdb());
      pdbBtn.setAttribute('aria-label', 'Load from RCSB PDB');

      const afBtn = this._mkBtn('AlphaFold', '#0969da', () => void this._loadAlphaFold());
      afBtn.title = 'Load from AlphaFold DB by UniProt accession';
      afBtn.setAttribute('aria-label', 'Load from AlphaFold DB');

      this._toolbar.append(label, this._idInput, pdbBtn, afBtn);
    } else {
      // File-open mode: just a title label
      const label = document.createElement('span');
      label.textContent = 'Molstar Viewer';
      label.style.cssText =
        'font-size:12px;font-weight:600;' +
        'color:var(--jp-ui-font-color1,#24292f);';
      this._toolbar.appendChild(label);
    }

    // ── Status overlay ────────────────────────────────────────────────────────
    this._statusEl = document.createElement('div');
    this._statusEl.style.cssText =
      'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' +
      'color:var(--jp-ui-font-color2,#57606a);font-size:13px;text-align:center;' +
      'pointer-events:none;z-index:10;white-space:pre-line;';
    this._statusEl.textContent = this._fileContent
      ? 'Loading…'
      : 'Enter a PDB ID or UniProt accession above and click Load.';

    // ── Molstar mount point ───────────────────────────────────────────────────
    this._viewerEl = document.createElement('div');
    this._viewerEl.style.cssText =
      'flex:1;position:relative;min-height:0;overflow:hidden;';
    this._viewerEl.appendChild(this._statusEl);

    root.append(this._toolbar, this._viewerEl);
  }

  /** Small helper for toolbar buttons. */
  private _mkBtn(text: string, bg: string, handler: () => void): HTMLButtonElement {
    const btn = document.createElement('button');
    btn.textContent = text;
    btn.style.cssText =
      `padding:3px 10px;border-radius:4px;border:none;cursor:pointer;` +
      `background:${bg};color:#fff;font-size:12px;white-space:nowrap;`;
    btn.addEventListener('click', handler);
    return btn;
  }

  // ── Lifecycle ───────────────────────────────────────────────────────────────

  protected onAfterAttach(msg: Message): void {
    super.onAfterAttach(msg);
    this._attached = true;
    if (this._fileContent) {
      void this._initAndLoadContent();
    }
  }

  protected onResize(_msg: Widget.ResizeMessage): void {
    // Molstar handles viewport resize internally via ResizeObserver
  }

  /** Called by the document factory once the file model is ready. */
  setContent(content: string, format: string): void {
    this._fileContent = content;
    this._format      = format;
    if (this._attached) {
      void this._initAndLoadContent();
    }
  }

  // ── Private helpers ─────────────────────────────────────────────────────────

  private async _ensureViewer(): Promise<void> {
    await loadMolstar();
    if (this._viewer) return;

    // Molstar needs a non-zero-sized element; guarantee one.
    const mount = document.createElement('div');
    mount.style.cssText = 'position:absolute;inset:0;';
    this._viewerEl.appendChild(mount);

    const { Viewer } = (window as any).molstar;
    this._viewer = await Viewer.create(mount, {
      layoutIsExpanded: false,
      layoutShowControls: true,
      layoutShowRemoteState: false,
      layoutShowSequence: true,
      layoutShowLog: false,
      layoutShowLeftPanel: true,
      viewportShowExpand: false,
      viewportShowSelectionMode: true,
      viewportShowAnimation: true,
      pdbProvider: 'rcsb',
      emdbProvider: 'rcsb',
    });
  }

  private async _initAndLoadContent(): Promise<void> {
    this._setStatus('Loading…');
    try {
      await this._ensureViewer();
      const fmt = this._format === 'mmcif' ? 'mmcif' : 'pdb';
      await this._viewer.loadStructureFromData(this._fileContent, fmt, false);
      this._clearStatus();
    } catch (err) {
      this._setStatus(`Error: ${(err as Error).message}`);
    }
  }

  private async _loadPdb(): Promise<void> {
    const id = this._idInput?.value.trim().toUpperCase();
    if (!id) return;
    this._setStatus(`Loading PDB ${id}…`);
    try {
      await this._ensureViewer();
      await this._viewer.loadPdb(id);
      this._clearStatus();
    } catch (err) {
      this._setStatus(`Error loading ${id}:\n${(err as Error).message}`);
    }
  }

  private async _loadAlphaFold(): Promise<void> {
    const id = this._idInput?.value.trim();
    if (!id) return;
    this._setStatus(`Loading AlphaFold structure for ${id}…`);
    try {
      await this._ensureViewer();
      await this._viewer.loadAlphaFoldDb(id);
      this._clearStatus();
    } catch (err) {
      this._setStatus(`Error loading AlphaFold ${id}:\n${(err as Error).message}`);
    }
  }

  private _setStatus(msg: string): void {
    this._statusEl.textContent = msg;
    this._statusEl.style.display = '';
  }

  private _clearStatus(): void {
    this._statusEl.style.display = 'none';
  }
}

// ─── Document Widget Factory ──────────────────────────────────────────────────

const MOLSTAR_FACTORY_NAME = 'Molstar Viewer';
// Reuse the file types already registered by pdbViewerPlugin so users get an
// "Open With → Molstar Viewer" option in the file-browser context menu.
const MOLSTAR_FILE_TYPES   = ['pdb', 'ent', 'mmcif'];

type MolstarDocWidget = IDocumentWidget<MolstarViewerWidget>;

class MolstarViewerFactory extends ABCWidgetFactory<MolstarDocWidget> {
  protected createNewWidget(context: DocumentRegistry.Context): MolstarDocWidget {
    const format  = context.path.endsWith('.mmcif') || context.path.endsWith('.cif')
      ? 'mmcif' : 'pdb';
    const content = new MolstarViewerWidget({ format });
    const widget  = new DocumentWidget({ content, context });
    widget.title.label   = context.path.split('/').pop() ?? context.path;
    widget.title.caption = context.path;

    void context.ready.then(() => {
      content.setContent(context.model.toString(), format);
    });

    return widget;
  }
}

// ─── Plugin ───────────────────────────────────────────────────────────────────

export const molstarViewerPlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-biolm:molstar-viewer',
  autoStart: true,
  optional: [ILauncher],
  activate: (app: JupyterFrontEnd, launcher: ILauncher | null) => {
    const { docRegistry, commands } = app;

    // Register the factory against the file types already registered by
    // pdbViewerPlugin ('pdb', 'ent', 'mmcif').  Setting defaultFor to [] means
    // 3Dmol stays the default double-click opener; Molstar appears under the
    // "Open With" sub-menu in the file-browser context menu.
    const factory = new MolstarViewerFactory({
      name: MOLSTAR_FACTORY_NAME,
      fileTypes: MOLSTAR_FILE_TYPES,
      defaultFor: [],
    });
    docRegistry.addWidgetFactory(factory);

    // Command: open standalone launcher widget
    commands.addCommand('biolm:open-molstar-viewer', {
      label: 'Molstar Viewer',
      caption: 'Open an interactive Molstar molecular structure viewer',
      icon: biolmIcon,
      execute: () => {
        const widget = new MolstarViewerWidget();
        widget.id             = `biolm-molstar-viewer-${Date.now()}`;
        widget.title.label   = 'Molstar Viewer';
        widget.title.caption = 'BioLM Molstar Viewer';
        widget.title.closable = true;
        if (!widget.isAttached) {
          app.shell.add(widget, 'main');
        }
        app.shell.activateById(widget.id);
      },
    });

    // Command: open file content in Molstar (callable from Results Explorer etc.)
    commands.addCommand('biolm:view-structure-molstar', {
      label: 'View in Molstar',
      execute: (args) => {
        const { content, format, name } = args as {
          content: string;
          format: string;
          name: string;
        };
        const widget = new MolstarViewerWidget({
          fileContent: String(content),
          format: String(format || 'pdb'),
        });
        widget.id             = `biolm-molstar-content-${Date.now()}`;
        widget.title.label   = String(name || 'Structure');
        widget.title.caption = 'BioLM Molstar Viewer';
        widget.title.closable = true;
        if (!widget.isAttached) {
          app.shell.add(widget, 'main');
        }
        app.shell.activateById(widget.id);
      },
    });

    if (launcher) {
      launcher.add({
        command: 'biolm:open-molstar-viewer',
        category: 'BioLM',
        rank: 2,
      });
    }

    console.log('[BioLM] Molstar Viewer plugin activated');
  },
};
