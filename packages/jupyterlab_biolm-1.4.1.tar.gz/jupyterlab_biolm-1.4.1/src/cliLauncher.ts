import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ILauncher } from '@jupyterlab/launcher';
import { biolmIcon } from './biolmIcon';

export const cliLauncherPlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-biolm:cli-launcher',
  autoStart: true,
  optional: [ILauncher],
  activate: (app: JupyterFrontEnd, launcher: ILauncher | null) => {
    app.commands.addCommand('biolm:open-cli', {
      label: 'BioLM CLI',
      caption: 'Open a terminal and run biolmai --help',
      icon: biolmIcon,
      execute: async () => {
        // terminal:create-new returns the terminal widget in JupyterLab 4
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const widget = (await app.commands.execute('terminal:create-new')) as any;
        const session = widget?.content?.session;
        if (!session) {
          return;
        }

        // Wait for the terminal session to connect before sending input
        if (session.connectionStatus !== 'connected') {
          await new Promise<void>(resolve => {
            const check = () => {
              if (session.connectionStatus === 'connected') {
                session.connectionStatusChanged.disconnect(check);
                resolve();
              }
            };
            session.connectionStatusChanged.connect(check);
          });
        }

        session.send({ type: 'stdin', content: ['biolmai --help\n'] });
      }
    });

    if (launcher) {
      launcher.add({
        command: 'biolm:open-cli',
        category: 'BioLM',
        rank: -1
      });
    }
  }
};
