/**
 * PDB Protein Structure Viewer Plugin
 * Uses 3Dmol.js bundled via npm.
 */
import * as $3Dmol from '3dmol';
import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ABCWidgetFactory, DocumentRegistry, DocumentWidget, IDocumentWidget } from '@jupyterlab/docregistry';
import { ILauncher } from '@jupyterlab/launcher';
import { Widget } from '@lumino/widgets';
import { Message } from '@lumino/messaging';
import { biolmIcon } from './biolmIcon';

// ─── Theme tokens ─────────────────────────────────────────────────────────────

interface Theme {
  bg: string;
  toolbarBg: string;
  border: string;
  text: string;
  mutedText: string;
  inputBg: string;
  selectBg: string;
  viewer3dBg: string;
}

const LIGHT: Theme = {
  bg: '#ffffff',
  toolbarBg: '#f6f8fa',
  border: '#d0d7de',
  text: '#24292f',
  mutedText: '#57606a',
  inputBg: '#ffffff',
  selectBg: '#ffffff',
  viewer3dBg: 'white',
};

const DARK: Theme = {
  bg: '#0d1117',
  toolbarBg: '#161b22',
  border: '#30363d',
  text: '#c9d1d9',
  mutedText: '#8b949e',
  inputBg: '#0d1117',
  selectBg: '#0d1117',
  viewer3dBg: 'black',
};

// ─── PDB Viewer Widget ────────────────────────────────────────────────────────

interface PDBViewerOptions {
  /** Pre-loaded PDB/mmCIF file content (file-open mode). */
  fileContent?: string;
  /** Format hint: 'pdb' | 'mmcif'. Defaults to 'pdb'. */
  format?: string;
}

export class PDBViewerWidget extends Widget {
  private _viewer: any = null;
  private _viewerContainer: HTMLDivElement;
  private _toolbar: HTMLDivElement;
  private _statusEl: HTMLDivElement;
  private _idInput: HTMLInputElement | null = null;
  private _fileContent: string;
  private _format: string;
  private _attached = false;
  private _dark = false;
  private _themeBtn!: HTMLButtonElement;
  private _styleSelect!: HTMLSelectElement;
  // Collected themed elements for bulk re-style
  private _themedEls: Array<{ el: HTMLElement; prop: keyof Theme }> = [];

  constructor(options: PDBViewerOptions = {}) {
    super();
    this._fileContent = options.fileContent ?? '';
    this._format = options.format ?? 'pdb';
    this.addClass('biolm-pdb-viewer');
    this._buildUI();
  }

  private _theme(): Theme { return this._dark ? DARK : LIGHT; }

  /** Register an element to receive theme updates for a single CSS property. */
  private _trackEl(
    el: HTMLElement,
    prop: keyof Theme,
    cssProp: string,
    extra?: string
  ): void {
    this._themedEls.push({ el, prop });
    (el as any).__cssProp = cssProp;
    (el as any).__cssExtra = extra ?? '';
  }

  private _buildUI(): void {
    const t = this._theme();
    const root = this.node;
    root.style.cssText = `display:flex;flex-direction:column;height:100%;width:100%;overflow:hidden;background:${t.bg};`;

    // ── Toolbar ──────────────────────────────────────────────────────────────
    this._toolbar = document.createElement('div');
    this._toolbar.style.cssText =
      `display:flex;align-items:center;gap:8px;padding:6px 10px;flex-shrink:0;` +
      `background:${t.toolbarBg};border-bottom:1px solid ${t.border};`;

    if (!this._fileContent) {
      // Launcher mode: PDB ID input + Load button
      const label = document.createElement('span');
      label.textContent = 'PDB ID:';
      label.style.cssText = `color:${t.text};font-size:12px;font-weight:600;white-space:nowrap;`;
      this._trackEl(label, 'text', 'color');

      this._idInput = document.createElement('input');
      this._idInput.type = 'text';
      this._idInput.placeholder = 'e.g. 1CRN';
      this._idInput.maxLength = 10;
      this._idInput.setAttribute('aria-label', 'PDB ID');
      this._idInput.style.cssText =
        `width:80px;padding:3px 6px;border-radius:4px;font-size:12px;` +
        `border:1px solid ${t.border};background:${t.inputBg};color:${t.text};`;
      this._trackEl(this._idInput, 'border', 'border', '1px solid ');
      this._trackEl(this._idInput, 'inputBg', 'background-color');
      this._trackEl(this._idInput, 'text', 'color');

      this._idInput.addEventListener('keydown', (e: KeyboardEvent) => {
        if (e.key === 'Enter') this._loadFromId();
      });

      const loadBtn = document.createElement('button');
      loadBtn.textContent = 'Load';
      loadBtn.setAttribute('aria-label', 'Load structure');
      loadBtn.style.cssText =
        'padding:3px 10px;border-radius:4px;border:none;cursor:pointer;' +
        'background:#238636;color:#fff;font-size:12px;';
      loadBtn.addEventListener('click', () => this._loadFromId());

      this._toolbar.append(label, this._idInput, loadBtn);
    } else {
      const label = document.createElement('span');
      label.textContent = 'Structure Viewer';
      label.style.cssText = `color:${t.text};font-size:12px;font-weight:600;`;
      this._trackEl(label, 'text', 'color');
      this._toolbar.appendChild(label);
    }

    // Style selector
    const styleLabel = document.createElement('span');
    styleLabel.textContent = 'Style:';
    styleLabel.style.cssText = `color:${t.mutedText};font-size:12px;margin-left:auto;white-space:nowrap;`;
    this._trackEl(styleLabel, 'mutedText', 'color');

    this._styleSelect = document.createElement('select');
    this._styleSelect.setAttribute('aria-label', 'Render style');
    this._styleSelect.style.cssText =
      `padding:2px 4px;border-radius:4px;font-size:12px;cursor:pointer;` +
      `border:1px solid ${t.border};background:${t.selectBg};color:${t.text};`;
    this._trackEl(this._styleSelect, 'border', 'border', '1px solid ');
    this._trackEl(this._styleSelect, 'selectBg', 'background-color');
    this._trackEl(this._styleSelect, 'text', 'color');

    [
      ['cartoon', 'Cartoon'],
      ['stick', 'Stick'],
      ['sphere', 'Sphere'],
      ['surface', 'Surface'],
      ['line', 'Line'],
    ].forEach(([val, lbl]) => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = lbl;
      this._styleSelect.appendChild(opt);
    });
    this._styleSelect.addEventListener('change', () =>
      this._applyStyle(this._styleSelect.value)
    );

    // Light/dark toggle
    this._themeBtn = document.createElement('button');
    this._themeBtn.setAttribute('aria-label', 'Toggle dark mode');
    this._themeBtn.style.cssText =
      'padding:3px 8px;border-radius:4px;border:1px solid #d0d7de;' +
      'cursor:pointer;font-size:12px;background:transparent;';
    this._updateThemeBtn();
    this._themeBtn.addEventListener('click', () => this._toggleTheme());

    this._toolbar.append(styleLabel, this._styleSelect, this._themeBtn);

    // ── Status + viewer container ─────────────────────────────────────────────
    this._statusEl = document.createElement('div');
    this._statusEl.style.cssText =
      'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' +
      `color:${t.mutedText};font-size:13px;text-align:center;pointer-events:none;`;
    this._trackEl(this._statusEl, 'mutedText', 'color');
    this._statusEl.textContent = this._fileContent
      ? 'Loading…'
      : 'Enter a PDB ID above and click Load.';

    this._viewerContainer = document.createElement('div');
    this._viewerContainer.style.cssText =
      `flex:1;position:relative;min-height:0;background:${t.bg};`;
    this._viewerContainer.appendChild(this._statusEl);

    root.append(this._toolbar, this._viewerContainer);
  }

  private _toggleTheme(): void {
    this._dark = !this._dark;
    this._applyTheme();
  }

  private _applyTheme(): void {
    const t = this._theme();

    // Root + viewer container backgrounds
    this.node.style.background = t.bg;
    this._viewerContainer.style.background = t.bg;

    // Toolbar
    this._toolbar.style.background = t.toolbarBg;
    this._toolbar.style.borderBottomColor = t.border;

    // Toggle button
    this._updateThemeBtn();

    // All tracked elements
    for (const { el, prop } of this._themedEls) {
      const cssProp = (el as any).__cssProp as string;
      const extra = (el as any).__cssExtra as string;
      (el.style as any)[cssProp.replace(/-([a-z])/g, (_: string, c: string) => c.toUpperCase())] =
        extra + t[prop];
    }

    // Update 3Dmol canvas background
    if (this._viewer) {
      this._viewer.setBackgroundColor(t.viewer3dBg);
      this._viewer.render();
    }
  }

  private _updateThemeBtn(): void {
    const t = this._theme();
    this._themeBtn.textContent = this._dark ? '☀ Light' : '🌙 Dark';
    this._themeBtn.style.color = t.text;
    this._themeBtn.style.borderColor = t.border;
  }

  protected onAfterAttach(msg: Message): void {
    super.onAfterAttach(msg);
    this._attached = true;
    if (this._fileContent) {
      void this._renderContent(this._fileContent, this._format);
    }
  }

  protected onResize(msg: Widget.ResizeMessage): void {
    super.onResize(msg);
    if (this._viewer) {
      this._viewer.resize();
      this._viewer.render();
    }
  }

  /** Called by the document factory once the file context is ready. */
  setContent(content: string, format: string): void {
    this._fileContent = content;
    this._format = format;
    if (this._attached) {
      void this._renderContent(content, format);
    }
  }

  private async _loadFromId(): Promise<void> {
    const id = this._idInput?.value.trim().toUpperCase();
    if (!id) return;
    this._setStatus(`Loading ${id}…`);
    try {
      this._initViewer();
      $3Dmol.download(
        `pdb:${id}`,
        this._viewer,
        { multimodel: true, frames: true },
        () => {
          this._viewer.setStyle({}, { cartoon: { color: 'spectrum' } });
          this._viewer.zoomTo();
          this._viewer.render();
          this._clearStatus();
        }
      );
    } catch (err) {
      this._setStatus(`Error: ${(err as Error).message}`);
    }
  }

  private async _renderContent(content: string, format: string): Promise<void> {
    this._setStatus('Loading…');
    try {
      this._initViewer();
      this._viewer.addModel(content, format === 'mmcif' ? 'cif' : 'pdb');
      this._viewer.setStyle({}, { cartoon: { color: 'spectrum' } });
      this._viewer.zoomTo();
      this._viewer.render();
      this._clearStatus();
    } catch (err) {
      this._setStatus(`Error: ${(err as Error).message}`);
    }
  }

  private _initViewer(): void {
    if (this._viewer) {
      this._viewer.clear();
    } else {
      const canvasContainer = document.createElement('div');
      canvasContainer.style.cssText = 'width:100%;height:100%;';
      this._viewerContainer.appendChild(canvasContainer);
      this._viewer = $3Dmol.createViewer(canvasContainer, {
        backgroundColor: this._theme().viewer3dBg,
        antialias: true,
      });
    }
  }

  private _applyStyle(style: string): void {
    if (!this._viewer) return;
    switch (style) {
      case 'cartoon':
        this._viewer.setStyle({}, { cartoon: { color: 'spectrum' } });
        break;
      case 'stick':
        this._viewer.setStyle({}, { stick: {} });
        break;
      case 'sphere':
        this._viewer.setStyle({}, { sphere: { colorscheme: 'ssJmol' } });
        break;
      case 'surface':
        this._viewer.setStyle({}, { cartoon: { color: 'spectrum' } });
        this._viewer.addSurface($3Dmol.SurfaceType.VDW, {
          opacity: 0.7,
          colorscheme: 'whiteCarbon',
        });
        break;
      case 'line':
        this._viewer.setStyle({}, { line: {} });
        break;
    }
    this._viewer.render();
  }

  private _setStatus(msg: string): void {
    this._statusEl.textContent = msg;
    this._statusEl.style.display = '';
  }

  private _clearStatus(): void {
    this._statusEl.style.display = 'none';
  }
}

// ─── Document Widget Factory ──────────────────────────────────────────────────

const PDB_FACTORY_NAME = 'Structure Viewer';
const PDB_FILE_TYPES = ['pdb', 'ent', 'mmcif'];

type PDBDocWidget = IDocumentWidget<PDBViewerWidget>;

class PDBViewerFactory extends ABCWidgetFactory<PDBDocWidget> {
  protected createNewWidget(context: DocumentRegistry.Context): PDBDocWidget {
    const format = context.path.endsWith('.mmcif') ? 'mmcif' : 'pdb';
    const content = new PDBViewerWidget({ format });
    const widget = new DocumentWidget({ content, context });
    widget.title.label = context.path.split('/').pop() ?? context.path;
    widget.title.caption = context.path;

    void context.ready.then(() => {
      content.setContent(context.model.toString(), format);
    });

    return widget;
  }
}

// ─── Plugin ───────────────────────────────────────────────────────────────────

export const pdbViewerPlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-biolm:pdb-viewer',
  autoStart: true,
  optional: [ILauncher],
  activate: (app: JupyterFrontEnd, launcher: ILauncher | null) => {
    const { docRegistry, commands } = app;

    docRegistry.addFileType({
      name: 'pdb',
      displayName: 'PDB Structure',
      extensions: ['.pdb', '.ent'],
      mimeTypes: ['chemical/x-pdb', 'text/plain'],
      contentType: 'file',
      fileFormat: 'text',
    });

    docRegistry.addFileType({
      name: 'mmcif',
      displayName: 'mmCIF Structure',
      extensions: ['.mmcif', '.cif'],
      mimeTypes: ['chemical/x-cif', 'text/plain'],
      contentType: 'file',
      fileFormat: 'text',
    });

    const factory = new PDBViewerFactory({
      name: PDB_FACTORY_NAME,
      fileTypes: PDB_FILE_TYPES,
      defaultFor: PDB_FILE_TYPES,
    });
    docRegistry.addWidgetFactory(factory);

    // Command for opening raw structure content (used by Results Explorer)
    commands.addCommand('biolm:view-structure-content', {
      label: 'View Structure in 3D',
      execute: (args) => {
        const { content, format, name } = args as {
          content: string;
          format: string;
          name: string;
        };
        const viewerWidget = new PDBViewerWidget({
          fileContent: String(content),
          format: String(format),
        });
        viewerWidget.id = `biolm-pdb-content-${Date.now()}`;
        viewerWidget.title.label = String(name || 'Structure');
        viewerWidget.title.caption = 'BioLM Structure Viewer';
        viewerWidget.title.closable = true;
        if (!viewerWidget.isAttached) {
          app.shell.add(viewerWidget, 'main');
        }
        app.shell.activateById(viewerWidget.id);
      },
    });

    commands.addCommand('biolm:open-pdb-viewer', {
      label: 'Structure Viewer',
      caption: 'Open an interactive 3D protein structure viewer',
      icon: biolmIcon,
      execute: () => {
        const widget = new PDBViewerWidget();
        widget.id = `biolm-pdb-viewer-${Date.now()}`;
        widget.title.label = 'Structure Viewer';
        widget.title.caption = 'BioLM Structure Viewer';
        widget.title.closable = true;
        if (!widget.isAttached) {
          app.shell.add(widget, 'main');
        }
        app.shell.activateById(widget.id);
      },
    });

    if (launcher) {
      launcher.add({
        command: 'biolm:open-pdb-viewer',
        category: 'BioLM',
        rank: 1,
      });
    }

    console.log('[BioLM] PDB Viewer plugin activated');
  },
};
