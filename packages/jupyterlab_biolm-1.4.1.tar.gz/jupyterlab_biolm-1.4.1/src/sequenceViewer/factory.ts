/**
 * SequenceViewerFactory — ABCWidgetFactory for opening sequence files
 * (GenBank, FASTA) via double-click in the JupyterLab file browser.
 */
import { JupyterFrontEnd } from '@jupyterlab/application';
import {
  ABCWidgetFactory,
  DocumentRegistry,
  DocumentWidget,
  IDocumentWidget,
} from '@jupyterlab/docregistry';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { SequenceViewerWidget } from './widget';

export class SequenceViewerFactory extends ABCWidgetFactory<
  IDocumentWidget<SequenceViewerWidget>
> {
  constructor(
    private readonly _app: JupyterFrontEnd,
    private readonly _docManager: IDocumentManager | null,
    options: DocumentRegistry.IWidgetFactoryOptions
  ) {
    super(options);
  }

  protected createNewWidget(
    context: DocumentRegistry.Context
  ): IDocumentWidget<SequenceViewerWidget> {
    const filename = context.path.split('/').pop() ?? context.path;

    const content = new SequenceViewerWidget(this._app, filename, this._docManager);
    const widget = new DocumentWidget({ content, context });
    widget.title.label = filename;
    widget.title.caption = context.path;
    widget.title.closable = true;

    void context.ready.then(() => {
      const text = context.model.toString();
      void content.setContent(text, filename);
    });

    return widget;
  }
}
