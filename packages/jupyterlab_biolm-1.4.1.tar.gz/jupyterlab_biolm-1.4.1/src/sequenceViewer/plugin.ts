/**
 * sequenceViewerPlugin — JupyterLab plugin for visualizing sequence files
 * using seqparse for parsing and seqviz for interactive visualization.
 */
import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ILauncher } from '@jupyterlab/launcher';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { biolmIcon } from '../biolmIcon';
import { SequenceViewerFactory } from './factory';
import { SequenceViewerWidget } from './widget';

export const sequenceViewerPlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-biolm:sequence-viewer',
  autoStart: true,
  optional: [ILauncher, IDocumentManager],
  activate: (
    app: JupyterFrontEnd,
    launcher: ILauncher | null,
    docManager: IDocumentManager | null
  ) => {
    // Register GenBank file type
    app.docRegistry.addFileType({
      name: 'genbank',
      displayName: 'GenBank Sequence',
      extensions: ['.gb', '.gbk'],
      mimeTypes: ['chemical/x-genbank', 'text/plain'],
      contentType: 'file',
      fileFormat: 'text',
    });

    // Register FASTA file type
    app.docRegistry.addFileType({
      name: 'fasta',
      displayName: 'FASTA Sequence',
      extensions: ['.fasta', '.fa', '.fas'],
      mimeTypes: ['text/x-fasta', 'text/plain'],
      contentType: 'file',
      fileFormat: 'text',
    });

    const factory = new SequenceViewerFactory(app, docManager, {
      name: 'BioLM Sequence Viewer',
      fileTypes: ['genbank', 'fasta'],
      defaultFor: ['genbank', 'fasta'],
    });
    app.docRegistry.addWidgetFactory(factory);

    // Launcher command — opens a standalone Sequence Viewer with the hero view
    app.commands.addCommand('biolm:open-sequence-viewer', {
      label: 'Sequence Viewer',
      caption: 'Open sequence files (GenBank, FASTA) with interactive circular/linear visualization',
      icon: biolmIcon,
      execute: () => {
        const widget = new SequenceViewerWidget(app, '', docManager);
        widget.id = `biolm-sequence-viewer-${Date.now()}`;
        widget.title.label = 'Sequence Viewer';
        widget.title.icon = biolmIcon;
        widget.title.closable = true;
        app.shell.add(widget, 'main');
        app.shell.activateById(widget.id);
      },
    });

    if (launcher) {
      launcher.add({
        command: 'biolm:open-sequence-viewer',
        category: 'BioLM',
        rank: 3,
      });
    }

    console.log('[BioLM] Sequence Viewer plugin activated');
  },
};
