/**
 * SequenceViewerWidget — ReactWidget for visualizing biological sequence files
 * using seqparse for parsing and seqviz for interactive rendering.
 *
 * When opened from the launcher it shows a hero landing page.
 * When a file is loaded it renders an interactive circular/linear sequence map.
 */
import React, { useState } from 'react';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { ReactWidget } from '@jupyterlab/ui-components';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { FileDialog } from '@jupyterlab/filebrowser';
import seqparse, { type Seq, type Annotation } from 'seqparse';
import { SeqViz } from 'seqviz';
import type { AnnotationProp } from 'seqviz/dist/elements';
import { biolmLogoDataUri } from '../biolmIcon';

type ViewerMode = 'both' | 'circular' | 'linear';

// ─── Widget class ─────────────────────────────────────────────────────────────

export class SequenceViewerWidget extends ReactWidget {
  private _seq: Seq | null = null;
  private _filename: string;
  /** True while waiting for context.ready before setContent is called. */
  private _initializing: boolean;
  private _loading = false;
  private _error: string | null = null;
  private readonly _app: JupyterFrontEnd;
  private readonly _docManager: IDocumentManager | null;

  constructor(
    app: JupyterFrontEnd,
    filename: string,
    docManager: IDocumentManager | null
  ) {
    super();
    this._app = app;
    this._filename = filename;
    // If a filename was provided (opened via file browser), show loading until
    // setContent is called. If opened from the launcher, show the hero view.
    this._initializing = !!filename;
    this._docManager = docManager;
    this.addClass('biolm-sequence-viewer');
    // Ensure the widget node fills its allocated area in the JupyterLab layout.
    this.node.style.height = '100%';
    this.node.style.display = 'flex';
    this.node.style.flexDirection = 'column';
    this.node.style.overflow = 'hidden';
  }

  /** Parse and load sequence content from a file string. */
  async setContent(content: string, filename: string): Promise<void> {
    this._initializing = false;
    this._loading = true;
    this._filename = filename;
    this._error = null;
    this.update();

    try {
      const result = await seqparse(content, { fileName: filename });
      this._seq = result ?? null;
      if (!this._seq || !this._seq.seq) {
        this._error = 'No sequence found in file.';
        this._seq = null;
      }
    } catch (e) {
      this._error = `Failed to parse sequence: ${e instanceof Error ? e.message : String(e)}`;
      this._seq = null;
    } finally {
      this._loading = false;
      this.update();
    }
  }

  private readonly _openFile = async (): Promise<void> => {
    if (!this._docManager) return;
    try {
      const result = await FileDialog.getOpenFiles({
        manager: this._docManager,
      });
      if (!result.value || result.value.length === 0) return;

      const path = result.value[0].path;
      const contents = await this._app.serviceManager.contents.get(path, {
        content: true,
      });
      const text = contents.content as string;
      const filename = path.split('/').pop() ?? path;

      await this.setContent(text, filename);
      this.title.label = filename;
    } catch (e) {
      console.error('[BioLM] Failed to open sequence file:', e);
    }
  };

  render(): React.ReactElement {
    if (!this._filename) {
      return (
        <SequenceHeroView
          onOpen={() => void this._openFile()}
          hasDocManager={!!this._docManager}
        />
      );
    }

    if (this._initializing || this._loading) {
      return <LoadingView />;
    }

    if (this._error || !this._seq) {
      return (
        <ErrorView
          error={this._error ?? 'Unknown error parsing sequence file.'}
          onOpen={this._docManager ? () => void this._openFile() : undefined}
        />
      );
    }

    return (
      <SequenceView
        seq={this._seq}
        filename={this._filename}
        onOpenFile={this._docManager ? () => void this._openFile() : undefined}
      />
    );
  }
}

// ─── Hero view ────────────────────────────────────────────────────────────────

interface HeroViewProps {
  onOpen: () => void;
  hasDocManager: boolean;
}

function SequenceHeroView({ onOpen, hasDocManager }: HeroViewProps): React.ReactElement {
  const codeStyle: React.CSSProperties = {
    background: 'var(--jp-layout-color2)',
    padding: '1px 5px',
    borderRadius: 3,
    fontSize: '0.9em',
    fontFamily: 'var(--jp-code-font-family, monospace)',
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: 20,
        color: 'var(--jp-ui-font-color0)',
        fontFamily: 'var(--jp-ui-font-family)',
        padding: 40,
        boxSizing: 'border-box',
      }}
    >
      <img
        src={biolmLogoDataUri}
        alt="BioLM Logo"
        style={{ width: 80, height: 80, borderRadius: 12, boxShadow: '0 4px 16px rgba(0,0,0,0.12)' }}
      />

      <div style={{ textAlign: 'center' }}>
        <h2 style={{ margin: '0 0 10px', fontSize: '1.5em', fontWeight: 700 }}>
          BioLM Sequence Viewer
        </h2>
        <p style={{ margin: 0, opacity: 0.65, fontSize: 14, lineHeight: 1.6, maxWidth: 420 }}>
          Open a <code style={codeStyle}>.gb</code> / <code style={codeStyle}>.gbk</code>{' '}
          (GenBank) or <code style={codeStyle}>.fasta</code> / <code style={codeStyle}>.fa</code>{' '}
          file to visualize the sequence with annotations in an interactive circular or linear map.
        </p>
      </div>

      {hasDocManager ? (
        <button
          className="jp-mod-styled jp-mod-accept"
          onClick={onOpen}
          style={{ padding: '10px 28px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}
        >
          Open File…
        </button>
      ) : (
        <p
          style={{
            margin: 0,
            padding: '10px 16px',
            borderRadius: 4,
            background: 'var(--jp-warn-color3, rgba(255,165,0,0.12))',
            color: 'var(--jp-warn-color0, orange)',
            fontSize: 13,
            textAlign: 'center',
            maxWidth: 380,
          }}
        >
          File dialog unavailable — double-click a <code style={codeStyle}>.gb</code> or{' '}
          <code style={codeStyle}>.fasta</code> file in the file browser to open it here.
        </p>
      )}

      <p style={{ margin: 0, opacity: 0.4, fontSize: 12 }}>
        You can also double-click any{' '}
        <code style={{ ...codeStyle, background: 'transparent' }}>.gb</code>,{' '}
        <code style={{ ...codeStyle, background: 'transparent' }}>.gbk</code>,{' '}
        <code style={{ ...codeStyle, background: 'transparent' }}>.fasta</code>, or{' '}
        <code style={{ ...codeStyle, background: 'transparent' }}>.fa</code> file in the file
        browser to open it directly.
      </p>
    </div>
  );
}

// ─── Loading view ─────────────────────────────────────────────────────────────

function LoadingView(): React.ReactElement {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        color: 'var(--jp-ui-font-color1)',
        fontFamily: 'var(--jp-ui-font-family)',
        gap: 10,
      }}
    >
      <span style={{ fontSize: 14 }}>Parsing sequence…</span>
    </div>
  );
}

// ─── Error view ───────────────────────────────────────────────────────────────

function ErrorView({
  error,
  onOpen,
}: {
  error: string;
  onOpen?: () => void;
}): React.ReactElement {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: 16,
        padding: 32,
        fontFamily: 'var(--jp-ui-font-family)',
        color: 'var(--jp-ui-font-color0)',
      }}
    >
      <p
        style={{
          margin: 0,
          padding: '12px 20px',
          borderRadius: 4,
          background: 'var(--jp-error-color3, rgba(220,53,69,0.12))',
          color: 'var(--jp-error-color1, #dc3545)',
          fontSize: 13,
          maxWidth: 480,
          textAlign: 'center',
          lineHeight: 1.5,
        }}
      >
        {error}
      </p>
      {onOpen && (
        <button
          className="jp-mod-styled jp-mod-accept"
          onClick={onOpen}
          style={{ padding: '8px 20px', fontSize: 13, cursor: 'pointer' }}
        >
          Open Another File…
        </button>
      )}
    </div>
  );
}

// ─── Sequence view ────────────────────────────────────────────────────────────

interface SequenceViewProps {
  seq: Seq;
  filename: string;
  onOpenFile?: () => void;
}

function SequenceView({ seq, filename, onOpenFile }: SequenceViewProps): React.ReactElement {
  // Amino acid sequences can't be meaningfully shown in circular view
  const defaultMode: ViewerMode = seq.type === 'aa' ? 'linear' : 'both';
  const [viewerMode, setViewerMode] = useState<ViewerMode>(defaultMode);

  const annotations: AnnotationProp[] = (seq.annotations as Annotation[]).map(a => ({
    name: a.name,
    start: a.start,
    end: a.end,
    direction: a.direction,
    color: a.color,
  }));

  const modes: ViewerMode[] = seq.type === 'aa' ? ['linear'] : ['both', 'circular', 'linear'];

  const toolbarStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '6px 12px',
    borderBottom: '1px solid var(--jp-border-color1)',
    background: 'var(--jp-layout-color1)',
    flexShrink: 0,
    fontFamily: 'var(--jp-ui-font-family)',
    fontSize: 12,
    overflow: 'hidden',
  };

  const modeBtnStyle = (active: boolean): React.CSSProperties => ({
    padding: '3px 10px',
    fontSize: 12,
    cursor: 'pointer',
    borderRadius: 3,
    border: '1px solid var(--jp-border-color1)',
    background: active ? 'var(--jp-brand-color1)' : 'var(--jp-layout-color2)',
    color: active ? '#fff' : 'var(--jp-ui-font-color1)',
    fontWeight: active ? 600 : 400,
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Toolbar */}
      <div style={toolbarStyle}>
        <span
          style={{
            flex: 1,
            fontWeight: 600,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            color: 'var(--jp-ui-font-color0)',
          }}
          title={filename}
        >
          {seq.name || filename}
        </span>

        <span
          style={{
            opacity: 0.6,
            whiteSpace: 'nowrap',
            fontSize: 11,
            color: 'var(--jp-ui-font-color1)',
          }}
        >
          {seq.seq.length.toLocaleString()} bp · {seq.type.toUpperCase()} ·{' '}
          {annotations.length} annotation{annotations.length !== 1 ? 's' : ''}
        </span>

        <div style={{ display: 'flex', gap: 4, marginLeft: 8 }}>
          {modes.map(mode => (
            <button
              key={mode}
              style={modeBtnStyle(viewerMode === mode)}
              onClick={() => setViewerMode(mode)}
              title={`${mode.charAt(0).toUpperCase() + mode.slice(1)} view`}
            >
              {mode === 'both' ? 'Both' : mode.charAt(0).toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>

        {onOpenFile && (
          <button
            className="jp-mod-styled"
            onClick={onOpenFile}
            style={{ padding: '3px 10px', fontSize: 12, cursor: 'pointer', marginLeft: 4 }}
          >
            Open…
          </button>
        )}
      </div>

      {/* SeqViz viewer */}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        <SeqViz
          name={seq.name}
          seq={seq.seq}
          annotations={annotations}
          viewer={viewerMode}
          primers={[]}
          style={{ height: '100%', width: '100%' }}
          showIndex={true}
          showComplement={seq.type !== 'aa'}
        />
      </div>
    </div>
  );
}
