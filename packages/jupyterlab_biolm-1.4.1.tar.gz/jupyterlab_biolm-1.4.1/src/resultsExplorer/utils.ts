/**
 * Utility functions for the BioLM Results Explorer.
 * Covers: structure detection, heatmap colours, stats, and structure extraction.
 */
import { Row, StatsResult, ExtractionOptions } from './types';

// ─── Structure field detection ─────────────────────────────────────────────

const STRUCTURE_KEYS = new Set(['cif', 'pdb', 'mmcif', 'ent', 'structure']);

export function isStructureValue(key: string, value: unknown): value is string {
  if (typeof value !== 'string' || value.length < 20) return false;
  if (STRUCTURE_KEYS.has(key.toLowerCase())) return true;
  const head = value.trimStart().substring(0, 30);
  return (
    head.startsWith('data_') ||
    head.startsWith('ATOM ') ||
    head.startsWith('HEADER') ||
    head.startsWith('REMARK')
  );
}

export function getStructureFormat(key: string, value: string): 'mmcif' | 'pdb' {
  const lk = key.toLowerCase();
  if (lk === 'cif' || lk === 'mmcif' || value.trimStart().startsWith('data_'))
    return 'mmcif';
  return 'pdb';
}

// ─── Score heatmap colouring (values in [0, 1]) ────────────────────────────

export function scoreBackground(value: number): string | undefined {
  if (value < 0 || value > 1) return undefined;
  const r = value < 0.5 ? 220 : Math.round(220 * (1 - value) * 2);
  const g = value < 0.5 ? Math.round(160 * value * 2) : 160;
  return `rgba(${r},${g},60,0.18)`;
}

// ─── Download helpers ──────────────────────────────────────────────────────

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadStructure(content: string, format: string, label: string): void {
  const ext = format === 'mmcif' ? '.cif' : '.pdb';
  const blob = new Blob([content], { type: 'text/plain' });
  downloadBlob(blob, `${label}${ext}`);
}

// ─── Descriptive statistics ────────────────────────────────────────────────

export function computeStats(values: number[]): StatsResult {
  if (values.length === 0) {
    return {
      count: 0, min: 0, max: 0, mean: 0, median: 0,
      q1: 0, q3: 0, stdDev: 0, whiskerLow: 0, whiskerHigh: 0, outliers: [],
    };
  }
  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;

  const quantile = (p: number): number => {
    const idx = p * (n - 1);
    const lo = Math.floor(idx);
    const hi = Math.ceil(idx);
    return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
  };

  const min = sorted[0];
  const max = sorted[n - 1];
  const mean = values.reduce((a, b) => a + b, 0) / n;
  const median = quantile(0.5);
  const q1 = quantile(0.25);
  const q3 = quantile(0.75);
  const iqr = q3 - q1;
  const whiskerLow = Math.max(min, q1 - 1.5 * iqr);
  const whiskerHigh = Math.min(max, q3 + 1.5 * iqr);
  const variance = values.reduce((acc, v) => acc + (v - mean) ** 2, 0) / n;
  const stdDev = Math.sqrt(variance);
  const outliers = values.filter(v => v < whiskerLow || v > whiskerHigh);

  return { count: n, min, max, mean, median, q1, q3, stdDev, whiskerLow, whiskerHigh, outliers };
}

// ─── Bulk structure extraction ─────────────────────────────────────────────

/** Minimal interface for the parts of IContentsManager we need. */
interface IContentsManagerSubset {
  save(
    path: string,
    options?: Partial<{ type: string; format: string; content: unknown }>
  ): Promise<unknown>;
}

export async function extractStructures(
  rows: Row[],
  colKey: string,
  opts: ExtractionOptions,
  contentsManager: IContentsManagerSubset
): Promise<{ success: number; errors: number }> {
  const structures = rows
    .map((row, i) => ({ content: String(row[colKey] ?? ''), index: i + 1 }))
    .filter(s => s.content.length > 20);

  let success = 0;
  let errors = 0;

  const getFilename = (i: number): string => `${opts.prefix}${i}${opts.ext}`;

  if (opts.dest === 'browser') {
    if (opts.archive === 'zip') {
      // Dynamic import of JSZip to avoid bundling it eagerly
      const { default: JSZip } = await import('jszip');
      const zip = new JSZip();
      structures.forEach(s => {
        zip.file(getFilename(s.index), s.content);
        success++;
      });
      const blob = await zip.generateAsync({ type: 'blob' });
      downloadBlob(blob, `${opts.prefix.replace(/_$/, '') || 'structures'}.zip`);
    } else {
      for (const s of structures) {
        const blob = new Blob([s.content], { type: 'text/plain' });
        downloadBlob(blob, getFilename(s.index));
        success++;
        // Small delay between downloads so the browser doesn't block them
        await new Promise<void>(resolve => setTimeout(resolve, 60));
      }
    }
  } else {
    // Save to server
    const dirPrefix = opts.serverDir ? opts.serverDir.replace(/\/$/, '') + '/' : '';

    if (opts.archive === 'zip') {
      const { default: JSZip } = await import('jszip');
      const zip = new JSZip();
      structures.forEach(s => zip.file(getFilename(s.index), s.content));
      const blob = await zip.generateAsync({ type: 'blob' });

      // Convert blob → base64 for the JupyterLab contents API
      const arrayBuffer = await blob.arrayBuffer();
      let binary = '';
      new Uint8Array(arrayBuffer).forEach(b => { binary += String.fromCharCode(b); });
      const base64 = btoa(binary);
      const zipPath = `${dirPrefix}${opts.prefix.replace(/_$/, '') || 'structures'}.zip`;

      try {
        await contentsManager.save(zipPath, { type: 'file', format: 'base64', content: base64 });
        success = structures.length;
      } catch (e) {
        errors = structures.length;
        console.error('[BioLM] Failed to save zip:', e);
      }
    } else {
      for (const s of structures) {
        const path = `${dirPrefix}${getFilename(s.index)}`;
        try {
          await contentsManager.save(path, { type: 'file', format: 'text', content: s.content });
          success++;
        } catch (e) {
          errors++;
          console.error(`[BioLM] Failed to save ${path}:`, e);
        }
      }
    }
  }

  return { success, errors };
}
