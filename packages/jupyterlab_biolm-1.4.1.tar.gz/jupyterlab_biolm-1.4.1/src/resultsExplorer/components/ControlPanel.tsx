/**
 * ControlPanel — collapsible panels for column show/hide+reorder and numeric filters.
 * Lives above the results table.
 */
import React, { useState } from 'react';
import { NumericFilter, FilterOp } from '../types';

interface ControlPanelProps {
  // Column management
  allColumns: string[];
  colOrder: string[];
  hiddenCols: Set<string>;
  onSetColOrder: (order: string[]) => void;
  onToggleCol: (col: string) => void;

  // Numeric filter management
  numericCols: string[];
  filters: NumericFilter[];
  onSetFilters: (filters: NumericFilter[]) => void;
}

export function ControlPanel({
  allColumns: _allColumns,
  colOrder,
  hiddenCols,
  onSetColOrder,
  onToggleCol,
  numericCols,
  filters,
  onSetFilters,
}: ControlPanelProps): React.ReactElement {
  const [colPanelOpen, setColPanelOpen] = useState(false);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);

  // ── Column reorder helpers ─────────────────────────────────────────────────
  const moveCol = (idx: number, dir: -1 | 1): void => {
    const newOrder = [...colOrder];
    const swap = idx + dir;
    if (swap < 0 || swap >= newOrder.length) return;
    [newOrder[idx], newOrder[swap]] = [newOrder[swap], newOrder[idx]];
    onSetColOrder(newOrder);
  };

  // ── Filter helpers ─────────────────────────────────────────────────────────
  const addFilter = (): void => {
    if (numericCols.length === 0) return;
    onSetFilters([
      ...filters,
      {
        id: Math.random().toString(36).slice(2),
        field: numericCols[0],
        op: '>',
        value: 0,
      },
    ]);
  };

  const updateFilter = (id: string, patch: Partial<NumericFilter>): void => {
    onSetFilters(filters.map(f => (f.id === id ? { ...f, ...patch } : f)));
  };

  const removeFilter = (id: string): void => {
    onSetFilters(filters.filter(f => f.id !== id));
  };

  // ── Shared styles ──────────────────────────────────────────────────────────
  const btnStyle: React.CSSProperties = {
    padding: '3px 10px',
    borderRadius: 4,
    border: '1px solid var(--jp-border-color1)',
    background: 'var(--jp-layout-color0)',
    color: 'var(--jp-ui-font-color1)',
    cursor: 'pointer',
    fontSize: 12,
    fontWeight: 600,
  };

  const inputStyle: React.CSSProperties = {
    fontSize: 12,
    padding: '3px 6px',
    borderRadius: 3,
    border: '1px solid var(--jp-border-color1)',
    background: 'var(--jp-layout-color0)',
    color: 'var(--jp-ui-font-color0)',
  };

  const sectionLabelStyle: React.CSSProperties = {
    fontSize: 11,
    fontWeight: 600,
    color: 'var(--jp-ui-font-color2)',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  };

  return (
    <div>
      {/* ── Toolbar row ──────────────────────────────────────────────────── */}
      <div
        style={{
          display: 'flex',
          gap: 8,
          padding: '5px 14px',
          background: 'var(--jp-layout-color1)',
          borderBottom: '1px solid var(--jp-border-color2)',
          alignItems: 'center',
          flexShrink: 0,
        }}
      >
        <button style={btnStyle} onClick={() => setColPanelOpen(v => !v)}>
          Columns {colPanelOpen ? '▴' : '▾'}
        </button>
        <button
          style={{
            ...btnStyle,
            background: filters.length > 0 ? 'var(--jp-brand-color3, rgba(31,111,235,0.15))' : 'var(--jp-layout-color0)',
          }}
          onClick={() => setFilterPanelOpen(v => !v)}
        >
          Filters{filters.length > 0 ? ` (${filters.length})` : ''} {filterPanelOpen ? '▴' : '▾'}
        </button>
      </div>

      {/* ── Column panel ─────────────────────────────────────────────────── */}
      {colPanelOpen && (
        <div
          style={{
            padding: '10px 14px',
            background: 'var(--jp-layout-color1)',
            borderBottom: '1px solid var(--jp-border-color1)',
            maxHeight: 260,
            overflowY: 'auto',
          }}
        >
          <div style={sectionLabelStyle}>Show / Reorder Columns</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {colOrder.map((col, idx) => (
              <div
                key={col}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '3px 6px',
                  borderRadius: 3,
                  background: 'var(--jp-layout-color0)',
                  border: '1px solid var(--jp-border-color2)',
                }}
              >
                <input
                  type="checkbox"
                  checked={!hiddenCols.has(col)}
                  onChange={() => onToggleCol(col)}
                  style={{ cursor: 'pointer', flexShrink: 0 }}
                />
                <span
                  style={{
                    flex: 1,
                    fontSize: 12,
                    fontFamily: 'var(--jp-code-font-family, monospace)',
                    color: hiddenCols.has(col) ? 'var(--jp-ui-font-color3)' : 'var(--jp-ui-font-color0)',
                    textDecoration: hiddenCols.has(col) ? 'line-through' : 'none',
                  }}
                >
                  {col}
                </span>
                <button
                  onClick={() => moveCol(idx, -1)}
                  disabled={idx === 0}
                  style={{ ...btnStyle, padding: '1px 6px', opacity: idx === 0 ? 0.3 : 1 }}
                  title="Move up"
                >
                  ▲
                </button>
                <button
                  onClick={() => moveCol(idx, 1)}
                  disabled={idx === colOrder.length - 1}
                  style={{ ...btnStyle, padding: '1px 6px', opacity: idx === colOrder.length - 1 ? 0.3 : 1 }}
                  title="Move down"
                >
                  ▼
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Filter panel ─────────────────────────────────────────────────── */}
      {filterPanelOpen && (
        <div
          style={{
            padding: '10px 14px',
            background: 'var(--jp-layout-color1)',
            borderBottom: '1px solid var(--jp-border-color1)',
          }}
        >
          <div style={sectionLabelStyle}>Numeric Filters (AND logic)</div>
          {numericCols.length === 0 ? (
            <p style={{ fontSize: 12, color: 'var(--jp-ui-font-color2)', margin: 0 }}>
              No numeric columns found in the current data.
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {filters.map(f => (
                <div key={f.id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  {/* Field selector */}
                  <select
                    value={f.field}
                    onChange={e => updateFilter(f.id, { field: e.target.value })}
                    style={{ ...inputStyle, maxWidth: 160 }}
                  >
                    {numericCols.map(c => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>

                  {/* Operator selector */}
                  <select
                    value={f.op}
                    onChange={e => updateFilter(f.id, { op: e.target.value as FilterOp })}
                    style={{ ...inputStyle, width: 56 }}
                  >
                    {(['>', '>=', '<', '<=', '=', '!='] as FilterOp[]).map(op => (
                      <option key={op} value={op}>
                        {op}
                      </option>
                    ))}
                  </select>

                  {/* Value input */}
                  <input
                    type="number"
                    step="any"
                    value={f.value}
                    onChange={e => updateFilter(f.id, { value: parseFloat(e.target.value) || 0 })}
                    style={{ ...inputStyle, width: 90 }}
                  />

                  {/* Remove button */}
                  <button
                    onClick={() => removeFilter(f.id)}
                    style={{ ...btnStyle, padding: '2px 8px', color: 'var(--jp-error-color1, #dc2626)' }}
                    title="Remove this filter"
                  >
                    ×
                  </button>
                </div>
              ))}

              <button
                onClick={addFilter}
                style={{ ...btnStyle, alignSelf: 'flex-start', marginTop: 3 }}
              >
                + Add Filter
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
