/**
 * StatsPanel — collapsible summary statistics + inline SVG boxplot.
 * Displayed below the results table; reacts to the current displayed (filtered) rows.
 */
import React, { useState, useMemo } from 'react';
import { Row, StatsResult } from '../types';
import { computeStats } from '../utils';

// ─── Inline SVG boxplot ───────────────────────────────────────────────────────

function BoxPlot({ stats }: { stats: StatsResult }): React.ReactElement {
  const W = 160;
  const H = 24;
  const pad = 8;
  const range = stats.max - stats.min;
  const toX = (v: number): number =>
    range === 0 ? W / 2 : pad + ((v - stats.min) / range) * (W - 2 * pad);

  const q1X = toX(stats.q1);
  const q3X = toX(stats.q3);
  const medX = toX(stats.median);
  const wlX = toX(stats.whiskerLow);
  const whX = toX(stats.whiskerHigh);
  const midY = H / 2;
  const boxH = 10;
  const boxY = midY - boxH / 2;

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width={W}
      height={H}
      style={{ display: 'block', color: 'var(--jp-ui-font-color1)' }}
    >
      {/* Whisker lines */}
      <line x1={wlX} y1={midY} x2={q1X} y2={midY} stroke="currentColor" strokeWidth="1.5" />
      <line x1={q3X} y1={midY} x2={whX} y2={midY} stroke="currentColor" strokeWidth="1.5" />
      {/* Whisker end caps */}
      <line x1={wlX} y1={boxY} x2={wlX} y2={boxY + boxH} stroke="currentColor" strokeWidth="1.5" />
      <line x1={whX} y1={boxY} x2={whX} y2={boxY + boxH} stroke="currentColor" strokeWidth="1.5" />
      {/* IQR box */}
      {q3X > q1X && (
        <rect
          x={q1X}
          y={boxY}
          width={q3X - q1X}
          height={boxH}
          fill="rgba(31,111,235,0.18)"
          stroke="currentColor"
          strokeWidth="1.5"
          rx={1}
        />
      )}
      {/* Median line */}
      <line x1={medX} y1={boxY} x2={medX} y2={boxY + boxH} stroke="currentColor" strokeWidth="2.5" />
      {/* Outlier circles (cap at 20 to avoid SVG overload) */}
      {stats.outliers.slice(0, 20).map((v, i) => (
        <circle
          key={i}
          cx={toX(v)}
          cy={midY}
          r={2.5}
          fill="none"
          stroke="var(--jp-warn-color1, orange)"
          strokeWidth="1.5"
        />
      ))}
    </svg>
  );
}

// ─── Stats panel ──────────────────────────────────────────────────────────────

interface StatsPanelProps {
  displayedRows: Row[];
  numericCols: string[];
}

export function StatsPanel({ displayedRows, numericCols }: StatsPanelProps): React.ReactElement {
  const [open, setOpen] = useState(false);

  const stats = useMemo<Record<string, StatsResult>>(() => {
    const result: Record<string, StatsResult> = {};
    for (const col of numericCols) {
      const values = displayedRows
        .map(row => row[col])
        .filter((v): v is number => typeof v === 'number' && !isNaN(v as number));
      if (values.length > 0) {
        result[col] = computeStats(values);
      }
    }
    return result;
  }, [displayedRows, numericCols]);

  const visibleCols = numericCols.filter(c => c in stats);

  if (visibleCols.length === 0) return <></>;

  const fmt = (v: number): string =>
    Number.isInteger(v) ? v.toFixed(0) : Math.abs(v) < 0.01 ? v.toExponential(2) : v.toFixed(4);

  return (
    <div
      style={{
        borderTop: '1px solid var(--jp-border-color1)',
        background: 'var(--jp-layout-color1)',
        flexShrink: 0,
      }}
    >
      {/* Toggle header */}
      <div
        onClick={() => setOpen(v => !v)}
        style={{
          padding: '5px 14px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontSize: 12,
          fontWeight: 600,
          color: 'var(--jp-ui-font-color1)',
          userSelect: 'none',
        }}
      >
        <span>Summary Stats</span>
        <span style={{ color: 'var(--jp-ui-font-color2)', fontWeight: 400 }}>
          ({visibleCols.length} column{visibleCols.length !== 1 ? 's' : ''}, {displayedRows.length} row
          {displayedRows.length !== 1 ? 's' : ''})
        </span>
        <span style={{ marginLeft: 'auto' }}>{open ? '▴' : '▾'}</span>
      </div>

      {open && (
        <div style={{ overflowX: 'auto', maxHeight: 280, overflowY: 'auto' }}>
          <table
            style={{
              borderCollapse: 'collapse',
              fontSize: 11,
              color: 'var(--jp-ui-font-color0)',
              width: '100%',
              minWidth: 640,
            }}
          >
            <thead>
              <tr style={{ background: 'var(--jp-layout-color2)' }}>
                {['Column', 'N', 'Min', 'Max', 'Mean', 'Median', 'Std Dev', 'Distribution'].map(h => (
                  <th
                    key={h}
                    style={{
                      padding: '5px 10px',
                      textAlign: h === 'Distribution' ? 'center' : 'right',
                      fontWeight: 600,
                      color: 'var(--jp-ui-font-color2)',
                      whiteSpace: 'nowrap',
                      borderBottom: '1px solid var(--jp-border-color1)',
                      position: 'sticky',
                      top: 0,
                      background: 'var(--jp-layout-color2)',
                      fontSize: 10,
                      textTransform: 'uppercase',
                      letterSpacing: 0.5,
                      ...(h === 'Column' ? { textAlign: 'left' } : {}),
                    }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visibleCols.map((col, i) => {
                const s = stats[col];
                return (
                  <tr
                    key={col}
                    style={{
                      background:
                        i % 2 === 0 ? 'var(--jp-layout-color0)' : 'var(--jp-layout-color1)',
                    }}
                  >
                    <td
                      style={{
                        padding: '4px 10px',
                        fontWeight: 600,
                        whiteSpace: 'nowrap',
                        fontFamily: 'var(--jp-code-font-family, monospace)',
                        fontSize: 11,
                        textAlign: 'left',
                      }}
                    >
                      {col}
                    </td>
                    {[s.count, s.min, s.max, s.mean, s.median, s.stdDev].map((v, j) => (
                      <td
                        key={j}
                        style={{
                          padding: '4px 10px',
                          textAlign: 'right',
                          fontFamily: 'var(--jp-code-font-family, monospace)',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {j === 0 ? String(v) : fmt(v as number)}
                      </td>
                    ))}
                    <td style={{ padding: '4px 10px', textAlign: 'center' }}>
                      {s.count > 1 ? (
                        <BoxPlot stats={s} />
                      ) : (
                        <span style={{ color: 'var(--jp-ui-font-color3)', fontSize: 10 }}>N/A</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
