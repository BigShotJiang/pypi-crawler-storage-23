/**
 * ResultsTable — the main table component for the BioLM Results Explorer.
 * Manages column ordering/visibility, search, numeric filters, sorting,
 * and delegates to sub-panels for stats and structure extraction.
 */
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { Row, NumericFilter } from '../types';
import { isStructureValue, getStructureFormat, scoreBackground, downloadStructure } from '../utils';
import { ControlPanel } from './ControlPanel';
import { StatsPanel } from './StatsPanel';
import { ExtractionPanel } from './ExtractionPanel';

// ─── Styles ───────────────────────────────────────────────────────────────────

const thStyle: React.CSSProperties = {
  padding: '8px 12px',
  textAlign: 'left',
  fontWeight: 600,
  fontSize: 12,
  color: 'var(--jp-ui-font-color1)',
  borderBottom: '2px solid var(--jp-border-color1)',
  whiteSpace: 'nowrap',
  position: 'sticky',
  top: 0,
  background: 'var(--jp-layout-color2)',
  cursor: 'pointer',
  userSelect: 'none',
};

const tdStyle: React.CSSProperties = {
  padding: '6px 12px',
  borderBottom: '1px solid var(--jp-border-color2)',
  verticalAlign: 'middle',
  maxWidth: 300,
};

const actionBtnStyle = (bg: string): React.CSSProperties => ({
  padding: '2px 8px',
  borderRadius: 4,
  border: 'none',
  cursor: 'pointer',
  background: bg,
  color: '#fff',
  fontSize: 11,
  fontWeight: 600,
  whiteSpace: 'nowrap',
  lineHeight: '18px',
});

// ─── Cell renderer ────────────────────────────────────────────────────────────

function CellValue({
  col,
  value,
  rowIdx,
  app,
}: {
  col: string;
  value: unknown;
  rowIdx: number;
  app: JupyterFrontEnd;
}): React.ReactElement {
  if (isStructureValue(col, value)) {
    const fmt = getStructureFormat(col, value);
    const label = `result_${rowIdx + 1}`;
    return (
      <span style={{ display: 'inline-flex', gap: 4 }}>
        <button
          title="Open in 3D Structure Viewer"
          onClick={() => {
            app.commands.execute('biolm:view-structure-content', {
              content: value,
              format: fmt,
              name: `${label}.${fmt === 'mmcif' ? 'cif' : 'pdb'}`,
            }).catch(err => {
              console.error('Failed to open structure viewer:', err);
            });
          }}
          style={actionBtnStyle('#0969da')}
        >
          🔬 View
        </button>
        <button
          title="Download structure file"
          onClick={() => downloadStructure(value, fmt, label)}
          style={actionBtnStyle('#1a7f37')}
        >
          ⬇ Download
        </button>
      </span>
    );
  }

  if (typeof value === 'number') {
    const bg = scoreBackground(value);
    const formatted = Number.isInteger(value) ? String(value) : value.toFixed(4);
    return (
      <span
        title={String(value)}
        style={{
          display: 'inline-block',
          padding: '2px 6px',
          borderRadius: 3,
          background: bg,
          fontFamily: 'var(--jp-code-font-family, monospace)',
          fontSize: 12,
        }}
      >
        {formatted}
      </span>
    );
  }

  if (typeof value === 'string') {
    const truncated = value.length > 80 ? value.substring(0, 77) + '…' : value;
    return (
      <span title={value.length > 80 ? value : undefined} style={{ fontSize: 12 }}>
        {truncated}
      </span>
    );
  }

  return <span style={{ fontSize: 12 }}>{String(value ?? '')}</span>;
}

// ─── ResultsTable ─────────────────────────────────────────────────────────────

interface ResultsTableProps {
  rows: Row[];
  columns: string[];
  app: JupyterFrontEnd;
  filename: string;
  /** Called when the user wants to open a different file. */
  onOpenFile?: () => void;
}

export function ResultsTable({
  rows,
  columns,
  app,
  filename,
  onOpenFile,
}: ResultsTableProps): React.ReactElement {
  // ── Sort state ─────────────────────────────────────────────────────────────
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  // ── Search state ───────────────────────────────────────────────────────────
  const [search, setSearch] = useState('');

  // ── Column management state ────────────────────────────────────────────────
  const [colOrder, setColOrder] = useState<string[]>([]);
  const [hiddenCols, setHiddenCols] = useState<Set<string>>(new Set());

  // ── Numeric filter state ───────────────────────────────────────────────────
  const [filters, setFilters] = useState<NumericFilter[]>([]);

  // ── Reset all state when the column set changes (new file loaded) ──────────
  useEffect(() => {
    const sc = columns.filter(
      c => rows.length > 0 && isStructureValue(c, rows[0][c])
    );
    const dc = columns.filter(c => !sc.includes(c));
    setColOrder([...dc, ...sc]);
    setHiddenCols(new Set());
    setFilters([]);
    setSortCol(null);
    setSearch('');
  }, [columns, rows]); // Both change together when a new file is loaded

  // ── Derived column lists ───────────────────────────────────────────────────
  const structureCols = useMemo(
    () => columns.filter(c => rows.length > 0 && isStructureValue(c, rows[0][c])),
    [columns, rows]
  );

  const numericCols = useMemo(
    () =>
      columns.filter(
        c => !structureCols.includes(c) && rows.length > 0 && typeof rows[0][c] === 'number'
      ),
    [columns, rows, structureCols]
  );

  const visibleCols = useMemo(
    () => colOrder.filter(k => !hiddenCols.has(k) && columns.includes(k)),
    [colOrder, hiddenCols, columns]
  );

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleSort = useCallback(
    (col: string) => {
      if (sortCol === col) {
        setSortDir(d => (d === 'asc' ? 'desc' : 'asc'));
      } else {
        setSortCol(col);
        setSortDir('asc');
      }
    },
    [sortCol]
  );

  const handleToggleCol = useCallback((col: string) => {
    setHiddenCols(prev => {
      const next = new Set(prev);
      if (next.has(col)) next.delete(col);
      else next.add(col);
      return next;
    });
  }, []);

  // ── Data pipeline ──────────────────────────────────────────────────────────
  // 1. Full text search
  const searchedRows = useMemo(() => {
    if (!search.trim()) return rows;
    const q = search.toLowerCase();
    return rows.filter(row =>
      Object.values(row).some(v => String(v).toLowerCase().includes(q))
    );
  }, [rows, search]);

  // 2. Numeric filters (AND-ed together) — this is "displayedRows" for stats/extraction
  const filteredRows = useMemo(() => {
    if (filters.length === 0) return searchedRows;
    return searchedRows.filter(row =>
      filters.every(f => {
        const v = Number(row[f.field]);
        if (isNaN(v)) return true; // non-numeric values pass through
        switch (f.op) {
          case '>':
            return v > f.value;
          case '>=':
            return v >= f.value;
          case '<':
            return v < f.value;
          case '<=':
            return v <= f.value;
          case '=':
            return v === f.value;
          case '!=':
            return v !== f.value;
          default:
            return true;
        }
      })
    );
  }, [searchedRows, filters]);

  // 3. Sort (display-only — does not affect stats/extraction)
  const sortedRows = useMemo(() => {
    if (!sortCol) return filteredRows;
    return [...filteredRows].sort((a, b) => {
      const av = a[sortCol];
      const bv = b[sortCol];
      if (av === bv) return 0;
      const cmp = av! < bv! ? -1 : 1;
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [filteredRows, sortCol, sortDir]);

  // ── Summary counts ─────────────────────────────────────────────────────────
  const activeFilterCount = filters.length;
  const showingCount = filteredRows.length;
  const hasActiveFilters = search.trim() !== '' || activeFilterCount > 0;

  // ─────────────────────────────────────────────────────────────────────────

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        fontFamily: 'var(--jp-ui-font-family)',
        background: 'var(--jp-layout-color0)',
        overflow: 'hidden',
      }}
    >
      {/* ── Header bar ──────────────────────────────────────────────────── */}
      <div
        style={{
          padding: '8px 14px',
          background: 'var(--jp-layout-color1)',
          borderBottom: '1px solid var(--jp-border-color1)',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          flexShrink: 0,
          flexWrap: 'wrap',
        }}
      >
        <span
          style={{ fontWeight: 700, fontSize: 14, color: 'var(--jp-ui-font-color0)', whiteSpace: 'nowrap' }}
        >
          🧬 BioLM Results Explorer
        </span>

        <span style={{ color: 'var(--jp-ui-font-color2)', fontSize: 12, whiteSpace: 'nowrap' }}>
          {filename} &mdash; <strong>{rows.length}</strong> result{rows.length !== 1 ? 's' : ''}
          {hasActiveFilters && showingCount !== rows.length ? (
            <span> ({showingCount} shown)</span>
          ) : null}
        </span>

        {/* Search box */}
        <input
          type="search"
          placeholder="Search all columns…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          aria-label="Search results"
          style={{
            marginLeft: 'auto',
            padding: '4px 8px',
            borderRadius: 4,
            border: '1px solid var(--jp-border-color1)',
            background: 'var(--jp-layout-color0)',
            color: 'var(--jp-ui-font-color0)',
            fontSize: 12,
            width: 200,
            outline: 'none',
          }}
        />

        {/* Open another file button */}
        {onOpenFile && (
          <button
            onClick={onOpenFile}
            style={{
              padding: '3px 10px',
              borderRadius: 4,
              border: '1px solid var(--jp-border-color1)',
              background: 'var(--jp-layout-color0)',
              color: 'var(--jp-ui-font-color1)',
              cursor: 'pointer',
              fontSize: 12,
              fontWeight: 600,
              whiteSpace: 'nowrap',
            }}
            title="Open a different file"
          >
            📂 Open…
          </button>
        )}
      </div>

      {/* ── Control panel (column + filter) ─────────────────────────────── */}
      <ControlPanel
        allColumns={columns}
        colOrder={colOrder}
        hiddenCols={hiddenCols}
        onSetColOrder={setColOrder}
        onToggleCol={handleToggleCol}
        numericCols={numericCols}
        filters={filters}
        onSetFilters={setFilters}
      />

      {/* ── Table ────────────────────────────────────────────────────────── */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {sortedRows.length === 0 ? (
          <div
            style={{
              padding: 60,
              textAlign: 'center',
              color: 'var(--jp-ui-font-color2)',
              fontSize: 14,
            }}
          >
            {rows.length === 0
              ? 'No results found in this file.'
              : 'No results match your current search or filter.'}
          </div>
        ) : (
          <table
            style={{
              borderCollapse: 'collapse',
              width: '100%',
              fontSize: 13,
              color: 'var(--jp-ui-font-color0)',
            }}
          >
            <thead>
              <tr>
                <th style={{ ...thStyle, cursor: 'default', width: 40 }}>#</th>
                {visibleCols.map(col => {
                  const isStruct = structureCols.includes(col);
                  return (
                    <th
                      key={col}
                      title={isStruct ? col : `Sort by ${col}`}
                      onClick={isStruct ? undefined : () => handleSort(col)}
                      style={{
                        ...thStyle,
                        cursor: isStruct ? 'default' : 'pointer',
                        color: isStruct
                          ? 'var(--jp-ui-font-color2)'
                          : 'var(--jp-ui-font-color1)',
                      }}
                    >
                      {col}
                      {!isStruct &&
                        (sortCol === col ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ' ↕')}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {sortedRows.map((row, i) => (
                <tr
                  key={i}
                  style={{
                    background:
                      i % 2 === 0 ? 'var(--jp-layout-color0)' : 'var(--jp-layout-color1)',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLTableRowElement).style.background =
                      'var(--jp-brand-color3, rgba(31,111,235,0.08))';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLTableRowElement).style.background =
                      i % 2 === 0 ? 'var(--jp-layout-color0)' : 'var(--jp-layout-color1)';
                  }}
                >
                  <td
                    style={{
                      ...tdStyle,
                      color: 'var(--jp-ui-font-color2)',
                      fontSize: 11,
                      textAlign: 'right',
                      paddingRight: 8,
                    }}
                  >
                    {i + 1}
                  </td>
                  {visibleCols.map(col => (
                    <td key={col} style={tdStyle}>
                      <CellValue col={col} value={row[col]} rowIdx={i} app={app} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ── Stats panel ──────────────────────────────────────────────────── */}
      <StatsPanel displayedRows={filteredRows} numericCols={numericCols} />

      {/* ── Extraction panel ─────────────────────────────────────────────── */}
      <ExtractionPanel displayedRows={filteredRows} allRows={rows} app={app} />
    </div>
  );
}
