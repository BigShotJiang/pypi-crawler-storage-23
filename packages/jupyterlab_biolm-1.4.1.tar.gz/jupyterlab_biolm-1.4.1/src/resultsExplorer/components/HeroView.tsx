/**
 * Hero landing page shown when the Results Explorer is opened from the launcher
 * (before any file has been loaded).
 */
import React from 'react';
import { biolmLogoDataUri } from '../../biolmIcon';

interface HeroViewProps {
  /** Called when the user clicks "Open File…". */
  onOpen: () => void;
  /** False if FileDialog is unavailable (IDocumentManager not injected). */
  hasDocManager: boolean;
}

export function HeroView({ onOpen, hasDocManager }: HeroViewProps): React.ReactElement {
  const codeStyle: React.CSSProperties = {
    background: 'var(--jp-layout-color2)',
    padding: '1px 5px',
    borderRadius: 3,
    fontSize: '0.9em',
    fontFamily: 'var(--jp-code-font-family, monospace)',
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: 20,
        color: 'var(--jp-ui-font-color0)',
        fontFamily: 'var(--jp-ui-font-family)',
        padding: 40,
        boxSizing: 'border-box',
      }}
    >
      <img
        src={biolmLogoDataUri}
        alt="BioLM Logo"
        style={{ width: 80, height: 80, borderRadius: 12, boxShadow: '0 4px 16px rgba(0,0,0,0.12)' }}
      />

      <div style={{ textAlign: 'center' }}>
        <h2 style={{ margin: '0 0 10px', fontSize: '1.5em', fontWeight: 700 }}>
          BioLM Results Explorer
        </h2>
        <p style={{ margin: 0, opacity: 0.65, fontSize: 14, lineHeight: 1.6, maxWidth: 400 }}>
          Open a <code style={codeStyle}>.jsonl</code> or <code style={codeStyle}>.csv</code>{' '}
          BioLM protocol results file to explore sequences, scores, and 3D structures interactively.
        </p>
      </div>

      {hasDocManager ? (
        <button
          className="jp-mod-styled jp-mod-accept"
          onClick={onOpen}
          style={{ padding: '10px 28px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}
        >
          Open File…
        </button>
      ) : (
        <p
          style={{
            margin: 0,
            padding: '10px 16px',
            borderRadius: 4,
            background: 'var(--jp-warn-color3, rgba(255,165,0,0.12))',
            color: 'var(--jp-warn-color0, orange)',
            fontSize: 13,
            textAlign: 'center',
            maxWidth: 380,
          }}
        >
          File dialog unavailable — please double-click a <code style={codeStyle}>.jsonl</code> file
          in the file browser to open it here.
        </p>
      )}

      <p style={{ margin: 0, opacity: 0.4, fontSize: 12 }}>
        You can also double-click any <code style={{ ...codeStyle, background: 'transparent' }}>.jsonl</code>{' '}
        file in the file browser to open it directly.
      </p>
    </div>
  );
}
