/**
 * ExtractionPanel — collapsible bulk structure extraction panel.
 * Operates only on the currently displayed (filtered + searched) rows.
 */
import React, { useState, useMemo, useEffect } from 'react';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { Row, ExtractionOptions } from '../types';
import { isStructureValue, getStructureFormat, extractStructures } from '../utils';

interface ExtractionPanelProps {
  /** Rows currently visible in the table (after search + numeric filters). */
  displayedRows: Row[];
  /** All rows (used to detect structure columns even if all are filtered out). */
  allRows: Row[];
  app: JupyterFrontEnd;
}

export function ExtractionPanel({
  displayedRows,
  allRows,
  app,
}: ExtractionPanelProps): React.ReactElement {
  const [open, setOpen] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [message, setMessage] = useState('');

  // Options state
  const [selectedCol, setSelectedCol] = useState('');
  const [dest, setDest] = useState<'browser' | 'server'>('browser');
  const [archive, setArchive] = useState<'individual' | 'zip'>('zip');
  const [prefix, setPrefix] = useState('result_');
  const [ext, setExt] = useState('.cif');
  const [serverDir, setServerDir] = useState('');

  // Detect structure columns from the full dataset (not just displayed rows)
  const structureCols = useMemo(() => {
    const sample = allRows.length > 0 ? allRows.slice(0, 10) : displayedRows.slice(0, 10);
    if (sample.length === 0) return [] as string[];
    return Object.keys(sample[0]).filter(col =>
      sample.some(row => isStructureValue(col, row[col]))
    );
  }, [allRows, displayedRows]);

  // Auto-initialise column + extension when structure columns become known
  useEffect(() => {
    if (structureCols.length > 0 && !structureCols.includes(selectedCol)) {
      const col = structureCols[0];
      setSelectedCol(col);
      setPrefix(`${col}_`);
      // Infer extension from the first available row
      const sample = allRows.find(row => isStructureValue(col, row[col]));
      if (sample) {
        const fmt = getStructureFormat(col, sample[col] as string);
        setExt(fmt === 'mmcif' ? '.cif' : '.pdb');
      }
    }
  }, [structureCols]); // eslint-disable-line react-hooks/exhaustive-deps

  // How many rows in the displayed set have a non-empty value for the selected column
  const n = useMemo(
    () => displayedRows.filter(row => isStructureValue(selectedCol, row[selectedCol])).length,
    [displayedRows, selectedCol]
  );

  if (structureCols.length === 0) return <></>;

  const handleExtract = async (): Promise<void> => {
    if (!selectedCol || n === 0) return;
    setExtracting(true);
    setMessage('');
    try {
      const opts: ExtractionOptions = { dest, archive, prefix, ext, serverDir };
      const { success, errors } = await extractStructures(
        displayedRows,
        selectedCol,
        opts,
        app.serviceManager.contents as Parameters<typeof extractStructures>[3]
      );
      if (errors === 0) {
        setMessage(`✓ Extracted ${success} structure${success !== 1 ? 's' : ''} successfully.`);
      } else {
        setMessage(`⚠ ${success} succeeded, ${errors} failed.`);
      }
    } catch (e) {
      setMessage(`Error: ${String(e)}`);
    } finally {
      setExtracting(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    fontSize: 12,
    padding: '3px 6px',
    borderRadius: 3,
    border: '1px solid var(--jp-border-color1)',
    background: 'var(--jp-layout-color0)',
    color: 'var(--jp-ui-font-color0)',
  };

  const radioLabelStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: 4,
    cursor: 'pointer',
    fontSize: 12,
  };

  const labelStyle: React.CSSProperties = {
    color: 'var(--jp-ui-font-color2)',
    width: 88,
    fontSize: 12,
    flexShrink: 0,
  };

  return (
    <div
      style={{
        borderTop: '1px solid var(--jp-border-color1)',
        background: 'var(--jp-layout-color1)',
        flexShrink: 0,
      }}
    >
      {/* Toggle header */}
      <div
        onClick={() => setOpen(v => !v)}
        style={{
          padding: '5px 14px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontSize: 12,
          fontWeight: 600,
          color: 'var(--jp-ui-font-color1)',
          userSelect: 'none',
        }}
      >
        <span>Extract Structures</span>
        <span style={{ color: 'var(--jp-ui-font-color2)', fontWeight: 400 }}>
          ({n} from displayed rows)
        </span>
        <span style={{ marginLeft: 'auto' }}>{open ? '▴' : '▾'}</span>
      </div>

      {open && (
        <div
          style={{
            padding: '10px 14px',
            display: 'flex',
            flexDirection: 'column',
            gap: 9,
            borderTop: '1px solid var(--jp-border-color2)',
          }}
        >
          {/* Column selector (only shown when multiple structure columns exist) */}
          {structureCols.length > 1 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={labelStyle}>Column:</span>
              <select
                value={selectedCol}
                onChange={e => setSelectedCol(e.target.value)}
                style={inputStyle}
              >
                {structureCols.map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Output destination */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={labelStyle}>Output:</span>
            <label style={radioLabelStyle}>
              <input
                type="radio"
                name="dest"
                value="browser"
                checked={dest === 'browser'}
                onChange={() => setDest('browser')}
              />
              Browser download
            </label>
            <label style={radioLabelStyle}>
              <input
                type="radio"
                name="dest"
                value="server"
                checked={dest === 'server'}
                onChange={() => setDest('server')}
              />
              Save to server
            </label>
          </div>

          {/* Archive mode */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={labelStyle}>Archive:</span>
            <label style={radioLabelStyle}>
              <input
                type="radio"
                name="archive"
                value="zip"
                checked={archive === 'zip'}
                onChange={() => setArchive('zip')}
              />
              Zip archive
            </label>
            <label style={radioLabelStyle}>
              <input
                type="radio"
                name="archive"
                value="individual"
                checked={archive === 'individual'}
                onChange={() => setArchive('individual')}
              />
              Individual files
            </label>
          </div>

          {/* Filename prefix + extension */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span style={labelStyle}>Filename:</span>
            <input
              type="text"
              value={prefix}
              onChange={e => setPrefix(e.target.value)}
              style={{ ...inputStyle, width: 120 }}
              placeholder="result_"
            />
            <span style={{ fontSize: 11, color: 'var(--jp-ui-font-color2)' }}>N</span>
            <select value={ext} onChange={e => setExt(e.target.value)} style={{ ...inputStyle, width: 64 }}>
              <option value=".cif">.cif</option>
              <option value=".pdb">.pdb</option>
              <option value=".ent">.ent</option>
            </select>
            <span style={{ fontSize: 11, color: 'var(--jp-ui-font-color3)' }}>
              → {prefix || 'result_'}1{ext}, {prefix || 'result_'}2{ext}, …
            </span>
          </div>

          {/* Server directory (only shown when dest === 'server') */}
          {dest === 'server' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={labelStyle}>Server dir:</span>
              <input
                type="text"
                value={serverDir}
                onChange={e => setServerDir(e.target.value)}
                style={{ ...inputStyle, flex: 1, minWidth: 200 }}
                placeholder="Leave blank to use current working directory"
              />
            </div>
          )}

          {/* Extract button + status message */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <button
              className="jp-mod-styled jp-mod-accept"
              disabled={extracting || n === 0}
              onClick={() => void handleExtract()}
              style={{ padding: '5px 16px', fontSize: 12, cursor: extracting ? 'wait' : 'pointer' }}
            >
              {extracting ? 'Extracting…' : `Extract ${n} structure${n !== 1 ? 's' : ''}`}
            </button>
            {message && (
              <span
                style={{
                  fontSize: 12,
                  color: message.startsWith('✓')
                    ? 'var(--jp-success-color0, #16a34a)'
                    : 'var(--jp-warn-color0, orange)',
                }}
              >
                {message}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
