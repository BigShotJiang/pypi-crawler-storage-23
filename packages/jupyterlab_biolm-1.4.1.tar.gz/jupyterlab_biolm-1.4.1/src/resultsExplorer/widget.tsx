/**
 * ResultsExplorerWidget — ReactWidget that can be opened standalone (hero view)
 * or pre-populated with data from a file (table view).
 */
import React from 'react';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { ReactWidget } from '@jupyterlab/ui-components';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { FileDialog } from '@jupyterlab/filebrowser';
import { Row } from './types';
import { parseResults } from './parsing';
import { HeroView } from './components/HeroView';
import { ResultsTable } from './components/ResultsTable';

export class ResultsExplorerWidget extends ReactWidget {
  private _rows: Row[] = [];
  private _columns: string[] = [];
  private _filename: string;
  private readonly _app: JupyterFrontEnd;
  private readonly _docManager: IDocumentManager | null;

  constructor(
    app: JupyterFrontEnd,
    filename: string,
    docManager: IDocumentManager | null
  ) {
    super();
    this._app = app;
    this._filename = filename;
    this._docManager = docManager;
    this.addClass('biolm-results-explorer');
  }

  /**
   * Load data into the widget and trigger a re-render.
   * Optionally update the displayed filename (e.g. when user opens a new file).
   */
  setData(rows: Row[], columns: string[], filename?: string): void {
    this._rows = rows;
    this._columns = columns;
    if (filename !== undefined) this._filename = filename;
    this.update();
  }

  /** Open a file picker dialog and load the selected file. */
  private readonly _openFile = async (): Promise<void> => {
    if (!this._docManager) return;
    try {
      const result = await FileDialog.getOpenFiles({
        manager: this._docManager,
        // Allow any file; we accept .jsonl and .csv in practice
      });
      if (!result.value || result.value.length === 0) return;

      const path = result.value[0].path;
      const contents = await this._app.serviceManager.contents.get(path, {
        content: true,
      });
      const text = contents.content as string;
      const format = path.toLowerCase().endsWith('.csv') ? 'csv' : 'jsonl';
      const filename = path.split('/').pop() ?? path;
      const { rows, columns } = parseResults(text, format);

      this.setData(rows, columns, filename);
      this.title.label = filename;
    } catch (e) {
      console.error('[BioLM] Failed to open file:', e);
    }
  };

  render(): React.ReactElement {
    // No file loaded yet → show the hero landing page
    if (!this._filename) {
      return (
        <HeroView
          onOpen={() => void this._openFile()}
          hasDocManager={!!this._docManager}
        />
      );
    }

    // File loaded → show the results table
    return (
      <ResultsTable
        rows={this._rows}
        columns={this._columns}
        app={this._app}
        filename={this._filename}
        onOpenFile={this._docManager ? () => void this._openFile() : undefined}
      />
    );
  }
}
