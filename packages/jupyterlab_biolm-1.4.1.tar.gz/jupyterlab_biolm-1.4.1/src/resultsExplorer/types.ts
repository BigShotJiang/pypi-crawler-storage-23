/**
 * Shared TypeScript types for the BioLM Results Explorer.
 */

/** A single row of parsed results data. */
export type Row = Record<string, unknown>;

/** Comparison operator for numeric filters. */
export type FilterOp = '>' | '>=' | '<' | '<=' | '=' | '!=';

/** A single numeric filter condition. */
export interface NumericFilter {
  /** Unique React key for the filter row. */
  id: string;
  /** Column name to filter on. */
  field: string;
  /** Comparison operator. */
  op: FilterOp;
  /** Threshold value. */
  value: number;
}

/** Descriptive statistics for a numeric column. */
export interface StatsResult {
  count: number;
  min: number;
  max: number;
  mean: number;
  median: number;
  q1: number;
  q3: number;
  stdDev: number;
  whiskerLow: number;
  whiskerHigh: number;
  outliers: number[];
}

/** Where to send extracted structure files. */
export type ExtractionDest = 'browser' | 'server';

/** Whether to bundle files into a zip or download individually. */
export type ArchiveMode = 'individual' | 'zip';

/** User-specified options for bulk structure extraction. */
export interface ExtractionOptions {
  dest: ExtractionDest;
  archive: ArchiveMode;
  /** Filename prefix (e.g. "result_" → result_1.cif, result_2.cif, …). */
  prefix: string;
  /** File extension including the dot (e.g. ".cif"). */
  ext: string;
  /** Server directory path (only used when dest === 'server'). */
  serverDir: string;
}
