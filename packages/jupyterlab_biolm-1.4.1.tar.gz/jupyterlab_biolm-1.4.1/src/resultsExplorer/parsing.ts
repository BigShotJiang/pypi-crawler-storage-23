/**
 * Parsing utilities for BioLM protocol results files (.jsonl and .csv).
 */
import { Row } from './types';

function parseJSONL(text: string): Row[] {
  return text
    .trim()
    .split('\n')
    .filter(line => line.trim())
    .map((line, i) => {
      try {
        return JSON.parse(line) as Row;
      } catch {
        console.warn(`[BioLM] Skipping malformed JSONL line ${i + 1}`);
        return null;
      }
    })
    .filter((r): r is Row => r !== null);
}

function parseCSVRow(line: string): string[] {
  const fields: string[] = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        field += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      fields.push(field);
      field = '';
    } else {
      field += ch;
    }
  }
  fields.push(field);
  return fields;
}

function parseCSV(text: string): Row[] {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return [];

  const headers = parseCSVRow(lines[0]);
  return lines
    .slice(1)
    .filter(l => l.trim())
    .map(line => {
      const vals = parseCSVRow(line);
      const row: Row = {};
      headers.forEach((h, i) => {
        const v = (vals[i] ?? '').trim();
        const n = Number(v);
        row[h] = v !== '' && !isNaN(n) ? n : v;
      });
      return row;
    });
}

/**
 * Parse a results file in JSONL or CSV format.
 * Returns the rows and a union of all column names (preserving first-seen order).
 */
export function parseResults(
  text: string,
  format: 'jsonl' | 'csv'
): { rows: Row[]; columns: string[] } {
  const rows = format === 'csv' ? parseCSV(text) : parseJSONL(text);
  if (rows.length === 0) return { rows: [], columns: [] };
  const colSet = new Set<string>();
  rows.forEach(r => Object.keys(r).forEach(k => colSet.add(k)));
  return { rows, columns: Array.from(colSet) };
}
