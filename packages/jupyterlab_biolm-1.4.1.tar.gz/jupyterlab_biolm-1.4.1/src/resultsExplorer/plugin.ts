/**
 * resultsExplorerPlugin — JupyterLab plugin registration for the Results Explorer.
 */
import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ILauncher } from '@jupyterlab/launcher';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { biolmIcon } from '../biolmIcon';
import { ResultsExplorerFactory } from './factory';
import { ResultsExplorerWidget } from './widget';

export const resultsExplorerPlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-biolm:results-explorer',
  autoStart: true,
  optional: [ILauncher, IDocumentManager],
  activate: (
    app: JupyterFrontEnd,
    launcher: ILauncher | null,
    docManager: IDocumentManager | null
  ) => {
    // Register .jsonl as a known file type so the Results Explorer can be
    // set as the default viewer for it.
    app.docRegistry.addFileType({
      name: 'jsonl',
      displayName: 'JSONL Results',
      extensions: ['.jsonl'],
      mimeTypes: ['application/x-ndjson', 'text/plain'],
      contentType: 'file',
      fileFormat: 'text',
    });

    const factory = new ResultsExplorerFactory(app, docManager, {
      name: 'BioLM Results Explorer',
      fileTypes: ['jsonl', 'csv'],
      defaultFor: ['jsonl'],
    });
    app.docRegistry.addWidgetFactory(factory);

    // Launcher command — opens a standalone Results Explorer with the hero view
    app.commands.addCommand('biolm:open-results-explorer', {
      label: 'Results Explorer',
      caption: 'Open BioLM protocol results (.jsonl or .csv) as an interactive table',
      icon: biolmIcon,
      execute: () => {
        const widget = new ResultsExplorerWidget(app, '', docManager);
        widget.id = `biolm-results-explorer-${Date.now()}`;
        widget.title.label = 'Results Explorer';
        widget.title.icon = biolmIcon;
        widget.title.closable = true;
        app.shell.add(widget, 'main');
        app.shell.activateById(widget.id);
      },
    });

    if (launcher) {
      launcher.add({
        command: 'biolm:open-results-explorer',
        category: 'BioLM',
        rank: 2,
      });
    }

    console.log('[BioLM] Results Explorer plugin activated');
  },
};
