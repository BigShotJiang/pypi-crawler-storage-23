/**
 * ResultsExplorerFactory — ABCWidgetFactory for opening .jsonl and .csv files
 * via double-click in the JupyterLab file browser.
 */
import { JupyterFrontEnd } from '@jupyterlab/application';
import {
  ABCWidgetFactory,
  DocumentRegistry,
  DocumentWidget,
  IDocumentWidget,
} from '@jupyterlab/docregistry';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { parseResults } from './parsing';
import { ResultsExplorerWidget } from './widget';

export class ResultsExplorerFactory extends ABCWidgetFactory<
  IDocumentWidget<ResultsExplorerWidget>
> {
  constructor(
    private readonly _app: JupyterFrontEnd,
    private readonly _docManager: IDocumentManager | null,
    options: DocumentRegistry.IWidgetFactoryOptions
  ) {
    super(options);
  }

  protected createNewWidget(
    context: DocumentRegistry.Context
  ): IDocumentWidget<ResultsExplorerWidget> {
    const format = context.path.toLowerCase().endsWith('.csv') ? 'csv' : 'jsonl';
    const filename = context.path.split('/').pop() ?? context.path;

    const content = new ResultsExplorerWidget(this._app, filename, this._docManager);
    const widget = new DocumentWidget({ content, context });
    widget.title.label = filename;
    widget.title.caption = context.path;
    widget.title.closable = true;

    void context.ready.then(() => {
      const text = context.model.toString();
      const { rows, columns } = parseResults(text, format);
      content.setData(rows, columns);
    });

    return widget;
  }
}
