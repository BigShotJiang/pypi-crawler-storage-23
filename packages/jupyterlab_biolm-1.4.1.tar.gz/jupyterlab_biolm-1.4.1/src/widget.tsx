/**
 * Main BioLM Sidebar Widget
 */
import React from 'react';
import { ReactWidget } from '@jupyterlab/apputils';
import { INotebookTracker } from '@jupyterlab/notebook';
import { ModelsTab } from './components/ModelsTab';
import { OperationsTab } from './components/OperationsTab';
import { SettingsTab } from './components/SettingsTab';

interface BioLMWidgetProps {
  notebookTracker: INotebookTracker;
}

interface TabErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class TabErrorBoundary extends React.Component<React.PropsWithChildren<{ tabName: string }>, TabErrorBoundaryState> {
  constructor(props: React.PropsWithChildren<{ tabName: string }>) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): TabErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    console.error(`[BioLM] Error in ${this.props.tabName} tab:`, error, info);
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <div className="biolm-error" style={{ padding: '16px' }}>
          <p><strong>{this.props.tabName} tab encountered an error.</strong></p>
          <p style={{ fontSize: '12px', opacity: 0.8 }}>{this.state.error?.message}</p>
          <button
            className="jp-mod-styled jp-mod-minimal"
            onClick={() => this.setState({ hasError: false, error: null })}
          >
            Retry
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

class BioLMWidgetComponent extends React.Component<BioLMWidgetProps, { activeTab: string }> {
  constructor(props: BioLMWidgetProps) {
    super(props);
    this.state = { activeTab: 'models' };
  }

  render() {
    const { activeTab } = this.state;
    const { notebookTracker } = this.props;

    return (
      <div className="biolm-widget">
        <div className="biolm-tabs" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'models'}
            aria-controls="biolm-tab-panel-models"
            className={`biolm-tab-button ${activeTab === 'models' ? 'active' : ''}`}
            onClick={() => this.setState({ activeTab: 'models' })}
          >
            Models
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'operations'}
            aria-controls="biolm-tab-panel-operations"
            className={`biolm-tab-button ${activeTab === 'operations' ? 'active' : ''}`}
            onClick={() => this.setState({ activeTab: 'operations' })}
          >
            Operations
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'settings'}
            aria-controls="biolm-tab-panel-settings"
            className={`biolm-tab-button ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => this.setState({ activeTab: 'settings' })}
          >
            Settings
          </button>
        </div>

        <div className="biolm-tab-content">
          {activeTab === 'models' && (
            <div id="biolm-tab-panel-models" role="tabpanel">
              <TabErrorBoundary tabName="Models">
                <ModelsTab notebookTracker={notebookTracker} />
              </TabErrorBoundary>
            </div>
          )}
          {activeTab === 'operations' && (
            <div id="biolm-tab-panel-operations" role="tabpanel">
              <TabErrorBoundary tabName="Operations">
                <OperationsTab notebookTracker={notebookTracker} />
              </TabErrorBoundary>
            </div>
          )}
          {activeTab === 'settings' && (
            <div id="biolm-tab-panel-settings" role="tabpanel">
              <TabErrorBoundary tabName="Settings">
                <SettingsTab notebookTracker={notebookTracker} />
              </TabErrorBoundary>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export class BioLMWidget extends ReactWidget {
  private _notebookTracker: INotebookTracker;

  constructor(notebookTracker: INotebookTracker) {
    super();
    this._notebookTracker = notebookTracker;
    this.addClass('biolm-widget-container');
    this.id = 'biolm-widget';
    this.title.label = 'BioLM';
    this.title.caption = 'BioLM Model Browser';
    this.title.iconClass = 'jp-MaterialIcon jp-Icon jp-Icon-16';
    this.title.closable = true;
  }

  render(): JSX.Element {
    return (
      <BioLMWidgetComponent
        notebookTracker={this._notebookTracker}
      />
    );
  }
}

