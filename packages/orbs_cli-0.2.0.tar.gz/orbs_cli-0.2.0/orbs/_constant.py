PLATFORM_LIST = {
    "mobile": ['android', 'iOS'],
    "web": ['chrome', 'firefox', 'safari', 'edge'],
    "api": ['api'],
}