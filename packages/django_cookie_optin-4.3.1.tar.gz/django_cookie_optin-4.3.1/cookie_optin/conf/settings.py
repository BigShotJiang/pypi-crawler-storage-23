# Django
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

PRIVACY_URL = getattr(settings, "COOKIE_OPTIN_PRIVACY_URL", None)
API_PATH = getattr(settings, "COOKIE_OPTIN_API_PATH", "/cookie-optin/api/")
ENABLE_OVERVIEW = getattr(settings, "COOKIE_OPTIN_ENABLE_OVERVIEW", False)
CONFIG_CACHE = getattr(settings, "COOKIE_OPTIN_CONFIG_CACHE", False)
CONFIG_CACHE_TIMEOUT = getattr(settings, "COOKIE_OPTIN_CONFIG_CACHE_TIMEOUT", 3600)
# localStorage key for theme sync with CMS toolbar (light/dark).
# Must match django-cms / djangocms-admin-style key: "theme"
THEME_STORAGE_KEY = getattr(settings, "COOKIE_OPTIN_THEME_STORAGE_KEY", "theme")

if PRIVACY_URL is None:
    raise ImproperlyConfigured("COOKIE_OPTIN_PRIVACY_URL must be defined")
