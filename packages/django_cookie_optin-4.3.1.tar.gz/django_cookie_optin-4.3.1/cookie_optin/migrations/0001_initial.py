# Django
import django.db.models.deletion
from django.db import migrations, models

# Third party
import parler.models


class Migration(migrations.Migration):
    dependencies = [("sites", "0001_initial")]

    operations = [
        migrations.CreateModel(
            name="Application",
            fields=[
                (
                    "id",
                    models.AutoField(
                        verbose_name="ID",
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                ),
                ("slug", models.SlugField(max_length=100, verbose_name="Slug")),
                (
                    "is_required",
                    models.BooleanField(
                        default=False,
                        help_text="Only if the application is required for the site to function correctly.",
                        verbose_name="Is required",
                    ),
                ),
            ],
            options={
                "verbose_name": "Application",
                "verbose_name_plural": "Applications",
            },
            bases=(parler.models.TranslatableModelMixin, models.Model),
        ),
        migrations.CreateModel(
            name="ApplicationTranslation",
            fields=[
                (
                    "id",
                    models.AutoField(
                        verbose_name="ID",
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                ),
                (
                    "language_code",
                    models.CharField(
                        max_length=15, verbose_name="Language", db_index=True
                    ),
                ),
                ("name", models.CharField(max_length=100, verbose_name="Name")),
                (
                    "description",
                    models.CharField(max_length=500, verbose_name="Description"),
                ),
                (
                    "master",
                    models.ForeignKey(
                        related_name="translations",
                        editable=False,
                        to="cookie_optin.Application",
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                    ),
                ),
            ],
            options={
                "managed": True,
                "db_table": "cookie_optin_application_translation",
                "db_tablespace": "",
                "default_permissions": (),
                "verbose_name": "Application Translation",
            },
        ),
        migrations.CreateModel(
            name="Cookie",
            fields=[
                (
                    "id",
                    models.AutoField(
                        verbose_name="ID",
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                ),
                ("name", models.CharField(max_length=250, verbose_name="Name")),
                (
                    "is_regexp",
                    models.BooleanField(
                        default=False, verbose_name="Regular expression"
                    ),
                ),
                (
                    "path",
                    models.CharField(
                        max_length=250, null=True, verbose_name="Path", blank=True
                    ),
                ),
                (
                    "application",
                    models.ForeignKey(
                        verbose_name="Application",
                        to="cookie_optin.Application",
                        on_delete=django.db.models.deletion.CASCADE,
                    ),
                ),
                (
                    "site",
                    models.ForeignKey(
                        verbose_name="Site",
                        to="sites.Site",
                        on_delete=django.db.models.deletion.CASCADE,
                    ),
                ),
            ],
            options={"verbose_name": "Cookie", "verbose_name_plural": "Cookies"},
        ),
        migrations.CreateModel(
            name="Purpose",
            fields=[
                (
                    "id",
                    models.AutoField(
                        verbose_name="ID",
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                )
            ],
            options={"verbose_name": "Purpose", "verbose_name_plural": "Purposes"},
            bases=(parler.models.TranslatableModelMixin, models.Model),
        ),
        migrations.CreateModel(
            name="PurposeTranslation",
            fields=[
                (
                    "id",
                    models.AutoField(
                        verbose_name="ID",
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                ),
                (
                    "language_code",
                    models.CharField(
                        max_length=15, verbose_name="Language", db_index=True
                    ),
                ),
                ("name", models.CharField(max_length=100, verbose_name="Name")),
                (
                    "master",
                    models.ForeignKey(
                        related_name="translations",
                        editable=False,
                        to="cookie_optin.Purpose",
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                    ),
                ),
            ],
            options={
                "managed": True,
                "db_table": "cookie_optin_purpose_translation",
                "db_tablespace": "",
                "default_permissions": (),
                "verbose_name": "Purpose Translation",
            },
        ),
        migrations.AddField(
            model_name="application",
            name="purposes",
            field=models.ManyToManyField(
                to="cookie_optin.Purpose", verbose_name="Purposes"
            ),
        ),
        migrations.AlterUniqueTogether(
            name="purposetranslation",
            unique_together={("language_code", "master")},
        ),
        migrations.AlterUniqueTogether(
            name="applicationtranslation",
            unique_together={("language_code", "master")},
        ),
    ]
