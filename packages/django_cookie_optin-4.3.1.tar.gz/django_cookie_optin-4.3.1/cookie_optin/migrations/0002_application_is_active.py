# Django
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("cookie_optin", "0001_initial")]

    operations = [
        migrations.AddField(
            model_name="application",
            name="is_active",
            field=models.BooleanField(default=False, verbose_name="Is active"),
        )
    ]
