# Django
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("cookie_optin", "0002_application_is_active")]

    operations = [
        migrations.AddField(
            model_name="application",
            name="no_consent",
            field=models.BooleanField(
                default=False,
                help_text="The application will load even before the user gave explicit consent. Use only if the application does not collect user data.",
                verbose_name="Don't need consent",
            ),
        )
    ]
