# Django
from django.apps import AppConfig


class CookieOptinConfig(AppConfig):
    name = "cookie_optin"
    verbose_name = "Cookie Opt-in"
    default_auto_field = "django.db.models.AutoField"

    def ready(self):
        # Django
        from django.apps import apps

        # Local application / specific library imports
        from .receivers import register_config_cache_receivers

        # Register CMS toolbar only when django-cms is installed
        if apps.is_installed("cms"):
            # Local application / specific library imports
            from . import cms_toolbars  # noqa: F401

        # Register config cache receivers
        register_config_cache_receivers()
