# Django
from django.urls import path

# Project
from cookie_optin.views import (
    ConfigView,
    ConsentApiView,
    ConsentOverviewView,
    VisitorOverviewView,
)

app_name = "cookie_optin"
urlpatterns = [
    path("config.js", ConfigView.as_view(), name="config"),
    path("api/", ConsentApiView.as_view(), name="api"),
    path("overview/", ConsentOverviewView.as_view(), name="overview"),
    path("visitors/", VisitorOverviewView.as_view(), name="visitor_overview"),
]
