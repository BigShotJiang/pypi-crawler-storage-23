# Django
from django.core.cache import cache

VERSION_KEY = "cookie_optin_config_version"


def invalidate_config_cache():
    """Bump config cache version so all cached config.js responses are invalidated.

    The version is stored in the cache backend, not in code, so server restarts
    do not reset it (with persistent backends). With in-memory cache, the cache
    is empty after restart so we simply regenerate; no stale content is served.
    """
    try:
        cache.incr(VERSION_KEY)
    except (ValueError, TypeError):
        cache.set(VERSION_KEY, 1, timeout=None)
