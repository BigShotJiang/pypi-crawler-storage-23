# Django
from django import forms

# Third party
from parler.forms import TranslatableModelForm

# Local application / specific library imports
from .models import Application, Cookie


class CookieAdminForm(forms.ModelForm):
    class Meta:
        model = Cookie
        fields = ["application", "name", "is_regexp", "path", "site"]
        widgets = {"path": forms.TextInput(attrs={"placeholder": "/"})}


class ApplicationAdminForm(TranslatableModelForm):
    class Meta:
        model = Application
        exclude = []
        widgets = {"slug": forms.HiddenInput}
