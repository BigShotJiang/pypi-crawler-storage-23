def is_kapt_user(user):
    """
    Return True if user is a Kapt user (gets overview access even when ENABLE_OVERVIEW is False).
    """
    if not user or not user.is_authenticated:
        return False
    if user.username == "kapt":
        return True
    return False
