/**
 * Default cookie consent callbacks.
 * Override or extend per application via specific templates if needed.
 */

function callback_default(consent, service) {}

function onInit_default(opts) {}

function onAccept_default(opts) {}

function onDecline_default(opts) {}
