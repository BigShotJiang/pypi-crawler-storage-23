/**
 * Google Tag Manager cookie consent callbacks.
 * Updates gtag consent for analytics_storage on accept/reject.
 */

function callback_GoogleTagManager(consent, service) {}

function onInit_GoogleTagManager(opts) {
  // initialization code here (will be executed only once per page-load)
  window.dataLayer = window.dataLayer || [];
  window.gtag = function(){dataLayer.push(arguments)}
  gtag('consent', 'default', {'ad_storage': 'denied', 'analytics_storage': 'denied', 'ad_user_data': 'denied', 'ad_personalization': 'denied'})
  gtag('set', 'ads_data_redaction', true)
}

function onAccept_GoogleTagManager(opts) {
  // we notify the tag manager about all services that were accepted. You can define
  // a custom event in GTM to load the service if consent was given.
  for(let k of Object.keys(opts.consents)){
  if (opts.consents[k]){
  let eventName = 'klaro-'+k+'-accepted'
  dataLayer.push({'event': eventName})
  }
  }
}

function onDecline_GoogleTagManager(opts) {}
