/**
 * Google Analytics cookie consent callbacks.
 * Updates gtag consent for analytics_storage on accept/reject.
 */

function callback_GoogleAnalytics(consent, service) {}

function onInit_GoogleAnalytics(opts) {}

function onAccept_GoogleAnalytics(opts) {
  // we grant analytics storage
  gtag('consent', 'update', {
    analytics_storage: 'granted',
  });
}

function onDecline_GoogleAnalytics(opts) {
  // we deny analytics storage
  gtag('consent', 'update', {
    analytics_storage: 'denied',
  });
}
