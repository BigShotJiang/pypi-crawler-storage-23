/**
 * Youtube cookie consent callbacks.
 * Override or extend per application via specific templates if needed.
 */

function callback_Youtube(consent, service) {
  var fitVids = require('fitvids')
  fitVids('.video', {
  players: 'iframe[src*="dailymotion.com"]',
  ignore: ['.tab-pane:not(.active) .video iframe']  // prevent initialization inside hidden tabs panes with 0 height iframes (instead initialize on shown.bs.tab event)
  })
}

function onInit_Youtube(opts) {}

function onAccept_Youtube(opts) {}

function onDecline_Youtube(opts) {}
