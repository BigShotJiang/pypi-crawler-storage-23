# Django
from django.db.models.signals import m2m_changed, post_delete, post_save

# Local application / specific library imports
from .cache import invalidate_config_cache
from .conf import settings
from .models import Application, Cookie, Purpose


def _invalidate_config_cache_receiver(**kwargs):
    invalidate_config_cache()


def register_config_cache_receivers():
    """Register config cache receivers for the given models."""

    if settings.CONFIG_CACHE:
        for model in (Purpose, Application, Cookie):
            post_save.connect(_invalidate_config_cache_receiver, sender=model)
            post_delete.connect(_invalidate_config_cache_receiver, sender=model)
        m2m_changed.connect(
            _invalidate_config_cache_receiver,
            sender=Application.purposes.through,
        )
