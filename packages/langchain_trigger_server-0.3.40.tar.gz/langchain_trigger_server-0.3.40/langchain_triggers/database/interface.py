"""Database interface for trigger operations."""

from abc import ABC, abstractmethod
from typing import Any, TypedDict


class AuthContext(TypedDict):
    """Authentication context containing user and tenant information."""

    user_id: str
    tenant_id: str


class TriggerContext(TypedDict, total=False):
    """Context for trigger database operations.

    Attributes:
        auth: Authentication context with user_id and tenant_id (required when present)
    """

    auth: AuthContext


class TriggerDatabaseInterface(ABC):
    """Abstract interface for trigger database operations.

    Context Parameter (Backward Compatible):
        All methods accept an optional 'context' keyword argument.
        When provided, context may contain:
            - 'auth': dict with 'user_id' (str) and 'tenant_id' (str)
    """

    # ========== Trigger Registrations ==========

    @abstractmethod
    async def create_trigger_registration(
        self,
        user_id: str,
        tenant_id: str,
        template_id: str,
        resource: dict,
        metadata: dict = None,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Create a new trigger registration for a user."""
        pass

    @abstractmethod
    async def get_user_trigger_registrations(
        self,
        user_id: str,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Get all trigger registrations for a user within a tenant."""
        pass

    @abstractmethod
    async def get_user_trigger_registrations_with_agents(
        self,
        user_id: str,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Get all trigger registrations for a user with linked agents in a single query within a tenant."""
        pass

    @abstractmethod
    async def get_trigger_registration(
        self,
        registration_id: str,
        user_id: str,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Get a specific trigger registration."""
        pass

    @abstractmethod
    async def find_registration_by_resource(
        self,
        template_id: str,
        resource_data: dict[str, Any],
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Find trigger registration by matching resource data."""
        pass

    @abstractmethod
    async def find_user_registration_by_resource(
        self,
        user_id: str,
        tenant_id: str,
        template_id: str,
        resource_data: dict[str, Any],
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Find trigger registration by matching resource data for a specific user within a tenant."""
        pass

    @abstractmethod
    async def get_all_registrations(
        self, template_id: str, context: dict[str, Any] | None = None, **kwargs: Any
    ) -> list[dict[str, Any]]:
        """Get all registrations for a specific trigger template."""
        pass

    @abstractmethod
    async def delete_trigger_registration(
        self,
        registration_id: str,
        user_id: str,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> bool:
        """Delete a trigger registration."""
        pass

    @abstractmethod
    async def update_trigger_registration(
        self,
        registration_id: str,
        user_id: str,
        tenant_id: str,
        status: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Update a trigger registration (currently supports status field) and return the updated record."""
        pass

    # ========== Agent-Trigger Links ==========

    @abstractmethod
    async def link_agent_to_trigger(
        self,
        agent_id: str,
        registration_id: str,
        created_by: str,
        field_selection: dict[str, bool] | None = None,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> bool:
        """Link an agent to a trigger registration with optional field selection."""
        pass

    @abstractmethod
    async def unlink_agent_from_trigger(
        self,
        agent_id: str,
        registration_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> bool:
        """Unlink an agent from a trigger registration."""
        pass

    @abstractmethod
    async def update_agent_trigger(
        self,
        agent_id: str,
        registration_id: str,
        enabled: bool | None = None,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> bool:
        """Update an agent-trigger link (e.g., enable/disable).

        Args:
            agent_id: Agent identifier
            registration_id: Registration identifier
            enabled: Optional flag to enable (True) or disable (False) the link
            context: Optional context with auth information
            **kwargs: Additional arguments for future extensions
        """
        pass

    @abstractmethod
    async def get_agents_for_trigger(
        self, registration_id: str, context: dict[str, Any] | None = None, **kwargs: Any
    ) -> list[dict[str, Any]]:
        """Get all agent links for a trigger registration with field_selection."""
        pass

    @abstractmethod
    async def get_agents_with_active_cron(
        self, registration_id: str, context: dict[str, Any] | None = None, **kwargs: Any
    ) -> list[dict[str, Any]]:
        """Get only the agents with cron that needs to be run by the existing system"""
        pass

    @abstractmethod
    async def get_registrations_for_agent(
        self,
        agent_id: str,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Get all trigger registrations linked to a specific agent within a tenant."""
        pass
