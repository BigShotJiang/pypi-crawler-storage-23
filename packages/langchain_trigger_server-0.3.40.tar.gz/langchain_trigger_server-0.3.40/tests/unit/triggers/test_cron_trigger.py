from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from langchain_triggers.triggers.cron_trigger import (
    CronRegistration,
    cron_poll_handler,
    cron_registration_handler,
)


@pytest.mark.asyncio
async def test_cron_registration_handler_valid_pattern():
    """Test cron_registration_handler with a valid cron pattern."""
    # set up test
    mock_request = MagicMock()
    user_id = "test_user"
    valid_crontab = "0 9 * * MON-FRI"
    registration = CronRegistration(crontab=valid_crontab)

    # call method / assertions
    result = await cron_registration_handler(mock_request, user_id, registration)

    assert result.create_registration is True
    assert "cron_pattern" in result.metadata
    assert result.metadata["cron_pattern"] == valid_crontab
    assert "timezone" in result.metadata
    assert result.metadata["timezone"] == "UTC"
    assert "created_at" in result.metadata
    assert result.metadata["validated"] is True


@pytest.mark.asyncio
async def test_cron_registration_handler_invalid_pattern():
    """Test cron_registration_handler with an invalid cron pattern."""
    # set up test
    mock_request = MagicMock()
    user_id = "test_user"

    # call method / assertions
    invalid_crontab = "invalid cron string"
    registration = CronRegistration(crontab=invalid_crontab)

    result = await cron_registration_handler(mock_request, user_id, registration)

    assert result.create_registration is False
    assert result.status_code == 400
    assert "error" in result.response_body
    assert result.response_body["error"] == "invalid_cron_pattern"

    # call method / assertions
    too_many_parts_crontab = "* * * * * *"

    registration = CronRegistration(crontab=too_many_parts_crontab)
    result = await cron_registration_handler(mock_request, user_id, registration)

    assert result.create_registration is False
    assert result.status_code == 400
    assert "error" in result.response_body
    assert result.response_body["error"] == "invalid_cron_pattern"


@pytest.mark.asyncio
@patch("langchain_triggers.triggers.cron_trigger.get_client")
async def test_cron_poll_handler_thread_creation_failed(mock_get_client):
    """Test cron_poll_handler when thread creation fails."""
    # Mocks
    mock_db = MagicMock()
    mock_db.get_agents_with_active_cron = AsyncMock(
        return_value=[{"agent_id": "agent1"}]
    )
    mock_client = MagicMock()
    mock_client.threads.create = AsyncMock(side_effect=Exception("API Error"))
    mock_get_client.return_value = mock_client

    registration = {
        "id": "reg1",
        "user_id": "user1",
        "tenant_id": "tenant1",
        "organization_id": "org1",
    }

    with (
        patch(
            "langchain_triggers.triggers.cron_trigger.get_org_config_with_service_auth",
            new=AsyncMock(return_value={"agent_builder_enabled": True}),
        ),
        patch(
            "langchain_triggers.triggers.cron_trigger.is_assistant_triggers_paused",
            new=AsyncMock(return_value=False),
        ),
        patch(
            "langchain_triggers.triggers.cron_trigger.create_service_auth_headers",
            return_value={"x-service-key": "test_key"},
        ),
    ):
        result = await cron_poll_handler(registration, mock_db)

    # TODO no linked agents
    assert result == {
        "agents_invoked": 0,
        "success": True,
        "message": "No linked agents",
    }
    mock_client.threads.create.assert_not_called()
    mock_client.runs.create.assert_not_called()
