"""Image utilities — format conversion, temp files, base64 decode."""

from __future__ import annotations

import base64
import os
import re
import tempfile
import uuid
from collections.abc import Callable
from pathlib import Path
from datetime import datetime


def decode_data_url(data_url: str) -> tuple[bytes, str]:
    """Decode a base64 data URL into (bytes, mime_type).

    Handles: data:image/png;base64,iVBOR...
    """
    match = re.match(r"data:([^;]+);base64,(.+)", data_url, re.DOTALL)
    if not match:
        raise ValueError("Invalid data URL format")
    mime_type = match.group(1)
    raw = base64.b64decode(match.group(2))
    return raw, mime_type


def mime_to_ext(mime_type: str) -> str:
    """Convert MIME type to file extension."""
    mapping = {
        "image/png": "png",
        "image/jpeg": "jpg",
        "image/webp": "webp",
    }
    return mapping.get(mime_type, "png")


def make_output_path(
    command: str,
    ext: str = "png",
    output: str | None = None,
    output_dir: str | None = None,
) -> Path:
    """Determine output file path.

    Priority: explicit output path > output_dir > temp dir.
    """
    if output:
        p = Path(output)
        # If output is relative and output_dir is given, resolve within output_dir
        if not p.is_absolute() and output_dir:
            p = Path(output_dir) / p
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    # Generate a unique name
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique = uuid.uuid4().hex[:6]
    filename = f"{command}_{unique}_{ts}.{ext}"

    if output_dir:
        d = Path(output_dir)
    else:
        # User-specific dir avoids permission clashes on shared /tmp
        d = Path(tempfile.gettempdir()) / f"imagor-{os.getuid()}"

    d.mkdir(parents=True, exist_ok=True)
    return d / filename


def convert_image(
    input_bytes: bytes,
    target_format: str,
    quality: int = 85,
) -> bytes:
    """Convert image bytes to target format using Pillow.

    Supports png, jpg/jpeg, webp.
    """
    from io import BytesIO
    from PIL import Image

    img = Image.open(BytesIO(input_bytes))

    # Flatten alpha channel for JPEG (WebP and PNG support alpha natively)
    if target_format in ("jpg", "jpeg") and img.mode in ("RGBA", "LA", "P"):
        background = Image.new("RGB", img.size, (255, 255, 255))
        if img.mode == "P":
            img = img.convert("RGBA")
        background.paste(img, mask=img.split()[-1])
        img = background

    buf = BytesIO()
    pil_format = {"jpg": "JPEG", "jpeg": "JPEG", "webp": "WebP", "png": "PNG"}.get(
        target_format, "PNG"
    )
    save_kwargs: dict = {"format": pil_format}
    if pil_format in ("JPEG", "WebP"):
        save_kwargs["quality"] = quality
    img.save(buf, **save_kwargs)
    return buf.getvalue()


def remove_background(image_bytes: bytes) -> bytes:
    """Remove background from image using rembg, returning PNG with alpha.

    Requires the 'rembg' optional dependency:
        pip install imagor[transparent]
    """
    try:
        from rembg import remove as rembg_remove
    except ImportError:
        raise ImportError(
            "Transparent background requires the 'rembg' package. "
            "Install it with: pip install imagor[transparent]  "
            "or: uv pip install imagor[transparent]"
        ) from None

    return rembg_remove(image_bytes)


def save_image(
    data_url: str,
    command: str,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
    post_process: Callable[[bytes], bytes] | None = None,
) -> Path:
    """Decode a data URL, optionally convert format, and save to disk.

    Returns the output Path.
    """
    raw_bytes, mime = decode_data_url(data_url)
    native_ext = mime_to_ext(mime)

    # Apply post-processing (e.g., background removal)
    if post_process is not None:
        raw_bytes = post_process(raw_bytes)
        # Post-processing may change format (rembg always returns PNG)
        native_ext = "png"

    # Determine final format
    fmt = target_format or native_ext
    ext = fmt if fmt != "jpeg" else "jpg"

    # Convert if needed
    if fmt != native_ext:
        raw_bytes = convert_image(raw_bytes, fmt, quality)

    out_path = make_output_path(command, ext, output, output_dir)
    out_path.write_bytes(raw_bytes)
    return out_path
