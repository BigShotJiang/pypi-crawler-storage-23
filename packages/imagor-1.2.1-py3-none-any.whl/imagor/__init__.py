"""Imagor: Multi-model image generation via OpenRouter."""

from importlib.metadata import version

__version__ = version("imagor")
