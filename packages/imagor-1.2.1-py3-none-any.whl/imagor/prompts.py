"""Prompt templates for each command type."""

from __future__ import annotations


def create_prompt(user_prompt: str) -> str:
    return user_prompt


def edit_prompt(user_prompt: str) -> str:
    return (
        f"Modify the provided image: {user_prompt}. "
        "Preserve elements not mentioned in the instructions."
    )


def icon_prompt(user_prompt: str, *, transparent: bool = False) -> str:
    if transparent:
        bg = (
            "Solid pure white (#FFFFFF) background with absolutely no gradients, "
            "shadows, or other elements on the background. "
        )
    else:
        bg = "White or light solid background. "

    return (
        "Create a clean flat-style icon suitable for UI use. "
        f"{bg}"
        "Centered subject filling most of the image area with minimal padding. "
        "Recognizable at small sizes. Flat design, minimal detail, bold shapes. "
        f"{user_prompt}"
    )


def build_color_instruction(colors: list[str]) -> str:
    """Build a prompt instruction for using specific colors."""
    if not colors:
        return ""
    labels = ["primary", "secondary", "tertiary", "accent", "highlight"]
    parts = []
    for i, color in enumerate(colors):
        label = labels[i] if i < len(labels) else f"color {i + 1}"
        parts.append(f"[{label}] {color}")

    return (
        "\n\nColor palette: Use these specific colors as the dominant palette "
        "in the design. " + ", ".join(parts) + ". "
        "Apply these colors prominently to the main elements of the image."
    )


def diagram_prompt(user_prompt: str) -> str:
    return (
        "Create a clear, professional technical diagram. "
        "Use clean lines, consistent spacing, and readable labels. "
        f"{user_prompt}"
    )


def diagram_enhance_prompt(user_prompt: str) -> str:
    return (
        "Enhance this technical diagram visually. "
        "Improve the styling, colors, and layout while preserving "
        "all information and relationships. "
        f"{user_prompt}"
    )


def combine_prompt(user_prompt: str) -> str:
    return (
        "Combine these images into a single cohesive composition. "
        f"{user_prompt}"
    )


def story_character_prompt(name: str, appearance: str) -> str:
    return (
        f"Create a detailed character reference sheet for {name}. "
        f"Appearance: {appearance}. "
        "Show the character from front and side views. "
        "Neutral pose, solid background."
    )


def story_scene_prompt(
    scene_prompt: str,
    style: str,
    character_descriptions: list[str],
    *,
    scene_number: int = 0,
    total_scenes: int = 0,
    setting: str = "",
    previous_scene: str = "",
) -> str:
    parts = [f"Art style: {style}."]
    if scene_number and total_scenes:
        parts.append(f"This is scene {scene_number} of {total_scenes} in a continuous visual story.")
    parts.append(
        "IMPORTANT: Maintain visual continuity with previous scenes — "
        "same setting, same lighting, same background elements unless "
        "the story explicitly moves to a new location."
    )
    if setting:
        parts.append(f"Story setting: {setting}")
    if character_descriptions:
        parts.append("Characters in this scene:")
        parts.extend(f"  - {desc}" for desc in character_descriptions)
    if previous_scene:
        parts.append(f"Previous scene: {previous_scene}")
    parts.append(f"Scene: {scene_prompt}")
    return "\n".join(parts)
