"""OpenRouter API client — async httpx-based."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Any

import httpx

from imagor.config import get_api_key

BASE_URL = "https://openrouter.ai/api/v1"


class OpenRouterError(Exception):
    """Base error for OpenRouter API calls."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class OpenRouterClient:
    """Async client for OpenRouter chat completions + credits."""

    def __init__(self, api_key: str | None = None, timeout: float = 120.0):
        self._api_key = api_key or get_api_key()
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=BASE_URL,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://github.com/imagor-cli",
                    "X-Title": "Imagor CLI",
                },
                timeout=httpx.Timeout(self._timeout, connect=10.0),
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    # -----------------------------------------------------------------
    # Image generation via chat completions
    # -----------------------------------------------------------------

    async def generate_image(
        self,
        messages: list[dict[str, Any]],
        model: str,
        modalities: list[str] | None = None,
        image_config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Call chat/completions with image modalities.

        Returns the full API response dict.
        """
        client = await self._get_client()

        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }
        if modalities:
            payload["modalities"] = modalities
        if image_config:
            payload["image_config"] = image_config

        resp = await client.post("/chat/completions", json=payload)
        if resp.status_code != 200:
            _raise_api_error(resp)

        return resp.json()

    # -----------------------------------------------------------------
    # Credits
    # -----------------------------------------------------------------

    async def get_credits(self) -> dict[str, Any]:
        """Fetch remaining credits. Returns {total_credits, total_usage}."""
        client = await self._get_client()
        resp = await client.get("/credits")
        if resp.status_code != 200:
            _raise_api_error(resp)
        data = resp.json()
        # Response: {"data": {"total_credits": N, "total_usage": N}}
        return data.get("data", data)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _raise_api_error(resp: httpx.Response) -> None:
    """Raise a descriptive error from an HTTP response."""
    try:
        body = resp.json()
        msg = body.get("error", {}).get("message", resp.text)
    except Exception:
        msg = resp.text
    raise OpenRouterError(f"OpenRouter API error ({resp.status_code}): {msg}", resp.status_code)


def encode_image_to_data_url(path: str) -> str:
    """Read a file and return a base64 data URL."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Image not found: {path}")
    suffix = p.suffix.lower().lstrip(".")
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp"}.get(
        suffix, "image/png"
    )
    data = base64.b64encode(p.read_bytes()).decode()
    return f"data:{mime};base64,{data}"


# Singleton client
_default_client: OpenRouterClient | None = None


async def get_client() -> OpenRouterClient:
    """Get or create the default client."""
    global _default_client
    if _default_client is None:
        _default_client = OpenRouterClient()
    return _default_client


async def close_client() -> None:
    """Close the singleton client (call on shutdown)."""
    global _default_client
    if _default_client is not None:
        await _default_client.close()
        _default_client = None


def reset_client() -> None:
    """Reset the singleton (for testing)."""
    global _default_client
    _default_client = None
