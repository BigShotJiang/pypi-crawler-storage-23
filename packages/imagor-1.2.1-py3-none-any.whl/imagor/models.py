"""Model registry — capabilities, constraints, and smart defaults."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelSpec:
    """Describes a model's capabilities and constraints."""

    id: str
    name: str
    can_generate: bool = True
    can_edit: bool = False
    aspect_ratios: tuple[str, ...] = (
        "1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9",
    )
    image_sizes: tuple[str, ...] = ("1K", "2K")
    output_formats: tuple[str, ...] = ("png",)
    modalities: tuple[str, ...] = ("image", "text")
    cost_note: str = ""
    # For models that need fixed sizes instead of aspect ratios
    fixed_sizes: tuple[str, ...] = ()
    # Zero Data Retention — provider supports ZDR on OpenRouter
    zdr: bool = False

    def supports_aspect_ratio(self, ratio: str) -> bool:
        return ratio in self.aspect_ratios

    def supports_image_size(self, size: str) -> bool:
        return size in self.image_sizes

    def supports_format(self, fmt: str) -> bool:
        return fmt in self.output_formats

    def validate(self, aspect_ratio: str | None, image_size: str | None, fmt: str | None) -> list[str]:
        """Return list of validation error messages (empty = valid)."""
        errors = []
        if aspect_ratio and not self.supports_aspect_ratio(aspect_ratio) and aspect_ratio not in self.fixed_sizes:
            supported = list(self.aspect_ratios) + list(self.fixed_sizes)
            errors.append(
                f"Model {self.id} doesn't support '{aspect_ratio}'. "
                f"Supported: {', '.join(supported)}"
            )
        if image_size and not self.supports_image_size(image_size):
            errors.append(
                f"Model {self.id} doesn't support image size '{image_size}'. "
                f"Supported: {', '.join(self.image_sizes)}"
            )
        # Format is not validated — Pillow converts PNG to any target format
        return errors


# ---------------------------------------------------------------------------
# Model registry
# ---------------------------------------------------------------------------

MODELS: dict[str, ModelSpec] = {
    "google/gemini-2.5-flash-image": ModelSpec(
        id="google/gemini-2.5-flash-image",
        name="Gemini 2.5 Flash Image (Nano Banana)",
        can_generate=True,
        can_edit=True,
        image_sizes=("1K", "2K"),
        cost_note="~$0.06/image",
        zdr=True,
    ),
    "google/gemini-3-pro-image-preview": ModelSpec(
        id="google/gemini-3-pro-image-preview",
        name="Gemini 3 Pro Image (Nano Banana Pro)",
        can_generate=True,
        can_edit=True,
        image_sizes=("1K", "2K", "4K"),
        cost_note="~$0.15/image",
        zdr=True,
    ),
    "openai/gpt-5-image": ModelSpec(
        id="openai/gpt-5-image",
        name="GPT-5 Image",
        can_generate=True,
        can_edit=True,
        aspect_ratios=(),
        fixed_sizes=("1024x1024", "1536x1024", "1024x1536"),
        image_sizes=(),
        cost_note="~$0.21/image",
    ),
    "openai/gpt-5-image-mini": ModelSpec(
        id="openai/gpt-5-image-mini",
        name="GPT-5 Image Mini",
        can_generate=True,
        can_edit=True,
        aspect_ratios=(),
        fixed_sizes=("1024x1024", "1536x1024", "1024x1536"),
        image_sizes=(),
        cost_note="~$0.05/image",
    ),
    "black-forest-labs/flux.2-pro": ModelSpec(
        id="black-forest-labs/flux.2-pro",
        name="FLUX.2 Pro",
        can_generate=True,
        can_edit=True,
        output_formats=("png", "jpeg", "webp"),
        modalities=("image",),
        cost_note="~$0.03/MP out, $0.015/MP in",
    ),
    "black-forest-labs/flux.2-max": ModelSpec(
        id="black-forest-labs/flux.2-max",
        name="FLUX.2 Max",
        can_generate=True,
        can_edit=True,
        output_formats=("png", "jpeg", "webp"),
        modalities=("image",),
        cost_note="~$0.07/MP out, $0.03/MP in",
    ),
    "black-forest-labs/flux.2-klein-4b": ModelSpec(
        id="black-forest-labs/flux.2-klein-4b",
        name="FLUX.2 Klein 4B",
        can_generate=True,
        can_edit=False,
        output_formats=("png", "jpeg", "webp"),
        modalities=("image",),
        cost_note="~$0.035/image",
    ),
    "bytedance-seed/seedream-4.5": ModelSpec(
        id="bytedance-seed/seedream-4.5",
        name="Seedream 4.5",
        can_generate=True,
        can_edit=True,
        modalities=("image",),
        cost_note="$0.04/image",
    ),
    "sourceful/riverflow-v2-fast": ModelSpec(
        id="sourceful/riverflow-v2-fast",
        name="Riverflow V2 Fast",
        can_generate=True,
        can_edit=True,
        modalities=("image",),
        cost_note="~$0.04-0.06/image",
    ),
    "sourceful/riverflow-v2-pro": ModelSpec(
        id="sourceful/riverflow-v2-pro",
        name="Riverflow V2 Pro",
        can_generate=True,
        can_edit=True,
        modalities=("image",),
        cost_note="~$0.04/image",
    ),
    "openrouter/auto": ModelSpec(
        id="openrouter/auto",
        name="Auto Router",
        can_generate=True,
        can_edit=True,
        cost_note="varies",
    ),
}

# Aliases for short names
MODEL_ALIASES: dict[str, str] = {
    "gemini": "google/gemini-2.5-flash-image",
    "gemini-flash": "google/gemini-2.5-flash-image",
    "nano-banana": "google/gemini-2.5-flash-image",
    "gemini-pro": "google/gemini-3-pro-image-preview",
    "gpt5": "openai/gpt-5-image",
    "gpt-5": "openai/gpt-5-image",
    "gpt5-mini": "openai/gpt-5-image-mini",
    "gpt-5-mini": "openai/gpt-5-image-mini",
    "flux": "black-forest-labs/flux.2-pro",
    "flux2": "black-forest-labs/flux.2-pro",
    "flux-max": "black-forest-labs/flux.2-max",
    "flux-klein": "black-forest-labs/flux.2-klein-4b",
    "seedream": "bytedance-seed/seedream-4.5",
    "riverflow": "sourceful/riverflow-v2-fast",
    "riverflow-pro": "sourceful/riverflow-v2-pro",
    "auto": "openrouter/auto",
}

# Default model per command (all cheapest by default)
COMMAND_DEFAULTS: dict[str, str] = {
    "create": "google/gemini-2.5-flash-image",
    "edit": "google/gemini-2.5-flash-image",
    "icon": "google/gemini-2.5-flash-image",
    "diagram": "google/gemini-3-pro-image-preview",
    "combine": "google/gemini-2.5-flash-image",
    "story": "google/gemini-2.5-flash-image",
}


def resolve_model(name: str | None, command: str = "create") -> ModelSpec:
    """Resolve a model name/alias to a ModelSpec, using command default if None."""
    from imagor.config import get_default_model

    if name is None:
        name = get_default_model(command)

    # Try alias first
    model_id = MODEL_ALIASES.get(name, name)
    spec = MODELS.get(model_id)
    if spec is None:
        available = ", ".join(sorted(MODELS.keys()))
        aliases = ", ".join(f"{k}→{v.split('/')[-1]}" for k, v in sorted(MODEL_ALIASES.items()))
        raise ValueError(
            f"Unknown model '{name}'. Available: {available}. Aliases: {aliases}"
        )
    return spec
