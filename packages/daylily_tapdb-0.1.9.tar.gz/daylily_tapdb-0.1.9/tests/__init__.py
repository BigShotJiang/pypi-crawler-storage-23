"""Tests for daylily-tapdb."""
