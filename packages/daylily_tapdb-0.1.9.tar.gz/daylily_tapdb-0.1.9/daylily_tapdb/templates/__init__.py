"""Template management for TAPDB."""

from daylily_tapdb.templates.manager import TemplateManager

__all__ = ["TemplateManager"]
