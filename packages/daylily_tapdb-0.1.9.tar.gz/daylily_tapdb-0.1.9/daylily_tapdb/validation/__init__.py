"""Validation helpers for TAPDB.

This package contains small, dependency-light validators that are shared across
the core library and the CLI.
"""
