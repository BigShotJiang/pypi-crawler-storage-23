"""CrewAI tool wrapper for Discovery Engine.

Usage:
    from discovery.integrations.crewai import DiscoveryEngineTool

    tool = DiscoveryEngineTool(api_key="disco_...")
    # Add to your CrewAI agent
    agent = Agent(tools=[tool], ...)
"""

from __future__ import annotations

import json
from typing import Any

from crewai.tools import BaseTool
from pydantic import Field

from discovery import Engine


class DiscoveryEngineTool(BaseTool):
    """CrewAI tool that runs Discovery Engine on tabular data.

    Finds novel, statistically validated patterns — feature interactions,
    subgroup effects, and conditional relationships — that correlation analysis,
    LLMs, and hypothesis-driven approaches miss.
    """

    name: str = "Discovery Engine"
    description: str = (
        "Run Discovery Engine on tabular data to find novel, statistically "
        "validated patterns that you cannot find with pandas, SQL, or by prompting "
        "an LLM to analyze data. Use when you need to go beyond correlation. "
        "Input: JSON with 'file' (path), 'target_column' (column to analyze). "
        "Optional: 'visibility' (public/private), 'depth_iterations' (search depth). "
        "Returns patterns with conditions, p-values, novelty scores, citations."
    )
    api_key: str = Field(description="Discovery Engine API key (disco_...)")
    quiet: bool = Field(default=True, description="Suppress progress output")

    def _run(self, query: str) -> str:
        """Run Discovery Engine."""
        try:
            params = json.loads(query)
        except json.JSONDecodeError:
            return json.dumps({"error": "Input must be JSON with 'file' and 'target_column' keys."})

        file_path = params.get("file")
        target_column = params.get("target_column")
        if not file_path or not target_column:
            return json.dumps({"error": "Missing required keys: 'file' and 'target_column'."})

        engine = Engine(api_key=self.api_key, quiet=self.quiet)

        try:
            result = engine.discover_sync(
                file=file_path,
                target_column=target_column,
                depth_iterations=params.get("depth_iterations", 1),
                visibility=params.get("visibility", "public"),
            )
        except Exception as e:
            return json.dumps({"error": str(e), "suggestion": getattr(e, "suggestion", None)})

        return _format_result(result)


def _format_result(result: Any) -> str:
    """Format EngineResult as a JSON string."""
    patterns = []
    for p in result.patterns:
        patterns.append(
            {
                "description": p.description,
                "conditions": p.conditions,
                "p_value": p.p_value,
                "novelty_type": p.novelty_type,
                "novelty_explanation": p.novelty_explanation,
                "effect_size": p.abs_target_change,
                "direction": p.target_change_direction,
                "support_percentage": p.support_percentage,
            }
        )

    output: dict[str, Any] = {
        "status": result.status,
        "patterns": patterns,
        "report_url": result.report_url,
    }
    if result.summary:
        output["summary"] = result.summary.overview
        output["key_insights"] = result.summary.key_insights

    return json.dumps(output, indent=2)
