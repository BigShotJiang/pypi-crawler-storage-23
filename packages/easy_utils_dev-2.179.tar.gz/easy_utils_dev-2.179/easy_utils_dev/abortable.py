import multiprocessing
import asyncio
from typing import NoReturn

class BackgroundProcess(multiprocessing.Process):
    def __init__(self, group=None, task_target=None, name=None, args=(), kwargs={}):
        """
        A background process that runs an asyncio event loop.
        It uses a multiprocessing.Event to orchestrate graceful shutdown across processes.
        """
        super().__init__(group=group, target=None, name=name)
        
        self._task_target = task_target
        self._args = args
        self._kwargs = kwargs
        
        # Shared event across processes to signal termination
        self._terminate_mpevent = multiprocessing.Event()

    def run(self):
        """Run an async event loop in the background process."""
        asyncio.run(self._run_until_terminated())

    async def run_task(self):
        try:
            if self._task_target is not None:
                await self._task_target(*self._args, **self._kwargs)
        finally:
            self._task_target = None
            self._args = ()
            self._kwargs = {}

    def terminate(self):
        """
        Signal the background process to stop gracefully.
        (Note: Does not immediately kill like the rigid `.terminate()` method)
        """
        self._terminate_mpevent.set()

    class TerminateTask(Exception):
        pass

    async def _poll_multiprocessing_event(self):
        """Poll the MP Event. When it sets, notify the asyncio Event."""
        while not self._terminate_mpevent.is_set():
            await asyncio.sleep(0.1)
        self._terminate_asyncio_event.set()

    async def _run_until_terminated(self):
        """Run task in the background process until termination is requested."""
        self._terminate_asyncio_event = asyncio.Event()
        poller_task = asyncio.create_task(self._poll_multiprocessing_event())

        async def raise_on_termination() -> NoReturn:
            await self._terminate_asyncio_event.wait()
            raise self.TerminateTask()

        try:
            async with asyncio.TaskGroup() as tg:
                tg.create_task(raise_on_termination())
                tg.create_task(self.run_task())
        except* self.TerminateTask:
            pass  # Graceful shutdown request handled cleanly!
        finally:
            poller_task.cancel()

