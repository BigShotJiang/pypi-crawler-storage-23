
import __init__
from easy_utils_dev.uiserver import UISERVER 
from easy_utils_dev.utils import getRandomKey , start_thread , kill_thread , getTimestamp
import time , random
from flask import request


server = UISERVER(
    address='127.0.0.1',
    port=8080,
)

app = server.getFlask()
stream = server.getSocketio()
server.ok = True
server.started = False

@app.route('/data')
def get_data() :
    print('Sending Data ...')
    print('Socketio SID = ' , request.headers.get('sid'))
    return server.Response.ok( "Hello World" , alert=True )

@app.route('/alert/<message>')
def data(message) :
    print('Sending Data ...')
    print('Socketio SID = ' , request.headers.get('sid'))
    return server.Response.ok( "Hello World" , message=message , alert=True )

@app.route('/toast/<message>')
def toast(message) :
    print('Sending Data ...')
    return server.Response.ok( "Hello World" , message=message , toast=True )

@app.route('/async/longtask' , methods=['POST'])
def async_long_url() :
    print(' I am started long task ')
    while True :
        id = request.form.get('id')
        print(f'Coming ID : {id}')
        time.sleep(10)
        print(time.time())

def test(x,y) :
    print(x,y)
    return x , y

@app.route('/async/longtask/<id>' , methods=['POST'])
def async_long_url_pathid(id) :
    print(' I am started long task with id')
    request.abort.on_before_abort = lambda: test(1,2)
    while True :
        print(f'Coming ID : {id}')
        time.sleep()
        print(time.time())


if __name__ == '__main__' :
    print('Starting ....')
    server.startUi()