# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "stigg"
__version__ = "0.1.0-alpha.6"  # x-release-please-version
