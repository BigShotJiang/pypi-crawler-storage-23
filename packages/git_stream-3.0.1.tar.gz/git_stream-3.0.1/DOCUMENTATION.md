# git-stream Python Module

A command line tool to implement streams in Git.