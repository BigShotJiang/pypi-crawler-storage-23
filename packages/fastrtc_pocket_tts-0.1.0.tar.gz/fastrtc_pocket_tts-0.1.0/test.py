import logging
from fastrtc import Stream, ReplyOnPause
import numpy as np

from fastrtc_pocket_tts import PocketTTS, PocketTTSOptions


logging.basicConfig(level=logging.INFO)

model = PocketTTS()
options = PocketTTSOptions(voice="alba")

async def echo_handler(audio: tuple[int, np.ndarray]):
    text_response = (
        "Hello! I heard you pause. I am speaking to you directly "
        "from your local CPU using the Kyutai Pocket T T S model."
    )

    # Example 1: Async streaming
    async for chunk in model.stream_tts(text_response, options):
        yield chunk

    # Example 2: Sync streaming
    # for chunk in model.stream_tts_sync(text_response, options):
    #     yield chunk
    
    # Example 3: Full generation - blocking
    # yield model.tts(text_response, options)

if __name__ == "__main__":
    stream = Stream(
        handler=ReplyOnPause(echo_handler), 
        modality="audio", 
        mode="send-receive"
    )
    
    stream.ui.launch()