import os
import queue
import threading
import asyncio
import numpy as np
from enum import Enum
from typing import AsyncGenerator, Generator, Optional, Union, Any
from numpy.typing import NDArray
from typing_extensions import Protocol
from dataclasses import dataclass
from typing import TypeVar

from pocket_tts import TTSModel as PocketCoreModel


class TTSOptions:
    pass


T = TypeVar("T", bound=TTSOptions, contravariant=True)


class PocketVoice(str, Enum):
    """Enum of all default voices in pocket-tts"""
    ALBA = "alba"
    MARIUS = "marius"
    JAVERT = "javert"
    JEAN = "jean"
    FANTINE = "fantine"
    COSETTE = "cosette"
    EPONINE = "eponine"
    AZELMA = "azelma"


@dataclass
class PocketTTSOptions(TTSOptions):
    voice: Union[PocketVoice, str] = PocketVoice.ALBA


class TTSModel(Protocol[T]):
    def tts(
        self, text: str, options: T | None = None
    ) -> tuple[int, NDArray[np.float32] | NDArray[np.int16]]: ...

    async def stream_tts(
        self, text: str, options: T | None = None
    ) -> AsyncGenerator[tuple[int, NDArray[np.float32] | NDArray[np.int16]], None]: ...

    def stream_tts_sync(
        self, text: str, options: T | None = None
    ) -> Generator[tuple[int, NDArray[np.float32] | NDArray[np.int16]], None, None]: ...


class PocketTTS(TTSModel[PocketTTSOptions]):
    """
    Wrapper for Pocket TTS compatible with FastRTC
    """
    def __init__(self, default_voice: Union[PocketVoice, str] = PocketVoice.ALBA):
        self.model = PocketCoreModel.load_model()
        self.sample_rate = self.model.sample_rate
        
        self.default_voice = self._resolve_voice(default_voice)
        
        self._voice_states = {
            self.default_voice: self.model.get_state_for_audio_prompt(self.default_voice)
        }

    def _resolve_voice(self, voice: Union[PocketVoice, str]) -> str:
        """ 
        Validates that the voice is either a known built-in or a valid file path.
        Returns the string representation of the voice/path
        """
        if isinstance(voice, PocketVoice):
            return voice.value
            
        if voice in [v.value for v in PocketVoice]:
            return voice
            
        if os.path.isfile(voice):
            return voice
            
        valid_defaults = ", ".join([v.value for v in PocketVoice])
        raise ValueError(
            f"Invalid voice: '{voice}'. Expected a built-in voice ({valid_defaults}) "
            f"or a valid local file path for voice cloning."
        )

    def _get_voice_state(self, voice_input: Union[PocketVoice, str]):
        """Helper to lazy-load and cache voices"""
        validated_voice = self._resolve_voice(voice_input)
        
        if validated_voice not in self._voice_states:
             self._voice_states[validated_voice] = self.model.get_state_for_audio_prompt(validated_voice)
             
        return self._voice_states[validated_voice]

    def tts(
        self, text: str, options: PocketTTSOptions | None = None
    ) -> tuple[int, NDArray[np.float32] | NDArray[np.int16]]:
        
        voice_req = options.voice if isinstance(options, PocketTTSOptions) else self.default_voice
        voice_state = self._get_voice_state(voice_req)
        
        audio_tensor = self.model.generate_audio(voice_state, text)
        return self.sample_rate, audio_tensor.numpy()

    def stream_tts_sync(
        self, text: str, options: PocketTTSOptions | None = None
    ) -> Generator[tuple[int, NDArray[np.float32] | NDArray[np.int16]], None, None]:
        
        voice_req = options.voice if isinstance(options, PocketTTSOptions) else self.default_voice
        voice_state = self._get_voice_state(voice_req)
        
        for chunk_tensor in self.model.generate_audio_stream(voice_state, text):
            yield (self.sample_rate, chunk_tensor.numpy())

    async def stream_tts(  # type: ignore[override]
        self, text: str, options: PocketTTSOptions | None = None
    ) -> AsyncGenerator[tuple[int, NDArray[np.float32] | NDArray[np.int16]], None]:
        
        voice_req = options.voice if isinstance(options, PocketTTSOptions) else self.default_voice
        self._resolve_voice(voice_req) # Raises ValueError instantly if bad
        
        q: queue.Queue[Any] = queue.Queue()
        end_marker = object()
        
        def _worker():
            try:
                for chunk in self.stream_tts_sync(text, options):
                    q.put(chunk)
            except Exception as e:
                q.put(e) # throw exceptions  to the async loop
            finally:
                q.put(end_marker)
                
        thread = threading.Thread(target=_worker)
        thread.start()
        
        while True:
            try:
                item = q.get_nowait()
                if item is end_marker:
                    break
                if isinstance(item, Exception):
                    raise item
                yield item
            except queue.Empty:
                await asyncio.sleep(0.01)
                
        thread.join()