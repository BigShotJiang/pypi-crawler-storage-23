from __future__ import annotations


class BicepElement(str):  # noqa: FURB189
    """An alias to differentiate between a string and a Bicep element."""
