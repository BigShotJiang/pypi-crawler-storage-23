"""
ProjectDetector — identifies the current project by git root,
working directory, and config files.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

try:
    from git import InvalidGitRepositoryError, Repo
except ImportError:
    Repo = None  # type: ignore[assignment, misc]
    InvalidGitRepositoryError = Exception  # type: ignore[assignment, misc]

try:
    import psutil
except ImportError:
    psutil = None  # type: ignore[assignment]


def _find_actual_cwd() -> str | None:
    """
    Look up the process tree to find the actual project directory.
    Useful when the MCP server is launched globally (e.g., from ~ or /)
    but the IDE/Agent process has a meaningful CWD.
    """
    if not psutil:
        return None

    try:
        current = psutil.Process()
        # Look up to 5 levels
        for _ in range(5):
            parent = current.parent()
            if not parent:
                break

            cwd = parent.cwd()
            name = parent.name().lower()

            # Ignore generic shells/python if they are in root/home
            if cwd and cwd not in ("/", os.path.expanduser("~")):
                return cwd

            current = parent
    except Exception:
        pass
    return None


def detect_project(cwd: str | None = None) -> dict:
    """
    Detect the current project.

    Returns dict: { name, path, language, framework, git_branch, git_commit }
    """
    project_path = cwd
    if not project_path:
        current_cwd = os.getcwd()
        if current_cwd and current_cwd not in ("/", os.path.expanduser("~")):
            project_path = current_cwd
        else:
            project_path = _find_actual_cwd() or current_cwd
    info: dict = {
        "name": Path(project_path).name,
        "path": str(Path(project_path).resolve()),
        "language": "",
        "framework": "",
        "git_branch": "",
        "git_commit": "",
    }

    # ── Git detection ────────────────────────────────────────────
    if Repo is not None:
        try:
            repo = Repo(project_path, search_parent_directories=True)
            info["path"] = repo.working_dir  # git root
            info["name"] = Path(repo.working_dir).name
            if not repo.head.is_detached:
                info["git_branch"] = str(repo.active_branch)
            info["git_commit"] = repo.head.commit.hexsha[:7]
        except (InvalidGitRepositoryError, ValueError):
            pass

    # ── Language / framework heuristics ──────────────────────────
    root = Path(info["path"])

    if (root / "package.json").exists():
        info["language"] = "javascript"
        _detect_js_framework(root, info)
    elif (root / "pyproject.toml").exists() or (root / "setup.py").exists():
        info["language"] = "python"
        _detect_py_framework(root, info)
    elif (root / "Cargo.toml").exists():
        info["language"] = "rust"
    elif (root / "go.mod").exists():
        info["language"] = "go"
    elif (root / "pom.xml").exists() or (root / "build.gradle").exists():
        info["language"] = "java"

    return info


def _detect_js_framework(root: Path, info: dict) -> None:
    """Detect JavaScript/TypeScript frameworks."""
    try:
        import json

        pkg = json.loads((root / "package.json").read_text())
        deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}

        if "next" in deps:
            info["framework"] = "next.js"
        elif "react" in deps:
            info["framework"] = "react"
        elif "vue" in deps:
            info["framework"] = "vue"
        elif "express" in deps:
            info["framework"] = "express"

        # Detect TypeScript
        if "typescript" in deps or (root / "tsconfig.json").exists():
            info["language"] = "typescript"
    except (json.JSONDecodeError, FileNotFoundError):
        pass


def _detect_py_framework(root: Path, info: dict) -> None:
    """Detect Python frameworks."""
    try:
        toml_text = (root / "pyproject.toml").read_text()
        if "django" in toml_text.lower():
            info["framework"] = "django"
        elif "flask" in toml_text.lower():
            info["framework"] = "flask"
        elif "fastapi" in toml_text.lower():
            info["framework"] = "fastapi"
    except FileNotFoundError:
        pass
