"""
MCP Tools — actions that agents can invoke.

Implements 9 tools from the PRD, each delegating to ContextManager.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from amcl.context.context_manager import ContextManager


def register_tools(mcp: FastMCP, ctx_mgr: ContextManager) -> None:
    """Register all A/MCL tools on the given FastMCP server."""

    @mcp.tool()
    def context_get_current(
        include: str = "conversation,files,tasks,reasoning,agents",
    ) -> str:
        """
        Get the complete current project context.

        Returns conversation history, file changes, active tasks,
        reasoning chains, and agent session history.

        Args:
            include: Comma-separated sections to include.
                     Options: conversation, files, tasks, reasoning, agents.
                     Default: all sections.
        """
        sections = [s.strip() for s in include.split(",")]
        context = ctx_mgr.get_current_context(include=sections)
        return json.dumps(context, indent=2, default=str)

    @mcp.tool()
    def context_update(data: str) -> str:
        """
        Update context with new information.

        Accepts a JSON string with one or more of these keys:
        - message: {role, content, context_note}
        - file_change: {file, action, summary, diff}
        - task: {description, status, id}
        - decision: {question, answer, reasoning, alternatives}

        Example:
            {"message": {"role": "user", "content": "Help me build auth"}}
        """
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            return json.dumps({"error": "Invalid JSON"})
        result = ctx_mgr.update_context(payload)
        return json.dumps({"status": "ok", **result})

    @mcp.tool()
    def context_query(query: str) -> str:
        """
        Search context history for specific information.

        Searches across conversation messages, decisions, and tasks.

        Args:
            query: Search term to look for in context history.
        """
        results = ctx_mgr.query_context(query)
        return json.dumps(results, indent=2, default=str)

    @mcp.tool()
    def context_get_files_changed() -> str:
        """
        Get files modified since the last agent switch.

        Returns a list of file changes with paths, actions,
        timestamps, and summaries.
        """
        changes = ctx_mgr.get_files_changed_since_switch()
        return json.dumps(changes, indent=2, default=str)

    @mcp.tool()
    def context_get_conversation(limit: int = 50) -> str:
        """
        Get recent conversation history.

        Args:
            limit: Maximum number of messages to return (default 50).
        """
        msgs = ctx_mgr.get_conversation(limit=limit)
        return json.dumps(msgs, indent=2, default=str)

    @mcp.tool()
    def context_get_reasoning() -> str:
        """
        Get the decision history and reasoning chains.

        Returns all logged design decisions with their rationale,
        alternatives considered, and the agent that made them.
        """
        decisions = ctx_mgr.get_reasoning()
        return json.dumps(decisions, indent=2, default=str)

    @mcp.tool()
    def context_add_decision(
        question: str,
        answer: str,
        reasoning: str = "",
        alternatives: str = "[]",
    ) -> str:
        """
        Log a design decision.

        Args:
            question: The question or decision point.
            answer: The chosen answer / approach.
            reasoning: Why this choice was made.
            alternatives: JSON array of alternative options considered.
        """
        try:
            alts = json.loads(alternatives)
        except json.JSONDecodeError:
            alts = []
        did = ctx_mgr.add_decision(question, answer, reasoning, alts)
        return json.dumps({"status": "ok", "decision_id": did})

    @mcp.tool()
    def context_mark_complete(task_id: str) -> str:
        """
        Mark a task as completed.

        Args:
            task_id: The ID of the task to mark as completed.
        """
        ctx_mgr.mark_task_complete(task_id)
        return json.dumps({"status": "ok", "task_id": task_id, "new_status": "completed"})

    @mcp.tool()
    def context_add_blocker(description: str) -> str:
        """
        Record a blocking issue.

        Args:
            description: Description of what is blocked and why.
        """
        tid = ctx_mgr.add_blocker(description)
        return json.dumps({"status": "ok", "task_id": tid, "status_set": "blocked"})
