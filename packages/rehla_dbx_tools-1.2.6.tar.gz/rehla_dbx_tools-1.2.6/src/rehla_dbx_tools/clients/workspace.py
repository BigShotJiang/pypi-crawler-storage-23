"""Compatibility module for workspace client."""

from databricks_api.clients.workspace import WorkspaceClient

__all__ = ["WorkspaceClient"]
