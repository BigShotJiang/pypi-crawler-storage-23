from __future__ import annotations

from flow.record.fieldtypes import string


class username(string):
    pass


class password(string):
    pass
