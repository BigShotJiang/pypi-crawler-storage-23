from .main import ADC as ADC

__all__ = ["ADC"]
