from enum import Enum


class PatchByOrgByRepoBodyUpstreamType0AutosyncType0ResolutionStrategy(str, Enum):
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
