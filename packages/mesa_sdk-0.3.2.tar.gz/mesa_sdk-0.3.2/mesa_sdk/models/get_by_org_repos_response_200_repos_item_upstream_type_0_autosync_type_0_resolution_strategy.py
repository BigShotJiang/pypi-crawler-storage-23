from enum import Enum


class GetByOrgReposResponse200ReposItemUpstreamType0AutosyncType0ResolutionStrategy(str, Enum):
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
