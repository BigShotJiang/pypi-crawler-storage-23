import argparse
import importlib
import logging
import sys
import traceback

from lsp_devtools import __version__

logger = logging.getLogger(__name__)


BUILTIN_COMMANDS = [
    "lsp_devtools.cli.agent",
    "lsp_devtools.cli.client",
    "lsp_devtools.cli.inspector",
    "lsp_devtools.cli.record",
]


def load_command(commands: argparse._SubParsersAction, name: str):
    try:
        mod = importlib.import_module(name)
    except Exception:
        logger.warning("Unable to load command '%s'\n%s", name, traceback.format_exc())
        return

    if not hasattr(mod, "cli"):
        logger.warning("Unable to load command '%s': missing 'cli' definition", name)
        return

    try:
        mod.cli(commands)
    except Exception:
        logger.warning("Unable to load command '%s'\n%s", name, traceback.format_exc())
        return


def main():
    cli = argparse.ArgumentParser(
        prog="lsp-devtools", description="Developer tooling for language servers"
    )
    cli.add_argument("--version", action="version", version=f"%(prog)s v{__version__}")
    cli.add_argument(
        "-v",
        "--verbose",
        default=0,
        action="count",
        help="increase the verbosity of the logging output",
    )
    commands = cli.add_subparsers(title="commands")

    for mod in BUILTIN_COMMANDS:
        load_command(commands, mod)

    try:
        idx = sys.argv.index("--")
        args, extra = sys.argv[1:idx], sys.argv[idx + 1 :]
    except ValueError:
        args, extra = sys.argv[1:], []

    parsed_args = cli.parse_args(args)

    if hasattr(parsed_args, "run"):
        try:
            return parsed_args.run(parsed_args, extra)
        except Exception as exc:
            print(f"Error: {exc}")
            return -1

    cli.print_help()
    return 0
