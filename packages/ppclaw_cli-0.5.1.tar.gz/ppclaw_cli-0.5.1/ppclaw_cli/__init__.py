"""OpenClaw Sandbox CLI - One-click launch of OpenClaw on Agent Sandbox."""

from importlib.metadata import version as _get_version

from .const import CLI_NAME

__version__ = _get_version(CLI_NAME)
