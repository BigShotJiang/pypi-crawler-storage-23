"""Act phase: execute plan steps with dependency handling (AD-003, AD-042)."""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import random
import time
from datetime import datetime
from typing import TYPE_CHECKING, Any, cast

from axis_core.config import RetryPolicy, ToolPolicy
from axis_core.context import (
    ContextWindowGuard,
    ExecutionResult,
    ModelCallRecord,
    RunContext,
    normalize_transcript_messages,
    prune_messages_for_context_window,
)
from axis_core.errors import (
    AxisError,
    ErrorClass,
    ErrorRecord,
    ModelError,
    ToolError,
)
from axis_core.protocols.model import ModelResponse, ToolCall, UsageStats
from axis_core.protocols.planner import Plan, PlanStep, StepType
from axis_core.redaction import redact_sensitive_data
from axis_core.tool import (
    Capability,
    ToolCallRecord,
    ToolContext,
    build_idempotency_key,
)

if TYPE_CHECKING:
    from axis_core.engine.lifecycle import LifecycleEngine

logger = logging.getLogger("axis_core.engine")


def _resolve_retry_policy(
    ctx: RunContext,
    step: PlanStep,
    tool_retry: RetryPolicy | None = None,
) -> RetryPolicy:
    """Resolve effective retry policy for a step."""
    if step.retry_policy is not None:
        return step.retry_policy
    if tool_retry is not None:
        return tool_retry

    config_retry = getattr(getattr(ctx, "config", None), "retry", None)
    if isinstance(config_retry, RetryPolicy):
        return config_retry

    return RetryPolicy(max_attempts=1, jitter=False, initial_delay=0.0, max_delay=0.0)


def _matches_retry_filter(error: Exception, retry_policy: RetryPolicy) -> bool:
    """Return True when retry_on filter allows retry for this error."""
    if retry_policy.retry_on is None:
        return True

    filters = {entry.lower() for entry in retry_policy.retry_on}
    error_name = type(error).__name__.lower()
    return any(token in error_name for token in filters)


def _is_retryable_tool_error(error: Exception, retry_policy: RetryPolicy) -> bool:
    """Determine whether a tool failure should be retried."""
    if not _matches_retry_filter(error, retry_policy):
        return False

    if isinstance(error, AxisError):
        return error.recoverable

    if isinstance(error, (TypeError, ValueError, KeyError)):
        return False

    return True


def _is_retryable_model_error(error: ModelError, retry_policy: RetryPolicy) -> bool:
    """Determine whether a model failure should be retried."""
    if not ModelError.is_reason_recoverable(error.reason):
        return False
    return _matches_retry_filter(error.cause or error, retry_policy)


def _retry_delay_seconds(retry_policy: RetryPolicy, attempt: int) -> float:
    """Compute retry delay before the next attempt."""
    if retry_policy.backoff == "fixed":
        delay = retry_policy.initial_delay
    elif retry_policy.backoff == "linear":
        delay = retry_policy.initial_delay * attempt
    else:
        delay = retry_policy.initial_delay * (2 ** max(0, attempt - 1))

    delay = min(delay, retry_policy.max_delay)
    if retry_policy.jitter and delay > 0:
        delay *= 0.5 + random.random()
    return max(0.0, delay)


async def _sleep_for_retry(retry_policy: RetryPolicy, attempt: int) -> None:
    """Sleep based on retry policy for an attempt number."""
    delay = _retry_delay_seconds(retry_policy, attempt)
    if delay > 0:
        await asyncio.sleep(delay)


def _coerce_bool(value: Any, *, default: bool = False) -> bool:
    """Coerce booleans from bool/string config values."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return default


def _coerce_positive_int(value: Any) -> int | None:
    """Coerce a value to positive int, returning None when unset/invalid."""
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, str):
        try:
            parsed = int(value.strip())
        except ValueError:
            return None
        return parsed if parsed > 0 else None
    return None


def _resolve_transcript_strict(ctx: RunContext, step: PlanStep) -> bool:
    """Resolve strict transcript guard mode from step/config/env."""
    if "transcript_strict" in step.payload:
        return _coerce_bool(step.payload.get("transcript_strict"), default=False)

    config_value = getattr(getattr(ctx, "config", None), "transcript_strict", None)
    if config_value is not None:
        return _coerce_bool(config_value, default=False)

    env_value = os.getenv("AXIS_TRANSCRIPT_STRICT")
    return _coerce_bool(env_value, default=False)


def _resolve_max_tool_result_chars(ctx: RunContext, step: PlanStep) -> int | None:
    """Resolve optional max chars guard for persisted tool-result messages."""
    if "max_tool_result_chars" in step.payload:
        return _coerce_positive_int(step.payload.get("max_tool_result_chars"))

    config_value = getattr(getattr(ctx, "config", None), "max_tool_result_chars", None)
    configured = _coerce_positive_int(config_value)
    if configured is not None:
        return configured

    return _coerce_positive_int(os.getenv("AXIS_MAX_TOOL_RESULT_CHARS"))


def _resolve_tool_idempotency_key(
    ctx: RunContext,
    step: PlanStep,
    *,
    tool_name: str,
) -> str | None:
    """Resolve explicit or generated idempotency key for a tool step."""
    if "idempotency_key" in step.payload:
        raw_key = step.payload.get("idempotency_key")
        if raw_key is None:
            return None
        if isinstance(raw_key, str):
            key = raw_key.strip()
            return key if key else None
        return str(raw_key)

    return build_idempotency_key(
        run_id=ctx.run_id,
        cycle=ctx.cycle_count,
        step_id=step.id,
        tool_name=tool_name,
    )


def _resolve_context_window_guard_enabled(ctx: RunContext, step: PlanStep) -> bool:
    """Resolve context-window guard enablement from step/config/env."""
    if "context_window_guard_enabled" in step.payload:
        return _coerce_bool(
            step.payload.get("context_window_guard_enabled"),
            default=False,
        )

    config_value = getattr(
        getattr(ctx, "config", None),
        "context_window_guard_enabled",
        None,
    )
    if config_value is not None:
        return _coerce_bool(config_value, default=False)

    env_value = os.getenv("AXIS_CONTEXT_GUARD_ENABLED")
    return _coerce_bool(env_value, default=False)


def _resolve_context_window_tokens(ctx: RunContext, step: PlanStep) -> int | None:
    """Resolve configured model context-window token budget."""
    if "context_window_tokens" in step.payload:
        return _coerce_positive_int(step.payload.get("context_window_tokens"))

    config_value = getattr(getattr(ctx, "config", None), "context_window_tokens", None)
    configured = _coerce_positive_int(config_value)
    if configured is not None:
        return configured

    return _coerce_positive_int(os.getenv("AXIS_CONTEXT_WINDOW_TOKENS"))


def _resolve_context_warn_tokens(ctx: RunContext, step: PlanStep) -> int:
    """Resolve remaining-token warn threshold for context-window guard."""
    if "context_window_warn_tokens" in step.payload:
        return _coerce_positive_int(step.payload.get("context_window_warn_tokens")) or 32_000

    config_value = getattr(
        getattr(ctx, "config", None),
        "context_window_warn_tokens",
        None,
    )
    configured = _coerce_positive_int(config_value)
    if configured is not None:
        return configured

    env_value = _coerce_positive_int(os.getenv("AXIS_CONTEXT_GUARD_WARN_TOKENS"))
    return env_value if env_value is not None else 32_000


def _resolve_context_block_tokens(ctx: RunContext, step: PlanStep) -> int:
    """Resolve remaining-token block threshold for context-window guard."""
    if "context_window_block_tokens" in step.payload:
        return _coerce_positive_int(step.payload.get("context_window_block_tokens")) or 16_000

    config_value = getattr(
        getattr(ctx, "config", None),
        "context_window_block_tokens",
        None,
    )
    configured = _coerce_positive_int(config_value)
    if configured is not None:
        return configured

    env_value = _coerce_positive_int(os.getenv("AXIS_CONTEXT_GUARD_BLOCK_TOKENS"))
    return env_value if env_value is not None else 16_000


def _resolve_context_pruning_enabled(ctx: RunContext, step: PlanStep) -> bool:
    """Resolve context pruning enablement from step/config/env."""
    if "context_pruning_enabled" in step.payload:
        return _coerce_bool(step.payload.get("context_pruning_enabled"), default=False)

    config_value = getattr(getattr(ctx, "config", None), "context_pruning_enabled", None)
    if config_value is not None:
        return _coerce_bool(config_value, default=False)

    env_value = os.getenv("AXIS_CONTEXT_PRUNE_ENABLED")
    return _coerce_bool(env_value, default=False)


def _record_retry_attempt(ctx: RunContext, step: PlanStep) -> None:
    """Track retry attempts in run state (not persisted by design)."""
    retry_state = ctx.state._retry_state.get(step.id, {"attempts": 0})
    retry_state["attempts"] = int(retry_state.get("attempts", 0)) + 1
    ctx.state._retry_state[step.id] = retry_state


async def _confirm_destructive_tool(
    ctx: RunContext,
    *,
    tool_name: str,
    args: Any,
    capabilities: tuple[Capability, ...] | None,
) -> None:
    """Require explicit approval before destructive tool execution."""
    if Capability.DESTRUCTIVE not in (capabilities or ()):
        return

    config = getattr(ctx, "config", None)
    confirmation_handler = getattr(config, "confirmation_handler", None)

    if confirmation_handler is None:
        raise ToolError(
            message=(
                f"Tool '{tool_name}' requires confirmation handler for "
                "Capability.DESTRUCTIVE"
            ),
            tool_name=tool_name,
            recoverable=False,
        )

    if not callable(confirmation_handler):
        raise ToolError(
            message=(
                f"Confirmation handler for tool '{tool_name}' is not callable"
            ),
            tool_name=tool_name,
            recoverable=False,
        )

    confirmation_args = args if isinstance(args, dict) else {}

    try:
        decision = confirmation_handler(tool_name, confirmation_args)
        if inspect.isawaitable(decision):
            decision = await cast(Any, decision)
    except Exception as e:
        raise ToolError(
            message=f"Confirmation handler failed for tool '{tool_name}': {e}",
            tool_name=tool_name,
            cause=e,
            recoverable=False,
        ) from e

    if not isinstance(decision, bool):
        raise ToolError(
            message=(
                f"Confirmation handler for tool '{tool_name}' must return bool, "
                f"got {type(decision).__name__}"
            ),
            tool_name=tool_name,
            recoverable=False,
        )

    if not decision:
        raise ToolError(
            message=f"Tool '{tool_name}' execution rejected by confirmation handler",
            tool_name=tool_name,
            recoverable=False,
        )


def _enforce_tool_policy(ctx: RunContext, *, tool_name: str) -> None:
    """Block tool execution when configured allow/deny policy rejects the tool."""
    runtime_config = getattr(ctx, "config", None)
    tool_policy = getattr(runtime_config, "tool_policy", None)
    if tool_policy is None:
        return
    if not isinstance(tool_policy, ToolPolicy):
        raise ToolError(
            message=(
                "Invalid runtime config: tool_policy must be ToolPolicy or None"
            ),
            tool_name=tool_name,
            recoverable=False,
        )

    allowed, reason = tool_policy.evaluate(tool_name)
    if allowed:
        return

    detail = f" ({reason})" if reason else ""
    raise ToolError(
        message=f"Tool '{tool_name}' blocked by tool policy{detail}",
        tool_name=tool_name,
        recoverable=False,
    )


async def act(engine: LifecycleEngine, ctx: RunContext, plan_obj: Plan) -> ExecutionResult:
    """Act phase: execute plan steps with dependency handling.

    Per AD-003, steps execute serially. Per AD-042, independent steps
    continue on failure while dependent steps are skipped.

    Args:
        engine: The lifecycle engine instance
        ctx: Current run context
        plan_obj: Plan to execute

    Returns:
        ExecutionResult with results, errors, and skipped steps
    """
    from axis_core.engine.lifecycle import Phase

    phase_start = time.monotonic()
    await engine._emit(
        "phase_entered",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
    )

    results: dict[str, Any] = {}
    errors: dict[str, AxisError] = {}
    skipped: set[str] = set()

    for step in plan_obj.steps:
        # AD-042: Skip if any dependency failed
        if step.dependencies:
            failed_deps = [d for d in step.dependencies if d in errors or d in skipped]
            if failed_deps:
                skipped.add(step.id)
                logger.info(
                    "Skipping step %s: dependencies failed/skipped: %s",
                    step.id,
                    failed_deps,
                )
                continue

        # Execute based on step type
        try:
            if step.type == StepType.TOOL:
                result = await _execute_tool_step(engine, ctx, step)
                results[step.id] = result
            elif step.type == StepType.MODEL:
                result = await _execute_model_step(engine, ctx, step)
                results[step.id] = result
            elif step.type == StepType.TERMINAL:
                # Terminal steps produce the final output
                output = step.payload.get("output", "")
                if output:
                    ctx.state.output = output
                    ctx.state.output_raw = str(output)
                results[step.id] = output
            elif step.type == StepType.TRANSFORM:
                result = step.payload.get("transform_result", step.payload)
                results[step.id] = result
        except Exception as e:
            axis_error = _wrap_error(e, step)
            errors[step.id] = axis_error
            redacted_error = str(redact_sensitive_data(str(axis_error)))

            # Record error in state
            ctx.state.append_error(
                ErrorRecord(
                    error=axis_error,
                    timestamp=datetime.utcnow(),
                    phase=Phase.ACT.value,
                    cycle=ctx.cycle_count,
                    recovered=True,  # We continue execution
                )
            )

            await engine._emit(
                "tool_failed" if step.type == StepType.TOOL else "step_failed",
                run_id=ctx.run_id,
                phase=Phase.ACT.value,
                cycle=ctx.cycle_count,
                step_id=step.id,
                data={"error": redacted_error},
            )

            logger.warning("Step %s failed: %s", step.id, redacted_error)

    execution_result = ExecutionResult(
        results=results,
        errors=errors,
        skipped=frozenset(skipped),
        duration_ms=(time.monotonic() - phase_start) * 1000,
    )

    ctx.state.current_execution = execution_result

    await engine._emit(
        "phase_exited",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
        duration_ms=execution_result.duration_ms,
        data={
            "results_count": len(results),
            "errors_count": len(errors),
            "skipped_count": len(skipped),
        },
    )

    return execution_result


async def _execute_tool_step(
    engine: LifecycleEngine,
    ctx: RunContext,
    step: PlanStep,
) -> Any:
    """Execute a single tool step.

    Args:
        engine: The lifecycle engine instance
        ctx: Current run context
        step: Tool step to execute

    Returns:
        Tool execution result

    Raises:
        ToolError: If tool execution fails
    """
    from axis_core.engine.lifecycle import Phase

    tool_name = step.payload.get("tool", "")
    args = step.payload.get("args", {})

    if tool_name not in engine.tools:
        raise ToolError(
            message=f"Tool '{tool_name}' not found",
            tool_name=tool_name,
        )

    tool_fn = engine.tools[tool_name]
    manifest = getattr(tool_fn, "_axis_manifest", None)
    capabilities = cast(
        tuple[Capability, ...] | None,
        getattr(manifest, "capabilities", None),
    )

    _enforce_tool_policy(ctx, tool_name=tool_name)

    await _confirm_destructive_tool(
        ctx,
        tool_name=tool_name,
        args=args,
        capabilities=capabilities,
    )

    retry_policy = _resolve_retry_policy(
        ctx,
        step,
        tool_retry=getattr(manifest, "retry", None),
    )
    max_attempts = max(1, retry_policy.max_attempts)
    idempotency_key = _resolve_tool_idempotency_key(ctx, step, tool_name=tool_name)

    try:
        tool_signature = inspect.signature(tool_fn)
        supports_ctx = "ctx" in tool_signature.parameters
        supports_idempotency_key = "idempotency_key" in tool_signature.parameters
    except (TypeError, ValueError):
        supports_ctx = False
        supports_idempotency_key = False

    await engine._emit(
        "tool_called",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
        step_id=step.id,
        data={
            "tool": tool_name,
            "args": args,
            "idempotency_key": idempotency_key,
        },
    )

    start = time.monotonic()
    cache_key: str | None = None
    tool_cache_ttl = getattr(manifest, "cache_ttl", None)
    if (
        engine.cache_enabled_for_tools()
        and isinstance(tool_cache_ttl, int)
        and tool_cache_ttl > 0
    ):
        cache_key = engine.compute_cache_key(
            "tool",
            {
                "tool": tool_name,
                "args": args,
            },
        )
        cache_hit, cached_result = engine.cache_get(cache_key)
        if cache_hit:
            duration_ms = (time.monotonic() - start) * 1000
            ctx.state.append_tool_call(ToolCallRecord(
                tool_name=tool_name,
                call_id=step.id,
                args=dict(args),
                result=cached_result,
                error=None,
                cached=True,
                duration_ms=duration_ms,
                timestamp=time.time(),
            ))
            await engine._emit(
                "tool_returned",
                run_id=ctx.run_id,
                phase=Phase.ACT.value,
                cycle=ctx.cycle_count,
                step_id=step.id,
                data={"tool": tool_name, "duration_ms": duration_ms, "cached": True},
                duration_ms=duration_ms,
            )
            return cached_result

    async def _invoke_tool_once(attempt: int) -> Any:
        tool_kwargs = dict(args)
        if "ctx" in tool_kwargs:
            tool_kwargs.pop("ctx")
        if (
            supports_idempotency_key
            and "idempotency_key" not in tool_kwargs
            and idempotency_key is not None
        ):
            tool_kwargs["idempotency_key"] = idempotency_key

        if supports_ctx:
            tool_ctx = ToolContext(
                run_id=ctx.run_id,
                agent_id=ctx.agent_id,
                cycle=ctx.cycle_count,
                context=ctx.context,
                budget=ctx.budget,
                budget_state=ctx.state.budget_state,
                idempotency_key=idempotency_key,
                retry_attempt=attempt,
            )
            return await tool_fn(ctx=tool_ctx, **tool_kwargs)
        return await tool_fn(**tool_kwargs)

    timeout_seconds = step.payload.get("timeout", getattr(manifest, "timeout", None))
    last_error: Exception | None = None
    result: Any = None

    for attempt in range(1, max_attempts + 1):
        try:
            await engine.acquire_tool_slot(ctx, tool_name=tool_name, step_id=step.id)
            if isinstance(timeout_seconds, (int, float)) and timeout_seconds > 0:
                result = await asyncio.wait_for(
                    _invoke_tool_once(attempt),
                    timeout=float(timeout_seconds),
                )
            else:
                result = await _invoke_tool_once(attempt)
            last_error = None
            break
        except Exception as e:
            last_error = e
            _record_retry_attempt(ctx, step)
            if attempt >= max_attempts or not _is_retryable_tool_error(e, retry_policy):
                break
            await _sleep_for_retry(retry_policy, attempt)

    if last_error is not None:
        error_msg = str(redact_sensitive_data(
            f"Tool '{tool_name}' failed: {last_error}"
        ))
        duration_ms = (time.monotonic() - start) * 1000
        ctx.state.append_tool_call(ToolCallRecord(
            tool_name=tool_name,
            call_id=step.id,
            args=dict(args),
            result=None,
            error=error_msg,
            cached=False,
            duration_ms=duration_ms,
            timestamp=time.time(),
        ))
        raise ToolError(
            message=error_msg,
            tool_name=tool_name,
            cause=last_error,
            recoverable=_is_retryable_tool_error(last_error, retry_policy),
        ) from last_error

    duration_ms = (time.monotonic() - start) * 1000

    # Track budget
    ctx.state.budget_state.tool_calls += 1

    # Record successful tool call for observability/checkpointing
    ctx.state.append_tool_call(ToolCallRecord(
        tool_name=tool_name,
        call_id=step.id,
        args=dict(args),
        result=result,
        error=None,
        cached=False,
        duration_ms=duration_ms,
        timestamp=time.time(),
    ))

    if cache_key is not None and isinstance(tool_cache_ttl, int) and tool_cache_ttl > 0:
        engine.cache_set(cache_key, result, ttl_seconds=tool_cache_ttl)

    await engine._emit(
        "tool_returned",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
        step_id=step.id,
        data={"tool": tool_name, "duration_ms": duration_ms, "cached": False},
        duration_ms=duration_ms,
    )

    return result


async def try_models_with_fallback(
    engine: LifecycleEngine,
    ctx: RunContext,
    call_fn: Any,
    step: PlanStep | None = None,
) -> Any:
    """Try primary model then fallbacks on recoverable errors (AD-013).

    Args:
        engine: The lifecycle engine instance
        ctx: Current run context
        call_fn: Async callable(model) -> ModelResponse

    Returns:
        ModelResponse from first successful model

    Raises:
        ModelError: If all models (primary + fallbacks) fail
    """
    from axis_core.engine.lifecycle import Phase

    models_to_try = [engine.model] + engine.fallback
    errors: list[ModelError] = []
    effective_step = step or PlanStep(id="model-call", type=StepType.MODEL)
    retry_policy = _resolve_retry_policy(ctx, effective_step)
    max_attempts = max(1, retry_policy.max_attempts)

    for idx, model in enumerate(models_to_try):
        model_id = getattr(model, "model_id", "unknown")
        last_error: ModelError | None = None

        for attempt in range(1, max_attempts + 1):
            try:
                await engine.acquire_model_slot(ctx, step_id=effective_step.id)
                response = await call_fn(model)

                if idx > 0:
                    previous_error = errors[-1] if errors else None
                    previous_model_id = getattr(
                        models_to_try[idx - 1], "model_id", "unknown"
                    )
                    telemetry_data: dict[str, Any] = {
                        "from_model": previous_model_id,
                        "to_model": model_id,
                        "attempt": idx + 1,
                    }
                    if previous_error is not None:
                        telemetry_data["reason"] = previous_error.reason
                        telemetry_data["status_code"] = previous_error.status_code
                        telemetry_data["provider_code"] = previous_error.provider_code
                    await engine._emit(
                        "model_fallback",
                        run_id=ctx.run_id,
                        phase=Phase.ACT.value,
                        cycle=ctx.cycle_count,
                        data=telemetry_data,
                    )

                ctx.state._retry_state.pop(effective_step.id, None)
                return response

            except Exception as e:
                model_error = (
                    e if isinstance(e, ModelError)
                    else ModelError.from_exception(e, model_id)
                )
                errors.append(model_error)
                last_error = model_error

                if not ModelError.is_reason_recoverable(model_error.reason):
                    logger.warning(
                        "Non-recoverable reason from model %s (%s): %s",
                        model_id,
                        model_error.reason,
                        model_error.message,
                    )
                    raise model_error

                _record_retry_attempt(ctx, effective_step)
                should_retry = (
                    attempt < max_attempts
                    and _is_retryable_model_error(model_error, retry_policy)
                )
                logger.info(
                    "Recoverable error from model %s (model #%d, retry %d/%d): %s",
                    model_id,
                    idx + 1,
                    attempt,
                    max_attempts,
                    model_error.message,
                )
                if should_retry:
                    await _sleep_for_retry(retry_policy, attempt)
                    continue
                break

        if last_error is not None and not ModelError.is_reason_recoverable(last_error.reason):
            raise last_error

    error_messages = [str(e) for e in errors]
    final_error = errors[-1] if errors else None
    raise ModelError(
        message=(
            f"All models failed after {len(models_to_try)} attempts. "
            f"Errors: {'; '.join(error_messages)}"
        ),
        model_id="fallback_chain",
        reason="fallback_exhausted",
        recoverable=False,
        status_code=final_error.status_code if final_error is not None else None,
        provider_code=final_error.provider_code if final_error is not None else None,
        cause=final_error,
    )


async def stream_model_response(
    engine: LifecycleEngine,
    model: Any,
    messages: Any,
    system: str | None,
    tools: Any | None,
    token_callback: Any,
) -> ModelResponse:
    """Stream a model response and aggregate into a ModelResponse."""
    content_parts: list[str] = []
    tool_calls_by_index: dict[int, dict[str, Any]] = {}
    requires_complete = False

    async for chunk in model.stream(
        messages=messages,
        system=system,
        tools=tools,
    ):
        if chunk.content:
            content_parts.append(chunk.content)
            await token_callback(chunk.content)

        if chunk.tool_call_delta:
            delta = chunk.tool_call_delta
            if "function" in delta:
                idx = int(delta.get("index", 0))
                entry = tool_calls_by_index.setdefault(
                    idx, {"id": None, "name": None, "arguments": ""}
                )
                if "id" in delta:
                    entry["id"] = delta["id"]
                func = delta.get("function") or {}
                name = func.get("name")
                if name:
                    entry["name"] = name
                args_text = func.get("arguments")
                if args_text:
                    entry["arguments"] += args_text
            elif "partial_json" in delta:
                requires_complete = True

        if chunk.is_final:
            break

    if requires_complete:
        return cast(
            ModelResponse,
            await model.complete(messages=messages, system=system, tools=tools),
        )

    tool_calls: tuple[ToolCall, ...] | None = None
    if tool_calls_by_index:
        calls: list[ToolCall] = []
        for idx in sorted(tool_calls_by_index):
            entry = tool_calls_by_index[idx]
            name = entry.get("name")
            if not name:
                requires_complete = True
                break
            parsed_args: dict[str, Any] = {}
            args_text = entry.get("arguments", "")
            if args_text:
                try:
                    parsed_args = json.loads(args_text)
                except json.JSONDecodeError:
                    parsed_args = {"_raw": args_text}
            calls.append(
                ToolCall(
                    id=entry.get("id") or f"call_{idx}",
                    name=name,
                    arguments=parsed_args,
                )
            )

        if requires_complete:
            return cast(
                ModelResponse,
                await model.complete(messages=messages, system=system, tools=tools),
            )

        tool_calls = tuple(calls) if calls else None

    content = "".join(content_parts)
    input_tokens = await _estimate_tokens_for_messages(
        model=model,
        messages=messages,
        system=system,
    )
    output_tokens = await _estimate_tokens(model=model, text=content)
    usage = UsageStats(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=input_tokens + output_tokens,
    )
    cost = await _estimate_cost(
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
    )

    return ModelResponse(
        content=content,
        tool_calls=tool_calls,
        usage=usage,
        cost_usd=cost,
    )


async def _estimate_tokens(model: Any, text: str) -> int:
    """Estimate token count using model adapter if available."""
    estimator = getattr(model, "estimate_tokens", None)
    if callable(estimator):
        try:
            value = estimator(text)
            if asyncio.iscoroutine(value):
                value = await value
            return int(value)
        except Exception:
            pass
    return max(1, len(text) // 4) if text else 0


async def _estimate_tokens_for_messages(
    model: Any,
    messages: Any,
    system: str | None,
) -> int:
    parts: list[str] = []
    if system:
        parts.append(system)
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, list):
            content = " ".join(str(part) for part in content)
        parts.append(str(content))
    return await _estimate_tokens(model=model, text="\n".join(parts))


async def _estimate_cost(
    model: Any,
    input_tokens: int,
    output_tokens: int,
) -> float:
    estimator = getattr(model, "estimate_cost", None)
    if callable(estimator):
        try:
            value = estimator(input_tokens, output_tokens)
            if asyncio.iscoroutine(value):
                value = await value
            return float(value)
        except Exception:
            return 0.0
    return 0.0


async def _execute_model_step(
    engine: LifecycleEngine,
    ctx: RunContext,
    step: PlanStep,
) -> Any:
    """Execute a model (LLM) step.

    Args:
        engine: The lifecycle engine instance
        ctx: Current run context
        step: Model step to execute

    Returns:
        Model response content
    """
    from axis_core.engine.lifecycle import Phase

    # Build messages if not explicitly provided
    if "messages" not in step.payload:
        # Get context strategy from environment or use default
        strategy = os.getenv("AXIS_CONTEXT_STRATEGY", "smart")
        if strategy not in {"smart", "full", "minimal"}:
            logger.warning(
                "Invalid AXIS_CONTEXT_STRATEGY='%s'; falling back to 'smart'",
                strategy,
            )
            strategy = "smart"

        raw_max_cycles = os.getenv("AXIS_MAX_CYCLE_CONTEXT", "5")
        try:
            max_cycles = int(raw_max_cycles)
        except ValueError:
            logger.warning(
                "Invalid AXIS_MAX_CYCLE_CONTEXT='%s'; falling back to 5",
                raw_max_cycles,
            )
            max_cycles = 5
        if max_cycles < 0:
            logger.warning(
                "Negative AXIS_MAX_CYCLE_CONTEXT=%d; falling back to 5",
                max_cycles,
            )
            max_cycles = 5
        messages = ctx.state.build_messages(ctx, strategy=strategy, max_cycles=max_cycles)
    else:
        messages = step.payload["messages"]

    strict_transcript_guard = _resolve_transcript_strict(ctx, step)
    max_tool_result_chars = _resolve_max_tool_result_chars(ctx, step)
    if isinstance(messages, list):
        try:
            messages = normalize_transcript_messages(
                messages,
                strict=strict_transcript_guard,
                max_tool_result_chars=max_tool_result_chars,
            )
        except ValueError as exc:
            raise ModelError(
                message=str(exc),
                model_id=getattr(engine.model, "model_id", "unknown"),
                reason="invalid_request",
                recoverable=False,
                cause=exc,
            ) from exc

    system = step.payload.get("system", engine.system)

    if isinstance(messages, list) and _resolve_context_window_guard_enabled(ctx, step):
        context_window_tokens = _resolve_context_window_tokens(ctx, step)
        if context_window_tokens is not None:
            warn_tokens = _resolve_context_warn_tokens(ctx, step)
            block_tokens = _resolve_context_block_tokens(ctx, step)
            guard = ContextWindowGuard(
                warn_threshold_tokens=warn_tokens,
                block_threshold_tokens=block_tokens,
            )

            estimated_tokens = await _estimate_tokens_for_messages(
                model=engine.model,
                messages=messages,
                system=system,
            )
            prune_enabled = _resolve_context_pruning_enabled(ctx, step)
            target_tokens = max(1, context_window_tokens - max(warn_tokens, block_tokens))
            if prune_enabled and estimated_tokens > target_tokens:
                pruned_messages, pruned_count = prune_messages_for_context_window(
                    messages,
                    target_tokens=target_tokens,
                )
                if pruned_count > 0:
                    pruned_estimated_tokens = await _estimate_tokens_for_messages(
                        model=engine.model,
                        messages=pruned_messages,
                        system=system,
                    )
                    await engine._emit(
                        "context_window_pruned",
                        run_id=ctx.run_id,
                        phase=Phase.ACT.value,
                        cycle=ctx.cycle_count,
                        step_id=step.id,
                        data={
                            "target_tokens": target_tokens,
                            "dropped_messages": pruned_count,
                            "estimated_tokens_before": estimated_tokens,
                            "estimated_tokens_after": pruned_estimated_tokens,
                        },
                    )
                    messages = pruned_messages
                    estimated_tokens = pruned_estimated_tokens

            assessment = guard.evaluate(
                estimated_tokens=estimated_tokens,
                context_window_tokens=context_window_tokens,
            )
            if assessment.should_warn:
                await engine._emit(
                    "context_window_warning",
                    run_id=ctx.run_id,
                    phase=Phase.ACT.value,
                    cycle=ctx.cycle_count,
                    step_id=step.id,
                    data={
                        "estimated_tokens": assessment.estimated_tokens,
                        "context_window_tokens": assessment.context_window_tokens,
                        "remaining_tokens": assessment.remaining_tokens,
                        "warn_threshold_tokens": warn_tokens,
                    },
                )

            if assessment.should_block:
                raise ModelError(
                    message=(
                        "Context window guard blocked model call: "
                        f"estimated_tokens={assessment.estimated_tokens}, "
                        f"remaining_tokens={assessment.remaining_tokens}, "
                        f"block_threshold={block_tokens}, "
                        f"context_window_tokens={assessment.context_window_tokens}"
                    ),
                    model_id=getattr(engine.model, "model_id", "unknown"),
                    reason="context_window_exceeded",
                    recoverable=False,
                )

    # Get tool manifests (protocol objects) - adapter will convert to its format
    tool_manifests = engine._get_tool_manifests()
    tools = tool_manifests if tool_manifests else None

    cache_key: str | None = None
    if engine.cache_enabled_for_models():
        cache_key = engine.compute_cache_key(
            "model",
            {
                "model": getattr(engine.model, "model_id", "unknown"),
                "messages": messages,
                "system": system,
                "tools": [str(m) for m in tool_manifests],
                "stream": engine._token_callback is not None,
            },
        )
        cache_hit, cached_response = engine.cache_get(cache_key)
        if cache_hit:
            response = cast(ModelResponse, cached_response)
            ctx.state.output_raw = response.content
            ctx.state.last_model_response = response
            await engine._emit(
                "model_returned",
                run_id=ctx.run_id,
                phase=Phase.ACT.value,
                cycle=ctx.cycle_count,
                step_id=step.id,
                data={
                    "input_tokens": response.usage.input_tokens,
                    "output_tokens": response.usage.output_tokens,
                    "cost_usd": response.cost_usd,
                    "cached": True,
                },
                duration_ms=0.0,
            )
            return response.content

    await engine._emit(
        "model_called",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
        step_id=step.id,
    )

    start = time.monotonic()
    timeout_seconds = step.payload.get("timeout")

    async def _with_timeout(operation: Any) -> Any:
        if isinstance(timeout_seconds, (int, float)) and timeout_seconds > 0:
            return await asyncio.wait_for(operation, timeout=float(timeout_seconds))
        return await operation

    # Use fallback chain if configured (Task 15.0)
    if engine._token_callback is not None:
        token_cb = engine._token_callback

        async def _stream_call(m: Any) -> Any:
            return await _with_timeout(
                stream_model_response(
                    engine=engine,
                    model=m,
                    messages=messages,
                    system=system,
                    tools=tools,
                    token_callback=token_cb,
                )
            )

        response = await try_models_with_fallback(engine, ctx, _stream_call, step=step)
    else:
        async def _complete_call(m: Any) -> Any:
            return await _with_timeout(
                m.complete(
                    messages=messages,
                    system=system,
                    tools=tools,
                )
            )

        response = await try_models_with_fallback(engine, ctx, _complete_call, step=step)
    duration_ms = (time.monotonic() - start) * 1000

    # Track budget
    ctx.state.budget_state.record_model_usage(usage=response.usage, cost_usd=response.cost_usd)

    # Record detailed model call for observability/checkpointing
    ctx.state.append_model_call(ModelCallRecord(
        model_id=getattr(engine.model, "model_id", "unknown"),
        call_id=step.id,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        cost_usd=response.cost_usd,
        duration_ms=duration_ms,
        timestamp=time.time(),
    ))

    await engine._emit(
        "model_returned",
        run_id=ctx.run_id,
        phase=Phase.ACT.value,
        cycle=ctx.cycle_count,
        step_id=step.id,
        data={
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens,
            "cost_usd": response.cost_usd,
        },
        duration_ms=duration_ms,
    )

    # Store raw response as potential output
    ctx.state.output_raw = response.content

    # Store full response for next Observe phase
    ctx.state.last_model_response = response

    if cache_key is not None:
        engine.cache_set(
            cache_key,
            response,
            ttl_seconds=engine.default_cache_ttl_seconds(),
        )

    return response.content


def _wrap_error(e: Exception, step: PlanStep) -> AxisError:
    """Wrap an exception into an appropriate AxisError.

    Args:
        e: Original exception
        step: Step that failed

    Returns:
        Wrapped AxisError
    """
    if isinstance(e, AxisError):
        return e
    if step.type == StepType.TOOL:
        return ToolError(
            message=str(redact_sensitive_data(f"Tool step '{step.id}' failed: {e}")),
            tool_name=step.payload.get("tool"),
            cause=e,
        )
    return AxisError(
        message=str(redact_sensitive_data(f"Step '{step.id}' failed: {e}")),
        error_class=ErrorClass.RUNTIME,
        cause=e,
    )
