"""Data models for spendctl."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Transaction:
    id: int | None
    date: str  # YYYY-MM-DD
    description: str
    amount_usd: float
    type: str
    from_account: str
    to_account: str
    category: str
    notes: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_row(cls, row) -> Transaction:
        return cls(
            id=row["id"],
            date=row["date"],
            description=row["description"],
            amount_usd=row["amount_usd"],
            type=row["type"],
            from_account=row["from_account"],
            to_account=row["to_account"],
            category=row["category"],
            notes=row["notes"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "date": self.date,
            "description": self.description,
            "amount_usd": self.amount_usd,
            "type": self.type,
            "from_account": self.from_account,
            "to_account": self.to_account,
            "category": self.category,
            "notes": self.notes,
        }


@dataclass
class CheckIn:
    id: int | None
    date: str
    check_in_number: str | None = None
    notes: str | None = None
    created_at: str | None = None
    balances: dict[str, float | None] = field(default_factory=dict)


@dataclass
class Subscription:
    id: int | None
    name: str
    amount: float
    account: str
    frequency: str = "Monthly"
    status: str = "Active"
    category: str = "Subscription"
    notes: str | None = None
    canceled_date: str | None = None

    @classmethod
    def from_row(cls, row) -> Subscription:
        return cls(
            id=row["id"],
            name=row["name"],
            amount=row["amount"],
            account=row["account"],
            frequency=row["frequency"],
            status=row["status"],
            category=row["category"],
            notes=row["notes"],
            canceled_date=row["canceled_date"],
        )
