"""Database connection management, schema initialization, and backup."""

from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from importlib import resources
from pathlib import Path

from spendctl import config


def get_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """Get a database connection with recommended pragmas."""
    path = str(db_path or config.DB_PATH)
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Create all tables, views, and indexes from schema.sql, then seed lookup data."""
    schema_sql = resources.files("spendctl").joinpath("schema.sql").read_text()
    conn.executescript(schema_sql)
    _seed_lookup_tables(conn)


def _seed_lookup_tables(conn: sqlite3.Connection) -> None:
    """Populate accounts, categories, transaction_types, and budget_income if empty."""
    # Accounts
    existing = {row["name"] for row in conn.execute("SELECT name FROM accounts").fetchall()}
    accounts = config.get_accounts()
    for name, info in accounts.items():
        if name not in existing:
            conn.execute(
                "INSERT INTO accounts (name, type, institution, apr, notes) VALUES (?, ?, ?, ?, ?)",
                (name, info["type"], info["institution"], info["apr"], info["description"]),
            )

    # Categories
    existing = {row["name"] for row in conn.execute("SELECT name FROM categories").fetchall()}
    categories = config.get_categories()
    for name, info in categories.items():
        if name not in existing:
            conn.execute(
                "INSERT INTO categories (name, group_name, budget_amount) VALUES (?, ?, ?)",
                (name, info["group"], info["budget"]),
            )

    # Transaction types
    existing = {row["name"] for row in conn.execute("SELECT name FROM transaction_types").fetchall()}
    for name in config.TRANSACTION_TYPES:
        if name not in existing:
            conn.execute("INSERT INTO transaction_types (name) VALUES (?)", (name,))

    # Budget income
    count = conn.execute("SELECT COUNT(*) FROM budget_income").fetchone()[0]
    if count == 0:
        income_sources = config.get_income_sources()
        for category, amount in income_sources.items():
            conn.execute("INSERT INTO budget_income (category, amount) VALUES (?, ?)", (category, amount))

    conn.commit()


def _add_starting_balance_column(conn: sqlite3.Connection) -> None:
    """Add starting_balance column to accounts if it doesn't exist yet (ALTER TABLE migration)."""
    cols = {row[1] for row in conn.execute("PRAGMA table_info(accounts)").fetchall()}
    if "starting_balance" not in cols:
        conn.execute("ALTER TABLE accounts ADD COLUMN starting_balance REAL DEFAULT 0")
        conn.commit()


def ensure_db() -> sqlite3.Connection:
    """Ensure the database exists and is initialized. Returns a connection."""
    if not config.config_exists():
        raise FileNotFoundError(
            f"Config not found at {config.CONFIG_PATH}. Run `spendctl init` to set up."
        )
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_connection()
    init_db(conn)
    _add_starting_balance_column(conn)
    return conn


def backup(db_path: Path | None = None) -> Path:
    """Create a timestamped backup of the database. Returns the backup path."""
    source = db_path or config.DB_PATH
    if not source.exists():
        raise FileNotFoundError(f"Database not found: {source}")

    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d")
    dest = config.BACKUP_DIR / f"spendctl-BACKUP-{stamp}.db"

    # If same-day backup exists, add time
    if dest.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dest = config.BACKUP_DIR / f"spendctl-BACKUP-{stamp}.db"

    shutil.copy2(str(source), str(dest))

    # Sanity check
    if dest.stat().st_size < source.stat().st_size * 0.5:
        raise RuntimeError(f"Backup suspiciously small: {dest.stat().st_size} vs {source.stat().st_size}")

    return dest
