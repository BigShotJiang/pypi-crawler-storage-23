"""Shared date utilities for query modules."""

from __future__ import annotations

from datetime import date


def default_month(month: str | None) -> str:
    """Return the given month or today's YYYY-MM."""
    return month if month is not None else date.today().strftime("%Y-%m")


def month_range(month: str) -> tuple[str, str]:
    """Return (first_day, first_day_of_next_month) for a YYYY-MM string.

    The range is half-open: [start, end) — use ``date >= start AND date < end``.
    """
    start = f"{month}-01"
    year, mon = int(month[:4]), int(month[5:7])
    if mon == 12:
        end = f"{year + 1}-01-01"
    else:
        end = f"{year}-{mon + 1:02d}-01"
    return start, end
