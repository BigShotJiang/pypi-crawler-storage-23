"""Query modules for spendctl."""

from spendctl.queries.budget import (
    budget_vs_actual,
    monthly_cushion,
    remaining_budget,
    total_income,
)
from spendctl.queries.check_ins import (
    add_check_in,
    add_reconciliation_adjustment,
    get_check_in_history,
    get_latest_check_in,
    reconcile_balances,
)
from spendctl.queries.dashboard import (
    account_balance,
    all_balances,
    debt_progress,
    net_worth,
)
from spendctl.queries.reports import (
    cash_flow,
    monthly_summary,
    spending_by_account,
    spending_by_category,
    yearly_summary,
)
from spendctl.queries.subscriptions import (
    active_monthly_total,
    add_subscription,
    cancel_subscription,
    list_subscriptions,
    update_subscription,
)
from spendctl.queries.transactions import (
    add_transaction,
    delete_transaction,
    find_duplicates,
    list_transactions,
    search_transactions,
    update_transaction,
)

__all__ = [
    # transactions
    "add_transaction",
    "list_transactions",
    "search_transactions",
    "update_transaction",
    "delete_transaction",
    "find_duplicates",
    # check_ins
    "add_check_in",
    "get_latest_check_in",
    "get_check_in_history",
    "reconcile_balances",
    "add_reconciliation_adjustment",
    # dashboard
    "account_balance",
    "all_balances",
    "net_worth",
    "debt_progress",
    # budget
    "budget_vs_actual",
    "remaining_budget",
    "total_income",
    "monthly_cushion",
    # reports
    "monthly_summary",
    "cash_flow",
    "spending_by_category",
    "spending_by_account",
    "yearly_summary",
    # subscriptions
    "list_subscriptions",
    "add_subscription",
    "update_subscription",
    "cancel_subscription",
    "active_monthly_total",
]
