"""Configuration loader for spendctl.

Reads user config from ~/.config/spendctl/config.json.
Run `spendctl init` to create the config file.
"""

from __future__ import annotations

import json
from pathlib import Path

# ── Paths (these are safe at module level — no config file needed) ──
CONFIG_DIR = Path.home() / ".config" / "spendctl"
CONFIG_PATH = CONFIG_DIR / "config.json"
DATA_DIR = CONFIG_DIR / "data"
DB_PATH = DATA_DIR / "spendctl.db"
BACKUP_DIR = DATA_DIR / "backups"

# ── Fixed constants (not user-configurable) ──
TRANSACTION_TYPES = ["Expense", "Income", "Transfer", "Debt Payment", "Interest", "Reconciliation"]

# Account types
ACCOUNT_TYPES = ("checking", "savings", "credit_card", "investment", "loan", "student_loan", "external")

# Category groups
CATEGORY_GROUPS = ("living_expense", "debt", "savings", "income", "reconciliation")

# ── Config cache (lazy loaded) ──
_config_cache: dict | None = None


def config_exists() -> bool:
    """Check if config file exists."""
    return CONFIG_PATH.is_file()


def load_config() -> dict:
    """Load and cache config from JSON file.

    Raises FileNotFoundError with helpful message if config doesn't exist.
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache
    if not config_exists():
        raise FileNotFoundError(f"Config not found at {CONFIG_PATH}. Run `spendctl init` to set up.")
    with open(CONFIG_PATH) as f:
        _config_cache = json.load(f)
    return _config_cache


def reload_config() -> dict:
    """Force reload config from disk (used after config edit)."""
    global _config_cache
    _config_cache = None
    return load_config()


def save_config(config: dict) -> None:
    """Write config dict to JSON file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")


# ── Accessor functions (all lazy, all call load_config()) ──


def get_accounts() -> dict:
    """Get accounts dict keyed by name. Each value has type, institution, apr, description."""
    cfg = load_config()
    return {
        a["name"]: {
            "type": a["type"],
            "institution": a.get("institution"),
            "apr": a.get("apr"),
            "description": a.get("description", ""),
        }
        for a in cfg.get("accounts", [])
    }


def get_categories() -> dict:
    """Get categories dict keyed by name. Each value has group, budget."""
    cfg = load_config()
    return {
        c["name"]: {
            "group": c["group"],
            "budget": c.get("budget", 0),
        }
        for c in cfg.get("categories", [])
    }


def get_income_sources() -> dict:
    """Get income sources dict keyed by name."""
    cfg = load_config()
    return {s["name"]: s["amount"] for s in cfg.get("income_sources", [])}


def get_targets() -> dict:
    """Get financial targets."""
    cfg = load_config()
    return cfg.get("targets", {})


def get_min_payments() -> dict:
    """Get minimum payments dict keyed by account name."""
    cfg = load_config()
    return cfg.get("min_payments", {})


def get_loans() -> list:
    """Get loan detail groups."""
    cfg = load_config()
    return cfg.get("loans", [])


def get_debt_accounts() -> set:
    """Derive debt accounts from account types (credit_card + loan)."""
    accounts = get_accounts()
    return {name for name, info in accounts.items() if info["type"] in ("credit_card", "loan")}


def get_student_loan_accounts() -> set:
    """Derive student loan accounts from account type."""
    accounts = get_accounts()
    return {name for name, info in accounts.items() if info["type"] == "student_loan"}


def get_non_balance_accounts() -> set:
    """Derive non-balance accounts (external)."""
    accounts = get_accounts()
    return {name for name, info in accounts.items() if info["type"] == "external"}


def get_default_from_account() -> str:
    """Get the first checking account as default 'from' account."""
    accounts = get_accounts()
    for name, info in accounts.items():
        if info["type"] == "checking":
            return name
    # Fallback to first non-external account
    for name, info in accounts.items():
        if info["type"] != "external":
            return name
    return "External"


def get_default_to_account() -> str:
    """Get the first external account as default 'to' account."""
    accounts = get_accounts()
    for name, info in accounts.items():
        if info["type"] == "external":
            return name
    return "External"


def get_ai_config() -> dict:
    """Get AI configuration (provider, model, endpoint)."""
    cfg = load_config()
    return cfg.get("ai", {})


def get_integrations() -> list:
    """Get list of configured AI assistant integrations."""
    cfg = load_config()
    return cfg.get("integrations", [])
