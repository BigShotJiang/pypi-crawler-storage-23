-- spendctl database schema

-- Lookup Tables
CREATE TABLE IF NOT EXISTS accounts (
    name              TEXT PRIMARY KEY,
    type              TEXT NOT NULL CHECK(type IN ('checking','savings','credit_card','investment','external','loan','student_loan')),
    institution       TEXT,
    apr               REAL,
    notes             TEXT,
    starting_balance  REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS categories (
    name          TEXT PRIMARY KEY,
    group_name    TEXT NOT NULL CHECK(group_name IN ('living_expense','debt','savings','income','other','reconciliation')),
    budget_amount REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transaction_types (
    name TEXT PRIMARY KEY
);

-- Core Tables
CREATE TABLE IF NOT EXISTS transactions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    date         TEXT NOT NULL,
    description  TEXT NOT NULL,
    amount_usd   REAL NOT NULL,
    type         TEXT NOT NULL REFERENCES transaction_types(name),
    from_account TEXT NOT NULL REFERENCES accounts(name),
    to_account   TEXT NOT NULL REFERENCES accounts(name),
    category     TEXT NOT NULL REFERENCES categories(name),
    notes        TEXT,
    created_at   TEXT DEFAULT (datetime('now')),
    updated_at   TEXT DEFAULT (datetime('now'))
);

-- NOTE: No eur_amount column. Removed for generalization.

-- Normalized check-ins (replaces column-per-account design)
CREATE TABLE IF NOT EXISTS check_ins (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    date             TEXT NOT NULL,
    check_in_number  TEXT,
    notes            TEXT,
    created_at       TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS check_in_balances (
    check_in_id   INTEGER NOT NULL,
    account_name  TEXT NOT NULL,
    balance       REAL,
    FOREIGN KEY (check_in_id) REFERENCES check_ins(id) ON DELETE CASCADE,
    FOREIGN KEY (account_name) REFERENCES accounts(name),
    PRIMARY KEY (check_in_id, account_name)
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    amount        REAL NOT NULL,
    account       TEXT NOT NULL REFERENCES accounts(name),
    frequency     TEXT NOT NULL DEFAULT 'Monthly',
    status        TEXT NOT NULL CHECK(status IN ('Active','Canceled','Paused')),
    category      TEXT NOT NULL REFERENCES categories(name),
    notes         TEXT,
    canceled_date TEXT,
    billing_day   INTEGER
);

CREATE TABLE IF NOT EXISTS budget_income (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    amount   REAL NOT NULL,
    notes    TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Views
CREATE VIEW IF NOT EXISTS v_monthly_expenses AS
SELECT
    strftime('%Y-%m', date) AS month,
    category,
    SUM(amount_usd) AS actual,
    COUNT(*) AS tx_count
FROM transactions
WHERE type = 'Expense'
GROUP BY strftime('%Y-%m', date), category;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_tx_category ON transactions(category);
CREATE INDEX IF NOT EXISTS idx_tx_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_tx_from ON transactions(from_account);
CREATE INDEX IF NOT EXISTS idx_tx_to ON transactions(to_account);
CREATE INDEX IF NOT EXISTS idx_tx_date_cat ON transactions(date, category);
CREATE INDEX IF NOT EXISTS idx_checkins_date ON check_ins(date);
CREATE INDEX IF NOT EXISTS idx_cib_checkin ON check_in_balances(check_in_id);
CREATE INDEX IF NOT EXISTS idx_cib_account ON check_in_balances(account_name);
