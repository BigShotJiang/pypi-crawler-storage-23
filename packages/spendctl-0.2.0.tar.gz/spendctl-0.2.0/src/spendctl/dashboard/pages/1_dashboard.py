"""Main financial health dashboard page."""

from __future__ import annotations

from datetime import date

import plotly.graph_objects as go
import streamlit as st

from spendctl import config
from spendctl.dashboard.helpers import (
    COLORS,
    auto_assign_colors,
    fmt_month,
    fmt_pct,
    fmt_usd,
    get_conn,
    hex_to_rgba,
    month_selector,
)
from spendctl.queries.budget import budget_vs_actual, monthly_cushion
from spendctl.queries.check_ins import get_check_in_history
from spendctl.queries.dashboard import all_balances, debt_progress, net_worth

DEBT_TYPES = {"credit_card", "loan", "student_loan"}

st.set_page_config(page_title="Dashboard — spendctl", layout="wide", page_icon="💰")
st.title("Financial Overview")

conn = get_conn()

# ---------------------------------------------------------------------------
# Target Countdown (e.g. retirement, separation date)
# ---------------------------------------------------------------------------
targets = config.get_targets()
target_date_str = targets.get("target_date")
target_label = targets.get("target_label", "Target")

today = date.today()

if target_date_str:
    try:
        target_date = date.fromisoformat(target_date_str)
        delta = target_date - today
        if delta.days > 0:
            total_days = delta.days
            months_remaining = total_days // 30
            days_remaining = total_days % 30
            st.markdown(
                f"""<div style="background: linear-gradient(90deg, #1a1a2e, #16213e); padding: 14px 20px;
                border-radius: 8px; margin-bottom: 16px; border-left: 4px solid {COLORS["blue"]};">
                <span style="font-size: 1.1rem; color: #aaa;">{target_label}:</span>
                <strong style="font-size: 1.3rem; color: #fff; margin-left: 8px;">{months_remaining} months, {days_remaining} days</strong>
                <span style="font-size: 0.9rem; color: #aaa; margin-left: 8px;">— {target_date.strftime("%b %d, %Y")}</span>
                </div>""",
                unsafe_allow_html=True,
            )
    except ValueError:
        pass

# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------
accounts = config.get_accounts()
bals = all_balances(conn)
nw = net_worth(conn, balances=bals)
dp = debt_progress(conn, balances=bals)
ef = nw["emergency_fund"]
ef_target = targets.get("emergency_fund_target", 0) or 0

# Check-in history for sparklines
check_ins = get_check_in_history(conn)

# Compute historical values for sparklines
ci_liquid = []
ci_ef = []
ci_debt = []
ci_net_worths = []
ci_dates = []

for ci in check_ins:
    bals_ci = ci.get("balances", {})
    checking = sum(bals_ci.get(n, 0) or 0 for n, info in accounts.items() if info["type"] == "checking")
    savings = sum(bals_ci.get(n, 0) or 0 for n, info in accounts.items() if info["type"] == "savings")
    investments = sum(bals_ci.get(n, 0) or 0 for n, info in accounts.items() if info["type"] == "investment")
    debt = sum(bals_ci.get(n, 0) or 0 for n, info in accounts.items() if info["type"] in ("credit_card", "loan", "student_loan"))
    liquid = checking + savings
    ci_liquid.append(liquid)
    ci_ef.append(savings)
    ci_debt.append(debt)
    ci_net_worths.append(liquid + investments - debt)
    ci_dates.append(ci["date"])


def _sparkline(values, color, height=80):
    """Render a compact chart with minimal axis labels."""
    if len(values) < 2:
        return
    fill_color = hex_to_rgba(color, 0.1)
    fig = go.Figure(
        go.Scatter(
            x=ci_dates[: len(values)],
            y=values,
            mode="lines+markers",
            line={"color": color, "width": 2},
            marker={"size": 4},
            fill="tozeroy",
            fillcolor=fill_color,
        )
    )
    fig.update_layout(
        height=height,
        margin={"t": 0, "b": 18, "l": 40, "r": 5},
        xaxis={"tickfont": {"size": 9, "color": "#666"}, "showgrid": False, "tickformat": "%b %d"},
        yaxis={"tickfont": {"size": 9, "color": "#666"}, "tickformat": "$,.0f", "showgrid": False},
        showlegend=False,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


# ---------------------------------------------------------------------------
# Row 1: Top-line metric cards with sparklines + % change from baseline
# ---------------------------------------------------------------------------

baseline_liquid = ci_liquid[0] if ci_liquid else 0
baseline_ef = ci_ef[0] if ci_ef else 0
baseline_nw = ci_net_worths[0] if ci_net_worths else 0
baseline_debt = ci_debt[0] if ci_debt else 0


def _pct_change(current, baseline):
    if baseline == 0:
        return None
    return ((current - baseline) / abs(baseline)) * 100


col1, col2, col3, col4 = st.columns(4)

with col1:
    liquid_chg = _pct_change(nw["liquid_assets"], baseline_liquid)
    st.metric(
        label="Liquid Assets",
        value=fmt_usd(nw["liquid_assets"]),
        delta=f"{liquid_chg:+.1f}% since start" if liquid_chg is not None else None,
    )
    _sparkline(ci_liquid, COLORS["blue"])

with col2:
    ef_pct = (ef / ef_target * 100) if ef_target else 0.0
    ef_chg = _pct_change(ef, baseline_ef)
    st.metric(
        label="Emergency Fund",
        value=fmt_usd(ef),
        delta=f"{fmt_pct(ef_pct)} of {fmt_usd(ef_target)} target ({ef_chg:+.1f}%)"
        if ef_chg is not None
        else f"{fmt_pct(ef_pct)} of {fmt_usd(ef_target)} target",
    )
    _sparkline(ci_ef, COLORS["green"])

with col3:
    nw_chg = _pct_change(nw["net_worth"], baseline_nw)
    st.metric(
        label="Net Worth",
        value=fmt_usd(nw["net_worth"]),
        delta=f"{nw_chg:+.1f}% since start" if nw_chg is not None else None,
    )
    _sparkline(ci_net_worths, COLORS["purple"])

with col4:
    debt_chg = _pct_change(nw["total_debt"], baseline_debt)
    st.metric(
        label="Total Debt",
        value=fmt_usd(nw["total_debt"]),
        delta=f"{debt_chg:+.1f}% since start" if debt_chg is not None else None,
        delta_color="inverse",
    )
    _sparkline(ci_debt, COLORS["red"])

st.divider()

# ---------------------------------------------------------------------------
# Row 2: Account Balances (grouped) | Debt Payoff Progress
# ---------------------------------------------------------------------------
col_left, col_right = st.columns([1, 1])

# Build ACCOUNT_GROUPS dynamically from config
TYPE_TO_GROUP = {
    "checking": "Checking",
    "savings": "Savings",
    "credit_card": "Credit Cards",
    "investment": "Investments",
    "loan": "Loans",
    "student_loan": "Student Loans",
}

GROUP_COLORS = {
    "Checking": COLORS["blue"],
    "Savings": COLORS["green"],
    "Credit Cards": COLORS["red"],
    "Investments": COLORS["purple"],
    "Loans": COLORS["orange"],
    "Student Loans": COLORS["gray"],
}

ACCOUNT_GROUPS: dict[str, list[str]] = {}
for name, info in accounts.items():
    if info["type"] == "external":
        continue
    group = TYPE_TO_GROUP.get(info["type"], "Other")
    ACCOUNT_GROUPS.setdefault(group, []).append(name)

with col_left:
    st.subheader("Account Balances")
    for group_name, group_accounts in ACCOUNT_GROUPS.items():
        rows_html = []
        for acct in group_accounts:
            bal = bals.get(acct, 0)
            if bal != 0.0:
                acct_type = accounts.get(acct, {}).get("type", "")
                color = COLORS["red"] if acct_type in DEBT_TYPES else COLORS["green"]
                rows_html.append(
                    f'<tr><td style="padding: 6px 10px; border-bottom: 1px solid #333; width: 60%;">{acct}</td>'
                    f'<td style="padding: 6px 10px; border-bottom: 1px solid #333; text-align: right; '
                    f'color: {color}; font-weight: 600; width: 40%;">{fmt_usd(bal)}</td></tr>'
                )
        if rows_html:
            gc = GROUP_COLORS.get(group_name, COLORS["gray"])
            st.markdown(
                f'<div style="background: {gc}; padding: 4px 10px; border-radius: 4px; '
                f'margin-top: 8px; margin-bottom: 4px;">'
                f'<span style="font-size: 0.85rem; font-weight: 600; color: #fff;">{group_name}</span></div>',
                unsafe_allow_html=True,
            )
            st.markdown(
                f'<table style="width: 100%; border-collapse: collapse; margin-bottom: 8px; table-layout: fixed;">'
                f'{"".join(rows_html)}</table>',
                unsafe_allow_html=True,
            )

with col_right:
    st.subheader("Debt Payoff Progress")

    # Active debts (exclude student loans — parked)
    student_loan_accounts = config.get_student_loan_accounts()
    debt_items = {k: v for k, v in dp.items() if not k.startswith("_") and k not in student_loan_accounts}
    total_starting = sum(v["starting_balance"] for v in debt_items.values())
    total_current = sum(v["current_balance"] for v in debt_items.values())
    total_paid = total_starting - total_current
    overall_pct = (total_paid / total_starting * 100) if total_starting > 0 else 0

    # Largest active debt share for gauge annotation
    largest_name = None
    largest_share_pct = 0
    if debt_items:
        largest_name = max(debt_items, key=lambda k: debt_items[k]["starting_balance"])
        largest_starting = debt_items[largest_name]["starting_balance"]
        largest_share_pct = (largest_starting / total_starting * 100) if total_starting > 0 else 0

    gauge_fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=overall_pct,
            number={"suffix": "%", "valueformat": ".1f"},
            title={"text": f"{fmt_usd(total_paid)} paid of {fmt_usd(total_starting)}"},
            gauge={
                "axis": {"range": [0, 100], "ticksuffix": "%"},
                "bar": {"color": COLORS["green"]},
                "steps": [
                    {"range": [0, largest_share_pct], "color": "#ffe0b2"},
                    {"range": [largest_share_pct, 50], "color": "#fff8e1"},
                    {"range": [50, 75], "color": "#e8f5e9"},
                    {"range": [75, 100], "color": "#c8e6c9"},
                ],
            },
        )
    )
    gauge_fig.update_layout(height=280, margin={"t": 50, "b": 10, "l": 20, "r": 20})
    if largest_name:
        gauge_fig.add_annotation(
            text=f"<b style='color:{COLORS['orange']}'>■</b> {largest_name}: {largest_share_pct:.0f}% of total debt",
            xref="paper", yref="paper", x=0.5, y=-0.05,
            showarrow=False, font={"size": 13},
        )
    st.plotly_chart(gauge_fig, use_container_width=True)

    # Emergency Fund gauge
    st.subheader("Emergency Fund Progress")
    ef_gauge = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=ef_pct,
            number={"suffix": "%", "valueformat": ".1f"},
            title={"text": f"{fmt_usd(ef)} of {fmt_usd(ef_target)}"},
            gauge={
                "axis": {"range": [0, 100], "ticksuffix": "%"},
                "bar": {"color": COLORS["blue"]},
                "steps": [
                    {"range": [0, 25], "color": "#fdecea"},
                    {"range": [25, 50], "color": "#fff8e1"},
                    {"range": [50, 75], "color": "#e8f5e9"},
                    {"range": [75, 100], "color": "#c8e6c9"},
                ],
            },
        )
    )
    ef_gauge.update_layout(height=250, margin={"t": 50, "b": 10, "l": 20, "r": 20})
    st.plotly_chart(ef_gauge, use_container_width=True)

st.divider()

# ---------------------------------------------------------------------------
# Row 3: Largest Debt Payoff | Emergency Fund Progress (line charts)
# ---------------------------------------------------------------------------
col_cc, col_ef_chart = st.columns(2)

with col_cc:
    if debt_items and largest_name:
        st.subheader(f"{largest_name} Payoff")
    else:
        st.subheader("Debt Payoff")

    if check_ins and debt_items and largest_name:
        largest_balances = []
        for ci in check_ins:
            bals_ci = ci.get("balances", {})
            largest_balances.append(bals_ci.get(largest_name, 0) or 0)

        fig_cc = go.Figure()
        fig_cc.add_trace(
            go.Scatter(
                x=ci_dates,
                y=largest_balances,
                mode="lines+markers+text",
                name="Balance",
                line={"color": COLORS["red"], "width": 3},
                marker={"size": 8},
                text=[fmt_usd(b) for b in largest_balances],
                textposition="top center",
            )
        )
        fig_cc.add_hline(y=0, line_dash="dash", line_color=COLORS["green"], annotation_text="Target: $0")
        fig_cc.update_layout(
            yaxis_title="Balance ($)",
            yaxis_tickformat="$,.0f",
            height=280,
            margin={"t": 20, "b": 20, "l": 10, "r": 10},
            showlegend=False,
        )
        st.plotly_chart(fig_cc, use_container_width=True)
    else:
        st.info("Need check-in data to show progress over time.")

with col_ef_chart:
    st.subheader("Emergency Fund Progress")
    if check_ins:
        ef_balances = []
        for ci in check_ins:
            bals_ci = ci.get("balances", {})
            ef_val = sum(bals_ci.get(n, 0) or 0 for n, info in accounts.items() if info["type"] == "savings")
            ef_balances.append(ef_val)

        fig_ef = go.Figure()
        fig_ef.add_trace(
            go.Scatter(
                x=ci_dates,
                y=ef_balances,
                mode="lines+markers+text",
                name="Emergency Fund",
                line={"color": COLORS["blue"], "width": 3},
                marker={"size": 8},
                text=[fmt_usd(b) for b in ef_balances],
                textposition="top center",
                fill="tozeroy",
                fillcolor="rgba(52, 152, 219, 0.1)",
            )
        )
        if ef_target:
            fig_ef.add_hline(
                y=ef_target,
                line_dash="dash",
                line_color=COLORS["green"],
                annotation_text=f"Target: {fmt_usd(ef_target)}",
            )
        fig_ef.update_layout(
            yaxis_title="Balance ($)",
            yaxis_tickformat="$,.0f",
            yaxis_range=[0, max(ef_target * 1.1, max(ef_balances, default=1000) * 1.1)],
            height=280,
            margin={"t": 20, "b": 20, "l": 10, "r": 10},
            showlegend=False,
        )
        st.plotly_chart(fig_ef, use_container_width=True)
    else:
        st.info("Need check-in data to show progress over time.")

st.divider()

# ---------------------------------------------------------------------------
# Row 4: Debt Progress (sorted highest to lowest) | Where Your Money Goes
# ---------------------------------------------------------------------------
col_left2, col_right2 = st.columns([1, 1])

with col_left2:
    st.subheader("Debt Progress")

    if debt_items:
        debt_color_map = auto_assign_colors(list(debt_items.keys()))
        sorted_debts = sorted(debt_items.items(), key=lambda x: x[1]["current_balance"], reverse=True)
        account_names = [k for k, v in sorted_debts]
        current_balances = [v["current_balance"] for k, v in sorted_debts]
        amount_paid_list = [v["amount_paid"] for k, v in sorted_debts]
        progress_pcts = [v["progress_pct"] for k, v in sorted_debts]
        bar_colors = [debt_color_map.get(a, COLORS["gray"]) for a in account_names]

        debt_fig = go.Figure()
        debt_fig.add_trace(
            go.Bar(
                name="Remaining",
                y=account_names,
                x=current_balances,
                orientation="h",
                marker_color=bar_colors,
                text=[fmt_usd(b) for b in current_balances],
                textposition="inside",
                insidetextanchor="end",
            )
        )
        debt_fig.add_trace(
            go.Bar(
                name="Paid",
                y=account_names,
                x=amount_paid_list,
                orientation="h",
                marker_color=COLORS["gray"],
                opacity=0.45,
                text=[f"{p:.1f}% paid" for p in progress_pcts],
                textposition="outside",
            )
        )
        debt_fig.update_layout(
            barmode="stack",
            xaxis_title="Balance ($)",
            legend={"orientation": "h", "y": -0.15},
            height=320,
            margin={"t": 20, "b": 40, "l": 10, "r": 20},
        )
        debt_fig.update_xaxes(tickformat="$,.0f")
        st.plotly_chart(debt_fig, use_container_width=True)
    else:
        st.info("No debt accounts on record.")

with col_right2:
    st.subheader("Monthly Cash Flow")

    cushion_data = monthly_cushion(conn)
    income = cushion_data["income"]
    expenses = cushion_data["expenses"]
    debt_pmts = cushion_data["debt_payments"]
    leftover = cushion_data["cushion"]

    st.metric("Income This Month", fmt_usd(income))

    categories = ["Living Expenses", "Debt Payments", "Unallocated"]
    values = [expenses, debt_pmts, max(leftover, 0)]
    bar_colors_list = [COLORS["red"], COLORS["orange"], COLORS["green"]]

    for cat, val, color in zip(categories, values, bar_colors_list, strict=True):
        pct = (val / income * 100) if income > 0 else 0
        st.markdown(
            f"""<div style="margin-bottom: 8px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
                <span style="font-size: 0.9rem;">{cat}</span>
                <span style="font-size: 0.9rem; color: #aaa;">{fmt_usd(val)} ({pct:.0f}%)</span>
            </div>
            <div style="background: #2c3e50; border-radius: 4px; height: 20px; overflow: hidden;">
                <div style="background: {color}; width: {min(pct, 100):.0f}%; height: 100%; border-radius: 4px;"></div>
            </div>
            </div>""",
            unsafe_allow_html=True,
        )

    if leftover < 0:
        st.error(f"Over budget by {fmt_usd(abs(leftover))} this month.")

st.divider()

# ---------------------------------------------------------------------------
# Row 5: Budget vs Actual with month selector
# ---------------------------------------------------------------------------
selected_month = month_selector(conn, key="dashboard_month")
bva = budget_vs_actual(conn, month=selected_month)

st.subheader(f"Budget vs Actual — {fmt_month(selected_month)}")

# Get category groups to determine which are savings vs expenses
cat_groups = {
    r["name"]: r["group_name"]
    for r in conn.execute("SELECT name, group_name FROM categories").fetchall()
}
excluded = {"Transfer", "Debt Payment", "Interest Charged", "Paycheck", "Interest Earned", "Refund", "Investment", "Reconciliation"}
bva_filtered = [
    r for r in bva
    if (r["budgeted"] > 0 or r["actual"] > 0) and r["category"] not in excluded
]
bva_sorted = sorted(bva_filtered, key=lambda r: r["budgeted"], reverse=True)

if bva_sorted:
    categories = [r["category"] for r in bva_sorted]
    budgeted_vals = [r["budgeted"] for r in bva_sorted]
    actual_vals = [r["actual"] for r in bva_sorted]
    diff_vals = [r["difference"] for r in bva_sorted]

    bar_colors = []
    bar_labels = []
    for cat, a, b, d in zip(categories, actual_vals, budgeted_vals, diff_vals, strict=False):
        is_savings = cat_groups.get(cat) == "savings"
        if b == 0 and a > 0:
            bar_colors.append(COLORS["red"])
            bar_labels.append(f"{fmt_usd(a)}  (no budget)")
        elif a == 0:
            bar_colors.append(COLORS["green"])
            bar_labels.append("")
        elif d < 0 and is_savings:
            bar_colors.append(COLORS["green"])
            bar_labels.append(f"{fmt_usd(a)}  / {fmt_usd(b)}  (+{fmt_usd(abs(d))} extra)")
        elif d < 0:
            bar_colors.append(COLORS["red"])
            bar_labels.append(f"{fmt_usd(a)}  / {fmt_usd(b)}  (+{fmt_usd(abs(d))} over)")
        else:
            bar_colors.append(COLORS["green"])
            bar_labels.append(f"{fmt_usd(a)}  / {fmt_usd(b)}")

    bva_fig = go.Figure()
    bva_fig.add_trace(
        go.Bar(
            name="Budget",
            y=categories,
            x=budgeted_vals,
            orientation="h",
            marker_color=COLORS["dark"],
            opacity=0.25,
            hovertemplate="%{y}: Budget %{x:$,.2f}<extra></extra>",
            text=[""] * len(categories),
        )
    )
    bva_fig.add_trace(
        go.Bar(
            name="Actual",
            y=categories,
            x=actual_vals,
            orientation="h",
            marker_color=bar_colors,
            text=bar_labels,
            textposition="outside",
            textfont={"size": 11},
            hovertemplate="%{y}: Actual %{x:$,.2f}<extra></extra>",
        )
    )
    bva_fig.update_layout(
        barmode="overlay",
        xaxis_title="Amount ($)",
        xaxis_tickformat="$,.0f",
        yaxis={"autorange": "reversed", "tickfont": {"size": 11}},
        legend={"orientation": "h", "y": 1.05, "x": 0},
        height=max(350, len(categories) * 30 + 80),
        margin={"t": 30, "b": 40, "l": 10, "r": 250},
    )
    st.plotly_chart(bva_fig, use_container_width=True)
else:
    st.info(f"No budget or spending data available for {selected_month}.")
