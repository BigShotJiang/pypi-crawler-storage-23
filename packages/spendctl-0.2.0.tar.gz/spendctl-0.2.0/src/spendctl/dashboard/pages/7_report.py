"""Monthly Budget Report — single-page printable summary."""

from __future__ import annotations

from datetime import date

import streamlit as st
import streamlit.components.v1 as components

from spendctl import config
from spendctl.dashboard.helpers import fmt_month, fmt_usd, get_conn, month_selector
from spendctl.queries.budget import budget_vs_actual, monthly_cushion
from spendctl.queries.dashboard import all_balances, debt_progress, net_worth
from spendctl.queries.reports import monthly_summary
from spendctl.queries.subscriptions import active_monthly_total

st.set_page_config(page_title="Report — spendctl", layout="wide", page_icon="💰")
st.title("Monthly Budget Report")

conn = get_conn()
today = date.today()

# ── Month selector ─────────────────────────────────────────────────────────────

selected_month = month_selector(conn, key="report_month", label="Select month for report")
month_label = fmt_month(selected_month)

# ── Load all data ──────────────────────────────────────────────────────────────

targets = config.get_targets()
ef_target = targets.get("emergency_fund_target", 0) or 0
target_date_str = targets.get("target_date")
target_label = targets.get("target_label", "Target")

student_loan_accounts = config.get_student_loan_accounts()

bals = all_balances(conn)
nw = net_worth(conn, balances=bals)
dp = debt_progress(conn, balances=bals)
cushion_data = monthly_cushion(conn, month=selected_month)
summary = monthly_summary(conn, month=selected_month)
bva = budget_vs_actual(conn, month=selected_month)
sub_total = active_monthly_total(conn)

dp_active = {k: v for k, v in dp.items() if not k.startswith("_") and k not in student_loan_accounts}
dp_sl = {k: v for k, v in dp.items() if k in student_loan_accounts}

# Target countdown
target_str = ""
if target_date_str:
    try:
        target_date = date.fromisoformat(target_date_str)
        delta = target_date - today
        if delta.days > 0:
            months_rem = delta.days // 30
            days_rem = delta.days % 30
            target_str = f"{months_rem} months, {days_rem} days"
    except ValueError:
        pass

# ── Generate Report button ─────────────────────────────────────────────────────

if st.button("Generate Report", type="primary"):
    # Build budget rows
    bva_rows = []
    for row in sorted(bva, key=lambda r: r["actual"], reverse=True):
        if row["budgeted"] > 0 or row["actual"] > 0:
            diff = row["difference"]
            diff_color = "#2ecc71" if diff >= 0 else "#e74c3c"
            diff_sign = "+" if diff >= 0 else ""
            bva_rows.append(
                f"<tr><td>{row['category']}</td>"
                f'<td style="text-align:right">{fmt_usd(row["budgeted"])}</td>'
                f'<td style="text-align:right">{fmt_usd(row["actual"])}</td>'
                f'<td style="text-align:right;color:{diff_color}">{diff_sign}{fmt_usd(diff)}</td></tr>'
            )

    # Build debt rows
    debt_rows = []
    total_debt_balance = 0
    for acct, data in dp_active.items():
        total_debt_balance += data["current_balance"]
        debt_rows.append(
            f"<tr><td>{acct}</td>"
            f'<td style="text-align:right">{fmt_usd(data["starting_balance"])}</td>'
            f'<td style="text-align:right">{fmt_usd(data["current_balance"])}</td>'
            f'<td style="text-align:right;color:#2ecc71">{fmt_usd(data["amount_paid"])}</td></tr>'
        )
    for acct, data in dp_sl.items():
        total_debt_balance += data["current_balance"]
        debt_rows.append(
            f'<tr style="color:#888"><td>{acct} (parked)</td>'
            f'<td style="text-align:right">{fmt_usd(data["starting_balance"])}</td>'
            f'<td style="text-align:right">{fmt_usd(data["current_balance"])}</td>'
            f'<td style="text-align:right">\u2014</td></tr>'
        )

    # Build balance rows
    balance_rows = []
    non_balance = config.get_non_balance_accounts()
    for acct, bal in sorted(bals.items(), key=lambda x: x[1], reverse=True):
        if bal != 0.0 and acct not in non_balance:
            balance_rows.append(f'<tr><td>{acct}</td><td style="text-align:right">{fmt_usd(bal)}</td></tr>')

    bva_html = "\n".join(bva_rows)
    debt_html = "\n".join(debt_rows)
    balance_html = "\n".join(balance_rows)

    total_budgeted = sum(r["budgeted"] for r in bva)
    total_active_paid = sum(v["amount_paid"] for v in dp_active.values())

    # Build subtitle with target info
    subtitle_parts = [month_label, f"Generated {today.strftime('%B %d, %Y')}"]
    if target_str:
        subtitle_parts.append(f"{target_label}: {target_str}")
    subtitle = " \u2014 ".join(subtitle_parts)

    html = (
        """<!DOCTYPE html>
<html>
<head>
<style>
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    color: #222;
    max-width: 900px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    font-size: 12px;
}
h1 {
    text-align: center;
    border-bottom: 2px solid #333;
    padding-bottom: 8px;
    margin-bottom: 4px;
    font-size: 20px;
    color: #222;
}
.subtitle {
    text-align: center;
    color: #666;
    font-size: 11px;
    margin-bottom: 16px;
}
h2 {
    font-size: 13px;
    color: #2c3e50;
    border-bottom: 1px solid #ccc;
    padding-bottom: 3px;
    margin-top: 14px;
    margin-bottom: 6px;
}
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 11px;
    margin-bottom: 8px;
}
th {
    text-align: left;
    border-bottom: 1px solid #999;
    padding: 3px 6px;
    color: #666;
    font-size: 9px;
    text-transform: uppercase;
}
td {
    padding: 2px 6px;
    border-bottom: 1px solid #eee;
}
.metric-row {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 14px;
}
.metric {
    flex: 1;
    background: #f5f5f5;
    border-radius: 6px;
    padding: 8px 10px;
    text-align: center;
    border: 1px solid #ddd;
}
.metric .label {
    font-size: 9px;
    color: #666;
    text-transform: uppercase;
}
.metric .value {
    font-size: 16px;
    font-weight: 700;
}
.two-col {
    display: flex;
    gap: 20px;
}
.two-col > div {
    flex: 1;
}
.total-row {
    font-weight: bold;
    border-top: 2px solid #999;
}
.footer {
    text-align: center;
    color: #888;
    font-size: 10px;
    margin-top: 12px;
    border-top: 1px solid #ccc;
    padding-top: 6px;
}
</style>
</head>
<body>
<h1>Monthly Budget Report</h1>
<div class="subtitle">"""
        + subtitle
        + """</div>

<div class="metric-row">
    <div class="metric">
        <div class="label">Monthly Income</div>
        <div class="value" style="color:#27ae60">"""
        + fmt_usd(cushion_data["income"])
        + """</div>
    </div>
    <div class="metric">
        <div class="label">Living Expenses</div>
        <div class="value" style="color:#c0392b">"""
        + fmt_usd(cushion_data["expenses"])
        + """</div>
    </div>
    <div class="metric">
        <div class="label">Debt Payments</div>
        <div class="value" style="color:#d68910">"""
        + fmt_usd(cushion_data["debt_payments"])
        + """</div>
    </div>
    <div class="metric">
        <div class="label">Remaining</div>
        <div class="value" style="color:#2980b9">"""
        + fmt_usd(cushion_data["cushion"])
        + """</div>
    </div>
</div>

<div class="two-col">
    <div>
        <h2>Budget vs Actual</h2>
        <table>
            <tr><th>Category</th><th style="text-align:right">Budget</th><th style="text-align:right">Actual</th><th style="text-align:right">Diff</th></tr>
            """
        + bva_html
        + """
            <tr class="total-row">
                <td>Total Expenses</td>
                <td style="text-align:right">"""
        + fmt_usd(total_budgeted)
        + """</td>
                <td style="text-align:right">"""
        + fmt_usd(summary["total_expenses"])
        + """</td>
                <td></td>
            </tr>
        </table>
    </div>
    <div>
        <h2>Account Balances</h2>
        <table>
            <tr><th>Account</th><th style="text-align:right">Balance</th></tr>
            """
        + balance_html
        + """
        </table>

        <h2>Net Worth Summary</h2>
        <table>
            <tr><td>Liquid Assets</td><td style="text-align:right">"""
        + fmt_usd(nw["liquid_assets"])
        + """</td></tr>
            <tr><td>Investments</td><td style="text-align:right">"""
        + fmt_usd(nw["investments"])
        + """</td></tr>
            <tr><td>Emergency Fund</td><td style="text-align:right">"""
        + fmt_usd(nw["emergency_fund"])
        + """</td></tr>
            <tr class="total-row"><td>Total Debt</td><td style="text-align:right;color:#c0392b">"""
        + fmt_usd(nw["total_debt"])
        + """</td></tr>
            <tr class="total-row"><td>Net Worth</td><td style="text-align:right">"""
        + fmt_usd(nw["net_worth"])
        + """</td></tr>
        </table>
    </div>
</div>

<h2>Debt Overview</h2>
<table>
    <tr><th>Account</th><th style="text-align:right">Starting</th><th style="text-align:right">Current</th><th style="text-align:right">Paid</th></tr>
    """
        + debt_html
        + """
    <tr class="total-row">
        <td>Total</td>
        <td></td>
        <td style="text-align:right">"""
        + fmt_usd(total_debt_balance)
        + """</td>
        <td style="text-align:right;color:#27ae60">"""
        + fmt_usd(total_active_paid)
        + """</td>
    </tr>
</table>

<div class="footer">
    Subscriptions: """
        + fmt_usd(sub_total)
        + f"""/mo &bull; Emergency Fund Target: {fmt_usd(ef_target)} ("""
        + fmt_usd(nw["emergency_fund"])
        + """ current)
</div>
</body>
</html>"""
    )

    components.html(html, height=900, scrolling=True)

    st.markdown("---")
    st.info(
        "**To print:** Right-click the report above → Print Frame, or Cmd+P and select 'Save as PDF'. The report uses a white background for clean printing."
    )
