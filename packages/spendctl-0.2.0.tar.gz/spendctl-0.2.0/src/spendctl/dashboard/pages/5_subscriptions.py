"""Subscription manager page."""

from __future__ import annotations

from datetime import date

import streamlit as st

from spendctl.dashboard.helpers import fmt_usd, get_conn
from spendctl.db import backup
from spendctl.queries.subscriptions import (
    cancel_subscription,
    list_subscriptions,
)

st.set_page_config(page_title="Subscriptions — spendctl", layout="wide", page_icon="💰")
st.title("Subscriptions")


def _ordinal(n: int | None) -> str:
    if n is None:
        return "—"
    suffix = {1: "st", 2: "nd", 3: "rd"}.get(n if n < 20 else n % 10, "th")
    return f"{n}{suffix}"


conn = get_conn()

# ---------------------------------------------------------------------------
# Load data — separate true subscriptions from recurring bills
# ---------------------------------------------------------------------------
all_subs = list_subscriptions(conn)

# Bills are identified by the category field in the subscription record
# vs true subscriptions (entertainment, SaaS, etc.)
# We use the category group from the DB to distinguish
bill_categories_rows = conn.execute(
    "SELECT name FROM categories WHERE group_name = 'living_expense'"
).fetchall()
bill_category_names = {r["name"] for r in bill_categories_rows}

true_subs = [s for s in all_subs if s.get("category") not in bill_category_names]
recurring_bills = [s for s in all_subs if s.get("category") in bill_category_names]

active_subs = [s for s in true_subs if s["status"] == "Active"]
canceled_subs = [s for s in true_subs if s["status"] == "Canceled"]
monthly_total = sum(s["amount"] for s in active_subs if s.get("frequency") == "Monthly")
annual_as_monthly = sum(s["amount"] / 12 for s in active_subs if s.get("frequency") == "Annual")
effective_monthly = monthly_total + annual_as_monthly

# ---------------------------------------------------------------------------
# Row 1: Metric cards
# ---------------------------------------------------------------------------
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Monthly Subscriptions", fmt_usd(monthly_total))

with col2:
    if annual_as_monthly > 0:
        st.metric("Annual (as Monthly)", fmt_usd(annual_as_monthly))
    else:
        st.metric("Effective Monthly", fmt_usd(effective_monthly))

with col3:
    annual_cost = (monthly_total * 12) + sum(s["amount"] for s in active_subs if s.get("frequency") == "Annual")
    st.metric("Annual Cost", fmt_usd(annual_cost))

st.divider()

# ---------------------------------------------------------------------------
# Row 2: Active subscriptions table with Cancel buttons
# ---------------------------------------------------------------------------
st.subheader("Active Subscriptions")

if active_subs:
    st.markdown(
        """<div style="display:flex; gap:0; background:#243b6a; padding:8px 12px;
        border-radius:6px; margin-bottom:4px;">
        <span style="flex:3; font-weight:600;">Name</span>
        <span style="flex:2; font-weight:600;">Amount</span>
        <span style="flex:2; font-weight:600;">Frequency</span>
        <span style="flex:2; font-weight:600;">Account</span>
        <span style="flex:1; font-weight:600;">Bills On</span>
        <span style="flex:2; font-weight:600;">Notes</span>
        <span style="flex:1; font-weight:600;">Action</span>
        </div>""",
        unsafe_allow_html=True,
    )

    for sub in active_subs:
        row_cols = st.columns([3, 2, 2, 2, 1, 2, 1])

        with row_cols[0]:
            st.write(sub["name"])
        with row_cols[1]:
            st.write(fmt_usd(sub["amount"]))
        with row_cols[2]:
            st.write(sub.get("frequency", "Monthly"))
        with row_cols[3]:
            st.write(sub.get("account") or "—")
        with row_cols[4]:
            st.write(_ordinal(sub.get("billing_day")))
        with row_cols[5]:
            st.write(sub.get("notes") or "")
        with row_cols[6]:
            cancel_key = f"cancel_{sub['id']}"
            if st.button("Cancel", key=cancel_key):
                try:
                    backup()
                    cancel_subscription(conn, sub["id"], canceled_date=date.today().isoformat())
                    st.cache_data.clear()
                    st.success(f"Canceled: {sub['name']}")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))
else:
    st.info("No active subscriptions.")

st.divider()

# ---------------------------------------------------------------------------
# Row 3: Canceled subscriptions with savings
# ---------------------------------------------------------------------------
with st.expander(f"Canceled Subscriptions ({len(canceled_subs)})"):
    if canceled_subs:
        canceled_monthly = sum(s["amount"] for s in canceled_subs if s.get("frequency", "Monthly") == "Monthly")
        canceled_annual_as_monthly = sum(s["amount"] / 12 for s in canceled_subs if s.get("frequency") == "Annual")
        total_savings = canceled_monthly + canceled_annual_as_monthly

        st.markdown(
            f"""<div style="background: #1a2e1a; padding: 12px 16px; border-radius: 6px;
            border-left: 4px solid #2ecc71; margin-bottom: 16px;">
            <span style="font-size: 1.1rem; color: #2ecc71; font-weight: 600;">
                Saving {fmt_usd(total_savings)}/month
            </span>
            <span style="font-size: 0.9rem; color: #aaa; margin-left: 8px;">
                ({fmt_usd(total_savings * 12)}/year) from canceled subscriptions
            </span>
            </div>""",
            unsafe_allow_html=True,
        )

        canceled_display = [
            {
                "Name": s["name"],
                "Was": fmt_usd(s["amount"]),
                "Frequency": s.get("frequency", "Monthly"),
                "Account": s.get("account") or "",
                "Billed On": _ordinal(s.get("billing_day")),
                "Canceled": s.get("canceled_date") or "",
                "Notes": s.get("notes") or "",
            }
            for s in canceled_subs
        ]
        st.dataframe(
            canceled_display,
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No canceled subscriptions.")

# ---------------------------------------------------------------------------
# Row 4: Recurring Bills (separate section)
# ---------------------------------------------------------------------------
if recurring_bills:
    st.divider()
    active_bills = [b for b in recurring_bills if b["status"] == "Active"]
    if active_bills:
        with st.expander(f"Recurring Bills ({len(active_bills)})"):
            st.caption("These are fixed monthly obligations — not cancelable subscriptions.")
            bills_display = [
                {
                    "Name": b["name"],
                    "Amount": fmt_usd(b["amount"]),
                    "Account": b.get("account") or "",
                    "Bills On": _ordinal(b.get("billing_day")),
                    "Category": b.get("category") or "",
                }
                for b in active_bills
            ]
            st.dataframe(
                bills_display,
                use_container_width=True,
                hide_index=True,
            )
            bills_total = sum(b["amount"] for b in active_bills)
            st.caption(f"Total recurring bills: {fmt_usd(bills_total)}/month")
