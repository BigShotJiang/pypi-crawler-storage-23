"""Loan Details page — student loans and other loan tracking."""

from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from spendctl import config
from spendctl.dashboard.helpers import COLORS, fmt_usd, get_conn
from spendctl.queries.check_ins import get_check_in_history
from spendctl.queries.dashboard import debt_progress

st.set_page_config(page_title="Loan Details — spendctl", layout="wide", page_icon="💰")
st.title("Loan Details")

conn = get_conn()

student_loan_accounts = config.get_student_loan_accounts()
loans_config = config.get_loans()

if not student_loan_accounts and not loans_config:
    st.info("No loan accounts configured. Add student_loan accounts to your config to track loans here.")
    st.stop()

# ── Load current balances ──────────────────────────────────────────────────────
dp = debt_progress(conn)
check_ins = get_check_in_history(conn)

# ── Aggregate loan metrics from config ────────────────────────────────────────
total_principal = sum(ln.get("principal", 0) for ln in loans_config)
total_daily_accrual = sum(ln.get("daily_accrual", 0) for ln in loans_config)
total_monthly_accrual = total_daily_accrual * 30
total_annual_accrual = total_daily_accrual * 365

# Current balance from check-ins (sum of all student loan accounts)
sl_balances_from_dp = {k: v["current_balance"] for k, v in dp.items() if k in student_loan_accounts}
current_balance_total = sum(sl_balances_from_dp.values()) if sl_balances_from_dp else sum(
    ln.get("principal", 0) + ln.get("accrued_interest", 0) for ln in loans_config
)

# ── Row 1: Key metrics ────────────────────────────────────────────────────────

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Current Balance", fmt_usd(current_balance_total))

with col2:
    if total_daily_accrual > 0:
        st.metric("Daily Interest", fmt_usd(total_daily_accrual))
    else:
        st.metric("Student Loan Accounts", str(len(student_loan_accounts)))

with col3:
    if total_monthly_accrual > 0:
        st.metric("Monthly Interest", fmt_usd(total_monthly_accrual))
    else:
        st.metric("Total Principal", fmt_usd(total_principal))

with col4:
    if total_annual_accrual > 0:
        st.metric("Annual Interest", fmt_usd(total_annual_accrual))

st.divider()

# ── Interest coverage callout (only if we have accrual data) ──────────────────
if total_monthly_accrual > 0:
    st.markdown(
        f"""<div style="background: linear-gradient(90deg, #1a2e1a, #16213e); padding: 14px 20px;
        border-radius: 8px; margin-bottom: 16px; border-left: 4px solid {COLORS["orange"]};">
        <span style="font-size: 1rem; color: #aaa;">To freeze the balance:</span>
        <strong style="font-size: 1.2rem; color: #fff; margin-left: 8px;">{fmt_usd(total_monthly_accrual)}/month</strong>
        <span style="font-size: 0.85rem; color: #aaa; margin-left: 8px;">
            — covers interest only, stops the balance from growing
        </span>
        </div>""",
        unsafe_allow_html=True,
    )

# ── Row 2: Loan breakdown from config ─────────────────────────────────────────
if loans_config:
    st.subheader("Loan Breakdown")
    cols = st.columns(len(loans_config))

    for i, loan in enumerate(loans_config):
        with cols[i]:
            principal = loan.get("principal", 0)
            accrued = loan.get("accrued_interest", 0)
            outstanding = principal + accrued
            daily = loan.get("daily_accrual", 0)
            rate = loan.get("rate", 0)
            group = loan.get("group", f"Loan {i + 1}")
            loan_type = loan.get("type", "Loan")
            status = loan.get("status", "")
            due_date = loan.get("due_date", "")

            st.markdown(
                f"""<div style="border-left: 4px solid {COLORS["gray"]}; padding: 12px 16px;
                background: #1e2329; border-radius: 4px;">
                <div style="font-size: 1rem; font-weight: 600; margin-bottom: 8px;">Group {group}</div>
                <div style="font-size: 0.85rem; color: #aaa; margin-bottom: 4px;">
                    Type: <strong style="color: #fff;">{loan_type}</strong>
                </div>
                <div style="font-size: 0.85rem; color: #aaa; margin-bottom: 4px;">
                    Principal: <strong style="color: #fff;">{fmt_usd(principal)}</strong>
                </div>
                {"" if accrued == 0 else f'<div style="font-size: 0.85rem; color: #aaa; margin-bottom: 4px;">Accrued Interest: <strong style="color: {COLORS["orange"]};">{fmt_usd(accrued)}</strong></div>'}
                <div style="font-size: 0.85rem; color: #aaa; margin-bottom: 4px;">
                    Outstanding: <strong style="color: #fff;">{fmt_usd(outstanding)}</strong>
                </div>
                <div style="font-size: 0.85rem; color: #aaa; margin-bottom: 4px;">
                    Rate: <strong style="color: #fff;">{rate:.3f}%</strong>
                </div>
                {"" if daily == 0 else f'<div style="font-size: 0.85rem; color: #aaa;">Daily Accrual: <strong style="color: {COLORS["orange"]};">{fmt_usd(daily)}/day</strong></div>'}
                {"" if not status else f'<div style="font-size: 0.85rem; color: #aaa; margin-top: 4px;">Status: <strong style="color: #fff;">{status}</strong></div>'}
                {"" if not due_date else f'<div style="font-size: 0.85rem; color: #aaa;">Due: <strong style="color: #fff;">{due_date}</strong></div>'}
                </div>""",
                unsafe_allow_html=True,
            )

            if principal > 0 and accrued > 0:
                fig = go.Figure()
                fig.add_trace(
                    go.Bar(
                        y=["Balance"],
                        x=[principal],
                        name="Principal",
                        orientation="h",
                        marker_color=COLORS["gray"],
                        text=[fmt_usd(principal)],
                        textposition="inside",
                    )
                )
                fig.add_trace(
                    go.Bar(
                        y=["Balance"],
                        x=[accrued],
                        name="Interest",
                        orientation="h",
                        marker_color=COLORS["orange"],
                        text=[fmt_usd(accrued)],
                        textposition="inside",
                    )
                )
                fig.update_layout(
                    barmode="stack",
                    height=80,
                    margin={"t": 5, "b": 5, "l": 5, "r": 5},
                    xaxis={"visible": False},
                    yaxis={"visible": False},
                    legend={"orientation": "h", "y": -0.5, "font": {"size": 9}},
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                )
                st.plotly_chart(fig, use_container_width=True)

    st.divider()

# ── Balance over time from check-ins ──────────────────────────────────────────
st.subheader("Balance Over Time")

if check_ins and student_loan_accounts:
    dates = []
    balances = []
    for ci in check_ins:
        bals_ci = ci.get("balances", {})
        sl_total = sum(bals_ci.get(acct, 0) or 0 for acct in student_loan_accounts)
        if sl_total > 0:
            dates.append(ci["date"])
            balances.append(sl_total)

    if dates:
        fig_balance = go.Figure()
        fig_balance.add_trace(
            go.Scatter(
                x=dates,
                y=balances,
                mode="lines+markers+text",
                line={"color": COLORS["gray"], "width": 3},
                marker={"size": 8},
                text=[fmt_usd(b) for b in balances],
                textposition="top center",
            )
        )
        if total_principal > 0:
            fig_balance.add_hline(
                y=total_principal,
                line_dash="dash",
                line_color=COLORS["blue"],
                annotation_text=f"Principal: {fmt_usd(total_principal)}",
            )
        fig_balance.update_layout(
            yaxis_title="Balance ($)",
            yaxis_tickformat="$,.0f",
            height=300,
            margin={"t": 20, "b": 20, "l": 10, "r": 10},
            showlegend=False,
        )
        st.plotly_chart(fig_balance, use_container_width=True)
    else:
        st.info("No balance data recorded for loan accounts yet.")
else:
    st.info("No check-in data available yet.")

st.divider()

# ── Context (from config status/notes) ────────────────────────────────────────
if loans_config:
    # Show any status/strategy notes from config
    statuses = [ln.get("status") for ln in loans_config if ln.get("status")]
    strategies = [ln.get("strategy") for ln in loans_config if ln.get("strategy")]

    if statuses or strategies:
        notes_parts = []
        if statuses:
            unique_statuses = list(dict.fromkeys(statuses))
            notes_parts.append(f"**Status:** {', '.join(unique_statuses)}")
        if strategies:
            unique_strategies = list(dict.fromkeys(strategies))
            notes_parts.append(f"**Strategy:** {' '.join(unique_strategies)}")
        if total_daily_accrual > 0:
            notes_parts.append(
                f"Interest accrues at **{fmt_usd(total_daily_accrual)}/day** "
                f"({fmt_usd(total_monthly_accrual)}/month). "
                f"An optional {fmt_usd(total_monthly_accrual)}/month payment would freeze the balance at current levels."
            )
        st.markdown("\n\n".join(notes_parts))
