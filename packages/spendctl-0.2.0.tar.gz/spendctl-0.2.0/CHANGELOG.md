# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-03-01

### Added

- `spendctl ask` command — ask your local AI about your finances using Ollama
- Ollama integration in setup wizard — auto-detects local or remote Ollama instances
- AI assistant integration in setup wizard — auto-configures Claude Code, Codex CLI, Gemini CLI, and Aider
- Dashboard install prompt in setup wizard
- Comparison table in README (vs ledger, beancount, budgetwarrior)

### Changed

- `spendctl init` wizard expanded with 4 new sections (dashboard, Ollama, AI assistants, next steps)
- `spendctl config edit` menu updated with new sections

## [0.1.0] - 2026-03-01

### Added

- Interactive setup wizard (`spendctl init`) for first-time configuration
- Config management commands (`spendctl config show/edit/reset`)
- 13 CLI commands with `--json` output on every command
- Transaction tracking: add, list, filter, search, update, delete
- Account balance computation (transaction-based with starting balance calibration)
- Budget vs actual comparison with monthly breakdowns
- Debt paydown progress tracking with per-account metrics
- Net worth computation grouped by account type
- Subscription management (active, canceled, paused)
- Check-in system for periodic balance snapshots (normalized schema)
- Monthly summary and cash flow reports
- Spending breakdowns by category and account
- CSV export
- Database backup with timestamped copies
- 7-page Streamlit dashboard (optional `[dashboard]` extra)
  - Overview with sparklines and net worth gauge
  - Spending analysis with category charts
  - Debt progress with payoff projections
  - Transaction browser
  - Subscription tracker
  - Loan detail page
  - Printable monthly report
- Full community standards: LICENSE, CONTRIBUTING, CODE_OF_CONDUCT, SECURITY
- CI pipeline with lint + test matrix (Python 3.10-3.12)
- 221 tests passing

[0.2.0]: https://github.com/Jscoats/spendctl/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/Jscoats/spendctl/releases/tag/v0.1.0
