"""Tests for spendctl.queries.budget."""

from __future__ import annotations

from spendctl.queries.budget import budget_vs_actual, monthly_cushion, remaining_budget, total_income


class TestBudgetVsActual:
    def test_returns_list_with_expected_keys(self, db):
        rows = budget_vs_actual(db, month="2026-02")
        assert isinstance(rows, list)
        assert len(rows) > 0
        for row in rows:
            assert "category" in row
            assert "budgeted" in row
            assert "actual" in row
            assert "difference" in row
            assert "tx_count" in row

    def test_groceries_actual_matches_seed(self, db):
        rows = budget_vs_actual(db, month="2026-02")
        groceries = [r for r in rows if r["category"] == "Groceries"]
        assert len(groceries) == 1
        # 87.42 + 112.35 = 199.77
        assert groceries[0]["actual"] == 199.77
        assert groceries[0]["tx_count"] == 2

    def test_difference_is_budgeted_minus_actual(self, db):
        rows = budget_vs_actual(db, month="2026-02")
        for row in rows:
            expected_diff = round(row["budgeted"] - row["actual"], 2)
            assert row["difference"] == expected_diff

    def test_includes_categories_with_budget_but_no_spending(self, db):
        rows = budget_vs_actual(db, month="2026-02")
        categories = {r["category"] for r in rows}
        # Emergency Fund has budget but no spending in seed data
        assert "Emergency Fund" in categories

    def test_empty_month_returns_only_budgeted_categories(self, db):
        rows = budget_vs_actual(db, month="2025-01")
        # No transactions in 2025, only budgeted categories should appear
        for row in rows:
            assert row["actual"] == 0.0


class TestRemainingBudget:
    def test_groceries_remaining(self, db):
        result = remaining_budget(db, "Groceries", month="2026-02")
        assert "budgeted" in result
        assert "spent" in result
        assert "remaining" in result
        # budgeted = 500.00, spent = 199.77
        assert result["budgeted"] == 500.00
        assert result["spent"] == 199.77
        assert result["remaining"] == round(500.00 - 199.77, 2)

    def test_category_with_no_spending(self, db):
        result = remaining_budget(db, "Emergency Fund", month="2026-02")
        assert result["spent"] == 0.0
        assert result["remaining"] == result["budgeted"]

    def test_unknown_category_returns_zero_budget(self, db):
        result = remaining_budget(db, "Nonexistent Category", month="2026-02")
        assert result["budgeted"] == 0.0
        assert result["spent"] == 0.0
        assert result["remaining"] == 0.0


class TestTotalIncome:
    def test_returns_budgeted_and_actual(self, db):
        result = total_income(db, month="2026-02")
        assert "budgeted" in result
        assert "actual" in result

    def test_budgeted_matches_config(self, db):
        result = total_income(db, month="2026-02")
        # Income source: Salary = 5000.0
        assert result["budgeted"] == 5000.0

    def test_actual_matches_seed(self, db):
        result = total_income(db, month="2026-02")
        # Only income tx in seed: 5000.00 salary
        assert result["actual"] == 5000.0

    def test_empty_month_actual_is_zero(self, db):
        result = total_income(db, month="2025-01")
        assert result["actual"] == 0.0


class TestMonthlyCushion:
    def test_returns_expected_keys(self, db):
        result = monthly_cushion(db, month="2026-02")
        assert "income" in result
        assert "expenses" in result
        assert "debt_payments" in result
        assert "budgeted_transfers" in result
        assert "cushion" in result

    def test_cushion_formula(self, db):
        result = monthly_cushion(db, month="2026-02")
        computed = result["income"] - result["expenses"] - result["debt_payments"] - result["budgeted_transfers"]
        assert abs(result["cushion"] - computed) < 0.01

    def test_values_match_seed(self, db):
        result = monthly_cushion(db, month="2026-02")
        # income = 5000.00
        # expenses = 87.42 + 55.00 + 17.99 + 112.35 = 272.76
        # debt_payments = 500.00
        assert result["income"] == 5000.00
        assert result["expenses"] == 272.76
        assert result["debt_payments"] == 500.0
