"""Tests for spendctl.cli — validation helpers, main() dispatch, and command handlers."""

from __future__ import annotations

import argparse
import json
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from spendctl import __version__
from spendctl.cli import (
    _validate_date,
    _validate_month,
    cmd_add,
    cmd_ask,
    cmd_balance,
    cmd_budget,
    cmd_debt,
    cmd_export_csv,
    cmd_list,
    cmd_spending,
    cmd_subscriptions,
    cmd_summary,
    main,
)

# ── Helpers ───────────────────────────────────────────────────────────


def _make_args(**kwargs):
    """Build a simple namespace object mimicking argparse output."""
    return argparse.Namespace(**kwargs)


# ── _validate_date ────────────────────────────────────────────────────


class TestValidateDate:
    def test_valid_date_passes(self):
        """A well-formed, real date should not raise or exit."""
        _validate_date("2026-02-15", "--start")

    def test_none_is_allowed(self):
        """None is a no-op (optional flag not provided)."""
        _validate_date(None, "--start")

    def test_invalid_format_exits(self):
        """Non-YYYY-MM-DD format should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_date("02-15-2026", "--start")
        assert exc.value.code == 1

    def test_invalid_date_exits(self):
        """Correct format but impossible date (Feb 30) should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_date("2026-02-30", "--start")
        assert exc.value.code == 1

    def test_garbage_string_exits(self):
        """Completely non-date input should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_date("not-a-date", "--end")
        assert exc.value.code == 1

    def test_leap_day_valid(self):
        """Feb 29 on a leap year should pass."""
        _validate_date("2024-02-29", "--start")

    def test_leap_day_invalid_year(self):
        """Feb 29 on a non-leap year should exit."""
        with pytest.raises(SystemExit) as exc:
            _validate_date("2026-02-29", "--start")
        assert exc.value.code == 1


# ── _validate_month ───────────────────────────────────────────────────


class TestValidateMonth:
    def test_valid_month_passes(self):
        """A well-formed YYYY-MM value should not raise or exit."""
        _validate_month("2026-02")

    def test_none_is_allowed(self):
        """None is a no-op (optional flag not provided)."""
        _validate_month(None)

    def test_invalid_format_exits(self):
        """Non-YYYY-MM format should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_month("2026/02")
        assert exc.value.code == 1

    def test_month_13_exits(self):
        """Month 13 is out of range and should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_month("2026-13")
        assert exc.value.code == 1

    def test_month_00_exits(self):
        """Month 00 is out of range and should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            _validate_month("2026-00")
        assert exc.value.code == 1

    def test_full_date_format_exits(self):
        """YYYY-MM-DD should fail (too many characters for month)."""
        with pytest.raises(SystemExit) as exc:
            _validate_month("2026-02-15")
        assert exc.value.code == 1


# ── main() ────────────────────────────────────────────────────────────


class TestMain:
    def test_version_flag(self, capsys):
        """--version should print the version string and exit 0."""
        with pytest.raises(SystemExit) as exc:
            main(["--version"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert __version__ in captured.out

    def test_no_args_exits_nonzero(self):
        """No subcommand should exit with code 1 (our custom help exit)."""
        with pytest.raises(SystemExit) as exc:
            main([])
        assert exc.value.code == 1

    def test_help_flag(self, capsys):
        """--help should print usage information and exit 0."""
        with pytest.raises(SystemExit) as exc:
            main(["--help"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert "spendctl" in captured.out

    def test_init_calls_run_init(self):
        """spendctl init should call run_init from the wizard."""
        with patch("spendctl.cli.cmd_init") as mock_cmd:
            main(["init"])
            mock_cmd.assert_called_once()

    def test_config_show_calls_show_config(self):
        """spendctl config show should call show_config."""
        with patch("spendctl.init_wizard.show_config") as mock_show:
            main(["config", "show"])
            mock_show.assert_called_once()

    def test_config_edit_calls_edit_config(self):
        """spendctl config edit should call edit_config."""
        with patch("spendctl.init_wizard.edit_config") as mock_edit:
            main(["config", "edit"])
            mock_edit.assert_called_once()

    def test_config_reset_calls_reset_config(self):
        """spendctl config reset should call reset_config."""
        with patch("spendctl.init_wizard.reset_config") as mock_reset:
            main(["config", "reset"])
            mock_reset.assert_called_once()

    def test_config_no_subcommand_exits(self, capsys):
        """spendctl config with no subcommand should exit nonzero."""
        with pytest.raises(SystemExit) as exc:
            main(["config"])
        assert exc.value.code == 1


# ── Config guard ──────────────────────────────────────────────────────


class TestConfigGuard:
    """Commands (except init) should fail gracefully when config doesn't exist."""

    def _run_guarded(self, argv):
        """Run main() with a patched config_exists that returns False."""
        with patch("spendctl.cli.config_exists", return_value=False):
            with pytest.raises(SystemExit) as exc:
                main(argv)
            assert exc.value.code == 1

    def test_list_guard(self, capsys):
        self._run_guarded(["list"])
        assert "spendctl init" in capsys.readouterr().out

    def test_balance_guard(self, capsys):
        self._run_guarded(["balance"])
        assert "spendctl init" in capsys.readouterr().out

    def test_spending_guard(self, capsys):
        self._run_guarded(["spending"])
        assert "spendctl init" in capsys.readouterr().out

    def test_debt_guard(self, capsys):
        self._run_guarded(["debt"])
        assert "spendctl init" in capsys.readouterr().out

    def test_budget_guard(self, capsys):
        self._run_guarded(["budget"])
        assert "spendctl init" in capsys.readouterr().out

    def test_summary_guard(self, capsys):
        self._run_guarded(["summary"])
        assert "spendctl init" in capsys.readouterr().out

    def test_subscriptions_guard(self, capsys):
        self._run_guarded(["subscriptions"])
        assert "spendctl init" in capsys.readouterr().out

    def test_export_csv_guard(self, capsys):
        self._run_guarded(["export-csv"])
        assert "spendctl init" in capsys.readouterr().out


# ── cmd_list ──────────────────────────────────────────────────────────


class TestCmdList:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should produce valid JSON with the seeded transactions."""
        args = _make_args(
            command="list",
            start=None,
            end=None,
            category=None,
            type=None,
            account=None,
            description=None,
            limit=25,
            json=True,
        )
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_list(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)
        assert len(data) == 6  # conftest seeds 6 transactions

    def test_table_output(self, db, mock_config, capsys):
        """Default (non-JSON) output should print a header and transaction count."""
        args = _make_args(
            command="list",
            start=None,
            end=None,
            category=None,
            type=None,
            account=None,
            description=None,
            limit=25,
            json=False,
        )
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_list(args)

        captured = capsys.readouterr()
        assert "Date" in captured.out
        assert "6 transaction(s)" in captured.out

    def test_empty_result(self, db, mock_config, capsys):
        """Filtering to a nonexistent category should print 'No transactions found.'."""
        args = _make_args(
            command="list",
            start=None,
            end=None,
            category="Nonexistent",
            type=None,
            account=None,
            description=None,
            limit=25,
            json=False,
        )
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_list(args)

        captured = capsys.readouterr()
        assert "No transactions found." in captured.out


# ── cmd_add ───────────────────────────────────────────────────────────


class TestCmdAdd:
    def test_add_creates_transaction(self, db, mock_config, capsys):
        """add should insert a transaction and report its ID."""
        args = _make_args(
            command="add",
            date="2026-03-01",
            description="Test purchase",
            amount=42.00,
            type="Expense",
            from_account="Checking",
            to_account="External",
            category="Groceries",
            notes=None,
            json=False,
        )
        with patch("spendctl.cli.ensure_db", return_value=db), patch("spendctl.cli.backup"):
            cmd_add(args)

        captured = capsys.readouterr()
        assert "Added transaction" in captured.out
        assert "Test purchase" in captured.out

    def test_add_json_output(self, db, mock_config, capsys):
        """--json flag on add should return {id, status}."""
        args = _make_args(
            command="add",
            date="2026-03-01",
            description="JSON test",
            amount=10.00,
            type="Expense",
            from_account="Checking",
            to_account="External",
            category="Groceries",
            notes=None,
            json=True,
        )
        with patch("spendctl.cli.ensure_db", return_value=db), patch("spendctl.cli.backup"):
            cmd_add(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "id" in data
        assert data["status"] == "added"

    def test_add_uses_config_defaults_when_accounts_none(self, db, mock_config, capsys):
        """When from/to are None, cmd_add should resolve from config."""
        args = _make_args(
            command="add",
            date="2026-03-01",
            description="Default account test",
            amount=5.00,
            type="Expense",
            from_account=None,
            to_account=None,
            category="Groceries",
            notes=None,
            json=False,
        )
        with patch("spendctl.cli.ensure_db", return_value=db), patch("spendctl.cli.backup"):
            cmd_add(args)

        # from_account should have been resolved from config (first checking account = "Checking")
        assert args.from_account is not None
        assert args.to_account is not None
        captured = capsys.readouterr()
        assert "Added transaction" in captured.out


# ── cmd_balance ───────────────────────────────────────────────────────


class TestCmdBalance:
    def test_all_accounts(self, db, mock_config, capsys):
        """No account arg should print a table with all accounts."""
        args = _make_args(command="balance", account=None, json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_balance(args)

        captured = capsys.readouterr()
        assert "Account" in captured.out
        assert "Balance" in captured.out
        assert "Checking" in captured.out

    def test_specific_account(self, db, mock_config, capsys):
        """Providing a specific account should print only that account's balance."""
        args = _make_args(command="balance", account="Checking", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_balance(args)

        captured = capsys.readouterr()
        assert "Checking" in captured.out
        assert "$" in captured.out

    def test_specific_account_json(self, db, mock_config, capsys):
        """JSON output for a specific account should include account and balance keys."""
        args = _make_args(command="balance", account="Checking", json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_balance(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["account"] == "Checking"
        assert isinstance(data["balance"], (int, float))

    def test_all_accounts_json(self, db, mock_config, capsys):
        """--json with no account should return a dict of balances."""
        args = _make_args(command="balance", account=None, json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_balance(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, dict)
        assert "Checking" in data

    def test_unknown_account_exits(self, db, mock_config):
        """An unrecognized account name should sys.exit(1)."""
        args = _make_args(command="balance", account="FakeBank", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            with pytest.raises(SystemExit) as exc:
                cmd_balance(args)
            assert exc.value.code == 1


# ── cmd_spending ──────────────────────────────────────────────────────


class TestCmdSpending:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should return a list of category spending data."""
        args = _make_args(command="spending", month="2026-02", json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_spending(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)

    def test_table_output(self, db, mock_config, capsys):
        """Table output should show category column headers."""
        args = _make_args(command="spending", month="2026-02", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_spending(args)

        captured = capsys.readouterr()
        assert "Category" in captured.out or "No spending data" in captured.out


# ── cmd_debt ─────────────────────────────────────────────────────────


class TestCmdDebt:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should return debt progress dict."""
        args = _make_args(command="debt", json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_debt(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, dict)

    def test_table_output(self, db, mock_config, capsys):
        """Table output should include Debt Progress header."""
        args = _make_args(command="debt", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_debt(args)

        captured = capsys.readouterr()
        assert "Debt Progress" in captured.out


# ── cmd_budget ───────────────────────────────────────────────────────


class TestCmdBudget:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should return budget vs actual list."""
        args = _make_args(command="budget", month="2026-02", json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_budget(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)

    def test_table_output(self, db, mock_config, capsys):
        """Table output should show Budget vs Actual header."""
        args = _make_args(command="budget", month="2026-02", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_budget(args)

        captured = capsys.readouterr()
        assert "Budget vs Actual" in captured.out


# ── cmd_summary ──────────────────────────────────────────────────────


class TestCmdSummary:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should return a summary dict."""
        args = _make_args(command="summary", month="2026-02", json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_summary(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, dict)
        assert "income" in data

    def test_table_output(self, db, mock_config, capsys):
        """Table output should show Monthly Summary header."""
        args = _make_args(command="summary", month="2026-02", json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_summary(args)

        captured = capsys.readouterr()
        assert "Monthly Summary" in captured.out


# ── cmd_subscriptions ────────────────────────────────────────────────


class TestCmdSubscriptions:
    def test_json_output(self, db, mock_config, capsys):
        """--json flag should return subscriptions and monthly total."""
        args = _make_args(command="subscriptions", status=None, json=True)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_subscriptions(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "subscriptions" in data
        assert "active_monthly_total" in data
        assert isinstance(data["subscriptions"], list)

    def test_table_output(self, db, mock_config, capsys):
        """Table output should list subscription names."""
        args = _make_args(command="subscriptions", status=None, json=False)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_subscriptions(args)

        captured = capsys.readouterr()
        assert "Active monthly total" in captured.out


# ── cmd_export_csv ────────────────────────────────────────────────────


class TestCmdExportCsv:
    def test_stdout_output(self, db, mock_config, capsys):
        """With no --output flag, CSV should be printed to stdout."""
        args = _make_args(command="export-csv", output=None)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_export_csv(args)

        captured = capsys.readouterr()
        lines = captured.out.strip().split("\n")
        # Header + 6 data rows
        assert len(lines) == 7
        header = lines[0]
        assert "date" in header
        assert "amount_usd" in header

    def test_no_eur_amount_column(self, db, mock_config, capsys):
        """CSV output should NOT include eur_amount column."""
        args = _make_args(command="export-csv", output=None)
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_export_csv(args)

        captured = capsys.readouterr()
        header = captured.out.strip().split("\n")[0]
        assert "eur_amount" not in header

    def test_file_output(self, db, mock_config, tmp_path, capsys):
        """With --output, CSV should be written to the specified file."""
        out_file = tmp_path / "export.csv"
        args = _make_args(command="export-csv", output=str(out_file))
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_export_csv(args)

        assert out_file.exists()
        content = out_file.read_text()
        lines = content.strip().split("\n")
        assert len(lines) == 7  # header + 6 rows

        captured = capsys.readouterr()
        assert "Exported 6 transactions" in captured.out

    def test_file_output_no_eur_amount(self, db, mock_config, tmp_path):
        """CSV file output should not have eur_amount column."""
        out_file = tmp_path / "export.csv"
        args = _make_args(command="export-csv", output=str(out_file))
        with patch("spendctl.cli.ensure_db", return_value=db):
            cmd_export_csv(args)

        header = out_file.read_text().split("\n")[0]
        assert "eur_amount" not in header


# ── cmd_ask ───────────────────────────────────────────────────────────


class TestCmdAsk:
    def test_ask_no_config_exits(self, capsys):
        """cmd_ask exits with helpful message when config doesn't exist."""
        args = _make_args(command="ask", question="Am I on budget?")
        with (
            patch("spendctl.cli.config_exists", return_value=False),
            pytest.raises(SystemExit) as exc,
        ):
            cmd_ask(args)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "spendctl init" in captured.out

    def test_ask_no_ai_config_exits(self, db, mock_config, capsys):
        """cmd_ask exits with helpful message when ai config is missing."""
        args = _make_args(command="ask", question="What's my net worth?")
        with (
            patch("spendctl.cli.config_exists", return_value=True),
            patch("spendctl.config.get_ai_config", return_value={}),
            pytest.raises(SystemExit) as exc,
        ):
            cmd_ask(args)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "config edit" in captured.out or "Ollama" in captured.out

    def test_ask_no_model_in_ai_config_exits(self, db, mock_config, capsys):
        """cmd_ask exits when ai config exists but model key is missing."""
        args = _make_args(command="ask", question="What's my net worth?")
        with (
            patch("spendctl.cli.config_exists", return_value=True),
            patch("spendctl.config.get_ai_config", return_value={"endpoint": "http://localhost:11434"}),
            pytest.raises(SystemExit) as exc,
        ):
            cmd_ask(args)
        assert exc.value.code == 1

    def test_ask_with_config_sends_correct_payload(self, db, mock_config, capsys):
        """cmd_ask sends a well-formed request to Ollama and prints the response."""
        fake_response_data = json.dumps({"response": "You are doing great!"}).encode()
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read = MagicMock(return_value=fake_response_data)

        args = _make_args(command="ask", question="How am I doing?")
        with (
            patch("spendctl.cli.config_exists", return_value=True),
            patch("spendctl.config.get_ai_config", return_value={"model": "llama3.2", "endpoint": "http://localhost:11434"}),
            patch("spendctl.cli.ensure_db", return_value=db),
            patch("urllib.request.urlopen", return_value=mock_resp) as mock_open,
        ):
            cmd_ask(args)

        captured = capsys.readouterr()
        assert "You are doing great!" in captured.out
        # Verify the request was made
        mock_open.assert_called_once()
        req = mock_open.call_args[0][0]
        body = json.loads(req.data.decode())
        assert body["model"] == "llama3.2"
        assert "How am I doing?" in body["prompt"]
        assert body["stream"] is False

    def test_ask_connection_error(self, db, mock_config, capsys):
        """cmd_ask prints a helpful error when Ollama is unreachable."""
        args = _make_args(command="ask", question="test question")
        with (
            patch("spendctl.cli.config_exists", return_value=True),
            patch("spendctl.config.get_ai_config", return_value={"model": "llama3.2", "endpoint": "http://localhost:11434"}),
            patch("spendctl.cli.ensure_db", return_value=db),
            patch("urllib.request.urlopen", side_effect=urllib.error.URLError("Connection refused")),
            pytest.raises(SystemExit) as exc,
        ):
            cmd_ask(args)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "Could not connect" in captured.out or "Ollama" in captured.out

    def test_ask_main_dispatch(self, capsys):
        """main(['ask', 'question']) dispatches to cmd_ask."""
        with patch("spendctl.cli.cmd_ask") as mock_cmd:
            main(["ask", "how am I doing?"])
            mock_cmd.assert_called_once()
