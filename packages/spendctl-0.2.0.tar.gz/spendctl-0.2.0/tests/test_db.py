"""Tests for spendctl.db — connection setup, schema initialization, and backup."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from spendctl.db import backup, get_connection, init_db

# ── init_db ───────────────────────────────────────────────────────────


class TestInitDb:
    def test_creates_expected_tables(self, mock_config):
        """init_db should create all core tables defined in the schema."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }

        expected = {
            "accounts",
            "categories",
            "transaction_types",
            "transactions",
            "check_ins",
            "check_in_balances",
            "subscriptions",
            "budget_income",
            "settings",
        }
        assert expected.issubset(tables), f"Missing tables: {expected - tables}"
        conn.close()

    def test_no_debt_plan_table(self, mock_config):
        """spendctl schema should NOT have a debt_plan table (removed)."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert "debt_plan" not in tables
        conn.close()

    def test_creates_views(self, mock_config):
        """init_db should create the expected views."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        views = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='view'"
            ).fetchall()
        }

        assert "v_monthly_expenses" in views
        # v_check_in_computed is removed in spendctl
        assert "v_check_in_computed" not in views
        conn.close()

    def test_creates_indexes(self, mock_config):
        """init_db should create indexes on core tables including normalized check-in indexes."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        indexes = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }

        assert "idx_tx_date" in indexes
        assert "idx_tx_category" in indexes
        assert "idx_cib_checkin" in indexes
        assert "idx_cib_account" in indexes
        conn.close()

    def test_idempotent(self, mock_config):
        """Calling init_db twice on the same connection should not error or duplicate data."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row

        init_db(conn)
        count_first = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]

        init_db(conn)
        count_second = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]

        assert count_first == count_second
        assert count_first > 0
        conn.close()

    def test_seeds_accounts(self, mock_config):
        """init_db should populate accounts from config."""
        import spendctl.config as cfg

        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        count = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        assert count == len(cfg.get_accounts())
        conn.close()

    def test_seeds_categories(self, mock_config):
        """init_db should populate categories from config."""
        import spendctl.config as cfg

        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        count = conn.execute("SELECT COUNT(*) FROM categories").fetchone()[0]
        assert count == len(cfg.get_categories())
        conn.close()

    def test_seeds_transaction_types(self, mock_config):
        """init_db should populate the transaction_types table."""
        from spendctl.config import TRANSACTION_TYPES

        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        count = conn.execute("SELECT COUNT(*) FROM transaction_types").fetchone()[0]
        assert count == len(TRANSACTION_TYPES)
        conn.close()

    def test_seeds_budget_income(self, mock_config):
        """init_db should populate budget_income from config income sources."""
        import spendctl.config as cfg

        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        count = conn.execute("SELECT COUNT(*) FROM budget_income").fetchone()[0]
        assert count == len(cfg.get_income_sources())
        conn.close()

    def test_transactions_no_eur_amount_column(self, mock_config):
        """The transactions table should NOT have an eur_amount column."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        cols = {row[1] for row in conn.execute("PRAGMA table_info(transactions)").fetchall()}
        assert "eur_amount" not in cols
        conn.close()

    def test_student_loan_account_type_allowed(self, mock_config):
        """Accounts table should allow student_loan type."""
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        init_db(conn)

        # Student Loans account should have been seeded from config
        row = conn.execute("SELECT type FROM accounts WHERE name = 'Student Loans'").fetchone()
        assert row is not None
        assert row["type"] == "student_loan"
        conn.close()


# ── get_connection ────────────────────────────────────────────────────


class TestGetConnection:
    def test_returns_connection(self, tmp_path, mock_config):
        """get_connection should return a sqlite3.Connection."""
        db_path = tmp_path / "test.db"
        conn = get_connection(db_path)
        assert isinstance(conn, sqlite3.Connection)
        conn.close()

    def test_row_factory_is_row(self, tmp_path, mock_config):
        """get_connection should set row_factory to sqlite3.Row."""
        db_path = tmp_path / "test.db"
        conn = get_connection(db_path)
        assert conn.row_factory is sqlite3.Row
        conn.close()

    def test_wal_mode_enabled(self, tmp_path, mock_config):
        """get_connection should enable WAL journal mode."""
        db_path = tmp_path / "test.db"
        conn = get_connection(db_path)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        assert mode == "wal"
        conn.close()

    def test_foreign_keys_enabled(self, tmp_path, mock_config):
        """get_connection should enable foreign key enforcement."""
        db_path = tmp_path / "test.db"
        conn = get_connection(db_path)
        fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
        assert fk == 1
        conn.close()


# ── backup ────────────────────────────────────────────────────────────


class TestBackup:
    def test_creates_backup_file(self, tmp_path, mock_config):
        """backup() should create a non-empty backup file."""
        source = tmp_path / "spendctl.db"
        conn = sqlite3.connect(str(source))
        conn.execute("CREATE TABLE test (id INTEGER PRIMARY KEY)")
        conn.execute("INSERT INTO test VALUES (1)")
        conn.commit()
        conn.close()

        backup_dir = tmp_path / "backups"
        with patch("spendctl.db.config") as mock_cfg:
            mock_cfg.DB_PATH = source
            mock_cfg.BACKUP_DIR = backup_dir
            dest = backup(db_path=source)

        assert dest.exists()
        assert dest.stat().st_size > 0
        assert "spendctl-BACKUP-" in dest.name

    def test_source_not_found_raises(self, tmp_path, mock_config):
        """backup() should raise FileNotFoundError if the source DB doesn't exist."""
        fake_path = tmp_path / "nonexistent.db"
        with pytest.raises(FileNotFoundError):
            backup(db_path=fake_path)

    def test_same_day_duplicate_gets_timestamp(self, tmp_path, mock_config):
        """A second backup on the same day should include a time suffix."""
        source = tmp_path / "spendctl.db"
        conn = sqlite3.connect(str(source))
        conn.execute("CREATE TABLE test (id INTEGER PRIMARY KEY)")
        conn.execute("INSERT INTO test VALUES (1)")
        conn.commit()
        conn.close()

        backup_dir = tmp_path / "backups"
        with patch("spendctl.db.config") as mock_cfg:
            mock_cfg.DB_PATH = source
            mock_cfg.BACKUP_DIR = backup_dir
            first = backup(db_path=source)
            second = backup(db_path=source)

        assert first != second
        assert first.exists()
        assert second.exists()
        assert "-" in second.stem.split("BACKUP-")[1]

    def test_suspiciously_small_backup_raises(self, tmp_path, mock_config):
        """backup() should raise RuntimeError when the backup is much smaller than the source."""
        source = tmp_path / "spendctl.db"
        conn = sqlite3.connect(str(source))
        conn.execute("CREATE TABLE big (data TEXT)")
        conn.execute("INSERT INTO big VALUES (?)", ("x" * 10000,))
        conn.commit()
        conn.close()

        backup_dir = tmp_path / "backups"
        backup_dir.mkdir()

        def fake_copy2(src, dst):
            Path(dst).write_text("tiny")

        with (
            patch("spendctl.db.config") as mock_cfg,
            patch("spendctl.db.shutil.copy2", fake_copy2),
            pytest.raises(RuntimeError, match="suspiciously small"),
        ):
            mock_cfg.DB_PATH = source
            mock_cfg.BACKUP_DIR = backup_dir
            backup(db_path=source)
