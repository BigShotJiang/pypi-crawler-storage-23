from pythonanywhere_briefcase_plugin.channel import PythonAnywherePublicationChannel

__version__ = "0.0.1a4"
__all__ = ["PythonAnywherePublicationChannel"]
