"""Ecommerce relevance rubric for LLM judgment."""

from veritail.rubrics.ecommerce_default import SYSTEM_PROMPT, format_user_prompt

__all__ = ["SYSTEM_PROMPT", "format_user_prompt"]
