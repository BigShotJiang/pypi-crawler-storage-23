# Package marker for importlib.resources
