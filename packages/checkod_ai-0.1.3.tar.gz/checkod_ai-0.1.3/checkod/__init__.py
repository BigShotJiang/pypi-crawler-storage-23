"""
AI Impact Assessment Agent - Local-first tool for analyzing code changes.
"""

__version__ = "0.1.1"
__author__ = "Anup Moncy"

from checkod.agent import run_agent

__all__ = ["run_agent"]
