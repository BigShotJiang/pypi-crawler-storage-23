"""
Main CLI entry point for CheckodAI.
"""

import typer
import warnings
from typing import Optional


warnings.filterwarnings(
    "ignore",
    message=r"urllib3 v2 only supports OpenSSL.*",
)

app = typer.Typer(
    name="checkod",
    help="CheckodAI - AI Impact Assessment for code changes.",
)



@app.command()
def assess(
    repo_path: Optional[str] = typer.Option(
        ".",
        "--repo",
        "-r",
        help="Path to the git repository to analyze",
    ),
    diff_range: Optional[str] = typer.Option(
        None,
        "--range",
        help="Git revision range (e.g. HEAD~1..HEAD)",
    ),
    include_untracked: bool = typer.Option(
        True,
        "--include-untracked/--no-include-untracked",
        help="Include untracked files in the diff",
    ),
) -> None:
    """
    Assess the impact of changes in the repository (no AI).
    
    Reads git diff, detects changed symbols, and prints a summary.
    Does NOT use AI risk assessment (Ollama is never called).
    """
    from checkod.agent import run_agent

    exit_code = run_agent(
        repo_path=repo_path,
        enable_risk_assessment=False,
        diff_range=diff_range,
        include_untracked=include_untracked,
    )
    
    if exit_code == 0:
        typer.echo("\n✅ Assessment complete!")
    else:
        raise typer.Exit(code=exit_code)


@app.command()
def assess_ai(
    repo_path: Optional[str] = typer.Option(
        ".",
        "--repo",
        "-r",
        help="Path to the git repository to analyze",
    ),
    diff_range: Optional[str] = typer.Option(
        None,
        "--range",
        help="Git revision range (e.g. HEAD~1..HEAD)",
    ),
    include_untracked: bool = typer.Option(
        True,
        "--include-untracked/--no-include-untracked",
        help="Include untracked files in the diff",
    ),
) -> None:
    """
    Assess the impact of changes in the repository, with AI risk assessment (Ollama).
    
    Reads git diff, detects changed symbols, and prints a summary.
    Uses AI risk assessment if Ollama is available.
    """
    from checkod.agent import run_agent

    exit_code = run_agent(
        repo_path=repo_path,
        enable_risk_assessment=True,
        diff_range=diff_range,
        include_untracked=include_untracked,
    )
    
    if exit_code == 0:
        typer.echo("\n✅ Assessment complete!")
    else:
        raise typer.Exit(code=exit_code)


@app.command()
def version() -> None:
    """Show version information."""
    from checkod import __version__
    typer.echo(f"impact-agent v{__version__}")


if __name__ == "__main__":
    app()
