"""
Guard module for commit safety.

Provides advisory warnings for high-impact changes,
alerting developers to critical system behavior modifications.
"""


def should_warn_commit(risk_level: str) -> bool:
    """
    Determine if commit should trigger a warning based on risk level.

    Args:
        risk_level: The risk level classification ("HIGH", "MEDIUM", "LOW")

    Returns:
        True if HIGH risk and should warn, False otherwise
    """
    return risk_level == "HIGH"
