"""
Observe module - reads git diff from the repository.
"""

from typing import Optional, List
import os
from git import Repo
from git.exc import InvalidGitRepositoryError


def get_diff(
    repo_path: str = ".",
    diff_range: Optional[str] = None,
    include_untracked: bool = True,
) -> Optional[str]:
    """
    Get the git diff from the repository.
    
    Compares the working directory against HEAD to detect changes.
    
    Args:
        repo_path: Path to the git repository
        diff_range: Optional git revision range (e.g. HEAD~1..HEAD)
        include_untracked: Include untracked files in the diff
        
    Returns:
        Git diff as a string, or None if no changes or error occurred
        
    Raises:
        InvalidGitRepositoryError: If the path is not a valid git repository
    """
    try:
        repo = Repo(repo_path)
        
        diff = ""

        if diff_range:
            diff = repo.git.diff(diff_range)
        else:
            # Get diff of unstaged changes
            diff = repo.git.diff()

            # If no unstaged changes, check staged changes
            if not diff:
                diff = repo.git.diff("--cached")

            # If still no diff, include untracked files
            if not diff and include_untracked:
                diff = _diff_untracked_files(repo)

        return diff if diff else None
        
    except InvalidGitRepositoryError:
        raise InvalidGitRepositoryError(
            f"'{repo_path}' is not a valid git repository"
        )
    except Exception as e:
        raise Exception(f"Failed to read git diff: {str(e)}")


def _diff_untracked_files(repo: Repo) -> str:
    working_dir = repo.working_tree_dir or "."
    diffs: List[str] = []

    for rel_path in repo.untracked_files:
        abs_path = os.path.join(working_dir, rel_path)
        try:
            diff_output = repo.git.diff("--no-index", "--", "/dev/null", abs_path)
            if diff_output:
                diffs.append(diff_output)
        except Exception:
            continue

    return "\n".join(diffs)
