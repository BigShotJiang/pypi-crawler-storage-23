from setuptools import setup, find_packages

setup(
    name="hello_world_test_raunak7",
    version="0.0.2",
    author="Test Author",
    author_email="test@example.com",
    description="A minimal hello world package for testing PyPI publishing",
    url="https://github.com/test/hello-world-test-pkg",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
