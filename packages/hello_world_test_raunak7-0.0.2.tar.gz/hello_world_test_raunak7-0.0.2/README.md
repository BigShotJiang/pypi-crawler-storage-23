# Hello World Test Package

A minimal Python package for testing PyPI publishing workflows.

## Installation

```bash
pip install hello-world-test-pkg
```

## Usage

```python
from hello_world_test_pkg import hello

hello.greet()
```
