def greet():
    """Print a hello world message."""
    print("Hello, World from test package!")
    return "Hello, World!"
