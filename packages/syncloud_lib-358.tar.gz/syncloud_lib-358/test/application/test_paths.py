from syncloudlib.application.paths import get_app_dir, get_data_dir


def test_import():
    assert True