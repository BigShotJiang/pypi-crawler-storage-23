# memsearch-cursor

Fork of [memsearch](https://github.com/zilliztech/memsearch) with Cursor IDE transcript support.

## Changes from upstream memsearch

- `memsearch-cursor transcript` supports both Claude Code and Cursor IDE JSONL formats (auto-detected)
- CLI command is `memsearch-cursor` (instead of `memsearch`)

## Installation

```shell
pip install memsearch-cursor
# or
uvx memsearch-cursor
```

All other commands and features are identical to upstream memsearch.
