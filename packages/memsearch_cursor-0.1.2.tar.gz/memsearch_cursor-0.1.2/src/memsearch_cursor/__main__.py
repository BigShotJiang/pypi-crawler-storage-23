"""Allow running memsearch-cursor as ``python -m memsearch_cursor``."""

from memsearch_cursor.cli import cli

cli()
