"""memsearch-cursor — semantic memory search for Cursor IDE."""

from .core import MemSearch

__all__ = ["MemSearch"]
