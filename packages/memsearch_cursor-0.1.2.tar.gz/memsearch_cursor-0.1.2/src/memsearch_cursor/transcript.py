"""Parse JSONL transcripts for progressive memory disclosure.

Supports both Claude Code and Cursor IDE transcript formats.
Format is auto-detected from the first entry's keys.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Turn:
    """A single conversation turn extracted from a JSONL transcript."""

    uuid: str
    timestamp: str
    role: str  # "user" or "assistant"
    content: str
    tool_calls: list[str] = field(default_factory=list)
    line_index: int = 0


def _detect_format(entries: list[dict[str, Any]]) -> str:
    """Auto-detect JSONL format from the first entry's keys.

    Returns "claude" for Claude Code, "cursor" for Cursor IDE, or "unknown".
    """
    for entry in entries:
        if "type" in entry and entry["type"] in ("user", "assistant"):
            return "claude"
        if "role" in entry and "type" not in entry:
            return "cursor"
    return "unknown"


def _extract_text_from_blocks(content: list[dict[str, Any]]) -> str:
    """Extract concatenated text from a list of content blocks."""
    parts = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text", "").strip()
            if text:
                parts.append(text)
    return "\n\n".join(parts)


def _parse_cursor(entries: list[dict[str, Any]]) -> list[Turn]:
    """Parse Cursor IDE JSONL entries into conversation turns.

    Cursor format: {role: "user"|"assistant", message: {content: [{type: "text", text: "..."}]}}
    No uuid or timestamp fields — line index is used as a synthetic identifier.
    """
    turns: list[Turn] = []
    current_turn: Turn | None = None

    for entry in entries:
        role = entry.get("role", "")
        msg = entry.get("message", {})
        content_blocks = msg.get("content", [])
        line_idx = entry.get("_line_index", 0)

        if not isinstance(content_blocks, list):
            continue

        if role == "user":
            raw_text = _extract_text_from_blocks(content_blocks)
            if not raw_text:
                continue
            clean = _strip_cursor_tags(raw_text)
            if not clean:
                continue
            if current_turn is not None:
                turns.append(current_turn)
            current_turn = Turn(
                uuid=f"L{line_idx}",
                timestamp="",
                role="user",
                content=clean,
                line_index=line_idx,
            )

        elif role == "assistant" and current_turn is not None:
            text = _extract_text_from_blocks(content_blocks)
            if text:
                if current_turn.role == "user":
                    current_turn.content += f"\n\n**Assistant**: {text}"
                else:
                    current_turn.content += f"\n{text}"

    if current_turn is not None:
        turns.append(current_turn)

    return turns


def _parse_claude(entries: list[dict[str, Any]]) -> list[Turn]:
    """Parse Claude Code JSONL entries into conversation turns (original logic)."""
    turns: list[Turn] = []
    current_turn: Turn | None = None

    for entry in entries:
        entry_type = entry.get("type", "")

        if entry_type == "user":
            msg = entry.get("message", {})
            content = msg.get("content", "")

            if isinstance(content, list):
                if content and isinstance(content[0], dict) and content[0].get("type") == "tool_result":
                    continue

            if isinstance(content, str) and content.strip():
                clean = _strip_hook_tags(content)
                if not clean:
                    continue
                if current_turn is not None:
                    turns.append(current_turn)
                current_turn = Turn(
                    uuid=entry.get("uuid", ""),
                    timestamp=entry.get("timestamp", ""),
                    role="user",
                    content=clean,
                    line_index=entry.get("_line_index", 0),
                )

        elif entry_type == "assistant" and current_turn is not None:
            msg = entry.get("message", {})
            content_blocks = msg.get("content", [])
            if not isinstance(content_blocks, list):
                continue

            for block in content_blocks:
                if not isinstance(block, dict):
                    continue
                block_type = block.get("type", "")

                if block_type == "text":
                    text = block.get("text", "").strip()
                    if text:
                        if current_turn.role == "user":
                            current_turn.content += f"\n\n**Assistant**: {text}"
                        else:
                            current_turn.content += f"\n{text}"

                elif block_type == "tool_use":
                    name = block.get("name", "unknown")
                    tool_input = block.get("input", {})
                    summary = _summarize_tool_input(name, tool_input)
                    current_turn.tool_calls.append(summary)

    if current_turn is not None:
        turns.append(current_turn)

    return turns


def parse_transcript(path: str | Path) -> list[Turn]:
    """Parse a JSONL transcript into a list of conversation turns.

    Auto-detects format (Claude Code vs Cursor IDE) and dispatches
    to the appropriate parser.
    """
    path = Path(path)
    if not path.exists():
        return []

    entries: list[dict[str, Any]] = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                obj["_line_index"] = i
                entries.append(obj)
            except json.JSONDecodeError:
                continue

    fmt = _detect_format(entries)
    if fmt == "cursor":
        return _parse_cursor(entries)
    elif fmt == "claude":
        return _parse_claude(entries)
    else:
        return _parse_cursor(entries) or _parse_claude(entries)


def find_turn_context(
    turns: list[Turn],
    target_uuid: str,
    context: int = 3,
) -> tuple[list[Turn], int]:
    """Find a turn by UUID (or line-based ID) and return surrounding context turns."""
    target_idx = -1
    for i, turn in enumerate(turns):
        if turn.uuid.startswith(target_uuid) or target_uuid.startswith(turn.uuid[:8]):
            target_idx = i
            break

    if target_idx == -1:
        return [], -1

    start = max(0, target_idx - context)
    end = min(len(turns), target_idx + context + 1)
    return turns[start:end], target_idx - start


def format_turns(turns: list[Turn], highlight_idx: int = -1) -> str:
    """Format turns into readable text output."""
    lines: list[str] = []
    for i, turn in enumerate(turns):
        marker = ">>> " if i == highlight_idx else ""
        ts = _extract_time(turn.timestamp) if turn.timestamp else f"#{turn.line_index}"
        lines.append(f"{marker}[{ts}] {turn.uuid[:8]}")
        lines.append(turn.content)
        if turn.tool_calls:
            lines.append(f"  Tools: {', '.join(turn.tool_calls)}")
        lines.append("")
    return "\n".join(lines)


def format_turn_index(turns: list[Turn]) -> str:
    """Format a compact index of all turns."""
    lines: list[str] = []
    for turn in turns:
        ts = _extract_time(turn.timestamp) if turn.timestamp else f"#{turn.line_index}"
        preview = turn.content[:80].replace("\n", " ")
        n_tools = len(turn.tool_calls)
        tool_info = f" [{n_tools} tools]" if n_tools else ""
        lines.append(f"  {turn.uuid[:12]:12s}  {ts:8s}  {preview}{tool_info}")
    return "\n".join(lines)


def turns_to_dicts(turns: list[Turn]) -> list[dict[str, Any]]:
    """Convert turns to JSON-serializable dicts."""
    return [
        {
            "uuid": t.uuid,
            "timestamp": t.timestamp,
            "content": t.content,
            "tool_calls": t.tool_calls,
            "line_index": t.line_index,
        }
        for t in turns
    ]


# -- Helpers --


def _strip_hook_tags(text: str) -> str:
    """Remove hook-injected XML tags from Claude Code user messages."""
    text = re.sub(r"<system-reminder>.*?</system-reminder>", "", text, flags=re.DOTALL)
    text = re.sub(r"<local-command-\w+>.*?</local-command-\w+>", "", text, flags=re.DOTALL)
    text = re.sub(r"<command-\w+>.*?</command-\w+>", "", text, flags=re.DOTALL)
    return text.strip()


def _strip_cursor_tags(text: str) -> str:
    """Remove Cursor-injected XML tags from user messages."""
    text = re.sub(r"<user_query>\s*", "", text, flags=re.DOTALL)
    text = re.sub(r"\s*</user_query>", "", text, flags=re.DOTALL)
    text = re.sub(r"<user_info>.*?</user_info>", "", text, flags=re.DOTALL)
    text = re.sub(r"<system_reminder>.*?</system_reminder>", "", text, flags=re.DOTALL)
    text = re.sub(r"<attached_files>.*?</attached_files>", "", text, flags=re.DOTALL)
    text = re.sub(r"<rules>.*?</rules>", "", text, flags=re.DOTALL)
    text = re.sub(r"<agent_skills>.*?</agent_skills>", "", text, flags=re.DOTALL)
    text = re.sub(r"<agent_transcripts>.*?</agent_transcripts>", "", text, flags=re.DOTALL)
    return text.strip()


def _extract_time(ts: str) -> str:
    """Extract HH:MM:SS from ISO timestamp."""
    if "T" in ts:
        time_part = ts.split("T")[1]
        return time_part[:8]
    return ts[:8] if len(ts) >= 8 else ts


def _summarize_tool_input(name: str, tool_input: dict) -> str:
    """Create a short summary of a tool call."""
    if name == "Bash":
        cmd = str(tool_input.get("command", ""))[:80]
        return f"Bash({cmd})"
    elif name == "Read":
        return f"Read({tool_input.get('file_path', '')})"
    elif name == "Edit":
        return f"Edit({tool_input.get('file_path', '')})"
    elif name == "Write":
        return f"Write({tool_input.get('file_path', '')})"
    elif name in ("Grep", "Glob"):
        pattern = tool_input.get("pattern", "")[:60]
        return f"{name}({pattern})"
    elif name == "Task":
        desc = tool_input.get("description", "")[:60]
        return f"Task({desc})"
    elif name == "WebSearch":
        query = tool_input.get("query", "")[:60]
        return f"WebSearch({query})"
    else:
        if tool_input:
            first_key = next(iter(tool_input))
            first_val = str(tool_input[first_key])[:60]
            return f"{name}({first_key}={first_val})"
        return name
