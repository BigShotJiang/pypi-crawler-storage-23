"""Embedding providers — protocol, factory, and concrete implementations."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class EmbeddingProvider(Protocol):
    """Minimal interface every embedding backend must satisfy."""

    @property
    def model_name(self) -> str: ...

    @property
    def dimension(self) -> int: ...

    async def embed(self, texts: list[str]) -> list[list[float]]: ...


# Provider registry: name -> (module_path, class_name)
_PROVIDERS: dict[str, tuple[str, str]] = {
    "openai": ("memsearch_cursor.embeddings.openai", "OpenAIEmbedding"),
    "google": ("memsearch_cursor.embeddings.google", "GoogleEmbedding"),
    "voyage": ("memsearch_cursor.embeddings.voyage", "VoyageEmbedding"),
    "ollama": ("memsearch_cursor.embeddings.ollama", "OllamaEmbedding"),
    "local": ("memsearch_cursor.embeddings.local", "LocalEmbedding"),
}

# Default model for each provider (mirrors the __init__ defaults in each class).
# Kept here so callers can resolve the effective model without importing heavy deps.
DEFAULT_MODELS: dict[str, str] = {
    "openai": "text-embedding-3-small",
    "google": "gemini-embedding-001",
    "voyage": "voyage-3-lite",
    "ollama": "nomic-embed-text",
    "local": "all-MiniLM-L6-v2",
}

_INSTALL_HINTS: dict[str, str] = {
    "openai": 'pip install memsearch-cursor  (or: uv add memsearch-cursor)',
    "google": 'pip install "memsearch-cursor[google]"  (or: uv add "memsearch-cursor[google]")',
    "voyage": 'pip install "memsearch-cursor[voyage]"  (or: uv add "memsearch-cursor[voyage]")',
    "ollama": 'pip install "memsearch-cursor[ollama]"  (or: uv add "memsearch-cursor[ollama]")',
    "local": 'pip install "memsearch-cursor[local]"  (or: uv add "memsearch-cursor[local]")',
}


def get_provider(
    name: str = "openai",
    *,
    model: str | None = None,
    batch_size: int = 0,
) -> EmbeddingProvider:
    """Instantiate an embedding provider by name.

    Parameters
    ----------
    name:
        One of "openai", "google", "voyage", "ollama", "local".
    model:
        Override the default model for the provider.
    batch_size:
        Maximum number of texts per embedding API call.
        ``0`` means use the provider's built-in default.
    """
    if name not in _PROVIDERS:
        raise ValueError(
            f"Unknown embedding provider {name!r}. "
            f"Available: {', '.join(sorted(_PROVIDERS))}"
        )

    module_path, class_name = _PROVIDERS[name]
    try:
        import importlib

        mod = importlib.import_module(module_path)
    except ImportError as exc:
        hint = _INSTALL_HINTS.get(name, "")
        raise ImportError(
            f"Embedding provider {name!r} requires extra dependencies. "
            f"Install with: {hint}"
        ) from exc

    cls = getattr(mod, class_name)
    kwargs: dict = {}
    if model is not None:
        kwargs["model"] = model
    if batch_size > 0:
        kwargs["batch_size"] = batch_size
    return cls(**kwargs)


__all__ = ["DEFAULT_MODELS", "EmbeddingProvider", "get_provider"]
