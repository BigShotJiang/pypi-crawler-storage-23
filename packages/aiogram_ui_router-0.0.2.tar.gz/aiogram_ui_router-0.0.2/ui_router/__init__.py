"""
UI Router - декларативный роутер для aiogram 3
"""

from .schema import (
    UIRouter,
    Scene,
    Handler,
    GlobalHandler,
    ActionInstruction,
    ActionType,
    EventType,
    TransitionType,
    MessageContent,
    Keyboard,
    Button,
    # Dynamic Keyboards
    DynamicKeyboard,
    ButtonTemplate,
    PaginationConfig,
    # Fallback
    FallbackConfig,
    # Other
    Filter,
    Flag,
    FlagGetter,
    DynamicContent,
    ContentTemplate,
    LocalizedContent,
    LocalizedTemplate,
    MediaContent,
    CallbackDataStrategy,
    NavigationConfig,
    # Variables & Rule Engine
    BotVariable,
    VariableScope,
    VariableType,
    ConditionalFlag,
    ConditionalContent,
    Rule,
    RuleCondition,
    ConditionOperator,
    # Events
    EventDefinition,
    EventHandler,
    EventSourceType,
    ScheduleType,
    # Action classes
    ActionBase,
    MessageActionBase,
    GotoSceneAction,
    SendMessageAction,
    EditMessageAction,
    SendPhotoAction,
    SendVideoAction,
    SendDocumentAction,
    DeleteMessageAction,
    AnswerCallbackAction,
    BackAction,
    SaveInputAction,
    ClearDataAction,
    SetVariableAction,
    ScheduleEventAction,
    EmitEventAction,
    BusinessAction,
    ApproveJoinRequestAction,
    DeclineJoinRequestAction,
    AnswerInlineQueryAction,
    InlineArticleResult,
    CustomAction,
    ChatMemberFilter,
    SwitchInlineQueryChosenChat,
    # Throttle
    ThrottleConfig,
    ThrottleScope,
)
from .variables import VariableRepository, InMemoryVariableRepository
from .rule_engine import RuleEngine, ConditionEvaluator
from .events import EventBus, EventScheduler, EventData, InMemoryEventScheduler, ScheduledTask
from .integrations import APSchedulerEventScheduler, TaskiqEventScheduler
from .event_dispatcher import EventDispatcher
from .event_sync import EventDiff, EventSynchronizer
from .router import UIRouterExecutor
from .registry import MasterRegistry
from .context import ExecutionContext, NavigationState, EventMode
from .context_factory import ContextFactory
from .flag_resolver import FlagResolver
from .navigation_storage import NavigationStorage, InMemoryNavigationStorage
from .services import (
    CacheStorageProtocol,
    SharedServices,
    NavigationService,
    ContentService,
    LocalizationService,
    SceneRenderer,
)
from .throttle import ThrottleChecker
from .services.shared import InMemoryCacheStorage
from .logging import configure_structlog, StructlogMiddleware
from .pre_checkout import PreCheckoutState, pre_checkout_scope
from .adapters import AiogramAdapter
from .filters import ABGroupFilter, BotExcludeFilter, BotIncludeFilter
from .analytics import AnalyticsCollector, AnalyticsEvent, AnalyticsEventType
from .validator import SchemaValidator, ValidationReport, ValidationIssue, ValidationSeverity, ValidationCategory
from .exceptions import (
    UIRouterError,
    ConfigurationError,
    SchemaValidationError,
    RegistryError,
    ActionError,
    MissingActionFieldError,
    UnknownActionTypeError,
    NavigationError,
    SceneNotFoundError,
    CallbackDataError,
    CallbackDecodeError,
    CallbackExpiredError,
    KeyboardRenderError,
    EventError,
    EventSchedulingError,
    EventSyncError,
    ContentError,
    RuleEngineError,
)


__all__ = [
    "APSchedulerEventScheduler",
    "ABGroupFilter",
    "ActionBase",
    "ActionInstruction",
    # Энумы
    "ActionType",
    "AnswerCallbackAction",
    "AnswerInlineQueryAction",
    "ApproveJoinRequestAction",
    "BackAction",
    # Adapters
    "AiogramAdapter",
    # Analytics
    "AnalyticsCollector",
    "AnalyticsEvent",
    "AnalyticsEventType",
    "BotExcludeFilter",
    "BotIncludeFilter",
    "BusinessAction",
    # Variables & Rule Engine
    "BotVariable",
    "Button",
    "ButtonTemplate",
    "CacheStorageProtocol",
    # Конфигурация
    "CallbackDataStrategy",
    "ChatMemberFilter",
    "ClearDataAction",
    "ConditionEvaluator",
    "ConditionOperator",
    "ConditionalContent",
    "ConditionalFlag",
    "ContentService",
    "ContentTemplate",
    "ContextFactory",
    "CustomAction",
    "DeclineJoinRequestAction",
    "DeleteMessageAction",
    "InlineArticleResult",
    "DynamicContent",
    "DynamicKeyboard",
    "EditMessageAction",
    "EmitEventAction",
    "EventBus",
    "EventData",
    # Events
    "EventDiff",
    "EventDefinition",
    "EventDispatcher",
    "EventHandler",
    "EventMode",
    "EventScheduler",
    "EventSourceType",
    "EventSynchronizer",
    "EventType",
    "ExecutionContext",
    "FallbackConfig",
    "Filter",
    "Flag",
    "FlagGetter",
    "FlagResolver",
    "GlobalHandler",
    "GotoSceneAction",
    "Handler",
    "InMemoryCacheStorage",
    "InMemoryEventScheduler",
    "InMemoryNavigationStorage",
    "InMemoryVariableRepository",
    "Keyboard",
    "LocalizationService",
    "LocalizedContent",
    "LocalizedTemplate",
    # Для расширения
    "MasterRegistry",
    "MediaContent",
    "MessageActionBase",
    "MessageContent",
    "NavigationConfig",
    "NavigationService",
    "NavigationState",
    "NavigationStorage",
    "PaginationConfig",
    "PreCheckoutState",
    "Rule",
    "RuleCondition",
    "RuleEngine",
    "SaveInputAction",
    # Схемы
    "Scene",
    "ScheduleEventAction",
    "SceneRenderer",
    "ScheduleType",
    "ScheduledTask",
    "SchemaValidator",
    "SendDocumentAction",
    "SendMessageAction",
    "SendPhotoAction",
    "SendVideoAction",
    "SetVariableAction",
    "SharedServices",
    "StructlogMiddleware",
    "SwitchInlineQueryChosenChat",
    "TaskiqEventScheduler",
    "ThrottleChecker",
    "ThrottleConfig",
    "ThrottleScope",
    "TransitionType",
    "configure_structlog",
    # Основное
    "UIRouter",
    "UIRouterExecutor",
    "pre_checkout_scope",
    # Валидатор
    "ValidationCategory",
    "ValidationIssue",
    "ValidationReport",
    "ValidationSeverity",
    "VariableRepository",
    "VariableScope",
    "VariableType",
    # Exceptions
    "UIRouterError",
    "ConfigurationError",
    "SchemaValidationError",
    "RegistryError",
    "ActionError",
    "MissingActionFieldError",
    "UnknownActionTypeError",
    "NavigationError",
    "SceneNotFoundError",
    "CallbackDataError",
    "CallbackDecodeError",
    "CallbackExpiredError",
    "KeyboardRenderError",
    "EventError",
    "EventSchedulingError",
    "EventSyncError",
    "ContentError",
    "RuleEngineError",
]

__version__ = "0.0.2"
