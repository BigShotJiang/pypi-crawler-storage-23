from aiogram.filters import BaseFilter
from aiogram.types import InlineQuery


DEFAULT_INLINE_PREFIX = "inline_prefix"


class PrefixInlineFilter(BaseFilter):
    def __init__(self, *keys: str, arg_key: str = DEFAULT_INLINE_PREFIX) -> None:
        self.keys = keys
        self.arg_key = arg_key

    async def __call__(self, event: InlineQuery) -> bool | dict:
        query = event.query.strip()
        for key in self.keys:
            if query[: len(key)] == key:
                return {self.arg_key: key}

        return False
