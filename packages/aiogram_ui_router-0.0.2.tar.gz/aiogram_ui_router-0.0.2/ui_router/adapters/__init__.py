"""
Adapters package for UI Router.

Contains adapter implementations for integrating with external frameworks
and libraries (e.g., aiogram integration).
"""

from .aiogram_adapter import AiogramAdapter

__all__ = ["AiogramAdapter"]
