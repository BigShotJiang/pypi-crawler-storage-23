"""
Аналитика для UI Router.

Определяет протокол AnalyticsCollector и структуру AnalyticsEvent.
Реализации коллекторов (DB, file, etc.) предоставляются внешними пакетами.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Protocol, runtime_checkable


class AnalyticsEventType(StrEnum):
    """Типы аналитических событий."""

    SCENE_ENTER = "scene_enter"
    SCENE_EXIT = "scene_exit"
    HANDLER_EXECUTED = "handler_executed"
    BUTTON_CLICK = "button_click"
    ACTION_EXECUTED = "action_executed"
    NAVIGATION = "navigation"


@dataclass
class AnalyticsEvent:
    """Событие аналитики."""

    event_type: AnalyticsEventType
    bot_id: int | str
    user_id: int | None = None
    chat_id: int | None = None
    scene_id: str | None = None
    handler_name: str | None = None
    action_type: str | None = None
    ab_group: str | None = None
    ab_test_id: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@runtime_checkable
class AnalyticsCollector(Protocol):
    """Протокол для сбора аналитики.

    Реализации должны быть асинхронными и неблокирующими.
    """

    async def track(self, event: AnalyticsEvent) -> None:
        """Отправить событие аналитики."""
        ...
