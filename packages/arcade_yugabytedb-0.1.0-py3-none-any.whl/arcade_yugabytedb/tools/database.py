"""YugabyteDB database tools — schema exploration and read-only queries."""

import json
from typing import Annotated, Any

import psycopg2
from arcade_mcp_server.metadata import Behavior, Operation, ToolMetadata
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import ToolExecutionError
from psycopg2 import sql as psql


def _connect(context: ToolContext) -> psycopg2.extensions.connection:
    """Create a YugabyteDB connection from the YUGABYTEDB_URL secret."""
    connection_string = context.get_secret("YUGABYTEDB_URL")
    if not connection_string:
        raise ToolExecutionError(
            message="YUGABYTEDB_URL secret is required",
            developer_message="YUGABYTEDB_URL secret was not provided or is empty",
        )
    return psycopg2.connect(connection_string)


@tool(
    requires_secrets=["YUGABYTEDB_URL"],
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
def summarize_database(
    context: ToolContext,
    db_schema: Annotated[str, "Database schema to summarize (e.g. 'public')"] = "public",
) -> Annotated[list[dict[str, Any]], "List of tables with column schemas and row counts"]:
    """
    List all tables in a YugabyteDB database, including column schemas and row counts.

    CALL THIS FIRST to understand the database structure before writing queries.
    Returns every table in the given schema with: table name, column definitions
    (name and data type), and total row count.
    """
    conn = _connect(context)
    try:
        summary: list[dict[str, Any]] = []
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s AND table_type = 'BASE TABLE'
                ORDER BY table_name
                """,
                (db_schema,),
            )
            tables = [row[0] for row in cur.fetchall()]

            for table in tables:
                cur.execute(
                    """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema = %s AND table_name = %s
                    ORDER BY ordinal_position
                    """,
                    (db_schema, table),
                )
                columns = [
                    {"column_name": col, "data_type": dtype} for col, dtype in cur.fetchall()
                ]

                cur.execute(
                    psql.SQL("SELECT COUNT(*) FROM {}.{}").format(
                        psql.Identifier(db_schema),
                        psql.Identifier(table),
                    )
                )
                row_count = cur.fetchone()[0]

                summary.append({
                    "table": table,
                    "row_count": row_count,
                    "columns": columns,
                })

        return summary
    finally:
        conn.close()


@tool(
    requires_secrets=["YUGABYTEDB_URL"],
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
def run_read_only_query(
    context: ToolContext,
    query: Annotated[str, "SQL query to execute (must be read-only)"],
) -> Annotated[str, "Query results as a JSON array of objects"]:
    """
    Run a read-only SQL query against YugabyteDB and return results as JSON.

    The query is executed inside a READ ONLY transaction so writes are rejected.
    Results are returned as a JSON array where each element is a row object
    with column names as keys.
    """
    conn = _connect(context)
    try:
        with conn.cursor() as cur:
            cur.execute("BEGIN READ ONLY")
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            result = [dict(zip(column_names, row, strict=False)) for row in rows]
            return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        try:
            with conn.cursor() as cur:
                cur.execute("ROLLBACK")
        except Exception:  # noqa: S110
            pass
        conn.close()
