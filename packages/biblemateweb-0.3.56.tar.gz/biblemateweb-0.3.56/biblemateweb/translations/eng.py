translation_eng = {
    "Search for words or refs": "Search for words or refs (e.g., Deut 6:4; John 3:16-18)",
}