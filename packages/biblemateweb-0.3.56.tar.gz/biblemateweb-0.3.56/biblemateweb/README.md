# BibleMate AI Web

**AI-powered Bible study web application with advanced search, original language tools, and autonomous agent capabilities.**

BibleMate AI Web provides a unified web interface combining the best features of [BibleMate AI](https://github.com/eliranwong/biblemate) and [UniqueBible](https://github.com/eliranwong/UniqueBible). This repository contains the Web UI, HTTP Server, and API Server components.


Read more at https://github.com/eliranwong/biblemateweb