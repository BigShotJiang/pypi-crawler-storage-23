# CRM Entities Summary

| id | class_code | label | type |
| --- | --- | --- | --- |
| 797b5fe7... | E21 | Albert Einstein | E21 |
| 720a3369... | E21 | in Philadelphia | E21 |
| d2dc38f9... | E21 | said she | E21 |
| 64502329... | E53 | Ulm | E53 |
| 9d34e357... | E53 | Munich | E53 |
| a1ae5da1... | E53 | Munich | E53 |
| d81a0267... | E53 | Munich | E53 |
| 7cf6ed68... | E53 | Zurich | E53 |
| c7be0797... | E53 | Zurich | E53 |
| 29355bc8... | E53 | Princeton | E53 |
| 46a44a65... | E53 | Princeton | E53 |
| 9100a1fb... | E53 | Princeton | E53 |
| 951ec7d6... | E53 | Princeton | E53 |
| 88763c20... | E53 | Princeton | E53 |
| 8f08b484... | E53 | Princeton | E53 |
| b1ae096d... | E53 | New York | E53 |
| 44468a5b... | E53 | Switzerland | E53 |
| 09a59d37... | E53 | Germany | E53 |
| 8be1a9c1... | E53 | Germany | E53 |
| febf9ba4... | E53 | Germany | E53 |
| cd149c79... | E53 | Germany | E53 |
| 9047b03f... | E53 | Italy | E53 |
| ee0d412d... | E53 | Italy | E53 |
| 886f940c... | E53 | United States | E53 |
| 30e278af... | E53 | United States | E53 |
| c2044bbb... | E53 | United States | E53 |
| 5c80139f... | E53 | United States | E53 |
| 9b0b536b... | E22 | theory of relativity | E22 |
| 299e9c9c... | E22 | theory of relativity and the equation E | E22 |
| 1d3ce3a5... | E22 | theory of relativity in  | E22 |
| 6246f06f... | E22 | theory explains that space and time are actually connected | E22 |
| ab4f517d... | E22 | theory of relativity | E22 |
| 0dc9ba9d... | E22 | theory the culmination of his life research | E22 |
| 3e8db6eb... | E22 | theory and key aspects of his general theory of relativity | E22 |
| c8ce630c... | E22 | theory of relativity allegedly came to him in a dream about cows being electrocuted | E22 |
| 88391b98... | E22 | paper on the matter | E22 |
| 6d001b1f... | E22 | Nobel Prize in Physics for his explanation of the photoelectric effect | E22 |
| cfdfb65d... | E22 | Nobel Prize in the future | E22 |
| e10a769a... | E22 | theory of relativity | E22 |
| d9e3947f... | E22 | theory of relativity | E22 |
| 13d2e636... | E22 | theory of relativity | E22 |
| 8893c8a0... | E22 | theory of relativity | E22 |
| f5c4879c... | E22 | theory of relativity | E22 |
| 0e435f4d... | E22 | theory of relativity | E22 |
| 56d3fb52... | E22 | photoelectric effect | E22 |
| 2fc43e81... | E22 | photoelectric effect | E22 |
| ca1e3d86... | E22 | atomic bomb | E22 |
| 785d0d94... | E22 | Manhattan Project | E22 |
| 38f4be2c... | E22 | atomic bomb | E22 |
| 4a43f93d... | E52 | born in 1902 | E52 |
| 5f711ede... | E52 | March 14, 1879 | E52 |
| 0aba9f6d... | E52 | January 6, 1903 | E52 |
| 0ad2e915... | E52 | March 14, 1951 | E52 |
| 8c51853c... | E52 | April 18, 1955 | E52 |
| c7aebf6c... | E52 | late 1940s | E52 |
| 9b558b4a... | E52 | 1880s | E52 |
| 0ebbe327... | E52 | 1890s | E52 |
| a4a04263... | E52 | 1940s | E52 |
| 21173323... | E52 | 1879 | E52 |
| de03cbc9... | E52 | 1902 | E52 |
| df6f8b42... | E52 | 1905 | E52 |
| 5c5bb23a... | E52 | 1905 | E52 |
| 8d083651... | E52 | 1915 | E52 |
| d47effbf... | E52 | 1919 | E52 |
| 688f043e... | E52 | 1905 | E52 |
| aa09bafa... | E52 | 1917 | E52 |
| 90155c0c... | E52 | 1933 | E52 |
| 4a3c0769... | E52 | 1921 | E52 |
| 4c3b5cff... | E52 | 1903 | E52 |
| 565979d4... | E52 | 1902 | E52 |
| d1db46c9... | E52 | 1902 | E52 |
| 3fd4e4ae... | E52 | 1919 | E52 |
| 0c97c5ca... | E52 | 1919 | E52 |
| a99e21d2... | E52 | 1936 | E52 |
| 75f7b3e6... | E52 | 1933 | E52 |
| 7b084e92... | E52 | 1935 | E52 |
| 61b9b760... | E52 | 1939 | E52 |
| 306a3b00... | E52 | 1940 | E52 |
| 3996349a... | E52 | 1945 | E52 |
| 71e8f952... | E52 | 1947 | E52 |
| c6c0ce05... | E52 | 1946 | E52 |
| c53b8952... | E52 | 1951 | E52 |
| 5e90837c... | E52 | 2017 | E52 |
| ef367e09... | E52 | 1955 | E52 |
| 8b64fed8... | E52 | 2014 | E52 |
| ba435b36... | E52 | 1999 | E52 |
| 29ad4c18... | E52 | 2011 | E52 |