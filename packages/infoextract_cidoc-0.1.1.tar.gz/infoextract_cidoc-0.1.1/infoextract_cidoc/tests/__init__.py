"""Test package for collie."""
