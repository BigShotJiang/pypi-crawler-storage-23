"""Golden tests for collie."""
