"""IronLayer Core Engine - Deterministic SQL transformation planning."""

__version__ = "0.1.0"
