# turbo-agent-job

`turbo-agent-job` 是 Turbo-Agent 的任务调度与执行单元模块。

说明：
- 本包用于承接原 `turbo-agent-worker` 的能力，对外统一命名为 job。
- worker 已停用，本包为唯一推荐入口。

运行：
- `uv run ta-job --help`
