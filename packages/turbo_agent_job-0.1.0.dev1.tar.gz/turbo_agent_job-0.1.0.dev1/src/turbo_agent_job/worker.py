import asyncio
import json
import uuid
import dramatiq
from loguru import logger
from turbo_agent_core.schema.jobs import TaskSpec, AgentPayload
from turbo_agent_core.schema.enums import TaskAction
from turbo_agent_core.schema.agents import Character
from turbo_agent_core.schema.states import Conversation, Message
from turbo_agent_job.dramatiq_broker import broker as dramatiq_broker
from turbo_agent_job.settings import settings
from turbo_agent_runtime.executors.character import CharacterRuntime

import redis.asyncio as redis
from turbo_agent_job.decorators import RedisRuntimeMonitor, set_monitor_context, monitor_object


# Initialize Runtime Monitor
# Remove module-level init which causes event loop issues
# init_runtime_monitor(settings.REDIS_RESULT_URL)

# Force register queues to the broker so the worker listens to them
# even if no actor is explicitly bound to them via decorator.
# This allows dynamic routing to these queues while using a single 'execute_task' actor.
# Use underscores instead of dots because Dramatiq validates queue names.
KNOWN_QUEUES = [
    "ta_job_online_external",
    "ta_job_online_internal",
    "ta_job_offline_external",
    "ta_job_offline_internal"
]
for q in KNOWN_QUEUES:
    dramatiq_broker.queues.add(q)


@dramatiq.actor(broker=dramatiq_broker)
def execute_task(task_spec_dict: dict):
    """
    执行任务（基于 TaskSpec）
    """
    try:
        # 1. 反序列化 TaskSpec
        task_spec = TaskSpec(**task_spec_dict)
        logger.info(f"Worker 接收到任务: {task_spec.task_id} (来源: {task_spec.task_source.value}, 归属: {task_spec.task_origin.value})")
        
        # 2. 异步执行任务
        asyncio.run(_execute_task_async(task_spec))
        
    except Exception as e:
        logger.exception("Worker 处理任务时发生异常: {}", e) # Remove f-string with {e} to avoid loguru formatting error with dicts
        # Re-raise to ensure Dramatiq handles retries/failures
        raise


async def _execute_task_async(task_spec: TaskSpec):
    """
    异步执行任务逻辑
    """
    # Create and set monitor for this execution context (loop)
    try:
         redis_client = redis.from_url(settings.REDIS_RESULT_URL, decode_responses=False)
         monitor = RedisRuntimeMonitor(redis_client)
         monitor.start()
         set_monitor_context(monitor)
    except Exception as e:
         logger.error(f"Failed to initialize monitor: {e}")
         return

    try:
        # 1. 解析操作类型
        if task_spec.action != TaskAction.START:
            logger.warning(f"目前 Worker 仅部分支持 START 操作，收到: {task_spec.action}")
            # TODO: 支持 RETRY/RESUME/INTERRUPT
            return
        
        # 2. 准备执行器 (Runtime)
        executor_schema = task_spec.executor
        if not isinstance(executor_schema, Character):
            logger.error(f"目前仅支持 Character 类型的执行器，收到: {type(executor_schema)}")
            return
            
        logger.info(f"正在启动 Character: {executor_schema.name} (ID: {executor_schema.id})")
        
        # 初始化 Runtime
        if executor_schema.tools is None:
            executor_schema.tools = []
        # 注意: CharacterRuntime 继承自 Character, 可以通过 dict 初始化
        runtime = CharacterRuntime(**executor_schema.model_dump())
        
        # 3. 准备输入 (Conversation)
        payload = task_spec.payload
        if not isinstance(payload, AgentPayload):
            logger.error(f"Character 需要 AgentPayload，收到: {type(payload)}")
            return
            
        # 构造 Conversation
        # 将 current_input 追加到 messages 中
        messages = payload.messages or []
        current_input = payload.current_input
        
        if isinstance(current_input, dict):
            # 将 dict 转换为 Message (假设是 User message)
             # 这里做一个简单假设，如果 payload.current_input 是 dict，可能是 Message 的 dict 形式，或者 content dict
            # 确保存在 id
            if "id" not in current_input:
                current_input["id"] = str(uuid.uuid4())
            try:
                msg = Message.model_validate(current_input)
            except:
                # 简化处理：当作 content 文本，并确保有 id
                msg = Message(id=str(uuid.uuid4()), role="user", content=str(current_input))
            messages.append(msg)
        elif isinstance(current_input, Message):
            messages.append(current_input)
        
        assistant_id = task_spec.executor.id if task_spec.executor and hasattr(task_spec.executor, "id") else "system"
        conversation = Conversation(
            id=payload.conversation_id or task_spec.task_id,
            messages=messages,
            assistant_id=assistant_id
        )
        
        # 4. 执行并推流
        # 生成或复用 Trace ID
        trace_id = task_spec.trace_id or task_spec.task_id or str(uuid.uuid4())
        
        logger.info(f"开始流式执行 (Conversation ID: {conversation.id}, Trace ID: {trace_id})")

        if task_spec.user:
             logger.info(f"Worker 绑定用户信息: {task_spec.user.id} role={task_spec.user.role}")

        # 4.1 绑定监控器并设置 Trace ID
        monitor_object(runtime, user_info=task_spec.user, override_trace_id=trace_id)
        
        # 4.2 执行
        # 这里的事件将自动通过 monitor_object 注入的逻辑发送到 Redis Stream
        async for _ in runtime.a_stream(input=conversation, leaf_message_id=payload.leaf_id):
            pass # 仅驱动生成器运行

        logger.info(f"任务 {task_spec.task_id} 执行完成")

    except Exception as e:
        logger.error(f"执行任务 {task_spec.task_id} 时出错: {e}", exc_info=True)
        # TODO: 发布错误事件
    finally:
        await monitor.close()
