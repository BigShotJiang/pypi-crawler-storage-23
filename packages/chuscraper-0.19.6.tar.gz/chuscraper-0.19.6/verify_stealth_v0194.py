import asyncio
import logging
import os
from chuscraper.core.browser import Browser
from chuscraper.core.stealth import SystemProfile

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TEST_SITES = [
    {"name": "CreepJS", "url": "https://creepjs.net/"},
    {"name": "BrowserScan", "url": "https://www.browserscan.net/"},
    {"name": "PixelScan", "url": "https://pixelscan.net/"},
    {"name": "SannySoft", "url": "https://bot.sannysoft.com/"}
]

async def run_stealth_tests():
    # Proxy configuration (Temporarily disabled for debugging)
    # proxy_server = "gw.dataimpulse.com:823"
    # proxy_user = "11de131690b3fdc7ba16__cr.in"
    # proxy_pass = "e3e7d1a8f82bd8e3"
    # proxy_url = f"http://{proxy_user}:{proxy_pass}@{proxy_server}"

    logger.info(f"Initializing Browser WITHOUT Proxy (Debugging mode)")
    # Using local package
    browser = await Browser.create(headless=False)
    async with browser:
        for site in TEST_SITES:
            logger.info(f"Testing {site['name']} at {site['url']}")
            tab = await browser.get(site['url'])
            
            # Apply Advanced Stealth
            profile = SystemProfile.from_system(cookie_domain=site['url'].split("//")[-1].split("/")[0])
            await profile.apply(tab)
            
            # Debug info
            detected_ver = await tab.get_browser_version()
            logger.info(f"Sync Result | Kernel: {detected_ver} | Profile UA: {profile.user_agent}")

            # Wait for detection to run
            await asyncio.sleep(10)
            
            screenshot_name = f"stealth_test_{site['name'].lower()}.png"
            await tab.save_screenshot(screenshot_name)
            logger.info(f"Screenshot saved: {screenshot_name}")
            
            # For CreepJS, maybe extract some text
            if site['name'] == "CreepJS":
                trust_score = await tab.select_one(".trust-score")
                if trust_score:
                    logger.info(f"CreepJS Trust Score Element Found")

if __name__ == "__main__":
    asyncio.run(run_stealth_tests())
