import asyncio
import logging
from chuscraper.core.browser import Browser
from chuscraper.core.stealth import SystemProfile

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

URL = "https://www.makemytrip.com/hotels/hotel-listing/?checkin=07262025&checkout=07272025&locusId=CTJAI&locusType=city&city=CTJAI&country=IN&searchText=Cygnett%20Style%20Ganga%20Hotel&roomStayQualifier=1e0e&_uCurrency=INR&reference=hotel&rf=directSearch&lat=26.814932&lng=75.86291&topHtlId=202311282002508888&type=hotel&rsc=1e1e0e"

PROXY_URL = "http://11de131690b3fdc7ba16__cr.in:e3e7d1a8f82bd8e3@gw.dataimpulse.com:823"

async def test_mmt():
    logger.info("Initializing Browser with Proxy and Elite Stealth Engine...")
    
    # Create browser with proxy
    browser = await Browser.create(
        headless=False,
        proxy=PROXY_URL
    )
    
    async with browser:
        logger.info(f"Navigating to MMT: {URL}")
        tab = await browser.get(URL)
        
        # Apply Elite Stealth
        profile = SystemProfile.from_system(cookie_domain="makemytrip.com")
        await profile.apply(tab)
        
        # Logic to wait for 1 minute as requested
        logger.info("Waiting for 60 seconds (Anti-bot cooling/Loading)...")
        await asyncio.sleep(60)
        
        # Save results
        screenshot_path = "mmt_verification.png"
        await tab.save_screenshot(screenshot_path)
        logger.info(f"Screenshot saved to {screenshot_path}")
        
        # Extract title to verify page content
        title = await tab.evaluate("document.title")
        logger.info(f"Page Title: {title}")

if __name__ == "__main__":
    asyncio.run(test_mmt())
