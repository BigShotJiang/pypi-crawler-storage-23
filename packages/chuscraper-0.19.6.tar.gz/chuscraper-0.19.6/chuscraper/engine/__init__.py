from .parser import Selector, Selectors

__all__ = ["Selector", "Selectors"]
