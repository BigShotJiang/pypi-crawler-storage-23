from ._utils import (
    log,
    set_logger,
    reset_logger,
    __CONSECUTIVE_SPACES_REGEX__,
    flatten,
    _is_iterable,
    _StorageTools,
    clean_spaces,
    html_forbidden,
)
