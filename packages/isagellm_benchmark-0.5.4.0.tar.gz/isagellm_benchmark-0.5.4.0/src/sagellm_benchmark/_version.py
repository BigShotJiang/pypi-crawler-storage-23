"""Version information for sagellm-benchmark."""

__version__ = "0.5.4.0"
