"""FastAPI app initialization."""
