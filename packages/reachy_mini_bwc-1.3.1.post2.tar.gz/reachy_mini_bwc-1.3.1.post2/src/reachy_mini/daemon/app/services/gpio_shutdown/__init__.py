"""GPIO shutdown service package."""
