#!/usr/bin/env bash

 systemctl restart reachy-mini-daemon.service 

