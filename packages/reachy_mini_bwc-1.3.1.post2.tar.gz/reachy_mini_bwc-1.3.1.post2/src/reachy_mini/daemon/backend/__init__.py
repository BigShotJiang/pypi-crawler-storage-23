"""Backend module for Reachy Mini Daemon."""
