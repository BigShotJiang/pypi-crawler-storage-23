"""Specific app sources.

For the moment, only huggingface spaces is implemented.
"""
