"""Hardware configuration utilities."""
