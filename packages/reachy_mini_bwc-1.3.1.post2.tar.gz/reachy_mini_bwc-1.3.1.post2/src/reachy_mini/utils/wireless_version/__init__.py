"""Utility functions for working with wireless version."""
