"""Blockchain anchoring module for Attestix (Base L2 via EAS)."""
