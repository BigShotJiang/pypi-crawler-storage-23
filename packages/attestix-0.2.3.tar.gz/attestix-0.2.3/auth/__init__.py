"""Authentication and cryptographic modules for Attestix."""
