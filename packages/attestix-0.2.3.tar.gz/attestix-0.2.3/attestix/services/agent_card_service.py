"""Re-export from flat module for namespace compatibility."""
from services.agent_card_service import AgentCardService

__all__ = ["AgentCardService"]
