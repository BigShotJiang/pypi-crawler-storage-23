"""Re-export from flat module for namespace compatibility."""
from services.credential_service import CredentialService

__all__ = ["CredentialService"]
