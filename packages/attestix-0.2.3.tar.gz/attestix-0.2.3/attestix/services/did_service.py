"""Re-export from flat module for namespace compatibility."""
from services.did_service import DIDService

__all__ = ["DIDService"]
