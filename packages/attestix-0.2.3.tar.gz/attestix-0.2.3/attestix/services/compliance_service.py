"""Re-export from flat module for namespace compatibility."""
from services.compliance_service import ComplianceService

__all__ = ["ComplianceService"]
