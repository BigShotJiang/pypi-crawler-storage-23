"""Re-export from flat module for namespace compatibility."""
from services.identity_service import IdentityService

__all__ = ["IdentityService"]
