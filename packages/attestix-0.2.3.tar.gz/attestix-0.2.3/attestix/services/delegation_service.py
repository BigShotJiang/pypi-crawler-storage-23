"""Re-export from flat module for namespace compatibility."""
from services.delegation_service import DelegationService

__all__ = ["DelegationService"]
