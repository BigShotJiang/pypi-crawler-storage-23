"""
单一策略量化结果分析

最后修改时间: 2026-02-12
"""

import pandas as pd
import numpy as np

from .util import _check_DatetimeIndex


class SingleStatagyAnalysis():
    """
    单一策略量化结果分析
    """
    def __init__(self, equity_curve: pd.DataFrame):
        """
        单一策略量化结果分析

        Args:
            equity_curve: 单一策略在不用交易品种下的权益曲线累计盈亏
        
        数据结构示意::

            +---------------+----------+------------+-----+
            | DatetimeIndex | stock 1  | comodity 2 | ... |
            +===============+==========+============+=====+
            | time          | value    | value      |     |
            +---------------+----------+------------+-----+
            | time          | value    | value      |     |
            +---------------+----------+------------+-----+
        """
        _check_DatetimeIndex(equity_curve)
        if equity_curve.index.freq == 'D':
            equity_curve.resample(pd.Timedelta(days=1)).last()
        total_days = equity_curve.shape[0] # 总天数
        K = 252 # 年交易日
        risk_free_rate = 0.02
        
        # 单日收益率
        daily_rate_of_return = (
            equity_curve
            .groupby(pd.Grouper(freq='D')).sum()
            .pct_change()
        ) 
        # 累计收益
        final_return = equity_curve.iloc[-1]/equity_curve.iloc[0] - 1
        # 年化收益
        annualized_percentage_rate = (K*final_return/total_days)-1
        # 年化波动率
        annulized_volatility = equity_curve.std()*np.sqrt(K)
        # Sharpe Ratio
        shape_ratio = (annualized_percentage_rate-risk_free_rate)/annulized_volatility
        # 最大回撤
        max_drawdown = (equity_curve/equity_curve.cummax()-1).min()
        # 胜率
        win_rate = (daily_rate_of_return>0).sum()/total_days
        
        self._out = pd.concat([
            final_return.rename("累计收益率"),
            annualized_percentage_rate.rename("年化收益(APR,不是EAR)"),
            annulized_volatility.rename("年化波动率"),
            shape_ratio.rename("Sharpe Ratio"),
            max_drawdown.rename("最大回撤"),
            win_rate.rename("胜率"),
        ],axis=1)

    @property
    def values(self):
        return self._out.round(1)
    
    def print(self):
        print(self._out.round(1).astype(str) + '%')
