"""
单因子横截面分析

最后修改时间: 2026-02-12
"""

import pandas as pd
from matplotlib import pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei'] # 设置中文字体为黑体 (SimHei)
plt.rcParams['axes.unicode_minus'] = False  # 解决负号 '-' 显示为方块的问题

from .util import _check_DatetimeIndex, Time


class SingleFactorAnalysis:
    """
    单因子横截面分析
    """
    def __init__(self, factor_values_df:pd.DataFrame, markets_df:pd.DataFrame, name:str = None):
        """
        单因子横截面分析
        Args:
            factor_values_df(DataFrame): 单因子在不同交易品种下具体值的横截面数据
            markets_df(DataFrame): 不同交易品种的市场价格数据
            name: 因子名称
        """
        _check_DatetimeIndex(factor_values_df)
        _check_DatetimeIndex(markets_df)
        self._price_df = markets_df
        self._factor_values_df = factor_values_df
        self._forward_return_df = pd.DataFrame()
        self._func_name = name

    def set_horizon(self, horizon: Time = Time(days=1)):
        self._forward_return_df = self._price_df.shift(freq=-1*pd.Timedelta(**horizon.values))/self._price_df-1
        return self

    def _check_horizon(self):
        if self._forward_return_df.empty:
            raise ValueError('回报率计算跨度未设定，请先调用.set_horizon()设定回报率的跨度')

    @property
    def IC(self):
        """
        信息系数: t 时刻因子值与 t + horizon 时刻的收益率 (从 t 时刻开始计算) 之间的相关系数。
        Args:
            horizon(Time): 回报率的跨度
        """
        # 跨度为horizon的收益率
        self._check_horizon()
        return self._factor_values_df.corrwith(self._forward_return_df,axis=1,method='pearson').sort_index().rename('IC')
    
    @property
    def rankIC(self):
        self._check_horizon()
        return self._factor_values_df.corrwith(self._forward_return_df,axis=1,method='spearman').sort_index().rename('rankIC')
        
    
    def plot(self):
        """
        画图
        """
        plt.figure()
        ax = self.IC.plot(legend=True)
        ax.legend(loc='best')      
        ax.set_title(f'因子名称:{self._func_name}\n IC随时间变化记录')
        ax.set_xlabel('时间')
        ax.set_ylabel('IC')
        
        plt.figure()
        ax = self.rankIC.plot(legend=True)
        ax.legend(loc='best')      
        ax.set_title(f'因子名称:{self._func_name}\n rankIC随时间变化记录')
        ax.set_xlabel('时间')
        ax.set_ylabel('rankIC')

