"""
交易策略

最后修改时间: 2026-02-12
"""

import pandas as pd

from .util import _check_DatetimeIndex
from .Factor import Factor

class Strategy():
    """
    交易策略
    """
    def __init__(self, df: pd.DataFrame|Factor):
        """
        绑定因子值并初始化内部状态
        Args:
            df: 绑定的因子值
        Examples:
        
            自定义策略函数时，应按照以下方式定义::

                def xxxxx(xxx: Strategy):
                    pass
        """
        if isinstance(df, Factor):
            self._df = df.values
        elif isinstance(df, pd.DataFrame):
            self._df = df
        _check_DatetimeIndex(self._df)
        index = self._df.index
        self._conditions = pd.DataFrame(index=index) # 当前所有条件
        self._signals = pd.DataFrame(index=index) # 当前交易信号记录
        
    # ---------------------------- 因子选择 ----------------------------
    def select(self,*labels):
        """
        按labels选择因子
        Args:
            *labels(str|list): 待选择因子的labels
        """
        if self._df.empty:
            raise 
        return Factor(self._df)[labels]
    
    def __getitem__(self, labels):
        """
        按labels选择因子
        Args:
            *labels(str|list): 待选择因子的labels
        """
        return self.select(labels)
        
    # ---------------------------- 交易 ----------------------------
    def when(self, condition: Factor|pd.Series[bool]):
        """
        设定交易条件: 把条件绑定成向量化可执行规则, 并在其上触发交易动作(buy / sell /...) (作为condition → action的桥梁)。
        Args:
            condition(pd.Series[bool]): 交易条件, 一个 bool “mask”, 而非 if 控制流
        """
        ## 检查交易条件合法性
        # 1. 所有交易条件应是一个 bool “mask”
        col = condition._df if isinstance(condition, Factor) else condition
        col = pd.Series(col.squeeze("columns"))
        if not col.dtype == bool:
            raise TypeError('交易条件应该为bool变量')
        # 2. 在同一个策略下的同一个时间点，交易条件应唯一
        temp = pd.concat([self._conditions, col], axis=1)
        if ((temp.astype('int').sum(axis=1))>1).any():
            raise ValueError('交易条件冲突')
        ## 更新交易条件
        self._conditions = temp
        return self
    
    def buy(self, size:float|list[float]):
        """
        根据当前交易条件执行买入交易
        Args:
            size(float): 交易订单数量
        """
        self._signals.loc[self._conditions.iloc[:,-1],'size'] = size
        return self
    
    def sell(self, size:float|list[float]):
        """
        根据当前交易条件执行卖出交易
        Args:
            size(float): 交易订单数量
        """
        self._signals.loc[self._conditions.iloc[:,-1],'size'] = -size
        return self

