"""
策略具体值，即交易信号

最后修改时间: 2026-02-12
"""

import pandas as pd
from typing import Callable, get_type_hints
import inspect

from .util import _check_DatetimeIndex
from .Factor import Factor
from .Strategy import Strategy


class StrategyValues():
    """
    策略具体值，即交易信号。 
        交易信号 = 策略 + 具体因子值: 将策略和具体因子值相结合，转变为交易信号 
        注意: 策略需要通过因子值才能生成交易信号, 同一策略在不同数据下会产生不同的交易信号
    """
    def __init__(self,func: Callable[[Strategy],None], df: pd.DataFrame|Factor):
        """
        Args:
            func(Callable): 自定义策略
            df(DataFrame): 因子值
        """
        self._check_strategy_validity(func)
        _check_DatetimeIndex(df)
        self._func = func
        self._df = df
        
    def _check_strategy_validity(self, func: Callable[[Strategy],None]):
        """
        检查策略定义合法性
            1. 检查函数签名：必须一个参数
            2. 检查类型注解（强制写 xxx: Strategy)
        Args:
            func: 自定义策略
        """
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        hints = get_type_hints(func, globalns=globals(), localns=locals())# get_type_hints 会解析 "Strategy" 这类前向引用
        p0 = params[0].name
        if (
            len(params) != 1 or 
            p0 not in hints or 
            hints[p0] is not Strategy
        ):
            raise TypeError(
                f"策略函数定义格式错误: def {func.__name__}{sig}, "
                f"应改为: def {func.__name__}({p0}: {Strategy.__module__}.Strategy)"  
            )
        return func

    @property
    def values(self) -> pd.DataFrame:
        _check_DatetimeIndex(self._df)
        # strategy的本质是._condition和._signals
        strategy = Strategy(self._df) # 1. 通过实例化一个strategy类来初始化._condition和._signals
        self._func(strategy) # 2. 函数在执行过程中，strategy里面的._condition和._signals会被func中调用的when、buy、sell改写
        signals = strategy._signals # 3. 在运行结束后，再次调用self._strategy._condition和self._strategy._signals就是我们要的执行结果
        # 将所有没有交易信号的地方填充0
        return signals.fillna(0) 

