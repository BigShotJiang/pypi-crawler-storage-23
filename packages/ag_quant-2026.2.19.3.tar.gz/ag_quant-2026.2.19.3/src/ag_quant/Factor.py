"""
因子

最后修改时间: 2026-02-12
"""

import pandas as pd

from .DSL import DSL
from .util import _check_DatetimeIndex, Time

class Factor(DSL):
    """
    因子构造, 一个时间序列Pandas DataFrame: 行index为DatetimeIndex, 列label为因子名称, 每一列为因子时间序列值:

    数据结构示意::
    
        +---------------+----------+----------+-----+
        | DatetimeIndex | factor 1 | factor 2 | ... |
        +===============+==========+==========+=====+
        | time          | value    | value    |     |
        +---------------+----------+----------+-----+
        | time          | value    | value    |     |
        +---------------+----------+----------+-----+
    
    """
    def __init__(self, df: pd.DataFrame):
        """
        因子构造, 一个时间序列Pandas DataFrame: 行index为DatetimeIndex, 列label为因子名称, 每一列为因子时间序列值:

        数据结构示意::

            +---------------+----------+----------+-----+
            | DatetimeIndex | factor 1 | factor 2 | ... |
            +===============+==========+==========+=====+
            | time          | value    | value    |     |
            +---------------+----------+----------+-----+
            | time          | value    | value    |     |
            +---------------+----------+----------+-----+

        Args:
            df(pd.DataFrame): 生成因子所基于的数据
        Examples:
            构造因子时，应按照以下方式定义, 
            注意最后一定要return f !!! ::

                def xxxxx(f: Factor):
                    pass
                    return f
            
        """
        _check_DatetimeIndex(df)
        super().__init__(df)

    # ---------------------------- Python 技术功能 ----------------------------
    def copy_DatetimeIndex(self):
        """
        生成一个全新的Factor类, 只保留DatetimeIndex
        """
        return self.__class__(pd.DataFrame(index = self._df.index.copy()))
        
    @property
    def _freq(self):
        return self._df.index.freq
    
    def _check_Time(self, window):
        if not isinstance(window, Time):
            raise TypeError('window的数据类型不是Time')

    # ---------------------------- 具体数据处理算法 ----------------------------
    def pct_change(
        self,
        window: Time,
        tolerance: Time = Time(days=7)       
    ):
        """
        环比变化
        Args:
            window(pd.DateOffset): 环比变化时间
            tolerance(Time): 最多允许偏差
        """
        self._check_Time(window)
        prev_df = self._df.reindex(
            self._df.index - pd.DateOffset(**window.values),
            method="ffill",
            tolerance=pd.Timedelta(**tolerance.values)
        ).set_index(self._df.index)

        return self.__class__(
            self._df / prev_df -1
        )
    
    def MA(self, window:Time):
        """
        滑动平均
        Args:
            window
        """
        self._check_Time(window)
        return self.__class__(
            self._df.rolling(pd.Timedelta(**window.values)).mean()
        )
    
    def MA_diff(self, window_1:Time, window_2:Time):
        """
        均线差
        """
        return self.__class__(
           self.MA(window_1)._df-self.MA(window_2)._df
        )
    
    def rolling_volatility(self, window:Time):
        """
        滚动波动率
        Args:
            window(int): the rolling window length
            unit(str): unit of windows
        """
        return self.__class__(
            self._df.rolling(pd.Timedelta(**window.values)).std()
        )

