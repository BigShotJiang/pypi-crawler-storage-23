"""
一些技术/检查工具

最后修改时间: 2026-02-12
"""

import pandas as pd

class Time:
    def __init__(
        self,
        years: int = None,
        months: int = None,
        weeks: int = None,
        days: int = None,
        hours: int = None,
        minutes: int = None,
        seconds: int = None,
    ): 
        self._dict = dict(
            years =  years,
            months = months,
            weeks =  weeks,
            days =  days,
            hours =  hours,
            minutes = minutes,
            seconds = seconds
        )
    
    @property
    def values(self):
        return {k: v for k, v in self._dict.items() if v}


def _to_list(args: tuple|object):
    if isinstance(args, tuple):
        return list(args) 
    elif isinstance(args, list):
        return args
    else:
        return [args]
    

def _check_DatetimeIndex(df: pd.DataFrame|pd.Series):
    """
    确保DataFrame的行index的数据类型为pd.DatetimeIndex, 且已设定频率
    """
    if not isinstance(df, pd.DataFrame|pd.Series): 
        raise TypeError('信号数据类型不是DataFrame或Series')
    if not isinstance(df.index, pd.DatetimeIndex):
        raise TypeError('输入DateFrame行index的数据类型不是pd.DatetimeIndex')  
    if df.index.freq is None:
        raise TypeError('输入DateFrame行DatetimeIndex没有设定freq')        
    df.sort_index(inplace=True)