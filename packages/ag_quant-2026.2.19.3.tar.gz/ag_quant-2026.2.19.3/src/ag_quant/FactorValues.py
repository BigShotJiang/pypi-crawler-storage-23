"""
将“因子构造”, 结合具体数据，转换为具体因子值

最后修改时间: 2026-02-12
"""

import inspect
from typing import Callable, get_type_hints
import pandas as pd

from .util import _check_DatetimeIndex
from .Factor import Factor


class FactorValues():
    """
    将“因子构造”, 结合具体数据，转换为具体因子值
        注意: 因子构造可以是相同的, 但是在不同交易品种数据下同一因子会有不同的因子值
    """
    def __init__(self, func: Callable[[Factor],Factor], df: pd.DataFrame):
        """
        将“因子构造”, 结合具体数据，转换为具体因子值
            注意: 因子构造可以是相同的, 但是在不同交易品种数据下同一因子会有不同的因子值
        Args:
            func(Callable): 因子构造
            df(DataFrame): 具体交易品种基础数据
        """
        self._check_factor_validity(func)
        _check_DatetimeIndex(df)
        self._func = func
        self._df = df
    
    def _check_factor_validity(self, func: Callable[[Factor],Factor]):
        """
        检查因子定义合法性
            1. 检查函数签名：必须一个参数
            2. 检查类型注解（强制写 xxx: Factor)
            3. 必须返回输入的参数自身
        Args:
            func: 因子构造
        """
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        hints = get_type_hints(func, globalns=globals(), localns=locals())# get_type_hints 会解析 "Factor" 这类前向引用
        p0 = params[0].name
        self._p0 = p0
        if (
            len(params) != 1 or 
            p0 not in hints or 
            hints[p0] is not Factor
        ):
            raise TypeError(
                f"因子构造函数定义格式错误: def {func.__name__}{sig},应改为: \n"
                f"\t\u0020  def {self._func.__name__}({self._p0}: {Factor.__module__}.Factor) \n"
                f"\t\u0020\u0020\u0020\u0020  xxxx \n "
                f"\t\u0020\u0020\u0020\u0020  return {self._p0}  <--不要忘了这一行"
            )
        return func

    @property
    def values(self) -> pd.DataFrame:
        factor = Factor(self._df) # 1. 实例化一个factor类
        factor = self._func(factor) # 2. 函数在执行过程中，func中创造的因子会以一个新列的方式保存到实例化的factor._df中, 然后被返回
        try: 
            factor.values
        except AttributeError:
            raise TypeError(
                f"因子构造函数定义格式错误: 函数定义最后没有 return {self._p0}。根据当前符号，正确格式为: \n"
                f"\t\u0020  def {self._func.__name__}({self._p0}: {Factor.__module__}.Factor) \n"
                f"\t\u0020\u0020\u0020\u0020  xxxx \n "
                f"\t\u0020\u0020\u0020\u0020  return {self._p0}  <--不要忘了这一行"
            )
        factor = factor._df.drop(columns=self._df.columns) # 3. 在返回的factor._df中把原先self._df中的列去掉，剩下的就是新创造的因子
        return factor
    
