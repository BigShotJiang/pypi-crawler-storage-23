from enum import Enum


class MatchTask(Enum):
    REFERENCE = (
        "reference",
        "Matching bibliographic references to works, such as "
        + "journal articles, conference papers, etc.",
    )
    PREPRINT = ("preprint", "Matching journal articles to preprints.")
    AFFILIATION = ("affiliation", "Matching affiliations to ROR IDs.")
    FUNDER = ("funder", "Matching funders to ROR IDs.")
    OTHER = ("other", "A generic matching task.")
    HEALTHCHECK = (
        "healthcheck",
        "used internally to check that things are working properly",
    )

    def __new__(cls, value, description):
        obj = object.__new__(cls)
        obj._value_ = value
        obj.description = description
        return obj

    @classmethod
    def get_tasks(cls):
        return [{"id": t.value, "description": t.description} for t in cls]

    @classmethod
    def get_ids(cls):
        return [t.value for t in cls]

    @property
    def id(self):
        # alias for "value"
        return self.value
