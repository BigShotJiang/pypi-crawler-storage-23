from .MatchTask import MatchTask as MatchTask
from .strategies import Strategy as Strategy
from crossref_matcher.matching.utils import get_resource_path

with open(get_resource_path("crossref_matcher.resources", "VERSION.txt"), "r") as f:
    __version__ = f.read().strip()
