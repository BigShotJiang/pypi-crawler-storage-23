import os
from crossref_matcher.app import run_app


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Load a specified strategy as a plugin and run a debug Crossref Matching API server"
    )
    parser.add_argument("module", help="Path to module to load as plugin", type=str)
    parser.add_argument(
        "--host", help="Host to run the server on", type=str, default="0.0.0.0"
    )
    parser.add_argument(
        "--port", help="Port to run the server on", type=int, default=8000
    )
    args = parser.parse_args()
    os.environ["MARPLE_TEST_MODULE"] = args.module
    run_app(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
