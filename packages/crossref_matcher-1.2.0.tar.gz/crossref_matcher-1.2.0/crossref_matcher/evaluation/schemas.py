from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field
from typing import Any


def to_kebab(string: str) -> str:
    if string is None:
        return None
    return "-".join(string.split("_"))


class Item(BaseModel):
    model_config = ConfigDict(
        from_attributes=True, populate_by_name=True, alias_generator=to_kebab
    )


class Response(Item):
    status: str = "ok"
    message_version: str = "1.0.0"
    message_type: str


class Message(Item):
    pass


class HeartbeatResponse(BaseModel):
    status: str


class DataPoint(Item):
    seq_no: int
    input: str
    output: list[str]


alternates: list[tuple[str, str]] = Field(
    default_factory=list,
    description="List of (id, id) pairs. The first item in each pair is an alternate match or 'no_match', and the second item is among the ids in `output` or 'no_match'. If the strategy predicted one of the alternate ids, it will be 'relaxed' to the corresponding value.",
)


class DataPointExtended(DataPoint):
    alternates: list[tuple[str, str]] = alternates
    weight: float = 1.0


class DatasetBasic(Item):
    id: str
    collected_at: datetime
    task_id: str


class Dataset(DatasetBasic):
    data_points: list[DataPoint] | list[DataPointExtended]


class Result(Item):
    seq_no: int
    input: str
    output: list[str]
    matched: list[str]
    extra: dict[Any, Any] | None = Field(default=None)


class ResultExtended(Result):
    alternates: list[tuple[str, str]] = alternates
    weight: float = 1.0


class FScore(Item):
    score: float
    beta: float


class Statistics(Item):
    total: int
    false_negatives: int
    false_positives: int
    precision: float
    recall: float
    f_scores: list[FScore] = Field(default_factory=list)


class ResultSetBasic(Item):
    id: str
    task_id: str
    strategy_id: str
    dataset_id: str
    matched_at: datetime
    statistics: dict[str, Statistics] = Field(
        default_factory=dict,
        description="""Dictionary with values being the Statistics object, and keys being a description. E.g., "weighted_relaxed": Statistics(total=...)""",
    )
    extra: dict[Any, Any] | None = Field(default=None)


class ResultSet(ResultSetBasic):
    results: list[Result] | list[ResultExtended]


class DatasetsMessage(Message):
    items: list[DatasetBasic]


class ResultSetsMessage(Message):
    items: list[ResultSetBasic]


class DatasetResponse(Response):
    message_type: str = "dataset"
    message: Dataset


class DatasetsResponse(Response):
    message_type: str = "dataset-list"
    message: DatasetsMessage


class ResultSetResponse(Response):
    message_type: str = "result-set"
    message: ResultSet


class ResultSetsResponse(Response):
    message_type: str = "result-set-list"
    message: ResultSetsMessage
