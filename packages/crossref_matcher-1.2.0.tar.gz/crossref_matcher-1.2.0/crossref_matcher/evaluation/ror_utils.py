import json
from pathlib import Path


def get_ror_name_map(path_to_ror_data: str) -> dict[str, str]:
    # Load ROR data from a JSON file
    ror_data = json.loads(Path(path_to_ror_data).read_text())
    ror_name_map = {}
    for entry in ror_data:
        ror_name = [
            name["value"] for name in entry["names"] if "ror_display" in name["types"]
        ][0]
        ror_name_map[entry["id"]] = ror_name
    return ror_name_map
