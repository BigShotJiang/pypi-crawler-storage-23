from copy import deepcopy
from typing import Iterable

from crossref_matcher.evaluation.evaluation import get_matched_alternate


def res_cat(true_link, matched_link):
    if matched_link == "no_match":
        if true_link == "no_match":
            return "TN"
        else:
            return "FN"
    else:
        if matched_link == true_link:
            return "TP"
        else:
            return "FP"


def get_candidate_position(candidates, target) -> int | None:
    if target == "no_match":
        return None
    if not candidates:
        return None
    for i, candidate in enumerate(candidates):
        if candidate["id"] == target:
            return i
    return -1


def construct_true_relaxed_list(this_result_true, alternates_negative):
    for t in this_result_true:
        if t in alternates_negative:
            yield "no_match"
        else:
            yield t


def get_matched_name(item, matched_id):
    for match in item["extra"].get("matching_result", []):
        if match["id"] == matched_id:
            return match.get("matched_name")
    return None


def construct_matched_list(this_result_true, matched, alternates_negative=None):
    # get a "matched" list the same length as the true list
    _matched = deepcopy(matched)
    this_result_matched = []

    if len(_matched) == 0:
        _matched = ["no_match"]
    for t in this_result_true:
        if t in _matched:
            this_result_matched.append(_matched.pop(_matched.index(t)))
        else:
            this_result_matched.append(False)
    for idx, val in enumerate(this_result_matched):
        # replace False values with either the false positive match or "no_match"
        if val is False:
            if len(_matched) > 0:
                item = _matched.pop()
                if alternates_negative is not None and item in alternates_negative:
                    # This will end up changing a true positive into a true negative.
                    # This is a bug, but it's a tough one to fix.
                    this_result_matched[idx] = "no_match"
                else:
                    this_result_matched[idx] = item
            else:
                this_result_matched[idx] = "no_match"
    return this_result_matched


def get_all_links(items: Iterable[dict]) -> list[dict]:
    """
    Convert evaluation items into a detailed flat list of link records for analysis.
    These records can then be used to create a pandas DataFrame for further evaluation.

    This function transforms evaluation data items into individual link records,
    creating one record per true link in each item. Each record contains both
    the expected (true) link and the actual (matched) link, along with metadata
    for evaluation analysis.

    The function handles both strict and relaxed matching scenarios:
    - Strict matching: Direct comparison between true and matched links
    - Relaxed matching: Accounts for alternate matches

    Some of the fields included in the output records require the use of an extra_fn
    function during evaluation to populate necessary metadata. See the docstring
    of the `run_strategy_on_eval_data` function for details on how to implement this.

    Args:
        items: Iterable of evaluation data items. These can be obtained from a
        list of Result objects by calling `r.model_dump() for r in results` or
        from a ResultSet object by calling `r.model_dump() for r in result_set.results`

    Returns:
        List of link record dicts. Each record contains:
            - "unique_id": Formatted unique identifier (seq_no + true_link)
            - "seq_no": Original sequence number from input item
            - "input": Original input text
            - "true_link": The expected/true link for this record
            - "matched": The link that was matched by the strategy
            - "matched_relaxed": The matched link under relaxed criteria
            - "res_cat": Result category (TP/TN/FP/FN) for strict matching
            - "res_cat_relaxed": Result category for relaxed matching
            - "matched_name": Human-readable name of the matched entity
            - "target_in_initial_candidates": Position of true link in candidates
            - "target_es_score": Elasticsearch score for the true link
            - "weight": Weight value from original item

    Note:
        - Items with no expected output are treated as expecting "no_match"
        - The function pairs true links with matched links, handling cases where
          the counts don't match by using "no_match" or false positives
        - Relaxed matching applies alternate matches as specified in the item's alternates

    Example usage:
        >>> # result_set is an instance of ResultSet obtained from evaluation.run_strategy_on_eval_data()
        >>> data = get_all_links(r.model_dump() for r in result_set.results)
        >>> import pandas as pd
        >>> df = pd.DataFrame(data).set_index("unique_id")
    """
    data = []
    for item in items:
        if len(item["output"]) == 0:
            this_result_true = ["no_match"]
        else:
            this_result_true = item["output"]
        alternates_negative = [
            x[1] for x in item.get("alternates", []) if x[0] == "no_match"
        ]
        this_result_true_relaxed = list(
            construct_true_relaxed_list(this_result_true, alternates_negative)
        )
        this_result_matched = construct_matched_list(this_result_true, item["matched"])
        this_result_matched_relaxed = construct_matched_list(
            this_result_true_relaxed,
            get_matched_alternate(item),
            alternates_negative=alternates_negative,
        )
        for i, this_row_true in enumerate(this_result_true):
            if this_row_true in this_result_matched:
                this_row_matched = this_row_true
            else:
                this_row_matched = this_result_matched[0]
            this_result_matched.remove(this_row_matched)
            if this_result_true_relaxed[i] in this_result_matched_relaxed:
                this_row_matched_relaxed = this_result_true_relaxed[i]
            else:
                this_row_matched_relaxed = this_result_matched_relaxed[0]
            this_result_matched_relaxed.remove(this_row_matched_relaxed)
            unique_id = f"""{item["seq_no"]:06}_{this_row_true}"""
            target_in_initial_candidates = get_candidate_position(
                item["extra"].get("initial_candidates", None), this_row_true
            )
            if (
                target_in_initial_candidates is not None
                and target_in_initial_candidates >= 0
            ):
                target_es_score = item["extra"]["initial_candidates"][
                    target_in_initial_candidates
                ]["elasticsearch_score"]
            else:
                target_es_score = None
            matched_name = get_matched_name(item, this_row_matched)
            data.append(
                {
                    "unique_id": unique_id,
                    "seq_no": item["seq_no"],
                    "input": item["input"],
                    "true_link": this_row_true,
                    "matched": this_row_matched,
                    "matched_relaxed": this_row_matched_relaxed,
                    "res_cat": res_cat(this_row_true, this_row_matched),
                    "res_cat_relaxed": res_cat(
                        this_result_true_relaxed[i], this_row_matched_relaxed
                    ),
                    "matched_name": matched_name,
                    "target_in_initial_candidates": target_in_initial_candidates,
                    "target_es_score": target_es_score,
                    "weight": item.get("weight"),
                }
            )
    return data
