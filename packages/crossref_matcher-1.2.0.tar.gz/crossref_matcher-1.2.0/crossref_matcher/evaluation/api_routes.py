import json
from starlette.responses import JSONResponse
from typing import Any
from fastapi import APIRouter


class AsciiJSONResponse(JSONResponse):
    def render(self, content: Any) -> bytes:
        return json.dumps(content, ensure_ascii=True).encode("utf-8")


router = APIRouter(
    prefix="/evaluate",
    tags=["Evaluation"],
)


@router.get("/", tags=["Evaluation"], response_class=AsciiJSONResponse)
async def evaluation_coming_soon():
    return {"message": "Evaluation endpoints coming soon!"}
