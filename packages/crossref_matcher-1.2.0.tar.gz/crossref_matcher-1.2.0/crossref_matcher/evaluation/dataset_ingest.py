from typing import Iterable, Mapping
from collections import defaultdict
import re
from pathlib import Path
from math import isnan

from crossref_matcher.evaluation.schemas import Dataset

import logging

logger = logging.getLogger(__name__)


def _check_isnan(x):
    return x is None or (isinstance(x, float) and isnan(x))


def prepare_alternates(
    data: Iterable[tuple[str, str, str]],
) -> Mapping[str, list[tuple[str, str]]]:
    """Prepare alternate matches and negatives from the input data.

    Args:
        data (Iterable[tuple[str, str, str]]): Input data as list of 3-tuples.

    Returns:
        _type_: Mapping[str, list[tuple[str, str]]]
        alternate_matches: Mapped alternate matches.
    """
    alternate_matches_mapped = defaultdict(list)
    for x in data:
        alternate_matches_mapped[x[0]].append((x[1], x[2]))
    return alternate_matches_mapped


def process_eval_data(
    data: Iterable[dict],
    dataset_id: str,
    task_id: str,
    collected_at: str | None = None,
    input_fieldname: str = "name",
    output_fieldname: str = "matched_id",
    unmatched_value: str = "no_match",
    alternates: Mapping[str, list[tuple[str, str]]] | None = None,
    weights_fieldname: str | None = None,
    save_file: bool | str | Path = False,
) -> Dataset:
    """
    Process raw evaluation data into a structured Dataset format.

    This function transforms raw evaluation data (typically from CSV/JSON files)
    into a standardized Dataset schema for use with the evaluation framework.
    It handles input/output mapping, alternate matches, weights, and optional
    file saving.

    Args:
        data: Iterable of dictionaries containing raw evaluation records.
              Each dict should have fields for input text (see input_fieldname)
              and expected outputs (see output_fieldname).
        dataset_id: Unique identifier for this dataset. If it contains a date
                   in YYYY-MM-DD format, that date will be used as collected_at
                   if not explicitly provided.
        task_id: Identifier for the evaluation task this dataset supports.
        collected_at: Optional date string (YYYY-MM-DD) when data was collected.
                     If None, attempts to extract from dataset_id.
        input_fieldname: Field name containing the input text to be processed.
                        Defaults to "name".
        output_fieldname: Field name containing expected output links/matches.
                         Can contain multiple values separated by semicolons.
                         Defaults to "matched_id".
        unmatched_value: Value in output field that indicates no match expected.
                        Defaults to "no_match".
        alternates: Optional mapping from input strings to lists of
                          alternate acceptable matches. Each alternate is a
                          tuple of (alternate id, relaxed id). See documentation.
        weights_fieldname: Optional field name containing numeric weights for
                          each evaluation item. If None, no weights are applied.
        save_file: Controls dataset file saving:
                  - False: Don't save (default)
                  - True: Save to ../data/datasets/{dataset_id}.json
                  - str/Path: Save to specified file path

    Returns:
        Dataset: Validated dataset object containing structured evaluation data.
                Each data point includes seq_no, input, output list, alternates,
                and optional weight.

    Raises:
        ValueError: If data is None or empty.

    Note:
        - Rows with empty/NaN output values are skipped entirely
        - Output values are split on semicolon to handle multi-match cases
        - Sequential numbering (seq_no) is applied after filtering
        - The returned Dataset is validated against the schema
    """
    if data is None:
        raise ValueError("No data provided")
    if collected_at is None:
        # use a regex to find the first occurrence of a date string in `dataset_id` that looks like "YYYY-mm-dd"
        date_regex = r"\d{4}-\d{2}-\d{2}"
        match = re.search(date_regex, dataset_id)
        if match:
            collected_at = match.group(0)
    out = {
        "id": dataset_id,
        "task_id": task_id,
        "collected_at": collected_at,
        "data_points": [],
    }
    i = 0
    for row in data:
        if row[output_fieldname] == unmatched_value:
            this_output = []
        elif not row[output_fieldname] or _check_isnan(row[output_fieldname]):
            continue
        else:
            this_output = row[output_fieldname].split(";")
        this_item = {
            "seq_no": i,
            "input": row[input_fieldname],
            "output": this_output,
        }
        if alternates is not None:
            this_item["alternates"] = alternates.get(row[input_fieldname], [])
        if weights_fieldname is not None:
            this_item["weight"] = row[weights_fieldname]
        out["data_points"].append(this_item)
        i += 1

    out = Dataset.model_validate(out)

    if save_file is True:
        outfp = Path("../data/datasets/").joinpath(f"{dataset_id}.json")
    elif save_file is False:
        outfp = None
        logger.debug("Not saving dataset to file.")
    else:
        outfp = Path(save_file)
    if outfp is not None:
        logger.info(f"Saving dataset to {outfp}")
        outfp.write_text(out.model_dump_json(indent=2))
    return out
