from collections import defaultdict
from datetime import datetime, timezone
from typing import Iterable, Callable
import inspect

from crossref_matcher.evaluation.schemas import (
    DataPointExtended,
    ResultSet,
)

from sklearn.metrics import precision_recall_fscore_support
from sklearn.preprocessing import MultiLabelBinarizer

import logging

logger = logging.getLogger(__name__)


def get_matched_alternate(item):
    """Transform matched IDs using alternate mappings.

    Maps matched IDs to their alternate representations based on the
    alternates mapping. If an alternate is "no_match", the ID is excluded.
    If no alternate exists, the original ID is kept.

    Args:
        item (dict): Item containing:
            - "matched" (list[str]): List of matched IDs
            - "alternates" (list[tuple[str, str]]): List of (alternate, relaxed) ID pairs.

    Returns:
        list[str]: List of transformed IDs with alternates applied

    Example:
        >>> item = {
        ...     "matched": ["alt1", "id2", "id3"],
        ...     "alternates": [("alt1", "id1"), ("id2", "no_match")]
        ... }
        >>> get_matched_alternate(item)
        ["id1", "id3"]
    """
    # get a mapping of alternates to list of relaxed IDs
    alternates_mapping = defaultdict(list)
    for alt, relaxed in item.get("alternates", []):
        alternates_mapping[alt].append(relaxed)

    matched_alternate = []
    for matched_id in item["matched"]:
        alt = alternates_mapping.get(matched_id)
        if not alt:
            matched_alternate.append(matched_id)
        else:
            for item in alt:
                if item == "no_match":
                    continue
                else:
                    matched_alternate.append(item)
    return matched_alternate


class EvaluateSklearn:
    """Scikit-learn based evaluation framework for multi-label classification tasks.

    Provides comprehensive evaluation metrics including precision, recall, F-scores
    with configurable beta values, and support for weighted samples and alternate
    matching scenarios (relaxed evaluation).

    Attributes:
        items (list[dict]): Original evaluation items
        y_true (list[list[str]]): True labels for each item
        sample_weights (list[float] | None): Optional sample weights
        f_score_betas (tuple[float]): Beta values for F-score calculation
        mlb (MultiLabelBinarizer): Scikit-learn binarizer for labels
        true_positives (int): Total count of true positive labels
    """

    def __init__(
        self,
        items: list[dict],
        sample_weights: Iterable[float] | None = None,
        f_score_betas: Iterable[float] = (1.0, 0.5),
    ):
        """Initialize the evaluator with items and optional parameters.

        Args:
            items (list[dict]): Evaluation items, each containing:
                - "output" (list[str]): Ground truth labels
                - "matched" (list[str]): Predicted labels
                - "alternates" (list[tuple[str, str]], optional): Alternate mappings for relaxed evaluation
            sample_weights (Iterable[float] | None): Optional weights for samples.
                If provided, must have same length as items.
            f_score_betas (Iterable[float]): Beta values for F-score calculation.
                Default is (1.0, 0.5) for F1 and F0.5 scores.

        Example:
            >>> items = [
            ...     {"output": ["A", "B"], "matched": ["A"]},
            ...     {"output": ["C"], "matched": ["C", "D"]}
            ... ]
            >>> evaluator = EvaluateSklearn(items, f_score_betas=(1.0, 2.0))
        """
        self.items = items
        self.y_true: Iterable[Iterable[str]] = [item["output"] for item in items]
        self.sample_weights = sample_weights
        self.mlb = MultiLabelBinarizer(sparse_output=True)
        self.mlb.fit(self.y_true)
        self.true_positives = sum(len(y) for y in self.y_true)
        self.f_score_betas = f_score_betas

    def run_one_evaluation(
        self,
        y_true: Iterable[Iterable[str]],
        y_pred: Iterable[Iterable[str]],
        sample_weights: Iterable[float] | None = None,
        f_score_betas: Iterable[float] | None = None,
    ):
        """Compute evaluation metrics for multi-label classification predictions
        using scikit-learn.

        Calculates precision, recall, F-scores with configurable beta values, and
        counts false positives/negatives using scikit-learn's implementation.

        Args:
            y_true (Iterable[Iterable[str]]): Ground truth labels for each sample.
                Each inner iterable contains the true labels for one sample.
            y_pred (Iterable[Iterable[str]]): Predicted labels for each sample.
                Each inner iterable contains the predicted labels for one sample.
            sample_weights (Iterable[float] | None): Optional weights for each sample.
                If provided, must have same length as y_true/y_pred. Used for
                weighted metric calculation.
            f_score_betas (Iterable[float] | None): Beta values for F-score calculation.
                If None, uses instance's f_score_betas. If empty, defaults to [1.0].
                Beta controls the balance between precision and recall:
                - β=1.0: F1 score (equal weight to precision and recall)
                - β<1.0: Favors precision (e.g., β=0.5 for F0.5)
                - β>1.0: Favors recall (e.g., β=2.0 for F2)

        Returns:
            dict: Evaluation metrics containing:
                - "total" (int): Number of samples evaluated
                - "false_positives" (int): Count of falsely predicted positive labels
                - "false_negatives" (int): Count of missed true positive labels
                - "precision" (float): Micro-averaged precision (0.0 to 1.0)
                - "recall" (float): Micro-averaged recall (0.0 to 1.0)
                - "f_scores" (list[dict]): List of F-score results, each containing:
                    - "score" (float): F-score value (0.0 to 1.0)
                    - "beta" (float): Beta parameter used for this score

        Note:
            - Uses micro-averaging which aggregates contributions across all samples
            - Handles empty label sets by returning perfect scores (1.0)
            - Zero division is handled gracefully (returns 0.0)
            - MultiLabelBinarizer is refitted for each evaluation to handle new labels
        """

        if f_score_betas is None:
            f_score_betas = self.f_score_betas
        if not f_score_betas:
            f_score_betas = [1.0]

        # Handle edge case where both y_true and y_pred are all empty
        all_labels = list(y_true) + list(y_pred)
        if not any(labels for labels in all_labels):
            # All empty - perfect match case
            # Bypass scikit-learn to avoid issues with empty classes
            f_scores = [{"score": 1.0, "beta": beta} for beta in f_score_betas]
            return {
                "total": len(self.y_true),
                "false_positives": 0,
                "false_negatives": 0,
                "precision": 1.0,
                "recall": 1.0,
                "f_scores": f_scores,
            }

        self.mlb.fit(y_true + y_pred)
        y_true_transformed = self.mlb.transform(y_true)
        y_pred_transformed = self.mlb.transform(y_pred)
        at = y_true_transformed.toarray()
        af = y_pred_transformed.toarray()
        false_positives = int((af & (1 - at)).sum())
        false_negatives = int((at & (1 - af)).sum())
        f_scores = []
        for beta in f_score_betas:
            precision, recall, fscore, _ = precision_recall_fscore_support(
                at,
                af,
                average="micro",
                zero_division=0.0,
                sample_weight=sample_weights,
                beta=beta,
            )
            f_scores.append(
                {
                    "score": fscore,
                    "beta": beta,
                }
            )
        return {
            "total": len(self.y_true),
            "false_positives": false_positives,
            "false_negatives": false_negatives,
            "precision": precision,
            "recall": recall,
            "f_scores": f_scores,
        }

    def evaluate(self, has_alternates: bool = False):
        """Perform comprehensive evaluation with optional relaxed matching.

        Evaluates the items provided during initialization, computing both standard
        and weighted metrics. When alternates are available, also computes "relaxed"
        metrics that consider alternate mappings and exclude negative alternates.

        Args:
            has_alternates (bool): Whether to perform relaxed evaluation using
                alternate mappings. If True, items must contain "alternates" field.

        Returns:
            dict: Evaluation results containing:
                - "unweighted" (dict): Standard evaluation metrics
                - "weighted" (dict, optional): Weighted metrics (if sample_weights provided)
                - "relaxed_unweighted" (dict, optional): Relaxed metrics (if has_alternates=True)
                - "relaxed_weighted" (dict, optional): Weighted relaxed metrics

                Each metrics dict contains the same structure as run_one_evaluation() output.

        Note:
            - Relaxed evaluation applies get_matched_alternate() to transform predictions
            - Negative alternates are excluded from both true and predicted labels
            - Weighted versions only included if sample_weights were provided during init
            - All evaluations use the same F-score betas configured during initialization
        """
        out = {}
        y_pred = [item["matched"] for item in self.items]
        if self.sample_weights is not None:
            out["weighted"] = self.run_one_evaluation(
                self.y_true, y_pred, sample_weights=self.sample_weights
            )
            out["unweighted"] = self.run_one_evaluation(
                self.y_true, y_pred, sample_weights=None
            )
        else:
            out["unweighted"] = self.run_one_evaluation(
                self.y_true, y_pred, sample_weights=None
            )

        if has_alternates is True:
            y_true_relaxed = []
            y_pred_relaxed = []
            for item in self.items:
                negative_alternates = [
                    x[1] for x in item.get("alternates", []) if x[0] == "no_match"
                ]
                y_true_relaxed.append(
                    [x for x in item["output"] if x not in negative_alternates]
                )
                altmatches = [
                    x
                    for x in get_matched_alternate(item)
                    if x not in negative_alternates
                ]
                y_pred_relaxed.append(altmatches)
            if self.sample_weights is not None:
                out["relaxed_weighted"] = self.run_one_evaluation(
                    y_true_relaxed, y_pred_relaxed, sample_weights=self.sample_weights
                )
                out["relaxed_unweighted"] = self.run_one_evaluation(
                    y_true_relaxed, y_pred_relaxed, sample_weights=None
                )
            else:
                out["relaxed_unweighted"] = self.run_one_evaluation(
                    y_true_relaxed, y_pred_relaxed, sample_weights=None
                )

        return out


def run_strategy_on_eval_data(
    strategy,
    eval_data: list[DataPointExtended],
    resultsetid: str,
    task_id: str,
    datasetid: str = "",
    extra_fn: Callable | None = None,
    include_code_module: bool = False,
) -> ResultSet:
    """Run a matching strategy on evaluation data and return the results.

    Args:
        strategy: The matching strategy to use.
        eval_data (list[DataPointExtended]): The evaluation data to use.
        resultsetid (str): The ID of the result set.
        task_id (str): The ID of the task.
        datasetid (str, optional): The ID of the dataset. Defaults to empty string.
        extra_fn (Callable | None, optional): An optional extra function to apply.
            It is run for each data point, and is passed the following arguments:
            strategy, data_point, this_result. It should return a dictionary which
            is merged into the 'extra' field of the result item.
        include_code_module (bool, optional): Whether to include the code module
            in the results. Defaults to False.

    Returns:
        ResultSet: The results of the evaluation.

    An example of an extra function, which makes use of a strategy that saves the "initial_candidates" and the "fund_countries" attributes for each match attempt:

    def _extra_fn(
        strategy,
        data_point,
        this_result,
    ):
        matched_ids = [item["id"] for item in this_result]
        matched_tp = [matched in data_point["output"] for matched in matched_ids]
        matched_fp = [not x for x in matched_tp]
        initial_candidates = getattr(strategy, "initial_candidates", [])
        detected_countries = getattr(strategy, "fund_countries", None)
        return {
            "detected_countries": detected_countries,
            "matching_result": this_result,
            "matched_tp": matched_tp,
            "false_positive_count": sum(matched_fp),
            "false_negative_count": len(data_point["output"]) - sum(matched_tp),
            "initial_candidates": initial_candidates,
        }

    Supplying this function to run_strategy_on_eval_data would add these items to the 'extra' field of each result item.
    """
    out = {
        "id": resultsetid,
        "strategy_id": strategy.strategy,
        "dataset_id": datasetid,
        "task_id": task_id,
        "matched_at": datetime.now(timezone.utc),
        "results": [],
        "extra": {},
    }
    sample_weights = []
    dataset_has_alternates = False
    for data_point in eval_data:
        logger.debug(f"matching data point {data_point.seq_no}")
        this_result = strategy.match(data_point.input)
        matched_ids = [item["id"] for item in this_result]
        out_item = {
            "seq_no": data_point.seq_no,
            "input": data_point.input,
            "output": data_point.output,
            "matched": matched_ids,
        }
        out_item["extra"] = {}
        if extra_fn is not None:
            extra_data = extra_fn(strategy, data_point, this_result)
            out_item["extra"].update(extra_data)

        if hasattr(data_point, "alternates"):
            dataset_has_alternates = True
            out_item["alternates"] = data_point.alternates
        this_weight = getattr(data_point, "weight", 1.0)
        out_item["weight"] = this_weight
        out["results"].append(out_item)
        sample_weights.append(this_weight)
    evaluator = EvaluateSklearn(out["results"], sample_weights=sample_weights)
    out["statistics"] = evaluator.evaluate(has_alternates=dataset_has_alternates)
    if include_code_module is True:
        try:
            out["extra"]["code_module"] = inspect.getsource(strategy.__class__)
        except OSError:
            out["extra"]["code_module"] = "source code not available"

    return ResultSet.model_validate(out)
