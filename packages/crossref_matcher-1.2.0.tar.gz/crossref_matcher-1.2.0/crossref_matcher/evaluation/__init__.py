import warnings
from .api_routes import router as router

try:
    from .evaluation import (
        get_matched_alternate as get_matched_alternate,
        EvaluateSklearn as EvaluateSklearn,
        run_strategy_on_eval_data as run_strategy_on_eval_data,
    )
except ImportError as e:
    warnings.warn(
        f"Error when importing evaluation module. Some functionality may be unavailable: {e}"
    )
