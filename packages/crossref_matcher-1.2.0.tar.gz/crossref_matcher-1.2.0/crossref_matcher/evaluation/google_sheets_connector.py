import gspread
from gspread_dataframe import set_with_dataframe, get_as_dataframe
import pandas as pd


class GoogleSheetsConnector:
    def __init__(self, creds_json: str, sheet_url: str) -> None:
        self.creds_json = creds_json
        self.sheet_url = sheet_url
        self.client = gspread.service_account(filename=creds_json)
        self.sheet = self.client.open_by_url(sheet_url)

    def set_data_with_template(
        self,
        data: pd.DataFrame,
        template_sheet_title: str,
        new_sheet_title: str,
        include_index: bool = True,
    ) -> None:
        template_sheet = self.sheet.worksheet(template_sheet_title)
        new_sheet = template_sheet.duplicate(
            insert_sheet_index=len(self.sheet.worksheets()),
            new_sheet_name=new_sheet_title,
        )
        set_with_dataframe(
            new_sheet, data, include_index=include_index, include_column_header=True
        )

    def get_worksheet_as_dataframe(
        self, sheet_title: str, index_col=0, **options
    ) -> pd.DataFrame:
        sheet = self.sheet.worksheet(sheet_title)
        return get_as_dataframe(sheet, index_col=index_col, **options)
