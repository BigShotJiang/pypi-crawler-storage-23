from pydantic import BaseModel, ConfigDict, Field


def to_kebab(string: str) -> str:
    if string is None:
        return None
    return "-".join(string.split("_"))


class Item(BaseModel):
    model_config = ConfigDict(
        from_attributes=True, populate_by_name=True, alias_generator=to_kebab
    )


class Response(Item):
    status: str = "ok"
    message_version: str = "1.0.0"
    message_type: str


class Message(Item):
    pass


class HeartbeatResponse(Response):
    message_type: str = "heartbeat"


class Task(Item):
    id: str
    description: str
    default_strategy: str = "UNKNOWN"


class Strategy(Item):
    id: str
    description: str
    default: bool
    disabled: bool = False


class MatchedItem(Item):
    id: str
    confidence: float
    strategies: list[str]


class TasksMessage(Message):
    items: list[Task]


class StrategiesMessage(Message):
    items: list[Strategy]


class MatchedItemsMessage(Message):
    items: list[MatchedItem] = Field(default_factory=list)
    target_data: str | None = Field(
        default=None,
        description="String identifying the target database matched against, e.g., 'ROR v1.67-2025-06-24'",
    )
    strategy: str | None = Field(
        default=None,
        description="Name of the strategy used for matching",
    )


class TasksResponse(Response):
    message_type: str = "task-list"
    message: TasksMessage


class StrategiesResponse(Response):
    message_type: str = "strategy-list"
    message: StrategiesMessage


class MatchedItemsResponse(Response):
    message_type: str = "matched-item-list"
    message: MatchedItemsMessage
