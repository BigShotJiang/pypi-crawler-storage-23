import boto3
import os

from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth


def get_auth():
    credentials = boto3.Session().get_credentials()
    return AWSV4SignerAuth(credentials, "us-east-1", "es")


ES_CLIENT = None


def get_es_client(hostname):
    return OpenSearch(
        hosts=[{"host": hostname, "port": 443}],
        http_auth=get_auth(),
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20,
    )


def get_es_client_dev(hostname: str, port: int = 9200):
    return OpenSearch(
        hosts=[{"host": hostname, "port": port}],
        use_ssl=False,
        verify_certs=False,
        ssl_assert_hostname=False,
        ssl_show_warn=False,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20,
    )


if os.getenv("ES_HOST"):
    ES_CLIENT = get_es_client(os.getenv("ES_HOST"))
elif os.environ.get("ES_HOST_DEV"):
    port = int(os.getenv("ES_PORT", "9200"))
    ES_CLIENT = get_es_client_dev(os.getenv("ES_HOST_DEV"), port=port)
