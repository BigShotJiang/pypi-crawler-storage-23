import requests
from ratelimit import limits, sleep_and_retry
from datetime import timedelta


@sleep_and_retry
@limits(calls=10, period=timedelta(seconds=1).total_seconds())
def crossref_rest_api_call(route, params):
    params["mailto"] = "marple@crossref.org"
    result = requests.get(f"https://api.crossref.org/{route}", params)
    code = result.status_code
    if code == 200:
        result = result.json()["message"]
    return code, result
