import re

import importlib.resources as resources


def doi_id(doi_str):
    if doi_str is None:
        return None
    return f"https://doi.org/{doi_str}"


def get_resource_path(module, file):
    """Get path to a resource file in a package."""
    return str(resources.files(module) / file)


def get_package_resources(module, regex=""):
    """Get list of resource files in a package matching a regex."""
    modulepath = str(resources.files(module))
    return [
        str(modulepath / f)
        for f in resources.files(module).iterdir()
        if f.is_file() and re.findall(regex, f.name)
    ]
