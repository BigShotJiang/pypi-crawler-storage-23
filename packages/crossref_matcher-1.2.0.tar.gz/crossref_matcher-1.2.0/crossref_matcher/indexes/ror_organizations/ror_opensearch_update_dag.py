"""Airflow DAG to keep the ROR OpenSearch index up to date."""

import base64
import boto3

from airflow.decorators import dag, task
from datetime import datetime
from datetime import timedelta
from opensearchpy import (
    OpenSearch,
    RequestsHttpConnection,
    AWSV4SignerAuth,
    NotFoundError,
)

import logging
from typing import Any

from crossref_matcher.indexes.ror_organizations.ror_zenodo_api import (
    get_ror_data_dump_metadata,
)
from crossref_matcher.indexes.ror_organizations.create_index import (
    index_body,
    initialize_index,
)
from crossref_matcher.indexes.ror_organizations.index_data import (
    download_ror_data_and_update_index,
)

logger = logging.getLogger(__name__)

REGION = "us-east-1"
INDEX = "organization"
INDEX_BATCH_SIZE = 400


def get_secret(secret_name: str) -> str | bytes:
    """Retrieve a secret value from AWS Secrets Manager."""
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=REGION)

    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    if "SecretString" in get_secret_value_response:
        return get_secret_value_response["SecretString"]
    else:
        return base64.b64decode(get_secret_value_response["SecretBinary"])


def get_es_client() -> OpenSearch:
    """Create an authenticated OpenSearch client using AWS credentials."""
    credentials = boto3.Session().get_credentials()
    auth = AWSV4SignerAuth(credentials, REGION, "es")

    return OpenSearch(
        hosts=[{"host": get_secret("es-host-matching"), "port": 443}],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20,
    )


@dag(
    schedule_interval="@daily",
    catchup=False,
    dagrun_timeout=timedelta(hours=10),
    start_date=datetime(2026, 1, 3),
    tags=["experiment", "ror", "matching"],
)
def update_ror_index():
    @task()
    def fetch_ror_metadata() -> dict[str, Any]:
        """Fetch metadata for the latest ROR data dump from Zenodo."""
        return get_ror_data_dump_metadata()

    @task.short_circuit()
    def is_update_needed(metadata: dict[str, Any]) -> bool:
        """Return True if the index checksum differs from the latest dump."""
        ror_checksum = metadata["checksum"]
        es_client = get_es_client()

        # # FOR TESTING: RUN THIS TO FORCE UPDATE, OTHERWISE COMMENT OUT
        # index_metadata = {
        #     "target_data": "",
        #     "ror_data_dump_checksum": "",
        #     "ror_data_dump_doi": "",
        # }
        # body = {"_meta": index_metadata}
        # es_client.indices.put_mapping(index=INDEX, body=body)

        try:
            mapping = es_client.indices.get_mapping(index=INDEX)
        except NotFoundError:
            return True
        meta = mapping[INDEX]["mappings"].get("_meta", {})
        current_checksum = meta.get("ror_data_dump_checksum", "")
        return current_checksum != ror_checksum

    @task()
    def create_index_if_not_exists():
        es_client = get_es_client()

        index_exists = es_client.indices.exists(index=INDEX)

        if not index_exists:
            index_body_content = index_body()
            response = initialize_index(INDEX, es_client, index_body_content)
            logger.info(f"Created index '{INDEX}': {response}")

    @task
    def download_and_update(metadata: dict[str, Any]) -> None:
        """Download the ROR data dump and update the index."""
        es_client = get_es_client()
        download_ror_data_and_update_index(metadata, es_client)

    metadata = fetch_ror_metadata()
    update_needed = is_update_needed(metadata)
    # if update_needed is false, the DAG will stop here

    update_needed >> create_index_if_not_exists() >> download_and_update(metadata)


workflow = update_ror_index()
