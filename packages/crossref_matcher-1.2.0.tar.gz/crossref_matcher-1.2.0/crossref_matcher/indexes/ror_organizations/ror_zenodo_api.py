import requests

API_URL = "https://zenodo.org/api/records/6347574"


def get_ror_data_dump_metadata(api_url: str = API_URL) -> dict:
    """Fetch Zenodo metadata for the latest ROR data dump."""
    response = requests.get(api_url, allow_redirects=True)
    response.raise_for_status()
    metadata = response.json()

    # Extract file information
    file_info = metadata["files"][0]
    filename = file_info["key"]
    download_url = file_info["links"]["self"]
    checksum = file_info["checksum"]
    doi = metadata["doi"]
    return {
        "filename": filename,
        "download_url": download_url,
        "checksum": checksum,
        "doi": doi,
    }
