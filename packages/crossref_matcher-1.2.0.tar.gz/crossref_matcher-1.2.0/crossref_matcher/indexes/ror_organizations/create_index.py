"""Create and initialize the ROR organizations OpenSearch index."""

from opensearchpy import OpenSearch
from opensearchpy.exceptions import NotFoundError

import logging

logger = logging.getLogger(__name__)

INDEX = "organization"


def index_body() -> dict:
    """Return the OpenSearch settings and mappings for the ROR index."""
    return {
        "settings": {
            "number_of_shards": 1,
            "analysis": {
                "analyzer": {
                    "string_lowercase": {
                        "tokenizer": "standard",
                        "filter": ["lowercase", "asciifolding"],
                    }
                },
            },
        },
        "mappings": {
            "_meta": {
                "target_data": "",  # to be filled in when indexing. E.g., 'ROR v1.67-2025-06-24'
                "ror_data_dump_checksum": "",  # to be filled in when indexing
                "ror_data_dump_doi": "",  # to be filled in when indexing
            },
            "properties": {
                "id": {"type": "keyword"},
                "country": {"type": "keyword"},
                "status": {"type": "keyword"},
                "primary": {"type": "text", "analyzer": "string_lowercase"},
                "names": {
                    "type": "nested",
                    "properties": {
                        "name": {"type": "text", "analyzer": "string_lowercase"},
                    },
                },
                "relationships": {
                    "properties": {
                        "type": {"type": "keyword"},
                        "id": {"type": "keyword"},
                    }
                },
                "placenames": {
                    "type": "nested",
                    "properties": {
                        "placename": {"type": "keyword"},
                    },
                },
                "acronymns": {"type": "keyword"},
                "descendents": {"type": "keyword"},
            },
        },
    }


def initialize_index(index: str, es_client: OpenSearch, body: dict) -> dict:
    """Create the OpenSearch index and return the client response.

    Args:
        index: Name of the index to create.
        es_client: OpenSearch client instance.
        body: Index settings and mappings payload.

    Returns:
        OpenSearch response payload from index creation.
    """
    response = es_client.indices.create(index=index, body=body)
    return response


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logging.getLogger("opensearch").setLevel(logging.WARNING)
    import argparse

    parser = argparse.ArgumentParser(
        description="Create OpenSearch index for affiliation matching"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force delete and recreate the index if it already exists",
    )
    args = parser.parse_args()

    from crossref_matcher.matching.search import ES_CLIENT as es_client

    # Check if index already exists
    index_exists = es_client.indices.exists(index=INDEX)

    if index_exists and not args.force:
        logger.info(
            f"Index '{INDEX}' already exists. Use --force to delete and recreate it."
        )
        exit(0)

    # Delete index if it exists and force flag is set
    if index_exists and args.force:
        try:
            response = es_client.indices.delete(index=INDEX)
            logger.info(f"Deleted existing index: {response}")
        except NotFoundError:
            logger.warning("Index not found during deletion")

    index_body_content = index_body()

    response = initialize_index(INDEX, es_client, index_body_content)
    logger.info(f"Created index '{INDEX}': {response}")
