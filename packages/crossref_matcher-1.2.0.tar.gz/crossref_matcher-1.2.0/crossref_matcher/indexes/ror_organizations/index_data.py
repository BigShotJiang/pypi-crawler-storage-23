"""Index ROR organization data into OpenSearch."""

from typing import Iterable, Iterator
import json
import re
from collections import defaultdict
import requests
from zipfile import ZipFile
import io

from opensearchpy import OpenSearch

import logging

logger = logging.getLogger(__name__)


INDEX = "organization"
PINNED_ROR_VERSION = "v1.67-2025-06-24-ror-data"
INTEGRATION_TESTING_ROR_DATA_URLS = [
    # Download ROR data from public Crossref S3 bucket (preferred) or Zenodo (fallback).
    # Note: Zenodo API is slow and rate-limited, so S3 is preferred.
    f"https://s3.us-east-1.amazonaws.com/outputs.research.crossref.org/ror_data/{PINNED_ROR_VERSION}.zip",
    "https://zenodo.org/api/records/15731450/files/v1.67-2025-06-24-ror-data.zip/content",
]


def get_names(org: dict) -> Iterator[str]:
    """Yield non-acronym organization names from a ROR record."""
    for name in org["names"]:
        if "acronym" not in name["types"]:
            yield name["value"]


def get_primary_name(org: dict) -> str:
    """Return the primary (ROR display) name for an organization."""
    return [n["value"] for n in org["names"] if "ror_display" in n["types"]][0]


def get_descendents(ror_data: Iterable[dict]) -> dict[str, list[str]]:
    """Build a mapping of org IDs to all descendant org IDs."""

    # for each organization, get the full lineage below it, including children, grandchildren, etc, using the "relationship" field
    def _get_children_recurse(
        org_id: str,
        child_map: dict[str, list[str]],
        visited: set[str] | None = None,
    ) -> list[str]:
        if visited is None:
            visited = set()
        if org_id in visited:
            return []
        visited.add(org_id)
        lineage = []
        for child_id in child_map.get(org_id, []):
            lineage.append(child_id)
            lineage.extend(_get_children_recurse(child_id, child_map, visited))
        return lineage

    descendents_map = defaultdict(list)
    child_map = defaultdict(list)
    for org in ror_data:
        org_id = org.get("id")
        relationships = org.get("relationships", [])
        for rel in relationships:
            if rel.get("type", "").lower() == "child" and "id" in rel:
                child_map[org_id].append(rel["id"])

    for org in ror_data:
        org_id = org.get("id")
        descendents_map[org_id] = _get_children_recurse(org_id, child_map)
    # descendents_map now maps each org to a list of all its descendants (children, grandchildren, etc.)
    return descendents_map


def get_name_clusters_with_clear_parent(
    primary_names: dict[str, str], descendents_map: dict[str, list[str]]
) -> dict[str, dict]:
    """Find name clusters with a single clear parent organization.

    Clusters are grouped by primary name with any trailing parenthetical removed.
    A clear parent is an org whose descendants include all others in the cluster.
    """
    # find clusters of organizations that share the same name (ignoring any parenthetical phrases at the end of the name)
    # if one organization in the cluster is a parent of all the others, mark it as the "clear parent"

    # regex pattern to find a phrase in parentheses at the end of a string
    pattern_parentheses = re.compile(r"\s*\(([^)]+)\)\s*$")
    clusters = defaultdict(list)
    names_without_parentheses = {
        k: pattern_parentheses.sub("", v).strip() for k, v in primary_names.items()
    }
    for ror_id, name_no_parentheses in names_without_parentheses.items():
        clusters[name_no_parentheses].append(ror_id)
    has_clear_parent = {}
    for name, ror_ids in clusters.items():
        if len(ror_ids) > 1:
            for ror_id in ror_ids:
                descendants = descendents_map[ror_id]
                if len(descendants) > 0 and all(
                    other_id in descendants
                    for other_id in ror_ids
                    if other_id != ror_id
                ):
                    if name in has_clear_parent:
                        raise ValueError(
                            f"Multiple clear parents found for name '{name}': {has_clear_parent[name]['parent']} and {ror_id}"
                        )
                    has_clear_parent[name] = {
                        "parent": ror_id,
                        "children": [
                            other_id for other_id in ror_ids if other_id != ror_id
                        ],
                    }
    return has_clear_parent


def update_index_metadata(
    index: str, es_client: OpenSearch, index_metadata: dict
) -> None:
    """Update index metadata and validate required fields."""
    REQUIRED_KEYS = ["target_data", "ror_data_dump_checksum", "ror_data_dump_doi"]
    missing_keys = [k for k in REQUIRED_KEYS if k not in index_metadata]
    if missing_keys:
        raise ValueError(
            f"Index metadata must have required keys: {REQUIRED_KEYS}. Missing key(s): {', '.join(missing_keys)}"
        )
    body = {"_meta": index_metadata}
    es_client.indices.put_mapping(index=index, body=body)


def unzip_ror_data(r_zipfile: requests.Response) -> list[dict] | None:
    """Extract ROR JSON data from a zipped response payload."""
    with ZipFile(io.BytesIO(r_zipfile.content)) as myzip:
        files = [file for file in myzip.namelist() if file.endswith(".json")]
        # if any of the files contain "schema_v2" in their name, get that one, otherwise get the first json file
        json_file = None
        for file in files:
            if "schema_v2" in file:
                json_file = file
                break
        if not json_file and files:
            json_file = files[0]
        if json_file:
            with myzip.open(json_file) as myfile:
                ror_data = json.loads(myfile.read())
                return ror_data
    return None


def index_organizations(
    index: str,
    es_client: OpenSearch,
    ror_data: Iterable[dict],
    index_metadata: dict | None = None,
    batch_size: int = 400,
) -> None:
    """Index ROR organizations into OpenSearch in batches."""
    if index_metadata:
        logger.info(f"updating index metadata for index {index} with {index_metadata}")
        update_index_metadata(index, es_client, index_metadata)

    primary_names = {org["id"]: get_primary_name(org) for org in ror_data}
    descendents_map = get_descendents(ror_data)
    to_exclude = []
    for v in get_name_clusters_with_clear_parent(
        primary_names, descendents_map
    ).values():
        to_exclude.extend(v["children"])
    to_exclude = set(to_exclude)

    organizations = []
    excluded = []
    for i, org in enumerate(ror_data):
        if org["id"] in to_exclude:
            excluded.append(org["id"])
            continue
        if i % 1000 == 0:
            logger.info(f"indexed {i} organizations")

        placenames = []
        for loc in org["locations"]:
            for k in ["country_name", "country_subdivision_name", "name"]:
                if loc["geonames_details"].get(k):
                    placenames.append(loc["geonames_details"][k])
        placenames = set(placenames)
        doc = {
            "id": org["id"],
            "country": org["locations"][0]["geonames_details"]["country_code"],
            "status": org["status"],
            "primary": primary_names[org["id"]],
            "names": [{"name": n} for n in get_names(org)],
            "relationships": [
                {"type": rel["type"], "id": rel["id"]} for rel in org["relationships"]
            ],
            "placenames": [{"placename": placename} for placename in placenames],
            "acronymns": [n["value"] for n in org["names"] if "acronym" in n["types"]],
            "descendents": descendents_map.get(org["id"], []),
        }

        if len(organizations) >= batch_size:
            bulk_data = "\n".join(organizations)
            res = es_client.bulk(body=bulk_data)
            if res["errors"]:
                logger.error(res)
            organizations = []
        organizations.append(json.dumps({"index": {"_index": index, "_id": org["id"]}}))
        organizations.append(json.dumps(doc))

    bulk_data = "\n".join(organizations)
    res = es_client.bulk(body=bulk_data)
    if res["errors"]:
        logger.error(res)
    logger.info(f"done, excluded {len(excluded)} organizations")


def download_ror_data_and_update_index(
    ror_dump_metadata: dict, es_client: OpenSearch
) -> None:
    """Download a ROR dump and index it, updating index metadata."""
    index_metadata = {
        "target_data": ror_dump_metadata["filename"].rsplit(".", 1)[0],
        "ror_data_dump_checksum": ror_dump_metadata["checksum"],
        "ror_data_dump_doi": ror_dump_metadata["doi"],
    }
    logger.info(
        f"Downloading ROR data from Zenodo URL {ror_dump_metadata['download_url']}..."
    )
    r_zipfile = requests.get(ror_dump_metadata["download_url"])
    logger.info("Unzipping ROR data...")
    ror_data = unzip_ror_data(r_zipfile)

    index_organizations(INDEX, es_client, ror_data, index_metadata=index_metadata)


def get_ror_data_pinned_url(urls: list[str]) -> list[dict]:
    """Download ROR data from the first reachable URL in a list."""
    ror_data = None
    for url in urls:
        logger.info(f"Downloading ROR data from {url}...")
        r_zipfile = requests.get(url)
        if r_zipfile.status_code == 200:
            ror_data = unzip_ror_data(r_zipfile)
            break
        else:
            logger.warning(f"Error downloading ROR data: {r_zipfile.status_code}")
    if not ror_data:
        raise RuntimeError("Error: could not download ROR data")
    return ror_data


def index_data_for_integration_testing(
    es_client: OpenSearch,
    urls: list[str] = INTEGRATION_TESTING_ROR_DATA_URLS,
    ror_version: str = PINNED_ROR_VERSION,
) -> None:
    """Index pinned ROR data for integration tests."""
    ror_data = get_ror_data_pinned_url(urls)
    index_metadata = {
        "target_data": ror_version,
        "ror_data_dump_checksum": "",
        "ror_data_dump_doi": "",
    }
    index_organizations(INDEX, es_client, ror_data, index_metadata=index_metadata)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logging.getLogger("opensearch").setLevel(logging.WARNING)
    import argparse

    parser = argparse.ArgumentParser(
        description="Index ROR organizations into OpenSearch for affiliation matching"
    )
    parser.add_argument(
        "--integration",
        action="store_true",
        help="Use pinned ROR data URLs for integration testing",
    )
    args = parser.parse_args()

    if args.integration:
        from crossref_matcher.matching.search import ES_CLIENT as es_client

        index_data_for_integration_testing(es_client=es_client)
    else:
        from crossref_matcher.matching.search import ES_CLIENT as es_client
        from crossref_matcher.indexes.ror_organizations.ror_zenodo_api import (
            get_ror_data_dump_metadata,
        )

        ror_dump_metadata = get_ror_data_dump_metadata()
        download_ror_data_and_update_index(ror_dump_metadata, es_client)
