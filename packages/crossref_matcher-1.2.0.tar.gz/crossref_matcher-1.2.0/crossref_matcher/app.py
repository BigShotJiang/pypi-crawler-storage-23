import os
import json
import time
from datetime import datetime
from starlette.responses import JSONResponse
from typing import Any
from contextlib import asynccontextmanager
from crossref_matcher import MatchTask, __version__
from crossref_matcher.evaluation.api_routes import router as evaluation_router
from crossref_matcher.matching import schemas
from crossref_matcher.strategies import (
    Strategy,
    get_default_strategy,
    list_strategies,
    get_strategy,
)

from fastapi import FastAPI, HTTPException, Request, Query
from typing import Union, Annotated

import logging

import uvicorn

logger = logging.getLogger(__name__)

# logging.getLogger("matching").setLevel(logging.DEBUG)
# handler = logging.StreamHandler()
# handler.setFormatter(
#     logging.Formatter(
#         fmt="%(asctime)s %(name)s.%(lineno)d %(levelname)s : %(message)s",
#         datefmt="%H:%M:%S",
#     )
# )
# logging.getLogger("matching").addHandler(handler)


class AsciiJSONResponse(JSONResponse):
    def render(self, content: Any) -> bytes:
        return json.dumps(content, ensure_ascii=True).encode("utf-8")


tags_metadata = [
    {"name": "Health", "description": "Health check endpoints."},
    {
        "name": "Tasks and strategies",
        "description": "Endpoints to list available matching tasks and strategies.",
    },
    {"name": "Matching", "description": "Endpoints to perform matching."},
    {
        "name": "Evaluation",
        "description": "Endpoints to evaluate matching strategies on datasets.",
    },
]


def warnings_config():
    if os.getenv("PYTEST_CURRENT_TEST"):
        return "log"
    elif os.getenv("MARPLE_TEST_MODULE"):
        return "ignore"
    else:
        return "warn"


@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup code goes here
    on_err = warnings_config()
    if os.getenv("MARPLE_TEST_MODULE"):
        m = Strategy.load_plugin_by_module_path(os.getenv("MARPLE_TEST_MODULE"))
        logger.info(f"Loaded module: {m}")

    # Load all plugins. Default error behavior is to warn.
    Strategy.load_plugins(on_err=on_err)
    yield
    # shutdown code goes here


app = FastAPI(
    title="Crossref Matching API",
    description="Matching API allows to match structured "
    "and unstructured data to identifiers.",
    lifespan=lifespan,
    version=__version__,
    openapi_tags=tags_metadata,
)


@app.middleware("http")
async def add_headers(request: Request, call_next):
    start_time = time.perf_counter()
    start_time_iso = datetime.fromtimestamp(time.time()).isoformat()
    response = await call_next(request)
    process_time = time.perf_counter() - start_time
    response.headers["X-Start-Time"] = start_time_iso
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["X-Service-Version"] = __version__
    return response


app.include_router(evaluation_router)


@app.get(
    "/heartbeat",
    response_model=schemas.HeartbeatResponse,
    tags=["Health"],
    description="Heartbeat",
    response_class=AsciiJSONResponse,
)
async def heartbeat():
    return {"status": "ok"}


@app.get(
    "/tasks",
    response_model=schemas.TasksResponse,
    tags=["Tasks and strategies"],
    description="The list of supported matching tasks.",
    response_class=AsciiJSONResponse,
)
async def list_tasks_endpoint():
    from crossref_matcher.strategies import (
        NoDefaultStrategyError,
        MultipleDefaultStrategiesError,
    )

    tasks = MatchTask.get_tasks()
    for task in tasks:
        try:
            default_strategy = get_default_strategy(task["id"])
            task["default_strategy"] = default_strategy.id
        except NoDefaultStrategyError:
            if task["id"] == "other":
                task["default_strategy"] = "N/A"
            else:
                task["default_strategy"] = "WARNING: No default strategy set"
        except MultipleDefaultStrategiesError:
            task["default_strategy"] = "WARNING: Multiple default strategies set"
    return schemas.TasksResponse(message=schemas.TasksMessage(items=tasks))


@app.get(
    "/tasks/{task_id}/strategies",
    response_model=schemas.StrategiesResponse,
    tags=["Tasks and strategies"],
    description="The list of strategies available for a given matching task.",
    response_class=AsciiJSONResponse,
)
async def list_strategies_endpoint(task_id: str, include_disabled: bool = False):
    task_id = task_id.replace("-matching", "")
    try:
        match_task = MatchTask(task_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="No such matching task")
    strategies = list_strategies(task=match_task.id, include_disabled=include_disabled)
    strategies = [
        {
            "id": s.id,
            "description": s.description,
            "default": s.is_default(),
            "disabled": s.is_disabled(),
        }
        for s in strategies
    ]
    return schemas.StrategiesResponse(
        message=schemas.StrategiesMessage(items=strategies)
    )


def match(
    task: str,
    input_data: str,
    strategy: Union[str, None] = None,
):
    task = task.replace("-matching", "")
    try:
        match_task = MatchTask(task)
    except ValueError:
        raise HTTPException(status_code=404, detail="No such matching task")

    try:
        strategy_class = get_strategy(strategy, match_task)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    try:
        strategy_id = strategy_class.id
        s = strategy_class()
        items = s.match(input_data)
        target_data = getattr(s, "target_data", None)
        items = [schemas.MatchedItem.model_validate(i) for i in items]
        return schemas.MatchedItemsResponse(
            message=schemas.MatchedItemsMessage(
                items=items, strategy=strategy_id, target_data=target_data
            )
        )
    except NotImplementedError:
        raise HTTPException(
            status_code=400,
            detail="Strategy is not implemented",
        )


@app.get(
    "/match",
    response_model=schemas.MatchedItemsResponse,
    tags=["Matching"],
    description="Match input to identifiers.",
    response_class=AsciiJSONResponse,
)
async def match_get(
    task: str,
    input_data: Annotated[str, Query(alias="input")],
    strategy: Union[str, None] = None,
):
    return match(task, input_data, strategy)


@app.post(
    "/match",
    response_model=schemas.MatchedItemsResponse,
    tags=["Matching"],
    description="Match input to identifiers.",
    response_class=AsciiJSONResponse,
)
async def match_post(
    request: Request,
    task: str,
    strategy: Union[str, None] = None,
):
    input_data = (await request.body()).decode("UTF-8")
    return match(task, input_data, strategy)


def run_app(host="0.0.0.0", port=8000):
    uvicorn.run(
        "crossref_matcher.app:app",
        host=host,
        port=port,
        reload=True,
        log_level="debug",
    )


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Run Crossref Matching API server")
    parser.add_argument(
        "--host", help="Host to run the server on", type=str, default="0.0.0.0"
    )
    parser.add_argument(
        "--port", help="Port to run the server on", type=int, default=8000
    )
    args = parser.parse_args()
    run_app(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
