from crossref_matcher.strategies import Strategy, MatchTask


class HealthcheckStrategy(Strategy):
    task = MatchTask.HEALTHCHECK
    id = "healthcheck-strategy"
    description = "A simple healthcheck strategy that always returns healthy."
    default = True

    def match(self, *args, **kwargs):
        return [
            {
                "id": "healthy",
                "confidence": 1.0,
                "strategies": [self.id],
            }
        ]
