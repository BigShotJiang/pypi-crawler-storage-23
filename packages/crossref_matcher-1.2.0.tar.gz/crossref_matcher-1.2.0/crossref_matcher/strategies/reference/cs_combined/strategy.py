from crossref_matcher.strategies import Strategy, MatchTask


class CsCombined(Strategy):
    task = MatchTask.REFERENCE
    id = "reference-cs-combined"
    description = (
        "Strategy used in CS on deposits. Here only for evaluation "
        + "purposes, no code is available."
    )

    def match(self, input_data):
        raise NotImplementedError
