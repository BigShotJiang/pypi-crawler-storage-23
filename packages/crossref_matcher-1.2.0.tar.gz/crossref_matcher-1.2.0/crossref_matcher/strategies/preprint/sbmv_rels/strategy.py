import json
import urllib.parse

from crossref_matcher.matching.http_utils import crossref_rest_api_call
from crossref_matcher.matching.utils import doi_id
from ..sbmv.strategy import Sbmv
from crossref_matcher.strategies import Strategy, MatchTask


class SbmvRels(Strategy):
    task = MatchTask.PREPRINT
    id = "preprint-sbmv-rels"
    description = (
        "This strategy uses Crossref's REST API to search for candidate "
        + "preprints, compares the metadata to validate the candiates, "
        + "additionally candidate matches where a better match would exist "
        + "with another journal article are pruned."
    )

    min_score_rel_validation = 0.95

    def match(self, input_data):
        if input_data.startswith("10."):
            _, article = crossref_rest_api_call(
                f"works/{urllib.parse.quote_plus(input_data)}", {}
            )
        else:
            article = json.loads(input_data)

        sbmv_strategy = Sbmv()

        sbmv_candidates = sbmv_strategy.get_candidates(article)
        sbmv_matches = sbmv_strategy.match_candidates(article, sbmv_candidates)
        matches = []

        for preprint_doi, preprint_score, preprint_candidate in sbmv_matches:
            if preprint_score > self.min_score_rel_validation:
                matches.append((preprint_doi, preprint_score))
                continue
            best_match = self.best_journal_match(sbmv_strategy, preprint_candidate)
            if best_match[0] == article["DOI"] or best_match[1] < preprint_score:
                matches.append((preprint_doi, preprint_score))

        return [
            {
                "id": doi_id(d),
                "confidence": s,
                "strategies": [self.strategy],
            }
            for d, s in matches
        ]

    def best_journal_match(self, sbmv_strategy, preprint):
        query = sbmv_strategy.candidate_query(preprint)
        code, results = crossref_rest_api_call(
            "works",
            {"query.bibliographic": query, "filter": "type:journal-article"},
        )
        candidates = results["items"]
        scores = [
            (candidate["DOI"], sbmv_strategy.score(candidate, preprint))
            for candidate in candidates
        ]
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[0]
