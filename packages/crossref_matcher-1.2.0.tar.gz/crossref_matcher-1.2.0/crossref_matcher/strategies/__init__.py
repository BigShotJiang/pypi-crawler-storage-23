"""Strategy abstract base class and plugin loader.

This module defines the Strategy base class which all strategies inherit from.
It also loads strategy plugins, validates required class attributes, and
provides lookup utilities for default and task-specific strategies.
"""

from abc import ABC, abstractmethod
import re
from importlib import resources, import_module
from importlib.metadata import entry_points
import json
import warnings
import types
from typing import Literal

from crossref_matcher import MatchTask

import logging

logger = logging.getLogger(__name__)


def pascal_to_snake_case(s):
    return re.sub(r"(?<!^)(?=[A-Z])", "_", s).lower()


def kebab_to_snake_case(string: str) -> str:
    if string is None:
        return None
    return "_".join(string.split("-"))


class NoDefaultStrategyError(ValueError):
    """Raised when no default strategy is configured for a task."""

    pass


class MultipleDefaultStrategiesError(ValueError):
    """Raised when more than one default strategy is configured for a task."""

    pass


class StrategyNotFoundError(ValueError):
    """Raised when a requested strategy cannot be resolved."""

    pass


class Strategy(ABC):
    """Abstract base class for all which all matching strategies inherit from."""

    REQUIRED_CLASS_FIELDS = {"id": str, "task": MatchTask, "description": str}
    # also define these fields explicitly for type hinting
    id: str
    task: MatchTask
    description: str

    @classmethod
    def create_dummy_subclass(cls, module_name: str, error: str):
        """Create a disabled placeholder strategy when a plugin fails to import."""
        task = MatchTask.OTHER
        for s in module_name.split("."):
            if s in MatchTask.get_ids():
                task = MatchTask(s)
        exec_body_dict = {
            "id": module_name,
            "task": task,
            "description": f"Disabled strategy due to import error: {error}",
        }

        dummy_class = types.new_class(
            module_name, (cls,), exec_body=lambda ns: ns.update(exec_body_dict)
        )
        dummy_class.disabled = True
        dummy_class.error = error
        return dummy_class

    @classmethod
    def error_handler_for_plugin_loading(
        cls,
        e: Exception,
        module: str,
        msg: str | None = None,
        on_err: Literal["warn", "raise", "ignore", "log", "debug"] = "warn",
    ):
        """Handle plugin import errors according to the specified strategy."""
        if msg is None:
            msg = f"Error when loading plugin {module}: {str(e)}"
        if on_err == "warn":
            warnings.warn(
                msg,
                UserWarning,
                stacklevel=2,
            )
        elif on_err == "raise":
            raise e
        elif on_err == "ignore":
            pass
        elif on_err == "debug":
            logger.debug(msg)
        else:
            logger.error(msg)

    @classmethod
    def load_plugins(
        cls,
        on_err: Literal["warn", "raise", "ignore", "log", "debug"] = "warn",
    ):
        """Load local and entry-point strategy plugins.

        When a plugin fails to import, a dummy disabled strategy is created so
        the failure is visible via listing endpoints.
        """
        modules_loaded = []
        with resources.files("crossref_matcher.resources").joinpath(
            "plugins.json"
        ).open("r", encoding="utf-8") as plugins:
            plugins_cfg = json.load(plugins)
            for module in (
                plugins_cfg["crossref_matcher.plugins.enabled"]
                + plugins_cfg["crossref_matcher.plugins.disabled"]
            ):
                if module in modules_loaded:
                    continue
                # First try to import from local modules.
                if cls.__module__ in module:
                    try:
                        import_module(f"{module}.strategy")
                        modules_loaded.append(module)
                    except (ImportError, ModuleNotFoundError) as e:
                        msg = f"Failed to import module {module}.strategy: {e}"
                        cls.error_handler_for_plugin_loading(
                            e, module, msg=msg, on_err=on_err
                        )
                        cls.create_dummy_subclass(module, str(e))
                        modules_loaded.append(module)
                # Next try to import from entry points (external plugins).
                else:
                    try:
                        eps = entry_points(group="crossref_matcher.strategies")
                        eps[module].load()
                        modules_loaded.append(module)
                    except (IndexError, KeyError) as e:
                        msg = f"Plugin {module} not found in entry points. Is it installed?"
                        cls.error_handler_for_plugin_loading(
                            e, module, msg=msg, on_err=on_err
                        )
                        cls.create_dummy_subclass(
                            module, "Plugin not found in entry points."
                        )
                        modules_loaded.append(module)
                    except (ImportError, ModuleNotFoundError) as e:
                        msg = f"Failed to import module {module}.strategy: {e}"
                        cls.error_handler_for_plugin_loading(
                            e, module, msg=msg, on_err=on_err
                        )
                        cls.create_dummy_subclass(module, str(e))
                        modules_loaded.append(module)

        # Mark disabled strategies based on config.
        for module in plugins_cfg["crossref_matcher.plugins.disabled"]:
            try:
                s = get_strategy_by_module_name(module, allow_disabled=True)
                s.disabled = True
            except ValueError:
                # already handled as import error above
                pass

        # Mark default strategies per task based on config.
        default_strategies_cfg = plugins_cfg[
            "crossref_matcher.plugins.default_strategies"
        ]
        for task_id, module_name in default_strategies_cfg.items():
            try:
                set_default_strategy_for_task(task_id, module_name=module_name)
            except StrategyNotFoundError as e:
                msg = f"Failed to set default strategy for task {task_id} to {module_name}: strategy not found."
                cls.error_handler_for_plugin_loading(
                    e, module_name, msg=msg, on_err=on_err
                )

        if on_err == "warn":
            warn_if_default_strategy_not_set()

    @classmethod
    def load_plugin_by_module_path(cls, module_path: str, force: bool = False):
        """Dynamically load a strategy plugin by its module path."""
        import importlib.util
        import sys
        from pathlib import Path

        module_path = Path(module_path).resolve()
        module_name = module_path.name

        # Create a module specification
        spec = importlib.util.spec_from_file_location(
            module_name,
            module_path.joinpath("strategy.py"),
            submodule_search_locations=[],
        )
        if spec is None:
            raise ImportError(
                f"Could not create spec for module {module_name} at {module_path}"
            )

        # Create a new module object from the specification
        module = importlib.util.module_from_spec(spec)
        if module in sys.modules and not force:
            logger.debug(f"Module {module_name} already loaded, skipping import.")
            return None

        # Register the module in sys.modules (important for standard import behavior)
        sys.modules[module_name] = module

        # Execute the module's code
        spec.loader.exec_module(module)

        return module

    def __init_subclass__(cls, **kwargs):
        """Validate that subclasses define required class-level attributes."""
        super().__init_subclass__(**kwargs)
        for name, type in cls.REQUIRED_CLASS_FIELDS.items():
            if not hasattr(cls, name) and not isinstance(
                getattr(cls, name, None), type
            ):
                raise TypeError(
                    f"Class {cls.__name__} must have a class field '{name}' of type {type.__name__}."
                )

    @classmethod
    def is_default(cls):
        """Return True if this strategy is marked as the default for its task."""
        return getattr(cls, "default", False)

    @classmethod
    def is_disabled(cls):
        """Return True if this strategy is marked as disabled."""
        return getattr(cls, "disabled", False)

    @property
    def strategy(self):
        """Legacy alias for `id` to preserve old callers."""
        return self.id

    @abstractmethod
    def match(self, *args, **kwargs):
        """Abstract method to perform a match operation."""
        pass


def list_strategies(
    task: MatchTask | str | None = None, include_disabled: bool = False
) -> list[type[Strategy]]:
    """List available strategy classes.

    Args:
        task: Optional task id or `MatchTask` to filter strategies by task.
        include_disabled: If True, include disabled strategies.

    Returns:
        A list of strategy classes that match the requested filters.
    """
    strategies = [i for i in Strategy.__subclasses__()]
    if include_disabled is False:
        strategies = [s for s in strategies if not s.is_disabled()]
    if task:
        task = MatchTask(task)
        strategies = [s for s in strategies if s.task is task]
    return strategies


def get_strategy_by_id(
    strategy_id: str | None,
    task: MatchTask | str | None = None,
    allow_disabled: bool = False,
) -> type[Strategy]:
    """Resolve a strategy by id, or return the task default.

    Args:
        strategy_id: Strategy id (snake_case or kebab-case). If None, use the
            default strategy for the task.
        task: Optional task id or `MatchTask` to scope the lookup.
        allow_disabled: If True, include disabled strategies in the lookup.

    Returns:
        The strategy class matching the requested id or default for the task.

    Raises:
        ValueError: If `strategy_id` is None and `task` is not provided.
        StrategyNotFoundError: If no matching strategy is found.
    """
    if not strategy_id:
        if not task:
            raise ValueError("Must specify at least one of [strategy_id, task]")
        return get_default_strategy(task)
    strategy_found = False
    for id_to_check in [strategy_id, kebab_to_snake_case(strategy_id)]:
        strategy = [
            c
            for c in list_strategies(task=task, include_disabled=allow_disabled)
            if c.id == id_to_check
        ]
        if strategy:
            strategy = strategy[0]
            strategy_found = True
            break
    if not strategy_found:
        msg = f"Strategy {strategy_id} not found"
        if task:
            task = MatchTask(task)
            msg += f" (for task: {task.id})"
        raise StrategyNotFoundError(msg)
    return strategy


def get_strategy_by_module_name(
    module_name: str,
    task: MatchTask | str | None = None,
    allow_disabled: bool = False,
) -> type[Strategy]:
    """Resolve a strategy by its module name (with or without .strategy).

    Args:
        module_name: Module path for the strategy implementation.
        task: Optional task id or `MatchTask` to scope the lookup.
        allow_disabled: If True, include disabled strategies in the lookup.

    Returns:
        The strategy class defined in the given module.

    Raises:
        StrategyNotFoundError: If no matching strategy is found.
    """
    strategy_found = False
    if module_name.endswith(".strategy"):
        module_name = module_name[: -len(".strategy")]
    for strategy in list_strategies(task=task, include_disabled=allow_disabled):
        this_module_name = strategy.__module__
        if this_module_name.endswith(".strategy"):
            this_module_name = this_module_name[: -len(".strategy")]
        if this_module_name == module_name:
            strategy_found = True
            return strategy
    if not strategy_found:
        msg = f"Strategy with module name {module_name} not found"
        if task:
            task = MatchTask(task)
            msg += f" (for task: {task.id})"
        raise StrategyNotFoundError(msg)


def get_strategy(
    strategy_id: str | None,
    task: MatchTask | str | None = None,
    allow_disabled: bool = False,
) -> type[Strategy]:
    """Public wrapper for strategy lookup by id.

    Args:
        strategy_id: Strategy id (snake_case or kebab-case). If None, use the
            default strategy for the task.
        task: Optional task id or `MatchTask` to scope the lookup.
        allow_disabled: If True, include disabled strategies in the lookup.

    Returns:
        The strategy class matching the requested id or default for the task.

    Raises:
        ValueError: If `strategy_id` is None and `task` is not provided.
        StrategyNotFoundError: If no matching strategy is found.
    """
    return get_strategy_by_id(strategy_id, task=task, allow_disabled=allow_disabled)


def get_default_strategy(task: MatchTask | str) -> type[Strategy]:
    """Return the single default strategy for a task.

    Args:
        task: Task id or `MatchTask` to resolve a default for.

    Returns:
        The default strategy class for the task.

    Raises:
        NoDefaultStrategyError: If no default strategy is configured.
        MultipleDefaultStrategiesError: If multiple defaults are configured.
    """
    task = MatchTask(task)
    strategies = list_strategies(task=task)
    default_strategy = [s for s in strategies if s.is_default()]
    if len(default_strategy) == 0:
        raise NoDefaultStrategyError(f"No default strategy found for task {task.id}")
    elif len(default_strategy) > 1:
        raise MultipleDefaultStrategiesError(
            f"More than one default strategy found for task {task.id}: {default_strategy}"
        )
    else:
        return default_strategy[0]


def warn_if_default_strategy_not_set():
    """Emit warnings for tasks without exactly one default strategy."""
    for task in MatchTask:
        if task is MatchTask.OTHER:
            continue
        try:
            get_default_strategy(task)
        except NoDefaultStrategyError:
            warnings.warn(
                f"No default strategy set for task {task.id}. Please set one strategy as default.",
                UserWarning,
                stacklevel=2,
            )
        except MultipleDefaultStrategiesError:
            warnings.warn(
                f"Multiple default strategies set for task {task.id}. Please ensure only one default strategy per task.",
                UserWarning,
                stacklevel=2,
            )


def set_default_strategy_for_task(
    task: MatchTask | str,
    strategy_id: str | None = None,
    module_name: str | None = None,
) -> None:
    """Set the default strategy for a task by id or module name.

    Args:
        task: Task id or `MatchTask` to update.
        strategy_id: Strategy id to mark as default.
        module_name: Module path to resolve a strategy id from.

    Raises:
        ValueError: If neither `strategy_id` nor `module_name` is provided.
        StrategyNotFoundError: If the strategy cannot be resolved.
    """
    if strategy_id is None and module_name is None:
        raise ValueError("Must specify at least one of [strategy_id, module_name]")
    task = MatchTask(task)
    strategies = list_strategies(task=task, include_disabled=True)
    if strategy_id is None:
        # find strategy_id from module_name
        try:
            target_strategy = get_strategy_by_module_name(
                module_name, task=task, allow_disabled=True
            )
            strategy_id = target_strategy.id
        except StrategyNotFoundError:
            raise StrategyNotFoundError(
                f"No strategy found for task {task.id} in module {module_name}"
            )
    for s in strategies:
        if s.id == strategy_id:
            s.default = True
        else:
            s.default = False
