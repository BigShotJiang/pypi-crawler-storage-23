import re
import unidecode
import unicodedata
from functools import cached_property


class StringRep(str):
    # This is meant to standardize all of the manipulations of the name strings
    def __new__(cls, s: str):
        obj = super().__new__(cls, s)
        obj.original = str(s)
        return obj

    def __str__(self):
        return self.original

    def __repr__(self):
        return f"StringRep({self.original!r})"

    def __len__(self):
        return len(self.original)

    @cached_property
    def lower_(self):
        return re.sub(r"\s+", " ", self.original.lower())

    @cached_property
    def lower_alpha(self):
        s = unidecode.unidecode(self.original).strip()
        return re.sub(
            r"\s+", " ", re.sub("[^a-z]", " ", s.lower())
        )  # Lowercase and keep only letters

    @cached_property
    def alpha(self):
        s = unidecode.unidecode(self.original).strip()
        return re.sub(r"\s+", " ", re.sub("[^a-zA-Z]", " ", s))  # Keep only letters

    def check_latin_chars(self, s):
        for ch in s:
            if ch.isalpha():
                if "LATIN" not in unicodedata.name(ch):
                    return False
        return True

    @cached_property
    def normalized(self):
        return self._normalize(self.original)

    def _normalize(self, s):
        """Normalize a string for matching.

        Args:
            s (str): The string to normalize.

        Returns:
            str: The normalized string.
        """
        if self.check_latin_chars(s):
            # if these are Latin characters, remove accent marks
            s = re.sub(r"\s+", " ", unidecode.unidecode(s).strip().lower())
        else:
            s = re.sub(r"\s+", " ", s.strip().lower())

        # Replace specific abbreviations with their full forms
        s = re.sub(
            "(?<![a-z])univ$",
            "university",
            re.sub(
                r"(?<![a-z])univ[\. ]",
                "university ",
                re.sub(r"(?<![a-z])u\.(?! ?[a-z]\.)", "university ", s),
            ),
        )
        s = re.sub(
            "(?<![a-z])lab$",
            "laboratory",
            re.sub("(?<![a-z])lab[^a-z]", "laboratory ", s),
        )
        s = re.sub(
            "(?<![a-z])inst$",
            "institute",
            re.sub("(?<![a-z])inst[^a-z]", "institute ", s),
        )
        s = re.sub(
            "(?<![a-z])tech$",
            "technology",
            re.sub("(?<![a-z])tech[^a-z]", "technology ", s),
        )
        s = re.sub(r"(?<![a-z])u\. ?s\.", "united states", s)
        s = re.sub("&", " and ", re.sub("&amp;", " and ", s))
        s = re.sub("^the ", "", s)

        s = re.sub(r"\s+", " ", s.strip().lower())

        return s
