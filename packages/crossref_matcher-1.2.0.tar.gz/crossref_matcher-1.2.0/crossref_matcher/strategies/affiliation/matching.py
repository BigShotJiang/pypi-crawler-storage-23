import re
import unicodedata
from .CountryMatcher import CountryMatcher
import unidecode
from .MatchedOrganization import MatchedOrganization


from fuzzywuzzy import fuzz
from opensearchpy.exceptions import RequestError

MATCHING_TYPE_PHRASE = "PHRASE"
MATCHING_TYPE_COMMON = "COMMON TERMS"
MATCHING_TYPE_FUZZY = "FUZZY"
MATCHING_TYPE_HEURISTICS = "HEURISTICS"
MATCHING_TYPE_EXACT = "EXACT"


def check_latin_chars(s):
    for ch in s:
        if ch.isalpha():
            if "LATIN" not in unicodedata.name(ch):
                return False
    return True


def normalize(s):
    """Normalize string for matching."""

    if check_latin_chars(s):
        s = re.sub(r"\s+", " ", unidecode.unidecode(s).strip().lower())
    else:
        s = re.sub(r"\s+", " ", s.strip().lower())
    s = re.sub(
        "(?<![a-z])univ$",
        "university",
        re.sub(
            r"(?<![a-z])univ[\. ]",
            "university ",
            re.sub(r"(?<![a-z])u\.(?! ?[a-z]\.)", "university ", s),
        ),
    )
    s = re.sub(
        "(?<![a-z])lab$", "laboratory", re.sub("(?<![a-z])lab[^a-z]", "laboratory ", s)
    )
    s = re.sub(
        "(?<![a-z])inst$", "institute", re.sub("(?<![a-z])inst[^a-z]", "institute ", s)
    )
    s = re.sub(
        "(?<![a-z])tech$",
        "technology",
        re.sub("(?<![a-z])tech[^a-z]", "technology ", s),
    )
    s = re.sub(r"(?<![a-z])u\. ?s\.", "united states", s)
    s = re.sub("&", " and ", re.sub("&amp;", " and ", s))
    s = re.sub("^the ", "", s)
    s = re.sub(r"\s+", " ", s.strip().lower())
    return s


def get_similarity(aff_sub, cand_name):
    """Calculate the similarity between the affiliation substring
    and the candidate name version."""

    aff_sub = normalize(aff_sub)
    cand_name = normalize(cand_name)
    comparfun = fuzz.token_sort_ratio
    if (
        "(" in aff_sub
        or ")" in aff_sub
        or "-" in aff_sub
        or len(
            [
                s
                for s in [
                    "university",
                    "college",
                    "school",
                    "department",
                    "institute",
                    "center",
                    "hospital",
                ]
                if s in aff_sub
            ]
        )
        > 1
    ):
        comparfun = fuzz.partial_ratio
    cand_name = re.sub(r"\(.*\)", "", cand_name).strip()
    return comparfun(aff_sub, cand_name) / 100


def get_score(candidate, aff_sub, countries):
    """Calculate the similarity between the affiliation substring
    and the candidate, using all name versions."""
    country_code = candidate.country
    all_names = [name["name"] for name in candidate.names]

    if countries and CountryMatcher.code_to_region(country_code) not in countries:
        return 0
    scores = [get_similarity(aff_sub, name) for name in all_names]
    return max(scores)


def match_by_query(text, matching_type, query, countries):
    """Match affiliation text using specific ES query."""
    candidates = []
    try:
        candidates = query.execute()
    except RequestError:
        pass
    scores = [
        (candidate, get_score(candidate, text, countries)) for candidate in candidates
    ]
    if not candidates:
        return MatchedOrganization(substring=text, matching_type=matching_type), []
    max_score = max([s[1] for s in scores])
    best = [s for s in scores if s[1] == max_score][0]
    chosen = MatchedOrganization(
        substring=text, matching_type=matching_type, score=best[1], organization=best[0]
    )
    all_matched = [
        MatchedOrganization(
            substring=text, matching_type=matching_type, score=s, organization=c
        )
        for c, s in scores
    ]
    return chosen, all_matched
