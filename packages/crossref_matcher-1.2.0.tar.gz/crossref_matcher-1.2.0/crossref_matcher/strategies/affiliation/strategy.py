from dataclasses import dataclass
from typing import Optional


@dataclass
class MatchedOrganization:
    chosen: bool = False
    substring: Optional[str] = None
    matching_type: Optional[str] = None
    score: float = 0
    organization: Optional[str] = None
