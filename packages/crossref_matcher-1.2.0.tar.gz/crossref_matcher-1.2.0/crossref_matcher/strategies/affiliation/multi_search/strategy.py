from itertools import groupby
from crossref_matcher.strategies.affiliation.CountryMatcher import CountryMatcher
from crossref_matcher.strategies import Strategy, MatchTask
from crossref_matcher.strategies.affiliation.MatchedOrganization import (
    MatchedOrganization,
)
from crossref_matcher.strategies.affiliation.es_utils import ESQueryBuilder
from crossref_matcher.strategies.affiliation.matching import (
    MATCHING_TYPE_COMMON,
    MATCHING_TYPE_EXACT,
    MATCHING_TYPE_FUZZY,
    MATCHING_TYPE_HEURISTICS,
    MATCHING_TYPE_PHRASE,
    match_by_query,
)
from . import MatchingGraph


class MultiSearch(Strategy):
    task = MatchTask.AFFILIATION
    id = "affiliation-multi-search"
    description = "Heuristic-based strategy; it segments the affiliation string, performs multiple candidate searches against ES and uses a number of heuristics to validate the candidates."

    MIN_CHOSEN_SCORE = 0.9
    MIN_MATCHING_SCORE = 0.5

    def match(self, input_data):
        matched = MultiSearch.match_affiliation(input_data)
        if not matched:
            return []
        matched = matched[0]
        if not matched.chosen:
            return []

        return [
            {
                "id": matched.organization["id"],
                "confidence": matched.score,
                "strategies": [self.id],
            }
        ]

    @staticmethod
    def get_output(chosen, all_matched):
        # don't allow multiple results with chosen=True
        if isinstance(chosen, list) and len(chosen) > 1:
            chosen = []
        type_map = {
            MATCHING_TYPE_EXACT: 5,
            MATCHING_TYPE_PHRASE: 4,
            MATCHING_TYPE_COMMON: 3,
            MATCHING_TYPE_FUZZY: 2,
            MATCHING_TYPE_HEURISTICS: 1,
        }
        output = []
        all_matched = [
            m for m in all_matched if m.score > MultiSearch.MIN_MATCHING_SCORE
        ]
        all_matched = [m for m in all_matched if m.organization.status == "active"]
        all_matched = sorted(all_matched, key=lambda x: x.organization.id)
        all_matched = groupby(all_matched, lambda x: x.organization.id)
        all_matched_list = []
        for org_id, g in all_matched:
            all_matched_list.append((org_id, list(g)))
        all_matched_list = sorted(all_matched_list, key=lambda x: x[0])
        for _, g in all_matched_list:
            best = g[0]
            for c in g:
                if c in chosen:
                    best = MatchedOrganization(
                        substring=c.substring,
                        score=c.score,
                        chosen=True,
                        matching_type=c.matching_type,
                        organization=c.organization,
                    )
                    break
                if (
                    c.score == 1.0
                    and type_map[best.matching_type] == type_map[MATCHING_TYPE_EXACT]
                    and type_map[c.matching_type] == type_map[MATCHING_TYPE_EXACT]
                ):
                    best = MatchedOrganization(
                        substring=c.substring,
                        score=c.score,
                        chosen=True,
                        matching_type=c.matching_type,
                        organization=c.organization,
                    )
                    break
                if best.score < c.score:
                    best = c
                if (
                    best.score == c.score
                    and type_map[best.matching_type] < type_map[c.matching_type]
                ):
                    best = c
                if (
                    (best.score == c.score)
                    and type_map[best.matching_type] == type_map[c.matching_type]
                    and len(best.substring) >= len(c.substring)
                ):
                    best = c
            output.append(best)
        return sorted(output, key=lambda x: x.score, reverse=True)[:100]

    @staticmethod
    def check_exact_match(affiliation, countries):
        qb = ESQueryBuilder()
        qb.add_string_query('"' + affiliation + '"')
        return match_by_query(
            affiliation, MATCHING_TYPE_EXACT, qb.get_query(), countries
        )

    @staticmethod
    def match_affiliation(affiliation):
        countries = CountryMatcher.get_regions(affiliation)
        exact_chosen, exact_all_matched = MultiSearch.check_exact_match(
            affiliation, countries
        )
        if exact_chosen.score == 1.0:
            return MultiSearch.get_output([exact_chosen], exact_all_matched)
        else:
            graph = MatchingGraph(affiliation)
            chosen, all_matched = graph.match(countries, MultiSearch.MIN_CHOSEN_SCORE)
            return MultiSearch.get_output(chosen, all_matched)
