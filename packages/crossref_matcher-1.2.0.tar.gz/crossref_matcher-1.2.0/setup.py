from setuptools import setup, find_packages
import os
import subprocess

URL = "https://gitlab.com/crossref/marple"


def getVersion():
    with open("crossref_matcher/resources/VERSION.txt", "r") as f:
        base_version = f.read().strip()

    # Only add git info for local builds (not CI/production)
    if os.path.exists(".local-dev"):
        try:
            git_hash = subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                universal_newlines=True,
                stderr=subprocess.DEVNULL,
            ).strip()

            # Check if working directory is dirty
            git_status = subprocess.check_output(
                ["git", "status", "--porcelain"],
                universal_newlines=True,
                stderr=subprocess.DEVNULL,
            ).strip()

            dirty_suffix = ".dirty" if git_status else ""
            return f"{base_version}+g{git_hash}{dirty_suffix}"
        except (subprocess.CalledProcessError, FileNotFoundError):
            # Git not available or not a git repo
            pass

    return base_version


setup(
    name="crossref-matcher",
    version=getVersion(),
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "fastapi>=0.100.0",
        "uvicorn>=0.30.0",
        "pydantic>=2.0.0",
        "crossref-example-matching-strategy>=0.2.1",
    ],
    entry_points={
        "console_scripts": [
            "crossref-matcher = crossref_matcher.app:main",
            "crossref-matcher-test-plugin = crossref_matcher.run_plugin_test:main",
        ],
    },
    author="Crossref",
    description="Crossref's matching API",
    long_description=f"See documentation at {URL}",
    url=URL,
    extras_require={
        "evaluation": ["scikit-learn>=1.7.0"],
        "strategies-core": [
            "boto3>=1.30.0",
            "opensearch-py>=2.0.0",
            "opensearch-dsl>=2.0.0",
            "rapidfuzz>=3.0.0",
            "unidecode>=1.3.0",
            "fuzzywuzzy>=0.17.0",
            "geonamescache>=1.3.0",
            "requests>=2.30.0",
            "ratelimit==2.2.0",
        ],
        "test": [
            "pytest>=8.4.2",
            "anyio>=4.10.0",
            "httpx>=0.28.1",
            "jsonschema>=4.25.1",
        ],
    },
)
