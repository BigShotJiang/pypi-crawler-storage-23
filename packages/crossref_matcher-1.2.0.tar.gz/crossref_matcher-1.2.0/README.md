# Marple

Crossref's matching service—codenamed Marple—provides the functionality for metadata matching:

* run multiple matching tasks
* implement multiple matching strategies
* create and populate backend indexes for the matching strategies
* evaluate the strategies against ground truth datasets

## Terminology

In short, matching is the task or process of finding an identifier of an item based on a structured or unstructured “description” of it. Examples include:

* finding the DOI based on a bibliographic reference,
* finding the ROR ID based on an affiliation string,
* finding the grant DOI based on the acknowledgment section of a paper.

There are also tasks that are technically not matching but are closely related, and in practice, we often treat them as matching tasks:

* finding a duplicate of a journal article,
* linking preprints to journal articles.

And there are a few tasks that are often included in matching conversations, but are definitely not matching, for example:

* retrieving the metadata of a work based on its DOI,
* retrieving all works that contain the phrase “citation parsing” in the title.

A matching task defines the nature of matching. Example matching tasks are bibliographic reference matching, preprint matching, and affiliation matching. A matching task has input and output:

* Input is all the data needed for the matching, for example: a structured record or a list of them, unstructured text.
* Output are simply matched identifiers. Within a specific matching task, output identifiers are usually of a specific type (i.e. we match to ROR ID, and not ORCID ID). In some cases, there can be a certain target database as well (i.e. we match only to DataCite DOIs). The output identifiers can have different cardinality depending on the task, some matching tasks will allow zero, one, and/or more identifiers as a result of matching of a single input.

A matching strategy defines how the matching is actually done. Multiple strategies can exist for a specific matching task. Some strategies can even run other strategies and combine their outcomes.

## Evaluation

We can evaluate a matching strategy using an evaluation set. See [Evaluation](crossref_matcher/evaluation/README.md) for more about this.

## Using `crossref-matcher` as a library

### Installation

Install with pip: `pip install crossref-matcher`

### Usage

With the `crossref-matcher` library installed in your own project, you can import the `Strategy` class to develop your own matching strategies. Create a file called `strategy.py`:

```python
# strategy.py

from crossref_matcher import Strategy, MatchTask

class MyMatchingStrategy(Strategy):
    # These three fields must be specified in any strategy!
    id = "my-matching-strategy"
    task = MatchTask.REFERENCE
    description = "Example strategy."

    def __init__(self):
        pass

    def match(self, input_data):
        # matching logic goes here

        # For example:
        if input_data == "Crossref":
            return [
                {
                    "id": "https://ror.org/02twcfp32",
                    "confidence": 1.0,
                    "strategies": [self.id],
                }
            ]
        return []
```

Find more information on the `Strategy` class in [`crossref_matcher/strategies/__init__.py`](crossref_matcher/strategies/__init__.py).

You can test out your strategy by running from your command line:

`crossref-matcher-test-plugin <path_to_directory_containing_my_strategy> --port 8000`

and then visit `http://localhost:8000/docs`

## Importing external strategies as plugins

After installing an external strategy, you can add it to [`plugins.json`](crossref_matcher/resources/plugins.json) to use it.

To see this in action, you can add the following entry to the `crossref_matcher.plugins.enabled` array in `plugins.json`:

```json
        "crossref_example_matching_strategy"
```

This will make available the [example matching strategy](https://gitlab.com/crossref/example-matching-strategy), which should already be installed (via `setup.py` and/or `requirements.txt`).

## Development

### Indexes

Some strategies need an OpenSearch index to match. [indexes directory](crossref_matcher/indexes/) contains scripts for creating and populating the indexes.

Use ES_HOST env var to point Marple to the OpenSearch cluster.

### How to run

Run

```sh
python -m crossref_matcher.app --host 0.0.0.0 --port 8000
```

and then visit `http://localhost:8000/docs`

### Strategies

Strategies are located in the [strategies directory](crossref_matcher/strategies/). They inherit from the [`Strategy` abstract base class](crossref_matcher/strategies/__init__.py).

Strategies must be added to the "enabled" list in [plugins.json](crossref_matcher/resources/plugins.json) before they can be used.

### Dependencies

Requirements are defined in `setup.py`. Requirements files with exact versions can be updated with `pip-compile`, which is a part of `pip-tools`. First run `pip install pip-tools`. Then:

* To update `requirements.txt` file: `pip-compile setup.py --extra strategies-core`

* To update `requirements-tests.txt` file: `pip-compile setup.py --extra strategies-core --extra evaluation --extra test -o requirements-tests.txt`
