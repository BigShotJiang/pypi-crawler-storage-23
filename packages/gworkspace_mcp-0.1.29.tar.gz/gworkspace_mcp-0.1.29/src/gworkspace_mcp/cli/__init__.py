"""CLI module for gworkspace-mcp."""
