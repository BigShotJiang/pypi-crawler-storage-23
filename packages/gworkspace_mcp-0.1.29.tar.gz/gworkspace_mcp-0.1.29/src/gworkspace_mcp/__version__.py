"""Version information for gworkspace-mcp."""

__version__ = "0.1.29"
