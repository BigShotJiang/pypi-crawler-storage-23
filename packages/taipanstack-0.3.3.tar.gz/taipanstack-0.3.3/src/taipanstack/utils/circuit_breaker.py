"""
Circuit Breaker pattern implementation.

Provides protection against cascading failures by temporarily
blocking calls to a failing service. Compatible with any
Python framework.
"""

from __future__ import annotations

import functools
import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")

logger = logging.getLogger("taipanstack.utils.circuit_breaker")

try:
    import structlog as _structlog

    _structlog_logger = _structlog.get_logger("taipanstack.utils.circuit_breaker")
    _HAS_STRUCTLOG = True
except ImportError:  # pragma: no cover — structlog is optional
    _structlog_logger = None
    _HAS_STRUCTLOG = False


class CircuitState(Enum):
    """States of the circuit breaker."""

    CLOSED = "closed"  # Normal operation, requests flow through
    OPEN = "open"  # Circuit is tripped, requests are blocked
    HALF_OPEN = "half_open"  # Testing if service has recovered


class CircuitBreakerError(Exception):
    """Raised when circuit breaker is open."""

    def __init__(self, message: str, state: CircuitState) -> None:
        """Initialize CircuitBreakerError.

        Args:
            message: Error description.
            state: Current circuit state.

        """
        self.state = state
        super().__init__(message)


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker behavior.

    Attributes:
        failure_threshold: Number of failures before opening circuit.
        success_threshold: Successes needed in half-open to close.
        timeout: Seconds before trying half-open after open.
        excluded_exceptions: Exceptions that don't count as failures.
        failure_exceptions: Exceptions that count as failures.

    """

    failure_threshold: int = 5
    success_threshold: int = 2
    timeout: float = 30.0
    excluded_exceptions: tuple[type[Exception], ...] = ()
    failure_exceptions: tuple[type[Exception], ...] = (Exception,)


@dataclass
class CircuitBreakerState:
    """Internal state tracking for circuit breaker."""

    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: float = 0.0
    lock: threading.Lock = field(default_factory=threading.Lock)


class CircuitBreaker:
    """Circuit breaker implementation.

    Monitors function calls and opens the circuit when too many
    failures occur, preventing further calls until the service
    recovers.

    Example:
        >>> breaker = CircuitBreaker(failure_threshold=3)
        >>> @breaker
        ... def call_external_api():
        ...     return requests.get("https://api.example.com")

    """

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        success_threshold: int = 2,
        timeout: float = 30.0,
        excluded_exceptions: tuple[type[Exception], ...] = (),
        failure_exceptions: tuple[type[Exception], ...] = (Exception,),
        name: str = "default",
        on_state_change: Callable[[CircuitState, CircuitState], None] | None = None,
    ) -> None:
        """Initialize CircuitBreaker.

        Args:
            failure_threshold: Failures before opening circuit.
            success_threshold: Successes to close from half-open.
            timeout: Seconds before attempting half-open.
            excluded_exceptions: Exceptions that don't trip circuit.
            failure_exceptions: Exceptions that count as failures.
            name: Name for logging/identification.
            on_state_change: Optional callback invoked on state transitions
                with (old_state, new_state). Useful for custom monitoring.

        """
        self.config = CircuitBreakerConfig(
            failure_threshold=failure_threshold,
            success_threshold=success_threshold,
            timeout=timeout,
            excluded_exceptions=excluded_exceptions,
            failure_exceptions=failure_exceptions,
        )
        self.name = name
        self._state = CircuitBreakerState()
        self._on_state_change = on_state_change

    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        return self._state.state

    @property
    def failure_count(self) -> int:
        """Get current failure count."""
        return self._state.failure_count

    def _notify_state_change(
        self,
        old_state: CircuitState,
        new_state: CircuitState,
    ) -> None:
        """Notify callback of state transition if registered.

        Emit a structured log via structlog when no callback is provided
        and structlog is available.
        """
        if self._on_state_change is not None:
            self._on_state_change(old_state, new_state)
        elif _HAS_STRUCTLOG and _structlog_logger is not None:  # pragma: no branch
            _structlog_logger.warning(
                "circuit_state_changed",
                circuit=self.name,
                old_state=old_state.value,
                new_state=new_state.value,
                failure_count=self._state.failure_count,
            )

    def _should_attempt(self) -> bool:
        """Check if a call should be attempted."""
        with self._state.lock:
            match self._state.state:
                case CircuitState.CLOSED:
                    return True

                case CircuitState.OPEN:
                    # Check if timeout has passed
                    elapsed = time.monotonic() - self._state.last_failure_time
                    if elapsed >= self.config.timeout:
                        self._state.state = CircuitState.HALF_OPEN
                        self._state.success_count = 0
                        logger.info(
                            "Circuit %s entering half-open state "
                            "(was open for %.1fs, failures=%d)",
                            self.name,
                            elapsed,
                            self._state.failure_count,
                        )
                        self._notify_state_change(
                            CircuitState.OPEN,
                            CircuitState.HALF_OPEN,
                        )
                        return True
                    return False

                case CircuitState.HALF_OPEN:  # pragma: no branch
                    # Allow limited attempts
                    return True

        return False  # pragma: no cover — unreachable, satisfies type checker

    def _record_success(self) -> None:
        """Record a successful call."""
        with self._state.lock:
            match self._state.state:
                case CircuitState.HALF_OPEN:
                    self._state.success_count += 1
                    if self._state.success_count >= self.config.success_threshold:
                        self._state.state = CircuitState.CLOSED
                        self._state.failure_count = 0
                        logger.info(
                            "Circuit %s closed after recovery "
                            "(%d consecutive successes)",
                            self.name,
                            self._state.success_count,
                        )
                        self._notify_state_change(
                            CircuitState.HALF_OPEN,
                            CircuitState.CLOSED,
                        )

                case CircuitState.CLOSED:
                    # Reset failure count on success
                    self._state.failure_count = 0

                case CircuitState.OPEN:  # pragma: no branch
                    pass  # Should not happen, but handle gracefully

    def _record_failure(self, exc: Exception) -> None:
        """Record a failed call."""
        # Check if exception should be excluded
        if isinstance(exc, self.config.excluded_exceptions):
            return

        with self._state.lock:
            self._state.failure_count += 1
            self._state.last_failure_time = time.monotonic()

            match self._state.state:
                case CircuitState.HALF_OPEN:
                    # Any failure in half-open reopens circuit
                    self._state.state = CircuitState.OPEN
                    logger.warning(
                        "Circuit %s reopened after failure in half-open "
                        "(total failures=%d)",
                        self.name,
                        self._state.failure_count,
                    )
                    self._notify_state_change(
                        CircuitState.HALF_OPEN,
                        CircuitState.OPEN,
                    )

                case CircuitState.CLOSED:
                    if self._state.failure_count >= self.config.failure_threshold:
                        self._state.state = CircuitState.OPEN
                        logger.warning(
                            "Circuit %s opened after %d failures (threshold=%d)",
                            self.name,
                            self._state.failure_count,
                            self.config.failure_threshold,
                        )
                        self._notify_state_change(
                            CircuitState.CLOSED,
                            CircuitState.OPEN,
                        )

                case CircuitState.OPEN:  # pragma: no branch
                    pass  # Already open, nothing to do

    def reset(self) -> None:
        """Reset circuit breaker to closed state."""
        with self._state.lock:
            self._state.state = CircuitState.CLOSED
            self._state.failure_count = 0
            self._state.success_count = 0
            logger.info("Circuit %s manually reset", self.name)

    def __call__(self, func: Callable[P, R]) -> Callable[P, R]:
        """Decorate a function with circuit breaker protection."""

        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            if not self._should_attempt():
                raise CircuitBreakerError(
                    f"Circuit {self.name} is open",
                    state=self._state.state,
                )

            try:
                result = func(*args, **kwargs)
                self._record_success()
                return result
            except self.config.failure_exceptions as e:
                self._record_failure(e)
                raise

        return wrapper


def circuit_breaker(
    *,
    failure_threshold: int = 5,
    success_threshold: int = 2,
    timeout: float = 30.0,
    excluded_exceptions: tuple[type[Exception], ...] = (),
    failure_exceptions: tuple[type[Exception], ...] = (Exception,),
    name: str | None = None,
    on_state_change: Callable[[CircuitState, CircuitState], None] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Decorator to apply circuit breaker pattern.

    Args:
        failure_threshold: Failures before opening circuit.
        success_threshold: Successes to close from half-open.
        timeout: Seconds before attempting half-open.
        excluded_exceptions: Exceptions that don't trip circuit.
        failure_exceptions: Exceptions that count as failures.
        name: Optional name for the circuit.
        on_state_change: Optional callback invoked on state transitions
            with (old_state, new_state).

    Returns:
        Decorated function with circuit breaker protection.

    Example:
        >>> @circuit_breaker(failure_threshold=3, timeout=60)
        ... def call_api(endpoint: str) -> dict:
        ...     return requests.get(endpoint).json()

        >>> @circuit_breaker(
        ...     failure_threshold=3,
        ...     on_state_change=lambda old, new: print(f"{old} -> {new}"),
        ... )
        ... def monitored_call() -> str:
        ...     return service.call()

    """

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        breaker = CircuitBreaker(
            failure_threshold=failure_threshold,
            success_threshold=success_threshold,
            timeout=timeout,
            excluded_exceptions=excluded_exceptions,
            failure_exceptions=failure_exceptions,
            name=name or func.__name__,
            on_state_change=on_state_change,
        )
        return breaker(func)

    return decorator
