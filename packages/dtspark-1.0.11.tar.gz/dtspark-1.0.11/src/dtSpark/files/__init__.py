"""File management module."""
from .manager import FileManager

__all__ = ['FileManager']
