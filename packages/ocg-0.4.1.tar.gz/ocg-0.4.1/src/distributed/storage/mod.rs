//! Distributed storage module for Parquet serialization and WAL.

pub mod parquet_serde;
pub mod snapshot_restore;
pub mod wal;

pub use parquet_serde::{save_partition_to_parquet, load_partition_metadata};

#[cfg(feature = "distributed")]
pub use parquet_serde::{PartitionMetadata, CompressionStats};

#[cfg(feature = "distributed")]
pub use wal::{WalConfig, WalSyncMode, WriteAheadLog};
