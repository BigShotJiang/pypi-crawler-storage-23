//! Distributed graph processing module.
//!
//! This module provides distributed graph partitioning, storage, networking,
//! and recovery capabilities for running OCG across multiple Kubernetes pods.

pub mod autoscaling;
pub mod graph;
pub mod health;
pub mod http;
pub mod network;
pub mod partition;
pub mod pod;
pub mod query;
pub mod recovery;
pub mod storage;
