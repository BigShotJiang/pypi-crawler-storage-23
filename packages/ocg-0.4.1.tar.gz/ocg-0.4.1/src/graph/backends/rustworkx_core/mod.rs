// Copyright 2026 Gregorio Momm
// Licensed under the Apache License, Version 2.0
//
// This file implements GraphBackend for rustworkx-core, IBM Qiskit's graph algorithm library.
//
// rustworkx-core: https://github.com/Qiskit/rustworkx (Apache-2.0)

//! RustworkxCore backend - IBM Qiskit graph algorithms on petgraph.

mod backend;
mod algorithms;

pub use backend::RustworkxCoreBackend;
