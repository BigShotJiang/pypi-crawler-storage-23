// Test to verify relationships are created and can be deleted properly
use ocg::{execute, PropertyGraph};

#[test]
fn test_relationship_creation_verification() {
    let mut graph = PropertyGraph::new();

    // Create a relationship
    let create_result = execute(&mut graph, "CREATE (a)-[r:KNOWS]->(b) RETURN r").unwrap();

    println!("\n=== Creation Verification ===");
    println!("Rows returned: {}", create_result.rows.len());
    println!("Relationships created: {}", create_result.stats.relationships_created);

    assert_eq!(create_result.rows.len(), 1, "Should return the created relationship");
    assert_eq!(create_result.stats.relationships_created, 1, "Should create 1 relationship");

    // Verify we can match it
    let match_result = execute(&mut graph, "MATCH ()-[r:KNOWS]->() RETURN r").unwrap();
    println!("Match found {} relationships", match_result.rows.len());
    assert_eq!(match_result.rows.len(), 1, "Should find the relationship");

    // Now delete it
    let delete_result = execute(&mut graph, "MATCH ()-[r:KNOWS]->() DELETE r").unwrap();
    println!("Deleted {} relationships", delete_result.stats.relationships_deleted);
    assert_eq!(delete_result.stats.relationships_deleted, 1, "Should delete 1 relationship");

    // Verify it's gone
    let final_match = execute(&mut graph, "MATCH ()-[r:KNOWS]->() RETURN r").unwrap();
    println!("After deletion, found {} relationships", final_match.rows.len());
    assert_eq!(final_match.rows.len(), 0, "Should find no relationships after deletion");
}

#[test]
fn test_bidirectional_match_counts_relationship_once() {
    let mut graph = PropertyGraph::new();

    // Create ONE relationship
    execute(&mut graph, "CREATE (a)-[r:KNOWS]->(b)").unwrap();

    // Match bidirectionally (undirected)
    let result = execute(&mut graph, "MATCH (a)-[r]-(b) RETURN r").unwrap();

    println!("\n=== Bidirectional Match Test ===");
    println!("Relationships matched: {}", result.rows.len());

    for (i, row) in result.rows.iter().enumerate() {
        println!("Row {}: {:?}", i, row.get("r"));
    }

    // In Neo4j, undirected pattern matches relationship from both directions
    // So (a)-[r]-(b) will match BOTH (a)-[r]->(b) AND (b)<-[r]-(a)
    // This means 2 rows for 1 relationship!
    println!("Expected: 2 rows (same relationship matched from both directions)");
}

#[test]
fn test_bidirectional_delete_issue() {
    let mut graph = PropertyGraph::new();

    // Create ONE relationship
    execute(&mut graph, "CREATE (a)-[r:KNOWS]->(b)").unwrap();

    // Try to delete using bidirectional pattern
    let result = execute(&mut graph, "MATCH (a)-[r]-(b) DELETE r");

    println!("\n=== Bidirectional Delete Test ===");
    match &result {
        Ok(r) => {
            println!("Success! Deleted {} relationships", r.stats.relationships_deleted);
        }
        Err(e) => {
            println!("Error: {:?}", e);
            println!("This is the bug! Same relationship matched twice, deletion attempted twice.");
        }
    }

    // This should succeed but might error with RelationshipNotFound
    // if the same relationship is attempted to be deleted twice
}

#[test]
fn test_multiple_relationships_bidirectional_delete() {
    let mut graph = PropertyGraph::new();

    // Create 2 relationships
    execute(&mut graph, "CREATE (a)-[r1:KNOWS]->(b), (a)-[r2:LIKES]->(b)").unwrap();

    // Verify they exist
    let match_result = execute(&mut graph, "MATCH ()-[r]-() RETURN r").unwrap();
    println!("\n=== Multiple Relationships Test ===");
    println!("Relationships matched: {}", match_result.rows.len());
    println!("Expected: 4 (2 relationships × 2 directions each)");

    // Delete using bidirectional pattern
    let delete_result = execute(&mut graph, "MATCH ()-[r]-() DELETE r");

    match &delete_result {
        Ok(r) => {
            println!("Successfully deleted {} relationships", r.stats.relationships_deleted);
            println!("Expected: 2 (not 4, because duplicates should be removed)");
        }
        Err(e) => {
            println!("Error during deletion: {:?}", e);
        }
    }
}

#[test]
fn test_path_deletion_with_shared_relationships() {
    let mut graph = PropertyGraph::new();

    // Create a path: (a)-[r1]->(b)-[r2]->(c)
    execute(&mut graph, "CREATE (a)-[r1:KNOWS]->(b)-[r2:KNOWS]->(c)").unwrap();

    // Match two overlapping paths that share node b
    // Path 1: (a)-[r1]->(b)
    // Path 2: (b)-[r2]->(c)
    let result = execute(&mut graph, r#"
        MATCH p1 = (a)-[r1:KNOWS]->(b),
              p2 = (b)-[r2:KNOWS]->(c)
        DELETE r1, r2
    "#);

    println!("\n=== Path Deletion Test ===");
    match &result {
        Ok(r) => {
            println!("Success! Deleted {} relationships", r.stats.relationships_deleted);
            assert_eq!(r.stats.relationships_deleted, 2);
        }
        Err(e) => {
            println!("Error: {:?}", e);
        }
    }
}
