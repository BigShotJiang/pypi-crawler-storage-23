// Mimic the exact failing TCK test
use ocg::{execute_with_params, PropertyGraph};
use std::collections::HashMap;

fn main() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    // Exact setup from WithOrderBy4 [1]
    println!("Setup: Creating nodes...");
    let setup = r#"
CREATE (:A {num: 1, num2: 4}),
       (:A {num: 5, num2: 2}),
       (:A {num: 9, num2: 0}),
       (:A {num: 3, num2: 3}),
       (:A {num: 7, num2: 1})
    "#;
    
    match execute_with_params(&mut graph, setup, params.clone()) {
        Ok(r) => println!("  ✓ Created {} nodes", r.stats.nodes_created),
        Err(e) => {
            println!("  ✗ Setup failed: {:?}", e);
            return;
        }
    }

    // Exact query from WithOrderBy4 [1]
    println!("\nQuery: WITH + ORDER BY + LIMIT");
    let query = r#"
MATCH (a:A)
WITH a, a.num + a.num2 AS sum
  ORDER BY a.num + a.num2
  LIMIT 3
RETURN a, sum
    "#;

    match execute_with_params(&mut graph, query, params) {
        Ok(r) => {
            println!("  ✓ Found {} rows (expected 3)", r.row_count());
            println!("  Columns: {:?}", r.columns);
            for (i, record) in r.rows.iter().enumerate() {
                println!("  Row {}: {:?}", i, record);
            }
        }
        Err(e) => println!("  ✗ Query failed: {:?}", e),
    }
}
