### Tabletop — Scoring Guidance

This query involves reusable front-of-house dining and bar serviceware.

**Critical distinctions to enforce:**

- **Material**: Porcelain vs melamine vs glass vs stainless differ in durability and use. If query specifies one, treat as hard.
- **Dimensions**: Plate diameter and bowl capacity are hard when specified.
- **Glassware type**: Pint vs rocks vs wine glass vs martini are distinct.
