### Ventilation — Scoring Guidance

This query involves kitchen ventilation systems and accessories.

**Critical distinctions to enforce:**

- **Hood type**: Type I (grease) vs Type II (heat/steam/condensate) matters. Do not substitute when specified.
- **Length and CFM**: Hood length, CFM, and filter type are hard constraints.
- **Fire suppression**: If query includes suppression, treat as hard.
