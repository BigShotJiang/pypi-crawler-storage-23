import os
import click
from pathlib import Path

TEMPLATE_STRUCTURE = {
    "app.py": """from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def dashboard():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
""",

    "requirements.txt": """flask
pandas
scikit-learn
joblib
""",

    "models/churn_model.pkl": "",  # empty placeholder
    "models/scaler.pkl": "",

    "data/churn_data.csv": "",

    "training/train_model.py": """# Model training script

def train_model():
    print("Training model...")

if __name__ == "__main__":
    train_model()
""",

    "training/churn.ipynb": "",

    "tests/APITest.http": """### Test Home Route
GET http://127.0.0.1:5000/
""",

    "templates/index.html": """<!DOCTYPE html>
<html>
<head>
    <title>Churn Dashboard</title>
</head>
<body>
    <h1>Customer Churn Dashboard</h1>
    <script src="{{ url_for('static', filename='js/dashboard.js') }}"></script>
</body>
</html>
""",

    "static/js/dashboard.js": """console.log("Churn Dashboard Loaded");"""
}


@click.command("create-churn-dashboard")
@click.argument("project_name")
def create_churn_dashboard(project_name):
    """Create Churn Dashboard project structure."""

    base_path = Path(project_name)

    if base_path.exists():
        click.echo("❌ Directory already exists.")
        return

    for path, content in TEMPLATE_STRUCTURE.items():
        file_path = base_path / path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)

    click.echo(f"✅ Churn Dashboard '{project_name}' created successfully!")