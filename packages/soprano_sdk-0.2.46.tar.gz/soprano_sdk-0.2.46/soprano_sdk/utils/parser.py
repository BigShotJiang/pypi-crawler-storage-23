
from typing import Any, Dict
from ..utils.logger import logger
import json
import ast


def convert_to_dict(response: Any) -> Dict[str, Any] | str:
    """
    Convert response to dict using 3 strategies:
    1. Check if already a dict
    2. Try json.loads()
    3. Try ast.literal_eval()
    """

    # Strategy 1: Already a dict
    if isinstance(response, dict):
        logger.info("Response is already a dict")
        return response

    # Convert to string for parsing
    response_str_raw = str(response)
    response_str = response_str_raw[response_str_raw.find("{"): response_str_raw.rfind("}")+1]

    # Strategy 2: Try json.loads()
    try:
        parsed = json.loads(response_str)
        logger.info("Successfully parsed with json.loads()")
        return parsed
    except (json.JSONDecodeError, ValueError, TypeError) as e:
        logger.error(f"json.loads() failed: {e}")

    # Strategy 3: Try ast.literal_eval()
    try:
        parsed = ast.literal_eval(response_str)
        if isinstance(parsed, dict):
            logger.info("Successfully parsed with ast.literal_eval()")
            return parsed
    except (ValueError, SyntaxError, TypeError) as e:
        logger.error(f"ast.literal_eval() failed: {e}")

    # All parsing failed - return as string
    logger.error("All parsing strategies failed, returning raw response")
    return response_str
