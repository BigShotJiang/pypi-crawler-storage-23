"""Tests for cron-related helpers in client.py."""

from __future__ import annotations

from redflow.client import RedflowClient, _cron_to_dict
from redflow.types import CronTrigger


class TestCronToDict:
    def test_minimal(self) -> None:
        c = CronTrigger(expression="0 * * * *")
        d = _cron_to_dict(c)
        assert d == {"expression": "0 * * * *"}

    def test_with_timezone(self) -> None:
        c = CronTrigger(expression="0 9 * * *", timezone="Europe/Berlin")
        d = _cron_to_dict(c)
        assert d == {"expression": "0 9 * * *", "timezone": "Europe/Berlin"}

    def test_with_input(self) -> None:
        c = CronTrigger(expression="*/5 * * * *", input={"key": "val"})
        d = _cron_to_dict(c)
        assert d == {"expression": "*/5 * * * *", "input": {"key": "val"}}

    def test_with_id(self) -> None:
        c = CronTrigger(expression="0 0 * * *", id="nightly")
        d = _cron_to_dict(c)
        assert d == {"expression": "0 0 * * *", "id": "nightly"}

    def test_full(self) -> None:
        c = CronTrigger(expression="0 0 * * *", timezone="UTC", input={"x": 1}, id="my-cron")
        d = _cron_to_dict(c)
        assert d == {"expression": "0 0 * * *", "timezone": "UTC", "input": {"x": 1}, "id": "my-cron"}

    def test_none_values_omitted(self) -> None:
        c = CronTrigger(expression="0 * * * *", timezone=None, input=None, id=None)
        d = _cron_to_dict(c)
        assert d == {"expression": "0 * * * *"}
        assert "timezone" not in d
        assert "input" not in d
        assert "id" not in d


class TestComputeCronId:
    def _make_client(self) -> RedflowClient:
        """Instantiate client with a dummy Redis — only _compute_cron_id is tested (no IO)."""
        return RedflowClient.__new__(RedflowClient)

    def test_user_id_deterministic(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf", "my-custom-id", "0 * * * *", None, None)
        id2 = c._compute_cron_id("wf", "my-custom-id", "0 * * * *", None, None)
        assert id1 == id2
        assert id1.startswith("cron_user_")

    def test_auto_id_deterministic(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf", None, "0 * * * *", "UTC", None)
        id2 = c._compute_cron_id("wf", None, "0 * * * *", "UTC", None)
        assert id1 == id2
        assert id1.startswith("cron_auto_")

    def test_different_expressions_different_ids(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf", None, "0 * * * *", None, None)
        id2 = c._compute_cron_id("wf", None, "*/5 * * * *", None, None)
        assert id1 != id2

    def test_different_workflows_different_ids(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf-a", None, "0 * * * *", None, None)
        id2 = c._compute_cron_id("wf-b", None, "0 * * * *", None, None)
        assert id1 != id2

    def test_different_input_different_ids(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf", None, "0 * * * *", None, {"a": 1})
        id2 = c._compute_cron_id("wf", None, "0 * * * *", None, {"a": 2})
        assert id1 != id2

    def test_user_id_ignores_expression(self) -> None:
        c = self._make_client()
        id1 = c._compute_cron_id("wf", "same-id", "0 * * * *", None, None)
        id2 = c._compute_cron_id("wf", "same-id", "*/5 * * * *", None, None)
        assert id1 == id2
