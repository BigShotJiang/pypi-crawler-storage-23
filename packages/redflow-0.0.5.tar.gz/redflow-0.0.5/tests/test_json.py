"""Test JSON serialization helpers for cross-language compatibility."""

import pytest

from redflow._json import (
    UNDEFINED_TOKEN,
    safe_json_dumps,
    safe_json_loads,
    safe_json_try_loads,
)


def test_dumps_none() -> None:
    assert safe_json_dumps(None) == "null"


def test_dumps_dict() -> None:
    result = safe_json_dumps({"a": 1})
    assert result == '{"a":1}'


def test_dumps_list() -> None:
    assert safe_json_dumps([1, 2, 3]) == "[1,2,3]"


def test_dumps_string() -> None:
    assert safe_json_dumps("hello") == '"hello"'


def test_dumps_unicode() -> None:
    result = safe_json_dumps({"emoji": "🇷🇸"})
    assert "🇷🇸" in result


def test_loads_null() -> None:
    assert safe_json_loads("null") is None


def test_loads_dict() -> None:
    assert safe_json_loads('{"a":1}') == {"a": 1}


def test_loads_none_raises() -> None:
    with pytest.raises(ValueError, match="Expected JSON"):
        safe_json_loads(None)


def test_loads_undefined_token() -> None:
    assert safe_json_loads(UNDEFINED_TOKEN) is None


def test_try_loads_none() -> None:
    assert safe_json_try_loads(None) is None


def test_try_loads_invalid() -> None:
    assert safe_json_try_loads("not json{{{") is None


def test_try_loads_valid() -> None:
    assert safe_json_try_loads('{"ok":true}') == {"ok": True}
