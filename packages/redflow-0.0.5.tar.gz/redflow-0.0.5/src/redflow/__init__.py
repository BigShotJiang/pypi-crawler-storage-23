"""redflow — Durable workflow engine backed by Redis.

Public API
----------

Client
~~~~~~
.. autoclass:: RedflowClient
.. autofunction:: create_client

Workflow definition
~~~~~~~~~~~~~~~~~~~
.. autofunction:: define_workflow
.. autodecorator:: workflow
.. autoclass:: WorkflowRegistry
.. autoclass:: WorkflowHandlerContext
.. autoclass:: WorkflowDefinition

Worker
~~~~~~
.. autofunction:: start_worker
.. autoclass:: StartWorkerOptions
.. autoclass:: WorkerHandle

Testing
~~~~~~~
.. autofunction:: run_inline
.. autoclass:: InlineRunResult
.. autoclass:: InlineStepResult

Types
~~~~~
.. autoclass:: RunState
.. autoclass:: StepState
.. autoclass:: RunStats
.. autoclass:: CronTrigger
.. autoclass:: DefineWorkflowOptions

Errors
~~~~~~
.. autoclass:: RedflowError
.. autoclass:: CanceledError
.. autoclass:: NonRetriableError
.. autoclass:: TimeoutError
"""

from .client import ConcreteRunHandle as RunHandle
from .client import RedflowClient, create_client
from .errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    RedflowError,
    TimeoutError,
    UnknownWorkflowError,
)
from .registry import (
    WorkflowDefinition,
    WorkflowHandlerContext,
    WorkflowRegistry,
    define_workflow,
    get_default_registry,
    workflow,
)
from .testing import InlineRunResult, InlineStepResult, run_inline
from .types import (
    CronTrigger,
    DefineWorkflowOptions,
    ListedRun,
    ListRunsParams,
    OnFailureContext,
    RunState,
    RunStats,
    RunStatus,
    StepState,
    WorkflowMeta,
)
from .worker import StartWorkerOptions, WorkerHandle, start_worker

__all__ = [
    "CanceledError",
    "CronTrigger",
    "DefineWorkflowOptions",
    "InlineRunResult",
    "InlineStepResult",
    "InputValidationError",
    "ListRunsParams",
    "ListedRun",
    "NonRetriableError",
    "OnFailureContext",
    "OutputSerializationError",
    # Client
    "RedflowClient",
    # Errors
    "RedflowError",
    "RunHandle",
    # Types
    "RunState",
    "RunStats",
    "RunStatus",
    "StartWorkerOptions",
    "StepState",
    "TimeoutError",
    "UnknownWorkflowError",
    "WorkerHandle",
    "WorkflowDefinition",
    "WorkflowHandlerContext",
    "WorkflowMeta",
    "WorkflowRegistry",
    "create_client",
    # Workflow definition
    "define_workflow",
    "get_default_registry",
    # Testing
    "run_inline",
    # Worker
    "start_worker",
    "workflow",
]
