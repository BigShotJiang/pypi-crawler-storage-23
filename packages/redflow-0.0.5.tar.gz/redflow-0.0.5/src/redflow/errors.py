"""Error hierarchy — wire-compatible with the TypeScript ``errors.ts``.

Every error class carries a ``kind`` tag that matches the TS serialized format,
so errors round-trip correctly across the Python ↔ TypeScript boundary.
"""

from __future__ import annotations

import traceback
from typing import Any, TypedDict


class RedflowError(Exception):
    """Base class for all redflow errors."""

    kind: str = "error"


class InputValidationError(RedflowError):
    """Workflow input did not pass schema validation."""

    kind = "validation"

    def __init__(self, message: str = "Workflow input validation failed", issues: Any = None) -> None:
        super().__init__(message)
        self.issues = issues


class UnknownWorkflowError(RedflowError):
    """The requested workflow is not registered."""

    kind = "unknown_workflow"

    def __init__(self, workflow_name: str) -> None:
        super().__init__(f"Unknown workflow: {workflow_name}")
        self.workflow_name = workflow_name


class CanceledError(RedflowError):
    """The run was canceled."""

    kind = "canceled"

    def __init__(self, message: str = "Run canceled") -> None:
        super().__init__(message)


class TimeoutError(RedflowError):
    """An operation exceeded its time limit."""

    kind = "timeout"

    def __init__(self, message: str = "Operation timed out") -> None:
        super().__init__(message)


class OutputSerializationError(RedflowError):
    """Workflow or step output could not be serialized to JSON."""

    kind = "serialization"

    def __init__(
        self,
        message: str = "Workflow output is not JSON-serializable",
        cause_error: Any = None,
    ) -> None:
        super().__init__(message)
        self.cause_error = cause_error


class NonRetriableError(RedflowError):
    """Throw to immediately fail the run without retries.

    Use for permanent/deterministic failures (invalid data, business-logic
    violations) where retrying would produce the same result.
    """

    kind = "non_retriable"


# ---------- serialization ----------


class SerializedError(TypedDict, total=False):
    name: str
    message: str
    stack: str
    code: str
    kind: str


def serialize_error(err: BaseException | Any) -> SerializedError:
    """Produce a wire-compatible serialized error dict."""
    if isinstance(err, RedflowError):
        kind = err.kind
        result: SerializedError = {
            "name": type(err).__name__,
            "message": str(err),
            "kind": kind,
        }
        tb = "".join(traceback.format_exception(type(err), err, err.__traceback__))
        if tb:
            result["stack"] = tb
        return result

    if isinstance(err, BaseException):
        result = {
            "name": type(err).__name__,
            "message": str(err),
            "kind": "error",
        }
        code = getattr(err, "code", None)
        if isinstance(code, str):
            result["code"] = code
        tb = "".join(traceback.format_exception(type(err), err, err.__traceback__))
        if tb:
            result["stack"] = tb
        return result

    return {
        "name": "Error",
        "message": _stringify_unknown_error(err),
        "kind": "error",
    }


def _stringify_unknown_error(err: Any) -> str:
    if isinstance(err, str):
        return err
    try:
        import json

        return json.dumps(err)
    except (TypeError, ValueError):
        pass
    try:
        return str(err)
    except Exception:
        return "Unknown error"
