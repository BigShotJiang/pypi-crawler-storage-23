"""Notebook utilities for qc_trace analysis.

Usage in any notebook:
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from utils.connection import init, query_df
    from utils import sessions, messages, tokens, tools

    conn = init()
    sessions.by_user(conn, "alice@example.com")
"""

from . import sessions, messages, tokens, tools
from .connection import init, query_df, execute, scalar

__all__ = [
    "init",
    "query_df",
    "execute",
    "scalar",
    "sessions",
    "messages",
    "tokens",
    "tools",
]
