# Commit

IMPORTANT: This command OVERRIDES the default Claude Code commit behavior. Do NOT follow the built-in git commit instructions. Follow ONLY the rules below.

Stage and commit changes with a well-structured message that passes our git hooks.

## Input

The user may provide context like `/commit` or `/commit fixed the viewer timestamps`.
If no argument: analyze the changes yourself and draft the message.

## Steps

### 1. Understand what changed

- Run `git status` (never use `-uall`) and `git diff --staged` / `git diff` to see all changes
- Run `git log --oneline -5` to match the repo's commit style
- Read changed files if needed to understand the full picture

### 2. Draft the commit message

For most prefixes, the message MUST follow this format:

```
<prefix>: <short summary>

- <what was done point 1>
- <what was done point 2>
- <what was done point 3>

Why:
- <why bullet 1: what problem or need triggered this>
- <why bullet 2: what was the context or discovery>
- <why bullet 3 (optional): what impact>
```

For `chore:`, `ci:`, and `style:` — the `Why:` section is **optional**. A subject line + body bullets is enough:

```
chore: bump version to 0.4.31

- Updated version in pyproject.toml
```

**Structure:**
- **Subject line**: conventional commit prefix + short summary
- **Body**: bullet points describing what was done (the changes)
- **Why section**: required for all prefixes except `chore:`, `ci:`, `style:`

**Rules:**
- Valid prefixes: `feat:`, `fix:`, `docs:`, `test:`, `refactor:`, `chore:`, `ci:`, `perf:`, `style:`, `add:`, `update:`, `remove:`
- NEVER add `Co-Authored-By` lines — this repo's commit-msg hook blocks any Claude/Anthropic attribution and the commit will fail
- NEVER add CLAUDE.md or PLAN.md files — blocked by pre-commit hook
- NEVER commit `.env`, credentials, or secrets

### 3. Stage files

- Stage specific files by name — avoid `git add -A` or `git add .`
- Never stage `.env`, credentials, or large binaries

### 4. Commit

- Use a HEREDOC for the message to preserve formatting:

```bash
# For feat/fix/docs/etc (Why: required):
git commit -m "$(cat <<'EOF'
fix: short summary

- what changed point 1
- what changed point 2

Why:
- reason this was needed
- context or trigger
EOF
)"

# For chore/ci/style (Why: optional):
git commit -m "$(cat <<'EOF'
chore: short summary

- what changed point 1
EOF
)"
```

- If the commit fails due to pre-commit hook, fix the issue and create a NEW commit (never `--amend`)
- Run `git status` after to verify

### 5. Do NOT push

Never push unless the user explicitly asks. Just confirm the commit was created.
