"""Entry point: python -m qc_trace.daemon"""

import logging

from qc_trace.daemon.config import DaemonConfig
from qc_trace.daemon.main import Daemon


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    config = DaemonConfig()
    daemon = Daemon(config)
    daemon.run()


if __name__ == "__main__":
    main()
