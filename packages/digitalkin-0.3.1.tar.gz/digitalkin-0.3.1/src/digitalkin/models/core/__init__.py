"""Core models."""
