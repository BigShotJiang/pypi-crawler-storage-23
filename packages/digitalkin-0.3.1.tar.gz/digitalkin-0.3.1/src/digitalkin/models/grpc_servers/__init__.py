"""Base gRPC server and client models."""
