"""Core of Digitlakin defining the task management and sub-modules."""
