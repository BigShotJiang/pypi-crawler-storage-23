"""Poison pill detection and retry count tracking."""

from __future__ import annotations

from neonlink.record import HEADER_RETRY_COUNT, Record


def is_poison_pill(record: Record, threshold: int) -> bool:
    """Check whether a record has exceeded the retry threshold."""
    return get_retry_count(record) >= threshold


def get_retry_count(record: Record) -> int:
    """Return the current retry count from record headers."""
    val = record.get_header(HEADER_RETRY_COUNT)
    if not val:
        return 0
    try:
        return int(val)
    except ValueError:
        return 0


def increment_retry_count(record: Record) -> int:
    """Increment the retry_count header and return the new value."""
    count = get_retry_count(record) + 1
    record.set_header(HEADER_RETRY_COUNT, str(count))
    return count
