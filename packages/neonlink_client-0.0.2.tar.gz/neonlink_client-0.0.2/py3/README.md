# neonlink-client

NeonLink SDK for Python — Kafka/Redpanda client + Protocol Buffer definitions.

## Installation

```bash
pip install neonlink-client
```

## Usage

### Kafka SDK

```python
from neonlink import Producer, Consumer, Config

config = Config.from_env()  # reads NEONLINK_* env vars
producer = Producer(config)
consumer = Consumer(config, group_id="my-service")
```

### Proto Types

```python
from messaging.v1 import messaging_pb2

header = messaging_pb2.MessageHeader(
    message_id="uuid",
    correlation_id="correlation-uuid",
    message_type=messaging_pb2.MESSAGE_TYPE_ETL_COMPLETION,
)
```

## Package Contents

- `neonlink` — Kafka/Redpanda client SDK (Producer, Consumer, circuit breaker, DLQ, tracing)
- `messaging.v1` — Protocol Buffer definitions for inter-service messaging

## Source

Published from [mcfo-neonlink](https://github.com/LetA-Tech/mcfo-neonlink).
