from dbt.tests.adapter.utils.test_hash import BaseHash


class TestHashFabric(BaseHash):
    pass
