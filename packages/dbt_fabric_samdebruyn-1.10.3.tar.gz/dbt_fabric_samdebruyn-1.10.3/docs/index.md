--8<-- "README.md:0:1"

![dbt logo for light mode](https://raw.githubusercontent.com/sdebruyn/dbt-fabric/forked-version/assets/dbt-signature_tm.png#gh-light-mode-only)
![dbt logo for dark mode](https://raw.githubusercontent.com/sdebruyn/dbt-fabric/forked-version/assets/dbt-signature_tm_light.png#gh-dark-mode-only)
![fabric logo](https://raw.githubusercontent.com/sdebruyn/dbt-fabric/forked-version/assets/fabric.png)

--8<-- "README.md:10:18"
--8<-- "README.md:22"
