{% macro fabric__log_natural(x) %}

    log({{ x }})

{%- endmacro -%}
