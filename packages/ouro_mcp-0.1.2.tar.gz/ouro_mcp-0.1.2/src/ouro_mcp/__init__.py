"""Ouro MCP Server — exposes Ouro platform capabilities to AI agents via the Model Context Protocol."""

__version__ = "0.1.2"
