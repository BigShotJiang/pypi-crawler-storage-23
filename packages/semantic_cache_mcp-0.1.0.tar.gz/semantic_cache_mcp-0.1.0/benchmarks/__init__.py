"""Benchmark utilities for semantic-cache-mcp."""
