"""Shared test constants."""

# Matches the current embedding model dimension. Change this single value
# when swapping models so all model-dependent tests adapt automatically.
TEST_EMBEDDING_DIM = 384
