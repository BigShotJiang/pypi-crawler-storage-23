import powerfactory

app = powerfactory.GetApplication()

app.PrintPlain("This is an embedded test script.")

#### Insert after this line

# This should be replaced

#### Insert before this line



#### Insert powfacpy after this line

# This should be replaced

#### End powfacpy before this line


