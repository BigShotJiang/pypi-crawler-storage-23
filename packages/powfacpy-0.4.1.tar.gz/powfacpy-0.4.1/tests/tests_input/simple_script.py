import powerfactory

app = powerfactory.GetApplication()

app.PrintPlain("This is a simple embedded test script.")