pub mod categorical;
pub mod numerical;
pub mod precategorical;
pub mod prenumerical;
pub mod woeiv;
