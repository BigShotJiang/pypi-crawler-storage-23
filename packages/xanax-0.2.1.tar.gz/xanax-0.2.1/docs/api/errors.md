# Errors

::: xanax.errors.XanaxError

::: xanax.errors.AuthenticationError

::: xanax.errors.RateLimitError

::: xanax.errors.NotFoundError

::: xanax.errors.ValidationError

::: xanax.errors.APIError
