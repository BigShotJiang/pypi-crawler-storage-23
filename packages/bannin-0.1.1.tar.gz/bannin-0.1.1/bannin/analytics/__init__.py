"""Bannin analytics -- persistent event storage and querying."""

from __future__ import annotations
