"""Bannin MCP Server -- exposes monitoring data to AI coding tools."""

from __future__ import annotations

from bannin.mcp.server import serve

__all__ = ["serve"]
