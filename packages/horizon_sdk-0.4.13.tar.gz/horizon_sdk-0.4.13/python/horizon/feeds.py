"""Feed wrappers for price data sources."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class BinanceWS:
    """Binance WebSocket price feed.

    Usage: BinanceWS("btcusdt")
    """

    symbol: str
    _type: str = "binance_ws"


@dataclass
class RESTFeed:
    """Generic REST API price feed.

    Usage: RESTFeed("https://api.example.com/price", interval=5.0)
    """

    url: str
    interval: float = 5.0
    _type: str = "rest"


@dataclass
class PolymarketBook:
    """Polymarket orderbook feed.

    Usage: PolymarketBook("will-btc-hit-100k")
    """

    market_slug: str
    _type: str = "polymarket_book"


@dataclass
class KalshiBook:
    """Kalshi orderbook feed.

    Usage: KalshiBook("KXBTC-25FEB16")
    """

    ticker: str
    _type: str = "kalshi_book"


@dataclass
class PredictItFeed:
    """PredictIt market price feed.

    Polls the PredictIt API for contract prices.

    Usage: PredictItFeed(market_id=7456, contract_id=28562)
    """

    market_id: int
    contract_id: int | None = None
    interval: float = 5.0
    _type: str = "predictit"


@dataclass
class ManifoldFeed:
    """Manifold Markets probability feed.

    Polls the Manifold API for market probability.

    Usage: ManifoldFeed("will-btc-hit-100k-by-2026")
    """

    slug: str
    interval: float = 5.0
    _type: str = "manifold"


@dataclass
class ESPNFeed:
    """ESPN live scoreboard feed.

    Polls ESPN for live game scores.

    Usage: ESPNFeed("basketball", "nba")
    """

    sport: str
    league: str
    event_id: str | None = None
    interval: float = 10.0
    _type: str = "espn"


@dataclass
class NWSFeed:
    """National Weather Service feed.

    Two modes:
      - forecast: temperature, wind, precipitation for a grid point
      - alerts: active weather alerts for a state

    Usage:
        NWSFeed(office="TOP", grid_x=31, grid_y=80)  # forecast
        NWSFeed(state="FL", mode="alerts")             # alerts
    """

    office: str = ""
    grid_x: int = 0
    grid_y: int = 0
    state: str = ""
    mode: str = "forecast"
    user_agent: str = "Horizon-SDK/0.4.7"
    interval: float = 60.0
    _type: str = "nws"


@dataclass
class RESTJsonPathFeed:
    """Enhanced REST feed with JSON path extraction.

    Uses dot-notation paths to map any JSON field to price/bid/ask/volume.

    Usage:
        RESTJsonPathFeed(
            url="https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd",
            price_path="bitcoin.usd",
        )
    """

    url: str
    price_path: str | None = None
    bid_path: str | None = None
    ask_path: str | None = None
    volume_path: str | None = None
    interval: float = 5.0
    _type: str = "rest_json_path"


@dataclass
class ChainlinkFeed:
    """Chainlink on-chain price oracle feed.

    Reads price data from a Chainlink aggregator proxy contract via
    JSON-RPC eth_call. Works with any EVM chain (Ethereum, Arbitrum,
    Polygon, BSC).

    Usage:
        ChainlinkFeed(
            contract_address="0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419",
            rpc_url="https://eth.llamarpc.com",
        )
    """

    contract_address: str
    rpc_url: str
    decimals: int = 8
    interval: float = 10.0
    _type: str = "chainlink"
