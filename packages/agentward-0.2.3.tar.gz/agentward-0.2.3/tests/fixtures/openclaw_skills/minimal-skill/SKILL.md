---
name: minimal-skill
description: A minimal skill with no special requirements.
---

# Minimal Skill

This skill has no binary or environment requirements.
