# No Frontmatter

This file has no YAML frontmatter at all.
It should be skipped by the scanner.
