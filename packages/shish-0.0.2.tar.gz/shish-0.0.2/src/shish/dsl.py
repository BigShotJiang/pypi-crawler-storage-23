"""DSL types and builders for shell command construction.

Cmd and Pipeline are thin wrappers around ir.Cmd/ir.Pipeline with no public
methods.  All operations (pipe, read, write, feed, run, out, etc.) are
module-level combinator functions that unwrap to IR, delegate, and re-wrap.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Generator, Mapping
from typing import TYPE_CHECKING, Never, cast, overload

import shish.ir as ir
from shish.aio import make_byte_wrapper
from shish.fdops import STDIN, STDOUT

if TYPE_CHECKING:
    from shish.aio import ByteStageCtx, TextStageCtx
    from shish.runtime import Execution

Flag = ir.PathLike | bool

TextFn = Callable[["TextStageCtx"], Awaitable[int]]
ByteFn = Callable[["ByteStageCtx"], Awaitable[int]]


class Cmd:
    """Immutable shell command builder with chainable syntax."""

    def __init__(self, _shish_ir: ir.Cmd) -> None:
        self._shish_ir = _shish_ir

    def __getattr__(self, name: str) -> Cmd:
        """Chain subcommand: cmd.foo -> Cmd with "foo" appended."""
        return Cmd(self._shish_ir.arg(name))

    def __call__(self, *args: ir.Arg, **kwargs: Flag) -> Cmd:
        """Add args and flags: cmd("arg", flag=True)."""
        call_args: list[ir.Arg] = list(args)
        for key, value in kwargs.items():
            if value is False:
                continue
            flag = f"-{key}" if len(key) == 1 else f"--{key.replace('_', '-')}"
            if value is True:
                call_args.append(flag)
            else:
                call_args.extend([flag, value])
        if call_args:
            return Cmd(self._shish_ir.arg(*call_args))
        return Cmd(self._shish_ir)

    def __or__(self, other: Runnable) -> Pipeline:
        """cmd1 | cmd2 -> Pipeline."""
        return pipe(self, other)

    def __gt__(self, target: ir.WriteDst | tuple[int, ir.WriteDst]) -> Cmd:
        """cmd > "file", cmd > sub, or cmd > (fd, target)."""
        match target:
            case fd, dst:
                return write(self, dst, fd=fd)
            case dst:
                return write(self, dst)  # type: ignore[arg-type]

    def __rshift__(self, target: ir.WriteDst | tuple[int, ir.WriteDst]) -> Cmd:
        """cmd >> "file", cmd >> sub, or cmd >> (fd, target)."""
        match target:
            case fd, dst:
                return write(self, dst, append=True, fd=fd)
            case dst:
                return write(self, dst, append=True)

    def __lt__(self, target: ir.ReadSrc | tuple[int, ir.ReadSrc]) -> Cmd:
        """cmd < "file", cmd < sub, or cmd < (fd, target)."""
        match target:
            case fd, src:
                return read(self, src, fd=fd)
            case src:
                return read(self, src)  # type: ignore[arg-type]

    def __lshift__(self, data: ir.Data | tuple[int, ir.Data]) -> Cmd:
        """cmd << "data" or cmd << (fd, "data")."""
        match data:
            case fd, payload:
                return feed(self, payload, fd=fd)
            case _:
                return feed(self, data)

    def __matmul__(self, path: ir.PathLike) -> Cmd:
        """cmd @ "/tmp" -> set working directory."""
        return cwd(self, path)

    def __rmod__(self, env_vars: Mapping[str, str | None]) -> Cmd:
        """{"FOO": "bar"} % cmd -> set env vars."""
        return env(self, **env_vars)

    def __bool__(self) -> Never:
        raise TypeError(
            "Cmd cannot be used as bool. Use parentheses: (cmd < 'in') > 'out'"
        )

    def __await__(self) -> Generator[object, None, int]:
        return self._shish_ir.run().__await__()


class Pipeline:
    """Immutable pipeline of commands."""

    def __init__(self, _shish_ir: ir.Pipeline) -> None:
        self._shish_ir = _shish_ir

    def __or__(self, other: Runnable) -> Pipeline:
        """pipeline | cmd -> Pipeline."""
        return pipe(self, other)

    def __ror__(self, other: Cmd) -> Pipeline:
        """cmd | pipeline -> Pipeline."""
        return pipe(other, self)

    def __gt__(self, target: object) -> Never:
        """Redirect operators are not supported on Pipeline."""
        raise TypeError(
            "Pipeline does not support >. You probably wanted: cmd1 | (cmd2 > target)"
        )

    def __rshift__(self, target: object) -> Never:
        """Redirect operators are not supported on Pipeline."""
        raise TypeError(
            "Pipeline does not support >>. You probably wanted: cmd1 | (cmd2 >> target)"
        )

    def __lt__(self, target: object) -> Never:
        """Redirect operators are not supported on Pipeline."""
        raise TypeError(
            "Pipeline does not support <. You probably wanted: (cmd1 < source) | cmd2"
        )

    def __lshift__(self, data: object) -> Never:
        """Redirect operators are not supported on Pipeline."""
        raise TypeError(
            "Pipeline does not support <<. You probably wanted: (cmd1 << data) | cmd2"
        )

    def __matmul__(self, path: object) -> Never:
        """@ operator is not supported on Pipeline."""
        raise TypeError("Pipeline does not support @. Apply cwd to individual cmds.")

    def __rmod__(self, env_vars: object) -> Never:
        """% operator is not supported on Pipeline."""
        raise TypeError("Pipeline does not support %. Apply env to individual cmds.")

    def __bool__(self) -> Never:
        raise TypeError(
            "Pipeline cannot be used as bool. Use parentheses: (cmd < 'in') > 'out'"
        )

    def __await__(self) -> Generator[object, None, int]:
        return self._shish_ir.run().__await__()


class Fn:
    """Immutable wrapper for a Python function as a pipeline stage."""

    def __init__(self, _shish_ir: ir.Fn) -> None:
        self._shish_ir = _shish_ir

    def __or__(self, other: Runnable) -> Pipeline:
        """fn | cmd -> Pipeline."""
        return pipe(self, other)

    def __bool__(self) -> Never:
        raise TypeError("Fn cannot be used as bool")

    def __await__(self) -> Generator[object, None, int]:
        return self._shish_ir.run().__await__()


# Type alias requiring all classes
Runnable = Cmd | Pipeline | Fn


# Combinators


@overload
def unwrap(cmd: Cmd) -> ir.Cmd: ...
@overload
def unwrap(cmd: Pipeline) -> ir.Pipeline: ...
@overload
def unwrap(cmd: Fn) -> ir.Fn: ...


def unwrap(cmd: Cmd | Pipeline | Fn) -> ir.Cmd | ir.Pipeline | ir.Fn:
    """Extract the IR from a DSL wrapper."""
    return cmd._shish_ir  # pyright: ignore[reportPrivateUsage]


@overload
def wrap(inner: ir.Cmd) -> Cmd: ...
@overload
def wrap(inner: ir.Pipeline) -> Pipeline: ...
@overload
def wrap(inner: ir.Fn) -> Fn: ...


def wrap(inner: ir.Cmd | ir.Pipeline | ir.Fn) -> Cmd | Pipeline | Fn:
    """Wrap an IR in its DSL counterpart."""
    match inner:
        case ir.Cmd():
            return Cmd(inner)
        case ir.Pipeline():
            return Pipeline(inner)
        case ir.Fn():
            return Fn(inner)


def cmd(*args: ir.Arg, **kwargs: Flag) -> Cmd:
    """Create a command from arguments: cmd("echo", "hello") -> Cmd."""
    return Cmd(ir.cmd())(*args, **kwargs)


@overload
def fn(func: TextFn, /) -> Fn: ...
@overload
def fn(func: TextFn, /, *, encoding: str) -> Fn: ...
@overload
def fn(func: ByteFn, /, *, encoding: None) -> Fn: ...
@overload
def fn(*, encoding: None) -> Callable[[ByteFn], Fn]: ...
@overload
def fn(*, encoding: str = ...) -> Callable[[TextFn], Fn]: ...


def fn(
    func: TextFn | ByteFn | None = None,
    *,
    encoding: str | None = "utf-8",
) -> Fn | Callable[[ByteFn], Fn] | Callable[[TextFn], Fn]:
    """Create an Fn from an async callable.

    Forms:
        @fn                         — text mode, utf-8
        @fn()                       — text mode, utf-8
        fn(f, encoding="latin-1")   — text mode, custom encoding
        @fn(encoding="latin-1")     — text mode, custom encoding
        fn(f, encoding=None)        — byte mode, no decoding
        @fn(encoding=None)          — byte mode, no decoding
    """
    match func, encoding:
        case None, None:  # @fn(encoding=None)
            def byte_decorator(inner: ByteFn) -> Fn:
                return Fn(ir.Fn(inner))

            return byte_decorator

        case None, enc:  # @fn() or @fn(encoding="...")
            def text_decorator(inner: TextFn) -> Fn:
                return Fn(ir.Fn(make_byte_wrapper(inner, enc)))

            return text_decorator

        case func_, None:  # fn(f, encoding=None)
            # cast: overloads guarantee ByteFn here, but pyright
            # can't narrow the func/encoding correlation
            return Fn(ir.Fn(cast("ByteFn", func_)))

        case func_, enc:  # @fn or fn(f) or fn(f, encoding="...")
            # cast: same — overloads guarantee TextFn here
            return Fn(ir.Fn(make_byte_wrapper(cast("TextFn", func_), enc)))


def pipe(*cmds: Runnable) -> Pipeline:
    """Pipe commands together: pipe(cmd1, cmd2, ...) -> Pipeline."""
    return Pipeline(ir.pipeline(*(unwrap(stage) for stage in cmds)))


def write(
    cmd: Cmd,
    dst: ir.WriteDst,
    *,
    append: bool = False,
    fd: int = STDOUT,
) -> Cmd:
    """Redirect fd to file or process substitution. Defaults to STDOUT."""
    return Cmd(unwrap(cmd).write(dst, append=append, fd=fd))


def read(cmd: Cmd, src: ir.ReadSrc, *, fd: int = STDIN) -> Cmd:
    """Read fd from file or process substitution. Defaults to STDIN."""
    return Cmd(unwrap(cmd).read(src, fd=fd))


def feed(cmd: Cmd, data: ir.Data, *, fd: int = STDIN) -> Cmd:
    """Feed data into fd. Defaults to STDIN."""
    return Cmd(unwrap(cmd).feed(data, fd=fd))


def close(cmd: Cmd, fd: int) -> Cmd:
    """Close fd."""
    return Cmd(unwrap(cmd).close(fd))


def env(cmd: Cmd, **kwargs: str | None) -> Cmd:
    """Set environment variables on a command. None values unset variables."""
    return Cmd(unwrap(cmd).env(**kwargs))


def cwd(cmd: Cmd, path: ir.PathLike) -> Cmd:
    """Set working directory for a command."""
    return Cmd(unwrap(cmd).cwd(path))


def sub_in(source: Runnable) -> ir.SubIn:
    """Input process substitution: <(source)."""
    return ir.SubIn(unwrap(source))


def sub_out(sink: Runnable) -> ir.SubOut:
    """Output process substitution: >(sink)."""
    return ir.SubOut(unwrap(sink))


async def prepare(cmd: Runnable) -> Execution:
    """Spawn a command or pipeline and return an Execution handle."""
    return await unwrap(cmd).prepare()


async def run(cmd: Runnable) -> int:
    """Execute a command or pipeline and return exit code."""
    return await unwrap(cmd).run()


async def out(cmd: Runnable, encoding: str | None = "utf-8") -> str | bytes:
    """Execute command and return stdout."""
    return await unwrap(cmd).out(encoding)


# Convenience


class Sh:
    """Root command builder. Attribute access creates Cmd instances."""

    def __getattr__(self, name: str) -> Cmd:
        """sh.echo -> Cmd with ("echo",)."""
        return cmd(name)

    def __call__(self, *args: ir.Arg, **kwargs: Flag) -> Cmd:
        """sh("cmd", "arg", flag=True) -> Cmd."""
        return cmd(*args, **kwargs)


sh = Sh()
