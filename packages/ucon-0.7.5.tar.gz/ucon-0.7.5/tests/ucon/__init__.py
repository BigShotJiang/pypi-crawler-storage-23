# © 2025 The Radiativity Company
# Licensed under the Apache License, Version 2.0
# See the LICENSE file for details.

from pathlib import Path

EXAMPLE_UNIT_EXTENSIONS_PATH = Path(__file__).parent.parent.parent / "examples" / "units"