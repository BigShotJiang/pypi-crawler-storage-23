# ucon MCP server
#
# Install: pip install ucon[mcp]
# Run: ucon-mcp

from ucon.mcp.server import main

__all__ = ["main"]
