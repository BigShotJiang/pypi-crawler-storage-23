import abc
import time
from collections.abc import Callable
from typing import Any

from iker.common.utils import logger
from iker.common.utils.dtutils import dt_utc_now
from iker.common.utils.randutils import randomizer

__all__ = [
    "Attempt",
    "Retry",
    "RetryWrapper",
    "retry",
    "retry_exponent",
    "retry_random",
]


class Attempt(object):
    def __init__(
        self,
        number: int,
        prev_wait: int,
        next_wait: int,
        start_ts: float,
        check_ts: float,
        last_exception: Exception,
    ):
        """
        Represents an attempt in retrying.

        :param number: The attempt number (1-based).
        :param prev_wait: The wait time before the previous attempt (in seconds).
        :param next_wait: The wait time before the next attempt (in seconds).
        :param start_ts: The start timestamp of the first attempt.
        :param check_ts: The timestamp at which the current attempt is checked.
        :param last_exception: The exception raised during the last attempt, if any.
        """
        self.number = number
        self.prev_wait = prev_wait
        self.next_wait = next_wait
        self.start_ts = start_ts
        self.check_ts = check_ts
        self.last_exception = last_exception


class Retry(abc.ABC):
    @abc.abstractmethod
    def on_attempt(self, attempt: Attempt):
        """
        Called before each retry attempt. Can be used to perform custom logic or logging before an attempt is made.

        :param attempt: The current ``Attempt`` instance containing attempt details.
        """
        pass

    @abc.abstractmethod
    def execute(self, *args, **kwargs):
        """
        Executes the target operation with retry logic. Must be implemented by subclasses.

        :param args: Positional arguments for the operation.
        :param kwargs: Keyword arguments for the operation.
        :return: The result of the operation.
        """
        pass


class RetryWrapper(object):
    def __init__(
        self,
        target: Callable[..., Any] | Retry,
        wait: int = None,
        wait_func: Callable[[int], int] = None,
        retrials: int = None,
        timeout: int = None,
    ):
        """
        Retry executor that wraps a callable or ``Retry`` instance, providing flexible retry strategies including fixed,
        exponential, and random waits.

        :param target: The target callable or ``Retry`` instance to execute.
        :param wait: Fixed wait time (in seconds) between retrials.
        :param wait_func: Function to determine wait time based on attempt number.
        :param retrials: Maximum number of retrials (``None`` for unlimited).
        :param timeout: Maximum total time (in seconds) allowed for all attempts (``None`` for unlimited).
        """
        self.target = target
        self.wait = wait
        self.wait_func = wait_func
        self.retrials = retrials
        self.timeout = timeout

    def __call__(self, *args, **kwargs):
        """
        Invokes the wrapped callable or ``Retry`` instance with retry logic.

        :param args: Positional arguments for the operation.
        :param kwargs: Keyword arguments for the operation.
        :return: The result of the operation.
        """
        return self.run(*args, **kwargs)

    def next_wait(self, attempt_number: int):
        """
        Determines the wait time before the next retry attempt based on the configured strategy.

        :param attempt_number: The current attempt number (1-based).
        :return: The wait time in seconds, or ``None`` if not applicable.
        """
        if attempt_number <= 0:
            return None
        if self.wait is not None:
            return self.wait
        if self.wait_func is not None:
            return self.wait_func(attempt_number)
        return 0

    def check_timeout(self, start_ts: float) -> tuple[bool, float]:
        """
        Checks if the retry operation has exceeded the configured timeout.

        :param start_ts: The start timestamp of the first attempt.
        :return: Tuple (``True`` if within timeout, current timestamp).
        """
        current_ts = dt_utc_now().timestamp()
        if self.timeout is None:
            return True, current_ts
        return current_ts < start_ts + self.timeout, current_ts

    def run(self, *args, **kwargs):
        """
        Runs the retry loop, invoking the wrapped callable or ``Retry`` instance until success, retrials exhausted, or
        timeout reached.

        :param args: Positional arguments for the operation.
        :param kwargs: Keyword arguments for the operation.
        :return: The result of the operation.
        :raises RuntimeError: If all attempts fail or timeout is reached.
        """
        attempt_number = 0
        start_ts = dt_utc_now().timestamp()
        last_exception = None

        while self.retrials is None or attempt_number <= self.retrials:
            attempt_number += 1

            check_result, check_ts = self.check_timeout(start_ts)
            if not check_result:
                break

            attempt = Attempt(
                attempt_number,
                self.next_wait(attempt_number - 1),
                self.next_wait(attempt_number),
                start_ts,
                check_ts,
                last_exception,
            )
            try:
                if isinstance(self.target, Retry):
                    self.target.on_attempt(attempt)
                    return self.target.execute(*args, **kwargs)
                else:
                    return self.target(*args, **kwargs)
            except Exception as e:
                logger.exception("Function target <'%s'> failed on attempt <%d>", self.target, attempt_number)
                last_exception = e
                time.sleep(self.next_wait(attempt_number))

        raise RuntimeError(f"failed to execute function target '{self.target}' after {attempt_number} attempts")


def retry(wait: int = None, retrials: int = None, timeout: int = None):
    """
    Decorator to apply fixed wait retry logic to a function or callable.

    :param wait: Fixed wait time (in seconds) between retrials.
    :param retrials: Maximum number of retrials (``None`` for unlimited).
    :param timeout: Maximum total time (in seconds) allowed for all attempts (``None`` for unlimited).
    :return: A decorated function with retry logic.
    """

    def wrapper(target):
        return RetryWrapper(target, wait=wait, retrials=retrials, timeout=timeout)

    return wrapper


def retry_exponent(wait_init: int, wait_max: int, retrials: int = None, timeout: int = None):
    """
    Decorator to apply exponential backoff retry logic to a function or callable.

    :param wait_init: Initial wait time for exponential backoff.
    :param wait_max: Maximum wait time for exponential backoff.
    :param retrials: Maximum number of retrials (``None`` for unlimited).
    :param timeout: Maximum total time (in seconds) allowed for all attempts (``None`` for unlimited).
    :return: A decorated function with retry logic.
    """

    def wrapper(target):
        return RetryWrapper(
            target,
            wait_func=lambda x: min(wait_init * (2 ** (x - 1)), wait_max),
            retrials=retrials,
            timeout=timeout,
        )

    return wrapper


def retry_random(wait_min: int, wait_max: int, retrials: int = None, timeout: int = None):
    """
    Decorator to apply random wait retry logic to a function or callable.

    :param wait_min: Minimum wait time for random backoff.
    :param wait_max: Maximum wait time for random backoff.
    :param retrials: Maximum number of retrials (``None`` for unlimited).
    :param timeout: Maximum total time (in seconds) allowed for all attempts (``None`` for unlimited).
    :return: A decorated function with retry logic.
    """

    def wrapper(target):
        return RetryWrapper(
            target,
            wait_func=lambda x: randomizer().next_int(wait_min, wait_max),
            retrials=retrials,
            timeout=timeout,
        )

    return wrapper
