"""CLI module for VenomQA v1."""

from venomqa.v1.cli.main import cli, main

__all__ = ["main", "cli"]
