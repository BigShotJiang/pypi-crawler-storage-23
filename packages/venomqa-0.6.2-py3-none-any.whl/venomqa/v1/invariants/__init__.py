"""Built-in invariant helpers for VenomQA."""

from venomqa.v1.invariants.openapi import OpenAPISchemaInvariant

__all__ = ["OpenAPISchemaInvariant"]
