"""Checkpoint - re-exports from sandbox context.

DEPRECATED: Import from venomqa.sandbox instead.
"""

from venomqa.sandbox.checkpoint import Checkpoint, SystemCheckpoint

__all__ = ["Checkpoint", "SystemCheckpoint"]
