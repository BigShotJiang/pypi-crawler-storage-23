"""Graph - re-exports from exploration context.

DEPRECATED: Import from venomqa.exploration instead.
"""

from venomqa.exploration.graph import Graph

__all__ = ["Graph"]
