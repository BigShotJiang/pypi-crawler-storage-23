"""Transition - re-exports from exploration context.

DEPRECATED: Import from venomqa.exploration instead.
"""

from venomqa.exploration.transition import Transition

__all__ = ["Transition"]
