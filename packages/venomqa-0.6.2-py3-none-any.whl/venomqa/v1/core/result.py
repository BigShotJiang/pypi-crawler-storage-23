"""ExplorationResult - re-exports from exploration context.

DEPRECATED: Import from venomqa.exploration instead.
"""

from venomqa.exploration.result import ExplorationResult

__all__ = ["ExplorationResult"]
