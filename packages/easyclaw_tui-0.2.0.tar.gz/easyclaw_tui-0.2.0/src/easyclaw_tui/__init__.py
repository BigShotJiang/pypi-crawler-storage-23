"""EasyClaw — AI Agent for OpenClaw."""

__version__ = "0.2.0"
