"""Abstract base class for all analyzers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from sentinel.models.findings import Finding, ScanResult, ScanStats


class BaseAnalyzer(ABC):
    """Processes raw collected data and produces typed findings."""

    module_name: str = "base"

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path

    @abstractmethod
    def analyze(self, collected: dict[str, Any]) -> ScanResult:
        """
        Analyze raw collected data and return a ScanResult.
        collected: the dict returned by the matching collector.
        """

    def _make_result(
        self,
        findings: list[Finding],
        stats: ScanStats | None = None,
        errors: list[str] | None = None,
    ) -> ScanResult:
        return ScanResult(
            module=self.module_name,
            target_path=str(self.repo_path),
            findings=findings,
            stats=stats or ScanStats(findings_count=len(findings)),
            errors=errors or [],
        )
