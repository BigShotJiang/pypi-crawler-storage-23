"""CI/CD Collector — gathers raw pipeline data from the repository."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sentinel.collectors.base import BaseCollector
from sentinel.collectors.cicd.parsers.gitlab_ci import GitLabCIParser
from sentinel.models.config import CicdConfig


class CicdCollector(BaseCollector):
    module_name = "cicd"

    def __init__(self, repo_path: Path, config: CicdConfig) -> None:
        super().__init__(repo_path)
        self.config = config

    def collect(self) -> dict[str, Any]:
        parser = GitLabCIParser(self.repo_path, deep_include=self.config.deep_include)
        data = parser.parse()
        data["required_stages"] = self.config.required_stages
        data["trusted_remote_domains"] = self.config.trusted_remote_domains
        return data
