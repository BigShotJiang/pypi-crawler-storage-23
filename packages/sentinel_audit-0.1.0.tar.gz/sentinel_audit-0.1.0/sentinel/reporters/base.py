"""Abstract base class for all reporters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from sentinel.models.findings import AggregatedReport


class BaseReporter(ABC):
    """Renders an AggregatedReport into a specific output format."""

    format_name: str = "base"
    file_extension: str = ".txt"

    def render(self, report: AggregatedReport, output_dir: Path) -> Path:
        """Render the report and write to output_dir. Returns the output path."""
        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / self._filename(report)
        self._write(report, out_path)
        return out_path

    def _filename(self, report: AggregatedReport) -> str:
        safe_client = report.client_name.lower().replace(" ", "-")
        date = report.engagement_date or report.generated_at[:10]
        return f"sentinel-{safe_client}-{date}{self.file_extension}"

    @abstractmethod
    def _write(self, report: AggregatedReport, path: Path) -> None:
        """Write the rendered content to path."""
