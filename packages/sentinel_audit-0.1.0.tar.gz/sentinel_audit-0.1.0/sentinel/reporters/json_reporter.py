"""JSON reporter — aggregated machine-readable findings output."""

from __future__ import annotations

import json
from pathlib import Path

from sentinel.models.findings import AggregatedReport
from sentinel.reporters.base import BaseReporter


class JsonReporter(BaseReporter):
    format_name = "json"
    file_extension = ".json"

    def _write(self, report: AggregatedReport, path: Path) -> None:
        path.write_text(
            json.dumps(report.model_dump(), indent=2, default=str),
            encoding="utf-8",
        )
