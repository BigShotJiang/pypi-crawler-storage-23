"""Markdown reporter — GitLab-friendly human-readable output."""

from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from sentinel.analyzers.compliance.mapper import (
    owasp_cicd_table,
    remediation_roadmap,
    soc2_gap_table,
)
from sentinel.models.findings import AggregatedReport
from sentinel.reporters.base import BaseReporter

_TEMPLATES_DIR = Path(__file__).parent / "templates"


class MarkdownReporter(BaseReporter):
    format_name = "markdown"
    file_extension = ".md"

    def _write(self, report: AggregatedReport, path: Path) -> None:
        env = Environment(
            loader=FileSystemLoader(str(_TEMPLATES_DIR)),
            autoescape=select_autoescape([]),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        env.filters["enumerate"] = enumerate
        template = env.get_template("report.md.j2")
        content = template.render(
            report=report,
            soc2_table=soc2_gap_table(report),
            owasp_table=owasp_cicd_table(report),
            roadmap=remediation_roadmap(report),
        )
        path.write_text(content, encoding="utf-8")
