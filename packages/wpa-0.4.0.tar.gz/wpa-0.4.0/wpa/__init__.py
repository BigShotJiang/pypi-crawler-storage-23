"""WordPress Automation — publish markdown files as WordPress pages."""

__version__ = "0.4.0"
