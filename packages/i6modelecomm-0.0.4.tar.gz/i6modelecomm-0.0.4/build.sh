#!/bin/bash -xe

eval "$(i6dev meta debug i6infra-build I6DEV_DEBUG)"


function cmd_encrypt() {
    i6dev secret enc-all src
}

function cmd_decrypt() {
    i6dev secret dec-all src
}

function cmd_dist() {
  [ ! -d dist ] || rm -rf dist
  i6dev python dist
}

function cmd_toarmor() {
    # pyarmor cfg pack:bootstrap="."
    pyarmor gen --assert-call -O ./i6modelecomm/model --platform windows.x86_64,linux.x86_64,darwin.x86_64,darwin.arm64 ./src/i6modelecomm.secret.py
    #mv ./i6modelecomm//model/i6modelecomm.secret.py ./i6modelecomm//model/i6modelecomm.py
}

function cmd_upload_test_pypi() {
    i6dev python auth-install
    source src/env.test.secret.sh
    twine upload --repository testpypi dist/*
}

function cmd_upload_prod_pypi() {
    i6dev python auth-install
    export TWINE_USERNAME="__token__" 
    export TWINE_PASSWORD="$(cat "$HOME/.ssh/prod.pypi.key")"
    twine upload --repository pypi dist/*
}

cd "$(dirname "$0")"; _cmd="${1?"cmd is required"}"; shift; "cmd_${_cmd}" "$@"

