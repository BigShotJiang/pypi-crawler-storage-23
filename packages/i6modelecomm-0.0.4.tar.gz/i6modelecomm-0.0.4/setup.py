import glob

from setuptools import setup, find_packages

from i6modelecomm.version import VERSION

def parse_requirements(profile : str = None):
    name = f'requirements-{profile}.txt' if profile else 'requirements.txt'
    with open(name) as f:
        return f.read().splitlines()
        
def parse_extra_requirements():
    files = glob.glob("requirements-*.txt")
    ret = {}
    for file in files:
        name = file.split('-')[1]
        name = name.split('.')[0]
        ret[name] = parse_requirements(name)
    return ret


def readme():
    with open('README.md', 'r') as f:
        return f.read()

setup(
    name="i6modelecomm",
    version=VERSION,
    author="i6",
    author_email="recsys-devs@infinity6.ai",
    description="Infinity6 Model Ecomm",
    long_description=readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/infinity6-ai/i6data-ems.git",
    packages=find_packages(exclude=["i6modelecomm.test", "i6modelecomm.test.*", "src.*"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=parse_requirements(),
    extras_require=parse_extra_requirements(),
    include_package_data=True,  # Include non-code files specified in MANIFEST.in
    entry_points={
        'console_scripts': [
            # Define command-line scripts here, e.g.:
            # 'your-command=your_module:main',
        ],
    },
)


