from i6modelecomm.model import i6modelecomm

CommerceIntent = i6modelecomm.CommerceIntent
CommerceIntentConfig = i6modelecomm.CommerceIntentConfig

# print(dir(i6modelecomm))
