#!/usr/bin/python
# coding: utf-8
from searxng_mcp.mcp import searxng_mcp

if __name__ == "__main__":
    searxng_mcp()
