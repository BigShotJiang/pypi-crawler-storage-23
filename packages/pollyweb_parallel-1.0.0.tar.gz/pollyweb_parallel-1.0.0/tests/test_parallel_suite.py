import shutil

from PW_PARALLEL.TEST_PARALLEL import TEST_PARALLEL


def test_namespace_imports():
    import pollyweb
    import pollyweb.parallel as parallel_mod
    import pollyweb.utils as utils_mod

    assert hasattr(pollyweb, "parallel")
    assert hasattr(pollyweb, "utils")
    assert parallel_mod.PARALLEL_PROCESS_POOL is not None
    assert parallel_mod.PARALLEL_THREAD_POOL is not None
    assert hasattr(utils_mod, "LOG")


def test_namespace_from_imports():
    from pollyweb import parallel, utils

    assert parallel.PARALLEL_PROCESS_POOL is not None
    assert parallel.PARALLEL_THREAD_POOL is not None
    assert hasattr(utils, "LOG")


def test_namespace_top_level_parallel_imports():
    import pollyweb
    from pollyweb import PARALLEL_PROCESS_POOL, PARALLEL_THREAD_POOL

    assert PARALLEL_PROCESS_POOL is not None
    assert PARALLEL_THREAD_POOL is not None
    assert pollyweb.PARALLEL_PROCESS_POOL is PARALLEL_PROCESS_POOL
    assert pollyweb.PARALLEL_THREAD_POOL is PARALLEL_THREAD_POOL


def test_parallel_suite():
    shutil.rmtree('__dumps__/PARALLEL', ignore_errors=True)
    TEST_PARALLEL.TestParallel()
