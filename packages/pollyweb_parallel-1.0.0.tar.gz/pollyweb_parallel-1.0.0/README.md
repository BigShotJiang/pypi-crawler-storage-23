# PollyWeb Parallel

Parallel processing helpers for PollyWeb.

## Installation

```bash
pip install pollyweb-parallel
```

## Imports

Preferred namespace imports:

```python
from pollyweb import PARALLEL_PROCESS_POOL, utils

pool = PARALLEL_PROCESS_POOL("demo")
utils.LOG.INFO("Pool ready")
```

Alternative import style:

```python
from pollyweb import parallel, utils

pool = parallel.PARALLEL_PROCESS_POOL("demo")
utils.LOG.INFO("Pool ready")
```

## Documentation

- [Docs Home](docs/README.md)
- [Quick Start](docs/quick-start.md)
- [Class Reference](docs/classes/README.md)
