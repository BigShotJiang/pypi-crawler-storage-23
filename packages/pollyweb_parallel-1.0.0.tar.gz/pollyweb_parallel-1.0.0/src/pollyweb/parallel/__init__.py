"""PollyWeb parallel helpers.

This package is a compatibility bridge to the existing ``PW_PARALLEL`` package.
"""

from PW_PARALLEL import PARALLEL_PROCESS_POOL
from PW_PARALLEL import PARALLEL_THREAD_POOL

__all__ = [
    "PARALLEL_PROCESS_POOL",
    "PARALLEL_THREAD_POOL",
]
