"""PollyWeb utils compatibility module.

This exposes ``PW_UTILS`` through ``pollyweb.utils``.
"""

import PW_UTILS as _pw_utils


def __getattr__(name: str):
    return getattr(_pw_utils, name)


def __dir__():
    return sorted(set(globals().keys()) | set(dir(_pw_utils)))


__all__ = getattr(_pw_utils, "__all__", [])
