"""PollyWeb namespace package.

Importing ``pollyweb`` gives access to lazy-loaded subpackages:
- ``pollyweb.parallel``
- ``pollyweb.utils``

It also re-exports common parallel helpers directly:
- ``pollyweb.PARALLEL_PROCESS_POOL``
- ``pollyweb.PARALLEL_THREAD_POOL``
"""

from importlib import import_module

__all__ = [
    "parallel",
    "utils",
    "PARALLEL_PROCESS_POOL",
    "PARALLEL_THREAD_POOL",
]


def __getattr__(name: str):
    if name in __all__:
        if name in {"PARALLEL_PROCESS_POOL", "PARALLEL_THREAD_POOL"}:
            parallel_mod = import_module(f"{__name__}.parallel")
            return getattr(parallel_mod, name)
        return import_module(f"{__name__}.{name}")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals().keys()) | set(__all__))
