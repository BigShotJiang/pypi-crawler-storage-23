# django PID


## django_pid: Extensible PID Pool Management for Django

`django_pid` is a Django app for managing persistent identifiers (PIDs) such as Handle, DOI, ARK, and more. It provides:

- **PID pool management**: Pre-registers and reserves PIDs, ensuring a ready supply for assignment to resources.
- **Server abstraction**: Supports multiple PID server types via a flexible factory pattern.
- **Asynchronous operations**: Uses Celery tasks for pool replenishment, health checks, and retry logic.

### Key Features

- **Extensible PIDService Factories**: Easily add support for new PID systems by registering custom service builders (see `object_factory.py`). The default implementation uses the PID4Cat Handle server, but you can plug in other PID services by implementing and registering a compatible factory.
- **Robust pool lifecycle**: Handles server outages gracefully, with local handle generation and exponential back-off retries.
- **Django ORM integration**: Models for PID servers, types, and pool entries, with custom managers for pool logic.

### Installation

This project uses [`uv`](https://github.com/astral-sh/uv) as the default Python package manager and runtime. Do **not** use `pip` directly.

```sh
uv sync  # Install all dependencies from pyproject.toml
```

For development tools and formatting:

```sh
uv run ruff check --fix .
uv run ruff format .
```

### Usage

Add `django_pid` to your Django `INSTALLED_APPS` and migrate:

```bash
python manage.py makemigrations django_pid
python manage.py migrate
```

Configure PID servers and types via the Django admin or fixtures. The app will maintain PID pools and handle assignment automatically.

### Extending with Custom PID Services

To support additional PID systems, implement a service class with the required interface (see `pid_service_builders/pid4cat.py`) and register it in the object factory (`object_factory.py`). This allows seamless integration of new PID backends without modifying core logic.

### Project Structure

- `src/django_pid/models.py`: ORM models for servers, types, and PIDs
- `src/django_pid/tasks.py`: Celery tasks for pool management
- `src/django_pid/object_factory.py`: Generic factory for service builders
- `src/django_pid/pid_service_builders/`: Service implementations (default: PID4Cat)

### License

See LICENSE for details.

## Features

## Installation

    pip install django_pid --index-url https://gitlab.com/api/v4/projects/<gitlab-project-id>/packages/pypi/simple

## Usage

    django_pid --help 

## Development

    git clone gitlab.com/opensourcelab/django-pid

    # create a virtual environment and activate it then run

    pip install -e .[dev]

    # run unittests

    invoke test   # use the invoke environment to manage development
    

## Documentation

The Documentation can be found here: [https://opensourcelab.gitlab.io/django-pid](https://opensourcelab.gitlab.io/django-pid) or [django-pid.gitlab.io](django_pid.gitlab.io/)


## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter)
 and the [gitlab.com/opensourcelab/software-dev/cookiecutter-pypackage](https://gitlab.com/opensourcelab/software-dev/cookiecutter-pypackage) project template.



