"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*django_pid admin *

:details: django_pid admin module admin backend configuration.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator django_pid >> admin.py" to update this file
________________________________________________________________________
"""

from django.contrib import admin
from .models import PIDServer, PIDType, PID


@admin.register(PIDServer)
class PIDServerAdmin(admin.ModelAdmin):
    """Admin configuration for PIDServer model."""

    list_display = ("name", "server_url", "prefix", "pool_min_size", "pool_target_size")
    search_fields = ("name", "server_url", "prefix")
    list_filter = ("prefix",)


@admin.register(PIDType)
class PIDTypeAdmin(admin.ModelAdmin):
    """Admin configuration for PIDType model."""

    list_display = ("name", "description")
    search_fields = ("name",)


@admin.register(PID)
class PIDAdmin(admin.ModelAdmin):
    """Admin configuration for PID model."""

    list_display = (
        "handle",
        "pid",
        "pid_type",
        "pid_server",
        "visible",
        "reserved",
        "registered",
        "created_at",
        "updated_at",
    )
    search_fields = ("handle", "pid")
    list_filter = ("visible", "reserved", "registered", "pid_server", "pid_type")
