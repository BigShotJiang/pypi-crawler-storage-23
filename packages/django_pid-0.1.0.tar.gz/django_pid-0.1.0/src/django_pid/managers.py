"""Custom query managers for django_pid models."""

import logging

from django.db import models, transaction
from django.utils import timezone

logger = logging.getLogger(__name__)


class PIDManager(models.Manager):
    """Manager for the PID pool model providing atomic reservation and flush helpers."""

    def get_next_available_pid(self, pid_server_id: str) -> "PID | None":  # noqa: F821
        """
        Atomically reserve and return the next available pool PID for a server.

        Only returns handles that are both registered at the server
        (``registered=True``) and not yet reserved.  Locally-generated
        pending handles (``registered=False``) are excluded.

        Args:
            pid_server_id: UUID (str) of the target :class:`~django_pid.models.PIDServer`.

        Returns:
            The reserved :class:`~django_pid.models.PID` instance, or ``None``
            when the pool is empty.

        """
        logger.info("Reserving next available PID for server %s", pid_server_id)
        with transaction.atomic():
            pid_obj = (
                self.select_for_update(skip_locked=True)
                .filter(pid_server_id=pid_server_id, reserved=False, registered=True)
                .order_by("created_at")
                .first()
            )
            if pid_obj is not None:
                pid_obj.reserved = True
                pid_obj.save(update_fields=["reserved", "updated_at"])
        return pid_obj

    def count_available(self, pid_server_id: str) -> int:
        """
        Return the number of unreserved, registered PIDs in the pool.

        Args:
            pid_server_id: UUID (str) of the :class:`~django_pid.models.PIDServer`.

        Returns:
            Number of available (unreserved, registered) PIDs.

        """
        return self.filter(pid_server_id=pid_server_id, reserved=False, registered=True).count()

    def count_pending(self, pid_server_id: str) -> int:
        """
        Return the number of locally-generated handles awaiting server registration.

        Args:
            pid_server_id: UUID (str) of the :class:`~django_pid.models.PIDServer`.

        Returns:
            Number of pending (not yet registered) pool handles.

        """
        return self.filter(pid_server_id=pid_server_id, reserved=False, registered=False).count()

    def get_pending_handles(self, pid_server_id: str, limit: int = 200) -> models.QuerySet:
        """
        Return pending handles whose retry time has passed (or is unset).

        These are locally-generated handles that should be flushed to the
        server by :func:`~django_pid.tasks.flush_pending_pool`.

        Args:
            pid_server_id: UUID (str) of the :class:`~django_pid.models.PIDServer`.
            limit: Maximum number of rows to return per flush batch.

        Returns:
            QuerySet of :class:`~django_pid.models.PID` instances ready for flush.

        """
        now = timezone.now()
        return (
            self.filter(
                pid_server_id=pid_server_id,
                reserved=False,
                registered=False,
            )
            .filter(models.Q(registration_retry_after__isnull=True) | models.Q(registration_retry_after__lte=now))
            .order_by("created_at")[:limit]
        )

    def needs_replenishment(self, pid_server_id: str) -> bool:
        """
        Return ``True`` when the available pool is below the server's configured minimum.

        Args:
            pid_server_id: UUID (str) of the :class:`~django_pid.models.PIDServer`.

        Returns:
            ``True`` if replenishment is needed, ``False`` otherwise.

        """
        from django_pid.models import PIDServer

        try:
            server = PIDServer.objects.get(pk=pid_server_id)
        except PIDServer.DoesNotExist:
            logger.warning("PIDServer %s not found - skipping replenishment check", pid_server_id)
            return False
        available = self.count_available(pid_server_id)
        needs = available < server.pool_min_size
        if needs:
            logger.info(
                "PID pool for server %s is low: %d available, minimum is %d",
                pid_server_id,
                available,
                server.pool_min_size,
            )
        return needs

    def missing_count(self, pid_server_id: str) -> int:
        """
        Return how many PIDs need to be created to reach *pool_target_size*.

        Args:
            pid_server_id: UUID (str) of the :class:`~django_pid.models.PIDServer`.

        Returns:
            Number of PIDs to create (0 when pool is already at or above target).

        """
        from django_pid.models import PIDServer

        try:
            server = PIDServer.objects.get(pk=pid_server_id)
        except PIDServer.DoesNotExist:
            return 0
        available = self.count_available(pid_server_id)
        return max(0, server.pool_target_size - available)
