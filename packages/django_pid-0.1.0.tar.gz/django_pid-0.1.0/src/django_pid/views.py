"""
_____________________________________________________________________

:PROJECT: LARAsuite

*django_pid views *

:details: django_pid views module.
         - add app specific urls here
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from dataclasses import dataclass, field

# from .forms import
# from .tables import

# Create your  django_pid views here.


@dataclass
class ItemMenu:
    menu_items:  list[dict] = field(default_factory=lambda: [
        {'name': 'item1',
         'path': 'django_pid:view1-name'},
        {'name': 'item2',
         'path': 'django_pid:view2-name'},
    ])
