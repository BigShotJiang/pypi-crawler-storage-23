"""Django signals for django_pid.

Listens for PID reservation events and triggers asynchronous pool
replenishment when the available pool drops below the configured minimum.
"""

import logging

from django.db.models.signals import post_save
from django.dispatch import receiver

logger = logging.getLogger(__name__)


def _register_signals() -> None:
    """Register all django_pid signals.

    Called from :meth:`~django_pid.apps.djangoPIDConfig.ready` so that
    signal handlers are only connected after the app is fully loaded.
    """
    # Import here to avoid AppRegistryNotReady errors.
    from django_pid.models import PID  # noqa: PLC0415 – deferred import

    @receiver(post_save, sender=PID, dispatch_uid="django_pid.signals.pid_reserved_check_pool")
    def pid_reserved_check_pool(
        sender: type,  # noqa: ARG001
        instance: PID,
        created: bool,  # noqa: ARG001
        update_fields: frozenset | None,
        **kwargs: object,
    ) -> None:
        """Trigger an async pool replenishment check when a PID is reserved.

        Args:
            sender: The :class:`~django_pid.models.PID` model class (unused).
            instance: The saved :class:`~django_pid.models.PID` instance.
            created: Whether this is a new record (unused).
            update_fields: Set of field names that were updated.
            **kwargs: Additional signal keyword arguments (unused).
        """
        # Only react when the ``reserved`` field changes to True.
        reserved_changed = update_fields is None or "reserved" in update_fields
        if not (instance.reserved and reserved_changed):
            return

        if instance.pid_server_id is None:
            logger.debug("PID %s has no server - skipping pool check", instance.pid_id)
            return

        logger.debug(
            "PID %s reserved - scheduling pool check for server %s",
            instance.pid_id,
            instance.pid_server_id,
        )
        # Import task lazily to avoid circular imports at module load time.
        try:
            from django_pid.tasks import check_pool_for_server  # noqa: PLC0415

            check_pool_for_server.delay(str(instance.pid_server_id))
        except Exception:  # noqa: BLE001
            logger.exception(
                "Failed to schedule pool check for server %s after reserving PID %s",
                instance.pid_server_id,
                instance.pid_id,
            )