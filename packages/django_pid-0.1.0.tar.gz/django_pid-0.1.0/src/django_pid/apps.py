"""django_pid app configuration and PID service factory."""

from django.apps import AppConfig

from django_pid.object_factory import ObjectFactory
from django_pid.pid_service_builders.pid4cat import PID4CatServiceBuilder


class PIDService(ObjectFactory):
    """PIDService is a factory for PID service builders."""

    def get(self, service_id: str, **kwargs: object) -> object:
        """
        Return a PID service instance for *service_id*.

        Args:
            service_id: Registered service key (e.g. ``"pid4cat"``).
            **kwargs: Forwarded to the builder callable.

        Returns:
            The service instance produced by the registered builder.

        """
        return self.create(service_id.strip().lower(), **kwargs)


class djangoPIDConfig(AppConfig):
    """AppConfig for the django_pid application."""

    name = "django_pid"
    verbose_name = "django-pid"

    pid_service = PIDService()
    pid_service.register_builder("pid4cat", PID4CatServiceBuilder())

    def ready(self) -> None:
        """Register signal handlers after the app registry is populated."""
        from django_pid.signals import _register_signals

        _register_signals()
