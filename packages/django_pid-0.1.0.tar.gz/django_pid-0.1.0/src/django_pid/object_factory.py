# generic object factory from https://realpython.com/factory-method-python/

class ObjectFactory:
    def __init__(self):
        self._builders = {}

    def register_builder(self, key, builder):
        self._builders[key] = builder

    def create(self, key, **kwargs):
        builder = self._builders.get(key)
        if not builder:
            raise ValueError(key)
        return builder(**kwargs)

    def list(self) -> list:
        """Return a list of registered builders"""
        return self._builders.keys()

    def has(self, key) -> bool:
        """Check if key is in registered builders, return True or False"""
        return key in self._builders.keys()
