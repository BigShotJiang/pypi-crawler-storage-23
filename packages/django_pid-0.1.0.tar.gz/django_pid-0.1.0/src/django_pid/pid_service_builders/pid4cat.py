"""
PID4Cat handle-server service and builder.

The :class:`PID4CatService` wraps the PyHandle REST client and provides the
operations needed to manage a pre-registered PID pool on a Handle System
server used by the PID4Cat infrastructure.

Expected ``PIDServer.connection_parameters`` JSON structure::

    {
        "username":    "300:prefix/ADMIN",
        "password":    "s3cr3t",
        "handleowner": "200:prefix/ADMIN"   // optional, defaults derived from prefix
    }

The ``PIDServer.server_url`` and ``PIDServer.prefix`` fields are used directly.

Fallback behaviour
~~~~~~~~~~~~~~~~~~
When the handle server is unavailable, :meth:`pre_register_handles_bulk` falls
back to *local generation*: handles are assigned a UUID-based suffix immediately
and saved to the database with ``registered=False``.  The
:func:`~django_pid.tasks.flush_pending_pool` Celery task periodically retries
registering these pending handles on the live server.
"""

import logging
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import httpx
from django.conf import settings
from django.utils import timezone

if TYPE_CHECKING:
    from django_pid.models import PID, PIDServer

from pyhandle.clientcredentials import PIDClientCredentials
from pyhandle.handleclient import PyHandleClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default settings (can be overridden per-server via PIDServer.pool_min_size)
# ---------------------------------------------------------------------------
_DEFAULT_POOL_MIN_SIZE: int = getattr(settings, "PID4CAT_POOL_MIN_SIZE", 10)
_DEFAULT_POOL_TARGET_SIZE: int = getattr(settings, "PID4CAT_POOL_TARGET_SIZE", 50)
_AVAILABILITY_TIMEOUT: float = getattr(settings, "PID4CAT_AVAILABILITY_TIMEOUT", 5.0)
# Back-off intervals (seconds) applied to pending handles after each failed flush attempt.
_RETRY_BACKOFF_SCHEDULE: tuple[int, ...] = getattr(
    settings,
    "PID4CAT_RETRY_BACKOFF_SCHEDULE",
    (60, 300, 900, 3600, 21600),  # 1 min, 5 min, 15 min, 1 h, 6 h
)


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------


@dataclass
class BulkRegistrationResult:
    """
    Result returned by :meth:`PID4CatService.pre_register_handles_bulk`.

    Attributes:
        registered: Handles confirmed by the server (``registered=True`` in DB).
        pending: Handles generated locally while the server was unreachable
            (``registered=False`` in DB, to be flushed later).
        server_available: Whether the server was reachable during this operation.

    """

    registered: list[str] = field(default_factory=list)
    pending: list[str] = field(default_factory=list)
    server_available: bool = True

    @property
    def total(self) -> int:
        """
        Total number of handles produced (registered + pending).

        Returns:
            Combined count of registered and pending handles.

        """
        return len(self.registered) + len(self.pending)


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


class PID4CatServiceBuilder:
    """
    Factory builder registered in the :class:`~django_pid.apps.PIDService` factory.

    This builder is intentionally lightweight; the heavy handle-client
    initialisation happens lazily inside :class:`PID4CatService`.
    """

    def __call__(self, pid_server: "PIDServer", **kwargs: object) -> "PID4CatService":
        """
        Instantiate a :class:`PID4CatService` for the given server.

        Args:
            pid_server: A :class:`~django_pid.models.PIDServer` instance that
                carries the connection parameters for the Handle server.
            **kwargs: Ignored - present for forward-compatibility.

        Returns:
            A configured :class:`PID4CatService`.

        """
        return PID4CatService(pid_server=pid_server)


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class PID4CatService:
    """
    High-level interface for managing PIDs on a PID4Cat Handle server.

    Responsibilities:

    * Check server availability.
    * Pre-register new (empty) handles in bulk to fill the pool.
    * Fall back to local handle generation when the server is unreachable.
    * Flush locally-generated (pending) handles once the server is reachable.
    * Register a pooled handle for active use (set target URL + metadata).
    * Change handle visibility (hide/show).
    * Delete a handle from the server.
    * Retrieve a handle record for inspection.

    The underlying :class:`~pyhandle.handleclient.PyHandleClient` is
    initialised lazily on first use so that the builder can be created
    cheaply.
    """

    def __init__(self, pid_server: "PIDServer") -> None:
        """
        Initialise the service with a :class:`~django_pid.models.PIDServer`.

        Args:
            pid_server: ORM instance carrying ``server_url``, ``prefix``,
                and ``connection_parameters``.

        """
        self.pid_server = pid_server
        self.prefix: str = pid_server.prefix or ""
        self._client: PyHandleClient | None = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def client(self) -> PyHandleClient:
        """
        Return (and lazily create) the authenticated PyHandle REST client.

        Returns:
            An authenticated :class:`~pyhandle.handleclient.PyHandleClient`.

        Raises:
            ValueError: When required connection parameters are missing.

        """
        if self._client is None:
            self._client = self._build_client()
        return self._client

    def _build_client(self) -> PyHandleClient:
        """
        Build and authenticate a PyHandle REST client.

        Returns:
            An authenticated client ready for use.

        Raises:
            ValueError: When ``server_url``, ``prefix``, or credentials are absent.

        """
        params: dict = self.pid_server.connection_parameters or {}
        server_url: str = self.pid_server.server_url or params.get("handle_server_url", "")
        username: str = params.get("username", "")
        password: str = params.get("password", "")
        handleowner: str = params.get("handleowner", f"200:{self.prefix}/ADMIN")

        if not server_url:
            raise ValueError("PIDServer.server_url is required for PID4CatService")
        if not self.prefix:
            raise ValueError("PIDServer.prefix is required for PID4CatService")
        if not username or not password:
            raise ValueError(
                "PIDServer.connection_parameters must contain 'username' and 'password' for PID4CatService"
            )

        logger.debug("Building PyHandle client for server %s (prefix=%s)", server_url, self.prefix)

        creds = PIDClientCredentials(
            store_uri=server_url,
            username=username,
            password=password,
            handleowner=handleowner,
            prefix=self.prefix,
        )
        return PyHandleClient("rest").instantiate_with_credentials(creds)

    @staticmethod
    def _make_suffix() -> str:
        """
        Return a random UUID-based handle suffix (lowercase, no hyphens).

        Returns:
            A 32-character hex string usable as a handle suffix.

        """
        return uuid.uuid4().hex

    def _placeholder_url(self) -> str:
        """
        Return the placeholder URL used for pool handles.

        Returns:
            Placeholder URL string from settings or the PID4Cat default.

        """
        return getattr(settings, "PID4CAT_POOL_PLACEHOLDER_URL", "https://pid4cat.de/pool/unassigned")

    # ------------------------------------------------------------------
    # Availability check
    # ------------------------------------------------------------------

    def is_available(self, timeout: float = _AVAILABILITY_TIMEOUT) -> bool:
        """
        Probe the handle server with a lightweight HTTP request.

        Sends a ``GET`` to the server's API endpoint and treats any 2xx/3xx/4xx
        response as *available* (the server is up, authentication issues are
        separate concerns).  Only network-level errors (connection refused,
        DNS failure, timeout) are treated as *unavailable*.

        Args:
            timeout: HTTP timeout in seconds (default from
                ``PID4CAT_AVAILABILITY_TIMEOUT`` setting or 5.0).

        Returns:
            ``True`` if the server responded, ``False`` on network error.

        """
        probe_url = self.pid_server.server_url or ""
        if not probe_url:
            logger.warning("PIDServer %s has no server_url - marking as unavailable", self.pid_server.name)
            return False
        try:
            response = httpx.get(probe_url, timeout=timeout, follow_redirects=True)
            logger.debug("Handle server %s probe: HTTP %s", probe_url, response.status_code)
            return True  # any HTTP response means the server is up
        except httpx.ConnectError:
            logger.warning("Handle server %s is unreachable (connection refused/DNS failure)", probe_url)
        except httpx.TimeoutException:
            logger.warning("Handle server %s timed out after %.1f s", probe_url, timeout)
        except httpx.RequestError as exc:
            logger.warning("Handle server %s probe failed: %s", probe_url, exc)
        return False

    # ------------------------------------------------------------------
    # Pool pre-registration (with offline fallback)
    # ------------------------------------------------------------------

    def pre_register_handle(self, suffix: str | None = None) -> str:
        """
        Create an empty (pool) handle on the server with a placeholder URL.

        The handle is registered so it is syntactically valid on the server.
        The placeholder URL is intentionally non-resolvable so pool handles do
        not accidentally resolve until they are activated via :meth:`register_pid`.

        Args:
            suffix: Optional fixed suffix.  When ``None`` a random UUID-based
                suffix is generated.

        Returns:
            The full handle string, e.g. ``"21.T11148/abc123def456..."``.

        Raises:
            Exception: Propagated from PyHandle on server-side errors.

        """
        suffix = suffix or self._make_suffix()
        handle = f"{self.prefix}/{suffix}"
        logger.info("Pre-registering handle %s with placeholder URL", handle)
        result: str = self.client.register_handle(handle, self._placeholder_url())
        logger.debug("Pre-registered handle: %s", result)
        return result

    def _generate_handle_locally(self, suffix: str | None = None) -> str:
        """
        Generate a handle string locally without contacting the server.

        The handle has the correct prefix and a UUID suffix but has *not* been
        registered at the Handle server yet.  It will be registered later by
        :meth:`flush_pending_handles`.

        Args:
            suffix: Optional fixed suffix; auto-generated when ``None``.

        Returns:
            A locally-generated full handle string.

        """
        suffix = suffix or self._make_suffix()
        return f"{self.prefix}/{suffix}"

    def pre_register_handles_bulk(self, count: int) -> BulkRegistrationResult:
        """
        Pre-register *count* handles, falling back to local generation if the server is down.

        The method first probes the server via :meth:`is_available`.  If the server
        is reachable, handles are registered normally.  When the server is
        unreachable, all handles are generated locally and saved as pending
        (``registered=False``) to be flushed later by
        :func:`~django_pid.tasks.flush_pending_pool`.

        If the server is available but individual registration calls fail (e.g.
        transient errors), those handles fall back to local generation as well.

        Args:
            count: Number of handles to create.

        Returns:
            A :class:`BulkRegistrationResult` with separate lists for
            server-confirmed and locally-generated handles.

        """
        logger.info("Bulk pre-registering %d handles for prefix %s", count, self.prefix)
        result = BulkRegistrationResult()

        if not self.is_available():
            result.server_available = False
            logger.warning(
                "Handle server for prefix %s is unavailable - generating %d handles locally",
                self.prefix,
                count,
            )
            result.pending = [self._generate_handle_locally() for _ in range(count)]
            return result

        for _ in range(count):
            try:
                handle = self.pre_register_handle()
                result.registered.append(handle)
            except Exception:
                logger.exception("Failed to pre-register handle at server - falling back to local generation")
                result.pending.append(self._generate_handle_locally())

        logger.info(
            "Bulk registration complete: %d registered, %d pending (local fallback)",
            len(result.registered),
            len(result.pending),
        )
        return result

    # ------------------------------------------------------------------
    # Pending-handle flush (retry registration for locally-generated handles)
    # ------------------------------------------------------------------

    def flush_pending_handles(self, handles: list[str]) -> BulkRegistrationResult:
        """
        Attempt to register locally-generated (pending) handles at the server.

        Called by :func:`~django_pid.tasks.flush_pending_pool` when the server
        becomes available again.  Handles that fail are returned in
        ``result.pending`` so the caller can apply back-off and reschedule.

        Args:
            handles: List of locally-generated handle strings to register.

        Returns:
            A :class:`BulkRegistrationResult` where ``registered`` contains
            handles that were successfully registered this time and ``pending``
            contains those that still failed.

        """
        result = BulkRegistrationResult()

        if not handles:
            return result

        if not self.is_available():
            result.server_available = False
            result.pending = list(handles)
            logger.warning("Server still unavailable - %d pending handles remain unregistered", len(handles))
            return result

        placeholder = self._placeholder_url()
        for handle in handles:
            try:
                self.client.register_handle(handle, placeholder)
                result.registered.append(handle)
                logger.debug("Flushed pending handle: %s", handle)
            except Exception:
                logger.exception("Failed to flush pending handle %s", handle)
                result.pending.append(handle)

        logger.info(
            "Flush complete: %d registered, %d still pending",
            len(result.registered),
            len(result.pending),
        )
        return result

    # ------------------------------------------------------------------
    # Active PID operations
    # ------------------------------------------------------------------

    def register_pid(self, handle: str, target_url: str, metadata: dict | None = None) -> None:
        """
        Activate a pooled handle by setting its target URL and optional metadata.

        This corresponds to the moment a resource is assigned a PID.  After
        calling this method the handle resolves to *target_url*.

        Args:
            handle: Full handle string, e.g. ``"21.T11148/abc123"``.
            target_url: The URL the handle should resolve to.
            metadata: Optional additional key-value pairs to store on the handle
                record (e.g. ``{"TITLE": "My dataset"}``).

        """
        updates: dict[str, str] = {"URL": target_url}
        if metadata:
            updates.update({k: str(v) for k, v in metadata.items()})
        logger.info("Registering handle %s -> %s", handle, target_url)
        self.client.modify_handle_value(handle, **updates)

    def change_visibility(self, handle: str, visible: bool) -> None:
        """
        Show or hide a handle on the server.

        Hiding is implemented by removing the ``URL`` index value so the handle
        no longer resolves.  Showing restores the URL from the database record.

        Args:
            handle: Full handle string.
            visible: ``True`` to make the handle resolvable, ``False`` to hide it.

        """
        if visible:
            logger.info("Making handle %s visible - target URL must be re-set by caller", handle)
        else:
            logger.info("Hiding handle %s (removing URL value)", handle)
            try:
                self.client.delete_handle_value(handle, "URL")
            except Exception:
                logger.exception("Failed to hide handle %s", handle)

    def delete_pid(self, handle: str) -> None:
        """
        Permanently delete a handle from the server.

        Note:
            Some Handle System operators do not allow deletion; in that case
            prefer :meth:`change_visibility` to hide the handle instead.

        Args:
            handle: Full handle string to delete.

        """
        logger.info("Deleting handle %s", handle)
        self.client.delete_handle(handle)

    def retrieve_handle_record(self, handle: str) -> dict:
        """
        Fetch the full handle record from the server.

        Args:
            handle: Full handle string.

        Returns:
            Dictionary of handle values keyed by index or type name.

        """
        logger.debug("Retrieving handle record for %s", handle)
        return self.client.retrieve_handle_record(handle)

    # ------------------------------------------------------------------
    # ORM integration helpers
    # ------------------------------------------------------------------

    def save_pre_registered_pids_to_db(
        self,
        handles: list[str],
        pid_type_id: str | None = None,
        registered: bool = True,
        retry_after: "timezone.datetime | None" = None,
    ) -> list["PID"]:
        """
        Persist handle strings as :class:`~django_pid.models.PID` pool entries.

        Args:
            handles: List of handle strings to persist.
            pid_type_id: Optional FK value for :attr:`~django_pid.models.PID.pid_type`.
            registered: ``True`` for server-confirmed handles; ``False`` for
                locally-generated pending handles that need a later flush.
            retry_after: Optional earliest retry timestamp for pending handles
                (only meaningful when ``registered=False``).

        Returns:
            List of created :class:`~django_pid.models.PID` instances.

        """
        from django_pid.models import PID

        pid_objects: list[PID] = [
            PID(
                handle=handle,
                pid=f"{self.pid_server.server_url.rstrip('/')}/{handle}" if self.pid_server.server_url else handle,
                pid_server=self.pid_server,
                pid_type_id=pid_type_id,
                registered=registered,
                reserved=False,
                visible=False,
                registration_retry_after=retry_after if not registered else None,
            )
            for handle in handles
        ]
        created = PID.objects.bulk_create(pid_objects, ignore_conflicts=True)
        status = "registered" if registered else "pending"
        logger.info("Saved %d %s PID pool entries for server %s", len(created), status, self.pid_server.name)
        return created

    def save_bulk_result_to_db(
        self,
        result: BulkRegistrationResult,
        pid_type_id: str | None = None,
        retry_after: "timezone.datetime | None" = None,
    ) -> tuple[list["PID"], list["PID"]]:
        """
        Persist both registered and pending handles from a :class:`BulkRegistrationResult`.

        Args:
            result: Result from :meth:`pre_register_handles_bulk` or
                :meth:`flush_pending_handles`.
            pid_type_id: Optional FK value for :attr:`~django_pid.models.PID.pid_type`.
            retry_after: Earliest retry time for pending handles.

        Returns:
            Tuple of ``(registered_pids, pending_pids)``.

        """
        registered_pids: list[PID] = []
        pending_pids: list[PID] = []
        if result.registered:
            registered_pids = self.save_pre_registered_pids_to_db(
                result.registered, pid_type_id=pid_type_id, registered=True
            )
        if result.pending:
            pending_pids = self.save_pre_registered_pids_to_db(
                result.pending, pid_type_id=pid_type_id, registered=False, retry_after=retry_after
            )
        return registered_pids, pending_pids


# ---------------------------------------------------------------------------
# Re-exported builder alias (used by apps.py factory registration)
# ---------------------------------------------------------------------------
PIDServiceBuilder = PID4CatServiceBuilder
