"""django_pid database models for PID server, type, and pool management."""

import logging
import uuid

from django.db import models

from django_pid.managers import PIDManager

logger = logging.getLogger(__name__)


class PIDServer(models.Model):
    """Definition of the PID servers, like handle, doi, ark, etc., at which PIDs are registered."""

    pid_server_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, blank=True, null=True, unique=True, help_text="Name of the PID server")
    server_url = models.URLField(blank=True, null=True, unique=True, help_text="URL of the PID server")
    prefix = models.CharField(max_length=255, blank=True, null=True, unique=True, help_text="Prefix of the PID server")
    url_pattern = models.TextField(blank=True, null=True, unique=True, help_text="pattern of the PID URLs")
    description = models.TextField(blank=True, null=True, help_text="Description of the PID server")
    connection_parameters = models.JSONField(
        blank=True,
        null=True,
        help_text=(
            "Connection parameters for the PID server: username, password, handleowner, etc. "
            'Example: {"username": "300:prefix/ADMIN", "password": "secret", '
            '"handleowner": "200:prefix/ADMIN"}'
        ),
    )
    pool_min_size = models.PositiveIntegerField(
        default=10,
        help_text=(
            "Minimum number of unreserved PIDs to maintain in the pool. "
            "When the pool drops below this value, new PIDs are requested asynchronously. "
            "Overrides the PID4CAT_POOL_MIN_SIZE Django setting when set."
        ),
    )
    pool_target_size = models.PositiveIntegerField(
        default=50,
        help_text="Target pool size to refill to when the pool drops below pool_min_size.",
    )


class PIDType(models.Model):
    """
    Type of the PID, like handle, handle:DOI, handle:ARK, etc.

    The name can include a resourceType, e.g. handle:handle/sample, handle:DOI/instrument.
    """

    pid_type_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, blank=True, null=True, unique=True, help_text="Name of the PID type")
    description = models.TextField(blank=True, null=True, help_text="Description of the PID type")


class PID(models.Model):
    """
    PID pool entry.

    PIDs are pre-registered at the handle server and held in a pool until they
    are assigned to a resource.  The lifecycle is:

    1. ``reserved=False, registered=True``  — in pool, ready for use.
    2. ``reserved=True,  registered=True``  — handed out, not yet linked to a resource.
    3. ``reserved=True,  registered=True, visible=True`` — active, resolves to the target URL.
    4. ``visible=False`` — soft-deleted / hidden on the handle server.
    """

    objects: "PIDManager" = PIDManager()

    pid_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    pid_type = models.ForeignKey(PIDType, on_delete=models.CASCADE, blank=True, null=True)
    pid_server = models.ForeignKey(PIDServer, on_delete=models.CASCADE, blank=True, null=True)
    pid = models.URLField(blank=True, null=True, unique=True, help_text="Full resolvable URL of the PID")
    handle = models.CharField(
        max_length=512,
        blank=True,
        null=True,
        unique=True,
        help_text="Raw handle string, e.g. '21.T11148/abc123'",
    )
    target_url = models.URLField(
        blank=True,
        null=True,
        help_text="The URL this handle currently resolves to.",
    )
    visible = models.BooleanField(default=True, help_text="PID is resolvable on the handle server")
    reserved = models.BooleanField(
        default=False,
        help_text="PID is reserved for usage but not yet linked to a resource.",
    )
    registered = models.BooleanField(default=False, help_text="PID has been registered at the handle server")

    metadata = models.JSONField(
        blank=True,
        null=True,
        help_text="Metadata stored alongside the PID on the handle server (PID-implementation specific).",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    registration_retry_after = models.DateTimeField(
        blank=True,
        null=True,
        help_text=(
            "Earliest time to retry server registration for locally-generated (pending) handles. "
            "Set automatically with exponential back-off when the server is unreachable. "
            "NULL means 'retry immediately'."
        ),
    )

    class Meta:  # noqa: D106
        indexes = [  # noqa: RUF012
            models.Index(fields=["pid_server", "reserved", "registered"], name="pid_pool_idx"),
        ]

    def __str__(self) -> str:
        """Return a human-readable representation."""
        return self.handle or self.pid or str(self.pid_id)
