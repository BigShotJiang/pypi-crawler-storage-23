"""
Asynchronous Celery tasks for PID pool management.

Pool lifecycle
~~~~~~~~~~~~~~
1. :func:`check_pool_for_server` is triggered whenever a PID is reserved
   (via the post-save signal in :mod:`django_pid.signals`).
2. If the available pool falls below ``PIDServer.pool_min_size`` the task
   enqueues :func:`replenish_pid_pool` with the number of PIDs to create.
3. :func:`replenish_pid_pool` calls :meth:`PID4CatService.pre_register_handles_bulk`
   and persists the result via :meth:`PID4CatService.save_bulk_result_to_db`.
4. When the server is unavailable, handles are generated locally
   (``registered=False``) and :func:`flush_pending_pool` retries the
   registration later with exponential back-off.
"""

from datetime import timedelta

from celery import shared_task
from celery.utils.log import get_task_logger
from django.utils import timezone

logger = get_task_logger(__name__)

# Back-off schedule for pending-handle flush retries (seconds).
# Loaded from the service module so both share the same default.
_RETRY_BACKOFF_SCHEDULE: tuple[int, ...] = (60, 300, 900, 3600, 21600)


# ---------------------------------------------------------------------------
# Server availability check
# ---------------------------------------------------------------------------


@shared_task
def check_server_availability(pid_server_id: str) -> str:
    """
    Test whether the Handle server for *pid_server_id* is reachable.

    Logs the result and returns a status string.  Intended for use in health
    dashboards and as a pre-flight check before other operations.

    Args:
        pid_server_id: String UUID of the :class:`~django_pid.models.PIDServer`.

    Returns:
        ``"available"`` or ``"unavailable:reason"``.

    """
    from django_pid.models import PIDServer
    from django_pid.pid_service_builders.pid4cat import PID4CatService

    try:
        server = PIDServer.objects.get(pk=pid_server_id)
    except PIDServer.DoesNotExist:
        logger.error("PIDServer %s not found", pid_server_id)
        return f"error:server_not_found:{pid_server_id}"

    service = PID4CatService(pid_server=server)
    if service.is_available():
        logger.info("Handle server '%s' is available", server.name)
        return "available"
    logger.warning("Handle server '%s' is NOT available", server.name)
    return "unavailable"


# ---------------------------------------------------------------------------
# Pool health check
# ---------------------------------------------------------------------------


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def check_pool_for_server(self, pid_server_id: str) -> str:
    """
    Check the PID pool for *pid_server_id* and trigger replenishment if needed.

    This task is lightweight and designed to be called frequently (e.g. after
    every PID reservation).  It does the DB count locally and only spawns a
    second task when the pool is genuinely below the minimum watermark.

    Args:
        self: Celery task instance (injected via ``bind=True``).
        pid_server_id: String UUID of the :class:`~django_pid.models.PIDServer`.

    Returns:
        A short status string describing what was done.

    """
    from django_pid.models import PID

    try:
        needs = PID.objects.needs_replenishment(pid_server_id)
        if needs:
            count = PID.objects.missing_count(pid_server_id)
            logger.info("Pool for server %s needs replenishment - requesting %d PIDs", pid_server_id, count)
            replenish_pid_pool.delay(pid_server_id, count)
            return f"replenishment_triggered:{count}"
        return "pool_ok"
    except Exception as exc:
        logger.exception("Error checking pool for server %s", pid_server_id)
        raise self.retry(exc=exc) from exc


# ---------------------------------------------------------------------------
# Pool replenishment (with offline fallback)
# ---------------------------------------------------------------------------


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def replenish_pid_pool(self, pid_server_id: str, count: int) -> str:
    """
    Pre-register *count* new handles and add them to the PID pool.

    When the server is reachable, handles are registered immediately.
    When unreachable, handles are generated locally (``registered=False``)
    and :func:`flush_pending_pool` is scheduled to retry later.

    Args:
        self: Celery task instance (injected via ``bind=True``).
        pid_server_id: String UUID of the :class:`~django_pid.models.PIDServer`.
        count: Number of new PIDs to create.

    Returns:
        A short status string with the number of handles registered and pending.

    """
    from django_pid.models import PIDServer
    from django_pid.pid_service_builders.pid4cat import _RETRY_BACKOFF_SCHEDULE, PID4CatService

    try:
        server = PIDServer.objects.get(pk=pid_server_id)
    except PIDServer.DoesNotExist:
        logger.error("PIDServer %s not found - aborting replenishment", pid_server_id)
        return f"error:server_not_found:{pid_server_id}"

    try:
        service = PID4CatService(pid_server=server)
        result = service.pre_register_handles_bulk(count)

        # Compute back-off for any locally-generated pending handles.
        retry_after = None
        if result.pending:
            backoff_seconds = _RETRY_BACKOFF_SCHEDULE[0]
            retry_after = timezone.now() + timedelta(seconds=backoff_seconds)

        service.save_bulk_result_to_db(result, retry_after=retry_after)

        if result.pending:
            flush_pending_pool.apply_async(
                args=[pid_server_id],
                countdown=backoff_seconds,
            )
            logger.info(
                "Scheduled flush_pending_pool for server %s in %d s",
                pid_server_id,
                backoff_seconds,
            )

        logger.info(
            "Replenishment for server %s: %d registered, %d pending",
            server.name,
            len(result.registered),
            len(result.pending),
        )
        return f"registered:{len(result.registered)},pending:{len(result.pending)}"
    except Exception as exc:
        logger.exception("Error replenishing PID pool for server %s", pid_server_id)
        raise self.retry(exc=exc) from exc


# ---------------------------------------------------------------------------
# Pending-handle flush (register locally-generated handles on the server)
# ---------------------------------------------------------------------------


@shared_task(bind=True, max_retries=len(_RETRY_BACKOFF_SCHEDULE))
def flush_pending_pool(self, pid_server_id: str) -> str:
    """
    Attempt to register pending (locally-generated) handles at the handle server.

    Picks up all DB entries with ``registered=False, reserved=False`` whose
    ``registration_retry_after`` is in the past (or NULL), attempts to register
    them, then applies exponential back-off for those that still fail.

    Args:
        self: Celery task instance (injected via ``bind=True``).
        pid_server_id: String UUID of the :class:`~django_pid.models.PIDServer`.

    Returns:
        A short status string with the flush outcome.

    """
    from django_pid.models import PID, PIDServer
    from django_pid.pid_service_builders.pid4cat import _RETRY_BACKOFF_SCHEDULE, PID4CatService

    try:
        server = PIDServer.objects.get(pk=pid_server_id)
    except PIDServer.DoesNotExist:
        logger.error("PIDServer %s not found - aborting flush", pid_server_id)
        return f"error:server_not_found:{pid_server_id}"

    pending_handles_qs = PID.objects.get_pending_handles(pid_server_id)
    if not pending_handles_qs.exists():
        logger.debug("No pending handles for server %s", server.name)
        return "no_pending"

    handle_strings = list(pending_handles_qs.values_list("handle", flat=True))
    logger.info("Flushing %d pending handles for server %s", len(handle_strings), server.name)

    service = PID4CatService(pid_server=server)
    result = service.flush_pending_handles(handle_strings)

    # Mark successfully registered handles in the DB.
    if result.registered:
        PID.objects.filter(
            pid_server_id=pid_server_id,
            handle__in=result.registered,
            registered=False,
        ).update(registered=True, registration_retry_after=None, updated_at=timezone.now())
        logger.info("Marked %d handles as registered", len(result.registered))

    # Apply back-off to still-failing handles.
    if result.pending:
        retry_index = min(self.request.retries, len(_RETRY_BACKOFF_SCHEDULE) - 1)
        backoff_seconds = _RETRY_BACKOFF_SCHEDULE[retry_index]
        new_retry_after = timezone.now() + timedelta(seconds=backoff_seconds)
        PID.objects.filter(
            pid_server_id=pid_server_id,
            handle__in=result.pending,
            registered=False,
        ).update(registration_retry_after=new_retry_after, updated_at=timezone.now())
        logger.warning(
            "%d handles still pending - next flush attempt in %d s",
            len(result.pending),
            backoff_seconds,
        )
        raise self.retry(countdown=backoff_seconds)

    return f"flushed:{len(result.registered)}"


# ---------------------------------------------------------------------------
# High-level convenience task (e.g. for management commands / cron)
# ---------------------------------------------------------------------------


@shared_task
def check_all_server_pools() -> str:
    """
    Trigger a pool health check and pending flush for every configured PIDServer.

    Useful as a periodic Celery beat task to ensure pool levels are maintained
    even when traffic is low and to catch up on any offline-generated handles.

    Returns:
        Comma-separated list of server names checked.

    """
    from django_pid.models import PIDServer

    results: list[str] = []
    for server in PIDServer.objects.all():
        sid = str(server.pid_server_id)
        check_pool_for_server.delay(sid)
        flush_pending_pool.delay(sid)
        results.append(str(server.name))
    return f"pools_checked:{','.join(results)}"
