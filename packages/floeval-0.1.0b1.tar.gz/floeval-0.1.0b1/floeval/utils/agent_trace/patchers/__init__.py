"""Patchers for trace capture."""
