"""
Pydantic schemas for trustguard.
"""

from trustguard.schemas.base import BaseResponse
from trustguard.schemas.generic import GenericResponse

__all__ = ["BaseResponse", "GenericResponse"]
