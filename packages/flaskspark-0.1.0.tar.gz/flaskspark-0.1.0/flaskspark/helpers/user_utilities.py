"""
User utility helpers for FlaskSpark.

Reserved for user-related convenience functions that are shared across apps.
"""
