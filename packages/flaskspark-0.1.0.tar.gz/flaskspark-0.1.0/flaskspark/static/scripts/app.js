// Import libraries from node.js
import { createPopper } from '@popperjs/core';
import {Alert, Button, Carousel, Collapse, Dropdown, Modal, Offcanvas, Popover, ScrollSpy, Tab, Toast, Tooltip} from 'bootstrap'
import { Notyf } from 'notyf';

// Domready listener
document.addEventListener('DOMContentLoaded', () => {
    // Add your custom javascript here...
});