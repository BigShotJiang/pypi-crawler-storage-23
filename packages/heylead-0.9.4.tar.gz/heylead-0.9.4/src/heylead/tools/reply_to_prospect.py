"""Tool: reply_to_prospect — Generate and send sentiment-aware replies to prospect messages.

Core reply loop:
1. Find next outreach needing a reply (hot_lead or replied with prospect message)
2. Load conversation history + last prospect message + sentiment
3. Resolve chat_id (prospect's linkedin_id → Unipile chat)
4. Generate personalized reply via sentiment-specific pipeline
5. In Copilot mode: show for approval. In Autopilot: send immediately.
6. Update outreach status
"""

from __future__ import annotations

import json
import logging
from typing import Any

from ..ai.message_fixer import fix_message
from ..ai.message_improver import improve_message
from ..ai.message_validator import validate_reply
from ..ai.prospect_analyzer import analyze_prospect
from ..ai.reply_generator import NEGATIVE_MAX_CHARS, REPLY_MAX_CHARS, generate_reply
from ..config import get_tier
from ..constants import (
    COPILOT_APPROVAL_THRESHOLD,
    FREE_MONTHLY_MESSAGES,
    TIER_PRO,
)
from ..db.queries import (
    find_active_campaign,
    get_campaign,
    get_campaign_context,
    get_contact_analysis,
    get_messages_for_outreach,
    get_monthly_usage,
    get_outreach,
    get_outreach_with_contact,
    get_reply_candidates,
    get_setting,
    increment_usage,
    log_action,
    save_contact_analysis,
    save_message,
    update_outreach,
)
from ..formatter import stars
from ..linkedin import (
    UnipileAuthError,
    UnipileError,
    get_account_id,
    get_linkedin_client,
)

logger = logging.getLogger(__name__)

SENTIMENT_ICONS = {
    "positive": "\U0001f525",
    "negative": "\U0001f44e",
    "question": "\u2753",
    "neutral": "\U0001f4ac",
    "out_of_office": "\u2708\ufe0f",
    "opt_out": "\U0001f6ab",
}

SENTIMENT_LABELS = {
    "positive": "Positive",
    "negative": "Negative",
    "question": "Question",
    "neutral": "Neutral",
    "out_of_office": "Out of Office",
    "opt_out": "Opt-Out",
}


async def run_reply_to_prospect(
    outreach_id: str = "",
    mode: str = "autopilot",
) -> str:
    """Generate and send (or queue) a sentiment-aware reply to a prospect.

    Flow:
    1. Find the active campaign and next outreach needing a reply
    2. Load conversation history and detect last prospect message
    3. Resolve chat_id
    4. Generate sentiment-aware reply
    5. Validate the reply (reply-specific pipeline)
    6. Copilot: show for review. Autopilot: send directly.
    """

    # ── Step 0: Pre-checks ──
    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before replying.\n\n"
            "Please run setup_profile first."
        )

    account_id = get_account_id()
    if not account_id:
        return "No LinkedIn account connected. Run setup_profile first."

    try:
        client = get_linkedin_client()
    except UnipileError as e:
        return f"{e}"

    # ── Step 1: Find outreach needing a reply ──
    campaign = None
    campaign_id = ""

    if outreach_id:
        # Specific outreach requested
        outreach = get_outreach(outreach_id)
        if not outreach:
            await client.close()
            return f"Outreach not found: {outreach_id}"
        if outreach["status"] not in ("hot_lead", "replied"):
            await client.close()
            return (
                f"Outreach status is '{outreach['status']}', not 'hot_lead' or 'replied'.\n"
                "Replies can only be sent to prospects who have messaged you.\n"
                "Use check_replies() first to detect new messages."
            )
        campaign = get_campaign(outreach["campaign_id"])
        if not campaign:
            await client.close()
            return "Campaign not found for this outreach."
        campaign_id = campaign["id"]
        candidate = get_outreach_with_contact(outreach_id)
        if not candidate:
            await client.close()
            return "Could not load contact data for this outreach."
    else:
        # Find campaign
        campaign, err = find_active_campaign("")
        if not campaign:
            await client.close()
            return err
        campaign_id = campaign["id"]

        # Block sends when campaign is paused
        if campaign.get("status") == "paused":
            await client.close()
            return (
                f"Campaign '{campaign['name']}' is paused.\n\n"
                "No messages will be sent while the campaign is paused.\n"
                "Use resume_campaign() to resume outreach."
            )

        # Find next reply candidate
        candidates = get_reply_candidates(campaign_id)
        if not candidates:
            await client.close()
            return (
                f"No prospects need a reply in '{campaign['name']}'.\n\n"
                "Prospects must have sent you a message first.\n"
                "Use check_replies() to detect new messages, or "
                "generate_and_send() to reach new prospects."
            )
        candidate = candidates[0]
        outreach_id = candidate["outreach_id"]

    # ── Step 2: Check tier limits ──
    tier = get_tier()
    if tier != TIER_PRO:
        usage = get_monthly_usage()
        if usage.get("messages_sent", 0) >= FREE_MONTHLY_MESSAGES:
            await client.close()
            return (
                f"Free tier limit reached: {FREE_MONTHLY_MESSAGES} messages/month.\n\n"
                "Upgrade to Pro ($29/mo) for unlimited messages."
            )

    # ── Step 3: Load conversation history + last prospect message ──
    messages = get_messages_for_outreach(outreach_id)

    # Find the last prospect message and its sentiment
    last_prospect_msg = None
    for msg in reversed(messages):
        if msg.get("role") == "prospect":
            last_prospect_msg = msg
            break

    if not last_prospect_msg:
        await client.close()
        return (
            f"No prospect message found for this outreach.\n\n"
            "The prospect needs to have sent you a message first.\n"
            "Use check_replies() to detect new messages."
        )

    reply_text = last_prospect_msg.get("text", "")
    sentiment = last_prospect_msg.get("sentiment", "neutral")

    # Don't auto-reply to opt_out or out_of_office
    if sentiment == "opt_out":
        await client.close()
        return (
            "This prospect has opted out of communication.\n"
            "No reply will be sent. Their outreach has been closed."
        )
    if sentiment == "out_of_office":
        await client.close()
        return (
            "This prospect is out of office.\n"
            "Wait for them to return before replying.\n"
            "Use send_followup() later when they're back."
        )

    # ── Step 4: Resolve chat_id ──
    prospect_linkedin_id = candidate.get("linkedin_id", "")
    if not prospect_linkedin_id:
        await client.close()
        return f"No LinkedIn ID for {candidate.get('name', 'Unknown')}. Cannot send DM."

    try:
        chat_id = await client.find_chat_for_user(account_id, prospect_linkedin_id)
    except Exception as e:
        logger.error(f"Failed to find chat: {e}")
        chat_id = None

    if not chat_id:
        await client.close()
        return (
            f"Could not find a chat with {candidate.get('name', 'the prospect')}.\n\n"
            "The chat may not have synced yet.\n"
            "Try check_replies() to update conversation data."
        )

    # ── Step 5: Load context for reply generation ──
    sender_profile = get_setting("profile", {})
    voice_signature = get_setting("voice_signature", {})
    campaign_config = json.loads(campaign.get("config_json", "{}"))
    icp_data = json.loads(campaign.get("icp_json", "{}"))

    campaign_context = {
        "target_description": campaign_config.get("target_description", ""),
        "relevance_hook": icp_data.get("relevance_hook", ""),
        "booking_link": campaign_config.get("booking_link", ""),
    }

    # Load campaign context (offerings, case_studies, social_proofs, preferences)
    campaign_ctx = get_campaign_context(campaign_id)

    booking_link = campaign_config.get("booking_link", "")

    prospect_data = json.loads(candidate.get("profile_json", "{}")) if candidate.get("profile_json") else {
        "name": candidate.get("name", ""),
        "title": candidate.get("title", ""),
        "company": candidate.get("company", ""),
        "headline": f"{candidate.get('title', '')} at {candidate.get('company', '')}",
    }

    # ── Prospect Intelligence: load cached or generate ──
    prospect_analysis = None
    contact_db_id = candidate.get("contact_db_id") or candidate.get("contact_id", "")
    if contact_db_id:
        prospect_analysis = get_contact_analysis(contact_db_id)
    if not prospect_analysis:
        try:
            prospect_analysis = await analyze_prospect(
                prospect=prospect_data,
                campaign_context=campaign_context,
                icp_data=icp_data,
            )
            if contact_db_id:
                save_contact_analysis(contact_db_id, prospect_analysis)
        except Exception as e:
            logger.warning(f"Prospect analysis failed, proceeding without: {e}")

    # Format conversation history for the generator
    conversation_history = [
        {"role": m["role"], "text": m["text"]}
        for m in messages
    ]

    # ── Step 6: Generate → Improve → Validate → Fix pipeline ──
    max_chars = NEGATIVE_MAX_CHARS if sentiment == "negative" else REPLY_MAX_CHARS
    message = ""
    reasoning = {}
    validation = None
    previous_sdr_messages = [m["text"] for m in messages if m.get("role") == "sdr"]

    # Attempt 1: Generate + Improve + Validate (+ Fix if needed)
    try:
        result = await generate_reply(
            prospect=prospect_data,
            sender_profile=sender_profile,
            voice_signature=voice_signature,
            campaign_context=campaign_context,
            conversation_history=conversation_history,
            reply_text=reply_text,
            sentiment=sentiment,
            prospect_analysis=prospect_analysis,
            booking_link=booking_link,
        )
        message = result.get("message", "")
        reasoning = result.get("reasoning", {})
    except Exception as e:
        logger.error(f"Reply generation failed: {e}")
        await client.close()
        return f"Failed to generate reply: {e}"

    # Improve stage — polish for naturalness
    try:
        message = await improve_message(
            draft=message,
            voice_signature=voice_signature,
            message_type="reply",
            max_chars=max_chars,
        )
    except Exception as e:
        logger.warning(f"Improve stage failed, using raw message: {e}")

    # Validate
    validation = validate_reply(
        message,
        voice_signature,
        sentiment=sentiment,
        previous_messages=previous_sdr_messages,
        max_chars=max_chars,
    )

    # Fix stage — if validation failed, surgically fix issues
    if not validation.is_valid:
        logger.info(f"Reply validation failed, attempting fix: {validation.issues}")
        try:
            message = await fix_message(
                message=message,
                issues=validation.issues,
                voice_signature=voice_signature,
                message_type="reply",
                max_chars=max_chars,
            )
            validation = validate_reply(
                message,
                voice_signature,
                sentiment=sentiment,
                previous_messages=previous_sdr_messages,
                max_chars=max_chars,
            )
        except Exception as e:
            logger.warning(f"Fix stage failed: {e}")

    # Last resort: regenerate from scratch if still invalid
    if not validation.is_valid:
        logger.info(f"Fix failed, regenerating reply from scratch: {validation.issues}")
        try:
            result = await generate_reply(
                prospect=prospect_data,
                sender_profile=sender_profile,
                voice_signature=voice_signature,
                campaign_context=campaign_context,
                conversation_history=conversation_history,
                reply_text=reply_text,
                sentiment=sentiment,
                prospect_analysis=prospect_analysis,
                booking_link=booking_link,
            )
            message = result.get("message", "")
            reasoning = result.get("reasoning", {})
            message = await improve_message(
                draft=message,
                voice_signature=voice_signature,
                message_type="reply",
                max_chars=max_chars,
            )
            validation = validate_reply(
                message,
                voice_signature,
                sentiment=sentiment,
                previous_messages=previous_sdr_messages,
                max_chars=max_chars,
            )
        except Exception as e:
            logger.error(f"Regeneration failed: {e}")

    if not validation or not validation.is_valid:
        issues_text = "\n".join(f"  \u26a0\ufe0f {issue}" for issue in (validation.issues if validation else []))
        if mode == "autopilot":
            logger.warning(f"Autopilot blocked invalid reply: {issues_text}")
            log_action("validation_blocked", outreach_id=outreach_id, result="blocked",
                       details={"issues": validation.issues if validation else [], "type": "reply"})
            await client.close()
            return (
                f"\u26a0\ufe0f Reply for {candidate.get('name', 'Unknown')} failed validation "
                f"after Generate \u2192 Improve \u2192 Fix pipeline.\n\n"
                f"Issues:\n{issues_text}\n\n"
                "The message was NOT sent to protect your account.\n"
                "Try: reply_to_prospect(mode='copilot') to review and edit manually."
            )
        else:
            logger.warning(f"Copilot reply has validation warnings: {issues_text}")

    # ── Step 7: Copilot vs Autopilot ──
    prospect_name = candidate.get("name", "Unknown")
    prospect_title = candidate.get("title", "")
    prospect_company = candidate.get("company", "")
    fit_score = candidate.get("fit_score", 0)

    role_str = prospect_title
    if prospect_company:
        role_str += f" at {prospect_company}" if role_str else prospect_company

    sentiment_icon = SENTIMENT_ICONS.get(sentiment, "\U0001f4ac")
    sentiment_label = SENTIMENT_LABELS.get(sentiment, "Unknown")

    if mode == "copilot":
        # Show message for review — store reply context in next_action as JSON
        reply_context = json.dumps({
            "type": "reply",
            "message": message,
            "sentiment": sentiment,
        })
        update_outreach(outreach_id, next_action=reply_context)

        output = [
            f"Reply to **{prospect_name}** ({role_str}) \u2014 Sentiment: {sentiment_icon} {sentiment_label}",
            f"   Fit: {stars(fit_score)}",
            "",
            f'   Their message: "{reply_text[:200]}{"..." if len(reply_text) > 200 else ""}"',
            "",
            f'   "{message}"',
            f"   ({len(message)}/{max_chars} chars)",
            "",
        ]

        # Show reasoning
        if reasoning:
            strategy = reasoning.get("strategy", "") or reasoning.get("answer_approach", "") or reasoning.get("close_style", "") or reasoning.get("angle", "")
            if strategy:
                output.append(f"   Strategy: {strategy}")
                output.append("")

        # Show validation warnings
        if validation and validation.warnings:
            for w in validation.warnings:
                output.append(f"   {w}")
            output.append("")

        output.extend([
            "Send this? Reply with:",
            "  'yes' / 'send' to send this reply",
            "  'skip' to skip this prospect",
            "  'edit: [your text]' to send a custom message instead",
            "  'stop' to pause the campaign",
        ])

        await client.close()
        return "\n".join(line for line in output if line is not None)

    else:
        # Autopilot — send immediately
        try:
            send_result = await client.send_message(
                account_id=account_id,
                chat_id=chat_id,
                text=message,
            )
        except UnipileAuthError:
            await client.close()
            return (
                "LinkedIn account disconnected.\n\n"
                "Run setup_profile() again to reconnect."
            )
        except Exception as e:
            await client.close()
            return f"Failed to send reply: {e}"
        finally:
            await client.close()

        if send_result.get("success"):
            # Update status based on sentiment
            if sentiment == "negative":
                new_status = "closed_unhappy"
                import time as _time
                outcome_data = json.dumps({
                    "outcome": "lost",
                    "reason": "Prospect declined (negative reply)",
                    "closed_at": int(_time.time()),
                    "previous_status": candidate.get("status", ""),
                })
                update_outreach(outreach_id, status=new_status, outcome_json=outcome_data, next_action=None)
            elif candidate.get("status") == "hot_lead":
                new_status = "hot_lead"  # Stay hot_lead
                update_outreach(outreach_id, status=new_status)
            else:
                new_status = "messaged"  # Back to messaged, waiting for their response
                update_outreach(outreach_id, status=new_status)
            save_message(outreach_id, role="sdr", text=message)
            increment_usage("messages_sent")
            log_action(
                "reply_sent",
                outreach_id=outreach_id,
                result="success",
                details={
                    "prospect": prospect_name,
                    "sentiment": sentiment,
                    "message_length": len(message),
                    "reasoning": reasoning,
                },
            )

            status_note = ""
            if sentiment == "negative":
                status_note = "\nOutreach closed gracefully."
            elif sentiment == "positive":
                status_note = "\nConversation continues \u2014 check back for their response."

            return (
                f"Sent reply to {prospect_name} ({role_str}) \u2014 {sentiment_icon} {sentiment_label}\n"
                f'   "{message}"\n'
                f"{status_note}"
            )
        else:
            error = send_result.get("error", "Unknown error")
            log_action(
                "reply_failed",
                outreach_id=outreach_id,
                result="error",
                details={"error": error},
            )
            return f"Reply failed for {prospect_name}: {error}"
