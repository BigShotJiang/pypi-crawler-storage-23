"""HeyLead constants — limits, defaults, tier definitions."""

from __future__ import annotations

# ──────────────────────────────────────────────
# Rate Limits (Simple Adaptive)
# ──────────────────────────────────────────────

INITIAL_DAILY_INVITATIONS = 15       # Start conservative for new accounts
MAX_DAILY_INVITATIONS = 50           # Cap (regular LinkedIn)
MAX_DAILY_INVITATIONS_SALES_NAV = 80 # Cap (Sales Navigator)
WEEKLY_INVITATION_CAP = 100          # Hard weekly ceiling
WEEKLY_INVITATION_CAP_SALES_NAV = 200
DAILY_MESSAGES = 50                  # Messages to existing connections

# Adaptive thresholds
ACCEPTANCE_RATE_RAMP_UP = 0.30       # >30% acceptance → increase limit by 5
ACCEPTANCE_RATE_PULL_BACK = 0.15     # <15% acceptance → decrease limit by 5
RAMP_STEP = 5                        # How much to change per adjustment
MIN_DAILY_LIMIT = 10                 # Floor (never go below)
BLOCK_HALVE_FLOOR = 5               # Minimum after halving on block

# Timing
MIN_DELAY_MINUTES = 15               # Min gap between invitations
MAX_DELAY_MINUTES = 45               # Max gap (randomized)
DEFAULT_START_HOUR = 0               # Autonomous bot: 24/7
DEFAULT_END_HOUR = 24                # Autonomous bot: 24/7
DEFAULT_ACTIVE_DAYS = [0, 1, 2, 3, 4, 5, 6]  # All days

# Message limits
INVITATION_NOTE_MAX_CHARS = 200      # Regular LinkedIn
INVITATION_NOTE_MAX_CHARS_SALES_NAV = 300  # Sales Navigator

# ──────────────────────────────────────────────
# Free Tier Caps
# ──────────────────────────────────────────────
# TODO(release): restore production limits before public release:
#   INVITATIONS=50, MESSAGES=20, CAMPAIGNS=1, CONTACTS=30,
#   ICP_GEN=1, ICP_V2=3, FOLLOWUPS=2, ENGAGEMENTS=30, ACCOUNTS=1

FREE_MONTHLY_INVITATIONS = 9999
FREE_MONTHLY_MESSAGES = 9999
FREE_MAX_CAMPAIGNS = 9999
FREE_MAX_CONTACTS_ANALYZED = 9999
FREE_MAX_ICP_GENERATIONS = 9999
FREE_MAX_ICP_V2_GENERATIONS = 9999
FREE_MAX_FOLLOWUPS = 9999
FREE_MAX_ENGAGEMENTS = 9999
FREE_MAX_LINKEDIN_ACCOUNTS = 9999

# ──────────────────────────────────────────────
# Pro Tier
# ──────────────────────────────────────────────

PRO_PRICE_MONTHLY = 29               # USD
PRO_PRICE_ANNUAL_MONTHLY = 24        # USD (billed annually)
PRO_MAX_FOLLOWUPS = 5
PRO_MAX_LINKEDIN_ACCOUNTS = 5
PRO_FOLLOWUP_SCHEDULE_DAYS = [1, 7, 14, 21, 28]

# ──────────────────────────────────────────────
# Engagement Limits
# ──────────────────────────────────────────────

COMMENT_MAX_CHARS = 200              # Keep comments concise for best engagement
DAILY_ENGAGEMENT_LIMIT = 20          # Max engagements per day (LinkedIn safety)
MIN_ENGAGEMENT_DELAY_MINUTES = 5     # Min gap between engagements
AUTO_REACT_PROBABILITY = 0.30        # 30% react / 70% comment in auto mode

# ──────────────────────────────────────────────
# LLM Defaults
# ──────────────────────────────────────────────

DEFAULT_LLM_PRIORITY = ["gemini", "claude", "openai"]
DEFAULT_GEMINI_MODEL = "gemini-2.0-flash"
DEFAULT_CLAUDE_MODEL = "claude-sonnet-4-20250514"
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"

GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models"
CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"

# ──────────────────────────────────────────────
# Unipile API
# ──────────────────────────────────────────────

UNIPILE_POLL_INTERVAL_SECONDS = 4   # How often to check for account during setup
UNIPILE_POLL_TIMEOUT_SECONDS = 120  # Max wait for LinkedIn OAuth completion

# ──────────────────────────────────────────────
# Paths
# ──────────────────────────────────────────────

HEYLEAD_DIR_NAME = ".heylead"
CONFIG_FILE = "config.json"
DB_DIR = "data"
DB_FILE = "heylead.db"
AUTH_DIR = "auth"
COOKIE_FILE = "linkedin.enc"  # Legacy — kept for cleanup of old installs
LOG_DIR = "logs"
LOG_FILE = "heylead.log"
KB_DIR = "knowledge-base"
EMBEDDINGS_DIR = "embeddings"

# ICP generation
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"
FIRECRAWL_API_URL = "https://api.firecrawl.dev/v1"
SERPER_API_URL = "https://google.serper.dev/news"

# ──────────────────────────────────────────────
# Backend Defaults
# ──────────────────────────────────────────────

DEFAULT_BACKEND_URL = "https://heylead-api-141730336364.us-central1.run.app"
LOGIN_URL_PATH = "/auth/login-url"
GEMINI_KEY_URL = "https://aistudio.google.com/apikey"

# ──────────────────────────────────────────────
# Misc
# ──────────────────────────────────────────────

MAX_LOG_SIZE_BYTES = 10 * 1024 * 1024  # 10 MB
LOG_BACKUP_COUNT = 3
COPILOT_APPROVAL_THRESHOLD = 10  # Auto-prompt for Autopilot after N approvals

# Tier enum-like
TIER_FREE = "free"
TIER_PRO = "pro"

# Campaign statuses
STATUS_ACTIVE = "active"
STATUS_PAUSED = "paused"
STATUS_COMPLETED = "completed"
STATUS_DRAFT = "draft"

# Warm-up enforcement
MIN_WARMUP_ENGAGEMENTS = 0           # Invites go out immediately; engagements run in parallel

# Outreach statuses
OUTREACH_PENDING = "pending"
OUTREACH_INVITED = "invited"
OUTREACH_CONNECTED = "connected"
OUTREACH_MESSAGED = "messaged"
OUTREACH_REPLIED = "replied"
OUTREACH_HOT_LEAD = "hot_lead"
OUTREACH_CLOSED_HAPPY = "closed_happy"
OUTREACH_CLOSED_UNHAPPY = "closed_unhappy"
OUTREACH_OPTED_OUT = "opted_out"
OUTREACH_REVIEW_PENDING = "review_pending"
OUTREACH_SKIPPED = "skipped"

# Sentiment labels
SENTIMENT_POSITIVE = "positive"
SENTIMENT_NEGATIVE = "negative"
SENTIMENT_QUESTION = "question"
SENTIMENT_NEUTRAL = "neutral"
SENTIMENT_OOO = "out_of_office"
SENTIMENT_OPT_OUT = "opt_out"

# ──────────────────────────────────────────────
# Scheduler (Sprint 17)
# ──────────────────────────────────────────────

# Loop intervals (seconds)
SCHEDULER_TICK_SECONDS = 60          # Main loop frequency
SCHEDULER_REPLY_CHECK_SECONDS = 300  # Check replies every 5 min
SCHEDULER_ENGAGEMENT_SECONDS = 600   # Schedule engagements every 10 min

# Action delays (seconds, randomized — matches original NestJS intervals)
INVITE_DELAY_MIN = 20 * 60           # 20 min between invitations
INVITE_DELAY_MAX = 40 * 60           # 40 min
FOLLOWUP_DELAY_MIN = 20 * 60         # 20 min between follow-up messages
FOLLOWUP_DELAY_MAX = 35 * 60         # 35 min
ENGAGEMENT_DELAY_MIN = 5 * 60        # 5 min between engagements
ENGAGEMENT_DELAY_MAX = 15 * 60       # 15 min
FOLLOW_DELAY_MIN = 10 * 60           # 10 min between follows
FOLLOW_DELAY_MAX = 25 * 60           # 25 min
DAILY_FOLLOW_LIMIT = 30              # Max follows per day (LinkedIn safety)
SCHEDULER_FOLLOW_SECONDS = 900       # Schedule follows every 15 min

# Retry & cleanup
SCHEDULER_MAX_RETRIES = 3            # Max retries per failed job
SCHEDULER_RETRY_DELAY = 300          # 5 min retry delay
SCHEDULER_CLEANUP_DAYS = 7           # Purge completed jobs after N days

# Inbound invitation auto-accept
INBOUND_CHECK_SECONDS = 900          # Check inbound invitations every 15 min
DAILY_INBOUND_ACCEPT_LIMIT = 50      # Max inbound accepts per day

# Skill endorsement warm-up
ENDORSE_DELAY_MIN = 10 * 60          # 10 min between endorsements
ENDORSE_DELAY_MAX = 25 * 60          # 25 min
DAILY_ENDORSE_LIMIT = 20             # Max endorsements per day (LinkedIn safety)
SCHEDULER_ENDORSE_SECONDS = 900      # Schedule endorsements every 15 min

# Stale invite withdrawal
STALE_INVITE_DAYS = 21               # Withdraw invites older than 21 days
WITHDRAW_CHECK_SECONDS = 3600        # Check stale invites every hour

# Job types
JOB_INVITE = "invite"
JOB_FOLLOWUP = "followup"
JOB_ENGAGE = "engage"
JOB_FOLLOW = "follow"
JOB_CHECK_REPLIES = "check_replies"
JOB_ACCEPT_INBOUND = "accept_inbound"
JOB_ENDORSE = "endorse"
JOB_WITHDRAW_INVITE = "withdraw_invite"
JOB_QUALIFY_INBOUND = "qualify_inbound"
JOB_CHECK_POST_COMMENTS = "check_post_comments"
JOB_BRAND_POST = "brand_post"
JOB_BRAND_ENGAGE = "brand_engage"
JOB_BRAND_ANALYZE = "brand_analyze"

# Job statuses
JOB_PENDING = "pending"
JOB_RUNNING = "running"
JOB_COMPLETED = "completed"
JOB_FAILED = "failed"

# Experiment analysis & A/B testing
SCHEDULER_AB_EVAL_SECONDS = 3600       # Evaluate A/B tests every hour
SCHEDULER_EXPERIMENT_SECONDS = 21600   # Run experiment analysis every 6 hours

# Inbound qualification pipeline
INBOUND_QUALIFY_SECONDS = 900          # Qualify new signals every 15 min
POST_COMMENT_CHECK_SECONDS = 1800      # Check post comments every 30 min
INBOUND_ENGAGE_CONFIDENCE = 0.7        # Auto-engage threshold
INBOUND_ASK_PURPOSE_CONFIDENCE = 0.4   # Ask-purpose threshold
DAILY_INBOUND_DM_LIMIT = 20           # Max discovery DMs per day
PUBLISHED_POST_MONITOR_DAYS = 7        # Monitor comments for 7 days

# ──────────────────────────────────────────────
# Brand Strategy Automation
# ──────────────────────────────────────────────

# Scheduling check intervals
BRAND_POST_CHECK_SECONDS = 3600          # Check if brand post is due every hour
BRAND_ENGAGE_CHECK_SECONDS = 4 * 3600    # Check brand engagement every 4 hours
BRAND_LIFECYCLE_CHECK_SECONDS = 3600     # Check lifecycle every hour

# Action delays (randomized for humanization)
BRAND_POST_DELAY_MIN = 30 * 60          # 30 min
BRAND_POST_DELAY_MAX = 4 * 3600         # 4 hours
BRAND_ENGAGE_DELAY_MIN = 5 * 60         # 5 min
BRAND_ENGAGE_DELAY_MAX = 20 * 60        # 20 min

# Daily limits
DAILY_BRAND_POST_LIMIT = 1              # Max 1 brand post per day
DAILY_BRAND_ENGAGE_LIMIT = 5            # Max 5 brand engagements per day

# Lifecycle
BRAND_REANALYZE_DAYS = 28               # Re-analyze every 4 weeks
