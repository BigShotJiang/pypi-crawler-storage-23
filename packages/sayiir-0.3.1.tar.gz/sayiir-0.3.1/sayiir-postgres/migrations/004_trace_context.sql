ALTER TABLE sayiir_workflow_snapshots ADD COLUMN IF NOT EXISTS trace_parent TEXT;
