"""SQL template engine for DBGear database operations."""
