import logging

import pytest

from mnemosynecore import mattermost


class _FakePosts:
    def __init__(self, should_fail=False):
        self.should_fail = should_fail
        self.calls = []

    def create_post(self, options):
        if self.should_fail:
            raise RuntimeError("boom")
        self.calls.append(options)


class _FakeDriver:
    def __init__(self, cfg, should_fail=False):
        self.cfg = cfg
        self.posts = _FakePosts(should_fail=should_fail)
        self.logged_in = False

    def login(self):
        self.logged_in = True


def test_get_mattermost_driver_from_json(monkeypatch):
    monkeypatch.setattr(mattermost, "Driver", _FakeDriver)
    raw = '{"host":"h","password":"t","schema":"http","port":8065,"basepath":"/api/v4"}'
    drv = mattermost.get_mattermost_driver(raw)
    assert drv.logged_in is True
    assert drv.cfg["url"] == "h"
    assert drv.cfg["token"] == "t"


def test_get_mattermost_driver_invalid_json():
    with pytest.raises(ValueError, match="Неверный формат JSON"):
        mattermost.get_mattermost_driver("{bad")


def test_get_mattermost_driver_from_conn(monkeypatch):
    monkeypatch.setattr(mattermost, "un_conn", lambda bot_id, conn_type: ("OK", bot_id, conn_type))
    assert mattermost.get_mattermost_driver("MM_CONN") == ("OK", "MM_CONN", "mattermost")


def test_send_message_success(monkeypatch):
    drv = _FakeDriver({})
    monkeypatch.setattr(mattermost, "get_mattermost_driver", lambda bot_id: drv)
    logs = []
    monkeypatch.setattr(logging, "info", lambda msg, cid: logs.append((msg, cid)))

    mattermost.send_message(channel_id="CH", bot_id="BOT", text="  hi  ")

    assert drv.posts.calls == [{"channel_id": "CH", "message": "hi"}]
    assert logs and logs[0][1] == "CH"


def test_send_message_reraises(monkeypatch):
    drv = _FakeDriver({}, should_fail=True)
    monkeypatch.setattr(mattermost, "get_mattermost_driver", lambda bot_id: drv)
    with pytest.raises(RuntimeError, match="boom"):
        mattermost.send_message(channel_id="CH", bot_id="BOT", text="x")


def test_send_message_test_success(monkeypatch):
    monkeypatch.setattr(mattermost, "Driver", _FakeDriver)
    monkeypatch.setattr(
        __import__("mnemosynecore.vault.client", fromlist=["get_secret_test"]),
        "get_secret_test",
        lambda bot_id, dir_path=None: {"host": "h", "password": "t"},
    )
    mattermost.send_message_test(channel_id="C1", bot_id="B1", text="  test ", silent=True)

