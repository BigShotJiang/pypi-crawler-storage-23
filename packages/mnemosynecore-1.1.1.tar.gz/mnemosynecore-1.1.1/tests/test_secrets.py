from mnemosynecore import secrets


def test_resolve_secret_prefers_test_file(monkeypatch):
    monkeypatch.setattr(secrets, "get_secret_test", lambda conn_id, dir_path=None: {"from": "test"})
    monkeypatch.setattr(secrets, "get_secret", lambda conn_id: {"from": "prod"})
    assert secrets.resolve_secret("CID") == {"from": "test"}


def test_resolve_secret_fallback_to_prod(monkeypatch):
    def fail(*_args, **_kwargs):
        raise FileNotFoundError()

    monkeypatch.setattr(secrets, "get_secret_test", fail)
    monkeypatch.setattr(secrets, "get_secret", lambda conn_id: {"from": "prod"})
    assert secrets.resolve_secret("CID") == {"from": "prod"}

