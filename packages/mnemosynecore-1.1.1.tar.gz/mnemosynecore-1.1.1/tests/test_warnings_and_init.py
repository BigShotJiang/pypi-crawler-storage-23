import warnings

import mnemosynecore as core
from mnemosynecore.warnings import old_function


def test_old_function_emits_deprecation_warning():
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        old_function()
    assert recorded
    assert issubclass(recorded[0].category, DeprecationWarning)


def test_init_exports_are_accessible():
    for name in core.__all__:
        assert hasattr(core, name), f"Missing export: {name}"

