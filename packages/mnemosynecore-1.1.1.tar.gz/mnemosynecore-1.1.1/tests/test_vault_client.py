from pathlib import Path

import pytest

from mnemosynecore.vault import client


def test_get_connection_as_json_from_env(monkeypatch):
    payload = '{"host":"env"}'
    monkeypatch.setenv("MY_CONN", payload)
    assert client.get_connection_as_json("MY_CONN") == payload


def test_get_connection_as_json_from_vault(monkeypatch):
    monkeypatch.delenv("MY_CONN", raising=False)
    monkeypatch.setattr(client.VaultClient, "get_secret", lambda self, key: '{"host":"vault"}')
    monkeypatch.setattr(client, "_airflow_connection_as_json", lambda key: '{"host":"airflow"}')
    assert client.get_connection_as_json("MY_CONN") == '{"host":"vault"}'


def test_get_connection_as_json_from_airflow(monkeypatch):
    monkeypatch.delenv("MY_CONN", raising=False)
    monkeypatch.setattr(client.VaultClient, "get_secret", lambda self, key: None)
    monkeypatch.setattr(client, "_airflow_connection_as_json", lambda key: '{"host":"airflow"}')
    assert client.get_connection_as_json("MY_CONN") == '{"host":"airflow"}'


def test_get_connection_as_json_raises_when_missing(monkeypatch):
    monkeypatch.delenv("MY_CONN", raising=False)
    monkeypatch.setattr(client.VaultClient, "get_secret", lambda self, key: None)
    monkeypatch.setattr(client, "_airflow_connection_as_json", lambda key: (_ for _ in ()).throw(ImportError()))
    with pytest.raises(ValueError, match="MY_CONN"):
        client.get_connection_as_json("MY_CONN")


def test_get_secret_parses_json(monkeypatch):
    monkeypatch.setattr(client, "get_connection_as_json", lambda _: '{"a": 1}')
    assert client.get_secret("X") == {"a": 1}


def test_get_secret_raises_on_invalid_json(monkeypatch):
    monkeypatch.setattr(client, "get_connection_as_json", lambda _: "not-json")
    with pytest.raises(ValueError, match="не является корректным JSON"):
        client.get_secret("X")


def test_get_connection_as_json_test_from_dir_path(tmp_path: Path):
    file = tmp_path / "BOT.json"
    file.write_text('{"x": 1}', encoding="utf-8")
    assert client.get_connection_as_json_test("BOT", dir_path=str(tmp_path)) == '{"x": 1}'


def test_get_connection_as_json_test_from_cwd(monkeypatch, tmp_path: Path):
    file = tmp_path / "BOT.json"
    file.write_text('{"x": 2}', encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    assert client.get_connection_as_json_test("BOT") == '{"x": 2}'


def test_get_connection_as_json_test_not_found(tmp_path: Path):
    with pytest.raises(FileNotFoundError, match="BOT.json"):
        client.get_connection_as_json_test("BOT", dir_path=str(tmp_path))


def test_get_secret_test_parses_json(monkeypatch):
    monkeypatch.setattr(client, "get_connection_as_json_test", lambda conn_id, dir_path=None: '{"a": 2}')
    assert client.get_secret_test("X") == {"a": 2}


def test_get_secret_test_raises_on_invalid_json(monkeypatch):
    monkeypatch.setattr(client, "get_connection_as_json_test", lambda conn_id, dir_path=None: "bad")
    with pytest.raises(ValueError, match="не является корректным JSON"):
        client.get_secret_test("X")
