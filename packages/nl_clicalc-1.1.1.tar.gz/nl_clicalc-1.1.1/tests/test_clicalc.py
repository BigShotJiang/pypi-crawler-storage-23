"""Tests for nl-calc."""

import pytest

from nl_calc import evaluate, EvaluationError, UnitValue
from nl_calc.normalize import run, NORMALIZE, PATTERNS, check_if_number


class TestEvaluator:
    """Tests for the evaluator module."""
    
    def test_basic_arithmetic(self):
        """Test basic arithmetic operations."""
        result = evaluate("5 + 3")
        assert result == 8 or (isinstance(result, UnitValue) and result.value == 8)
    
    def test_order_of_operations(self):
        """Test order of operations."""
        result = evaluate("2 + 3 * 4")
        assert result == 14 or (isinstance(result, UnitValue) and result.value == 14)
    
    def test_trigonometric_functions(self):
        """Test trigonometric functions."""
        assert abs(evaluate("sin(0)") - 0.0) < 1e-10
        assert abs(evaluate("cos(0)") - 1.0) < 1e-10
        assert abs(evaluate("tan(0)") - 0.0) < 1e-10
    
    def test_constants(self):
        """Test mathematical constants."""
        assert abs(evaluate("pi") - 3.141592653589793) < 1e-10
        assert abs(evaluate("e") - 2.718281828459045) < 1e-10
    
class TestUnitConversions:
    """Tests for unit conversions using the run function."""
    
    def test_length_conversion(self):
        """Test length unit conversions."""
        from io import StringIO
        import sys
        
        captured = StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        run("30m + 100ft", NORMALIZE, PATTERNS)
        sys.stdout = old_stdout
        output = captured.getvalue()
        assert "m" in output
    
    def test_time_conversion(self):
        """Test time unit conversions."""
        from io import StringIO
        import sys
        
        captured = StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        run("1h + 30min", NORMALIZE, PATTERNS)
        sys.stdout = old_stdout
        output = captured.getvalue()
        assert "h" in output
    
    def test_data_conversion(self):
        """Test data storage unit conversions."""
        from io import StringIO
        import sys
        
        captured = StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        run("1GB + 500MB", NORMALIZE, PATTERNS)
        sys.stdout = old_stdout
        output = captured.getvalue()
        assert "GB" in output
    
    def test_mixed_conversion(self):
        """Test mixed unit operations."""
        from io import StringIO
        import sys
        
        captured = StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        run("(30m+100ft)/2", NORMALIZE, PATTERNS)
        sys.stdout = old_stdout
        output = captured.getvalue()
        assert "m" in output
    
    def test_invalid_expression(self):
        """Test that invalid expressions raise errors."""
        with pytest.raises(EvaluationError):
            evaluate("import os")
    
    def test_power_operations(self):
        """Test power operations."""
        result = evaluate("2 ** 3")
        assert result == 8 or (isinstance(result, UnitValue) and result.value == 8)
        result = evaluate("4 ** 0.5")
        assert result == 2 or (isinstance(result, UnitValue) and result.value == 2)
    
    def test_negative_numbers(self):
        """Test negative numbers."""
        result = evaluate("-5 + 3")
        # Note: -5 + 3 in Python evaluates to -2, but depending on order might be different
        # Just verify it's a valid number
        assert isinstance(result, (int, float, UnitValue))


class TestNormalize:
    """Tests for the normalize module."""
    
    def test_check_if_number_integer(self):
        """Test checking if token is an integer."""
        result = check_if_number("42")
        assert result["bool"] is True
        assert result["converted"] == 42
    
    def test_check_if_number_float(self):
        """Test checking if token is a float."""
        result = check_if_number("3.14")
        assert result["bool"] is True
        assert result["converted"] == 3.14
    
    def test_check_if_number_with_unit(self):
        """Test checking if token has a unit."""
        result = check_if_number("50m")
        assert result["bool"] is True
        assert result["converted"] == 50
    
    def test_check_if_number_invalid(self):
        """Test checking invalid number."""
        result = check_if_number("abc")
        assert result["bool"] is False
    
    def test_natural_language_numbers(self):
        """Test natural language number conversion."""
        run("five plus three", NORMALIZE, PATTERNS)
        # Just check it doesn't error


class TestCLI:
    """Tests for CLI functionality."""
    
    def test_help_flag(self):
        """Test that help flag works."""
        from nl_calc.normalize import print_help
        # Just verify it doesn't error
        print_help()
    
    def test_empty_expression(self):
        """Test empty expression shows help."""
        from nl_calc.normalize import main
        import sys
        sys.argv = ["nl_calc"]
        main()


class TestUnitValue:
    """Tests for UnitValue class."""
    
    def test_creation(self):
        """Test creating UnitValue."""
        uv = UnitValue(5, "m")
        assert uv.value == 5
        assert uv.unit == "m"
    
    def test_repr(self):
        """Test string representation."""
        uv = UnitValue(5, "m")
        assert repr(uv) == "5 m"
    
    def test_addition_same_unit(self):
        """Test adding same units."""
        uv1 = UnitValue(5, "m")
        uv2 = UnitValue(3, "m")
        result = uv1 + uv2
        assert result.value == 8
        assert result.unit == "m"
    
    def test_addition_different_unit(self):
        """Test adding different units."""
        uv1 = UnitValue(1, "m")
        uv2 = UnitValue(100, "cm")
        result = uv1 + uv2
        assert result.unit == "m"
        assert abs(result.value - 2) < 1e-10
    
    def test_addition_incompatible_units(self):
        """Test adding incompatible units raises ValueError."""
        uv1 = UnitValue(30, "mi")
        uv2 = UnitValue(30, "gal")
        with pytest.raises(ValueError):
            uv1 + uv2
    
    def test_subtraction_incompatible_units(self):
        """Test subtracting incompatible units raises ValueError."""
        uv1 = UnitValue(30, "m")
        uv2 = UnitValue(10, "kg")
        with pytest.raises(ValueError):
            uv1 - uv2
    
    def test_addition_compatible_units(self):
        """Test adding compatible units (same category)."""
        uv1 = UnitValue(30, "mi")
        uv2 = UnitValue(30, "m")
        result = uv1 + uv2
        assert result.unit in ("mi", "m")
        assert result.value > 30


class TestPhysicalConstants:
    """Tests for physical constants."""
    
    def test_avogadro(self):
        """Test Avogadro constant."""
        # Use evaluate which needs preprocessing
        from io import StringIO
        import sys
        
        captured = StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        run("5 times avogadro", NORMALIZE, PATTERNS)
        sys.stdout = old_stdout
        output = captured.getvalue()
        assert "na" in output.lower() or "avogadro" in output.lower()
    
    def test_speed_of_light(self):
        """Test speed of light."""
        result = evaluate("c")
        assert result == 299792458
    
    def test_boltzmann(self):
        """Test Boltzmann constant."""
        result = evaluate("k")
        assert abs(result - 1.380649e-23) < 1e-30
    
    def test_planck(self):
        """Test Planck constant."""
        result = evaluate("h")
        assert abs(result - 6.62607015e-34) < 1e-40


class TestPyCalcApp:
    """Tests for PyCalcApp class."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if isinstance(result, UnitValue):
            return result.value
        return result
    
    def test_basic_calculate(self):
        """Test basic calculation."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        result = app.calculate("5 + 3")
        assert self._get_value(result) == 8
    
    def test_natural_language(self):
        """Test natural language input."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        result = app.calculate("five plus three")
        assert self._get_value(result) == 8
    
    def test_caching(self):
        """Test that caching works."""
        from nl_calc import PyCalcApp
        app = PyCalcApp(cache_size=10)
        
        # First call
        result1 = app.calculate("5 + 3")
        assert app.cache_size == 1
        
        # Second call should use cache
        result2 = app.calculate("5 + 3")
        assert app.cache_size == 1
        assert self._get_value(result1) == self._get_value(result2)
    
    def test_cache_clear(self):
        """Test cache clearing."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        app.calculate("5 + 3")
        assert app.cache_size == 1
        app.clear_cache()
        assert app.cache_size == 0
    
    def test_cache_disabled(self):
        """Test with caching disabled."""
        from nl_calc import PyCalcApp
        app = PyCalcApp(enable_cache=False)
        app.calculate("5 + 3")
        assert app.cache_size == 0
    
    def test_register_constant(self):
        """Test registering custom constant."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        app.register_constant("myconst", 42)
        result = app.calculate("myconst")
        assert self._get_value(result) == 42
    
    def test_register_function(self):
        """Test registering custom function."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        app.register_function("double", lambda x: x * 2)
        result = app.calculate("double(5)")
        assert self._get_value(result) == 10
    
    def test_instance_isolation_constants(self):
        """Test that instances have isolated constants."""
        from nl_calc import PyCalcApp
        app1 = PyCalcApp()
        app2 = PyCalcApp()
        
        app1.register_constant("myconst", 42)
        app2.register_constant("myconst", 100)
        
        result1 = app1.calculate("myconst")
        result2 = app2.calculate("myconst")
        
        assert self._get_value(result1) == 42
        assert self._get_value(result2) == 100
    
    def test_instance_isolation_functions(self):
        """Test that instances have isolated functions."""
        from nl_calc import PyCalcApp
        app1 = PyCalcApp()
        app2 = PyCalcApp()
        
        app1.register_function("myfunc", lambda x: x * 2)
        app2.register_function("myfunc", lambda x: x * 3)
        
        result1 = app1.calculate("myfunc(5)")
        result2 = app2.calculate("myfunc(5)")
        
        assert self._get_value(result1) == 10
        assert self._get_value(result2) == 15
    
    def test_unit_calculations(self):
        """Test unit calculations in PyCalcApp."""
        from nl_calc import PyCalcApp
        app = PyCalcApp()
        result = app.calculate("30m + 100ft")
        assert hasattr(result, 'unit') or 'm' in str(result)


class TestAsyncFunctions:
    """Tests for async evaluation functions."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if isinstance(result, UnitValue):
            return result.value
        return result
    
    def test_evaluate_async(self):
        """Test async evaluation."""
        import asyncio
        from nl_calc import evaluate_async
        
        async def run_test():
            result = await evaluate_async("5 + 3")
            return result
        
        result = asyncio.run(run_test())
        assert self._get_value(result) == 8
    
    def test_nl_calc_app_async(self):
        """Test PyCalcApp async calculation."""
        import asyncio
        from nl_calc import PyCalcApp
        
        app = PyCalcApp()
        
        async def run_test():
            result = await app.calculate_async("5 + 3")
            return result
        
        result = asyncio.run(run_test())
        assert self._get_value(result) == 8


class TestCaching:
    """Tests for caching functions."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if isinstance(result, UnitValue):
            return result.value
        return result
    
    def test_evaluate_cached(self):
        """Test evaluate_cached function."""
        from nl_calc import evaluate_cached
        
        result = evaluate_cached("5 + 3")
        assert self._get_value(result) == 8
        
        # Second call should use cache
        result2 = evaluate_cached("5 + 3")
        assert self._get_value(result2) == 8
    
    def test_evaluate_cached_natural_language(self):
        """Test evaluate_cached with natural language."""
        from nl_calc import evaluate_cached
        
        result = evaluate_cached("five plus three")
        assert self._get_value(result) == 8


class TestTimeout:
    """Tests for timeout functionality."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if isinstance(result, UnitValue):
            return result.value
        return result
    
    def test_evaluate_with_timeout_success(self):
        """Test evaluate_with_timeout with fast expression."""
        from nl_calc import evaluate_with_timeout
        
        result = evaluate_with_timeout("5 + 3", timeout=1.0)
        assert self._get_value(result) == 8
    
    def test_evaluate_with_timeout_natural_language(self):
        """Test evaluate_with_timeout with natural language."""
        from nl_calc import evaluate_with_timeout
        
        result = evaluate_with_timeout("five plus three", timeout=1.0)
        assert self._get_value(result) == 8
    
    def test_timeout_error_raised(self):
        """Test that TimeoutError can be raised."""
        from nl_calc import TimeoutError
        
        # Just test that the exception class exists and is importable
        assert issubclass(TimeoutError, Exception)


class TestComplexNumbers:
    """Tests for complex number functionality."""
    
    def test_imaginary_unit(self):
        """Test imaginary unit i."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("i * i")
        if hasattr(result, 'value'):
            result = result.value
        assert abs(result.real + 1) < 1e-10
        assert abs(result.imag) < 1e-10
    
    def test_complex_literal(self):
        """Test complex literals."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("3 + 4i")
        if hasattr(result, 'value'):
            result = result.value
        assert abs(result.real - 3) < 1e-10
        assert abs(result.imag - 4) < 1e-10
    
    def test_sqrt_negative(self):
        """Test sqrt of negative number."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("sqrt(-1)")
        if hasattr(result, 'value'):
            result = result.value
        assert abs(result.imag - 1) < 1e-10
    
    def test_abs_complex(self):
        """Test abs of complex number."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("abs(3+4i)")
        if hasattr(result, 'value'):
            result = result.value
        assert abs(result - 5) < 1e-10
    
    def test_conj(self):
        """Test complex conjugate."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("conj(3+4i)")
        if hasattr(result, 'value'):
            result = result.value
        assert abs(result.real - 3) < 1e-10
        assert abs(result.imag + 4) < 1e-10


class TestBitwise:
    """Tests for bitwise operations."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if hasattr(result, 'value'):
            return result.value
        return result
    
    def test_bitand(self):
        """Test bitwise AND."""
        from nl_calc import evaluate_raw
        
        assert self._get_value(evaluate_raw("5 AND 3")) == 1
        assert self._get_value(evaluate_raw("5 & 3")) == 1
    
    def test_bitor(self):
        """Test bitwise OR."""
        from nl_calc import evaluate_raw
        
        assert self._get_value(evaluate_raw("5 OR 3")) == 7
        assert self._get_value(evaluate_raw("5 | 3")) == 7
    
    def test_bitxor_word(self):
        """Test bitwise XOR using word."""
        from nl_calc import evaluate_raw
        
        assert self._get_value(evaluate_raw("5 XOR 3")) == 6
    
    def test_bitnot(self):
        """Test bitwise NOT."""
        from nl_calc import evaluate_raw
        
        assert self._get_value(evaluate_raw("~5")) == -6
    
    def test_shifts(self):
        """Test bit shifts."""
        from nl_calc import evaluate_raw
        
        assert self._get_value(evaluate_raw("5 << 2")) == 20
        assert self._get_value(evaluate_raw("5 >> 1")) == 2
    
    def test_base_prefixes(self):
        """Test base prefixes."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("0xFF") == 255
        assert evaluate_raw("0b1010") == 10
        assert evaluate_raw("0o777") == 511


class TestCombinatorics:
    """Tests for combinatorics functions."""
    
    def test_perm(self):
        """Test permutations."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("perm(5, 3)") == 60
        assert evaluate_raw("nPr(5, 3)") == 60
    
    def test_comb(self):
        """Test combinations."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("comb(5, 3)") == 10
        assert evaluate_raw("nCr(5, 3)") == 10
    
    def test_lcm(self):
        """Test LCM."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("lcm(12, 18)") == 36
        assert evaluate_raw("lcm(12, 18, 24)") == 72


class TestPrimes:
    """Tests for prime functions."""
    
    def test_isprime(self):
        """Test prime check."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("isprime(17)") == True
        assert evaluate_raw("isprime(18)") == False
    
    def test_primefactors(self):
        """Test prime factorization."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("primefactors(84)")
        assert "2" in result and "3" in result and "7" in result
    
    def test_nextprime(self):
        """Test next prime."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("nextprime(17)") == 19


class TestStatistics:
    """Tests for statistical functions."""
    
    def test_median(self):
        """Test median."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("median(1, 2, 3, 4, 5)") == 3
        assert evaluate_raw("median(1, 2, 3, 4)") == 2.5
    
    def test_mode(self):
        """Test mode."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("mode(1, 2, 2, 3)") == 2
    
    def test_variance(self):
        """Test variance."""
        from nl_calc import evaluate_raw
        
        result = evaluate_raw("variance(1, 2, 3, 4, 5)")
        assert abs(result - 2.0) < 1e-10


class TestPercentage:
    """Tests for percentage functionality."""
    
    def test_percent_literal(self):
        """Test percentage literal."""
        from nl_calc import evaluate_raw
        
        assert abs(evaluate_raw("50%") - 0.5) < 1e-10
        assert abs(evaluate_raw("25%") - 0.25) < 1e-10
    
    def test_percentof(self):
        """Test percentof function."""
        from nl_calc import evaluate_raw
        
        assert evaluate_raw("percentof(20, 100)") == 20.0


class TestRandom:
    """Tests for random functions."""
    
    def test_random_range(self):
        """Test random is in range."""
        from nl_calc import evaluate_raw
        
        evaluate_raw("seed(42)")
        result = evaluate_raw("random()")
        assert 0 <= result < 1
    
    def test_randint_range(self):
        """Test randint is in range."""
        from nl_calc import evaluate_raw
        
        evaluate_raw("seed(42)")
        result = evaluate_raw("randint(1, 100)")
        assert 1 <= result <= 100


class TestMemory:
    """Tests for memory functions."""
    
    def test_store_recall(self):
        """Test store and recall."""
        from nl_calc import evaluate_raw, memory_clear
        
        memory_clear()
        result = evaluate_raw("store(42)")
        assert result == 42
        
        result = evaluate_raw("recall()")
        assert result == 42


class TestVariables:
    """Tests for variable functionality."""
    
    def _get_value(self, result):
        """Extract numeric value from result."""
        if hasattr(result, 'value'):
            return result.value
        return result
    
    def test_setvar_getvar(self):
        """Test setvar and getvar."""
        from nl_calc import evaluate_raw, clearvars
        
        clearvars()
        result = evaluate_raw('setvar("x", 10)')
        assert self._get_value(result) == 10
        
        result = evaluate_raw("x + 5")
        assert self._get_value(result) == 15


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
