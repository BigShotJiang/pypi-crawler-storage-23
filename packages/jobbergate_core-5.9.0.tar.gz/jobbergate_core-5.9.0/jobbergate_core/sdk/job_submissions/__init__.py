from jobbergate_core.sdk.job_submissions.app import JobSubmissions

__all__ = [
    "JobSubmissions",
]
