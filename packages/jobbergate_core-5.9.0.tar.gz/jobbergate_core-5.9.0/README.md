# Jobbergate Core

Jobbergate-core is a sub-project that contains the key components and logic that is shared among all other sub-projects
(CLI, API, and Agent). Additionally, jobbergate-core exists to support custom automation built on top of Jobbergate.

## License

* [MIT](LICENSE)

## Copyright

* Copyright (c) 2023 OmniVector Solutions <info@omnivector.solutions>
