"""Models for duckdb connector."""
