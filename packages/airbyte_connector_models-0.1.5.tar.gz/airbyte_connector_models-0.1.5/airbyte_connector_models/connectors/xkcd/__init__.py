"""Models for xkcd connector."""
