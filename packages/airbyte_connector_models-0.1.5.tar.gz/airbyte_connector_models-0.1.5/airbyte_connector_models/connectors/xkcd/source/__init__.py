"""Models for source-xkcd."""
