"""Models for pokeapi connector."""
