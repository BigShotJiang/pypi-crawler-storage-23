"""Models for airbyte connector."""
