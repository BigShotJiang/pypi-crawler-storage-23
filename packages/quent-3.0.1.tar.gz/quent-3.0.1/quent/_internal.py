__QUENT_INTERNAL__ = object()
