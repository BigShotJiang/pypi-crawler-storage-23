# Copyright (C) 2024,2025,2026 Kian-Meng Ang

# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option) any
# later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
# details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.


import argparse
from pathlib import Path

import fotolab.subcommands.auto


def test_auto_subcommand_single_image(cli_runner, image_file):
    img_path = image_file("sample.png")
    ret = cli_runner("auto", str(img_path))
    assert ret.returncode == 0
    assert "output/sample.png" in ret.files_created


def test_auto_subcommand_with_title(cli_runner, image_file):
    img_path = image_file("sample.png")
    ret = cli_runner("auto", str(img_path), "--title", "My Testing")
    assert ret.returncode == 0
    assert "output/my_testing.png" in ret.files_created


def test_auto_subcommand_multi_image(cli_runner, image_file):
    img_path1 = image_file("sample.png")
    img_path2 = Path(img_path1.parent, "sample2.png")
    img_path2.write_bytes(img_path1.read_bytes())

    ret = cli_runner(
        "auto",
        str(img_path1),
        str(img_path2),
        "--title",
        "Batch Job",
    )
    assert ret.returncode == 0

    assert "output/batch_job_sample.png" in ret.files_created
    assert "output/batch_job_sample2.png" in ret.files_created
    assert "output/batch_job.gif" in ret.files_created


def test_auto_subcommand_no_title_multi(cli_runner, image_file):
    img_path1 = image_file("sample.png")
    img_path2 = Path(img_path1.parent, "sample2.png")
    img_path2.write_bytes(img_path1.read_bytes())

    ret = cli_runner("auto", str(img_path1), str(img_path2))
    assert ret.returncode == 0

    assert "output/sample.png" in ret.files_created
    assert "output/sample2.png" in ret.files_created
    assert "output/animation.gif" in ret.files_created


def test_auto_subcommand_open_single(image_file, monkeypatch):
    mock_open = []
    monkeypatch.setattr(
        fotolab.subcommands.auto,
        "open_image",
        mock_open.append,
    )

    img_path = image_file("sample.png")
    args = argparse.Namespace(
        image_paths=[str(img_path)],
        open=True,
        title=None,
        watermark="kianmeng.org",
        output_dir="output",
        overwrite=False,
    )

    fotolab.subcommands.auto.run(args)
    assert len(mock_open) == 1


def test_auto_subcommand_open_multi(image_file, monkeypatch):
    mock_open = []
    monkeypatch.setattr(
        fotolab.subcommands.auto,
        "open_image",
        mock_open.append,
    )

    img_path1 = image_file("sample.png")
    img_path2 = Path(img_path1.parent, "sample2.png")
    img_path2.write_bytes(img_path1.read_bytes())

    args = argparse.Namespace(
        image_paths=[str(img_path1), str(img_path2)],
        open=True,
        title=None,
        watermark="kianmeng.org",
        output_dir="output",
        overwrite=False,
    )

    fotolab.subcommands.auto.run(args)
    assert len(mock_open) == 1
    assert "animation.gif" in str(mock_open[0])
