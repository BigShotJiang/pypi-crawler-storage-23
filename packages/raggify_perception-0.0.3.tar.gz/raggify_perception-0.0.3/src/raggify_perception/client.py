from __future__ import annotations

import asyncio
import threading
from dataclasses import dataclass
from typing import Callable, Optional

from raggify_perception.core.constants import (
    DEFAULT_ASR_PROMPT,
    DEFAULT_AUDIO_CAPTION_PROMPT,
    DEFAULT_IMAGE_CAPTION_PROMPT,
    DEFAULT_OCR_PROMPT,
    DEFAULT_VIDEO_CAPTION_PROMPT,
    MEDIA_TYPE_AUDIO,
    MEDIA_TYPE_IMAGE,
    MEDIA_TYPE_TEXT,
    MEDIA_TYPE_VIDEO,
    NORMALIZED_AUDIO_MIME_TYPE,
    NORMALIZED_IMAGE_MIME_TYPE,
    NORMALIZED_VIDEO_MIME_TYPE,
    PDF_MIME_TYPE,
)
from raggify_perception.core.settings import Settings, get_settings
from raggify_perception.domain.media import (
    MediaInput,
    MediaPayload,
    parse_media_input,
    to_data_url,
)
from raggify_perception.domain.pdf_pages import PDFPageImage, split_pdf_to_page_images
from raggify_perception.domain.result_utils import (
    normalize_model_output_text,
    strip_think_blocks,
)
from raggify_perception.infra.ffmpeg_io import (
    normalize_audio_to_mp3_bytes,
    normalize_image_to_png_bytes,
    normalize_video_to_mp4_bytes,
)
from raggify_perception.infra.openai_chat_backend import (
    AsyncOpenAIChatBackend,
    OpenAIChatBackend,
)


@dataclass(frozen=True)
class CapabilityConfig:
    """Capability routing and preprocessing configuration.

    Args:
        model (str): Model name resolved by perception settings.
        prompt (str): Fixed prompt controlled by perception.
        media_type (str): OpenAI content type such as `image_url`.
        input_mime (str): Default MIME for raw bytes input.
        normalizer (Callable[[bytes, str], bytes]): Media normalization function.
        postprocessor (Callable[[str, str], str]): Output postprocessor function.
    """

    model: str
    prompt: str
    media_type: str
    input_mime: str
    normalizer: Callable[[bytes, str], bytes]
    postprocessor: Callable[[str, str], str]


@dataclass(frozen=True)
class RequestOptions:
    """Per-request transport options for external completion calls.

    Args:
        timeout_sec (float): Request timeout in seconds.
        max_retries (int): Number of retries after the first attempt.
        retry_backoff_sec (list[float]): Retry wait seconds list.
    """

    timeout_sec: float
    max_retries: int
    retry_backoff_sec: list[float]


@dataclass(frozen=True)
class PDFResultItem:
    """Single PDF page processing result.

    Args:
        page_number (int): One-based page number.
        file_name (str): Synthetic file name with `001` suffix.
        content (str): OCR or caption result.
    """

    page_number: int
    file_name: str
    content: str


def _postprocess_passthrough(text: str, prompt: str) -> str:
    """Return normalized text without additional filtering.

    Args:
        text (str): Generated text.
        prompt (str): Prompt text (unused).

    Returns:
        str: Output text.
    """

    _ = prompt
    return text


def _postprocess_ocr(text: str, prompt: str) -> str:
    """Normalize OCR output and drop prompt echoes.

    Args:
        text (str): Generated text.
        prompt (str): OCR prompt.

    Returns:
        str: OCR text.
    """

    if not text:
        return ""
    if text.strip().casefold() == prompt.strip().casefold():
        return ""
    return text


def _is_repetitive_output(text: str) -> bool:
    """Detect repetitive low-information output.

    Args:
        text (str): Generated text.

    Returns:
        bool: True when output is mostly repeated tokens.
    """

    normalized = " ".join(text.split())
    if not normalized:
        return False

    tokens = [
        token.strip(".,!?;:\"'()[]{}").casefold()
        for token in normalized.split(" ")
        if token.strip(".,!?;:\"'()[]{}")
    ]
    if len(tokens) < 8:
        return False

    counts: dict[str, int] = {}
    for token in tokens:
        counts[token] = counts.get(token, 0) + 1
    return max(counts.values()) / len(tokens) >= 0.6


def _postprocess_asr(text: str, prompt: str) -> str:
    """Normalize ASR output and drop prompt echo artifacts.

    Args:
        text (str): Generated text.
        prompt (str): ASR prompt.

    Returns:
        str: ASR text.
    """

    if not text:
        return ""
    normalized_text = text.strip().casefold()
    normalized_prompt = prompt.strip().casefold()
    if normalized_text == normalized_prompt:
        return ""
    if normalized_text.count(normalized_prompt) >= 2:
        return ""
    if _is_repetitive_output(text):
        return ""
    return text


def _resolve_request_options(
    settings: Settings,
    timeout_sec: Optional[float],
    max_retries: Optional[int],
    retry_backoff_sec: Optional[list[float]],
) -> RequestOptions:
    """Resolve request options from explicit parameters or settings defaults.

    Args:
        settings (Settings): Runtime settings.
        timeout_sec (Optional[float]): Per-call timeout override.
        max_retries (Optional[int]): Per-call retry count override.
        retry_backoff_sec (Optional[list[float]]): Per-call backoff override.

    Returns:
        RequestOptions: Resolved options.
    """

    resolved_timeout_sec = (
        timeout_sec
        if timeout_sec is not None
        else float(settings.request_timeout_seconds)
    )
    resolved_max_retries = (
        max_retries if max_retries is not None else settings.max_retries
    )
    resolved_retry_backoff_sec = (
        retry_backoff_sec
        if retry_backoff_sec is not None
        else settings.retry_backoff_sec
    )
    return RequestOptions(
        timeout_sec=resolved_timeout_sec,
        max_retries=resolved_max_retries,
        retry_backoff_sec=list(resolved_retry_backoff_sec),
    )


class PerceptionClient:
    """Synchronous perception library client."""

    def __init__(self, settings: Optional[Settings] = None) -> None:
        """Create a synchronous client.

        Args:
            settings (Optional[Settings], optional): Runtime settings. Defaults to None.
        """

        self.settings = settings if settings is not None else get_settings()
        self.backend = OpenAIChatBackend(self.settings)
        self._semaphore = threading.BoundedSemaphore(
            self.settings.batch_max_concurrency
        )

    def get_ocr_text(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Extract OCR text from image media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: OCR result text.
        """

        config = CapabilityConfig(
            model=self.settings.model_ocr,
            prompt=DEFAULT_OCR_PROMPT,
            media_type=MEDIA_TYPE_IMAGE,
            input_mime=NORMALIZED_IMAGE_MIME_TYPE,
            normalizer=normalize_image_to_png_bytes,
            postprocessor=_postprocess_ocr,
        )
        return self._run_capability(
            media,
            config,
            file_name=file_name,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_image_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate image caption text.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        config = CapabilityConfig(
            model=self.settings.model_caption_image,
            prompt=DEFAULT_IMAGE_CAPTION_PROMPT,
            media_type=MEDIA_TYPE_IMAGE,
            input_mime=NORMALIZED_IMAGE_MIME_TYPE,
            normalizer=normalize_image_to_png_bytes,
            postprocessor=_postprocess_passthrough,
        )
        return self._run_capability(
            media,
            config,
            file_name=file_name,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_asr_text(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Transcribe speech from audio media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: ASR text.
        """

        config = CapabilityConfig(
            model=self.settings.model_asr,
            prompt=DEFAULT_ASR_PROMPT,
            media_type=MEDIA_TYPE_AUDIO,
            input_mime=NORMALIZED_AUDIO_MIME_TYPE,
            normalizer=normalize_audio_to_mp3_bytes,
            postprocessor=_postprocess_asr,
        )
        return self._run_capability(
            media,
            config,
            file_name=file_name,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_audio_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate caption text from audio media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        config = CapabilityConfig(
            model=self.settings.model_caption_audio,
            prompt=DEFAULT_AUDIO_CAPTION_PROMPT,
            media_type=MEDIA_TYPE_AUDIO,
            input_mime=NORMALIZED_AUDIO_MIME_TYPE,
            normalizer=normalize_audio_to_mp3_bytes,
            postprocessor=_postprocess_passthrough,
        )
        return self._run_capability(
            media,
            config,
            file_name=file_name,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_video_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate caption text from video media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        config = CapabilityConfig(
            model=self.settings.model_caption_video,
            prompt=DEFAULT_VIDEO_CAPTION_PROMPT,
            media_type=MEDIA_TYPE_VIDEO,
            input_mime=NORMALIZED_VIDEO_MIME_TYPE,
            normalizer=normalize_video_to_mp4_bytes,
            postprocessor=_postprocess_passthrough,
        )
        return self._run_capability(
            media,
            config,
            file_name=file_name,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_pdf_ocr(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> list[PDFResultItem]:
        """Extract OCR text from each PDF page.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            list[PDFResultItem]: Page-level OCR results.
        """

        pages = self._split_pdf(media, file_name)
        return self._run_pdf_pages(
            pages=pages,
            model=self.settings.model_ocr_pdf,
            prompt=DEFAULT_OCR_PROMPT,
            postprocessor=_postprocess_ocr,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def get_pdf_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> list[PDFResultItem]:
        """Generate caption text from each PDF page.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            list[PDFResultItem]: Page-level caption results.
        """

        pages = self._split_pdf(media, file_name)
        return self._run_pdf_pages(
            pages=pages,
            model=self.settings.model_caption_pdf,
            prompt=DEFAULT_IMAGE_CAPTION_PROMPT,
            postprocessor=_postprocess_passthrough,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def _split_pdf(
        self, media: MediaInput, file_name: Optional[str]
    ) -> list[PDFPageImage]:
        """Split input PDF media into page images.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str]): Optional source file name.

        Returns:
            list[PDFPageImage]: Split PDF pages.
        """

        payload = parse_media_input(media, PDF_MIME_TYPE, file_name=file_name)
        effective_file_name = file_name if file_name is not None else payload.file_name
        return split_pdf_to_page_images(
            pdf_bytes=payload.data,
            original_file_name=effective_file_name,
            max_pages=self.settings.pdf_max_pages,
        )

    def _run_pdf_pages(
        self,
        pages: list[PDFPageImage],
        model: str,
        prompt: str,
        postprocessor: Callable[[str, str], str],
        request_options: RequestOptions,
    ) -> list[PDFResultItem]:
        """Run image completion for rendered PDF pages.

        Args:
            pages (list[PDFPageImage]): Rendered pages.
            model (str): External model.
            prompt (str): Fixed prompt.
            postprocessor (Callable[[str, str], str]): Output postprocessor.
            request_options (RequestOptions): Request options for external completion.

        Returns:
            list[PDFResultItem]: Page-level results.
        """

        results: list[PDFResultItem] = []
        for page in pages:
            image_payload = MediaPayload(
                mime=NORMALIZED_IMAGE_MIME_TYPE,
                data=normalize_image_to_png_bytes(
                    page.image_bytes, self.settings.ffmpeg_bin
                ),
                file_name=page.file_name,
            )
            content = self._complete(
                model=model,
                media_type=MEDIA_TYPE_IMAGE,
                prompt=prompt,
                payload=image_payload,
                request_options=request_options,
            )
            results.append(
                PDFResultItem(
                    page_number=page.page_number,
                    file_name=page.file_name,
                    content=postprocessor(content, prompt),
                )
            )
        return results

    def _run_capability(
        self,
        media: MediaInput,
        config: CapabilityConfig,
        file_name: Optional[str] = None,
        request_options: Optional[RequestOptions] = None,
    ) -> str:
        """Run a capability pipeline from media parsing to output normalization.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            config (CapabilityConfig): Capability configuration.
            file_name (Optional[str], optional): Optional source file name. Defaults to None.
            request_options (Optional[RequestOptions], optional): Request options.
                Defaults to None.

        Returns:
            str: Final normalized output.
        """

        payload = parse_media_input(media, config.input_mime, file_name=file_name)
        normalized_payload = MediaPayload(
            mime=config.input_mime,
            data=config.normalizer(payload.data, self.settings.ffmpeg_bin),
            file_name=payload.file_name,
        )
        resolved_request_options = (
            request_options
            if request_options is not None
            else _resolve_request_options(self.settings, None, None, None)
        )
        text = self._complete(
            model=config.model,
            media_type=config.media_type,
            prompt=config.prompt,
            payload=normalized_payload,
            request_options=resolved_request_options,
        )
        return config.postprocessor(text, config.prompt)

    def _complete(
        self,
        model: str,
        media_type: str,
        prompt: str,
        payload: MediaPayload,
        request_options: RequestOptions,
    ) -> str:
        """Call external chat completion for a single media payload.

        Args:
            model (str): External model.
            media_type (str): OpenAI media type block.
            prompt (str): Fixed prompt.
            payload (MediaPayload): Media payload.
            request_options (RequestOptions): Request options.

        Returns:
            str: Normalized completion text.
        """

        message = {
            "role": "user",
            "content": [
                {"type": MEDIA_TYPE_TEXT, "text": prompt},
                {"type": media_type, media_type: {"url": to_data_url(payload)}},
            ],
        }
        with self._semaphore:
            raw_text = self.backend.complete(
                model=model,
                messages=[message],
                temperature=self.settings.request_temperature,
                timeout_sec=request_options.timeout_sec,
                max_retries=request_options.max_retries,
                retry_backoff_sec=request_options.retry_backoff_sec,
            )
        return normalize_model_output_text(strip_think_blocks(raw_text))


class AsyncPerceptionClient:
    """Asynchronous perception library client."""

    def __init__(self, settings: Optional[Settings] = None) -> None:
        """Create an asynchronous client.

        Args:
            settings (Optional[Settings], optional): Runtime settings. Defaults to None.
        """

        self.settings = settings if settings is not None else get_settings()
        self.backend = AsyncOpenAIChatBackend(self.settings)
        self._semaphore = asyncio.Semaphore(self.settings.batch_max_concurrency)

    async def aget_ocr_text(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Extract OCR text from image media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: OCR result text.
        """

        return await self._run_capability_async(
            media=media,
            file_name=file_name,
            config=CapabilityConfig(
                model=self.settings.model_ocr,
                prompt=DEFAULT_OCR_PROMPT,
                media_type=MEDIA_TYPE_IMAGE,
                input_mime=NORMALIZED_IMAGE_MIME_TYPE,
                normalizer=normalize_image_to_png_bytes,
                postprocessor=_postprocess_ocr,
            ),
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_image_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate image caption text.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        return await self._run_capability_async(
            media=media,
            file_name=file_name,
            config=CapabilityConfig(
                model=self.settings.model_caption_image,
                prompt=DEFAULT_IMAGE_CAPTION_PROMPT,
                media_type=MEDIA_TYPE_IMAGE,
                input_mime=NORMALIZED_IMAGE_MIME_TYPE,
                normalizer=normalize_image_to_png_bytes,
                postprocessor=_postprocess_passthrough,
            ),
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_asr_text(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Transcribe speech from audio media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: ASR text.
        """

        return await self._run_capability_async(
            media=media,
            file_name=file_name,
            config=CapabilityConfig(
                model=self.settings.model_asr,
                prompt=DEFAULT_ASR_PROMPT,
                media_type=MEDIA_TYPE_AUDIO,
                input_mime=NORMALIZED_AUDIO_MIME_TYPE,
                normalizer=normalize_audio_to_mp3_bytes,
                postprocessor=_postprocess_asr,
            ),
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_audio_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate caption text from audio media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        return await self._run_capability_async(
            media=media,
            file_name=file_name,
            config=CapabilityConfig(
                model=self.settings.model_caption_audio,
                prompt=DEFAULT_AUDIO_CAPTION_PROMPT,
                media_type=MEDIA_TYPE_AUDIO,
                input_mime=NORMALIZED_AUDIO_MIME_TYPE,
                normalizer=normalize_audio_to_mp3_bytes,
                postprocessor=_postprocess_passthrough,
            ),
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_video_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> str:
        """Generate caption text from video media.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            str: Caption text.
        """

        return await self._run_capability_async(
            media=media,
            file_name=file_name,
            config=CapabilityConfig(
                model=self.settings.model_caption_video,
                prompt=DEFAULT_VIDEO_CAPTION_PROMPT,
                media_type=MEDIA_TYPE_VIDEO,
                input_mime=NORMALIZED_VIDEO_MIME_TYPE,
                normalizer=normalize_video_to_mp4_bytes,
                postprocessor=_postprocess_passthrough,
            ),
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_pdf_ocr(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> list[PDFResultItem]:
        """Extract OCR text from each PDF page.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            list[PDFResultItem]: Page-level OCR results.
        """

        pages = await asyncio.to_thread(self._split_pdf, media, file_name)
        return await self._run_pdf_pages_async(
            pages=pages,
            model=self.settings.model_ocr_pdf,
            prompt=DEFAULT_OCR_PROMPT,
            postprocessor=_postprocess_ocr,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    async def aget_pdf_caption(
        self,
        media: MediaInput,
        file_name: Optional[str] = None,
        timeout_sec: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_backoff_sec: Optional[list[float]] = None,
    ) -> list[PDFResultItem]:
        """Generate caption text from each PDF page.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str], optional): Source file name. Defaults to None.
            timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
            max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
            retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

        Returns:
            list[PDFResultItem]: Page-level caption results.
        """

        pages = await asyncio.to_thread(self._split_pdf, media, file_name)
        return await self._run_pdf_pages_async(
            pages=pages,
            model=self.settings.model_caption_pdf,
            prompt=DEFAULT_IMAGE_CAPTION_PROMPT,
            postprocessor=_postprocess_passthrough,
            request_options=_resolve_request_options(
                self.settings,
                timeout_sec,
                max_retries,
                retry_backoff_sec,
            ),
        )

    def _split_pdf(
        self, media: MediaInput, file_name: Optional[str]
    ) -> list[PDFPageImage]:
        """Split input PDF media into page images.

        Args:
            media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
            file_name (Optional[str]): Optional source file name.

        Returns:
            list[PDFPageImage]: Split PDF pages.
        """

        payload = parse_media_input(media, PDF_MIME_TYPE, file_name=file_name)
        effective_file_name = file_name if file_name is not None else payload.file_name
        return split_pdf_to_page_images(
            pdf_bytes=payload.data,
            original_file_name=effective_file_name,
            max_pages=self.settings.pdf_max_pages,
        )

    async def _run_pdf_pages_async(
        self,
        pages: list[PDFPageImage],
        model: str,
        prompt: str,
        postprocessor: Callable[[str, str], str],
        request_options: RequestOptions,
    ) -> list[PDFResultItem]:
        """Run image completion for rendered PDF pages asynchronously.

        Args:
            pages (list[PDFPageImage]): Rendered pages.
            model (str): External model.
            prompt (str): Fixed prompt.
            postprocessor (Callable[[str, str], str]): Output postprocessor.
            request_options (RequestOptions): Request options for external completion.

        Returns:
            list[PDFResultItem]: Page-level results.
        """

        results: list[PDFResultItem] = []
        for page in pages:
            normalized_bytes = await asyncio.to_thread(
                normalize_image_to_png_bytes,
                page.image_bytes,
                self.settings.ffmpeg_bin,
            )
            image_payload = MediaPayload(
                mime=NORMALIZED_IMAGE_MIME_TYPE,
                data=normalized_bytes,
                file_name=page.file_name,
            )
            content = await self._complete_async(
                model=model,
                media_type=MEDIA_TYPE_IMAGE,
                prompt=prompt,
                payload=image_payload,
                request_options=request_options,
            )
            results.append(
                PDFResultItem(
                    page_number=page.page_number,
                    file_name=page.file_name,
                    content=postprocessor(content, prompt),
                )
            )
        return results

    async def _run_capability_async(
        self,
        media: MediaInput,
        config: CapabilityConfig,
        file_name: Optional[str] = None,
        request_options: Optional[RequestOptions] = None,
    ) -> str:
        """Run a capability pipeline asynchronously.

        Args:
            media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
            config (CapabilityConfig): Capability configuration.
            file_name (Optional[str], optional): Optional source file name. Defaults to None.
            request_options (Optional[RequestOptions], optional): Request options.
                Defaults to None.

        Returns:
            str: Final normalized output.
        """

        payload = await asyncio.to_thread(
            parse_media_input, media, config.input_mime, file_name
        )
        normalized_bytes = await asyncio.to_thread(
            config.normalizer,
            payload.data,
            self.settings.ffmpeg_bin,
        )
        normalized_payload = MediaPayload(
            mime=config.input_mime,
            data=normalized_bytes,
            file_name=payload.file_name,
        )
        resolved_request_options = (
            request_options
            if request_options is not None
            else _resolve_request_options(self.settings, None, None, None)
        )
        text = await self._complete_async(
            model=config.model,
            media_type=config.media_type,
            prompt=config.prompt,
            payload=normalized_payload,
            request_options=resolved_request_options,
        )
        return config.postprocessor(text, config.prompt)

    async def _complete_async(
        self,
        model: str,
        media_type: str,
        prompt: str,
        payload: MediaPayload,
        request_options: RequestOptions,
    ) -> str:
        """Call external chat completion for a single media payload.

        Args:
            model (str): External model.
            media_type (str): OpenAI media type block.
            prompt (str): Fixed prompt.
            payload (MediaPayload): Media payload.
            request_options (RequestOptions): Request options.

        Returns:
            str: Normalized completion text.
        """

        message = {
            "role": "user",
            "content": [
                {"type": MEDIA_TYPE_TEXT, "text": prompt},
                {"type": media_type, media_type: {"url": to_data_url(payload)}},
            ],
        }
        async with self._semaphore:
            raw_text = await self.backend.complete(
                model=model,
                messages=[message],
                temperature=self.settings.request_temperature,
                timeout_sec=request_options.timeout_sec,
                max_retries=request_options.max_retries,
                retry_backoff_sec=request_options.retry_backoff_sec,
            )
        return normalize_model_output_text(strip_think_blocks(raw_text))


_default_sync_client: Optional[PerceptionClient] = None
_default_async_client: Optional[AsyncPerceptionClient] = None


def get_default_client() -> PerceptionClient:
    """Get a process-level singleton sync client.

    Returns:
        PerceptionClient: Shared sync client.
    """

    global _default_sync_client
    if _default_sync_client is None:
        _default_sync_client = PerceptionClient()
    return _default_sync_client


def get_default_async_client() -> AsyncPerceptionClient:
    """Get a process-level singleton async client.

    Returns:
        AsyncPerceptionClient: Shared async client.
    """

    global _default_async_client
    if _default_async_client is None:
        _default_async_client = AsyncPerceptionClient()
    return _default_async_client


def get_ocr_text(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Extract OCR text with the default sync client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: OCR text.
    """

    return get_default_client().get_ocr_text(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_image_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate image caption with the default sync client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return get_default_client().get_image_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_asr_text(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Transcribe speech with the default sync client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: ASR text.
    """

    return get_default_client().get_asr_text(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_audio_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate audio caption with the default sync client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return get_default_client().get_audio_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_video_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate video caption with the default sync client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return get_default_client().get_video_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_pdf_ocr(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> list[PDFResultItem]:
    """Extract PDF OCR text with the default sync client.

    Args:
        media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        list[PDFResultItem]: Page-level OCR results.
    """

    return get_default_client().get_pdf_ocr(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


def get_pdf_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> list[PDFResultItem]:
    """Generate PDF captions with the default sync client.

    Args:
        media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        list[PDFResultItem]: Page-level caption results.
    """

    return get_default_client().get_pdf_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_ocr_text(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Extract OCR text with the default async client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: OCR text.
    """

    return await get_default_async_client().aget_ocr_text(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_image_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate image caption with the default async client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return await get_default_async_client().aget_image_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_asr_text(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Transcribe speech with the default async client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: ASR text.
    """

    return await get_default_async_client().aget_asr_text(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_audio_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate audio caption with the default async client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return await get_default_async_client().aget_audio_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_video_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> str:
    """Generate video caption with the default async client.

    Args:
        media (MediaInput): Input media. Accepts raw bytes, base64 data URL string (`data:<mime>;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        str: Caption text.
    """

    return await get_default_async_client().aget_video_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_pdf_ocr(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> list[PDFResultItem]:
    """Extract PDF OCR text with the default async client.

    Args:
        media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        list[PDFResultItem]: Page-level OCR results.
    """

    return await get_default_async_client().aget_pdf_ocr(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )


async def aget_pdf_caption(
    media: MediaInput,
    file_name: Optional[str] = None,
    timeout_sec: Optional[float] = None,
    max_retries: Optional[int] = None,
    retry_backoff_sec: Optional[list[float]] = None,
) -> list[PDFResultItem]:
    """Generate PDF captions with the default async client.

    Args:
        media (MediaInput): PDF input. Accepts PDF bytes, base64 data URL string (`data:application/pdf;base64,...`), or `http/https` URL string.
        file_name (Optional[str], optional): Source file name. Defaults to None.
        timeout_sec (Optional[float], optional): Per-request timeout. Defaults to None.
        max_retries (Optional[int], optional): Per-request retry count. Defaults to None.
        retry_backoff_sec (Optional[list[float]], optional): Per-request retry backoff. Defaults to None.

    Returns:
        list[PDFResultItem]: Page-level caption results.
    """

    return await get_default_async_client().aget_pdf_caption(
        media=media,
        file_name=file_name,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        retry_backoff_sec=retry_backoff_sec,
    )
