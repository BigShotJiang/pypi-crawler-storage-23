from __future__ import annotations

from functools import lru_cache
from typing import Optional

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class Settings(BaseSettings):
    """Perception library settings loaded from environment variables."""

    model_config = SettingsConfigDict(env_prefix="RAGGIFY_PCT_", extra="ignore")

    external_api_base_url: str = "http://localhost:1234/v1"
    external_api_key: Optional[str] = None
    request_timeout_seconds: int = Field(default=30, ge=1, le=300)
    request_temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_backoff_sec: list[float] = Field(default_factory=lambda: [1.0, 2.0, 4.0])

    ffmpeg_bin: str = "ffmpeg"
    pdf_max_pages: int = Field(default=0, ge=0)
    batch_max_concurrency: int = Field(default=1, ge=1, le=32)

    model_ocr: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    model_asr: str = "openai/whisper-small"
    model_caption_image: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    model_caption_audio: str = "MU-NLPC/whisper-small-audio-captioning"
    model_caption_video: str = "MU-NLPC/whisper-small-audio-captioning"
    model_ocr_pdf: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    model_caption_pdf: str = "Qwen/Qwen2.5-VL-7B-Instruct"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load and cache the application settings.

    Returns:
        Settings: Parsed application settings.
    """

    return Settings()
