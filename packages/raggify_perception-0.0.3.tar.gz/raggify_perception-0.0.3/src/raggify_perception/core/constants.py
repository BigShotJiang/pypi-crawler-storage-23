from __future__ import annotations

MODEL_OCR = "perception-ocr"
MODEL_CAPTION_IMAGE = "perception-caption-image"
MODEL_ASR = "perception-asr"
MODEL_CAPTION_AUDIO = "perception-caption-audio"
MODEL_CAPTION_VIDEO = "perception-caption-video"
MODEL_OCR_PDF = "perception-ocr-pdf"
MODEL_CAPTION_PDF = "perception-caption-pdf"

MEDIA_TYPE_TEXT = "text"
MEDIA_TYPE_IMAGE = "image_url"
MEDIA_TYPE_AUDIO = "audio_url"
MEDIA_TYPE_VIDEO = "video_url"

DEFAULT_OCR_PROMPT = (
    "Extract only readable text from the image. "
    "If no readable text is present, return an empty string."
)
DEFAULT_IMAGE_CAPTION_PROMPT = "Describe this image."
DEFAULT_ASR_PROMPT = (
    "Transcribe spoken words only. "
    "If no clear speech is present, return an empty string."
)
DEFAULT_AUDIO_CAPTION_PROMPT = "Describe the sounds in this audio clip."
DEFAULT_VIDEO_CAPTION_PROMPT = "Describe this video."

PDF_MIME_TYPE = "application/pdf"
PDF_DEFAULT_FILE_NAME = "document.pdf"
PDF_PAGE_NUMBER_DIGITS = 3
PDF_PAGE_IMAGE_SUFFIX = ".png"

DEFAULT_HTTP_TIMEOUT_SECONDS = 30
DEFAULT_REQUEST_TEMPERATURE = 0.0

NORMALIZED_IMAGE_MIME_TYPE = "image/png"
NORMALIZED_AUDIO_MIME_TYPE = "audio/mpeg"
NORMALIZED_VIDEO_MIME_TYPE = "video/mp4"

INVALID_DATA_URL_CODE = "invalid_data_url"
INVALID_MEDIA_URL_CODE = "invalid_media_url"
EXTERNAL_API_KEY_MISSING_CODE = "external_api_key_missing"
EXTERNAL_API_ERROR_CODE = "external_api_error"
MEDIA_NORMALIZATION_FAILED_CODE = "media_normalization_failed"
VIDEO_AUDIO_EXTRACTION_FAILED_CODE = "video_audio_extraction_failed"
PDF_PROCESSING_FAILED_CODE = "pdf_processing_failed"
