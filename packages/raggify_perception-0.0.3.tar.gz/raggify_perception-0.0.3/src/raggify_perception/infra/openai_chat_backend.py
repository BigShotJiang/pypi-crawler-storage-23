from __future__ import annotations

import asyncio
import time
from typing import Optional, cast

from openai import AsyncOpenAI, OpenAI
from openai.types.chat import ChatCompletionMessageParam

from raggify_perception.core.constants import (
    EXTERNAL_API_ERROR_CODE,
    EXTERNAL_API_KEY_MISSING_CODE,
)
from raggify_perception.core.errors import PerceptionError
from raggify_perception.core.settings import Settings
from raggify_perception.domain.result_utils import extract_chat_text_content


class OpenAIChatBackend:
    """OpenAI-compatible backend for sync chat completion calls.

    Args:
        settings (Settings): Runtime settings.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        if settings.external_api_key is None:
            raise PerceptionError(
                "external_api_key is required.",
                EXTERNAL_API_KEY_MISSING_CODE,
            )
        self.client = OpenAI(
            api_key=settings.external_api_key,
            base_url=settings.external_api_base_url,
            timeout=float(settings.request_timeout_seconds),
        )

    def complete(
        self,
        model: str,
        messages: list[dict[str, object]],
        temperature: float,
        timeout_sec: float,
        max_retries: int,
        retry_backoff_sec: list[float],
    ) -> str:
        """Request chat completion.

        Args:
            model (str): External model name.
            messages (list[dict[str, object]]): OpenAI chat message payload.
            temperature (float): Sampling temperature.
            timeout_sec (float): Request timeout in seconds.
            max_retries (int): Number of retries after initial attempt.
            retry_backoff_sec (list[float]): Retry wait seconds per retry index.

        Raises:
            PerceptionError: If external call fails.

        Returns:
            str: Extracted text content.
        """

        payload_messages = cast(list[ChatCompletionMessageParam], messages)
        last_exception: Optional[Exception] = None
        total_attempts = max_retries + 1
        for attempt in range(total_attempts):
            try:
                completion = self.client.chat.completions.create(
                    model=model,
                    messages=payload_messages,
                    temperature=temperature,
                    timeout=timeout_sec,
                )
                if not completion.choices:
                    return ""
                return extract_chat_text_content(completion.choices[0].message.content)
            except Exception as exc:
                last_exception = exc
                if attempt == max_retries:
                    break
                # Retry wait is controlled by explicit backoff values from settings or call options.
                if retry_backoff_sec:
                    backoff_index = min(attempt, len(retry_backoff_sec) - 1)
                    time.sleep(retry_backoff_sec[backoff_index])

        raise PerceptionError(
            f"External chat completion failed: {last_exception}",
            EXTERNAL_API_ERROR_CODE,
            cause=last_exception,
        )


class AsyncOpenAIChatBackend:
    """OpenAI-compatible backend for async chat completion calls.

    Args:
        settings (Settings): Runtime settings.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        if settings.external_api_key is None:
            raise PerceptionError(
                "external_api_key is required.",
                EXTERNAL_API_KEY_MISSING_CODE,
            )
        self.client = AsyncOpenAI(
            api_key=settings.external_api_key,
            base_url=settings.external_api_base_url,
            timeout=float(settings.request_timeout_seconds),
        )

    async def complete(
        self,
        model: str,
        messages: list[dict[str, object]],
        temperature: float,
        timeout_sec: float,
        max_retries: int,
        retry_backoff_sec: list[float],
    ) -> str:
        """Request chat completion asynchronously.

        Args:
            model (str): External model name.
            messages (list[dict[str, object]]): OpenAI chat message payload.
            temperature (float): Sampling temperature.
            timeout_sec (float): Request timeout in seconds.
            max_retries (int): Number of retries after initial attempt.
            retry_backoff_sec (list[float]): Retry wait seconds per retry index.

        Raises:
            PerceptionError: If external call fails.

        Returns:
            str: Extracted text content.
        """

        payload_messages = cast(list[ChatCompletionMessageParam], messages)
        last_exception: Optional[Exception] = None
        total_attempts = max_retries + 1
        for attempt in range(total_attempts):
            try:
                completion = await self.client.chat.completions.create(
                    model=model,
                    messages=payload_messages,
                    temperature=temperature,
                    timeout=timeout_sec,
                )
                if not completion.choices:
                    return ""
                return extract_chat_text_content(completion.choices[0].message.content)
            except Exception as exc:
                last_exception = exc
                if attempt == max_retries:
                    break
                # Retry wait is controlled by explicit backoff values from settings or call options.
                if retry_backoff_sec:
                    backoff_index = min(attempt, len(retry_backoff_sec) - 1)
                    await asyncio.sleep(retry_backoff_sec[backoff_index])

        raise PerceptionError(
            f"External chat completion failed: {last_exception}",
            EXTERNAL_API_ERROR_CODE,
            cause=last_exception,
        )
