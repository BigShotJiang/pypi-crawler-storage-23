from __future__ import annotations

import base64
import mimetypes
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Optional, Union
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

from raggify_perception.core.constants import (
    DEFAULT_HTTP_TIMEOUT_SECONDS,
    INVALID_DATA_URL_CODE,
    INVALID_MEDIA_URL_CODE,
)
from raggify_perception.core.errors import PerceptionError

_DATA_URL_PATTERN = re.compile(r"^data:(?P<mime>[^;]+);base64,(?P<data>.+)$")
_SUPPORTED_MEDIA_URL_SCHEMES = {"http", "https"}
_DEFAULT_MEDIA_MIME = "application/octet-stream"
_PERCEPTION_HTTP_USER_AGENT = "raggify-perception/0.2"


@dataclass(frozen=True)
class MediaPayload:
    """Resolved media payload.

    Args:
        mime (str): MIME type.
        data (bytes): Media bytes.
        file_name (Optional[str], optional): Source file name. Defaults to None.
    """

    mime: str
    data: bytes
    file_name: Optional[str] = None


MediaInput = Union[bytes, bytearray, memoryview, str]


def parse_data_url(data_url: str) -> MediaPayload:
    """Parse a base64 data URL into media payload.

    Args:
        data_url (str): Data URL string.

    Raises:
        PerceptionError: If format or base64 payload is invalid.

    Returns:
        MediaPayload: Parsed payload.
    """

    match = _DATA_URL_PATTERN.match(data_url)
    if match is None:
        raise PerceptionError("Invalid data URL format.", INVALID_DATA_URL_CODE)

    mime = match.group("mime")
    encoded = match.group("data")
    try:
        data = base64.b64decode(encoded, validate=True)
    except ValueError as exc:
        raise PerceptionError(
            "Data URL payload is not valid base64.",
            INVALID_DATA_URL_CODE,
            cause=exc,
        ) from exc
    return MediaPayload(mime=mime, data=data)


def infer_file_name_from_url(media_url: str, default_file_name: str) -> str:
    """Infer file name from URL path.

    Args:
        media_url (str): Source URL.
        default_file_name (str): Fallback name.

    Returns:
        str: File name.
    """

    parsed = urlparse(media_url)
    file_name = unquote(PurePosixPath(parsed.path).name)
    if file_name:
        return file_name
    return default_file_name


def _normalize_media_mime(content_type: Optional[str], media_url: str) -> str:
    """Resolve MIME from HTTP headers and URL suffix.

    Args:
        content_type (Optional[str]): Response content type.
        media_url (str): Source URL.

    Returns:
        str: Resolved MIME.
    """

    if content_type:
        normalized = content_type.split(";", maxsplit=1)[0].strip()
        if normalized:
            return normalized
    guessed_mime, _ = mimetypes.guess_type(media_url)
    if guessed_mime:
        return guessed_mime
    return _DEFAULT_MEDIA_MIME


def _download_http_media(media_url: str) -> MediaPayload:
    """Download media via HTTP(S).

    Args:
        media_url (str): Source URL.

    Raises:
        PerceptionError: If download fails.

    Returns:
        MediaPayload: Downloaded media.
    """

    request = Request(
        media_url,
        headers={"User-Agent": _PERCEPTION_HTTP_USER_AGENT},
        method="GET",
    )
    try:
        with urlopen(request, timeout=DEFAULT_HTTP_TIMEOUT_SECONDS) as response:
            content = response.read()
            content_type = response.headers.get("Content-Type")
    except Exception as exc:
        raise PerceptionError(
            f"Failed to fetch media URL: {exc}",
            INVALID_MEDIA_URL_CODE,
            cause=exc,
        ) from exc

    mime = _normalize_media_mime(content_type=content_type, media_url=media_url)
    file_name = infer_file_name_from_url(
        media_url, default_file_name="downloaded-media"
    )
    return MediaPayload(mime=mime, data=content, file_name=file_name)


def parse_media_input(
    media: MediaInput,
    default_mime: str,
    file_name: Optional[str] = None,
) -> MediaPayload:
    """Parse media input from bytes, data URL, or HTTP URL.

    Args:
        media (MediaInput): Media input.
        default_mime (str): Default MIME for raw bytes input.
        file_name (Optional[str], optional): Optional file name for raw bytes. Defaults to None.

    Raises:
        PerceptionError: If input format is unsupported.

    Returns:
        MediaPayload: Parsed payload.
    """

    if isinstance(media, bytes):
        return MediaPayload(mime=default_mime, data=media, file_name=file_name)
    if isinstance(media, bytearray):
        return MediaPayload(
            mime=default_mime,
            data=bytes(media),
            file_name=file_name,
        )
    if isinstance(media, memoryview):
        return MediaPayload(
            mime=default_mime,
            data=media.tobytes(),
            file_name=file_name,
        )
    if isinstance(media, str):
        if media.startswith("data:"):
            parsed = parse_data_url(media)
            return MediaPayload(mime=parsed.mime, data=parsed.data, file_name=file_name)

        parsed_url = urlparse(media)
        if parsed_url.scheme in _SUPPORTED_MEDIA_URL_SCHEMES:
            payload = _download_http_media(media)
            if file_name is not None:
                return MediaPayload(
                    mime=payload.mime, data=payload.data, file_name=file_name
                )
            return payload

    raise PerceptionError(
        "Media must be bytes, base64 data URL, or http/https URL.",
        INVALID_MEDIA_URL_CODE,
    )


def to_data_url(payload: MediaPayload) -> str:
    """Encode media payload to base64 data URL.

    Args:
        payload (MediaPayload): Media payload.

    Returns:
        str: Data URL.
    """

    encoded = base64.b64encode(payload.data).decode("ascii")
    return f"data:{payload.mime};base64,{encoded}"
