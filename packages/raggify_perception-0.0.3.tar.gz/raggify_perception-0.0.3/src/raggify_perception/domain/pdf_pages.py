from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Protocol, cast

from raggify_perception.core.constants import (
    PDF_DEFAULT_FILE_NAME,
    PDF_PAGE_IMAGE_SUFFIX,
    PDF_PAGE_NUMBER_DIGITS,
    PDF_PROCESSING_FAILED_CODE,
)
from raggify_perception.core.errors import PerceptionError

_PDF_RENDER_SCALE = 2.0


class _PDFPageProtocol(Protocol):
    def get_pixmap(self, matrix: object) -> _PDFPixmapProtocol:
        """Render page pixmap."""
        ...


class _PDFPixmapProtocol(Protocol):
    def tobytes(self, fmt: str) -> bytes:
        """Encode pixmap bytes."""
        ...


class _PDFDocumentProtocol(Protocol):
    page_count: int

    def load_page(self, page_index: int) -> _PDFPageProtocol:
        """Load page by index."""
        ...

    def close(self) -> None:
        """Close document."""
        ...


@dataclass(frozen=True)
class PDFPageImage:
    """Rendered PDF page image.

    Args:
        page_number (int): One-based page number.
        file_name (str): Synthetic file name with page suffix.
        image_bytes (bytes): Rendered PNG bytes.
    """

    page_number: int
    file_name: str
    image_bytes: bytes


def _open_pdf_document(pdf_bytes: bytes) -> _PDFDocumentProtocol:
    """Open a PDF document from bytes.

    Args:
        pdf_bytes (bytes): PDF bytes.

    Raises:
        PerceptionError: If PyMuPDF is missing or PDF is invalid.

    Returns:
        object: Opened PDF document.
    """

    try:
        import fitz
    except ImportError as exc:
        raise PerceptionError(
            "PyMuPDF is required for PDF processing.",
            PDF_PROCESSING_FAILED_CODE,
            cause=exc,
        ) from exc

    try:
        return cast(_PDFDocumentProtocol, fitz.open(stream=pdf_bytes, filetype="pdf"))
    except Exception as exc:
        raise PerceptionError(
            f"Invalid PDF file: {exc}",
            PDF_PROCESSING_FAILED_CODE,
            cause=exc,
        ) from exc


def split_pdf_to_page_images(
    pdf_bytes: bytes,
    original_file_name: Optional[str] = None,
    max_pages: int = 0,
) -> list[PDFPageImage]:
    """Split a PDF into per-page PNG images.

    Args:
        pdf_bytes (bytes): PDF bytes.
        original_file_name (Optional[str], optional): Source file name. Defaults to None.
        max_pages (int, optional): Maximum number of pages. `0` means all pages. Defaults to 0.

    Returns:
        list[PDFPageImage]: Rendered page images.
    """

    import fitz

    file_name = original_file_name or PDF_DEFAULT_FILE_NAME
    stem = Path(file_name).stem
    document = _open_pdf_document(pdf_bytes)
    page_images: list[PDFPageImage] = []

    try:
        total_pages = document.page_count
        page_limit = total_pages if max_pages <= 0 else min(total_pages, max_pages)
        for page_index in range(page_limit):
            page_number = page_index + 1
            page = document.load_page(page_index)
            pixmap = page.get_pixmap(
                matrix=fitz.Matrix(_PDF_RENDER_SCALE, _PDF_RENDER_SCALE)
            )
            png_bytes = cast(bytes, pixmap.tobytes("png"))
            page_file_name = f"{stem}_{page_number:0{PDF_PAGE_NUMBER_DIGITS}d}{PDF_PAGE_IMAGE_SUFFIX}"
            page_images.append(
                PDFPageImage(
                    page_number=page_number,
                    file_name=page_file_name,
                    image_bytes=png_bytes,
                )
            )
    finally:
        document.close()

    return page_images
