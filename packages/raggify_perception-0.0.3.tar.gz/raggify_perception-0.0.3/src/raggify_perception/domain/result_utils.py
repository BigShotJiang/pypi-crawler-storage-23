from __future__ import annotations

import re
from typing import Optional

_THINK_BLOCK_PATTERN = re.compile(
    r"<think>(?P<think>.*?)</think>", re.IGNORECASE | re.DOTALL
)
_QUOTE_CHARACTERS = {'"', "'"}


def extract_generated_text(result: object) -> str:
    """Extract generated text from a pipeline-like output object.

    Args:
        result (object): Raw output object.

    Returns:
        str: Extracted text.
    """

    if isinstance(result, list) and result:
        first = result[0]
        if isinstance(first, dict):
            for key in ("generated_text", "text"):
                text_value = first.get(key)
                if isinstance(text_value, str):
                    return text_value
    if isinstance(result, dict):
        for key in ("generated_text", "text"):
            text_value = result.get(key)
            if isinstance(text_value, str):
                return text_value
    return str(result)


def extract_chat_text_content(content: object) -> str:
    """Extract plain text from OpenAI chat completion content.

    Args:
        content (object): OpenAI content value.

    Returns:
        str: Extracted text.
    """

    if isinstance(content, str):
        return content
    if isinstance(content, list):
        text_parts: list[str] = []
        for part in content:
            if isinstance(part, dict):
                text_value = part.get("text")
                if isinstance(text_value, str):
                    text_parts.append(text_value)
                    continue
            extracted_part = _extract_text_attr(part)
            if extracted_part is not None:
                text_parts.append(extracted_part)
        return "\n".join(text_parts)
    return str(content)


def _extract_text_attr(value: object) -> Optional[str]:
    """Extract `.text` attribute if available and string typed.

    Args:
        value (object): Arbitrary object.

    Returns:
        Optional[str]: Text attribute value.
    """

    try:
        text_candidate = value.text  # type: ignore[attr-defined]
    except Exception:
        return None
    if isinstance(text_candidate, str):
        return text_candidate
    return None


def normalize_model_output_text(text: str) -> str:
    """Normalize raw model output text.

    Args:
        text (str): Raw text.

    Returns:
        str: Normalized text.
    """

    stripped_text = text.strip()
    if len(stripped_text) >= 2 and stripped_text[0] == stripped_text[-1]:
        quote_character = stripped_text[0]
        if quote_character in _QUOTE_CHARACTERS:
            if not stripped_text[1:-1].strip():
                return ""
    return stripped_text


def strip_think_blocks(text: str) -> str:
    """Remove think blocks from model output.

    Args:
        text (str): Raw output.

    Returns:
        str: Output without think blocks.
    """

    return _THINK_BLOCK_PATTERN.sub("", text).strip()
