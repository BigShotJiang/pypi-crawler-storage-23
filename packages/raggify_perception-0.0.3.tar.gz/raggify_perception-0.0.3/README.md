# Raggify Perception

## Introduction

This document is an input reference for developing raggify-perception: the part of Raggify system.

## Related Modules

### Raggify App

- Developed as a web application

#### Web Server (raggify-app client)

- The `client` folder is the root of raggify-app client
- Frontend of raggify-app
- Uses React, TypeScript, etc.
- Main feature is chat-style querying over documents ingested into the knowledge base
- Chat UI aims for a NotebookLM-like experience
- RAG pipeline settings UI aims for a Dify-like experience

#### App Server (raggify-app server)

- The `server` folder is the root of raggify-app server
- Backend of raggify-app
- Python program
- Manages user information and routes requests to raggify server
- Sits between raggify-app client (front) and raggify server (back)
- raggify server is treated as a driver abstraction
- It has an agent implementation and uses the backend LLM server to generate answers

### RAG Server (raggify server)

- The RAG foundation library described above
- Published as a PyPI library
- Handles upstream RAG processing (local file/URL ingestion, embeddings, index generation, etc.)
- Can selectively use local models and third-party APIs
- Supports several usage modes; in this project it runs as a resident REST API server
- This is where scaling should happen

### Raggify Client

- Client program used when raggify server is accessed as a REST API server
- Published as a PyPI library
- Supports several usage modes; in this project it provides an API for requests from raggify-app server to raggify server

### LLM Server

- Pure local LLM server.

### Raggify Perception Library

- The development target of this project
- Provides REST API Client for OCR, ASR, and image, audio, and video captioning, used by the raggify server when ingesting documents and by the app server when generating queries
