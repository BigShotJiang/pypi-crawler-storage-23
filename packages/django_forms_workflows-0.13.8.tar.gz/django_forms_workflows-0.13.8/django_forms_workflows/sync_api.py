"""
Django Forms Workflows - Cross-Instance Sync API

Provides serialization/deserialization of FormDefinition (with all related
objects) so that form + workflow + config definitions can be pushed or pulled
between multiple instances (e.g. test → prod).

Settings
--------
FORMS_SYNC_API_TOKEN : str
    Shared secret token that protects the export/import HTTP endpoints.
    If unset, the sync API endpoints are disabled.

Usage examples
--------------
Management commands (bundled)::

    # Pull all forms from a test instance
    python manage.py pull_forms --source-url=https://test.example.com --token=SECRET

    # Push selected forms to a prod instance
    python manage.py push_forms --dest-url=https://prod.example.com --token=SECRET --slugs=time-off,onboarding
"""

import logging
from decimal import Decimal

from django.conf import settings
from django.contrib.auth.models import Group
from django.db import transaction
from django.utils import timezone as django_tz

from .models import (
    FormCategory,
    FormDefinition,
    FormField,
    PostSubmissionAction,
    PrefillSource,
    WorkflowDefinition,
    WorkflowStage,
)

logger = logging.getLogger(__name__)

SYNC_SCHEMA_VERSION = 1


# ── Auth helpers ──────────────────────────────────────────────────────────────


def get_sync_token():
    """Return the configured sync API token, or None if not configured."""
    return getattr(settings, "FORMS_SYNC_API_TOKEN", None)


def verify_sync_token(request):
    """Return True if the Bearer token in the request matches the configured token."""
    token = get_sync_token()
    if not token:
        return False  # No token configured → sync disabled
    auth_header = request.META.get("HTTP_AUTHORIZATION", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:] == token
    return False


# ── Remote helpers ────────────────────────────────────────────────────────────


def get_sync_remotes():
    """Return configured remote instances from the FORMS_SYNC_REMOTES setting.

    Each entry should be a dict::

        {"name": "Test Site", "url": "https://test.example.com", "token": "secret"}

    Returns an empty list if the setting is not configured.
    """
    return getattr(settings, "FORMS_SYNC_REMOTES", [])


def fetch_remote_payload(remote_url, token, slugs=None, timeout=15):
    """Fetch an export payload from a remote instance via HTTP GET.

    Args:
        remote_url: Base URL of the remote instance (e.g. ``https://test.example.com``).
        token: Bearer token matching the remote's ``FORMS_SYNC_API_TOKEN``.
        slugs: Optional list of form slugs to filter. If ``None`` all forms are returned.
        timeout: Request timeout in seconds.

    Returns:
        Parsed JSON payload dict from the remote export endpoint.

    Raises:
        requests.HTTPError: If the remote returns a non-2xx response.
        requests.RequestException: For connection / timeout errors.
    """
    import requests

    url = remote_url.rstrip("/") + "/forms-sync/export/"
    params = {"slugs": ",".join(slugs)} if slugs else {}
    response = requests.get(
        url,
        params=params,
        headers={"Authorization": f"Bearer {token}"},
        timeout=timeout,
    )
    response.raise_for_status()
    return response.json()


def push_to_remote(remote_url, token, queryset, conflict="update", timeout=30):
    """Push a local form queryset to a remote instance via HTTP POST.

    Args:
        remote_url: Base URL of the remote instance.
        token: Bearer token matching the remote's ``FORMS_SYNC_API_TOKEN``.
        queryset: ``FormDefinition`` queryset to export and push.
        conflict: Conflict resolution mode (``update``, ``skip``, or ``new_slug``).
        timeout: Request timeout in seconds.

    Returns:
        Parsed JSON response dict from the remote import endpoint.

    Raises:
        requests.HTTPError: If the remote returns a non-2xx response.
        requests.RequestException: For connection / timeout errors.
    """
    import requests

    payload = build_export_payload(queryset)
    url = remote_url.rstrip("/") + f"/forms-sync/import/?conflict={conflict}"
    response = requests.post(
        url,
        json=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        timeout=timeout,
    )
    response.raise_for_status()
    return response.json()


# ── Serializers ───────────────────────────────────────────────────────────────


def _group_names(qs):
    return list(qs.values_list("name", flat=True))


def _serialize_prefill_source(ps):
    if ps is None:
        return None
    return {
        "name": ps.name,
        "source_type": ps.source_type,
        "source_key": ps.source_key,
        "description": ps.description,
        "is_active": ps.is_active,
        "db_alias": ps.db_alias,
        "db_schema": ps.db_schema,
        "db_table": ps.db_table,
        "db_column": ps.db_column,
        "db_columns": ps.db_columns,
        "db_template": ps.db_template,
        "db_lookup_field": ps.db_lookup_field,
        "db_user_field": ps.db_user_field,
        "ldap_attribute": ps.ldap_attribute,
        "api_endpoint": ps.api_endpoint,
        "api_field": ps.api_field,
        "custom_config": ps.custom_config,
        "database_query_key": ps.database_query_key,
        "order": ps.order,
    }


def _serialize_category(cat):
    if cat is None:
        return None
    return {
        "name": cat.name,
        "slug": cat.slug,
        "description": cat.description,
        "order": cat.order,
        "is_collapsed_by_default": cat.is_collapsed_by_default,
        "icon": cat.icon,
        "allowed_groups": _group_names(cat.allowed_groups),
        "parent_slug": cat.parent.slug if cat.parent else None,
    }


def _serialize_field(field):
    return {
        "field_name": field.field_name,
        "field_label": field.field_label,
        "field_type": field.field_type,
        "order": field.order,
        "help_text": field.help_text,
        "placeholder": field.placeholder,
        "css_class": field.css_class,
        "width": field.width,
        "required": field.required,
        "readonly": field.readonly,
        "min_value": str(field.min_value) if field.min_value is not None else None,
        "max_value": str(field.max_value) if field.max_value is not None else None,
        "min_length": field.min_length,
        "max_length": field.max_length,
        "regex_validation": field.regex_validation,
        "regex_error_message": field.regex_error_message,
        "choices": field.choices,
        "prefill_source": field.prefill_source,
        "prefill_source_config": _serialize_prefill_source(field.prefill_source_config),
        "default_value": field.default_value,
        "show_if_field": field.show_if_field,
        "show_if_value": field.show_if_value,
        "conditional_rules": field.conditional_rules,
        "validation_rules": field.validation_rules,
        "field_dependencies": field.field_dependencies,
        "step_number": field.step_number,
        "approval_step": field.approval_step,
        "allowed_extensions": field.allowed_extensions,
        "max_file_size_mb": field.max_file_size_mb,
    }


def _serialize_workflow_stage(stage):
    return {
        "name": stage.name,
        "order": stage.order,
        "approval_logic": stage.approval_logic,
        "approval_groups": _group_names(stage.approval_groups),
        "requires_manager_approval": stage.requires_manager_approval,
    }


def _serialize_workflow(wf):
    if wf is None:
        return None
    return {
        "requires_approval": wf.requires_approval,
        "approval_groups": _group_names(wf.approval_groups),
        "approval_logic": wf.approval_logic,
        "requires_manager_approval": wf.requires_manager_approval,
        "manager_can_override_group": wf.manager_can_override_group,
        "escalation_field": wf.escalation_field,
        "escalation_threshold": str(wf.escalation_threshold)
        if wf.escalation_threshold is not None
        else None,
        "escalation_groups": _group_names(wf.escalation_groups),
        "approval_deadline_days": wf.approval_deadline_days,
        "send_reminder_after_days": wf.send_reminder_after_days,
        "auto_approve_after_days": wf.auto_approve_after_days,
        "notify_on_submission": wf.notify_on_submission,
        "notify_on_approval": wf.notify_on_approval,
        "notify_on_rejection": wf.notify_on_rejection,
        "notify_on_withdrawal": wf.notify_on_withdrawal,
        "additional_notify_emails": wf.additional_notify_emails,
        "notification_cadence": wf.notification_cadence,
        "notification_cadence_day": wf.notification_cadence_day,
        "notification_cadence_time": wf.notification_cadence_time.isoformat()
        if wf.notification_cadence_time
        else None,
        "notification_cadence_form_field": wf.notification_cadence_form_field,
        "enable_db_updates": wf.enable_db_updates,
        "db_update_mappings": wf.db_update_mappings,
        "visual_workflow_data": wf.visual_workflow_data,
        "stages": [
            _serialize_workflow_stage(s) for s in wf.stages.all().order_by("order")
        ],
    }


def _serialize_post_action(action):
    return {
        "name": action.name,
        "action_type": action.action_type,
        "trigger": action.trigger,
        "is_active": action.is_active,
        "order": action.order,
        "db_alias": action.db_alias,
        "db_schema": action.db_schema,
        "db_table": action.db_table,
        "db_lookup_field": action.db_lookup_field,
        "db_user_field": action.db_user_field,
        "db_field_mappings": action.db_field_mappings,
        "ldap_dn_template": action.ldap_dn_template,
        "ldap_field_mappings": action.ldap_field_mappings,
        "api_endpoint": action.api_endpoint,
        "api_method": action.api_method,
        "api_headers": action.api_headers,
        "api_body_template": action.api_body_template,
        "custom_handler_path": action.custom_handler_path,
        "custom_handler_config": action.custom_handler_config,
        "email_to": action.email_to,
        "email_to_field": action.email_to_field,
        "email_cc": action.email_cc,
        "email_cc_field": action.email_cc_field,
        "email_subject_template": action.email_subject_template,
        "email_body_template": action.email_body_template,
        "email_template_name": action.email_template_name,
        "is_locked": action.is_locked,
        "condition_field": action.condition_field,
        "condition_operator": action.condition_operator,
        "condition_value": action.condition_value,
        "fail_silently": action.fail_silently,
        "retry_on_failure": action.retry_on_failure,
        "max_retries": action.max_retries,
        "description": action.description,
    }


def serialize_form(form_definition):
    """Serialize a FormDefinition (with all related objects) to a plain dict."""
    try:
        workflow = form_definition.workflow
    except WorkflowDefinition.DoesNotExist:
        workflow = None

    return {
        "schema_version": SYNC_SCHEMA_VERSION,
        "category": _serialize_category(form_definition.category),
        "form": {
            "name": form_definition.name,
            "slug": form_definition.slug,
            "description": form_definition.description,
            "instructions": form_definition.instructions,
            "is_active": form_definition.is_active,
            "version": form_definition.version,
            "submit_groups": _group_names(form_definition.submit_groups),
            "view_groups": _group_names(form_definition.view_groups),
            "admin_groups": _group_names(form_definition.admin_groups),
            "allow_save_draft": form_definition.allow_save_draft,
            "allow_withdrawal": form_definition.allow_withdrawal,
            "requires_login": form_definition.requires_login,
            "enable_multi_step": form_definition.enable_multi_step,
            "form_steps": form_definition.form_steps,
            "enable_auto_save": form_definition.enable_auto_save,
            "auto_save_interval": form_definition.auto_save_interval,
            "pdf_generation": form_definition.pdf_generation,
        },
        "fields": [
            _serialize_field(f) for f in form_definition.fields.all().order_by("order")
        ],
        "workflow": _serialize_workflow(workflow),
        "post_actions": [
            _serialize_post_action(a)
            for a in form_definition.post_actions.all().order_by("order")
        ],
    }


def build_export_payload(queryset):
    """Build the full export payload dict for a queryset of FormDefinitions."""
    qs = queryset.prefetch_related(
        "fields",
        "fields__prefill_source_config",
        "workflow",
        "workflow__stages",
        "workflow__stages__approval_groups",
        "workflow__approval_groups",
        "workflow__escalation_groups",
        "post_actions",
        "submit_groups",
        "view_groups",
        "admin_groups",
        "category",
        "category__allowed_groups",
    )
    return {
        "schema_version": SYNC_SCHEMA_VERSION,
        "exported_at": django_tz.now().isoformat(),
        "form_count": qs.count(),
        "forms": [serialize_form(f) for f in qs],
    }


# ── Deserializers / Import logic ───────────────────────────────────────────────


def _get_or_create_group(name):
    """Return a Group with the given name, creating it if necessary."""
    group, _ = Group.objects.get_or_create(name=name)
    return group


def _get_or_create_prefill_source(data):
    """Find or create a PrefillSource by name, updating its fields."""
    if data is None:
        return None
    ps, _ = PrefillSource.objects.update_or_create(
        name=data["name"],
        defaults={k: v for k, v in data.items() if k != "name"},
    )
    return ps


def _get_or_create_category(data, category_cache=None):
    """Find or create a FormCategory by slug, updating its fields."""
    if data is None:
        return None
    if category_cache is not None and data["slug"] in category_cache:
        return category_cache[data["slug"]]

    parent = None
    if data.get("parent_slug"):
        parent = FormCategory.objects.filter(slug=data["parent_slug"]).first()

    cat, _ = FormCategory.objects.update_or_create(
        slug=data["slug"],
        defaults={
            "name": data["name"],
            "description": data.get("description", ""),
            "order": data.get("order", 0),
            "is_collapsed_by_default": data.get("is_collapsed_by_default", False),
            "icon": data.get("icon", ""),
            "parent": parent,
        },
    )
    # Sync allowed_groups
    cat.allowed_groups.set(
        [_get_or_create_group(n) for n in data.get("allowed_groups", [])]
    )

    if category_cache is not None:
        category_cache[data["slug"]] = cat
    return cat


@transaction.atomic
def import_form(form_data, conflict="update", category_cache=None):
    """
    Import a single serialized form dict.

    Parameters
    ----------
    form_data : dict
        A single form entry as returned by ``serialize_form()``.
    conflict : str
        How to handle an existing form with the same slug.
        ``'update'``    — overwrite the existing form (default).
        ``'skip'``      — leave the existing form untouched and return it.
        ``'new_slug'``  — append ``_imported`` to the slug and create a copy.
    category_cache : dict or None
        Pass a dict to cache ``FormCategory`` objects across multiple calls.

    Returns
    -------
    tuple[FormDefinition, str]
        ``(form_definition, action)`` where *action* is one of
        ``'created'``, ``'updated'``, or ``'skipped'``.
    """
    if category_cache is None:
        category_cache = {}

    fd = form_data.get("form", form_data)  # tolerate bare-form dicts
    slug = fd["slug"]

    category = _get_or_create_category(form_data.get("category"), category_cache)

    existing = FormDefinition.objects.filter(slug=slug).first()
    if existing:
        if conflict == "skip":
            return existing, "skipped"
        if conflict == "new_slug":
            slug = slug + "_imported"
            existing = FormDefinition.objects.filter(slug=slug).first()

    form_defaults = {
        "name": fd["name"],
        "description": fd.get("description", ""),
        "instructions": fd.get("instructions", ""),
        "is_active": fd.get("is_active", True),
        "version": fd.get("version", 1),
        "category": category,
        "allow_save_draft": fd.get("allow_save_draft", False),
        "allow_withdrawal": fd.get("allow_withdrawal", False),
        "requires_login": fd.get("requires_login", True),
        "enable_multi_step": fd.get("enable_multi_step", False),
        "form_steps": fd.get("form_steps"),
        "enable_auto_save": fd.get("enable_auto_save", False),
        "auto_save_interval": fd.get("auto_save_interval", 30),
        "pdf_generation": fd.get("pdf_generation", False),
    }

    form_obj, created = FormDefinition.objects.update_or_create(
        slug=slug,
        defaults=form_defaults,
    )
    action = "created" if created else "updated"

    # Sync M2M groups
    form_obj.submit_groups.set(
        [_get_or_create_group(n) for n in fd.get("submit_groups", [])]
    )
    form_obj.view_groups.set(
        [_get_or_create_group(n) for n in fd.get("view_groups", [])]
    )
    form_obj.admin_groups.set(
        [_get_or_create_group(n) for n in fd.get("admin_groups", [])]
    )

    # ── Fields ─────────────────────────────────────────────────────────────────
    # Delete existing fields so we get a clean ordered set
    form_obj.fields.all().delete()
    for field_data in form_data.get("fields", []):
        ps_config = _get_or_create_prefill_source(
            field_data.pop("prefill_source_config", None)
        )
        field_data_copy = dict(field_data)
        field_data_copy.pop("prefill_source_config", None)
        min_val = field_data_copy.pop("min_value", None)
        max_val = field_data_copy.pop("max_value", None)
        FormField.objects.create(
            form_definition=form_obj,
            prefill_source_config=ps_config,
            min_value=Decimal(min_val) if min_val is not None else None,
            max_value=Decimal(max_val) if max_val is not None else None,
            **field_data_copy,
        )

    # ── Workflow ───────────────────────────────────────────────────────────────
    wf_data = form_data.get("workflow")
    if wf_data is not None:
        from datetime import time as _time

        nc_time_str = wf_data.pop("notification_cadence_time", None)
        nc_time = _time.fromisoformat(nc_time_str) if nc_time_str else None
        stages_data = wf_data.pop("stages", [])
        esc_thresh = wf_data.pop("escalation_threshold", None)
        approval_group_names = wf_data.pop("approval_groups", [])
        escalation_group_names = wf_data.pop("escalation_groups", [])

        wf, _ = WorkflowDefinition.objects.update_or_create(
            form_definition=form_obj,
            defaults={
                **wf_data,
                "notification_cadence_time": nc_time,
                "escalation_threshold": Decimal(esc_thresh) if esc_thresh else None,
            },
        )
        wf.approval_groups.set([_get_or_create_group(n) for n in approval_group_names])
        wf.escalation_groups.set(
            [_get_or_create_group(n) for n in escalation_group_names]
        )

        wf.stages.all().delete()
        for stage_data in stages_data:
            stage_group_names = stage_data.pop("approval_groups", [])
            stage = WorkflowStage.objects.create(workflow=wf, **stage_data)
            stage.approval_groups.set(
                [_get_or_create_group(n) for n in stage_group_names]
            )
    else:
        # Remove workflow if source had none
        WorkflowDefinition.objects.filter(form_definition=form_obj).delete()

    # ── Post-submission actions ────────────────────────────────────────────────
    form_obj.post_actions.all().delete()
    for action_data in form_data.get("post_actions", []):
        PostSubmissionAction.objects.create(form_definition=form_obj, **action_data)

    logger.info("Sync import: form '%s' %s.", slug, action)
    return form_obj, action


def import_payload(payload, conflict="update"):
    """
    Import a full export payload (as returned by ``build_export_payload()``).

    Returns a list of ``(FormDefinition, action)`` tuples.
    """
    results = []
    category_cache = {}
    for form_data in payload.get("forms", []):
        result = import_form(
            form_data, conflict=conflict, category_cache=category_cache
        )
        results.append(result)
    return results
