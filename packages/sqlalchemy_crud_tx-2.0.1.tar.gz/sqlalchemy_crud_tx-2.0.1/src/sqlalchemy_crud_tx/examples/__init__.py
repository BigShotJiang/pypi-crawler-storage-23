"""Runnable example scripts shipped with the package."""

