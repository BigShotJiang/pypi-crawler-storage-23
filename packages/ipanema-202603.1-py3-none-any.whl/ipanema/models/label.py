from . import base, Language
from peewee import TextField, ForeignKeyField, CompositeKey, DoesNotExist
from playhouse.sqlite_ext import JSONField
from typing import Self


class Label(base.Model):
    """
    A language-specified label on Wiktionary (pronunciation, varieties, etc.),
    see `Module:labels <https://en.wiktionary.org/wiki/Module:labels>`_.
    """
    language = ForeignKeyField(Language, db_column="lang_code", backref='labels')
    """The language this label belongs to"""
    name = TextField(null=False)
    """The name of the label."""
    accent_display = TextField(null=True)
    """The text to display for an accent label"""
    accent_wikipedia = TextField(null=True)
    """The Wikipedia page of this accent"""
    wikidata_item = TextField(null=True)
    """The Wikidata item of this label"""
    wikipedia = TextField(null=True)
    """The Wikipedia page of this label"""
    region = TextField(null=True)
    """The region this label applies to (MediaWiki markup formatted)"""
    plain_categories = JSONField(null=True)
    """Simple categories (langname does not get appended)"""
    regional_categories = JSONField(null=True)
    """The regional categories ([Devonian, Somerset] => ["Devonian English", "Somerset English"])"""
    aliases = JSONField(null=True)
    """A list of aliases for this label"""
    parent_label = TextField(null=True)
    """The parent label (e.g. Cornwall => West Country)"""

    class Meta:
        table_name = 'labels'
        primary_key = CompositeKey('language', 'name')

    @classmethod
    def query(cls, lang_code: str, name: str) -> Self | None:
        """
        :param name: a label name
        :return: the label or None
        """
        try:
            return cls.get((cls.language == lang_code) & (cls.name == name))
        except DoesNotExist:
            alias = cls.aliases.children().alias('aliases')
            return cls.select() \
                      .from_(cls, alias) \
                      .where((cls.language == lang_code) & (alias.c.value == name)) \
                      .get()
