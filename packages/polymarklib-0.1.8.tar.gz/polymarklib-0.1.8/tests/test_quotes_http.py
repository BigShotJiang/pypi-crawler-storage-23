import json
from polymarklib.markets import fetch_quote
from polymarklib.config import ENDPOINTS


def test_fetch_quote():
    token_id = "26862536219457017543347627171743044936250003640211533940359819134114136544255"
    quote = fetch_quote(token_id)
    print(quote)
    return quote
