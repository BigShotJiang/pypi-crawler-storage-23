#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode
import geode_common

from .lib64.geode_numerics_py_frame_field import *

NumericsFrameFieldLibrary.initialize()
