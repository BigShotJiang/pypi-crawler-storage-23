import io4dolfinx


def test_version():
    assert io4dolfinx.__version__ is not None
