# SPDX-License-Identifier: Apache-2.0
"""
vLLM Model Security — namespace package extension.

This package extends the official vllm package with model encryption,
license validation, and authorization capabilities.

When imported (automatically via .pth or manually), it patches the
official vllm.config.LoadFormat enum to add ENCRYPTED support.

Installation:
    pip install vllm==0.8.5.post1
    pip install light-vllm-security

After installation the patch fires automatically at Python startup
via the vllm_model_security.pth file placed in site-packages.
Users can then run vllm normally:

    vllm serve /path/to/encrypted_model --load-format encrypted

or use auto-detection (just point at an encrypted model dir):

    vllm serve /path/to/encrypted_model
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Patch strategy:
#
# vllm's argparse `choices` for --load-format is built lazily inside
# make_arg_parser() which calls EngineArgs.add_cli_args(), which in turn
# does something like:
#
#   choices=[f.value for f in LoadFormat]
#
# at the time make_arg_parser() is called (NOT at module import time).
#
# So we need to:
#   1. Extend the LoadFormat enum BEFORE make_arg_parser() is called.
#   2. Patch get_model_loader() to return EncryptedModelLoader for "encrypted".
#
# The .pth file runs `import vllm.model_security` at Python startup,
# which is before any vllm CLI code runs, so the timing is correct.
# ---------------------------------------------------------------------------

def _patch_load_format() -> None:
    """
    Inject new members into vllm.config.LoadFormat in-place.

    setattr(module, "LoadFormat", new_class) does NOT work because every
    other module that has already done `from vllm.config import LoadFormat`
    holds a direct reference to the original class object — replacing the
    module attribute has no effect on those references.

    The only reliable approach is to mutate the original class object itself.
    All holders of the reference see the change automatically.
    """
    # --- YOUR NEW MEMBERS: name -> value ---
    _new_members = {
        "ENCRYPTED": "encrypted",
    }

    try:
        import sys as _sys
        # Always operate on the currently-live module object, not a stale ref.
        _cfg = _sys.modules.get("vllm.config")
        if _cfg is None:
            import vllm.config as _cfg
        cls = _cfg.LoadFormat
        for name, value in _new_members.items():
            if name in cls._member_map_:
                continue  # already present, skip
            new_member = str.__new__(cls, value)
            new_member._name_ = name
            new_member._value_ = value
            cls._member_map_[name] = new_member
            cls._member_names_.append(name)
            cls._value2member_map_[value] = new_member
            # Bypass EnumMeta.__setattr__ which forbids reassigning members.
            type.__setattr__(cls, name, new_member)
        logger.debug("vllm-model-security: patched LoadFormat members: %s",
                     list(_new_members))
    except Exception as exc:
        logger.warning("vllm-model-security: failed to patch LoadFormat: %s", exc)


def _patch_get_model_loader() -> None:
    """
    Fully replace vllm's get_model_loader with a custom implementation.

    Edit _replacement_get_model_loader below to implement your logic.
    The original function body is inlined as the default behavior;
    add your own branches before the originals.
    """
    # -----------------------------------------------------------------------
    # FULL REPLACEMENT
    # This function completely replaces get_model_loader in both:
    #   vllm.model_executor.model_loader.loader  (loader.py)
    #   vllm.model_executor.model_loader         (__init__.py re-export)
    # The original is NOT called. Add all formats you need here.
    # -----------------------------------------------------------------------
    def _replacement_get_model_loader(load_config):
        from vllm.config import LoadFormat
        from vllm.model_executor.model_loader.loader import (
            BitsAndBytesModelLoader,
            DefaultModelLoader,
            DummyModelLoader,
            GGUFModelLoader,
            RunaiModelStreamerLoader,
            ShardedStateLoader,
            TensorizerLoader,
        )

        # --- YOUR CUSTOM LOGIC BELOW ---
        if isinstance(load_config.load_format, type):
            return load_config.load_format(load_config)

        if load_config.load_format == LoadFormat.DUMMY:
            return DummyModelLoader(load_config)

        if load_config.load_format == LoadFormat.TENSORIZER:
            return TensorizerLoader(load_config)

        if load_config.load_format == LoadFormat.SHARDED_STATE:
            return ShardedStateLoader(load_config)

        if load_config.load_format == LoadFormat.BITSANDBYTES:
            return BitsAndBytesModelLoader(load_config)

        if load_config.load_format == LoadFormat.GGUF:
            return GGUFModelLoader(load_config)

        if load_config.load_format == LoadFormat.RUNAI_STREAMER:
            return RunaiModelStreamerLoader(load_config)

        if load_config.load_format == LoadFormat.RUNAI_STREAMER_SHARDED:
            return ShardedStateLoader(load_config, runai_model_streamer=True)

        # Explicit encrypted format
        if load_config.load_format == LoadFormat.ENCRYPTED:
            try:
                from .encrypted_loader import EncryptedModelLoader
                return EncryptedModelLoader(load_config)
            except ImportError as exc:
                raise RuntimeError(
                    f"Encrypted model loader requested but a required dependency "
                    f"is missing: {exc}. Install it with: pip install cryptography"
                ) from exc

        # Auto-detect encrypted models (non-invasive: only activates when .enc files found).
        # Lazy import avoids mandatory dependency on cryptography lib for non-encrypted use.
        # We do a two-phase import so that:
        #   1. A missing vllm.model_security package is silently skipped (module not installed).
        #   2. A broken import *inside* the security module (e.g. missing `cryptography`) raises
        #      loudly when an encrypted model is actually detected, rather than silently falling
        #      through to DefaultModelLoader which would produce a confusing error.
        try:
            from .encrypted_loader import is_encrypted_model
        except ImportError:
            is_encrypted_model = None  # type: ignore[assignment]

        model_path = getattr(load_config, 'model', None)
        if is_encrypted_model is not None and model_path and is_encrypted_model(model_path):
            try:
                from .encrypted_loader import EncryptedModelLoader
                return EncryptedModelLoader(load_config)
            except ImportError as exc:
                raise RuntimeError(
                    f"Encrypted model detected at '{model_path}' but a required dependency "
                    f"is missing: {exc}. Install it with: pip install cryptography"
                ) from exc

        return DefaultModelLoader(load_config)

    try:
        import vllm.model_executor.model_loader as _loader_pkg
        import vllm.model_executor.model_loader.loader as _loader_mod

        # Patch both locations: loader.py and its __init__.py re-export
        _loader_mod.get_model_loader = _replacement_get_model_loader
        _loader_pkg.get_model_loader = _replacement_get_model_loader

        logger.debug("vllm-model-security: replaced get_model_loader")
    except Exception as exc:
        logger.warning(
            "vllm-model-security: failed to replace get_model_loader: %s", exc
        )


# Run patches at import time (triggered by .pth file at Python startup)
_patch_load_format()
_patch_get_model_loader()

# ---------------------------------------------------------------------------
# Public API re-exports
# ---------------------------------------------------------------------------

from vllm.model_security.crypto import (  # noqa: E402
    ModelEncryptor,
    ModelDecryptor,
    generate_dek,
)
from vllm.model_security.license import (  # noqa: E402
    LicenseManager,
    LicenseValidator,
    LicenseInfo,
)
from vllm.model_security.fingerprint import (  # noqa: E402
    get_machine_fingerprint,
    FingerprintPolicy,
)

__all__ = [
    "ModelEncryptor",
    "ModelDecryptor",
    "generate_dek",
    "LicenseManager",
    "LicenseValidator",
    "LicenseInfo",
    "get_machine_fingerprint",
    "FingerprintPolicy",
]
