# SPDX-License-Identifier: Apache-2.0
"""
vllm-serve-encrypted — drop-in wrapper around `vllm serve`.

Why this wrapper exists
-----------------------
`vllm serve` builds its argparse choices for --load-format at module import
time via:

    cli/main.py  →  import vllm.entrypoints.cli.serve          (module level)
                 →  from vllm.engine.arg_utils import ...       (module level)
                 →  from vllm.config import LoadFormat          (module level)

By the time a .pth-triggered monkey-patch fires, all these imports have
already resolved and `LoadFormat` is already bound in `arg_utils`' namespace.
Mutating the class object afterwards has no effect on the already-captured
reference inside `choices=[f.value for f in LoadFormat]`.

This wrapper solves the problem by controlling import order:
  1. Import vllm.model_security  →  patches LoadFormat in-place
  2. THEN import vllm's CLI machinery  →  picks up the patched class

Usage (identical to `vllm serve`):
    vllm-serve-encrypted ./my-model --load-format encrypted [options...]
    vllm-serve-encrypted ./my-model [options...]   # auto-detect
"""

from __future__ import annotations

import sys


def main() -> None:
    # Step 1: patch LoadFormat and get_model_loader BEFORE vllm's CLI imports.
    import vllm.model_security  # noqa: F401  triggers both patches

    # Step 2: now import vllm's CLI stack — LoadFormat is already patched.
    from vllm.entrypoints.cli.main import main as vllm_main

    vllm_main()


if __name__ == "__main__":
    sys.exit(main())
