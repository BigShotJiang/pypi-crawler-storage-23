# SPDX-License-Identifier: Apache-2.0
"""
Encrypted model loader for vLLM.

Integrates with vLLM's model loading pipeline to transparently decrypt
model weights at load time. Supports both safetensors and GGUF formats.
"""

import io
import os
import signal
import threading
from datetime import date
from typing import Generator, Optional, Tuple

import torch
from torch import nn

from vllm.config import LoadConfig, ModelConfig, VllmConfig
from vllm.logger import init_logger
from vllm.model_executor.model_loader.loader import (
    BaseModelLoader,
    GGUFModelLoader,
    _initialize_model,
    _process_weights_after_loading,
)
from vllm.model_executor.model_loader.utils import set_default_torch_dtype
from vllm.model_executor.model_loader.weight_utils import (
    gguf_quant_weights_iterator,
)
from vllm.model_security.crypto import ModelDecryptor, MAGIC_BYTES, HEADER_SIZE
from vllm.model_security.license import LicenseValidator

logger = init_logger(__name__)

# Supported encrypted file extensions
ENC_SUFFIX = ".enc"
SAFETENSORS_ENC = ".safetensors.enc"
GGUF_ENC = ".gguf.enc"


def is_encrypted_model(model_path: str) -> bool:
    """
    Check if a model directory or file contains encrypted weights.

    Args:
        model_path: Path to model directory or single file

    Returns:
        True if encrypted model files are detected
    """
    if os.path.isfile(model_path):
        return model_path.endswith(ENC_SUFFIX)

    if os.path.isdir(model_path):
        for fname in os.listdir(model_path):
            if fname.endswith(ENC_SUFFIX):
                return True

    return False


def _validate_enc_file(path: str) -> bool:
    """Quick check that a file has the correct magic bytes."""
    try:
        with open(path, 'rb') as f:
            magic = f.read(len(MAGIC_BYTES))
            return magic == MAGIC_BYTES
    except Exception:
        return False


def _decrypt_to_buffer(enc_path: str, decryptor: ModelDecryptor) -> io.BytesIO:
    """
    Decrypt an encrypted file into an in-memory buffer.

    For large models this is called per-shard, so memory usage is bounded
    by the size of a single shard (typically 2-5 GB).
    """
    buf = io.BytesIO()
    for chunk in decryptor.decrypt_file_stream(enc_path):
        buf.write(chunk)
    buf.seek(0)
    return buf


def _encrypted_safetensors_weights_iterator(
    enc_files: list,
    decryptor: ModelDecryptor,
) -> Generator[Tuple[str, torch.Tensor], None, None]:
    """
    Iterate over weights from encrypted safetensors files.

    Decrypts each shard into memory, then reads tensors from the buffer.
    Memory usage = size of one shard at a time.
    """
    from safetensors.torch import load as safetensors_load

    for enc_file in enc_files:
        logger.debug("Decrypting shard: %s", enc_file)
        buf = _decrypt_to_buffer(enc_file, decryptor)
        # safetensors.load() accepts bytes-like objects
        tensors = safetensors_load(buf.read())
        for name, tensor in tensors.items():
            yield name, tensor
        del buf, tensors


def _encrypted_gguf_weights_iterator(
    enc_file: str,
    decryptor: ModelDecryptor,
    gguf_to_hf_name_map: dict,
) -> Generator[Tuple[str, torch.Tensor], None, None]:
    """
    Iterate over weights from an encrypted GGUF file.

    Decrypts the entire GGUF file into memory, then uses the standard
    gguf_quant_weights_iterator on the in-memory data.
    """
    import stat
    import tempfile

    logger.debug("Decrypting GGUF file: %s", enc_file)
    # GGUF reader requires a file path, so we write to a temp file.
    # Use mkstemp to create the file with restrictive permissions (0o600) atomically,
    # preventing TOCTOU race where another process could open the file before chmod.
    tmp_fd = None
    tmp_path = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(suffix='.gguf')
        # Ensure restrictive permissions (0o600) before writing sensitive data
        os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)
        
        with os.fdopen(tmp_fd, 'wb') as tmp:
            tmp_fd = None  # fdopen takes ownership
            for chunk in decryptor.decrypt_file_stream(enc_file):
                tmp.write(chunk)

        yield from gguf_quant_weights_iterator(tmp_path, gguf_to_hf_name_map)
    finally:
        if tmp_fd is not None:
            os.close(tmp_fd)
        if tmp_path is not None and os.path.exists(tmp_path):
            os.unlink(tmp_path)


class EncryptedModelLoader(BaseModelLoader):
    """
    Model loader that transparently decrypts encrypted model weights.

    Supports:
    - Encrypted safetensors (.safetensors.enc)
    - Encrypted GGUF (.gguf.enc)

    Usage:
        vllm serve ./my_encrypted_model \\
            --load-format encrypted \\
            --model-loader-extra-config '{"license_path": "./model.lic", "vendor_pubkey_path": "./vendor.pub"}'
    """

    def __init__(self, load_config: LoadConfig):
        super().__init__(load_config)
        extra = load_config.model_loader_extra_config or {}
        self.license_path: Optional[str] = extra.get("license_path")
        self.vendor_pubkey_path: Optional[str] = extra.get("vendor_pubkey_path")
        # vendor_secret is required for symmetric DEK decryption (OfflineLicenseManager mode).
        # Can be provided as hex string via config or environment variable.
        vendor_secret_hex = extra.get("vendor_secret") or os.environ.get("VLLM_VENDOR_SECRET")
        self.vendor_secret: Optional[bytes] = (
            bytes.fromhex(vendor_secret_hex) if vendor_secret_hex else None
        )
        self._decryptor: Optional[ModelDecryptor] = None
        self._license_info = None
        self._validator: Optional[LicenseValidator] = None
        self._monitor_thread: Optional[threading.Thread] = None

    def _start_license_monitor(self) -> None:
        """Start background thread that checks license expiry every 24 hours."""
        if self._monitor_thread is not None:
            return

        def _monitor_loop():
            import time
            while True:
                time.sleep(86400)  # 24 hours
                self._check_license_expiry()

        self._monitor_thread = threading.Thread(
            target=_monitor_loop,
            name="license-monitor",
            daemon=True,
        )
        self._monitor_thread.start()
        logger.info("License monitor started (checking every 24 hours)")

    def _check_license_expiry(self) -> None:
        """Check license expiry status and warn or terminate accordingly."""
        if self._license_info is None or self._validator is None:
            return
        status = self._validator.check_expiry_with_grace(self._license_info, grace_days=3)
        expire_at = getattr(self._license_info, "expire_at", "N/A")
        if status == "valid":
            return
        if status == "warning":
            expire_date = date.fromisoformat(expire_at)
            days_over = (date.today() - expire_date).days
            days_left = 3 - days_over
            logger.warning("=" * 80)
            logger.warning("⚠️  LICENSE EXPIRED: License expired on %s", expire_at)
            logger.warning("   Grace period: %d day(s) remaining before service stops.", days_left)
            logger.warning("   Please contact your vendor for a license renewal.")
            logger.warning("=" * 80)
        elif status == "expired":
            logger.error("=" * 80)
            logger.error("🚫 LICENSE GRACE PERIOD ENDED: License expired on %s", expire_at)
            logger.error("   Service is shutting down. Please renew your license.")
            logger.error("=" * 80)
            os.kill(os.getpid(), signal.SIGTERM)

    def _get_decryptor(self, model_path: str) -> ModelDecryptor:
        """Initialize and cache the decryptor after license validation."""
        if self._decryptor is not None:
            return self._decryptor

        # Resolve license and pubkey paths
        license_path = self.license_path
        vendor_pubkey_path = self.vendor_pubkey_path

        # Auto-discover from model directory if not specified
        if not license_path:
            candidate = os.path.join(model_path, "model.lic")
            if os.path.isfile(candidate):
                license_path = candidate

        if not vendor_pubkey_path:
            candidate = os.path.join(model_path, "vendor_public.pem")
            if os.path.isfile(candidate):
                vendor_pubkey_path = candidate

        if not license_path:
            raise ValueError(
                "License file not found. Provide via --model-loader-extra-config "
                '\'{"license_path": "/path/to/model.lic"}\' or place model.lic '
                "in the model directory."
            )
        if not vendor_pubkey_path:
            raise ValueError(
                "Vendor public key not found. Provide via --model-loader-extra-config "
                '\'{"vendor_pubkey_path": "/path/to/vendor_public.pem"}\' or place '
                "vendor_public.pem in the model directory."
            )

        logger.warning("=" * 80)
        logger.warning("🔐 MODEL SECURITY: Validating license: %s", license_path)
        logger.warning("=" * 80)
        validator = LicenseValidator(vendor_pubkey_path)
        license_info = validator.load_license(license_path)
        validator.validate(license_info)
        dek = validator.extract_dek_from_model_dir(
            license_info, model_path, self.vendor_secret
        )
        logger.warning("=" * 80)
        logger.warning("✅ LICENSE VALID - Model authorized for use")
        logger.warning("   License ID: %s", getattr(license_info,'license_id', 'N/A'))
        logger.warning("   Expires: %s", getattr(license_info,'expire_at', 'N/A'))
        logger.warning("=" * 80)

        self._license_info = license_info
        self._validator = validator
        self._decryptor = ModelDecryptor(dek)
        self._start_license_monitor()
        return self._decryptor

    def _find_enc_files(self, model_path: str, suffix: str) -> list:
        """Find all encrypted files with given suffix in model directory."""
        if os.path.isfile(model_path) and model_path.endswith(suffix):
            return [model_path]

        if os.path.isdir(model_path):
            files = sorted([
                os.path.join(model_path, f)
                for f in os.listdir(model_path)
                if f.endswith(suffix)
            ])
            return files

        return []

    def download_model(self, model_config: ModelConfig) -> None:
        """Encrypted models are local-only; no download needed."""
        pass

    def load_model(self, vllm_config: VllmConfig) -> nn.Module:
        device_config = vllm_config.device_config
        model_config = vllm_config.model_config
        model_path = model_config.model
        target_device = torch.device(device_config.device)

        decryptor = self._get_decryptor(model_path)

        # Detect format: GGUF or safetensors
        gguf_enc_files = self._find_enc_files(model_path, GGUF_ENC)
        st_enc_files = self._find_enc_files(model_path, SAFETENSORS_ENC)

        with set_default_torch_dtype(model_config.dtype):
            with target_device:
                model = _initialize_model(vllm_config=vllm_config)

            if gguf_enc_files:
                if len(gguf_enc_files) != 1:
                    raise ValueError(
                        f"Expected exactly one .gguf.enc file, found: {gguf_enc_files}"
                    )
                logger.info("Loading encrypted GGUF model: %s", gguf_enc_files[0])
                # Reuse GGUFModelLoader's name mapping logic
                gguf_loader = GGUFModelLoader(self.load_config)
                gguf_weights_map = gguf_loader._get_gguf_weights_map(model_config)
                weights_iter = _encrypted_gguf_weights_iterator(
                    gguf_enc_files[0], decryptor, gguf_weights_map
                )
            elif st_enc_files:
                logger.info(
                    "Loading encrypted safetensors model (%d shards)", len(st_enc_files)
                )
                weights_iter = _encrypted_safetensors_weights_iterator(
                    st_enc_files, decryptor
                )
            else:
                raise ValueError(
                    f"No encrypted model files found in: {model_path}. "
                    f"Expected files ending with {SAFETENSORS_ENC} or {GGUF_ENC}."
                )

            model.load_weights(weights_iter)
            _process_weights_after_loading(model, model_config, target_device)

        return model.eval()
