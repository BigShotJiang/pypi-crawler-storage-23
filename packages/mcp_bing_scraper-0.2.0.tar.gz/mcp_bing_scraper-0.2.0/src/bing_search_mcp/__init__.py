"""Bing Search MCP Server - 免费的 Bing 搜索 MCP 服务器"""

__version__ = "0.1.0"
