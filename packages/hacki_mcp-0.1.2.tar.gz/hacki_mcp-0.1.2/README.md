# hacki-mcp

Security code analysis for your IDE, powered by the [HackiAI](https://hacki.ai) API.

**hacki-mcp** is a [Model Context Protocol (MCP)](https://modelcontextprotocol.io) server that brings HackiAI's security analysis directly into Claude Desktop, Cursor, VS Code, Claude Code, and any other MCP-compatible client.

## Tools

| Tool | Description |
|------|-------------|
| `hacki_review_file` | Analyze a single file for security vulnerabilities |
| `hacki_review_files` | Analyze a list of files together |
| `hacki_review_directory` | Analyze a directory recursively |
| `hacki_commit` | Analyze staged files and generate a suggested commit message |
| `hacki_get_history` | List past reviews with filters and pagination |
| `hacki_get_findings` | Get the findings for a specific review |
| `hacki_update_finding_status` | Mark a finding as `resolved`, `ignored`, or `pending` |

## Usage

Just ask your AI agent in natural language. The agent decides which tool to call. If it searches your codebase instead of calling the tool, be explicit with the tool name.

### Analyze a file

```
Review /home/user/project/app.py for security issues
```
```
Use hacki_review_file to analyze /home/user/project/app.py
```

### Analyze multiple files together

```
Use hacki_review_files to analyze src/auth.py, src/models.py and src/api.py
```

> Multi-file analysis automatically generates a code graph (AST + CFG + DFG) to detect cross-file vulnerabilities.

### Analyze an entire directory

```
Run a security review on the /home/user/project/src directory
```
```
Use hacki_review_directory on ./src
```

### Before committing — analyze staged files

Stage your files first (`git add`), then:

```
Use hacki_commit to review my staged changes and suggest a commit message
```

The tool returns a suggested commit message plus any security findings in the staged code.

### View past reviews

```
Show my last 10 security reviews
```
```
Use hacki_get_history with page 1 and size 10
```

Filter by filename or date:

```
Show reviews from the last week for files named auth
```

### See the findings of a specific review

Copy the review ID from the history and ask:

```
Show the findings for review 59f862db-adb1-4f63-a920-fbfc42ee4f93
```
```
Get the critical and high severity findings for review <id>
```

### Mark a finding as resolved

```
Mark finding <issue_id> in review <review_id> as resolved
```
```
Ignore finding <issue_id> in review <review_id>
```

Valid statuses: `resolved`, `ignored`, `pending`.

### Typical workflow

```
1. Ask for your review history to find recent reviews
2. Ask for the findings of a specific review
3. Fix the issues in your code
4. Mark the findings as resolved
```

---

## Requirements

A HackiAI API key. Get one at [hacki.ai](https://hacki.ai).

## Installation

### uvx — recommended, no install needed

[uvx](https://docs.astral.sh/uv/) runs the server on demand without polluting your Python environment:

```json
{
  "mcpServers": {
    "hacki": {
      "command": "uvx",
      "args": ["hacki-mcp@latest"],
      "env": { "HACKI_API_KEY": "hacki_xxxx" }
    }
  }
}
```

### pip

```bash
pip install hacki-mcp
```

### Docker

```bash
docker pull hackiai/hacki-mcp
```

## Configuration

### Claude Desktop

Edit your config file:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "hacki": {
      "command": "uvx",
      "args": ["hacki-mcp@latest"],
      "env": {
        "HACKI_API_KEY": "hacki_xxxx"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add hacki -- uvx hacki-mcp
```

Then add your API key in `.claude/settings.json`:

```json
{
  "mcpServers": {
    "hacki": {
      "command": "uvx",
      "args": ["hacki-mcp@latest"],
      "env": {
        "HACKI_API_KEY": "hacki_xxxx"
      }
    }
  }
}
```

### Cursor

Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "hacki": {
      "command": "uvx",
      "args": ["hacki-mcp@latest"],
      "env": {
        "HACKI_API_KEY": "hacki_xxxx"
      }
    }
  }
}
```

### VS Code (GitHub Copilot Agent)

Open the Command Palette (`Ctrl+Shift+P`) and run **"MCP: Open User Configuration"**, then add:

```json
{
  "servers": {
    "hacki": {
      "command": "uvx",
      "args": ["hacki-mcp@latest"],
      "env": {
        "HACKI_API_KEY": "hacki_xxxx"
      }
    }
  }
}
```

Switch Copilot to **Agent** mode to use the tools.

### Docker (any IDE)

Use this variant if you prefer not to install Python:

```json
{
  "mcpServers": {
    "hacki": {
      "command": "docker",
      "args": ["run", "--rm", "-i", "-e", "HACKI_API_KEY", "hackiai/hacki-mcp"],
      "env": {
        "HACKI_API_KEY": "hacki_xxxx"
      }
    }
  }
}
```

### Already using the HackiAI CLI?

If you have run `hacki login`, your credentials are already stored at `~/.hacki_cli/config.json`. The MCP reads them automatically — no `HACKI_API_KEY` needed in the config.

## Code Graph

hacki-mcp automatically generates AST, IR, CFG, and DFG graphs (via [hacki-graph](https://pypi.org/project/hacki-graph/)) when analyzing multiple files. This significantly improves cross-file vulnerability detection.

Supported languages: Python, JavaScript, TypeScript, Java, C#, Go, PHP.

## License

[MIT](LICENSE)
