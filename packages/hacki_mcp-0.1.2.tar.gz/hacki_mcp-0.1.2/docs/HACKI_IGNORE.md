.hackiignore — cómo usarlo
Crea un archivo .hackiignore en la raíz del proyecto (junto a .git):


# Documentación — sin superficie de vulnerabilidad
docs/
*.md
*.rst
*.txt

# Auto-generados
dist/
build/
__pycache__/
*.pyc
*.min.js
*.min.css

# Dependencias
node_modules/
vendor/
.venv/
venv/

# Tests (opcional)
# tests/
# test/
Cómo funciona
Escenario	Comportamiento
hacki review --modified	Filtra los archivos modificados antes de enviarlos
hacki review src/	Filtra al expandir el directorio
/review en hacki start	Mismo filtrado, aplica antes del progress widget
/commit	Filtra archivos staged
Patrón docs/	Excluye todo lo que esté dentro de docs/
Patrón *.md	Excluye todos los .md en cualquier subdirectorio
Patrón !README.md	Revierte la exclusión para ese archivo específico
El archivo se busca automáticamente subiendo desde el directorio de trabajo hasta encontrar .git o el propio .hackiignore, igual que hace git.