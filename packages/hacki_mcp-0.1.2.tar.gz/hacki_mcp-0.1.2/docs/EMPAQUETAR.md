Para que quede en PyPI con estos cambios necesitas hacer uv build && uv publish con la versión actualizada. 
La version se sube en pyproject.toml y en "__init__.py"