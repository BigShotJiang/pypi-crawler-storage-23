# Guía de Usuario - Hacki CLI

Esta guía explica cómo usar Hacki CLI para análisis de código con snapshots canonical.

---

## 📋 Tabla de Contenidos

1. [Conceptos Básicos](#conceptos-básicos)
2. [Inicialización de Proyecto](#inicialización-de-proyecto)
3. [Sincronización de Snapshots](#sincronización-de-snapshots)
4. [Análisis de Código](#análisis-de-código)
5. [Historial y Gestión de Hallazgos](#historial-y-gestión-de-hallazgos)
6. [Troubleshooting](#troubleshooting)

---

## 🎯 Conceptos Básicos

### ¿Qué es un Snapshot Canonical?

Un **snapshot canonical** es el estado "oficial" del proyecto según el backend. Se genera automáticamente después de hacer merge a las ramas base (main/develop) y representa el estado estable del código.

**Características:**
- ✅ Fuente de verdad del estado del proyecto
- ✅ Solo se actualiza mediante `hacki sync` o después de merge en backend
- ✅ Se usa como base para comparar cambios en reviews
- ✅ Solo disponible en ramas base (main/master/develop)

### Grafos Temporales vs. Canonical

**Grafos Temporales:**
- Generados localmente por el CLI
- Específicos de la rama actual
- Se invalidan si cambias de rama
- Se usan para análisis en feature branches

**Snapshot Canonical:**
- Generado por el backend
- Representa el estado estable
- No cambia al cambiar de rama
- Base para comparación

---

## 🚀 Inicialización de Proyecto

### Opción 1: Proyecto desde Plataforma

Si tu proyecto ya existe en la plataforma Hacki:

```bash
hacki init
```

**Flujo:**
1. Selecciona tu proyecto de la lista
2. El CLI intenta obtener el snapshot canonical del backend
3. Si existe: se guarda automáticamente
4. Si no existe: te pregunta si deseas generarlo

**Ejemplo:**
```
📋 Recursos disponibles:
  1. 📁 Mi Proyecto - Descripción del proyecto
  2. 🔗 mi-repo (GitHub) - Repositorio existente
  3. 🆕 Crear proyecto local (sin conectar con plataforma)

Selecciona un recurso: 1

✅ Snapshot canonical obtenido del backend
✅ Configuración guardada en .hacki/project.json
```

### Opción 2: Repositorio Existente

Si seleccionas un repositorio existente:

```bash
hacki init
```

**Importante:** El repositorio **DEBE** tener un snapshot canonical en el backend. Si no existe, verás un error y deberás contactar al administrador.

### Opción 3: Crear Proyecto Local

Para crear un proyecto nuevo sin conectar con la plataforma:

```bash
hacki init
```

**Flujo:**
1. Selecciona "🆕 Crear proyecto local"
2. El CLI valida que estés en una rama base (main/develop)
3. Genera snapshot canonical automáticamente
4. Opcionalmente puedes crear el proyecto en la plataforma después

**Ejemplo:**
```
📋 Recursos disponibles:
  ...
  3. 🆕 Crear proyecto local (sin conectar con plataforma)

Selecciona un recurso: 3

⚠️  Advertencia: No estás en una rama base (rama actual: feature/new-feature)
¿Deseas continuar de todos modos? [y/N]: n

📊 Generando snapshot canonical inicial...
   📊 Construyendo grafo completo...
✅ Snapshot canonical guardado localmente

¿Deseas crear este proyecto en la plataforma? [y/N]: y
Ingresa el nombre del proyecto: Mi Nuevo Proyecto
✅ Proyecto creado en la plataforma (ID: proj123)
✅ Snapshot enviado al backend
```

---

## 🔄 Sincronización de Snapshots

### Sincronización Manual

Para sincronizar el snapshot canonical desde el backend:

```bash
hacki sync
```

**Características:**
- Solo funciona en ramas base (main/develop)
- Descarga el snapshot más reciente del backend
- Actualiza archivos locales
- Muestra estadísticas del snapshot

**Ejemplo:**
```bash
$ hacki sync

🔄 Sincronizando snapshot canonical desde backend...
   Rama: main
   Commit: abc123...
✅ Snapshot canonical sincronizado exitosamente
   Archivos: 55
   Última sincronización: 2024-01-15T09:00:00
```

### Sincronización Automática (Git Hooks)

El CLI instala automáticamente hooks de Git que sincronizan después de `git pull`:

**Hook `post-merge`:**
- Se ejecuta después de `git pull` o `git merge`
- Detecta si estás en main/develop
- Ejecuta `hacki sync --auto` silenciosamente
- No interrumpe el flujo de Git

**Hook `post-checkout`:**
- Se ejecuta al cambiar de rama
- Informativo (no sincroniza automáticamente)

### Forzar Sincronización

Si necesitas forzar la sincronización aunque el snapshot esté actualizado:

```bash
hacki sync --force
```

---

## 🔍 Análisis de Código

### Review Básico

```bash
hacki review archivo.py
```

**Qué hace:**
1. Construye/actualiza grafos temporales si es necesario
2. Si hay snapshot canonical, lo compara contra el código actual
3. Identifica archivos nuevos, modificados, eliminados
4. Envía análisis al backend con contexto completo

### Review con Snapshot

Cuando ejecutas `hacki review`, el CLI automáticamente:

1. **Verifica snapshot:**
   - Si estás en main/develop y el snapshot está desactualizado → sincroniza automáticamente
   - Si no hay snapshot → continúa con análisis temporal

2. **Compara contra snapshot:**
   - Identifica archivos nuevos
   - Identifica archivos eliminados
   - Cuenta archivos modificados
   - Incluye esta información en el payload al backend

3. **Incluye contexto:**
   - `repo_id`: ID del repositorio (si aplica)
   - `branch`: Rama actual de Git
   - `commit_sha`: SHA del commit actual
   - `base_branch`: Rama base detectada (main/develop)

### Ejemplo de Payload

El payload enviado al backend incluye:

```json
{
  "files": [...],
  "repo_id": "repo123",
  "branch": "feature/new-feature",
  "commit_sha": "def456...",
  "base_branch": "main",
  "code_graph": {
    "tree_sitter": {...},
    "static_analysis": {...}
  },
  "snapshot_comparison": {
    "has_snapshot": true,
    "new_files": ["src/new_file.py"],
    "deleted_files": ["src/old_file.py"],
    "modified_files_count": 5,
    "total_files_in_snapshot": 55,
    "total_files_current": 56
  }
}
```

---

## 🏛️ Historial y Gestión de Hallazgos

A diferencia de versiones anteriores, el historial de Hacki ahora se sincroniza plenamente con el servidor, permitiendo gestionar el estado de los hallazgos (issues) de forma persistente.

### 📜 Comando History

Para ver el historial de análisis (reviews) que has realizado:

```bash
hacki history [OPTIONS]
```

**Parámetros:**
- `--page` (int): Número de página (Default: 1).
- `--size` (int): Cantidad de resultados por página (Default: 10).
- `--filename` (str): Filtra reviews que incluyan un archivo específico.

**Ejemplo:**
```bash
$ hacki history --size 5
Historial de Reviews (Página 1/3)
Review ID                             Archivo      Tipo      Hallazgos   Fecha
18683cf1-cfc8-4171-8976-d2580d9beb9f  main.py      security  15 (3 CRIT) 2026-01-16 10:30
...
```

### 🔍 Detalle de Hallazgos

Para ver todos los problemas detectados en un análisis específico:

```bash
hacki review-detail <UUID> [OPTIONS]
```

**Parámetros:**
- `<UUID>` (Argumento): El ID del review obtenido del historial.
- `--status` (text): Filtra por estado (`pending`, `resolved`, `ignored`). Puede repetirse.
- `--severity` (text): Filtra por severidad (`CRITICAL`, `HIGH`, etc.).

### 🐚 Uso en Modo Interactivo (hacki start)

Dentro del shell interactivo, puedes gestionar tus hallazgos de forma visual:

1. **/history**: Lista los últimos análisis remotos.
2. **/show `<UUID>`**: Carga los hallazgos de ese análisis en el chat.
3. **Gestión de Estados**: Al expandir un hallazgo (haciendo click), aparecerán botones interactivos:
   - **Resolve**: Marca el hallazgo como solucionado en el servidor.
   - **Ignore**: Marca el hallazgo para ser ignorado en futuros reportes.
   - **Pending**: Devuelve el hallazgo al estado inicial.

### 🔄 Actualización Manual de Estado

Si prefieres usar la terminal tradicional:

```bash
hacki update-status <ReviewUUID> <IssueUUID> <status>
```

Donde `<status>` es `pending`, `resolved` o `ignored`.

---

## 🛠️ Troubleshooting

### Error: "No se encontró job_id en la configuración del proyecto"

**Causa:** El proyecto no está vinculado con el backend.

**Solución:**
1. Ejecuta `hacki init` y selecciona un proyecto de la plataforma
2. O crea un proyecto local y luego créalo en la plataforma

### Error: "Este repositorio no tiene snapshot canonical"

**Causa:** El repositorio seleccionado no tiene snapshot en el backend.

**Solución:**
- Contacta al administrador del sistema
- O crea un proyecto nuevo desde la plataforma

### Warning: "Snapshot desactualizado"

**Causa:** El snapshot local no coincide con el commit actual.

**Solución:**
```bash
hacki sync
```

### Los grafos se regeneran cada vez

**Causa:** Estás cambiando de rama frecuentemente.

**Explicación:** Esto es normal. Los grafos temporales se invalidan al cambiar de rama para mantener consistencia.

**Solución:** 
- Usa `hacki sync` en ramas base para obtener snapshot canonical
- Los grafos temporales se regeneran automáticamente cuando es necesario

### No se detecta la rama base

**Causa:** Git no está configurado o no estás en un repositorio Git.

**Solución:**
```bash
git init  # Si no es un repo Git
git checkout -b main  # Si no estás en main
```

---

## 📚 Comandos Relacionados

### Ver Estado del Proyecto

```bash
hacki status
```

Muestra:
- Configuración del proyecto
- Estado de sincronización
- Información de Git

### Ver Grafos

```bash
hacki graph --stats
```

Muestra estadísticas de los grafos generados.

### Reconstruir Grafos

```bash
hacki graph --rebuild
```

Reconstruye todos los grafos desde cero.

---

## 💡 Mejores Prácticas

1. **Sincroniza regularmente:**
   - Ejecuta `hacki sync` después de `git pull` en main/develop
   - Los hooks lo hacen automáticamente

2. **Usa ramas base para snapshots:**
   - Los snapshots canonical solo se generan en main/develop
   - Las feature branches usan grafos temporales

3. **No modifiques snapshots manualmente:**
   - Los snapshots canonical son gestionados por el backend
   - Solo usa `hacki sync` para actualizarlos

4. **Revisa antes de commit:**
   - Usa `hacki review --modified` antes de hacer commit
   - Esto te ayuda a detectar problemas temprano

---

## 🔗 Recursos Adicionales

- [Formatos de Archivos](./FILE_FORMATS.md) - Documentación técnica de formatos
- [README Principal](../README.md) - Documentación general del proyecto

