# HackiAI — MCP & VS Code Plugin: Referencia Técnica

> Documento de referencia para el equipo que desarrollará el **MCP (Model Context Protocol)** y el **plugin de VS Code**. Cubre autenticación, tipos de archivo reconocidos, flujos de análisis, commit review y generación de grafos.

---

## Índice

1. [Visión general](#1-visión-general)
2. [Autenticación](#2-autenticación)
3. [Tipos de archivo reconocidos](#3-tipos-de-archivo-reconocidos)
4. [Flujo: Code Review](#4-flujo-code-review)
5. [Flujo: Commit Review](#5-flujo-commit-review)
6. [Flujo: Historial y gestión de hallazgos](#6-flujo-historial-y-gestión-de-hallazgos)
7. [Flujo: Generación de grafos](#7-flujo-generación-de-grafos)
8. [Seguimiento de progreso en tiempo real (WebSocket)](#8-seguimiento-de-progreso-en-tiempo-real-websocket)
9. [Estructura de datos completa](#9-estructura-de-datos-completa)
10. [Manejo de errores](#10-manejo-de-errores)
11. [Herramientas MCP a exponer (beta)](#11-herramientas-mcp-a-exponer-beta)

---

## 1. Visión general

HackiAI es un sistema de análisis de seguridad de código basado en IA. El MCP y el plugin de VS Code deben exponer las siguientes capacidades principales:

| Capacidad | Descripción |
|-----------|-------------|
| **Code Review** | Analiza archivos individuales, listas de archivos o directorios completos. Detecta automáticamente código, IaC y dependencias. |
| **Commit Review** | Analiza archivos staged, genera hallazgos y sugiere un mensaje de commit en formato Conventional Commits o simple. |
| **Historial** | Lista reviews pasados y sus hallazgos. Permite filtrar y paginar. |
| **Gestión de hallazgos** | Marca hallazgos como resueltos, ignorados o pendientes. |
| **Code Graph** | Genera representaciones de árbol sintáctico (AST/tree-sitter) y análisis estático (CFG, DFG, IR) para mejorar la calidad del análisis. |

### URLs base

```
# Producción
API_URL  = https://api.hacki.ai
WS_URL   = wss://api.hacki.ai

# Desarrollo local
API_URL  = http://127.0.0.1:5008
WS_URL   = ws://localhost:5008
```

---

## 2. Autenticación

Todos los endpoints requieren una API Key proporcionada por header HTTP:

```
X-API-Key: <api-key-del-usuario>
```

### Configuración local

La CLI guarda la API Key en `~/.hacki_cli/config.json`:

```json
{ "api_key": "hacki_xxxxxxxxxxxxxxxxxxxxxxxx" }
```

### Configuración de proyecto — detección automática

El proyecto puede estar asociado a un recurso HackiAI. El MCP debe **buscar automáticamente** el archivo `.hacki/project.json` subiendo directorios desde el CWD (o el directorio del archivo analizado), igual que hace `git` para encontrar `.git/`.

**Algoritmo de búsqueda:**
```
directorio_actual = CWD (o directorio del archivo)
mientras directorio_actual != raíz del filesystem:
    si existe directorio_actual/.hacki/project.json → usar ese archivo
    subir un nivel
si no se encontró → buscar ~/.hacki/config.json (config global)
si tampoco → omitir project_id/repo_id del payload (OK, funciona igual)
```

**Contenido del archivo `.hacki/project.json`:**

```json
{
  "resource_type": "project",
  "resource_id": "uuid-del-proyecto",
  "name": "Mi Proyecto",
  "job_id": "uuid-del-job"
}
```

**Cómo incluirlo en el payload según `resource_type`:**
- `"project"` → agregar `"project_id": "<resource_id>"`
- `"repository"` → agregar `"repo_id": "<resource_id>"`

> La asociación a proyecto es **completamente automática** — no requiere configuración manual del usuario en el MCP. El archivo `.hacki/project.json` lo crea el comando `hacki init` del CLI.

### Obtener recursos disponibles del usuario

```http
GET /cli/resources
X-API-Key: <key>
```

**Response:**
```json
{
  "projects": [
    { "id": "uuid", "name": "Mi Proyecto" }
  ],
  "repositories": [
    { "id": "uuid", "name": "mi-repo" }
  ]
}
```

---

## 3. Tipos de archivo reconocidos

El sistema clasifica automáticamente cada archivo en uno de tres tipos. **El tipo determina el motor de análisis** que se usará en el backend (LLM, Trivy, etc.).

### 3.1 `"code"` — Código fuente

Tabla completa de extensión → valor exacto del campo `language` que espera la API:

| Extensión(es) | `language` |
|--------------|------------|
| `.py`, `.pyw` | `"python"` |
| `.js`, `.jsx` | `"javascript"` |
| `.ts`, `.tsx` | `"typescript"` |
| `.java` | `"java"` |
| `.go` | `"go"` |
| `.rs` | `"rust"` |
| `.c`, `.h` | `"c"` |
| `.cpp`, `.cc`, `.hpp` | `"cpp"` |
| `.cs` | `"csharp"` |
| `.rb` | `"ruby"` |
| `.php` | `"php"` |
| `.swift` | `"swift"` |
| `.kt` | `"kotlin"` |
| `.scala` | `"scala"` |
| `.sh`, `.bash` | `"bash"` |
| `.ps1` | `"powershell"` |
| `.sql` | `"sql"` |
| `.html` | `"html"` |
| `.css` | `"css"` |
| `.vue` | `"vuejs"` |
| `.svelte` | `"svelte"` |
| `.dart` | `"dart"` |
| `.hs` | `"haskell"` |
| `.lua` | `"lua"` |
| `.r` | `"r"` |
| `.jl` | `"julia"` |
| `.ex`, `.exs` | `"elixir"` |
| `.erl` | `"erlang"` |
| `.nim` | `"nim"` |
| `.zig` | `"zig"` |
| `.bat`, `.cmd` | `"batch"` |
| `.json` | `"json"` |
| `.yml`, `.yaml` | `"yaml"` |
| `.xml` | `"xml"` |
| `.toml` | `"toml"` |
| `Dockerfile`, `Dockerfile.*` | `"dockerfile"` |
| `.github/workflows/*.yml` | `"github-actions"` |
| Desconocida | `""` (cadena vacía) |

> **Casos comunes que difieren de lo esperado:**
> - `.jsx` → `"javascript"` (NO `"jsx"`)
> - `.tsx` → `"typescript"` (NO `"tsx"`)
> - `.cs` → `"csharp"` (NO `"c#"`)
> - `.cpp`/`.cc` → `"cpp"` (NO `"c++"`)
> - `.sh`/`.bash` → `"bash"` (NO `"shell"`)

### 3.2 `"dependency"` — Archivos de dependencias

Se detectan por nombre exacto de archivo:

| Ecosistema | Archivos |
|-----------|---------|
| Python | `requirements.txt`, `Pipfile`, `Pipfile.lock`, `poetry.lock`, `pyproject.toml` |
| Node.js | `package.json`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml` |
| PHP | `composer.json`, `composer.lock` |
| Ruby | `Gemfile`, `Gemfile.lock` |
| Rust | `Cargo.toml`, `Cargo.lock` |
| Go | `go.mod`, `go.sum` |
| Java | `pom.xml` |

> **Nota:** Los archivos de dependencias se agrupan con sus lock files correspondientes y se analizan juntos con nuestro motor para detectar CVEs.

### 3.3 `"infrastructure"` — Infraestructura como código

Se detectan por extensión, nombre de archivo o directorio padre:

**Por extensión:**
- `.tf`, `.tf.json` — Terraform
- `.bicep` — Azure Bicep
- `.rego` — Open Policy Agent
- `.jsonnet` — Jsonnet

**Por nombre de archivo:**
- `Dockerfile`, `docker-compose.yml`, `docker-compose.yaml`
- `serverless.yml`, `serverless.yaml`, `serverless.json`
- `.gitlab-ci.yml`, `.travis.yml`, `Jenkinsfile`
- `Chart.yaml` (Helm), `values.yaml` (Helm)
- Playbooks de Ansible (`playbook.yml`, `site.yml`)

**Por directorio padre:**
- `.github/workflows/`, `.circleci/`, `terraform/`, `kubernetes/`, `k8s/`, `helm/`, `charts/`, `templates/`

Los archivos `.yaml`/`.yml`/`.json` dentro de esos directorios también se tratan como IaC.

### Algoritmo de detección

Para implementar la detección en el MCP/plugin, seguir este orden de prioridad:

```
1. ¿El nombre del archivo está en DEPENDENCY_FILES? → "dependency"
2. ¿Es un archivo IaC por nombre, extensión o directorio? → "infrastructure"
3. ¿Tiene extensión de código fuente reconocida? → "code"
4. Default → "code"
```

---

## 4. Flujo: Code Review

### 4.1 Descripción general

```
Cliente                               Servidor
  │                                      │
  ├─ POST /analisis/review ─────────────►│
  │    gzip({ files, code_graph, ... })  │ (encola tareas Celery)
  │◄─ 202 { tasks: [{task_id}] } ───────┤
  │                                      │
  │  Para cada task_id:                  │
  ├─ WS /analisis/ws/tasks/{id} ────────►│
  │◄─ progress / completed ──────────────┤
  │                                      │
  │  (fallback si WS no disponible)      │
  ├─ GET /analisis/task/{task_id} ───────►│ (polling cada 3s)
  │◄─ { status, result } ────────────────┤
```

### 4.2 Preparar archivos

Cada archivo del array `files` debe tener esta estructura:

```json
{
  "filename": "app.py",
  "code": "1: import os\n2: password = 'secret'\n...",
  "language": "python",
  "type": "code",
  "sd": false,
  "file_path": "/ruta/absoluta/al/archivo/app.py",
  "processed": false,

  "diff": "--- a/app.py\n+++ b/app.py\n...",
  "git_metadata": {
    "author": "Dev Name",
    "email": "dev@example.com",
    "date": "2026-02-24T10:00:00",
    "message": "último mensaje de commit",
    "sha": "abc123def456"
  }
}
```

| Campo | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| `filename` | string | ✅ | Nombre del archivo (sin ruta) |
| `code` | string | ✅ | Contenido del archivo. Para código: incluir números de línea en formato `N: contenido` |
| `language` | string | ✅ | Lenguaje detectado (`"python"`, `"javascript"`, etc.) |
| `type` | string | ✅ | Tipo: `"code"`, `"dependency"`, `"infrastructure"` |
| `sd` | boolean | ✅ | Static dependency flag — siempre `false` para el MCP |
| `file_path` | string | ✅ | Ruta absoluta en el filesystem del cliente |
| `processed` | boolean | ✅ | Siempre `false` para archivos nuevos |
| `diff` | string | ❌ | Resultado de `git diff <archivo>` (mejora la calidad) |
| `git_metadata` | object | ❌ | Metadata del último commit del archivo (mejora la calidad) |

> **Formato con números de línea:** El CLI añade `N: ` al inicio de cada línea para que el modelo pueda referenciar líneas exactas en los hallazgos. Ejemplo: `"1: def login():\n2:     password = 'admin'\n"`

### 4.3 Enviar el review

El payload se **serializa a JSON, se comprime con gzip** y se envía con el header `Content-Encoding: gzip`.

```http
POST /analisis/review
Content-Type: application/json
Content-Encoding: gzip
X-API-Key: <key>

<body: JSON serializado y comprimido con gzip>
```

**Payload JSON (antes de comprimir):**

```json
{
  "files": [
    {
      "filename": "app.py",
      "code": "1: import os\n2: password = 'secret'\n",
      "language": "python",
      "type": "code",
      "sd": false,
      "file_path": "/workspace/app.py",
      "processed": false,
      "diff": "--- a/app.py\n+++ b/app.py\n@@ ...",
      "git_metadata": { "author": "Dev", "sha": "abc123" }
    },
    {
      "filename": "requirements.txt",
      "code": "flask==2.0.0\nrequests==2.28.0\n",
      "language": "text",
      "type": "dependency",
      "sd": false,
      "file_path": "/workspace/requirements.txt",
      "processed": false
    }
  ],
  "code_graph": {
    "tree_sitter": {
      "nodes": [...],
      "edges": [...]
    },
    "static_analysis": {
      "ir_files": { "app.py": "<representación IR del código>" },
      "cfg_files": { "app.py": "<control flow graph serializado>" },
      "dfg_files": { "app.py": "<data flow graph serializado>" },
      "stats": { "functions": 5, "classes": 1, "imports": 3 }
    }
  },
  "project_id": "uuid-proyecto",
  "repo_id": "uuid-repo",
  "branch": "main",
  "commit_sha": "abc123def456",
  "base_branch": "main"
}
```

> **`code_graph` es opcional** pero mejora significativamente la calidad del análisis. Si el MCP no puede generarlo (tree-sitter no disponible, error, etc.), se puede omitir el campo y el análisis continúa igualmente.

**Serialización en código (ejemplo Python):**

```python
import gzip, json, requests

payload = { "files": [...], "code_graph": {...}, "branch": "main" }
body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
compressed = gzip.compress(body)

response = requests.post(
    "https://api.hacki.ai/analisis/review",
    data=compressed,
    headers={
        "X-API-Key": api_key,
        "Content-Type": "application/json",
        "Content-Encoding": "gzip",
    },
    timeout=90,
)
```

**Serialización en código (ejemplo TypeScript):**

```typescript
import zlib from "zlib";

const payload = { files, code_graph, branch: "main" };
const body = Buffer.from(JSON.stringify(payload), "utf-8");
const compressed = zlib.gzipSync(body);

const response = await fetch("https://api.hacki.ai/analisis/review", {
  method: "POST",
  body: compressed,
  headers: {
    "X-API-Key": apiKey,
    "Content-Type": "application/json",
    "Content-Encoding": "gzip",
  },
});
```

**Response 202:**

```json
{
  "tasks": [
    {
      "task_id": "celery-task-uuid-1",
      "filename": "app.py",
      "type": "code",
      "file_path": "/workspace/app.py",
      "error": null
    },
    {
      "task_id": "celery-task-uuid-2",
      "filename": "requirements.txt",
      "type": "dependency",
      "file_path": "/workspace/requirements.txt",
      "error": null
    }
  ]
}
```

> Si una tarea tiene `"error": "mensaje"` en lugar de `task_id`, ese archivo no pudo encolarse. Mostrar el error al usuario y continuar con los demás.

### 4.4 Obtener resultados por tarea

#### Opción A: WebSocket (recomendado para tiempo real)

```
WS /analisis/ws/tasks/{task_id}?api_key={key}
```

Ver sección 8 para el protocolo WebSocket completo.

#### Opción B: HTTP Polling

```http
GET /analisis/task/{task_id}
X-API-Key: <key>
```

Hacer polling cada 3 segundos hasta que `status` sea `"success"`, `"completed"` o `"error"`.

**Response mientras procesa:**
```json
{ "status": "pending" }
```

**Response cuando completa:**
```json
{
  "status": "success",
  "result": {
    "filename": "app.py",
    "value": [
      {
        "line": 2,
        "severity": "HIGH",
        "issue": "Hardcoded password",
        "description": "Password is hardcoded in source code",
        "suggestion": "Use environment variables",
        "suggestion_code": "password = os.getenv('DB_PASSWORD')",
        "priority": "P1",
        "original_severity": "HIGH"
      }
    ]
  }
}
```

### 4.5 Estructura de resultado según tipo de archivo

#### `"code"` — campo `value`

```json
{
  "value": [
    {
      "line": 42,
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO",
      "issue": "Título del hallazgo",
      "description": "Descripción detallada",
      "suggestion": "Cómo resolver",
      "suggestion_code": "// código de ejemplo",
      "priority": "P1",
      "original_severity": "HIGH"
    }
  ]
}
```

#### `"dependency"` — campo `propuestas`

```json
{
  "propuestas": [
    {
      "line": 1,
      "severity": "HIGH",
      "issue": "CVE-2023-12345 en flask 2.0.0",
      "description": "Vulnerabilidad conocida en esta versión",
      "suggestion": "Actualizar a flask>=2.3.0"
    }
  ]
}
```

#### `"infrastructure"` — campo `misconfigurations`

```json
{
  "misconfigurations": [
    {
      "id": "AVD-AWS-0001",
      "line": 15,
      "end_line": 20,
      "severity": "CRITICAL",
      "issue": "S3 bucket is publicly accessible",
      "description": "Descripción detallada",
      "suggestion": "Deshabilitar acceso público",
      "resource": "aws_s3_bucket.main",
      "file": "main.tf",
      "references": ["https://avd.aquasec.com/..."]
    }
  ]
}
```

### 4.6 Modos de selección de archivos

El MCP debe soportar estos modos (a decidir por el tool call):

| Modo | Descripción | Cómo obtener los archivos |
|------|-------------|--------------------------|
| **Single file** | Un archivo específico | Leer el archivo directamente |
| **Files list** | Lista de paths | Leer cada archivo |
| **Directory** | Directorio recursivo | Caminar el árbol de directorios |
| **Modified** | Archivos modificados en git | `git diff --name-only HEAD` |
| **Staged** | Archivos en staging | `git diff --cached --name-only` |

En todos los casos, aplicar el filtro `.hackiignore` si existe (ver [HACKI_IGNORE.md](HACKI_IGNORE.md)).

---

## 5. Flujo: Commit Review

El commit review analiza los archivos staged y además **genera un mensaje de commit sugerido** usando LLM.

### 5.1 Descripción general

```
Cliente                               Servidor
  │                                      │
  ├─ POST /analisis/commit-review ──────►│
  │    { files, commit_message_style }   │
  │◄─ 202 { commit_review_id, tasks } ──┤
  │                                      │
  ├─ WS /ws/commit-review/{id} ────────►│ (tiempo real)
  │◄─ progress / completed ─────────────┤
  │                                      │
  │  (fallback polling)                  │
  ├─ GET /analisis/commit-review/{id}/results ►│
  │◄─ { status, findings, commit_message } ────┤
```

### 5.2 Preparar el payload

Los archivos tienen el mismo formato que el review estándar. El payload también incluye `code_graph` y se envía **comprimido con gzip** igual que el review estándar:

```json
{
  "files": [
    {
      "filename": "app.py",
      "code": "1: def login():\n2:     pass\n",
      "language": "python",
      "type": "code",
      "sd": false,
      "file_path": "/workspace/app.py",
      "processed": false
    }
  ],
  "code_graph": {
    "tree_sitter": { "nodes": [...], "edges": [...] },
    "static_analysis": {
      "ir_files": { "app.py": "<representación IR del código>" },
      "cfg_files": { "app.py": "<control flow graph serializado>" },
      "dfg_files": { "app.py": "<data flow graph serializado>" },
      "stats": { "functions": 5, "classes": 1, "imports": 3 }
    }
  },
  "commit_message_style": "conventional",
  "diff": "<output de git diff --cached>",
  "project_id": "uuid-proyecto",
  "repo_id": "uuid-repo",
  "branch": "feature/login",
  "commit_sha": "abc123",
  "base_branch": "main"
}
```

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `commit_message_style` | string | `"conventional"` (default) o `"simple"` |
| `code_graph` | object | Igual estructura que en el review estándar (opcional) |
| `diff` | string | Output de `git diff --cached` (mejora el mensaje generado) |

### 5.3 Enviar el commit review

Mismo esquema de compresión gzip que el review estándar:

```http
POST /analisis/commit-review
Content-Type: application/json
Content-Encoding: gzip
X-API-Key: <key>

<body: JSON serializado y comprimido con gzip>
```

**Response 202:**

```json
{
  "commit_review_id": "uuid-del-commit-review",
  "tasks": [
    {
      "task_id": "celery-task-uuid",
      "filename": "app.py",
      "type": "code"
    }
  ]
}
```

### 5.4 Obtener resultados completos

#### Opción A: WebSocket

```
WS /ws/commit-review/{commit_review_id}?api_key={key}
```

El mensaje final tiene `type: "completed"` y los campos en el nivel raíz (ver sección 8).

#### Opción B: HTTP Polling

```http
GET /analisis/commit-review/{commit_review_id}/results
X-API-Key: <key>
```

Polling cada 2-3 segundos. Máximo 60 intentos (aprox. 2 minutos).

**Response cuando completa (status: "completed"):**

```json
{
  "status": "completed",
  "commit_message": "fix(security): remove hardcoded credentials",
  "commit_message_body": "Replace hardcoded password with environment variable\n\n- app.py:2 — hardcoded password removed",
  "findings": [
    {
      "filename": "app.py",
      "issues": [
        {
          "line": 2,
          "severity": "HIGH",
          "issue": "Hardcoded password",
          "description": "...",
          "suggestion": "...",
          "suggestion_code": "password = os.getenv('DB_PASSWORD')",
          "original_severity": "HIGH",
          "priority": "P1"
        }
      ]
    }
  ],
  "findings_summary": {
    "critical": 0,
    "high": 1,
    "medium": 0,
    "low": 0,
    "total": 1
  },
  "files_analyzed": ["app.py"],
  "analysis_time": 8.3,
  "error": null
}
```

**Response mientras procesa (status: "pending"):**

```json
{
  "status": "pending",
  "commit_message": null,
  "findings": null,
  "findings_summary": null,
  "error": null
}
```

### 5.5 Estilos de mensaje de commit

**`"conventional"`** (Conventional Commits):
```
fix(security): remove hardcoded credentials
feat(auth): add JWT authentication
refactor(api): improve error handling
chore: update dependencies to latest stable
```

**`"simple"`**:
```
Fix security issues in auth module
Add user authentication
Refactor API layer
```

---

## 6. Flujo: Historial y gestión de hallazgos

### 6.1 Listar reviews del usuario

```http
GET /analisis-cli/reviews
X-API-Key: <key>
```

**Query params:**

| Param | Tipo | Default | Descripción |
|-------|------|---------|-------------|
| `page` | int | 1 | Número de página |
| `size` | int | 20 | Resultados por página (máx 100) |
| `start_date` | ISO 8601 | — | Filtrar desde esta fecha |
| `end_date` | ISO 8601 | — | Filtrar hasta esta fecha |
| `filename` | string | — | Búsqueda parcial por nombre de archivo |
| `sort` | string | `created_at_desc` | `created_at_desc`, `created_at_asc`, `filename_asc`, `filename_desc` |

**Response:**

```json
{
  "items": [
    {
      "id": "uuid-review",
      "filename": "app.py",
      "type": "security",
      "total_issues": 15,
      "low_quantity": 5,
      "medium_quantity": 6,
      "high_quantity": 3,
      "critical_quantity": 1,
      "highest_severity": "CRITICAL",
      "created_at": "2026-02-24T10:30:00"
    }
  ],
  "pagination": {
    "total": 45,
    "page": 1,
    "size": 20,
    "pages": 3,
    "has_next": true,
    "has_prev": false
  }
}
```

### 6.2 Listar hallazgos de un review

```http
GET /analisis-cli/reviews/{review_id}/issues
X-API-Key: <key>
```

**Query params:**

| Param | Tipo | Descripción |
|-------|------|-------------|
| `page` | int | Número de página |
| `size` | int | Resultados por página (máx 200) |
| `severity` | string[] | `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` (repetible) |
| `status` | string[] | `pending`, `resolved`, `ignored` (repetible) |
| `filename` | string | Filtro parcial por archivo |
| `sort` | string | `severity_asc` (default), `severity_desc`, `line_asc`, `line_desc`, `created_at_desc` |

**Response:**

```json
{
  "items": [
    {
      "id": "uuid-issue",
      "filename": "app.py",
      "line": 42,
      "issue": "SQL Injection vulnerability",
      "description": "User input is directly concatenated into SQL query",
      "severity": "CRITICAL",
      "suggestion": "Use parameterized queries",
      "fixed_code": "cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
      "original_severity": "CRITICAL",
      "priority": "P1",
      "status": "pending",
      "created_at": "2026-02-24T10:30:00"
    }
  ],
  "pagination": {
    "total": 15,
    "page": 1,
    "size": 50,
    "pages": 1,
    "has_next": false,
    "has_prev": false
  },
  "total_issues_in_review": 15
}
```

### 6.3 Actualizar estado de un hallazgo

```http
PATCH /analisis-cli/reviews/{review_id}/issues/{issue_id}/status
Content-Type: application/json
X-API-Key: <key>

{ "status": "resolved" }
```

**Valores válidos de `status`:**
- `"pending"` — pendiente (estado inicial)
- `"resolved"` — resuelto/corregido
- `"ignored"` — ignorado/wontfix

**Response 200:** El issue actualizado (mismo schema que en la lista).

---

## 7. Code Graph: generación e inclusión en el payload

El `code_graph` se incluye en **ambos endpoints** (`/analisis/review` y `/analisis/commit-review`). Es **opcional** pero mejora significativamente la calidad del análisis, especialmente para detectar problemas cross-file.

### 7.0 Cómo se genera el grafo

El CLI genera el grafo usando el paquete interno `hacki.graph` (Python). Dependencias requeridas:
- **`tree-sitter-languages`** — gramáticas precompiladas para 40+ lenguajes
- **`networkx`** — estructura del grafo en memoria
- **`hacki.graph.orchestrator.GraphOrchestrator`** — coordina el análisis completo
- **`hacki.graph.manager.EnhancedGraphManager`** — gestiona AST + IR/CFG/DFG

El MCP puede replicar esto usando los bindings de `tree-sitter` disponibles para el lenguaje de implementación (Python, TypeScript, etc.). Si por alguna razón no es posible generarlo, el campo `code_graph` puede omitirse — la API funciona correctamente sin él, aunque la calidad del análisis mejora cuando está presente.

### 7.1 Qué contiene el grafo

```json
{
  "code_graph": {
    "tree_sitter": {
      "nodes": [
        { "id": "func_login", "type": "function", "name": "login", "file": "app.py", "line": 10 }
      ],
      "edges": [
        { "source": "func_login", "target": "func_validate_password", "type": "calls" }
      ]
    },
    "static_analysis": {
      "ir_files": {
        "app.py": "<representación IR del código>"
      },
      "cfg_files": {
        "app.py": "<control flow graph serializado>"
      },
      "dfg_files": {
        "app.py": "<data flow graph serializado>"
      },
      "stats": {
        "functions": 12,
        "classes": 3,
        "imports": 8
      }
    }
  }
}
```

| Componente | Descripción |
|-----------|-------------|
| `tree_sitter.nodes` | Nodos del AST: funciones, clases, variables, llamadas. Generado con tree-sitter. |
| `tree_sitter.edges` | Relaciones entre nodos: `calls`, `imports`, `inherits`, `defines` |
| `static_analysis.ir_files` | Intermediate Representation por archivo (si disponible). Clave: ruta absoluta del archivo. |
| `static_analysis.cfg_files` | Control Flow Graph por archivo (si disponible). Clave: ruta absoluta del archivo. |
| `static_analysis.dfg_files` | Data Flow Graph por archivo (si disponible). Clave: ruta absoluta del archivo. |
| `static_analysis.stats` | Estadísticas globales: cantidad de funciones, clases e imports analizados. |

### 7.2 Cuándo incluir el grafo

| Escenario | Recomendación |
|-----------|--------------|
| Archivo único pequeño | Omitir — overhead no justificado |
| Múltiples archivos relacionados | Incluir si tree-sitter está disponible |
| Review de directorio | Incluir — mejora detección cross-file |
| Commit review | Incluir siempre que sea posible |
| tree-sitter no disponible | Omitir el campo `code_graph` y continuar |

### 7.3 Protocolo chunked para commit review con archivos grandes

El endpoint de commit review soporta un protocolo alternativo vía WebSocket para cuando el payload supera 1 MB o hay más de 3 archivos:

**Protocolo 1 — Simple (recomendado):** todo en un solo request HTTP gzip.

**Protocolo 2 — Chunked (WebSocket):** se envía metadata primero, luego cada archivo por separado.

> Usar siempre **Protocolo 1** (HTTP gzip). El Protocolo 2 existe para casos extremos del CLI y no es necesario para el MCP.

---

## 8. Seguimiento de progreso en tiempo real (WebSocket)

### 8.1 Review estándar — por tarea

```
WS /analisis/ws/tasks/{task_id}?api_key={key}
```

**Parámetros de conexión recomendados:**
- `ping_interval`: 20s
- `ping_timeout`: 30s
- `open_timeout`: 10s
- Timeout total: 180s

**Mensajes del servidor:**

```json
{ "type": "connected" }

{ "type": "progress", "current": 2, "total": 5, "message": "Analizando funciones...", "stage": "analysis" }

{ "type": "completed", "data": { /* resultado de la tarea */ } }

{ "type": "error", "message": "Descripción del error" }

{ "type": "keepalive" }
```

### 8.2 Commit review — resultado completo

```
WS /ws/commit-review/{commit_review_id}?api_key={key}
```

Los mensajes de progreso son iguales. El mensaje final tiene la estructura del resultado directamente en el nivel raíz:

```json
{
  "type": "completed",
  "commit_message": "fix(security): remove hardcoded credentials",
  "commit_message_body": "...",
  "findings": [...],
  "findings_summary": { "critical": 0, "high": 1, "medium": 0, "low": 0, "total": 1 }
}
```

### 8.3 Fallback a HTTP polling

Si la conexión WebSocket falla, usar polling HTTP:

- **Review por tarea:** `GET /analisis/task/{task_id}` (cada 3s, máx 60 intentos)
- **Commit review:** `GET /analisis/commit-review/{id}/results` (cada 2s, máx 60 intentos)

---

## 9. Estructura de datos completa

### FileInput (para enviar a la API)

```typescript
interface FileInput {
  filename: string;          // Nombre del archivo
  code: string;              // Contenido (con números de línea para código)
  language: string;          // Lenguaje detectado
  type: "code" | "dependency" | "iac";
  sd: boolean;               // Siempre false
  file_path: string;         // Ruta absoluta
  processed: boolean;        // Siempre false
  diff?: string;             // git diff del archivo (opcional)
  git_metadata?: {           // Metadata del último commit (opcional)
    author: string;
    email: string;
    date: string;            // ISO 8601
    message: string;
    sha: string;
  };
}
```

### Issue (hallazgo individual)

```typescript
interface Issue {
  line: number;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO";
  issue: string;             // Título
  description: string;       // Descripción detallada
  suggestion: string;        // Recomendación
  suggestion_code?: string;  // Código de ejemplo
  priority?: string;         // "P1", "P2", etc.
  original_severity?: string; // Severidad antes de ajuste
}
```

### Issue (en historial de reviews)

```typescript
interface HistoryIssue {
  id: string;                // UUID
  filename: string;
  line: number | null;
  issue: string;
  description: string | null;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "UNKNOWN";
  suggestion: string | null;
  fixed_code: string | null;
  original_severity?: string;
  priority?: string;
  status: "pending" | "resolved" | "ignored";
  created_at: string;        // ISO 8601
}
```

### ReviewSummary (en lista de historial)

```typescript
interface ReviewSummary {
  id: string;                // UUID del review batch
  filename: string;          // Nombre del archivo principal
  type: string;              // Tipo de review
  total_issues: number;
  low_quantity: number;
  medium_quantity: number;
  high_quantity: number;
  critical_quantity: number;
  highest_severity: string;
  created_at: string;        // ISO 8601
}
```

### CommitReviewResult

```typescript
interface CommitReviewResult {
  status: "pending" | "completed" | "error";
  commit_message: string | null;
  commit_message_body: string | null;
  findings: Array<{
    filename: string;
    issues: Issue[];
  }> | null;
  findings_summary: {
    critical: number;
    high: number;
    medium: number;
    low: number;
    total: number;
  } | null;
  files_analyzed: string[] | null;
  analysis_time: number | null;
  error: string | null;
}
```

---

## 10. Manejo de errores

### Códigos HTTP

| Código | Significado | Acción recomendada |
|--------|-------------|-------------------|
| `200 / 202` | Éxito | Procesar respuesta |
| `400` | Request inválido | Mostrar detalle de error al usuario |
| `401` | API Key inválida | Pedir al usuario que configure su API Key |
| `403` | Sin permisos o plan insuficiente | Mostrar mensaje de plan/permisos |
| `404` | Recurso no encontrado | Informar que el review expiró o no existe |
| `422` | Error de validación (FastAPI) | Mostrar `detail[].msg` al usuario |
| `429` | Rate limit alcanzado | Esperar y reintentar con backoff |
| `500+` | Error del servidor | Mostrar mensaje genérico, reintentar |

### Formato de error 422

```json
{
  "detail": [
    {
      "loc": ["body", "files", 0, "code"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

### Timeouts recomendados

| Operación | Timeout |
|-----------|---------|
| Enviar review (POST) | 90s |
| Polling por tarea | 10s por request |
| WebSocket total | 180s |
| Commit review total | 300s |
| Historial / issues | 30s |

---

## 11. Herramientas MCP a exponer

Las siguientes son las herramientas que el MCP debe exponer.

**Formato de output:** todos los tools devuelven **JSON estructurado** (la respuesta directa de la API, normalizada). No formatear como markdown — el LLM que consume el tool se encarga de la presentación al usuario.

---

### `hacki_review_file`

Analiza un archivo individual.

**Input:**
```json
{
  "file_path": "/ruta/absoluta/archivo.py",
  "include_diff": true
}
```

**Output:**
```json
{
  "filename": "archivo.py",
  "type": "code",
  "findings": [
    {
      "line": 42,
      "severity": "HIGH",
      "issue": "Hardcoded password",
      "description": "Password is hardcoded in source code",
      "suggestion": "Use environment variables",
      "suggestion_code": "password = os.getenv('DB_PASSWORD')"
    }
  ],
  "summary": { "critical": 0, "high": 1, "medium": 0, "low": 0, "total": 1 },
  "error": null
}
```

---

### `hacki_review_files`

Analiza una lista de archivos.

**Input:**
```json
{
  "file_paths": ["/workspace/app.py", "/workspace/utils.py"],
  "include_diff": true
}
```

**Output:**
```json
{
  "files": [
    {
      "filename": "app.py",
      "type": "code",
      "findings": [...],
      "summary": { "critical": 1, "high": 2, "medium": 0, "low": 1, "total": 4 },
      "error": null
    }
  ],
  "total_summary": { "critical": 1, "high": 2, "medium": 0, "low": 1, "total": 4 }
}
```

---

### `hacki_review_directory`

Analiza todos los archivos de un directorio de forma recursiva.

**Input:**
```json
{
  "directory_path": "/workspace/src",
  "include_diff": false
}
```

> **Exclusiones:** se aplica `.hackiignore` automáticamente (siempre, si existe en la raíz del proyecto). No hay parámetro `exclude_patterns` — para excluir archivos del análisis, el usuario debe configurar su `.hackiignore`.

**Output:** Mismo formato que `hacki_review_files`.

---

### `hacki_commit`

Analiza los archivos staged en git y genera un mensaje de commit.

**Input:**
```json
{
  "commit_message_style": "conventional"
}
```

**Output:**
```json
{
  "commit_message": "fix(auth): remove hardcoded password",
  "commit_message_body": "Replace hardcoded password with env variable\n\n- app.py:42 — removed DB_PASSWORD literal",
  "findings_summary": { "critical": 0, "high": 1, "medium": 0, "low": 0, "total": 1 },
  "findings": [
    {
      "filename": "app.py",
      "issues": [
        {
          "line": 42,
          "severity": "HIGH",
          "issue": "Hardcoded password",
          "suggestion": "Use environment variables",
          "suggestion_code": "password = os.getenv('DB_PASSWORD')"
        }
      ]
    }
  ],
  "error": null
}
```

---

### `hacki_get_history`

Lista los reviews pasados del usuario.

**Input:**
```json
{
  "page": 1,
  "size": 10,
  "filename": null,
  "start_date": null,
  "end_date": null
}
```

**Output:** Respuesta directa del endpoint `GET /analisis-cli/reviews` (ver sección 6.1).

---

### `hacki_get_findings`

Obtiene los hallazgos de un review específico.

**Input:**
```json
{
  "review_id": "uuid-del-review",
  "severity": ["CRITICAL", "HIGH"],
  "status": ["pending"],
  "page": 1,
  "size": 50
}
```

**Output:** Respuesta directa del endpoint `GET /analisis-cli/reviews/{id}/issues` (ver sección 6.2).

---

### `hacki_update_finding_status`

Actualiza el estado de un hallazgo.

**Input:**
```json
{
  "review_id": "uuid-del-review",
  "issue_id": "uuid-del-issue",
  "status": "resolved"
}
```

**Output:** Respuesta directa del endpoint `PATCH /analisis-cli/reviews/{id}/issues/{id}/status` (ver sección 6.3).

---

## Referencias

- [CLI_REVIEWS_API.md](CLI_REVIEWS_API.md) — Documentación detallada de los endpoints de historial
- [COMMIT_REVIEW_API.md](COMMIT_REVIEW_API.md) — Documentación detallada del endpoint de commit review
- [WEBSOCKET_COMMIT_REVIEW.md](WEBSOCKET_COMMIT_REVIEW.md) — Protocolo WebSocket para commit review
- [HACKI_IGNORE.md](HACKI_IGNORE.md) — Formato del archivo `.hackiignore`
- [USER_GUIDE.md](USER_GUIDE.md) — Guía de usuario del CLI

---

*Última actualización: 2026-02-24*
