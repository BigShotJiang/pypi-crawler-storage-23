"""Configuration loading and project context discovery."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path


class HackiAuthError(Exception):
    """Raised when API key is missing or invalid."""


class HackiGitError(Exception):
    """Raised when not in a git repo or git is unavailable."""


@dataclass
class HackiConfig:
    api_key: str
    api_url: str
    ws_url: str


@dataclass
class ProjectContext:
    project_id: str | None = None
    repo_id: str | None = None


def _derive_ws_url(api_url: str) -> str:
    if api_url.startswith("https://"):
        return "wss://" + api_url[len("https://"):]
    if api_url.startswith("http://"):
        return "ws://" + api_url[len("http://"):]
    return api_url


def load_config() -> HackiConfig:
    """Load HackiAI config from ~/.hacki_cli/config.json.

    Raises HackiAuthError if the API key is not found.
    """
    api_key = os.environ.get("HACKI_API_KEY")
    if not api_key:
        config_path = Path.home() / ".hacki_cli" / "config.json"
        if not config_path.exists():
            raise HackiAuthError(
                "HackiAI API key not found. "
                "Run 'hacki login' to configure your API key, "
                "or set the HACKI_API_KEY environment variable."
            )
        try:
            data = json.loads(config_path.read_text())
            api_key = data.get("api_key", "")
        except (json.JSONDecodeError, OSError) as exc:
            raise HackiAuthError(
                f"Failed to read HackiAI config from {config_path}: {exc}"
            ) from exc

    if not api_key:
        raise HackiAuthError(
            "HackiAI API key is empty. "
            "Run 'hacki login' to configure your API key."
        )

    api_url = os.environ.get("HACKI_API_URL", "https://api.hacki.ai").rstrip("/")
    ws_url = _derive_ws_url(api_url)

    return HackiConfig(api_key=api_key, api_url=api_url, ws_url=ws_url)


def discover_project_context(start_path: Path | str | None = None) -> ProjectContext:
    """Walk up directories searching for .hacki/project.json.

    Falls back to ~/.hacki/config.json. Returns ProjectContext(None, None)
    if nothing is found.
    """
    if start_path is None:
        start_path = Path.cwd()
    else:
        start_path = Path(start_path)

    if start_path.is_file():
        start_path = start_path.parent

    current = start_path.resolve()
    root = Path(current.anchor)

    while current != root:
        candidate = current / ".hacki" / "project.json"
        if candidate.exists():
            return _parse_project_json(candidate)
        current = current.parent

    # Global fallback
    global_config = Path.home() / ".hacki" / "config.json"
    if global_config.exists():
        return _parse_project_json(global_config)

    return ProjectContext()


def _parse_project_json(path: Path) -> ProjectContext:
    try:
        data = json.loads(path.read_text())
        resource_type = data.get("resource_type", "")
        resource_id = data.get("resource_id")
        if resource_type == "project":
            return ProjectContext(project_id=resource_id)
        if resource_type == "repository":
            return ProjectContext(repo_id=resource_id)
    except (json.JSONDecodeError, OSError):
        pass
    return ProjectContext()
