"""Code graph generation using hacki-graph (GraphOrchestrator).

Generates AST + IR + CFG + DFG for the files being reviewed.
Returns None gracefully on any failure — a missing graph never blocks a review.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def find_project_root(start: Path) -> Path:
    """Walk up from start to find the project root (.git or .hacki directory).

    Falls back to start itself if nothing is found.
    """
    current = start.resolve()
    if current.is_file():
        current = current.parent

    root = Path(current.anchor)
    while current != root:
        if (current / ".git").exists() or (current / ".hacki").exists():
            return current
        current = current.parent

    return start.resolve() if start.is_file() else start.resolve()


def _common_ancestor(paths: list[Path]) -> Path:
    """Return the common ancestor directory of a list of paths."""
    if not paths:
        return Path.cwd()
    if len(paths) == 1:
        p = paths[0].resolve()
        return p.parent if p.is_file() else p

    resolved = [p.resolve() for p in paths]
    common = Path(os.path.commonpath([str(p) for p in resolved]))
    return common if common.is_dir() else common.parent


def build_code_graph(
    files: list[Path], project_root: Path | None = None
) -> dict[str, Any] | None:
    """Build a full code graph (AST + IR + CFG + DFG) using hacki-graph.

    Returns None when:
    - fewer than 2 files
    - no files in supported languages
    - hacki-graph raises any exception (never blocks a review)
    """
    if len(files) < 2:
        return None

    try:
        return _build_graph(files, project_root)
    except Exception:
        return None


def _build_graph(
    files: list[Path], project_root: Path | None
) -> dict[str, Any] | None:
    from hacki_graph import GraphOrchestrator, get_language_registry  # type: ignore[import]

    registry = get_language_registry()

    # Keep only files whose language hacki-graph supports
    supported = [f for f in files if registry.is_file_supported(str(f.name))]
    if len(supported) < 2:
        return None

    # Resolve project root: explicit > git/hacki root > common ancestor
    if project_root is None:
        project_root = find_project_root(_common_ancestor(supported))

    file_paths = [str(f.resolve()) for f in supported]

    orchestrator = GraphOrchestrator(str(project_root))
    results = orchestrator.ensure_analysis_ready(file_paths)

    if not results:
        return None

    tree_sitter_graph = results.get("tree_sitter_graph", {})
    static_analysis = results.get("static_analysis", {})

    # Require at least some nodes — otherwise there's nothing useful to send
    if not tree_sitter_graph.get("nodes"):
        return None

    return {
        "tree_sitter": {
            "nodes": tree_sitter_graph.get("nodes", []),
            "edges": tree_sitter_graph.get("edges", []),
            "metadata": tree_sitter_graph.get("metadata", {}),
        },
        "static_analysis": {
            "ir_files": static_analysis.get("ir_files", {}),
            "cfg_files": static_analysis.get("cfg_files", {}),
            "dfg_files": static_analysis.get("dfg_files", {}),
            "stats": static_analysis.get("stats", {}),
        },
    }
