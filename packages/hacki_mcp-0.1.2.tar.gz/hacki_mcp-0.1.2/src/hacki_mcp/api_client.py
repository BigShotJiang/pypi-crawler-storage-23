"""HackiAI async HTTP/WebSocket client."""

from __future__ import annotations

import asyncio
import gzip
import json
from typing import Any

import httpx

try:
    import websockets
    from websockets.exceptions import WebSocketException
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False
    WebSocketException = Exception  # type: ignore[assignment,misc]

from .config import HackiAuthError, HackiConfig


# ---------------------------------------------------------------------------
# Error hierarchy
# ---------------------------------------------------------------------------

class HackiAPIError(Exception):
    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message


class HackiForbiddenError(HackiAPIError):
    pass


class HackiNotFoundError(HackiAPIError):
    pass


class HackiRateLimitError(HackiAPIError):
    pass


class HackiValidationError(HackiAPIError):
    def __init__(self, status_code: int, message: str, detail: list[dict] | None = None) -> None:
        super().__init__(status_code, message)
        self.detail = detail or []


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class HackiClient:
    """Async HTTP + WebSocket client for the HackiAI API."""

    def __init__(self, config: HackiConfig) -> None:
        self._config = config
        self._headers = {
            "X-API-Key": config.api_key,
            "Content-Type": "application/json",
        }
        self._http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "HackiClient":
        self._http = httpx.AsyncClient(
            base_url=self._config.api_url,
            headers=self._headers,
            timeout=30.0,
        )
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._http:
            await self._http.aclose()
            self._http = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compress(payload: dict) -> bytes:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        return gzip.compress(body)

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.status_code < 400:
            return

        try:
            data = response.json()
        except Exception:
            data = {}

        message = data.get("detail") or data.get("message") or response.text or str(response.status_code)

        if response.status_code == 401:
            raise HackiAuthError(
                f"Authentication failed (401): {message}. "
                "Check your API key with 'hacki login'."
            )
        if response.status_code == 403:
            raise HackiForbiddenError(response.status_code, f"Forbidden (403): {message}")
        if response.status_code == 404:
            raise HackiNotFoundError(response.status_code, f"Not found (404): {message}")
        if response.status_code == 429:
            raise HackiRateLimitError(response.status_code, f"Rate limit exceeded (429): {message}")
        if response.status_code == 422:
            detail = data.get("detail", [])
            msgs = "; ".join(d.get("msg", "") for d in detail) if isinstance(detail, list) else str(detail)
            raise HackiValidationError(response.status_code, f"Validation error (422): {msgs}", detail if isinstance(detail, list) else [])

        raise HackiAPIError(response.status_code, f"API error ({response.status_code}): {message}")

    async def _post_gzip(self, path: str, payload: dict, timeout: float) -> dict:
        """POST with gzip-compressed JSON body, with rate-limit retry backoff."""
        assert self._http is not None
        compressed = self._compress(payload)
        headers = {"Content-Encoding": "gzip"}
        backoff_delays = [5.0, 10.0, 20.0]
        last_exc: Exception | None = None

        for attempt in range(4):  # initial + 3 retries
            try:
                response = await self._http.post(
                    path,
                    content=compressed,
                    headers=headers,
                    timeout=timeout,
                )
                if response.status_code == 429 and attempt < 3:
                    await asyncio.sleep(backoff_delays[attempt])
                    last_exc = HackiRateLimitError(429, "Rate limit exceeded")
                    continue
                self._raise_for_status(response)
                return response.json()
            except HackiRateLimitError as exc:
                last_exc = exc
                if attempt < 3:
                    await asyncio.sleep(backoff_delays[attempt])
            except (HackiAPIError, HackiAuthError):
                raise
            except httpx.TimeoutException as exc:
                raise HackiAPIError(0, f"Request timed out: {exc}") from exc

        raise last_exc or HackiAPIError(429, "Rate limit exceeded after retries")

    async def _get(self, path: str, params: dict | None = None, timeout: float = 30.0) -> dict:
        assert self._http is not None
        try:
            response = await self._http.get(path, params=params, timeout=timeout)
            self._raise_for_status(response)
            return response.json()
        except (HackiAPIError, HackiAuthError):
            raise
        except httpx.TimeoutException as exc:
            raise HackiAPIError(0, f"Request timed out: {exc}") from exc

    async def _patch(self, path: str, body: dict, timeout: float = 30.0) -> dict:
        assert self._http is not None
        try:
            response = await self._http.patch(path, json=body, timeout=timeout)
            self._raise_for_status(response)
            return response.json()
        except (HackiAPIError, HackiAuthError):
            raise
        except httpx.TimeoutException as exc:
            raise HackiAPIError(0, f"Request timed out: {exc}") from exc

    # ------------------------------------------------------------------
    # Review endpoints
    # ------------------------------------------------------------------

    async def submit_review(self, payload: dict) -> dict:
        """POST /analisis/review with gzip. Returns 202 response."""
        return await self._post_gzip("/analisis/review", payload, timeout=90.0)

    async def submit_commit_review(self, payload: dict) -> dict:
        """POST /analisis/commit-review with gzip. Returns 202 response."""
        return await self._post_gzip("/analisis/commit-review", payload, timeout=90.0)

    # ------------------------------------------------------------------
    # Task result retrieval: WS first, polling fallback
    # ------------------------------------------------------------------

    async def get_task_result(self, task_id: str) -> dict:
        """Get the result of a review task. Tries WS first, then polling."""
        if HAS_WEBSOCKETS:
            try:
                return await asyncio.wait_for(
                    self._ws_task(task_id), timeout=180.0
                )
            except (WebSocketException, OSError, TimeoutError, asyncio.TimeoutError):
                pass
        return await self._poll_task_result(task_id)

    async def _ws_task(self, task_id: str) -> dict:
        """Connect to WS and wait for task completion."""
        url = (
            f"{self._config.ws_url}/analisis/ws/tasks/{task_id}"
            f"?api_key={self._config.api_key}"
        )
        async with websockets.connect(
            url,
            ping_interval=20,
            ping_timeout=30,
            open_timeout=10,
        ) as ws:
            async for raw in ws:
                msg = json.loads(raw)
                msg_type = msg.get("type", "")
                if msg_type == "completed":
                    return msg.get("data", msg)
                if msg_type == "error":
                    raise HackiAPIError(0, msg.get("message", "Task error"))
        raise HackiAPIError(0, "WebSocket closed without result")

    async def _poll_task_result(self, task_id: str, interval: float = 3.0, max_attempts: int = 60) -> dict:
        """Poll GET /analisis/task/{id} until terminal state."""
        terminal = {"success", "completed", "error"}
        for _ in range(max_attempts):
            data = await self._get(f"/analisis/task/{task_id}", timeout=10.0)
            status = data.get("status", "")
            if status in terminal:
                if status == "error":
                    raise HackiAPIError(0, f"Task failed: {data.get('error', 'unknown error')}")
                return data
            await asyncio.sleep(interval)
        raise HackiAPIError(0, f"Timeout waiting for task {task_id}")

    # ------------------------------------------------------------------
    # Commit review result retrieval
    # ------------------------------------------------------------------

    async def get_commit_review_result(self, commit_review_id: str) -> dict:
        """Get commit review result. Tries WS first, then polling."""
        if HAS_WEBSOCKETS:
            try:
                return await asyncio.wait_for(
                    self._ws_commit_review(commit_review_id), timeout=300.0
                )
            except (WebSocketException, OSError, TimeoutError, asyncio.TimeoutError):
                pass
        return await self._poll_commit_review(commit_review_id)

    async def _ws_commit_review(self, commit_review_id: str) -> dict:
        """Connect to commit-review WS and wait for completion."""
        url = (
            f"{self._config.ws_url}/ws/commit-review/{commit_review_id}"
            f"?api_key={self._config.api_key}"
        )
        async with websockets.connect(
            url,
            ping_interval=20,
            ping_timeout=30,
            open_timeout=10,
        ) as ws:
            async for raw in ws:
                msg = json.loads(raw)
                msg_type = msg.get("type", "")
                # Handle both "completed" and "analysis_complete" (API inconsistency)
                if msg_type in ("completed", "analysis_complete"):
                    return msg
                if msg_type == "error":
                    raise HackiAPIError(0, msg.get("message", "Commit review error"))
        raise HackiAPIError(0, "WebSocket closed without result")

    async def _poll_commit_review(
        self, commit_review_id: str, interval: float = 3.0, max_attempts: int = 60
    ) -> dict:
        """Poll GET /analisis/commit-review/{id}/results until terminal state."""
        terminal = {"success", "completed", "error"}
        for _ in range(max_attempts):
            data = await self._get(
                f"/analisis/commit-review/{commit_review_id}/results", timeout=10.0
            )
            status = data.get("status", "")
            if status in terminal:
                if status == "error":
                    raise HackiAPIError(0, f"Commit review failed: {data.get('error', 'unknown error')}")
                return data
            await asyncio.sleep(interval)
        raise HackiAPIError(0, f"Timeout waiting for commit review {commit_review_id}")

    # ------------------------------------------------------------------
    # Batch task resolution
    # ------------------------------------------------------------------

    async def resolve_tasks(self, tasks: list[dict]) -> list[dict | Exception]:
        """Resolve all valid tasks concurrently. Skips tasks with errors.

        Returns a list preserving input order. Tasks with submission errors
        are replaced with Exception instances.
        """
        coros = []
        valid_indices: list[int] = []

        for i, task in enumerate(tasks):
            if task.get("error") or not task.get("task_id"):
                coros.append(_failed_task(task))
            else:
                coros.append(self.get_task_result(task["task_id"]))
            valid_indices.append(i)

        results = await asyncio.gather(*coros, return_exceptions=True)
        return list(results)

    # ------------------------------------------------------------------
    # History & findings endpoints
    # ------------------------------------------------------------------

    async def get_history(
        self,
        page: int = 1,
        size: int = 20,
        filename: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict:
        params: dict = {"page": page, "size": size}
        if filename:
            params["filename"] = filename
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        return await self._get("/analisis-cli/reviews", params=params)

    async def get_findings(
        self,
        review_id: str,
        severity: list[str] | None = None,
        status: list[str] | None = None,
        page: int = 1,
        size: int = 50,
    ) -> dict:
        params: dict[str, Any] = {"page": page, "size": size}
        # httpx supports list params as repeated keys
        if severity:
            params["severity"] = severity
        if status:
            params["status"] = status
        return await self._get(f"/analisis-cli/reviews/{review_id}/issues", params=params)

    async def update_finding_status(
        self, review_id: str, issue_id: str, status: str
    ) -> dict:
        return await self._patch(
            f"/analisis-cli/reviews/{review_id}/issues/{issue_id}/status",
            {"status": status},
        )


async def _failed_task(task: dict) -> Exception:
    return Exception(task.get("error", "Task submission failed"))
