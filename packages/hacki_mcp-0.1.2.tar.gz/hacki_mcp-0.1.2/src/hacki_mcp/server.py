"""HackiAI MCP server — exposes 7 security analysis tools."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from .api_client import (
    HackiAPIError,
    HackiClient,
    HackiForbiddenError,
    HackiNotFoundError,
    HackiRateLimitError,
    HackiValidationError,
)
from .config import HackiAuthError, HackiGitError, HackiConfig, load_config, discover_project_context
from .file_utils import (
    PreparedFile,
    collect_files,
    get_git_branch,
    get_git_commit_sha,
    get_staged_diff,
    get_staged_files,
    prepare_file,
)
from .graph import build_code_graph, find_project_root

mcp = FastMCP("hacki-mcp")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def format_api_error(exc: Exception) -> dict:
    """Convert a typed exception to a user-friendly dict."""
    if isinstance(exc, HackiAuthError):
        return {
            "error": "authentication_error",
            "message": str(exc),
            "hint": "Run 'hacki login' to configure your API key, or set the HACKI_API_KEY environment variable.",
        }
    if isinstance(exc, HackiForbiddenError):
        return {
            "error": "forbidden",
            "message": str(exc),
            "hint": "Your plan may not support this feature. Check your HackiAI subscription.",
        }
    if isinstance(exc, HackiNotFoundError):
        return {
            "error": "not_found",
            "message": str(exc),
        }
    if isinstance(exc, HackiRateLimitError):
        return {
            "error": "rate_limit",
            "message": str(exc),
            "hint": "Too many requests. Please wait a moment before retrying.",
        }
    if isinstance(exc, HackiValidationError):
        return {
            "error": "validation_error",
            "message": str(exc),
            "detail": exc.detail,
        }
    if isinstance(exc, HackiAPIError):
        return {
            "error": "api_error",
            "message": str(exc),
            "status_code": exc.status_code,
        }
    if isinstance(exc, HackiGitError):
        return {
            "error": "git_error",
            "message": str(exc),
        }
    return {
        "error": "unexpected_error",
        "message": str(exc),
    }


def count_by_severity(findings: list[dict]) -> dict:
    """Count findings by severity level."""
    counts: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0, "total": 0}
    for item in findings:
        sev = item.get("severity", "").lower()
        if sev in counts:
            counts[sev] += 1
        counts["total"] += 1
    return counts


def aggregate_summaries(summaries: list[dict]) -> dict:
    """Sum severity counts across multiple file summaries."""
    total: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0, "total": 0}
    for s in summaries:
        for key in total:
            total[key] += s.get(key, 0)
    return total


def normalize_task_result(task_meta: dict, raw_result: dict) -> dict:
    """Normalize a task result into a unified format with 'findings' and 'summary'."""
    file_type = task_meta.get("type", "code")
    filename = task_meta.get("filename", "")
    result_payload = raw_result.get("result", raw_result)

    # Extract findings depending on type
    if file_type == "dependency":
        raw_findings = result_payload.get("propuestas", [])
    elif file_type == "infrastructure":
        raw_findings = result_payload.get("misconfigurations", [])
    else:
        # code — could be nested under result.value or at top level
        raw_findings = result_payload.get("value", result_payload.get("findings", []))

    if not isinstance(raw_findings, list):
        raw_findings = []

    summary = count_by_severity(raw_findings)

    return {
        "filename": filename,
        "type": file_type,
        "findings": raw_findings,
        "summary": summary,
        "error": None,
    }


def build_review_payload(
    prepared_files: list[PreparedFile],
    config: HackiConfig,
    start_path: Path | None = None,
    include_graph: bool = False,
    extra: dict | None = None,
) -> dict:
    """Build the full gzip payload for POST /analisis/review."""
    ctx = discover_project_context(start_path)

    files_payload = []
    for pf in prepared_files:
        if pf.is_binary:
            continue
        entry: dict[str, Any] = {
            "filename": pf.filename,
            "code": pf.code,
            "language": pf.language,
            "type": pf.file_type,
            "sd": False,
            "file_path": str(pf.path.resolve()),
            "processed": False,
        }
        if pf.diff:
            entry["diff"] = pf.diff
        if pf.git_metadata:
            entry["git_metadata"] = pf.git_metadata
        files_payload.append(entry)

    payload: dict[str, Any] = {"files": files_payload}

    if ctx.project_id:
        payload["project_id"] = ctx.project_id
    if ctx.repo_id:
        payload["repo_id"] = ctx.repo_id

    branch = get_git_branch()
    if branch:
        payload["branch"] = branch

    sha = get_git_commit_sha()
    if sha:
        payload["commit_sha"] = sha

    if include_graph:
        paths = [pf.path for pf in prepared_files if not pf.is_binary]
        proj_root = find_project_root(start_path) if start_path else None
        graph = build_code_graph(paths, project_root=proj_root)
        if graph:
            payload["code_graph"] = graph

    if extra:
        payload.update(extra)

    return payload


async def _run_review(
    prepared: list[PreparedFile],
    config: HackiConfig,
    start_path: Path | None = None,
    include_graph: bool = False,
    extra_payload: dict | None = None,
) -> list[dict]:
    """Submit files for review and collect per-file results."""
    payload = build_review_payload(
        prepared, config, start_path=start_path, include_graph=include_graph, extra=extra_payload
    )

    async with HackiClient(config) as client:
        response = await client.submit_review(payload)
        tasks: list[dict] = response.get("tasks", [])
        results = await client.resolve_tasks(tasks)

    file_results = []
    for task_meta, raw in zip(tasks, results):
        if isinstance(raw, Exception):
            file_results.append({
                "filename": task_meta.get("filename", ""),
                "type": task_meta.get("type", "code"),
                "findings": [],
                "summary": count_by_severity([]),
                "error": str(raw),
            })
        else:
            file_results.append(normalize_task_result(task_meta, raw))

    return file_results


# ---------------------------------------------------------------------------
# Tool 1: hacki_review_file
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_review_file(file_path: str, include_diff: bool = False) -> dict:
    """Analyze a single file for security issues.

    Args:
        file_path: Absolute path to the file to analyze.
        include_diff: If True, include git diff context to improve analysis quality.

    Returns:
        A dict with 'filename', 'type', 'findings', 'summary', and 'error'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    path = Path(file_path)
    if not path.exists():
        return {"error": "file_not_found", "message": f"File not found: {file_path}"}

    pf = prepare_file(path, include_diff=include_diff)
    if pf is None:
        return {"error": "read_error", "message": f"Could not read file: {file_path}"}

    if pf.is_binary:
        return {
            "filename": pf.filename,
            "type": pf.file_type,
            "findings": [],
            "summary": count_by_severity([]),
            "error": None,
            "note": "Binary file skipped.",
        }

    try:
        results = await _run_review([pf], config, start_path=path.parent, include_graph=False)
        return results[0] if results else {"error": "no_results", "message": "No results returned."}
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 2: hacki_review_files
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_review_files(file_paths: list[str], include_diff: bool = False) -> dict:
    """Analyze a list of files for security issues.

    Args:
        file_paths: List of absolute file paths to analyze.
        include_diff: If True, include git diff context.

    Returns:
        A dict with 'files' (per-file results) and 'total_summary'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    if not file_paths:
        return {"error": "no_files", "message": "No file paths provided."}

    prepared: list[PreparedFile] = []
    skipped: list[dict] = []
    for fp in file_paths:
        path = Path(fp)
        if not path.exists():
            skipped.append({"filename": path.name, "error": f"File not found: {fp}"})
            continue
        pf = prepare_file(path, include_diff=include_diff)
        if pf is None:
            skipped.append({"filename": path.name, "error": f"Could not read: {fp}"})
            continue
        if pf.is_binary:
            skipped.append({"filename": path.name, "note": "Binary file skipped."})
            continue
        prepared.append(pf)

    if not prepared:
        return {
            "files": [],
            "skipped": skipped,
            "total_summary": count_by_severity([]),
            "error": "no_readable_files",
            "message": "No readable files to analyze.",
        }

    include_graph = len(prepared) >= 2
    start_path = Path(file_paths[0]).parent if file_paths else None

    try:
        results = await _run_review(
            prepared, config, start_path=start_path, include_graph=include_graph
        )
        summaries = [r.get("summary", {}) for r in results]
        total_summary = aggregate_summaries(summaries)
        return {
            "files": results,
            "skipped": skipped,
            "total_summary": total_summary,
        }
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 3: hacki_review_directory
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_review_directory(directory_path: str, include_diff: bool = False) -> dict:
    """Analyze all files in a directory recursively for security issues.

    Automatically respects .hackiignore files. Does not accept exclude_patterns —
    configure .hackiignore to exclude files.

    Args:
        directory_path: Absolute path to the directory to analyze.
        include_diff: If True, include git diff context.

    Returns:
        A dict with 'files' (per-file results) and 'total_summary'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    directory = Path(directory_path)
    if not directory.exists() or not directory.is_dir():
        return {
            "error": "directory_not_found",
            "message": f"Directory not found: {directory_path}",
        }

    all_paths = collect_files(directory)
    if not all_paths:
        return {
            "files": [],
            "total_summary": count_by_severity([]),
            "message": "No files found in directory.",
        }

    prepared: list[PreparedFile] = []
    skipped: list[dict] = []
    for path in all_paths:
        pf = prepare_file(path, include_diff=include_diff)
        if pf is None:
            skipped.append({"filename": path.name, "error": f"Could not read: {path}"})
            continue
        if pf.is_binary:
            skipped.append({"filename": path.name, "note": "Binary file skipped."})
            continue
        prepared.append(pf)

    if not prepared:
        return {
            "files": [],
            "skipped": skipped,
            "total_summary": count_by_severity([]),
            "message": "No readable files found.",
        }

    include_graph = len(prepared) >= 2

    try:
        results = await _run_review(
            prepared, config, start_path=directory, include_graph=include_graph
        )
        summaries = [r.get("summary", {}) for r in results]
        total_summary = aggregate_summaries(summaries)
        return {
            "files": results,
            "skipped": skipped,
            "total_summary": total_summary,
        }
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 4: hacki_commit
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_commit(commit_message_style: str = "conventional") -> dict:
    """Analyze staged git files and generate a suggested commit message.

    Requires git to be installed and files to be staged.

    Args:
        commit_message_style: Either 'conventional' (Conventional Commits) or 'simple'.

    Returns:
        A dict with 'commit_message', 'commit_message_body', 'findings_summary',
        'findings', and 'error'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    try:
        staged_paths = get_staged_files()
    except HackiGitError as exc:
        return format_api_error(exc)

    if not staged_paths:
        return {
            "error": "no_staged_files",
            "message": "No files are staged for commit. Use 'git add' to stage files.",
        }

    prepared: list[PreparedFile] = []
    skipped: list[dict] = []
    for path in staged_paths:
        if not path.exists():
            skipped.append({"filename": path.name, "note": "File staged but not found on disk (deleted?)."})
            continue
        pf = prepare_file(path, include_diff=False)
        if pf is None:
            skipped.append({"filename": path.name, "error": "Could not read file."})
            continue
        if pf.is_binary:
            skipped.append({"filename": path.name, "note": "Binary file skipped."})
            continue
        prepared.append(pf)

    if not prepared:
        return {
            "error": "no_readable_staged_files",
            "message": "No readable staged files found.",
            "skipped": skipped,
        }

    ctx = discover_project_context()
    staged_diff = get_staged_diff()
    branch = get_git_branch()
    sha = get_git_commit_sha()
    include_graph = len(prepared) >= 2

    payload: dict[str, Any] = {
        "files": [],
        "commit_message_style": commit_message_style,
    }

    for pf in prepared:
        entry: dict[str, Any] = {
            "filename": pf.filename,
            "code": pf.code,
            "language": pf.language,
            "type": pf.file_type,
            "sd": False,
            "file_path": str(pf.path.resolve()),
            "processed": False,
        }
        payload["files"].append(entry)

    if ctx.project_id:
        payload["project_id"] = ctx.project_id
    if ctx.repo_id:
        payload["repo_id"] = ctx.repo_id
    if staged_diff:
        payload["diff"] = staged_diff
    if branch:
        payload["branch"] = branch
    if sha:
        payload["commit_sha"] = sha

    if include_graph:
        paths = [pf.path for pf in prepared]
        graph = build_code_graph(paths, project_root=find_project_root(Path.cwd()))
        if graph:
            payload["code_graph"] = graph

    try:
        async with HackiClient(config) as client:
            response = await client.submit_commit_review(payload)
            commit_review_id = response.get("commit_review_id")
            if not commit_review_id:
                return {
                    "error": "missing_commit_review_id",
                    "message": "Server did not return a commit_review_id.",
                }
            result = await client.get_commit_review_result(commit_review_id)

        return {
            "commit_message": result.get("commit_message"),
            "commit_message_body": result.get("commit_message_body"),
            "findings_summary": result.get("findings_summary"),
            "findings": result.get("findings", []),
            "files_analyzed": result.get("files_analyzed", []),
            "skipped": skipped,
            "error": result.get("error"),
        }
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 5: hacki_get_history
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_get_history(
    page: int = 1,
    size: int = 20,
    filename: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> dict:
    """List past security reviews.

    Args:
        page: Page number (default 1).
        size: Results per page (default 20, max 100).
        filename: Optional partial filename filter.
        start_date: Optional ISO 8601 start date filter (e.g. '2026-01-01').
        end_date: Optional ISO 8601 end date filter.

    Returns:
        Response from GET /analisis-cli/reviews with 'items' and 'pagination'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    try:
        async with HackiClient(config) as client:
            return await client.get_history(
                page=page,
                size=size,
                filename=filename,
                start_date=start_date,
                end_date=end_date,
            )
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 6: hacki_get_findings
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_get_findings(
    review_id: str,
    severity: Optional[list[str]] = None,
    status: Optional[list[str]] = None,
    page: int = 1,
    size: int = 50,
) -> dict:
    """Get the findings for a specific review.

    Args:
        review_id: The UUID of the review.
        severity: Optional list of severity filters: 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'.
        status: Optional list of status filters: 'pending', 'resolved', 'ignored'.
        page: Page number (default 1).
        size: Results per page (default 50, max 200).

    Returns:
        Response from GET /analisis-cli/reviews/{id}/issues with 'items' and 'pagination'.
    """
    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    try:
        async with HackiClient(config) as client:
            return await client.get_findings(
                review_id=review_id,
                severity=severity,
                status=status,
                page=page,
                size=size,
            )
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Tool 7: hacki_update_finding_status
# ---------------------------------------------------------------------------

@mcp.tool()
async def hacki_update_finding_status(
    review_id: str, issue_id: str, status: str
) -> dict:
    """Update the status of a specific finding.

    Args:
        review_id: The UUID of the review containing the issue.
        issue_id: The UUID of the issue to update.
        status: New status — one of 'pending', 'resolved', 'ignored'.

    Returns:
        The updated issue object.
    """
    valid_statuses = {"pending", "resolved", "ignored"}
    if status not in valid_statuses:
        return {
            "error": "invalid_status",
            "message": f"Invalid status '{status}'. Must be one of: {', '.join(sorted(valid_statuses))}.",
        }

    try:
        config = load_config()
    except HackiAuthError as exc:
        return format_api_error(exc)

    try:
        async with HackiClient(config) as client:
            return await client.update_finding_status(
                review_id=review_id, issue_id=issue_id, status=status
            )
    except Exception as exc:
        return format_api_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
