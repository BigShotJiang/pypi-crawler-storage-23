# ...existing code...
from deepface import DeepFace
import cv2
import numpy as np
import time
import traceback

def _normalize_face_arr(arr):
    arr = np.array(arr)
    if arr.dtype in (np.float32, np.float64):
        if arr.max() <= 1.0:
            arr = (arr * 255).clip(0, 255).astype(np.uint8)
        else:
            arr = arr.clip(0, 255).astype(np.uint8)
    else:
        arr = arr.astype(np.uint8)
    # RGB -> BGR for OpenCV display if 3 channels
    if arr.ndim == 3 and arr.shape[2] == 3:
        arr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    return arr

def extract_first_face_safe(image_path, backend):
    try:
        t0 = time.time()
        faces = DeepFace.extract_faces(img_path=image_path, detector_backend=backend, enforce_detection=False)
        dt = time.time() - t0
        if faces:
            fobj = faces[0] if not isinstance(faces[0], dict) else faces[0].get('face', None)
            if fobj is not None:
                face_img = _normalize_face_arr(fobj)
                return face_img, f"{backend}: {len(faces)} faces, {dt:.2f}s"
        return None, f"{backend}: no faces detected, {dt:.2f}s"
    except Exception as e:
        return None, f"{backend}: error -> {str(e)}"

def make_label_img(text, width, height, bg_color=(200,200,200)):
    img = np.full((height, width, 3), bg_color, dtype=np.uint8)
    lines = text.split('\n')
    y0 = 20
    for i, line in enumerate(lines):
        cv2.putText(img, line, (8, y0 + i*20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (10,10,10), 1, cv2.LINE_AA)
    return img

def show_faces_side_by_side(image_path, backends=None, target_h=200, window_name="Detections (press any key to close)"):
    if backends is None:
        backends = ["retinaface", "mtcnn", "mediapipe", "ssd", "dlib", "opencv"]

    tiles = []
    for b in backends:
        face_img, msg = extract_first_face_safe(image_path, b)
        if face_img is None:
            # placeholder with message
            placeholder = make_label_img(msg, width=target_h, height=target_h)
            tiles.append(placeholder)
            continue

        h, w = face_img.shape[:2]
        scale = target_h / float(h)
        new_w = max(1, int(w * scale))
        resized = cv2.resize(face_img, (new_w, target_h), interpolation=cv2.INTER_LINEAR)
        # add a small label strip on top
        label_strip = make_label_img(msg, width=resized.shape[1], height=24, bg_color=(30,30,30))
        # label text in white
        cv2.putText(label_strip, msg, (6,16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1, cv2.LINE_AA)
        combined = np.vstack([label_strip, resized])
        tiles.append(combined)

    # unify heights
    max_h = max(img.shape[0] for img in tiles)
    norm_tiles = []
    for img in tiles:
        h, w = img.shape[:2]
        if h < max_h:
            pad = np.full((max_h - h, w, 3), 255, dtype=np.uint8)
            img = np.vstack([img, pad])
        norm_tiles.append(img)

    # horizontally concatenate with small gaps
    gap = 8
    gap_img = np.full((max_h, gap, 3), 255, dtype=np.uint8)
    canvas = norm_tiles[0]
    for t in norm_tiles[1:]:
        canvas = np.hstack([canvas, gap_img, t])

    # show
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.imshow(window_name, canvas)
    cv2.setWindowProperty(window_name, cv2.WND_PROP_TOPMOST, 1)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    cv2.waitKey(1)

if __name__ == "__main__":
    # örnek kullanım
    backends = ["retinaface", "mtcnn", "mediapipe", "ssd", "opencv"]
    show_faces_side_by_side("example_photo.jpg", backends=backends)
# ...existing code...