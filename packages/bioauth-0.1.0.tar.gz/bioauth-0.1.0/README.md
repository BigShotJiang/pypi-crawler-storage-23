# 🛡️ Biyometrik Kimlik Doğrulama Sistemi (Face Verification MVP)

Modern siber güvenlik standartlarına uygun, yapay zeka destekli, uçtan uca (Full-Stack) biyometrik kimlik doğrulama ve kayıt sistemi. Bu proje, kullanıcıların TC Kimlik numaraları ve yüzlerinin 512 boyutlu vektörel izdüşümleri (embeddings) ile eşleştirilerek sisteme güvenli bir şekilde giriş yapmalarını sağlar.

Öğrenme ve öğretme misyonuyla geliştirilen bu projenin kaynak kodları, mimari kararları ve algoritmaları açıklayan **detaylı eğitim amaçlı yorum satırlarıyla** donatılmıştır.

---

## 🎯 Projenin Amacı ve Vizyonu
Geleneksel şifre tabanlı sistemlerin yerini alan biyometrik güvenlik mimarilerinin nasıl çalıştığını uçtan uca göstermek. Sistem, sadece bir web uygulaması olmakla kalmayıp, kendi içinde `bioauth` adında bağımsız, açık kaynak standartlarında bir Python yapay zeka kütüphanesi barındırmaktadır.

## 🚀 Öne Çıkan Özellikler
- **Gerçek Zamanlı Yüz Tarama:** React ve WebRTC kullanılarak tarayıcı üzerinden anlık fotoğraf çekimi.
- **Matematiksel TC Doğrulama:** Hatalı veya sahte TC Kimlik numaralarını daha AI katmanına inmeden yakalayan güvenlik duvarı.
- **Gelişmiş Yüz Tanıma (ArcFace):** İnsan yüzlerini 512 boyutlu vektörlere dönüştüren derin öğrenme modeli.
- **Vektörel Veritabanı:** Geleneksel metin araması yerine, Kosinüs Benzerliği (Cosine Distance) ile vektörel arama yapan `pgvector` destekli PostgreSQL.
- **Production-Ready Docker Mimarisi:** Multi-stage build (Nginx) içeren frontend ve izole edilmiş backend konteynerleri ile tek tıkla kurulum.

---

## 🛠️ Kullanılan Teknolojiler

| Katman | Teknoloji / Araç | Kullanım Amacı |
| :--- | :--- | :--- |
| **Yapay Zeka (AI)** | `DeepFace` (ArcFace), `OpenCV`, `NumPy` | Yüz tespiti, vektör çıkarımı ve görselleştirme. |
| **Backend** | `FastAPI`, `Python 3.9`, `SQLAlchemy`, `Alembic` | Asenkron, yüksek performanslı REST API ve ORM mimarisi. |
| **Veritabanı** | `PostgreSQL`, `pgvector` | 512 boyutlu yüz vektörlerinin saklanması ve uzaysal aranması. |
| **Frontend** | `React`, `Vite`, `Tailwind CSS`, `Axios` | Modern, responsive ve hızlı kullanıcı arayüzü. |
| **DevOps & QA** | `Docker`, `Docker Compose`, `Nginx`, `Pytest` | Konteynerleştirme, CI/CD hazırlığı ve otomatik API testleri. |

---

## 🏗️ Mimari Tasarım ve Kütüphane Yapısı (`bioauth`)

Projenin kalbi, ana sistemden izole edilerek bir Python paketi (`enes-bioauth`) olarak tasarlanmış yapay zeka modülüdür. Nesne Yönelimli Programlama (OOP) ilkelerine sadık kalınarak tasarlanan bu paket 3 ana sınıftan oluşur:

### 1. `FaceExtractor` (Vektör Çıkarıcı)
* **Görev:** Kameradan gelen fotoğraftaki yüzü tespit eder, hizalar ve derin öğrenme modelinden (ArcFace) geçirerek 512 boyutlu bir sayı dizisine (vektör) çevirir.
* **Güvenlik:** Fotoğrafta birden fazla yüz tespit edilirse (örn: arkada biri varsa) sistemi güvenlik gerekçesiyle durdurur (`multiple_faces_detected` hatası fırlatır).

### 2. `FaceComparator` (Yüz Karşılaştırıcı)
* **Görev:** Veritabanındaki kayıtlı vektör ile giriş yapmaya çalışan kişinin anlık vektörünü karşılaştırır.
* **Algoritma:** İki vektör arasındaki açıyı hesaplayan **Kosinüs Mesafesi (Cosine Distance)** formülünü kullanır. ArcFace modeli için optimum eşik değeri olan `0.68` baz alınarak, bu değerin altındaki mesafeler "Eşleşti (True)", üstündekiler "Reddedildi (False)" olarak kabul edilir.

### 3. `FaceVisualizer` (Görsel Analiz)
* **Görev:** Hata ayıklama ve geliştirici testleri için iki yüzü yan yana koyup, eşleşme skorunu ve limitleri OpenCV pencerelerinde görsel olarak raporlar.

---

## ⚙️ Kurulum ve Çalıştırma (Tek Tıkla Deployment)

Proje, bilgisayarınızda hiçbir Python veya Node.js bağımlılığı gerektirmeden çalışacak şekilde Dockerize edilmiştir. 

**Gereksinimler:** Sadece `Docker` ve `Docker Compose` yüklü olmalıdır.

**Adımlar:**
1. Projeyi bilgisayarınıza klonlayın.
2. Terminali açıp projenin ana dizinine gidin.
3. Aşağıdaki komutu çalıştırın:
```bash
docker-compose up -d --build

Sistem Ayağa Kalktığında:

🖥️ Kullanıcı Arayüzü (Frontend): http://localhost:5173 (Nginx üzerinden sunulur)

⚙️ API Dokümantasyonu (Swagger UI): http://localhost:8000/docs

🗄️ Veritabanı: localhost:5432 portunda çalışır.

🧪 Otomatik Testler (QA)
Sistemin uç durumlara (Edge Cases) karşı dayanıklılığını ölçmek için pytest kullanılmıştır.
Testleri çalıştırmak için lokal sanal ortamınızda (venv):

Bash
pytest -v


Test Senaryoları:

Geçersiz TC Kimlik numarası uzunluğu kontrolü.

Matematiksel algoritması yanlış TC Kimlik reddi.

Geçersiz dosya formatı (Resim yerine PDF vb. yüklenmesi) engellemesi.


👨‍💻 Geliştirici
Enes Taşçı Bilgisayar Mühendisliği | Yapay Zeka ve Gömülü Sistemler Tutkunu