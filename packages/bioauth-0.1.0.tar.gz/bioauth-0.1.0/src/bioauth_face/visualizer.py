import cv2
import numpy as np

class FaceVisualizer:
    @staticmethod
    def show_match_result(img1_path, img2_path, result_dict):
        """
        İki fotoğrafı yan yana birleştirip, altına analiz sonucunu görsel olarak basar.
        """
        # 1. Fotoğrafları diskten oku
        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)
        
        if img1 is None or img2 is None:
            print("Hata: Görseller okunurken bir sorun oluştu.")
            return
            
        # 2. Fotoğrafları aynı boyuta (yüksekliğe) getir ki yan yana düzgün dursunlar
        target_height = 400
        
        aspect1 = img1.shape[1] / img1.shape[0]
        aspect2 = img2.shape[1] / img2.shape[0]
        
        img1_resized = cv2.resize(img1, (int(target_height * aspect1), target_height))
        img2_resized = cv2.resize(img2, (int(target_height * aspect2), target_height))
        
        # 3. İki fotoğrafı yatay eksende (Horizontal) birleştir
        combined_images = cv2.hconcat([img1_resized, img2_resized])
        
        # 4. Alt kısıma bilgi paneli (siyah şerit) oluştur
        panel_height = 100
        panel = np.zeros((panel_height, combined_images.shape[1], 3), dtype=np.uint8)
        
        # 5. Sonuca göre renk ve mesaj belirle
        distance = result_dict['distance']
        threshold = result_dict['threshold']
        
        if result_dict['is_match']:
            color = (0, 255, 0) # OpenCV'de BGR -> Yeşil
            text = f"ESLESTI! (Mesafe: {distance} < Limit: {threshold})"
        else:
            color = (0, 0, 255) # OpenCV'de BGR -> Kırmızı
            text = f"REDDEDILDI! (Mesafe: {distance} > Limit: {threshold})"
            
        # 6. Yazıyı panele ekle (Türkçe karakter kullanmıyoruz ki font bozulmasın)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(panel, text, (20, 60), font, 0.7, color, 2, cv2.LINE_AA)
        
        # 7. Fotoğraflarla siyah paneli dikey (Vertical) birleştir
        final_ui = cv2.vconcat([combined_images, panel])
        
        # 8. Ekranda göster
        window_name = "Yuz Dogrulama Analizi (Kapatmak icin tusa basin)"
        cv2.imshow(window_name, final_ui)
        
        # macOS için pencereyi öne getirme hilesi
        cv2.setWindowProperty(window_name, cv2.WND_PROP_TOPMOST, 1)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        cv2.waitKey(1)