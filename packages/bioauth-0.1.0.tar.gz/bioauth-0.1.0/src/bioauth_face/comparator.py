import numpy as np

class FaceComparator:
    def __init__(self, threshold=0.68):
        # ArcFace modeli için literatürde kabul gören standart eşik değeri
        self.threshold = threshold

    def calculate_cosine_distance(self, vector1, vector2):
        """
        İki vektör arasındaki Cosine (Kosinüs) mesafesini hesaplar.
        Mesafe 0'a ne kadar yakınsa, yüzler o kadar birbirinin aynısıdır.
        """
        a = np.array(vector1)
        b = np.array(vector2)
        
        # Nokta çarpımı (Dot Product)
        dot_product = np.dot(a, b)
        
        # Vektörlerin büyüklükleri (Norm/Magnitude)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        # Sıfıra bölme hatasını engellemek için güvenlik kontrolü
        if norm_a == 0 or norm_b == 0:
            return 1.0 # Tamamen farklı (maksimum mesafe) kabul et
            
        # Kosinüs benzerliği formülü uygulanır
        similarity = dot_product / (norm_a * norm_b)
        
        # Benzerliği (1 tam eşleşme) mesafeye (0 tam eşleşme) çeviriyoruz
        distance = 1.0 - similarity
        
        # Bilgisayardaki çok küçük ondalıklı hesaplama hatalarını (örn: -0.0000001) düzeltme
        return max(0.0, float(distance))

    def verify(self, vector1, vector2):
        """
        İki vektörün eşleşip eşleşmediğine karar verir.
        """
        distance = self.calculate_cosine_distance(vector1, vector2)
        is_match = distance <= self.threshold
        
        return {
            "is_match": is_match,
            "distance": round(distance, 4), # Daha temiz okumak için 4 ondalık basamağa yuvarladık
            "threshold": self.threshold
        }