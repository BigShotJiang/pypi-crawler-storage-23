from deepface import DeepFace

class FaceExtractor:
    def __init__(self, model_name='ArcFace', detector_backend='mtcnn'):
        self.model_name = model_name
        self.detector_backend = detector_backend

    def get_embedding(self, image_path):
        """
        Verilen fotoğraftaki yüzü bulur, ön işlemeden geçirir ve vektörünü döner.
        """
        try:
            # Ön işleme ve Vektör Çıkarımı
            embedding_objs = DeepFace.represent(
                img_path=image_path, 
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                enforce_detection=True 
            )
            
            # --- YENİ EKLENEN GÜVENLİK KONTROLÜ ---
            # Eğer fotoğrafta 1'den fazla yüz tespit edilirse güvenlik riski vardır
            if len(embedding_objs) > 1:
                raise ValueError("multiple_faces_detected")
            
            # Bulunan ilk (ve tek) yüzün 512 boyutlu vektörünü döndür
            return embedding_objs[0]['embedding']
            
        except ValueError as e:
            # DeepFace yüz bulamadığında veya bizim çoklu yüz hatamız fırlatıldığında
            if str(e) == "multiple_faces_detected":
                raise ValueError("Güvenlik ihlali: Fotoğrafta birden fazla yüz tespit edildi. Lütfen tek başınıza ve kameraya bakarak çekinin.")
            else:
                raise ValueError(f"Sistem fotoğrafta net bir insan yüzü tespit edemedi. Lütfen ışığı ve açıyı kontrol edip tekrar deneyin.")
        except Exception as e:
            raise RuntimeError(f"Vektör çıkarılırken sistem hatası oluştu: {str(e)}")