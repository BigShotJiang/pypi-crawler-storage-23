from setuptools import setup, find_packages

setup(
    name="bioauth",  # Paket adı
    version="0.1.0",
    description="Gelişmiş Yüz Tanıma ve Biyometrik Doğrulama Kütüphanesi",
    author="Enes Taşçı",
    packages=find_packages(where="src"), # Paketleri src klasöründe ara
    package_dir={"": "src"},             # Kök dizin olarak src'yi belirle
    install_requires=[
        "deepface",
        "opencv-python",
        "numpy",
        "tf-keras"
    ],
    python_requires=">=3.8",
)