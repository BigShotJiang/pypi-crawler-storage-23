"""Allow running as: python -m code_review_graph"""
from .cli import main

main()
