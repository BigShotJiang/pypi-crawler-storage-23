# Legal & Privacy

**License:** MIT (see [LICENSE](../LICENSE) in project root)

**Privacy:**
- Zero telemetry
- All graph data stored locally in `.code-review-graph/graph.db`
- No network calls during normal operation
- Optional embeddings model downloaded once from HuggingFace (when using `[embeddings]` extra)

**Data:** Never leaves your machine.

**Warranty:** Provided as-is, without warranty of any kind.
