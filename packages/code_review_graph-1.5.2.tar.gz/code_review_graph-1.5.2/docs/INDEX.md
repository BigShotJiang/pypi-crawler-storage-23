# Documentation Index

- [USAGE.md](USAGE.md) — How to install and use
- [FEATURES.md](FEATURES.md) — What's included, changelog
- [COMMANDS.md](COMMANDS.md) — All MCP tools, skills, and CLI commands
- [LLM-OPTIMIZED-REFERENCE.md](LLM-OPTIMIZED-REFERENCE.md) — Token-optimized reference (Claude Code reads this)
- [architecture.md](architecture.md) — System design and data flow
- [schema.md](schema.md) — Graph node/edge schema and SQLite tables
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) — Common issues and fixes
- [ROADMAP.md](ROADMAP.md) — Planned features
- [LEGAL.md](LEGAL.md) — License and privacy
