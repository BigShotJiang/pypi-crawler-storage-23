# galed

Galed is a requirements definition language and traceability engine for human-AI hybrid authorship in regulated systems — built on a heap of testimony, stone by stone.
