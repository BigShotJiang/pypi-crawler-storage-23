# Galed — namespace placeholder. Full implementation in progress.
# https://github.com/aetucker91/galed
