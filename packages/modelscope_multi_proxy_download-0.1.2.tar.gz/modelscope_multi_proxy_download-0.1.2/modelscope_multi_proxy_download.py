#!/usr/bin/env python3
"""Multi-proxy downloader for ModelScope model repos."""

from __future__ import annotations

import argparse
import fnmatch
import multiprocessing
import os
import queue
import sys
import threading
import time
from concurrent.futures import ProcessPoolExecutor, TimeoutError, as_completed
from pathlib import Path
from typing import Iterable


_PROXY_ENV_KEYS = (
    "http_proxy",
    "https_proxy",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "all_proxy",
    "ALL_PROXY",
)
_DIRECT_ROUTE = "DIRECT"
_DIRECT_TOKENS = {"DIRECT", "NONE", "NO_PROXY", "LOCAL"}
_WORKER_PROGRESS_QUEUE = None
_WORKER_SLOT = -1
_WORKER_ABORT_FLAGS = None
_SLOW_ABORT_SENTINEL = "__SLOW_ABORT__"
_LOW_SPEED_THRESHOLD_BPS = 500 * 1024
_LOW_SPEED_WINDOW_SEC = 60
_MAX_FILE_RETRIES = 3


def _read_proxy_file(path: str) -> list[str]:
    proxies: list[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            proxies.append(line)
    return proxies


def _expand_proxy_args(proxy_args: Iterable[str]) -> list[str]:
    expanded: list[str] = []
    for item in proxy_args:
        value = item.strip()
        if not value:
            continue
        proxy_file = Path(value)
        if proxy_file.is_file():
            expanded.extend(_read_proxy_file(str(proxy_file)))
        else:
            expanded.append(value)
    return expanded


def _normalize_proxy_list(raw_proxies: Iterable[str]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for item in raw_proxies:
        proxy = item.strip()
        if not proxy:
            continue
        if proxy.upper() in _DIRECT_TOKENS:
            proxy = _DIRECT_ROUTE
        elif "://" not in proxy:
            proxy = f"http://{proxy}"
        if proxy in seen:
            continue
        seen.add(proxy)
        deduped.append(proxy)
    return deduped


def _set_proxy_env(proxy: str) -> dict[str, str | None]:
    old: dict[str, str | None] = {k: os.environ.get(k) for k in _PROXY_ENV_KEYS}
    if proxy == _DIRECT_ROUTE:
        for key in _PROXY_ENV_KEYS:
            os.environ.pop(key, None)
    else:
        for key in _PROXY_ENV_KEYS:
            os.environ[key] = proxy
    return old


def _restore_proxy_env(old: dict[str, str | None]) -> None:
    for key, value in old.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


def _list_model_files(
    model_id: str,
    revision: str | None,
    token: str | None,
    proxies: list[str],
) -> tuple[str, list[str], str]:
    from modelscope.hub.api import HubApi

    last_error = "unknown error"
    for proxy in proxies:
        old_env = _set_proxy_env(proxy)
        try:
            api = HubApi(token=token)
            endpoint = api.get_endpoint_for_read(
                repo_id=model_id, repo_type="model", token=token
            )
            rev = api.get_valid_revision(
                model_id, revision=revision, cookies=api.get_cookies(), endpoint=endpoint
            )
            files = api.get_model_files(
                model_id=model_id,
                revision=rev,
                recursive=True,
                use_cookies=False if api.get_cookies() is None else api.get_cookies(),
                endpoint=endpoint,
            )
            paths = [f["Path"] for f in files if f.get("Type") != "tree" and "Path" in f]
            if not paths:
                raise RuntimeError(f"No downloadable files found in {model_id}@{rev}")
            return rev, paths, proxy
        except Exception as exc:  # pragma: no cover - runtime/network dependent
            last_error = f"{type(exc).__name__}: {exc}"
        finally:
            _restore_proxy_env(old_env)
    raise RuntimeError(f"Failed to list files via all proxies: {last_error}")


def _match_patterns(path: str, allow: list[str], ignore: list[str]) -> bool:
    if allow and not any(fnmatch.fnmatch(path, p) for p in allow):
        return False
    if ignore and any(fnmatch.fnmatch(path, p) for p in ignore):
        return False
    return True


def _format_bytes(num: float) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(max(0.0, num))
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            if unit == "B":
                return f"{int(value)}{unit}"
            return f"{value:.1f}{unit}"
        value /= 1024.0
    return f"{value:.1f}TB"


class _QueueTqdm:
    """Replacement for worker tqdm; emits progress events to parent process."""

    def __init__(self, *args, **kwargs):
        self.desc = kwargs.get("desc", "")
        self.total = kwargs.get("total", 0) or 0
        self.n = kwargs.get("initial", 0) or 0
        self._last_emit = 0.0
        self._emit(force=True)

    def _emit(self, force: bool = False) -> None:
        if _WORKER_PROGRESS_QUEUE is None:
            return
        now = time.time()
        if not force and now - self._last_emit < 0.2:
            return
        self._last_emit = now
        _WORKER_PROGRESS_QUEUE.put(("progress", _WORKER_SLOT, self.desc, self.n, self.total))

    def update(self, n: int = 1) -> None:
        if _WORKER_ABORT_FLAGS is not None and _WORKER_ABORT_FLAGS.get(_WORKER_SLOT, False):
            raise RuntimeError(_SLOW_ABORT_SENTINEL)
        self.n += n
        self._emit()

    def close(self) -> None:
        self._emit(force=True)
        if _WORKER_PROGRESS_QUEUE is not None:
            _WORKER_PROGRESS_QUEUE.put(
                ("progress_done", _WORKER_SLOT, self.desc, self.n, self.total)
            )


class _ProgressLayout:
    def __init__(self, workers: int):
        self.workers = workers
        self.status = [f"[Task {i + 1}] idle" for i in range(workers)]
        self.footer = "[Total] speed: 0B/s"
        self.enabled = sys.stdout.isatty()
        self._printed = False
        self._lock = threading.Lock()

    def _render(self) -> None:
        if not self.enabled:
            return
        if not self._printed:
            sys.stdout.write("\n" * (self.workers + 1))
            self._printed = True
        sys.stdout.write(f"\x1b[{self.workers + 1}F")
        for line in self.status:
            sys.stdout.write(f"\r\x1b[2K{line[:200]}\n")
        sys.stdout.write(f"\r\x1b[2K{self.footer[:200]}\n")
        sys.stdout.flush()

    def update(self, slot: int, line: str) -> None:
        if slot < 0 or slot >= self.workers:
            return
        with self._lock:
            self.status[slot] = line
            self._render()

    def set_footer(self, line: str) -> None:
        with self._lock:
            self.footer = line
            self._render()

    def log(self, line: str) -> None:
        with self._lock:
            if not self.enabled or not self._printed:
                print(line)
                return
            sys.stdout.write(f"\x1b[{self.workers + 1}F")
            sys.stdout.write(f"\r\x1b[2K{line}\n")
            for status_line in self.status:
                sys.stdout.write(f"\r\x1b[2K{status_line[:200]}\n")
            sys.stdout.write(f"\r\x1b[2K{self.footer[:200]}\n")
            sys.stdout.flush()


class _SpeedState:
    def __init__(self, workers: int):
        self._lock = threading.Lock()
        self._speed = [0.0] * workers
        self._desc = [""] * workers
        self._done = [0.0] * workers
        self._ts = [0.0] * workers
        self._low_since = [None] * workers

    def update(self, slot: int, desc: str, done: float, speed: float, now: float) -> None:
        with self._lock:
            self._speed[slot] = speed
            if desc != self._desc[slot]:
                self._low_since[slot] = None
            self._desc[slot] = desc
            self._done[slot] = done
            self._ts[slot] = now
            if done > 0 and speed < _LOW_SPEED_THRESHOLD_BPS and desc:
                if self._low_since[slot] is None:
                    self._low_since[slot] = now
            else:
                self._low_since[slot] = None

    def snapshot_slot(self, slot: int) -> dict:
        with self._lock:
            return {
                "speed": self._speed[slot],
                "desc": self._desc[slot],
                "done": self._done[slot],
                "ts": self._ts[slot],
                "low_since": self._low_since[slot],
            }


def _worker_init(
    proxy: str,
    enable_progress_layout: bool = False,
    progress_queue=None,
    worker_slot: int = -1,
    abort_flags=None,
) -> None:
    global _WORKER_PROGRESS_QUEUE, _WORKER_SLOT, _WORKER_ABORT_FLAGS
    _set_proxy_env(proxy)
    _WORKER_PROGRESS_QUEUE = progress_queue
    _WORKER_SLOT = worker_slot
    _WORKER_ABORT_FLAGS = abort_flags
    if enable_progress_layout and progress_queue is not None:
        import modelscope.hub.callback as callback_mod
        import modelscope.hub.file_download as file_download_mod

        callback_mod.tqdm = _QueueTqdm
        file_download_mod.tqdm = _QueueTqdm


def _progress_consumer(
    progress_queue, renderer: _ProgressLayout, speed_state: _SpeedState, stop_event: threading.Event
) -> None:
    last_done = [0.0] * renderer.workers
    last_ts = [0.0] * renderer.workers
    speed = [0.0] * renderer.workers
    last_desc = [""] * renderer.workers
    while not stop_event.is_set():
        try:
            event = progress_queue.get(timeout=0.2)
        except queue.Empty:
            continue
        except Exception:
            break

        _, slot, desc, done, total = event
        now = time.time()
        if slot < 0 or slot >= renderer.workers:
            continue

        if desc != last_desc[slot] or done < last_done[slot]:
            last_done[slot] = float(done)
            last_ts[slot] = now
            speed[slot] = 0.0
            last_desc[slot] = desc
        else:
            dt = now - last_ts[slot]
            delta = float(done) - last_done[slot]
            if dt > 0 and delta >= 0:
                inst = delta / dt
                speed[slot] = inst if speed[slot] <= 0 else (speed[slot] * 0.7 + inst * 0.3)
            last_done[slot] = float(done)
            last_ts[slot] = now

        if total and total > 0:
            pct = f"{(done / total) * 100:5.1f}%"
            progress = f"{_format_bytes(done)}/{_format_bytes(total)}"
        else:
            pct = "  ?.?%"
            progress = f"{_format_bytes(done)}"
        renderer.update(
            slot,
            f"[Task {slot + 1}] {pct} {progress} {_format_bytes(speed[slot])}/s {desc}",
        )
        renderer.set_footer(f"[Total] speed: {_format_bytes(sum(speed))}/s")
        speed_state.update(slot=slot, desc=desc, done=float(done), speed=float(speed[slot]), now=now)


def _check_proxy_reachable(proxy: str, timeout: float, test_url: str) -> tuple[bool, str]:
    import requests

    old_env = _set_proxy_env(proxy)
    started = time.time()
    try:
        resp = requests.get(test_url, timeout=timeout)
        elapsed = (time.time() - started) * 1000.0
        return True, f"HTTP {resp.status_code}, {elapsed:.0f}ms"
    except Exception as exc:  # pragma: no cover - runtime/network dependent
        return False, f"{type(exc).__name__}: {exc}"
    finally:
        _restore_proxy_env(old_env)


def _download_one(task: dict) -> tuple[str, bool, str]:
    from modelscope.hub.file_download import _repo_file_download

    path = task["file_path"]
    try:
        _repo_file_download(
            repo_id=task["model_id"],
            file_path=path,
            repo_type="model",
            revision=task["revision"],
            cache_dir=task["cache_dir"],
            local_dir=task["local_dir"],
            disable_tqdm=task["disable_worker_tqdm"],
            token=task["token"],
        )
        return path, True, ""
    except Exception as exc:  # pragma: no cover - runtime/network dependent
        return path, False, f"{type(exc).__name__}: {exc}"


def _download_one_via_route(task: dict, route: str) -> tuple[bool, str]:
    """Try downloading one file via a specific route in current process."""
    from modelscope.hub.file_download import _repo_file_download

    old_env = _set_proxy_env(route)
    try:
        _repo_file_download(
            repo_id=task["model_id"],
            file_path=task["file_path"],
            repo_type="model",
            revision=task["revision"],
            cache_dir=task["cache_dir"],
            local_dir=task["local_dir"],
            disable_tqdm=task["disable_worker_tqdm"],
            token=task["token"],
        )
        return True, ""
    except Exception as exc:  # pragma: no cover - runtime/network dependent
        return False, f"{type(exc).__name__}: {exc}"
    finally:
        _restore_proxy_env(old_env)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Download a ModelScope model with multiple proxies in parallel. "
            "Compatible with `modelscope download MODEL_ID --local_dir ...` core args."
        )
    )
    parser.add_argument("model_id", help="Model id, e.g. Qwen/Qwen3-VL-30B-A3B-Instruct-FP8")
    parser.add_argument(
        "--local_dir",
        default=None,
        help="Target directory for downloaded files (default: last path segment of model_id)",
    )
    parser.add_argument("--revision", default=None, help="Branch/tag/commit revision")
    parser.add_argument("--cache_dir", default=None, help="ModelScope cache directory")
    parser.add_argument("--token", default=None, help="ModelScope token for private models")
    parser.add_argument("--allow-pattern", dest="allow_patterns", action="append", default=[])
    parser.add_argument("--ignore-pattern", dest="ignore_patterns", action="append", default=[])
    parser.add_argument(
        "--proxy",
        action="append",
        default=[],
        help=(
            "Proxy endpoint or proxy-list file path. Can be passed multiple times, "
            "e.g. --proxy http://127.0.0.1:7890 or --proxy client/proxies.txt"
        ),
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=None,
        help="Override worker count (default: number of proxies)",
    )
    parser.add_argument(
        "--no-direct",
        action="store_true",
        help="Exclude DIRECT route from route pool",
    )
    parser.add_argument("--dry-run", action="store_true", help="Only list matched files")
    parser.add_argument(
        "--no-worker-progress",
        action="store_true",
        help="Disable managed real-time worker progress lines in parent process",
    )
    parser.add_argument(
        "--no-route-fallback",
        action="store_true",
        help="Disable retrying failed files on other routes",
    )
    parser.add_argument(
        "--check-proxies",
        action="store_true",
        help="Check whether each proxy route is reachable before download",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Only check route reachability and exit without listing/downloading model files",
    )
    parser.add_argument(
        "--check-url",
        default="https://www.modelscope.cn",
        help="URL used for route reachability checks",
    )
    parser.add_argument(
        "--check-timeout",
        type=float,
        default=8.0,
        help="Timeout seconds for each route reachability check (default: 8)",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if not args.local_dir:
        model_id_clean = args.model_id.strip().strip("/")
        if not model_id_clean:
            print("Error: invalid model_id for deriving local_dir", file=sys.stderr)
            return 2
        args.local_dir = model_id_clean.split("/")[-1]

    proxy_inputs = _expand_proxy_args(args.proxy)
    proxies = _normalize_proxy_list(proxy_inputs)
    if not args.no_direct and _DIRECT_ROUTE not in proxies:
        proxies.insert(0, _DIRECT_ROUTE)
    if args.no_direct:
        proxies = [p for p in proxies if p != _DIRECT_ROUTE]
    if not proxies:
        print(
            "Error: no available routes. Provide --proxy values or remove --no-direct.",
            file=sys.stderr,
        )
        return 2

    if args.check_proxies or args.check_only:
        print(f"Checking routes via: {args.check_url}")
        ok_count = 0
        for proxy in proxies:
            ok, detail = _check_proxy_reachable(
                proxy=proxy, timeout=args.check_timeout, test_url=args.check_url
            )
            label = "OK  " if ok else "FAIL"
            print(f"[{label}] {proxy} -> {detail}")
            if ok:
                ok_count += 1
        print(f"Reachable routes: {ok_count}/{len(proxies)}")
        if args.check_only:
            return 0 if ok_count > 0 else 1

    Path(args.local_dir).mkdir(parents=True, exist_ok=True)
    revision, all_files, list_proxy = _list_model_files(
        model_id=args.model_id,
        revision=args.revision,
        token=args.token,
        proxies=proxies,
    )
    matched_files = [
        f for f in all_files if _match_patterns(f, args.allow_patterns, args.ignore_patterns)
    ]
    if not matched_files:
        print("No files matched allow/ignore patterns; nothing to download.")
        return 0

    print(f"Model: {args.model_id}")
    print(f"Revision: {revision}")
    print(f"Listed via proxy: {list_proxy}")
    print(f"Matched files: {len(matched_files)} / Total files: {len(all_files)}")
    print(f"Proxies: {len(proxies)}")

    if args.dry_run:
        for path in matched_files:
            print(path)
        return 0

    workers = args.max_workers if args.max_workers is not None else len(proxies)
    workers = max(1, min(workers, len(proxies)))
    worker_proxies = proxies[:workers]
    print(f"Workers: {workers}")

    show_worker_progress = not args.no_worker_progress
    manager = multiprocessing.Manager()
    progress_queue = manager.Queue() if manager is not None else None
    progress_renderer = _ProgressLayout(workers) if show_worker_progress else None
    speed_state = _SpeedState(workers)
    progress_stop_event = threading.Event() if show_worker_progress else None
    abort_flags = manager.dict({slot: False for slot in range(workers)})
    progress_thread = None
    if show_worker_progress:
        progress_thread = threading.Thread(
            target=_progress_consumer,
            args=(progress_queue, progress_renderer, speed_state, progress_stop_event),
            daemon=True,
        )
        progress_thread.start()

    executors = []
    for slot, proxy in enumerate(worker_proxies):
        executors.append(
            ProcessPoolExecutor(
                max_workers=1,
                initializer=_worker_init,
                initargs=(proxy, show_worker_progress, progress_queue, slot, abort_flags),
            )
        )

    pending = {}
    running_by_slot: dict[int, object] = {}
    task_queue: list[dict] = [
        {
            "file_path": fp,
            "preferred_proxy": None,
            "reconnect_used": False,
            "slow_abort_count": 0,
        }
        for fp in matched_files
    ]
    file_fail_retries: dict[str, int] = {fp: 0 for fp in matched_files}
    failed: list[tuple[str, str]] = []

    def _log(msg: str, err: bool = False) -> None:
        if progress_renderer is not None:
            progress_renderer.log(msg)
        elif err:
            print(msg, file=sys.stderr)
        else:
            print(msg)

    def _submit_task(slot: int, task_item: dict) -> None:
        file_path = task_item["file_path"]
        task = {
            "model_id": args.model_id,
            "file_path": file_path,
            "revision": revision,
            "cache_dir": args.cache_dir,
            "local_dir": args.local_dir,
            "disable_worker_tqdm": not show_worker_progress,
            "token": args.token,
        }
        abort_flags[slot] = False
        future = executors[slot].submit(_download_one, task)
        pending[future] = {
            "slot": slot,
            "proxy": worker_proxies[slot],
            "file_path": file_path,
            "preferred_proxy": task_item.get("preferred_proxy"),
            "reconnect_used": bool(task_item.get("reconnect_used", False)),
            "slow_abort_count": int(task_item.get("slow_abort_count", 0)),
            "slow_action_taken": False,
            "resubmit_proxy": None,
        }
        running_by_slot[slot] = future

    def _pick_idle_slot(preferred_proxy: str | None) -> int | None:
        idle_slots = [slot for slot in range(workers) if slot not in running_by_slot]
        if not idle_slots:
            return None
        if preferred_proxy:
            for slot in idle_slots:
                if worker_proxies[slot] == preferred_proxy:
                    return slot
        return idle_slots[0]

    try:
        completed = 0
        total = len(matched_files)
        while completed < total:
            # Fill idle workers
            while task_queue:
                next_item = task_queue[0]
                slot = _pick_idle_slot(next_item.get("preferred_proxy"))
                if slot is None:
                    break
                task_queue.pop(0)
                _submit_task(slot, next_item)

            # Check low-speed switching/reconnect policy
            now = time.time()
            for slot, future in list(running_by_slot.items()):
                meta = pending.get(future)
                if meta is None:
                    continue
                snap = speed_state.snapshot_slot(slot)
                low_since = snap["low_since"]
                if low_since is None or now - low_since < _LOW_SPEED_WINDOW_SEC:
                    continue
                if meta.get("slow_action_taken", False):
                    continue

                idle_slots = [s for s in range(workers) if s not in running_by_slot and s != slot]
                if idle_slots:
                    target_slot = idle_slots[0]
                    meta["resubmit_proxy"] = worker_proxies[target_slot]
                    meta["slow_action_taken"] = True
                    abort_flags[slot] = True
                    _log(
                        f"[SLOW] {meta['file_path']} <500KB/s for 60s, switch to proxy "
                        f"{meta['resubmit_proxy']}"
                    )
                elif not meta["reconnect_used"]:
                    meta["resubmit_proxy"] = worker_proxies[slot]
                    meta["reconnect_used"] = True
                    meta["slow_action_taken"] = True
                    abort_flags[slot] = True
                    _log(
                        f"[SLOW] {meta['file_path']} <500KB/s for 60s, reconnect once via "
                        f"{meta['resubmit_proxy']}"
                    )

            if not pending:
                continue

            done_futures = []
            try:
                for future in as_completed(list(pending.keys()), timeout=1):
                    done_futures.append(future)
            except TimeoutError:
                done_futures = []

            for future in done_futures:
                meta = pending.pop(future, None)
                if meta is None:
                    continue
                slot = meta["slot"]
                running_by_slot.pop(slot, None)
                abort_flags[slot] = False
                file_path = meta["file_path"]

                try:
                    result_path, ok, err = future.result()
                except Exception as exc:  # pragma: no cover
                    ok = False
                    result_path = file_path
                    err = f"{type(exc).__name__}: {exc}"

                if ok:
                    completed += 1
                    _log(f"[{completed}/{total}] OK   {result_path}")
                    continue

                if _SLOW_ABORT_SENTINEL in err:
                    slow_abort_count = meta["slow_abort_count"] + 1
                    if slow_abort_count > (_MAX_FILE_RETRIES + 1):
                        completed += 1
                        fail_msg = f"{err} (exceeded slow-abort retries)"
                        _log(f"[{completed}/{total}] FAIL {file_path} -> {fail_msg}", err=True)
                        failed.append((file_path, fail_msg))
                        continue
                    task_queue.append(
                        {
                            "file_path": file_path,
                            "preferred_proxy": meta.get("resubmit_proxy"),
                            "reconnect_used": meta.get("reconnect_used", False),
                            "slow_abort_count": slow_abort_count,
                        }
                    )
                    _log(
                        f"[REQUEUE] {file_path} due to slow speed, retry via "
                        f"{meta.get('resubmit_proxy') or 'next available proxy'}"
                    )
                    continue

                file_fail_retries[file_path] += 1
                retry_count = file_fail_retries[file_path]
                if retry_count <= _MAX_FILE_RETRIES:
                    preferred = worker_proxies[slot] if args.no_route_fallback else None
                    task_queue.append(
                        {
                            "file_path": file_path,
                            "preferred_proxy": preferred,
                            "reconnect_used": meta.get("reconnect_used", False),
                            "slow_abort_count": meta.get("slow_abort_count", 0),
                        }
                    )
                    _log(
                        f"[RETRY {retry_count}/{_MAX_FILE_RETRIES}] {file_path} -> {err}",
                        err=True,
                    )
                else:
                    completed += 1
                    _log(f"[{completed}/{total}] FAIL {file_path} -> {err}", err=True)
                    failed.append((file_path, err))
    finally:
        for executor in executors:
            executor.shutdown(wait=True, cancel_futures=False)
        if progress_stop_event is not None:
            progress_stop_event.set()
        if progress_thread is not None:
            progress_thread.join(timeout=1.0)
        if manager is not None:
            manager.shutdown()

    if failed:
        print(f"\nFailed files: {len(failed)}", file=sys.stderr)
        for path, err in failed[:20]:
            print(f"- {path}: {err}", file=sys.stderr)
        if len(failed) > 20:
            print(f"... and {len(failed) - 20} more", file=sys.stderr)
        return 1

    print("\nAll files downloaded successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
