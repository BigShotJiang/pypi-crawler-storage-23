#!/usr/bin/env bash
# Git pre-commit hook to automatically bump patch version
# Install this hook by adding it to .pre-commit-config.yaml

set -e

# Get the project root directory
PROJECT_ROOT="$(git rev-parse --show-toplevel)"
cd "$PROJECT_ROOT"

# Check if uv is available
if ! command -v uv &> /dev/null; then
    echo "Warning: uv not found. Skipping version bump."
    exit 0
fi

# Get current version
CURRENT_VERSION=$(uv version --short 2>/dev/null || echo "0.0.0")

# Bump patch version (use --frozen to avoid re-locking)
echo "Bumping version from $CURRENT_VERSION..."
uv version --bump patch --frozen

# Get new version
NEW_VERSION=$(uv version --short)

# Stage the updated pyproject.toml
git add pyproject.toml

echo "Version bumped to $NEW_VERSION"
