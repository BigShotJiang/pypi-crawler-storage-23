"""Tests for the executor module."""

import json
from datetime import UTC, datetime

from steerdev_agent.executor.base import EventType, StreamEvent
from steerdev_agent.executor.stream import StreamParser


class TestStreamParser:
    """Tests for StreamParser."""

    def test_parse_valid_line(self):
        """Test parsing a valid JSON line."""
        parser = StreamParser()
        line = json.dumps({"type": "assistant", "message": {"content": "Hello"}})

        event = parser.parse_line(line)

        assert event is not None
        assert event.event_type == EventType.ASSISTANT
        assert event.data["message"]["content"] == "Hello"
        assert event.raw_json == line

    def test_parse_empty_line(self):
        """Test parsing an empty line returns None."""
        parser = StreamParser()
        event = parser.parse_line("")
        assert event is None

    def test_parse_whitespace_line(self):
        """Test parsing whitespace-only line returns None."""
        parser = StreamParser()
        event = parser.parse_line("   \n\t  ")
        assert event is None

    def test_parse_invalid_json(self):
        """Test parsing invalid JSON returns None."""
        parser = StreamParser()
        event = parser.parse_line("not valid json {")
        assert event is None

    def test_event_type_mapping(self):
        """Test all event types are mapped correctly."""
        parser = StreamParser()

        test_cases = [
            ("system", EventType.SYSTEM),
            ("user", EventType.USER),
            ("assistant", EventType.ASSISTANT),
            ("tool_use", EventType.TOOL_USE),
            ("tool_result", EventType.TOOL_RESULT),
            ("error", EventType.ERROR),
            ("result", EventType.RESULT),
        ]

        for type_str, expected_type in test_cases:
            line = json.dumps({"type": type_str})
            event = parser.parse_line(line)
            assert event is not None
            assert event.event_type == expected_type

    def test_unknown_type_defaults_to_system(self):
        """Test unknown event type defaults to SYSTEM."""
        parser = StreamParser()
        line = json.dumps({"type": "unknown_type"})

        event = parser.parse_line(line)

        assert event is not None
        assert event.event_type == EventType.SYSTEM

    def test_session_id_extraction_from_result(self):
        """Test session ID is extracted from result events."""
        parser = StreamParser()
        line = json.dumps(
            {
                "type": "result",
                "session_id": "test-session-123",
            }
        )

        event = parser.parse_line(line)

        assert event is not None
        assert parser.session_id == "test-session-123"

    def test_session_id_extraction_from_nested_result(self):
        """Test session ID is extracted from nested result."""
        parser = StreamParser()
        line = json.dumps(
            {
                "type": "result",
                "result": {"session_id": "nested-session-456"},
            }
        )

        event = parser.parse_line(line)

        assert event is not None
        assert parser.session_id == "nested-session-456"

    def test_feed_complete_lines(self):
        """Test feed method with complete lines."""
        parser = StreamParser()
        chunk = '{"type": "system"}\n{"type": "user"}\n'

        events = parser.feed(chunk)

        assert len(events) == 2
        assert events[0].event_type == EventType.SYSTEM
        assert events[1].event_type == EventType.USER

    def test_feed_partial_lines(self):
        """Test feed method with partial lines across chunks."""
        parser = StreamParser()

        # First chunk with partial line
        events1 = parser.feed('{"type": ')
        assert len(events1) == 0

        # Complete the line
        events2 = parser.feed('"assistant"}\n')
        assert len(events2) == 1
        assert events2[0].event_type == EventType.ASSISTANT

    def test_flush_remaining_buffer(self):
        """Test flush method returns remaining buffered data."""
        parser = StreamParser()

        # Feed partial line without newline
        parser.feed('{"type": "error"}')

        # Flush should return the event
        event = parser.flush()
        assert event is not None
        assert event.event_type == EventType.ERROR

    def test_flush_empty_buffer(self):
        """Test flush with empty buffer returns None."""
        parser = StreamParser()
        event = parser.flush()
        assert event is None

    def test_timestamp_parsing(self):
        """Test timestamp parsing from event data."""
        parser = StreamParser()
        line = json.dumps(
            {
                "type": "system",
                "timestamp": "2025-01-30T12:00:00Z",
            }
        )

        event = parser.parse_line(line)

        assert event is not None
        assert event.timestamp.year == 2025
        assert event.timestamp.month == 1
        assert event.timestamp.day == 30

    def test_timestamp_missing_uses_now(self):
        """Test missing timestamp defaults to now."""
        parser = StreamParser()
        before = datetime.now(UTC)

        line = json.dumps({"type": "system"})
        event = parser.parse_line(line)

        after = datetime.now(UTC)

        assert event is not None
        assert before <= event.timestamp <= after


class TestStreamEvent:
    """Tests for StreamEvent."""

    def test_is_final_for_result(self):
        """Test is_final returns True for result events."""
        event = StreamEvent(
            event_type=EventType.RESULT,
            timestamp=datetime.now(UTC),
            data={},
            raw_json="{}",
        )
        assert event.is_final is True

    def test_is_final_for_non_result(self):
        """Test is_final returns False for non-result events."""
        for event_type in [EventType.SYSTEM, EventType.USER, EventType.ASSISTANT]:
            event = StreamEvent(
                event_type=event_type,
                timestamp=datetime.now(UTC),
                data={},
                raw_json="{}",
            )
            assert event.is_final is False
