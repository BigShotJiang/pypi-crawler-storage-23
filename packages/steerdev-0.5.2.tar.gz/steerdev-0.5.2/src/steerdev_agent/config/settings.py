"""Environment settings management for steerdev."""

import os
from pathlib import Path
from typing import Annotated

from loguru import logger
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="STEERDEV_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # API Settings
    api_key: Annotated[
        str | None,
        Field(default=None, description="API key for steerdev.com"),
    ]
    api_endpoint: Annotated[
        str,
        Field(
            default="https://platform.steerdev.com/api/activity-report",
            description="API endpoint for activity reports",
        ),
    ]

    def get_env_value(self, env_var_name: str) -> str | None:
        """Get a value from environment by variable name.

        This allows config to reference environment variables by name
        rather than hardcoding values.

        Args:
            env_var_name: Name of the environment variable.

        Returns:
            The value if set, None otherwise.
        """
        return os.environ.get(env_var_name)


def get_settings() -> Settings:
    """Get cached settings instance.

    Returns:
        Singleton Settings instance.
    """
    from dotenv import load_dotenv

    logger.debug(f"Loading environment variables from {Path.cwd() / '.env'}")
    loaded_envs = load_dotenv(Path.cwd() / ".env", override=True)
    logger.debug(f"Environment variables loaded: {loaded_envs}")

    return Settings()
