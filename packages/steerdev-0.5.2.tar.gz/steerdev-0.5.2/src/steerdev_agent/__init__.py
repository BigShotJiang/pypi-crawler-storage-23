"""SteerDev Agent - Backend task runner for steerdev.com.

Orchestrates TUI coding agents (Claude Code, Gemini CLI, Codex) using tui-operator,
with activity reporting to steerdev.com API and notification integrations.
"""

from steerdev_agent.version import get_version

__version__ = get_version()
__all__ = ["__version__"]
