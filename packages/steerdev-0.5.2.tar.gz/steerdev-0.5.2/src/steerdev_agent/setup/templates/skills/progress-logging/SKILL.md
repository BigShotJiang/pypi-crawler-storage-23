# Progress Logging Skill

This skill provides instructions for writing progress logs during task execution.

**You MUST write progress logs for every task you work on.**

## Why Progress Logging

- **Visibility**: Track what agents are doing in real-time
- **Debugging**: Understand what happened when things go wrong
- **Knowledge Transfer**: Document decisions and approaches for future reference
- **Accountability**: Create an audit trail of work performed

## File Locations

All progress logs are written to the `docs/` directory:

```
docs/
├── progress.jsonl                    # Index of all progress events (append-only)
├── 20260203_143022_add_auth.md       # Detailed progress for a specific task
├── 20260203_150000_fix_login_bug.md  # Another task's progress
└── ...
```

## Progress Markdown Files

Create a detailed markdown file for each task:

**Naming convention**: `docs/{YYYYMMDD_HHMMSS}_{task_name_slug}.md`

**Template**:
```markdown
# Task: {Task Title}

**Task ID**: {task-id}
**Started**: {ISO timestamp}
**Status**: in-progress | completed | blocked

## Objective
{Brief description of what needs to be done}

## Progress

### {HH:MM} - {Phase/Action}
{Description of what was done}

**Files Modified**:
- `path/to/file.ts` - {what changed}

**Decisions Made**:
- {Decision and reasoning}

## Blockers
- {Any blockers encountered}

## Result
{Final outcome when completed}
```

## Progress Index (progress.jsonl)

Append a JSON line to `docs/progress.jsonl` for every significant event.

**Format**: One JSON object per line (newline-delimited JSON)

**Required fields**:
| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | string | ISO 8601 timestamp |
| `task_id` | string | Short task ID (first 8 chars of UUID) |
| `event` | string | Event type (see below) |
| `message` | string | Human-readable description |

**Optional fields**:
| Field | Type | Description |
|-------|------|-------------|
| `doc_file` | string | Path to detailed progress markdown |
| `files_modified` | array | List of file paths changed |
| `pr_url` | string | Pull request URL |
| `error` | string | Error message (for error events) |
| `metadata` | object | Additional structured data |

**Event types**:
| Event | When to Use |
|-------|-------------|
| `started` | Beginning work on a task |
| `progress` | Completing a milestone or significant step |
| `blocked` | Encountering a blocker |
| `error` | Encountering an error |
| `completed` | Finishing the task |

## When to Log

1. **Task Start**: Create progress markdown + log `started` event
2. **Major Milestones**: Log `progress` for each significant completion
3. **Every 15-30 minutes**: Log `progress` if still working (keeps session alive)
4. **Blockers**: Log `blocked` with what's needed to unblock
5. **Errors**: Log `error` with error details
6. **Task Completion**: Log `completed` with result and PR URL

## Example Commands

### Start a Task
```bash
# Create progress file
TIMESTAMP=$(date -u +%Y%m%d_%H%M%S)
TASK_SLUG="add_user_auth"
DOC_FILE="docs/${TIMESTAMP}_${TASK_SLUG}.md"

cat > "$DOC_FILE" << 'EOF'
# Task: Add User Authentication

**Task ID**: abc12345
**Started**: 2026-02-03T14:30:22Z
**Status**: in-progress

## Objective
Implement JWT-based authentication with login/logout endpoints.

## Progress

### 14:30 - Starting Implementation
Beginning work on authentication module.
EOF

# Log started event
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"started","message":"Beginning auth implementation","doc_file":"'"$DOC_FILE"'"}' >> docs/progress.jsonl
```

### Log Progress
```bash
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"progress","message":"JWT token generation complete","files_modified":["src/lib/auth.ts","src/lib/jwt.ts"]}' >> docs/progress.jsonl
```

### Log Blocker
```bash
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"blocked","message":"Need database credentials for testing"}' >> docs/progress.jsonl
```

### Log Error
```bash
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"error","message":"Build failed","error":"Module not found: @types/node"}' >> docs/progress.jsonl
```

### Log Completion
```bash
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"completed","message":"Auth implementation complete with tests","pr_url":"https://github.com/org/repo/pull/42","doc_file":"docs/20260203_143022_add_user_auth.md"}' >> docs/progress.jsonl
```

## Complete Workflow Example

```bash
# 1. Get next task
steerdev tasks next
# Returns task abc12345: "Add user authentication"

# 2. Mark task as started
steerdev tasks update abc12345... --status started

# 3. Create progress file and log start
TIMESTAMP=$(date -u +%Y%m%d_%H%M%S)
DOC_FILE="docs/${TIMESTAMP}_add_user_auth.md"

cat > "$DOC_FILE" << 'EOF'
# Task: Add User Authentication

**Task ID**: abc12345
**Started**: 2026-02-03T14:30:22Z
**Status**: in-progress

## Objective
Implement JWT-based authentication.

## Progress
EOF

echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"started","message":"Beginning auth implementation","doc_file":"'"$DOC_FILE"'"}' >> docs/progress.jsonl

# 4. Work on the task, logging progress...
# ... implement features ...

echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"progress","message":"Login endpoint complete"}' >> docs/progress.jsonl

# 5. Create PR and complete
git push -u origin HEAD
gh pr create --title "Add user authentication" --body "..."
# Returns: https://github.com/org/repo/pull/42

echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"completed","message":"Auth complete","pr_url":"https://github.com/org/repo/pull/42","doc_file":"'"$DOC_FILE"'"}' >> docs/progress.jsonl

# 6. Update task status
steerdev tasks update abc12345... --status completed --result "Implemented JWT auth. PR: https://github.com/org/repo/pull/42"
```

## Best Practices

1. **Create the progress file immediately** when starting a task
2. **Log frequently** - aim for updates every 15-30 minutes of active work
3. **Be specific** in messages - include what was done, not just "working on it"
4. **Include file paths** when you modify files
5. **Document decisions** - explain why you chose an approach
6. **Update the markdown file** with detailed notes as you work
7. **Always log completion** with PR URL before marking task done

## Integration with Other Skills

Progress logging works alongside:
- **Task Management**: Log progress while working on tasks
- **Activity Reporting**: Progress logs complement API activity reports
- **Git Workflow**: Include PR URLs in completion logs
