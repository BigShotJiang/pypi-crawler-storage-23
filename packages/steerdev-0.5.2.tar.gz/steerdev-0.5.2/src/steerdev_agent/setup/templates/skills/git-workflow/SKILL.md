# Git Workflow Skill

This skill provides Git workflow commands with steerdev conventions for branch management and pull requests.

## When to Use

- **Starting a task**: Create a properly named task branch
- **Completing work**: Create a pull request with proper format
- **Checking status**: See current branch and task context

## Available Commands

### Create Task Branch

```bash
steerdev git branch TASK_ID [--name NAME]
```

Create a task branch with steerdev naming convention: `task/<task-id-short>`.

**Arguments:**
- `TASK_ID`: Task ID to create branch for (uses first 8 characters)

**Options:**
- `--name`, `-n`: Custom branch name suffix

**Examples:**
```bash
# Create branch for task
steerdev git branch abc12345-def6-7890-...
# Creates: task/abc12345

# Create branch with descriptive suffix
steerdev git branch abc12345-def6-7890-... --name auth-flow
# Creates: task/abc12345-auth-flow
```

**Behavior:**
- If branch already exists, switches to it
- If branch doesn't exist, creates and switches to it

### Create Pull Request

```bash
steerdev git pr --title "TITLE" [--body "BODY"] [--task-id ID] [--draft]
```

Create a pull request using GitHub CLI with steerdev conventions.

**Options:**
- `--title`, `-t`: PR title (required)
- `--body`, `-b`: PR body/description
- `--task-id`: Task ID to reference in PR
- `--draft`, `-d`: Create as draft PR

**Examples:**
```bash
# Simple PR
steerdev git pr --title "Add user authentication"

# PR with description
steerdev git pr \
  --title "Add user authentication" \
  --body "## Summary
Implements JWT-based authentication.

## Changes
- Login endpoint
- Logout endpoint
- Auth middleware"

# PR linked to task
steerdev git pr \
  --title "Add user authentication" \
  --task-id abc12345...

# Draft PR
steerdev git pr \
  --title "WIP: Add user authentication" \
  --draft
```

**Note:** Requires GitHub CLI (`gh`) to be installed and authenticated.

### Check Git Status

```bash
steerdev git status
```

Show current branch and task context.

**Returns:**
- Current branch name
- Task ID (if branch follows `task/<id>` convention)
- Number of uncommitted changes
- Remote tracking status
- Ahead/behind status

**Example Output:**
```
Git Status
Branch: task/abc12345
Task ID: abc12345
Uncommitted changes: 3 file(s)
Tracking: origin/task/abc12345
Status: 2 ahead, 0 behind
```

## Complete Workflow Example

```bash
# 1. Get next task
steerdev tasks next

# 2. Create task branch
steerdev git branch abc12345-def6-7890-...

# 3. Check status
steerdev git status

# 4. Mark task as started
steerdev tasks update abc12345... --status started

# 5. Create progress log
TIMESTAMP=$(date -u +%Y%m%d_%H%M%S)
DOC_FILE="docs/${TIMESTAMP}_add_user_auth.md"
cat > "$DOC_FILE" << 'EOF'
# Task: Add User Authentication
**Task ID**: abc12345
**Started**: 2026-02-03T14:30:22Z
**Status**: in-progress
## Progress
EOF
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"started","message":"Beginning auth implementation","doc_file":"'"$DOC_FILE"'"}' >> docs/progress.jsonl

# 6. Implement the task...
# (make commits as you work)
git add .
git commit -m "feat: add login endpoint"

# Log progress
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"progress","message":"Login endpoint complete"}' >> docs/progress.jsonl

git add .
git commit -m "feat: add logout endpoint"

# 7. Check status before PR
steerdev git status

# 8. Push and create PR
git push -u origin HEAD
steerdev git pr \
  --title "Add user authentication" \
  --task-id abc12345... \
  --body "## Summary
Implements JWT authentication as specified.

## Changes
- Login endpoint with JWT generation
- Logout endpoint with token invalidation
- Auth middleware for protected routes

## Testing
- Run \`pytest tests/auth/\`
- Manual test via /api/docs"
# Returns: https://github.com/org/repo/pull/42

# 9. Log completion
echo '{"timestamp":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","task_id":"abc12345","event":"completed","message":"Auth implementation complete","pr_url":"https://github.com/org/repo/pull/42","doc_file":"'"$DOC_FILE"'"}' >> docs/progress.jsonl

# 10. Mark task complete with PR URL
steerdev tasks update abc12345... \
  --status completed \
  --result "Implemented auth. PR: https://github.com/org/repo/pull/42"
```

## Branch Naming Convention

Branches follow the pattern: `task/<short-task-id>[-optional-suffix]`

- `task/abc12345` - Basic task branch
- `task/abc12345-auth` - With descriptive suffix
- `task/abc12345-fix-login` - More detailed suffix

The short task ID is the first 8 characters of the full UUID.

## PR Conventions

Pull requests created via this skill include:

1. **Title**: Descriptive title of changes
2. **Body**: Optional description with:
   - Summary of changes
   - Task reference (if --task-id provided)
3. **Footer**: Link to steerdev.com

## Important Rules

1. **Always create a branch** before starting work
2. **Commit frequently** with descriptive messages
3. **Create PR before marking task complete**
4. **Include PR URL** in task completion result
5. **Log progress** to `docs/progress.jsonl` (see Progress Logging skill)
6. **Log completion** with PR URL before marking task done

## Prerequisites

- **Git**: Must be installed and repository initialized
- **GitHub CLI**: Required for `git pr` command
  - Install: https://cli.github.com
  - Authenticate: `gh auth login`

## Environment

No additional environment variables required for git commands.

Uses local git configuration for author information.
