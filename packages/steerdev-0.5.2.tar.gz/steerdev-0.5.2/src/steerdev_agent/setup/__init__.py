"""Setup module for configuring Claude Code integration."""

from steerdev_agent.setup.claude_setup import ClaudeSetup

__all__ = ["ClaudeSetup"]
