"""Prompt templates for different agent scenarios."""


class PromptTemplates:
    """Collection of prompt templates."""

    # Base system prompt template
    SYSTEM_PROMPT = """You are an AI coding assistant working on a software project.

## Project Information
{project_info}

## Task
{task_info}

## Instructions
{instructions}
"""

    # Task prompt template
    TASK_PROMPT = """## Current Task

**Title:** {title}
**ID:** {task_id}
**Priority:** {priority}
**Status:** {status}

### Description
{prompt}

### Working Directory
{working_directory}
"""

    # Project info template
    PROJECT_INFO = """**Project:** {name}
**ID:** {project_id}
**Description:** {description}
"""

    # Workflow phase template
    WORKFLOW_PHASE = """## Workflow Phase

**Phase:** {phase_name}
**Description:** {phase_description}

### Phase Instructions
{phase_instructions}
"""

    # Default instructions when none are provided
    DEFAULT_INSTRUCTIONS = """1. Analyze the task requirements carefully
2. Break down the work into logical steps
3. Implement changes incrementally, testing as you go
4. Write clean, maintainable code
5. Follow the project's coding conventions
6. Document significant changes
7. Ensure all tests pass before completing
"""

    # Resume prompt template
    RESUME_PROMPT = """Continue working on the previous task.

{message}
"""

    # Spec generation prompt
    SPEC_GENERATION = """You are generating a technical specification for a new feature or change.

## Task
{task_info}

## Instructions
1. Analyze the requirements thoroughly
2. Create a detailed technical specification
3. Include:
   - Overview and goals
   - Technical approach
   - Implementation details
   - Testing strategy
   - Potential risks and mitigations
4. Be specific about file changes needed
5. Consider edge cases and error handling
"""

    # Implementation prompt
    IMPLEMENTATION = """You are implementing a task based on an existing specification.

## Task
{task_info}

## Specification
{spec}

## Instructions
1. Follow the specification closely
2. Implement all required changes
3. Write tests as specified
4. Ensure code quality and best practices
5. Report any deviations from the spec
"""

    # PRD Analysis prompt - for analyzing PRDs and generating clarification questions
    PRD_ANALYZE = """Analyze this Product Requirements Document (PRD) and identify areas needing clarification.

## PRD Title
{prd_title}

## PRD Content
{prd_content}

## Instructions
1. Read the PRD carefully and thoroughly
2. Identify ambiguous, incomplete, or unclear requirements
3. Generate specific questions that need answers before implementation can begin
4. Group related questions logically by category (Technical, UX, Business, etc.)
5. For each question, provide context explaining why this clarification is needed

## Response Format
You MUST respond with valid JSON in this exact format:
{{
  "summary": "Brief 2-3 sentence summary of what this PRD is about",
  "questions": [
    {{
      "question": "What authentication method should be used?",
      "context": "The PRD mentions 'secure login' but doesn't specify OAuth, JWT, session cookies, etc.",
      "category": "Technical"
    }},
    {{
      "question": "Should the dashboard support mobile responsive design?",
      "context": "Screen dimensions and breakpoints are not specified",
      "category": "UX"
    }}
  ],
  "initial_observations": "Any immediate feedback, concerns, or suggestions about the PRD"
}}

Focus on questions that would meaningfully impact the implementation approach.
Avoid trivial questions that can be reasonably assumed or decided during implementation.
"""

    # PRD Plan Generation prompt - for creating implementation plans from clarified PRDs
    PRD_GENERATE_PLAN = """Generate an implementation plan from this Product Requirements Document.

## PRD Title
{prd_title}

## PRD Content
{prd_content}

## Clarifications Received
{clarifications}

## Instructions
1. Based on the PRD and clarifications, create a comprehensive implementation plan
2. Break the work into logical sections/phases
3. Each section should represent a cohesive unit of work
4. Estimate complexity for each section (low, medium, high)
5. Preview the types of tasks that would be created for each section
6. Identify dependencies between sections
7. Note any risks or considerations

## Response Format
You MUST respond with valid JSON in this exact format:
{{
  "plan_summary": "High-level overview of the implementation approach (2-3 paragraphs)",
  "sections": [
    {{
      "title": "Authentication System",
      "description": "Detailed description of what needs to be built in this section",
      "estimated_complexity": "medium",
      "tasks_preview": [
        "Set up OAuth provider integration",
        "Implement login/logout flow",
        "Add session management",
        "Create protected route middleware"
      ]
    }},
    {{
      "title": "User Dashboard",
      "description": "Build the main user dashboard with key metrics and actions",
      "estimated_complexity": "high",
      "tasks_preview": [
        "Design dashboard layout",
        "Implement metrics widgets",
        "Add data visualization components",
        "Create responsive mobile view"
      ]
    }}
  ],
  "dependencies": [
    "Authentication System must complete before User Dashboard",
    "Database schema must be finalized before API development"
  ],
  "risks": [
    "Third-party API rate limits may affect performance",
    "Mobile responsive requirements may extend timeline"
  ]
}}

Create sections that represent meaningful units of work that can be developed and tested independently where possible.
"""

    # PRD Task Generation prompt - for creating development tasks from implementation plan
    PRD_GENERATE_TASKS = """Generate specific development tasks from this implementation plan.

## PRD Title
{prd_title}

## Implementation Plan
{implementation_plan}

## Instructions
1. Convert the implementation plan sections into actionable development tasks
2. Each task should be specific, well-defined, and independently completable
3. Include clear acceptance criteria in the description
4. Assign appropriate priority (0=None, 1=Urgent, 2=High, 3=Medium, 4=Low)
5. Note any dependencies between tasks
6. Ensure tasks are appropriately sized (not too large, not too small)

## Response Format
You MUST respond with valid JSON in this exact format:
{{
  "tasks": [
    {{
      "title": "Set up OAuth provider integration",
      "description": "Integrate with the selected OAuth provider (e.g., Auth0, Clerk).\\n\\nAcceptance Criteria:\\n- OAuth client configured\\n- Callback URLs set up\\n- Environment variables documented\\n- Basic login test passing",
      "priority": 2,
      "section": "Authentication System",
      "dependencies": []
    }},
    {{
      "title": "Implement login/logout flow",
      "description": "Create the login and logout user flows with proper session handling.\\n\\nAcceptance Criteria:\\n- Login page with OAuth buttons\\n- Logout functionality\\n- Session persistence\\n- Redirect after auth",
      "priority": 2,
      "section": "Authentication System",
      "dependencies": ["Set up OAuth provider integration"]
    }}
  ]
}}

Create tasks that can be completed by a single developer in a reasonable time (1-2 days).
Larger work should be broken into multiple tasks.
"""

    @classmethod
    def format_system_prompt(
        cls,
        project_info: str = "",
        task_info: str = "",
        instructions: str = "",
    ) -> str:
        """Format the system prompt with provided context.

        Args:
            project_info: Formatted project information.
            task_info: Formatted task information.
            instructions: Custom instructions or defaults.

        Returns:
            Formatted system prompt.
        """
        return cls.SYSTEM_PROMPT.format(
            project_info=project_info or "No project information available.",
            task_info=task_info or "No task information available.",
            instructions=instructions or cls.DEFAULT_INSTRUCTIONS,
        )

    @classmethod
    def format_task(
        cls,
        title: str,
        task_id: str,
        prompt: str,
        priority: int = 3,
        status: str = "unstarted",
        working_directory: str = ".",
    ) -> str:
        """Format task information.

        Args:
            title: Task title.
            task_id: Task ID.
            prompt: Task prompt/description.
            priority: Task priority (1-4).
            status: Task status.
            working_directory: Working directory.

        Returns:
            Formatted task information.
        """
        priority_names = {1: "Urgent", 2: "High", 3: "Medium", 4: "Low", 0: "None"}
        priority_display = priority_names.get(priority, "Unknown")

        return cls.TASK_PROMPT.format(
            title=title,
            task_id=task_id,
            priority=priority_display,
            status=status,
            prompt=prompt,
            working_directory=working_directory,
        )

    @classmethod
    def format_project(
        cls,
        name: str,
        project_id: str,
        description: str = "",
    ) -> str:
        """Format project information.

        Args:
            name: Project name.
            project_id: Project ID.
            description: Project description.

        Returns:
            Formatted project information.
        """
        return cls.PROJECT_INFO.format(
            name=name,
            project_id=project_id,
            description=description or "No description available.",
        )

    @classmethod
    def format_workflow_phase(
        cls,
        phase_name: str,
        phase_description: str = "",
        phase_instructions: str = "",
    ) -> str:
        """Format workflow phase information.

        Args:
            phase_name: Name of the workflow phase.
            phase_description: Description of the phase.
            phase_instructions: Specific instructions for this phase.

        Returns:
            Formatted workflow phase information.
        """
        return cls.WORKFLOW_PHASE.format(
            phase_name=phase_name,
            phase_description=phase_description or "No description available.",
            phase_instructions=phase_instructions or "Follow standard procedures.",
        )

    @classmethod
    def format_prd_analyze(
        cls,
        prd_title: str,
        prd_content: str,
    ) -> str:
        """Format PRD analysis prompt.

        Args:
            prd_title: Title of the PRD.
            prd_content: Full content of the PRD.

        Returns:
            Formatted PRD analysis prompt.
        """
        return cls.PRD_ANALYZE.format(
            prd_title=prd_title,
            prd_content=prd_content,
        )

    @classmethod
    def format_prd_generate_plan(
        cls,
        prd_title: str,
        prd_content: str,
        clarifications: list[dict[str, str]] | None = None,
    ) -> str:
        """Format PRD plan generation prompt.

        Args:
            prd_title: Title of the PRD.
            prd_content: Full content of the PRD.
            clarifications: List of Q&A clarifications.

        Returns:
            Formatted PRD plan generation prompt.
        """
        clarifications_text = "No clarifications provided."
        if clarifications:
            clarifications_text = "\n".join(
                f"**Q:** {c.get('question', 'N/A')}\n**A:** {c.get('answer', 'N/A')}\n"
                for c in clarifications
            )

        return cls.PRD_GENERATE_PLAN.format(
            prd_title=prd_title,
            prd_content=prd_content,
            clarifications=clarifications_text,
        )

    @classmethod
    def format_prd_generate_tasks(
        cls,
        prd_title: str,
        implementation_plan: dict,
    ) -> str:
        """Format PRD task generation prompt.

        Args:
            prd_title: Title of the PRD.
            implementation_plan: The implementation plan as a dictionary.

        Returns:
            Formatted PRD task generation prompt.
        """
        import json

        plan_text = json.dumps(implementation_plan, indent=2)

        return cls.PRD_GENERATE_TASKS.format(
            prd_title=prd_title,
            implementation_plan=plan_text,
        )
