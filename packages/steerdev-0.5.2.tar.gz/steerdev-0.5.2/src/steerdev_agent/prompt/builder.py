"""Dynamic prompt builder for agent execution."""

from typing import Any

from pydantic import BaseModel, Field

from steerdev_agent.prompt.templates import PromptTemplates


class ProjectContext(BaseModel):
    """Project context for prompt building."""

    id: str = Field(description="Project ID")
    name: str = Field(description="Project name")
    description: str = Field(default="", description="Project description")
    working_directory: str = Field(default=".", description="Default working directory")
    custom_instructions: str | None = Field(
        default=None, description="Custom instructions for this project"
    )


class WaveContext(BaseModel):
    """Wave context for prompt building."""

    wave_number: int = Field(description="Current wave number")
    total_waves: int = Field(description="Total number of waves")
    wave_description: str = Field(default="", description="Description of this wave")
    wave_tasks_summary: str = Field(default="", description="Summary of tasks in this wave")
    completed_waves_summary: str = Field(default="", description="Summary of completed waves")


class TaskContext(BaseModel):
    """Task context for prompt building."""

    id: str = Field(description="Task ID")
    title: str = Field(description="Task title")
    prompt: str = Field(description="Task prompt/description")
    status: str = Field(default="unstarted", description="Task status")
    priority: int = Field(default=3, description="Task priority (1=urgent, 4=low)")
    working_directory: str | None = Field(default=None, description="Task working directory")
    spec: str | None = Field(default=None, description="Technical specification")
    metadata: dict[str, Any] | None = Field(default=None, description="Additional metadata")
    wave: WaveContext | None = Field(
        default=None, description="Wave context if task is part of a wave"
    )


class WorkflowContext(BaseModel):
    """Workflow phase context for prompt building."""

    phase_name: str = Field(description="Current workflow phase name")
    phase_description: str = Field(default="", description="Phase description")
    phase_instructions: str = Field(default="", description="Phase-specific instructions")


class PromptContext(BaseModel):
    """Complete context for building a prompt."""

    project: ProjectContext | None = Field(default=None, description="Project context")
    task: TaskContext | None = Field(default=None, description="Task context")
    workflow: WorkflowContext | None = Field(default=None, description="Workflow context")
    custom_instructions: str | None = Field(
        default=None, description="Additional custom instructions"
    )
    resume_message: str | None = Field(
        default=None, description="Message for resume (if resuming session)"
    )


class PromptBuilder:
    """Builds prompts by combining context from various sources.

    The builder combines:
    - Project metadata and instructions
    - Task details and requirements
    - Workflow phase information
    - Custom instructions

    Into a single coherent prompt for the agent.
    """

    def __init__(self, templates: PromptTemplates | None = None) -> None:
        """Initialize the prompt builder.

        Args:
            templates: Custom templates to use. Defaults to PromptTemplates.
        """
        self.templates = templates or PromptTemplates()

    def build(self, context: PromptContext) -> str:
        """Build a complete prompt from the context.

        Args:
            context: The prompt context containing all information.

        Returns:
            A formatted prompt string.
        """
        # Handle resume case
        if context.resume_message:
            return self._build_resume_prompt(context)

        # Build components
        project_info = self._build_project_info(context.project)
        task_info = self._build_task_info(context.task, context.project)
        instructions = self._build_instructions(context)

        # Add workflow phase if present
        if context.workflow:
            workflow_info = self.templates.format_workflow_phase(
                phase_name=context.workflow.phase_name,
                phase_description=context.workflow.phase_description,
                phase_instructions=context.workflow.phase_instructions,
            )
            task_info = f"{task_info}\n\n{workflow_info}"

        return self.templates.format_system_prompt(
            project_info=project_info,
            task_info=task_info,
            instructions=instructions,
        )

    def _build_resume_prompt(self, context: PromptContext) -> str:
        """Build a prompt for resuming a session.

        Args:
            context: The prompt context.

        Returns:
            A resume prompt string.
        """
        message = context.resume_message or "Continue working on the task."
        return self.templates.RESUME_PROMPT.format(message=message)

    def _build_project_info(self, project: ProjectContext | None) -> str:
        """Build project information section.

        Args:
            project: Project context or None.

        Returns:
            Formatted project information.
        """
        if project is None:
            return ""

        return self.templates.format_project(
            name=project.name,
            project_id=project.id,
            description=project.description,
        )

    def _build_task_info(
        self,
        task: TaskContext | None,
        project: ProjectContext | None,
    ) -> str:
        """Build task information section.

        Args:
            task: Task context or None.
            project: Project context for working directory fallback.

        Returns:
            Formatted task information.
        """
        if task is None:
            return ""

        # Determine working directory
        working_dir = task.working_directory
        if working_dir is None and project is not None:
            working_dir = project.working_directory
        if working_dir is None:
            working_dir = "."

        task_info = self.templates.format_task(
            title=task.title,
            task_id=task.id,
            prompt=task.prompt,
            priority=task.priority,
            status=task.status,
            working_directory=working_dir,
        )

        # Add spec if present
        if task.spec:
            task_info = f"{task_info}\n\n### Specification\n{task.spec}"

        # Add wave context if present
        if task.wave:
            wave_section = (
                f"\n\n### Wave Context\n"
                f"**Wave {task.wave.wave_number} of {task.wave.total_waves}**"
            )
            if task.wave.wave_description:
                wave_section += f" — {task.wave.wave_description}"
            if task.wave.completed_waves_summary:
                wave_section += f"\n\n**Completed Waves:**\n{task.wave.completed_waves_summary}"
            if task.wave.wave_tasks_summary:
                wave_section += f"\n\n**Tasks in This Wave:**\n{task.wave.wave_tasks_summary}"
            task_info = f"{task_info}{wave_section}"

        return task_info

    def _build_instructions(self, context: PromptContext) -> str:
        """Build the instructions section.

        Combines default instructions with custom instructions from
        project and context.

        Args:
            context: The prompt context.

        Returns:
            Combined instructions string.
        """
        instructions_parts = []

        # Add project custom instructions
        if context.project and context.project.custom_instructions:
            instructions_parts.append(context.project.custom_instructions)

        # Add context custom instructions
        if context.custom_instructions:
            instructions_parts.append(context.custom_instructions)

        # If no custom instructions, use defaults
        if not instructions_parts:
            return self.templates.DEFAULT_INSTRUCTIONS

        return "\n\n".join(instructions_parts)

    def build_from_dict(
        self,
        project: dict[str, Any] | None = None,
        task: dict[str, Any] | None = None,
        workflow: dict[str, Any] | None = None,
        custom_instructions: str | None = None,
        resume_message: str | None = None,
    ) -> str:
        """Build a prompt from dictionary inputs.

        Convenience method for building prompts from API responses.

        Args:
            project: Project data dict.
            task: Task data dict.
            workflow: Workflow data dict.
            custom_instructions: Additional instructions.
            resume_message: Message for resume.

        Returns:
            A formatted prompt string.
        """
        context = PromptContext(
            project=ProjectContext(**project) if project else None,
            task=TaskContext(**task) if task else None,
            workflow=WorkflowContext(**workflow) if workflow else None,
            custom_instructions=custom_instructions,
            resume_message=resume_message,
        )
        return self.build(context)
