"""Base API client for SteerDev API."""

import os
from typing import Any, Self

import httpx
from rich.console import Console

console = Console()

# Default API endpoint
DEFAULT_API_ENDPOINT = "https://platform.steerdev.com/api/v1"


def get_api_key() -> str | None:
    """Get API key from environment."""
    return os.environ.get("STEERDEV_API_KEY")


def get_project_id() -> str | None:
    """Get project ID from environment."""
    return os.environ.get("STEERDEV_PROJECT_ID")


def get_agent_id() -> str | None:
    """Get agent ID from environment."""
    return os.environ.get("STEERDEV_AGENT_ID")


def get_agent_name() -> str | None:
    """Get agent name from environment."""
    return os.environ.get("STEERDEV_AGENT_NAME")


def get_api_endpoint() -> str:
    """Get API endpoint from environment or use default."""
    return os.environ.get("STEERDEV_API_ENDPOINT", DEFAULT_API_ENDPOINT)


class SteerDevClient:
    """Base HTTP client for SteerDev API.

    Handles authentication, headers, and common error handling.
    """

    def __init__(self, api_key: str | None = None, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY env var.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or get_api_key()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _get_client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.Client(timeout=self.timeout, follow_redirects=True)
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> Self:
        """Enter context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context manager."""
        self.close()

    def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make a GET request.

        Args:
            path: API path (e.g., "/tasks").
            params: Query parameters.

        Returns:
            HTTP response.
        """
        client = self._get_client()
        return client.get(
            f"{self.api_base}{path}",
            headers=self.headers,
            params=params,
        )

    def post(
        self,
        path: str,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make a POST request.

        Args:
            path: API path (e.g., "/tasks").
            json: Request body as JSON.

        Returns:
            HTTP response.
        """
        client = self._get_client()
        return client.post(
            f"{self.api_base}{path}",
            headers=self.headers,
            json=json,
        )

    def patch(
        self,
        path: str,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make a PATCH request.

        Args:
            path: API path (e.g., "/tasks/{id}").
            json: Request body as JSON.

        Returns:
            HTTP response.
        """
        client = self._get_client()
        return client.patch(
            f"{self.api_base}{path}",
            headers=self.headers,
            json=json,
        )

    def check_api_key(self) -> bool:
        """Check if API key is configured.

        Returns:
            True if API key is set.
        """
        if not self.api_key:
            console.print("[red]Error: STEERDEV_API_KEY environment variable not set[/red]")
            return False
        return True
