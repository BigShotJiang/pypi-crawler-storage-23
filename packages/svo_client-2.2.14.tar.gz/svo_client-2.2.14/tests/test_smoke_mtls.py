"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Smoke test for chunking on localhost:8009 with mTLS.
"""

import asyncio
from pathlib import Path

import pytest

from svo_client import ChunkerClient, SVOConnectionError


@pytest.mark.asyncio
class TestSmokeMTLS:
    """Smoke tests for mTLS chunking on localhost:8009."""

    @pytest.fixture
    def mtls_certs(self):
        """Get mTLS certificate paths."""
        cert_dir = Path("mtls_certificates")
        if not cert_dir.exists():
            pytest.skip("mTLS certificates not found")

        cert = cert_dir / "client" / "svo-chunker.crt"
        key = cert_dir / "client" / "svo-chunker.key"
        ca = cert_dir / "ca" / "ca.crt"

        if not (cert.exists() and key.exists() and ca.exists()):
            pytest.skip("mTLS certificates incomplete")

        return {
            "cert": str(cert),
            "key": str(key),
            "ca": str(ca),
        }

    # Use server_available from conftest

    async def test_smoke_health(self, server_available, mtls_certs):
        """Smoke test: health check via mTLS."""
        if not server_available:
            pytest.fail("Server not available on localhost:8009")

        async with ChunkerClient(
            host="localhost",
            port=8009,
            cert=mtls_certs["cert"],
            key=mtls_certs["key"],
            ca=mtls_certs["ca"],
            check_hostname=False,
        ) as client:
            result = await client.health()
            assert result is not None
            assert isinstance(result, dict)

    async def test_smoke_chunk_simple(self, server_available, mtls_certs):
        """Smoke test: simple chunking via mTLS."""
        if not server_available:
            pytest.fail("Server not available on localhost:8009")

        test_text = "This is a simple test text for chunking. It contains multiple sentences to ensure it meets the minimum length requirements. The text should be long enough to be processed by the chunking service without errors."

        async with ChunkerClient(
            host="localhost",
            port=8009,
            cert=mtls_certs["cert"],
            key=mtls_certs["key"],
            ca=mtls_certs["ca"],
            check_hostname=False,
            timeout=180.0,  # Chunking may take time if embedding service is slow
        ) as client:
            batch = await client.chunk(
                [test_text], type="Draft", language="en", verify_integrity=False
            )
            chunks = batch[0] if batch else []
            assert len(chunks) > 0
            assert all(hasattr(chunk, "text") for chunk in chunks)

    async def test_smoke_chunk_integrity(self, server_available, mtls_certs):
        """Smoke test: chunking with integrity verification."""
        if not server_available:
            pytest.fail("Server not available on localhost:8009")

        test_text = "Artificial Intelligence is a branch of computer science. It aims to create intelligent machines that can perform tasks typically requiring human intelligence. Machine learning is a subset of AI that enables systems to learn from data."

        async with ChunkerClient(
            host="localhost",
            port=8009,
            cert=mtls_certs["cert"],
            key=mtls_certs["key"],
            ca=mtls_certs["ca"],
            check_hostname=False,
            timeout=180.0,  # Chunking with embeddings can be slow
        ) as client:
            from svo_client.text_utils import reconstruct_text
            batch = await client.chunk(
                [test_text],
                type="Draft",
                language="en",
                verify_integrity=True,
            )
            chunks = batch[0] if batch else []
            assert len(chunks) > 0
            reconstructed = reconstruct_text(chunks)
            # Chunker may normalize whitespace (e.g. drop space after period); check content
            assert len(reconstructed) >= len(test_text) * 0.9
            assert "Artificial Intelligence" in reconstructed
            assert "Machine learning" in reconstructed

    @pytest.mark.skip(reason="WS-only client: queue operations removed")
    async def test_smoke_queue_operations(self, server_available, mtls_certs):
        """Smoke test: queue operations (submit, status, wait)."""
        pass

    @pytest.mark.skip(reason="WS-only client: list_jobs removed")
    async def test_smoke_list_jobs(self, server_available, mtls_certs):
        """Smoke test: list jobs."""
        pass

