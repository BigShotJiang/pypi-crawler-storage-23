"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Edge case tests for ChunkerClient to increase coverage.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from svo_client import ChunkerClient
from svo_client.errors import SVOServerError


class TestChunkerClientEdgeCases:
    """Edge case tests for ChunkerClient."""

    @pytest.mark.skip(reason="WS-only client: wait_for_result removed")
    @pytest.mark.asyncio
    async def test_wait_for_result_status_dict(self):
        """Test wait_for_result with status as dict."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_status = {
                "data": {
                    "status": "completed",
                    "result": {"chunks": []},
                }
            }
            mock_client.return_value.queue_get_job_status = AsyncMock(
                return_value=mock_status
            )
            client = ChunkerClient(host="localhost", port=8009)
            result = await client.wait_for_result("job_id")
            assert result is not None

    @pytest.mark.skip(reason="WS-only client: wait_for_result removed")
    @pytest.mark.asyncio
    async def test_wait_for_result_status_string(self):
        """Test wait_for_result with status as string."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_status = {
                "data": {
                    "status": "completed",
                    "result": {"chunks": []},
                }
            }
            mock_client.return_value.queue_get_job_status = AsyncMock(
                return_value=mock_status
            )
            client = ChunkerClient(host="localhost", port=8009)
            result = await client.wait_for_result("job_id")
            assert result is not None

    @pytest.mark.skip(reason="WS-only client: wait_for_result removed")
    @pytest.mark.asyncio
    async def test_wait_for_result_no_status_field(self):
        """Test wait_for_result with no status field."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_status = {
                "data": {
                    "result": {"chunks": []},
                }
            }
            mock_client.return_value.queue_get_job_status = AsyncMock(
                return_value=mock_status
            )
            client = ChunkerClient(host="localhost", port=8009)
            result = await client.wait_for_result("job_id")
            assert result is not None

    @pytest.mark.skip(reason="WS-only client: wait_for_result removed")
    @pytest.mark.asyncio
    async def test_wait_for_result_empty_status_value(self):
        """Test wait_for_result with empty status value."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_status = {
                "data": {
                    "status": "",
                    "result": {"chunks": []},
                }
            }
            mock_client.return_value.queue_get_job_status = AsyncMock(
                return_value=mock_status
            )
            client = ChunkerClient(host="localhost", port=8009)
            result = await client.wait_for_result("job_id")
            assert result is not None

    @pytest.mark.skip(reason="WS-only client: wait_for_result removed")
    @pytest.mark.asyncio
    async def test_wait_for_result_pending_states(self):
        """Test wait_for_result with different pending states."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            pending_states = ["queued", "pending", "running"]
            completed_state = {
                "data": {
                    "status": "completed",
                    "result": {"chunks": []},
                }
            }

            call_count = 0

            async def mock_status(job_id):
                nonlocal call_count
                if call_count < len(pending_states):
                    state = pending_states[call_count]
                    call_count += 1
                    return {"data": {"status": state}}
                return completed_state

            mock_client.return_value.queue_get_job_status = mock_status

            with patch("asyncio.sleep", new_callable=AsyncMock):
                client = ChunkerClient(host="localhost", port=8009)
                result = await client.wait_for_result(
                    "job_id", poll_interval=0.1, timeout=None
                )
                assert result is not None

    @pytest.mark.asyncio
    async def test_chunk_with_verify_integrity_false(self):
        """Test chunk with verify_integrity=False."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_result = {
                "result": {
                    "success": True,
                    "results": [{"success": True, "chunks": [{"text": "Test", "body": "Test", "type": "Draft", "ordinal": 0}]}],
                }
            }
            mock_client.return_value.execute_command_unified = AsyncMock(
                return_value=mock_result
            )
            client = ChunkerClient(host="localhost", port=8009)
            batch = await client.chunk(["test"], verify_integrity=False)
            assert len(batch) > 0 and len(batch[0]) > 0

    @pytest.mark.skip(reason="WS-only client: get_job_status removed")
    @pytest.mark.asyncio
    async def test_get_job_status_exception(self):
        """Test get_job_status with exception."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_client.return_value.queue_get_job_status = AsyncMock(
                side_effect=Exception("Connection error")
            )
            client = ChunkerClient(host="localhost", port=8009)
            with pytest.raises(Exception):
                await client.get_job_status("job_id")

    @pytest.mark.skip(reason="WS-only client: get_job_logs removed")
    @pytest.mark.asyncio
    async def test_get_job_logs_exception(self):
        """Test get_job_logs with exception."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_client.return_value.queue_get_job_logs = AsyncMock(
                side_effect=Exception("Connection error")
            )
            client = ChunkerClient(host="localhost", port=8009)
            with pytest.raises(Exception):
                await client.get_job_logs("job_id")

    @pytest.mark.skip(reason="WS-only client: list_jobs removed")
    @pytest.mark.asyncio
    async def test_list_jobs_exception(self):
        """Test list_jobs with exception."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_client.return_value.queue_list_jobs = AsyncMock(
                side_effect=Exception("Connection error")
            )
            client = ChunkerClient(host="localhost", port=8009)
            with pytest.raises(Exception):
                await client.list_jobs()

    @pytest.mark.skip(reason="WS-only client: list_jobs removed")
    @pytest.mark.asyncio
    async def test_list_jobs_with_status_filter(self):
        """Test list_jobs with status filter."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_client.return_value.queue_list_jobs = AsyncMock(
                return_value=[{"id": "1", "status": "completed"}]
            )
            client = ChunkerClient(host="localhost", port=8009)
            jobs = await client.list_jobs(status="completed")
            assert len(jobs) == 1

    @pytest.mark.skip(reason="WS-only client: list_jobs removed")
    @pytest.mark.asyncio
    async def test_list_jobs_with_limit(self):
        """Test list_jobs with limit."""
        with patch(
            "svo_client.chunker_client.JsonRpcClient"
        ) as mock_client:
            mock_client.return_value.queue_list_jobs = AsyncMock(
                return_value=[{"id": "1"}, {"id": "2"}]
            )
            client = ChunkerClient(host="localhost", port=8009)
            jobs = await client.list_jobs(limit=2)
            assert len(jobs) == 2
