"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

WS-only client for SVO semantic chunker. Single chunking command "chunk"
with params "texts" (list); server returns { success, results }.
"""

# mypy: disable-error-code=import-untyped

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from mcp_proxy_adapter.client.jsonrpc_client import (
    JsonRpcClient,
)  # type: ignore[import-untyped]
from mcp_proxy_adapter.client.jsonrpc_client.transport import (
    JsonRpcTransport,
)  # type: ignore[import-untyped]
from svo_client.config_loader import ConfigLoader
from svo_client.config_utils import config_to_client_kwargs
from svo_client.error_mapper import map_exception
from svo_client.errors import SVOChunkingIntegrityError
from svo_client.result_parser import (
    extract_batch_results_or_raise,
    unwrap_batch_result,
)
from svo_client.text_utils import verify_text_integrity

if TYPE_CHECKING:
    from chunk_metadata_adapter import (  # type: ignore[import-untyped]
        SemanticChunk,
    )


class ChunkerClient:
    """WS-only client; single chunking command over WebSocket."""

    def __init__(
        self,
        *,
        config: Optional[Dict[str, Any]] = None,
        host: str = "localhost",
        port: int = 8009,
        cert: Optional[str] = None,
        key: Optional[str] = None,
        ca: Optional[str] = None,
        token: Optional[str] = None,
        token_header: str = "X-API-Key",
        check_hostname: bool = False,
        timeout: Optional[float] = None,
    ):
        """Initialize ChunkerClient.

        Args:
            config: Optional pre-built config; if set, other args ignored.
            host: Server host.
            port: Server port.
            cert, key, ca: mTLS paths.
            token, token_header: API key auth.
            check_hostname: Verify SSL hostname.
            timeout: Request timeout in seconds; None = no timeout.
        """
        cfg = config or ConfigLoader.resolve_config(
            host=host,
            port=port,
            cert=cert,
            key=key,
            ca=ca,
            token=token,
            token_header=token_header,
            check_hostname=check_hostname,
            timeout=timeout,
        )
        config_timeout = cfg.get("timeout")
        if timeout is None and config_timeout is not None:
            timeout = config_timeout

        protocol, client_kwargs = config_to_client_kwargs(
            cfg, check_hostname=check_hostname
        )
        self.protocol = protocol
        self.host = client_kwargs["host"]
        self.port = client_kwargs["port"]
        self.timeout = timeout

        self._client = JsonRpcClient(**client_kwargs)
        if isinstance(self._client, JsonRpcTransport) and timeout is not None:
            self._client.timeout = timeout

    async def close(self) -> None:
        """Close the underlying client."""
        await self._client.close()

    async def __aenter__(self) -> "ChunkerClient":
        return self

    async def __aexit__(
        self, exc_type: Any, exc_val: Any, exc_tb: Any
    ) -> None:
        await self.close()

    async def chunk(
        self,
        texts: List[str],
        verify_integrity: bool = False,
        **params: Any,
    ) -> List[List["SemanticChunk"]]:
        """Chunk texts via WS command "chunk". One chunk list per text.

        Args:
            texts: List of texts to chunk.
            verify_integrity: If True, verify text reconstructs from chunks.
            **params: type, language, window, etc. (applied to all).

        Returns:
            List of chunk lists (one per input text).
        """
        try:
            unified = await self._client.execute_command_unified(
                "chunk",
                {"texts": texts, **params},
                expect_queue=False,
            )
        except Exception as exc:  # noqa: BLE001
            if isinstance(exc, RuntimeError):
                error_str = str(exc).lower()
                if "integrity" in error_str:
                    error_data = getattr(exc, "data", {}) or {}
                    if (
                        isinstance(error_data, dict)
                        and error_data.get("error") == "ChunkingIntegrityError"
                    ):
                        raise SVOChunkingIntegrityError(
                            message=str(exc),
                            original_text_length=error_data.get(
                                "original_text_length"
                            ),
                            reconstructed_text_length=error_data.get(
                                "reconstructed_text_length"
                            ),
                            chunk_count=error_data.get("chunk_count"),
                            integrity_error=error_data.get("integrity_error"),
                        ) from exc
            raise map_exception(exc, self.timeout or 0.0) from exc

        batch_result = unwrap_batch_result(unified)
        batch = extract_batch_results_or_raise(batch_result)
        if verify_integrity and len(batch) == len(texts):
            for i, chunks in enumerate(batch):
                if i < len(texts):
                    verify_text_integrity(chunks, texts[i])
        return batch

    async def health(self) -> Dict[str, Any]:
        """Health check (JSON-RPC)."""
        try:
            return await self._client.execute_command(
                "health", None, use_cmd_endpoint=False
            )
        except Exception as exc:  # noqa: BLE001
            raise map_exception(exc, self.timeout or 0.0) from exc
