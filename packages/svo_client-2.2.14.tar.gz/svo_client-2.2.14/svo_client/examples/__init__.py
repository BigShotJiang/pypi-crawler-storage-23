"""Examples package for svo_client."""
