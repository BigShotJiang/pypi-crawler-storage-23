To configure this module, you need to:

- go to Settings \> Management System
- in Risk computation group, select the risk computation formula
