This module enables you to manage the risks of your health and safety
management system. This is a sub module of management system hazard.
