# -*- coding: utf-8 -*-
__version__ = '1.0'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()