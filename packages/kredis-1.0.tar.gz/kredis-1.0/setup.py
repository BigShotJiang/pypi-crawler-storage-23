
# 打包上传 python setup.py sdist upload
# 安装 python setup.py install
import os,sys
from kredis import __version__
from setuptools import setup
confkcws={}
confkcws['name']='kredis'
confkcws['version']=__version__
confkcws['description']='kcwcache'
confkcws['long_description']=''
confkcws['license']='MIT License'
confkcws['url']=''
confkcws['author']='百里'
confkcws['author_email']='kwebs@kwebapp.cn'
confkcws['maintainer']='坤坤'
confkcws['maintainer_email']='fk1402936534@qq.com'
def get_file(folder='./',lists=[]):
    lis=os.listdir(folder)
    for files in lis:
        if not os.path.isfile(folder+"/"+files):
            if files=='__pycache__' or files=='.git':
                pass
            else:
                lists.append(folder+"/"+files)
                get_file(folder+"/"+files,lists)
        else:
            pass
    return lists
def start():
    b=get_file("kredis",['kredis'])
    setup(
        name = confkcws["name"],
        version = confkcws["version"],
        keywords = "kredis"+confkcws['version'],
        description = confkcws["description"],
        long_description = confkcws["long_description"],
        license = confkcws["license"],
        author = confkcws["author"],
        author_email = confkcws["author_email"],
        maintainer = confkcws["maintainer"],
        maintainer_email = confkcws["maintainer_email"],
        url=confkcws['url'],
        packages =  b,

        
        install_requires = ['redis==3.3.8'], #第三方包
        package_data = {
            '': ['*.html', '*.js','*.css','*.jpg','*.png','*.gif'],
        }
    )
start()