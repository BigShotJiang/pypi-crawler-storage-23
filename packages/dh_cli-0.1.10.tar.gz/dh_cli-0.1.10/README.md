# dh-cli

Developer CLI for [Dayhoff Labs](https://dayhofflabs.com).

## Installation

```bash
pip install dh-cli
```

## Usage

```bash
dh --help
dh --version
```

## Commands

| Command | Description |
|---------|-------------|
| `dh engine` | Manage compute engines |
| `dh studio` | Manage development studios |
| `dh batch` | Submit and monitor batch jobs |
| `dh aws` | AWS SSO authentication |
| `dh gcp` | GCP authentication |
| `dh gh` | GitHub authentication |
| `dh wget` | Download from data warehouse |
| `dh wheel` | Build and publish packages |
| `dh clean` | Delete local git branches |

## Requirements

- Python >= 3.11
- AWS credentials (for most commands)

## License

[PolyForm Noncommercial 1.0.0](https://polyformproject.org/licenses/noncommercial/1.0.0)
