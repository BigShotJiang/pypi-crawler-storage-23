"""Warehouse read operations for the dh CLI.

Only includes `dh wget` (dvc get from warehouse). Write operations
(wadd, wimport, wancestry) remain in legacy dayhoff-tools.
"""

import os
import subprocess
import sys
from pathlib import Path


def _find_project_root() -> Path | None:
    """Find the project root by searching upwards for .git or pyproject.toml."""
    current_dir = Path.cwd().resolve()
    while current_dir != current_dir.parent:
        if (current_dir / ".git").is_dir() or (
            current_dir / "pyproject.toml"
        ).is_file():
            return current_dir
        current_dir = current_dir.parent
    if (current_dir / ".git").is_dir() or (current_dir / "pyproject.toml").is_file():
        return current_dir
    return None


def _warn_if_gcp_default_sa(force_prompt: bool = False) -> None:
    """Warn the user when the active gcloud principal is the default VM SA."""
    from dh_cli import cloud_commands as _cc

    try:
        impersonation = _cc._get_current_gcp_impersonation()
        user = _cc._get_current_gcp_user()
        active = impersonation if impersonation != "None" else user
        short = _cc._get_short_name(active)
        auth_valid = _cc._is_gcp_user_authenticated()
    except Exception:
        return

    problem_type = None
    if short == "default VM service account":
        problem_type = "default_sa"
    elif not auth_valid:
        problem_type = "stale"

    if problem_type is None:
        return

    YELLOW = getattr(_cc, "YELLOW", "\033[0;33m")
    BLUE = getattr(_cc, "BLUE", "\033[0;36m")
    RED = getattr(_cc, "RED", "\033[0;31m")
    NC = getattr(_cc, "NC", "\033[0m")

    if problem_type == "default_sa":
        msg_body = (
            "You are currently authenticated as the *default VM service account*.\n"
            "   This will block gsutil/DVC access to private buckets (e.g. warehouse)."
        )
    else:
        msg_body = (
            "Your GCP credentials appear to be *expired/stale*.\n"
            "   Re-authenticate to refresh the access token."
        )

    print(
        f"{YELLOW}⚠  {msg_body}{NC}\n"
        f"{YELLOW}   Run {BLUE}dh gcp login{YELLOW} or {BLUE}dh gcp use-devcon{YELLOW} before retrying.{NC}",
        file=sys.stderr,
    )

    if force_prompt and sys.stdin.isatty() and sys.stdout.isatty():
        import questionary

        if not questionary.confirm("Proceed anyway?", default=False).ask():
            print(f"{RED}Aborted due to unsafe GCP credentials.{NC}", file=sys.stderr)
            raise SystemExit(1)


def get_from_warehouse(
    warehouse_path: str,
    output_folder: str = "same_as_warehouse",
    branch: str = "main",
    logger=None,
) -> str:
    """`dvc get` a file from warehouse.

    Args:
        warehouse_path: Relative path to a .dvc file in the warehouse submodule.
        output_folder: Destination folder. Defaults to the same as warehouse.
        branch: The branch of warehouse to get from.

    Returns:
        The path to the downloaded file.
    """
    assert warehouse_path.startswith(
        "warehouse"
    ), "expected the relative path to start with 'warehouse'"
    assert warehouse_path.endswith(
        ".dvc"
    ), "expected the relative path to end with '.dvc'"

    if branch != "main":
        msg = "WARNING: You should usually import data from main.\n"
        if logger:
            logger.warning(msg)
        else:
            print(msg)

    if output_folder.endswith("/"):
        output_folder = output_folder[:-1]

    core_path = warehouse_path[len("warehouse/") : -len(".dvc")]
    filename = core_path.split("/")[-1]

    command = [
        "dvc",
        "get",
        "https://github.com/dayhofflabs/warehouse",
        core_path,
    ]

    if output_folder == "same_as_warehouse":
        final_path = core_path
        final_folder = "/".join(final_path.split("/")[:-1])
    else:
        final_folder = output_folder
        final_path = final_folder + "/" + filename

    os.makedirs(final_folder, exist_ok=True)
    command += ["--out", final_path, "--rev", branch]

    if os.path.exists(final_path):
        msg = "File already exists. Will exit without changing."
        if logger:
            logger.info(msg)
        else:
            print(msg)
    else:
        msg = f"Getting from warehouse: {final_path}"
        if logger:
            logger.info(msg)
        else:
            print(msg)
        subprocess.run(command, check=True)

    return final_path


def get_from_warehouse_typer() -> None:
    """Get a file from warehouse using `dvc get`.

    Emits an early warning if the active GCP credentials are the default VM
    service account.
    """
    _warn_if_gcp_default_sa(force_prompt=True)

    import questionary

    project_root = _find_project_root()
    cwd = Path.cwd()
    if not project_root or project_root != cwd:
        error_msg = (
            "This command must be run from the project's root directory, which is"
            " expected to contain a `.git` folder or a `pyproject.toml` file.\n"
            f"Current directory: {cwd}"
        )
        if project_root:
            error_msg += f"\nDetected project root: {project_root}"
        raise Exception(error_msg)

    warehouse_path = questionary.text("Warehouse path:").ask()

    output_folder_choice = questionary.select(
        "Output folder:",
        choices=["data/imports", "same_as_warehouse", "Custom path..."],
    ).ask()

    if output_folder_choice == "Custom path...":
        output_folder = questionary.text("Enter custom output folder:").ask()
    else:
        output_folder = output_folder_choice

    branch = questionary.text("Branch (default: main):", default="main").ask()

    get_from_warehouse(
        warehouse_path=warehouse_path,
        output_folder=output_folder,
        branch=branch,
    )
