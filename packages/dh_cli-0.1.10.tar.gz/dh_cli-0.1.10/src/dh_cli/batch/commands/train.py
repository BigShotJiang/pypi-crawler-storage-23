"""ML training pipeline command.

Submits hatchery training jobs to AWS Batch using pre-built container images.
One command, one config file — replaces the legacy ``dh deploy batch`` workflow.
"""

import os
import shutil
import subprocess
from copy import deepcopy
from pathlib import Path

import click
import yaml

from ..aws_batch import BatchClient
from ..job_id import generate_job_id
from ..manifest import (
    BATCH_JOBS_BASE,
    BatchConfig,
    InputConfig,
    JobManifest,
    JobStatus,
    OutputConfig,
    create_job_directory,
    save_manifest,
)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_QUEUE = "t4-1x"
DEFAULT_VCPUS = 8
DEFAULT_MEMORY_MB = 32768  # 32 GiB
DEFAULT_GPUS = 1
DEFAULT_TIMEOUT_SECONDS = 604800  # 7 days
DEFAULT_SHM_MB = 16384  # 16 GiB
DEFAULT_JOB_DEFINITION = "dayhoff-train"
DEFAULT_IMAGE_URI = (
    "074735440724.dkr.ecr.us-east-1.amazonaws.com/dayhoff:train-latest"
)


def _parse_timeout(value: str) -> int:
    """Convert a human-friendly timeout string to seconds.

    Accepts forms like ``7d``, ``12h``, ``3600``, ``1d12h``.
    """
    if value.isdigit():
        return int(value)

    total = 0
    current_num = ""
    for ch in value:
        if ch.isdigit():
            current_num += ch
        elif ch == "d":
            total += int(current_num) * 86400
            current_num = ""
        elif ch == "h":
            total += int(current_num) * 3600
            current_num = ""
        elif ch == "m":
            total += int(current_num) * 60
            current_num = ""
        elif ch == "s":
            total += int(current_num)
            current_num = ""
        else:
            raise click.BadParameter(f"Unrecognised timeout character: {ch!r}")

    if current_num:
        total += int(current_num)

    return total


def _parse_memory(value: str) -> int:
    """Convert a memory string like ``32G`` or ``16384`` to MiB."""
    v = value.strip().upper()
    if v.endswith("G"):
        return int(v[:-1]) * 1024
    if v.endswith("M"):
        return int(v[:-1])
    return int(v)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _load_training_config(path: str) -> dict:
    """Load and return a raw training config YAML as a dict."""
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _deep_get(d: dict, dotted_key: str, default=None):
    """Get a value from a nested dict using dot-separated keys."""
    keys = dotted_key.split(".")
    for k in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(k, default)
        if d is default:
            return default
    return d


def _deep_set(d: dict, dotted_key: str, value):
    """Set a value in a nested dict using dot-separated keys."""
    keys = dotted_key.split(".")
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    d[keys[-1]] = value


def _apply_overrides(config: dict, overrides: tuple[str, ...]) -> dict:
    """Apply --override key=value pairs to config."""
    for override in overrides:
        if "=" not in override:
            raise click.BadParameter(
                f"Override must be key=value, got: {override}"
            )
        key, value = override.split("=", 1)
        # Try to coerce types
        if value.lower() == "true":
            value = True
        elif value.lower() == "false":
            value = False
        else:
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass  # keep as string
        _deep_set(config, key, value)
    return config


def _resolve_pond_paths(config: dict) -> dict:
    """Resolve any ``pond://`` paths to ``s3://`` URLs.

    Uses ``dvc.api.get_url()`` on the CLI side so the training container
    never needs DVC.
    """
    def _walk(d: dict) -> dict:
        for key, value in d.items():
            if isinstance(value, dict):
                _walk(value)
            elif isinstance(value, str) and value.startswith("pond://"):
                d[key] = _resolve_one_pond_path(value)
        return d

    return _walk(config)


def _resolve_one_pond_path(pond_uri: str) -> str:
    """Resolve a single ``pond://dataset/path`` to an ``s3://`` URL."""
    # pond://horizyn/v1_1/final/file.db → data/horizyn/v1_1/final/file.db
    rel_path = "data/" + pond_uri[len("pond://"):]
    click.echo(f"  Resolving {pond_uri} ...")
    try:
        import dvc.api

        s3_url = dvc.api.get_url(
            path=rel_path,
            repo="https://github.com/dayhofflabs/pond",
        )
        click.echo(f"  → {s3_url}")
        return s3_url
    except Exception as e:
        raise click.ClickException(
            f"Failed to resolve pond path {pond_uri}: {e}\n"
            "Ensure DVC and GitHub auth are available in this environment."
        )


def _build_job_name(config: dict) -> str:
    """Derive a human-friendly AWS Batch job name from the config."""
    run_name = _deep_get(config, "init.wandb.run_name", "")
    if run_name:
        # Sanitise for Batch (alphanumeric, hyphens, underscores only)
        safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in run_name)
        return safe[:50]
    return "train"


# ---------------------------------------------------------------------------
# Click command
# ---------------------------------------------------------------------------

@click.command()
@click.argument("config_yaml", type=click.Path(exists=True))
@click.option(
    "--queue",
    default=DEFAULT_QUEUE,
    help=f"AWS Batch queue [default: {DEFAULT_QUEUE}]",
)
@click.option(
    "--vcpus",
    default=DEFAULT_VCPUS,
    type=int,
    help=f"vCPU override [default: {DEFAULT_VCPUS}]",
)
@click.option(
    "--memory",
    default="32G",
    help="Memory override [default: 32G]",
)
@click.option(
    "--gpus",
    default=DEFAULT_GPUS,
    type=int,
    help=f"GPU count [default: {DEFAULT_GPUS}]",
)
@click.option(
    "--timeout",
    default="7d",
    help="Job timeout [default: 7d]",
)
@click.option(
    "--shm",
    default="16g",
    help="Shared memory size [default: 16g]",
)
@click.option(
    "--override",
    "overrides",
    multiple=True,
    help="Config overrides (e.g. --override training.trainer_kwargs.max_epochs=5)",
)
@click.option(
    "--wandb-mode",
    default=None,
    type=click.Choice(["online", "offline", "disabled"]),
    help="Override wandb mode",
)
@click.option(
    "--local",
    "run_local",
    is_flag=True,
    help="Run in local container instead of Batch",
)
@click.option(
    "--shell",
    "run_shell",
    is_flag=True,
    help="Open shell in local container for debugging",
)
@click.option("--dry-run", is_flag=True, help="Show submission plan without submitting")
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Job directory base")
@click.option(
    "--image",
    default=None,
    help=f"Docker image URI [default: {DEFAULT_IMAGE_URI}]",
)
def train(
    config_yaml,
    queue,
    vcpus,
    memory,
    gpus,
    timeout,
    shm,
    overrides,
    wandb_mode,
    run_local,
    run_shell,
    dry_run,
    base_path,
    image,
):
    """Submit an ML training job to AWS Batch.

    Reads a hatchery training config YAML, resolves data paths, and submits
    a single training job to AWS Batch using a pre-built container image.

    \b
    Examples:
      # Submit a training job
      dh batch train configs/horizyn/nano_config.yaml --queue t4-1x

      # Submit with overrides
      dh batch train config.yaml --override training.trainer_kwargs.max_epochs=5

      # Dry run to see what would be submitted
      dh batch train config.yaml --dry-run

      # Run locally in Docker
      dh batch train config.yaml --local

    \b
    After job completes:
      dh batch status <job-id>    # Check status
      dh batch logs <job-id>      # View logs
    """
    config_path = Path(config_yaml).resolve()
    image_uri = image or DEFAULT_IMAGE_URI

    if run_shell:
        _run_shell_mode(config_path, image_uri)
        return

    if run_local:
        _run_local_mode(config_path, image_uri)
        return

    _submit_batch_job(
        config_path=config_path,
        queue=queue,
        vcpus=vcpus,
        memory=memory,
        gpus=gpus,
        timeout=timeout,
        shm=shm,
        overrides=overrides,
        wandb_mode=wandb_mode,
        dry_run=dry_run,
        base_path=base_path,
    )


# ---------------------------------------------------------------------------
# Batch submission
# ---------------------------------------------------------------------------

def _submit_batch_job(
    config_path: Path,
    queue: str,
    vcpus: int,
    memory: str,
    gpus: int,
    timeout: str,
    shm: str,
    overrides: tuple[str, ...],
    wandb_mode: str | None,
    dry_run: bool,
    base_path: str,
):
    """Submit a training job to AWS Batch."""
    # Load and modify config
    raw_config = _load_training_config(str(config_path))

    # Build a working copy
    config = deepcopy(raw_config)

    # Apply CLI overrides
    if overrides:
        config = _apply_overrides(config, overrides)

    # Resolve pond:// paths to s3:// on CLI side
    config = _resolve_pond_paths(config)

    # Read init section for submission decisions
    use_wandb = _deep_get(config, "init.wandb.use_wandb", False)
    wandb_config_mode = _deep_get(config, "init.wandb.mode", "disabled")
    wandb_project = _deep_get(config, "init.wandb.project", "")
    wandb_entity = _deep_get(config, "init.wandb.entity", "")
    wandb_run_name = _deep_get(config, "init.wandb.run_name", "")
    wandb_tags = _deep_get(config, "init.wandb.tags", [])
    wandb_notes = _deep_get(config, "init.wandb.notes", "")
    fail_without_gpu = _deep_get(config, "init.fail_without_gpu", False)

    # Override wandb mode if requested via CLI
    effective_wandb_mode = wandb_mode or wandb_config_mode
    if use_wandb:
        _deep_set(config, "init.wandb.mode", effective_wandb_mode)

    # Generate job ID
    job_id = generate_job_id("train")

    # Compute resource values
    timeout_seconds = _parse_timeout(timeout)
    memory_mb = _parse_memory(memory)
    shm_mb = _parse_memory(shm)

    # Validate GPU/queue sanity
    if fail_without_gpu and "cpu" in queue.lower():
        click.echo(
            click.style(
                "Warning: config has fail_without_gpu=True but queue looks CPU-only",
                fg="yellow",
            )
        )

    # Show plan
    click.echo()
    click.echo(f"Job ID:           {job_id}")
    click.echo(f"Config:           {config_path}")
    click.echo(f"Queue:            {queue}")
    click.echo(f"Resources:        {vcpus} vCPUs, {memory_mb} MiB RAM, {gpus} GPU(s)")
    click.echo(f"Shared memory:    {shm_mb} MiB")
    click.echo(f"Timeout:          {timeout_seconds}s ({timeout})")
    click.echo(f"Job definition:   {DEFAULT_JOB_DEFINITION}")
    if use_wandb:
        click.echo(f"WandB:            {effective_wandb_mode} ({wandb_project})")
    if overrides:
        click.echo(f"Overrides:        {', '.join(overrides)}")

    if dry_run:
        click.echo()
        click.echo(click.style("Dry run — job not submitted", fg="yellow"))
        return

    click.echo()

    # Create job directory and write modified config
    job_dir = create_job_directory(job_id, base_path)
    input_dir = job_dir / "input"
    output_dir = job_dir / "output"

    # Override checkpoint and log dirs to point to job output
    _deep_set(config, "init.checkpoint_dir", str(output_dir / "checkpoints"))
    _deep_set(config, "init.log_dir", str(output_dir / "logs"))

    # Also update checkpoint_kwargs.checkpoint_dir if present
    if _deep_get(config, "training.checkpoint_kwargs.checkpoint_dir") is not None:
        _deep_set(
            config,
            "training.checkpoint_kwargs.checkpoint_dir",
            str(output_dir / "checkpoints"),
        )

    # Write the modified config
    config_dest = input_dir / "config.yaml"
    with open(config_dest, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    click.echo(f"Created job directory: {job_dir}")
    click.echo(f"Config written to:     {config_dest}")

    # Build environment variables for the container
    environment = {
        "JOB_DIR": str(job_dir),
        "JOB_ID": job_id,
    }

    if use_wandb:
        # Pass wandb API key from local environment
        wandb_key = os.environ.get("WANDB_API_KEY", "")
        if effective_wandb_mode == "online" and not wandb_key:
            click.echo(
                click.style(
                    "Warning: wandb mode is 'online' but WANDB_API_KEY is not set. "
                    "Set it or use --wandb-mode=offline",
                    fg="yellow",
                )
            )
        if wandb_key:
            environment["WANDB_API_KEY"] = wandb_key
        environment["WANDB_MODE"] = effective_wandb_mode
        if wandb_project:
            environment["WANDB_PROJECT"] = wandb_project
        if wandb_entity:
            environment["WANDB_ENTITY"] = wandb_entity
        if wandb_run_name:
            environment["WANDB_RUN_NAME"] = wandb_run_name
        if wandb_tags:
            if isinstance(wandb_tags, list):
                environment["WANDB_TAGS"] = ",".join(str(t) for t in wandb_tags)
            else:
                environment["WANDB_TAGS"] = str(wandb_tags)
        if wandb_notes:
            environment["WANDB_NOTES"] = str(wandb_notes)

    # Create manifest
    manifest = JobManifest(
        job_id=job_id,
        user=job_id.split("-")[0],
        pipeline="train",
        status=JobStatus.PENDING,
        image_uri=DEFAULT_IMAGE_URI,
        input=InputConfig(
            source=str(config_path),
        ),
        batch=BatchConfig(
            queue=queue,
            job_definition=DEFAULT_JOB_DEFINITION,
        ),
        output=OutputConfig(
            destination=str(output_dir),
            finalized=False,
        ),
    )

    save_manifest(manifest, base_path)

    # Submit to AWS Batch
    try:
        client = BatchClient()

        # Build container overrides for resource requirements
        container_overrides: dict = {
            "environment": [
                {"name": k, "value": v} for k, v in environment.items()
            ],
            "resourceRequirements": [
                {"type": "VCPU", "value": str(vcpus)},
                {"type": "MEMORY", "value": str(memory_mb)},
                {"type": "GPU", "value": str(gpus)},
            ],
        }

        # Build the submit_job kwargs directly for more control
        submit_args = {
            "jobName": job_id,
            "jobDefinition": DEFAULT_JOB_DEFINITION,
            "jobQueue": queue,
            "containerOverrides": container_overrides,
            "retryStrategy": {"attempts": 3},
            "timeout": {"attemptDurationSeconds": timeout_seconds},
        }

        response = client.batch.submit_job(**submit_args)
        batch_job_id = response["jobId"]

        # Update manifest
        manifest.status = JobStatus.SUBMITTED
        manifest.batch.job_id = batch_job_id
        save_manifest(manifest, base_path)

        click.echo()
        click.echo(click.style("✓ Job submitted successfully!", fg="green"))
        click.echo()
        click.echo(f"AWS Batch Job ID: {batch_job_id}")
        click.echo()
        click.echo("Next steps:")
        click.echo(f"  Check status:  dh batch status {job_id}")
        click.echo(f"  View logs:     dh batch logs {job_id}")
        click.echo(f"  Cancel:        dh batch cancel {job_id}")
        click.echo()
        click.echo("Outputs will appear at:")
        click.echo(f"  Checkpoints:   {output_dir}/checkpoints/")
        click.echo(f"  Logs:          {output_dir}/logs/")

    except Exception as exc:
        manifest.status = JobStatus.FAILED
        manifest.error_message = str(exc)
        save_manifest(manifest, base_path)
        click.echo(
            click.style(f"✗ Failed to submit job: {exc}", fg="red"), err=True
        )
        raise SystemExit(1) from exc


# ---------------------------------------------------------------------------
# Local modes
# ---------------------------------------------------------------------------

def _get_aws_credential_env() -> list[str]:
    """Resolve current AWS credentials and return Docker -e flags.

    Uses boto3 to resolve credentials from any source (env vars, SSO
    cache, profiles, instance metadata).  Returns a list like
    ``["-e", "AWS_ACCESS_KEY_ID=...", "-e", "AWS_SECRET_ACCESS_KEY=...", ...]``
    suitable for splicing into a ``docker run`` command.
    """
    try:
        import boto3

        session = boto3.Session()
        creds = session.get_credentials()
        if creds is None:
            return []
        frozen = creds.get_frozen_credentials()
        flags: list[str] = [
            "-e", f"AWS_ACCESS_KEY_ID={frozen.access_key}",
            "-e", f"AWS_SECRET_ACCESS_KEY={frozen.secret_key}",
        ]
        if frozen.token:
            flags.extend(["-e", f"AWS_SESSION_TOKEN={frozen.token}"])
        region = session.region_name or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        flags.extend(["-e", f"AWS_DEFAULT_REGION={region}"])
        return flags
    except Exception:
        return []


def _stage_config_to_primordial(config_path: Path) -> str:
    """Stage a modified config to Primordial for local Docker runs.

    In Docker-from-Docker setups (dev containers using the host Docker
    socket), bind-mounting workspace paths fails because the Docker daemon
    sees the host filesystem, not the container's.  Primordial (EFS) is
    mounted on both, so we stage files there.

    The config is modified so that checkpoints and logs write to Primordial
    instead of the container's ephemeral overlay filesystem.

    Returns:
        The container-visible path to the staged config.
    """
    staging_dir = Path("/primordial/.tmp/local-train")
    output_dir = staging_dir / "output"
    (output_dir / "checkpoints").mkdir(parents=True, exist_ok=True)
    (output_dir / "logs").mkdir(parents=True, exist_ok=True)

    # Load, modify, and write — same overrides as _submit_batch_job
    config = _load_training_config(str(config_path))
    _deep_set(config, "init.checkpoint_dir", str(output_dir / "checkpoints"))
    _deep_set(config, "init.log_dir", str(output_dir / "logs"))
    if _deep_get(config, "training.checkpoint_kwargs.checkpoint_dir") is not None:
        _deep_set(
            config,
            "training.checkpoint_kwargs.checkpoint_dir",
            str(output_dir / "checkpoints"),
        )

    dest = staging_dir / config_path.name
    with open(dest, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    click.echo(f"Outputs:     {output_dir}")
    # The container mounts /primordial:/primordial, so the path is the same.
    return str(dest)


def _run_local_mode(config_path: Path, image_uri: str):
    """Run training locally in a Docker container."""
    click.echo("Running training locally in container...")
    click.echo(f"Config: {config_path}")
    click.echo(f"Image:  {image_uri}")

    container_config = _stage_config_to_primordial(config_path)
    aws_flags = _get_aws_credential_env()
    if not aws_flags:
        click.echo(
            click.style(
                "Warning: Could not resolve AWS credentials. "
                "S3 downloads will fail. Run awslogin first.",
                fg="yellow",
            )
        )

    cmd = [
        "docker",
        "run",
        "--rm",
        "--gpus",
        "all",
        "-v",
        "/primordial:/primordial",
        "-e",
        "JOB_DIR=/tmp/local-train",
        "-e",
        "JOB_ID=local",
        *aws_flags,
        "--shm-size=16g",
        "--entrypoint",
        "",
        image_uri,
        "pixi",
        "run",
        "--frozen",
        "--environment",
        "default",
        "python",
        "main.py",
        f"--config={container_config}",
    ]

    click.echo(f"Running: {' '.join(cmd)}")
    click.echo()

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            click.echo(
                click.style(
                    f"Container exited with code {result.returncode}", fg="red"
                ),
                err=True,
            )
            raise SystemExit(result.returncode)
        click.echo()
        click.echo(click.style("✓ Training complete!", fg="green"))
    except FileNotFoundError as exc:
        click.echo(
            click.style(
                "Error: Docker not found. Is Docker installed and running?",
                fg="red",
            ),
            err=True,
        )
        raise SystemExit(1) from exc


def _run_shell_mode(config_path: Path, image_uri: str):
    """Drop into container shell for debugging."""
    container_config = _stage_config_to_primordial(config_path)
    aws_flags = _get_aws_credential_env()

    click.echo("Dropping into training container shell...")
    click.echo(f"Config available at: {container_config}")
    click.echo(f"Image:  {image_uri}")
    click.echo()

    cmd = [
        "docker",
        "run",
        "--rm",
        "-it",
        "--gpus",
        "all",
        "-v",
        "/primordial:/primordial",
        "-e",
        "JOB_DIR=/tmp/local-train",
        "-e",
        "JOB_ID=local",
        *aws_flags,
        "--shm-size=16g",
        "--entrypoint",
        "/bin/bash",
        image_uri,
    ]

    click.echo(f"Running: {' '.join(cmd)}")
    click.echo()

    try:
        subprocess.run(cmd, check=False)
    except FileNotFoundError as exc:
        click.echo(
            click.style(
                "Error: Docker not found. Is Docker installed and running?",
                fg="red",
            ),
            err=True,
        )
        raise SystemExit(1) from exc
