"""S3 transport utilities for batch jobs.

Provides upload/download functions for using S3 as a staging layer
between the CLI (local machine) and batch workers (Primordial).
"""

import logging
import tempfile
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

S3_BUCKET = "dayhoff-atlas"
S3_BATCH_PREFIX = "ephemeral/batch-jobs"


def s3_job_prefix(job_id: str) -> str:
    """Return the S3 prefix for a job.

    Returns:
        s3://dayhoff-atlas/ephemeral/batch-jobs/{job_id}/
    """
    return f"s3://{S3_BUCKET}/{S3_BATCH_PREFIX}/{job_id}/"


def parse_s3_uri(uri: str) -> tuple[str, str]:
    """Parse an S3 URI into bucket and key.

    Args:
        uri: S3 URI like s3://bucket/key

    Returns:
        Tuple of (bucket, key)

    Raises:
        ValueError: If URI is not a valid S3 URI
    """
    if not uri.startswith("s3://"):
        raise ValueError(f"Not a valid S3 URI: {uri}")
    without_scheme = uri[5:]
    bucket, _, key = without_scheme.partition("/")
    if not bucket:
        raise ValueError(f"No bucket in S3 URI: {uri}")
    return bucket, key


def _get_client():
    """Get a boto3 S3 client."""
    return boto3.client("s3")


def upload_file(local_path: Path, s3_uri: str) -> None:
    """Upload a local file to S3.

    Args:
        local_path: Path to local file
        s3_uri: Destination S3 URI
    """
    bucket, key = parse_s3_uri(s3_uri)
    client = _get_client()
    logger.info(f"Uploading {local_path} -> {s3_uri}")
    client.upload_file(str(local_path), bucket, key)


def upload_directory(local_dir: Path, s3_prefix: str, glob: str = "*") -> None:
    """Upload all matching files from a local directory to S3.

    Args:
        local_dir: Local directory to upload from
        s3_prefix: S3 URI prefix (e.g. s3://bucket/prefix/)
        glob: Glob pattern for files to upload (default: all files)
    """
    bucket, prefix_key = parse_s3_uri(s3_prefix)
    client = _get_client()

    files = sorted(local_dir.glob(glob))
    for f in files:
        if not f.is_file():
            continue
        key = prefix_key + f.name
        logger.info(f"Uploading {f} -> s3://{bucket}/{key}")
        client.upload_file(str(f), bucket, key)

    logger.info(f"Uploaded {len(files)} files to {s3_prefix}")


def download_file(s3_uri: str, local_path: Path) -> None:
    """Download a file from S3.

    Args:
        s3_uri: Source S3 URI
        local_path: Local destination path
    """
    bucket, key = parse_s3_uri(s3_uri)
    client = _get_client()
    local_path.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"Downloading {s3_uri} -> {local_path}")
    client.download_file(bucket, key, str(local_path))


def download_directory(s3_prefix: str, local_dir: Path) -> None:
    """Download all objects under an S3 prefix to a local directory.

    Args:
        s3_prefix: S3 URI prefix (e.g. s3://bucket/prefix/)
        local_dir: Local directory to download into
    """
    bucket, prefix_key = parse_s3_uri(s3_prefix)
    client = _get_client()
    local_dir.mkdir(parents=True, exist_ok=True)

    paginator = client.get_paginator("list_objects_v2")
    count = 0
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix_key):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            # Get relative path from prefix
            relative = key[len(prefix_key) :]
            if not relative:
                continue
            local_path = local_dir / relative
            local_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"Downloading s3://{bucket}/{key} -> {local_path}")
            client.download_file(bucket, key, str(local_path))
            count += 1

    logger.info(f"Downloaded {count} files from {s3_prefix}")


def s3_exists(s3_uri: str) -> bool:
    """Check if an S3 object exists.

    Args:
        s3_uri: S3 URI to check

    Returns:
        True if the object exists
    """
    bucket, key = parse_s3_uri(s3_uri)
    client = _get_client()
    try:
        client.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError:
        return False


def delete_prefix(s3_prefix: str) -> None:
    """Delete all objects under an S3 prefix.

    Args:
        s3_prefix: S3 URI prefix to delete
    """
    bucket, prefix_key = parse_s3_uri(s3_prefix)
    client = _get_client()

    paginator = client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix_key):
        objects = page.get("Contents", [])
        if not objects:
            continue
        delete_keys = [{"Key": obj["Key"]} for obj in objects]
        client.delete_objects(Bucket=bucket, Delete={"Objects": delete_keys})
        logger.info(f"Deleted {len(delete_keys)} objects from {s3_prefix}")
