"""Entry file for the dh CLI, which aggregates and aliases all commands."""

from importlib.metadata import PackageNotFoundError, version

import typer
from dh_cli.cloud_commands import aws_app, gcp_app
from dh_cli.github_commands import gh_app
from dh_cli.utility_commands import (
    build_and_upload_wheel,
    delete_local_branch,
)
from dh_cli.warehouse import get_from_warehouse_typer


def _get_version() -> str:
    try:
        return version("dh-cli")
    except PackageNotFoundError:
        return "unknown"


app = typer.Typer(
    help=f"Dayhoff Labs CLI (dh) v{_get_version()}\n\nUse 'dh --version' to print version and exit.",
    context_settings={"help_option_names": ["-h", "--help"]},
)

# Utility commands
app.command("clean")(delete_local_branch)
app.command("wget")(get_from_warehouse_typer)

# Cloud commands
app.add_typer(gcp_app, name="gcp", help="Manage GCP authentication and impersonation.")
app.add_typer(aws_app, name="aws", help="Manage AWS SSO authentication.")
app.add_typer(gh_app, name="gh", help="Manage GitHub authentication.")


# Engine and Studio commands (v2 - Click-based, passthrough wrapper)
@app.command(
    "engine",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
    add_help_option=False,
)
def engine_cmd(ctx: typer.Context):
    """Manage compute engines for development."""
    from dh_cli.engines_studios import engine_cli

    engine_cli(ctx.args, standalone_mode=False)


@app.command(
    "studio",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
    add_help_option=False,
)
def studio_cmd(ctx: typer.Context):
    """Manage persistent development studios."""
    from dh_cli.engines_studios import studio_cli

    studio_cli(ctx.args, standalone_mode=False)


# Batch job management (Click-based CLI)
@app.command(
    "batch",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
    add_help_option=False,
)
def batch_cmd(ctx: typer.Context):
    """Manage batch jobs on AWS Batch."""
    from dh_cli.batch import batch_cli

    batch_cli(ctx.args, standalone_mode=False)


@app.callback(invoke_without_command=True)
def _version_option(
    ctx: typer.Context,
    version_flag: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Print version and exit.",
        is_eager=True,
    ),
):
    """Global options for the dh CLI (e.g., version)."""
    if version_flag:
        typer.echo(_get_version())
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command("wheel")
def wheel_command(
    target: str = typer.Argument(
        help="What to publish: 'cli', 'batch', 'embedders', 'chem', or 'legacy' (PyPI).",
    ),
    bump: str = typer.Option(
        "patch",
        "--bump",
        "-b",
        help="Version part to bump: 'major', 'minor', or 'patch'.",
        case_sensitive=False,
    ),
    profile: str = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile for CodeArtifact auth.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Build only, skip upload.",
    ),
    no_pypi: bool = typer.Option(
        False,
        "--no-pypi",
        help="Skip PyPI publish (CodeArtifact only).",
    ),
):
    """Build wheel, bump version, and publish.

    \b
    Targets:
      cli        Build and publish dh-cli to CodeArtifact + PyPI
      batch      Build and publish dh-batch to CodeArtifact
      embedders  Build and publish dh-embedders to CodeArtifact
      chem       Build and publish dh-chem to CodeArtifact
      legacy     Build and publish dayhoff-tools to PyPI (default)
    """
    from dh_cli.codeartifact import PACKAGE_DIRS

    if target in PACKAGE_DIRS:
        from dh_cli.codeartifact import publish_to_codeartifact

        publish_to_codeartifact(
            target=target,
            bump_part=bump,
            profile=profile,
            dry_run=dry_run,
            skip_pypi=no_pypi,
        )
    elif target == "legacy":
        build_and_upload_wheel(bump_part=bump)
    else:
        typer.echo(
            f"Unknown target '{target}'. Use 'cli', 'batch', 'embedders', 'chem', or 'legacy'."
        )
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
