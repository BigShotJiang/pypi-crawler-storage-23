import asyncio
import argparse
import json
from .core import generate_links
from .utils import slugify

def main():
    parser = argparse.ArgumentParser(description="Async Movie / TV metadata fetcher")
    parser.add_argument("title", help="Movie or TV show name")
    parser.add_argument("--media", choices=["movie", "tv"], default="movie")
    parser.add_argument("--json", action="store_true", help="Save output as JSON")

    args = parser.parse_args()

    result = asyncio.run(generate_links(args.title, args.media))
    print(json.dumps(result, indent=4, ensure_ascii=False))

    if args.json:
        filename = f"{slugify(args.title)}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=4, ensure_ascii=False)
        print(f"\nSaved → {filename}")

if __name__ == "__main__":
    main()