import asyncio
import aiohttp
from decouple import config
from .utils import slugify, fetch_json, head_exists

TMDB_API_KEY = config("TMDB_API_KEY")
TMDB_BASE_URL = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/w500"

CACHE = {}

async def fetch_tmdb_data(title: str, media: str, session):
    search_url = f"{TMDB_BASE_URL}/search/{media}"
    search = await fetch_json(
        session,
        search_url,
        {"api_key": TMDB_API_KEY, "query": title}
    )

    if not search.get("results"):
        return None

    item = search["results"][0]
    tmdb_id = item["id"]

    details_url = f"{TMDB_BASE_URL}/{media}/{tmdb_id}"
    credits_url = f"{details_url}/credits"

    details, credits = await asyncio.gather(
        fetch_json(session, details_url, {"api_key": TMDB_API_KEY}),
        fetch_json(session, credits_url, {"api_key": TMDB_API_KEY})
    )

    official_title = details.get("title") or details.get("name")
    release_date = details.get("release_date") or details.get("first_air_date")
    release_year = release_date[:4] if release_date else None
    runtime = details.get("runtime")
    if not runtime:
        ep = details.get("episode_run_time")
        runtime = ep[0] if ep else None

    poster = details.get("poster_path")
    poster_url = f"{IMAGE_BASE}{poster}" if poster else None
    genres = [g["name"] for g in details.get("genres", [])]
    cast = [c["name"] for c in credits.get("cast", [])[:5]]
    imdb_id = details.get("imdb_id")
    imdb_link = f"https://www.imdb.com/title/{imdb_id}/" if imdb_id else None

    return {
        "Official Title": official_title,
        "Release Year": release_year,
        "Genres": genres,
        "Runtime (mins)": runtime,
        "TMDB Rating": f'{details.get("vote_average")} ({details.get("vote_count")} votes)',
        "Poster URL": poster_url,
        "Top Cast": cast,
        "TMDB Link": f"https://www.themoviedb.org/{media}/{tmdb_id}",
        "IMDb Link": imdb_link,
        "slug": slugify(official_title)
    }

async def generate_links(title: str, media: str):
    cache_key = f"{title}_{media}"
    if cache_key in CACHE:
        return CACHE[cache_key]

    async with aiohttp.ClientSession() as session:
        data = await fetch_tmdb_data(title, media, session)
        if not data:
            return {"Error": "Movie / TV show not found"}

        rt_type = "m" if media == "movie" else "tv"
        rt_url = f"https://www.rottentomatoes.com/{rt_type}/{data['slug']}"
        rt_final = rt_url if await head_exists(session, rt_url) else "RT page not found"

        result = {
            **{k: v for k, v in data.items() if k != "slug"},
            "Rotten Tomatoes": rt_final,
            "Metacritic": f"https://www.metacritic.com/search/{media}/{data['slug']}/results",
            "Letterboxd": f"https://letterboxd.com/film/{data['slug']}/" if media == "movie" else None,
            "JustWatch (PK)": f"https://www.justwatch.com/pk/search?q={title}"
        }

        CACHE[cache_key] = result
        return result