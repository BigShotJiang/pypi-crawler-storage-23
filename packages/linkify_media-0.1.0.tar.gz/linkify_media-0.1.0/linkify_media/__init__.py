from .core import generate_links

__version__ = "0.1.0"
__all__ = ["generate_links"]