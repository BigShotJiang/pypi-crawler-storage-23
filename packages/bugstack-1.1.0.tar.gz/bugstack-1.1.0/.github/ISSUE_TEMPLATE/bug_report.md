---
name: Bug Report
about: Report a bug in the BugStack Python SDK
title: "[Bug] "
labels: bug
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
```python
# Minimal code to reproduce
```

**Expected behavior**
What you expected to happen.

**Environment**
- Python version:
- SDK version:
- Framework (if applicable):
- OS:
