# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2026-03-02

### Fixed

- **Fork-safe transport**: Background worker thread now automatically restarts
  after `os.fork()`, fixing silent event loss under Gunicorn, uWSGI, and other
  prefork WSGI servers.
- **Worker loop resilience**: Unexpected exceptions in the worker loop are now
  caught and logged instead of silently killing the thread.
- **Debug logging under WSGI servers**: Replaced `logging.basicConfig()` (which
  is a no-op when the root logger is already configured by Gunicorn/uWSGI) with
  a direct handler on the `bugstack` logger.

### Added

- Python 3.14 support (tested and confirmed).

## [1.0.0] - 2026-02-13

### Added

- Core SDK with `bugstack.init()` and `bugstack.capture_exception()`
- Background HTTP transport with retry and exponential backoff
- SHA-256 error fingerprinting and client-side deduplication
- `before_send` hook for event inspection/modification/filtering
- `ignored_errors` for skipping specific error types or messages
- `dry_run` mode for transparent debugging
- `enabled` kill switch
- FastAPI middleware integration
- Django middleware integration with auto-init from settings
- Flask integration via `init_app()`
- Generic integration via `sys.excepthook` and `threading.excepthook`
