"""Allow running vastly as ``python -m vastly``."""

from vastly.cli import main

if __name__ == "__main__":
    main()
