"""ghtraf subcommands.

Each command module exports:
  register(subparsers, parents) — add the subcommand to argparse
  run(args) — execute the command
"""
