"""vida operators — Vida Agent 专用算子

包含 Vida Agent 的核心 operator 实现：

- VidaMemoryBridge:    三层记忆接入 operator（工作/情节/语义记忆）
- VidaReflectionEngine: 周期性自我反思与记忆整合 operator

依赖:
    - isage-neuromem >= 0.2.1（三层服务 + AsyncMemoryAdapter）
    - sage.middleware.components.sage_mem（neuromem 官方 SAGE 入口）
"""

from __future__ import annotations

from .vida_agent import VidaAgent, VidaMessage, VidaResult
from .vida_memory_bridge import VidaMemoryBridge
from .vida_reflection_engine import LLMProtocol, VidaReflectionEngine
from .vida_trigger_manager import TriggerManager, VidaEvent

__all__ = [
    "LLMProtocol",
    "VidaAgent",
    "VidaMessage",
    "VidaMemoryBridge",
    "VidaReflectionEngine",
    "VidaResult",
    "TriggerManager",
    "VidaEvent",
]
