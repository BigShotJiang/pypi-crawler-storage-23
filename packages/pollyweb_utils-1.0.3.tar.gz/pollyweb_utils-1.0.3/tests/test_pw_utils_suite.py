from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

LEGACY_ENTRYPOINT = "PW_UTILS.test"
TAIL_LINES = 80


def _tail(lines: str) -> str:
    return "\n".join(lines.splitlines()[-TAIL_LINES:])


def test_pw_utils_legacy_suite() -> None:
    """Run the existing PW_UTILS suite through the legacy module entrypoint."""
    result = subprocess.run(
        [sys.executable, "-m", LEGACY_ENTRYPOINT],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        tail = _tail(result.stdout)
        error_tail = _tail(result.stderr)
        raise AssertionError(
            "Legacy PW_UTILS suite failed.\n"
            f"stdout tail:\n{tail}\n\nstderr tail:\n{error_tail}"
        )


def test_pw_utils_run_direct() -> None:
    """Ensure TEST_UTILS.Run executes directly under pytest."""
    from PW_UTILS.TEST_UTILS import TEST_UTILS

    TEST_UTILS.Run()


def test_pollyweb_namespace_imports() -> None:
    """Ensure new pollyweb.utils namespace exports legacy symbols."""
    import pollyweb
    from pollyweb.utils import LOG

    assert hasattr(pollyweb, "utils")
    assert hasattr(LOG, "Print")


def test_pollyweb_top_level_imports() -> None:
    """Ensure `import pollyweb` exposes top-level utility symbols."""
    import pollyweb

    assert hasattr(pollyweb, "LOG")
    assert hasattr(pollyweb.LOG, "Print")
