class SETTINGS:

    ICONS_ENABLED:bool = False
    '''👉️ Icons on dirs and files doesn't survive race conditions.
        * Keep this as False, unless you've fixed the limitation.'''


    