# pylint: disable=duplicate-code
# TODO: Extract common AIdol converters to shared module
#       (duplicated in managers/database_aidol_manager.py)
"""
AIdol repository

Implements BaseRepository pattern for BaseCrudRouter compatibility.
"""

from datetime import timezone

from aioia_core.repositories import BaseRepository
from sqlalchemy.orm import Session

from aidol.models import DBAIdol
from aidol.schemas import AIdol, AIdolCreateWithAnonymousId, AIdolStatus, AIdolUpdate


def _convert_db_aidol_to_model(db_aidol: DBAIdol) -> AIdol:
    """Convert DB AIdol to Pydantic model.

    Includes anonymous_id for internal use (Service layer).
    Router should convert to AIdolPublic for API responses.
    """
    return AIdol(
        id=db_aidol.id,
        name=db_aidol.name,
        email=db_aidol.email,
        greeting=db_aidol.greeting,
        concept=db_aidol.concept,
        profile_image_url=db_aidol.profile_image_url,
        status=AIdolStatus(db_aidol.status),
        anonymous_id=db_aidol.anonymous_id,
        created_at=db_aidol.created_at.replace(tzinfo=timezone.utc),
        updated_at=db_aidol.updated_at.replace(tzinfo=timezone.utc),
    )


def _convert_aidol_create_to_db(
    schema: AIdolCreateWithAnonymousId | AIdolUpdate,
) -> dict:
    """Convert AIdolCreateWithAnonymousId or AIdolUpdate schema to DB model data dict."""
    data = schema.model_dump(exclude_unset=True)

    # Enforce DRAFT status only on creation
    if isinstance(schema, AIdolCreateWithAnonymousId):
        data["status"] = AIdolStatus.DRAFT.value

    return data


class AIdolRepository(
    BaseRepository[AIdol, DBAIdol, AIdolCreateWithAnonymousId, AIdolUpdate]
):
    """
    Database-backed AIdol repository.

    Extends BaseRepository for CRUD operations compatible with BaseCrudRouter.
    """

    def __init__(self, db_session: Session):
        super().__init__(
            db_session=db_session,
            db_model=DBAIdol,
            convert_to_model=_convert_db_aidol_to_model,
            convert_to_db_model=_convert_aidol_create_to_db,
        )
