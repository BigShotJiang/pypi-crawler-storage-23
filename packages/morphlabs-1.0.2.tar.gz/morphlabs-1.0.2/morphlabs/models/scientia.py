import io
import requests
import numpy as np
import mne
import os
import logging
import time
from typing import Optional
from matplotlib.figure import Figure
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from morphlabs.io.loading import EEGData
from morphlabs.io.preprocessing import denormalize

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_ERROR_MESSAGES = {
    400: "Bad request: The data sent to the API was invalid. Please check your input data format.",
    401: "Authentication failed: Invalid API key. Please check your SCIENTIA_API_KEY.",
    403: "Access denied: Your API key does not have permission for this operation. Please contact support.",
    404: "API endpoint not found: Please check the base_url configuration.",
    429: "Rate limit exceeded: Too many requests. Please wait a moment and try again.",
    500: "Server error: The Scientia API encountered an internal error. Please try again later.",
    502: "Bad gateway: The Scientia API is temporarily unavailable. Please try again later.",
    503: "Service unavailable: The Scientia API is temporarily down for maintenance. Please try again later.",
    504: "Gateway timeout: The request took too long. Please try again with smaller data segments.",
}

RETRYABLE_STATUS_CODES = [429, 500, 502, 503, 504]

RUNPOD_API_KEY = "rpa_FFBJYB2SODF8Z3MCXWY5W78L8KI0A4BGQ999JLUZcqkk9u"

DEFAULT_POLL_INTERVAL = 1.0    # seconds between status polls
DEFAULT_MAX_POLL_TIME = 300.0  # 5 min timeout per job


class RetryableAPIError(Exception):
    pass

class Scientia:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_poll_time: float = DEFAULT_MAX_POLL_TIME,
    ):
        api_key = api_key if api_key is not None else os.getenv("SCIENTIA_API_KEY")

        if api_key is not None and not api_key.strip():
            raise ValueError("API key cannot be empty or whitespace. Please provide a valid API key.")
        self.api_key = api_key

        base_url = base_url if base_url is not None else os.getenv(
            "MORPHLABS_BASE_URL", "https://api.runpod.ai/v2/bsqrfd0tjfl0u4"
        )
        if not base_url.startswith(("http://", "https://")):
            raise ValueError(f"Invalid base_url: '{base_url}'. URL must start with http:// or https://")
        self.base_url = base_url.rstrip("/")

        self.poll_interval = poll_interval
        self.max_poll_time = max_poll_time

    def clean_data(
        self,
        data_path: str,
        sfreq: Optional[float] = 250.0,
        powerline_freq: float = 60.0
    ) -> tuple[np.ndarray, list[str], float]:
        """
        Clean EEG data using the Scientia API.

        Args:
            data_path: Path to the EEG data file (.csv, .edf, or .bdf)
            sfreq: Sampling frequency in Hz. For CSV files, defaults to 250 Hz.
                   For EDF/BDF files, this is auto-detected from the file metadata.
            powerline_freq: Power line frequency for notch filter (default 60.0 Hz for US,
                           use 50.0 for EU)

        Returns:
            A tuple of (cleaned_data, channel_names, sfreq) where:
                - cleaned_data: numpy array of shape (n_channels, n_samples)
                - channel_names: list of channel name strings
                - sfreq: sampling frequency in Hz
        """
        if self.api_key is None:
            raise ValueError("API key not found. Please pass the API key as an argument or set the SCIENTIA_API_KEY environment variable.")

        data_obj = EEGData(data_path, sfreq=sfreq, powerline_freq=powerline_freq)

        data_samples = data_obj.get_data()
        channel_names = data_obj.get_channel_names()
        pad_amount = data_obj.get_pad_amount()
        normalization_params = data_obj.get_normalization_params()

        cleaned_samples = []
        total_segments = len(data_samples)
        total_samples = total_segments * 1000 - pad_amount

        logger.info(f"Cleaning {total_samples} samples ({total_segments} segments)")

        # Upload all segments to B2 and submit a single infer job
        upload_url, data_key = self._get_upload_url()
        self._upload_to_b2(upload_url, data_samples)
        logger.info(f"Uploaded {total_segments} segments to B2")

        payload = {"input": {"api_key": self.api_key, "channel_names": channel_names, "data_key": data_key}}
        job_id = self._submit_job(payload)
        response_data = self._poll_job(job_id)
        output = response_data.get("output", {})

        if output is None or "reconstructed" not in output:
            raise ValueError("Invalid response from API: Missing 'reconstructed' field in response.")

        reconstructed = output["reconstructed"]

        for j, cleaned_data in enumerate(reconstructed):
            cleaned_sample = np.array(cleaned_data)
            cleaned_sample = denormalize(cleaned_sample, normalization_params[j])

            if j == total_segments - 1 and pad_amount > 0:
                cleaned_sample = cleaned_sample[:, :-pad_amount]

            cleaned_samples.append(cleaned_sample)

        return self._reconstruct_data(cleaned_samples), channel_names, data_obj.get_sfreq()

    def plot_data(
        self,
        data: np.ndarray,
        channel_names: list[str],
        sfreq: float,
        **kwargs,
    ) -> Figure:
        """
        Plot cleaned EEG data using MNE's interactive viewer.

        Args:
            data: Cleaned EEG data array of shape (n_channels, n_samples), values in volts.
            channel_names: List of channel name strings.
            sfreq: Sampling frequency in Hz.
            **kwargs: Additional keyword arguments passed to mne.io.RawArray.plot()
                      (e.g. duration, n_channels, scalings, title).

        Returns:
            The MNE figure instance (can be used to save, e.g. fig.savefig(...)).
        """
        info = mne.create_info(
            ch_names=channel_names,
            sfreq=sfreq,
            ch_types='eeg',
        )
        raw = mne.io.RawArray(data, info, verbose=False)
        return raw.plot(**kwargs)

    def _reconstruct_data(self, cleaned_samples: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(cleaned_samples, axis=1)

    def _get_upload_url(self) -> tuple[str, str]:
        """Request a presigned B2 upload URL from the server."""
        payload = {"input": {"api_key": self.api_key, "action": "get_upload_url"}}
        job_id = self._submit_job(payload)
        response_data = self._poll_job(job_id)
        output = response_data.get("output", {})
        if output is None or "upload_url" not in output or "data_key" not in output:
            raise ValueError("Invalid response from API: Missing 'upload_url' or 'data_key' in get_upload_url response.")
        return output["upload_url"], output["data_key"]

    def _upload_to_b2(self, upload_url: str, segments: list[np.ndarray]) -> None:
        """Stack segments into a single numpy array and PUT it to the presigned B2 URL."""
        stacked = np.stack(segments)  # shape (N, C, 1000)
        buf = io.BytesIO()
        np.save(buf, stacked)
        buf.seek(0)
        response = requests.put(upload_url, data=buf.read(), headers={"Content-Type": "application/octet-stream"}, timeout=120)
        if not response.ok:
            raise ValueError(f"B2 upload failed with status {response.status_code}: {response.text}")

    def _submit_job(self, payload: dict) -> str:
        """Submit a job to the async /run endpoint and return the job ID."""
        response = self._make_api_request(
            url=f"{self.base_url}/run",
            method="POST",
            json=payload,
            timeout=120,
        )
        try:
            response_data = response.json()
        except requests.exceptions.JSONDecodeError:
            raise ValueError("Invalid response from API: Expected JSON but received invalid data.")

        job_id = response_data.get("id")
        if not job_id:
            raise ValueError("Invalid response from API: Missing job 'id' field in /run response.")
        return job_id

    def _poll_job(self, job_id: str) -> dict:
        """Poll the /status endpoint until the job completes, fails, or times out."""
        start = time.monotonic()
        while True:
            elapsed = time.monotonic() - start
            if elapsed >= self.max_poll_time:
                raise TimeoutError(
                    f"Job {job_id} did not complete within {self.max_poll_time}s."
                )

            response = self._make_api_request(
                url=f"{self.base_url}/status/{job_id}",
                method="GET",
                timeout=30,
            )
            try:
                response_data = response.json()
            except requests.exceptions.JSONDecodeError:
                raise ValueError("Invalid response from API: Expected JSON but received invalid data.")

            status = response_data.get("status")
            if status == "COMPLETED":
                return response_data
            elif status in ("IN_QUEUE", "IN_PROGRESS"):
                time.sleep(self.poll_interval)
            elif status == "FAILED":
                error_msg = response_data.get("error", "Unknown error")
                raise ValueError(f"Scientia API request failed: {error_msg}")
            elif status == "CANCELLED":
                raise ValueError("Scientia API request was cancelled.")
            else:
                raise ValueError(f"Unexpected response status from Scientia API: {status}")

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=15), retry=retry_if_exception_type(RetryableAPIError))
    def _make_api_request(self, url: str, method: str = "POST", json: Optional[dict] = None, timeout: int = 120) -> requests.Response:
        headers = {"Authorization": f"Bearer {RUNPOD_API_KEY}"}
        try:
            if method == "GET":
                response = requests.get(url, headers=headers, timeout=timeout)
            else:
                response = requests.post(url, headers=headers, json=json, timeout=timeout)
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            raise RetryableAPIError(f"Network error: {e}")

        if response.status_code in RETRYABLE_STATUS_CODES:
            raise RetryableAPIError(f"API request failed with status {response.status_code}: {response.text}")

        if not response.ok:
            error_msg = API_ERROR_MESSAGES.get(response.status_code, f"API request failed with status {response.status_code}: {response.text}")
            raise ValueError(error_msg)

        return response
