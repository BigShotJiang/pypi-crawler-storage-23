import numpy as np
import matplotlib.pyplot as plt
import mne
import os
from scipy.signal import butter, iirnotch, sosfiltfilt, filtfilt

from morphlabs.models import Scientia

# Path to test file
FILE_PATH = "/Users/sohammehra/Downloads/eeg_subset_morph.edf"
CACHE_PATH = "/Users/sohammehra/Morph/sdk/examples/cleaned_cache.npy"

# Load raw data for "before" visualization
print("Loading raw EEG data...")
raw = mne.io.read_raw_edf(FILE_PATH, preload=True, verbose=False)
raw_data = raw.get_data()
sfreq = raw.info['sfreq']
ch_names = raw.ch_names

print(f"Channels: {len(ch_names)}")
print(f"Sampling frequency: {sfreq} Hz")
print(f"Duration: {raw_data.shape[1] / sfreq:.2f} seconds")

# Apply traditional filtering (60Hz notch + 1-40Hz bandpass)
print("\nApplying traditional filters (60Hz notch + 1-40Hz bandpass)...")

def bandpass_filter(data, sfreq, lowcut=1.0, highcut=40.0, order=4):
    nyquist = sfreq / 2.0
    low = lowcut / nyquist
    high = highcut / nyquist
    sos = butter(order, [low, high], btype='band', output='sos')
    return sosfiltfilt(sos, data, axis=1).astype(np.float32)

def notch_filter(data, sfreq, freq=60.0, quality=30.0):
    b, a = iirnotch(freq, quality, sfreq)
    return filtfilt(b, a, data, axis=1).astype(np.float32)

# Apply notch then bandpass
filtered_data = notch_filter(raw_data.astype(np.float32), sfreq, freq=60.0)
filtered_data = bandpass_filter(filtered_data, sfreq, lowcut=1.0, highcut=40.0)

# Clean data using Scientia API (with caching)
if os.path.exists(CACHE_PATH):
    print("\nLoading cached cleaned data...")
    cleaned_data = np.load(CACHE_PATH)
else:
    print("\nCleaning data with Scientia...")
    scientia = Scientia(api_key="sk_live_r854XZxUiNMH0AQQjVDEAwf-GxAk5uQv")
    cleaned_data, channel_names, sfreq = scientia.clean_data(FILE_PATH, sfreq=sfreq)
    np.save(CACHE_PATH, cleaned_data)
    print("Cached cleaned data for future runs.")

print(f"Raw shape: {raw_data.shape}")
print(f"Filtered shape: {filtered_data.shape}")
print(f"Cleaned shape: {cleaned_data.shape}")

# Create time axis - show 15 second window starting at 30s
start_sec = 30
duration_sec = 15
start_sample = int(start_sec * sfreq)
end_sample = int((start_sec + duration_sec) * sfreq)
n_samples = end_sample - start_sample
time = np.arange(n_samples) / sfreq + start_sec

# Convert to microvolts
raw_data_uv = raw_data * 1e6
filtered_data_uv = filtered_data * 1e6
cleaned_data_uv = cleaned_data * 1e6

# Select channels to display (first 6 for clarity)
n_display = min(6, len(ch_names))

# Plot comparison (3 columns)
fig, axes = plt.subplots(n_display, 3, figsize=(18, 2.5 * n_display), sharex=True)
fig.suptitle("EEG: Raw vs Traditional Filtering vs Scientia Cleaning", fontsize=14, fontweight='bold')

for i in range(n_display):
    # Raw
    axes[i, 0].plot(time, raw_data_uv[i, start_sample:end_sample], 'b-', linewidth=0.5)
    axes[i, 0].set_ylabel(f"{ch_names[i]}\n(μV)", fontsize=9)
    if i == 0:
        axes[i, 0].set_title("Raw", fontsize=12)

    # Filtered (notch + bandpass)
    axes[i, 1].plot(time, filtered_data_uv[i, start_sample:end_sample], 'orange', linewidth=0.5)
    if i == 0:
        axes[i, 1].set_title("Filtered (60Hz notch + 1-40Hz bandpass)", fontsize=12)

    # Cleaned (Scientia)
    axes[i, 2].plot(time, cleaned_data_uv[i, start_sample:end_sample], 'g-', linewidth=0.5)
    if i == 0:
        axes[i, 2].set_title("Scientia Cleaned", fontsize=12)

axes[-1, 0].set_xlabel("Time (s)")
axes[-1, 1].set_xlabel("Time (s)")
axes[-1, 2].set_xlabel("Time (s)")

plt.tight_layout()
plt.savefig("eeg_cleaning_comparison.png", dpi=150)
plt.show()

print("\nPlot saved to eeg_cleaning_comparison.png")
