import io
import pytest
import numpy as np
from unittest.mock import patch, MagicMock
from pathlib import Path
import requests

from morphlabs.models import Scientia
from morphlabs.io.preprocessing import NormalizationParams


@pytest.fixture
def test_data_path():
    return Path(__file__).parent / "test_data"


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("SCIENTIA_API_KEY", "test_api_key")
    return "test_api_key"


@pytest.fixture
def no_api_key(monkeypatch):
    monkeypatch.delenv("SCIENTIA_API_KEY", raising=False)


# =============================================================================
# MockRunPodAPI helper
# =============================================================================

class MockRunPodAPI:
    """Stateful mock that simulates the B2-based async RunPod flow.

    clean_data now always does:
      1. POST /run  (get_upload_url)  →  poll  →  {upload_url, data_key}
      2. PUT  upload_url  (raw .npy bytes)
      3. POST /run  (infer w/ data_key)  →  poll  →  {reconstructed}

    The mock captures the PUT body, deserializes the .npy, and echoes it
    back as `reconstructed` when the infer job is polled.
    """

    MOCK_UPLOAD_URL = "https://b2.example.com/file/bucket/inputs/test.npy?auth=xyz"
    MOCK_DATA_KEY = "inputs/test-uuid.npy"

    def __init__(self, job_id="test-job-123", poll_responses=None):
        self.job_id = job_id
        self.submitted_payloads = []
        self.poll_call_count = 0
        self.put_calls = []  # (url, body_bytes)
        self._job_counter = 0
        self._poll_responses = poll_responses
        self._submitted_data = None
        self._uploaded_data = None  # np.ndarray parsed from PUT body

    def mock_post(self, url, headers=None, json=None, **kwargs):
        self.submitted_payloads.append(json)
        self._submitted_data = json
        self._job_counter += 1
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {
            "id": f"{self.job_id}-{self._job_counter}",
            "status": "IN_QUEUE",
        }
        return mock_response

    def mock_get(self, url, headers=None, **kwargs):
        self.poll_call_count += 1
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True

        if self._poll_responses:
            # Pop the next scripted response
            resp = self._poll_responses.pop(0)
            mock_response.json.return_value = resp
        elif self._submitted_data and self._submitted_data.get("input", {}).get("action") == "get_upload_url":
            # get_upload_url completed
            mock_response.json.return_value = {
                "status": "COMPLETED",
                "output": {
                    "upload_url": self.MOCK_UPLOAD_URL,
                    "data_key": self.MOCK_DATA_KEY,
                },
            }
        elif self._submitted_data and "data_key" in self._submitted_data.get("input", {}):
            # Infer job — echo uploaded .npy data back as reconstructed
            reconstructed = self._uploaded_data.tolist() if self._uploaded_data is not None else []
            mock_response.json.return_value = {
                "status": "COMPLETED",
                "output": {
                    "reconstructed": reconstructed,
                    "meta": {"model_version": "v1"},
                },
            }
        else:
            # Fallback (inline data echo — kept for low-level tests)
            data = self._submitted_data["input"].get("data", []) if self._submitted_data else []
            mock_response.json.return_value = {
                "status": "COMPLETED",
                "output": {
                    "reconstructed": data,
                    "meta": {"model_version": "v1"},
                },
            }
        return mock_response

    def mock_put(self, url, data=None, headers=None, **kwargs):
        self.put_calls.append((url, data))
        if data is not None:
            self._uploaded_data = np.load(io.BytesIO(data), allow_pickle=False)
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        return mock_response

    def mock_put_fail(self, url, data=None, headers=None, **kwargs):
        self.put_calls.append((url, data))
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.ok = False
        mock_response.text = "Forbidden"
        return mock_response

    @classmethod
    def upload_url_response(cls):
        """Scripted COMPLETED response for get_upload_url (for poll_responses lists)."""
        return {
            "status": "COMPLETED",
            "output": {
                "upload_url": cls.MOCK_UPLOAD_URL,
                "data_key": cls.MOCK_DATA_KEY,
            },
        }


# =============================================================================
# Init Tests
# =============================================================================

def test_init_defaults(no_api_key):
    scientia = Scientia()
    assert scientia.api_key is None
    assert scientia.base_url == "https://api.runpod.ai/v2/bsqrfd0tjfl0u4"


def test_init_with_api_key(no_api_key):
    scientia = Scientia(api_key="test_api_key1")
    assert scientia.api_key == "test_api_key1"
    assert scientia.base_url == "https://api.runpod.ai/v2/bsqrfd0tjfl0u4"


def test_init_from_env(api_key):
    scientia = Scientia(base_url="https://test.scientia.ai")
    assert scientia.api_key == "test_api_key"
    assert scientia.base_url == "https://test.scientia.ai"


@pytest.mark.parametrize("base_url,expected", [
    ("https://api.scientia.ai/", "https://api.scientia.ai"),
    ("https://api.scientia.ai/v1", "https://api.scientia.ai/v1"),
    ("https://api.scientia.ai/v1/", "https://api.scientia.ai/v1"),
])
def test_init_strips_trailing_slash(base_url, expected):
    scientia = Scientia(api_key="test_api_key", base_url=base_url)
    assert scientia.base_url == expected


def test_configurable_poll_params():
    scientia = Scientia(api_key="test_api_key", poll_interval=2.5, max_poll_time=600.0)
    assert scientia.poll_interval == 2.5
    assert scientia.max_poll_time == 600.0


def test_base_url_from_env(monkeypatch):
    monkeypatch.setenv("MORPHLABS_BASE_URL", "https://dev.runpod.ai/v2/dev-endpoint")
    scientia = Scientia(api_key="test_api_key")
    assert scientia.base_url == "https://dev.runpod.ai/v2/dev-endpoint"


def test_base_url_param_overrides_env(monkeypatch):
    monkeypatch.setenv("MORPHLABS_BASE_URL", "https://dev.runpod.ai/v2/dev-endpoint")
    scientia = Scientia(api_key="test_api_key", base_url="https://custom.api.ai/v1")
    assert scientia.base_url == "https://custom.api.ai/v1"


# =============================================================================
# Validation Tests
# =============================================================================

def test_missing_api_key_error(no_api_key, test_data_path):
    scientia = Scientia()
    with pytest.raises(ValueError) as e:
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key not found" in str(e.value)


def test_empty_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", "")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_whitespace_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", " ")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_invalid_base_url_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "Invalid base_url" in str(e.value)


def test_invalid_base_url_protocol_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="ftp://invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "URL must start with http:// or https://" in str(e.value)


# =============================================================================
# Success / Data Tests
# =============================================================================

def test_clean_data_success(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        data, channel_names, sfreq = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data is not None
        assert data.shape == (19, 2500)
        assert isinstance(channel_names, list)
        assert isinstance(sfreq, float)


def test_clean_data_removes_padding(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()

        data_padded, _, _ = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data_padded.shape == (19, 2500)

        data_no_pad, _, _ = scientia.clean_data(test_data_path / "valid_19ch_2000samples.csv")
        assert data_no_pad.shape == (19, 2000)


def test_json_missing_reconstructed_field(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        # get_upload_url completes normally
        MockRunPodAPI.upload_url_response(),
        # infer job returns bad output
        {"status": "COMPLETED", "output": {}},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert "Invalid response from API: Missing 'reconstructed' field in response." in str(e.value)


def test_json_decode_error_on_submit(api_key, test_data_path):
    def mock_bad_json_post(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError("", "", 0)
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_bad_json_post):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Expected JSON but received invalid data" in str(e.value)


def test_json_decode_error_on_poll(api_key, test_data_path):
    mock_api = MockRunPodAPI()

    def mock_bad_json_get(url, headers=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError("", "", 0)
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_bad_json_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Expected JSON but received invalid data" in str(e.value)


# =============================================================================
# HTTP Error Tests
# =============================================================================

@pytest.mark.parametrize("status_code", [429, 500, 502, 503, 504])
def test_retryable_status_codes(api_key, test_data_path, status_code):
    def mock_retryable_error(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_retryable_error):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert f"API request failed with status {status_code}" in str(last_exception)


@pytest.mark.parametrize("status_code,expected_msg", [
    (400, "Bad request"),
    (401, "Authentication failed"),
    (403, "Access denied"),
    (404, "API endpoint not found"),
])
def test_non_retryable_status_codes(api_key, test_data_path, status_code, expected_msg):
    def mock_non_retryable_error(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_non_retryable_error):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert expected_msg in str(e.value)


def test_retry_attempts_count(api_key, test_data_path):
    call_count = 0

    def mock_always_fails(url, headers=None, json=None, **kwargs):
        nonlocal call_count
        call_count += 1
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.ok = False
        mock_response.text = "Server error"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_always_fails):
        scientia = Scientia()
        with pytest.raises(Exception):
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert call_count == 3


def test_network_timeout(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.Timeout("Connection timed out")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


def test_network_connection_error(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.ConnectionError("Connection refused")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


# =============================================================================
# RunPod Polling / Status Tests
# =============================================================================

def test_poll_transitions_through_statuses(api_key, test_data_path):
    """IN_QUEUE -> IN_PROGRESS -> COMPLETED should succeed on the infer job."""
    mock_api = MockRunPodAPI(poll_responses=[
        # get_upload_url completes immediately
        MockRunPodAPI.upload_url_response(),
        # infer job transitions
        {"status": "IN_QUEUE"},
        {"status": "IN_PROGRESS"},
        # Final COMPLETED will be auto-generated by mock_get default path
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        data, _, _ = scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert data is not None
        assert data.shape == (19, 1000)
        # 1 (get_upload_url) + 3 (IN_QUEUE + IN_PROGRESS + COMPLETED for infer)
        assert mock_api.poll_call_count == 4


def test_runpod_failed_status(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        MockRunPodAPI.upload_url_response(),
        {"status": "FAILED", "error": "GPU out of memory"},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Scientia API request failed" in str(e.value)
        assert "GPU out of memory" in str(e.value)


def test_runpod_cancelled_status(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        MockRunPodAPI.upload_url_response(),
        {"status": "CANCELLED"},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "was cancelled" in str(e.value)


def test_poll_timeout(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        MockRunPodAPI.upload_url_response(),
        {"status": "IN_QUEUE"},
        {"status": "IN_QUEUE"},
        {"status": "IN_PROGRESS"},
    ])

    # Provide enough monotonic() values for tenacity internals + both _poll_job calls.
    # The exact call count depends on tenacity's retry decorator (which calls
    # monotonic on begin/retry), plus _poll_job's own loop.  We supply a generous
    # sequence that starts at 0 and jumps past 300s on the later calls.
    time_values = iter([0.0] * 10 + [100.0] * 4 + [400.0] * 4)

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"), \
         patch("morphlabs.models.scientia.time.monotonic", side_effect=time_values):
        scientia = Scientia(max_poll_time=300.0)
        with pytest.raises(TimeoutError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "did not complete within" in str(e.value)


def test_submit_missing_job_id(api_key, test_data_path):
    """If /run response lacks an 'id' field, raise ValueError."""
    def mock_no_id_post(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {"status": "IN_QUEUE"}  # no "id"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_no_id_post):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Missing job 'id' field" in str(e.value)


def test_url_construction(api_key, test_data_path):
    """Verify POST goes to /run and GET goes to /status/{job_id}."""
    captured_post_urls = []
    captured_get_urls = []

    mock_api = MockRunPodAPI()
    original_post = mock_api.mock_post
    original_get = mock_api.mock_get

    def capture_post(url, headers=None, json=None, **kwargs):
        captured_post_urls.append(url)
        return original_post(url, headers=headers, json=json, **kwargs)

    def capture_get(url, headers=None, **kwargs):
        captured_get_urls.append(url)
        return original_get(url, headers=headers, **kwargs)

    with patch("morphlabs.models.scientia.requests.post", side_effect=capture_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=capture_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert all(url.endswith("/run") for url in captured_post_urls)
    assert all("/status/test-job-123-" in url for url in captured_get_urls)


# =============================================================================
# Payload / Header Tests
# =============================================================================

def test_api_key_in_payload(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    # Two payloads: get_upload_url then infer
    assert len(mock_api.submitted_payloads) == 2

    # get_upload_url payload
    upload_payload = mock_api.submitted_payloads[0]
    assert upload_payload["input"]["api_key"] == "test_api_key"
    assert upload_payload["input"]["action"] == "get_upload_url"

    # infer payload
    infer_payload = mock_api.submitted_payloads[1]
    assert infer_payload["input"]["api_key"] == "test_api_key"
    assert "data_key" in infer_payload["input"]
    assert isinstance(infer_payload["input"]["channel_names"], list)
    assert "data" not in infer_payload["input"]


def test_runpod_api_key_in_header(api_key, test_data_path):
    captured_headers = None
    mock_api = MockRunPodAPI()

    def mock_capture_headers(url, headers=None, json=None, **kwargs):
        nonlocal captured_headers
        captured_headers = headers
        # Delegate to mock_api so it stores the submitted data for polling
        return mock_api.mock_post(url, headers=headers, json=json, **kwargs)

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_capture_headers), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert captured_headers is not None
    assert "Authorization" in captured_headers
    assert captured_headers["Authorization"].startswith("Bearer ")
    assert "rpa_" in captured_headers["Authorization"]


def test_channel_names_in_payload(api_key, test_data_path):
    """Verify channel_names values match expected normalized names."""
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    # infer payload is the 2nd submission
    infer_payload = mock_api.submitted_payloads[1]
    channel_names = infer_payload["input"]["channel_names"]
    expected = [
        "FP1", "FP2", "F7", "F3", "FZ", "F4", "F8",
        "T3", "C3", "CZ", "C4", "T4",
        "T5", "P3", "PZ", "P4", "T6",
        "O1", "O2",
    ]
    assert channel_names == expected


# =============================================================================
# B2 Upload Tests
# =============================================================================

def _make_fake_eeg_data(num_channels, num_segments):
    """Create fake EEGData-like segments: list of (C, 1000) arrays."""
    return [np.random.randn(num_channels, 1000).astype(np.float64) for _ in range(num_segments)]


class _FakeEEGData:
    """Minimal stand-in for EEGData used in B2 upload tests."""
    def __init__(self, channel_names, segments, pad_amount=0, sfreq=250.0):
        self._channel_names = channel_names
        self._segments = segments
        self._pad_amount = pad_amount
        self._sfreq = sfreq

    def get_data(self):
        return self._segments

    def get_channel_names(self):
        return self._channel_names

    def get_pad_amount(self):
        return self._pad_amount

    def get_normalization_params(self):
        return [NormalizationParams(mean=np.zeros(len(self._channel_names)),
                                    std=np.ones(len(self._channel_names)))
                for _ in self._segments]

    def get_sfreq(self):
        return self._sfreq


def test_b2_upload_flow(api_key):
    """Verify the full B2 flow: get_upload_url → PUT .npy → infer with data_key."""
    num_channels = 19
    num_segments = 3
    channel_names = [f"CH{i}" for i in range(num_channels)]
    segments = _make_fake_eeg_data(num_channels, num_segments)
    fake_eeg = _FakeEEGData(channel_names, segments)

    mock_api = MockRunPodAPI()

    with patch("morphlabs.models.scientia.EEGData", return_value=fake_eeg), \
         patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        data, ch, sfreq = scientia.clean_data("dummy.csv")

    # Exactly 2 POST submissions: get_upload_url + infer
    assert len(mock_api.submitted_payloads) == 2

    # First is get_upload_url
    assert mock_api.submitted_payloads[0]["input"]["action"] == "get_upload_url"

    # Second is infer with data_key
    infer_payload = mock_api.submitted_payloads[1]
    assert infer_payload["input"]["data_key"] == MockRunPodAPI.MOCK_DATA_KEY
    assert "data" not in infer_payload["input"]

    # Exactly 1 PUT to B2
    assert len(mock_api.put_calls) == 1
    assert mock_api.put_calls[0][0] == MockRunPodAPI.MOCK_UPLOAD_URL

    # Output shape matches input
    assert data.shape == (num_channels, num_segments * 1000)


def test_b2_upload_npy_format(api_key):
    """Verify the PUT body is valid .npy bytes with the correct shape."""
    num_channels = 64
    num_segments = 16
    channel_names = [f"CH{i}" for i in range(num_channels)]
    segments = _make_fake_eeg_data(num_channels, num_segments)
    fake_eeg = _FakeEEGData(channel_names, segments)

    mock_api = MockRunPodAPI()

    with patch("morphlabs.models.scientia.EEGData", return_value=fake_eeg), \
         patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data("dummy.csv")

    # Extract the bytes sent via PUT
    assert len(mock_api.put_calls) == 1
    put_body = mock_api.put_calls[0][1]
    assert isinstance(put_body, bytes)

    # Deserialize and check shape
    arr = np.load(io.BytesIO(put_body))
    assert arr.shape == (num_segments, num_channels, 1000)


def test_b2_upload_failure(api_key):
    """B2 PUT returns 403 → raises ValueError."""
    num_channels = 19
    num_segments = 3
    channel_names = [f"CH{i}" for i in range(num_channels)]
    segments = _make_fake_eeg_data(num_channels, num_segments)
    fake_eeg = _FakeEEGData(channel_names, segments)

    mock_api = MockRunPodAPI()

    with patch("morphlabs.models.scientia.EEGData", return_value=fake_eeg), \
         patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.requests.put", side_effect=mock_api.mock_put_fail), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data("dummy.csv")
        assert "B2 upload failed" in str(e.value)
        assert "403" in str(e.value)
