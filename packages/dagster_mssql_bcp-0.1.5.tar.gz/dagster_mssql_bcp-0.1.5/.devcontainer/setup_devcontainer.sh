#/bin/bash

# Install Drivers and setup database
. /workspace/.devcontainer/setup_drivers.sh
