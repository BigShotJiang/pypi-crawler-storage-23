# /bin/bash

/bin/bash /workspace/.devcontainer/setup_database.sh
pip install -e ".[dev]"
