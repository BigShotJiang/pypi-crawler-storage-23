This app is essentially asking a LLM "would you have generated the same response?".
Then it probes the internals of the model for its opinion.
The more surprised the LLM is the more "human" the text is scored.

Some texts that were originally human written are considered "AI" here:
- very well-know samples like Wikipedia articles, classic books in the public domain, etc
- generic and predictable phrases like idioms, formal style, etc; so "take this with a grain of salt"!

IE anything that is highly predictable is deemed "AI": more precisely, this app asks the question "what is *original* human work in this text?".

Believe it or not this entire introduction was written by hand, so you can see the limits of my tool!
More than individual scores, the "aspect" of whole sections is reliable.
Use your judgment to assess where your sample sits between the two extrems:
- a sentence with one or more green tokens is likely human, at least reworked by a human to some extent
- a sentence that is all red is highly generic, which often indicates templated or LLM writing

Lemme plug in some personal opinion on text: phrases like "sincerely yours" are copypasta at best, not human intention.

The final probability score is a combination of several metrics, computed token by token (word by word):
- the `unicode` metric outlines invisible or relatively rare glyphs like the infamous em-dash "—" or the curly quotes "“"
- the `surprisal` metric measures how individual tokens diverge from the distribution estimated by the model
- the `perplexity` metric rates how surprising a sequence of tokens is according to the model
- the `ramping` ratio is used to dampen the scores at the begining, where the model lacks context

The fixed recipe used to combine these metrics into the final score for each token is obviously insufficient to detect the ever improving outputs of LLMs.

It is highly likely that you will make a better use of them, so the indicators are plotted in the "graphs" tab.
You will find a few samples to train your eye and spot LLM patterns.

And the details of the scoring recipe are available in the tab "docs".
