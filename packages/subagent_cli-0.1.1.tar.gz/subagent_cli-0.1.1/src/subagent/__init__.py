"""subagent CLI package."""

from .constants import SCHEMA_VERSION

__version__ = "0.1.1"

__all__ = ["SCHEMA_VERSION", "__version__"]
