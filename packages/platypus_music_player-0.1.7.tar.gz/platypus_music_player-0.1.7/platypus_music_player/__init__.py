from main import *
print("Attempting to launch Platypus Player...")
app = main()
app.main_loop()