import toga
from toga.style import Pack
from toga.style.pack import COLUMN


path_label = toga.Label("No file selected", style=Pack(padding=(0, 5)))

async def select_file(widget):
    
    selected_file = await widget.window.open_file_dialog(
        title="Select your .platypus file",
        file_types=["platypus"]
    )
    
    if selected_file is not None:
        path_label.text = f"Path: {selected_file}"

def build(app):
    main_box = toga.Box(style=Pack(direction=COLUMN, padding=10))
    
    
    select_button = toga.Button(
        "Select Platypus File",
        on_press=select_file,
        style=Pack(padding=5)
    )
    
    
    main_box.add(select_button)
    main_box.add(path_label)
    
    return main_box

def main():
    return toga.App("Platypus Player", "org.platypus.music", startup=build)

if __name__ == "__main__":
    app = main()
    app.main_loop()