from typing import Any, Optional


def identify_collection_description(
    item_id: str,
    process_id: str,
) -> None:
    pass


def create_description_data() -> None:
    pass
