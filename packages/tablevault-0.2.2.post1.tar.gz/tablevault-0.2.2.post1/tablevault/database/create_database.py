# make more stringent about pids

from typing import Any, Dict, List, Optional

from arango import ArangoClient
from arango.database import StandardDatabase
from arango.graph import Graph
from tablevault.database.database_views import create_tablevault_query_views

ALL_ITEM_COLLECTIONS: List[str] = [
    "process",
    "file_list",
    "file",
    "embedding_list",
    "embedding",
    "document_list",
    "document",
    "record_list",
    "record",
    "description",
]

DESCRIPTION_COLLECTIONS: List[str] = [
    "process_list",
    "file_list",
    "document_list",
    "record_list",
    "embedding_list",
]

VIEW_COLLECTIONS: List[str] = ["process", "embedding", "document", "record", "description"]


def create_collection_safe(
    db: StandardDatabase, name: str, schema: Optional[Dict[str, Any]] = None, edge: bool = False
) -> None:
    """Helper to create collection only if it doesn't exist."""
    if not db.has_collection(name):
        db.create_collection(name=name, schema=schema, edge=edge)


def get_arango_db(
    database_name: str,
    arango_url: str,
    arango_username: str,
    arango_password: str,
    arango_root_username: str,
    arango_root_password: str,
    new_arango_db: bool = True,
) -> StandardDatabase:
    client = ArangoClient(hosts=arango_url)
    sys_db = client.db(
        "_system", username=arango_root_username, password=arango_root_password
    )
    if new_arango_db and sys_db.has_database(database_name):
        sys_db.delete_database(database_name)
    if new_arango_db:
        sys_db.create_database(
            name=database_name,
            users=[
                {
                    "username": arango_username,
                    "password": arango_password,
                    "active": True,
                }
            ],
        )

    db = client.db(database_name, username=arango_username, password=arango_password)
    return db


def create_tablevault_db(
    db: StandardDatabase, log_file: str, description_embedding_size: int
) -> None:
    if db.has_graph("lineage_graph"):
        graph = db.graph("lineage_graph")
    else:
        graph = db.create_graph("lineage_graph")

    create_collection_safe(db, "metadata")
    doc = {
        "_key": "global",
        "description_embedding_size": description_embedding_size,
        "active_timestamps": {},
        "new_timestamp": 1,
        "vector_indices": {},
        "log_file": log_file,
    }
    col = db.collection("metadata")
    col.insert(doc)

    create_collection_safe(
        db,
        "items",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "timestamp": {"type": "number"},
                    "collection": {"type": "string"},
                    "version": {"type": "number"},
                },
                "required": ["name", "timestamp", "collection"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "process_list",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "interrupt_request": {"type": "string"},
                    "interrupt_action": {"type": "string"},
                    "execution_type": {"type": "string"},
                    "length": {"type": "number"},
                    "n_items": {"type": "number"},
                    "pid": {"type": "number"},
                    "creator_user_id": {"type": "string"},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "interrupt_request",
                    "interrupt_action",
                    "execution_type",
                    "length",
                    "n_items",
                    "pid",
                    "creator_user_id",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "process",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                    "text": {"type": "string"},
                    "status": {"type": "string"},
                    "error": {"type": "string"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "index",
                    "timestamp",
                    "start_position",
                    "end_position",
                    "text",
                    "status",
                    "error",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "file_list",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "n_items": {"type": "number"},
                    "length": {"type": "number"},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "n_items",
                    "length",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "file",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "index": {"type": "number"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                    "location": {"type": "string"},
                },
                "required": [
                    "name",
                    "index",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "start_position",
                    "end_position",
                    "location",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "embedding_list",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "n_items": {"type": "number"},
                    "length": {"type": "number"},
                    "n_dim": {"type": "number"},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "n_items",
                    "length",
                    "n_dim",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "embedding",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "index": {"type": "number"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                },
                "patternProperties": {
                    "^embedding_\d+$": {"type": "array", "items": {"type": "number"}}
                },
                "required": [
                    "name",
                    "index",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "start_position",
                    "end_position",
                ],
                "additionalProperties": True,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "document_list",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "n_items": {"type": "number"},
                    "length": {"type": "number"},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "n_items",
                    "length",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )
    create_collection_safe(
        db,
        "document",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "index": {"type": "number"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                    "text": {"type": "string"},
                },
                "required": [
                    "name",
                    "index",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "start_position",
                    "end_position",
                    "text",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "record_list",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "n_items": {"type": "number"},
                    "length": {"type": "number"},
                    "column_names": {"type": "array", "items": {"type": "string"}},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "name",
                    "process_name",
                    "process_index",
                    "timestamp",
                    "n_items",
                    "length",
                    "column_names",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "record",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "index": {"type": "number"},
                    "timestamp": {"type": "number"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                    "data": {"type": ["object", "null"]},
                    "data_text": {"type": ["string", "null"]},
                    "column_names": {"type": "array", "items": {"type": "string"}},
                },
                "required": [
                    "name",
                    "index",
                    "timestamp",
                    "process_name",
                    "process_index",
                    "start_position",
                    "end_position",
                    "data",
                    "data_text",
                    "column_names",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "description",
        {
            "rule": {
                "properties": {
                    "name": {"type": "string"},
                    "item_name": {"type": "string"},
                    "process_name": {"type": "string"},
                    "process_index": {"type": "number"},
                    "collection": {"type": "string"},
                    "timestamp": {"type": "number"},
                    "text": {"type": "string"},
                    "embedding": {"type": "array", "items": {"type": "number"}},
                    "deleted": {"type": "number"},
                },
                "required": [
                    "item_name",
                    "name",
                    "process_name",
                    "process_index",
                    "collection",
                    "timestamp",
                    "text",
                    "embedding",
                    "deleted",
                ],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "parent_edge",
        edge=True,
        schema={
            "rule": {
                "properties": {
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                },
                "required": ["timestamp", "start_position", "end_position"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "dependency_edge",
        edge=True,
        schema={
            "rule": {
                "properties": {
                    "timestamp": {"type": "number"},
                    "start_position": {"type": "number"},
                    "end_position": {"type": "number"},
                },
                "required": ["timestamp", "start_position", "end_position"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "description_edge",
        edge=True,
        schema={
            "rule": {
                "properties": {
                    "timestamp": {"type": "number"},
                },
                "required": ["timestamp"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "process_parent_edge",
        edge=True,
        schema={
            "rule": {
                "properties": {
                    "timestamp": {"type": "number"},
                    "index": {"type": "number"},
                },
                "required": ["timestamp", "index"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    create_collection_safe(
        db,
        "deleted_process_parent_edge",
        edge=True,
        schema={
            "rule": {
                "properties": {
                    "timestamp": {"type": "number"},
                    "index": {"type": "number"},
                },
                "required": ["timestamp", "index"],
                "additionalProperties": False,
            },
            "level": "strict",
        },
    )

    def add_edge_def(edge_col: str, from_cols: List[str], to_cols: List[str]) -> None:
        if graph.has_edge_definition(edge_col):
            pass
        else:
            graph.create_edge_definition(
                edge_collection=edge_col,
                from_vertex_collections=from_cols,
                to_vertex_collections=to_cols,
            )

    add_edge_def(
        "dependency_edge", DESCRIPTION_COLLECTIONS, VIEW_COLLECTIONS
    )  # input_list -> item (checked)
    add_edge_def(
        "deleted_process_parent_edge", ["process_list"], DESCRIPTION_COLLECTIONS
    )
    add_edge_def(
        "process_parent_edge", ["process_list"], ALL_ITEM_COLLECTIONS
    )  # process_list -> item (checked)
    add_edge_def(
        "description_edge", DESCRIPTION_COLLECTIONS, ["description"]
    )  # item_list -> description (checked)
    add_edge_def(
        "parent_edge", DESCRIPTION_COLLECTIONS, VIEW_COLLECTIONS
    )  # item_list -> item (checked)
    create_tablevault_query_views(db, description_embedding_size)
