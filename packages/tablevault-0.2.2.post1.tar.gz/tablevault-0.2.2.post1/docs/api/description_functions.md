# Description API Reference

Description operations are currently documented in the main API page:

- `create_description` in `docs/api/core_api.md`
- `query_item_description` in `docs/api/core_api.md`

This page is reserved for a dedicated description-focused API reference in a future update.
