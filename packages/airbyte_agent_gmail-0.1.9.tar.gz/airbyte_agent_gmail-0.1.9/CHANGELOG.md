# Gmail changelog

## [0.1.9] - 2026-02-26
- Updated connector definition (YAML version 0.1.2)
- Source commit: 9072a725
- SDK version: 0.1.0

## [0.1.8] - 2026-02-23
- Updated connector definition (YAML version 0.1.2)
- Source commit: 62fbfc1f
- SDK version: 0.1.0

## [0.1.7] - 2026-02-20
- Updated connector definition (YAML version 0.1.2)
- Source commit: cb4380e7
- SDK version: 0.1.0

## [0.1.6] - 2026-02-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: 7cda3ed1
- SDK version: 0.1.0

## [0.1.5] - 2026-02-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: 3f4da97b
- SDK version: 0.1.0

## [0.1.4] - 2026-02-11
- Updated connector definition (YAML version 0.1.2)
- Source commit: 9ee3d6a8
- SDK version: 0.1.0

## [0.1.3] - 2026-02-11
- Updated connector definition (YAML version 0.1.1)
- Source commit: d14a5853
- SDK version: 0.1.0

## [0.1.2] - 2026-02-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 8c602f77
- SDK version: 0.1.0

## [0.1.1] - 2026-02-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 114c9599
- SDK version: 0.1.0

## [0.1.0] - 2026-02-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 7c00a573
- SDK version: 0.1.0
