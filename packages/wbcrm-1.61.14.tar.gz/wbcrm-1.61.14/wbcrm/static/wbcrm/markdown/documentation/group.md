# Groups
This is a list of every group in the database where you can modify, delete and add new groups. Typing in the search field or the column filter accessible from the three lines at the end of the column title filters the groups by name. Click on the column title to order it.
