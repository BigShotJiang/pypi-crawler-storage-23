import os
import json
import pathlib
from typing import Dict, Any, List, Optional, Callable


import subprocess
import threading
import uuid
from typing import Dict, Any, List, Optional, Callable, Union
import concurrent.futures
import requests

import asyncio
import threading
from contextlib import AsyncExitStack

class AsyncMCPManager:
    """Bridges synchronous thread executions into native asynchronous MCP Contexts."""
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        
        self.sessions = {}
        self.exit_stacks = {}
        self.available_tools = {} # server_id -> list of tool dicts
        self.routing = {} # tool_name -> server_id

    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def connect_server(self, server_id: str, command: List[str]) -> int:
        future = asyncio.run_coroutine_threadsafe(self._connect_async(server_id, command), self.loop)
        return future.result(timeout=20)
        
    async def _connect_async(self, server_id: str, command: List[str]) -> int:
        from mcp import ClientSession
        
        stack = AsyncExitStack()
        self.exit_stacks[server_id] = stack
        
        if len(command) == 1 and command[0].startswith("http"):
            from mcp.client.sse import sse_client
            read_stream, write_stream = await stack.enter_async_context(sse_client(command[0]))
        else:
            from mcp.client.stdio import stdio_client, StdioServerParameters
            server_params = StdioServerParameters(command=command[0], args=command[1:])
            read_stream, write_stream = await stack.enter_async_context(stdio_client(server_params))
            
        session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()
        
        self.sessions[server_id] = session
        
        # Get tools natively
        response = await session.list_tools()
        tools_list = []
        for tool in response.tools:
            schema = tool.inputSchema if hasattr(tool, 'inputSchema') else getattr(tool, 'input_schema', {})
            tool_dict = {
                "name": tool.name,
                "description": tool.description,
                "input_schema": schema
            }
            tools_list.append(tool_dict)
            self.routing[tool.name] = server_id
            
        self.available_tools[server_id] = tools_list
        return len(tools_list)

    def execute_tool(self, name: str, arguments: dict) -> str:
        server_id = self.routing.get(name)
        if not server_id:
            return f"Error: Tool {name} not found."
            
        future = asyncio.run_coroutine_threadsafe(
            self.sessions[server_id].call_tool(name, arguments=arguments),
            self.loop
        )
        try:
            res = future.result(timeout=60)
            parts = []
            for item in res.content:
                if item.type == "text":
                    parts.append(item.text)
            return "\n".join(parts)
        except Exception as e:
            return f"MCP Error: {str(e)}"

    def stop(self):
        for server_id, stack in self.exit_stacks.items():
            try:
                asyncio.run_coroutine_threadsafe(stack.aclose(), self.loop).result(timeout=5)
            except:
                pass
        self.loop.call_soon_threadsafe(self.loop.stop)


class AgentManager:
    """
    SOTA Agent Manager for Xoron-Dev.
    Provides the model with direct filesystem access and MCP tool orchestration.
    """
    def __init__(self, workspace_dir: str = "."):
        self.workspace_dir = pathlib.Path(workspace_dir).absolute()
        self.tools: Dict[str, Callable] = {}
        self.mcp = AsyncMCPManager()
        self._register_default_tools()

    def connect_mcp(self, server_id: str, command: List[str]):
        """Connects to an MCP server (stdio via list, or HTTP via single string url) and maps its tools."""
        return self.mcp.connect_server(server_id, command)

    def get_all_tool_definitions(self) -> List[Dict]:
        """Returns a list of tool schema dicts for the system prompt."""
        defs = []
        # Local Tools
        defs.append({"name": "read_file", "description": "Read file contents", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}})
        defs.append({"name": "write_file", "description": "Write text to file", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}})
        defs.append({"name": "list_dir", "description": "List directory", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}})
        defs.append({"name": "edit_file", "description": "String replacement in file", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "old_text": {"type": "string"}, "new_text": {"type": "string"}}, "required": ["path", "old_text", "new_text"]}})
        
        # MCP Tools
        for tools in self.mcp.available_tools.values():
            defs.extend(tools)

        return defs

    def get_tool_prompt(self) -> str:
        """Format total tool definitions as a string using model special tokens."""
        tools = self.get_all_tool_definitions()
        
        lines = ["<|available_tools|>"]
        for tool in tools:
            lines.append(f"<|tool_def|>")
            lines.append(f"<|tool_name|>{tool.get('name', 'unknown')}<|/tool_name|>")
            lines.append(f"<|tool_desc|>{tool.get('description', '')}<|/tool_desc|>")
            lines.append(f"<|tool_params|>")
            
            # Map MCP JSONSchema format
            props = tool.get("input_schema", {}).get("properties", {})
            required_fields = tool.get("input_schema", {}).get("required", [])
            for pname, pinfo in props.items():
                req = "<|param_required|>" if pname in required_fields else "<|param_optional|>"
                ptype = pinfo.get("type", "string")
                lines.append(f"<|param_name|>{pname}<|/param_name|><|param_type|>{ptype}<|/param_type|>{req}")
                
            lines.append(f"<|/tool_params|>")
            lines.append(f"<|/tool_def|>")
        lines.append("<|/available_tools|>")
        return "\n".join(lines)


    def _register_default_tools(self):
        """Registers core agentic tools."""
        self.register_tool("read_file", self.read_file)
        self.register_tool("write_file", self.write_file)
        self.register_tool("list_dir", self.list_dir)
        self.register_tool("edit_file", self.edit_file)

    def register_tool(self, name: str, func: Callable):
        self.tools[name] = func

    # --- Filesystem Tools ---

    def read_file(self, path: str) -> str:
        full_path = self.workspace_dir / path
        if not full_path.exists():
            return f"Error: File {path} does not exist."
        return full_path.read_text()

    def write_file(self, path: str, content: str) -> str:
        full_path = self.workspace_dir / path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content)
        return f"Successfully wrote to {path}"

    def list_dir(self, path: str = ".") -> List[str]:
        full_path = self.workspace_dir / path
        return [str(p.relative_to(self.workspace_dir)) for p in full_path.iterdir()]

    def edit_file(self, path: str, old_text: str, new_text: str) -> str:
        full_path = self.workspace_dir / path
        if not full_path.exists():
            return f"Error: File {path} does not exist."
        content = full_path.read_text()
        if old_text not in content:
            return f"Error: Original text segment not found in {path}."
        new_content = content.replace(old_text, new_text)
        full_path.write_text(new_content)
        return f"Successfully edited {path}"
