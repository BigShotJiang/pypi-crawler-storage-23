# Welcome to Xoron-Dev Documentation

This is the central hub for learning about the architecture and usage of the Xoron-Dev Multimodal model.

## Core Features
1. **Dynamic Streaming:** Real-time binary audio protocols for 0-latency voice mapping.
2. **MoE Agentic Architecture:** Integrated deep-tool routing utilizing specialized mixture-of-experts.
3. **Omnimodal Execution:** Run image, video, text, and audio tasks interactively in a single context window.

> [!NOTE]
> Select a topic from the sidebar to dive deeper into the technical specifications!
