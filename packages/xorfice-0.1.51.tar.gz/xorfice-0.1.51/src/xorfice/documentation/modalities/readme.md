# Modalities Guide

Xoron-Dev supports parallel modality inference natively out of the box using discrete token interleaving.

## Text
Standard LLM auto-regressive generation.

## Image `<|generate_image|>`
Powered by the MoE-DiT network, flow matching allows latent generation at 1024x1024 resolution.

## Audio `<|speech_to_speech|>`
Continuous low latency streaming audio inference using integrated VAD and explicit waveform codecs.
