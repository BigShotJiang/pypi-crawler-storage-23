"""Tests for tsumugi.persona module."""

from tsumugi.config import build_config
from tsumugi.persona import DEFAULT_PERSONA, build_system_prompt


class TestDefaultPersona:
    def test_has_placeholder(self):
        assert "{user_name}" in DEFAULT_PERSONA

    def test_contains_key_phrases(self):
        assert "つむぎ" in DEFAULT_PERSONA
        assert "先輩" in DEFAULT_PERSONA
        assert "一人称" in DEFAULT_PERSONA


class TestBuildSystemPrompt:
    def test_replaces_user_name(self):
        config = build_config(cli_provider="anthropic")
        prompt = build_system_prompt(config)
        # Default user_name is "user" or whatever config.json has
        assert "{user_name}" not in prompt

    def test_contains_persona(self):
        config = build_config(cli_provider="anthropic")
        prompt = build_system_prompt(config)
        assert "つむぎ" in prompt

    def test_contains_runtime_context(self):
        config = build_config(cli_provider="anthropic")
        prompt = build_system_prompt(config)
        assert "実行環境" in prompt
        assert "作業ディレクトリ" in prompt

    def test_includes_instructions(self):
        config = build_config(cli_provider="anthropic")
        config.instructions = ["テスト用の指示です"]
        prompt = build_system_prompt(config)
        assert "テスト用の指示です" in prompt
        assert "TSUMUGI.md" in prompt

    def test_includes_memory(self):
        config = build_config(cli_provider="anthropic")
        config.memory = "# テストメモリ\nこれはテストです"
        prompt = build_system_prompt(config)
        assert "テストメモリ" in prompt
        assert "MEMORY.md" in prompt

    def test_custom_user_name(self):
        config = build_config(cli_provider="anthropic")
        config.user_name = "taro"
        prompt = build_system_prompt(config)
        assert "taro先輩" in prompt
