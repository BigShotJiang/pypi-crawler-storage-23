"""Tests for tsumugi.permissions module."""

from tsumugi.permissions import PermissionManager
from tsumugi.tools.base import PermissionLevel


class TestPermissionManager:
    def test_read_always_allowed(self):
        pm = PermissionManager()
        assert pm.check("read_file", PermissionLevel.READ, "") is True

    def test_session_allow(self):
        pm = PermissionManager()
        # Manually add to always_allowed (simulating user pressing 'a')
        pm._always_allowed.add("write_file")
        assert pm.check("write_file", PermissionLevel.WRITE, "") is True

    def test_persistent_allow(self):
        pm = PermissionManager()
        # Manually add to persistent (simulating user pressing 'p')
        pm._persistent_allowed.add("shell")
        assert pm.check("shell", PermissionLevel.EXECUTE, "") is True

    def test_multiple_read_tools(self):
        pm = PermissionManager()
        for tool in ["read_file", "glob_search", "grep_search", "list_directory"]:
            assert pm.check(tool, PermissionLevel.READ, "") is True
