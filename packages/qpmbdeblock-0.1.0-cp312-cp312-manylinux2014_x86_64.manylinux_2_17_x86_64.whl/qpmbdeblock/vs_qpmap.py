from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


def _load_mkv(core: "object", path: str) -> "object":  # vs.VideoNode
    """Load via bestsource, ffms2 or lsmas, whichever is installed first."""
    import vapoursynth as vs

    if hasattr(core, "bs"):
        clip = core.bs.VideoSource(path, fpsnum=-1)
    elif hasattr(core, "ffms2"):
        clip = core.ffms2.Source(path)
    elif hasattr(core, "lsmas"):
        clip = core.lsmas.Source(path)
    else:
        raise RuntimeError(
            "[qpmap] No source plugin found. Install bestsource, ffms2 or lsmas."
        )

    return core.resize.Point(clip, format=vs.GRAY8)


def VSqpmap_mask(
    input_video: str,
    qpmap_path: Optional[str] = None,
    ffmpeg_path: str = "ffmpeg",
    high_bitdepth: bool = True,
    scale_video: bool = True,
    reference_clip: Optional["object"] = None,  # vs.VideoNode
) -> "object":  # vs.VideoNode
    """
    Load (or generate) a QP map as a VapourSynth VideoNode.

    Parameters
    ----------
    input_video    : Path to the source H.264 video.
    qpmap_path     : Path to the qpmap MKV file.
                     Defaults to `<stem>.qpmap.mkv` next to the source file.
    ffmpeg_path    : Path to the ffmpeg executable (used only during generation).
    high_bitdepth  : If True (default), output in GRAY16, values stay 0-63.
    scale_video    : If True (default), upscale the QP map 16x via Point resize
                     then crop it to match `reference_clip` dimensions.
                     Requires `reference_clip` to be provided.
    reference_clip : A VapourSynth VideoNode used as crop reference when
                     `scale_video=True`. Must be the post-upscale source clip.

    Returns
    -------
    vs.VideoNode  GRAY8 or GRAY16, cropped to reference dimensions if scale_video.
    """
    import vapoursynth as vs

    core = vs.core

    input_path = Path(input_video).resolve()

    if qpmap_path is None:
        qpmap_path = str(input_path.parent / f"{input_path.stem}.qpmap.mkv")
    qpmap_path = str(Path(qpmap_path).resolve())

    # Generate if missing
    if not os.path.isfile(qpmap_path):
        print(f"[qpmap] Generating QP map: {qpmap_path}")
        from .qpmap_native import h264QPparser

        parser = h264QPparser(str(input_path), ffmpeg_path=ffmpeg_path)
        result = parser.create_qp_map(qpmap_path)
        if result is None:
            raise RuntimeError(f"[qpmap] Failed to generate QP map for: {input_path}")
        print(f"[qpmap] QP map created: {qpmap_path}")
    else:
        print(f"[qpmap] Loading QP map: {qpmap_path}")

    clip = _load_mkv(core, qpmap_path)  # GRAY8

    if scale_video:
        if reference_clip is None:
            raise ValueError(
                "[qpmap] scale_video=True requires a reference_clip VideoNode."
            )

        ref_w = reference_clip.width
        ref_h = reference_clip.height

        scaled_w = clip.width * 16
        scaled_h = clip.height * 16

        clip = core.resize.Point(clip, width=scaled_w, height=scaled_h)

        crop_right = scaled_w - ref_w
        crop_bottom = scaled_h - ref_h

        if crop_right < 0 or crop_bottom < 0:
            raise ValueError(
                f"[qpmap] Scaled QP map ({scaled_w}×{scaled_h}) is smaller than "
                f"reference ({ref_w}×{ref_h}). Check that the reference clip is "
                f"the post-upscale version of the video."
            )

        clip = core.std.Crop(clip, right=crop_right, bottom=crop_bottom)

    if high_bitdepth:
        clip = core.resize.Point(clip, format=vs.GRAY16)

    return clip
