from __future__ import annotations

import glob
import os
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import numpy as np

# Windows DLL setup – must run before qp_extractor (.pyd) is imported
_HERE = Path(__file__).parent.resolve()

if sys.platform == "win32":
    _ffmpeg_bin: str | None = None
    _ffmpeg_exe = shutil.which("ffmpeg")
    if _ffmpeg_exe:
        _ffmpeg_bin = os.path.dirname(_ffmpeg_exe)

    if _ffmpeg_bin:
        try:
            os.add_dll_directory(_ffmpeg_bin)
        except AttributeError:
            os.environ["PATH"] = _ffmpeg_bin + os.pathsep + os.environ.get("PATH", "")

if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

try:
    from . import qp_extractor as _ext
except ImportError:
    try:
        import qp_extractor as _ext
    except ImportError as _e:
        raise ImportError(
            f"Cannot import qp_extractor native extension ({_e}).\n"
            f"Make sure to install the package first:  pip install ."
        ) from _e


def _get_video_info(
    video_path: str,
    ffmpeg_path: str = "ffmpeg",
) -> tuple[float, int | None]:

    ffprobe = (
        ffmpeg_path.replace("ffmpeg.exe", "ffprobe.exe")
        if ffmpeg_path.endswith(".exe")
        else ffmpeg_path.replace("ffmpeg", "ffprobe")
    )

    fps: float = 0.0
    n_frames: int | None = None

    print("[qpmap] Probing video metadata...")

    try:
        from fractions import Fraction

        probe2 = subprocess.run(
            [
                ffprobe,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=r_frame_rate,nb_frames:stream_tags=NUMBER_OF_FRAMES",
                "-of",
                "default=noprint_wrappers=1",
                video_path,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        for line in probe2.stdout.splitlines():
            k, _, v = line.partition("=")
            if k == "r_frame_rate" and v and fps == 0.0:
                try:
                    fps = float(Fraction(v.strip()))
                except Exception:
                    pass
            elif k == "nb_frames" and v and v.strip().isdigit() and n_frames is None:
                try:
                    n_frames = int(v.strip())
                except Exception:
                    pass
            elif k == "TAG:NUMBER_OF_FRAMES" and v and n_frames is None:
                try:
                    n_frames = int(v.strip())
                except Exception:
                    pass
    except Exception as e:
        print(f"[qpmap] Metadata reading exception: {e}")

    if fps == 0.0:
        fps = 24000 / 1001
        print("[qpmap] WARNING: could not detect FPS, defaulting to 23.976")

    return fps, n_frames


def extract_qpmap_parallel(
    input_video: str,
    ffmpeg_path: str = "ffmpeg",
    segment_duration: float = 10.0,
    max_workers: Optional[int] = None,
    keep_segments: bool = False,
) -> tuple[np.ndarray, float]:
    """
    Extract the QP macroblock map for an entire video in parallel.

    Parameters
    ----------
    input_video      : path to the input video (H.264 encoded)
    ffmpeg_path      : path to ffmpeg executable (ffprobe is auto-derived)
    segment_duration : seconds per segment for splitting (default 10 s)
    max_workers      : thread pool size; default = min(4, cpu_count)
    keep_segments    : if True, temp segment files are NOT deleted (debug)

    Returns
    -------
    (qpmap, fps)
        qpmap : numpy.ndarray shape (n_frames, mb_rows, mb_cols), dtype int8
                QP values 0-63
        fps   : float, frame rate detected from the source video
    """
    input_video = str(Path(input_video).resolve())
    if not os.path.isfile(input_video):
        raise FileNotFoundError(f"Input video not found: {input_video}")

    fps, expected_frames = _get_video_info(input_video, ffmpeg_path)
    print(f"[qpmap] Source: fps={fps:.4f}, expected_frames={expected_frames}")

    tmpdir = Path(tempfile.mkdtemp(prefix="qpmap_segs_"))
    t0 = time.time()

    try:
        seg_pattern = str(tmpdir / "seg_%05d.mkv")
        split_cmd = [
            ffmpeg_path,
            "-y",
            "-i",
            input_video,
            "-map",
            "0:v",
            "-f",
            "segment",
            "-segment_time",
            str(segment_duration),
            "-c",
            "copy",
            "-reset_timestamps",
            "1",
            "-avoid_negative_ts",
            "1",
            seg_pattern,
        ]
        print(f"[qpmap] Splitting into ~{segment_duration}s segments …")
        ret = subprocess.run(
            split_cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        if ret.returncode != 0:
            raise RuntimeError(
                f"FFmpeg segment split failed (exit {ret.returncode}):\n{ret.stderr[-2000:]}"
            )

        segments = sorted(glob.glob(str(tmpdir / "seg_*.mkv")))
        if not segments:
            raise RuntimeError(
                "No segments produced. Check ffmpeg output:\n" + ret.stderr[-1000:]
            )
        print(f"[qpmap] {len(segments)} segment(s) produced")

        _cpu = os.cpu_count() or 4
        workers = max_workers if max_workers is not None else min(4, _cpu)
        results: list[Optional[np.ndarray]] = [None] * len(segments)

        def _worker(task):
            idx, seg_path = task
            arr = _ext.extract_qpmap(seg_path)
            return idx, arr

        print(f"[qpmap] Extracting QP with {workers} worker(s) …")
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(_worker, (i, seg)): i for i, seg in enumerate(segments)
            }
            for future in as_completed(futures):
                i, arr = future.result()
                results[i] = arr
                qp_valid = arr[arr >= 0]
                print(
                    f"[qpmap]   segment {i + 1:>3}/{len(segments)}"
                    f"  →  shape {arr.shape}"
                    f"  QP {int(qp_valid.min()) if qp_valid.size else '?'}"
                    f"–{int(arr.max())}"
                )

        # concatenate in order
        full = np.concatenate(results, axis=0)  # type: ignore[arg-type]
        got_frames = full.shape[0]
        print(f"[qpmap] Full array: shape={full.shape}, dtype={full.dtype}")

        # Frame count check
        if expected_frames is not None:
            if got_frames == expected_frames:
                print(f"[qpmap] Frame check OK: {got_frames} frames")
            else:
                print(
                    f"[qpmap] Frame count mismatch: "
                    f"source={expected_frames}, extracted={got_frames} "
                    f"(diff={got_frames - expected_frames:+d}). "
                    f"This can happen at segment boundaries; data is still usable."
                    f"The video may be corrupted, but still usable."
                )

        t_total = time.time() - t0
        print(
            f"[qpmap] Extraction complete in {t_total:.2f}s "
            f"({got_frames / t_total:.1f} fps)"
        )

        return full, fps

    finally:
        if not keep_segments:
            shutil.rmtree(tmpdir, ignore_errors=True)


# Grayscale FFV1 video output
def write_qpmap_video(
    qpmap: np.ndarray,
    output_path: str,
    fps: float,
    ffmpeg_path: str = "ffmpeg",
    expected_frames: int | None = None,
) -> None:
    """
    Write a QP map array to a grayscale FFV1-encoded MKV.

    Parameters
    ----------
    qpmap          : np.ndarray shape (n_frames, mb_rows, mb_cols) int8 array
    output_path    : str destination .mkv path
    fps            : float frame rate — MUST match the source video exactly
    ffmpeg_path    : str path to ffmpeg executable
    expected_frames: int | None (optional) verifying video frames
    """
    if qpmap.ndim != 3:
        raise ValueError(f"Expected 3-D array (frames, mb_h, mb_w), got {qpmap.ndim}-D")

    n_frames, mb_rows, mb_cols = qpmap.shape

    h = mb_rows
    w = mb_cols

    # Stream raw grayscale directly into FFmpeg (FFV1, lossless) via stdin.
    try:
        print(
            f"[qpmap] Writing {n_frames} frames ({w}×{h} px, "
            f"fps={fps:.4f})  [Streaming direct to FFV1 MKV] …"
        )
        t_write = time.time()

        ffmpeg_cmd = [
            ffmpeg_path,
            "-y",
            "-f",
            "rawvideo",
            "-pixel_format",
            "gray",
            "-video_size",
            f"{w}x{h}",
            "-framerate",
            str(fps),
            "-color_range",
            "pc",
            "-i",
            "-",
            "-c:v",
            "ffv1",
            "-level",
            "3",
            "-color_range",
            "pc",
            output_path,
        ]

        proc = subprocess.Popen(
            ffmpeg_cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
        )

        chunk_size = 500
        try:
            for start_idx in range(0, n_frames, chunk_size):
                end_idx = min(start_idx + chunk_size, n_frames)
                chunk = qpmap[start_idx:end_idx]

                chunk_u8 = np.clip(chunk, 0, 63).astype(np.uint8)

                if proc.stdin:
                    proc.stdin.write(chunk_u8.tobytes())
                print(f"[qpmap]   stream: {end_idx}/{n_frames} frames")
        finally:
            if proc.stdin:
                proc.stdin.close()

        _, stderr_data = proc.communicate()

        if proc.returncode != 0:
            stderr_text = stderr_data.decode("utf-8", errors="replace")
            raise RuntimeError(
                f"FFmpeg encode failed (exit {proc.returncode}):\n{stderr_text[-2000:]}"
            )

        t_done = time.time()
        print(f"[qpmap] FFmpeg encode finished in {t_done - t_write:.2f}s. ")
        print(f"[qpmap] Done → {output_path}")

    except Exception as e:
        print(f"[qpmap] Error during stream: {e}")
        raise


class h264QPparser:
    """
    A unified class interface for extracting QP maps from H.264 videos.
    """

    def __init__(self, input_video: str, ffmpeg_path: str = "ffmpeg"):
        self.input_video = input_video
        self.ffmpeg_path = ffmpeg_path
        self._fps, self._expected_frames = _get_video_info(input_video, ffmpeg_path)

    def extract(
        self,
        segment_duration: float = 10.0,
        max_workers: int | None = None,
        keep_segments: bool = False,
    ) -> np.ndarray:
        """
        Extract the QP map as an int8 NumPy array (n_frames, mb_rows, mb_cols).
        """
        arr, fps = extract_qpmap_parallel(
            input_video=self.input_video,
            ffmpeg_path=self.ffmpeg_path,
            segment_duration=segment_duration,
            max_workers=max_workers,
            keep_segments=keep_segments,
        )
        self._fps = fps
        return arr

    def write_video(self, qpmap: np.ndarray, output_path: str) -> None:
        """
        Export the QP map array to a grayscale FFV1 MKV video.
        """
        if self._fps == 0.0:
            self._fps = 24.0

        write_qpmap_video(
            qpmap=qpmap,
            output_path=output_path,
            fps=self._fps,
            ffmpeg_path=self.ffmpeg_path,
            expected_frames=self._expected_frames,
        )

    def create_qp_map(
        self,
        output_path: str,
        segment_duration: float = 10.0,
        max_workers: int | None = None,
        keep_segments: bool = False,
    ) -> str | None:
        """
        Extract the QP map and immediately write it to an FFV1 video file.
        Returns the output path if successful, or None if an error occurred.
        """
        try:
            qpmap = self.extract(
                segment_duration=segment_duration,
                max_workers=max_workers,
                keep_segments=keep_segments,
            )
            self.write_video(qpmap=qpmap, output_path=output_path)
            return output_path
        except Exception as e:
            print(f"[qpmap] Failed to create QP map: {e}")
            return None
