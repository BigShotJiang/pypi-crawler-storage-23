# -*- coding: utf-8 -*-
"""
Created on Sat Jan 31 20:06:48 2026

@author: Afreen Aman
"""

from typing import TypedDict, Optional, List

class InputState(TypedDict):
    raw_text: str
    clean_text: Optional[str]
    language: Optional[str]
    quality_score: Optional[float]

class ClassificationState(TypedDict):
    envbert_label: Optional[str]
    envbert_confidence: Optional[float]
    llm_label: Optional[str]
    llm_confidence: Optional[float]
    final_label: Optional[str]
    final_confidence: Optional[float]
    route: Optional[str]

class MetaState(TypedDict):
    decision_trace: Optional[str]
    reasoning: Optional[str]
    key_phrases: Optional[List[str]]

class MonitoringState(TypedDict):
    drift_flag: Optional[bool]

class EnvBertState(TypedDict):
    input: InputState
    classification: ClassificationState
    meta: MetaState
    monitoring: MonitoringState
