# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:49:59 2026

@author: Afreen Aman
"""


from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.llm_fallback import LLMFallbackAgent
from envbert_agent.agents.llm_adapter import LLMAdapter
from envbert_agent.config import LLMConfig


def llm_node_factory(config: LLMConfig):
    adapter = LLMAdapter(config)
    agent = LLMFallbackAgent(adapter)

    def llm_node(state: EnvBertState) -> EnvBertState:
        return agent(state)

    return llm_node
