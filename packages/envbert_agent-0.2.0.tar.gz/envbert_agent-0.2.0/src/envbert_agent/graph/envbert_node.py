# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:47:41 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.envbert_backbone import classify_with_envbert


def envbert_node(state: EnvBertState) -> EnvBertState:
    # 1. Extract clean text from preprocessing output
    text = state["input"].get("clean_text")

    if not isinstance(text, str) or not text.strip():
        raise ValueError("EnvBert node requires non-empty clean_text")

    # 2. Run EnvBert backbone
    result = classify_with_envbert(text)

    # 3. Store results back into state
    state["classification"]["envbert_label"] = result["label"]
    state["classification"]["envbert_confidence"] = result["confidence"]

    return state
