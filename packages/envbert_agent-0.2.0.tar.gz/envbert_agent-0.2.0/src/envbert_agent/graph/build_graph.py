# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:52:09 2026

@author: Afreen Aman
"""

from langgraph.graph import StateGraph, END

from envbert_agent.graph.state import EnvBertState
from envbert_agent.graph.preprocessing_node import preprocessing_node
from envbert_agent.graph.envbert_node import envbert_node
from envbert_agent.graph.arbitration_node import arbitration_node
from envbert_agent.graph.evaluation_node import evaluation_node
from envbert_agent.graph.explainability_node import explainability_node
from envbert_agent.graph.monitoring_node import monitoring_node
from envbert_agent.graph.llm_node import llm_node_factory

from envbert_agent.config import LLMConfig


def build_app(llm_config: LLMConfig):
    graph = StateGraph(EnvBertState)

    graph.add_node("preprocess", preprocessing_node)
    graph.add_node("envbert", envbert_node)
    graph.add_node("arbitrate", arbitration_node)
    graph.add_node("llm", llm_node_factory(llm_config))
    graph.add_node("evaluate", evaluation_node)
    graph.add_node("explain", explainability_node)
    graph.add_node("monitor", monitoring_node)

    graph.set_entry_point("preprocess")

    graph.add_edge("preprocess", "envbert")
    graph.add_edge("envbert", "arbitrate")

    graph.add_conditional_edges(
        "arbitrate",
        lambda s: s["classification"]["route"],
        {
            "accept": "evaluate",
            "llm": "llm",
            "review": "monitor",
        },
    )

    graph.add_edge("llm", "evaluate")
    graph.add_edge("evaluate", "explain")
    graph.add_edge("explain", "monitor")
    graph.add_edge("monitor", END)

    return graph.compile()
