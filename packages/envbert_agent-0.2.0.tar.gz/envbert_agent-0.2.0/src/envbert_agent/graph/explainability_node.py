# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:51:12 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.explainability import explainability_agent


def explainability_node(state: EnvBertState) -> EnvBertState:
    return explainability_agent(state)
