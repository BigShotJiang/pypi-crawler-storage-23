# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:48:52 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.arbitration import arbitration_agent


def arbitration_node(state: EnvBertState) -> EnvBertState:
    return arbitration_agent(state)
