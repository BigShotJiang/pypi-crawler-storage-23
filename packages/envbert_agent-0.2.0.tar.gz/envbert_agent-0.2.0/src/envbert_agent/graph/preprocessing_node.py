# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 19:46:23 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.preprocessing import preprocess_text


def preprocessing_node(state: EnvBertState) -> EnvBertState:
    raw_text = state["input"]["raw_text"]

    result = preprocess_text(raw_text)

    state["input"]["clean_text"] = result["clean_text"]
    state["input"]["language"] = result["language"]
    state["input"]["quality_score"] = result["quality_score"]

    return state