# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 17:45:53 2026

@author: Afreen Aman
"""

"""
EnvBert Agentic Pipeline Assembly

This module defines the public factory function `build_app`
which wires agents and graph nodes into a LangGraph application.
"""

from langgraph.graph import StateGraph, END

from envbert_agent.state import EnvBertState
from envbert_agent.config import LLMConfig

# Agents
from envbert_agent.agents.llm_adapter import LLMAdapter
from envbert_agent.agents.llm_fallback import LLMFallbackAgent

# Graph nodes
from envbert_agent.graph.preprocessing_node import preprocessing_node
from envbert_agent.graph.envbert_node import envbert_node
from envbert_agent.graph.arbitration_node import arbitration_node
from envbert_agent.graph.llm_node import llm_node_factory
from envbert_agent.graph.evaluation_node import evaluation_node
from envbert_agent.graph.explainability_node import explainability_node
from envbert_agent.graph.monitoring_node import monitoring_node


from typing import Optional

from envbert_agent.config import LLMConfig
from envbert_agent.graph.build_graph import build_app
from envbert_agent.graph.state import EnvBertState


def run(
    text: str,
    llm_config: Optional[LLMConfig] = None,
) -> EnvBertState:
    """
    Public API to run the EnvBert LangGraph pipeline on input text.

    Parameters
    ----------
    text : str
        Input text to classify.
    llm_config : LLMConfig, optional
        Configuration for the fallback LLM provider.

    Returns
    -------
    EnvBertState
        Final graph state after execution.
    """

    config = llm_config or LLMConfig()
    app = build_app(config)

    initial_state: EnvBertState = {
        "input": {"raw_text": text},
        "classification": {},
        "meta": {},
        "monitoring": {},
    }

    return app.invoke(initial_state)
