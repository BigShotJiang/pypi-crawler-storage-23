import argparse
import json

from envbert_agent.app import run
from envbert_agent.config import LLMConfig


def main():
    parser = argparse.ArgumentParser(
        description="EnvBert Agentic AI Pipeline (CLI)"
    )

    parser.add_argument(
        "text",
        type=str,
        help="Input text to classify",
    )

    parser.add_argument(
        "--provider",
        type=str,
        default="ollama",
        choices=["ollama", "openai", "azure"],
        help="LLM provider for fallback",
    )

    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model name (optional)",
    )

    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print JSON output",
    )

    args = parser.parse_args()

    config = LLMConfig(
        provider=args.provider,
        model=args.model,
    )

    result = run(args.text, llm_config=config)

    if args.pretty:
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps(result))


if __name__ == "__main__":
    main()
