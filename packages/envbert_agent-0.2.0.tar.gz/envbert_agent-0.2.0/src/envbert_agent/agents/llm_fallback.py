# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 18:16:24 2026

@author: Afreen Aman
"""


import json
import re
import logging
from typing import Dict, Set

from envbert_agent.graph.state import EnvBertState
from envbert_agent.agents.llm_adapter import LLMAdapter

logger = logging.getLogger(__name__)


ALLOWED_CATEGORIES: Set[str] = {
    "Remediation Standards",
    "Extent of Contamination",
    "Depth to Water",
    "Groundwater–Surface Water Interaction",
    "GW Velocity",
    "Geology",
    "Contaminated Media",
    "Remediation Activities",
    "Remediation Goals",
    "Source of Contamination",
    "Contaminants",
    "Not Relevant",
}


class LLMFallbackAgent:
    """
    Semantic fallback classifier used when EnvBert
    confidence is insufficient.

    The LLM is strictly constrained to a fixed taxonomy.
    """

    def __init__(self, adapter: LLMAdapter):
        self.adapter = adapter

    def __call__(self, state: EnvBertState) -> EnvBertState:
        text = state["input"]["clean_text"]

        prompt = self._build_prompt(text)

        try:
            raw = self.adapter.invoke(prompt)
            parsed = self._parse_response(raw)

        except Exception as e:
            logger.warning(
                "LLM fallback classification failed",
                exc_info=True,
            )
            parsed = {
                "category": None,
                "confidence": 0.0,
                "reasoning": f"LLM fallback failed: {e}",
            }

        cls = state["classification"]
        meta = state["meta"]

        cls["llm_label"] = parsed["category"]
        cls["llm_confidence"] = parsed["confidence"]

        meta["llm_reasoning"] = parsed["reasoning"]
        meta["decision_trace"] = "LLM fallback"

        return state

    # -------------------------
    # Prompt
    # -------------------------
    def _build_prompt(self, text: str) -> str:
        categories = ", ".join(sorted(ALLOWED_CATEGORIES))

        return f"""
You are an environmental due-diligence text classifier.

Choose EXACTLY ONE category from the list below.
Do NOT invent new categories.

Allowed categories:
{categories}

Return ONLY valid JSON in this format:

{{
  "category": "<one of the allowed categories>",
  "confidence": <float between 0 and 1>,
  "reasoning": "<short technical justification>"
}}

TEXT:
\"\"\"{text}\"\"\"
""".strip()

    # -------------------------
    # Parsing & validation
    # -------------------------
    def _parse_response(self, raw) -> Dict:
        content = (
            raw.content
            if hasattr(raw, "content")
            else str(raw)
        )

        match = re.search(r"\{.*\}", content, re.DOTALL)
        if not match:
            raise ValueError("No JSON object detected")

        parsed = json.loads(match.group())

        category = parsed.get("category")
        if category not in ALLOWED_CATEGORIES:
            raise ValueError(f"Invalid category returned: {category}")

        return {
            "category": category,
            "confidence": float(parsed.get("confidence", 0.0)),
            "reasoning": parsed.get("reasoning"),
        }
