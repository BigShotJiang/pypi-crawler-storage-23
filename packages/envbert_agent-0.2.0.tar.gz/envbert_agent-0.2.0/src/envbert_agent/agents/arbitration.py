# -*- coding: utf-8 -*-
"""
Created on Fri Feb  6 16:16:17 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState

CONFIDENCE_THRESHOLD = 0.75 
QUALITY_THRESHOLD = 0.4 

def arbitration_agent(state: EnvBertState) -> EnvBertState: 
    input_state = state["input"] 
    cls = state["classification"] 
    if input_state["quality_score"] < QUALITY_THRESHOLD: 
        cls["route"] = "review" 
    elif cls["envbert_confidence"] >= CONFIDENCE_THRESHOLD:
        cls["route"] = "accept"
    else: cls["route"] = "llm" 
    return state