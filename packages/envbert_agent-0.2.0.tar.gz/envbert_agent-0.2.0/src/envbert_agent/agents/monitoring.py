# -*- coding: utf-8 -*-
"""
Created on Fri Feb  6 19:51:50 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState


def monitoring_agent(state: EnvBertState) -> EnvBertState:
    state["monitoring"]["drift_flag"] = (
        state["classification"]["final_confidence"] < 0.5
    )
    return state
