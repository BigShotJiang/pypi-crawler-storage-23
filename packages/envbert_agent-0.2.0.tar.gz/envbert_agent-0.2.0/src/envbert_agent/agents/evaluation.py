# -*- coding: utf-8 -*-
"""
Created on Fri Feb  6 19:47:03 2026

@author: Afreen Aman
"""

from envbert_agent.graph.state import EnvBertState

def evaluation_agent(state: EnvBertState) -> EnvBertState:
    cls = state["classification"]
    meta = state["meta"]

    if cls.get("llm_confidence", 0) > cls.get("envbert_confidence", 0):
        cls["final_label"] = cls["llm_label"]
        cls["final_confidence"] = cls["llm_confidence"]
        meta["decision_trace"] = "LLM fallback"
    else:
        cls["final_label"] = cls["envbert_label"]
        cls["final_confidence"] = cls["envbert_confidence"]
        meta["decision_trace"] = "EnvBert backbone"

    return state