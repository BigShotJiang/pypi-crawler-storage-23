# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 18:13:54 2026

@author: Afreen Aman
"""

# -*- coding: utf-8 -*-
"""
LLM Adapter for EnvBert-Agent

Initializes the appropriate LLM backend
based on the provided LLMConfig.
"""

import os
from typing import Any
from envbert_agent.config import LLMConfig


class LLMAdapter:
    """
    Adapter that initializes and invokes an LLM backend
    based on the provided configuration.

    This class contains NO task or classification logic.
    """

    def __init__(self, config: LLMConfig):
        self.config = config
        self.llm = self._initialize_llm()

    def _initialize_llm(self) -> Any:
        provider = self.config.provider.lower()

        # 🔹 OpenAI (direct OpenAI API)
        if provider == "openai":
            from langchain_openai import ChatOpenAI

            return ChatOpenAI(
                model=self.config.model or "gpt-4o-mini",
                temperature=0,
            )

        # 🔹 Azure OpenAI
        if provider == "azure":
            from langchain_openai import AzureChatOpenAI

            endpoint = (
                self.config.azure_endpoint
                or os.getenv("AZURE_OPENAI_ENDPOINT")
            )

            deployment = (
                self.config.azure_deployment
                or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
            )

            if not endpoint or not deployment:
                raise ValueError(
                    "Azure provider selected but AZURE_OPENAI_ENDPOINT "
                    "or AZURE_OPENAI_DEPLOYMENT_NAME not set."
                )

            return AzureChatOpenAI(
                azure_endpoint=endpoint,
                azure_deployment=deployment,
                api_version=self.config.azure_api_version,
                temperature=0,
            )

        # 🔹 Default: Local / Open-source (Ollama)
        from langchain_community.llms import Ollama

        return Ollama(
            model=self.config.model or "llama3",
            temperature=0,
        )

    def invoke(self, prompt: str) -> Any:
        """
        Invoke the underlying LLM with a prompt.
        """
        return self.llm.invoke(prompt)