# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 18:10:38 2026

@author: Afreen Aman
"""

from typing import Dict
from EnvBert.due_diligence import envbert_predict


def classify_with_envbert(text: str) -> Dict:
    """
    Classify text using the EnvBert backbone model.

    Parameters
    ----------
    text : str
        Preprocessed input text.

    Returns
    -------
    dict
        Dictionary with keys:
        - label
        - confidence
    """

    result = envbert_predict(text)

    if isinstance(result, list) and len(result) == 2:
        return {
            "label": result[0],
            "confidence": float(result[1]),
        }

    if isinstance(result, dict):
        return {
            "label": result.get("label"),
            "confidence": (
                result.get("relevancy")
                or result.get("confidence")
                or 0.0
            ),
        }

    return {
        "label": None,
        "confidence": 0.0,
    }
