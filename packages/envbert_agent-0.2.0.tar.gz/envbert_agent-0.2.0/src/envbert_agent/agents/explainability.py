# -*- coding: utf-8 -*-
"""
Created on Fri Feb  6 19:49:24 2026

@author: Afreen Aman
"""


from envbert_agent.graph.state import EnvBertState

STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "in", "on", "at",
    "to", "for", "with", "by", "from",
    "was", "were", "is", "are", "be", "been", "being",
    "only", "that", "this", "these", "those"
}


def explainability_agent(state: EnvBertState) -> EnvBertState:
    meta = state["meta"]
    cls = state["classification"]

    words = state["input"]["clean_text"].lower().split()
    meta["key_phrases"] = [
    w for w in dict.fromkeys(words)
    if w not in STOPWORDS
][:6]

    if meta["decision_trace"] == "EnvBert backbone":
        meta["reasoning"] = (
            f"EnvBert classified the text as '{cls['final_label']}'. "
            f"Salient terms in the input include: "
            f"{', '.join(meta['key_phrases'][:3])}."
        )

        return state