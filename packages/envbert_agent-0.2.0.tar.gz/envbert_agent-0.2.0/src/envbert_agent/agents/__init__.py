# -*- coding: utf-8 -*-
"""
Created on Sat Jan 31 19:58:28 2026

@author: Afreen Aman
"""

