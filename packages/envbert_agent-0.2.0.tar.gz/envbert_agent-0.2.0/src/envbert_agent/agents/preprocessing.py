# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 18:07:15 2026

@author: Afreen Aman
"""

import re
from langdetect import detect


def preprocess_text(raw_text: str) -> dict:
    """
    Clean raw text and extract basic quality signals.

    Parameters
    ----------
    raw_text : str
        Original input text.

    Returns
    -------
    dict
        Dictionary containing:
        - clean_text
        - language
        - quality_score
    """

    clean = re.sub(r"\s+", " ", raw_text).strip()

    try:
        language = detect(clean)
    except Exception:
        language = "unknown"

    quality_score = min(1.0, len(clean) / 50)

    return {
        "clean_text": clean,
        "language": language,
        "quality_score": quality_score,
    }
