# -*- coding: utf-8 -*-
"""
Created on Sat Jan 31 19:48:23 2026

@author: Afreen Aman
"""

from typing import Optional

class LLMConfig:
    def __init__(
        self,
        provider: str = "ollama",
        model: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        azure_deployment: Optional[str] = None,
        azure_api_version: str = "2024-02-15-preview",
    ):
        self.provider = provider
        self.model = model
        self.azure_endpoint = azure_endpoint
        self.azure_deployment = azure_deployment
        self.azure_api_version = azure_api_version
