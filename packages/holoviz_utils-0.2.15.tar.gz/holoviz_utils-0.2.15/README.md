# holoviz-utils

A Python package for HoloViz utilities.

## Installation

```bash
pip install -e .
```

For development:

```bash
pip install -e ".[dev]"
```

## Usage

```python
import holoviz_utils
```

## Development

Run tests:

```bash
pytest
```

## License

MIT
