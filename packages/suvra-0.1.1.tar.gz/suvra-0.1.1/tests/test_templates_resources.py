from __future__ import annotations

from pathlib import Path

from suvra.core.policy import PolicyEngine
from suvra.resources.templates import extract_openclaw_templates, list_openclaw_templates


def test_templates_embedded_list_and_extract(tmp_path: Path) -> None:
    templates = list_openclaw_templates()
    names = [item.name for item in templates]
    assert names == [
        "openclaw-ci.yaml",
        "openclaw-dev-lite.yaml",
        "openclaw-monitor-safe.yaml",
        "openclaw-research.yaml",
    ]

    extracted = extract_openclaw_templates(tmp_path)
    assert len(extracted) == 4
    for path in extracted:
        assert path.exists()
        assert path.read_text(encoding="utf-8").strip()


def test_extracted_template_policy_loads(tmp_path: Path) -> None:
    extracted = extract_openclaw_templates(tmp_path)
    monitor_safe = next(path for path in extracted if path.name == "openclaw-monitor-safe.yaml")
    engine = PolicyEngine(policy_path=monitor_safe)
    result = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/hello.txt", "content": "hello"},
            "meta": {"actor": "tester"},
        }
    )
    assert result.decision == "allow"
