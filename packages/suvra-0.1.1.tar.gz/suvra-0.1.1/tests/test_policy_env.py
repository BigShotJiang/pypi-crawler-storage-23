from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data))


def _write_env_policies(root: Path) -> None:
    _write_policy(
        root / "policies" / "dev" / "policy.yaml",
        {
            "defaults": {"mode": "deny"},
            "rules": [
                {
                    "id": "dev_allow_write",
                    "effect": "allow",
                    "type": "fs.write_file",
                    "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                }
            ],
        },
    )
    _write_policy(
        root / "policies" / "prod" / "policy.yaml",
        {
            "defaults": {"mode": "deny"},
            "rules": [],
        },
    )


def test_suvra_env_loads_different_policy_files(monkeypatch, tmp_path: Path) -> None:
    _write_env_policies(tmp_path)

    action = {
        "action_id": "env-validate-1",
        "type": "fs.write_file",
        "params": {"path": "workspace/env.txt", "content": "hello"},
        "meta": {"actor": "env"},
    }

    monkeypatch.setenv("SUVRA_ENV", "dev")
    dev_engine = EnforcementEngine(root=tmp_path)
    dev_result = dev_engine.validate(action)
    assert dev_result["decision"] == "allow"
    assert dev_engine.policy_engine.policy_path == tmp_path / "policies" / "dev" / "policy.yaml"

    monkeypatch.setenv("SUVRA_ENV", "prod")
    prod_engine = EnforcementEngine(root=tmp_path)
    prod_result = prod_engine.validate(action)
    assert prod_result["decision"] == "deny"
    assert prod_engine.policy_engine.policy_path == tmp_path / "policies" / "prod" / "policy.yaml"


def test_explicit_policy_path_overrides_env(monkeypatch, tmp_path: Path) -> None:
    _write_env_policies(tmp_path)
    _write_policy(
        tmp_path / "custom" / "policy.yaml",
        {
            "defaults": {"mode": "deny"},
            "rules": [
                {
                    "id": "custom_allow_write",
                    "effect": "allow",
                    "type": "fs.write_file",
                    "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                }
            ],
        },
    )

    monkeypatch.setenv("SUVRA_ENV", "prod")
    monkeypatch.setenv("SUVRA_POLICY_PATH", "custom/policy.yaml")

    engine = EnforcementEngine(root=tmp_path)
    result = engine.validate(
        {
            "action_id": "env-override-1",
            "type": "fs.write_file",
            "params": {"path": "workspace/override.txt", "content": "hello"},
            "meta": {"actor": "env"},
        }
    )

    assert result["decision"] == "allow"
    assert engine.policy_engine.policy_path == tmp_path / "custom" / "policy.yaml"


def test_dashboard_policy_page_shows_active_environment(monkeypatch, tmp_path: Path) -> None:
    _write_env_policies(tmp_path)
    monkeypatch.setenv("SUVRA_ENV", "stage")
    _write_policy(
        tmp_path / "policies" / "stage" / "policy.yaml",
        {
            "defaults": {"mode": "deny"},
            "rules": [],
        },
    )

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/policy")
        assert response.status_code == 200
        assert "Environment" in response.text
        assert "stage" in response.text
        assert "policies/stage/policy.yaml" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_policy_page_shows_configured_workspace_dir(monkeypatch, tmp_path: Path) -> None:
    _write_env_policies(tmp_path)
    monkeypatch.setenv("SUVRA_ENV", "dev")
    monkeypatch.setenv("SUVRA_WORKSPACE_DIR", "mywork")

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/policy")
        assert response.status_code == 200
        assert "Workspace Root" in response.text
        assert "mywork" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_policy_page_lists_openclaw_starter_templates(monkeypatch, tmp_path: Path) -> None:
    _write_env_policies(tmp_path)
    monkeypatch.setenv("SUVRA_ENV", "dev")

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/policy")
        assert response.status_code == 200
        assert "OpenClaw Starter Templates" in response.text
        assert "openclaw-dev-lite" in response.text
        assert "openclaw-ci" in response.text
    finally:
        app_main.engine = old_engine
