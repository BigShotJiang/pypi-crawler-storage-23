from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _read_policy(path: Path) -> dict:
    raw = path.read_text()
    try:
        import yaml  # type: ignore
    except ModuleNotFoundError:
        return json.loads(raw)
    return yaml.safe_load(raw) or {}


def test_first_run_creates_policy_from_safe_template_and_server_boots(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_POLICY_PATH", raising=False)
    monkeypatch.setenv("SUVRA_ENV", "dev")

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        policy_path = tmp_path / "policies" / "dev" / "policy.yaml"
        assert policy_path.exists()

        policy = _read_policy(policy_path)
        assert policy.get("defaults", {}).get("mode") == "deny"

        with TestClient(app_main.app) as client:
            health = client.get("/health")
            assert health.status_code == 200
            overview = client.get("/dashboard")
            assert overview.status_code == 200
            assert "Policy created from template: local_sandbox." in overview.text

            write_sim = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "tmpl-write-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/tmpl.txt", "content": "ok"},
                        "meta": {"actor": "tmpl"},
                    }
                },
            )
            assert write_sim.status_code == 200
            assert write_sim.json()["decision"] == "allow"

            delete_sim = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "tmpl-delete-1",
                        "type": "fs.delete_file",
                        "params": {"path": "workspace/tmpl.txt"},
                        "meta": {"actor": "tmpl"},
                    }
                },
            )
            assert delete_sim.status_code == 200
            assert delete_sim.json()["decision"] == "needs_approval"
    finally:
        app_main.engine = old_engine


def test_template_hard_denies_block_protected_paths_even_with_broad_allow(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_ENV", "dev")
    engine = EnforcementEngine(root=tmp_path)
    policy_path = tmp_path / "policies" / "dev" / "policy.yaml"
    policy = _read_policy(policy_path)

    policy["rules"].append(
        {
            "id": "broad_allow_write",
            "effect": "allow",
            "type": "fs.write_file",
            "constraints": {"path_prefix": ""},
        }
    )

    result_data = engine.simulate(
        {
            "action_id": "tmpl-data-write-deny",
            "type": "fs.write_file",
            "params": {"path": "data/audit.db", "content": "x"},
            "meta": {"actor": "tmpl"},
        },
        policy_override=policy,
    )
    assert result_data["decision"] == "deny"

    result_policies = engine.simulate(
        {
            "action_id": "tmpl-policies-write-deny",
            "type": "fs.write_file",
            "params": {"path": "policies/dev/policy.yaml", "content": "x"},
            "meta": {"actor": "tmpl"},
        },
        policy_override=policy,
    )
    assert result_policies["decision"] == "deny"


def test_template_http_hard_denies_block_local_targets(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_ENV", "dev")
    engine = EnforcementEngine(root=tmp_path)
    policy_path = tmp_path / "policies" / "dev" / "policy.yaml"
    policy = _read_policy(policy_path)

    policy["rules"].append(
        {
            "id": "allow_localhost_get",
            "effect": "allow",
            "type": "http.request",
            "constraints": {"method": "GET", "allow_domains": ["localhost", "169.254.169.254", "127.0.0.1"]},
        }
    )

    localhost = engine.simulate(
        {
            "action_id": "tmpl-http-localhost-deny",
            "type": "http.request",
            "params": {"url": "http://localhost/status"},
            "meta": {"actor": "tmpl"},
        },
        policy_override=policy,
    )
    assert localhost["decision"] == "deny"

    link_local = engine.simulate(
        {
            "action_id": "tmpl-http-linklocal-deny",
            "type": "http.request",
            "params": {"url": "http://169.254.169.254/latest/meta-data"},
            "meta": {"actor": "tmpl"},
        },
        policy_override=policy,
    )
    assert link_local["decision"] == "deny"

    loopback = engine.simulate(
        {
            "action_id": "tmpl-http-loopback-deny",
            "type": "http.request",
            "params": {"url": "http://127.0.0.1:8000/"},
            "meta": {"actor": "tmpl"},
        },
        policy_override=policy,
    )
    assert loopback["decision"] == "deny"
