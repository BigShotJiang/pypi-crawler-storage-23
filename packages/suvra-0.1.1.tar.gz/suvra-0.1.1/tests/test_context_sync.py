from __future__ import annotations

from pathlib import Path

from fastapi.routing import APIRoute, Mount

from suvra.app.main import app


def test_context_doc_mentions_all_non_static_routes() -> None:
    doc_text = Path("docs/SUVRA_CONTEXT.md").read_text()
    ignored = {"/openapi.json", "/docs", "/redoc"}

    paths: set[str] = set()
    for route in app.routes:
        if isinstance(route, Mount):
            if route.path.startswith("/static"):
                continue
            continue
        if not isinstance(route, APIRoute):
            continue
        if route.path in ignored or route.path.startswith("/docs"):
            continue
        paths.add(route.path)

    missing = sorted(path for path in paths if path not in doc_text)
    assert not missing, f"Missing routes in docs/SUVRA_CONTEXT.md: {missing}"
