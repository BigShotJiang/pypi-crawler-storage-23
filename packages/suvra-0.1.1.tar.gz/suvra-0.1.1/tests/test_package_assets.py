from __future__ import annotations

from importlib import resources


def test_web_assets_available_via_importlib_resources() -> None:
    web_root = resources.files("suvra.web")
    static_dir = web_root / "static"
    templates_dir = web_root / "templates"

    assert static_dir.is_dir()
    assert templates_dir.is_dir()
    assert (static_dir / "style.css").is_file()
    assert (templates_dir / "base.html").is_file()


def test_embedded_openclaw_templates_available_via_importlib_resources() -> None:
    resources_root = resources.files("suvra.resources")
    openclaw_dir = resources_root / "templates" / "openclaw"

    assert openclaw_dir.is_dir()
    names = sorted(item.name for item in openclaw_dir.iterdir() if item.name.endswith(".yaml"))
    assert names == [
        "openclaw-ci.yaml",
        "openclaw-dev-lite.yaml",
        "openclaw-monitor-safe.yaml",
        "openclaw-research.yaml",
    ]


def test_builtin_policy_templates_available_via_importlib_resources() -> None:
    policies_root = resources.files("suvra.policies")
    templates_dir = policies_root / "templates"

    assert templates_dir.is_dir()
    assert (templates_dir / "local_sandbox.yaml").is_file()
