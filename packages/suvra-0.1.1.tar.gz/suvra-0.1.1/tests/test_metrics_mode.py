from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    }
                ],
            }
        )
    )


def _reset_metrics() -> None:
    for series in app_main.app.state.metrics.values():
        series.clear()


def test_metrics_public_and_contains_mode_labels(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    try:
        with TestClient(app_main.app) as client:
            _ = client.get("/health")
            response = client.get("/metrics")
        assert response.status_code == 200
        assert 'mode="' in response.text or "mode=" in response.text
    finally:
        app_main.engine = old_engine


def test_metrics_strict_mode_lines_present_after_simulate(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_MODE", raising=False)
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    try:
        with TestClient(app_main.app) as client:
            sim = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "mode-metrics-strict-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/mode.txt", "content": "x"},
                        "meta": {"actor": "mode"},
                    }
                },
            )
            assert sim.status_code == 200
            metrics = client.get("/metrics")

        assert metrics.status_code == 200
        assert 'suvra_requests_total{' in metrics.text
        assert 'mode="strict"' in metrics.text
        assert 'suvra_policy_decisions_total{' in metrics.text
    finally:
        app_main.engine = old_engine


def test_metrics_monitor_mode_lines_present_after_execute(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_MODE", "monitor")
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    try:
        with TestClient(app_main.app) as client:
            execute = client.post(
                "/actions/execute",
                json={
                    "action_id": "mode-metrics-monitor-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/monitor-metrics.txt", "content": "x"},
                    "meta": {"actor": "mode"},
                },
            )
            assert execute.status_code in (200, 400, 403)
            metrics = client.get("/metrics")

        assert metrics.status_code == 200
        assert 'mode="monitor"' in metrics.text
        assert 'suvra_policy_decisions_total{' in metrics.text
        assert 'action_type="fs.write_file"' in metrics.text
    finally:
        app_main.engine = old_engine
