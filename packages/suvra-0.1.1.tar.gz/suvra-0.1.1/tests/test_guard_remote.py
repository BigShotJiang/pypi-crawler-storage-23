from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import urlsplit

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine
from suvra.sdk.guard import Guard


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    },
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def test_guard_remote_mode_end_to_end(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            def transport(method: str, url: str, payload: dict) -> dict:
                parsed = urlsplit(url)
                response = client.request(method, parsed.path, json=payload)
                assert response.status_code < 400, response.text
                return response.json()

            guard = Guard(url="http://testserver", transport=transport)

            validate_result = guard.validate(
                {
                    "action_id": "rv-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/remote_validate.txt", "content": "v"},
                    "meta": {"actor": "remote-test"},
                    "dry_run": True,
                }
            )
            assert validate_result["decision"] == "allow"

            execute_result = guard.execute(
                {
                    "action_id": "re-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/remote_exec.txt", "content": "hello remote"},
                    "meta": {"actor": "remote-test"},
                    "dry_run": False,
                }
            )
            assert execute_result["decision"] == "allow"
            assert execute_result["status"] == "executed"
            assert tmp_path.joinpath("workspace/remote_exec.txt").exists()

            delete_pending = guard.execute(
                {
                    "action_id": "re-del-1",
                    "type": "fs.delete_file",
                    "params": {"path": "workspace/remote_exec.txt"},
                    "meta": {"actor": "remote-test"},
                    "dry_run": False,
                }
            )
            assert delete_pending["decision"] == "needs_approval"
            approval_id = delete_pending["approval_id"]

            approved = guard.approve(approval_id=approval_id, decided_by="admin", note="ok")
            assert approved["status"] == "approved"

            deleted = guard.execute(
                {
                    "action_id": "re-del-1",
                    "type": "fs.delete_file",
                    "params": {"path": "workspace/remote_exec.txt"},
                    "meta": {"actor": "remote-test", "approval_id": approval_id},
                    "dry_run": False,
                }
            )
            assert deleted["decision"] == "allow"
            assert deleted["status"] == "executed"
            assert not tmp_path.joinpath("workspace/remote_exec.txt").exists()

            rolled_back = guard.rollback("re-del-1")
            assert rolled_back["status"] == "rolled_back"
            assert tmp_path.joinpath("workspace/remote_exec.txt").exists()
    finally:
        app_main.engine = old_engine


def test_guard_rejects_both_policy_and_url() -> None:
    try:
        Guard(policy="policy.yaml", url="http://127.0.0.1:8000")
        assert False, "expected Guard init to reject both policy and url"
    except ValueError as exc:
        assert "either embedded mode" in str(exc)
