from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )


def _request_id_for_action(engine: EnforcementEngine, action_id: str) -> str | None:
    with sqlite3.connect(engine.audit.db_path) as conn:
        row = conn.execute(
            "SELECT request_id FROM audit_events WHERE action_id = ? ORDER BY event_id DESC LIMIT 1",
            (action_id,),
        ).fetchone()
    return str(row[0]) if row and row[0] is not None else None


def test_simulate_response_header_matches_audit_request_id(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            action_id = "reqid-sim-1"
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": action_id,
                        "type": "fs.write_file",
                        "params": {"path": "workspace/reqid-sim.txt", "content": "hello"},
                        "meta": {"actor": "reqid"},
                    }
                },
            )
        assert response.status_code == 200
        header_request_id = response.headers.get("X-Suvra-Request-ID")
        assert header_request_id
        assert _request_id_for_action(app_main.engine, action_id) == header_request_id
    finally:
        app_main.engine = old_engine


def test_execute_response_header_matches_audit_request_id(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            action_id = "reqid-exec-1"
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": action_id,
                    "type": "fs.write_file",
                    "params": {"path": "workspace/reqid-exec.txt", "content": "hello"},
                    "meta": {"actor": "reqid"},
                },
            )
        assert response.status_code == 200
        header_request_id = response.headers.get("X-Suvra-Request-ID")
        assert header_request_id
        assert _request_id_for_action(app_main.engine, action_id) == header_request_id
    finally:
        app_main.engine = old_engine
