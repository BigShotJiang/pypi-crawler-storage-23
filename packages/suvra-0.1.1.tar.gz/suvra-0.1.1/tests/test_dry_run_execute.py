from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine
from suvra.core.service import SuvraService


def _write_policy(root: Path, path_prefix: str = "workspace/") -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_write",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": path_prefix, "max_bytes": 2048},
                    },
                    {
                        "id": "allow_http",
                        "effect": "allow",
                        "type": "http.request",
                        "constraints": {"method": "GET", "allow_domains": ["example.com"], "timeout_seconds": 2},
                    },
                ],
            }
        )
    )


def _audit_dry_run(db_path: Path, action_id: str) -> int:
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT dry_run FROM audit_events WHERE action_id = ? ORDER BY event_id DESC LIMIT 1",
            (action_id,),
        ).fetchone()
    assert row is not None
    return int(row[0])


def test_execute_api_dry_run_in_params_does_not_write_and_echoes_true(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "dryrun-api-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/ok.txt", "content": "hello", "dry_run": True},
                    "meta": {"actor": "tester"},
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert payload["dry_run"] is True
        assert not (tmp_path / "workspace" / "ok.txt").exists()
        assert _audit_dry_run(app_main.engine.audit.db_path, "dryrun-api-1") == 1
    finally:
        app_main.engine = old_engine


def test_execute_api_dry_run_with_custom_workspace_keeps_jail(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_WORKSPACE_DIR", "mywork")
    _write_policy(tmp_path, path_prefix="")
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            allowed = client.post(
                "/actions/execute",
                json={
                    "action_id": "dryrun-custom-allow",
                    "type": "fs.write_file",
                    "params": {"path": "mywork/ok.txt", "content": "hello", "dry_run": True},
                    "meta": {"actor": "tester"},
                },
            )
            blocked = client.post(
                "/actions/execute",
                json={
                    "action_id": "dryrun-custom-block",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/should_fail.txt", "content": "x", "dry_run": True},
                    "meta": {"actor": "tester"},
                },
            )
        assert allowed.status_code == 200
        assert allowed.json()["dry_run"] is True
        assert not (tmp_path / "mywork" / "ok.txt").exists()
        assert _audit_dry_run(app_main.engine.audit.db_path, "dryrun-custom-allow") == 1

        assert blocked.status_code == 400
        detail = blocked.json()["detail"]
        assert detail["code"] == "EXECUTION_ERROR"
        assert "path must remain within mywork/" in detail["message"]
    finally:
        app_main.engine = old_engine


def test_execute_non_dry_run_still_writes(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    service = SuvraService(tmp_path)

    result = service.execute(
        {
            "action_id": "dryrun-control-write",
            "type": "fs.write_file",
            "params": {"path": "workspace/out.txt", "content": "hello"},
            "meta": {"actor": "tester"},
        }
    )

    assert result["decision"] == "allow"
    assert result["dry_run"] is False
    assert (tmp_path / "workspace" / "out.txt").read_text() == "hello"


def test_http_dry_run_does_not_call_network(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    service = SuvraService(tmp_path)
    called = {"value": False}

    def _fake_urlopen(*args: object, **kwargs: object) -> object:
        called["value"] = True
        raise RuntimeError("network should not be called in dry_run")

    monkeypatch.setattr("suvra.core.executors.http.urlopen", _fake_urlopen)
    result = service.execute(
        {
            "action_id": "dryrun-http-1",
            "type": "http.request",
            "params": {"method": "GET", "url": "https://example.com", "dry_run": True},
            "meta": {"actor": "tester"},
        }
    )

    assert result["decision"] == "allow"
    assert result["dry_run"] is True
    assert result["status"] == "dry_run"
    assert called["value"] is False


def test_dry_run_execute_needs_approval_does_not_create_approval(tmp_path: Path) -> None:
    tmp_path.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "write_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )
    service = SuvraService(tmp_path)
    result = service.execute(
        {
            "action_id": "dryrun-needs-approval-1",
            "type": "fs.write_file",
            "params": {"path": "workspace/pending.txt", "content": "x", "dry_run": True},
            "meta": {"actor": "tester"},
        }
    )

    assert result["decision"] == "needs_approval"
    assert result["dry_run"] is True
    assert "approval_id" not in result
    assert service.engine.audit.approval_counts()["total"] == 0
