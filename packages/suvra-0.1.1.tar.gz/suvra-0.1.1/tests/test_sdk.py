from __future__ import annotations

from pathlib import Path

from suvra.sdk.guard import Guard


def test_guard_execute_write_action() -> None:
    guard = Guard(policy="policy.yaml")
    action = {
        "action_id": "sdk-1",
        "actor": "sdk-test",
        "type": "fs.write_file",
        "params": {"path": "workspace/sdk_guard.txt", "content": "hello from sdk"},
    }

    result = guard.execute(action)

    assert result["status"] == "executed"
    assert Path("workspace/sdk_guard.txt").read_text() == "hello from sdk"

