from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    }
                ],
            }
        )
    )


def _write_policy_with_delete_approval(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    },
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def _create_pending_approval(engine: EnforcementEngine) -> str:
    engine.execute(
        {
            "action_id": "csrf-write-1",
            "type": "fs.write_file",
            "params": {"path": "workspace/csrf.txt", "content": "csrf"},
            "meta": {"actor": "csrf"},
        }
    )
    pending = engine.execute(
        {
            "action_id": "csrf-delete-1",
            "type": "fs.delete_file",
            "params": {"path": "workspace/csrf.txt"},
            "meta": {"actor": "csrf"},
        }
    )
    return str(pending["approval_id"])


def test_auth_token_protects_api_and_dashboard(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    monkeypatch.setenv("SUVRA_AUTH_TOKEN", "devtoken")
    try:
        with TestClient(app_main.app) as client:
            health = client.get("/health")
            assert health.status_code == 200

            dash_unauth = client.get("/dashboard", follow_redirects=False)
            assert dash_unauth.status_code in (302, 303)
            assert dash_unauth.headers.get("location") == "/dashboard/login"

            validate_unauth = client.post(
                "/actions/validate",
                json={
                    "action_id": "auth-v1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/x.txt", "content": "x"},
                    "meta": {"actor": "test"},
                },
            )
            assert validate_unauth.status_code == 401

            simulate_unauth = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "auth-sim-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/sim.txt", "content": "x"},
                        "meta": {"actor": "test"},
                    }
                },
            )
            assert simulate_unauth.status_code == 401

            simulate_preflight = client.options(
                "/simulate",
                headers={
                    "Origin": "http://localhost:3000",
                    "Access-Control-Request-Method": "POST",
                },
            )
            assert simulate_preflight.status_code in (200, 204)

            headers = {"X-Suvra-Token": "devtoken"}
            validate_auth = client.post(
                "/actions/validate",
                headers=headers,
                json={
                    "action_id": "auth-v2",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/y.txt", "content": "y"},
                    "meta": {"actor": "test"},
                },
            )
            assert validate_auth.status_code == 200

            simulate_auth = client.post(
                "/simulate",
                headers=headers,
                json={
                    "action": {
                        "action_id": "auth-sim-2",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/sim2.txt", "content": "y"},
                        "meta": {"actor": "test"},
                    }
                },
            )
            assert simulate_auth.status_code == 200

            login = client.post("/dashboard/login", data={"token": "devtoken"}, follow_redirects=False)
            assert login.status_code in (302, 303)
            assert login.headers.get("location") == "/dashboard"
            assert "suvra_session=" in login.headers.get("set-cookie", "")

            dash_auth = client.get("/dashboard")
            assert dash_auth.status_code == 200
    finally:
        app_main.engine = old_engine


def test_dashboard_csrf_protection_for_approve(monkeypatch, tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    monkeypatch.setenv("SUVRA_AUTH_TOKEN", "devtoken")
    try:
        approval_id = _create_pending_approval(app_main.engine)
        with TestClient(app_main.app) as client:
            login = client.post("/dashboard/login", data={"token": "devtoken"}, follow_redirects=False)
            assert login.status_code in (302, 303)

            missing_csrf = client.post(
                f"/dashboard/approvals/{approval_id}/approve",
                data={"decided_by": "admin", "note": "ok"},
                follow_redirects=False,
            )
            assert missing_csrf.status_code == 403
            assert "CSRF check failed" in missing_csrf.text

            with_csrf = client.post(
                f"/dashboard/approvals/{approval_id}/approve",
                data={"decided_by": "admin", "note": "ok", "csrf": "1"},
                follow_redirects=False,
            )
            assert with_csrf.status_code in (302, 303)
            assert "msg=approved" in with_csrf.headers.get("location", "")
    finally:
        app_main.engine = old_engine


def test_audit_csv_returns_header_and_rows(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    monkeypatch.setenv("SUVRA_AUTH_TOKEN", "devtoken")
    try:
        app_main.engine.execute(
            {
                "action_id": "csv-1",
                "type": "fs.write_file",
                "params": {"path": "workspace/csv.txt", "content": "csv"},
                "meta": {"actor": "csv-test"},
            }
        )

        with TestClient(app_main.app) as client:
            login = client.post("/dashboard/login", data={"token": "devtoken"}, follow_redirects=False)
            assert login.status_code in (302, 303)

            response_with_cookie = client.get("/audit.csv")
            assert response_with_cookie.status_code == 200
            assert response_with_cookie.headers.get("content-type", "").startswith("text/csv")
            assert "event_id,action_id,actor,action_type,decision,status,created_at,dry_run,result_summary,rollback_available" in response_with_cookie.text
            assert "csv-1" in response_with_cookie.text

            response_with_header = client.get("/audit.csv", headers={"X-Suvra-Token": "devtoken"})
            assert response_with_header.status_code == 200
    finally:
        app_main.engine = old_engine
