from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

import uvicorn

from suvra.core.config import get_workspace_dir
from suvra.core.service import SuvraService
from suvra.resources.templates import extract_openclaw_templates, list_openclaw_templates


def _load_action(path: str) -> dict:
    return json.loads(Path(path).read_text())


def _run_validate(args: argparse.Namespace) -> int:
    service = SuvraService()
    action = _load_action(args.action_file)
    result = service.validate(action, dry_run=True)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def _run_execute(args: argparse.Namespace) -> int:
    service = SuvraService()
    action = _load_action(args.action_file)
    result = service.execute(action, dry_run=bool(args.dry_run))
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def _set_if_value(env_key: str, value: Any) -> None:
    if value is None:
        return
    os.environ[env_key] = str(value)


def _run_serve(args: argparse.Namespace) -> int:
    _set_if_value("SUVRA_MODE", args.mode)
    _set_if_value("SUVRA_POLICY_PATH", args.policy_path)
    _set_if_value("SUVRA_WORKSPACE_DIR", args.workspace_dir)
    _set_if_value("SUVRA_DB_PATH", args.db_path)
    _set_if_value("SUVRA_AUTH_TOKEN", args.auth_token)
    uvicorn.run("suvra.app.main:app", host=args.host, port=args.port)
    return 0


def _run_templates_list(args: argparse.Namespace) -> int:
    del args
    for item in list_openclaw_templates():
        print(item.name)
    return 0


def _run_templates_extract(args: argparse.Namespace) -> int:
    out_dir = Path(args.out)
    paths = extract_openclaw_templates(out_dir)
    for path in paths:
        print(str(path))
    return 0


def _run_doctor(args: argparse.Namespace) -> int:
    del args
    mode = os.getenv("SUVRA_MODE", "strict")
    policy_path = os.getenv("SUVRA_POLICY_PATH", "policy.yaml")
    db_path = os.getenv("SUVRA_DB_PATH", "data/audit.db")
    workspace_dir = get_workspace_dir()
    auth_enabled = bool(os.getenv("SUVRA_AUTH_TOKEN"))
    payload = {
        "mode": mode,
        "policy_path": policy_path,
        "db_path": db_path,
        "workspace_dir": workspace_dir,
        "auth_enabled": auth_enabled,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Suvra CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate")
    validate_parser.add_argument("action_file")
    validate_parser.set_defaults(handler=_run_validate)

    execute_parser = subparsers.add_parser("execute")
    execute_parser.add_argument("action_file")
    execute_parser.add_argument("--dry-run", action="store_true")
    execute_parser.set_defaults(handler=_run_execute)

    serve_parser = subparsers.add_parser("serve", help="Start Suvra API server")
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8000)
    serve_parser.add_argument("--mode", choices=["strict", "monitor", "disabled"])
    serve_parser.add_argument("--policy-path", help="Set SUVRA_POLICY_PATH")
    serve_parser.add_argument("--workspace-dir", help="Set SUVRA_WORKSPACE_DIR")
    serve_parser.add_argument("--db-path", help="Set SUVRA_DB_PATH")
    serve_parser.add_argument(
        "--auth-token",
        help="Set SUVRA_AUTH_TOKEN (optional; use only for local beta/dev usage).",
    )
    serve_parser.set_defaults(handler=_run_serve)

    templates_parser = subparsers.add_parser("templates", help="List or extract embedded OpenClaw templates")
    templates_subparsers = templates_parser.add_subparsers(dest="templates_command", required=True)
    templates_list_parser = templates_subparsers.add_parser("list", help="List embedded OpenClaw template names")
    templates_list_parser.set_defaults(handler=_run_templates_list)
    templates_extract_parser = templates_subparsers.add_parser("extract", help="Extract embedded templates to disk")
    templates_extract_parser.add_argument("--out", required=True, help="Output directory")
    templates_extract_parser.set_defaults(handler=_run_templates_extract)

    doctor_parser = subparsers.add_parser("doctor", help="Show resolved Suvra config from environment")
    doctor_parser.set_defaults(handler=_run_doctor)

    args = parser.parse_args()
    handler = getattr(args, "handler")
    handler(args)


if __name__ == "__main__":
    main()
