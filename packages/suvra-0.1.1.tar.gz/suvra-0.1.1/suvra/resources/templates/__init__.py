from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path


@dataclass(frozen=True)
class TemplateInfo:
    name: str
    package_path: str


def list_openclaw_templates() -> list[TemplateInfo]:
    root = resources.files(__package__) / "openclaw"
    items: list[TemplateInfo] = []
    for entry in sorted(root.iterdir(), key=lambda item: item.name):
        if not entry.name.endswith(".yaml"):
            continue
        items.append(
            TemplateInfo(
                name=entry.name,
                package_path=f"{__package__}.openclaw/{entry.name}",
            )
        )
    return items


def extract_openclaw_templates(out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    root = resources.files(__package__) / "openclaw"
    written: list[Path] = []
    for item in list_openclaw_templates():
        source = root / item.name
        target = out_dir / item.name
        target.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
        written.append(target)
    return written
