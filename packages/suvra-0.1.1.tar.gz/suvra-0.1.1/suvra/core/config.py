from __future__ import annotations

import os
from pathlib import Path, PurePosixPath

DEFAULT_WORKSPACE_DIR = "workspace"


def get_workspace_dir() -> str:
    raw = os.getenv("SUVRA_WORKSPACE_DIR")
    if raw is None:
        return DEFAULT_WORKSPACE_DIR

    normalized = _normalize_workspace_dir(raw)
    return normalized


def resolve_workspace_root(engine_root: Path) -> Path:
    return (engine_root / Path(get_workspace_dir())).resolve()


def workspace_prefix(workspace_dir: str | None = None) -> str:
    value = workspace_dir if workspace_dir is not None else get_workspace_dir()
    return f"{value.rstrip('/')}/"


def _normalize_workspace_dir(value: str) -> str:
    raw = value.strip()
    if not raw:
        raise ValueError("SUVRA_WORKSPACE_DIR must not be empty")

    posix_path = PurePosixPath(raw.replace("\\", "/"))
    if posix_path.is_absolute():
        raise ValueError("SUVRA_WORKSPACE_DIR must be a relative path under engine root")

    parts: list[str] = []
    for part in posix_path.parts:
        if part in {"", "."}:
            continue
        if part == "..":
            raise ValueError("SUVRA_WORKSPACE_DIR must not contain '..' traversal segments")
        parts.append(part)

    if not parts:
        raise ValueError("SUVRA_WORKSPACE_DIR must resolve to a non-empty relative path")

    return PurePosixPath(*parts).as_posix()
