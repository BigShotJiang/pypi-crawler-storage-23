from __future__ import annotations

import base64
import binascii
from pathlib import Path
from typing import Any

from suvra.core.config import get_workspace_dir, resolve_workspace_root, workspace_prefix


class FileSystemExecutor:
    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root).resolve()
        self.workspace_dir = get_workspace_dir()
        self.workspace_root = resolve_workspace_root(self.root)
        self.workspace_prefix = workspace_prefix(self.workspace_dir)

    def _resolve_workspace_path(self, raw_path: str) -> Path:
        input_path = Path(raw_path)
        if input_path.is_absolute():
            raise ValueError(f"path must remain within {self.workspace_prefix}")
        if any(part == ".." for part in input_path.parts):
            raise ValueError(f"path traversal is not allowed; path must remain within {self.workspace_prefix}")

        candidate = (self.root / input_path).resolve()
        if not self._is_within_workspace(candidate):
            raise ValueError(f"path must remain within {self.workspace_prefix}")
        return candidate

    def _is_within_workspace(self, path: Path) -> bool:
        try:
            path.relative_to(self.workspace_root)
            return True
        except ValueError:
            return False

    def execute_write_file(
        self,
        params: dict[str, Any],
        constraints: dict[str, Any] | None,
        dry_run: bool,
    ) -> dict[str, Any]:
        path = str(params.get("path", ""))
        content = str(params.get("content", ""))
        max_bytes = int((constraints or {}).get("max_bytes", 10_000_000))

        content_bytes = content.encode("utf-8")
        if len(content_bytes) > max_bytes:
            raise ValueError(f"content exceeds max_bytes={max_bytes}")

        target = self._resolve_workspace_path(path)

        if dry_run:
            return {
                "status": "dry_run",
                "summary": f"dry_run: would write {len(content_bytes)} bytes to {target}",
                "rollback": {
                    "type": "fs.write_file",
                    "path": path,
                    "restore_content": None,
                    "delete_on_rollback": False,
                },
            }

        existed = target.exists()
        previous_content = target.read_text() if existed else None
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
        return {
            "status": "executed",
            "summary": f"wrote {len(content_bytes)} bytes to {target}",
            "rollback": {
                "type": "fs.write_file",
                "path": path,
                "restore_content": previous_content,
                "delete_on_rollback": not existed,
            },
        }

    def execute_delete_file(
        self,
        params: dict[str, Any],
        constraints: dict[str, Any] | None,
        dry_run: bool,
    ) -> dict[str, Any]:
        del constraints  # constraints are enforced by policy; executor still enforces filesystem jail.
        path = str(params.get("path", ""))
        target = self._resolve_workspace_path(path)
        if not target.exists():
            raise ValueError(f"file does not exist: {path}")
        if not target.is_file():
            raise ValueError(f"path is not a file: {path}")
        if target.is_symlink():
            symlink_target = target.resolve()
            if not self._is_within_workspace(symlink_target):
                raise ValueError(f"symlink target escapes {self.workspace_prefix}")

        if dry_run:
            return {"status": "dry_run", "summary": f"would delete {target}"}

        original_bytes = target.read_bytes()
        mode = target.stat().st_mode & 0o777
        target.unlink()
        return {
            "status": "executed",
            "summary": f"deleted {target}",
            "rollback": {
                "type": "fs.delete_file",
                "path": path,
                "restore_b64": base64.b64encode(original_bytes).decode("ascii"),
                "restore_mode": mode,
            },
        }

    def rollback_write_file(self, payload: dict[str, Any], dry_run: bool = False) -> dict[str, Any]:
        path = str(payload.get("path", ""))
        target = self._resolve_workspace_path(path)
        restore_content = payload.get("restore_content")
        delete_on_rollback = bool(payload.get("delete_on_rollback", False))

        if dry_run:
            return {"status": "dry_run", "summary": f"would rollback file {target}"}

        if delete_on_rollback:
            if target.exists():
                target.unlink()
            return {"status": "rolled_back", "summary": f"deleted {target}"}

        if restore_content is None:
            return {"status": "rolled_back", "summary": "nothing to restore"}

        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(str(restore_content))
        return {"status": "rolled_back", "summary": f"restored {target}"}

    def rollback_delete_file(self, payload: dict[str, Any], dry_run: bool = False) -> dict[str, Any]:
        path = str(payload.get("path", ""))
        target = self._resolve_workspace_path(path)
        restore_b64 = str(payload.get("restore_b64", ""))
        restore_mode = payload.get("restore_mode")

        try:
            restore_bytes = base64.b64decode(restore_b64.encode("ascii"), validate=True)
        except (ValueError, binascii.Error) as exc:
            raise ValueError("invalid rollback payload: restore_b64") from exc

        if dry_run:
            return {"status": "dry_run", "summary": f"would restore deleted file {target}"}

        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(restore_bytes)
        if restore_mode is not None:
            target.chmod(int(restore_mode))
        return {"status": "rolled_back", "summary": f"restored {target}"}
