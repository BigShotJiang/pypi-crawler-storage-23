from __future__ import annotations

from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen


class HttpExecutor:
    def execute_request(
        self,
        params: dict[str, Any],
        constraints: dict[str, Any] | None,
        dry_run: bool,
    ) -> dict[str, Any]:
        method = str(params.get("method", "GET")).upper()
        if method != "GET":
            raise ValueError("http.request only supports GET")

        url = str(params.get("url", ""))
        if not url:
            raise ValueError("url is required")

        allowed_domains = (constraints or {}).get("allow_domains")
        if allowed_domains is not None:
            domain = urlparse(url).hostname or ""
            if domain not in allowed_domains:
                raise ValueError(f"domain '{domain}' is not allowed")

        timeout = float(params.get("timeout_seconds", (constraints or {}).get("timeout_seconds", 10)))
        if dry_run:
            return {
                "status": "dry_run",
                "summary": f"would GET {url} with timeout={timeout}",
                "rollback": None,
            }

        req = Request(url=url, method="GET")
        with urlopen(req, timeout=timeout) as response:  # nosec B310 - policy constrained URL and method
            body = response.read(200)
            status_code = getattr(response, "status", 200)

        return {
            "status": "executed",
            "summary": f"GET {url} -> {status_code}",
            "http": {
                "status_code": status_code,
                "body_preview": body.decode("utf-8", errors="replace"),
            },
            "rollback": None,
        }
