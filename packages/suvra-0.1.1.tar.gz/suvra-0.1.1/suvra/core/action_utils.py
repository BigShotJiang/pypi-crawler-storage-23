from __future__ import annotations

from typing import Any


def _coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off", ""}:
            return False
    if isinstance(value, (int, float)):
        if value == 1:
            return True
        if value == 0:
            return False
    return False


def is_dry_run(action: dict[str, Any]) -> bool:
    params = action.get("params")
    if isinstance(params, dict) and "dry_run" in params:
        return _coerce_bool(params.get("dry_run"))
    return _coerce_bool(action.get("dry_run"))


def resolve_dry_run(action: dict[str, Any], override: bool | None = None) -> bool:
    if override is not None:
        return bool(override)
    return is_dry_run(action)
