from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from suvra.core.engine import EnforcementEngine


class Guard:
    def __init__(
        self,
        policy: str | None = None,
        db_path: str = "data/audit.db",
        url: str | None = None,
        transport: Callable[[str, str, dict[str, Any]], dict[str, Any]] | None = None,
    ):
        if policy and url:
            raise ValueError("Guard supports either embedded mode (policy) or remote mode (url), not both")
        if not policy and not url:
            raise ValueError("Guard requires policy for embedded mode or url for remote mode")

        self._remote_url = url.rstrip("/") if url else None
        self._transport = transport or self._urllib_transport
        self.engine: EnforcementEngine | None = None

        if policy:
            policy_path = Path(policy)
            root = policy_path.parent or Path(".")
            self.engine = EnforcementEngine(
                root=root,
                policy_path=policy_path,
                db_path=db_path,
            )

    def validate(self, action: dict[str, Any]) -> dict[str, Any]:
        if self._remote_url:
            return self._post("/actions/validate", action)
        if self.engine is None:
            raise RuntimeError("embedded engine is not configured")
        return self.engine.validate(action)

    def execute(self, action: dict[str, Any]) -> dict[str, Any]:
        if self._remote_url:
            return self._post("/actions/execute", action)
        if self.engine is None:
            raise RuntimeError("embedded engine is not configured")
        return self.engine.execute(action)

    def approve(self, approval_id: str, decided_by: str, note: str = "") -> dict[str, Any]:
        if self._remote_url:
            return self._post(
                f"/approvals/{approval_id}/approve",
                {"decided_by": decided_by, "note": note},
            )
        if self.engine is None:
            raise RuntimeError("embedded engine is not configured")
        return self.engine.approve(approval_id=approval_id, decided_by=decided_by, note=note)

    def rollback(self, action_id: str) -> dict[str, Any]:
        if self._remote_url:
            return self._post(f"/rollback/{action_id}", {})
        if self.engine is None:
            raise RuntimeError("embedded engine is not configured")
        return self.engine.rollback(action_id)

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        if not self._remote_url:
            raise RuntimeError("remote mode is not configured")
        return self._transport("POST", f"{self._remote_url}{path}", payload)

    @staticmethod
    def _urllib_transport(method: str, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        req = Request(
            url=url,
            data=body,
            method=method,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urlopen(req, timeout=5) as resp:  # nosec B310
                data = resp.read().decode("utf-8")
        except HTTPError as exc:
            details = exc.read().decode("utf-8")
            raise RuntimeError(f"remote call failed: {exc.code} {details}") from exc
        return json.loads(data or "{}")
