from __future__ import annotations

import csv
import io
import os
import time
from uuid import uuid4
from collections import defaultdict, deque
from pathlib import Path
from typing import Deque
from urllib.parse import parse_qs

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from suvra.core.engine import EnforcementEngine, SuvraError
from suvra.core.mode import get_suvra_mode
from suvra.core.request_context import reset_request_id, set_request_id
from suvra.web.router import create_dashboard_router

app = FastAPI(title="Suvra v0")
engine = EnforcementEngine()
app.state.rate_limit_store: dict[str, dict[str, Deque[float]]] = defaultdict(lambda: defaultdict(deque))
app.state.metrics = {
    "requests_total": defaultdict(int),
    "policy_decisions_total": defaultdict(int),
    "simulations_total": defaultdict(int),
    "approvals_total": defaultdict(int),
    "rollbacks_total": defaultdict(int),
    "rate_limited_total": defaultdict(int),
}


def _inc_metric(name: str, labels: tuple[str, ...], value: int = 1) -> None:
    app.state.metrics[name][labels] += value


def _current_mode() -> str:
    return get_suvra_mode()


def _route_label(request: Request) -> str:
    route = request.scope.get("route")
    path = getattr(route, "path", None) if route is not None else None
    if isinstance(path, str) and path:
        return path
    return request.url.path


def _metric_line(name: str, labels: dict[str, str], value: int) -> str:
    def _esc(text: str) -> str:
        return text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")

    if labels:
        rendered = ",".join(f'{k}="{_esc(v)}"' for k, v in labels.items())
        return f"{name}{{{rendered}}} {value}"
    return f"{name} {value}"


def _cors_origins_from_env() -> list[str]:
    raw = os.getenv("SUVRA_CORS_ORIGINS", "")
    if not raw.strip():
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


_cors_origins = _cors_origins_from_env()
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "X-Suvra-Token"],
    )

_web_dir = Path(__file__).resolve().parents[1] / "web"
app.mount("/static", StaticFiles(directory=str(_web_dir / "static")), name="static")
app.include_router(create_dashboard_router(lambda: engine))


def get_auth_token() -> str | None:
    token = os.getenv("SUVRA_AUTH_TOKEN", "").strip()
    return token or None


def _valid_header_token(request: Request, token: str) -> bool:
    return request.headers.get("X-Suvra-Token", "") == token


def _valid_dashboard_session(request: Request, token: str) -> bool:
    return request.cookies.get("suvra_session", "") == token


def _render_login(error: str = "") -> HTMLResponse:
    body = """
    <html>
      <head><title>Suvra Login</title></head>
      <body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f6f8fb;padding:24px;">
        <div style="max-width:360px;margin:60px auto;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px;">
          <h1 style="margin:0 0 8px;font-size:20px;">Suvra Dashboard Login</h1>
          <p style="margin:0 0 14px;color:#6b7280;font-size:13px;">Enter your access token to continue.</p>
          __ERROR__
          <form method="post" action="/dashboard/login">
            <input name="token" type="password" placeholder="Token" style="width:100%;padding:9px;border:1px solid #d1d5db;border-radius:6px;" />
            <button type="submit" style="margin-top:10px;width:100%;padding:9px;background:#1d4ed8;color:#fff;border:0;border-radius:6px;">Sign in</button>
          </form>
        </div>
      </body>
    </html>
    """
    error_html = (
        f"<p style='margin:0 0 10px;color:#991b1b;font-size:13px;'>{error}</p>" if error else ""
    )
    return HTMLResponse(body.replace("__ERROR__", error_html), status_code=200)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For", "").strip()
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client and request.client.host:
        return request.client.host
    return "unknown"


def _rate_limit_rule(path: str) -> tuple[str, int, int] | None:
    if (
        path.startswith("/actions")
        or path.startswith("/approvals")
        or path.startswith("/rollback")
        or path.startswith("/simulate")
    ):
        return ("critical", 60, 60)
    if path.startswith("/audit"):
        return ("audit", 120, 60)
    return None


@app.middleware("http")
async def token_auth_middleware(request: Request, call_next):
    token = get_auth_token()
    if not token:
        return await call_next(request)

    if request.method == "OPTIONS":
        origin = request.headers.get("origin", "")
        preflight = request.headers.get("access-control-request-method", "")
        if preflight:
            headers: dict[str, str] = {}
            if origin and origin in _cors_origins:
                headers = {
                    "Access-Control-Allow-Origin": origin,
                    "Access-Control-Allow-Credentials": "true",
                    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type,X-Suvra-Token",
                    "Vary": "Origin",
                }
            return Response(status_code=204, headers=headers)
        return await call_next(request)

    path = request.url.path
    if path == "/health" or path == "/metrics" or path.startswith("/static"):
        return await call_next(request)

    if path == "/dashboard/login" and request.method in {"GET", "POST"}:
        return await call_next(request)

    if path.startswith("/dashboard"):
        if _valid_dashboard_session(request, token):
            if request.method == "POST" and path != "/dashboard/logout":
                body = (await request.body()).decode("utf-8")
                data = parse_qs(body)
                if (data.get("csrf") or [""])[0] != "1":
                    return HTMLResponse(
                        "<html><body><h1>CSRF check failed</h1><p>CSRF check failed</p></body></html>",
                        status_code=403,
                    )
            return await call_next(request)
        return RedirectResponse(url="/dashboard/login", status_code=303)

    if path == "/audit.csv" and _valid_dashboard_session(request, token):
        return await call_next(request)

    if _valid_header_token(request, token):
        return await call_next(request)
    return JSONResponse({"detail": "Unauthorized: provide valid X-Suvra-Token header"}, status_code=401)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    path = request.url.path
    if path == "/health" or path.startswith("/dashboard") or path.startswith("/static"):
        return await call_next(request)

    rule = _rate_limit_rule(path)
    if not rule:
        return await call_next(request)

    bucket, limit, window_seconds = rule
    ip = _client_ip(request)
    now = time.monotonic()
    entries = app.state.rate_limit_store[ip][bucket]
    while entries and (now - entries[0]) > window_seconds:
        entries.popleft()
    if len(entries) >= limit:
        _inc_metric("rate_limited_total", (path, _current_mode()))
        return JSONResponse({"code": "RATE_LIMITED", "message": "Too many requests"}, status_code=429)
    entries.append(now)
    return await call_next(request)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = str(uuid4())
    request.state.request_id = request_id
    token = set_request_id(request_id)
    try:
        response = await call_next(request)
    finally:
        reset_request_id(token)
    response.headers["X-Suvra-Request-ID"] = request_id
    _inc_metric(
        "requests_total",
        (_route_label(request), request.method.upper(), str(response.status_code), _current_mode()),
    )
    return response


@app.get("/dashboard/login")
def dashboard_login_get() -> HTMLResponse:
    if not get_auth_token():
        return RedirectResponse(url="/dashboard", status_code=303)
    return _render_login()


@app.post("/dashboard/login")
async def dashboard_login_post(request: Request) -> HTMLResponse:
    token = get_auth_token()
    if not token:
        return RedirectResponse(url="/dashboard", status_code=303)
    body = (await request.body()).decode("utf-8")
    data = parse_qs(body)
    provided = (data.get("token") or [""])[0].strip()
    if provided != token:
        return _render_login("Invalid token.")
    response = RedirectResponse(url="/dashboard", status_code=303)
    response.set_cookie(
        "suvra_session",
        token,
        httponly=True,
        samesite="lax",
        secure=(request.url.scheme == "https"),
    )
    return response


@app.post("/dashboard/logout")
def dashboard_logout() -> HTMLResponse:
    response = RedirectResponse(url="/dashboard/login", status_code=303)
    response.delete_cookie("suvra_session")
    return response


class ActionRequest(BaseModel):
    action_id: str = Field(..., description="Unique action identifier")
    type: str
    params: dict = Field(default_factory=dict)
    meta: dict = Field(default_factory=dict)
    dry_run: bool = False
    actor: str | None = Field(default=None, description="Deprecated: use meta.actor")
    approval_id: str | None = Field(default=None, description="Deprecated: use meta.approval_id")


class RollbackRequest(BaseModel):
    dry_run: bool = False


class ApprovalDecisionRequest(BaseModel):
    decided_by: str
    note: str | None = None


class SimulateRequest(BaseModel):
    action: ActionRequest
    policy_override: dict | None = None


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/metrics")
def metrics() -> Response:
    lines = [
        "# HELP suvra_requests_total Total HTTP requests.",
        "# TYPE suvra_requests_total counter",
    ]
    for (route, method, status, mode), value in sorted(app.state.metrics["requests_total"].items()):
        lines.append(
            _metric_line(
                "suvra_requests_total",
                {"route": route, "method": method, "status": status, "mode": mode},
                int(value),
            )
        )

    lines.extend(
        [
            "# HELP suvra_policy_decisions_total Policy decisions by decision and action type.",
            "# TYPE suvra_policy_decisions_total counter",
        ]
    )
    for (decision, action_type, mode), value in sorted(app.state.metrics["policy_decisions_total"].items()):
        lines.append(
            _metric_line(
                "suvra_policy_decisions_total",
                {"decision": decision, "action_type": action_type, "mode": mode},
                int(value),
            )
        )

    lines.extend(
        [
            "# HELP suvra_simulations_total Simulation outcomes by decision.",
            "# TYPE suvra_simulations_total counter",
        ]
    )
    for (decision, mode), value in sorted(app.state.metrics["simulations_total"].items()):
        lines.append(_metric_line("suvra_simulations_total", {"decision": decision, "mode": mode}, int(value)))

    lines.extend(
        [
            "# HELP suvra_approvals_total Approval status updates.",
            "# TYPE suvra_approvals_total counter",
        ]
    )
    for (status, mode), value in sorted(app.state.metrics["approvals_total"].items()):
        lines.append(_metric_line("suvra_approvals_total", {"status": status, "mode": mode}, int(value)))

    lines.extend(
        [
            "# HELP suvra_rollbacks_total Rollback outcomes by status.",
            "# TYPE suvra_rollbacks_total counter",
        ]
    )
    for (status, mode), value in sorted(app.state.metrics["rollbacks_total"].items()):
        lines.append(_metric_line("suvra_rollbacks_total", {"status": status, "mode": mode}, int(value)))

    lines.extend(
        [
            "# HELP suvra_rate_limited_total Rate-limited requests by route.",
            "# TYPE suvra_rate_limited_total counter",
        ]
    )
    for (route, mode), value in sorted(app.state.metrics["rate_limited_total"].items()):
        lines.append(_metric_line("suvra_rate_limited_total", {"route": route, "mode": mode}, int(value)))

    body = "\n".join(lines) + "\n"
    return Response(content=body, media_type="text/plain; version=0.0.4; charset=utf-8")


@app.post("/actions/validate")
def validate_action(action: ActionRequest) -> dict:
    payload = action.model_dump()
    result = engine.validate(payload)
    _inc_metric(
        "policy_decisions_total",
        (str(result.get("decision")), str(payload.get("type")), _current_mode()),
    )
    return result


@app.post("/actions/execute")
def execute_action(action: ActionRequest) -> dict:
    payload = action.model_dump()
    try:
        result = engine.execute(payload)
        _inc_metric(
            "policy_decisions_total",
            (str(result.get("decision")), str(payload.get("type")), _current_mode()),
        )
        return result
    except SuvraError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"code": exc.code, "message": exc.message},
        ) from exc


@app.post("/simulate")
def simulate_action(request: SimulateRequest) -> dict:
    action_payload = request.action.model_dump()
    try:
        result = engine.simulate(
            action=action_payload,
            policy_override=request.policy_override,
        )
        decision = str(result.get("decision"))
        mode = _current_mode()
        _inc_metric("policy_decisions_total", (decision, str(action_payload.get("type")), mode))
        _inc_metric("simulations_total", (decision, mode))
        return result
    except SuvraError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"code": exc.code, "message": exc.message},
        ) from exc


@app.post("/approvals/request")
def request_approval(action: ActionRequest) -> dict:
    result = engine.request_approval(action.model_dump())
    _inc_metric("approvals_total", (str(result.get("status")), _current_mode()))
    return result


@app.post("/approvals/{approval_id}/approve")
def approve_approval(approval_id: str, request: ApprovalDecisionRequest) -> dict:
    try:
        result = engine.approve(
            approval_id=approval_id,
            decided_by=request.decided_by,
            note=request.note,
        )
        _inc_metric("approvals_total", (str(result.get("status")), _current_mode()))
        return result
    except SuvraError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"code": exc.code, "message": exc.message},
        ) from exc


@app.post("/approvals/{approval_id}/deny")
def deny_approval(approval_id: str, request: ApprovalDecisionRequest) -> dict:
    try:
        result = engine.deny(
            approval_id=approval_id,
            decided_by=request.decided_by,
            note=request.note,
        )
        _inc_metric("approvals_total", (str(result.get("status")), _current_mode()))
        return result
    except SuvraError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"code": exc.code, "message": exc.message},
        ) from exc


@app.get("/approvals/{approval_id}")
def get_approval(approval_id: str) -> dict:
    try:
        return engine.get_approval(approval_id)
    except SuvraError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"code": exc.code, "message": exc.message},
        ) from exc


@app.post("/rollback/{action_id}")
def rollback(action_id: str, request: RollbackRequest) -> dict:
    result = engine.rollback(action_id, dry_run=request.dry_run)
    _inc_metric("rollbacks_total", (str(result.get("status")), _current_mode()))
    return result


@app.get("/audit")
def get_audit(
    actor: str | None = None,
    action_type: str | None = None,
    decision: str | None = None,
    status: str | None = None,
    q: str = Query(default=""),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=100, ge=1, le=1000),
) -> list[dict]:
    offset = (page - 1) * page_size
    return engine.list_audit(
        actor=actor,
        action_type=action_type,
        decision=decision,
        status=status,
        q=q.strip(),
        limit=page_size,
        offset=offset,
    )


@app.get("/audit.csv")
def get_audit_csv(
    actor: str | None = None,
    action_type: str | None = None,
    decision: str | None = None,
    status: str | None = None,
    q: str = Query(default=""),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    limit: int | None = Query(default=None, ge=1, le=20000),
) -> StreamingResponse:
    del page
    del page_size
    export_limit = min(limit or 5000, 20000)
    rows = engine.list_audit(
        actor=actor,
        action_type=action_type,
        decision=decision,
        status=status,
        q=q.strip(),
        limit=export_limit,
    )

    def _iter_csv():
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(
            [
                "event_id",
                "action_id",
                "actor",
                "action_type",
                "decision",
                "status",
                "created_at",
                "dry_run",
                "result_summary",
                "rollback_available",
            ]
        )
        yield buffer.getvalue()
        buffer.seek(0)
        buffer.truncate(0)

        for row in rows:
            summary = str(row.get("result_summary") or "")
            writer.writerow(
                [
                    row.get("event_id"),
                    row.get("action_id"),
                    row.get("actor"),
                    row.get("action_type"),
                    row.get("decision"),
                    row.get("status"),
                    row.get("created_at"),
                    row.get("dry_run"),
                    summary[:500],
                    row.get("rollback_available"),
                ]
            )
            yield buffer.getvalue()
            buffer.seek(0)
            buffer.truncate(0)

    return StreamingResponse(
        _iter_csv(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=audit.csv"},
    )
