# vcspull search - `vcspull.cli.search`

.. automodule:: vcspull.cli.search
