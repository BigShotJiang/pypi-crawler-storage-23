"""Sphinx extensions for vcspull documentation."""

from __future__ import annotations
