"""Tests for docs/_ext Sphinx extensions."""

from __future__ import annotations
