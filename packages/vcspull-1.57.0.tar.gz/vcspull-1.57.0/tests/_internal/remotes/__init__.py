"""Tests for vcspull._internal.remotes package."""
