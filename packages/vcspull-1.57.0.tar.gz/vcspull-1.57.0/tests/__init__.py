"""Tests for vcspull package."""

from __future__ import annotations

from . import fixtures
