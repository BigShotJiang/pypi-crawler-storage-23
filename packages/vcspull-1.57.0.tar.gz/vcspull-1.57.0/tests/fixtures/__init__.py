"""Test fixture data for vcspull."""
