mcp-name: io.github.NeetPatel/devops-mcp

# DevOps MCP Server

MCP server that exposes **Project AI Memory** (`memory.md`) as resources and tools so AI clients (Cursor, Claude Desktop, etc.) can load DevOps/DevSecOps context.

## Install

```bash
pip install mcp-memory-server
```

Run from a directory that contains `memory.md`, or set the path:

```bash
mcp-memory
# or
MCP_MEMORY_PATH=/path/to/memory.md mcp-memory
```

## What it exposes

- **Resource** `memory://project-context` – full contents of `memory.md`
- **Tools** – `get_memory_section`, `get_security_checklist`, `get_code_standards`

## Load in Cursor (any system, like AWS Labs MCPs)

Add to Cursor MCP config (`~/.cursor/mcp.json` or **Settings → MCP**). Uses **uvx** so the server runs from PyPI without a local clone (same pattern as `awslabs.cdk-mcp-server`):

```json
{
  "mcpServers": {
    "devops-mcp": {
      "command": "uvx",
      "args": ["mcp-memory-server@latest"],
      "env": {}
    }
  }
}
```

- Use `mcp-memory-server` for latest install, or `mcp-memory-server@latest` to pin to latest.
- Cursor uses your **workspace as cwd**, so put `memory.md` in the project root, or set a path in `env`:

```json
"devops-mcp": {
  "command": "uvx",
  "args": ["mcp-memory-server@latest"],
  "env": {
    "MCP_MEMORY_PATH": "/path/to/your/memory.md"
  }
}
```

Requires [uv](https://docs.astral.sh/uv/) (`curl -LsSf https://astral.sh/uv/install.sh | sh`).

## Publish to PyPI (so others can use uvx)

From this repo, after tests pass:

```bash
uv run python -m build
uv run twine upload dist/*
```

Or with a GitHub workflow: build the package, then `twine upload` using a PyPI token. Once `mcp-memory-server` is on PyPI, anyone can use the Cursor config above on any machine.

## Links

- Repository: https://github.com/NeetPatel/devops-mcp
