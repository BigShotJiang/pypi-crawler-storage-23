"""Entry point for uvx: uvx mcp-memory-server runs this."""
from mcp_memory_server.server import main

if __name__ == "__main__":
    main()
