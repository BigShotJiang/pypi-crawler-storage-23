"""MCP Server for Project AI Memory (memory.md)."""

from mcp_memory_server.server import main

__all__ = ["main"]
