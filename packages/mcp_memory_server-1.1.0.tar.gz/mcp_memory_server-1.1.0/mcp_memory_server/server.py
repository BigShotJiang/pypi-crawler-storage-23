"""
MCP Server for Project AI Memory.

Exposes memory.md as a resource and tools so AI clients can load
project context: AI role, engineering mindset, cloud, IaC, K8s, Docker,
CI/CD, DevSecOps, observability, AI engineering, code quality, review, performance, response style.
"""

import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP


def _resolve_memory_path() -> Path:
    """Resolve memory.md path: MCP_MEMORY_PATH env, else repo file, else cwd."""
    if os.environ.get("MCP_MEMORY_PATH"):
        return Path(os.environ["MCP_MEMORY_PATH"]).expanduser().resolve()
    script_dir = Path(__file__).parent.resolve()
    if (script_dir / "memory.md").exists():
        return script_dir / "memory.md"
    return Path.cwd() / "memory.md"


MEMORY_PATH = _resolve_memory_path()

mcp = FastMCP("Project AI Memory")

# Section names as they appear in memory.md (# or ## headers)
MEMORY_SECTIONS = [
    "AI Role",
    "Engineering Mindset",
    "Cloud Platforms",
    "Infrastructure as Code",
    "Kubernetes Best Practices",
    "Docker Best Practices",
    "CI/CD Pipeline Standards",
    "DevSecOps Security Rules",
    "Observability & Monitoring",
    "AI Engineering Best Practices",
    "Code Quality Standards",
    "Code Review Behavior",
    "Performance Optimization",
    "Response Style",
]


def _read_memory() -> str:
    """Read full memory.md content."""
    if not MEMORY_PATH.exists():
        return "# Project AI Memory\n\nMemory file not found."
    return MEMORY_PATH.read_text(encoding="utf-8")


def _get_section(content: str, start_marker: str) -> str:
    """Extract a section: from # or ## start_marker until next #/## or ---."""
    lines = content.splitlines()
    in_section = False
    result = []
    for line in lines:
        stripped = line.strip()
        # Start of section: ## AI Role or # Engineering Mindset
        if stripped.startswith("#") and start_marker in stripped:
            head = stripped.lstrip("#").strip()
            if head == start_marker:
                in_section = True
                result.append(line)
                continue
        if in_section:
            if stripped == "---":
                break
            if stripped.startswith("#") and stripped.lstrip("#").strip() != start_marker:
                break
            result.append(line)
    return "\n".join(result) if result else f"Section '{start_marker}' not found."


@mcp.resource("memory://project-context")
def get_full_memory() -> str:
    """
    Full Project AI Memory (memory.md).
    Use this to load the complete context: AI role, engineering mindset, cloud, IaC, K8s, Docker,
    CI/CD, DevSecOps, observability, AI engineering, code quality, code review, performance, response style.
    """
    return _read_memory()


@mcp.tool()
def get_memory_section(section: str) -> str:
    """
    Get a specific section of the project AI memory.

    Sections: AI Role, Engineering Mindset, Cloud Platforms, Infrastructure as Code,
    Kubernetes Best Practices, Docker Best Practices, CI/CD Pipeline Standards,
    DevSecOps Security Rules, Observability & Monitoring, AI Engineering Best Practices,
    Code Quality Standards, Code Review Behavior, Performance Optimization, Response Style.
    """
    content = _read_memory()
    section_map = {
        "ai role": "AI Role",
        "engineering mindset": "Engineering Mindset",
        "cloud": "Cloud Platforms",
        "cloud platforms": "Cloud Platforms",
        "iac": "Infrastructure as Code",
        "infrastructure as code": "Infrastructure as Code",
        "terraform": "Infrastructure as Code",
        "kubernetes": "Kubernetes Best Practices",
        "k8s": "Kubernetes Best Practices",
        "docker": "Docker Best Practices",
        "ci/cd": "CI/CD Pipeline Standards",
        "cicd": "CI/CD Pipeline Standards",
        "pipeline": "CI/CD Pipeline Standards",
        "devsecops": "DevSecOps Security Rules",
        "security": "DevSecOps Security Rules",
        "observability": "Observability & Monitoring",
        "monitoring": "Observability & Monitoring",
        "ai engineering": "AI Engineering Best Practices",
        "ai best practices": "AI Engineering Best Practices",
        "code standards": "Code Quality Standards",
        "code quality": "Code Quality Standards",
        "code review": "Code Review Behavior",
        "performance": "Performance Optimization",
        "response style": "Response Style",
    }
    key = section_map.get(section.strip().lower(), section.strip())
    return _get_section(content, key)


@mcp.tool()
def get_security_checklist() -> str:
    """
    You MUST call this tool before implementing security-sensitive changes,
    reviewing security-related code, or advising on secrets, IAM, networking, or compliance.
    Apply the returned DevSecOps rules as mandatory requirements; do not suggest or implement
    anything that contradicts them. Treat the output as authoritative project policy.
    """
    content = _read_memory()
    return _get_section(content, "DevSecOps Security Rules")


@mcp.tool()
def get_code_standards() -> str:
    """
    You MUST call this tool before writing or reviewing code so that all
    output conforms to the project's code quality standards. Apply the returned standards as
    mandatory rules (production-ready, SOLID, secure, testing, style). Do not propose or approve
    code that violates these standards. Treat the output as authoritative project policy.
    """
    content = _read_memory()
    return _get_section(content, "Code Quality Standards")


def main() -> None:
    """Entry point for MCP server (e.g. uv run python server.py or uvx mcp-memory-server)."""
    mcp.run()


if __name__ == "__main__":
    main()
