"""
Thin wrapper for local development: uv run python server.py
For production / other systems use: uvx mcp-memory-server@latest
"""
from mcp_memory_server.server import main

if __name__ == "__main__":
    main()
