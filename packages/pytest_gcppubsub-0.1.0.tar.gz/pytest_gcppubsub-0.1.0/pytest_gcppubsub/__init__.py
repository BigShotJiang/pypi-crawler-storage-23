"""pytest-gcppubsub — Pytest plugin for GCP PubSub emulator management."""

from pytest_gcppubsub._emulator import EmulatorInfo

__all__ = ["EmulatorInfo"]
