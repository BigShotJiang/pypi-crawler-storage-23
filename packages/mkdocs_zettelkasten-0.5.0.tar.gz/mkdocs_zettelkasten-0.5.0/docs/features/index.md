# Features

- [Render markdown document as zettel](20211123212328.md)
- [Print metadata in card's header](20211123213357.md)
- [List references in card's footer](20211123213414.md)
- [Find backlinks and list them in card's footer](20211123214904.md)
- [Convert relative links to absolute](20211123215420.md)
- [Insert zettel title as top heading if not done](20211123215950.md)
- [Override previous / next page to follow the sequence of Zettelkasten IDs](20211123220309.md)
- [Collect links by tag](20211123221647.md)
- [Code highlighting test](../20260218000000.md) — sample code blocks for verifying syntax highlighting in light/dark modes
- [References and backlinks test](20260218000001.md) — zettel with both sections for verifying icons and footer styling
