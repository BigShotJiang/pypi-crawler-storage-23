"""sageLLM Developer Tools.

Unified toolkit for sageLLM multi-repository development workflow.

CLI Tool: sage-dev

Examples:
    $ sage-dev init          # Clone all repos
    $ sage-dev sync          # Sync all repos
    $ sage-dev check         # Run checks
    $ sage-dev hooks install # Install git hooks
    $ sage-dev gh list <repo> # List open issues
"""

from __future__ import annotations

from sagellm_dev_tools._version import __version__

__all__ = ["__version__"]
