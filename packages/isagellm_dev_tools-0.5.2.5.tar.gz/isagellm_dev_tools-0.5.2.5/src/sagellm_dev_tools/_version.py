"""Version information for sagellm-dev-tools."""

__version__ = "0.5.2.5"
