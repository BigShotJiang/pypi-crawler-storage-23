# Copyright 2026 Flyto2. Licensed under Apache-2.0. See LICENSE.

"""Allow running as: python -m core.api"""

from .server import main

if __name__ == "__main__":
    main()
