# Copyright 2026 Flyto2. Licensed under Apache-2.0. See LICENSE.

"""
Notification Modules
Send and receive notifications via various platforms.
"""
from .send import notify_send

__all__ = ['notify_send']
