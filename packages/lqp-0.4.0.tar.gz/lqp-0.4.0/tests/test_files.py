from pathlib import Path

import pytest

from .utils import BIN_SNAPSHOTS_DIR, REPO_ROOT, get_all_files, get_lqp_input_files


def get_base_filename(filepath):
    """Get the base filename without extension from a file path."""
    return Path(filepath).stem


def check_output_files_have_corresponding_inputs():
    """Check that all output files have corresponding input files."""
    input_files = get_lqp_input_files()
    input_basenames = {get_base_filename(f) for f in input_files}

    missing_inputs = []

    output_files = [
        (REPO_ROOT / "tests" / "pretty", ".lqp"),
        (BIN_SNAPSHOTS_DIR, ".bin"),
    ]

    for directory, file_extension in output_files:
        if not directory.exists():
            continue
        for output_file in get_all_files(directory, file_extension):
            base_name = get_base_filename(output_file)
            if base_name not in input_basenames:
                missing_inputs.append(
                    f"{Path(output_file).parent.name}/{Path(output_file).name} -> missing input {base_name}.lqp"
                )

    return missing_inputs


def test_all_output_files_have_corresponding_inputs():
    """Test that all output files have corresponding input files."""
    missing_inputs = check_output_files_have_corresponding_inputs()

    if missing_inputs:
        error_message = (
            "Found output files without corresponding input files:\n"
            + "\n".join(missing_inputs)
        )
        pytest.fail(error_message)
