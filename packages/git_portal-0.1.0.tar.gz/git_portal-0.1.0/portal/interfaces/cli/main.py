"""Main entry point for Portal CLI application."""

from __future__ import annotations

import sys

# Ensure we can import click and rich for CLI functionality
try:
    import click  # noqa: F401
    import git
    import rich  # noqa: F401
    from rich.console import Console
except ImportError as e:
    print("Error: Missing CLI dependencies. Install with: uv pip install -e '.[cli]'")
    print(f"Missing module: {e.name}")
    sys.exit(1)

from portal.interfaces.cli.app import create_cli_app


def main() -> None:
    """Main entry point for Portal CLI."""
    try:
        cli_app = create_cli_app()
        cli_app()
    except KeyboardInterrupt:
        console = Console()
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(130)
    except git.InvalidGitRepositoryError:
        console = Console()
        console.print("[red]Error: Not a git repository[/red]")
        console.print("Run this command from within a git repository.")
        sys.exit(1)
    except Exception as e:
        console = Console()
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
