"""Helper utilities for worktree data extraction."""

from typing import Any


def get_worktree_attr(worktree: dict[str, Any] | Any, attr: str, default: Any = None) -> Any:
    """Get attribute from worktree data regardless of type."""
    if isinstance(worktree, dict):
        return worktree.get(attr, default)
    return getattr(worktree, attr, default)


def extract_worktree_display_info(worktree: dict[str, Any] | Any) -> dict[str, Any]:
    """Extract display information from worktree data.

    Returns:
        Dictionary with is_current, is_base, branch, and base_branch.
    """
    return {
        "is_current": get_worktree_attr(worktree, "is_current", False),
        "is_base": get_worktree_attr(worktree, "is_base", False),
        "branch": get_worktree_attr(worktree, "branch", ""),
        "base_branch": get_worktree_attr(worktree, "base_branch", ""),
    }


def format_branch_display(
    branch: str,
    base_branch: str = "",
    is_base: bool = False,
    colored: bool = False,
    color_hex: str = "",
) -> str:
    """Format branch name for display.

    Args:
        branch: Branch name
        base_branch: Base branch name (optional)
        is_base: Whether this is the base repository
        colored: Whether to apply color formatting
        color_hex: Hex color for formatting (if colored=True)

    Returns:
        Formatted branch display string.
    """
    branch_display = f"[{color_hex}]{branch}[/{color_hex}]" if colored and color_hex else branch

    if base_branch:
        branch_display = f"{branch_display} ({base_branch})"

    if is_base:
        if colored:
            branch_display = f"{branch_display} [cyan][BASE][/cyan]"
        else:
            branch_display = f"{branch_display} [BASE]"

    return branch_display
