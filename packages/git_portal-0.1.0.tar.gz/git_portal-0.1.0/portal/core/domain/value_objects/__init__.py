"""Value objects package."""

from .branch_name import BranchName

__all__ = [
    "BranchName",
]
