"""Domain models package."""

from .base import BaseResult, DataResult, HookExecutionResult, SuccessResult
from .color import ColorListResult, ColorPalette, ColorResult, ColorUsageStats, WorktreeColor
from .condition import Condition, ConditionType
from .config import ColorSettings, EditorSettings, PortalConfig, ShellSettings
from .hook import Hook, HookErrorStrategy, HookResult, HookType
from .hook_stage import HookStage
from .template import WorktreeTemplate
from .worktree import (
    Worktree,
    WorktreeListResult,
    WorktreeResult,
    WorktreeSafetyResult,
    WorktreeStatus,
)

__all__ = [
    "BaseResult",
    "ColorListResult",
    "ColorPalette",
    "ColorResult",
    "ColorSettings",
    "ColorUsageStats",
    "Condition",
    "ConditionType",
    "DataResult",
    "EditorSettings",
    "Hook",
    "HookErrorStrategy",
    "HookExecutionResult",
    "HookResult",
    "HookStage",
    "HookType",
    "PortalConfig",
    "ShellSettings",
    "SuccessResult",
    "WorktreeColor",
    "WorktreeTemplate",
    "Worktree",
    "WorktreeListResult",
    "WorktreeResult",
    "WorktreeSafetyResult",
    "WorktreeStatus",
]
