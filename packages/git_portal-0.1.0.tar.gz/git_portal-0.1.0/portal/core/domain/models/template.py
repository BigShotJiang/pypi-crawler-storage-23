"""Template models for Portal worktree creation."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class WorktreeTemplate(BaseModel):
    """Template for creating worktrees with predefined structure."""

    name: str = Field(..., description="Template name")
    description: str = Field("", description="Template description")

    # Directory structure to create
    structure: list[str] = Field(default_factory=list, description="Directories to create")

    # Files to create/copy
    files: list[dict[str, str]] = Field(
        default_factory=list, description="Files to create with sources"
    )

    # Hooks specific to this template
    hooks: dict[str, list[dict[str, Any]]] = Field(
        default_factory=dict, description="Template-specific hooks"
    )

    # Variables for templating
    variables: dict[str, Any] = Field(
        default_factory=dict, description="Default variables for template rendering"
    )

    model_config = {"extra": "forbid"}
