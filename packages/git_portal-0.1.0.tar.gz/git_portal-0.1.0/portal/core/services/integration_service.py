"""Service for managing external tool integrations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from portal.infrastructure.editors.cursor_adapter import CursorAdapter
    from portal.infrastructure.editors.vscode_adapter import VSCodeAdapter
    from portal.infrastructure.terminals.iterm_adapter import ITermAdapter
    from portal.infrastructure.terminals.terminal_adapter import TerminalAdapter


class IntegrationService:
    """Service for managing external tool integrations (UI-agnostic)."""

    def __init__(
        self,
        iterm_adapter: ITermAdapter,
        terminal_adapter: TerminalAdapter,
        cursor_adapter: CursorAdapter,
        vscode_adapter: VSCodeAdapter,
    ) -> None:
        """Initialize integration service with all adapters.

        Args:
            iterm_adapter: iTerm2 integration adapter
            terminal_adapter: Terminal.app integration adapter
            cursor_adapter: Cursor IDE integration adapter
            vscode_adapter: VSCode integration adapter
        """
        self.iterm_adapter = iterm_adapter
        self.terminal_adapter = terminal_adapter
        self.cursor_adapter = cursor_adapter
        self.vscode_adapter = vscode_adapter

    def get_all_integrations_status(self) -> dict[str, Any]:
        """Get status of all external integrations."""
        return {
            "terminals": {
                "iterm": self.iterm_adapter.get_status(),
                "terminal": self.terminal_adapter.get_status(),
            },
            "editors": {
                "cursor": self.cursor_adapter.get_status(),
                "vscode": self.vscode_adapter.get_status(),
            },
        }

    def get_available_terminals(self) -> list[dict[str, Any]]:
        """Get list of available terminal applications."""
        terminals = []

        if self.iterm_adapter.is_available():
            terminals.append(self.iterm_adapter.get_status())

        if self.terminal_adapter.is_available():
            terminals.append(self.terminal_adapter.get_status())

        return terminals

    def get_available_editors(self) -> list[dict[str, Any]]:
        """Get list of available editor applications."""
        editors = []

        if self.cursor_adapter.is_available():
            editors.append(self.cursor_adapter.get_status())

        if self.vscode_adapter.is_available():
            editors.append(self.vscode_adapter.get_status())

        return editors

    def get_recommended_editor(self) -> str | None:
        """Get recommended editor based on availability."""
        # Prefer Cursor, then VSCode
        if self.cursor_adapter.is_available():
            return "cursor"
        elif self.vscode_adapter.is_available():
            return "vscode"

        return None

    def get_recommended_terminal(self) -> str | None:
        """Get recommended terminal based on availability."""
        # Prefer iTerm, then Terminal.app
        if self.iterm_adapter.is_available():
            return "iterm"
        elif self.terminal_adapter.is_available():
            return "terminal"

        return None

    def count_available_integrations(self) -> dict[str, int]:
        """Count available integrations by category."""
        return {
            "terminals": len(self.get_available_terminals()),
            "editors": len(self.get_available_editors()),
            "total": len(self.get_available_terminals()) + len(self.get_available_editors()),
        }

    def has_any_integrations(self) -> bool:
        """Check if any integrations are available."""
        return self.count_available_integrations()["total"] > 0
