"""Core event definitions for Portal."""

from enum import StrEnum


class WorktreeEvents(StrEnum):
    """Worktree-related events."""

    CREATING = "worktree.creating"
    CREATED = "worktree.created"
    SWITCHING = "worktree.switching"
    SWITCHED = "worktree.switched"
    DELETING = "worktree.deleting"
    DELETED = "worktree.deleted"
    LISTING = "worktree.listing"
    LISTED = "worktree.listed"


class HookEvents(StrEnum):
    """Hook-related events."""

    EXECUTING = "hook.executing"
    EXECUTED = "hook.executed"
    FAILED = "hook.failed"
    REGISTERED = "hook.registered"
    UNREGISTERED = "hook.unregistered"


class ConfigEvents(StrEnum):
    """Configuration-related events."""

    LOADING = "config.loading"
    LOADED = "config.loaded"
    SAVING = "config.saving"
    SAVED = "config.saved"
    SETTING_CHANGED = "config.setting_changed"


class ColorEvents(StrEnum):
    """Color-related events."""

    ASSIGNING = "color.assigning"
    ASSIGNED = "color.assigned"
    RETRIEVING = "color.retrieving"
    RETRIEVED = "color.retrieved"


class SystemEvents(StrEnum):
    """System-level events."""

    STARTUP = "system.startup"
    SHUTDOWN = "system.shutdown"
    ERROR = "system.error"
    WARNING = "system.warning"


class GitEvents(StrEnum):
    """Git-related events."""

    REPOSITORY_FOUND = "git.repository_found"
    REPOSITORY_NOT_FOUND = "git.repository_not_found"
    WORKTREE_CREATING = "git.worktree_creating"
    WORKTREE_CREATED = "git.worktree_created"
    WORKTREE_DELETING = "git.worktree_deleting"
    WORKTREE_DELETED = "git.worktree_deleted"
    BRANCH_CREATING = "git.branch_creating"
    BRANCH_CREATED = "git.branch_created"
