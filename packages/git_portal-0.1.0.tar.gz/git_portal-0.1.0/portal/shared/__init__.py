"""Shared utilities and infrastructure."""

from .container import ServiceContainer

__all__ = [
    "ServiceContainer",
]
