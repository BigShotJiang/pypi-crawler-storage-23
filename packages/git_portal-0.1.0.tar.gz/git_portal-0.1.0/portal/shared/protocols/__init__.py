"""Service protocols for dependency injection."""

from .service_protocols import (
    ColorServiceProtocol,
    ConfigServiceProtocol,
    GitRepositoryProtocol,
    HookServiceProtocol,
    WorktreeServiceProtocol,
)

__all__ = [
    "ColorServiceProtocol",
    "ConfigServiceProtocol",
    "GitRepositoryProtocol",
    "HookServiceProtocol",
    "WorktreeServiceProtocol",
]
