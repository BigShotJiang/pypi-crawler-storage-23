"""Portal - Modern git worktree manager with color coding and automation."""

__version__ = "0.1.0"
