"""Shell execution infrastructure."""

from .shell_executor import ShellExecutor

__all__ = ["ShellExecutor"]
