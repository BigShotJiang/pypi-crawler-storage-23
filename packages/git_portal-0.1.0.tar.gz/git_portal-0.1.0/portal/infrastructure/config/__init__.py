"""Configuration infrastructure module."""

from .yaml_config_repository import YamlConfigRepository

__all__ = ["YamlConfigRepository"]
