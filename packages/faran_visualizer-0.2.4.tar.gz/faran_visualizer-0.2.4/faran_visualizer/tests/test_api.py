def test_that_nothing_crashes() -> None:
    pass
