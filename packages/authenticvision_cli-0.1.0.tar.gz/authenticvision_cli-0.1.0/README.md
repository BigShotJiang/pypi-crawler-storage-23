# AuthenticVision CLI - Deepfake Detection Tool

Un outil en ligne de commande (CLI) puissant pour analyser des images et détecter si elles ont été générées ou manipulées par une Intelligence Artificielle (Deepfakes), en utilisant un modèle Vision Transformer (ViT) avancé.

---

## 🚀 Installation

L'outil est packagé pour s'installer facilement et de manière globale sur votre système.

1.  Ouvrez votre terminal et placez-vous dans le dossier du projet :
    ```bash
    cd /chemin/vers/deepfake_detection
    ```
2.  Installez le package en mode éditable avec `pip` :
    ```bash
    pip install -e .
    ```

Une fois l'installation terminée, la commande globale **`deepfake`** sera accessible depuis n'importe quel dossier de votre terminal.

---

## 🛠️ Utilisation

La syntaxe de base est très simple : passez simplement le chemin de l'image que vous souhaitez analyser.

### 1. Analyse Standard Rapide
```bash
deepfake mon_image.jpg
```
*L'outil chargera le modèle silencieusement (pour ne pas polluer l'écran) et affichera un encart clair avec le verdict "AUTHENTIQUE" ou "DEEPFAKE" ainsi que le pourcentage de confiance.*

### 2. Ajuster la Sensibilité (Rigueur)
L'outil vous permet d'ajuster sa tolérance grâce à l'argument `--sensitivity` (valeur entre 1 et 99, par défaut : 50).
-   **Augmenter la sensibilité (ex: 80)** : Rend l'IA plus stricte. Utile si vous analysez des documents sensibles où le moindre doute génératif doit déclencher une alerte.
-   **Diminuer la sensibilité (ex: 20)** : Rend l'IA plus indulgente. Utile pour éviter les faux positifs sur des photos réelles mais très compressées ou avec beaucoup de filtres (type Instagram).

```bash
deepfake mon_image.jpg --sensitivity 85
```

### 3. Sortie au format JSON (Pour les scripts/pipelines)
Si vous souhaitez intégrer cet outil dans un script automatisé (bash, Node.js, Pipeline CI/CD, etc.), utilisez le flag `--json`.
L'interface visuelle sera désactivée et la sortie sera un JSON pur, facilement parsable.

```bash
deepfake mon_image.jpg --json
```

**Exemple de sortie JSON :**
```json
{
  "status": "success",
  "file": "test.jpg",
  "verdict": "AUTHENTIQUE",
  "fake_prob": 0.0398,
  "real_prob": 0.9602,
  "sensitivity_used": 50
}
```

### 4. Afficher l'Aide
Pour retrouver toutes les commandes disponibles directement dans le terminal :
```bash
deepfake --help
```
