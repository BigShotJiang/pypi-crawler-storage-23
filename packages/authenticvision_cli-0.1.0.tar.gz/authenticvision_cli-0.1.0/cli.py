#!/usr/bin/env python
import sys
import argparse
import json
import os
import logging
import contextlib
import warnings

# Hide TensorFlow and Hugging Face logs
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
logging.getLogger("transformers").setLevel(logging.ERROR)
warnings.filterwarnings("ignore")

import torch
from PIL import Image
from transformers import ViTImageProcessor, ViTForImageClassification
from transformers import logging as hf_logging
hf_logging.set_verbosity_error()

def main():
    parser = argparse.ArgumentParser(description="Outil en ligne de commande pour la détection de Deepfakes.")
    parser.add_argument('image_path', type=str, help='Le chemin vers l\'image à analyser.')
    parser.add_argument('--sensitivity', type=int, default=50, help='Sensibilité de 1 à 99 (défaut: 50). Augmenter pour être plus strict sur les fakes.')
    parser.add_argument('--json', action='store_true', help='Affiche le résultat au format JSON bruit pour faciliter le traitement par d\'autres scripts.')
    
    args = parser.parse_args()

    try:
        # Configuration de l'appareil
        device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
        model_name = "prithivMLmods/Deep-Fake-Detector-Model"
        
        # Rediriger silencieusement le chargement des poids du modèle
        with open(os.devnull, 'w') as fnull:
            with contextlib.redirect_stdout(fnull), contextlib.redirect_stderr(fnull):
                processor = ViTImageProcessor.from_pretrained(model_name)
                model = ViTForImageClassification.from_pretrained(model_name).to(device)
                model.eval()
    except Exception as e:
        if args.json:
            print(json.dumps({"status": "error", "message": f"Erreur de chargement du modèle: {str(e)}"}))
        else:
            print(f"❌ Erreur critique lors du chargement du modèle : {e}")
        sys.exit(1)

    try:
        img = Image.open(args.image_path).convert("RGB")
    except Exception as e:
        if args.json:
            print(json.dumps({"status": "error", "message": f"Erreur lors de l'ouverture de l'image: {str(e)}"}))
        else:
            print(f"❌ Erreur lors de l'ouverture : Vérifiez que le chemin '{args.image_path}' est correct.")
        sys.exit(1)

    try:
        inputs = processor(images=img, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            
            real_prob = float(probs[0][0])
            fake_prob = float(probs[0][1])
            
        # Logique de Sensibilité (1-99) identique à api.py / app.py
        shift = args.sensitivity - 50.0 
        multiplier = 10 ** (shift / 25.0) 
        
        fake_odds = fake_prob / (real_prob + 1e-9)
        adjusted_fake_odds = fake_odds * multiplier
        
        adjusted_fake_prob = adjusted_fake_odds / (1 + adjusted_fake_odds)
        adjusted_real_prob = 1.0 - adjusted_fake_prob
        
        verdict = "DEEPFAKE" if adjusted_fake_prob > 0.50 else "AUTHENTIQUE"

    except Exception as e:
        if args.json:
            print(json.dumps({"status": "error", "message": f"Erreur lors de l'analyse: {str(e)}"}))
        else:
            print(f"❌ Erreur lors de l'analyse : {e}")
        sys.exit(1)

    if args.json:
        output_data = {
            "status": "success",
            "file": args.image_path,
            "verdict": verdict,
            "fake_prob": adjusted_fake_prob,
            "real_prob": adjusted_real_prob,
            "sensitivity_used": args.sensitivity,
        }
        print(json.dumps(output_data, indent=2))
    else:
        print("\n" + "="*40)
        print("RÉSULTAT DE L'ANALYSE")
        print("="*40)
        print(f"Fichier analysé : {args.image_path}")
        print(f"Sensibilité     : {args.sensitivity}%")
        print("-" * 40)
        
        if verdict == "DEEPFAKE":
            print(f"🚨 Verdict : {verdict} (Confiance : {adjusted_fake_prob*100:.1f}%)")
            print(f"   Ce contenu présente de fortes traces de génération par IA.")
        else:
            print(f"✅ Verdict : {verdict} (Confiance : {adjusted_real_prob*100:.1f}%)")
            print(f"   Ce contenu semble être réel.")
            
        print("="*40 + "\n")

if __name__ == '__main__':
    main()
