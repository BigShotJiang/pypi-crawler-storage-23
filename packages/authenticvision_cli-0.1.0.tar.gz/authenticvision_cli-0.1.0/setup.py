from setuptools import setup
import os

# Lire le contenu du README pour la description longue de PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='authenticvision-cli', # Un nom unique sur PyPI pour éviter les conflits
    version='0.1.0',
    description='CLI tool for Deepfake Image Detection',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author='Khalifa A. BEYE',
    py_modules=['cli'],
    install_requires=[
        'torch',
        'transformers',
        'Pillow',
        'fastapi',
        'uvicorn',
        'python-multipart',
        'gradio',
    ],
    entry_points={
        'console_scripts': [
            'deepfake=cli:main', # La commande globale que l'utilisateur tapera
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: End Users/Desktop",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Image Recognition"
    ],
    python_requires='>=3.8',
)
