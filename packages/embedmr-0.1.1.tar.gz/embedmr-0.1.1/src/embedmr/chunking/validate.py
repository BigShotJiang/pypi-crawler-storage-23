# src/embedmr/chunking/validate.py
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple


@dataclass(frozen=True, slots=True)
class ValidationResult:
    ok: bool
    docs: int
    chunks: int
    errors: Tuple[str, ...]


def _req_str(obj: Dict[str, Any], key: str, where: str) -> str:
    v = obj.get(key)
    if not isinstance(v, str) or not v.strip():
        raise ValueError(f"{where}: '{key}' must be a non-empty string")
    return v


def validate_chunks_jsonl(path: str | Path, *, allowed_chunker_versions: Optional[Sequence[str]] = None) -> ValidationResult:
    p = Path(path)
    if not p.is_file():
        return ValidationResult(ok=False, docs=0, chunks=0, errors=(f"File not found: {p}",))

    errors = []
    docs_seen = set()
    chunks = 0

    with p.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            s = line.strip()
            if not s:
                continue
            where = f"{p}:{line_no}"
            try:
                obj = json.loads(s)
                if not isinstance(obj, dict):
                    raise ValueError(f"{where}: each line must be a JSON object")

                doc_id = _req_str(obj, "doc_id", where)
                chunk_id = _req_str(obj, "chunk_id", where)
                text = _req_str(obj, "text", where)
                chunker_version = _req_str(obj, "chunker_version", where)

                if allowed_chunker_versions is not None and chunker_version not in allowed_chunker_versions:
                    raise ValueError(f"{where}: chunker_version '{chunker_version}' not allowed")

                # Invariant: chunk_id stable within doc; we enforce our v1 format expectation
                if not chunk_id.startswith(doc_id + ":"):
                    raise ValueError(f"{where}: chunk_id must start with '{doc_id}:'")

                md = obj.get("metadata")
                if md is not None and not isinstance(md, dict):
                    raise ValueError(f"{where}: metadata must be an object/dict if present")

                # Basic sanity
                if len(text) == 0:
                    raise ValueError(f"{where}: text must not be empty")

                docs_seen.add(doc_id)
                chunks += 1

            except Exception as e:
                errors.append(str(e))

    return ValidationResult(ok=(len(errors) == 0), docs=len(docs_seen), chunks=chunks, errors=tuple(errors))
