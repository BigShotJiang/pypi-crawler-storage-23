# src/embedmr/chunking/chunker.py
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from embedmr.core.hashing import sha256_hex_str
from embedmr.core.normalize import NormalizerConfig, normalize_text
from embedmr.core.schemas import ChunkRow
from embedmr.dataio.atomic import atomic_write_text, AtomicWriteConfig


@dataclass(frozen=True, slots=True)
class ChunkerConfig:
    """
    Deterministic v1: character window with overlap, on newline-normalized text.
    """
    chunk_size: int = 1000
    overlap: int = 200
    chunker_version: str = "chunk:v1"
    # doc_id stability:
    # - if user provides doc_id in JSON/JSONL, use it
    # - else derive from normalized full document text (content-based)
    docid_normalizer: NormalizerConfig = NormalizerConfig(lowercase=False)

    def __post_init__(self) -> None:
        if self.chunk_size <= 0:
            raise ValueError("chunk_size must be > 0")
        if self.overlap < 0 or self.overlap >= self.chunk_size:
            raise ValueError("overlap must be >=0 and < chunk_size")
        if "|" in self.chunker_version:
            raise ValueError("chunker_version must not contain '|' (used as delimiter elsewhere)")


def _normalize_newlines_only(text: str) -> str:
    # Deterministic across OS tools: CRLF/CR -> LF
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _derive_doc_id(full_text: str, *, cfg: ChunkerConfig) -> str:
    # Content-based stable doc id
    text_for_id = normalize_text(full_text, cfg=cfg.docid_normalizer)
    return sha256_hex_str(text_for_id)


def _chunk_ranges(n: int, *, size: int, overlap: int) -> Iterator[Tuple[int, int]]:
    if n == 0:
        return
    step = size - overlap
    start = 0
    while start < n:
        end = min(n, start + size)
        yield start, end
        if end == n:
            break
        start += step


def _read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _iter_input_documents(inputs: Sequence[str | Path]) -> Iterator[Tuple[str, str, Optional[Dict[str, Any]]]]:
    """
    Yields (doc_id_or_empty, text, metadata_or_none).

    Accepted input files:
      - .txt : doc_id derived, metadata includes {"source_path": "..."}
      - .json : single object with fields {"text": "...", "doc_id"?, "metadata"?}
      - .jsonl : many objects with fields {"text": "...", "doc_id"?, "metadata"?}
    """
    paths: List[Path] = []
    for x in inputs:
        p = Path(x)
        if p.is_dir():
            paths.extend([q for q in p.rglob("*") if q.is_file()])
        elif p.is_file():
            paths.append(p)
        else:
            raise FileNotFoundError(f"Input path not found: {p}")

    for p in sorted(paths, key=lambda z: str(z).lower()):
        suf = p.suffix.lower()
        if suf == ".txt":
            text = _read_text_file(p)
            md = {"source_path": str(p)}
            yield ("", text, md)
        elif suf == ".json":
            obj = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(obj, dict) or "text" not in obj:
                raise ValueError(f"{p} must be an object with at least a 'text' field")
            yield (str(obj.get("doc_id") or ""), str(obj["text"]), obj.get("metadata"))
        elif suf == ".jsonl":
            with p.open("r", encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    s = line.strip()
                    if not s:
                        continue
                    obj = json.loads(s)
                    if not isinstance(obj, dict) or "text" not in obj:
                        raise ValueError(f"{p}:{line_no} must be an object with at least a 'text' field")
                    yield (str(obj.get("doc_id") or ""), str(obj["text"]), obj.get("metadata"))
        else:
            # ignore unknown files
            continue


def make_chunks(
    *,
    inputs: Sequence[str | Path],
    output_jsonl: str | Path,
    cfg: ChunkerConfig = ChunkerConfig(),
) -> Dict[str, int]:
    """
    Produces chunks.jsonl (atomic write).
    Returns basic counts: {"docs": X, "chunks": Y}.
    """
    out_path = Path(output_jsonl)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows: List[Dict[str, Any]] = []
    docs = 0
    chunks = 0

    for provided_doc_id, raw_text, md in _iter_input_documents(inputs):
        docs += 1
        text = _normalize_newlines_only(raw_text)
        doc_id = provided_doc_id.strip() or _derive_doc_id(text, cfg=cfg)

        # Deterministic chunking on newline-normalized text
        idx = 0
        for start, end in _chunk_ranges(len(text), size=cfg.chunk_size, overlap=cfg.overlap):
            chunk_text = text[start:end]
            chunk_id = f"{doc_id}:{idx:06d}"  # stable within doc
            idx += 1

            meta: Optional[Dict[str, Any]] = None
            if md is not None:
                if not isinstance(md, dict):
                    raise ValueError("metadata must be an object/dict when provided")
                meta = dict(md)  # copy
            else:
                meta = None

            # Always include offsets (deterministic) for traceability
            offsets = {"start_char": start, "end_char": end}
            if meta is None:
                meta = offsets
            else:
                meta = {**meta, **offsets}

            row = ChunkRow(
                doc_id=doc_id,
                chunk_id=chunk_id,
                text=chunk_text,
                chunker_version=cfg.chunker_version,
                metadata=meta,
            )
            rows.append(row.to_json())
            chunks += 1

    # Atomic write all rows (Stage 2 output is usually manageable; v2 can stream)
    text_out = "\n".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) for r in rows)
    if text_out:
        text_out += "\n"
    atomic_write_text(out_path, text_out, cfg=AtomicWriteConfig(fsync=True))

    return {"docs": docs, "chunks": chunks}
