# src/embedmr/dataio/__init__.py
from .jsonl import iter_jsonl, write_jsonl_atomic
from .atomic import atomic_write_bytes, atomic_write_text

__all__ = ["iter_jsonl", "write_jsonl_atomic", "atomic_write_bytes", "atomic_write_text"]
