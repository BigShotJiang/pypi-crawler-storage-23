# src/embedmr/dataio/atomic.py
from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class AtomicWriteConfig:
    fsync: bool = True
    encoding: str = "utf-8"


def _fsync_file(f) -> None:
    f.flush()
    os.fsync(f.fileno())


def atomic_write_bytes(path: str | Path, data: bytes, *, cfg: AtomicWriteConfig = AtomicWriteConfig()) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    fd, tmp_name = tempfile.mkstemp(prefix=p.name + ".", suffix=".tmp", dir=str(p.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            if cfg.fsync:
                _fsync_file(f)
        os.replace(str(tmp_path), str(p))
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def atomic_write_text(path: str | Path, text: str, *, cfg: AtomicWriteConfig = AtomicWriteConfig()) -> None:
    atomic_write_bytes(path, text.encode(cfg.encoding), cfg=cfg)
