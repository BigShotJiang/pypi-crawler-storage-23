# src/embedmr/dataio/jsonl.py
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Sequence

from embedmr.dataio.atomic import atomic_write_text, AtomicWriteConfig


def _collect_input_files(inputs: Sequence[str | Path]) -> List[Path]:
    files: List[Path] = []
    for x in inputs:
        p = Path(x)
        if p.is_dir():
            # Deterministic: sort by full path string
            for fp in sorted([q for q in p.rglob("*") if q.is_file()], key=lambda z: str(z).lower()):
                files.append(fp)
        elif p.is_file():
            files.append(p)
        else:
            raise FileNotFoundError(f"Input path not found: {p}")
    return files


def iter_jsonl(*inputs: str | Path) -> Iterator[Dict[str, Any]]:
    """
    Read JSONL from:
      - a single file
      - a directory (all files inside)
      - multiple files/dirs
    Deterministic file order.
    """
    files = _collect_input_files(list(inputs))
    for fpath in files:
        if fpath.suffix.lower() != ".jsonl":
            continue
        with fpath.open("r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                s = line.strip()
                if not s:
                    continue
                try:
                    obj = json.loads(s)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid JSON in {fpath}:{line_no}: {e}") from e
                if not isinstance(obj, dict):
                    raise ValueError(f"Each JSONL line must be an object in {fpath}:{line_no}")
                yield obj


@dataclass(frozen=True, slots=True)
class JsonlWriteConfig:
    atomic: bool = True
    fsync: bool = True


def write_jsonl_atomic(path: str | Path, rows: Iterable[Dict[str, Any]], *, cfg: JsonlWriteConfig = JsonlWriteConfig()) -> None:
    """
    Writes a JSONL file. Default is atomic write (tmp -> fsync -> rename).
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    lines: List[str] = []
    for r in rows:
        lines.append(json.dumps(r, ensure_ascii=False, separators=(",", ":")))

    text = "\n".join(lines) + ("\n" if lines else "")
    if cfg.atomic:
        atomic_write_text(p, text, cfg=AtomicWriteConfig(fsync=cfg.fsync))
    else:
        with p.open("w", encoding="utf-8") as f:
            f.write(text)
            if cfg.fsync:
                import os
                f.flush()
                os.fsync(f.fileno())
