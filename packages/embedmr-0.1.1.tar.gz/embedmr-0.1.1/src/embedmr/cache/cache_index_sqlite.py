# src/embedmr/cache/cache_index_sqlite.py
from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from embedmr.runtime.constants import CacheStatus


@dataclass(frozen=True, slots=True)
class CacheRecord:
    cache_key: str
    vec_ref: Optional[str]
    dim: Optional[int]
    status: CacheStatus
    created_at: Optional[int]
    error: Optional[str]


class SQLiteCacheIndex:
    """
    Stage 0 must-have schema + atomic state transitions.

    Table: cache_index
      cache_key TEXT PRIMARY KEY
      vec_ref   TEXT
      dim       INTEGER
      status    TEXT (READY|IN_PROGRESS|FAILED)
      created_at INTEGER (unix epoch seconds)
      error     TEXT
    """

    def __init__(self, db_path: str | Path) -> None:
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(str(self._path), timeout=30.0, isolation_level=None)  # autocommit; use BEGIN manually
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA synchronous=NORMAL;")
        con.execute("PRAGMA foreign_keys=ON;")
        con.execute("PRAGMA busy_timeout=30000;")
        return con

    def init_db(self) -> None:
        with self.connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS cache_index (
                    cache_key  TEXT PRIMARY KEY,
                    vec_ref    TEXT,
                    dim        INTEGER,
                    status     TEXT NOT NULL,
                    created_at INTEGER,
                    error      TEXT
                );
                """
            )
            con.execute("CREATE INDEX IF NOT EXISTS idx_cache_status ON cache_index(status);")

    def get(self, cache_key: str) -> Optional[CacheRecord]:
        with self.connect() as con:
            row = con.execute(
                "SELECT cache_key, vec_ref, dim, status, created_at, error FROM cache_index WHERE cache_key=?",
                (cache_key,),
            ).fetchone()
        if row is None:
            return None
        return CacheRecord(
            cache_key=row[0],
            vec_ref=row[1],
            dim=row[2],
            status=CacheStatus(row[3]),
            created_at=row[4],
            error=row[5],
        )

    def try_mark_in_progress(self, cache_key: str) -> bool:
        """
        Single-flight primitive (local host v1):
        - If row doesn't exist: insert IN_PROGRESS -> True
        - If exists and status==FAILED: move to IN_PROGRESS (retry) -> True
        - If exists and status==IN_PROGRESS/READY: -> False
        Atomic via transaction + conditional updates.
        """
        now = int(time.time())
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE;")
            try:
                existing = con.execute(
                    "SELECT status FROM cache_index WHERE cache_key=?",
                    (cache_key,),
                ).fetchone()
                if existing is None:
                    con.execute(
                        """
                        INSERT INTO cache_index(cache_key, vec_ref, dim, status, created_at, error)
                        VALUES(?, NULL, NULL, ?, ?, NULL)
                        """,
                        (cache_key, CacheStatus.IN_PROGRESS.value, now),
                    )
                    con.execute("COMMIT;")
                    return True

                status = CacheStatus(existing[0])
                if status == CacheStatus.FAILED:
                    con.execute(
                        """
                        UPDATE cache_index
                           SET status=?, vec_ref=NULL, dim=NULL, error=NULL
                         WHERE cache_key=? AND status=?
                        """,
                        (
                            CacheStatus.IN_PROGRESS.value,
                            cache_key,
                            CacheStatus.FAILED.value,
                        ),
                    )
                    # If conditional update matched, we own it.
                    changed = con.total_changes > 0
                    con.execute("COMMIT;")
                    return changed

                con.execute("COMMIT;")
                return False
            except Exception:
                con.execute("ROLLBACK;")
                raise

    def mark_ready(self, cache_key: str, *, vec_ref: str, dim: int) -> None:
        if dim <= 0:
            raise ValueError("dim must be positive")
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE;")
            try:
                con.execute(
                    """
                    INSERT INTO cache_index(cache_key, vec_ref, dim, status, created_at, error)
                    VALUES(?, ?, ?, ?, COALESCE((SELECT created_at FROM cache_index WHERE cache_key=?), ?), NULL)
                    ON CONFLICT(cache_key) DO UPDATE SET
                        vec_ref=excluded.vec_ref,
                        dim=excluded.dim,
                        status=excluded.status,
                        error=NULL
                    """,
                    (
                        cache_key,
                        vec_ref,
                        dim,
                        CacheStatus.READY.value,
                        cache_key,
                        int(time.time()),
                    ),
                )
                con.execute("COMMIT;")
            except Exception:
                con.execute("ROLLBACK;")
                raise

    def mark_failed(self, cache_key: str, *, error: str) -> None:
        err = (error or "").strip()[:2000]
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE;")
            try:
                con.execute(
                    """
                    INSERT INTO cache_index(cache_key, vec_ref, dim, status, created_at, error)
                    VALUES(?, NULL, NULL, ?, ?, ?)
                    ON CONFLICT(cache_key) DO UPDATE SET
                        status=excluded.status,
                        error=excluded.error
                    """,
                    (cache_key, CacheStatus.FAILED.value, int(time.time()), err),
                )
                con.execute("COMMIT;")
            except Exception:
                con.execute("ROLLBACK;")
                raise
