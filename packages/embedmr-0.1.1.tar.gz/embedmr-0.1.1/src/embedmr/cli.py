# src/embedmr/cli.py
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from embedmr.chunking.chunker import ChunkerConfig, make_chunks
from embedmr.chunking.validate import validate_chunks_jsonl


def _cmd_make_chunks(args: argparse.Namespace) -> int:
    cfg = ChunkerConfig(
        chunk_size=args.chunk_size,
        overlap=args.overlap,
        chunker_version=args.chunker_version,
    )
    stats = make_chunks(inputs=args.inputs, output_jsonl=args.output, cfg=cfg)
    print(f"Wrote {args.output} (docs={stats['docs']}, chunks={stats['chunks']})")
    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    res = validate_chunks_jsonl(args.path)
    if res.ok:
        print(f"OK: {args.path} (docs={res.docs}, chunks={res.chunks})")
        return 0
    print(f"INVALID: {args.path} (docs={res.docs}, chunks={res.chunks})", file=sys.stderr)
    for e in res.errors[:50]:
        print(f"  - {e}", file=sys.stderr)
    if len(res.errors) > 50:
        print(f"  ... (+{len(res.errors)-50} more)", file=sys.stderr)
    return 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="embedmr")
    sub = p.add_subparsers(dest="cmd", required=True)

    mk = sub.add_parser("make-chunks", help="Create chunks.jsonl from extracted text (.txt/.json/.jsonl)")
    mk.add_argument("--input", dest="inputs", nargs="+", required=True, help="Input file(s) or dir(s)")
    mk.add_argument("--output", required=True, help="Output chunks.jsonl")
    mk.add_argument("--chunk-size", type=int, default=1000)
    mk.add_argument("--overlap", type=int, default=200)
    mk.add_argument("--chunker-version", default="chunk:v1")
    mk.set_defaults(fn=_cmd_make_chunks)

    vd = sub.add_parser("validate", help="Validate chunks.jsonl schema + invariants")
    vd.add_argument("path", help="Path to chunks.jsonl")
    vd.set_defaults(fn=_cmd_validate)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.fn(args))


if __name__ == "__main__":
    raise SystemExit(main())
