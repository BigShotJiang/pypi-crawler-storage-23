# src/embedmr/core/fingerprint.py
from __future__ import annotations

from dataclasses import dataclass

_ILLEGAL = "|"


def _ensure_no_pipe(name: str, value: str) -> None:
    if _ILLEGAL in value:
        raise ValueError(f"{name} must not contain '{_ILLEGAL}': {value!r}")


@dataclass(frozen=True, slots=True)
class EmbedderSpec:
    embedder_id: str
    embedder_version: str
    dim: int
    pooling: str  # e.g., "mean", "cls", "last"

    def __post_init__(self) -> None:
        _ensure_no_pipe("embedder_id", self.embedder_id)
        _ensure_no_pipe("embedder_version", self.embedder_version)
        _ensure_no_pipe("pooling", self.pooling)
        if not isinstance(self.dim, int) or self.dim <= 0:
            raise ValueError(f"dim must be a positive int, got {self.dim!r}")


def build_embedder_fingerprint(
    spec: EmbedderSpec,
    *,
    normalize_version: str,
    chunker_version: str,
) -> str:
    _ensure_no_pipe("normalize_version", normalize_version)
    _ensure_no_pipe("chunker_version", chunker_version)

    # Stage 0 invariant:
    # embedder_id|embedder_version|dim|pooling|normalize_version|chunker_version
    return "|".join(
        [
            spec.embedder_id,
            spec.embedder_version,
            str(spec.dim),
            spec.pooling,
            normalize_version,
            chunker_version,
        ]
    )
