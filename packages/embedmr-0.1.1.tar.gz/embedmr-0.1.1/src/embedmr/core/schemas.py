# src/embedmr/core/schemas.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True, slots=True)
class ChunkRow:
    doc_id: str
    chunk_id: str
    text: str
    chunker_version: str
    metadata: Optional[Dict[str, Any]] = None

    def to_json(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "doc_id": self.doc_id,
            "chunk_id": self.chunk_id,
            "text": self.text,
            "chunker_version": self.chunker_version,
        }
        if self.metadata is not None:
            out["metadata"] = self.metadata
        return out


@dataclass(frozen=True, slots=True)
class IntermediateRow:
    doc_id: str
    chunk_id: str
    cache_key: str
    vec_ref: str
    dim: int
    metadata: Optional[Dict[str, Any]] = None

    def to_json(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "doc_id": self.doc_id,
            "chunk_id": self.chunk_id,
            "cache_key": self.cache_key,
            "vec_ref": self.vec_ref,
            "dim": self.dim,
        }
        if self.metadata is not None:
            out["metadata"] = self.metadata
        return out


@dataclass(frozen=True, slots=True)
class MappingRow:
    doc_id: str
    chunk_id: str
    cache_key: str

    def to_json(self) -> Dict[str, Any]:
        return {"doc_id": self.doc_id, "chunk_id": self.chunk_id, "cache_key": self.cache_key}


@dataclass(frozen=True, slots=True)
class EmbeddingRow:
    cache_key: str
    vec_ref: str
    dim: int

    def to_json(self) -> Dict[str, Any]:
        return {"cache_key": self.cache_key, "vec_ref": self.vec_ref, "dim": self.dim}
