# src/embedmr/core/normalize.py
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

_WS_RE = re.compile(r"\s+")


@dataclass(frozen=True, slots=True)
class NormalizerConfig:
    """
    Stage 0 invariant:
      - Unicode NFKC
      - newline normalize CRLF -> LF
      - trim
      - collapse whitespace to single space
      - optional lowercase
    """
    lowercase: bool = False

    @property
    def normalize_version(self) -> str:
        # Keep version stable and explicit; change only when semantics change.
        base = "norm:v1:nfkc+crlf2lf+trim+ws1"
        return f"{base}+lower" if self.lowercase else base


def normalize_text(text: str, *, cfg: NormalizerConfig = NormalizerConfig()) -> str:
    if text is None:
        raise TypeError("text must be a str, got None")

    if not isinstance(text, str):
        raise TypeError(f"text must be a str, got {type(text)!r}")

    # 1) Unicode NFKC
    s = unicodedata.normalize("NFKC", text)

    # 2) newline normalize \r\n -> \n (also normalize stray \r)
    s = s.replace("\r\n", "\n").replace("\r", "\n")

    # 3) optional lowercase
    if cfg.lowercase:
        s = s.lower()

    # 4) trim + 5) collapse whitespace (incl newlines/tabs) to single space
    s = s.strip()
    s = _WS_RE.sub(" ", s)

    return s
