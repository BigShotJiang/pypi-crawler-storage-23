# src/embedmr/core/hashing.py
from __future__ import annotations

import hashlib


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_hex_str(s: str) -> str:
    if not isinstance(s, str):
        raise TypeError(f"expected str, got {type(s)!r}")
    return sha256_hex(s.encode("utf-8"))


def cache_key_for_text_norm(*, embedder_fingerprint: str, text_norm: str) -> str:
    """
    Stage 0 invariant:
      cache_key = sha256(embedder_fingerprint + "|" + sha256(text_norm))
    """
    inner = sha256_hex_str(text_norm)
    payload = f"{embedder_fingerprint}|{inner}"
    return sha256_hex_str(payload)


def stable_hash_to_int(s: str, *, bits: int = 64) -> int:
    """
    Stable across processes/runs/platforms (unlike Python's hash()).
    Uses sha256(s) and returns the first `bits` bits as an int.
    """
    if bits not in (32, 64, 128):
        raise ValueError("bits must be one of {32, 64, 128}")
    digest = hashlib.sha256(s.encode("utf-8")).digest()
    nbytes = bits // 8
    return int.from_bytes(digest[:nbytes], "big", signed=False)
