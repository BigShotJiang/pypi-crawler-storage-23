# embedmr

embedmr is a cache-aware MapReduce embedding framework.

It helps users:
- Convert text into deterministic chunks
- Generate embeddings efficiently
- Avoid duplicate embedding computation using cache
- Scale embedding generation using MapReduce architecture

## Install

```bash
pip install embedmr
````

## Usage

```bash
embedmr make-chunks --input docs/ --output chunks.jsonl
embedmr validate chunks.jsonl
```

## Purpose

embedmr ensures deterministic, reproducible, and scalable embedding pipelines.

````

Then publish update:

```powershell
# bump version
# in pyproject.toml change:
version = "0.1.1"

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
uv run python -m build
uv run python -m twine upload dist/*
````

---

## Step 8: Verify install works

Test in new terminal:

```bash
pip install embedmr
embedmr --help
```

---
