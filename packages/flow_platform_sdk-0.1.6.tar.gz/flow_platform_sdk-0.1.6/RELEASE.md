# Release Process

## Prerequisites

1. Install uv: `curl -LsSf https://astral.sh/uv/install.sh | sh`
2. Install GitHub CLI: `brew install gh`
3. Authenticate: `gh auth login`
4. Configure PyPI trusted publishing (see below)

## Creating a Release

Run the release script from the `flow-platform-sdk` directory:

```bash
./release.sh [patch|minor|major]
```

Example:
```bash
./release.sh patch  # 0.1.0 -> 0.1.1
./release.sh minor  # 0.1.0 -> 0.2.0
./release.sh major  # 0.1.0 -> 1.0.0
```

### Dry Run

Test without making changes:

```bash
./release.sh patch --dry-run
```

## Release Workflow

1. **Run release script** → Bumps version, creates release branch, opens PR
2. **Review and merge PR** → Automatically creates git tag and triggers deployment
3. **GitHub Actions** → Builds package and publishes to PyPI

The workflow only triggers if:
- PR is merged from a `release/v*` branch
- SDK files (`flow-platform-sdk/**`) were modified

## PyPI Trusted Publishing Setup

1. Go to https://pypi.org/manage/account/publishing/
2. Add a new trusted publisher:
   - **PyPI Project Name**: `flow-platform-sdk`
   - **Owner**: `uniphore`
   - **Repository**: `flow-agent`
   - **Workflow name**: `sdk-release.yml`
   - **Environment name**: (leave blank)

## Manual Trigger (if auto-deployment fails)

If the automatic deployment doesn't trigger after merging:

```bash
gh workflow run sdk-release.yml -f tag=release/v0.1.4
```

## Manual Publishing (emergency only)

```bash
uv build
uv run twine upload dist/*
```
