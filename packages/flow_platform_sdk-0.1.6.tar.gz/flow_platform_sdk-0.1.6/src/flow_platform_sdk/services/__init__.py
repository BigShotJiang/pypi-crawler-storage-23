"""Service proxies for remote platform services."""

from .platform_api import PlatformApiService

__all__ = [
    "PlatformApiService",
]
