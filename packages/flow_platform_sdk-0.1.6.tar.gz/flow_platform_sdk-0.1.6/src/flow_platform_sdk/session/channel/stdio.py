import asyncio
import sys
import threading

from ...models.channel import ChannelRequest, ChannelResponse
from ..protocol import encode_call, try_decode_result
from .base import Channel

TIMEOUT = 120  # seconds


class StdioChannel(Channel):
    """Standard I/O based channel implementation for inter-process communication.

    Each request starts its own reader task that waits for the response.
    Uses daemon threads so the program can exit even if stdin is blocked.
    """

    def _read_stdin_line(self):
        return sys.stdin.readline()

    async def _read_response(self, call_id: str, result_queue: asyncio.Queue) -> None:
        """Read response from stdin for a specific request."""
        loop = asyncio.get_event_loop()

        try:
            while True:
                future = asyncio.Future()

                def read_in_thread():
                    try:
                        line = self._read_stdin_line()
                        loop.call_soon_threadsafe(future.set_result, line)
                    except Exception as e:
                        loop.call_soon_threadsafe(future.set_exception, e)

                thread = threading.Thread(target=read_in_thread, daemon=True)
                thread.start()

                try:
                    line = await asyncio.wait_for(future, timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                if not line:
                    continue

                payload = try_decode_result(line.rstrip("\n"))
                if not payload:
                    continue

                if payload.get("id") == call_id:
                    await result_queue.put(payload)
                    break

        except asyncio.CancelledError:
            pass

    async def request(self, message: ChannelRequest) -> ChannelResponse:
        """Send request via stdout and wait for response via stdin."""
        call_id = message.id
        result_queue = asyncio.Queue()

        reader_task = asyncio.create_task(self._read_response(call_id, result_queue))

        try:
            message_dict = message.model_dump()
            print(encode_call(message_dict), flush=True)

            response_dict = await asyncio.wait_for(result_queue.get(), timeout=TIMEOUT)

            return ChannelResponse(**response_dict)

        finally:
            reader_task.cancel()
            try:
                await reader_task
            except asyncio.CancelledError:
                pass
