from abc import ABC, abstractmethod

from ...models.channel import ChannelRequest, ChannelResponse


class Channel(ABC):
    """Base class for RPC communication channels."""

    @abstractmethod
    async def request(self, message: ChannelRequest) -> ChannelResponse:
        """Send a request and wait for a response."""
        raise NotImplementedError
