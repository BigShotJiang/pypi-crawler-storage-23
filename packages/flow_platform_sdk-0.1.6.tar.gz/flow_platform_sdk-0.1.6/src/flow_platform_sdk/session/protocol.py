import json
from typing import Any

CALL_PREFIX = "REMOTE_SERVICE_CALL:"
RESULT_PREFIX = "REMOTE_SERVICE_RESULT:"


def encode_call(payload: dict[str, Any]) -> str:
    """Encode call message to JSON string."""
    return CALL_PREFIX + json.dumps(payload, separators=(",", ":"))


def try_decode_result(line: str) -> dict[str, Any] | None:
    """Decode result message from JSON string."""
    if not line.startswith(RESULT_PREFIX):
        return None

    try:
        return json.loads(line[len(RESULT_PREFIX) :])
    except json.JSONDecodeError:
        return None
