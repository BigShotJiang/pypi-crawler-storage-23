"""Owlvin Platform MCP Server — one install, every AI tool."""

from .server import main

__all__ = ["main"]
