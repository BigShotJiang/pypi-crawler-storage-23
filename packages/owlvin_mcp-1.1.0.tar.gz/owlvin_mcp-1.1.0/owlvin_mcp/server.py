"""
Owlvin Platform MCP Server
One install, every AI tool. Exposes the Owlvin billing platform as MCP tools
so any agent can discover services, check credits, buy credits, and call APIs.

Config:
  - API key: env var OWLVIN_API_KEY or ~/.config/owlvin/config.json
  - API URL: env var OWLVIN_API_URL (default: Modal deployment)

Usage:
  python -m owlvin_mcp          # stdio transport (default for Claude Code)
  owlvin-mcp                    # same, via entry point
"""

import json
import os
from pathlib import Path

import httpx
from mcp.server.fastmcp import FastMCP

# ── Server setup ─────────────────────────────────────────────────────────────

mcp = FastMCP(
    "Owlvin",
    instructions=(
        "Owlvin is a billing platform for AI tools. "
        "Use owlvin_services to discover available tools, "
        "owlvin_credits to check your balance, "
        "and owlvin_call to invoke any service through the platform."
    ),
)

# ── Config ───────────────────────────────────────────────────────────────────

CONFIG_PATH = Path.home() / ".config" / "owlvin" / "config.json"
DEFAULT_BASE_URL = "https://whoisgloom--owlvin-platform-web.modal.run"


def _load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _get_api_key() -> str:
    key = os.environ.get("OWLVIN_API_KEY")
    if key:
        return key
    config = _load_config()
    key = config.get("api_key")
    if key:
        return key
    raise ValueError(
        "No API key found. Set OWLVIN_API_KEY environment variable "
        'or add {"api_key": "ow_live_..."} to ~/.config/owlvin/config.json'
    )


def _get_base_url() -> str:
    url = os.environ.get("OWLVIN_API_URL")
    if url:
        return url.rstrip("/")
    config = _load_config()
    url = config.get("api_url")
    if url:
        return url.rstrip("/")
    return DEFAULT_BASE_URL


def _build_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=_get_base_url(),
        headers={
            "X-API-Key": _get_api_key(),
            "User-Agent": "owlvin-mcp/1.0.0",
        },
        timeout=httpx.Timeout(connect=10.0, read=30.0, write=30.0, pool=10.0),
    )


# ── Tools ────────────────────────────────────────────────────────────────────

@mcp.tool()
async def owlvin_services() -> str:
    """List all available services on the Owlvin platform with pricing.

    Returns a list of services, each with its operations and per-call cost.
    Use this to discover what tools are available before calling them.
    """
    try:
        async with _build_client() as client:
            r = await client.get("/v1/services")
            if r.status_code == 200:
                return json.dumps(r.json(), indent=2)
            return json.dumps({"error": f"Failed to list services ({r.status_code})", "detail": r.text})
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_credits() -> str:
    """Check your Owlvin platform credit balance and usage.

    Returns credits remaining (in cents), account tier, total API calls, and total spent.
    """
    try:
        async with _build_client() as client:
            r = await client.get("/v1/credits")
            if r.status_code == 200:
                data = r.json()
                data["credits_dollars"] = f"${data.get('credits_remaining', 0) / 100:.2f}"
                return json.dumps(data, indent=2)
            if r.status_code == 401:
                return json.dumps({"error": "Invalid API key. Check your OWLVIN_API_KEY."})
            return json.dumps({"error": f"Failed ({r.status_code})", "detail": r.text})
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_buy_credits(amount_cents: int) -> str:
    """Get a Stripe Checkout URL to buy platform credits.

    Args:
        amount_cents: Amount in cents. Valid options: 500 ($5 = $5 credits),
                      2500 ($25 = $30 credits, +$5 bonus),
                      10000 ($100 = $130 credits, +$30 bonus).

    Returns a checkout URL. Open it in a browser to complete payment.
    Credits are added automatically after payment.
    """
    if amount_cents not in (500, 2500, 10000):
        return json.dumps({
            "error": "Invalid amount. Choose 500 ($5), 2500 ($25 + $5 bonus), or 10000 ($100 + $30 bonus)."
        })
    try:
        async with _build_client() as client:
            r = await client.post("/v1/checkout", json={"amount_cents": amount_cents})
            if r.status_code == 200:
                return json.dumps(r.json(), indent=2)
            return json.dumps({"error": f"Checkout failed ({r.status_code})", "detail": r.text})
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_call(service: str, operation: str, input_data: str = "{}") -> str:
    """Call any service on the Owlvin platform. This is the universal API gateway.

    Billing, rate limiting, and auth are handled automatically.
    Use owlvin_services first to see available services and operations.

    Args:
        service: Service slug (e.g. "drumsplit").
        operation: Operation name (e.g. "full", "drumbus").
        input_data: JSON string with operation-specific parameters. Default: "{}".

    Returns the service response. Cost is deducted from your credit balance automatically.
    """
    try:
        payload = json.loads(input_data)
    except json.JSONDecodeError:
        return json.dumps({"error": "input_data must be valid JSON"})

    try:
        async with _build_client() as client:
            r = await client.post(
                f"/v1/services/{service}/{operation}",
                json=payload,
                timeout=httpx.Timeout(connect=10.0, read=120.0, write=30.0, pool=10.0),
            )
            try:
                return json.dumps(r.json(), indent=2)
            except Exception:
                return r.text
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except httpx.TimeoutException:
        return json.dumps({"error": "Request timed out. The service may be processing a large input."})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_pricing() -> str:
    """Show credit packages and pricing for the Owlvin platform.

    Returns available credit packages with prices, bonuses, and per-call costs for each service.
    """
    try:
        async with _build_client() as client:
            r = await client.get("/v1/pricing")
            if r.status_code == 200:
                return json.dumps(r.json(), indent=2)
            return json.dumps({"error": f"Failed ({r.status_code})", "detail": r.text})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_aeo_scan(url: str) -> str:
    """Scan an MCP server and score its agent discoverability (AEO — Agent Engine Optimization).

    Checks server-card.json, agents.json, OpenAPI spec, tool description quality,
    and registry presence on Smithery, PyPI, and GitHub. Returns a score (0-100),
    letter grade, and specific recommendations to improve discoverability.

    Args:
        url: The MCP server's base URL to scan (e.g. "https://api.example.com").

    Returns a full AEO report with score, grade, issues found, and recommendations.
    """
    try:
        async with _build_client() as client:
            r = await client.post("/v1/aeo/scan", json={"url": url})
            if r.status_code == 200:
                return json.dumps(r.json(), indent=2)
            return json.dumps({"error": f"Scan failed ({r.status_code})", "detail": r.text})
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


@mcp.tool()
async def owlvin_aeo_optimize(url: str) -> str:
    """Generate optimized metadata files to boost an MCP server's agent discoverability.

    Scans the server, then generates ready-to-use server-card.json, agents.json,
    and improved tool descriptions. Copy these files to your server to improve your AEO score.

    Args:
        url: The MCP server's base URL to optimize (e.g. "https://api.example.com").

    Returns generated metadata files and projected score improvement.
    """
    try:
        async with _build_client() as client:
            r = await client.post("/v1/aeo/optimize", json={"url": url})
            if r.status_code == 200:
                return json.dumps(r.json(), indent=2)
            return json.dumps({"error": f"Optimize failed ({r.status_code})", "detail": r.text})
    except ValueError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({"error": f"Cannot connect to Owlvin API at {_get_base_url()}"})
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    """Run the MCP server on stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
