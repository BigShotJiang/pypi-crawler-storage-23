"""Allow running as: python -m owlvin_mcp"""

from .server import main

main()
