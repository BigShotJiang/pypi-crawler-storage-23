"""
Agent orchestrator - coordinates the impact assessment workflow.
"""

from typing import List, Dict, Optional
from checkod.observe import get_diff
from checkod.understand import extract_symbols
from checkod.change_type import detect_change_type, format_change_summary
from checkod.assess import assess_risk, is_ollama_available, prompt_and_install_ollama_if_needed
from checkod.summary import format_impact_report
from checkod.guard import should_warn_commit


def run_agent(
    repo_path: str = ".",
    enable_risk_assessment: bool = True,
    force_override: bool = False,
    diff_range: Optional[str] = None,
    include_untracked: bool = True,
) -> int:
    """
    Run the impact assessment agent.
    
    Args:
        repo_path: Path to the git repository to analyze
        enable_risk_assessment: Whether to use AI risk assessment (requires Ollama)
        force_override: Unused parameter for backward compatibility
        diff_range: Optional git revision range (e.g. HEAD~1..HEAD)
        include_untracked: Include untracked files in the diff
        
    Returns:
        Exit code: 0 for success/advisory, 1 for error only
    """
    try:
        # Step 1: Observe - Get git diff
        diff_content = get_diff(
            repo_path,
            diff_range=diff_range,
            include_untracked=include_untracked,
        )
        
        if not diff_content:
            print("ℹ️  No changes detected in the repository")
            return 0
        
        if enable_risk_assessment and not is_ollama_available():
            if not prompt_and_install_ollama_if_needed():
                print("Proceeding without AI summary.\n")
                print("Tip: To skip AI risk assessment in the future, use: checkod assess --no-risk")
                enable_risk_assessment = False

        # Step 2: Understand - Extract changed symbols
        changed_symbols = extract_symbols(diff_content)
        
        # Step 3: Detect change types for each symbol
        change_types = detect_change_type(diff_content)
        
        import time
        # Step 4: Report - Display symbols with change types or fallback to file-level changes
        print("\n==============================")
        time.sleep(0.3)
        print(f"📊 File Change Assessment")
        print("==============================")
        time.sleep(0.3)
        import re
        file_add_pattern = r"^diff --git a/(.*?) b/(.*?)$"
        file_stats = {}
        current_file = None
        added = deleted = 0
        for line in diff_content.splitlines():
            m = re.match(file_add_pattern, line)
            if m:
                if current_file and (added > 0 or deleted > 0):
                    file_stats[current_file] = (added, deleted)
                current_file = m.group(2)
                added = deleted = 0
            elif line.startswith('+') and not line.startswith('+++'):
                added += 1
            elif line.startswith('-') and not line.startswith('---'):
                deleted += 1
        if current_file:
            file_stats[current_file] = (added, deleted)
        if file_stats:
            print(f"{'File':<30} {'+Lines':>7} {'-Lines':>7}")
            print('-' * 48)
            time.sleep(0.2)
            for fname, (add, delete) in file_stats.items():
                print(f"{fname:<30} {add:>7} {delete:>7}")
                time.sleep(0.1)
        else:
            print("No file changes detected.")
        print("\n--------------------------------")
        time.sleep(0.2)
        
        # Step 5: Assess Risk (optional, requires Ollama)
        highest_risk = "LOW"  # Track highest risk level
        if enable_risk_assessment and changed_symbols:
            print("\n" + "=" * 80)
            print("Risk Assessment")
            print("=" * 80)
            print("Details\n")
            # For each file-symbol pair, print risk summary
            for fname, (add, delete) in file_stats.items():
                for symbol in changed_symbols:
                    print(f"File: {fname} - Symbol: {symbol}")
                    # Print risk summary for this symbol
                    change_type = change_types.get(symbol, "unknown")
                    usage_locations = [f"[{change_type}]"]
                    risk_assessment = assess_risk(symbol, usage_locations)
                    print(risk_assessment)
                    print()
            # Track highest risk for summary
            highest_risk = _run_risk_assessment(changed_symbols, change_types)
        
        # Step 6: Generate Impact Summary
        if changed_symbols:
            print("\n" + "=" * 80)
            time.sleep(0.3)
            print("📋 Impact Summary")
            print("=" * 80)
            time.sleep(0.3)
            summary_report = _generate_summary_report(
                changed_symbols,
                change_types,
                highest_risk
            )
            print(summary_report)
            time.sleep(0.3)

        # Step 6b: Print a single 'This may affect:' summary for all changes
        affected_services = set()
        affected_apis = set()
        affected_tests = set()
        for symbol in changed_symbols:
            affected_services.add(f"{symbol.lower()}_service")
            affected_apis.add(f"/api/{symbol.lower()}")
            affected_tests.add(f"test_{symbol.lower()}")
        if changed_symbols:
            time.sleep(0.3)
            print("\nThis may affect:")
            time.sleep(0.2)
            for s in sorted(affected_services):
                print(f"  • {s} (logic flow)")
                time.sleep(0.05)
            for a in sorted(affected_apis):
                print(f"  • {a} (user-facing behavior)")
                time.sleep(0.05)
            for t in sorted(affected_tests):
                print(f"  • {t} (test coverage)")
                time.sleep(0.05)
        
        # Step 7: Guard - Advisory warning for HIGH risk changes
        if should_warn_commit(highest_risk):
            print("\n" + "=" * 80)
            print("⚠️  HIGH IMPACT CHANGE DETECTED")
            print("\nThis change may affect critical system behavior.")
            print("\nRecommended:")
            print("  • run related tests")
            print("  • verify downstream services")
            print("  • review impact summary")
            print("\nCommit will proceed.")
            print("=" * 80)
        
        return 0
        
    except Exception as e:
        print(f"❌ Error during assessment: {str(e)}")
        return 1


def _run_risk_assessment(symbols: List[str], change_types: Dict[str, str]) -> str:
    """
    Run risk assessment for changed symbols.
    
    Args:
        symbols: List of changed symbol names
        change_types: Dict mapping symbols to change types
        
    Returns:
        Highest risk level found: "HIGH", "MEDIUM", or "LOW"
    """
    from checkod.assess import assess_risk

    print("\n📍 Analyzing risk for each symbol...\n")
    
    highest_risk = "LOW"  # Track highest risk level
    risk_hierarchy = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    
    for symbol in symbols:
        try:
            # Get change type for context
            change_type = change_types.get(symbol, "unknown")
            
            # Build context about the change
            usage_locations = [f"[{change_type}]"]  # Add change type as context
            
            # In a real implementation, we would have symbol usage data
            # For now, use change type as context for the LLM
            risk_assessment = assess_risk(symbol, usage_locations)
            
            # Extract risk level from assessment (look for HIGH/MEDIUM/LOW)
            current_risk = "MEDIUM"  # Default
            if "HIGH" in risk_assessment.upper():
                current_risk = "HIGH"
            elif "LOW" in risk_assessment.upper():
                current_risk = "LOW"
            
            # Update highest risk
            if risk_hierarchy.get(current_risk, 0) > risk_hierarchy.get(highest_risk, 0):
                highest_risk = current_risk
            
            print(f"Symbol: {symbol}")
            print(f"Change: {change_type}")
            print("-" * 40)
            print(risk_assessment)
            print()
            
        except Exception as e:
            print(f"⚠️  Risk assessment failed for {symbol}: {str(e)}\n")
    
    return highest_risk


def _generate_summary_report(
    symbols: List[str],
    change_types: Dict[str, str],
    default_risk: str
) -> str:
    """
    Generate impact summaries for each changed symbol.
    
    Args:
        symbols: List of changed symbols
        change_types: Dict mapping symbols to change types
    """
    symbols_with_impact: Dict[str, Dict] = {}

    # Tabular summary: Symbol | Change Type | Risk Level
    lines = []
    lines.append(f"{'Symbol':<25} {'Change Type':<20} {'Risk':<8}")
    lines.append('-' * 56)
    for symbol in symbols:
        change_type = change_types.get(symbol, "unknown")
        risk = default_risk
        lines.append(f"{symbol:<25} {change_type:<20} {risk:<8}")
    return '\n'.join(lines)

