# CheckodAI

AI Impact Assessment for code changes - understand what Copilot changed before you commit it.

## Overview

CheckodAI is a Python CLI tool that helps developers understand the scope and implications of their code changes by analyzing git diffs and extracting modified symbols (functions, classes, variables). It can optionally use a local LLM (Ollama) to assess the risk of each change.

## Privacy

CheckodAI runs entirely locally.

- No code is uploaded
- No cloud calls required
- No telemetry
- Works offline with local LLM (Ollama)

All analysis happens on your machine.


**Features (Simple):**
- Local-first: Runs entirely on your machine with no cloud calls or telemetry.
- Impact Assessment: Detects specific changes to functions, classes, and variables and provides human-readable recommendations for each modified symbol.
- AI-powered risk assessment: Utilizes local Ollama for intelligent impact analysis and scoring.
- CLI-first: `checkod assess` and `checkod assess-ai`
- Works offline, no telemetry

## Installation

### Prerequisites
- Python 3.8+
- Git
- Ollama (optional, for AI risk assessment)


## Initial Setup

Install from PyPI:
```bash
pip install checkod-ai
```

## How to Use

1. **Make your code change** (or let Copilot make changes)

2. **Stage your changes with git**
  ```bash
  git add .
  # For new files, you may need:
  git add -N .
  ```


3. **Run the assessment (no AI)**
  ```bash
  checkod assess
  ```

  Or, to use AI-powered risk assessment (requires Ollama):
  ```bash
  checkod assess-ai
  ```


> **Note:** For newly created files, you must run `git add -N .` (intent-to-add) so that `checkod assess` or `checkod assess-ai` can detect them. This is a git limitation for diff tools.

## Usage

### Basic Commands

Analyze changes in the current repository:
```bash
checkod assess
```

Analyze a specific repository:
```bash
checkod assess --repo /path/to/repo
```

### Example Output

```
==============================
📊 File Change Assessment
==============================
File                            +Lines  -Lines
------------------------------------------------
README.md                            9       2
checkod/main.py                     42       8

--------------------------------

================================================================================
📋 Impact Summary
================================================================================
Symbol                    Change Type          Risk    
--------------------------------------------------------
assess_ai                 function added       LOW     
exit_code                 variable added       LOW     
repo_path                 variable added       LOW     
enable_risk_assessment    variable added       LOW     
diff_range                variable added       LOW     
include_untracked         variable added       LOW     
help                      variable added       LOW     

This may affect:
  • diff_range_service (logic flow)
  • enable_risk_assessment_service (logic flow)
  • exit_code_service (logic flow)
  • help_service (logic flow)
  • include_untracked_service (logic flow)
  • repo_path_service (logic flow)
  • /api/diff_range (user-facing behavior)
  • /api/enable_risk_assessment (user-facing behavior)
  • /api/exit_code (user-facing behavior)

  • test_repo_path (test coverage)

✅ Assessment complete!
```

### Optional: Install Ollama for AI Risk Assessment

Ollama enables intelligent risk scoring. Install and configure:

```bash
# macOS / Linux
curl -fsSL https://ollama.ai/install.sh | sh

# Or use Homebrew (macOS)
brew install ollama

# Pull the model
ollama pull llama3

# Start the server (runs on localhost:11434)
ollama serve
```

With Ollama running, you'll also get AI-powered risk assessment:

```
================================================================================
Risk Assessment
================================================================================
Details

File: src/payment.py - Symbol: process_payment
Risk: MEDIUM
Summary: This function was modified to add new logic for payment retries. Review for edge cases and ensure all payment gateways are supported. Add integration and regression tests.

File: src/payment.py - Symbol: PaymentGateway
Risk: LOW
Summary: This class was refactored for clarity. Confirm that all gateway subclasses are compatible and update documentation as needed.

File: src/user.py - Symbol: userTier
Risk: LOW
Summary: Variable added to support new user segmentation. Validate tier assignment logic and update user onboarding tests.

File: src/user.py - Symbol: upgrade_account
Risk: HIGH
Summary: Function signature changed. This affects account upgrade flow. Review downstream services, update API docs, and run full test suite for upgrade scenarios.

File: src/api/orders.py - Symbol: OrderStatus
Risk: LOW
Summary: Enum values updated. Ensure all order states are handled in frontend and backend. Add tests for new states.

File: src/api/orders.py - Symbol: calculateDiscount
Risk: MEDIUM
Summary: Function logic changed. Test discount calculation across pricing tiers and verify integration with checkout service.

✅ Assessment complete!
```

## How It Works

1. **Reads git diff** - Gets all staged and unstaged changes
2. **Extracts symbols** - Finds functions, classes, and variables
3. **Detects change type** - Identifies what kind of change was made
4. **Assesses risk** - Uses local AI (Ollama) or heuristics
5. **Generates recommendations** - Suggests testing and review actions
6. **Advisory warnings** - HIGH risk changes trigger warnings

---

**Note**: This is an early-stage project. The API and behavior are subject to change.
