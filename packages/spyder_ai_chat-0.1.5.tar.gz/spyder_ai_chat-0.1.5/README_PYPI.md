# Spyder AI Chat

An OpenAI-compatible AI chat panel for **Spyder 6.x**.  
Connect to **OpenAI**, **Groq**, **Ollama**, **LM Studio**, or any server that
exposes an OpenAI-compatible `/v1/chat/completions` endpoint — all from inside
your IDE, without switching windows.

© 2026 Maciej Piecko — MIT License

---

## Features

| | Feature | Details |
|---|---|---|
| 🗨️ | Chat panel | Scrollable conversation with colour-coded user / assistant messages |
| ⚡ | Streaming | Token-by-token streaming so you see the reply as it is generated |
| 🔁 | Model selector | Dropdown populated live from the API — switch models instantly |
| 🔧 | Any provider | OpenAI cloud, Groq, Ollama, LM Studio, or any OpenAI-compatible server |
| 🔑 | Optional API key | Leave blank for local models that need no authentication |
| 🧠 | System prompt | Optional field to set the assistant's persona or task context |
| ⏹ | Stop | Cancel a streaming reply at any time |
| 🗑 | New Chat | Start a fresh conversation; the current one is saved automatically |
| 📋 | Chat history | Browse, load, and delete saved chats; active chat highlighted in green |
| 📎 | File context | Attach whole files or selected text from the editor as context |
| 🖊️ | Markdown rendering | Headings, bold, italic, lists, tables, code blocks, blockquotes, links, strikethrough |
| 🧠 | Thinking blocks | `<think>` tags rendered as a collapsible thinking box (DeepSeek-R1, QwQ, …) |
| 📋 | Copy to editor | Insert any code block or full response at the cursor in the active file |
| ↔ | Horizontal scroll | Wide code blocks scroll horizontally instead of wrapping |
| ⚙ | Settings | Tabbed dialog: API connection, per-element font sizes, history saving options |

---

## Requirements

- Python ≥ 3.9
- Spyder ≥ 6.0
- No additional Python packages — HTTP via `urllib` (stdlib), UI via Qt (bundled with Spyder)

---

## Installation

### From PyPI

```bash
pip install spyder-ai-chat
```

### From source / development build

```bash
# Unzip the release archive or clone the repository, then:
cd spyder_ai_chat
pip install -e .
```

> **Important:** install into the **same Python environment that Spyder uses**.  
> If you launched Spyder from a conda environment, activate that environment first.

After installation, **restart Spyder**.  
The panel appears automatically. If it is not visible, go to
**View → Panes → AI Chat**.

---

## Quick start

1. Open **Settings** (⚙ button in the panel toolbar).
2. On the **Connection** tab, enter your API base URL and key:
   - OpenAI: `https://api.openai.com/v1` + your `sk-…` key
   - Groq: `https://api.groq.com/openai/v1` + your `gsk_…` key
   - Ollama (local): `http://localhost:11434/v1` — leave the key blank
3. Click **⟳** to load the model list and pick a model.
4. Type a message and press **Ctrl+Enter** or click **Send**.

---

## License

MIT — see the `LICENSE` file included in the package.
