# Spyder AI Chat Plugin

An OpenAI-compatible chat pane for **Spyder 6.x**.  
Supports **OpenAI**, **Groq**, **Ollama**, **LM Studio**, and any other server that exposes an OpenAI-compatible `/v1/chat/completions` endpoint.

© 2026 Maciej Piecko — MIT License

---

## Features

| Feature | Details |
|---|---|
| 🗨️ Chat UI | Scrollable conversation with colour-coded user / assistant messages |
| ⚡ Streaming | Token-by-token streaming so you see the reply as it is generated |
| 🧠 System prompt | Optional system prompt field to set the assistant's persona |
| 🔁 Model selector | Dropdown populated from the API — switch models without leaving Spyder |
| 🔧 Configurable URL | Works with OpenAI cloud, Groq, Ollama, LM Studio, and any compatible server |
| 🔑 Optional API key | Leave blank for local models that don't require authentication |
| ⏹ Stop button | Cancel a streaming reply at any time |
| 🗑 New Chat | Save current chat to history and start a fresh conversation |
| 📋 Chat history | Browse, load, and delete saved chats — active chat highlighted in green |
| 📎 File context | Add whole files or selected text as structured attachments; shown as locked badges in chat |
| 🖊️ Markdown rendering | Full markdown: headings, bold, italic, lists, tables, code blocks, blockquotes, links, strikethrough |
| 🧠 Thinking blocks | `<think>...</think>` tags rendered as a collapsible thinking box |
| 📋 Copy to editor | Insert code blocks or full responses directly into the active editor |
| ↔ Horizontal scroll | Chat area scrolls horizontally when code blocks are wider than the pane |
| ⚙ Settings | Tabbed settings dialog: API connection, editor font sizes, history saving options |

---

## Installation

### Install from source (recommended while in development)

```bash
# Unzip the release archive, then:
cd spyder_ai_chat
pip install -e .
```

> **Important:** install into the **same Python environment that Spyder uses**.  
> If you launched Spyder from a conda environment, activate that environment first.

After installation, **restart Spyder**.  
The plugin appears automatically; if the pane is not visible go to  
**View → Panes → AI Chat** to show it.

---

## Configuration

Click the **⚙ Settings** button in the plugin pane toolbar to open the tabbed settings dialog.

### Tab 1 — Connection

| Provider | URL |
|---|---|
| OpenAI (cloud) | `https://api.openai.com/v1` |
| Groq | `https://api.groq.com/openai/v1` |
| Ollama (local) | `http://localhost:11434/v1` |
| LM Studio | `http://localhost:1234/v1` |
| Any OpenAI-compatible server | `http://<host>:<port>/v1` |

- **OpenAI / Groq**: paste your API key.
- **Ollama / LM Studio**: leave the API key blank (or type anything — it is ignored).

### Tab 2 — Editor

Configure font sizes (6–24 pt) for each rendered element independently:

| Setting | Default | Affects |
|---|---|---|
| Base text | 10 pt | Paragraphs, blockquotes |
| Code blocks | 10 pt | Fenced code block content |
| Headings (H1 base) | 14 pt | H1 = base, H2 = base−2, H3 = base−4 |
| Lists | 10 pt | Bullet and numbered lists |
| Tables | 10 pt | Table header and data cells |
| Thinking box | 9 pt | `<think>` block content |

Changes apply to new messages rendered after saving.

### Tab 3 — History

- **Automatically save chats to history** — when on, every completed exchange is written to disk silently. When off, nothing is saved automatically.
- **Save unsent chat when starting New Chat** — only relevant when auto-save is off; gives a one-time save at the moment you click New Chat so the unsaved conversation is not lost.

---

## Usage

### Sending messages

1. Type your message in the input box at the bottom.
2. Press **Ctrl+Enter** or click **Send**.
3. The assistant's reply streams in above in real time.
4. Click **Stop** to cancel a reply mid-stream.

### Model selection

Click the model name button at the top of the pane to open the model dropdown.  
Click **⟳** to refresh the model list from the API.

### System prompt

Type a system prompt in the field above the input box to guide the assistant's behaviour, e.g. *"You are a helpful Python debugging assistant."*

### Adding file context

Right-click in any editor tab to access the **AI Chat** submenu:

- **Add whole file to context** — attaches the current file's full content.
- **Add selection to context** — attaches the currently highlighted text (enabled only when text is selected).

Context tags appear above the input box and can be individually dismissed before sending. Once the message is sent, the tags become locked badges (📎 for files, ✂ for selections) displayed inside the user message bubble — showing exactly which files were attached to which message. Attachment content is stored as structured metadata in the chat JSON, separate from the message text.

### Chat history

Click the checklist icon (🗒) in the toolbar to open the chat history popup. Each entry shows the first message preview and the date saved.

- **Click an entry** to load that chat (the current chat is saved first if auto-save is on).
- **✕** — permanently delete a chat. If the currently open chat is deleted, the chat window clears automatically.
- The **active chat** is highlighted with a green background so you always know which one is loaded.
- Sort order is by creation date and never changes when a chat is re-opened.

Chats are saved to `~/.spyder_ai_chat/chats/`.

### Markdown rendering

The assistant's responses are fully rendered with:

- **Headings** (H1 – H3) with scaled sizes and teal colour
- **Bold**, *italic*, ***bold+italic***, ~~strikethrough~~, `inline code`
- Bullet lists (with `•` / `◦` for nested items) and numbered lists
- Blockquotes with a blue left border
- Fenced code blocks with language label and **Copy to editor** button
- Tables with header row and alternating row shading
- Clickable hyperlinks (open in browser)
- Horizontal scrollbar when code blocks exceed the pane width
- `<think>...</think>` blocks rendered as a collapsible **Thinking** box with a dark green background — useful for reasoning models such as DeepSeek-R1, QwQ, and Qwen-thinking variants

### Ollama quick-start

```bash
# Install Ollama from https://ollama.com, then:
ollama serve          # starts the server on port 11434
ollama pull llama3    # download a model
```

In **Settings → Connection** set:
- **API URL**: `http://localhost:11434/v1`
- **API key**: *(leave blank)*

---

## Data storage

All plugin data is stored under `~/.spyder_ai_chat/`:

| Path | Contents |
|---|---|
| `state.json` | API URL, selected model, model list cache, editor font sizes, history settings |
| `chats/` | One JSON file per saved chat session (filename = timestamp) |

Each chat JSON file contains: `saved_at`, `preview`, `model`, `system_prompt`, and the `messages` array. User messages with attachments store the file content in a structured `attachments` list separate from the message text.

---

## Project structure

```
spyder_ai_chat/
├── pyproject.toml               # Build config, version, author, license
├── README.md
├── LICENSE                      # MIT
└── spyder_ai_chat/
    ├── __init__.py              # Package init
    ├── plugin.py                # SpyderDockablePlugin subclass —
    │                            #   Spyder integration, editor context
    │                            #   menu injection (Add file / Add selection)
    ├── confpage.py              # Preferences page (reserved for future use)
    └── widgets/
        ├── __init__.py
        ├── chat_widget.py          # Main chat panel UI, streaming API worker,
        │                           #   model popup, chat history popup,
        │                           #   file context bar, state persistence
        ├── chat_history_manager.py # File-per-chat JSON storage:
        │                           #   save / load / delete / list chats
        ├── markdown_renderer.py    # Markdown → Qt widgets renderer:
        │                           #   headings, paragraphs, lists, tables,
        │                           #   code blocks, blockquotes, think blocks,
        │                           #   inline formatting, configurable font sizes
        └── settings_dialog.py      # Tabbed settings dialog:
                                    #   Connection, Editor font sizes, History options
```

---

## Requirements

- Python ≥ 3.9
- Spyder ≥ 6.0
- No extra Python packages — uses only `urllib` from the standard library for HTTP and Qt (already bundled with Spyder) for the UI.

---

## Changelog

### 0.1.4
- Tabbed settings dialog (refactored into `settings_dialog.py`): Connection, Editor, History tabs
- Configurable font sizes for all rendered markdown elements (base text, code, headings, lists, tables, thinking box)
- History saving options: auto-save toggle and save-on-new-chat toggle with correct enable/disable logic
- Horizontal scrollbar in chat area for wide code blocks
- File/text context attachments restructured: content stored separately from message text in JSON; sent-attachments shown as locked badges inside user message bubbles
- Attachments supported on any message (removed first-message-only restriction)
- Active chat highlighted in green in the history list
- Deleting the currently open chat from the history list now clears the chat window immediately
- Fixed: deleted chat no longer reappears when reopening the history popup

### 0.1.3
- Added `User-Agent` header to fix 403 errors with Groq and some other providers
- Improved HTTP error reporting — status bar now shows the full error reason
- Copyright notice `(C) 2026 by Maciej Piecko` added to all module docstrings

### 0.1.2
- Full markdown rendering module (`markdown_renderer.py`): headings, bold/italic, lists, tables, blockquotes, links, strikethrough
- `<think>...</think>` block support with collapsible thinking box
- Chat history: save, load, delete, and browse past conversations
- Auto-save after every completed exchange
- Editor context menu: Add whole file / Add selection to context
- Chat history popup with checklist icon button
- Dynamic theme support (dark/light) for menus and popups

### 0.1.0
- Initial release: streaming chat, model selector, system prompt, stop button, code block rendering with Copy to editor

---

## License

MIT — see `LICENSE` file.
