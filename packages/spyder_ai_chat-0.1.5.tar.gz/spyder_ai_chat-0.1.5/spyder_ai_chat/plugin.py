# -*- coding: utf-8 -*-
"""Spyder AI Chat Plugin (C) 2026 by Maciej Piecko"""

from spyder.api.plugins import SpyderDockablePlugin
from spyder.api.translations import get_translation
from .widgets.chat_widget import AIChatWidget

_ = get_translation("spyder_ai_chat")


class AIChatPlugin(SpyderDockablePlugin):

    NAME         = "ai_chat"
    WIDGET_CLASS = AIChatWidget
    CONF_SECTION = "ai_chat"
    REQUIRES     = []
    try:
        from spyder.api.plugins import Plugins as _P
        OPTIONAL = [_P.Editor]
    except Exception:
        OPTIONAL = ['editor']

    @staticmethod
    def get_name():
        return "AI Chat"

    @staticmethod
    def get_description():
        return "Chat with AI via OpenAI-compatible API"

    @classmethod
    def get_icon(cls):
        return cls.create_icon("editcopy")

    def on_initialize(self):
        widget = self.get_widget()
        widget.set_editor_cursor_fn(self._get_editor_cursor)
        from qtpy.QtCore import QTimer
        QTimer.singleShot(2000, self._hook_editor_context_menu)

    def register(self):
        pass

    # ── menu injection ────────────────────────────────────────────────

    def _inject_into_editor(self, editor):
        """Inject AI Chat submenu into this editor's context menu via aboutToShow."""
        if editor is None:
            return
        if getattr(editor, '_ai_chat_injected', False):
            return
        try:
            menu        = editor.menu
            submenu     = self._ai_submenu
            sel_action  = self._sel_action

            # Track selection state via signal — more reliable than
            # querying cursor at aboutToShow time (right-click can clear selection)
            def _on_selection_changed():
                try:
                    editor._ai_chat_has_selection = editor.textCursor().hasSelection()
                except Exception:
                    editor._ai_chat_has_selection = False

            editor.selectionChanged.connect(_on_selection_changed)
            editor._ai_chat_has_selection = False

            def _on_about_to_show():
                # Add submenu if not already present
                for act in menu.actions():
                    if act is self._submenu_action:
                        sel_action.setEnabled(
                            getattr(editor, '_ai_chat_has_selection', False))
                        return
                menu.addSeparator()
                menu.addAction(self._submenu_action)
                sel_action.setEnabled(
                    getattr(editor, '_ai_chat_has_selection', False))

            menu.aboutToShow.connect(_on_about_to_show)
            editor._ai_chat_injected = True
        except Exception:
            pass

            menu.aboutToShow.connect(_on_about_to_show)
            editor._ai_chat_injected = True
        except Exception:
            pass

    def _hook_editor_context_menu(self):
        try:
            from spyder.api.plugins import Plugins
            from qtpy.QtWidgets import QAction
            from qtpy.QtCore import QTimer

            editor_plugin = self.get_plugin(Plugins.Editor)
            if editor_plugin is None:
                return

            if not hasattr(self, '_ai_submenu'):
                # Give it the main window as parent so it inherits Spyder's stylesheet
                try:
                    from qtpy.QtWidgets import QApplication
                    main_win = QApplication.instance().activeWindow()
                    if main_win is None:
                        main_win = next(
                            (w for w in QApplication.topLevelWidgets()
                             if w.isVisible()), None)
                except Exception:
                    main_win = None

                try:
                    from spyder.api.widgets.menus import SpyderMenu
                    self._ai_submenu = SpyderMenu(title="AI Chat", parent=main_win)
                except Exception:
                    from qtpy.QtWidgets import QMenu
                    self._ai_submenu = QMenu("AI Chat", main_win)

                self._file_action = QAction("➕ Add whole file to context", None)
                self._file_action.triggered.connect(self._on_add_current_file)

                self._sel_action = QAction("➕ Add selection to context", None)
                self._sel_action.triggered.connect(self._on_add_selection)
                self._sel_action.setEnabled(False)

                self._ai_submenu.addAction(self._file_action)
                self._ai_submenu.addAction(self._sel_action)

                # QAction that carries the submenu — added to editor.menu
                self._submenu_action = QAction("AI Chat", None)
                self._submenu_action.setMenu(self._ai_submenu)

            def _hook_editorstack(editorstack):
                if editorstack is None:
                    return
                try:
                    self._inject_into_editor(editorstack.get_current_editor())
                except Exception:
                    pass
                if not getattr(editorstack, '_ai_chat_hooked', False):
                    try:
                        editorstack.editor_focus_changed.connect(
                            lambda es=editorstack:
                                self._inject_into_editor(es.get_current_editor()))
                    except Exception:
                        pass
                    try:
                        editorstack.sig_codeeditor_created.connect(
                            self._inject_into_editor)
                    except Exception:
                        pass
                    editorstack._ai_chat_hooked = True

            try:
                ew = editor_plugin.get_widget()
                for es in self._iter_editorstacks(ew):
                    _hook_editorstack(es)
            except Exception:
                pass
            try:
                _hook_editorstack(editor_plugin.get_current_editorstack())
            except Exception:
                pass

            self._hook_attempts = getattr(self, '_hook_attempts', 0) + 1
            if self._hook_attempts < 5:
                QTimer.singleShot(3000, self._hook_editor_context_menu)

        except Exception:
            pass

    def _iter_editorstacks(self, widget):
        from qtpy.QtWidgets import QWidget
        results = []
        try:
            if type(widget).__name__ == 'EditorStack':
                results.append(widget)
            for child in widget.children():
                if isinstance(child, QWidget):
                    results.extend(self._iter_editorstacks(child))
        except Exception:
            pass
        return results

    # ── actions ───────────────────────────────────────────────────────

    def _get_current_editor_and_filename(self):
        """Return (editor, name) or (None, None)."""
        try:
            from spyder.api.plugins import Plugins
            import os
            editor_plugin = self.get_plugin(Plugins.Editor)
            if editor_plugin is None:
                return None, None
            editor = None
            for fn in [
                lambda: editor_plugin.get_current_editorstack().get_current_editor(),
                lambda: editor_plugin.get_current_editor(),
                lambda: editor_plugin.get_widget().get_current_editorstack().get_current_editor(),
            ]:
                try:
                    ed = fn()
                    if ed is not None:
                        editor = ed
                        break
                except Exception:
                    pass
            if editor is None:
                return None, None
            path = None
            for fn in [
                lambda: editor_plugin.get_current_filename(),
                lambda: editor_plugin.get_current_editorstack().get_current_filename(),
                lambda: editor_plugin.get_widget().get_current_editorstack().get_current_filename(),
            ]:
                try:
                    p = fn()
                    if p:
                        path = p
                        break
                except Exception:
                    pass
            name = os.path.basename(path) if path else "unsaved file"
            return editor, name
        except Exception:
            return None, None

    def _on_add_current_file(self):
        """Add the full content of the current editor file to AI Chat context."""
        try:
            editor, name = self._get_current_editor_and_filename()
            if editor is None:
                return
            import os
            ext = os.path.splitext(name)[1].lower()
            text_exts = {
                '.py', '.txt', '.md', '.js', '.ts', '.html', '.css',
                '.json', '.yaml', '.yml', '.toml', '.ini', '.cfg',
                '.rst', '.xml', '.csv', '.sh', '.bat', '.c', '.cpp',
                '.h', '.java', '.rs', '.go', '.rb', '.php',
            }
            if name != "unsaved file" and ext not in text_exts:
                return
            content = editor.toPlainText()
            if content:
                self.get_widget().add_file_context_content(name, content)
        except Exception:
            pass

    def _on_add_selection(self):
        """Add the currently selected text to AI Chat context."""
        try:
            editor, name = self._get_current_editor_and_filename()
            if editor is None:
                return
            cursor = editor.textCursor()
            if not cursor.hasSelection():
                return
            selected = cursor.selectedText()
            # Qt uses Unicode paragraph separator \u2029 for newlines
            selected = selected.replace('\u2029', '\n')
            if not selected.strip():
                return
            # Give it a unique label: "<filename> selection <n>"
            sel_id = self.get_widget().next_selection_id(name)
            label  = f"{name} selection {sel_id}"
            self.get_widget().add_file_context_content(label, selected)
        except Exception:
            pass

    def _get_editor_cursor(self):
        diag = []
        try:
            from spyder.api.plugins import Plugins
            editor_plugin = self.get_plugin(Plugins.Editor)
            if editor_plugin is None:
                return None, "editor_plugin is None"
            editor = None
            for attempt, fn in enumerate([
                lambda: editor_plugin.get_current_editorstack().get_current_editor(),
                lambda: editor_plugin.get_current_editor(),
                lambda: editor_plugin.get_widget().get_current_editorstack().get_current_editor(),
                lambda: editor_plugin.get_widget().editorsplitter.editorstack.get_current_editor(),
            ]):
                try:
                    result = fn()
                    if result is not None:
                        editor = result
                        break
                except Exception as e:
                    diag.append(f"attempt {attempt} failed: {e}")
            if editor is not None:
                return editor.textCursor(), editor
        except Exception as e:
            diag.append(f"outer exception: {e}")
        return None, " | ".join(str(d) for d in diag)
