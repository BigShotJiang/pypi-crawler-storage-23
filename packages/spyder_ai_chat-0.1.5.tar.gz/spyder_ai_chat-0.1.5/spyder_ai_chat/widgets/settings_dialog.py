# -*- coding: utf-8 -*-
"""Settings dialog for AI Chat plugin (C) 2026 by Maciej Piecko"""

from qtpy.QtWidgets import (
    QDialog, QTabWidget, QWidget, QFormLayout, QVBoxLayout,
    QLineEdit, QLabel, QDialogButtonBox, QSpinBox, QCheckBox,
)
from qtpy.QtCore import Qt


# Default font size configuration
EDITOR_DEFAULTS = {
    "fs_base":    10,
    "fs_code":    10,
    "fs_heading": 14,
    "fs_list":    10,
    "fs_table":   10,
    "fs_think":    9,
}

HISTORY_DEFAULTS = {
    "autosave":    True,
    "save_on_new": True,
}


class SettingsDialog(QDialog):
    """
    Tabbed settings dialog with three tabs:
      1. Connection  — API URL and key
      2. Editor      — font sizes for rendered markdown elements
      3. History     — auto-save toggles
    """

    def __init__(self, parent, api_url, api_key, editor_cfg, history_cfg):
        super().__init__(parent)
        self.setWindowTitle("AI Chat – Settings")
        self.setMinimumWidth(480)
        self.setMinimumHeight(340)

        tabs = QTabWidget()

        # ── Tab 1: Connection ────────────────────────────────────────
        conn_w = QWidget()
        form = QFormLayout(conn_w)
        form.setContentsMargins(12, 12, 12, 12)
        form.setSpacing(8)

        self.url_edit = QLineEdit(api_url)
        self.url_edit.setToolTip(
            "OpenAI:    https://api.openai.com/v1\n"
            "Groq:      https://api.groq.com/openai/v1\n"
            "Ollama:    http://localhost:11434/v1\n"
            "LM Studio: http://localhost:1234/v1")
        form.addRow("API base URL:", self.url_edit)

        self.key_edit = QLineEdit(api_key)
        self.key_edit.setEchoMode(QLineEdit.Password)
        self.key_edit.setPlaceholderText("sk-…  (blank for local models)")
        form.addRow("API key:", self.key_edit)

        tabs.addTab(conn_w, "🔌 Connection")

        # ── Tab 2: Editor (font sizes) ───────────────────────────────
        editor_w = QWidget()
        ef = QFormLayout(editor_w)
        ef.setContentsMargins(12, 12, 12, 12)
        ef.setSpacing(8)

        def _spin(key):
            s = QSpinBox()
            s.setRange(6, 24)
            s.setValue(editor_cfg.get(key, EDITOR_DEFAULTS[key]))
            s.setSuffix(" pt")
            s.setFixedWidth(72)
            return s

        self.fs_base    = _spin("fs_base")
        self.fs_code    = _spin("fs_code")
        self.fs_heading = _spin("fs_heading")
        self.fs_list    = _spin("fs_list")
        self.fs_table   = _spin("fs_table")
        self.fs_think   = _spin("fs_think")

        ef.addRow("Base text:", self.fs_base)
        ef.addRow("Code blocks:", self.fs_code)
        ef.addRow("Headings (H1 base):", self.fs_heading)
        ef.addRow("Lists:", self.fs_list)
        ef.addRow("Tables:", self.fs_table)
        ef.addRow("Thinking box:", self.fs_think)

        note = QLabel("Changes apply to new messages after saving.")
        note.setStyleSheet("color: gray; font-size: 9pt;")
        ef.addRow(note)
        tabs.addTab(editor_w, "🖊 Editor")

        # ── Tab 3: History ───────────────────────────────────────────
        hist_w = QWidget()
        hl = QVBoxLayout(hist_w)
        hl.setContentsMargins(12, 12, 12, 12)
        hl.setSpacing(8)

        self.cb_autosave = QCheckBox("Automatically save chats to history")
        self.cb_autosave.setChecked(
            history_cfg.get("autosave", HISTORY_DEFAULTS["autosave"]))

        self.cb_save_on_new = QCheckBox(
            "Save unsent chat when starting New Chat")
        self.cb_save_on_new.setChecked(
            history_cfg.get("save_on_new", HISTORY_DEFAULTS["save_on_new"]))

        # save_on_new only matters when auto-save is OFF —
        # if auto-save is on the chat is already saved continuously
        def _sync_hist():
            enabled = not self.cb_autosave.isChecked()
            self.cb_save_on_new.setEnabled(enabled)
            if not enabled:
                self.cb_save_on_new.setChecked(True)
        self.cb_autosave.toggled.connect(_sync_hist)
        _sync_hist()

        # Info notice
        info = QLabel(
            "<b>How it works:</b><br>"
            "When <i>auto-save</i> is on, every completed exchange (your message "
            "and the AI reply) is written to disk automatically — you never lose "
            "a conversation.<br><br>"
            "When <i>auto-save</i> is off, nothing is saved unless you manually "
            "load a chat from history. In that case, <i>Save unsent chat on New Chat</i> "
            "gives you a one-time save at the moment you click New Chat, so the "
            "current unsaved conversation is not lost."
        )
        info.setWordWrap(True)
        info.setTextFormat(Qt.RichText)
        info.setStyleSheet(
            "color: gray; font-size: 9pt; padding: 8px; "
            "background: rgba(128,128,128,0.08); border-radius: 4px;")

        hl.addWidget(self.cb_autosave)
        hl.addWidget(self.cb_save_on_new)
        hl.addSpacing(4)
        hl.addWidget(info)
        hl.addStretch()
        tabs.addTab(hist_w, "🗂 History")

        # ── Dialog buttons ───────────────────────────────────────────
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(tabs)
        lay.addWidget(btns)

    def values(self):
        """Return all settings as a dict ready to pass to _save_state."""
        return {
            "api_url": self.url_edit.text().strip(),
            "api_key": self.key_edit.text().strip(),
            "editor": {
                "fs_base":    self.fs_base.value(),
                "fs_code":    self.fs_code.value(),
                "fs_heading": self.fs_heading.value(),
                "fs_list":    self.fs_list.value(),
                "fs_table":   self.fs_table.value(),
                "fs_think":   self.fs_think.value(),
            },
            "history": {
                "autosave":    self.cb_autosave.isChecked(),
                "save_on_new": self.cb_save_on_new.isChecked(),
            },
        }
