# -*- coding: utf-8 -*-
"""
Markdown → Qt widgets renderer for AI Chat responses. (C) 2026 by Maciej Piecko

Supported elements:
  - Headings (#, ##, ###)
  - Bold (**text** or __text__)
  - Italic (*text* or _text_)
  - Bold+Italic (***text***)
  - Inline code (`code`)
  - Fenced code blocks (```lang ... ```)
  - Bullet lists (-, *, +)
  - Numbered lists (1. 2. etc.)
  - Blockquotes (> text)
  - Horizontal rules (--- or ***)
  - Tables (| col | col |)
  - Strikethrough (~~text~~)
  - Links ([text](url))
  - Plain paragraphs
"""

import re
from qtpy.QtCore import Qt, Signal
from qtpy.QtGui import QFont, QColor
from qtpy.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QSizePolicy, QGridLayout,
)


# ---------------------------------------------------------------------------
# Inline markdown → HTML  (used inside QLabel with RichText)
# ---------------------------------------------------------------------------
def _inline_to_html(text):
    """Convert inline markdown to HTML for use in a QLabel."""
    # Escape HTML special chars first (except we'll add our own tags)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    # Bold + Italic: ***text*** or ___text___
    text = re.sub(r'\*{3}(.+?)\*{3}', r'<b><i>\1</i></b>', text)
    text = re.sub(r'_{3}(.+?)_{3}',   r'<b><i>\1</i></b>', text)

    # Bold: **text** or __text__
    text = re.sub(r'\*{2}(.+?)\*{2}', r'<b>\1</b>', text)
    text = re.sub(r'_{2}(.+?)_{2}',   r'<b>\1</b>', text)

    # Italic: *text* or _text_  (not inside words)
    text = re.sub(r'(?<!\w)\*(.+?)\*(?!\w)', r'<i>\1</i>', text)
    text = re.sub(r'(?<!\w)_(.+?)_(?!\w)',   r'<i>\1</i>', text)

    # Strikethrough: ~~text~~
    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    # Inline code: `code`
    text = re.sub(r'`([^`]+)`',
                  r'<code style="background:#1e1e1e;color:#d4d4d4;'
                  r'padding:1px 4px;border-radius:3px;">\1</code>', text)

    # Links: [text](url)
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)',
                  r'<a href="\2" style="color:#4ec9b0;">\1</a>', text)

    return text


# ---------------------------------------------------------------------------
# Block-level parser — splits raw markdown into block tokens
# ---------------------------------------------------------------------------
def parse_blocks(text):
    """
    Parse markdown text into a list of block tokens.
    Each token is a dict with a 'type' key and type-specific fields.
    """
    # ── pre-pass: extract <think>...</think> blocks ───────────────────
    # Split text into think/non-think segments before line parsing
    raw_blocks = []
    think_pattern = re.compile(r'<think>(.*?)</think>', re.DOTALL | re.IGNORECASE)
    last = 0
    for m in think_pattern.finditer(text):
        if m.start() > last:
            raw_blocks.append(("text", text[last:m.start()]))
        raw_blocks.append(("think", m.group(1).strip()))
        last = m.end()
    if last < len(text):
        raw_blocks.append(("text", text[last:]))

    blocks = []
    for seg_type, seg_text in raw_blocks:
        if seg_type == "think":
            blocks.append({"type": "think", "content": seg_text})
        else:
            blocks.extend(_parse_text_blocks(seg_text))
    return blocks


def _parse_text_blocks(text):
    """Parse a plain text segment into markdown blocks (no think tags)."""
    lines  = text.splitlines()
    blocks = []
    i      = 0

    while i < len(lines):
        line = lines[i]

        # ── fenced code block ────────────────────────────────────────
        m = re.match(r'^```(\w*)\s*$', line)
        if m:
            lang  = m.group(1)
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1  # skip closing ```
            blocks.append({"type": "code", "lang": lang,
                           "content": "\n".join(code_lines)})
            continue

        # ── heading ──────────────────────────────────────────────────
        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            level = len(m.group(1))
            blocks.append({"type": "heading", "level": level,
                           "content": m.group(2).strip()})
            i += 1
            continue

        # ── horizontal rule ──────────────────────────────────────────
        if re.match(r'^(---+|\*\*\*+|___+)\s*$', line):
            blocks.append({"type": "hr"})
            i += 1
            continue

        # ── blockquote ───────────────────────────────────────────────
        if line.startswith("> ") or line == ">":
            quote_lines = []
            while i < len(lines) and (lines[i].startswith("> ") or
                                       lines[i] == ">"):
                quote_lines.append(lines[i][2:] if lines[i].startswith("> ")
                                   else lines[i][1:])
                i += 1
            blocks.append({"type": "blockquote",
                           "content": "\n".join(quote_lines)})
            continue

        # ── table ────────────────────────────────────────────────────
        if "|" in line and i + 1 < len(lines) and re.match(
                r'^\s*\|?[\s\-:|]+\|', lines[i + 1]):
            rows = []
            while i < len(lines) and "|" in lines[i]:
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            # rows[0] = header, rows[1] = separator, rows[2:] = data
            if len(rows) >= 2:
                header = rows[0]
                data   = rows[2:] if len(rows) > 2 else []
                blocks.append({"type": "table", "header": header, "rows": data})
                continue
            # Fallback: treat as paragraph
            for r in rows:
                blocks.append({"type": "paragraph",
                               "content": " | ".join(r)})
            continue

        # ── bullet list ──────────────────────────────────────────────
        if re.match(r'^(\s*[-*+])\s+', line):
            items = []
            while i < len(lines) and re.match(r'^(\s*[-*+])\s+', lines[i]):
                indent = len(lines[i]) - len(lines[i].lstrip())
                items.append({"indent": indent // 2,
                              "content": re.sub(r'^\s*[-*+]\s+', '',
                                                lines[i])})
                i += 1
            blocks.append({"type": "bullet_list", "items": items})
            continue

        # ── numbered list ────────────────────────────────────────────
        if re.match(r'^\d+\.\s+', line):
            items = []
            while i < len(lines) and re.match(r'^\d+\.\s+', lines[i]):
                items.append(re.sub(r'^\d+\.\s+', '', lines[i]))
                i += 1
            blocks.append({"type": "numbered_list", "items": items})
            continue

        # ── blank line ───────────────────────────────────────────────
        if line.strip() == "":
            i += 1
            continue

        # ── paragraph (collect until blank line or block element) ────
        para_lines = []
        while i < len(lines):
            l = lines[i]
            if (l.strip() == "" or
                    re.match(r'^#{1,6}\s', l) or
                    re.match(r'^```', l) or
                    re.match(r'^(---+|\*\*\*+|___+)\s*$', l) or
                    re.match(r'^>\s?', l) or
                    re.match(r'^\s*[-*+]\s+', l) or
                    re.match(r'^\d+\.\s+', l) or
                    ("|" in l and i + 1 < len(lines) and
                     re.match(r'^\s*\|?[\s\-:|]+\|', lines[i + 1]
                              if i + 1 < len(lines) else ""))):
                break
            para_lines.append(l)
            i += 1
        if para_lines:
            blocks.append({"type": "paragraph",
                           "content": " ".join(para_lines)})

    return blocks


# ---------------------------------------------------------------------------
# Qt widget builders for each block type
# ---------------------------------------------------------------------------

def _make_label(html, selectable=True, word_wrap=True, text_color="#d4d4d4",
                font_size=10):
    lbl = QLabel()
    lbl.setTextFormat(Qt.RichText)
    lbl.setWordWrap(word_wrap)
    lbl.setText(html)
    lbl.setOpenExternalLinks(True)
    lbl.setStyleSheet(
        f"background: transparent; padding: 1px 8px; "
        f"color: {text_color}; font-size: {font_size}pt;")
    if selectable:
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard |
            Qt.LinksAccessibleByMouse)
    return lbl


def build_heading(block, base_size=14):
    level   = block["level"]
    content = _inline_to_html(block["content"])
    # Scale heading levels relative to base_size
    sizes   = {1: base_size, 2: base_size - 2, 3: base_size - 4,
               4: base_size - 5, 5: base_size - 6, 6: base_size - 7}
    size    = max(sizes.get(level, base_size - 4), 8)
    colors  = {1: "#4ec9b0", 2: "#4ec9b0", 3: "#9cdcfe"}
    color   = colors.get(level, "#d4d4d4")
    html    = (f'<span style="font-size:{size}pt; font-weight:bold; '
               f'color:{color};">{content}</span>')
    w = _make_label(html, text_color=color, font_size=size)
    w.setStyleSheet(
        f"background: transparent; padding: 6px 8px 2px 8px; "
        f"color: {color}; font-size: {size}pt;")
    return w


def build_paragraph(block, text_color="#d4d4d4", font_size=10):
    html = _inline_to_html(block["content"])
    return _make_label(
        f'<span style="color:{text_color};">{html}</span>',
        text_color=text_color, font_size=font_size)


def build_hr():
    line = QFrame()
    line.setFrameShape(QFrame.HLine)
    line.setFrameShadow(QFrame.Sunken)
    line.setStyleSheet("color: #555; margin: 4px 8px;")
    return line


def build_think(block, font_size=9):
    """Collapsible thinking block with distinct background."""
    outer = QFrame()
    outer.setStyleSheet(
        "QFrame { background: #1a2a1a; border: 1px solid #2a3d2a; "
        "border-radius: 4px; margin: 2px 8px; }")
    lay = QVBoxLayout(outer)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(0)

    # Header row with toggle button
    header = QWidget()
    header.setStyleSheet(
        "background: #243824; border-bottom: 1px solid #2a3d2a; "
        "border-radius: 4px 4px 0 0;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 3, 8, 3)
    icon_lbl = QLabel("🧠")
    icon_lbl.setStyleSheet("background: transparent; border: none; font-size: 11px;")
    hl.addWidget(icon_lbl)
    title_lbl = QLabel("Thinking…")
    title_lbl.setStyleSheet(
        f"color: #7ec87e; font-size: {font_size}pt; "
        "background: transparent; border: none;")
    hl.addWidget(title_lbl)
    hl.addStretch()
    toggle_btn = QPushButton("▾ hide")
    toggle_btn.setFlat(True)
    toggle_btn.setStyleSheet(
        f"QPushButton {{ color: #7ec87e; font-size: {font_size}pt; border: none; "
        "background: transparent; padding: 0 4px; }"
        "QPushButton:hover { color: #aeeaae; }")
    hl.addWidget(toggle_btn)
    lay.addWidget(header)

    # Content area
    content_w = QWidget()
    content_w.setStyleSheet("QWidget { background: transparent; border: none; }")
    cl = QVBoxLayout(content_w)
    cl.setContentsMargins(10, 6, 10, 6)
    cl.setSpacing(3)

    for line in block["content"].splitlines():
        if not line.strip():
            continue
        lbl = QLabel(_inline_to_html(line))
        lbl.setTextFormat(Qt.RichText)
        lbl.setWordWrap(True)
        lbl.setOpenExternalLinks(True)
        lbl.setStyleSheet(
            f"color: #8abf8a; font-size: {font_size}pt; "
            "background: transparent; padding: 1px 0; border: none;")
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(lbl)

    lay.addWidget(content_w)

    # Wire toggle
    def _toggle():
        visible = content_w.isVisible()
        content_w.setVisible(not visible)
        toggle_btn.setText("▸ show" if visible else "▾ hide")

    toggle_btn.clicked.connect(_toggle)
    return outer


def build_blockquote(block, text_color="#d4d4d4", font_size=10):
    w   = QFrame()
    w.setStyleSheet(
        "QFrame { border-left: 3px solid #4a90d9; "
        "background: rgba(74,144,217,0.08); "
        "margin: 2px 8px; border-radius: 2px; }")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(10, 4, 8, 4)
    lay.setSpacing(2)
    for line in block["content"].splitlines():
        lbl = _make_label(
            f'<i style="color:#9cdcfe;">{_inline_to_html(line)}</i>',
            text_color="#9cdcfe", font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: #9cdcfe; font-size: {font_size}pt;")
        lay.addWidget(lbl)
    return w


def build_bullet_list(block, text_color="#d4d4d4", font_size=10):
    w   = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(8, 2, 8, 2)
    lay.setSpacing(1)
    for item in block["items"]:
        row = QHBoxLayout()
        row.setContentsMargins(item["indent"] * 12, 0, 0, 0)
        bullet = QLabel("•" if item["indent"] == 0 else "◦")
        bullet.setStyleSheet(
            f"color: #4ec9b0; padding: 0 4px 0 0; background: transparent; font-size: {font_size}pt;")
        bullet.setFixedWidth(14)
        row.addWidget(bullet, 0, Qt.AlignTop)
        lbl = _make_label(
            f'<span style="color:{text_color};">'
            f'{_inline_to_html(item["content"])}</span>',
            text_color=text_color, font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: {text_color}; font-size: {font_size}pt;")
        row.addWidget(lbl, 1)
        lay.addLayout(row)
    return w


def build_numbered_list(block, text_color="#d4d4d4", font_size=10):
    w   = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(8, 2, 8, 2)
    lay.setSpacing(1)
    for n, item in enumerate(block["items"], 1):
        row = QHBoxLayout()
        num = QLabel(f"{n}.")
        num.setStyleSheet(
            f"color: #4ec9b0; padding: 0 6px 0 0; background: transparent; font-size: {font_size}pt;")
        num.setFixedWidth(24)
        row.addWidget(num, 0, Qt.AlignTop)
        lbl = _make_label(
            f'<span style="color:{text_color};">'
            f'{_inline_to_html(item)}</span>',
            text_color=text_color, font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: {text_color}; font-size: {font_size}pt;")
        row.addWidget(lbl, 1)
        lay.addLayout(row)
    return w


def build_table(block, font_size=10):
    w   = QFrame()
    w.setStyleSheet("QFrame { margin: 4px 8px; }")
    grid = QGridLayout(w)
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setSpacing(0)

    for col, cell in enumerate(block["header"]):
        lbl = QLabel(_inline_to_html(cell))
        lbl.setTextFormat(Qt.RichText)
        lbl.setWordWrap(True)
        lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        lbl.setStyleSheet(
            f"background: #2d2d2d; color: #4ec9b0; font-weight: bold; "
            f"padding: 4px 8px; border: 1px solid #444; font-size: {font_size}pt;")
        lbl.setOpenExternalLinks(True)
        grid.addWidget(lbl, 0, col)

    for row_i, row in enumerate(block["rows"]):
        bg = "#1e1e1e" if row_i % 2 == 0 else "#252525"
        for col, cell in enumerate(row):
            text = cell if col < len(row) else ""
            lbl = QLabel(_inline_to_html(text))
            lbl.setTextFormat(Qt.RichText)
            lbl.setWordWrap(True)
            lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            lbl.setStyleSheet(
                f"background: {bg}; color: #d4d4d4; "
                f"padding: 3px 8px; border: 1px solid #444; font-size: {font_size}pt;")
            lbl.setOpenExternalLinks(True)
            lbl.setTextInteractionFlags(
                Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
            grid.addWidget(lbl, row_i + 1, col)

    return w


def build_code_block(block, insert_signal=None, font_size=10):
    """Build a code block frame with header bar and copy button."""
    lang = block["lang"]
    code = block["content"]

    frame = QFrame()
    frame.setFrameShape(QFrame.StyledPanel)
    frame.setStyleSheet(
        "QFrame { background: #1e1e1e; border: 1px solid #444; "
        "border-radius: 4px; margin: 2px 8px; }")
    fl = QVBoxLayout(frame)
    fl.setContentsMargins(0, 0, 0, 0)
    fl.setSpacing(0)

    # Header
    header = QWidget()
    header.setStyleSheet("background: #2d2d2d; border-bottom: 1px solid #444;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 2, 4, 2)
    lang_lbl = QLabel(lang if lang else "code")
    lang_lbl.setStyleSheet(
        "color: #888; font-size: 10px; background: transparent; border: none;")
    hl.addWidget(lang_lbl)
    hl.addStretch()

    if insert_signal is not None:
        copy_btn = QPushButton("📋 Copy to editor")
        copy_btn.setFlat(True)
        copy_btn.setStyleSheet(
            "QPushButton { color: #4ec9b0; font-size: 10px; "
            "padding: 1px 6px; border: none; background: transparent; }"
            "QPushButton:hover { color: #fff; }")
        copy_btn.setToolTip("Insert this code at cursor in the current editor")
        copy_btn.clicked.connect(
            lambda checked=False, c=code: insert_signal.emit(c))
        hl.addWidget(copy_btn)
    fl.addWidget(header)

    # Code text
    code_lbl = QLabel(code)
    code_lbl.setWordWrap(False)
    code_lbl.setTextFormat(Qt.PlainText)
    code_lbl.setFont(QFont("Monospace", font_size))
    code_lbl.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
    code_lbl.setStyleSheet(
        "color: #d4d4d4; background: transparent; "
        "padding: 8px 10px; border: none;")
    code_lbl.setTextInteractionFlags(
        Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
    fl.addWidget(code_lbl)
    return frame


# ---------------------------------------------------------------------------
# Main entry point: render markdown text into a QWidget
# ---------------------------------------------------------------------------
def render_markdown(text, insert_signal=None, font_cfg=None):
    """
    Parse markdown text and return a QWidget containing all rendered blocks.
    insert_signal: optional Signal(str) emitted when user clicks "Copy to editor"
    font_cfg: optional dict with keys fs_base, fs_code, fs_heading, fs_list,
              fs_table, fs_think (all in pt). Falls back to defaults if absent.
    """
    from .settings_dialog import EDITOR_DEFAULTS
    cfg = {**EDITOR_DEFAULTS, **(font_cfg or {})}

    try:
        from spyder.config.gui import is_dark_interface
        text_color = "#d4d4d4" if is_dark_interface() else "#1a1a1a"
    except Exception:
        text_color = "#d4d4d4"

    container = QWidget()
    lay = QVBoxLayout(container)
    lay.setContentsMargins(0, 2, 0, 2)
    lay.setSpacing(3)

    blocks = parse_blocks(text)
    has_code = any(b["type"] == "code" for b in blocks)

    for block in blocks:
        t = block["type"]
        if t == "think":
            lay.addWidget(build_think(block, cfg["fs_think"]))
        elif t == "heading":
            lay.addWidget(build_heading(block, cfg["fs_heading"]))
        elif t == "paragraph":
            lay.addWidget(build_paragraph(block, text_color, cfg["fs_base"]))
        elif t == "code":
            lay.addWidget(build_code_block(block, insert_signal, cfg["fs_code"]))
        elif t == "hr":
            lay.addWidget(build_hr())
        elif t == "blockquote":
            lay.addWidget(build_blockquote(block, text_color, cfg["fs_base"]))
        elif t == "bullet_list":
            lay.addWidget(build_bullet_list(block, text_color, cfg["fs_list"]))
        elif t == "numbered_list":
            lay.addWidget(build_numbered_list(block, text_color, cfg["fs_list"]))
        elif t == "table":
            lay.addWidget(build_table(block, cfg["fs_table"]))

    if not has_code and insert_signal is not None:
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        copy_all = QPushButton("📋 Copy to editor")
        copy_all.setFlat(True)
        copy_all.setStyleSheet(
            "QPushButton { color: #888; font-size: 10px; padding: 1px 4px; "
            "border: none; background: transparent; }"
            "QPushButton:hover { color: #ccc; }")
        copy_all.setToolTip("Insert full response at cursor in current editor")
        copy_all.clicked.connect(
            lambda checked=False, t=text: insert_signal.emit(t))
        btn_row.addWidget(copy_all)
        lay.addLayout(btn_row)

    lay.addStretch()
    return container
