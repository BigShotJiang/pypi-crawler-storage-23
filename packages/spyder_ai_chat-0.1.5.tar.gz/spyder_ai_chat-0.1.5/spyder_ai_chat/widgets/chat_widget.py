# -*- coding: utf-8 -*-
"""AI Chat Panel — Spyder 6 plugin (C) 2026 by Maciej Piecko"""

import json
import threading

from qtpy.QtCore import Qt, Signal, Slot, QEvent, QObject, QThread
from qtpy.QtGui import QFont, QTextCursor
from qtpy.QtWidgets import (
    QApplication, QDialog, QDialogButtonBox, QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QFrame, QPlainTextEdit, QPushButton, QTextEdit,
    QVBoxLayout, QWidget, QSizePolicy, QToolButton, QStyle, QScrollArea,
)

from .chat_history_manager import save_chat, load_chat, delete_chat, list_chats

DEFAULT_MODELS = [
    "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo",
    "llama3", "mistral", "codellama", "phi3",
]


# ---------------------------------------------------------------------------
# Chat History Popup
# ---------------------------------------------------------------------------
class _ChatHistoryPopup(QFrame):
    """Popup listing saved chats. Emits load_chat(filename) or del_chat(filename)."""
    load_chat = Signal(str)
    del_chat  = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setMinimumWidth(320)
        self.setMinimumHeight(420)
        self.setMaximumHeight(600)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(2)

        header = QLabel("Chat History")
        header.setStyleSheet("font-weight: bold; padding: 2px 4px;")
        lay.addWidget(header)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._container = QWidget()
        self._list_lay = QVBoxLayout(self._container)
        self._list_lay.setContentsMargins(0, 0, 0, 0)
        self._list_lay.setSpacing(1)
        self._list_lay.addStretch()
        self._scroll.setWidget(self._container)
        lay.addWidget(self._scroll)

        self._empty_lbl = QLabel("No saved chats yet.")
        self._empty_lbl.setStyleSheet("color: gray; padding: 8px;")
        self._empty_lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(self._empty_lbl)

    def show_below(self, btn, current_file=None):
        self._current_file = current_file
        self._refresh()
        self.adjustSize()

        # Anchor to button's bottom-right, extending leftward,
        # so the popup's right edge aligns with the button's right edge.
        # This keeps it inside the pane regardless of which side it's docked.
        try:
            btn_bottom_right = btn.mapToGlobal(btn.rect().bottomRight())
            popup_x = btn_bottom_right.x() - self.width()
            popup_y = btn_bottom_right.y()
            # Clamp to screen bounds
            from qtpy.QtWidgets import QApplication
            screen = QApplication.primaryScreen().availableGeometry()
            popup_x = max(screen.left(), popup_x)
        except Exception:
            pos = btn.mapToGlobal(btn.rect().bottomLeft())
            popup_x, popup_y = pos.x(), pos.y()

        self.move(popup_x, popup_y)
        self.show()
        self.raise_()

    def _refresh(self):
        # Clear existing rows (keep stretch at end)
        while self._list_lay.count() > 1:
            item = self._list_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        chats = list_chats()
        self._empty_lbl.setVisible(len(chats) == 0)
        self._scroll.setVisible(len(chats) > 0)

        for chat in chats:
            self._add_row(chat)

    def _add_row(self, chat):
        fname   = chat["filename"]
        preview = chat["preview"] or "(empty)"
        label   = preview[:35] + ("…" if len(preview) > 35 else "")
        try:
            dt = chat["saved_at"][:16].replace("T", " ")
        except Exception:
            dt = ""

        is_active = (fname == getattr(self, "_current_file", None))

        row = QFrame()
        row.setObjectName("chatrow")
        if is_active:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; background: #1a3a1a; "
                "border: 1px solid #3a7a3a; }"
                "QFrame#chatrow:hover { background: #244a24; }")
        else:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; }"
                "QFrame#chatrow:hover { background: palette(highlight); }")
        rl = QHBoxLayout(row)
        rl.setContentsMargins(4, 3, 4, 3)
        rl.setSpacing(6)

        txt_btn = QPushButton(f"{label}\n{dt}")
        txt_btn.setFlat(True)
        if is_active:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0; "
                "font-size: 11px; color: #7ec87e; }"
                "QPushButton:hover { color: #aeeaae; }")
        else:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0; "
                "font-size: 11px; }"
                "QPushButton:hover { color: palette(highlighted-text); }")
        txt_btn.clicked.connect(lambda checked=False, f=fname: self._on_load(f))
        rl.addWidget(txt_btn, stretch=1)

        del_btn = QPushButton("✕")
        del_btn.setFixedSize(20, 20)
        del_btn.setFlat(True)
        del_btn.setToolTip("Delete this chat")
        del_btn.setStyleSheet(
            "QPushButton { color: #888; border: none; font-size: 10px; }"
            "QPushButton:hover { color: red; }")
        del_btn.clicked.connect(lambda checked=False, f=fname: self._on_delete(f))
        rl.addWidget(del_btn)

        self._list_lay.insertWidget(self._list_lay.count() - 1, row)

    def _on_load(self, filename):
        self.hide()
        self.load_chat.emit(filename)

    def _on_delete(self, filename):
        delete_chat(filename)
        self.del_chat.emit(filename)
        self._refresh()




# ---------------------------------------------------------------------------
# Chat API worker
# ---------------------------------------------------------------------------
class _ChatWorker(QObject):
    chunk_ready = Signal(str)
    finished    = Signal()
    error       = Signal(str)

    def __init__(self, api_url, api_key, model, messages):
        super().__init__()
        self._url      = api_url.rstrip("/")
        self._key      = api_key
        self._model    = model
        self._messages = messages
        self._stop     = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            import urllib.request
            import urllib.error
            payload = json.dumps({
                "model": self._model,
                "messages": self._messages,
                "stream": True,
            }).encode()
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "spyder-ai-chat/0.1.2",
            }
            if self._key:
                headers["Authorization"] = f"Bearer {self._key}"
            req = urllib.request.Request(
                f"{self._url}/chat/completions",
                data=payload, headers=headers, method="POST")
            try:
                resp_cm = urllib.request.urlopen(req, timeout=120)
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:300]
                except Exception:
                    body = ""
                self.error.emit(f"HTTP {e.code} {e.reason}: {body}")
                return
            with resp_cm as resp:
                for raw in resp:
                    if self._stop:
                        break
                    line = raw.decode().strip()
                    if not line or line == "data: [DONE]":
                        continue
                    if line.startswith("data: "):
                        line = line[6:]
                    try:
                        d = json.loads(line)
                        t = d["choices"][0]["delta"].get("content", "")
                        if t:
                            self.chunk_ready.emit(t)
                    except Exception:
                        pass
        except Exception as exc:
            self.error.emit(str(exc))
        finally:
            self.finished.emit()


# ---------------------------------------------------------------------------
# Model dropdown popup
# ---------------------------------------------------------------------------
class _ModelPopup(QFrame):
    selected = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        self._lw = QListWidget()
        self._lw.setFrameShape(QFrame.NoFrame)
        self._lw.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._lw.itemClicked.connect(
            lambda item: (self.selected.emit(item.text()), self.hide()))
        lay.addWidget(self._lw)

    def _apply_theme(self):
        """Inherit application theme — no custom stylesheet needed."""
        self.setStyleSheet("")
        self._lw.setStyleSheet("")

    def show_below(self, btn, models, current):
        self._apply_theme()
        self._lw.clear()
        for m in models:
            item = QListWidgetItem(m)
            if m == current:
                f = item.font(); f.setBold(True); item.setFont(f)
            self._lw.addItem(item)
        row_h = max(self._lw.sizeHintForRow(0), 24)
        self._lw.setFixedHeight(min(row_h * len(models) + 4, 350))
        self.setFixedWidth(max(btn.width(), 200))
        self.adjustSize()
        self.move(btn.mapToGlobal(btn.rect().bottomLeft()))
        self.show()
        self.raise_()


from .markdown_renderer import render_markdown
from .settings_dialog import SettingsDialog, EDITOR_DEFAULTS, HISTORY_DEFAULTS


# ---------------------------------------------------------------------------
# Helper: assemble LLM message content from structured storage
# ---------------------------------------------------------------------------
def _build_llm_content(msg):
    """
    Build the content string to send to the LLM from a stored message dict.
    New format: {"role": "user", "content": "user text",
                 "attachments": [{"name": "file.py", "content": "..."}]}
    Old format: {"role": "user", "content": "File: ...\n```\n...\n```\n\ntext"}
                 — returned as-is for backwards compatibility.
    """
    import os
    text        = msg.get("content", "")
    attachments = msg.get("attachments", [])

    if not attachments:
        return text  # no attachments, or legacy format

    parts = []
    for att in attachments:
        name    = att.get("name", "")
        content = att.get("content", "")
        ext  = os.path.splitext(name)[1].lower()
        lang = {".py": "python", ".js": "javascript", ".ts": "typescript",
                ".html": "html", ".css": "css", ".json": "json",
                ".md": "markdown", ".txt": ""}.get(ext, "")
        fence = f"```{lang}" if lang else "```"
        parts.append(f"File: {name}\n{fence}\n{content}\n```")
    file_block = "\n\n".join(parts)
    return f"{file_block}\n\n{text}"


# ---------------------------------------------------------------------------
# The chat history display
# ---------------------------------------------------------------------------
class _ChatHistory(QWidget):

    insert_to_editor = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(4, 4, 4, 4)
        self._lay.setSpacing(6)
        self._lay.addStretch()
        self._blocks = []   # list of (role, container_widget)
        # streaming state
        self._stream_container = None
        self._stream_lbl       = None

    # ── user bubble ───────────────────────────────────────────────────
    def add_user(self, text, attachments=None):
        """
        Add a user message bubble.
        attachments: optional list of attachment name strings to show as
                     locked badges (📎 file or ✂ selection) below the text.
        """
        container = QWidget()
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)
        title = QLabel("<b>You:</b>")
        title.setStyleSheet("color: #569cd6;")
        cl.addWidget(title)
        w = QLabel(text)
        w.setWordWrap(True)
        w.setTextFormat(Qt.PlainText)
        w.setFont(QFont("Monospace", 10))
        w.setStyleSheet(
            "background: transparent; border-left: 3px solid #569cd6; "
            "padding: 4px 8px;")
        w.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(w)

        # Locked attachment badges (no X button — already sent)
        if attachments:
            badge_row = QWidget()
            badge_row.setStyleSheet("background: transparent;")
            bl = QHBoxLayout(badge_row)
            bl.setContentsMargins(8, 2, 0, 0)
            bl.setSpacing(4)
            for name in attachments:
                icon = "✂" if " selection" in name else "📎"
                tag = QFrame()
                tag.setStyleSheet(
                    "QFrame { background: #1e3a1e; border: 1px solid #3a6a3a; "
                    "border-radius: 3px; }")
                tl = QHBoxLayout(tag)
                tl.setContentsMargins(5, 1, 5, 1)
                tl.setSpacing(3)
                lbl = QLabel(f"{icon} {name}")
                lbl.setStyleSheet(
                    "color: #7ec87e; font-size: 9px; border: none; "
                    "background: transparent;")
                tl.addWidget(lbl)
                bl.addWidget(tag)
            bl.addStretch()
            cl.addWidget(badge_row)

        self._lay.insertWidget(self._lay.count() - 1, container)
        self._blocks.append(("user", container))

    # ── assistant: streaming placeholder ─────────────────────────────
    def add_assistant_start(self):
        """Create a plain streaming label. Returns the QLabel to write into."""
        container = QWidget()
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)
        title = QLabel("<b>Assistant:</b>")
        title.setStyleSheet("color: #4ec9b0;")
        cl.addWidget(title)
        lbl = QLabel()
        lbl.setWordWrap(True)
        lbl.setTextFormat(Qt.PlainText)
        lbl.setFont(QFont("Monospace", 10))
        lbl.setStyleSheet(
            "background: transparent; border-left: 3px solid #4ec9b0; "
            "padding: 4px 8px;")
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(lbl)
        self._lay.insertWidget(self._lay.count() - 1, container)
        self._blocks.append(("assistant_streaming", container))
        self._stream_container = container
        self._stream_lbl       = lbl
        return lbl

    # ── assistant: finalize with parsed code blocks ───────────────────
    def finalize_assistant(self, full_text):
        """
        Replace the streaming placeholder with fully rendered markdown.
        Works both after streaming (container exists) and when loading from file.
        """
        # If no streaming container exists (e.g. loading from file), create one now
        if self._stream_container is None:
            container = QWidget()
            cl = QVBoxLayout(container)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            title = QLabel("<b>Assistant:</b>")
            title.setStyleSheet("color: #4ec9b0;")
            cl.addWidget(title)
            self._lay.insertWidget(self._lay.count() - 1, container)
            self._blocks.append(("assistant_streaming", container))
            self._stream_container = container
            self._stream_lbl = None

        container = self._stream_container
        cl        = container.layout()

        # Remove the plain streaming label
        if self._stream_lbl is not None:
            self._stream_lbl.setParent(None)
            self._stream_lbl.deleteLater()
            self._stream_lbl = None

        # Render full markdown and add to container
        rendered = render_markdown(
            full_text,
            insert_signal=self.insert_to_editor,
            font_cfg=self._font_cfg if hasattr(self, "_font_cfg") else None,
        )
        cl.addWidget(rendered)

        # Update block record
        for i, b in enumerate(self._blocks):
            if b[0] == "assistant_streaming" and b[1] is container:
                self._blocks[i] = ("assistant", container)
                break

        self._stream_container = None

    def clear_all(self):
        for _, container in self._blocks:
            container.deleteLater()
        self._blocks.clear()
        self._stream_container = None
        self._stream_lbl       = None


# ---------------------------------------------------------------------------
# Main chat panel — pure QWidget, no PluginMainWidget inheritance
# ---------------------------------------------------------------------------
class AIChatPanel(QWidget):

    _sig_models_ok  = Signal(list)
    _sig_models_err = Signal(str)

    def __init__(self, get_conf, set_conf, get_editor_cursor, parent=None):
        super().__init__(parent)
        self._get_editor_cursor = get_editor_cursor
        self._messages         = []
        self._assistant_buf    = ""
        self._model_list       = list(DEFAULT_MODELS)
        self._current_model    = DEFAULT_MODELS[0]
        self._fetching         = False
        self._chat_thread      = None
        self._chat_worker      = None
        self._current_lbl      = None
        self._context_files    = []   # list of (name, content) added as context
        self._selection_counters = {}  # filename -> selection count
        self._current_chat_file = None  # filename of currently saved chat
        self._hist_popup = None         # created lazily

        self._sig_models_ok.connect(self._on_models_ok)
        self._sig_models_err.connect(self._on_models_err)

        # Load persisted state from local JSON file (reliable across restarts)
        self._state = self._load_state()
        saved_models = self._state.get("model_list", [])
        if saved_models:
            self._model_list = saved_models
        saved_sel = self._state.get("selected_model", "")
        if saved_sel and saved_sel in self._model_list:
            self._current_model = saved_sel
        elif self._model_list:
            self._current_model = self._model_list[0]

        self._popup = None  # created lazily on first use

        self._build_ui()

    # ── persistent state helpers ──────────────────────────────────────
    @staticmethod
    def _state_path():
        import os
        home = os.path.expanduser("~")
        d = os.path.join(home, ".spyder_ai_chat")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "state.json")

    def _load_state(self):
        try:
            with open(self._state_path(), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_state(self, **kwargs):
        state = self._load_state()
        state.update(kwargs)
        try:
            with open(self._state_path(), "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def _build_ui(self):
        # ── top bar ───────────────────────────────────────────────────
        top = QHBoxLayout()
        top.setContentsMargins(4, 4, 4, 2)
        top.setSpacing(4)

        self._model_btn = QPushButton(self._current_model + " ▾")
        self._model_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._model_btn.setToolTip("Select model")
        self._model_btn.clicked.connect(self._toggle_popup)
        top.addWidget(self._model_btn)

        self._reload_btn = QPushButton("⟳")
        self._reload_btn.setToolTip("Reload model list from API")
        self._reload_btn.setFixedWidth(36)
        self._reload_btn.setStyleSheet(
            "QPushButton { font-size: 16px; font-weight: bold; padding: 0px; }")
        self._reload_btn.clicked.connect(self._reload_models)
        top.addWidget(self._reload_btn)

        self._new_btn = QPushButton("🗑 New Chat")
        self._new_btn.setToolTip("Clear conversation and start fresh")
        self._new_btn.clicked.connect(self._new_chat)
        top.addWidget(self._new_btn)

        self._cfg_btn = QPushButton("⚙ Settings")
        self._cfg_btn.clicked.connect(self._open_settings)
        top.addWidget(self._cfg_btn)

        self._hist_btn = QPushButton()
        self._hist_btn.setToolTip("Chat history")
        self._hist_btn.setFixedSize(28, 24)
        self._hist_btn.setStyleSheet("QPushButton { padding: 1px; border: none; }")
        # Inline SVG: document with checkmark lines
        _svg = b"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path d="M6 2h9l4 4v16H5V2z" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M14 2v5h5" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M7 10l1.5 1.5L11 9" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="10" x2="17" y2="10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 14l1.5 1.5L11 13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="14" x2="17" y2="14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 18l1.5 1.5L11 17" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="18" x2="17" y2="18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>"""
        from qtpy.QtSvg import QSvgRenderer
        from qtpy.QtGui import QPixmap, QPainter, QColor
        from qtpy.QtCore import QByteArray
        try:
            # Try to get foreground color from theme
            from spyder.config.gui import is_dark_interface
            icon_color = "#d4d4d4" if is_dark_interface() else "#333333"
        except Exception:
            icon_color = "#d4d4d4"
        svg_colored = _svg.replace(b"currentColor", icon_color.encode())
        renderer = QSvgRenderer(QByteArray(svg_colored))
        pixmap = QPixmap(16, 16)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        renderer.render(painter)
        painter.end()
        from qtpy.QtGui import QIcon
        self._hist_btn.setIcon(QIcon(pixmap))
        self._hist_btn.setIconSize(pixmap.size())
        self._hist_btn.clicked.connect(self._toggle_history_popup)
        top.addWidget(self._hist_btn)

        # ── scrollable chat history ───────────────────────────────────
        from qtpy.QtWidgets import QScrollArea
        self._history = _ChatHistory()
        self._history._font_cfg = self._editor_cfg()
        self._history.setMinimumWidth(400)
        scroll = QScrollArea()
        scroll.setWidget(self._history)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)
        self._scroll = scroll

        # ── file context bar ──────────────────────────────────────────
        # Shows dismissible tags for files added as context
        self._ctx_bar = QWidget()
        self._ctx_bar.setVisible(False)
        self._ctx_bar_layout = QHBoxLayout(self._ctx_bar)
        self._ctx_bar_layout.setContentsMargins(4, 2, 4, 2)
        self._ctx_bar_layout.setSpacing(4)
        self._ctx_bar_layout.addStretch()

        # ── system prompt ─────────────────────────────────────────────
        self._sys_prompt = QPlainTextEdit()
        self._sys_prompt.setPlaceholderText(
            "System prompt (optional)")
        self._sys_prompt.setMaximumHeight(48)
        self._sys_prompt.setFont(QFont("Monospace", 9))

        # ── input row ─────────────────────────────────────────────────
        self._input = QPlainTextEdit()
        self._input.setPlaceholderText("Type message… (Ctrl+Enter to send)")
        self._input.setMaximumHeight(72)
        self._input.setFont(QFont("Monospace", 10))
        self._input.installEventFilter(self)

        self._send_btn = QPushButton("Send")
        self._send_btn.setMinimumHeight(72)
        self._send_btn.setMinimumWidth(64)
        self._send_btn.clicked.connect(self._send)

        self._stop_btn = QPushButton("Stop")
        self._stop_btn.setMinimumHeight(72)
        self._stop_btn.setMinimumWidth(64)
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop)

        input_row = QHBoxLayout()
        input_row.addWidget(self._input)
        input_row.addWidget(self._send_btn)
        input_row.addWidget(self._stop_btn)

        # ── status ────────────────────────────────────────────────────
        n = len(self._model_list)
        src = "saved" if self._state.get("model_list") else "defaults"
        self._status = QLabel(f"Ready. {n} model(s) from {src}. Click ⟳ to refresh.")
        self._status.setWordWrap(True)
        self._status.setStyleSheet("font-size:10px; padding:2px 4px;")

        # ── assemble ──────────────────────────────────────────────────
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        lay.addLayout(top)
        lay.addWidget(scroll, stretch=1)
        lay.addWidget(self._ctx_bar)
        lay.addWidget(self._sys_prompt)
        lay.addLayout(input_row)
        lay.addWidget(self._status)

        # Wire up copy-to-editor from history
        self._history.insert_to_editor.connect(self._insert_to_editor)

    # ── file context ─────────────────────────────────────────────────
    def add_file_context(self, path):
        """Add a saved file by path — reads content from disk."""
        import os
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as e:
            self._status.setText(f"⚠ Could not read file: {e}")
            return
        self.add_file_context_content(os.path.basename(path), content)

    def add_file_context_content(self, name, content):
        """Add file context by name + content directly (works for unsaved files)."""
        # Don't add duplicates by name
        if any(n == name for n, _ in self._context_files):
            self._status.setText(f"Already in context: {name}")
            return
        self._context_files.append((name, content))
        self._rebuild_ctx_bar()
        self._status.setText(
            f"Added to context: {name} ({len(content)} chars)")

    def next_selection_id(self, filename):
        """Return and increment the selection counter for this filename."""
        key = filename
        count = self._selection_counters.get(key, 0) + 1
        self._selection_counters[key] = count
        return count

    def _remove_file_context(self, name):
        self._context_files = [(n, c) for n, c in self._context_files if n != name]
        self._rebuild_ctx_bar()

    def _rebuild_ctx_bar(self):
        # Remove all tag widgets (everything except the trailing stretch)
        while self._ctx_bar_layout.count() > 1:
            item = self._ctx_bar_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for name, _ in self._context_files:
            tag = QFrame()
            tag.setStyleSheet(
                "QFrame { background: #2d4a6e; border: 1px solid #4a7ab5; "
                "border-radius: 3px; padding: 1px; }")
            tl = QHBoxLayout(tag)
            tl.setContentsMargins(5, 1, 3, 1)
            tl.setSpacing(3)
            lbl = QLabel(name)
            lbl.setStyleSheet(
                "color: #9ec8f0; font-size: 10px; border: none; "
                "background: transparent;")
            tl.addWidget(lbl)
            x_btn = QPushButton("×")
            x_btn.setFixedSize(14, 14)
            x_btn.setFlat(True)
            x_btn.setStyleSheet(
                "QPushButton { color: #888; font-size: 11px; border: none; "
                "background: transparent; padding: 0; }"
                "QPushButton:hover { color: #fff; }")
            x_btn.clicked.connect(
                lambda checked=False, n=name: self._remove_file_context(n))
            tl.addWidget(x_btn)
            self._ctx_bar_layout.insertWidget(
                self._ctx_bar_layout.count() - 1, tag)

        self._ctx_bar.setVisible(len(self._context_files) > 0)

    # ── event filter ─────────────────────────────────────────────────
    def eventFilter(self, obj, event):
        if obj is self._input and event.type() == QEvent.KeyPress:
            if (event.key() in (Qt.Key_Return, Qt.Key_Enter)
                    and event.modifiers() & Qt.ControlModifier):
                self._send()
                return True
        return super().eventFilter(obj, event)

    # ── model popup ───────────────────────────────────────────────────
    def _toggle_popup(self):
        if self._popup is None:
            # Create lazily so main window is visible and stylesheet is applied
            try:
                from qtpy.QtWidgets import QApplication
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._popup = _ModelPopup(main_win)
            self._popup.selected.connect(self._select_model)

        if self._popup.isVisible():
            self._popup.hide()
        else:
            self._popup.show_below(
                self._model_btn, self._model_list, self._current_model)

    def _select_model(self, name):
        self._current_model = name
        self._model_btn.setText(name + " ▾")
        self._status.setText(f"Model: {name}")
        self._save_state(selected_model=name)

    def _reload_models(self):
        """Manually triggered model list refresh from API."""
        self._fetching = False   # force re-fetch even if previous attempt failed
        self._reload_btn.setEnabled(False)
        self._reload_btn.setText("…")
        self._fetch_models()

    # ── model fetching ────────────────────────────────────────────────
    def _fetch_models(self):
        if self._fetching:
            return
        self._fetching = True
        url = self._api_url()
        key = self._api_key()
        sig_ok  = self._sig_models_ok
        sig_err = self._sig_models_err

        def _work():
            try:
                import urllib.request
                import urllib.error
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": "spyder-ai-chat/0.1.2",
                }
                if key:
                    headers["Authorization"] = f"Bearer {key}"
                req = urllib.request.Request(
                    url.rstrip("/") + "/models", headers=headers)
                with urllib.request.urlopen(req, timeout=8) as r:
                    data  = json.loads(r.read().decode())
                    items = data.get("data", data.get("models", []))
                    models = sorted(
                        m["id"] for m in items
                        if isinstance(m, dict) and "id" in m)
                    sig_ok.emit(models if models else [])
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:200]
                except Exception:
                    body = ""
                sig_err.emit(f"HTTP {e.code} {e.reason}: {body}")
            except Exception as e:
                sig_err.emit(f"{type(e).__name__}: {e}")

        threading.Thread(target=_work, daemon=True).start()

    @Slot(list)
    def _on_models_ok(self, models):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        if models:
            self._model_list = models
            if self._current_model not in models:
                self._current_model = models[0]
                self._model_btn.setText(self._current_model + " ▾")
            self._save_state(model_list=models, selected_model=self._current_model)
            preview = ", ".join(models[:3]) + (" …" if len(models) > 3 else "")
            self._status.setText(f"✓ {len(models)} model(s): {preview}")
        else:
            self._status.setText("⚠ No models returned.")

    @Slot(str)
    def _on_models_err(self, err):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        self._status.setText(f"⚠ Model fetch failed: {err}")

    # ── config ────────────────────────────────────────────────────────
    def _api_url(self):
        return self._load_state().get("api_url", "https://api.openai.com/v1")

    def _api_key(self):
        return self._load_state().get("api_key", "")

    def _history_cfg(self):
        return {**HISTORY_DEFAULTS, **self._load_state().get("history", {})}

    def _editor_cfg(self):
        return {**EDITOR_DEFAULTS, **self._load_state().get("editor", {})}

    # ── copy to editor ────────────────────────────────────────────────
    def _insert_to_editor(self, text):
        result = self._get_editor_cursor()
        cursor, editor_or_diag = result

        if cursor is not None:
            try:
                cursor.insertText(text)
                editor_or_diag.setTextCursor(cursor)
                self._status.setText("✓ Inserted into editor at cursor position.")
                return
            except Exception as e:
                editor_or_diag = str(e)

        # Fallback: clipboard
        QApplication.clipboard().setText(text)
        # Show diagnostic info so we can debug
        self._status.setText(f"Clipboard copy. Diag: {editor_or_diag}")

    # ── new chat ──────────────────────────────────────────────────────
    def _on_history_deleted(self, filename):
        """Called when a chat is deleted from the history popup."""
        if filename == self._current_chat_file:
            # The currently displayed chat was deleted — clear the window
            self._current_chat_file = None
            self._messages.clear()
            self._history.clear_all()
            self._context_files.clear()
            self._selection_counters.clear()
            self._rebuild_ctx_bar()
            self._sys_prompt.clear()
            self._status.setText("Current chat deleted.")

    def _new_chat(self):
        # Save current chat to history before clearing (if enabled)
        if self._messages and self._history_cfg().get("save_on_new", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sys_prompt.toPlainText().strip(),
                model=self._current_model,
                filename=self._current_chat_file,
            )
        self._current_chat_file = None
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()
        self._sys_prompt.clear()
        self._status.setText("New conversation started.")

    def _toggle_history_popup(self):
        if self._hist_popup is None:
            try:
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._hist_popup = _ChatHistoryPopup(main_win)
            self._hist_popup.load_chat.connect(self._load_chat_from_file)
            self._hist_popup.del_chat.connect(self._on_history_deleted)

        if self._hist_popup.isVisible():
            self._hist_popup.hide()
        else:
            self._hist_popup.show_below(self._hist_btn, self._current_chat_file)

    def _load_chat_from_file(self, filename):
        """Load a saved chat into the current view."""
        data = load_chat(filename)
        if data is None:
            self._status.setText("⚠ Could not load chat.")
            return
        # Save current chat first if it has content and saving is enabled
        if self._messages and self._history_cfg().get("autosave", True):
            save_chat(
                self._messages,
                system_prompt=self._sys_prompt.toPlainText().strip(),
                model=self._current_model,
                filename=self._current_chat_file,
            )
        # Restore state
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()

        sys_p = data.get("system_prompt", "")
        self._sys_prompt.setPlainText(sys_p)

        model = data.get("model", "")
        if model and model in self._model_list:
            self._current_model = model
            self._model_btn.setText(model + " ▾")

        for msg in data.get("messages", []):
            role    = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user":
                attachments = msg.get("attachments", [])
                # New format: content is plain user text, attachments are separate
                # Legacy format: file blocks embedded in content — strip them
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                self._history.add_user(display, attachments=att_names or None)
                self._messages.append(msg)
            elif role == "assistant":
                self._history.finalize_assistant(content)
                self._messages.append(msg)

        self._current_chat_file = filename
        self._status.setText(f"Loaded: {data.get('preview', filename)[:40]}")

    # ── settings ──────────────────────────────────────────────────────
    def _open_settings(self):
        state = self._load_state()
        dlg = SettingsDialog(
            self,
            api_url     = state.get("api_url", "https://api.openai.com/v1"),
            api_key     = state.get("api_key", ""),
            editor_cfg  = state.get("editor", {}),
            history_cfg = state.get("history", {}),
        )
        if dlg.exec_() == QDialog.Accepted:
            v = dlg.values()
            self._save_state(
                api_url = v["api_url"],
                api_key = v["api_key"],
                editor  = v["editor"],
                history = v["history"],
            )
            self._history._font_cfg = self._editor_cfg()
            self._fetching = False
            self._status.setText(f"Settings saved.")
            self._fetch_models()

    # ── send / stop ───────────────────────────────────────────────────
    def _send(self):
        text = self._input.toPlainText().strip()
        if not text:
            return
        if self._chat_thread is not None and self._chat_thread.isRunning():
            return
        self._input.clear()

        # Snapshot and clear pending context files
        pending_attachments = list(self._context_files)  # [(name, content), ...]
        if pending_attachments:
            self._context_files.clear()
            self._rebuild_ctx_bar()

        # Build structured message — content holds only user text,
        # attachments hold full file data; LLM payload is assembled at send time
        user_msg = {
            "role": "user",
            "content": text,
        }
        if pending_attachments:
            user_msg["attachments"] = [
                {"name": name, "content": content}
                for name, content in pending_attachments
            ]

        # Assemble LLM payload content from structured message
        llm_content = _build_llm_content(user_msg)

        # Build full message list for LLM (system prompt + history + new)
        messages = []
        sys_p = self._sys_prompt.toPlainText().strip()
        if sys_p:
            messages.append({"role": "system", "content": sys_p})
        # Rebuild LLM content from structured storage for each history message
        for m in self._messages:
            messages.append({"role": m["role"],
                             "content": _build_llm_content(m)})
        messages.append({"role": "user", "content": llm_content})

        attachment_names = [a["name"] for a in user_msg.get("attachments", [])]

        # Update UI and internal state
        self._history.add_user(text, attachments=attachment_names or None)
        self._messages.append(user_msg)
        self._current_lbl = self._history.add_assistant_start()
        self._assistant_buf = ""

        # Scroll to bottom
        self._scroll.verticalScrollBar().setValue(
            self._scroll.verticalScrollBar().maximum())

        worker = _ChatWorker(
            self._api_url(), self._api_key(),
            self._current_model, messages)
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk_ready.connect(self._on_chunk)
        worker.finished.connect(self._on_done)
        worker.error.connect(self._on_err)
        worker.finished.connect(thread.quit)

        self._chat_worker = worker
        self._chat_thread = thread

        self._send_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._status.setText(f"Generating with {self._current_model}…")
        thread.start()

    def _stop(self):
        if self._chat_worker:
            self._chat_worker.stop()
        self._status.setText("Stopped.")

    @Slot(str)
    def _on_chunk(self, text):
        self._assistant_buf += text
        if self._current_lbl:
            self._current_lbl.setText(
                self._current_lbl.text() + text)
        # Auto-scroll
        self._scroll.verticalScrollBar().setValue(
            self._scroll.verticalScrollBar().maximum())

    @Slot()
    def _on_done(self):
        if self._assistant_buf:
            self._messages.append(
                {"role": "assistant", "content": self._assistant_buf})
        # Replace streaming label with parsed code-block view
        self._history.finalize_assistant(self._assistant_buf)
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._status.setText("Done.")
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl = None
        # Auto-save after each completed exchange
        self._autosave()

    @Slot(str)
    def _on_err(self, msg):
        self._history.finalize_assistant(self._assistant_buf or f"[Error: {msg}]")
        self._status.setText(f"⚠ {msg}")
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl = None
        self._autosave()

    def _autosave(self):
        """Save current chat to disk after each exchange (if enabled)."""
        if self._messages and self._history_cfg().get("autosave", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sys_prompt.toPlainText().strip(),
                model=self._current_model,
                filename=self._current_chat_file,
            )


# ---------------------------------------------------------------------------
# PluginMainWidget — proper Spyder 6 integration
# Spyder calls setup() to build content inside its managed central area.
# get_main_layout() returns the QVBoxLayout of the central content widget,
# which sits BELOW the toolbars and title bar — so toolbars stay intact.
# ---------------------------------------------------------------------------
from spyder.api.widgets.main_widget import PluginMainWidget

class AIChatWidget(PluginMainWidget):

    DEFAULT_OPTIONS = {}

    def get_title(self):
        return "AI Chat"

    def setup(self, options=None):
        self._panel = AIChatPanel(
            get_conf=lambda k, d="": d,
            set_conf=lambda k, v: None,
            get_editor_cursor=lambda: (None, "not set yet"),
            parent=self,
        )
        # set_content_widget() is the correct Spyder 6 API —
        # places our panel in the central area below the toolbars
        self.set_content_widget(self._panel)

    def set_editor_cursor_fn(self, fn):
        """Called by plugin.py after Spyder wires up the editor plugin."""
        if hasattr(self, '_panel'):
            self._panel._get_editor_cursor = fn

    def add_file_context(self, path):
        """Called by plugin.py when user picks 'Add to AI Chat context'."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context(path)

    def add_file_context_content(self, name, content):
        """Called by plugin.py with already-read content (supports unsaved files)."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context_content(name, content)

    def next_selection_id(self, filename):
        """Return next selection counter for this filename."""
        if hasattr(self, '_panel'):
            return self._panel.next_selection_id(filename)
        return 1

    def update_actions(self):
        pass
