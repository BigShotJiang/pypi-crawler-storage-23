# -*- coding: utf-8 -*-
"""
AI Chat – Preferences page (Spyder 6 compatible) (C) 2026 by Maciej Piecko
"""
# This file is kept for future use if/when Spyder 6 preference page
# registration is wired up. For now, settings are edited via a dialog
# launched from the ⚙ button in the pane itself.
