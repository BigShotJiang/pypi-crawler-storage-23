"""OpenRouter AI provider implementation.

OpenRouter provides unified access to multiple AI models including:
- Anthropic Claude models
- OpenAI GPT models  
- Google Gemini models
- Meta Llama models
- Mistral models
- And many more

See https://openrouter.ai/docs for available models and pricing.
"""

from datetime import datetime
from typing import Iterator, Optional, List, Dict, Any

from claude_dev_cli.providers.base import (
    AIProvider,
    ModelInfo,
    UsageInfo,
    InsufficientCreditsError,
    ProviderConnectionError,
    ModelNotFoundError,
    ProviderError,
)

# Try to import openai SDK (OpenRouter uses OpenAI-compatible API)
try:
    from openai import OpenAI, APIError, AuthenticationError, RateLimitError, NotFoundError
    OPENAI_SDK_AVAILABLE = True
except ImportError:
    OPENAI_SDK_AVAILABLE = False
    OpenAI = None  # type: ignore
    APIError = Exception  # type: ignore
    AuthenticationError = Exception  # type: ignore
    RateLimitError = Exception  # type: ignore
    NotFoundError = Exception  # type: ignore


class OpenRouterProvider(AIProvider):
    """OpenRouter unified AI API provider.
    
    OpenRouter provides access to 100+ models through a single API.
    Uses OpenAI-compatible API format.
    """
    
    # Popular models on OpenRouter (prices as of 2024, per million tokens)
    KNOWN_MODELS = {
        # Anthropic Claude models
        "anthropic/claude-3.5-sonnet": {
            "display_name": "Claude 3.5 Sonnet",
            "context_window": 200000,
            "input_price": 3.00,
            "output_price": 15.00,
            "capabilities": ["chat", "code", "analysis", "vision"]
        },
        "anthropic/claude-3-opus": {
            "display_name": "Claude 3 Opus",
            "context_window": 200000,
            "input_price": 15.00,
            "output_price": 75.00,
            "capabilities": ["chat", "code", "analysis", "vision"]
        },
        "anthropic/claude-3-sonnet": {
            "display_name": "Claude 3 Sonnet",
            "context_window": 200000,
            "input_price": 3.00,
            "output_price": 15.00,
            "capabilities": ["chat", "code", "analysis", "vision"]
        },
        "anthropic/claude-3-haiku": {
            "display_name": "Claude 3 Haiku",
            "context_window": 200000,
            "input_price": 0.25,
            "output_price": 1.25,
            "capabilities": ["chat", "code", "fast"]
        },
        # OpenAI models
        "openai/gpt-4-turbo": {
            "display_name": "GPT-4 Turbo",
            "context_window": 128000,
            "input_price": 10.00,
            "output_price": 30.00,
            "capabilities": ["chat", "code", "analysis", "vision"]
        },
        "openai/gpt-4": {
            "display_name": "GPT-4",
            "context_window": 8192,
            "input_price": 30.00,
            "output_price": 60.00,
            "capabilities": ["chat", "code", "analysis"]
        },
        "openai/gpt-3.5-turbo": {
            "display_name": "GPT-3.5 Turbo",
            "context_window": 16385,
            "input_price": 0.50,
            "output_price": 1.50,
            "capabilities": ["chat", "code", "fast"]
        },
        # Google models
        "google/gemini-pro-1.5": {
            "display_name": "Gemini Pro 1.5",
            "context_window": 2000000,
            "input_price": 1.25,
            "output_price": 5.00,
            "capabilities": ["chat", "code", "analysis", "vision"]
        },
        # Meta Llama
        "meta-llama/llama-3.1-70b-instruct": {
            "display_name": "Llama 3.1 70B",
            "context_window": 131072,
            "input_price": 0.35,
            "output_price": 0.40,
            "capabilities": ["chat", "code"]
        },
        "meta-llama/llama-3.1-8b-instruct": {
            "display_name": "Llama 3.1 8B",
            "context_window": 131072,
            "input_price": 0.06,
            "output_price": 0.06,
            "capabilities": ["chat", "code", "fast"]
        },
        # Mistral
        "mistralai/mistral-large": {
            "display_name": "Mistral Large",
            "context_window": 128000,
            "input_price": 2.00,
            "output_price": 6.00,
            "capabilities": ["chat", "code", "analysis"]
        },
        # DeepSeek
        "deepseek/deepseek-chat": {
            "display_name": "DeepSeek Chat",
            "context_window": 64000,
            "input_price": 0.14,
            "output_price": 0.28,
            "capabilities": ["chat", "code"]
        },
    }
    
    def __init__(self, config: Any) -> None:
        """Initialize OpenRouter provider.
        
        Args:
            config: ProviderConfig with api_key
        
        Raises:
            RuntimeError: If openai SDK is not installed
        """
        super().__init__(config)
        
        if not OPENAI_SDK_AVAILABLE:
            raise RuntimeError(
                "OpenRouter provider requires the openai package. "
                "Install it with: pip install 'claude-dev-cli[openai]'"
            )
        
        # Extract API key from config
        api_key = getattr(config, 'api_key', None)
        if not api_key:
            raise ValueError("OpenRouter provider requires api_key in config")
        
        # Get timeout from config
        timeout = getattr(config, 'timeout', None) or 120
        
        # Initialize OpenAI client with OpenRouter base URL
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://openrouter.ai/api/v1",
            timeout=timeout
        )
        self.last_usage: Optional[UsageInfo] = None
    
    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 1.0,
    ) -> str:
        """Make a synchronous call to OpenRouter API."""
        model = model or "anthropic/claude-3.5-sonnet"
        max_tokens = max_tokens or 4096
        
        # Build messages array (OpenAI format)
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        start_time = datetime.utcnow()
        
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,  # type: ignore
                max_tokens=max_tokens,
                temperature=temperature
            )
        except AuthenticationError as e:
            raise ProviderConnectionError(
                f"OpenRouter authentication failed: {e}",
                provider="openrouter"
            )
        except RateLimitError as e:
            raise ProviderError(f"OpenRouter rate limit exceeded: {e}")
        except NotFoundError as e:
            raise ModelNotFoundError(
                f"Model not found: {model}. See https://openrouter.ai/docs#models",
                model=model,
                provider="openrouter"
            )
        except APIError as e:
            # Check for quota/billing issues
            error_message = str(e).lower()
            if "quota" in error_message or "billing" in error_message or "insufficient" in error_message or "credits" in error_message:
                raise InsufficientCreditsError(
                    f"Insufficient OpenRouter credits: {e}",
                    provider="openrouter"
                )
            raise ProviderConnectionError(
                f"OpenRouter API error: {e}",
                provider="openrouter"
            )
        
        end_time = datetime.utcnow()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Calculate cost from model pricing
        model_info = self.KNOWN_MODELS.get(model, {})
        input_price = model_info.get("input_price", 0.0)
        output_price = model_info.get("output_price", 0.0)
        
        input_tokens = response.usage.prompt_tokens if response.usage else 0
        output_tokens = response.usage.completion_tokens if response.usage else 0
        
        input_cost = (input_tokens / 1_000_000) * input_price
        output_cost = (output_tokens / 1_000_000) * output_price
        total_cost = input_cost + output_cost
        
        # Store usage info
        self.last_usage = UsageInfo(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            duration_ms=duration_ms,
            model=model,
            timestamp=end_time,
            cost_usd=total_cost
        )
        
        # Extract text from response
        if response.choices and len(response.choices) > 0:
            message = response.choices[0].message
            return message.content or ""
        return ""
    
    def call_streaming(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 1.0,
    ) -> Iterator[str]:
        """Make a streaming call to OpenRouter API."""
        model = model or "anthropic/claude-3.5-sonnet"
        max_tokens = max_tokens or 4096
        
        # Build messages array
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            stream = self.client.chat.completions.create(
                model=model,
                messages=messages,  # type: ignore
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    if delta.content:
                        yield delta.content
                        
        except AuthenticationError as e:
            raise ProviderConnectionError(
                f"OpenRouter authentication failed: {e}",
                provider="openrouter"
            )
        except RateLimitError as e:
            raise ProviderError(f"OpenRouter rate limit exceeded: {e}")
        except APIError as e:
            error_message = str(e).lower()
            if "quota" in error_message or "billing" in error_message or "credits" in error_message:
                raise InsufficientCreditsError(
                    f"Insufficient OpenRouter credits: {e}",
                    provider="openrouter"
                )
            raise ProviderConnectionError(
                f"OpenRouter API error: {e}",
                provider="openrouter"
            )
    
    def list_models(self) -> List[ModelInfo]:
        """List known OpenRouter models.
        
        Note: OpenRouter has 100+ models. This returns a curated list
        of popular models. See https://openrouter.ai/docs for full list.
        """
        models = []
        for model_id, info in self.KNOWN_MODELS.items():
            models.append(ModelInfo(
                model_id=model_id,
                display_name=info["display_name"],
                provider="openrouter",
                context_window=info["context_window"],
                input_price_per_mtok=info["input_price"],
                output_price_per_mtok=info["output_price"],
                capabilities=info["capabilities"]
            ))
        return models
    
    def get_last_usage(self) -> Optional[UsageInfo]:
        """Get usage information from the last API call."""
        return self.last_usage
    
    @property
    def provider_name(self) -> str:
        """Get the provider's name."""
        return "openrouter"
    
    def test_connection(self) -> bool:
        """Test if the OpenRouter API is accessible."""
        try:
            # Make a minimal API call to test credentials
            response = self.client.chat.completions.create(
                model="anthropic/claude-3-haiku",  # Cheapest model
                messages=[{"role": "user", "content": "test"}],
                max_tokens=5
            )
            return True
        except Exception:
            return False
