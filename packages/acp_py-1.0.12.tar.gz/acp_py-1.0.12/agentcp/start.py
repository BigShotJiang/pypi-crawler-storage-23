#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
acp-py 默认启动脚本
使用方式: python -m agentcp.start [args]
"""
import os
import time
import argparse
import json


def _create_session_with_target(aid, target_aid, session_name=None):
    """创建会话并邀请目标"""
    name = session_name or f"session_{int(time.time())}"
    session_id = aid.create_session(name, "ACP 会话")
    if session_id:
        aid.invite_member(session_id, target_aid)
    return session_id


def main():
    parser = argparse.ArgumentParser(description='启动 Python Agent')
    parser.add_argument('--data', '-d', default='./acp-data', help='数据目录 (默认: ./acp-data)')
    parser.add_argument('--password', '-p', default='agentcp@2025', help='种子密码 (默认: agentcp@2025，也可通过环境变量 ACP_SEED_PASSWORD 设置)')
    parser.add_argument('--name', '-n', default=None, help='Agent 名称 (默认: 自动生成)')
    parser.add_argument('--ap', default='aid.pub', help='AP 地址 (默认: aid.pub)')
    parser.add_argument('--debug', action='store_true', help='启用调试模式')
    parser.add_argument('--target', '-t', default=None, help='目标 Agent AID (用于发送消息)')
    parser.add_argument('--cli', action='store_true', help='使用 CLI 交互模式 (不启动 Web)')
    parser.add_argument('--port', type=int, default=9528, help='Web 服务端口 (默认: 9528)')
    parser.add_argument('--no-browser', action='store_true', help='不自动打开浏览器')
    args = parser.parse_args()

    # 解析种子密码：环境变量 > CLI参数（含默认值）
    env_password = os.environ.get('ACP_SEED_PASSWORD')
    if env_password:
        args.password = env_password

    # Web 模式（默认）
    if not args.cli:
        from agentcp.web_server import start_server
        start_server(port=args.port, data_dir=args.data, seed_password=args.password, open_browser=not args.no_browser)
        return

    # 延迟导入，确保 PYTHONPATH 已设置
    from agentcp import AgentCP

    # 创建数据目录
    data_path = os.path.abspath(args.data)
    os.makedirs(data_path, exist_ok=True)

    print("=" * 50)
    print("ACP Python Agent")
    print("=" * 50)
    print(f"数据目录: {data_path}")

    # 创建 AgentCP 实例
    acp = AgentCP(
        data_path,
        seed_password=args.password,
        debug=args.debug,
        run_proxy=False
    )

    # 创建 Agent 的 AID
    agent_name = args.name or f"acp_py_{int(time.time())}"
    aid = acp.create_aid(ap=args.ap, agent_name=agent_name)
    print(f"Agent 名称: {agent_name}")
    print(f"Agent AID: {aid.id}")

    # 注册消息处理器（异步函数）
    async def handle_message(data):
        """处理收到的消息"""
        try:
            sender = data.get('sender', '未知')
            session_id = data.get('session_id', '')
            message_id = data.get('message_id', '')

            # 解析消息内容
            message_raw = data.get('message', '{}')
            message = json.loads(message_raw) if isinstance(message_raw, str) else message_raw

            # 处理消息列表
            if isinstance(message, list):
                message = message[0] if message else {}

            # 提取内容
            if isinstance(message, dict):
                content = message.get('content', message.get('text', str(message)))
                msg_type = message.get('type', '')
            else:
                content = str(message)
                msg_type = ''

            print(f"\n{'=' * 40}")
            print(f"[收到消息]")
            print(f"  发送者: {sender}")
            print(f"  内容: {content}")
            if msg_type:
                print(f"  类型: {msg_type}")
            if args.debug:
                print(f"  会话ID: {session_id}")
                print(f"  消息ID: {message_id}")
            print(f"{'=' * 40}")
            print(">>> ", end="", flush=True)

        except Exception as e:
            print(f"\n[消息处理错误] {e}")
            if args.debug:
                import traceback
                traceback.print_exc()
            print(">>> ", end="", flush=True)

    aid.add_message_handler(handle_message)

    # 上线
    aid.online()
    print("Agent 已上线")

    # 会话管理
    session_id = None
    target_aid = args.target

    # 如果指定了目标，创建会话
    if target_aid:
        print(f"目标 Agent: {target_aid}")
        session_id = _create_session_with_target(aid, target_aid, "acp_session")
        if session_id:
            print(f"会话ID: {session_id}")
            print(f"已邀请 {target_aid} 加入会话")

    print("=" * 50)
    print("命令:")
    print("  /target <aid>  - 设置目标 Agent")
    print("  /session       - 显示当前会话信息")
    print("  /aid           - 显示本机 AID")
    print("  /quit          - 退出")
    print("  其他输入       - 发送消息")
    print("=" * 50)

    # 交互式输入
    while True:
        try:
            msg = input(">>> ").strip()
            if not msg:
                continue

            # 处理命令
            if msg.startswith('/'):
                parts = msg.split(maxsplit=1)
                cmd = parts[0].lower()

                if cmd in ('/quit', '/exit', '/q'):
                    print("正在退出...")
                    break

                elif cmd == '/target':
                    if len(parts) > 1:
                        target_aid = parts[1].strip()
                        session_id = _create_session_with_target(aid, target_aid)
                        if session_id:
                            print(f"已设置目标: {target_aid}")
                            print(f"新会话ID: {session_id}")
                        else:
                            print("创建会话失败")
                    else:
                        print(f"当前目标: {target_aid}" if target_aid else "未设置目标，使用: /target <aid>")

                elif cmd == '/session':
                    print(f"会话ID: {session_id or '无'}")
                    print(f"目标AID: {target_aid or '无'}")

                elif cmd == '/aid':
                    print(f"本机 AID: {aid.id}")

                elif cmd == '/help':
                    print("命令:")
                    print("  /target <aid>  - 设置目标 Agent")
                    print("  /session       - 显示当前会话信息")
                    print("  /aid           - 显示本机 AID")
                    print("  /quit          - 退出")

                else:
                    print(f"未知命令: {cmd}，输入 /help 查看帮助")

            else:
                # 发送消息
                if not target_aid:
                    print("请先设置目标: /target <aid>")
                    continue

                if not session_id:
                    session_id = _create_session_with_target(aid, target_aid)
                    if not session_id:
                        print("创建会话失败")
                        continue

                aid.send_message(session_id, [target_aid], msg)
                print(f"[已发送] {msg}")

        except KeyboardInterrupt:
            print("\n正在退出...")
            break
        except EOFError:
            break

    # 清理资源
    try:
        aid.offline()
    except (Exception, KeyboardInterrupt):
        pass


if __name__ == "__main__":
    main()
