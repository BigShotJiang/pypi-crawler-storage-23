__author__    = "Daniel Westwood"
__contact__   = "daniel.westwood@stfc.ac.uk"
__copyright__ = "Copyright 2026 United Kingdom Research and Innovation"

import os
from base64 import b64encode
import json
import requests
from typing import Union

# def get_auth():
#     print('Getting Oauth Token')
#     uname = ''
#     pwd = ''
#     csecret = ''
#     cmd = f"""curl --location 'https://accounts.ceda.ac.uk/realms/ceda/protocol/openid-connect/token' --header 'Content-Type: application/x-www-form-urlencoded' --data-urlencode 'username={uname}' --data-urlencode 'password={pwd}' --data-urlencode 'client_id=bearer-token-test' --data-urlencode 'client_secret={csecret}' --data-urlencode 'grant_type=password' > jsons/token.json"""
    
#     os.system(cmd)

#     with open('jsons/token.json') as f:
#         token = json.load(f)

#     auth = {"Authorization":f"{token['token_type']} {token['access_token']}"}
#     return None

def get_new_token(
        username, 
        password):

    url = "https://services.ceda.ac.uk/api/token/create/"

    token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
    headers = {
        "Authorization": f'Basic {token}',
    }

    response = requests.request("POST", url, headers=headers)
    return {"Authorization": f"Bearer {json.loads(response.text)['access_token']}"}

# def get_ssl_context():
#     print('Setting up SSL context')
#     # Set up ssl context
#     ssl_context = ssl.create_default_context(cafile=CERT_FILE, capath=CERT_FILE)
#     ssl_context.check_hostname = False
#     ssl_context.verify_mode = ssl.CERT_NONE
#     return ssl_context

# def get_cookies():
#     print('Getting Cookies')
#     tiny_readme_url = "https://dap.ceda.ac.uk/badc/ukcp18/data/land-cpm/ancil/lsm/lsm_land-cpm_BI_5km.nc"
#     r = requests.get(tiny_readme_url, cert=CERT_FILE, verify=False)
#     print(r.content)
#     return r.cookies

def remote_options(username: Union[str,None] = None, password: Union[str,None] = None):
    username = username or os.environ.get("CEDA_USERNAME")
    password = password or os.environ.get("CEDA_PASSWORD")
    remote_options = {'headers':get_new_token(username, password)}
# else:
#     print('Using SSL Certificate')
#     remote_options = {'ssl':get_ssl_context(),'cookies':get_cookies()}

if __name__ == '__main__':
    print('Token Auth Headers Utility Package')