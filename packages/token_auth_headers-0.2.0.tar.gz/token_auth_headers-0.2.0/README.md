# token_auth_headers
Utility package for generating token auth headers for CEDA data accesses
