from .plugin import IdealPlugin

__all__ = ["IdealPlugin"]
