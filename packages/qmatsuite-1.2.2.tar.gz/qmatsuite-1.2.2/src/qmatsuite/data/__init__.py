"""
Embedded data assets for QMatSuite.
"""

from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from typing import Any, Dict

# Re-export qe_metadata helpers for convenience
from .qe_metadata import (
    get_doc_url_pattern,
    get_module_doc_url,
    get_module_namelists,
    get_module_param_sections,
    get_module_card_sections,
    get_ui_parameters,
    get_metadata_file_info,
    get_qe_metadata_debug_info,
    list_supported_modules,
    safe_load_metadata,
    reload_metadata,
    validate_ui_parameters,
    QEUIParam,
)

__all__ = [
    "load_qe_parameter_map",
    "get_module_param_sections",
    "get_module_card_sections",
    "get_metadata_file_info",
    "get_qe_metadata_debug_info",
    "get_module_doc_url",
    "get_doc_url_pattern",
    "get_module_namelists",
    "list_supported_modules",
    "get_ui_parameters",
    "safe_load_metadata",
    "reload_metadata",
    "validate_ui_parameters",
    "QEUIParam",
]


@lru_cache()
def load_qe_parameter_map() -> Dict[str, Any]:
    """
    Load the generated QE module parameter map.
    
    DEPRECATED: Most code should use the helper functions in qe_metadata.py instead
    of calling this directly. This function is kept for backward compatibility only.
    
    For new code that needs QE metadata, use safe_load_metadata() instead.
    This now delegates to qe_metadata.safe_load_metadata() to ensure all access
    goes through the single source of truth and raises RuntimeError for better
    error handling.
    """
    from .qe_metadata import safe_load_metadata
    return safe_load_metadata()