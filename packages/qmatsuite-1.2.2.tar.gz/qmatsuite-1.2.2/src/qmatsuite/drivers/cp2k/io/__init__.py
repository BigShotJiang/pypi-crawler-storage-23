"""CP2K I/O modules (stdlib only, no kernel imports)."""
