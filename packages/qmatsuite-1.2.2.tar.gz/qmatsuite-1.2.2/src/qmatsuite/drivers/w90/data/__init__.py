"""Wannier90 parameter metadata catalog."""
