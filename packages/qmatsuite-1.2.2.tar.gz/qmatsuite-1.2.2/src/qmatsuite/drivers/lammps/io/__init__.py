"""LAMMPS I/O modules: script and data file parse/write functions."""
