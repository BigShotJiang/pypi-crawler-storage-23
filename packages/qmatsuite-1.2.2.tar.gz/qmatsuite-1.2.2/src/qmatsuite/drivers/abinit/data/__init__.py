"""ABINIT engine data package — metadata catalogs and access layers."""
