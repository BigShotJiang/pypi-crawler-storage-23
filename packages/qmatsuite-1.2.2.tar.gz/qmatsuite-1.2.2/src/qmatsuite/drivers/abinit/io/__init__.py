"""ABINIT I/O modules (stdlib only, no kernel imports)."""
