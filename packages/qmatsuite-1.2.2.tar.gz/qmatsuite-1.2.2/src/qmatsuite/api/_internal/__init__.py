"""
Internal API helpers.

This module contains internal utilities used by the API layer.
Not part of the public API surface.
"""

__all__ = []

