"""Backward-compatibility re-export for qe engine (moved to drivers/qe/engine/)."""

from qmatsuite.drivers.qe.engine.qe_engine import QuantumEspressoEngine

__all__ = ["QuantumEspressoEngine"]

