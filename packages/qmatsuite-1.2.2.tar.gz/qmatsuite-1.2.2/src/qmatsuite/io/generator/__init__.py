"""Backward-compatibility re-export for QE generator (moved to drivers/qe/io/)."""

# Empty __init__.py - qe_generator.py is re-exported below
