"""
QE installation utilities (re-exported from legacy module).
"""

from qmatsuite.core.public import QEInstallation

__all__ = ["QEInstallation"]

