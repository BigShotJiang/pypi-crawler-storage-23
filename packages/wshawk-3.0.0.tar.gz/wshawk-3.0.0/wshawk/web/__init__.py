"""
WSHawk Web GUI - Flask-based dashboard
Author: Regaan (@noobforanonymous)
"""
