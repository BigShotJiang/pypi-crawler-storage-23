# Simple Python scripts deployer `deploypyfiles`

Copy files from working directory to specified locations
