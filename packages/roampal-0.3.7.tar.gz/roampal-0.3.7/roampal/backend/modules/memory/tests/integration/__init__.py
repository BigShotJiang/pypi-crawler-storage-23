# Integration tests for roampal memory modules
