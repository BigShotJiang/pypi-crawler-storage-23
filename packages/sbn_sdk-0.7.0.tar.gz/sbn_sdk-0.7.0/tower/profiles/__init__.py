"""Tower Agent profile clients — product-scoped API wrappers.

Each profile client extends BaseProfileClient with domain-specific
context ingestion methods:

- DominionProfileClient: payroll batch, float, GEC, tax health
- GridProfileClient: NUMA signals, GEC, grid stats, utilization
- StillpointProfileClient: treasury snapshots, reflexes, yield, GEC
"""

from tower.profiles._base import BaseProfileClient
from tower.profiles.dominion import DominionProfileClient
from tower.profiles.grid import GridProfileClient
from tower.profiles.stillpoint import StillpointProfileClient

__all__ = [
    "BaseProfileClient",
    "DominionProfileClient",
    "GridProfileClient",
    "StillpointProfileClient",
]
