"""
pgdag — Universal Proof-Gated DAG Kernel.

The shared execution kernel for all SBN products.  Every product
(Dominion, Grid, Sonic, Stillpoint) imports this kernel and provides
its own templates, step functions, and engine configurations.

Core principle: **a step produces a proof artifact or it didn't happen.**
Downstream nodes trust proof hashes, not mutable state.

Package layout:
  pgdag/
  ├── factory.py    — build() one-call wiring, ExecutionLayer
  ├── artifact.py   — ProofArtifact, ProofStatus, merkle_root
  ├── envelope.py   — StepEnvelope, StepEnvelopeBuilder
  ├── runner.py     — StepRunner, ProofWriter, StepContext, StepFn, SealBackend
  ├── gate.py       — IdempotencyGate
  ├── reducer.py    — Reducer, RunState, ReducerStatus
  ├── interrupt.py  — InterruptionHandler, InterruptionSignal
  ├── dag.py        — PGDAGRunner, DAGTemplate, DAGNode, DAGEdge, RunResult
  ├── chains.py     — EvidenceChainManager, ChainHealthTracker
  ├── entity.py     — EntityReducer, EntityState, EntityCheckpoint
  └── handoff.py    — HandoffEnvelope, build_handoff, validate_upstream_proof

Dependencies:
  - sbn-sdk (optional): SnapChore sealing, SmartBlock publish, Gateway slots
  - No product knowledge: templates, steps, engines are product-specific

Quick start:

    from pgdag import build, DAGTemplate, DAGNode

    layer = build(sbn_client=sbn, domain="finance.payroll")

    layer.runner.register_steps({
        "ingest":  my_ingest_fn,
        "compute": my_compute_fn,
    })

    template = DAGTemplate(
        name="payroll_batch",
        nodes=[DAGNode(id="ingest"), DAGNode(id="compute")],
    )

    result = await layer.runner.execute(template, inputs={...}, actor="dom-engine")

Local dev (no SBN):

    layer = build(domain="test")
    # Same API, SHA-256 sealing, no network calls.
"""

__version__ = "0.7.0"

# Factory (the recommended entry point)
from .factory import ExecutionLayer, build

# Core artifacts
from .artifact import (
    ProofArtifact,
    ProofStatus,
    canonical_fingerprint,
    merkle_root,
)

# Envelope
from .envelope import (
    SnapChoreCapture,
    StepEnvelope,
    StepEnvelopeBuilder,
)

# Execution
from .runner import (
    LocalSealBackend,
    ProofWriter,
    SbnSealBackend,
    SealBackend,
    StepContext,
    StepFn,
    StepRunner,
)

# Idempotency
from .gate import (
    IdempotencyGate,
    SnapChoreDiscover,
)

# State reduction
from .reducer import (
    Reducer,
    ReducerStatus,
    RunState,
)

# Interruption
from .interrupt import (
    InterruptionHandler,
    InterruptionSignal,
)

# DAG execution
from .dag import (
    DAGEdge,
    DAGNode,
    DAGResult,
    DAGTemplate,
    NodeResult,
    PGDAGRunner,
    RunResult,
    WaitForEvent,
)

# Evidence chains
from .chains import (
    ChainEntry,
    ChainHealthReport,
    ChainHealthTracker,
    ChainState,
    EvidenceChainManager,
    chain_id,
)

# Entity state
from .entity import (
    EntityCheckpoint,
    EntityReducer,
    EntityState,
)

# Cross-product handoff
from .handoff import (
    HandoffEnvelope,
    build_handoff,
    validate_upstream_proof,
)

__all__ = [
    # Version
    "__version__",
    # Factory
    "build",
    "ExecutionLayer",
    # Artifacts
    "ProofArtifact",
    "ProofStatus",
    "canonical_fingerprint",
    "merkle_root",
    # Envelope
    "SnapChoreCapture",
    "StepEnvelope",
    "StepEnvelopeBuilder",
    # Execution
    "StepRunner",
    "ProofWriter",
    "SealBackend",
    "LocalSealBackend",
    "SbnSealBackend",
    "StepContext",
    "StepFn",
    # Idempotency
    "IdempotencyGate",
    "SnapChoreDiscover",
    # State reduction
    "Reducer",
    "ReducerStatus",
    "RunState",
    # Interruption
    "InterruptionHandler",
    "InterruptionSignal",
    # DAG execution
    "PGDAGRunner",
    "DAGTemplate",
    "DAGNode",
    "DAGEdge",
    "DAGResult",
    "NodeResult",
    "RunResult",
    "WaitForEvent",
    # Evidence chains
    "EvidenceChainManager",
    "ChainHealthTracker",
    "ChainEntry",
    "ChainState",
    "ChainHealthReport",
    "chain_id",
    # Entity state
    "EntityReducer",
    "EntityState",
    "EntityCheckpoint",
    # Cross-product handoff
    "HandoffEnvelope",
    "build_handoff",
    "validate_upstream_proof",
]
