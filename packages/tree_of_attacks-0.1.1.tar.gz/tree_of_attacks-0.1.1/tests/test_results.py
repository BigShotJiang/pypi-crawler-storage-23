"""Tests for taprune.results."""

from taprune.results import RunResult, _build_summary


def test_run_result_dataclass():
    r = RunResult(
        result_prompt="test",
        iteration_log=[],
        target_response="resp",
        extra=None,
        success=True,
    )
    assert r.result_prompt == "test"
    assert r.success is True
    assert r.extra is None


def test_build_summary_success():
    s = _build_summary(True, [{"iteration": 1}], "winning prompt")
    assert "Jailbreak found" in s


def test_build_summary_no_iterations():
    s = _build_summary(False, [], None)
    assert "no iterations" in s


def test_build_summary_all_pruned():
    log = [{"iteration": 2, "num_on_topic": 0, "num_off_topic": 4}]
    s = _build_summary(False, log, None)
    assert "pruned" in s


def test_build_summary_max_depth():
    log = [{"iteration": 1}, {"iteration": 2}, {"iteration": 3}]
    s = _build_summary(False, log, None)
    assert "max depth" in s
