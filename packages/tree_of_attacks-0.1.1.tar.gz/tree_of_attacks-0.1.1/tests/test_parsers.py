"""Tests for taprune.parsers."""

from taprune.parsers import (
    get_parser,
    no_extra,
    parse_deal_from_reply,
    raw_reply,
)


def test_no_extra_returns_none():
    assert no_extra("anything") is None


def test_raw_reply_returns_input():
    assert raw_reply("hello world") == "hello world"


def test_parse_deal_from_reply_with_numbers():
    reply = "Rating: 8\nDeal: 90, 10"
    result = parse_deal_from_reply(reply)
    assert result == [90, 10]


def test_parse_deal_from_reply_none():
    reply = "Rating: 5\nDeal: none"
    result = parse_deal_from_reply(reply)
    assert result is None


def test_parse_deal_from_reply_no_deal_line():
    reply = "Rating: 3"
    result = parse_deal_from_reply(reply)
    assert result is None


def test_parse_deal_from_reply_single_number():
    reply = "Deal: 50"
    result = parse_deal_from_reply(reply)
    assert result is None


def test_get_parser_known_names():
    assert get_parser("parse_deal_from_reply") is parse_deal_from_reply
    assert get_parser("no_extra") is no_extra
    assert get_parser("raw_reply") is raw_reply


def test_get_parser_none():
    assert get_parser(None) is None
    assert get_parser("") is None
    assert get_parser("   ") is None


def test_get_parser_unknown():
    assert get_parser("nonexistent") is None
