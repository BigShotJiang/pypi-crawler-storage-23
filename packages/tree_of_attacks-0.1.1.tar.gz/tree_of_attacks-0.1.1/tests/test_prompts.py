"""Tests for taprune.prompts."""

import pytest

from taprune.prompts import get_prompts


def test_get_prompts_fills_placeholders():
    config = {
        "prompts": {
            "judge": "Objective: [[OBJECTIVE]] Start: [[STARTING_STRING]]",
            "off_topic": "Task: [[OBJECTIVE]]",
            "attacker": "Goal: [[OBJECTIVE]] Secret: [[SECRET_VALUE]]",
        },
        "attacker_secret_value": "s3cret",
    }
    result = get_prompts(config, "test goal", "Sure, here is")
    assert result["judge"] == "Objective: test goal Start: Sure, here is"
    assert result["off_topic"] == "Task: test goal"
    assert result["attacker"] == "Goal: test goal Secret: s3cret"


def test_get_prompts_missing_key_raises():
    config = {
        "prompts": {
            "judge": "j",
            # off_topic missing
            "attacker": "a",
        }
    }
    with pytest.raises(ValueError, match="Missing"):
        get_prompts(config, "goal", "start")


def test_get_prompts_empty_prompts_raises():
    config = {"prompts": {}}
    with pytest.raises(ValueError):
        get_prompts(config, "goal", "start")


def test_get_prompts_no_secret_value():
    """When attacker_secret_value is missing, [[SECRET_VALUE]] becomes empty string."""
    config = {
        "prompts": {
            "judge": "j",
            "off_topic": "o",
            "attacker": "secret=[[SECRET_VALUE]]",
        }
    }
    result = get_prompts(config, "g", "s")
    assert result["attacker"] == "secret="
