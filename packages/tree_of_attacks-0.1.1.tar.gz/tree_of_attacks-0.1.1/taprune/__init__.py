"""TAP: Tree of Attacks with Pruning - automated jailbreaking for black-box LLMs."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("tree-of-attacks")
except PackageNotFoundError:
    __version__ = "0.0.0"

from taprune.config import TapConfig
from taprune.llm import LLM, OpenAILLM, OpenRouterLLM
from taprune.parsers import no_extra, parse_deal_from_reply, raw_reply
from taprune.results import RunResult
from taprune.tap import TAP, Node, Attacker, Evaluator, Target

__all__ = [
    "__version__",
    "TAP",
    "Node",
    "Attacker",
    "Evaluator",
    "Target",
    "LLM",
    "OpenAILLM",
    "OpenRouterLLM",
    "RunResult",
    "TapConfig",
    "no_extra",
    "parse_deal_from_reply",
    "raw_reply",
]
