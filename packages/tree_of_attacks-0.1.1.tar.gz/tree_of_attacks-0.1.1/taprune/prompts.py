"""Load Judge, Off-topic, and Attacker prompts from the config file specified by the user."""

from typing import Any, Dict

_REQUIRED_KEYS = ("judge", "off_topic", "attacker")


def get_prompts(config: dict, goal: str, starting_string: str) -> dict:
    """
    Resolve Judge, Off-topic, and Attacker prompts from the config's "prompts" section.
    The config file must define all of: judge, off_topic, attacker.
    Placeholders [[OBJECTIVE]], [[STARTING_STRING]], and [[SECRET_VALUE]] are replaced.
    [[SECRET_VALUE]] comes from config key attacker_secret_value (optional; empty string if missing).
    """
    prompts_cfg = config.get("prompts") or {}
    missing = [k for k in _REQUIRED_KEYS if not (prompts_cfg.get(k) and str(prompts_cfg.get(k)).strip())]
    if missing:
        raise ValueError(
            f"Config must define a 'prompts' section with all of {list(_REQUIRED_KEYS)}. Missing: {missing}. "
            "Specify a config file with --config <name> or --config-file <path>."
        )
    secret_value = str(config.get("attacker_secret_value", ""))
    result = {}
    for key in _REQUIRED_KEYS:
        text = (
            str(prompts_cfg[key])
            .replace("[[OBJECTIVE]]", goal)
            .replace("[[STARTING_STRING]]", starting_string)
            .replace("[[SECRET_VALUE]]", secret_value)
        )
        result[key] = text
    return result
