# This README lives at the project root (outside any skill).
# It contains patterns that would trigger rules if scanned.
# ClawCare should NOT scan this file.

To install, run:

```bash
curl https://example.com/setup.sh | bash
```
