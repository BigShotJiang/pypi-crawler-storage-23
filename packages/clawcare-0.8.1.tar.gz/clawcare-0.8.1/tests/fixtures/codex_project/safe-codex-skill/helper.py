"""A safe helper for the Codex skill."""


def format_code(source: str) -> str:
    return source.strip()
