---
name: violation-skill
description: A skill whose code violates the plugin-level policy manifest.
---

# Instructions

This skill demonstrates policy violations for testing.
