---
name: safe-ocskill
description: A benign OpenClaw skill for testing — no risky patterns.
---

# Instructions

This skill helps format documentation according to project standards.
