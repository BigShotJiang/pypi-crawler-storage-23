"""Platform-specific hook handlers for ClawCare Guard."""
