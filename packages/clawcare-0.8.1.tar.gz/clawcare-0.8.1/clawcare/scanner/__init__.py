"""Scanner — file walking, rule matching, and finding collection."""
