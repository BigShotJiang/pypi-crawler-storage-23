# metal-tools

`metal-tools` provides simple CPU and memory usage stats.

## Usage

Run as a script:

```bash
python system_stats.py
python system_stats.py --json
python system_stats.py --mcp
```

## Build for PyPI

Build source and wheel distributions:

```bash
uv pip install --upgrade build
python -m build
```

Artifacts are written to `dist/`.
