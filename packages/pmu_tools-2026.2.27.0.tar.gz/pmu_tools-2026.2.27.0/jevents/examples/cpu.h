unsigned mem_loads_event(void);
unsigned mem_stores_event(void);
