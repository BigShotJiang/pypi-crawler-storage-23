import os
import numpy as np
import torch
from torchvision import datasets
from typing import Literal
from pathlib import Path
from byzh.core import B_os
from PIL import Image

from ..standard import b_data_standard2d
from .base import Download_Base


class B_Download_Oxford_IIIT_Pet(Download_Base):
    def __init__(self, save_dir='./Oxford-IIIT-Pet', mean=None, std=None):
        super().__init__(save_dir, mean, std)
    def _get_name(self):
        return "Oxford-IIIT-Pet"
    def _get_num_classes(self):
        return 37
    def _get_num_samples(self):
        return 3_680 + 3_669
    def _get_shape(self):
        return (3, 224, 224)
    def download(self):
        '''
        采用 torchvision 下载数据集\n

        :param save_dir:
        :return: X_train, y_train, X_test, y_test
        '''
        downloading_dir = os.path.join(self.save_dir, f'{self.name}_download_dir')

        if self._check(self.save_paths):
            X_train = torch.load(self.save_paths[0])
            y_train = torch.load(self.save_paths[1])
            X_test = torch.load(self.save_paths[2])
            y_test = torch.load(self.save_paths[3])
            return X_train, y_train, X_test, y_test

        # 未标准化
        train_data = datasets.OxfordIIITPet(root=downloading_dir, split="trainval", target_types="category", download=True)
        test_data = datasets.OxfordIIITPet(root=downloading_dir, split="test", target_types="category", download=True)

        # 拆分
        def pil_to_tensor_01(img):
            if img.mode != "RGB":
                img = img.convert("RGB")
            if img.size != (224, 224):
                img = img.resize((224, 224), resample=Image.BILINEAR)
            arr = np.asarray(img, dtype=np.uint8).copy()
            x = torch.from_numpy(arr).permute(2, 0, 1).float()
            return x

        X_train = torch.stack([pil_to_tensor_01(train_data[i][0]) for i in range(len(train_data))], dim=0) / 255.0
        y_train = torch.tensor([train_data[i][1] for i in range(len(train_data))], dtype=torch.long)

        X_test = torch.stack([pil_to_tensor_01(test_data[i][0]) for i in range(len(test_data))], dim=0) / 255.0
        y_test = torch.tensor([test_data[i][1] for i in range(len(test_data))], dtype=torch.long)

        print(f"X_train.shape: {X_train.shape}")
        print(f"y_train.shape: {y_train.shape}")
        print(f"X_test.shape: {X_test.shape}")
        print(f"y_test.shape: {y_test.shape}")
        B, C, H, W = X_train.shape
        print(f"X_train[{B // 2}, {C // 2}, {H // 2}]=\n{X_train[B // 2, C // 2, H // 2]}")

        # 保存
        os.makedirs(self.save_dir, exist_ok=True)
        torch.save(X_train, self.save_paths[0])
        torch.save(y_train, self.save_paths[1])
        torch.save(X_test, self.save_paths[2])
        torch.save(y_test, self.save_paths[3])

        B_os.rm(downloading_dir)

        return X_train, y_train, X_test, y_test