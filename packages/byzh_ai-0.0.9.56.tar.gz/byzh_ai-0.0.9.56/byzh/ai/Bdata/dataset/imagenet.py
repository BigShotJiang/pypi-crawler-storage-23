import os
import numpy as np
import torch
from torchvision import datasets
from typing import Literal
from pathlib import Path
from byzh.core import B_os
from PIL import Image
from datasets import load_dataset

from ..standard import b_data_standard2d
from .base import Download_Base

class B_Download_Tiny_ImageNet(Download_Base):
    def __init__(self, save_dir='./Tiny-ImageNet', mean=None, std=None):
        super().__init__(save_dir, mean, std)

    def _get_name(self):
        return "Tiny-ImageNet"

    def _get_num_classes(self):
        return 200

    def _get_num_samples(self):
        return 100_000 + 10_000

    def _get_shape(self):
        return (3, 64, 64)

    def download(self):
        '''
        采用 huggingface 下载数据集\n

        :param save_dir:
        :return: X_train, y_train, X_test, y_test
        '''
        downloading_dir = os.path.join(self.save_dir, f'{self.name}_download_dir')

        if self._check(self.save_paths):
            X_train = torch.load(self.save_paths[0])
            y_train = torch.load(self.save_paths[1])
            X_test = torch.load(self.save_paths[2])
            y_test = torch.load(self.save_paths[3])
            return X_train, y_train, X_test, y_test

        # 未标准化
        ds = load_dataset("zh-plus/tiny-imagenet", cache_dir=self.save_dir)
        # print(ds.keys()) # dict_keys(['train', 'valid'])

        def to_rgb64(img: Image.Image):
            # 统一通道
            if img.mode != "RGB":
                img = img.convert("RGB")
            return np.asarray(img, dtype=np.uint8)  # (64,64,3)

        # train
        train = ds["train"]
        imgs = np.stack([to_rgb64(img) for img in train["image"]], axis=0) # (N,64,64,3)
        X_train = torch.from_numpy(imgs).permute(0, 3, 1, 2) / 255.0 # (N,3,64,64)
        y_train = torch.tensor(train["label"], dtype=torch.long)

        # test
        valid = ds["valid"]
        imgs = np.stack([to_rgb64(img) for img in valid["image"]], axis=0) # (N,64,64,3)
        X_test = torch.from_numpy(imgs).permute(0, 3, 1, 2) / 255.0 # (N,3,64,64)
        y_test = torch.tensor(valid["label"], dtype=torch.long)

        print(f"X_train.shape: {X_train.shape}")
        print(f"y_train.shape: {y_train.shape}")
        print(f"X_test.shape: {X_test.shape}")
        print(f"y_test.shape: {y_test.shape}")
        B, C, H, W = X_train.shape
        print(f"X_train[{B // 2}, {C // 2}, {H // 2}]=\n{X_train[B // 2, C // 2, H // 2]}")

        # 保存
        os.makedirs(self.save_dir, exist_ok=True)
        torch.save(X_train, self.save_paths[0])
        torch.save(y_train, self.save_paths[1])
        torch.save(X_test, self.save_paths[2])
        torch.save(y_test, self.save_paths[3])

        B_os.rm(downloading_dir)

        return X_train, y_train, X_test, y_test
