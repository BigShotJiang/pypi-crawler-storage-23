import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn
import torch.nn.functional as F

class B_LeNet5_Paper(nn.Module):
    def __init__(self, num_classes: int = 10):
        super().__init__()

        # C1
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=0)
        # C3
        self.conv2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1, padding=0)
        # C5
        self.conv3 = nn.Conv2d(in_channels=16, out_channels=120, kernel_size=5, stride=1, padding=0)

        # F6
        self.fc1 = nn.Linear(120, 84)
        # F7
        self.fc2 = nn.Linear(84, num_classes)

        # S2/S4
        self.pool = nn.AvgPool2d(kernel_size=2, stride=2)

        # activation
        self.act = nn.Tanh()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # If input is MNIST 28x28, pad to 32x32 (2 pixels each side)
        # (N,1,28,28) -> (N,1,32,32)
        if x.shape[-2:] == (28, 28):
            x = F.pad(x, (2, 2, 2, 2))  # left,right,top,bottom

        # C1: (N,1,32,32) -> (N,6,28,28)
        x = self.conv1(x)
        x = self.act(x)
        # S2: (N,6,28,28) -> (N,6,14,14)
        x = self.pool(x)

        # C3: (N,6,14,14) -> (N,16,10,10)
        x = self.conv2(x)
        x = self.act(x)
        # S4: (N,16,10,10) -> (N,16,5,5)
        x = self.pool(x)

        # C5: (N,16,5,5) -> (N,120,1,1)
        x = self.conv3(x)
        x = self.act(x)

        # flatten: (N,120,1,1) -> (N,120)
        x = x.view(x.size(0), -1)

        # F6: (N,120) -> (N,84)
        x = self.fc1(x)
        x = self.act(x)
        # Output: (N,84) -> (N,10)
        x = self.fc2(x)

        return x


class B_Lenet5(nn.Module):
    def __init__(self, num_classes, interpolate=True):
        super().__init__()

        self.interpolate = interpolate

        # [b, 6, 32, 32]
        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 6, kernel_size=5, stride=1, padding=0),
            nn.BatchNorm2d(6),
            nn.ReLU(),
        )
        # [b, 6, 28, 28]
        self.subsample1 = nn.MaxPool2d(kernel_size=2, stride=2)  # 下采样
        # [b, 6, 14, 14]
        self.layer2 = nn.Sequential(
            nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0),
            nn.BatchNorm2d(16),
            nn.ReLU(),
        )
        # [b, 16, 10, 10]
        self.subsample2 = nn.MaxPool2d(kernel_size=2, stride=2)  # 下采样
        # [b, 16, 5, 5]

        # 全连接
        self.L1 = nn.Linear(400, 120)
        self.relu = nn.ReLU()
        self.L2 = nn.Linear(120, 84)
        self.relu1 = nn.ReLU()
        self.L3 = nn.Linear(84, num_classes)

    def forward(self, x):
        if self.interpolate:
            x = F.interpolate(x, size=(32, 32), mode='bilinear', align_corners=False)

        x = self.layer1(x)
        x = self.subsample1(x)
        x = self.layer2(x)
        x = self.subsample2(x)
        # 将上一步输出的16个5×5特征图中的400个像素展平成一维向量，以便下一步全连接
        x = x.reshape(x.size(0), -1)
        # 全连接
        x = self.L1(x)
        x = self.relu(x)
        x = self.L2(x)
        x = self.relu1(x)
        x = self.L3(x)
        return x

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # fan_out模式会根据输出通道的数量来计算标准差
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                if m.bias is not None: # 当bias=False时，bias=None
                    nn.init.constant_(m.bias, 0)


if __name__ == '__main__':
    net = B_Lenet5(2)
    a = torch.randn(50, 1, 32, 32)
    result = net(a)
    print(result.shape)