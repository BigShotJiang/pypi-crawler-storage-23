import numpy as np
import matplotlib.pyplot as plt

# -------------------------
# GELU (tanh approximation)
# -------------------------
def gelu(x):
    """GELU (tanh approximation)"""
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * x**3)))

def gelu_derivative_numeric(x, eps=1e-4):
    """Numeric derivative: f'(x) ≈ (f(x+eps)-f(x-eps)) / (2*eps)"""
    return (gelu(x + eps) - gelu(x - eps)) / (2 * eps)

plt.figure(figsize=(12, 4))

x = np.linspace(-10, 10, 2000)  # 平滑函数，点多一点更好看
y = gelu(x)
dy = gelu_derivative_numeric(x)

# (1) function
plt.subplot(1, 2, 1)
plt.plot(x, y, color='blue', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

plt.scatter(0, 0, color='red', s=30, zorder=5)
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1.2, 1.2),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title('GELU', fontsize=12)
plt.xlabel('x')
plt.ylabel('gelu(x)')
plt.grid(True, alpha=0.3)

# (2) derivative
plt.subplot(1, 2, 2)
plt.plot(x, dy, color='red', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axhline(y=1, color='gray', linestyle=':', alpha=0.8)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

d0 = float(gelu_derivative_numeric(np.array([0.0]))[0])  # 约等于 0.5
plt.scatter(0, d0, color='blue', s=30, zorder=5)
plt.annotate(f'(0, {d0:.3f})', xy=(0, d0), xytext=(1.2, d0 + 0.1),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('GELU Derivative (numeric)', fontsize=12)
plt.xlabel('x')
plt.ylabel("d/dx gelu(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.2)

plt.tight_layout()

# plt.show()
plt.savefig('./gelu.png', dpi=300)