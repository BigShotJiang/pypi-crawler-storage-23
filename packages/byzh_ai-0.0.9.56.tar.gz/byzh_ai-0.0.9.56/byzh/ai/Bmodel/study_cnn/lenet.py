import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

class ScaledTanh(nn.Module):
    """
    原论文常用的缩放版 tanh
    f(x) = 1.7159 * tanh((2/3) * x)

    后来: 被 ReLU 系列替代
    """
    def __init__(self, A=1.7159, S=2.0/3.0):
        super().__init__()
        self.A = A
        self.S = S

    def forward(self, x):
        return self.A * torch.tanh(self.S * x)


class SubsamplingLayer(nn.Module):
    """
    原论文的 S 层（subsampling layer）
    不是纯 AvgPool，而是：
        y = a * avgpool(x) + b
    其中 a,b 对每个通道(feature map)可学习

    输入:  (N, C, H, W)
    输出:  (N, C, H/2, W/2)  (当 kernel=2, stride=2)
    """
    def __init__(self, channels, kernel_size=2, stride=2):
        super().__init__()
        # 平均池化：负责下采样
        self.pool = nn.AvgPool2d(kernel_size=kernel_size, stride=stride)

        # 每个通道一个可学习的缩放系数 a 和偏置 b
        # 形状是 (C,) ，forward 时会 reshape 成 (1,C,1,1) 以便广播
        self.a = nn.Parameter(torch.ones(channels))
        self.b = nn.Parameter(torch.zeros(channels))

    def forward(self, x):
        # 先做下采样
        x = self.pool(x)  # (N,C,H/2,W/2)

        # 做通道级的仿射变换：a * x + b
        a = self.a.view(1, -1, 1, 1)
        b = self.b.view(1, -1, 1, 1)
        x = a * x + b

        return x


class B_LeNet5_Paper(nn.Module):
    """
    输入: (N, 1, 32, 32)

    注意：
    - 这里把 S2/S4 改成论文里的 subsampling（avgpool + 可学习 a,b）
    - 激活用论文常用的 scaled tanh
    - C3 的“部分连接表”(partial connectivity) 这里仍使用现代全连接卷积（更常见的复现做法）
      如果你要严格复刻 C3 的连接表，我也可以再给一版

    工作流(形状):
    input shape: (N,1,32,32)
      -> conv5x5 -> (N,6,28,28) [可学习]
      -> tanh
      -> paper-sub -> (N,6,14,14) [可学习 a,b]
      -> conv5x5 -> (N,16,10,10) [可学习]
      -> tanh
      -> paper-sub -> (N,16,5,5) [可学习 a,b]
      -> conv5x5 -> (N,120,1,1) [可学习]
      -> tanh
      -> flatten -> (N,120)
      -> linear -> (N,84) [可学习]
      -> tanh
      -> linear -> (N,10) [可学习]
    """
    def __init__(self, num_classes=10):
        super().__init__()

        # 论文风格激活
        self.act = ScaledTanh()

        # C1: 1 -> 6
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5, stride=1, padding=0)

        # S2: 6 通道的论文风格下采样（avgpool + 可学习 a,b）
        # 是否在 S 层后再接激活：这里先不接（更保守、也更常见）
        self.pool2 = SubsamplingLayer(channels=6, kernel_size=2, stride=2)

        # C3: 6 -> 16
        self.conv3 = nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0)

        # S4: 16 通道的论文风格下采样
        self.pool4 = SubsamplingLayer(channels=16, kernel_size=2, stride=2)

        # C5: 16 -> 120，输入正好是 5x5，所以输出 1x1
        self.conv5 = nn.Conv2d(16, 120, kernel_size=5, stride=1, padding=0)

        # F6
        self.fc6 = nn.Linear(120, 84)
        # F7
        self.fc7 = nn.Linear(84, num_classes)

    def forward(self, x):
        # 兼容 MNIST 原始 28x28：先 pad 到 32x32
        if x.shape[-2:] == (28, 28):
            x = F.pad(x, (2, 2, 2, 2), mode="constant", value=0.0)  # left,right,top,bottom

        # conv + act
        x = self.conv1(x)          # (N,6,28,28)
        x = self.act(x)

        # pool
        x = self.pool2(x)          # (N,6,14,14)

        # conv + act
        x = self.conv3(x)          # (N,16,10,10)
        x = self.act(x)

        # pool
        x = self.pool4(x)          # (N,16,5,5)

        # conv + act
        x = self.conv5(x)          # (N,120,1,1)
        x = self.act(x)

        # flatten
        x = x.view(x.size(0), -1)  # (N,120)

        # linear + act
        x = self.fc6(x)            # (N,84)
        x = self.act(x)

        # linear
        logits = self.fc7(x)       # (N,10)

        return logits

if __name__ == '__main__':
    net = B_LeNet5_Paper(num_classes=2)
    a = torch.randn(50, 1, 28, 28)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 61_070