import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params


class BasicBlock(nn.Module):
    """
    ResNet-18/34 使用的基础残差块（BasicBlock）。

    主分支（main path）：
        conv3x3(stride) -> BN -> ReLU -> conv3x3(stride=1) -> BN
        （第二个卷积后不立刻 ReLU，先与残差分支相加）

    残差分支（shortcut / identity path）：
        - 当 stride=1 且 in_ch==out_ch 时：恒等映射（x 直接相加）
        - 当 stride!=1 或 in_ch!=out_ch 时：使用 1x1 conv + BN
          用于下采样（stride）或通道对齐

    输出：
        ReLU(main + shortcut)
    """
    expansion = 1  # BasicBlock 不扩张通道：输出通道数 = out_ch * expansion = out_ch

    def __init__(self, in_ch: int, out_ch: int, stride: int = 1):
        """
        Args:
            in_ch  : 输入特征图通道数 C_in
            out_ch : 主分支两层 3x3 卷积的输出通道数（基础通道数）
            stride : 第一层 3x3 卷积的步长
                     - stride=1：不下采样，空间尺寸不变
                     - stride=2：下采样，H/W 减半（典型 stage 切换）
        """
        super().__init__()

        # =========================
        # 主分支 main path
        # =========================

        # conv1：3x3 卷积（可能下采样）
        # padding=1 让 stride=1 时保持 H/W 不变
        self.conv1 = nn.Conv2d(
            in_ch, out_ch, kernel_size=3, stride=stride, padding=1, bias=False
        )
        self.bn1 = nn.BatchNorm2d(out_ch)

        # conv2：3x3 卷积（不下采样，stride=1）
        # 第二层卷积后不立刻 ReLU：符合 ResNet v1 的 “post-activation after add”
        self.conv2 = nn.Conv2d(
            out_ch, out_ch, kernel_size=3, stride=1, padding=1, bias=False
        )
        self.bn2 = nn.BatchNorm2d(out_ch)

        # =========================
        # 残差分支 shortcut
        # =========================
        # 默认恒等映射：当尺寸和通道都一致时，不做任何参数化变换
        self.shortcut = nn.Sequential()

        # 若 stride!=1（空间尺寸变化）或 in_ch!=out_ch（通道不一致）
        # 需要通过 1x1 conv 对齐：既可以下采样也可以通道匹配
        if stride != 1 or in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_ch),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: 输入特征图，形状 (N, C_in, H, W)

        Returns:
            输出特征图，形状 (N, C_out, H', W')
        """
        # -------- main path --------
        out = self.conv1(x)
        out = self.bn1(out)
        out = torch.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        # -------- residual add --------
        # shortcut(x) 要与 main 的 out 在 (N, C, H, W) 上完全同形状，才能逐元素相加
        out = out + self.shortcut(x)

        # -------- activation after add --------
        out = torch.relu(out)
        return out


class Bottleneck(nn.Module):
    """
    ResNet-50/101/152 使用的瓶颈残差块（Bottleneck）。

    主分支（main path）：
        1) 1x1 conv: 降维（C_in -> out_ch）
        2) 3x3 conv: 特征提取（stride 控制是否下采样）
        3) 1x1 conv: 升维（out_ch -> out_ch * expansion）

        每个卷积后接 BN；ReLU 放在前两层后；
        第三层 1x1 卷积后不立即 ReLU，先与 shortcut 相加，再 ReLU。

    残差分支（shortcut）：
        - 当 stride=1 且 in_ch==out_ch*expansion：恒等映射
        - 否则：1x1 conv(stride) + BN 做尺寸/通道对齐

    注：
        expansion=4 是经典 ResNet bottleneck 设计：
        最终输出通道 C_out = out_ch * 4
    """
    expansion = 4  # 瓶颈块最终输出通道扩大 4 倍

    def __init__(self, in_ch: int, out_ch: int, stride: int = 1):
        """
        Args:
            in_ch  : 输入通道数 C_in
            out_ch : 瓶颈内部通道数（中间维度），最终输出通道为 out_ch*4
            stride : 3x3 卷积的步长（通常在 stage 切换时为 2）
        """
        super().__init__()

        # =========================
        # 主分支 main path
        # =========================

        # conv1：1x1 降维，不改变空间尺寸
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)

        # conv2：3x3 特征提取，可下采样（stride）
        # padding=1 让 stride=1 时保持 H/W 不变
        self.conv2 = nn.Conv2d(
            out_ch, out_ch, kernel_size=3, stride=stride, padding=1, bias=False
        )
        self.bn2 = nn.BatchNorm2d(out_ch)

        # conv3：1x1 升维，输出通道 out_ch*expansion
        self.conv3 = nn.Conv2d(out_ch, out_ch * self.expansion, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_ch * self.expansion)

        # =========================
        # 残差分支 shortcut
        # =========================
        self.shortcut = nn.Sequential()

        # 若 stride!=1（空间尺寸变化）或通道数不匹配（in_ch != out_ch*expansion）
        # 需要对齐后才能相加
        if stride != 1 or in_ch != out_ch * self.expansion:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_ch * self.expansion),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: 输入特征图，形状 (N, C_in, H, W)

        Returns:
            输出特征图，形状 (N, out_ch*4, H', W')
            - H'/W' 由 stride 决定（stride=2 时通常减半）
        """
        # -------- 1) reduce --------
        out = self.conv1(x)
        out = self.bn1(out)
        out = torch.relu(out)

        # -------- 2) transform --------
        out = self.conv2(out)
        out = self.bn2(out)
        out = torch.relu(out)

        # -------- 3) expand (no ReLU here) --------
        out = self.conv3(out)
        out = self.bn3(out)

        # -------- residual add --------
        out = out + self.shortcut(x)

        # -------- activation after add --------
        out = torch.relu(out)
        return out


class ResNet(nn.Module):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, block, layers, num_classes=1000):
        super().__init__()
        self.in_ch = 64

        self.conv1 = nn.Conv2d(3, 64, 7, 2, 3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(3, 2, 1)

        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512 * block.expansion, num_classes)

    def _make_layer(self, block, out_ch, blocks, stride=1):
        layers = []
        layers.append(block(self.in_ch, out_ch, stride))
        self.in_ch = out_ch * block.expansion

        for _ in range(1, blocks):
            layers.append(block(self.in_ch, out_ch))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = torch.relu(self.bn1(self.conv1(x)))
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x

class B_ResNet18_Paper(ResNet):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        block = BasicBlock
        layers = [2, 2, 2, 2]
        super().__init__(block=block, layers=layers, num_classes=num_classes)


class B_ResNet34_Paper(ResNet):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        block = BasicBlock
        layers = [3, 4, 6, 3]
        super().__init__(block=block, layers=layers, num_classes=num_classes)

class B_ResNet50_Paper(ResNet):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        block = Bottleneck
        layers = [3, 4, 6, 3]
        super().__init__(block=block, layers=layers, num_classes=num_classes)

class B_ResNet101_Paper(ResNet):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        block = Bottleneck
        layers = [3, 4, 23, 3]
        super().__init__(block=block, layers=layers, num_classes=num_classes)

class B_ResNet152_Paper(ResNet):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        block = Bottleneck
        layers = [3, 8, 36, 3]
        super().__init__(block=block, layers=layers, num_classes=num_classes)

if __name__ == '__main__':
    # ResNet18
    net = B_ResNet18_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 11_689_512

    # ResNet34
    net = B_ResNet34_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 21_797_672

    # ResNet50
    net = B_ResNet50_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 25_557_032

    # ResNet101
    net = B_ResNet101_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 44_549_160

    # ResNet152
    net = B_ResNet152_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}")  # 60_192_808