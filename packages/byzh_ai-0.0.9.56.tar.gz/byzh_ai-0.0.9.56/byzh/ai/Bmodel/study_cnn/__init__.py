from .lenet import B_LeNet5_Paper
from .alexnet import B_AlexNet_Paper
from .nin import B_NiN_Paper_CIFAR, B_NiN_Paper_ImageNet
from .vgg import B_VGG11_Paper, B_VGG13_Paper, B_VGG16_Paper, B_VGG19_Paper
from .googlenet import B_GoogLeNet_Paper
from .resnet import B_ResNet18_Paper, B_ResNet34_Paper, B_ResNet50_Paper, B_ResNet101_Paper, B_ResNet152_Paper
from .densenet import B_DenseNet121_Paper

__all__ = [
    'B_LeNet5_Paper',
    'B_AlexNet_Paper',
    'B_NiN_Paper_CIFAR', 'B_NiN_Paper_ImageNet',
    'B_VGG11_Paper', 'B_VGG13_Paper', 'B_VGG16_Paper', 'B_VGG19_Paper',
    'B_GoogLeNet_Paper',
    'B_ResNet18_Paper', 'B_ResNet34_Paper', 'B_ResNet50_Paper', 'B_ResNet101_Paper', 'B_ResNet152_Paper',
    'B_DenseNet121_Paper',
]