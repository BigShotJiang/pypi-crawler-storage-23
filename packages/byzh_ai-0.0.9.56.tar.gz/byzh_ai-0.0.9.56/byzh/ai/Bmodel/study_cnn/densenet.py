import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params


class DenseLayer(nn.Module):
    """
    DenseNet-BC 单层：
    BN -> ReLU -> 1x1 -> BN -> ReLU -> 3x3 -> (Dropout optional) -> Concat

    input_shape: (N, in_channels, H, W)
    output_shape: (N, in_channels+growth_rate, H, W)
    """
    def __init__(self, in_channels, growth_rate, bn_size=4, drop_rate=0.0):
        super().__init__()
        mid_channels = bn_size * growth_rate # growth_rate就是k

        # Pre-Activation 结构
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv1 = nn.Conv2d(in_channels, mid_channels, kernel_size=1, bias=False) # 先用 1x1 降维

        # Pre-Activation 结构
        self.bn2 = nn.BatchNorm2d(mid_channels)
        self.conv2 = nn.Conv2d(mid_channels, growth_rate, kernel_size=3, padding=1, bias=False) # 再用 3x3 提取特征

        self.drop_rate = drop_rate

    def forward(self, x):
        # Pre-Activation 结构
        out = self.bn1(x)
        out = F.relu(out, inplace=True)
        out = self.conv1(out)

        # Pre-Activation 结构
        out = self.bn2(out)
        out = F.relu(out, inplace=True)
        out = self.conv2(out)

        if self.drop_rate > 0.0:
            out = F.dropout(out, p=self.drop_rate, training=self.training)

        # 通道维度合并
        layer_out = torch.cat([x, out], dim=1)

        return layer_out


class DenseBlock(nn.Module):
    """
    input_shape: (N, in_channels, H, W)
    output_shape: (N, in_channels+num_layers*growth_rate, H, W)
    """
    def __init__(self, num_layers, in_channels, growth_rate, bn_size=4, drop_rate=0.0):
        super().__init__()
        layers = []
        for i in range(num_layers):
            layers.append(
                DenseLayer(
                    in_channels=in_channels + i * growth_rate,
                    growth_rate=growth_rate,
                    bn_size=bn_size,
                    drop_rate=drop_rate
                )
            )
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        out = self.block(x)
        return out


class Transition(nn.Module):
    """
    过渡层: 压缩特征图数量并降低分辨率
    BN -> ReLU -> 1x1 Conv -> AvgPool2d

    input_shape: (N, in_ch, H, W)
    output_shape: (N, out_ch, H/2, W/2)
    """
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.bn = nn.BatchNorm2d(in_ch)
        self.conv = nn.Conv2d(in_ch, out_ch, kernel_size=1, bias=False)

        self.pool = nn.AvgPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        # Pre-Activation 结构
        x = self.bn(x)
        x = F.relu(x, inplace=True)
        x = self.conv(x)

        # 用 AvgPool2d 降采样
        x = self.pool(x)
        return x


class B_DenseNet121_Paper(nn.Module):
    """
    DenseNet-121 (DenseNet-BC)

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, growth_rate=32, bn_size=4, compression=0.5, drop_rate=0.0):
        """
        :param growth_rate: 密集连接网络中的增长率，即每个密集块中每层输出的特征图数量
        :param bn_size: 瓶颈层中 1x1 卷积的倍数因子，用于控制瓶颈层的宽度
        :param compression: 过渡层的压缩比例，用于减少特征图的数量，取值范围 (0, 1)
        :param drop_rate: 训练时的 dropout 比例，用于防止过拟合
        """
        super().__init__()
        block_config = [6, 12, 24, 16]
        num_init_features = 64

        # Stem(ImageNet): “降采样”与“特征提取”
        self.conv1 = nn.Conv2d(3, num_init_features, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(num_init_features)
        self.pool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        num_features = num_init_features # 64

        # DenseBlock 1
        self.block1 = DenseBlock(block_config[0], num_features, growth_rate, bn_size, drop_rate)
        num_features = num_features + block_config[0] * growth_rate # 64 + 6*32
        out_features = int(num_features * compression) # (64 + 6*32)*0.5
        self.trans1 = Transition(num_features, out_features)
        num_features = out_features # 128

        # DenseBlock 2
        self.block2 = DenseBlock(block_config[1], num_features, growth_rate, bn_size, drop_rate)
        num_features = num_features + block_config[1] * growth_rate # 128 + 12*32
        out_features = int(num_features * compression) # (128 + 12*32)*0.5
        self.trans2 = Transition(num_features, out_features)
        num_features = out_features # 256

        # DenseBlock 3
        self.block3 = DenseBlock(block_config[2], num_features, growth_rate, bn_size, drop_rate)
        num_features = num_features + block_config[2] * growth_rate # 256 + 24*32
        out_features = int(num_features * compression) # (256 + 24*32)*0.5
        self.trans3 = Transition(num_features, out_features)
        num_features = out_features # 512

        # DenseBlock 4
        self.block4 = DenseBlock(block_config[3], num_features, growth_rate, bn_size, drop_rate)
        num_features = num_features + block_config[3] * growth_rate # 512 + 16*32 = 1024

        # Head: 头部网络: 最终的任务
        self.bn_final = nn.BatchNorm2d(num_features)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(num_features, num_classes)

    def forward(self, x):
        # x: (N, 3, 224, 224)

        # Stem: “降采样”与“特征提取”
        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x, inplace=True)
        x = self.pool1(x)
        # x: (N, 64, 56, 56)

        # DenseBlock 1
        x = self.block1(x)
        x = self.trans1(x)
        # x: (N, 128, 28, 28)

        # DenseBlock 2
        x = self.block2(x)
        x = self.trans2(x)
        # x: (N, 256, 14, 14)

        # DenseBlock 3
        x = self.block3(x)
        x = self.trans3(x)
        # x: (N, 512, 7, 7)

        # DenseBlock 4
        x = self.block4(x)
        # x: (N, 1024, 7, 7)

        x = self.bn_final(x)
        x = F.relu(x, inplace=True)
        x = self.avgpool(x)
        x = self.flatten(x)
        x = self.fc(x)

        return x

if __name__ == '__main__':
    net = B_DenseNet121_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}") # 7_978_856