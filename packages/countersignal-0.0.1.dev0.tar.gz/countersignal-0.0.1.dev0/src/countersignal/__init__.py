"""CounterSignal - Agentic AI content & supply chain attack toolkit."""
