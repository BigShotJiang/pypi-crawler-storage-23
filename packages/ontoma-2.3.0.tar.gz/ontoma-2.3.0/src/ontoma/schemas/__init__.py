"""DataFrame JSON schemas."""

from __future__ import annotations
