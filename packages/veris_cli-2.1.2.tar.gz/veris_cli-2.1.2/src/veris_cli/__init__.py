"""Veris CLI - Connect your existing agent to Veris simulations."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("veris-cli")
except PackageNotFoundError:
    __version__ = "unknown"
