"""Configuration management for Veris CLI."""

from pathlib import Path
from typing import Optional

import yaml


class Config:
    """Manages CLI configuration stored in ~/.veris/config.yaml"""

    def __init__(self):
        self.config_dir = Path.home() / ".veris"
        self.config_file = self.config_dir / "config.yaml"

    def load(self) -> dict:
        """Load configuration from ~/.veris/config.yaml"""
        if not self.config_file.exists():
            return {}

        with open(self.config_file, "r") as f:
            return yaml.safe_load(f) or {}

    def save(self, config: dict) -> None:
        """Save configuration to ~/.veris/config.yaml"""
        self.config_dir.mkdir(parents=True, exist_ok=True)

        with open(self.config_file, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)

    def get_api_key(self) -> Optional[str]:
        """Get API key from config"""
        config = self.load()
        return config.get("api_key")

    def get_backend_url(self) -> str:
        """Get backend URL from config, defaults to prod"""
        config = self.load()
        return config.get("backend_url", "https://sandbox.api.veris.ai")

    def set_api_key(self, api_key: str, backend_url: str = "https://sandbox.api.veris.ai") -> None:
        """Set API key and backend URL in config"""
        config = self.load()
        config["api_key"] = api_key
        config["backend_url"] = backend_url
        self.save(config)


class ProjectConfig:
    """Manages project-level configuration stored in .veris/config.yaml"""

    def __init__(self, project_dir: Optional[Path] = None):
        self.project_dir = project_dir or Path.cwd()
        self.veris_dir = self.project_dir / ".veris"
        self.config_file = self.veris_dir / "config.yaml"

    def load(self) -> dict:
        """Load project configuration from .veris/config.yaml"""
        if not self.config_file.exists():
            return {}

        with open(self.config_file, "r") as f:
            return yaml.safe_load(f) or {}

    def save(self, config: dict) -> None:
        """Save project configuration to .veris/config.yaml"""
        self.veris_dir.mkdir(parents=True, exist_ok=True)

        with open(self.config_file, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)

    def get_environment_id(self) -> Optional[str]:
        """Get environment ID from project config"""
        config = self.load()
        return config.get("environment_id")

    def set_environment_id(self, environment_id: str, environment_name: str) -> None:
        """Set environment ID in project config"""
        config = self.load()
        config["environment_id"] = environment_id
        config["environment_name"] = environment_name
        self.save(config)
