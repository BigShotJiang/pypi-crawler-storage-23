"""CLI for Veris - Connect agents to simulations."""

import os
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from importlib import resources
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import click

from veris_cli import output, prompts, templates
from veris_cli.api import VerisAPI
from veris_cli.config import Config, ProjectConfig


def get_script_path(script_name: str) -> Path:
    """Get path to a script file from the package."""
    try:
        # Python 3.9+
        files = resources.files("veris_cli.scripts")
        return files / script_name
    except AttributeError:
        # Fallback for older Python
        import pkg_resources

        return Path(pkg_resources.resource_filename("veris_cli.scripts", script_name))


def run_script(script_name: str, *args: str) -> int:
    """Run a bash script from the package."""
    script_path = get_script_path(script_name)
    # Run with bash explicitly, don't rely on executable bit
    result = subprocess.run(["bash", str(script_path), *args], cwd=Path.cwd())
    return result.returncode


@click.group()
@click.version_option(prog_name="veris")
def cli():
    """Veris CLI - Connect your existing agent to Veris simulations."""
    pass


@cli.command()
@click.argument("api_key", required=False, default=None)
@click.option(
    "--backend-url",
    default=None,
    help="Backend URL (default: https://sandbox.api.veris.ai)",
)
def login(api_key: str | None, backend_url: str | None):
    """Authenticate with Veris via Google login or API key.

    Usage:
      veris login                     # Browser-based Google login
      veris login <api-key>           # Direct API key login (for CI/scripts)
      veris login --backend-url URL   # Specify backend URL
    """
    config = Config()

    if backend_url:
        # Save backend URL even before auth
        cfg = config.load()
        cfg["backend_url"] = backend_url
        config.save(cfg)

    # Direct API key login (backwards compatible, useful for CI)
    if api_key:
        effective_url = backend_url or config.get_backend_url()
        config.set_api_key(api_key, effective_url)
        output.print_success(f"API key saved to {config.config_file}")
        output.print_info(f"Backend URL: {effective_url}")
        return

    # Browser-based Google OAuth login
    effective_url = backend_url or config.get_backend_url()
    result: dict[str, str] = {}
    server_ready = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            if "token" in query:
                result["token"] = query["token"][0]
                result["email"] = query.get("email", [""])[0]
                result["name"] = query.get("name", [""])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body style='font-family:system-ui;display:flex;"
                    b"justify-content:center;align-items:center;height:100vh;margin:0'>"
                    b"<div style='text-align:center'>"
                    b"<h2>Login successful!</h2>"
                    b"<p>You can close this tab and return to the CLI.</p>"
                    b"</div></body></html>"
                )
            else:
                error = query.get("error", ["Unknown error"])[0]
                result["error"] = error
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    f"<html><body><h2>Login failed: {error}</h2></body></html>".encode()
                )

        def log_message(self, *args):
            pass  # Suppress request logs

    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]

    def serve():
        server_ready.set()
        server.handle_request()  # Handle exactly one request then stop

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    server_ready.wait()

    login_url = f"{effective_url}/v1/auth/google/login?cli_port={port}"
    output.print_info("Opening browser to log in with Google...")
    webbrowser.open(login_url)

    # Wait for the callback (timeout after 2 minutes)
    thread.join(timeout=120)
    server.server_close()

    if "error" in result:
        output.print_error(f"Login failed: {result['error']}")
        sys.exit(1)
    elif "token" not in result:
        output.print_error("Login timed out. Please try again.")
        sys.exit(1)

    # Save credentials
    config.set_api_key(result["token"], effective_url)

    email = result.get("email", "")
    if email:
        output.print_success(f"Logged in as {email}")
    else:
        output.print_success("Logged in successfully")
    output.print_info(f"API key saved to {config.config_file}")


@cli.command()
@click.option("--name", default=None, help="Environment name (will prompt if not provided)")
def init(name: str):
    """Creates .veris/ folder and environment"""
    veris_dir = Path.cwd() / ".veris"

    # Create directory if it doesn't exist
    veris_dir.mkdir(parents=True, exist_ok=True)

    # Create files (only if they don't exist)
    dockerfile_path = veris_dir / "Dockerfile.sandbox"
    veris_yaml_path = veris_dir / "veris.yaml"
    env_sim_path = veris_dir / ".env.simulation"

    created_files = []

    if not dockerfile_path.exists():
        dockerfile_path.write_text(templates.get_dockerfile_sandbox())
        created_files.append("  - .veris/Dockerfile.sandbox - Docker image template")
    else:
        output.print_info("Skipping .veris/Dockerfile.sandbox (already exists)")

    if not veris_yaml_path.exists():
        veris_yaml_path.write_text(templates.get_veris_yaml())
        created_files.append("  - .veris/veris.yaml - Simulation configuration")
    else:
        output.print_info("Skipping .veris/veris.yaml (already exists)")

    if not env_sim_path.exists():
        env_sim_path.write_text(templates.get_env_simulation())
        created_files.append("  - .veris/.env.simulation - Environment variables")
    else:
        output.print_info("Skipping .veris/.env.simulation (already exists)")

    if created_files:
        output.print_success("Created files:")
        for file in created_files:
            output.print_info(file)

    # Prompt for environment name
    if not name:
        name = prompts.prompt_environment_name()
        if not name:
            output.print_error("Environment name is required")
            sys.exit(1)

    # Create environment
    output.print_info(f"\nCreating environment '{name}'...")
    try:
        api = VerisAPI()
        result = api.create_environment(name=name)

        environment = result.get("environment", {})
        env_id = environment.get("id")

        if not env_id:
            output.print_error("Failed to get environment ID from response")
            sys.exit(1)

        # Save environment ID to project config
        project_config = ProjectConfig()
        project_config.set_environment_id(env_id, name)

        output.print_success(f"Environment created: {env_id}")
        output.print_info("Environment ID saved to .veris/config.yaml")
        output.print_info("\nNext steps:")
        output.print_info("  1. Edit .veris/Dockerfile.sandbox to match your agent")
        output.print_info("  2. Edit .veris/veris.yaml with your agent settings")
        output.print_info("  3. Run 'veris env push' to build and push your image")

    except ValueError as e:
        output.print_error(str(e))
        output.print_info("You can create the environment later with 'veris env push'")
    except Exception as e:
        output.print_error(f"Failed to create environment: {e}")
        output.print_info("You can create the environment later with 'veris env push'")


# Environment commands
@cli.group()
def env():
    """Environment management commands"""
    pass


@env.command(name="build")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.option("--no-cache", is_flag=True, help="Build without using cache")
def env_build(tag: str, no_cache: bool):
    """Build Docker image (without pushing)"""
    # Validate files exist
    veris_dir = Path.cwd() / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"

    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    # Get environment ID from project config
    project_config = ProjectConfig()
    env_id = project_config.get_environment_id()

    if not env_id:
        output.print_error("No environment configured. Run 'veris init' first.")
        sys.exit(1)

    try:
        api = VerisAPI()
        result = api.create_environment_tag(environment_id=env_id, tag=tag)

        image_uri = result.get("image_uri")
        push_creds = result.get("push_credentials", {})

        if not push_creds:
            output.print_error("No push credentials received from backend")
            sys.exit(1)

        username = push_creds.get("username", "_token")
        password = push_creds.get("password", "")
        registry = push_creds.get("registry", "gcr.io")

        output.print_success(f"Tag created: {tag}")
        output.print_info(f"Building image: {image_uri}\n")

        # Run build script (with credentials to pull base image)
        no_cache_flag = "1" if no_cache else "0"
        exit_code = run_script(
            "docker_build.sh",
            str(dockerfile),
            image_uri,
            registry,
            username,
            password,
            no_cache_flag,
        )

        if exit_code != 0:
            output.print_error("Docker build failed")
            sys.exit(exit_code)

        output.print_success(f"\nImage built: {image_uri}")
        output.print_info("Run 'veris env push' to push the image")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to build: {e}")
        sys.exit(1)


@env.command(name="push")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.option("--no-cache", is_flag=True, help="Build without using cache")
def env_push(tag: str, no_cache: bool):
    """Build and push Docker image for this environment"""
    # Validate files exist
    veris_dir = Path.cwd() / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"

    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    # Get environment ID from project config
    project_config = ProjectConfig()
    env_id = project_config.get_environment_id()

    if not env_id:
        output.print_error("No environment configured. Run 'veris init' first.")
        sys.exit(1)

    try:
        api = VerisAPI()
        result = api.create_environment_tag(environment_id=env_id, tag=tag)

        image_uri = result.get("image_uri")
        push_creds = result.get("push_credentials", {})

        if not push_creds:
            output.print_error("No push credentials received from backend")
            sys.exit(1)

        username = push_creds.get("username", "_token")
        password = push_creds.get("password", "")
        registry = push_creds.get("registry", "gcr.io")

        output.print_success(f"Tag created: {tag}")
        output.print_info(f"Building and pushing image: {image_uri}\n")

        # Build image (with credentials to pull base image)
        no_cache_flag = "1" if no_cache else "0"
        exit_code = run_script(
            "docker_build.sh",
            str(dockerfile),
            image_uri,
            registry,
            username,
            password,
            no_cache_flag,
        )
        if exit_code != 0:
            output.print_error("Docker build failed")
            sys.exit(exit_code)

        # Push image
        output.print_info("\nPushing image...\n")
        exit_code = run_script("docker_push.sh", image_uri, registry, username, password)

        if exit_code != 0:
            output.print_error("Docker push failed")
            sys.exit(exit_code)

        output.print_success(f"\nImage pushed: {image_uri}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to push: {e}")
        sys.exit(1)


@env.command(name="list")
@click.option("--status", default=None, help="Filter by status (e.g., ready)")
def env_list(status: str):
    """List environments"""
    try:
        api = VerisAPI()
        result = api.list_environments(status=status)
        output.print_environments_table(result.get("environments", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list environments: {e}")
        sys.exit(1)


# Scenario commands
@cli.group()
def scenarios():
    """Scenario management commands"""
    pass


@scenarios.command(name="list")
@click.option("--visibility", default=None, help="Filter by visibility (public/private/org)")
def scenarios_list(visibility: str):
    """List scenarios"""
    try:
        api = VerisAPI()
        result = api.list_scenario_sets(visibility=visibility)
        output.print_scenario_sets_table(result)
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list scenarios: {e}")
        sys.exit(1)


# Run commands
@cli.group()
def run():
    """Run management commands"""
    pass


@run.command(name="create")
@click.option("--scenario-set-id", default=None, help="Scenario set ID")
@click.option("--env-id", default=None, help="Environment ID")
@click.option("--concurrency", default=10, help="Parallel jobs per scenario (default: 10)")
def run_create(scenario_set_id: str, env_id: str, concurrency: int):
    """Create a new run (interactive if flags omitted)"""
    try:
        api = VerisAPI()

        # Interactive mode if flags are missing
        if not scenario_set_id:
            result = api.list_scenario_sets()
            scenario_set_id = prompts.select_scenario(result)
            if not scenario_set_id:
                output.print_error("No scenario selected")
                sys.exit(1)

        if not env_id:
            result = api.list_environments(status="ready")
            env_id = prompts.select_environment(result.get("environments", []))
            if not env_id:
                output.print_error("No environment selected")
                sys.exit(1)

        if not scenario_set_id or not env_id:
            concurrency = prompts.prompt_concurrency(default=concurrency)

        # Create run
        result = api.create_run(
            scenario_set_id=scenario_set_id,
            environment_id=env_id,
            parallel_jobs=concurrency,
        )

        run_id = result.get("id")
        output.print_success(f"Run created: {run_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create run: {e}")
        sys.exit(1)


@run.command(name="status")
@click.argument("run_id")
@click.option("--watch", is_flag=True, help="Poll every 3 seconds")
def run_status(run_id: str, watch: bool):
    """Get run status"""
    try:
        api = VerisAPI()

        if watch:
            while True:
                run_data = api.get_run(run_id)
                output.print_run_details(run_data)

                status = run_data.get("status", "")
                if status in ["completed", "failed", "cancelled"]:
                    break

                time.sleep(3)
        else:
            run_data = api.get_run(run_id)
            output.print_run_details(run_data)

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get run status: {e}")
        sys.exit(1)


@run.command(name="logs")
@click.argument("run_id")
@click.option("--follow", is_flag=True, help="Poll for new events")
def run_logs(run_id: str, follow: bool):
    """Get run logs/events"""
    try:
        api = VerisAPI()

        if follow:
            last_count = 0
            while True:
                result = api.get_run_events(run_id)
                events = result.get("events", [])
                new_events = events[last_count:]

                if new_events:
                    output.print_run_events(new_events)
                    last_count = len(events)

                time.sleep(3)
        else:
            result = api.get_run_events(run_id)
            output.print_run_events(result.get("events", []))

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get run logs: {e}")
        sys.exit(1)


@run.command(name="cancel")
@click.argument("run_id")
def run_cancel(run_id: str):
    """Cancel a run"""
    try:
        if not prompts.confirm_action(f"Cancel run {run_id}?", default=False):
            output.print_info("Cancelled")
            return

        api = VerisAPI()
        api.cancel_run(run_id)
        output.print_success(f"Run {run_id} cancelled")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to cancel run: {e}")
        sys.exit(1)


def _load_dotenv(path: Path) -> dict[str, str]:
    """Parse and return environment variables from a .env file."""
    env = {}
    if not path.exists():
        return env

    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            # Strip quotes from value
            v = v.strip().strip('"').strip("'")
            env[k.strip()] = v
    return env


def _resolve_scenarios(scenarios_dir: Path, scenario_args: tuple[str, ...]) -> list[str]:
    """Resolve scenario IDs from arguments or by scanning scenarios directory.

    Returns a list of scenario IDs (e.g., ['checkout', 'payment']).
    """
    # If specific scenarios are provided, use them as-is
    if scenario_args:
        return list(scenario_args)

    # Otherwise, scan the scenarios directory
    if not scenarios_dir.exists():
        # Fallback to default scenario
        return ["customer_browse_and_purchase"]

    scenarios = []

    for entry in sorted(scenarios_dir.iterdir()):
        if entry.is_file():
            # Strip extension to get scenario ID
            # e.g., checkout.yaml -> checkout
            stem = entry.stem
            if stem and not stem.startswith("."):
                scenarios.append(stem)
        elif entry.is_dir():
            # Use directory name as scenario ID
            # e.g., checkout/ -> checkout
            if not entry.name.startswith("."):
                scenarios.append(entry.name)

    # If no scenarios found, use default
    if not scenarios:
        scenarios = ["customer_browse_and_purchase"]

    return scenarios


@run.command(name="local")
@click.argument("scenarios", nargs=-1)
@click.option("--skip-build", is_flag=True, help="Skip building the Docker image")
@click.option("--image", default="veris-sandbox", help="Docker image name (default: veris-sandbox)")
@click.option("--platform", default="linux/arm64", help="Docker platform (default: linux/arm64)")
@click.option(
    "--scenarios-dir", default="./scenarios", help="Path to scenarios folder (default: ./scenarios)"
)
@click.option(
    "--concurrency", default=None, type=int, help="Max parallel containers (default: unbounded)"
)
def run_local(
    scenarios: tuple[str, ...],
    skip_build: bool,
    image: str,
    platform: str,
    scenarios_dir: str,
    concurrency: int | None,
):
    """Run scenarios locally in Docker containers.

    Examples:
      veris run local                                     # run all scenarios in ./scenarios/
      veris run local checkout payment                    # run two specific scenarios in parallel
      veris run local --scenarios-dir ./tests/scenarios   # custom folder
      veris run local checkout --skip-build               # skip Docker build step
    """
    project_root = Path.cwd()
    veris_dir = project_root / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"
    scenarios_path = project_root / scenarios_dir

    # 1. Validate prerequisites
    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    # 2. Load .env file
    dotenv_path = project_root / ".env"
    env_vars = _load_dotenv(dotenv_path)

    # Merge into os.environ for subprocess
    for k, v in env_vars.items():
        os.environ.setdefault(k, v)

    # 3. Resolve scenario list
    scenario_list = _resolve_scenarios(scenarios_path, scenarios)

    output.print_info(f"Running {len(scenario_list)} scenario(s): {', '.join(scenario_list)}")

    # 4. Build image once (unless --skip-build)
    if not skip_build:
        output.print_info(f"\nBuilding Docker image: {image}")
        build_cmd = [
            "docker",
            "buildx",
            "build",
            "--platform",
            platform,
            "--load",
            "-f",
            str(dockerfile),
            "-t",
            image,
            str(project_root),
        ]

        result = subprocess.run(build_cmd)
        if result.returncode != 0:
            output.print_error("Docker build failed")
            sys.exit(result.returncode)

        output.print_success("Docker image built successfully\n")
    else:
        output.print_info("Skipping Docker build\n")

    # 5. Launch containers in parallel
    logs_base = veris_dir / "logs"
    logs_base.mkdir(parents=True, exist_ok=True)

    runs = []  # List of (scenario, sim_id, process, logs_dir) tuples

    # Helper to launch a single container
    def launch_container(scenario_id: str):
        sim_id = secrets.token_hex(4)
        logs_dir = logs_base / sim_id
        logs_dir.mkdir(parents=True, exist_ok=True)

        container_name = f"veris-sim-{sim_id}"

        # Build docker run command
        docker_cmd = [
            "docker",
            "run",
            "--rm",
            "--name",
            container_name,
            "--platform",
            platform,
        ]

        # Pass all environment variables from .env file
        for key, value in env_vars.items():
            docker_cmd.extend(["-e", f"{key}={value}"])

        # Add SCENARIO_ID
        docker_cmd.extend(["-e", f"SCENARIO_ID={scenario_id}"])

        # Add volume mounts
        docker_cmd.extend(
            [
                "-v",
                f"{veris_yaml}:/config/veris.yaml:ro",
                "-v",
                f"{logs_dir}:/sessions",
            ]
        )

        # Mount scenarios directory if it exists
        if scenarios_path.exists():
            docker_cmd.extend(["-v", f"{scenarios_path}:/scenarios:ro"])

        docker_cmd.append(image)

        # Launch non-blocking
        process = subprocess.Popen(docker_cmd)

        return (scenario_id, sim_id, process, logs_dir)

    # Launch all containers (with concurrency limit if specified)
    if concurrency:
        # Launch in batches
        for i in range(0, len(scenario_list), concurrency):
            batch = scenario_list[i : i + concurrency]
            batch_runs = [launch_container(s) for s in batch]
            runs.extend(batch_runs)

            # Wait for this batch to complete before starting next
            for _, _, proc, _ in batch_runs:
                proc.wait()
    else:
        # Launch all at once
        runs = [launch_container(s) for s in scenario_list]

    output.print_info(f"Launched {len(runs)} container(s)\n")

    # 6. Wait for all to complete (if not already waited due to concurrency)
    if not concurrency:
        for scenario_id, sim_id, proc, _ in runs:
            output.print_info(f"Waiting for {scenario_id} (sim_id: {sim_id})...")
            proc.wait()

    # 7. Collect exit codes and print summary
    output.print_info("\n" + "=" * 60)
    output.print_success("All containers finished\n")

    # Print summary table
    print(f"{'Scenario':<30} {'Sim ID':<12} {'Exit Code':<12} {'Logs Path'}")
    print("-" * 100)

    for scenario_id, sim_id, proc, logs_dir in runs:
        exit_code = proc.returncode if proc.returncode is not None else proc.poll()
        logs_path = logs_dir.relative_to(project_root)
        print(f"{scenario_id:<30} {sim_id:<12} {exit_code:<12} {logs_path}")

    # 8. Dump logs
    output.print_info("\n" + "=" * 60)
    output.print_info("Logs:\n")

    for scenario_id, sim_id, _, logs_dir in runs:
        output.print_info(f"--- {scenario_id} (sim_id: {sim_id}) ---")

        # Find all .log files recursively
        log_files = sorted(logs_dir.glob("**/*.log"))

        if not log_files:
            output.print_info("  (no log files found)\n")
            continue

        for log_file in log_files:
            log_name = log_file.relative_to(logs_dir)
            output.print_info(f"\n  [{log_name}]")
            try:
                content = log_file.read_text()
                # Indent each line for better readability
                for line in content.splitlines():
                    print(f"    {line}")
            except Exception as e:
                output.print_error(f"    Failed to read log: {e}")

        print()


def main():
    """Main entry point"""
    cli()


if __name__ == "__main__":
    main()
