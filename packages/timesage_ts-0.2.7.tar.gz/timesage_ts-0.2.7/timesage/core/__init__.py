from timesage.core.timeseries import TimeSeries
from timesage.core.result import ForecastResult
