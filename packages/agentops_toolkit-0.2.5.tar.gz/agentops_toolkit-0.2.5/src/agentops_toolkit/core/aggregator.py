"""Aggregation and report building.

SPEC-003 §3 Phase 4: Aggregator computes per-evaluator and overall statistics.
"""
