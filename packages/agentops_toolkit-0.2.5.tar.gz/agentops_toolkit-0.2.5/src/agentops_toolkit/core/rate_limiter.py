"""Rate limiter — token-bucket for Foundry API calls.

SPEC-003 §4: FoundryRateLimiter with configurable rate and burst.
"""
