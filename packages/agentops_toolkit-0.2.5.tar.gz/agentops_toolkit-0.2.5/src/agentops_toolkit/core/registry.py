"""Evaluator registry — resolves evaluator references to implementations.

SPEC-003 §3: EvaluatorRegistry, BaseEvaluator, FoundryEvaluatorWrapper, CustomEvaluator.
"""
