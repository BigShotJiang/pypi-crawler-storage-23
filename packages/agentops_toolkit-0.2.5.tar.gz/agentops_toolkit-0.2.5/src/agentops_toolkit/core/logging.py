"""Structured logging setup for AgentOps.

SPEC-006 §9, NFR-062: Configurable level, optional file output, text/JSON format.
Uses stdlib logging + rich.logging.RichHandler for development.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any


class JSONFormatter(logging.Formatter):
    """JSON log formatter for machine-readable output (CI/CD, production)."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, Any] = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)


def setup_logging(
    level: str = "info",
    log_format: str = "text",
    log_file: str | None = None,
) -> None:
    """Configure logging for the AgentOps toolkit.

    Args:
        level: Log level — "debug", "info", "warning", "error".
        log_format: Output format — "text" (rich) or "json".
        log_file: Optional file path for log output.
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    root_logger = logging.getLogger("agentops_toolkit")
    root_logger.setLevel(log_level)

    # Remove existing handlers
    root_logger.handlers.clear()

    if log_format == "json":
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(JSONFormatter())
    else:
        try:
            from rich.logging import RichHandler

            handler = RichHandler(
                level=log_level,
                show_path=False,
                show_time=True,
                markup=True,
                rich_tracebacks=True,
            )
        except ImportError:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(
                logging.Formatter("%(asctime)s %(levelname)-8s %(name)s — %(message)s")
            )

    root_logger.addHandler(handler)

    # Optional file handler
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(
            JSONFormatter()
            if log_format == "json"
            else logging.Formatter("%(asctime)s %(levelname)-8s %(name)s — %(message)s")
        )
        root_logger.addHandler(file_handler)
