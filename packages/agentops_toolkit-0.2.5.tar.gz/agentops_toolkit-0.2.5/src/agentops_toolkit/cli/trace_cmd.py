"""agentops trace init|instrument|run|list — Tracing commands.

SPEC-007 §3.8, FR-104–FR-109.
"""

from __future__ import annotations

import typer
from rich.console import Console

console = Console()
trace_app = typer.Typer(name="trace", help="Configure and manage OpenTelemetry tracing.")


@trace_app.command("init")
def trace_init(
    project_endpoint: str | None = typer.Option(
        None,
        "--project-endpoint",
        "-p",
        help="Foundry project endpoint",
        envvar="FOUNDRY_PROJECT_ENDPOINT",
    ),
    local: bool = typer.Option(False, "--local", help="Use local tracing (console/OTLP)"),
    otlp: str | None = typer.Option(
        None, "--otlp", help="OTLP endpoint (e.g. http://localhost:4317)"
    ),
    service_name: str = typer.Option("agentops", "--service-name", "-s", help="OTEL_SERVICE_NAME"),
    capture_content: bool = typer.Option(
        False,
        "--capture-content",
        help="Record message content (PII risk)",
    ),
) -> None:
    """Configure OpenTelemetry tracing (SPEC-007 §3.3, FR-104)."""
    from agentops_toolkit.obs.tracing import TracingConfig, TracingManager

    if not local and not project_endpoint:
        console.print(
            "[red]✗[/red] --project-endpoint is required"
            " for cloud tracing. Use --local for local mode."
        )
        raise typer.Exit(code=1)

    config = TracingConfig(
        project_endpoint=project_endpoint or "",
        capture_content=capture_content,
        service_name=service_name,
        local_mode=local,
        otlp_endpoint=otlp,
    )

    try:
        manager = TracingManager(config)
        manager.initialize()
    except ImportError as e:
        console.print(f"[red]✗[/red] {e}")
        console.print("[dim]Install: pip install agentops-toolkit[observability][/dim]")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]✗[/red] Tracing initialization failed: {e}")
        raise typer.Exit(code=1) from e

    if local:
        target = f"OTLP → {otlp}" if otlp else "console"
        console.print("[green]✓[/green] Local tracing configured")
        console.print(f"  Exporter: {target}")
    else:
        console.print("[green]✓[/green] Tracing configured for Foundry")
        console.print("  Exporter: Application Insights (Foundry-linked)")

    console.print(f"  Service:  {service_name}")
    console.print()
    console.print("  Next: [bold]agentops trace run -- python src/agent.py[/bold]")


@trace_app.command("instrument")
def trace_instrument(
    framework: str = typer.Option(
        ...,
        "--framework",
        "-f",
        help="Framework to instrument: openai|semantic-kernel|langchain|openai-agents",
    ),
) -> None:
    """Auto-instrument a supported agent framework (SPEC-007 §3.5, FR-105)."""
    from agentops_toolkit.obs.tracing import TracingConfig, TracingManager

    manager = TracingManager(TracingConfig(local_mode=True))
    manager.initialize()

    try:
        manager.instrument_framework(framework)
        console.print(f"[green]✓[/green] Framework '{framework}' instrumented for tracing")
    except ValueError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e
