"""agentops run start|list|show|compare — Agent execution and run management.

SPEC-002 §3.8–3.10, FR-030–FR-039.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from agentops_toolkit.models.run import Run

console = Console()
run_app = typer.Typer(name="run", help="Execute agents and manage runs.")


def _load_all_runs(output_dir: str = "agentops/runs") -> list[Run]:
    """Load all runs from disk."""
    runs_dir = Path(output_dir)
    if not runs_dir.exists():
        return []

    runs: list[Run] = []
    for run_dir in sorted(runs_dir.iterdir(), reverse=True):
        run_json = run_dir / "run.json"
        if run_json.exists():
            try:
                data = json.loads(run_json.read_text(encoding="utf-8"))
                runs.append(Run.model_validate(data))
            except Exception:
                pass
    return runs


@run_app.command("list")
def run_list(
    limit: int = typer.Option(20, "--limit", "-n", help="Max runs to show"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
    output_dir: str = typer.Option("agentops/runs", "--output-dir", help="Runs directory"),
) -> None:
    """List all past runs (SPEC-002 §3.9, FR-036)."""
    runs = _load_all_runs(output_dir)[:limit]

    if not runs:
        console.print("[dim]No runs found. Run 'agentops eval run' first.[/dim]")
        return

    if format == "json":
        data = [
            {
                "id": r.id,
                "status": r.status.value,
                "dataset": r.dataset_name,
                "bundle": r.config.bundle,
                "entries": r.summary.total_entries if r.summary else 0,
                "score": r.summary.aggregate_score if r.summary else None,
                "date": str(r.created_at),
            }
            for r in runs
        ]
        console.print_json(json.dumps(data))
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Run ID", style="cyan")
    table.add_column("Status")
    table.add_column("Dataset")
    table.add_column("Bundle")
    table.add_column("Entries", justify="right")
    table.add_column("Score", justify="right")
    table.add_column("Date")

    for r in runs:
        status_icon = {
            "completed": "✓",
            "failed": "✗",
            "running": "○",
            "pending": "…",
            "cancelled": "✘",
        }.get(r.status.value, "?")
        entries = f"{r.summary.successful_entries}/{r.summary.total_entries}" if r.summary else "—"
        score = (
            f"{r.summary.aggregate_score:.2f}" if r.summary and r.summary.aggregate_score else "—"
        )
        date = r.created_at.strftime("%Y-%m-%d") if r.created_at else "—"

        table.add_row(
            r.id,
            f"{status_icon} {r.status.value}",
            r.dataset_name,
            r.config.bundle,
            entries,
            score,
            date,
        )

    console.print(table)


@run_app.command("show")
def run_show(
    run_id: str = typer.Argument(..., help="Run ID"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
    output_dir: str = typer.Option("agentops/runs", "--output-dir", help="Runs directory"),
) -> None:
    """Show detailed run metadata (SPEC-002 §3.9, FR-037)."""
    run_dir = Path(output_dir) / run_id
    run_json = run_dir / "run.json"

    if not run_json.exists():
        console.print(f"[red]✗[/red] Run not found: {run_id}")
        raise typer.Exit(code=1)

    run = Run.model_validate(json.loads(run_json.read_text(encoding="utf-8")))

    if format == "json":
        console.print_json(run.model_dump_json(indent=2))
        return

    console.print()
    console.print(f"[bold]Run:[/bold] {run.id}")
    console.print(f"[bold]Status:[/bold] {run.status.value}")
    console.print(f"[bold]Dataset:[/bold] {run.dataset_name}")
    console.print(f"[bold]Bundle:[/bold] {run.config.bundle}")
    console.print(f"[bold]Created:[/bold] {run.created_at}")
    if run.completed_at:
        console.print(f"[bold]Completed:[/bold] {run.completed_at}")

    if run.summary:
        s = run.summary
        console.print("\n[bold]Summary:[/bold]")
        console.print(
            f"  Entries: {s.successful_entries} success,"
            f" {s.failed_entries} failed,"
            f" {s.skipped_entries} skipped"
        )
        if s.aggregate_score:
            console.print(f"  Aggregate score: {s.aggregate_score:.2f}")
        if s.pass_rate is not None:
            console.print(f"  Pass rate: {s.pass_rate:.0%}")
        console.print(f"  Duration: {s.total_duration_ms:.0f}ms")

    # Entry status breakdown
    if run.entries:
        from collections import Counter

        status_counts = Counter(e.status.value for e in run.entries)
        console.print("\n[bold]Entry Status:[/bold]")
        for status, count in status_counts.most_common():
            console.print(f"  {status}: {count}")

    console.print()
