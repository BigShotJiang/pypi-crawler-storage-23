"""agentops report show|export — Evaluation reporting.

SPEC-002 §3.12–3.13, FR-050–FR-054.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from agentops_toolkit.models.run import Run

console = Console()
report_app = typer.Typer(name="report", help="View and export evaluation reports.")


def _find_run(run_id: str, output_dir: str = "agentops/runs") -> Run:
    """Load a Run from disk by ID or 'latest'."""
    runs_dir = Path(output_dir)
    if not runs_dir.exists():
        raise FileNotFoundError(f"Runs directory not found: {runs_dir}")

    if run_id == "latest":
        # Sort by modification time (most recent first) to handle
        # same-date runs whose hex UUID suffixes don't sort chronologically
        run_dirs = sorted(
            (d for d in runs_dir.iterdir() if d.is_dir()),
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
        if not run_dirs:
            raise FileNotFoundError("No runs found.")
        run_dir = run_dirs[0]
    else:
        run_dir = runs_dir / run_id
        if not run_dir.exists():
            raise FileNotFoundError(f"Run not found: {run_id}")

    run_json = run_dir / "run.json"
    if not run_json.exists():
        raise FileNotFoundError(f"run.json not found in {run_dir}")

    data = json.loads(run_json.read_text(encoding="utf-8"))
    return Run.model_validate(data)


@report_app.command("show")
def report_show(
    run_id: str = typer.Argument("latest", help="Run ID or 'latest'"),
    format: str = typer.Option(
        "table",
        "--format",
        "-f",
        help="Output format: table|json|markdown",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Include per-entry details"),
    evaluator: str | None = typer.Option(None, "--evaluator", help="Filter to specific evaluator"),
    output_dir: str = typer.Option("agentops/runs", "--output-dir", help="Runs directory"),
) -> None:
    """Display an evaluation report (SPEC-002 §3.12, FR-050)."""
    try:
        run = _find_run(run_id, output_dir)
    except FileNotFoundError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e

    summary = run.summary
    if summary is None:
        console.print("[red]✗[/red] Run has no summary (incomplete?).")
        raise typer.Exit(code=1)

    if format == "json":
        console.print_json(run.model_dump_json(indent=2))
        return

    if format == "markdown":
        _print_markdown(run)
        return

    # Rich table output
    console.print()
    console.print(
        Panel(
            f"[bold]AgentOps Evaluation Report[/bold]\n"
            f"Run: {run.id}\n"
            f"Date: {run.created_at}\n"
            f"Dataset: {run.dataset_name} ({summary.total_entries} entries)\n"
            f"Bundle: {run.config.bundle}",
            border_style="blue",
        )
    )

    # Scores table
    scores = summary.evaluator_scores
    if evaluator:
        scores = {k: v for k, v in scores.items() if k == evaluator}

    if scores:
        table = Table(show_header=True, header_style="bold")
        table.add_column("Evaluator", style="cyan")
        table.add_column("Mean", justify="right")
        table.add_column("Median", justify="right")
        table.add_column("Min", justify="right")
        table.add_column("Max", justify="right")
        table.add_column("StdDev", justify="right")
        table.add_column("Pass Rate", justify="right")

        for name, es in sorted(scores.items()):
            pr = f"{es.pass_rate:.0%}" if es.pass_rate is not None else "—"
            table.add_row(
                name,
                f"{es.mean_score:.2f}",
                f"{es.median_score:.1f}",
                f"{es.min_score:.1f}",
                f"{es.max_score:.1f}",
                f"{es.std_dev:.2f}",
                pr,
            )
        console.print()
        console.print(table)

    # Summary
    console.print()
    agg = f"{summary.aggregate_score:.2f}" if summary.aggregate_score else "—"
    pr = f"{summary.pass_rate:.0%}" if summary.pass_rate is not None else "—"
    console.print(f"  Aggregate: [bold]{agg}[/bold]   Pass rate: [bold]{pr}[/bold]")
    console.print(
        f"  Entries: {summary.successful_entries} success, "
        f"{summary.failed_entries} failed, {summary.skipped_entries} skipped"
    )
    console.print(f"  Duration: {summary.total_duration_ms:.0f}ms")

    # Below-threshold entries
    below = [
        (entry, er) for entry in run.entries for er in entry.eval_results if er.passed is False
    ]
    if evaluator:
        below = [(e, er) for e, er in below if er.evaluator_name == evaluator]
    if below:
        console.print(f"\n  [yellow]⚠ {len(below)} score(s) below threshold:[/yellow]")
        for entry, er in below[:10]:
            console.print(f"    Entry {entry.dataset_entry_id}: {er.evaluator_name}={er.score}")
        if len(below) > 10:
            console.print(f"    ... and {len(below) - 10} more")

    # Verbose: per-entry details
    if verbose:
        console.print("\n[bold]Per-Entry Details:[/bold]")
        for entry in run.entries:
            results = entry.eval_results
            if evaluator:
                results = [er for er in results if er.evaluator_name == evaluator]
            scores_str = ", ".join(
                f"{er.evaluator_name}={er.score}" for er in results if er.score is not None
            )
            console.print(f"  [{entry.status.value}] {entry.dataset_entry_id}: {scores_str}")

    console.print()


def _print_markdown(run: Run) -> None:
    """Render report as markdown (for PR comments / GITHUB_STEP_SUMMARY)."""
    summary = run.summary
    assert summary is not None

    lines = [
        "## AgentOps Evaluation Report",
        "",
        f"- **Run:** {run.id}",
        f"- **Date:** {run.created_at}",
        f"- **Dataset:** {run.dataset_name} ({summary.total_entries} entries)",
        f"- **Bundle:** {run.config.bundle}",
        "",
        "| Evaluator | Mean | Median | Min | Max | Pass Rate |",
        "|-----------|------|--------|-----|-----|-----------|",
    ]
    for name, es in sorted(summary.evaluator_scores.items()):
        pr = f"{es.pass_rate:.0%}" if es.pass_rate is not None else "—"
        lines.append(
            f"| {name} | {es.mean_score:.2f} | {es.median_score:.1f} | "
            f"{es.min_score:.1f} | {es.max_score:.1f} | {pr} |"
        )

    agg = f"{summary.aggregate_score:.2f}" if summary.aggregate_score else "—"
    pr = f"{summary.pass_rate:.0%}" if summary.pass_rate is not None else "—"
    lines.extend([
        "",
        f"**Aggregate:** {agg} | **Pass rate:** {pr}",
        "",
        "*Generated by agentops-toolkit*",
    ])
    console.print("\n".join(lines))


@report_app.command("export")
def report_export(
    run_id: str = typer.Argument("latest", help="Run ID or 'latest'"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    format: str = typer.Option(
        "markdown",
        "--format",
        "-f",
        help="Export format: json|markdown|html|csv",
    ),
    output_dir: str = typer.Option("agentops/runs", "--output-dir", help="Runs directory"),
) -> None:
    """Export a report to a file (SPEC-002 §3.13, FR-051)."""
    try:
        run = _find_run(run_id, output_dir)
    except FileNotFoundError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e

    if run.summary is None:
        console.print("[red]✗[/red] Run has no summary.")
        raise typer.Exit(code=1)

    # Determine output path
    ext = {"json": "json", "markdown": "md", "html": "html", "csv": "csv"}.get(format, "md")
    out_path = Path(output) if output else Path(f"agentops/reports/{run.id}.{ext}")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if format == "json":
        out_path.write_text(run.model_dump_json(indent=2), encoding="utf-8")
    elif format == "markdown":
        from io import StringIO

        buf = StringIO()
        _old_console = Console(file=buf)
        # Generate markdown
        summary = run.summary
        lines = [
            "## AgentOps Evaluation Report\n",
            f"- **Run:** {run.id}",
            f"- **Dataset:** {run.dataset_name} ({summary.total_entries} entries)",
            f"- **Bundle:** {run.config.bundle}\n",
            "| Evaluator | Mean | Median | Min | Max | Pass Rate |",
            "|-----------|------|--------|-----|-----|-----------|",
        ]
        for name, es in sorted(summary.evaluator_scores.items()):
            pr = f"{es.pass_rate:.0%}" if es.pass_rate is not None else "—"
            lines.append(
                f"| {name} | {es.mean_score:.2f} | {es.median_score:.1f} | "
                f"{es.min_score:.1f} | {es.max_score:.1f} | {pr} |"
            )
        agg = f"{summary.aggregate_score:.2f}" if summary.aggregate_score else "—"
        pr = f"{summary.pass_rate:.0%}" if summary.pass_rate is not None else "—"
        lines.append(f"\n**Aggregate:** {agg} | **Pass rate:** {pr}")
        out_path.write_text("\n".join(lines), encoding="utf-8")
    elif format == "csv":
        import csv

        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["entry_id", "status", "evaluator", "score", "passed"])
            for entry in run.entries:
                for er in entry.eval_results:
                    writer.writerow([
                        entry.dataset_entry_id,
                        entry.status.value,
                        er.evaluator_name,
                        er.score,
                        er.passed,
                    ])
    else:
        console.print(f"[red]✗[/red] Unsupported format: {format}")
        raise typer.Exit(code=1)

    console.print(f"[green]✓[/green] Report exported to {out_path}")
