"""Main Typer application — registers all command groups.

SPEC-002 §2: Command tree root.
"""

import typer

from agentops_toolkit import __version__

app = typer.Typer(
    name="agentops",
    help="AgentOps Toolkit — Evaluate, trace, and monitor AI agents.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"agentops-toolkit {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """AgentOps Toolkit — Evaluate, trace, and monitor AI agents on Azure AI Foundry."""


# ── Register command groups ──

from agentops_toolkit.cli.bundle_cmd import bundle_app  # noqa: E402
from agentops_toolkit.cli.config_cmd import config_app  # noqa: E402
from agentops_toolkit.cli.dataset_cmd import dataset_app  # noqa: E402
from agentops_toolkit.cli.eval_cmd import eval_app  # noqa: E402
from agentops_toolkit.cli.init_cmd import init_app  # noqa: E402
from agentops_toolkit.cli.model_cmd import model_app  # noqa: E402
from agentops_toolkit.cli.monitor_cmd import monitor_app  # noqa: E402
from agentops_toolkit.cli.report_cmd import report_app  # noqa: E402
from agentops_toolkit.cli.run_cmd import run_app  # noqa: E402
from agentops_toolkit.cli.trace_cmd import trace_app  # noqa: E402

app.add_typer(init_app, name="init", help="Initialize AgentOps in a project.")
app.add_typer(bundle_app, name="bundle", help="Manage evaluator bundles.")
app.add_typer(eval_app, name="eval", help="Run evaluations on agent outputs.")
app.add_typer(dataset_app, name="dataset", help="Manage evaluation datasets.")
app.add_typer(report_app, name="report", help="View and export evaluation reports.")
app.add_typer(run_app, name="run", help="Execute agents and manage runs.")
app.add_typer(config_app, name="config", help="Configuration management.")
app.add_typer(trace_app, name="trace", help="Configure OpenTelemetry tracing.")
app.add_typer(monitor_app, name="monitor", help="Monitor agents in production.")
app.add_typer(model_app, name="model", help="Model lifecycle via Foundry MCP Server.")


def cli() -> None:
    """Entry point for the `agentops` CLI."""
    app()
