"""agentops dataset list|validate|import|describe — Dataset management.

SPEC-002 §3.5–3.7, FR-020–FR-025.
"""

from __future__ import annotations

import json
import shutil
import statistics
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from agentops_toolkit.core.bundle_registry import BundleRegistry
from agentops_toolkit.core.config_loader import ConfigError, load_config
from agentops_toolkit.core.pipeline import load_dataset

console = Console()
dataset_app = typer.Typer(name="dataset", help="Manage evaluation datasets.")


def _resolve_datasets(config_path: str | None) -> list[dict]:
    """Get dataset list from config."""
    try:
        cfg = load_config(config_path)
        return [
            {"name": ds.name, "path": ds.path, "format": ds.format, "description": ds.description}
            for ds in cfg.datasets.entries
        ]
    except ConfigError:
        return []


@dataset_app.command("list")
def dataset_list(
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
) -> None:
    """List registered datasets (SPEC-002 §3.5, FR-025)."""
    datasets = _resolve_datasets(config)

    if not datasets:
        console.print("[dim]No datasets registered. Run 'agentops init' first.[/dim]")
        return

    if format == "json":
        console.print_json(json.dumps(datasets))
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Dataset", style="cyan")
    table.add_column("Format")
    table.add_column("Entries", justify="right")
    table.add_column("Has Context")
    table.add_column("Has Ground Truth")
    table.add_column("Path")

    for ds in datasets:
        path = Path(ds["path"])
        entry_count = "—"
        has_context = "—"
        has_ground_truth = "—"

        if path.exists():
            try:
                entries = load_dataset(path)
                entry_count = str(len(entries))
                has_context = "✓" if any(e.context for e in entries) else "✗"
                has_ground_truth = "✓" if any(e.ground_truth for e in entries) else "✗"
            except Exception:
                entry_count = "ERR"

        table.add_row(
            ds["name"],
            ds["format"],
            entry_count,
            has_context,
            has_ground_truth,
            ds["path"],
        )

    console.print(table)


@dataset_app.command("validate")
def dataset_validate(
    name: str = typer.Argument(..., help="Dataset name or file path"),
    bundle: str | None = typer.Option(
        None,
        "--bundle",
        "-b",
        help="Validate against bundle evaluator requirements",
    ),
    strict: bool = typer.Option(False, "--strict", help="Fail on warnings"),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Validate a dataset file (SPEC-002 §3.6, FR-022)."""
    # Resolve path: try as file path first, then look up in config, then search datasets dir
    path = Path(name)
    if not path.exists():
        datasets = _resolve_datasets(config)
        match = [d for d in datasets if d["name"] == name]
        if match:
            path = Path(match[0]["path"])
        else:
            # Fallback: check agentops/datasets/{name}.jsonl
            candidate = Path("agentops") / "datasets" / f"{name}.jsonl"
            if candidate.exists():
                path = candidate
            else:
                console.print(f"[red]✗[/red] Dataset not found: {name}")
                raise typer.Exit(code=1)

    if not path.exists():
        console.print(f"[red]✗[/red] Dataset file not found: {path}")
        raise typer.Exit(code=1)

    # Load and validate
    errors: list[str] = []
    warnings: list[str] = []

    try:
        entries = load_dataset(path)
    except ValueError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to parse dataset: {e}")
        raise typer.Exit(code=1) from e

    if not entries:
        errors.append("Dataset is empty")

    # Check each entry
    for i, entry in enumerate(entries, 1):
        if not entry.query or not entry.query.strip():
            errors.append(f"Entry #{i} (id={entry.id}): 'query' is empty")

    # Check columns
    has_context = any(e.context for e in entries)
    has_response = any(e.response for e in entries)
    has_ground_truth = any(e.ground_truth for e in entries)

    # Bundle column requirements
    if bundle:
        try:
            registry = BundleRegistry()
            b = registry.get(bundle)
            required_cols: set[str] = set()
            for ev in b.evaluators:
                from agentops_toolkit.evaluators.base import FoundryEvaluatorWrapper

                wrapper = FoundryEvaluatorWrapper(ev.name)
                required_cols.update(wrapper.required_columns)

            if "context" in required_cols and not has_context:
                warnings.append(
                    f"'context' is needed by bundle '{bundle}' but missing from entries"
                )
            if "response" in required_cols and not has_response:
                warnings.append(
                    f"'response' is needed by bundle '{bundle}' but missing from entries"
                )
            if "ground_truth" in required_cols and not has_ground_truth:
                warnings.append(
                    "'ground_truth' is needed by evaluator 'similarity' but missing from entries"
                )
        except KeyError:
            warnings.append(f"Bundle '{bundle}' not found — skipping column check")

    # Report
    if errors:
        console.print(f"[red]✗[/red] Dataset '{name}' has {len(errors)} error(s)")
        for err in errors:
            console.print(f"  [red]ERROR[/red]  {err}")
        for w in warnings:
            console.print(f"  [yellow]WARN[/yellow]   {w}")
        raise typer.Exit(code=1)

    if warnings and strict:
        console.print(
            f"[yellow]⚠[/yellow] Dataset '{name}' has {len(warnings)} warning(s) (strict mode)"
        )
        for w in warnings:
            console.print(f"  [yellow]WARN[/yellow]   {w}")
        raise typer.Exit(code=1)

    # Success
    console.print(f"[green]✓[/green] Dataset '{name}' is valid")
    console.print(f"  {len(entries)} entries parsed")
    cols = ["query ✓"]
    if has_response:
        cols.append("response ✓")
    if has_context:
        cols.append("context ✓")
    if has_ground_truth:
        cols.append("ground_truth ✓")
    console.print(f"  Columns: {', '.join(cols)}")
    if warnings:
        console.print(f"  Warnings: {len(warnings)}")
        for w in warnings:
            console.print(f"    [yellow]WARN[/yellow] {w}")
    else:
        console.print("  Warnings: 0")


@dataset_app.command("import")
def dataset_import(
    path: str = typer.Argument(..., help="Path to the file to import"),
    name: str | None = typer.Option(
        None,
        "--name",
        "-n",
        help="Dataset name (defaults to filename)",
    ),
    format: str | None = typer.Option(None, "--format", help="File format: jsonl|csv|json"),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Import an external dataset file (SPEC-002 §3.7, FR-023)."""
    src_path = Path(path)
    if not src_path.exists():
        console.print(f"[red]✗[/red] File not found: {path}")
        raise typer.Exit(code=1)

    # Derive name and format
    ds_name = name or src_path.stem
    ds_format = format or src_path.suffix.lstrip(".")
    if ds_format not in ("jsonl", "csv", "json"):
        console.print(f"[red]✗[/red] Unsupported format: {ds_format}. Use jsonl, csv, or json.")
        raise typer.Exit(code=1)

    # Copy to datasets directory
    datasets_dir = Path("agentops/datasets")
    datasets_dir.mkdir(parents=True, exist_ok=True)
    dest = datasets_dir / src_path.name
    shutil.copy2(src_path, dest)

    # Validate the imported file
    try:
        entries = load_dataset(dest)
        console.print(f"[green]✓[/green] Dataset '{ds_name}' imported ({len(entries)} entries)")
        console.print(f"  Copied to: {dest}")
        console.print("  [dim]Add to agentops.yaml datasets section to register it.[/dim]")
    except Exception as e:
        console.print(f"[yellow]⚠[/yellow] File copied but validation failed: {e}")
        console.print(f"  Copied to: {dest}")


@dataset_app.command("describe")
def dataset_describe(
    name: str = typer.Argument(..., help="Dataset name or file path"),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
) -> None:
    """Show dataset statistics (SPEC-002 §3.8, FR-024)."""
    # Resolve path
    path = Path(name)
    if not path.exists():
        datasets = _resolve_datasets(config)
        match = [d for d in datasets if d["name"] == name]
        if match:
            path = Path(match[0]["path"])
        else:
            # Fallback: check agentops/datasets/{name}.jsonl
            candidate = Path("agentops") / "datasets" / f"{name}.jsonl"
            if candidate.exists():
                path = candidate

    if not path.exists():
        console.print(f"[red]✗[/red] Dataset not found: {name}")
        raise typer.Exit(code=1)

    entries = load_dataset(path)
    if not entries:
        console.print(f"[dim]Dataset '{name}' is empty.[/dim]")
        return

    # Compute stats
    has_context = sum(1 for e in entries if e.context)
    has_response = sum(1 for e in entries if e.response)
    has_ground_truth = sum(1 for e in entries if e.ground_truth)
    has_tool_calls = sum(1 for e in entries if e.tool_calls)
    has_turns = sum(1 for e in entries if e.conversation_turns)

    query_lens = [len(e.query) for e in entries]
    context_lens = [
        len(e.context) if isinstance(e.context, str) else sum(len(c) for c in e.context)
        for e in entries
        if e.context
    ]

    stats = {
        "name": name,
        "path": str(path),
        "entries": len(entries),
        "fields": {
            "query": len(entries),
            "context": has_context,
            "response": has_response,
            "ground_truth": has_ground_truth,
            "tool_calls": has_tool_calls,
            "conversation_turns": has_turns,
        },
        "query_length": {
            "min": min(query_lens),
            "max": max(query_lens),
            "mean": round(statistics.mean(query_lens), 1),
        },
    }
    if context_lens:
        stats["context_length"] = {
            "min": min(context_lens),
            "max": max(context_lens),
            "mean": round(statistics.mean(context_lens), 1),
        }

    if format == "json":
        console.print_json(json.dumps(stats))
        return

    console.print()
    console.print(f"[bold]Dataset:[/bold] {name}")
    console.print(f"[bold]Path:[/bold] {path}")
    console.print(f"[bold]Entries:[/bold] {len(entries)}")
    console.print()

    # Field coverage table
    table = Table(show_header=True, header_style="bold", title="Field Coverage")
    table.add_column("Field")
    table.add_column("Present", justify="right")
    table.add_column("Coverage", justify="right")

    for field, count in stats["fields"].items():
        pct = f"{count / len(entries):.0%}" if entries else "—"
        table.add_row(field, str(count), pct)

    console.print(table)
    console.print()

    # Length stats
    console.print(
        f"  Query length: min={stats['query_length']['min']}, "
        f"max={stats['query_length']['max']}, "
        f"mean={stats['query_length']['mean']}"
    )
    if "context_length" in stats:
        cl = stats["context_length"]
        console.print(f"  Context length: min={cl['min']}, max={cl['max']}, mean={cl['mean']}")
    console.print()
