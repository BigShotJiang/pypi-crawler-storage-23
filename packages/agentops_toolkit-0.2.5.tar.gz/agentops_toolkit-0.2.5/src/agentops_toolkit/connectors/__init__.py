"""IQ data connectors — pull evaluation data from IQ knowledge layers.

SPEC-008 §7: FoundryIQConnector, WorkIQConnector, FabricIQConnector.
"""
