"""AgentOps Toolkit — Evaluate, trace, and monitor AI agents."""

__version__ = "0.2.5"
