"""Generic adapter — works with any framework via callable or HTTP endpoint.

SPEC-004 §4.4, FR-084: GenericAdapter with @agentops.trace support.
"""

from __future__ import annotations

import logging
from typing import Any

from agentops_toolkit.adapters.registry import (
    AdapterCapabilities,
    AdapterRegistry,
    AgentDiscovery,
    AgentOutput,
    DiscoveredAgent,
)

logger = logging.getLogger(__name__)


class GenericAdapter:
    """Generic adapter for any framework (SPEC-004 §4.4).

    Supports two modes:
    - Python callable: auto-detected function signature
    - HTTP endpoint: POST with JSON request/response
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config

    @property
    def name(self) -> str:
        return "custom"

    @property
    def framework_version(self) -> str:
        return "n/a"

    async def setup(self, config: dict[str, Any]) -> None:
        entry_point = config.get("entry_point", "")
        logger.info("Generic adapter setup: entry=%s", entry_point)

    async def teardown(self) -> None:
        pass

    async def invoke(self, query: str, context: str | None = None) -> AgentOutput:
        entry_point = self._config.get("entry_point", "")

        if entry_point.startswith("http://") or entry_point.startswith("https://"):
            return await self._invoke_http(query, context, entry_point)
        else:
            return await self._invoke_callable(query, context, entry_point)

    async def _invoke_http(self, query: str, context: str | None, url: str) -> AgentOutput:
        """Invoke agent via HTTP POST."""
        import httpx

        payload: dict[str, Any] = {"query": query}
        if context:
            payload["context"] = context

        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()

        return AgentOutput(
            response=data.get("response", str(data)),
            metadata={"source": "http", "url": url},
        )

    async def _invoke_callable(
        self, query: str, context: str | None, entry_point: str
    ) -> AgentOutput:
        """Invoke agent via Python callable."""
        import importlib

        if ":" in entry_point:
            module_path, func_name = entry_point.rsplit(":", 1)
        else:
            module_path = entry_point.replace(".py", "").replace("/", ".").replace("\\", ".")
            func_name = "agent_fn"

        try:
            module = importlib.import_module(module_path)
            func = getattr(module, func_name)
            result = func(query, context) if context else func(query)

            if hasattr(result, "__await__"):
                result = await result

            return AgentOutput(
                response=str(result),
                metadata={"source": "callable", "entry_point": entry_point},
            )
        except Exception as e:
            return AgentOutput(
                response="",
                metadata={"error": str(e)},
            )

    async def discover(self, config: dict[str, Any]) -> AgentDiscovery:
        return AgentDiscovery(
            framework="custom",
            agents=[
                DiscoveredAgent(
                    name="agent",
                    entry_point=config.get("entry_point", ""),
                )
            ],
        )

    def get_capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities()

    def supports_streaming(self) -> bool:
        return False


AdapterRegistry.register("custom", GenericAdapter)
