"""Base evaluator interfaces.

SPEC-003 §3: BaseEvaluator(ABC), FoundryEvaluatorWrapper, CustomEvaluator.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from agentops_toolkit.models.run import EvalResult


class BaseEvaluator(ABC):
    """Interface all evaluators must implement (SPEC-003 §3)."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Evaluator identifier."""
        ...

    @property
    @abstractmethod
    def required_columns(self) -> list[str]:
        """Input columns this evaluator requires."""
        ...

    @property
    def score_range(self) -> tuple[float, float]:
        """Min/max score range. Default: (1.0, 5.0) for Foundry evaluators."""
        return (1.0, 5.0)

    @abstractmethod
    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        """Score a single input. Returns an EvalResult."""
        ...


# Evaluators that use an LLM judge and require model_config
_LLM_JUDGE_EVALUATORS: set[str] = {
    "groundedness",
    "relevance",
    "coherence",
    "fluency",
    "similarity",
}

# Content-safety evaluators — require credential + azure_ai_project
_SAFETY_EVALUATORS: set[str] = {
    "hate_unfairness",
    "sexual",
    "violence",
    "self_harm",
    "protected_material",
}


class FoundryEvaluatorWrapper(BaseEvaluator):
    """Wraps an Azure AI Foundry evaluator SDK call (SPEC-003 §3).

    This class adapts Foundry SDK evaluators to the BaseEvaluator interface.
    """

    # Column requirements per evaluator
    _COLUMN_MAP: dict[str, list[str]] = {
        "groundedness": ["query", "response", "context"],
        "relevance": ["query", "response", "context"],
        "coherence": ["query", "response"],
        "fluency": ["response"],
        "similarity": ["response", "ground_truth"],
        "f1_score": ["response", "ground_truth"],
        "hate_unfairness": ["query", "response"],
        "sexual": ["query", "response"],
        "violence": ["query", "response"],
        "self_harm": ["query", "response"],
        "protected_material": ["query", "response"],
        "jailbreak": ["query"],
        "tool_call_accuracy": ["expected_tool_calls", "actual_tool_calls"],
        "task_completion": ["task_description", "agent_output"],
        "handoff_quality": ["conversation_turns", "handoff_points"],
    }

    def __init__(
        self,
        evaluator_name: str,
        threshold: float | None = None,
        column_mapping: dict[str, str] | None = None,
        model_config: dict[str, Any] | None = None,
        project_connection: str = "",
    ) -> None:
        self._name = evaluator_name
        self._threshold = threshold
        self._column_mapping = column_mapping or {}
        self._model_config = model_config
        self._project_connection = project_connection

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._COLUMN_MAP.get(self._name, ["query", "response"])

    def _map_columns(self, input_data: dict[str, Any]) -> dict[str, Any]:
        """Apply column mapping to input data."""
        if not self._column_mapping:
            return input_data
        mapped = dict(input_data)
        for evaluator_col, data_col in self._column_mapping.items():
            if data_col in mapped:
                mapped[evaluator_col] = mapped.pop(data_col)
        return mapped

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        """Call the Foundry evaluator and return an EvalResult.

        For Sprint 1, this calls the evaluator synchronously via the SDK.
        """
        from agentops_toolkit.core.foundry_sdk_client import _get_evaluator_class

        mapped = self._map_columns(input_data)

        try:
            cls = _get_evaluator_class(self._name)
            if self._name in _SAFETY_EVALUATORS and self._project_connection:
                from azure.identity import DefaultAzureCredential

                evaluator = cls(
                    credential=DefaultAzureCredential(),
                    azure_ai_project=self._project_connection,
                )
            elif self._model_config and self._name in _LLM_JUDGE_EVALUATORS:
                evaluator = cls(model_config=self._model_config)
            else:
                evaluator = cls()
            raw = evaluator(**mapped)
            raw_dict = dict(raw) if raw else {}

            # Extract score — Foundry evaluators return various key patterns
            score = self._extract_score(raw_dict)
            label = raw_dict.get("label")
            severity = raw_dict.get("severity")
            reasoning = raw_dict.get("reasoning") or raw_dict.get("reason")

            passed = None
            if self._threshold is not None and score is not None:
                # Safety evaluators: lower = safer (0-7), pass when BELOW threshold
                if self._name in _SAFETY_EVALUATORS:
                    passed = score < self._threshold
                else:
                    passed = score >= self._threshold

            return EvalResult(
                evaluator_name=self._name,
                score=score,
                label=str(label) if label else None,
                severity=str(severity) if severity else None,
                reasoning=str(reasoning) if reasoning else None,
                passed=passed,
                raw_output=raw_dict,
            )
        except Exception as e:
            return EvalResult(
                evaluator_name=self._name,
                score=None,
                passed=False,
                raw_output={"error": str(e), "error_type": type(e).__name__},
            )

    def _extract_score(self, raw: dict[str, Any]) -> float | None:
        """Extract numeric score from Foundry evaluator output."""
        # Try common key patterns
        for key in [
            f"gpt_{self._name}",
            f"{self._name}_score",
            self._name,
            "score",
        ]:
            if key in raw:
                val = raw[key]
                if isinstance(val, (int, float)):
                    return float(val)
        return None


class CustomEvaluator(BaseEvaluator):
    """User-defined evaluator — subclass this to add custom metrics (SPEC-003 §3).

    Example::

        class MyEvaluator(CustomEvaluator):
            name = "my_metric"
            required_columns = ["query", "response"]
            score_range = (0.0, 1.0)

            async def evaluate(self, input_data: dict) -> EvalResult:
                score = my_scoring_logic(input_data["response"])
                return EvalResult(evaluator_name=self.name, score=score)
    """

    pass
