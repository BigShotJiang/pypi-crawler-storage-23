"""MonitorManager — monitoring setup, dashboards, alerts.

SPEC-007 §4: Wire Agent Monitoring Dashboard, pre-built templates, alert rules.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class AlertRule(BaseModel):
    """Azure Monitor alert rule configuration (SPEC-007 §4.3)."""

    name: str
    metric: str
    operator: str  # "lt" | "gt" | "eq"
    threshold: float
    severity: int = Field(default=2, ge=0, le=4)
    evaluation_frequency: str = "PT5M"
    window_size: str = "PT15M"
    action_group: str | None = None


class MonitorManager:
    """Manages monitoring setup for AgentOps (SPEC-007 §4.3)."""

    TEMPLATES = {
        "agent-overview": {
            "name": "Agent Overview",
            "description": "Token usage, latency P50/P95/P99, error rates, throughput",
        },
        "eval-quality": {
            "name": "Evaluation Quality",
            "description": (
                "Continuous evaluation scores: relevance, fluency, coherence, groundedness"
            ),
        },
        "safety-monitor": {
            "name": "Safety Monitor",
            "description": "Safety evaluator scores, content violations, red teaming results",
        },
    }

    def __init__(self, service_name: str = "agentops") -> None:
        self._service_name = service_name

    def list_templates(self) -> list[dict[str, str]]:
        """Return available dashboard templates."""
        return [{"id": tid, **info} for tid, info in self.TEMPLATES.items()]

    def setup_dashboard(self, template_name: str) -> dict[str, Any]:
        """Generate dashboard configuration from a template."""
        if template_name not in self.TEMPLATES:
            available = ", ".join(self.TEMPLATES.keys())
            raise ValueError(f"Unknown template '{template_name}'. Available: {available}")
        logger.info(
            "Dashboard template '%s' configured for service '%s'",
            template_name,
            self._service_name,
        )
        return {
            "template": template_name,
            "service_name": self._service_name,
            **self.TEMPLATES[template_name],
        }

    def create_alert_rule(self, rule: AlertRule) -> dict[str, Any]:
        """Generate Azure Monitor alert rule ARM snippet."""
        logger.info(
            "Alert rule '%s' created: %s %s %s",
            rule.name,
            rule.metric,
            rule.operator,
            rule.threshold,
        )
        return {
            "type": "Microsoft.Insights/metricAlerts",
            "apiVersion": "2018-03-01",
            "name": rule.name,
            "properties": {
                "severity": rule.severity,
                "evaluationFrequency": rule.evaluation_frequency,
                "windowSize": rule.window_size,
                "criteria": {
                    "allOf": [
                        {
                            "metricName": rule.metric,
                            "operator": rule.operator.capitalize(),
                            "threshold": rule.threshold,
                            "timeAggregation": "Average",
                        }
                    ]
                },
            },
        }
