"""@agentops_trace decorator — custom span capture.

SPEC-007 §3.4, FR-111-OBS: Creates OpenTelemetry spans around any function.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any


def agentops_trace(
    name: str | None = None,
    attributes: dict[str, Any] | None = None,
) -> Callable:
    """Decorator to create a traced span around a function (SPEC-007 §3.4).

    Usage::

        @agentops_trace("process_claim", {"claim.type": "insurance"})
        def process_claim(claim_id: str):
            ...

        @agentops_trace()
        async def my_async_handler(request):
            ...
    """

    def decorator(func: Callable) -> Callable:
        import asyncio

        span_name = name or func.__qualname__

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                from opentelemetry import trace
                from opentelemetry.trace import SpanKind

                tracer = trace.get_tracer("agentops")
                with tracer.start_as_current_span(span_name, kind=SpanKind.INTERNAL) as span:
                    if attributes:
                        for k, v in attributes.items():
                            span.set_attribute(k, str(v))
                    return func(*args, **kwargs)
            except ImportError:
                # OTel not installed — run without tracing
                return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                from opentelemetry import trace
                from opentelemetry.trace import SpanKind

                tracer = trace.get_tracer("agentops")
                with tracer.start_as_current_span(span_name, kind=SpanKind.INTERNAL) as span:
                    if attributes:
                        for k, v in attributes.items():
                            span.set_attribute(k, str(v))
                    return await func(*args, **kwargs)
            except ImportError:
                return await func(*args, **kwargs)

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator
