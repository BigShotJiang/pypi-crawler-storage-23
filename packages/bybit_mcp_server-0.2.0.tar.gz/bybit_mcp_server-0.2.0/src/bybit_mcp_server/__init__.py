"""Bybit MCP Server - A Model Context Protocol server for Bybit V5 API."""

__version__ = "0.2.0"
