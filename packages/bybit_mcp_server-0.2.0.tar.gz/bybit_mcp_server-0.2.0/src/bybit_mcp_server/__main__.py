"""Entry point for uvx compatibility."""

from bybit_mcp_server.server import main

main()
