"""iflow2api - 将 iFlow CLI 的 AI 服务暴露为 OpenAI 兼容 API"""

__version__ = "1.6.10"
