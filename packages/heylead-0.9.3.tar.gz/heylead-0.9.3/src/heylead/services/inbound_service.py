"""Inbound lead qualification pipeline service.

Orchestrates the full inbound flow:
1. Load new signals from DB (status='new')
2. Qualify each against active ICPs via LLM
3. Generate discovery DMs for qualified leads
4. Send DMs (full autopilot)
5. Update signal status
"""

from __future__ import annotations

import logging
import time
from typing import Any

from ..ai.inbound_qualifier import (
    InboundQualification,
    generate_discovery_question,
    qualify_inbound,
)
from ..constants import (
    DAILY_INBOUND_DM_LIMIT,
    INBOUND_ASK_PURPOSE_CONFIDENCE,
    INBOUND_ENGAGE_CONFIDENCE,
)
from ..db.queries import (
    get_setting,
    list_icps,
    list_inbound_signals,
    list_published_posts,
    log_action,
    save_inbound_signal,
    update_inbound_signal,
)

logger = logging.getLogger(__name__)


async def process_inbound_signals() -> str:
    """Process all new inbound signals through the qualification pipeline.

    Loads unqualified signals, runs LLM qualification, updates DB.
    Returns a summary string.
    """
    new_signals = list_inbound_signals(status="new", limit=20)
    if not new_signals:
        return "No new inbound signals to qualify."

    active_icps = list_icps(status="active")

    qualified_count = 0
    results: list[dict[str, Any]] = []

    for signal in new_signals:
        profile = {
            "name": signal.get("sender_name", ""),
            "headline": signal.get("sender_headline", ""),
            "company": signal.get("sender_company", ""),
            "title": signal.get("sender_headline", ""),
        }
        content = signal.get("content", "")
        signal_type = signal.get("signal_type", "invitation")

        try:
            qual = await qualify_inbound(
                profile=profile,
                content=content,
                signal_type=signal_type,
                active_icps=active_icps,
            )

            update_inbound_signal(
                signal["id"],
                intent=qual.intent,
                matched_icp_id=qual.matched_icp_id,
                confidence=qual.confidence,
                recommended_action=qual.recommended_action,
                reasoning=qual.reasoning,
                status="qualified",
                qualified_at=int(time.time()),
            )
            qualified_count += 1
            results.append({
                "signal_id": signal["id"],
                "name": signal.get("sender_name", ""),
                "intent": qual.intent,
                "confidence": qual.confidence,
                "action": qual.recommended_action,
            })

        except Exception as e:
            logger.warning(
                "Failed to qualify signal %s (%s): %s",
                signal["id"], signal.get("sender_name"), e,
            )

    summary = f"Qualified {qualified_count}/{len(new_signals)} inbound signals."
    high_conf = [r for r in results if r["confidence"] >= INBOUND_ENGAGE_CONFIDENCE]
    if high_conf:
        summary += f" {len(high_conf)} high-confidence leads detected."

    return summary


async def send_discovery_dms() -> str:
    """Send discovery DMs to qualified inbound connections.

    Full autopilot — no copilot review. Sends to all qualified signals
    that haven't been engaged yet, except spam/job_seeking.

    Returns summary string.
    """
    from ..linkedin import UnipileError, get_account_id, get_linkedin_client

    # Get qualified signals that haven't been engaged yet
    qualified = list_inbound_signals(status="qualified", limit=DAILY_INBOUND_DM_LIMIT)
    if not qualified:
        return "No qualified signals pending engagement."

    account_id = get_account_id()
    if not account_id:
        return "No LinkedIn account connected."

    voice = get_setting("voice_signature", {})
    profile = get_setting("profile", {})

    try:
        client = get_linkedin_client()
    except UnipileError as e:
        return f"LinkedIn client error: {e}"

    sent = 0
    skipped = 0
    errors = 0

    for signal in qualified:
        intent = signal.get("intent", "unknown")
        confidence = signal.get("confidence", 0) or 0

        # Skip spam/recruiters — accept silently, no DM
        if intent in ("spam", "job_seeking"):
            update_inbound_signal(signal["id"], status="dismissed")
            skipped += 1
            continue

        # Generate discovery DM
        sender_profile = {
            "name": signal.get("sender_name", ""),
            "headline": signal.get("sender_headline", ""),
            "company": signal.get("sender_company", ""),
        }

        qual = InboundQualification(
            intent=intent,
            matched_icp_id=signal.get("matched_icp_id"),
            confidence=confidence,
            recommended_action=signal.get("recommended_action", "ask_purpose"),
            reasoning=signal.get("reasoning", ""),
        )

        try:
            dm_result = await generate_discovery_question(
                sender_profile=sender_profile,
                signal_type=signal.get("signal_type", "invitation"),
                content=signal.get("content", ""),
                voice=voice,
                qualification=qual,
            )
            dm_text = dm_result.get("message", "")
            if not dm_text:
                skipped += 1
                continue

            # Find the chat/conversation with this person and send the DM
            sender_id = signal.get("sender_id", "")
            if sender_id:
                try:
                    chat_id = await client.find_chat_for_user(account_id, sender_id)
                    if chat_id:
                        result = await client.send_message(
                            account_id=account_id,
                            chat_id=chat_id,
                            text=dm_text,
                        )
                        if result.get("success"):
                            update_inbound_signal(signal["id"], status="engaged")
                            log_action(
                                "inbound_discovery_dm_sent",
                                result="success",
                                details={
                                    "signal_id": signal["id"],
                                    "sender_name": signal.get("sender_name", ""),
                                    "intent": intent,
                                    "confidence": confidence,
                                    "dm_text": dm_text[:200],
                                },
                            )
                            sent += 1
                            continue
                    # No chat found — they may not have accepted yet
                    logger.debug(
                        "No chat found for %s — skipping DM (may not be connected yet)",
                        signal.get("sender_name"),
                    )
                    skipped += 1
                except Exception as e:
                    logger.warning("Failed to send discovery DM to %s: %s", signal.get("sender_name"), e)
                    errors += 1
            else:
                skipped += 1

        except Exception as e:
            logger.warning("Failed to generate discovery DM for %s: %s", signal.get("sender_name"), e)
            errors += 1

    await client.close()

    summary = f"Discovery DMs: {sent} sent"
    if skipped:
        summary += f", {skipped} skipped"
    if errors:
        summary += f", {errors} failed"
    return summary


async def check_post_comments() -> str:
    """Check comments on recently published posts and save new commenters as inbound signals.

    Returns summary string.
    """
    from ..constants import PUBLISHED_POST_MONITOR_DAYS
    from ..linkedin import UnipileError, get_account_id, get_linkedin_client

    posts = list_published_posts(days=PUBLISHED_POST_MONITOR_DAYS)
    if not posts:
        return "No recent posts to monitor for comments."

    account_id = get_account_id()
    if not account_id:
        return "No LinkedIn account connected."

    try:
        client = get_linkedin_client()
    except UnipileError as e:
        return f"LinkedIn client error: {e}"

    # Get our own profile to filter out our own comments
    our_profile = get_setting("profile", {})
    our_name = (our_profile.get("name") or "").lower()

    new_commenters = 0
    posts_checked = 0

    for post in posts:
        post_id = post.get("post_id", "")
        if not post_id:
            continue

        try:
            comments = await client.get_post_comments(account_id, post_id, limit=50)
            posts_checked += 1

            for comment in comments:
                author_name = comment.get("author_name", "")
                author_id = comment.get("author_id", "")
                comment_text = comment.get("text", "")

                # Skip our own comments
                if our_name and author_name.lower() == our_name:
                    continue

                # Dedup: check if this commenter already has a signal for this post
                if author_id:
                    from ..db.queries import get_inbound_signal_by_sender
                    existing = get_inbound_signal_by_sender(author_id, "comment")
                    if existing:
                        continue

                # Save as inbound signal
                save_inbound_signal(
                    signal_type="comment",
                    sender_name=author_name,
                    sender_id=author_id,
                    content=comment_text,
                    post_id=post_id,
                )
                new_commenters += 1

            # Update monitoring state
            from ..db.queries import update_published_post
            update_published_post(
                post_id=post_id,
                last_checked=int(time.time()),
                comment_count=len(comments),
            )

        except Exception as e:
            logger.warning("Failed to check comments for post %s: %s", post_id, e)

    await client.close()
    return f"Checked {posts_checked} posts, found {new_commenters} new commenters."
