# DC U2 Driver

**Credit:** Original development by **Dai Chao Online**

DC U2 Driver is a lightweight Python package for automating Android devices using **uiautomator2**.  
It’s designed for developers who want fast device interactions, robust element handling, and simple APIs without extra complexity.

## Features

- Connect to Android devices via device ID  
- Interact with UI elements using multiple locator types  
- Handle clicks, long clicks, and text input  
- Retrieve element attributes safely  
- Filter English text and skip unwanted UI elements  
- Retry clicks and wait for elements with customizable timing  
- Supports Python 3.10+  

## Installation

Install using pip:

```bash
pip install dc-u2-driver
```

### Example

```python
from dc_u2_driver import ElementDriver

driver = ElementDriver("device_id_here")
# use driver.work_on_element(...) etc.

```