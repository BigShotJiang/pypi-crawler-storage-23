"""
U2Automator - A helper class for interacting with Android devices via uiautomator2.

Features:
- Connects to a device by ID
- Filters English text from UI elements
- Interacts with elements using multiple locator types
- Handles clicks, long clicks, text input, and attribute retrieval
- Includes retries and post-wait timing for stability

Credit: Developed by Dai Chao Online
"""

import uiautomator2 as u2
import logging
from time import sleep
import random
from urllib3.exceptions import MaxRetryError, NewConnectionError, ProtocolError 

class DeviceConnectionError(Exception):
    pass

class U2Driver:
    def __init__(self, deviceID: str):
        self.driver = None
        if deviceID:
            try:
                self.driver = u2.connect(deviceID)
            except (MaxRetryError, NewConnectionError, ProtocolError, ConnectionResetError) as e:
                logging.error(f"Failed to connect to device {deviceID}: {e}")
                raise DeviceConnectionError(f"Cannot connect to device {deviceID}") from e

    def is_english(self, text):
        if not text:
            return False
        try:
            return all(ord(c) < 128 for c in text)
        except Exception:
            return False

    def _filter_names(self, texts):
        filtered = []
        for t in texts:
            if not t:
                continue

            low = t.lower()
            if "notification" in low or "accounts center" in low or "create facebook profile" in low:
                continue

            if not self.is_english(t):
                continue

            filtered.append(t)
        return filtered

    def work_on_element(self, wait, locatorValue, locatorType="xpath", isJustWait=False, textInput=None, index=None, isLongClick=False, get_attribute=False, attribute=None, get_all=False, status=False, element=None, filter_result=False, post_wait=0.3, click_retry=3):
        def _wait_for_clickable(el, timeout=2.0, interval=0.3):
            elapsed = 0
            while elapsed < timeout:
                if el.exists and el.info.get("enabled", False):
                    return True
                sleep(interval)
                elapsed += interval
            return False

        try:
            if not element:
                locatorType = locatorType.lower()
                selector = None

                if locatorType == "xpath":
                    selector = self.driver.xpath(locatorValue)
                elif locatorType == "text":
                    selector = self.driver(text=locatorValue)
                elif locatorType == "class":
                    selector = self.driver(className=locatorValue)
                elif locatorType == "des":
                    selector = self.driver(description=locatorValue)
                else:
                    kwargs = {locatorType: locatorValue}
                    selector = self.driver(**kwargs)

                if not selector.wait(timeout=wait):
                    return False if status else None

                if get_all:
                    elements = selector.all()
                    if get_attribute and attribute:
                        texts = [el.info.get(attribute) for el in elements]
                        return self._filter_names(texts) if filter_result else texts
                    return elements

                if index is not None:
                    if selector.count > index:
                        element = selector[index]
                    else:
                        logging.error(f"Index {index} is out of bounds. Found {selector.count} elements.")
                        return None
                else:
                    element = selector

            target_element = element
            sleep(post_wait)

            if not target_element:
                return False if status else None

            if status:
                return target_element.exists

            if isJustWait:
                return target_element

            if get_attribute and attribute:
                value = target_element.info.get(attribute)
                if filter_result and isinstance(value, str):
                    filtered = self._filter_names([value])
                    return filtered[0] if filtered else None
                return value

            if textInput is not None:
                target_element.set_text(textInput)
                return target_element

            if isLongClick:
                target_element.long_click()
                return target_element

            if not _wait_for_clickable(target_element, timeout=2):
                logging.warning("Element not clickable after waiting")
                return None

            for attempt in range(click_retry):
                try:
                    sleep(random.uniform(0.1, 0.3))
                    target_element.click()
                    break
                except Exception as e:
                    logging.warning(f"Click attempt {attempt+1} failed: {e}")
                    sleep(0.1)

            return target_element

        except (MaxRetryError, NewConnectionError, ProtocolError, ConnectionResetError) as e:
            raise RuntimeError(f"Device connection error while interacting with element: {e}") from e
        except Exception as e:
            logging.error(f"Error while interacting with element: {e}")
            return None