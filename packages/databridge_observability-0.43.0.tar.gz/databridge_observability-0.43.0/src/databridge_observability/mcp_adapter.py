"""Package-backed MCP adapter for observability tools."""

from src.observability.mcp_impl import register_observability_tools
from src.observability.unified import (
    _ensure_metrics_store,
    _ensure_alert_manager,
    _ensure_anomaly_detector,
    _ensure_health_scorer,
)


def get_components(data_dir: str = "data/observability"):
    """Back-compat helper used by legacy workflows."""

    class _Settings:
        pass

    settings = _Settings()
    # unified._get_data_dir appends '/observability' to settings.data_dir
    settings.data_dir = data_dir.rsplit("/observability", 1)[0] if data_dir.endswith("/observability") else data_dir
    store = _ensure_metrics_store(settings)
    alerts = _ensure_alert_manager(settings)
    detector = _ensure_anomaly_detector(settings)
    scorer = _ensure_health_scorer(settings)
    return store, alerts, detector, scorer

__all__ = ["register_observability_tools", "get_components"]
