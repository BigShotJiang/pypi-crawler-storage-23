"""Compatibility entrypoint for the `henosis-tools` console script.

Historically this repo exposed two entrypoints:
  - `henosis-cli`   -> cli:main
  - `henosis-tools` -> henosis_cli:main

The latter is kept for backwards compatibility (and for users who installed an
older name). For now it simply forwards to the main interactive CLI.
"""

from __future__ import annotations


def main() -> None:
    from cli import main as _main

    _main()
