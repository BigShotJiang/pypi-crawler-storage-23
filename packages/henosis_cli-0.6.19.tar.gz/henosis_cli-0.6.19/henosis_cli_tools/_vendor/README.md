# Vendored binaries

This directory is used to ship small, platform-specific helper binaries inside the
`henosis-cli` Python wheels.

Current intent:
- Bundle **ripgrep** (`rg` / `rg.exe`) so models and users can rely on `rg` being
  available even when it isn't installed on the system PATH.

How it gets populated:
- During CI wheel builds, we download the appropriate upstream `ripgrep` release
  for the target OS/arch and place the binary here.

Notes:
- Do not manually edit binaries in this folder. Prefer the vendoring script.
- The runtime code prepends this folder to `PATH` for subprocess execution.
