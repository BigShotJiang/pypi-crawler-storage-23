"""
Cross-platform line editor for henosis-cli with Shift+Enter newlines when possible.

Goals
- Windows: True Shift+Enter via Win32 console key events (ctypes).
- POSIX: Try to enable modern terminal keyboard protocols (kitty CSI u and
  xterm modifyOtherKeys). Calibrate whether Shift+Enter is distinguishable; if
  not, fall back to Ctrl+J for newline.

Design
- Blocking read_message(prompt_label, cont_label) that returns the composed
  message when Enter is pressed (without Shift). Raises KeyboardInterrupt on
  Ctrl+C. Minimal editing: printable chars, backspace, newline insertion, and
  submit.
- Rendering: simple echo to stdout; on newline we DO NOT prefix continuation
  lines with any label (no "..." prefixes). We do not implement full cursor
  navigation.

Limitations
- Full terminal editing parity is out of scope; we implement practical cursor
  movement and in-buffer edits for common keys.
"""
from __future__ import annotations

import os
import sys
import time
import base64
import subprocess
import shutil
import signal
from dataclasses import dataclass
from typing import Optional


def _get_terminal_width(default: int = 80) -> int:
    """Best-effort terminal width in columns.

    Used by the interactive redraw logic to account for soft-wrapping.
    """
    try:
        cols = shutil.get_terminal_size((default, 24)).columns
        return int(cols) if cols and cols > 0 else default
    except Exception:
        return default


def _wrap_rows_for_line(line_len: int, *, offset: int, width: int) -> int:
    """How many terminal rows a logical line occupies given soft-wrapping.

    This approximates VT-style auto-wrap behavior ("wrap pending").
    """
    if width <= 0:
        return 1
    if line_len <= 0:
        return 1
    # Rows consumed by printing `line_len` characters starting at `offset`.
    return ((offset + line_len - 1) // width) + 1


def _cursor_row_col_from_abs_cols(abs_cols: int, *, width: int) -> tuple[int, int]:
    """Map absolute columns advanced into (row, col) under wrap-pending semantics.

    abs_cols is the cursor column *after* printing characters from the start of a
    physical line (col=0). When abs_cols lands exactly on the right margin, most
    terminals keep the cursor on the last column with a wrap-pending flag.
    """
    if width <= 0:
        return 0, max(0, abs_cols)
    if abs_cols <= 0:
        return 0, 0
    if abs_cols % width == 0:
        return (abs_cols // width) - 1, width - 1
    return abs_cols // width, abs_cols % width


def _visual_total_rows(text: str, *, prompt_len: int, width: int) -> int:
    lines = text.split("\n") if text is not None else [""]
    if not lines:
        return 1
    total = 0
    for i, line in enumerate(lines):
        total += _wrap_rows_for_line(len(line), offset=(prompt_len if i == 0 else 0), width=width)
    return max(1, total)


def _visual_cursor_row_col(text: str, *, index: int, prompt_len: int, width: int) -> tuple[int, int]:
    """Return visual (row, col) within a rendered prompt+buffer block."""
    if text is None:
        text = ""
    if index < 0:
        index = 0
    if index > len(text):
        index = len(text)

    before = text[:index]
    parts = before.split("\n")
    if not parts:
        return 0, 0

    row = 0
    for i, line in enumerate(parts[:-1]):
        row += _wrap_rows_for_line(len(line), offset=(prompt_len if i == 0 else 0), width=width)

    logical_idx = len(parts) - 1
    offset = prompt_len if logical_idx == 0 else 0
    abs_cols = offset + len(parts[-1])
    row_in_line, col = _cursor_row_col_from_abs_cols(abs_cols, width=width)
    return row + row_in_line, col


@dataclass
class EngineInfo:
    supports_shift_enter: bool
    hint: str
    fallback_key_name: Optional[str] = None  # e.g., "Ctrl+J" when shift not available


class BaseInputEngine:
    def __init__(self) -> None:
        self.info = EngineInfo(
            supports_shift_enter=False,
            hint="Enter sends; Ctrl+J inserts a newline. Ctrl+A selects all; Ctrl+C copies when selected.",
            fallback_key_name="Ctrl+J",
        )
        # Input history used by Up/Down arrow navigation in key engines.
        # This is intentionally lightweight and stores only user-entered strings.
        self._history: list[str] = []
        self._history_max: int = 200

    def set_history(self, items: list[str]) -> None:
        """Replace the current history list.

        Callers (CLI) are expected to pass a list of *user-entered* inputs.
        """
        try:
            cleaned: list[str] = []
            for x in items or []:
                if isinstance(x, str):
                    s = x
                    if s and s.strip():
                        cleaned.append(s)
            if self._history_max and len(cleaned) > int(self._history_max):
                cleaned = cleaned[-int(self._history_max) :]
            self._history = cleaned
        except Exception:
            # Never break input because of history.
            self._history = []

    def add_history(self, item: str) -> None:
        """Append a single entry to history (best effort)."""
        try:
            if not isinstance(item, str):
                return
            s = item
            if not s or not s.strip():
                return
            # Avoid immediate duplicates.
            if self._history and self._history[-1] == s:
                return
            self._history.append(s)
            if self._history_max and len(self._history) > int(self._history_max):
                self._history = self._history[-int(self._history_max) :]
        except Exception:
            pass

    def get_history(self) -> list[str]:
        try:
            return list(self._history)
        except Exception:
            return []

    def read_message(self, prompt_label: str = "\nYou: ", cont_label: str = "... ") -> str:
        raise NotImplementedError


def _is_tty() -> bool:
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def _copy_to_clipboard(text: str) -> bool:
    """Best-effort copy to the user's clipboard.

    This is used only for the CLI's internal "select all" highlight state.

    Strategy (best-effort, no hard deps):
    - Try pyperclip if installed.
    - Windows: use Win32 clipboard via ctypes (CF_UNICODETEXT).
    - macOS: pbcopy.
    - Linux: wl-copy, xclip, xsel.
    - Last resort: OSC52 (many modern terminals support it).

    Returns True if we believe the copy succeeded.
    """
    try:
        if not isinstance(text, str) or not text:
            return False
    except Exception:
        return False

    # 1) Optional dependency
    try:
        import pyperclip  # type: ignore

        try:
            pyperclip.copy(text)
            return True
        except Exception:
            pass
    except Exception:
        pass

    # 2) Windows native clipboard
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            # Temporary memory object already discarded by owner.
            GHND = 0x0042

            user32 = ctypes.WinDLL("user32", use_last_error=True)  # type: ignore[attr-defined]
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]

            user32.OpenClipboard.argtypes = [wintypes.HWND]
            user32.OpenClipboard.restype = wintypes.BOOL
            user32.EmptyClipboard.argtypes = []
            user32.EmptyClipboard.restype = wintypes.BOOL
            user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
            user32.SetClipboardData.restype = wintypes.HANDLE
            user32.CloseClipboard.argtypes = []
            user32.CloseClipboard.restype = wintypes.BOOL

            kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
            kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
            kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
            kernel32.GlobalLock.restype = wintypes.LPVOID
            kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
            kernel32.GlobalUnlock.restype = wintypes.BOOL
            kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]
            kernel32.GlobalFree.restype = wintypes.HGLOBAL

            opened = False
            # Clipboard can be momentarily busy; retry briefly.
            for _ in range(10):
                if user32.OpenClipboard(None):
                    opened = True
                    break
                time.sleep(0.01)
            if not opened:
                return False
            try:
                if not user32.EmptyClipboard():
                    return False
                data = (text + "\x00").encode("utf-16le")
                hglob = kernel32.GlobalAlloc(GMEM_MOVEABLE | GHND, len(data))
                if not hglob:
                    return False
                locked = kernel32.GlobalLock(hglob)
                if not locked:
                    kernel32.GlobalFree(hglob)
                    return False
                try:
                    ctypes.memmove(locked, data, len(data))
                finally:
                    kernel32.GlobalUnlock(hglob)
                if not user32.SetClipboardData(CF_UNICODETEXT, hglob):
                    kernel32.GlobalFree(hglob)
                    return False
                # Ownership of hglob is transferred to the system on success.
                return True
            finally:
                user32.CloseClipboard()
        except Exception:
            pass
        # 2b) Windows command fallback
        try:
            p = subprocess.run(
                ["cmd", "/c", "clip"],
                input=text,
                text=True,
                encoding="utf-8",
                check=False,
            )
            if p.returncode == 0:
                return True
        except Exception:
            pass

    # 3) macOS
    try:
        if sys.platform == "darwin":
            p = subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=False)
            return p.returncode == 0
    except Exception:
        pass

    # 4) Linux/Unix helpers
    try:
        for cmd in ("wl-copy", "xclip", "xsel"):
            if shutil.which(cmd):
                if cmd == "xclip":
                    p = subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode("utf-8"), check=False)
                elif cmd == "xsel":
                    p = subprocess.run(["xsel", "--clipboard", "--input"], input=text.encode("utf-8"), check=False)
                else:
                    p = subprocess.run(["wl-copy"], input=text.encode("utf-8"), check=False)
                if p.returncode == 0:
                    return True
    except Exception:
        pass

    # 5) OSC52 fallback (many terminals; also works over SSH in some setups)
    try:
        b64 = base64.b64encode(text.encode("utf-8", errors="replace")).decode("ascii")
        osc52 = f"\x1b]52;c;{b64}\x07"
        sys.stdout.write(osc52)
        sys.stdout.flush()
        return True
    except Exception:
        return False


class WindowsKeyEngine(BaseInputEngine):
    def __init__(self) -> None:
        super().__init__()
        import ctypes, msvcrt  # local imports
        self.ctypes = ctypes
        self.msvcrt = msvcrt
        self.user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        self.VK_SHIFT = 0x10
        # Windows supports detecting Shift reliably
        self.info = EngineInfo(supports_shift_enter=True, hint="Shift+Enter inserts a newline; Enter sends. Ctrl+A selects all; Ctrl+C copies when selected.")
        # Best-effort: enable ANSI escape processing so we can move the cursor
        try:
            kernel32 = ctypes.windll.kernel32
            STD_OUTPUT_HANDLE = -11
            handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
            mode = ctypes.c_uint()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
                kernel32.SetConsoleMode(handle, new_mode)
        except Exception:
            pass

    def read_message(self, prompt_label: str = "\nYou: ", cont_label: str = "... ") -> str:
        buf: list[str] = []
        cursor = 0
        select_all = False
        # Input history navigation state
        history = self.get_history()
        hist_pos = len(history)  # len(history) means "draft" (no history selected)
        draft_text: Optional[str] = None
        # Keep track of what we *last rendered* so redraw can move relative to the
        # current terminal cursor position (which is still at the previous cursor
        # location when we mutate the buffer).
        prev_render_text = ""
        prev_render_cursor = 0
        # Visible prompt is the part after the last newline in the label
        try:
            visible_prompt_len = len(prompt_label.rsplit("\n", 1)[-1])
        except Exception:
            visible_prompt_len = len(prompt_label)
        try:
            visible_prompt = prompt_label.rsplit("\n", 1)[-1]
        except Exception:
            visible_prompt = prompt_label
        # Track previously rendered *visual* line count so redraw can clear stale wrapped rows.
        prev_visual_line_count = 1

        def _redraw_input(highlight_all: bool) -> None:
            """Redraw prompt + buffer and place terminal cursor at logical cursor."""
            nonlocal prev_visual_line_count
            nonlocal prev_render_text, prev_render_cursor
            try:
                width = _get_terminal_width()
                current = "".join(buf)
                visual_line_count = _visual_total_rows(current, prompt_len=visible_prompt_len, width=width)

                # Assume we're somewhere inside the input block: go to top line.
                sys.stdout.write("\r")
                # IMPORTANT: move relative to the *previously rendered* cursor row.
                # If the edit shrinks the buffer (e.g., Ctrl+A then Backspace), the
                # new cursor row may be 0 even though the terminal cursor is still
                # sitting on a lower wrapped row from the old render.
                prev_cursor_row, _ = _visual_cursor_row_col(
                    prev_render_text,
                    index=prev_render_cursor,
                    prompt_len=visible_prompt_len,
                    width=width,
                )
                if prev_cursor_row > 0:
                    sys.stdout.write(f"\x1b[{prev_cursor_row}A")

                # Clear previously rendered block.
                for i in range(prev_visual_line_count):
                    sys.stdout.write("\r\x1b[2K")
                    if i < (prev_visual_line_count - 1):
                        sys.stdout.write("\x1b[1B")
                if prev_visual_line_count > 1:
                    sys.stdout.write(f"\x1b[{prev_visual_line_count - 1}A")

                # Render prompt + content.
                sys.stdout.write(str(visible_prompt))
                if current:
                    render_current = current.replace("\n", "\r\n")
                    if highlight_all:
                        sys.stdout.write("\x1b[7m" + render_current + "\x1b[27m")
                    else:
                        sys.stdout.write(render_current)

                # Move to logical cursor position.
                target_row, target_col = _visual_cursor_row_col(current, index=cursor, prompt_len=visible_prompt_len, width=width)
                end_row, _end_col = _visual_cursor_row_col(current, index=len(current), prompt_len=visible_prompt_len, width=width)
                sys.stdout.write("\r")
                if end_row > 0:
                    sys.stdout.write(f"\x1b[{end_row}A")
                if target_row > 0:
                    sys.stdout.write(f"\x1b[{target_row}B")
                sys.stdout.write("\r")
                if target_col > 0:
                    sys.stdout.write(f"\x1b[{target_col}C")
                sys.stdout.flush()
                prev_visual_line_count = visual_line_count
                prev_render_text = current
                prev_render_cursor = cursor
            except Exception:
                # Last resort: don't crash input; just print prompt on a new line.
                try:
                    sys.stdout.write("\n" + str(visible_prompt))
                    sys.stdout.flush()
                except Exception:
                    pass

        sys.stdout.write(prompt_label)
        sys.stdout.flush()
        prev_sigint = None
        sigint_pending = False

        def _sigint_handler(_signum, _frame) -> None:
            nonlocal sigint_pending
            sigint_pending = True

        try:
            prev_sigint = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _sigint_handler)
        except (ValueError, OSError):
            # If not in main thread, signal override is unavailable.
            prev_sigint = None

        try:
            while True:
                if sigint_pending:
                    sigint_pending = False
                    if select_all and buf:
                        _copy_to_clipboard("".join(buf))
                        _redraw_input(highlight_all=True)
                        continue
                    raise KeyboardInterrupt
                if not self.msvcrt.kbhit():
                    time.sleep(0.01)
                    continue
                ch = self.msvcrt.getwch()
                # Ctrl+C
                if ch == "\x03":
                    if select_all and buf:
                        _copy_to_clipboard("".join(buf))
                        # Keep the visual highlight so the user gets feedback.
                        _redraw_input(highlight_all=True)
                        continue
                    raise KeyboardInterrupt
                # Ctrl+A: select all (replace-on-type)
                if ch == "\x01":
                    select_all = True
                    cursor = len(buf)
                    # Visual highlight: show the whole current buffer inverted.
                    _redraw_input(highlight_all=True)
                    continue
                # Special keys: consume the next code and handle common editors.
                if ch in ("\x00", "\xe0"):
                    code = self.msvcrt.getwch()
                    c = ord(code) if code else -1
                    # Up (history back)
                    if c == 72:
                        if history:
                            if hist_pos == len(history):
                                draft_text = "".join(buf)
                            if hist_pos > 0:
                                hist_pos -= 1
                            buf[:] = list(history[hist_pos])
                            cursor = len(buf)
                            select_all = False
                            _redraw_input(highlight_all=False)
                        continue
                    # Down (history forward)
                    if c == 80:
                        if history:
                            if hist_pos < len(history) - 1:
                                hist_pos += 1
                                buf[:] = list(history[hist_pos])
                                cursor = len(buf)
                            else:
                                hist_pos = len(history)
                                restore = draft_text if draft_text is not None else ""
                                buf[:] = list(restore)
                                cursor = len(buf)
                            select_all = False
                            _redraw_input(highlight_all=False)
                        continue
                    # Left
                    if c == 75:
                        if select_all:
                            select_all = False
                        if cursor > 0:
                            cursor -= 1
                            _redraw_input(highlight_all=False)
                        continue
                    # Right
                    if c == 77:
                        if select_all:
                            select_all = False
                        if cursor < len(buf):
                            cursor += 1
                            _redraw_input(highlight_all=False)
                        continue
                    # Home
                    if c == 71:
                        if select_all:
                            select_all = False
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        continue
                    # End
                    if c == 79:
                        if select_all:
                            select_all = False
                        cursor = len(buf)
                        _redraw_input(highlight_all=False)
                        continue
                    # Delete
                    if c == 83:
                        if select_all:
                            buf.clear()
                            cursor = 0
                            select_all = False
                            _redraw_input(highlight_all=False)
                            continue
                        if cursor < len(buf):
                            del buf[cursor]
                            _redraw_input(highlight_all=False)
                        continue
                    continue
                if ch == "\r":
                    # Check if Shift is currently pressed
                    shift_down = (self.user32.GetKeyState(self.VK_SHIFT) & 0x8000) != 0
                    if shift_down:
                        if select_all:
                            buf.clear()
                            cursor = 0
                            _redraw_input(highlight_all=False)
                            select_all = False
                        buf.insert(cursor, "\n")
                        cursor += 1
                        _redraw_input(highlight_all=False)
                        continue
                    else:
                        sys.stdout.write("\n")
                        sys.stdout.flush()
                        return "".join(buf).strip()
                if ch == "\x08":  # backspace
                    if cursor > 0:
                        if select_all:
                            # Delete all (common UX: Ctrl+A then Backspace clears everything)
                            buf.clear()
                            cursor = 0
                            _redraw_input(highlight_all=False)
                            select_all = False
                            continue
                        del buf[cursor - 1]
                        cursor -= 1
                        _redraw_input(highlight_all=False)
                    continue
                # Regular printable
                if ch not in ("\n",):
                    if select_all:
                        buf.clear()
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        select_all = False
                    # Any typing exits history mode
                    if hist_pos != len(history):
                        hist_pos = len(history)
                        draft_text = None
                    buf.insert(cursor, ch)
                    cursor += 1
                    _redraw_input(highlight_all=False)
        except KeyboardInterrupt:
            raise
        finally:
            if prev_sigint is not None:
                try:
                    signal.signal(signal.SIGINT, prev_sigint)
                except (ValueError, OSError):
                    pass


class PosixKeyEngine(BaseInputEngine):
    def __init__(self) -> None:
        super().__init__()
        import termios, tty, select  # local imports
        self.termios = termios
        self.tty = tty
        self.select = select
        self.fd = sys.stdin.fileno()
        self._orig_attrs = termios.tcgetattr(self.fd)
        # Enable raw mode
        self.tty.setcbreak(self.fd)
        # Try enabling modern keyboard protocols (best effort)
        try:
            sys.stdout.write("\x1b[>1u")  # kitty CSI u
            sys.stdout.write("\x1b[>4;2m")  # xterm modifyOtherKeys=2
            sys.stdout.flush()
        except Exception:
            pass
        # Calibrate Shift+Enter signature (non-intrusive, one-shot)
        self.shift_sig: Optional[bytes] = None
        self.enter_sigs = {b"\r", b"\n", b"\r\n"}
        try:
            self._calibrate()
        except Exception:
            # If calibration fails, fallback remains
            pass
        if self.shift_sig is not None:
            self.info = EngineInfo(supports_shift_enter=True, hint="Shift+Enter inserts a newline; Enter sends. Ctrl+A selects all; Ctrl+C copies when selected.")
        else:
            self.info = EngineInfo(supports_shift_enter=False, hint="Enter sends; Ctrl+J inserts a newline. Ctrl+A selects all; Ctrl+C copies when selected.", fallback_key_name="Ctrl+J")

    def __del__(self) -> None:  # best effort restore
        try:
            self.termios.tcsetattr(self.fd, self.termios.TCSADRAIN, self._orig_attrs)
        except Exception:
            pass
        # Disable protocols
        try:
            sys.stdout.write("\x1b[>0u")  # disable kitty CSI u
            sys.stdout.write("\x1b[>4;0m")  # disable modifyOtherKeys
            sys.stdout.flush()
        except Exception:
            pass

    def _read_bytes(self, timeout: float = 5.0) -> bytes:
        start = time.time()
        chunks: list[bytes] = []
        while True:
            r, _, _ = self.select.select([self.fd], [], [], max(0, timeout - (time.time() - start)))
            if not r:
                break
            try:
                b = os.read(self.fd, 64)
            except InterruptedError:
                continue
            if not b:
                break
            chunks.append(b)
            # If first byte is not ESC, we likely have a single key
            if chunks[0][:1] != b"\x1b":
                break
            # If ESC sequence, read a little more to complete it (short wait)
            time.sleep(0.01)
            if time.time() - start > timeout:
                break
        return b"".join(chunks)

    def _calibrate(self) -> None:
        # Ask the terminal silently to differentiate Enter vs Shift+Enter by sampling two presses.
        # We'll keep this subtle: short messages to stderr to avoid interfering with stdout rendering
        try:
            sys.stderr.write("[calibration] Press Enter, then Shift+Enter (or Ctrl+J if Shift+Enter unsupported).\n")
            sys.stderr.flush()
        except Exception:
            pass
        # Read Enter
        b1 = self._read_bytes(timeout=10.0)
        if b1:
            # Normalize CRLF
            if b1 == b"\r\n":
                b1 = b"\r"
            self.enter_sigs.add(b1)
        # Read Shift+Enter attempt (or Ctrl+J fallback)
        b2 = self._read_bytes(timeout=10.0)
        if not b2:
            return
        # Common kitty CSI u for Shift+Enter: ESC [ 13 ; 2 u
        if b2.startswith(b"\x1b[") and (b"13;2" in b2) and (b2.endswith(b"u") or b2.endswith(b"~")):
            self.shift_sig = b2
            return
        # Some terminals using modifyOtherKeys can send ESC [ 27 ; 2 ; 13 ~ (varies); accept any non-equal distinct sequence
        if b2 not in self.enter_sigs:
            self.shift_sig = b2
            return
        # If identical, no support detected; fallback remains
        self.shift_sig = None

    def _is_backspace(self, b: bytes) -> bool:
        return b in (b"\x7f", b"\x08")

    def read_message(self, prompt_label: str = "\nYou: ", cont_label: str = "... ") -> str:
        # Visible prompt is the part after the last newline in the label
        try:
            visible_prompt_len = len(prompt_label.rsplit("\n", 1)[-1])
        except Exception:
            visible_prompt_len = len(prompt_label)
        sys.stdout.write(prompt_label)
        sys.stdout.flush()
        buf: list[str] = []
        cursor = 0
        select_all = False
        # Input history navigation state
        history = self.get_history()
        hist_pos = len(history)
        draft_text: Optional[str] = None
        prev_render_text = ""
        prev_render_cursor = 0
        prev_visual_line_count = 1
        try:
            visible_prompt = prompt_label.rsplit("\n", 1)[-1]
        except Exception:
            visible_prompt = prompt_label

        def _redraw_input(highlight_all: bool) -> None:
            nonlocal prev_visual_line_count
            nonlocal prev_render_text, prev_render_cursor
            try:
                width = _get_terminal_width()
                current = "".join(buf)
                visual_line_count = _visual_total_rows(current, prompt_len=visible_prompt_len, width=width)

                sys.stdout.write("\r")
                prev_cursor_row, _ = _visual_cursor_row_col(
                    prev_render_text,
                    index=prev_render_cursor,
                    prompt_len=visible_prompt_len,
                    width=width,
                )
                if prev_cursor_row > 0:
                    sys.stdout.write(f"\x1b[{prev_cursor_row}A")

                for i in range(prev_visual_line_count):
                    sys.stdout.write("\r\x1b[2K")
                    if i < (prev_visual_line_count - 1):
                        sys.stdout.write("\x1b[1B")
                if prev_visual_line_count > 1:
                    sys.stdout.write(f"\x1b[{prev_visual_line_count - 1}A")

                sys.stdout.write(str(visible_prompt))
                if current:
                    render_current = current.replace("\n", "\r\n")
                    if highlight_all:
                        sys.stdout.write("\x1b[7m" + render_current + "\x1b[27m")
                    else:
                        sys.stdout.write(render_current)

                target_row, target_col = _visual_cursor_row_col(current, index=cursor, prompt_len=visible_prompt_len, width=width)
                end_row, _end_col = _visual_cursor_row_col(current, index=len(current), prompt_len=visible_prompt_len, width=width)
                sys.stdout.write("\r")
                if end_row > 0:
                    sys.stdout.write(f"\x1b[{end_row}A")
                if target_row > 0:
                    sys.stdout.write(f"\x1b[{target_row}B")
                sys.stdout.write("\r")
                if target_col > 0:
                    sys.stdout.write(f"\x1b[{target_col}C")
                sys.stdout.flush()
                prev_visual_line_count = visual_line_count
                prev_render_text = current
                prev_render_cursor = cursor
            except Exception:
                try:
                    sys.stdout.write("\n" + str(visible_prompt))
                    sys.stdout.flush()
                except Exception:
                    pass
        try:
            while True:
                b = self._read_bytes(timeout=1e6)  # effectively block
                if not b:
                    continue
                # Ctrl+C in raw mode arrives as 0x03
                if b == b"\x03":
                    if select_all and buf:
                        _copy_to_clipboard("".join(buf))
                        _redraw_input(highlight_all=True)
                        continue
                    raise KeyboardInterrupt
                # Ctrl+A: select all (replace-on-type)
                if b == b"\x01":
                    select_all = True
                    cursor = len(buf)
                    _redraw_input(highlight_all=True)
                    continue
                # Ctrl+J fallback for newline when shift unsupported
                if not self.info.supports_shift_enter and b == b"\n":
                    if select_all:
                        buf.clear()
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        select_all = False
                    buf.insert(cursor, "\n")
                    cursor += 1
                    _redraw_input(highlight_all=False)
                    continue
                # Submit on Enter
                if b in self.enter_sigs:
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    return "".join(buf).strip()
                # Shift+Enter signature insert newline
                if self.info.supports_shift_enter and self.shift_sig is not None and b == self.shift_sig:
                    if select_all:
                        buf.clear()
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        select_all = False
                    buf.insert(cursor, "\n")
                    cursor += 1
                    _redraw_input(highlight_all=False)
                    continue
                # Backspace
                if self._is_backspace(b):
                    if cursor > 0:
                        if select_all:
                            buf.clear()
                            cursor = 0
                            _redraw_input(highlight_all=False)
                            select_all = False
                            continue
                        del buf[cursor - 1]
                        cursor -= 1
                        _redraw_input(highlight_all=False)
                    continue
                # Arrow/navigation keys
                if b.startswith(b"\x1b"):
                    if select_all:
                        select_all = False
                    if b == b"\x1b[A":  # Up (history back)
                        if history:
                            if hist_pos == len(history):
                                draft_text = "".join(buf)
                            if hist_pos > 0:
                                hist_pos -= 1
                            buf[:] = list(history[hist_pos])
                            cursor = len(buf)
                            _redraw_input(highlight_all=False)
                        continue
                    if b == b"\x1b[B":  # Down (history forward)
                        if history:
                            if hist_pos < len(history) - 1:
                                hist_pos += 1
                                buf[:] = list(history[hist_pos])
                                cursor = len(buf)
                            else:
                                hist_pos = len(history)
                                restore = draft_text if draft_text is not None else ""
                                buf[:] = list(restore)
                                cursor = len(buf)
                            _redraw_input(highlight_all=False)
                        continue
                    if b == b"\x1b[D":  # Left
                        if cursor > 0:
                            cursor -= 1
                            _redraw_input(highlight_all=False)
                        continue
                    if b == b"\x1b[C":  # Right
                        if cursor < len(buf):
                            cursor += 1
                            _redraw_input(highlight_all=False)
                        continue
                    if b in (b"\x1b[H", b"\x1b[1~"):  # Home
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        continue
                    if b in (b"\x1b[F", b"\x1b[4~"):  # End
                        cursor = len(buf)
                        _redraw_input(highlight_all=False)
                        continue
                    if b == b"\x1b[3~":  # Delete
                        if cursor < len(buf):
                            del buf[cursor]
                            _redraw_input(highlight_all=False)
                        continue
                    # If the user typed literal ESC followed by something else, ignore.
                    continue
                # Printable bytes -> decode
                try:
                    s = b.decode("utf-8", errors="ignore")
                except Exception:
                    s = ""
                if s:
                    if select_all:
                        buf.clear()
                        cursor = 0
                        _redraw_input(highlight_all=False)
                        select_all = False
                    # Any typing exits history mode
                    if hist_pos != len(history):
                        hist_pos = len(history)
                        draft_text = None
                    for ch in s:
                        buf.insert(cursor, ch)
                        cursor += 1
                    _redraw_input(highlight_all=False)
        except KeyboardInterrupt:
            raise


def make_engine() -> BaseInputEngine:
    if not _is_tty():
        # Non-tty: fallback to simple input() composer
        return SimpleInputEngine()
    if os.name == "nt":
        try:
            return WindowsKeyEngine()
        except Exception:
            return SimpleInputEngine()
    else:
        try:
            return PosixKeyEngine()
        except Exception:
            return SimpleInputEngine()


class SimpleInputEngine(BaseInputEngine):
    def __init__(self) -> None:
        super().__init__()
        # Multiline composer using input(): Enter on an empty line submits
        self.info = EngineInfo(
            supports_shift_enter=False,
            hint="Empty line submits; paste freely.",
            fallback_key_name="Ctrl+J",
        )

    def read_message(self, prompt_label: str = "\nYou: ", cont_label: str = "... ") -> str:  # noqa: ARG002
        # Multiline input fallback for non-tty or failure cases.
        # Rules:
        # - Print prompt once.
        # - Read lines until an empty line is entered; submit accumulated text.
        # - EOF (Ctrl+D/Z) submits if buffer has content; otherwise propagates.
        sys.stdout.write(prompt_label)
        sys.stdout.flush()
        lines: list[str] = []
        while True:
            try:
                line = input()
            except EOFError:
                # Submit what we have; if nothing, bubble up for graceful exit
                if lines:
                    return "\n".join(lines)
                raise
            # Empty line submits (if we already have something)
            if line == "":
                if lines:
                    return "\n".join(lines)
                # If first line is empty, treat as empty message
                return ""
            lines.append(line)
