import asyncio
import importlib


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


class _DummyResp:
    def __init__(self, status_code=200, text="ok"):
        self.status_code = status_code
        self.text = text


class _DummyClient:
    def __init__(self):
        self.posts = []

    async def post(self, url, json=None, timeout=None):
        self.posts.append({"url": url, "json": json, "timeout": timeout})
        return _DummyResp(200, "ok")


def test_issue18_level3_auto_approves_without_prompt():
    cli = make_cli()
    cli.control_level = None
    cli._current_turn["level"] = 3

    async def _noop_broadcast(_typ, _data):
        return None

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("approval prompt should not run at level 3")

    cli._ws_broadcast = _noop_broadcast  # type: ignore[attr-defined]
    cli._ws_is_open = lambda _ws: False  # type: ignore[attr-defined]
    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]
    cli.ui.confirm = _prompt_should_not_run  # type: ignore[method-assign]

    client = _DummyClient()
    data = {
        "tool": "run_command",
        "call_id": "call-1",
        "args_preview": {"cmd": "rg --files"},
        "level": 3,
        "timeout_sec": 30,
    }
    asyncio.run(cli._handle_approval_request(client, "sess-1", data))

    assert len(client.posts) == 1
    payload = client.posts[0]["json"]
    assert payload["session_id"] == "sess-1"
    assert payload["call_id"] == "call-1"
    assert payload["approve"] is True
    assert payload["note"] == "Auto-approved (Level 3)"
    assert not cli._pending_approvals


def test_issue18_registers_pending_before_ws_broadcast():
    cli = make_cli()
    cli.control_level = None
    cli._current_turn["level"] = 2

    seen = {"pending_present": False}

    async def _broadcast_with_fast_reply(typ, data):
        if typ == "approval.request":
            call_id = str(data.get("call_id"))
            if call_id in cli._pending_approvals:
                seen["pending_present"] = True
                fut = cli._pending_approvals[call_id]
                if not fut.done():
                    fut.set_result((True, "Approved via Web"))

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("cli prompt should not run when ws is connected")

    cli._ws_broadcast = _broadcast_with_fast_reply  # type: ignore[attr-defined]
    cli._ws_is_open = lambda _ws: True  # type: ignore[attr-defined]
    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]
    cli.ui.confirm = _prompt_should_not_run  # type: ignore[method-assign]

    client = _DummyClient()
    data = {
        "tool": "write_file",
        "call_id": "call-2",
        "args_preview": {"path": "x.txt", "content": "abc"},
        "level": 2,
        "timeout_sec": 30,
    }
    asyncio.run(cli._handle_approval_request(client, "sess-2", data))

    assert seen["pending_present"] is True
    assert len(client.posts) == 1
    payload = client.posts[0]["json"]
    assert payload["session_id"] == "sess-2"
    assert payload["call_id"] == "call-2"
    assert payload["approve"] is True
    assert payload["note"] == "Approved via Web"
    assert not cli._pending_approvals


def test_issue18_ws_timeout_does_not_spawn_cli_prompt():
    cli = make_cli()
    cli.control_level = None
    cli._current_turn["level"] = 2

    async def _broadcast_no_reply(_typ, _data):
        return None

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("cli prompt should not run in ws-only approval path")

    cli._ws_broadcast = _broadcast_no_reply  # type: ignore[attr-defined]
    cli._ws_is_open = lambda _ws: True  # type: ignore[attr-defined]
    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]
    cli.ui.confirm = _prompt_should_not_run  # type: ignore[method-assign]

    client = _DummyClient()
    data = {
        "tool": "apply_patch",
        "call_id": "call-3",
        "args_preview": {"patch": "*** Begin Patch\n*** End Patch\n"},
        "level": 2,
        "timeout_sec": 0.01,
    }
    asyncio.run(cli._handle_approval_request(client, "sess-3", data))

    assert len(client.posts) == 1
    payload = client.posts[0]["json"]
    assert payload["session_id"] == "sess-3"
    assert payload["call_id"] == "call-3"
    assert payload["approve"] is False
    assert payload["note"] == "Timed out"
    assert not cli._pending_approvals


def test_issue18_server_level_overrides_stale_local_level():
    cli = make_cli()
    # Simulate stale local setting from a prior turn.
    cli.control_level = 2
    cli._current_turn["level"] = 3
    cli._last_server_level = 3

    async def _noop_broadcast(_typ, _data):
        return None

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("approval prompt should not run when event/server level is 3")

    cli._ws_broadcast = _noop_broadcast  # type: ignore[attr-defined]
    cli._ws_is_open = lambda _ws: False  # type: ignore[attr-defined]
    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]
    cli.ui.confirm = _prompt_should_not_run  # type: ignore[method-assign]

    client = _DummyClient()
    data = {
        "tool": "run_command",
        "call_id": "call-4",
        "args_preview": {"cmd": "git status"},
        "level": 3,
        "timeout_sec": 30,
    }
    asyncio.run(cli._handle_approval_request(client, "sess-4", data))

    assert len(client.posts) == 1
    payload = client.posts[0]["json"]
    assert payload["session_id"] == "sess-4"
    assert payload["call_id"] == "call-4"
    assert payload["approve"] is True
    assert payload["note"] == "Auto-approved (Level 3)"
    assert not cli._pending_approvals


def test_issue18_cli_approval_uses_explicit_level_from_dispatch():
    cli = make_cli()
    # Local control may be stale, but the dispatch event can be authoritative.
    cli.control_level = 2
    cli._current_turn["level"] = 3
    cli._last_server_level = 3

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("approval prompt should not run for explicit Level 3 dispatch")

    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]

    ok = cli._cli_approval_for(
        "run_command",
        {"cmd": "git status", "cwd": ".", "timeout": 30},
        level=3,
    )
    assert ok is True


def test_issue18_cli_approval_prefers_server_level_over_stale_local():
    cli = make_cli()
    cli.control_level = 2
    cli._current_turn["level"] = 3
    cli._last_server_level = 3

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("approval prompt should not run when stream level is 3")

    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]

    ok = cli._cli_approval_for("write_file", {"path": "x.txt", "content": "hello"})
    assert ok is True


def test_issue18_session_level_cache_overrides_stale_globals():
    cli = make_cli()
    # Simulate a late event after turn reset where globals are stale.
    cli.control_level = 2
    cli._current_turn["level"] = None
    cli._last_server_level = 2
    cli._session_level_by_id["sess-l3"] = 3

    async def _noop_broadcast(_typ, _data):
        return None

    def _prompt_should_not_run(*_args, **_kwargs):
        raise AssertionError("approval prompt should not run when session level cache says L3")

    cli._ws_broadcast = _noop_broadcast  # type: ignore[attr-defined]
    cli._ws_is_open = lambda _ws: False  # type: ignore[attr-defined]
    cli._approval_prompt_ui = _prompt_should_not_run  # type: ignore[attr-defined]
    cli.ui.confirm = _prompt_should_not_run  # type: ignore[method-assign]

    client = _DummyClient()
    data = {
        "session_id": "sess-l3",
        "tool": "run_command",
        "call_id": "call-5",
        "args_preview": {"cmd": "git status"},
        # Intentionally omit level to exercise session-id mapping path.
        "timeout_sec": 30,
    }
    asyncio.run(cli._handle_approval_request(client, None, data))

    assert len(client.posts) == 1
    payload = client.posts[0]["json"]
    assert payload["session_id"] == "sess-l3"
    assert payload["call_id"] == "call-5"
    assert payload["approve"] is True
    assert payload["note"] == "Auto-approved (Level 3)"
    assert not cli._pending_approvals


def test_issue18_effective_level_uses_event_session_id_mapping():
    cli = make_cli()
    cli.control_level = 2
    cli._current_turn["level"] = None
    cli._last_server_level = 2
    cli._session_level_by_id["sess-l3b"] = 3

    lvl = cli._effective_control_level({"session_id": "sess-l3b"})
    assert lvl == 3
