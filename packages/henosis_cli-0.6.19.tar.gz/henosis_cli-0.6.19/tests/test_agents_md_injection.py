import os

from cli import ChatCLI


def test_agents_md_injection_order_and_only_once(tmp_path):
    cli = ChatCLI(
        server=os.getenv("HENOSIS_SERVER", "https://henosis.us/api_v2"),
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=True,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )

    # Force deterministic content without relying on package files.
    cli.inject_agents_md = True
    cli.agents_md_text = "DEFAULT_AGENTS"
    cli._codebase_map_raw = "# MAP\n- file: x.py\n"
    cli._did_inject_codebase_map = False
    cli._did_inject_custom_first_turn = False
    cli._did_inject_working_memory = False
    cli._did_inject_agents_md = False

    # Also test local AGENTS.md prepend behavior.
    local_agents = tmp_path / "AGENTS.md"
    local_agents.write_text("LOCAL_AGENTS", encoding="utf-8")
    cli.host_base = str(tmp_path)
    cli._host_base_ephemeral = False
    cli.agents_prepend_mode = "prepend_default"

    msgs1 = cli._build_messages("First?")
    content1 = msgs1[-1]["content"]

    assert content1.startswith("<AGENTS.md>"), "AGENTS.md block should be prefixed on the first turn"
    assert "DEFAULT_AGENTS" in content1
    assert "LOCAL_AGENTS" in content1
    assert content1.index("<AGENTS.md>") < content1.index("<codebase_map>")

    # Second turn: should not re-inject.
    msgs2 = cli._build_messages("Second?")
    content2 = msgs2[-1]["content"]
    assert "<AGENTS.md>" not in content2
    assert "<codebase_map>" not in content2
