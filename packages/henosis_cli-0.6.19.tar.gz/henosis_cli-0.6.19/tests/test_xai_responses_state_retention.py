import json
import copy
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from starlette.testclient import TestClient

# Ensure repository root is on sys.path so `import app` works regardless of pytest cwd.
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


class _FakeHTTPResponse:
    def __init__(self, status_code: int = 200, data: Optional[Dict[str, Any]] = None, text: str = ""):
        self.status_code = status_code
        self._data = data or {}
        self.text = text

    def json(self) -> Dict[str, Any]:
        return dict(self._data)


class _FakeStreamResponse:
    def __init__(self, lines: List[str], status_code: int = 200):
        self._lines = lines
        self.status_code = status_code

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def aiter_lines(self):
        for line in self._lines:
            yield line

    async def aread(self) -> bytes:
        return b""


class _FakeXAIAsyncClient:
    instances: List["_FakeXAIAsyncClient"] = []
    response_id: str = "resp_xai_1"

    def __init__(self, *args, **kwargs):
        self.stream_calls: List[Dict[str, Any]] = []
        self.post_calls: List[Dict[str, Any]] = []
        _FakeXAIAsyncClient.instances.append(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, url: str, headers: Optional[Dict[str, str]] = None, json: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None):
        self.post_calls.append(
            {
                "url": url,
                "headers": dict(headers or {}),
                "json": dict(json or {}),
                "timeout": timeout,
            }
        )
        # Tool-detect path is not expected in these tests (enable_tools=False),
        # but return a valid empty response object defensively.
        data = {
            "id": "resp_detect_unused",
            "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
            "output": [],
        }
        return _FakeHTTPResponse(status_code=200, data=data)

    def stream(self, method: str, url: str, headers: Optional[Dict[str, str]] = None, json: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None):
        self.stream_calls.append(
            {
                "method": method,
                "url": url,
                "headers": dict(headers or {}),
                "json": copy.deepcopy(dict(json or {})),
                "timeout": timeout,
            }
        )
        final_response = {
            "id": _FakeXAIAsyncClient.response_id,
            "usage": {"input_tokens": 5, "output_tokens": 3, "total_tokens": 8},
            "output": [
                {"type": "reasoning", "id": "rs_1", "summary": [], "encrypted_content": "enc_blob"},
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Hello from xAI"}],
                },
            ],
        }
        lines = [
            "data: " + json_module.dumps({"type": "response.output_text.delta", "delta": "Hello from xAI"}),
            "data: " + json_module.dumps({"type": "response.completed", "response": final_response}),
            "data: [DONE]",
        ]
        return _FakeStreamResponse(lines=lines, status_code=200)


class _FakeXAIToolsAsyncClient:
    instances: List["_FakeXAIToolsAsyncClient"] = []

    def __init__(self, *args, **kwargs):
        self.stream_calls: List[Dict[str, Any]] = []
        self.post_calls: List[Dict[str, Any]] = []
        _FakeXAIToolsAsyncClient.instances.append(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, url: str, headers: Optional[Dict[str, str]] = None, json: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None):
        self.post_calls.append(
            {
                "url": url,
                "headers": dict(headers or {}),
                "json": dict(json or {}),
                "timeout": timeout,
            }
        )
        data = {
            "id": "resp_detect_tools_1",
            "usage": {"input_tokens": 12, "output_tokens": 7, "total_tokens": 19},
            "output": [
                {"type": "reasoning", "id": "rs_tools_1", "summary": [], "encrypted_content": "enc_tools_blob"},
                {"type": "web_search_call", "id": "ws_1", "query": "xai responses docs"},
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Tool-backed final answer"}],
                },
            ],
        }
        return _FakeHTTPResponse(status_code=200, data=data)

    def stream(self, method: str, url: str, headers: Optional[Dict[str, str]] = None, json: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None):
        self.stream_calls.append(
            {
                "method": method,
                "url": url,
                "headers": dict(headers or {}),
                "json": copy.deepcopy(dict(json or {})),
                "timeout": timeout,
            }
        )
        final_response = {
            "id": "resp_stream_tools_fallback",
            "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
            "output": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "fallback stream"}],
                },
            ],
        }
        lines = [
            "data: " + json_module.dumps({"type": "response.output_text.delta", "delta": "fallback stream"}),
            "data: " + json_module.dumps({"type": "response.completed", "response": final_response}),
            "data: [DONE]",
        ]
        return _FakeStreamResponse(lines=lines, status_code=200)


json_module = json


def _collect_completed_payload(client: TestClient, payload: Dict[str, Any]) -> Dict[str, Any]:
    r = client.post("/v0/chat/stream", json=payload)
    assert r.status_code == 200
    current_event: Optional[str] = None
    completed: Optional[Dict[str, Any]] = None
    for line in r.iter_lines():
        s = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if s.startswith("event:"):
            current_event = s[len("event:"):].strip()
        elif s.startswith("data:"):
            try:
                obj = json.loads(s[len("data:"):].strip())
            except Exception:
                obj = None
            if current_event == "message.completed" and isinstance(obj, dict):
                completed = obj
    assert completed is not None, "Did not receive message.completed payload"
    return completed


def _ensure_v0_router():
    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass
    return chat_router


def test_xai_completed_payload_includes_replay_state(monkeypatch):
    monkeypatch.setattr(settings, "XAI_API_KEY", "xai-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    chat_router = _ensure_v0_router()
    monkeypatch.setattr(chat_router.httpx, "AsyncClient", _FakeXAIAsyncClient)

    client = TestClient(app)
    payload = {
        "model": "grok-4",
        "messages": [{"role": "user", "content": "Hello"}],
        "enable_tools": False,
    }
    completed = _collect_completed_payload(client, payload)

    assert completed.get("xai_previous_response_id") == "resp_xai_1"
    assert completed.get("xai_response_ids") == ["resp_xai_1"]
    delta_items = completed.get("xai_delta_items")
    assert isinstance(delta_items, list) and delta_items
    assert any(isinstance(it, dict) and it.get("type") == "reasoning" for it in delta_items)
    assert any(isinstance(it, dict) and it.get("type") == "message" for it in delta_items)


def test_xai_stream_uses_client_supplied_input_items(monkeypatch):
    monkeypatch.setattr(settings, "XAI_API_KEY", "xai-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    chat_router = _ensure_v0_router()
    monkeypatch.setattr(chat_router.httpx, "AsyncClient", _FakeXAIAsyncClient)

    # Clear previous instances to make assertions deterministic.
    _FakeXAIAsyncClient.instances = []

    client = TestClient(app)
    native_items = [{"role": "user", "content": "authoritative native input"}]
    payload = {
        "model": "grok-4",
        "messages": [{"role": "user", "content": "fallback should not be used"}],
        "xai_input_items": native_items,
        "enable_tools": False,
    }
    _ = _collect_completed_payload(client, payload)

    assert _FakeXAIAsyncClient.instances, "Expected xAI AsyncClient to be instantiated"
    recorded = _FakeXAIAsyncClient.instances[-1].stream_calls
    assert recorded, "Expected at least one stream call"
    first_json = recorded[0].get("json") or {}
    assert first_json.get("input") == native_items


def test_xai_tools_mode_retains_provider_native_tool_items(monkeypatch):
    monkeypatch.setattr(settings, "XAI_API_KEY", "xai-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    chat_router = _ensure_v0_router()
    monkeypatch.setattr(chat_router.httpx, "AsyncClient", _FakeXAIToolsAsyncClient)

    _FakeXAIToolsAsyncClient.instances = []

    client = TestClient(app)
    payload = {
        "model": "grok-4",
        "messages": [{"role": "user", "content": "Find docs and summarize"}],
        "enable_tools": True,
    }
    completed = _collect_completed_payload(client, payload)

    assert completed.get("xai_previous_response_id") == "resp_detect_tools_1"
    delta_items = completed.get("xai_delta_items")
    assert isinstance(delta_items, list) and delta_items
    assert any(isinstance(it, dict) and it.get("type") == "web_search_call" for it in delta_items)
    assert _FakeXAIToolsAsyncClient.instances, "Expected xAI AsyncClient to be instantiated"
    assert not _FakeXAIToolsAsyncClient.instances[-1].stream_calls, "Tools path should not issue an extra final stream request"
