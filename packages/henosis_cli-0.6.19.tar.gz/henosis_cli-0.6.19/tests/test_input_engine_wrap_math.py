from henosis_cli_tools.input_engine import (
    _cursor_row_col_from_abs_cols,
    _visual_cursor_row_col,
    _visual_total_rows,
    _wrap_rows_for_line,
)


def test_wrap_rows_for_line_basic() -> None:
    # Empty line still occupies one row.
    assert _wrap_rows_for_line(0, offset=0, width=10) == 1
    # 1 char at col0 occupies one row.
    assert _wrap_rows_for_line(1, offset=0, width=10) == 1
    # 10 chars at col0 occupies one row under wrap-pending semantics.
    assert _wrap_rows_for_line(10, offset=0, width=10) == 1
    # But 10 chars starting at col5 must wrap.
    assert _wrap_rows_for_line(10, offset=5, width=10) == 2


def test_cursor_row_col_wrap_pending_margin() -> None:
    # Exactly at the right margin should keep cursor on the last column
    # (wrap pending), not jump to the next row.
    assert _cursor_row_col_from_abs_cols(10, width=10) == (0, 9)
    # One past the margin is row 1 col 1.
    assert _cursor_row_col_from_abs_cols(11, width=10) == (1, 1)


def test_visual_total_rows_accounts_for_soft_wrap_and_prompt() -> None:
    width = 10
    prompt_len = 5
    # First line uses 2 rows due to prompt offset.
    assert _visual_total_rows("1234567890", prompt_len=prompt_len, width=width) == 2
    # Newline adds another logical line (at least one row).
    assert _visual_total_rows("1234567890\nX", prompt_len=prompt_len, width=width) == 3


def test_visual_cursor_row_col_with_prompt_and_wrap() -> None:
    width = 10
    prompt_len = 5
    text = "1234567890"
    # Cursor at start sits after prompt on row 0.
    assert _visual_cursor_row_col(text, index=0, prompt_len=prompt_len, width=width) == (0, 5)
    # After 5 chars, still on first row at right margin.
    assert _visual_cursor_row_col(text, index=5, prompt_len=prompt_len, width=width) == (0, 9)
    # After 6 chars, wrapped to the next row.
    assert _visual_cursor_row_col(text, index=6, prompt_len=prompt_len, width=width) == (1, 1)
    # End position.
    assert _visual_cursor_row_col(text, index=len(text), prompt_len=prompt_len, width=width) == (1, 5)
