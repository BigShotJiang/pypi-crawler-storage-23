import signal

import pytest

from henosis_cli_tools import input_engine as ie


class _FakeUser32:
    def GetKeyState(self, _vk: int) -> int:
        return 0


class _FakeMsvcrt:
    def __init__(self, queue, handler_ref, inject_mode: str) -> None:
        self._queue = list(queue)
        self._handler_ref = handler_ref
        self._inject_mode = inject_mode
        self._sigint_fired = False
        self._inject_after_ctrl_a = False

    def kbhit(self) -> bool:
        if self._inject_mode == "immediate" and not self._sigint_fired:
            handler = self._handler_ref.get("handler")
            if callable(handler):
                handler(signal.SIGINT, None)
            self._sigint_fired = True
            return False
        if self._inject_mode == "after_ctrl_a" and self._inject_after_ctrl_a and not self._sigint_fired:
            handler = self._handler_ref.get("handler")
            if callable(handler):
                handler(signal.SIGINT, None)
            self._sigint_fired = True
            return False
        return bool(self._queue)

    def getwch(self) -> str:
        if not self._queue:
            raise AssertionError("getwch() called with empty queue")
        ch = self._queue.pop(0)
        if self._inject_mode == "after_ctrl_a" and ch == "\x01":
            self._inject_after_ctrl_a = True
        return ch


def _build_engine(fake_msvcrt: _FakeMsvcrt) -> ie.WindowsKeyEngine:
    engine = object.__new__(ie.WindowsKeyEngine)
    engine.msvcrt = fake_msvcrt
    engine.user32 = _FakeUser32()
    engine.VK_SHIFT = 0x10
    return engine


def _patch_signal(monkeypatch):
    original_handler = object()
    state = {"handler": None, "set_calls": []}

    def _fake_getsignal(sig):
        assert sig == signal.SIGINT
        return original_handler

    def _fake_signal(sig, handler):
        assert sig == signal.SIGINT
        state["handler"] = handler
        state["set_calls"].append(handler)
        return None

    monkeypatch.setattr(signal, "getsignal", _fake_getsignal)
    monkeypatch.setattr(signal, "signal", _fake_signal)
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)
    return original_handler, state


def test_windows_read_message_sigint_copies_when_select_all(monkeypatch):
    original_handler, signal_state = _patch_signal(monkeypatch)
    copied = []
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda txt: copied.append(txt) or True)

    fake_msvcrt = _FakeMsvcrt(["a", "b", "c", "\x01", "\r"], signal_state, inject_mode="after_ctrl_a")
    engine = _build_engine(fake_msvcrt)

    result = engine.read_message("You: ", "")

    assert result == "abc"
    assert copied == ["abc"]
    assert signal_state["handler"] is original_handler


def test_windows_read_message_sigint_raises_without_select_all(monkeypatch):
    original_handler, signal_state = _patch_signal(monkeypatch)
    copied = []
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda txt: copied.append(txt) or True)

    fake_msvcrt = _FakeMsvcrt([], signal_state, inject_mode="immediate")
    engine = _build_engine(fake_msvcrt)

    with pytest.raises(KeyboardInterrupt):
        engine.read_message("You: ", "")

    assert copied == []
    assert signal_state["handler"] is original_handler


def test_windows_read_message_left_right_insert(monkeypatch):
    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)

    # Type "abc", move left twice, insert "X", move right once, insert "Y".
    fake_msvcrt = _FakeMsvcrt(
        [
            "a",
            "b",
            "c",
            "\xe0",
            chr(75),  # Left
            "\xe0",
            chr(75),  # Left
            "X",
            "\xe0",
            chr(77),  # Right
            "Y",
            "\r",
        ],
        {"handler": None},
        inject_mode="none",
    )
    engine = _build_engine(fake_msvcrt)

    result = engine.read_message("You: ", "")

    assert result == "aXbYc"


def test_windows_read_message_delete_at_cursor(monkeypatch):
    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)

    # Type "abcd", move left twice, Delete removes "c".
    fake_msvcrt = _FakeMsvcrt(
        [
            "a",
            "b",
            "c",
            "d",
            "\xe0",
            chr(75),  # Left
            "\xe0",
            chr(75),  # Left
            "\xe0",
            chr(83),  # Delete
            "\r",
        ],
        {"handler": None},
        inject_mode="none",
    )
    engine = _build_engine(fake_msvcrt)

    result = engine.read_message("You: ", "")

    assert result == "abd"
