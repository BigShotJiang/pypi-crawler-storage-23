import app.routers.chat as chat_router


def test_openai_responses_backoff_prefers_function_call_output_removal():
    items = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_responses_handoff_input(
        conversation_items=items,
        user_text="handoff",
        apply_backoff=True,
    )
    assert items[-1]["type"] == "function_call_output"
    assert out[-1] == {"role": "user", "content": "handoff"}
    assert out[0] == {"role": "user", "content": "start"}
    assert len(out) == 2


def test_openai_compatible_backoff_prefers_tool_message_removal():
    messages = [
        {"role": "user", "content": "start"},
        {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "t1", "content": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_compatible_handoff_messages(
        messages=messages,
        user_text="handoff",
        apply_backoff=True,
    )
    assert messages[-1]["role"] == "tool"
    assert out[-1] == {"role": "user", "content": "handoff"}
    assert out[0] == {"role": "user", "content": "start"}
    assert len(out) == 2


def test_openai_overflow_action_includes_last_tool_and_args():
    items = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{\"path\":\"a.py\"}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]
    action = chat_router._overflow_action_with_openai_tool_context(
        {"code": "context_length_exceeded", "message": "too long"},
        items,
    )
    assert "code=context_length_exceeded" in action
    assert "tool=read_file" in action
    assert "args={\"path\":\"a.py\"}" in action


def test_anthropic_backoff_prefers_tool_result_block_removal():
    msgs = [
        {"role": "user", "content": [{"type": "text", "text": "start"}]},
        {"role": "assistant", "content": [{"type": "tool_use", "id": "t1", "name": "read_file", "input": {"path": "a.py"}}]},
        {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "ok"}]},
    ]
    out = chat_router._prepare_anthropic_handoff_messages(
        msgs=msgs,
        user_text="handoff",
        apply_backoff=True,
    )
    assert out[-1]["role"] == "user"
    assert out[-1]["content"][0]["text"] == "handoff"
    assert out[-2]["role"] == "assistant"


def test_gemini_backoff_prefers_function_response_removal():
    contents = [
        {"role": "user", "parts": [{"text": "start"}]},
        {"role": "model", "parts": [{"function_call": {"name": "read_file", "args": {"path": "a.py"}}}]},
        {"role": "user", "parts": [{"function_response": {"name": "read_file", "response": {"ok": True}}}]},
    ]
    out = chat_router._gemini_backoff_one_step(contents)
    assert len(out) == 2
    assert out[-1]["role"] == "model"


def test_openai_compatible_handoff_usage_normalizes_prompt_completion_fields():
    usage = {"prompt_tokens": 11, "completion_tokens": 4}
    norm = chat_router._openai_compatible_handoff_usage(usage)
    assert norm == {"input_tokens": 11, "output_tokens": 4, "total_tokens": 15}
