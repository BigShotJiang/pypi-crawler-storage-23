import os


def test_windows_normalize_and_strip_wrapping_quotes_basic():
    # Import directly from implementation module (internal helper).
    from henosis_cli_tools import tool_impl as ti

    assert ti._windows_normalize_and_strip_wrapping_quotes('"fastapi"') == "fastapi"
    assert ti._windows_normalize_and_strip_wrapping_quotes("'fastapi'") == "fastapi"

    # Smart quotes commonly copied from docs / chat UIs.
    assert ti._windows_normalize_and_strip_wrapping_quotes("\u201cfastapi\u201d") == "fastapi"


def test_windows_sanitize_argv_noop_on_posix():
    from henosis_cli_tools import tool_impl as ti

    parts = ["rg", '"fastapi"']
    out, changed = ti._windows_sanitize_argv(parts)

    if os.name != "nt":
        assert out == parts
        assert changed is False


def test_run_command_argv_sanitized_metadata_on_windows():
    """When cmd parsing produces argv entries with wrapping quotes on Windows,
    run_command should strip the wrapping quotes and report argv_sanitized=True.
    """
    if os.name != "nt":
        return

    from henosis_cli_tools import tool_impl as ti

    pol = ti.FileToolPolicy(scope="workspace")

    # If the quotes are not stripped, python will execute a string literal and print nothing.
    # If the quotes ARE stripped, python executes print(123) and prints "123".
    # In this cmd string, we intentionally pass literal quote chars into the -c argument.
    # If the quotes are not stripped, python will execute a string literal and print nothing.
    # If the quotes ARE stripped, python executes print(123) and prints "123".
    res = ti.run_command(
        cmd='python -c "\\"print(123)\\""',
        policy=pol,
        cwd=".",
        timeout=30,
        allow_commands_csv="*",
    )

    assert res["ok"] is True
    d = res["data"]
    assert d["exit_code"] == 0
    assert d.get("argv_sanitized") is True
    assert "windows.strip_wrapping_quotes" in str(d.get("parse_method"))
    assert d.get("stdout", "").strip() == "123"
