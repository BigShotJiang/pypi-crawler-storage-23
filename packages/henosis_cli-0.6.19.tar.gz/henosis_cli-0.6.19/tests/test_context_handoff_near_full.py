import app.routers.chat as chat_router


def test_near_full_provider_usage_takes_priority():
    near = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=120000,
        prompt_obj="tiny prompt",
    )
    assert near is not None
    assert near.get("source") == "provider_usage"


def test_near_full_estimator_fallback_when_usage_missing():
    large_prompt = "x" * 500000
    near = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=0,
        prompt_obj=large_prompt,
    )
    assert near is not None
    assert near.get("source") == "estimator_fallback"


def test_near_full_none_when_below_threshold():
    near = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=1000,
        prompt_obj="short prompt",
    )
    assert near is None


def test_near_full_threshold_uses_settings(monkeypatch):
    # 120k / 128k ~= 93.75%
    monkeypatch.setattr(chat_router.settings, "CONTEXT_NEAR_FULL_PCT", 0.99, raising=False)
    near_high = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=120000,
        prompt_obj="tiny prompt",
    )
    assert near_high is None

    monkeypatch.setattr(chat_router.settings, "CONTEXT_NEAR_FULL_PCT", 0.90, raising=False)
    near_low = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=120000,
        prompt_obj="tiny prompt",
    )
    assert near_low is not None


def test_near_full_threshold_request_override_wins(monkeypatch):
    # settings threshold would not trigger, request override should trigger
    monkeypatch.setattr(chat_router.settings, "CONTEXT_NEAR_FULL_PCT", 0.99, raising=False)
    near = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=120000,
        prompt_obj="tiny prompt",
        threshold_override=0.90,
    )
    assert near is not None


def test_near_full_threshold_override_accepts_percent_string(monkeypatch):
    monkeypatch.setattr(chat_router.settings, "CONTEXT_NEAR_FULL_PCT", 0.99, raising=False)
    near = chat_router._near_full_from_provider_or_estimate(
        model_name="deepseek-chat",
        used_total_tokens=120000,
        prompt_obj="tiny prompt",
        threshold_override="95%",
    )
    assert near is None


def test_near_full_threshold_label_includes_default_when_overridden(monkeypatch):
    monkeypatch.setattr(chat_router.settings, "CONTEXT_NEAR_FULL_PCT", 0.85, raising=False)
    label = chat_router._near_full_threshold_label(0.90)
    assert "90%" in label
    assert "default 85%" in label


def test_openai_responses_backoff_removes_tool_result_and_call_pair():
    items = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_responses_handoff_input(
        conversation_items=items,
        user_text="handoff",
        apply_backoff=True,
    )
    assert out == [
        {"role": "user", "content": "start"},
        {"role": "user", "content": "handoff"},
    ]


def test_openai_compatible_backoff_removes_tool_result_and_call_pair():
    messages = [
        {"role": "user", "content": "start"},
        {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "t1", "content": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_compatible_handoff_messages(
        messages=messages,
        user_text="handoff",
        apply_backoff=True,
    )
    assert out == [
        {"role": "user", "content": "start"},
        {"role": "user", "content": "handoff"},
    ]


def test_overflow_action_with_openai_tool_context_includes_tool_and_args():
    items = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{\"path\":\"a.py\"}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]
    action = chat_router._overflow_action_with_openai_tool_context(
        {"code": "context_length_exceeded", "message": "too long"},
        items,
    )
    assert "code=context_length_exceeded" in action
    assert "tool=read_file" in action
    assert "args={\"path\":\"a.py\"}" in action


def test_openai_responses_backoff_removes_prepended_reasoning_with_tool_pair():
    items = [
        {"role": "user", "content": "start"},
        {"type": "reasoning", "id": "rs_1", "summary": []},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_responses_handoff_input(
        conversation_items=items,
        user_text="handoff",
        apply_backoff=True,
    )
    assert out == [
        {"role": "user", "content": "start"},
        {"role": "user", "content": "handoff"},
    ]


def test_openai_responses_backoff_fallback_removes_reasoning_before_trailing_function_call():
    # call_id missing on both records -> fallback path should still remove call + prepended reasoning.
    items = [
        {"role": "user", "content": "start"},
        {"type": "reasoning", "id": "rs_2", "summary": []},
        {"type": "function_call", "name": "read_file", "arguments": "{}"},
        {"type": "function_call_output", "output": "{\"ok\":true}"},
    ]
    out = chat_router._prepare_openai_responses_handoff_input(
        conversation_items=items,
        user_text="handoff",
        apply_backoff=True,
    )
    assert out == [
        {"role": "user", "content": "start"},
        {"role": "user", "content": "handoff"},
    ]
