import asyncio
import shutil
import tempfile
from pathlib import Path

import app.routers.chat as chat_router
from app.tools.file_tools import FileToolPolicy


def _new_workspace() -> Path:
    root = Path("workspace/.tmp_tests")
    root.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix="context-handoff-probe-", dir=str(root)))


def test_handoff_includes_codeword_keep_notes_and_prompt():
    ws = _new_workspace()
    try:
        policy = FileToolPolicy(scope="workspace", workspace_base=ws)
        codeword = "ALBATROSS-77"
        keep_notes = f"{codeword}: checkpoint for resume"

        def fake_request(_user_text: str):
            return {
                "call_id": "probe-call",
                "args_obj": {
                    "reason": "near_full",
                    "keep_notes": keep_notes,
                    "keep_files": [],
                },
                "usage": {},
                "raw_response_meta": {"probe": True},
            }

        out = asyncio.run(
            chat_router._attempt_context_handoff(
                reason="near_full",
                overflow_action=None,
                request_forced_context_handoff=fake_request,
                file_policy=policy,
            )
        )

        assert out is not None
        assert codeword in str(out.get("resume_prompt", ""))
        handoff_prompt = str(out.get("handoff_prompt", ""))
        assert "reason='near_full'" in handoff_prompt
        assert keep_notes == str(out.get("handoff_keep_notes", ""))
        assert out.get("handoff_keep_notes_injected") is True

        tool_result = out.get("tool_result") or {}
        assert bool(tool_result.get("ok")) is True
        assert handoff_prompt == str(tool_result.get("handoff_prompt", ""))
        data = tool_result.get("data") or {}
        assert handoff_prompt == str(data.get("handoff_prompt", ""))
        assert keep_notes == str(data.get("handoff_keep_notes", ""))
        assert data.get("handoff_keep_notes_injected") is True
    finally:
        shutil.rmtree(ws, ignore_errors=True)


def test_handoff_prompt_contains_overflow_action_for_reactive():
    ws = _new_workspace()
    try:
        policy = FileToolPolicy(scope="workspace", workspace_base=ws)

        def fake_request(_user_text: str):
            return {
                "call_id": "probe-call-2",
                "args_obj": {
                    "reason": "context_length_exceeded",
                    "keep_notes": "reactive checkpoint",
                    "keep_files": [],
                },
                "usage": {},
                "raw_response_meta": {"probe": True},
            }

        out = asyncio.run(
            chat_router._attempt_context_handoff(
                reason="context_length_exceeded",
                overflow_action="code=context_length_exceeded; message=too long",
                request_forced_context_handoff=fake_request,
                file_policy=policy,
            )
        )

        assert out is not None
        handoff_prompt = str(out.get("handoff_prompt", ""))
        assert "reason='context_length_exceeded'" in handoff_prompt
        assert "Action that overflowed context:" in handoff_prompt
        assert "code=context_length_exceeded" in handoff_prompt
    finally:
        shutil.rmtree(ws, ignore_errors=True)


def test_near_full_with_tiny_window_triggers_estimator_fallback(monkeypatch):
    original = dict(chat_router._MODEL_CONTEXT_WINDOWS)
    try:
        monkeypatch.setitem(chat_router._MODEL_CONTEXT_WINDOWS, "gpt-5.2", 100)
        near = chat_router._near_full_from_provider_or_estimate(
            model_name="gpt-5.2",
            used_total_tokens=0,
            prompt_obj=("x" * 600),
        )
        assert near is not None
        assert near.get("source") == "estimator_fallback"
        assert float(near.get("ratio", 0.0)) >= 0.85
    finally:
        chat_router._MODEL_CONTEXT_WINDOWS.clear()
        chat_router._MODEL_CONTEXT_WINDOWS.update(original)
