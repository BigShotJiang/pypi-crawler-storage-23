import shutil
import tempfile
from pathlib import Path

from app.tools.file_tools import FileToolPolicy, context_handoff_tool


def _new_workspace() -> Path:
    root = Path("workspace/.tmp_tests")
    root.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix="context-handoff-", dir=str(root)))


def test_context_handoff_requires_non_empty_keep_notes():
    ws = _new_workspace()
    try:
        pol = FileToolPolicy(scope="workspace", workspace_base=ws)
        out = context_handoff_tool(
            {"reason": "near_full", "keep_notes": "   ", "keep_files": []},
            pol,
        )
        assert out.get("ok") is False
        assert "keep_notes is required" in str(out.get("error", ""))
    finally:
        shutil.rmtree(ws, ignore_errors=True)


def test_context_handoff_normalizes_keep_files_and_no_memory_path():
    ws = _new_workspace()
    try:
        pol = FileToolPolicy(scope="workspace", workspace_base=ws)
        out = context_handoff_tool(
            {
                "reason": "context_length_exceeded",
                "keep_notes": "continue from here",
                "keep_files": ["a.py", "", "a.py", " b.py ", 123, None],
            },
            pol,
        )
        assert out.get("ok") is True
        data = out.get("data") or {}
        assert isinstance(data.get("handoff_id"), str) and data.get("handoff_id")
        assert data.get("reason") == "context_length_exceeded"
        assert data.get("keep_files") == ["a.py", "b.py"]
        assert "memory_path" not in data
        stats = data.get("resume_context_stats") or {}
        assert stats.get("keep_notes_chars") == len("continue from here")
        assert stats.get("keep_files_count") == 2
    finally:
        shutil.rmtree(ws, ignore_errors=True)
