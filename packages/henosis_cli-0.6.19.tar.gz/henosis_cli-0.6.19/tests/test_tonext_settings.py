def test_legacy_tonext_settings_removed():
    from app.settings import settings

    assert not hasattr(settings, "ANTHROPIC_ENABLE_TONEXT_TOOL")
    assert not hasattr(settings, "ANTHROPIC_TONEXT_TOOL_NAME")
    assert not hasattr(settings, "ANTHROPIC_TONEXT_ATTACH_BETA")
    assert not hasattr(settings, "ANTHROPIC_TONEXT_BETA_HEADER")
    assert not hasattr(settings, "ANTHROPIC_TONEXT_ENABLE_MEMORY_TOOL")
    assert not hasattr(settings, "ANTHROPIC_TONEXT_MEMORY_DIR")
