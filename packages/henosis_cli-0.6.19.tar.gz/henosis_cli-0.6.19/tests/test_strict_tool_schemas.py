from app.tools.file_tools import FILE_TOOLS


def test_strict_tools_require_all_properties():
    """Strict tool schemas must list every property in `required`.

    This matches provider validation rules for strict function tools and
    prevents runtime 400s like:
    invalid_function_parameters (missing key from required array).
    """
    for tool in FILE_TOOLS:
        if not isinstance(tool, dict) or tool.get("type") != "function":
            continue
        if not bool(tool.get("strict")):
            continue

        params = tool.get("parameters") or {}
        props = params.get("properties") or {}
        required = params.get("required")

        assert isinstance(props, dict), f"{tool.get('name')}: properties must be an object"
        assert isinstance(required, list), f"{tool.get('name')}: required must be a list"
        assert set(required) == set(props.keys()), (
            f"{tool.get('name')}: strict schema required mismatch; "
            f"required={required}, properties={list(props.keys())}"
        )
