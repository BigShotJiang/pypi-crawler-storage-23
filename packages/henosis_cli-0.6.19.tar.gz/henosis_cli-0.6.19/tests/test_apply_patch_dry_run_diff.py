from pathlib import Path

import henosis_cli_tools.tool_impl as tool_impl
from henosis_cli_tools import FileToolPolicy, apply_patch


def _workspace_policy(base: Path) -> FileToolPolicy:
    return FileToolPolicy(scope="workspace", workspace_base=base)


def test_apply_patch_dry_run_update_includes_unified_diff(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir(parents=True, exist_ok=True)
    (ws / "demo.txt").write_text("one\ntwo\nthree\n", encoding="utf-8")
    pol = _workspace_policy(ws)

    patch = "\n".join(
        [
            "*** Begin Patch",
            "*** Update File: demo.txt",
            "@@",
            " one",
            "-two",
            "+TWO",
            " three",
            "*** End Patch",
        ]
    )
    res = apply_patch(patch=patch, policy=pol, cwd=".", dry_run=True)
    assert res["ok"], res

    data = res["data"]
    detail = data["details"][0]
    diff = detail.get("diff") or ""
    assert "--- " in diff and "+++ " in diff
    assert "-two" in diff
    assert "+TWO" in diff
    assert int(detail.get("lines_added", 0)) >= 1
    assert int(detail.get("lines_removed", 0)) >= 1
    assert int((data.get("diff_stats") or {}).get("lines_added", 0)) >= 1
    assert int((data.get("diff_stats") or {}).get("lines_removed", 0)) >= 1


def test_apply_patch_dry_run_add_includes_diff_and_stats(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir(parents=True, exist_ok=True)
    pol = _workspace_policy(ws)

    patch = "\n".join(
        [
            "*** Begin Patch",
            "*** Add File: new_file.txt",
            "+alpha",
            "+beta",
            "*** End Patch",
        ]
    )
    res = apply_patch(patch=patch, policy=pol, cwd=".", dry_run=True)
    assert res["ok"], res

    data = res["data"]
    detail = data["details"][0]
    assert detail.get("action") == "A"
    diff = detail.get("diff") or ""
    assert "+++ " in diff
    assert "+alpha" in diff
    assert "+beta" in diff
    assert int(detail.get("lines_added", 0)) >= 2
    assert int((data.get("diff_stats") or {}).get("files_changed", 0)) >= 1


def test_apply_patch_dry_run_delete_includes_diff_and_stats(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir(parents=True, exist_ok=True)
    (ws / "remove_me.txt").write_text("a\nb\n", encoding="utf-8")
    pol = _workspace_policy(ws)

    patch = "\n".join(
        [
            "*** Begin Patch",
            "*** Delete File: remove_me.txt",
            "*** End Patch",
        ]
    )
    res = apply_patch(patch=patch, policy=pol, cwd=".", dry_run=True)
    assert res["ok"], res

    data = res["data"]
    detail = data["details"][0]
    assert detail.get("action") == "D"
    diff = detail.get("diff") or ""
    assert "--- " in diff
    assert "-a" in diff
    assert int(detail.get("lines_removed", 0)) >= 2
    assert int((data.get("diff_stats") or {}).get("lines_removed", 0)) >= 2


def test_apply_patch_dry_run_move_reflects_rename_in_diff_headers(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir(parents=True, exist_ok=True)
    (ws / "old_name.txt").write_text("hello\nworld\n", encoding="utf-8")
    pol = _workspace_policy(ws)

    patch = "\n".join(
        [
            "*** Begin Patch",
            "*** Update File: old_name.txt",
            "*** Move to: new_name.txt",
            "@@",
            " hello",
            "-world",
            "+WORLD",
            "*** End Patch",
        ]
    )
    res = apply_patch(patch=patch, policy=pol, cwd=".", dry_run=True)
    assert res["ok"], res

    data = res["data"]
    detail = data["details"][0]
    diff = detail.get("diff") or ""
    assert "old_name.txt" in diff
    assert "new_name.txt" in diff
    assert detail.get("moved")


def test_apply_patch_dry_run_diff_truncation_metadata(tmp_path: Path, monkeypatch):
    ws = tmp_path / "ws"
    ws.mkdir(parents=True, exist_ok=True)
    pol = _workspace_policy(ws)

    monkeypatch.setattr(tool_impl, "_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_PER_FILE", 100)
    monkeypatch.setattr(tool_impl, "_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL", 100)

    patch_lines = ["*** Begin Patch", "*** Add File: big.txt"]
    for i in range(30):
        patch_lines.append(f"+line-{i:02d}-abcdefghijklmnopqrstuvwxyz")
    patch_lines.append("*** End Patch")
    patch = "\n".join(patch_lines)

    res = tool_impl.apply_patch(patch=patch, policy=pol, cwd=".", dry_run=True)
    assert res["ok"], res
    detail = res["data"]["details"][0]
    assert bool(detail.get("diff_truncated")) is True
    pol_meta = detail.get("diff_truncation_policy") or {}
    assert int(pol_meta.get("original_chars", 0)) > int(pol_meta.get("kept_chars", 0))
    assert "diff" in detail
