import pytest


from app.routers.chat import (
    _responses_output_items,
    _responses_output_text_from_items,
    _responses_function_calls_from_items,
    _responses_usage_from_data,
)


def test_responses_output_text_from_items_extracts_output_text():
    data = {
        "id": "resp_123",
        "output": [
            {
                "type": "message",
                "role": "assistant",
                "content": [
                    {"type": "output_text", "text": "Hello"},
                    {"type": "output_text", "text": ", world"},
                ],
            }
        ],
    }
    items = _responses_output_items(data)
    assert _responses_output_text_from_items(items) == "Hello, world"


def test_responses_function_calls_from_items_extracts_function_call_items():
    data = {
        "id": "resp_123",
        "output": [
            {"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": "..."}]},
            {"type": "function_call", "call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"README.md\"}"},
            {"type": "function_call", "call_id": "call_2", "name": "run_command", "arguments": "{\"cmd\":\"echo hi\",\"cwd\":\".\"}"},
        ],
    }
    items = _responses_output_items(data)
    calls = _responses_function_calls_from_items(items)
    assert calls == [
        {"call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"README.md\"}"},
        {"call_id": "call_2", "name": "run_command", "arguments": "{\"cmd\":\"echo hi\",\"cwd\":\".\"}"},
    ]


def test_responses_function_calls_from_items_accepts_tool_call_alias_and_dict_args():
    data = {
        "id": "resp_456",
        "output": [
            {
                "type": "tool_call",
                "tool_call_id": "tc_1",
                "function": {"name": "search_web", "arguments": {"q": "xai docs"}},
            }
        ],
    }
    items = _responses_output_items(data)
    calls = _responses_function_calls_from_items(items)
    assert calls == [
        {"call_id": "tc_1", "name": "search_web", "arguments": "{\"q\": \"xai docs\"}"},
    ]


def test_responses_usage_from_data_normalizes_usage_tokens():
    assert _responses_usage_from_data({"usage": {"input_tokens": 10, "output_tokens": 20, "total_tokens": 31}}) == {
        "input_tokens": 10,
        "output_tokens": 20,
        "total_tokens": 31,
    }
    # missing total => compute
    assert _responses_usage_from_data({"usage": {"input_tokens": 10, "output_tokens": 20}}) == {
        "input_tokens": 10,
        "output_tokens": 20,
        "total_tokens": 30,
    }
    # bad shapes => zeros
    assert _responses_usage_from_data({}) == {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
