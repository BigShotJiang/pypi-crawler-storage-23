"""Setuptools shim for custom wheel tagging.

We ship platform-specific helper binaries (e.g., ripgrep) as package data under
henosis_cli_tools/_vendor.

Even though the project is "pure Python" from an extension-module standpoint,
the resulting wheel *must* be platform-tagged so that:
  - PyPI can host distinct wheels per OS/arch, and
  - pip will never install (for example) a Windows wheel on Linux.

This file keeps all metadata in pyproject.toml (PEP 621) and only customizes
bdist_wheel tagging.
"""

from __future__ import annotations

from setuptools import setup


def _cmdclass():
    try:
        from wheel.bdist_wheel import bdist_wheel as _bdist_wheel  # type: ignore
    except Exception:
        return {}

    class bdist_wheel(_bdist_wheel):  # type: ignore
        def finalize_options(self) -> None:  # noqa: D401
            super().finalize_options()
            # Ensure wheel is not tagged as "any".
            self.root_is_pure = False

        def get_tag(self):  # noqa: D401
            py, abi, plat = super().get_tag()
            # This package is compatible with any Python 3 (>=3.9) because it has
            # no compiled extensions. Only the *platform* varies due to vendored
            # binaries.
            return "py3", "none", plat

    return {"bdist_wheel": bdist_wheel}


setup(cmdclass=_cmdclass())
