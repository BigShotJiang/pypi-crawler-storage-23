"""Skill validation helpers.

Author:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Final

from aip_agents.skills.errors import SkillValidationError

_SKILL_NAME_RE: Final[re.Pattern[str]] = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
_SKILL_NAME_MAX_LEN: Final[int] = 64


def validate_skill_name(name: str) -> None:
    """Validate a skill name against DeepAgents naming rules.

    Args:
        name (str): Skill directory name.

    Returns:
        None: This function returns None.
    """
    if not name or len(name) > _SKILL_NAME_MAX_LEN or _SKILL_NAME_RE.fullmatch(name) is None:
        raise SkillValidationError(
            "Invalid skill name. Expected lowercase alphanumerics with single hyphens "
            f"(max {_SKILL_NAME_MAX_LEN} chars): {name!r}."
        )


def validate_skill_root(skill_root: Path) -> None:
    """Validate a local skill root directory.

    Args:
        skill_root (Path): Local path to the skill directory.

    Returns:
        None: This function returns None.
    """
    if not skill_root.exists():
        raise SkillValidationError(f"Skill path does not exist: {skill_root}.")
    if not skill_root.is_dir():
        raise SkillValidationError(f"Skill path is not a directory: {skill_root}.")

    validate_skill_name(skill_root.name)

    skill_md_path = skill_root / "SKILL.md"
    if not skill_md_path.is_file():
        raise SkillValidationError(f"Missing required SKILL.md at: {skill_md_path}.")
