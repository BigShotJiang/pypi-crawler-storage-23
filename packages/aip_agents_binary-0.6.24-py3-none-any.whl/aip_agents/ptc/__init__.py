"""PTC (Programmatic Tool Calling) core module.

This module provides core PTC functionality, including executor, prompt builder,
sandbox bridge, and custom tool configuration validation.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from aip_agents.ptc.custom_tools import (
    PTCCustomToolConfig,
    PTCCustomToolValidationError,
    PTCFileToolDef,
    PTCPackageToolDef,
    PTCToolDef,
    enrich_tool_def_with_metadata,
    extract_tool_metadata,
    validate_custom_tool_config,
)
from aip_agents.ptc.custom_tools_payload import (
    CustomToolPayloadResult,
    build_custom_tools_payload,
)
from aip_agents.ptc.exceptions import PTCError, PTCToolError
from aip_agents.ptc.prompt_builder import PromptConfig, build_ptc_prompt, compute_ptc_prompt_hash
from aip_agents.ptc.tool_def_helpers import file_tool, package_tool
from aip_agents.ptc.tool_enrichment import (
    build_tool_lookup,
    enrich_custom_tools_from_agent,
    match_tool_by_name,
)

__all__ = [
    # Exceptions
    "PTCError",
    "PTCToolError",
    "PTCCustomToolValidationError",
    # Executor
    "PTCSandboxConfig",
    "PTCSandboxExecutor",
    # Custom tools
    "PTCCustomToolConfig",
    "PTCToolDef",
    "PTCPackageToolDef",
    "PTCFileToolDef",
    "validate_custom_tool_config",
    "extract_tool_metadata",
    "enrich_tool_def_with_metadata",
    # Tool enrichment
    "build_tool_lookup",
    "match_tool_by_name",
    "enrich_custom_tools_from_agent",
    # Tool definition helpers
    "package_tool",
    "file_tool",
    # Custom tools payload
    "CustomToolPayloadResult",
    "build_custom_tools_payload",
    # Prompt builder
    "PromptConfig",
    "build_ptc_prompt",
    "compute_ptc_prompt_hash",
    # Sandbox bridge
    "build_sandbox_payload",
    "wrap_ptc_code",
]


def __getattr__(name: str):
    """Lazy import to avoid circular dependencies."""
    if name == "PTCSandboxConfig":
        from aip_agents.ptc.executor import PTCSandboxConfig

        return PTCSandboxConfig
    elif name == "PTCSandboxExecutor":
        from aip_agents.ptc.executor import PTCSandboxExecutor

        return PTCSandboxExecutor
    elif name == "build_sandbox_payload":
        from aip_agents.ptc.sandbox_bridge import build_sandbox_payload

        return build_sandbox_payload
    elif name == "wrap_ptc_code":
        from aip_agents.ptc.sandbox_bridge import wrap_ptc_code

        return wrap_ptc_code
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
