"""Templates for custom LangChain tool payload generation."""
