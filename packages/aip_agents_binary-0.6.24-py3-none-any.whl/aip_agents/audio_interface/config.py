"""Typed config objects for audio sessions."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any

from aip_agents.audio_interface.errors import AudioConfigError

_ENV_REF_RE = re.compile(r"^\$\{([A-Z0-9_]+)\}$")


def _resolve_env_ref(value: str | None) -> str | None:
    if value is None:
        return None
    m = _ENV_REF_RE.match(value.strip())
    if not m:
        return value
    return os.environ.get(m.group(1))


@dataclass(frozen=True, slots=True)
class AudioIOConfig:
    """I/O toggles and device hints for an audio session."""

    input_enabled: bool = True
    output_enabled: bool = True
    input_device: str | None = None
    output_device: str | None = None


@dataclass(frozen=True, slots=True)
class AudioModelConfig:
    """Model selection for provider-specific audio components.

    For OpenAI STT/TTS wiring in the LiveKit provider:
      provider="openai", voice="echo"
    """

    provider: str | None = None
    model: str | None = None
    voice: str | None = None
    credentials: str | None = None


@dataclass(frozen=True, slots=True)
class LiveKitConfig:
    """Connection and provider configuration for LiveKit audio sessions."""

    url: str
    api_key: str | None = None
    api_secret: str | None = None
    room_name: str | None = None
    identity: str | None = None

    # Optional: OpenAI STT/TTS via livekit-plugins-openai
    openai_stt_model: str | None = None
    openai_tts_model: str | None = None
    openai_voice: str | None = None
    openai_use_realtime_stt: bool = True
    openai_api_key: str | None = None
    openai_base_url: str | None = None

    def resolve_api_key(self) -> str:
        """Resolve the LiveKit API key from config/env."""
        val = _resolve_env_ref(self.api_key) or os.environ.get("LIVEKIT_API_KEY")
        if not val:
            raise AudioConfigError("LIVEKIT_API_KEY missing")
        return val

    def resolve_api_secret(self) -> str:
        """Resolve the LiveKit API secret from config/env."""
        val = _resolve_env_ref(self.api_secret) or os.environ.get("LIVEKIT_API_SECRET")
        if not val:
            raise AudioConfigError("LIVEKIT_API_SECRET missing")
        return val

    def resolve_openai_api_key(self) -> str:
        """Resolve OpenAI API key used by livekit-plugins-openai."""
        val = _resolve_env_ref(self.openai_api_key) or os.environ.get("OPENAI_API_KEY")
        if not val:
            raise AudioConfigError("OPENAI_API_KEY missing (required for OpenAI STT/TTS)")
        return val


@dataclass(frozen=True, slots=True)
class AudioSessionConfig:
    """Top-level audio session config as used by the audio interface."""

    provider: str = "livekit"
    io: AudioIOConfig = AudioIOConfig()
    model: AudioModelConfig | None = None
    provider_config: LiveKitConfig | dict[str, Any] | None = None

    @staticmethod
    def from_agent_config_audio(raw: dict[str, Any]) -> AudioSessionConfig:
        """Parse the `agent_config.audio` section into a typed config."""
        if not isinstance(raw, dict):
            raise AudioConfigError("agent_config.audio must be a dict")

        provider = raw.get("provider") or "livekit"
        io_raw = raw.get("io") or {}
        io = AudioIOConfig(
            input_enabled=bool(io_raw.get("input_enabled", True)),
            output_enabled=bool(io_raw.get("output_enabled", True)),
            input_device=io_raw.get("input_device"),
            output_device=io_raw.get("output_device"),
        )

        model_raw = raw.get("model")
        model: AudioModelConfig | None = None
        if isinstance(model_raw, dict):
            model = AudioModelConfig(
                provider=model_raw.get("provider"),
                model=model_raw.get("model"),
                voice=model_raw.get("voice"),
                credentials=model_raw.get("credentials"),
            )

        provider_cfg: LiveKitConfig | dict[str, Any] | None = None
        if provider in {"livekit", "livekit_realtime"}:
            lk = raw.get(provider) or raw.get("livekit")
            if not isinstance(lk, dict):
                raise AudioConfigError(f"{provider}.url is required")
            url = lk.get("url")
            if not url:
                raise AudioConfigError(f"{provider}.url is required")
            provider_cfg = LiveKitConfig(
                url=str(url),
                api_key=lk.get("api_key"),
                api_secret=lk.get("api_secret"),
                room_name=lk.get("room_name"),
                identity=lk.get("identity"),
                openai_stt_model=lk.get("openai_stt_model"),
                openai_tts_model=lk.get("openai_tts_model"),
                openai_voice=lk.get("openai_voice"),
                openai_use_realtime_stt=bool(lk.get("openai_use_realtime_stt", True)),
                openai_api_key=lk.get("openai_api_key"),
                openai_base_url=lk.get("openai_base_url"),
            )
        elif isinstance(raw.get(provider), dict):
            provider_cfg = dict(raw[provider])

        return AudioSessionConfig(provider=provider, io=io, model=model, provider_config=provider_cfg)
