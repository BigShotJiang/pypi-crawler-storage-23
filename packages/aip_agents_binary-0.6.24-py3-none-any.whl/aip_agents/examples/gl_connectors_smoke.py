"""Smoke test for GL Connectors integration.

This script is meant for manual verification against a real GL Connectors environment.
It prints the tool schema to help you discover the required parameters, then optionally
invokes the tool with JSON input you provide.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from aip_agents.tools.gl_connector import GLConnectorTool

_REQUIRED_ENV_VARS: tuple[str, ...] = (
    "GL_CONNECTORS_BASE_URL",
    "GL_CONNECTORS_API_KEY",
    "GL_CONNECTORS_USERNAME",
    "GL_CONNECTORS_PASSWORD",
)


def _get_schema(tool: Any) -> dict[str, Any] | None:
    args_schema = getattr(tool, "args_schema", None)
    if args_schema is None:
        return None

    if isinstance(args_schema, dict):
        return args_schema

    model_json_schema = getattr(args_schema, "model_json_schema", None)
    if callable(model_json_schema):
        return model_json_schema()

    return None


def _parse_json_arg(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    if not isinstance(parsed, dict):
        raise ValueError("Tool input must be a JSON object.")
    return parsed


def _require_env() -> None:
    missing = [key for key in _REQUIRED_ENV_VARS if not os.getenv(key)]
    if not missing:
        return

    print("Missing required environment variables:", ", ".join(missing), file=sys.stderr)
    print(
        "Tip: export GL_CONNECTORS_BASE_URL, GL_CONNECTORS_API_KEY, GL_CONNECTORS_USERNAME, GL_CONNECTORS_PASSWORD",
        file=sys.stderr,
    )
    raise SystemExit(2)


def main(argv: list[str] | None = None) -> int:
    """Run the smoke test for GL Connectors integration.

    Args:
        argv: Command line arguments. If None, uses sys.argv.

    Returns:
        Exit code (0 for success, non-zero for error).
    """
    parser = argparse.ArgumentParser(description="Manual smoke test for GLConnectorTool.")
    parser.add_argument(
        "--tool-name",
        default=os.getenv("GL_CONNECTORS_SMOKE_TOOL_NAME", "arxiv_search_papers_tool"),
        help="Exact connector tool name.",
    )
    parser.add_argument(
        "--tool-input-json",
        default=os.getenv("GL_CONNECTORS_SMOKE_TOOL_INPUT_JSON"),
        help="JSON object to pass into tool.invoke(...).",
    )
    parser.add_argument(
        "--print-schema-only",
        action="store_true",
        help="Print args schema and exit without invoking.",
    )
    args = parser.parse_args(argv)

    _require_env()

    tool = GLConnectorTool(args.tool_name)
    schema = _get_schema(tool)
    print(f"Tool: {getattr(tool, 'name', args.tool_name)}")
    if schema is not None:
        print("Args schema (JSON):")
        print(json.dumps(schema, indent=2, sort_keys=True))
    else:
        print("Args schema: <unavailable>")

    if args.print_schema_only:
        return 0

    if not args.tool_input_json:
        print(
            "No input provided. Re-run with --tool-input-json '{...}' or set GL_CONNECTORS_SMOKE_TOOL_INPUT_JSON.",
            file=sys.stderr,
        )
        return 2

    tool_input = _parse_json_arg(args.tool_input_json)
    result = tool.invoke(tool_input)
    print("Result:")
    if isinstance(result, dict | list):
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
