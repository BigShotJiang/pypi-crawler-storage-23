"""Base protocol and types for agent middleware.

This module defines the core AgentMiddleware protocol that all middleware components
must implement, along with the ModelRequest type for model invocations.


Architecture Overview
---------------------

The middleware system has two layers:

1. AgentMiddleware Protocol (this file)
   - Defines the interface that individual middleware classes implement
   - Each middleware provides hooks and can define tools/system prompts
   - Example: MemoryMiddleware implements before_run/after_run for recall/persistence

2. MiddlewareManager (manager.py)
   - Orchestrates multiple middleware instances
   - Calls hooks on ALL registered middleware in order
   - Handles errors and merges results
   - Used by agents to interact with the middleware stack


Middleware Hook Execution Flow
------------------------------

    Agent.arun(query)  ←── Start of agent run
      │
      ▼
    [abefore_run]  ←── Run-level: once per run (memory recall, audit start)
      │
      ▼
    Prepare graph input
      │
      ▼
    LangGraph execution begins
      │
      ├──► [abefore_model]  ←── Per-model: before each LLM call (guardrails)
      │      │
      │      ▼
      │    [modify_model_request]  ←── Modify request (tools, prompts)
      │      │
      │      ▼
      │    LLM invocation
      │      │
      │      ▼
      │    [aafter_model]  ←── Per-model: after each LLM call (validation)
      │      │
      │    (loops for tool calls/reasoning steps)
      │
      ▼
    Run completes
      │
      ▼
    [aafter_run]  ←── Run-level: once per run (persistence, audit end)
      │
      ▼
    Return output


Hook Types
----------

Run hooks (before_run/after_run):
  - Execute ONCE per agent invocation
  - Outside LangGraph execution
  - Use cases: Memory recall/persistence, audit logging, run setup/cleanup
  - Called by: BaseLangGraphAgent._arun()

Model hooks (before_model/after_model/modify_model_request):
  - Execute MULTIPLE times per run (once per LLM call)
  - Inside LangGraph during agent reasoning
  - Use cases: Guardrails, input/output validation, tool modification
  - Called by: LangGraphReactAgent._handle_lm_invoker_call()

All hooks are optional with no-op defaults. Middleware can implement any subset.
"""

from typing import Any, Protocol, TypedDict

from langchain_core.tools import BaseTool


class ModelRequest(TypedDict, total=False):
    """Represents parameters for a model invocation that middleware can modify.

    This TypedDict defines the structure of requests passed to the LLM, allowing
    middleware to add tools or modify prompts before each invocation.

    Attributes:
        messages: List of messages in the conversation.
        tools: List of tools available to the model.
        system_prompt: System-level instruction for the model.
    """

    messages: list[Any]
    tools: list[BaseTool]
    system_prompt: str


class AgentMiddleware(Protocol):
    """Protocol defining the interface for composable agent middleware.

    Middleware components can contribute tools, enhance system prompts, and provide
    lifecycle hooks that execute before, during, and after model invocations.

    All middleware must implement this protocol to be compatible with MiddlewareManager.

    Attributes:
        tools: List of tools contributed by this middleware.
        system_prompt_additions: Optional text to append to the agent's system prompt.
    """

    tools: list[BaseTool]
    system_prompt_additions: str | None

    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed before each model invocation.

        Use this hook to prepare state, log context, or perform setup tasks
        before the model is called.

        Args:
            state: Current agent state containing messages and other context.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
        return {}  # pragma: no cover  # Protocol default

    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous version of before_model hook."""
        return self.before_model(state)  # pragma: no cover

    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Hook to modify the model request before invocation.

        Use this hook to add tools, modify the system prompt, adjust model parameters,
        or change tool selection strategy.

        Args:
            request: The model request that will be sent to the LLM.
            state: Current agent state for context.

        Returns:
            Modified ModelRequest. Can return the same request if no changes needed.
        """
        return request  # pragma: no cover

    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed after each model invocation.

        Use this hook for cleanup, logging, state updates, or post-processing
        of model outputs.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
        return {}  # pragma: no cover

    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous version of after_model hook."""
        return self.after_model(state)  # pragma: no cover

    def before_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Hook executed before each agent run.

        Use this hook for run-level setup like memory recall or audit logging.

        Args:
            state: Initial agent state.
            config: Optional run configuration.

        Returns:
            Dict of state updates to merge. Return empty dict if no updates needed.
        """
        return {}  # pragma: no cover  # Protocol default

    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Asynchronous version of before_run hook."""
        return self.before_run(state, config)  # pragma: no cover  # Protocol default

    def after_run(
        self,
        *,
        final_state: dict[str, Any],
        output: str | None,
        config: dict[str, Any] | None,
        error: Exception | None,
    ) -> None | dict[str, Any]:
        """Hook executed after each agent run.

        Use this hook for run-level cleanup like memory persistence.

        Args:
            final_state: Final agent state after run completion.
            output: The final output string from the agent, or None if failed.
            config: Optional run configuration.
            error: Exception if the run failed, None if successful.

        Returns:
            Optional dict of state updates. None if no updates needed.
        """
        return None  # pragma: no cover  # Protocol default

    async def aafter_run(
        self,
        *,
        final_state: dict[str, Any],
        output: str | None,
        config: dict[str, Any] | None,
        error: Exception | None,
    ) -> None | dict[str, Any]:
        """Asynchronous version of after_run hook."""
        return self.after_run(
            final_state=final_state, output=output, config=config, error=error
        )  # pragma: no cover  # Protocol default

    def on_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Hook executed when streaming final response is captured.

        This hook is invoked during A2A streaming when a FINAL_RESPONSE event is emitted.
        It enables early side effects (e.g. fire-and-forget persistence) without waiting
        for the stream consumer to finish reading.

        Args:
            content: Final response text content.
            context: Context dict (agent name, thread id, original query, etc.).
        """
        return None  # pragma: no cover  # Protocol default

    async def aon_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Asynchronous version of on_final_response hook."""
        self.on_final_response(content, context)  # pragma: no cover
