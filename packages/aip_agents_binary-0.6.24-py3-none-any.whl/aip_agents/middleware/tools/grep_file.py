"""Grep tool for agents.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)

Notes:
TODO: After migrating to deepagents:
  - Reuse from deepagents: BackendProtocol, GrepMatch, format_grep_matches()
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

from aip_agents.middleware.backends.protocol import GrepMatch
from aip_agents.middleware.backends.utils import ensure_absolute_path, format_grep_matches

GREP_TOOL_DESCRIPTION = """Search for a text pattern across files.

Searches for literal text (not regex) and returns matching files or content based on output_mode.
Special characters like parentheses, brackets, pipes, etc. are treated as literal characters, not regex operators.

Examples:
- Search all files: `grep(pattern="TODO")`
- Search Python files only: `grep(pattern="import", glob="*.py")`
- Show matching lines: `grep(pattern="error", output_mode="content")`
- Search for code with special chars: `grep(pattern="def __init__(self):")`"""


class GrepInput(BaseModel):
    """Input schema for grep tool."""

    path: str = Field(description="Directory path to search")
    pattern: str = Field(description="Text pattern to search for (literal string)")
    max_matches: int = Field(default=50, description="Maximum number of matches to return")


class GrepTool(BaseTool):
    """Tool for searching file contents across directories."""

    name: str = "grep"
    description: str = GREP_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = GrepInput
    backend: Annotated[Any, SkipValidation()]

    def _run(self, path: str, pattern: str, max_matches: int = 50) -> str:
        """Execute the grep operation.

        Args:
            path (str): Directory path to search.
            pattern (str): Text pattern to search for.
            max_matches (int, optional): Maximum matches to return. Defaults to 50.

        Returns:
            str: Search results or error message.
        """
        try:
            matches = self.backend.grep(pattern=pattern, path=path)
            if len(matches) > max_matches:
                matches = matches[:max_matches]
            # Normalize paths to absolute so read_file receives consistent input
            normalized = [
                GrepMatch(
                    path=ensure_absolute_path(m.path),
                    line_number=m.line_number,
                    content=m.content,
                )
                for m in matches
            ]
            return format_grep_matches(normalized, output_mode="content")
        except FileNotFoundError:
            return f"Error: Path not found: {path}"
        except ValueError as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Error searching: {str(e)}"
