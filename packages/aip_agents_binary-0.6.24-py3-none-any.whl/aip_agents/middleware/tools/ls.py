"""List files tool for agents.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)

TODO: When migrating to deepagents, replace this entire file with:
    from deepagents.middleware.tools.ls import LsTool, LsInput, truncate_if_too_long

    Note: deepagents LsTool uses ToolRuntime pattern instead of BaseTool.
    We'll need to adapt our middleware to use deepagents' tool registration.
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

from aip_agents.middleware.backends.utils import (
    ensure_absolute_path,
    truncate_if_too_long,
)

LIST_FILES_TOOL_DESCRIPTION = """Lists all files in a directory.

This is useful for exploring the filesystem and finding the right file to read or edit.
You should almost ALWAYS use this tool before using the read_file tool."""


class LsInput(BaseModel):
    """Input schema for ls tool."""

    path: str = Field(description="Absolute path to the directory to list. Must be absolute, not relative.")


class LsTool(BaseTool):
    """Tool for listing directory contents.

    Returns a Python list representation (as string) of absolute paths for files and directories.
    Large results are automatically truncated with guidance.
    """

    name: str = "ls"
    description: str = LIST_FILES_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = LsInput
    backend: Annotated[Any, SkipValidation()]

    def _run(self, path: str) -> str:
        """Execute the ls operation.

        Args:
            path (str): Directory path to list.

        Returns:
            str: Python list representation (as string) of absolute paths,
                or an error message if directory not found or path is not a directory.
            Example: "['/workspace/file1.txt', '/workspace/file2.txt']"
        """
        try:
            entries = self.backend.ls_info(path)
            # Extract full paths like deepagents does
            paths = [ensure_absolute_path(str(entry["path"])) for entry in entries]
            truncated = truncate_if_too_long(paths)
            return str(truncated)
        except FileNotFoundError:
            return f"No directory found: {path}"
        except NotADirectoryError:
            return f"Not a directory: {path}"
        except Exception as e:
            return f"Error: {str(e)}"
