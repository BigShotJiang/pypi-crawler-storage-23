"""Edit file tool for agents.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

EDIT_FILE_TOOL_DESCRIPTION = """Performs exact string replacements in files.

Usage:
- You must read the file before editing. This tool will error if you attempt an edit without reading the file first.
- When editing, preserve the exact indentation (tabs/spaces) from the read output. Never include line number prefixes in old_string or new_string.
- ALWAYS prefer editing existing files over creating new ones.
- Only use emojis if the user explicitly requests it."""


class EditFileInput(BaseModel):
    """Input schema for edit_file tool."""

    file_path: str = Field(description="Absolute path to the file to edit. Must be absolute, not relative.")
    old_string: str = Field(
        description="The exact text to find and replace. Must be unique in the file unless replace_all is True."
    )
    new_string: str = Field(description="The text to replace old_string with. Must be different from old_string.")
    replace_all: bool = Field(
        default=False,
        description="If True, replace all occurrences of old_string. If False (default), old_string must be unique.",
    )


class EditFileTool(BaseTool):
    """Tool for performing exact string replacements in existing files."""

    name: str = "edit_file"
    description: str = EDIT_FILE_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = EditFileInput
    backend: Annotated[Any, SkipValidation()]

    def _run(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> str:
        """Execute the edit operation.

        Args:
            file_path: Absolute path to the file to edit.
            old_string: Exact text to find.
            new_string: Replacement text.
            replace_all: Whether to replace all occurrences. Defaults to False.

        Returns:
            Success message or error string.
        """
        try:
            res = self.backend.edit(file_path, old_string, new_string, replace_all=replace_all)
            if not res.success or res.error:
                return res.error or "Error: Edit operation failed"
            return f"Successfully replaced {res.occurrences} instance(s) of the string in '{res.path}'"
        except Exception as e:
            return f"Error editing file '{file_path}': {str(e)}"
