"""
Tool management resource for SeekrAI SDK.

This module provides functionality to manage tools independently of agents,
including creation, listing, retrieval, updating, deletion, and duplication.
"""

from typing import Any, List, Optional

from pydantic import TypeAdapter

from seekrai.abstract import api_requestor
from seekrai.seekrflow_response import SeekrFlowResponse
from seekrai.types import (
    GetToolsResponse,
    SeekrFlowClient,
    SeekrFlowRequest,
    ToolAgentSummaryResponse,
    ToolDeleteResponse,
    ToolResponse,
)
from seekrai.types.enums import ToolStatus, ToolType
from seekrai.types.tools import CreateToolRequest, UpdateToolRequest


TOOL_RESPONSE_ADAPTER: TypeAdapter[ToolResponse] = TypeAdapter(ToolResponse)


class Tools:
    """Tool management resource for managing tools independently of agents."""

    def __init__(self, client: SeekrFlowClient) -> None:
        self._client = client
        self._requestor = api_requestor.APIRequestor(client=self._client)

    def create(self, request: CreateToolRequest) -> ToolResponse:
        """
        Create a new tool.

        Args:
            request: Tool creation request containing name and typed tool object

        Returns:
            Created tool response
        """
        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/tools",
                params=request.model_dump(by_alias=True),
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    def list(
        self,
        offset: int = 0,
        limit: int = 100,
        tool_type: Optional[ToolType] = None,
        tool_status: Optional[ToolStatus] = None,
    ) -> GetToolsResponse:
        """
        List tools with pagination and filtering.

        Args:
            offset: Number of records to skip
            limit: Maximum number of records to return (1-1000)
            tool_type: Filter by tool type
            tool_status: Filter by tool status

        Returns:
            Paginated list of tools
        """
        params: dict[str, Any] = {
            "offset": offset,
            "limit": limit,
        }

        if tool_type is not None:
            params["tool_type"] = tool_type.value
        if tool_status is not None:
            params["tool_status"] = tool_status.value

        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="GET",
                url="flow/tools",
                params=params,
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return GetToolsResponse(**response.data)

    def list_agents(self, tool_id: str) -> List[ToolAgentSummaryResponse]:
        """
        List agent summaries linked to this tool.

        Args:
            tool_id: Tool ID linked to agents

        Returns:
            List of agent summaries
        """
        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/tools/{tool_id}/agents",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        assert isinstance(response.data, list)
        return [ToolAgentSummaryResponse(**agent_tool) for agent_tool in response.data]

    def retrieve(self, tool_id: str) -> ToolResponse:
        """
        Retrieve a specific tool by ID.

        Args:
            tool_id: Tool ID to retrieve

        Returns:
            Tool response
        """
        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/tools/{tool_id}",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    def update(self, tool_id: str, request: UpdateToolRequest) -> ToolResponse:
        """
        Update an existing tool.

        Args:
            tool_id: Tool ID to update
            request: Tool update request containing updated fields

        Returns:
            Updated tool response
        """
        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="PUT",
                url=f"flow/tools/{tool_id}",
                params=request.model_dump(by_alias=True),
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    def delete(self, tool_id: str) -> ToolDeleteResponse:
        """
        Delete a tool if it's not referenced by active agents.

        Args:
            tool_id: Tool ID to delete

        Returns:
            Deletion response indicating success/failure
        """
        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="DELETE",
                url=f"flow/tools/{tool_id}",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return ToolDeleteResponse(**response.data)

    def duplicate(self, tool_id: str, name: Optional[str] = None) -> ToolResponse:
        """
        Duplicate an existing tool with a new name.

        Args:
            tool_id: Tool ID to duplicate
            name (optional): Name for duplicated tool

        Returns:
            New tool response
        """
        params = {}
        if name is not None:
            params["name"] = name

        response, _, _ = self._requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/tools/{tool_id}/duplicate",
                params=params,
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)


class AsyncTools:
    """Async tool management resource for managing tools independently of agents."""

    def __init__(self, client: SeekrFlowClient) -> None:
        self._client = client
        self._requestor = api_requestor.APIRequestor(client=self._client)

    async def create(self, request: CreateToolRequest) -> ToolResponse:
        """
        Create a new tool.

        Args:
            request: Tool creation request containing name and typed tool object

        Returns:
            Created tool response
        """
        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/tools",
                params=request.model_dump(by_alias=True),
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    async def list(
        self,
        offset: int = 0,
        limit: int = 100,
        tool_type: Optional[ToolType] = None,
        tool_status: Optional[ToolStatus] = None,
    ) -> GetToolsResponse:
        """
        List tools with pagination and filtering.

        Args:
            offset: Number of records to skip
            limit: Maximum number of records to return (1-1000)
            tool_type: Filter by tool type
            tool_status: Filter by tool status

        Returns:
            Paginated list of tools
        """
        params: dict[str, Any] = {
            "offset": offset,
            "limit": limit,
        }

        if tool_type is not None:
            params["tool_type"] = tool_type.value
        if tool_status is not None:
            params["tool_status"] = tool_status.value

        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="GET",
                url="flow/tools",
                params=params,
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return GetToolsResponse(**response.data)

    async def list_agents(self, tool_id: str) -> List[ToolAgentSummaryResponse]:
        """
        List agent summaries linked to this tool.

        Args:
            tool_id: Tool ID linked to agents

        Returns:
            List of agent summaries
        """
        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/tools/{tool_id}/agents",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        assert isinstance(response.data, list)
        return [ToolAgentSummaryResponse(**agent_tool) for agent_tool in response.data]

    async def retrieve(self, tool_id: str) -> ToolResponse:
        """
        Retrieve a specific tool by ID.

        Args:
            tool_id: Tool ID to retrieve

        Returns:
            Tool response
        """
        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/tools/{tool_id}",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    async def update(self, tool_id: str, request: UpdateToolRequest) -> ToolResponse:
        """
        Update an existing tool.

        Args:
            tool_id: Tool ID to update
            request: Tool update request containing updated fields

        Returns:
            Updated tool response
        """
        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="PUT",
                url=f"flow/tools/{tool_id}",
                params=request.model_dump(by_alias=True),
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)

    async def delete(self, tool_id: str) -> ToolDeleteResponse:
        """
        Delete a tool if it's not referenced by active agents.

        Args:
            tool_id: Tool ID to delete

        Returns:
            Deletion response indicating success/failure
        """
        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="DELETE",
                url=f"flow/tools/{tool_id}",
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return ToolDeleteResponse(**response.data)

    async def duplicate(
        self,
        tool_id: str,
        name: Optional[str] = None,
    ) -> ToolResponse:
        """
        Duplicate an existing tool with a new name.

        Args:
            tool_id: Tool ID to duplicate
            name (optional): Name for duplicated tool

        Returns:
            New tool response
        """
        params = {}
        if name is not None:
            params["name"] = name

        response, _, _ = await self._requestor.arequest(
            options=SeekrFlowRequest(
                method="POST", url=f"flow/tools/{tool_id}/duplicate", params=params
            ),
        )

        assert isinstance(response, SeekrFlowResponse)
        return TOOL_RESPONSE_ADAPTER.validate_python(response.data)
