from __future__ import annotations

from typing import List, Optional

from seekrai.abstract import api_requestor
from seekrai.resources.resource_base import ResourceBase
from seekrai.seekrflow_response import SeekrFlowResponse
from seekrai.types import SeekrFlowRequest
from seekrai.types.abstract import SeekrFlowClient
from seekrai.types.data_jobs import (
    DataJobAddFileRequest,
    DataJobCreateRequest,
    DataJobDetailResponse,
    DataJobListQuery,
    DataJobListResponse,
    DataJobRemoveFilesRequest,
    DataJobResponse,
    DataJobType,
    DataJobUpdateRequest,
    GenerateSystemPromptRequest,
    GenerateSystemPromptResponse,
    SortableField,
)


_UNSET = object()


class DataJobs(ResourceBase):
    def create(
        self,
        name: str,
        job_type: DataJobType = DataJobType.FILE,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> DataJobResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobCreateRequest(
            name=name,
            description=description,
            job_type=job_type,
            system_prompt=system_prompt,
        ).model_dump()

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/data-jobs",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobResponse(**response.data)

    def list(
        self,
        job_type: Optional[DataJobType] = None,
        sort_by: SortableField = SortableField.CREATED_AT,
        sort_order: str = "desc",
        limit: int = 25,
        offset: int = 0,
    ) -> DataJobListResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobListQuery(
            job_type=job_type,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
            offset=offset,
        ).model_dump(mode="json")

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="GET",
                url="flow/data-jobs",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobListResponse(**response.data)

    def retrieve(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/data-jobs/{data_job_id}",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def add_files(
        self, data_job_id: str, file_ids: List[str], method: Optional[str] = "best"
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobAddFileRequest(
            file_ids=file_ids, method=method
        ).model_dump()

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/add-files",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def remove_files(
        self, data_job_id: str, file_ids: List[str]
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobRemoveFilesRequest(file_ids=file_ids).model_dump()

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/remove-files",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def update(
        self,
        data_job_id: str,
        name: str | None | object = _UNSET,
        description: str | None | object = _UNSET,
        system_prompt: str | None | object = _UNSET,
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        update_data: dict[str, object] = {}
        if name is not _UNSET:
            update_data["name"] = name
        if description is not _UNSET:
            update_data["description"] = description
        if system_prompt is not _UNSET:
            update_data["system_prompt"] = system_prompt

        parameter_payload = DataJobUpdateRequest(**update_data).model_dump(
            exclude_unset=True
        )

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="PATCH",
                url=f"flow/data-jobs/{data_job_id}",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def start(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/start",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def cancel(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/cancel",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    def generate_system_prompt(
        self, instructions: str, document_summary: Optional[str] = None
    ) -> GenerateSystemPromptResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = GenerateSystemPromptRequest(
            instructions=instructions, document_summary=document_summary
        ).model_dump()

        response, _, _ = requestor.request(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/data-jobs/gen_system_prompt",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return GenerateSystemPromptResponse(**response.data)


class AsyncDataJobs(ResourceBase):
    def __init__(self, client: SeekrFlowClient) -> None:
        super().__init__(client)

    async def create(
        self,
        name: str,
        job_type: DataJobType = DataJobType.FILE,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> DataJobResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobCreateRequest(
            name=name,
            description=description,
            job_type=job_type,
            system_prompt=system_prompt,
        ).model_dump()

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/data-jobs",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobResponse(**response.data)

    async def list(
        self,
        job_type: Optional[DataJobType] = None,
        sort_by: SortableField = SortableField.CREATED_AT,
        sort_order: str = "desc",
        limit: int = 25,
        offset: int = 0,
    ) -> DataJobListResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobListQuery(
            job_type=job_type,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
            offset=offset,
        ).model_dump(mode="json")

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="GET",
                url="flow/data-jobs",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobListResponse(**response.data)

    async def retrieve(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="GET",
                url=f"flow/data-jobs/{data_job_id}",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def add_files(
        self, data_job_id: str, file_ids: List[str], method: Optional[str] = "best"
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobAddFileRequest(
            file_ids=file_ids, method=method
        ).model_dump()

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/add-files",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def remove_files(
        self, data_job_id: str, file_ids: List[str]
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = DataJobRemoveFilesRequest(file_ids=file_ids).model_dump()

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/remove-files",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def update(
        self,
        data_job_id: str,
        name: str | None | object = _UNSET,
        description: str | None | object = _UNSET,
        system_prompt: str | None | object = _UNSET,
    ) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        update_data: dict[str, object] = {}
        if name is not _UNSET:
            update_data["name"] = name
        if description is not _UNSET:
            update_data["description"] = description
        if system_prompt is not _UNSET:
            update_data["system_prompt"] = system_prompt

        parameter_payload = DataJobUpdateRequest(**update_data).model_dump(
            exclude_unset=True
        )

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="PATCH",
                url=f"flow/data-jobs/{data_job_id}",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def start(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/start",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def cancel(self, data_job_id: str) -> DataJobDetailResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url=f"flow/data-jobs/{data_job_id}/cancel",
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return DataJobDetailResponse(**response.data)

    async def generate_system_prompt(
        self, instructions: str, document_summary: Optional[str] = None
    ) -> GenerateSystemPromptResponse:
        requestor = api_requestor.APIRequestor(client=self._client)

        parameter_payload = GenerateSystemPromptRequest(
            instructions=instructions, document_summary=document_summary
        ).model_dump()

        response, _, _ = await requestor.arequest(
            options=SeekrFlowRequest(
                method="POST",
                url="flow/data-jobs/gen_system_prompt",
                params=parameter_payload,
            ),
            stream=False,
        )

        assert isinstance(response, SeekrFlowResponse)
        return GenerateSystemPromptResponse(**response.data)
