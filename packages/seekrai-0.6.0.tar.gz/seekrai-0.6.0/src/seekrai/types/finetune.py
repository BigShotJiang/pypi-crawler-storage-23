from __future__ import annotations

import warnings
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Literal, Optional

from pydantic import Field, field_validator, model_serializer, model_validator

from seekrai.types.abstract import BaseModel
from seekrai.types.common import (
    ObjectType,
)
from seekrai.utils._log import log_info


class FinetuneJobStatus(str, Enum):
    """
    Possible fine-tune job status
    """

    STATUS_PENDING = "pending"
    STATUS_QUEUED = "queued"
    STATUS_RUNNING = "running"
    # STATUS_COMPRESSING = "compressing"
    # STATUS_UPLOADING = "uploading"
    STATUS_CANCEL_REQUESTED = "cancel_requested"
    STATUS_CANCELLED = "cancelled"
    STATUS_FAILED = "failed"
    STATUS_COMPLETED = "completed"
    STATUS_DELETED = "deleted"


class FinetuneEventLevels(str, Enum):
    """
    Fine-tune job event status levels
    """

    NULL = ""
    INFO = "Info"
    WARNING = "Warning"
    ERROR = "Error"
    LEGACY_INFO = "info"
    LEGACY_IWARNING = "warning"
    LEGACY_IERROR = "error"


class FinetuneEventType(str, Enum):
    """
    Fine-tune job event types
    """

    JOB_PENDING = "JOB_PENDING"
    JOB_START = "JOB_START"
    JOB_STOPPED = "JOB_STOPPED"
    MODEL_DOWNLOADING = "MODEL_DOWNLOADING"
    MODEL_DOWNLOAD_COMPLETE = "MODEL_DOWNLOAD_COMPLETE"
    TRAINING_DATA_DOWNLOADING = "TRAINING_DATA_DOWNLOADING"
    TRAINING_DATA_DOWNLOAD_COMPLETE = "TRAINING_DATA_DOWNLOAD_COMPLETE"
    VALIDATION_DATA_DOWNLOADING = "VALIDATION_DATA_DOWNLOADING"
    VALIDATION_DATA_DOWNLOAD_COMPLETE = "VALIDATION_DATA_DOWNLOAD_COMPLETE"
    WANDB_INIT = "WANDB_INIT"
    TRAINING_START = "TRAINING_START"
    CHECKPOINT_SAVE = "CHECKPOINT_SAVE"
    BILLING_LIMIT = "BILLING_LIMIT"
    EPOCH_COMPLETE = "EPOCH_COMPLETE"
    TRAINING_COMPLETE = "TRAINING_COMPLETE"
    MODEL_COMPRESSING = "COMPRESSING_MODEL"
    MODEL_COMPRESSION_COMPLETE = "MODEL_COMPRESSION_COMPLETE"
    MODEL_UPLOADING = "MODEL_UPLOADING"
    MODEL_UPLOAD_COMPLETE = "MODEL_UPLOAD_COMPLETE"
    JOB_COMPLETE = "JOB_COMPLETE"
    JOB_ERROR = "JOB_ERROR"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    JOB_RESTARTED = "JOB_RESTARTED"
    REFUND = "REFUND"
    WARNING = "WARNING"


class FineTuneType(str, Enum):
    STANDARD = "STANDARD"
    GRPO = "GRPO"  # deprecated
    PREFERENCE = "PREFERENCE"
    REINFORCEMENT = "REINFORCEMENT"


class GraderType(str, Enum):
    FORMAT_CHECK = "format_check"
    MATH_ACCURACY = "math_accuracy"
    STRING_CHECK = "string_check"
    TEXT_SIMILARITY = "text_similarity"


class StringOperation(str, Enum):
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    CONTAINS = "contains"
    CASE_INSENSITIVE_CONTAINS = "case_insensitive_contains"


class TextSimilarityOperation(str, Enum):
    BLEU = "bleu"
    ROUGE = "rouge"


class FinetuneEvent(BaseModel):
    """
    Fine-tune event type
    """

    # object type
    object: Literal[ObjectType.FinetuneEvent]
    # created at datetime stamp
    created_at: datetime | None = None
    # metrics that we expose
    loss: float | None = None
    epoch: float | None = None
    reward: float | None = None

    @model_serializer(mode="wrap")
    def serialize_model(
        self, handler: Callable[[Any], dict[str, Any]]
    ) -> dict[str, Any]:
        # Remove 'reward' if it's None
        dump_dict = handler(self)
        if dump_dict.get("reward") is None:
            del dump_dict["reward"]
        return dump_dict


class LoRAConfig(BaseModel):
    r: int = Field(8, gt=0, description="Rank of the update matrices.")
    alpha: int = Field(32, gt=0, description="Scaling factor applied to LoRA updates.")
    dropout: float = Field(
        0.1,
        ge=0.0,
        le=1.0,
        description="Fraction of LoRA neurons dropped during training.",
    )
    bias: Literal["none", "all", "lora_only"] = Field(
        "none",
        description="Bias terms to train; choose from 'none', 'all', or 'lora_only'.",
    )
    extras: Dict[str, Any] = Field(default_factory=dict)


class Grader(BaseModel):
    type: GraderType
    weight: float | None = Field(default=None, gt=0.0, le=1.0)
    operation: StringOperation | TextSimilarityOperation | None = Field(default=None)

    @model_validator(mode="before")
    @classmethod
    def validate_operation(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        grader_type = data.get("type")
        operation_value = data.get("operation")

        if grader_type == GraderType.STRING_CHECK:
            if not operation_value:
                raise ValueError(
                    "string_check grader is missing required StringOperation"
                )
            if isinstance(operation_value, str):
                try:
                    # Convert to enum to validate it's a valid value
                    data["operation"] = StringOperation(operation_value.lower())
                except ValueError:
                    raise ValueError(
                        f"Invalid operation for string_check grader: "
                        f"expected StringOperation, but got type '{type(operation_value).__name__}' with value '{operation_value}'"
                    )
        elif grader_type == GraderType.TEXT_SIMILARITY:
            if not operation_value:
                raise ValueError(
                    "text_similarity grader is missing required TextSimilarityOperation"
                )
            if isinstance(operation_value, str):
                try:
                    data["operation"] = TextSimilarityOperation(operation_value.lower())
                except ValueError:
                    raise ValueError(
                        f"Invalid operation for text_similarity grader: "
                        f"expected TextSimilarityOperation, got type '{type(operation_value).__name__}' with value '{operation_value}'"
                    )

        elif grader_type in (GraderType.FORMAT_CHECK, GraderType.MATH_ACCURACY):
            if operation_value:
                raise ValueError(f"{grader_type} grader cannot have an operation")
            data["operation"] = None

        return data


class RewardComponents(BaseModel):
    format_reward_weight: float = Field(default=0.1, gt=0.0, le=1.0)
    graders: list[Grader] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_weights(self) -> "RewardComponents":
        is_format_weight_specified = "format_reward_weight" in self.model_fields_set

        grader_weights_specified = [
            grader.weight is not None for grader in self.graders
        ]

        all_graders_have_weights = all(grader_weights_specified)
        some_graders_have_weights = any(grader_weights_specified) and not all(
            grader_weights_specified
        )
        no_graders_have_weights = not any(grader_weights_specified)

        if some_graders_have_weights:
            raise ValueError(
                "Only some graders have weights specified. Either all graders must have weights specified, or none of them."
            )

        if all_graders_have_weights and is_format_weight_specified:
            self._validate_weights_sum_to_one()

        elif all_graders_have_weights and not is_format_weight_specified:
            self._normalize_grader_weights()

        elif no_graders_have_weights:
            self._initialize_grader_weights()
            self._normalize_grader_weights()

        return self

    def _validate_weights_sum_to_one(self) -> None:
        """Validate that format_reward_weight and grader weights sum to 1.0"""
        total_weight = self.format_reward_weight + sum(  # type: ignore[operator]
            grader.weight  # type: ignore[misc]
            for grader in self.graders
        )

        if abs(total_weight - 1.0) > 1e-10:
            raise ValueError(
                f"When all weights are explicitly provided, they must sum to 1.0. "
                f"Got format_reward_weight={self.format_reward_weight}, "
                f"graders={self.graders}"
            )

    def _normalize_grader_weights(self) -> None:
        """Normalize only grader weights to fill (1 - format_reward_weight)"""
        total_grader_weight = sum(grader.weight for grader in self.graders)  # type: ignore[misc]
        target_grader_total = 1.0 - self.format_reward_weight

        # only normalize if weights aren't already properly normalized
        if abs(total_grader_weight - target_grader_total) > 1e-10:
            scale_factor = target_grader_total / total_grader_weight
            for grader in self.graders:
                original_weight = grader.weight
                grader.weight *= scale_factor  # type: ignore[operator]
                log_info(
                    f"{grader.type}'s weight scaled from {original_weight} to {grader.weight:.2f}"
                )

    def _initialize_grader_weights(self) -> None:
        """Initialize all grader weights when none are provided"""
        for grader in self.graders:
            grader.weight = 1.0


class TrainingConfig(BaseModel):
    # training file ID
    training_files: List[str]
    # base model string
    model: str
    # number of epochs to train for
    n_epochs: int
    # training learning rate
    learning_rate: float
    # number of checkpoints to save
    n_checkpoints: int | None = None
    # training batch size
    batch_size: int = Field(..., ge=1, le=1024)
    # up to 40 character suffix for output model name
    experiment_name: str | None = None
    # sequence length
    max_length: int = 2500
    # # weights & biases api key
    # wandb_key: str | None = None
    # IFT by default
    pre_train: bool = False
    # fine-tune type
    fine_tune_type: FineTuneType = FineTuneType.STANDARD
    # LoRA config
    lora_config: Optional[LoRAConfig] = None
    # reward_components are REINFORCEMENT-specific
    reward_components: Optional[RewardComponents] = None

    @model_validator(mode="after")
    def validate_reward_components(self) -> "TrainingConfig":
        # TODO: re-enable the below and make reward_components required for REINFORCEMENT. Disabled for now for backwards-compatibility
        # if (
        #     self.fine_tune_type in (FineTuneType.REINFORCEMENT, FineTuneType.GRPO)
        #     and not self.reward_components
        # ):
        #     raise ValueError("REINFORCEMENT fine-tuning requires reward components")
        if (
            self.fine_tune_type in (FineTuneType.REINFORCEMENT, FineTuneType.GRPO)
            and not self.reward_components
        ):
            self.reward_components = RewardComponents(
                format_reward_weight=0.1,
                graders=[Grader(type=GraderType.MATH_ACCURACY, weight=0.9)],
            )
        if self.fine_tune_type == FineTuneType.STANDARD and self.reward_components:
            raise ValueError(
                "Reward components are incompatible with standard fine-tuning"
            )
        if self.fine_tune_type == FineTuneType.PREFERENCE and self.reward_components:
            raise ValueError(
                "Reward components are incompatible with preference fine-tuning"
            )

        return self

    @field_validator("fine_tune_type")
    def validate_fine_tune_type(cls, v: Any) -> Any:
        if v == FineTuneType.GRPO:
            warnings.warn(
                "FineTuneType.GRPO is deprecated and will be removed in a future version. Use FineTuneType.REINFORCEMENT",
                DeprecationWarning,
                stacklevel=2,
            )
        return v


class AcceleratorType(str, Enum):
    GAUDI2 = "GAUDI2"
    GAUDI3 = "GAUDI3"
    A100 = "A100"
    A10 = "A10"
    H100 = "H100"
    MI300X = "MI300X"


class InfrastructureConfig(BaseModel):
    accel_type: AcceleratorType
    n_accel: int
    n_node: int = 1


class FinetuneRequest(BaseModel):
    """
    Fine-tune request type
    """

    project_id: int
    training_config: TrainingConfig
    infrastructure_config: InfrastructureConfig


class FinetuneResponse(BaseModel):
    """
    Fine-tune API response type
    """

    # job ID
    id: str | None = None
    # fine-tune type
    fine_tune_type: FineTuneType = FineTuneType.STANDARD
    reward_components: Optional[RewardComponents] = None
    # training file id
    training_files: List[str] | None = None
    # validation file id
    # validation_files: str | None = None TODO
    # base model name
    model: str | None = None
    accel_type: AcceleratorType
    n_accel: int
    n_node: int | None = None
    # number of epochs
    n_epochs: int | None = None
    # number of checkpoints to save
    # n_checkpoints: int | None = None # TODO
    # training batch size
    batch_size: int | None = None
    # training learning rate
    learning_rate: float | None = None
    # LoRA configuration returned when LoRA fine-tuning is enabled
    lora_config: Optional[LoRAConfig] = None
    # number of steps between evals
    # eval_steps: int | None = None TODO
    # created/updated datetime stamps
    created_at: datetime | None = None
    # updated_at: str | None = None
    # up to 40 character suffix for output model name
    experiment_name: str | None = None
    # job status
    status: FinetuneJobStatus | None = None
    deleted_at: datetime | None = None

    # list of fine-tune events
    events: List[FinetuneEvent] | None = None
    inference_available: bool = False
    project_id: Optional[int] = None  # TODO - fix this
    completed_at: datetime | None = None
    description: str | None = None

    # dataset token count
    # TODO
    # token_count: int | None = None
    # # model parameter count
    # param_count: int | None = None
    # # fine-tune job price
    # total_price: int | None = None
    # # number of epochs completed (incrementing counter)
    # epochs_completed: int | None = None
    # # place in job queue (decrementing counter)
    # queue_depth: int | None = None
    # # weights & biases project name
    # wandb_project_name: str | None = None
    # # weights & biases job url
    # wandb_url: str | None = None
    # # training file metadata
    # training_file_num_lines: int | None = Field(None, alias="TrainingFileNumLines")
    # training_file_size: int | None = Field(None, alias="TrainingFileSize")

    @model_serializer(mode="wrap")
    def serialize_model(
        self, handler: Callable[[Any], dict[str, Any]]
    ) -> dict[str, Any]:
        # Remove 'reward_components' if it's None
        dump_dict = handler(self)
        if dump_dict.get("reward_components") is None:
            del dump_dict["reward_components"]
        return dump_dict


class FinetuneList(BaseModel):
    # object type
    object: Literal["list"] | None = None
    # list of fine-tune job objects
    data: List[FinetuneResponse] | None = None


class FinetuneListEvents(BaseModel):
    # object type
    object: Literal["list"] | None = None
    # list of fine-tune events
    data: List[FinetuneEvent] | None = None


class FinetuneDownloadResult(BaseModel):
    # object type
    object: Literal["local"] | None = None
    # fine-tune job id
    id: str | None = None
    # checkpoint step number
    checkpoint_step: int | None = None
    # local path filename
    filename: str | None = None
    # size in bytes
    size: int | None = None
