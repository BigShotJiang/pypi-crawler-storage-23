from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Literal, Optional

from pydantic import Field

from seekrai.types.abstract import BaseModel


class IngestionJobStatus(Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class IngestionRequest(BaseModel):
    files: List[str] = Field(
        default=..., description="List of file ids to use for alignment"
    )
    method: str = Field(default="best", description="Method to use for ingestion")


class IngestionResponse(BaseModel):
    id: str = Field(default=..., description="Ingestion job ID")
    created_at: datetime
    status: IngestionJobStatus
    output_files: List[str]
    file_records: Optional[List["IngestionFileRecord"]] = Field(
        default=None, description="Detailed file records with queue positions"
    )


class IngestionFileRecord(BaseModel):
    record_id: str = Field(default=..., description="File record ID")
    ingestion_job_id: str = Field(default=..., description="Parent ingestion job ID")
    alignment_file_id: str = Field(default=..., description="Alignment file ID")
    user_id: str = Field(default=..., description="Owner of the ingestion job")
    filename: str = Field(default=..., description="Filename")
    metaflow_job_id: Optional[str] = Field(
        default=None, description="Metaflow job handling this file"
    )
    method: Optional[str] = Field(
        default=None, description="Ingestion method used for processing"
    )
    status: str = Field(default=..., description="File processing status")
    queue_position: Optional[int] = Field(
        default=None, description="Position in queue if status is queued"
    )
    error_message: Optional[str] = Field(
        default=None, description="Error message if failed"
    )
    suggested_fix: Optional[str] = Field(
        default=None, description="Suggested fix when processing fails"
    )
    worker_id: Optional[str] = Field(
        default=None, description="Worker currently handling the file"
    )
    created_at: datetime
    processing_at: Optional[datetime] = Field(
        default=None, description="Timestamp when processing started"
    )
    completed_at: Optional[datetime] = Field(
        default=None, description="Timestamp when processing completed"
    )
    failed_at: Optional[datetime] = Field(
        default=None, description="Timestamp when processing failed"
    )


class IngestionList(BaseModel):
    # object type
    object: Literal["list"] | None = None
    # list of fine-tune job objects
    data: List[IngestionResponse] | None = None
