from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Dict, List, Literal, Optional

from pydantic import Field

from seekrai.types.abstract import BaseModel
from seekrai.types.alignment import AlignmentResponse
from seekrai.types.ingestion import IngestionFileRecord


class DataJobType(str, Enum):
    FILE = "file"


class SortableField(str, Enum):
    NAME = "name"
    DESCRIPTION = "description"
    CREATED_AT = "created_at"
    JOB_TYPE = "job_type"


class DataJobStatus(str, Enum):
    FILE_PROCESSING = "file_processing"
    NEEDS_REVIEW = "needs_review"
    READY_TO_START = "ready_to_start"
    ALIGNMENT_PENDING = "pending"
    ALIGNMENT_QUEUED = "queued"
    ALIGNMENT_RUNNING = "running"
    ALIGNMENT_CANCELLED = "cancelled"
    ALIGNMENT_FAILED = "failed"
    ALIGNMENT_COMPLETED = "completed"


class DataJobListQuery(BaseModel):
    job_type: Optional[DataJobType] = None
    sort_by: SortableField = SortableField.CREATED_AT
    sort_order: Literal["asc", "desc"] = "desc"
    limit: int = Field(default=25, ge=1, le=100)
    offset: int = Field(default=0, ge=0)


class DataJobCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = Field(default=None)
    job_type: DataJobType
    system_prompt: Optional[str] = Field(default=None)


class DataJobResponse(BaseModel):
    id: str
    user_id: str
    name: str
    description: Optional[str]
    job_type: str
    alignment_job_id: Optional[str]
    created_at: datetime
    updated_at: datetime
    status: DataJobStatus
    system_prompt: Optional[str] = None
    system_prompt_updated_at: Optional[datetime] = None


class DataJobListResponse(BaseModel):
    object: Literal["list"] = "list"
    data: List[DataJobResponse] = Field(default_factory=list)


class TimelineEvent(BaseModel):
    timestamp: datetime
    event_type: str
    message: str
    metadata: Dict[str, object] = Field(default_factory=dict)


class IngestionJobDetail(BaseModel):
    id: str
    status: DataJobStatus
    created_at: datetime
    updated_at: datetime
    file_ids: List[str] = Field(default_factory=list)
    records: List[IngestionFileRecord] = Field(default_factory=list)


class DataJobFile(BaseModel):
    file_id: str = Field(..., description="Alignment file identifier")
    record_id: Optional[str] = Field(
        default=None, description="Ingestion job file record identifier (if any)"
    )
    name: Optional[str] = Field(default=None, description="Human readable file name")
    type: Optional[str] = Field(default=None, description="Detected file type")
    created_at: Optional[datetime] = Field(
        default=None, description="Creation timestamp of the underlying file"
    )
    status: Optional[str] = Field(
        default=None, description="Processing status for ingestion records"
    )
    suggested_fix: Optional[str] = Field(
        default=None, description="Suggested fix when ingestion failed"
    )


class DataJobDetailResponse(DataJobResponse):
    additional_alignment_file_ids: List[str] = Field(default_factory=list)
    ingestion_jobs: List[IngestionJobDetail] = Field(default_factory=list)
    alignment_job: Optional[AlignmentResponse] = None
    files: List[DataJobFile] = Field(default_factory=list)
    fine_tuning_job_ids: List[str] = Field(default_factory=list)
    timeline: List[TimelineEvent] = Field(default_factory=list)


class DataJobAddFileRequest(BaseModel):
    file_ids: List[str] = Field(
        ..., min_length=1, description="Files to associate with the data job"
    )
    method: Optional[str] = Field(
        default="best",
        description="Ingestion method used for non-alignment-ready files",
    )


class DataJobUpdateRequest(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    description: Optional[str] = Field(default=None)
    system_prompt: Optional[str] = Field(default=None)


class DataJobRemoveFilesRequest(BaseModel):
    file_ids: List[str] = Field(..., min_length=1, description="File IDs to remove")


class GenerateSystemPromptRequest(BaseModel):
    instructions: str
    document_summary: Optional[str] = None


class GenerateSystemPromptResponse(BaseModel):
    system_prompt: str
