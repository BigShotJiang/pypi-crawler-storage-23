from typing import Generic, Optional, TypeVar

from pydantic import BaseModel

from seekrai.types.agents.tools.env_model_config import EnvConfig
from seekrai.types.enums import ToolType as SeekrToolType


TName = TypeVar("TName", bound=str)
TEnv = TypeVar("TEnv", bound=EnvConfig)

ToolType = SeekrToolType


class ToolBase(BaseModel, Generic[TName, TEnv]):
    id: Optional[str] = None
    name: TName
    tool_env: TEnv


__all__ = [
    "ToolBase",
    "ToolType",
]  # explicitly re-export ToolType from old namespace to keep backward compatibility
