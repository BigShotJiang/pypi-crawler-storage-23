from typing import Literal

from seekrai.types.agents.tools import EnvConfig
from seekrai.types.agents.tools.tool import ToolBase, ToolType


class AgentAsToolLegacy(ToolBase[Literal["agent_as_tool"], EnvConfig]):
    name: Literal["agent_as_tool"] = ToolType.AGENT_AS_TOOL.value
    description: str
    agent_id: str

    model_config = {
        "json_schema_extra": {
            "deprecated": True,
        }
    }
