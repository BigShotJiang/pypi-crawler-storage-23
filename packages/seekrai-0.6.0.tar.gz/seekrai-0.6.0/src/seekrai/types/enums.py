from enum import Enum


class AgentStatus(str, Enum):
    INACTIVE = "Inactive"
    PENDING = "Pending"
    ACTIVE = "Active"
    UPDATING = "Updating"
    FAILED = "Failed"


class ReasoningEffort(str, Enum):
    PERFORMANCE_OPTIMIZED = "performance_optimized"
    SPEED_OPTIMIZED = "speed_optimized"


class ToolStatus(str, Enum):
    """Tool status enumeration."""

    ACTIVE = "Active"
    INACTIVE = "Inactive"
    DEPRECATED = "Deprecated"


class ToolType(str, Enum):
    """Tool type enumeration used to discriminate the union."""

    FILE_SEARCH = "file_search"
    WEB_SEARCH = "web_search"
    RUN_PYTHON = "run_python"
    AGENT_AS_TOOL = "agent_as_tool"
