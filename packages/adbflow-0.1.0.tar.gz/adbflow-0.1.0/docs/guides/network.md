# Network

The `NetworkManager` controls WiFi, mobile data, airplane mode, port forwarding, reverse forwarding, proxy settings, and packet capture. Access via `device.network`.

## WiFi

```python
async def wifi_examples(device):
    net = device.network

    # Enable/disable
    await net.wifi_enable_async()
    await net.wifi_disable_async()

    # Check status
    enabled = await net.wifi_is_enabled_async()

    # Get WiFi info
    info = await net.wifi_info_async()
    if info:
        print(f"SSID: {info.ssid}, IP: {info.ip_address}")

    # Connect to a network
    await net.wifi_connect_async("MyNetwork", password="secret123")
```

## Mobile Data

```python
async def mobile_data_examples(device):
    net = device.network

    await net.mobile_data_enable_async()
    await net.mobile_data_disable_async()
    enabled = await net.mobile_data_is_enabled_async()
```

## Airplane Mode

```python
async def airplane_examples(device):
    net = device.network

    await net.airplane_enable_async()
    await net.airplane_disable_async()
    enabled = await net.airplane_is_enabled_async()
```

## Port Forwarding

Forward ports between host and device:

```python
async def forwarding_examples(device):
    net = device.network

    # Forward host port 8080 to device port 80
    await net.forward_async("tcp:8080", "tcp:80")

    # List active forwards
    rules = await net.forward_list_async()
    for r in rules:
        print(f"{r.local} -> {r.remote}")

    # Remove a specific forward
    await net.forward_remove_async("tcp:8080")

    # Remove all forwards
    await net.forward_remove_all_async()
```

## Reverse Forwarding

Forward from device to host (useful for connecting device apps to a local server):

```python
async def reverse_examples(device):
    net = device.network

    # Device port 8080 → host port 3000
    await net.reverse_async("tcp:8080", "tcp:3000")

    # Remove
    await net.reverse_remove_async("tcp:8080")
    await net.reverse_remove_all_async()
```

## Proxy

```python
from adbflow.utils.types import ProxyConfig

async def proxy_examples(device):
    net = device.network

    # Set proxy
    await net.proxy_set_async(ProxyConfig(host="192.168.1.100", port=8888))

    # Get current proxy
    config = await net.proxy_get_async()
    if config:
        print(f"Proxy: {config.host}:{config.port}")

    # Clear proxy
    await net.proxy_clear_async()
```

## Packet Capture (tcpdump)

```python
async def tcpdump_examples(device):
    net = device.network

    # Start capture
    await net.tcpdump_start_async(
        output_path="/sdcard/capture.pcap",
        filter_expr="port 80"
    )

    # ... run your test ...
    import asyncio
    await asyncio.sleep(10)

    # Stop capture
    await net.tcpdump_stop_async()

    # Pull capture file
    await net.tcpdump_pull_async("/local/capture.pcap")
```

## Tips

- WiFi and mobile data toggling may require root on some devices.
- Port forwarding is essential for testing apps that communicate with local development servers.
- Use reverse forwarding when the app on the device needs to reach a service on your host machine.
- tcpdump requires root access on the device.
