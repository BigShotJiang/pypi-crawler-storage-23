# Notifications

List, search, and wait for notifications on the device. Access via `device.notifications`.

## List Notifications

```python
async def list_notifications(device):
    notifications = await device.notifications.list_async()
    for n in notifications:
        print(f"[{n.package}] {n.title}: {n.text}")
```

## Find Notifications

```python
async def find_notifications(device):
    # By package
    msgs = await device.notifications.find_async(package="com.example.chat")

    # By title
    alerts = await device.notifications.find_async(title_contains="Alert")

    # By text content
    errors = await device.notifications.find_async(text_contains="failed")

    # Combine filters
    specific = await device.notifications.find_async(
        package="com.example.app",
        title_contains="Download"
    )
```

## Wait for a Notification

```python
async def wait_notification(device):
    # Wait for a notification from a specific package
    notif = await device.notifications.wait_for_async(
        package="com.example.app",
        timeout=30.0,
        interval=1.0
    )
    print(f"Got: {notif.title}")

    # Wait for notification with specific title
    notif = await device.notifications.wait_for_async(
        title_contains="Download complete",
        timeout=60.0
    )
```

## Clear Notifications

```python
async def clear_notifications(device):
    await device.notifications.clear_all_async()
```

## Tips

- Notification access requires the notification listener or `dumpsys notification` to work, which is available on most devices without extra permissions.
- Use `wait_for_async` to synchronize on async events like push notifications, download completions, or background task results.
- The `interval` parameter controls polling frequency. Use longer intervals (2–5s) for notifications that may take a while.
