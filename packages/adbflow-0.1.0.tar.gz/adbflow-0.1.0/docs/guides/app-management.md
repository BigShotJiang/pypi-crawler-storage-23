# App Management

The `AppManager` handles installing, launching, stopping, and querying Android packages. Access it via `device.apps`.

## Install & Uninstall

```python
async def install_examples(device):
    # Install an APK
    await device.apps.install_async("/path/to/app.apk")

    # Install with flags
    from adbflow.utils.types import InstallFlag
    await device.apps.install_async(
        "/path/to/app.apk",
        flags=[InstallFlag.REPLACE, InstallFlag.GRANT_PERMISSIONS]
    )

    # Install multiple APKs (split APK)
    await device.apps.install_multiple_async([
        "/path/to/base.apk",
        "/path/to/split_config.apk",
    ])

    # Install with progress callback
    def on_progress(transferred, total):
        print(f"{transferred}/{total} bytes")

    await device.apps.install_async("/path/to/app.apk", progress=on_progress)

    # Uninstall
    await device.apps.uninstall_async("com.example.app")

    # Uninstall but keep data
    await device.apps.uninstall_async("com.example.app", keep_data=True)
```

## Launch & Stop

```python
async def lifecycle_examples(device):
    # Launch with default activity
    await device.apps.start_async("com.example.app")

    # Launch a specific activity
    await device.apps.start_async(
        "com.example.app",
        activity="com.example.app/.MainActivity"
    )

    # Force stop
    await device.apps.stop_async("com.example.app")

    # Clear app data
    await device.apps.clear_data_async("com.example.app")
```

## Query Packages

```python
from adbflow.utils.types import PackageFilter

async def query_examples(device):
    # List all packages
    packages = await device.apps.list_async()

    # Filter packages
    third_party = await device.apps.list_async(filter=PackageFilter.THIRD_PARTY)
    system = await device.apps.list_async(filter=PackageFilter.SYSTEM)

    # Check if installed
    installed = await device.apps.is_installed_async("com.example.app")

    # Get detailed info
    info = await device.apps.info_async("com.example.app")
    if info:
        print(f"Version: {info.version_name}")

    # Current foreground app
    current = await device.apps.current_async()
    print(f"Foreground: {current}")
```

## Intents

Use the `Intent` builder to send intents:

```python
from adbflow.apps import Intent

async def intent_examples(device):
    # Open a URL in browser
    intent = (
        Intent()
        .action("android.intent.action.VIEW")
        .data("https://example.com")
    )
    await device.apps.start_activity_async(intent)

    # Send a broadcast
    intent = (
        Intent()
        .action("com.example.MY_ACTION")
        .extra_string("key", "value")
        .extra_int("count", 42)
        .extra_bool("enabled", True)
    )
    await device.apps.broadcast_async(intent)

    # Start a specific component
    intent = (
        Intent()
        .component("com.example.app/.MyService")
        .extra_string("command", "start")
    )
    await device.apps.start_service_async(intent)
```

## Permissions

```python
async def permission_examples(device):
    perms = device.apps.permissions

    # List permissions for a package
    all_perms = await perms.list_async("com.example.app")
    for p in all_perms:
        print(f"{p.name}: {'granted' if p.granted else 'denied'}")

    # Grant a permission
    await perms.grant_async(
        "com.example.app",
        "android.permission.CAMERA"
    )

    # Revoke a permission
    await perms.revoke_async(
        "com.example.app",
        "android.permission.CAMERA"
    )

    # Check if granted
    granted = await perms.is_granted_async(
        "com.example.app",
        "android.permission.CAMERA"
    )
```

## Extract APK

```python
async def extract_example(device):
    await device.apps.extract_async("com.example.app", "/tmp/extracted.apk")
```
