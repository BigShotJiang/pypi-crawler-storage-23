# Screen Capture

adbflow supports screenshots (as bytes, PIL images, or saved to files) and screen recording. Access via `device.media`.

## Screenshots

### Raw PNG Bytes

```python
async def screenshot_bytes(device):
    # Quick screenshot via device shortcut
    png_bytes = await device.screenshot_async()

    # Or via the media manager
    png_bytes = await device.media.screenshot.capture_async()
```

### Save to File

```python
async def screenshot_file(device):
    await device.media.screenshot.capture_to_file_async("screen.png")
```

### PIL Image

```python
async def screenshot_pil(device):
    image = await device.media.screenshot.capture_pil_async()
    # image is a PIL Image object — crop, resize, analyze
    width, height = image.size
    cropped = image.crop((0, 0, width // 2, height // 2))
    cropped.save("top_left.png")
```

## Screen Recording

```python
async def recording_example(device):
    recorder = device.media.recording

    # Start recording
    await recorder.start_async()

    # ... perform actions ...
    import asyncio
    await asyncio.sleep(5)

    # Stop recording
    await recorder.stop_async()

    # Pull the recording to local machine
    await recorder.pull_async("/local/recording.mp4")
```

### Custom Recording Options

```python
async def recording_options(device):
    recorder = device.media.recording

    # Custom output path and options
    await recorder.start_async(
        remote_path="/sdcard/my_recording.mp4",
        options={"time-limit": 30, "size": "720x1280"}
    )

    # Check if recording is active
    is_recording = await recorder.is_recording_async()
    print(f"Recording: {is_recording}")

    await recorder.stop_async()
    await recorder.pull_async(
        "/local/my_recording.mp4",
        remote_path="/sdcard/my_recording.mp4"
    )
```

## Audio

```python
from adbflow.utils.types import AudioStream

async def audio_examples(device):
    audio = device.media.audio

    # Get/set volume
    vol = await audio.get_volume_async(AudioStream.MUSIC)
    await audio.set_volume_async(AudioStream.MUSIC, 10)

    # Mute/unmute
    await audio.mute_async(AudioStream.NOTIFICATION)
    is_muted = await audio.is_muted_async(AudioStream.NOTIFICATION)
    await audio.unmute_async(AudioStream.NOTIFICATION)
```

## Tips

- Screenshots return PNG-encoded bytes. Use `Pillow` to decode and manipulate them.
- Screen recording uses Android's `screenrecord` command, which has a max duration of 180 seconds.
- The `capture_pil_async()` method requires `Pillow` (included in core dependencies).
