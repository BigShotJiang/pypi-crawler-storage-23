# ADB

`adbflow.core.adb.ADB`

The top-level entry point for discovering and connecting to Android devices. This is the first object you create.

```python
from adbflow import ADB

adb = ADB()
# or with custom ADB path
adb = ADB(adb_path="/opt/android/platform-tools/adb")
```

## Properties

| Property    | Type                  | Description                        |
| ----------- | --------------------- | ---------------------------------- |
| `transport` | `SubprocessTransport` | The underlying transport layer     |

## Async Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `devices_async` | — | `list[DeviceListEntry]` | List all connected devices |
| `device_async` | `serial: str \| None = None` | `Device` | Get a device (auto-detect if no serial) |
| `connect_async` | `host: str, port: int = 5555` | `Device` | Connect to a device over TCP/IP |
| `disconnect_async` | `host: str, port: int = 5555` | `None` | Disconnect a TCP/IP device |

## Sync Methods

Each async method has a sync wrapper (without `_async` suffix):

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `devices` | — | `list[DeviceListEntry]` | List all connected devices |
| `device` | `serial: str \| None = None` | `Device` | Get a device |
| `connect` | `host: str, port: int = 5555` | `Device` | Connect over TCP/IP |
| `disconnect` | `host: str, port: int = 5555` | `None` | Disconnect TCP/IP device |

## Example

```python
import asyncio
from adbflow import ADB

async def main():
    adb = ADB()

    # List devices
    devices = await adb.devices_async()
    for d in devices:
        print(f"{d.serial} ({d.state})")

    # Connect to first device
    device = await adb.device_async()

    # Connect over TCP
    device = await adb.connect_async("192.168.1.50")

asyncio.run(main())
```

## Related

- [`Device`](device.md) — the object returned by `device_async()` and `connect_async()`
- [`SubprocessTransport`](types.md) — the transport layer used internally
