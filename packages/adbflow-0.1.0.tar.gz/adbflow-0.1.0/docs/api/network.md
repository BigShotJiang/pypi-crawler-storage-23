# Network

## NetworkManager

`adbflow.network.controls.NetworkManager`

Controls WiFi, mobile data, airplane mode, port forwarding, proxy, and packet capture. Access via `device.network`.

### WiFi

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `wifi_enable_async` | — | `None` | Enable WiFi |
| `wifi_disable_async` | — | `None` | Disable WiFi |
| `wifi_is_enabled_async` | — | `bool` | Check WiFi status |
| `wifi_info_async` | — | `WifiInfo \| None` | Get WiFi info |
| `wifi_connect_async` | `ssid, password=None, security=None` | `None` | Connect to network |

### Mobile Data

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `mobile_data_enable_async` | — | `None` | Enable mobile data |
| `mobile_data_disable_async` | — | `None` | Disable mobile data |
| `mobile_data_is_enabled_async` | — | `bool` | Check status |

### Airplane Mode

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `airplane_enable_async` | — | `None` | Enable airplane mode |
| `airplane_disable_async` | — | `None` | Disable airplane mode |
| `airplane_is_enabled_async` | — | `bool` | Check status |

### Port Forwarding

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `forward_async` | `local, remote` | `None` | Forward host → device |
| `forward_remove_async` | `local: str` | `None` | Remove a forward rule |
| `forward_remove_all_async` | — | `None` | Remove all forwards |
| `forward_list_async` | — | `list[ForwardRule]` | List active forwards |

### Reverse Forwarding

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `reverse_async` | `remote, local` | `None` | Forward device → host |
| `reverse_remove_async` | `remote: str` | `None` | Remove a reverse rule |
| `reverse_remove_all_async` | — | `None` | Remove all reverses |

### Proxy

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `proxy_set_async` | `config: ProxyConfig` | `None` | Set proxy |
| `proxy_clear_async` | — | `None` | Clear proxy |
| `proxy_get_async` | — | `ProxyConfig \| None` | Get current proxy |

### Packet Capture

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `tcpdump_start_async` | `output_path, interface=None, filter_expr=None` | `None` | Start capture |
| `tcpdump_stop_async` | — | `None` | Stop capture |
| `tcpdump_pull_async` | `local, remote="/sdcard/capture.pcap"` | `None` | Pull capture file |
