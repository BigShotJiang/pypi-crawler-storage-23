# Parallel

## DevicePool

`adbflow.parallel.pool.DevicePool`

Multi-device execution pool.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `devices` | `list[Device]` | Devices in the pool |

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `run_async` | `fn, *args, **kwargs` | `list[T \| BaseException]` | Run function on all devices in parallel |
| `run_sequential_async` | `fn, *args, **kwargs` | `list[T \| BaseException]` | Run function on devices sequentially |
| `filter_async` | `fn` | `list[Device]` | Filter devices by async predicate |
| `first_async` | `fn` | `Device \| None` | First device matching predicate |
| `__len__` | — | `int` | Number of devices |
| `__iter__` | — | `Iterator[Device]` | Iterate devices |

### Example

```python
from adbflow import ADB
from adbflow.parallel import DevicePool

adb = ADB()
entries = await adb.devices_async()
devices = [await adb.device_async(serial=e.serial) for e in entries]
pool = DevicePool(devices)

# Parallel execution
async def get_model(device):
    return await device.info.model_async()

results = await pool.run_async(get_model)

# Filter
async def is_android_14(device):
    sdk = await device.info.sdk_level_async()
    return sdk >= 34

android14_devices = await pool.filter_async(is_android_14)
```
