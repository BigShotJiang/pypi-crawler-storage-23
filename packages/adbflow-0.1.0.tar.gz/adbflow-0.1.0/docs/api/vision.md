# Vision

Requires the `[vision]` extra: `pip install adbflow[vision]`

## VisionManager

`adbflow.vision.manager.VisionManager`

Template matching and color detection on screenshots. Access via `device.vision`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `find_on_screen_async` | `template, threshold=0.8` | `MatchResult \| None` | Find template on screen |
| `find_all_on_screen_async` | `template, threshold=0.8` | `list[MatchResult]` | Find all matches |
| `tap_template_async` | `template, threshold=0.8` | `MatchResult` | Find and tap template |
| `wait_and_tap_async` | `template, timeout=10.0, threshold=0.8` | `MatchResult` | Wait for template, then tap |
| `find_color_async` | `color_rgb, tolerance=20, region=None` | `list[Point]` | Find pixels by color |

### Example

```python
# Find and tap
result = await device.vision.find_on_screen_async("button.png")
if result:
    print(f"Found at {result.center}, confidence: {result.confidence}")

# Wait and tap
await device.vision.wait_and_tap_async("play.png", timeout=10.0)

# Color detection
red_pixels = await device.vision.find_color_async((255, 0, 0), tolerance=20)
```

## TemplateMatcher

`adbflow.vision.template.TemplateMatcher`

Low-level image matching (no ADB dependency).

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `match` | `screenshot, template, threshold=0.8` | `MatchResult \| None` | Single match |
| `match_all` | `screenshot, template, threshold=0.8` | `list[MatchResult]` | All matches |
| `match_color` | `screenshot, color_rgb, tolerance=20, region=None` | `list[Point]` | Color match |
| `wait_for_template` | `get_screenshot, template, timeout=10.0, interval=0.5, threshold=0.8` | `MatchResult` | Poll for template |
