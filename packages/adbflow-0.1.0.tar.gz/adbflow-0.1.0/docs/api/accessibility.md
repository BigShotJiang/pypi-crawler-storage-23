# Accessibility

## AccessibilityManager

`adbflow.accessibility.manager.AccessibilityManager`

Manage accessibility services on the device. Access via `device.accessibility`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `list_services_async` | — | `list[AccessibilityService]` | List all accessibility services |
| `get_enabled_async` | — | `list[str]` | Get enabled service component names |
| `is_enabled_async` | `component: str` | `bool` | Check if service is enabled |
| `enable_async` | `component: str` | `None` | Enable a service |
| `disable_async` | `component: str` | `None` | Disable a service |

### Example

```python
a11y = device.accessibility

# List all services
services = await a11y.list_services_async()
for s in services:
    print(f"{s.component}: {s.label}")

# Check and toggle
component = "com.example.app/.MyA11yService"
if not await a11y.is_enabled_async(component):
    await a11y.enable_async(component)

# Get currently enabled
enabled = await a11y.get_enabled_async()
print(f"Enabled: {enabled}")
```
