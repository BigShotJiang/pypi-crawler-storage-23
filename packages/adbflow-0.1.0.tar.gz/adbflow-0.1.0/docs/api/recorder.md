# Recorder

## ActionRecorder

`adbflow.recorder.recorder.ActionRecorder`

Records a sequence of actions for later playback. Access via `device.recorder`.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `actions` | `list[RecordedAction]` | Recorded actions |

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `record_tap` | `x: int, y: int` | `None` | Record a tap |
| `record_swipe` | `x1, y1, x2, y2, duration=300` | `None` | Record a swipe |
| `record_key` | `keycode: int` | `None` | Record a key press |
| `record_text` | `text: str` | `None` | Record text input |
| `record_wait` | `seconds: float` | `None` | Record a pause |
| `record_shell` | `command: str` | `None` | Record a shell command |
| `clear` | — | `None` | Clear all recorded actions |
| `to_json` | — | `str` | Serialize to JSON string |
| `save` | `path: str` | `None` | Save to file |

### Class Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `from_json` | `json_str, serial="", transport=None` | `ActionRecorder` | Load from JSON string |
| `load` | `path, serial="", transport=None` | `ActionRecorder` | Load from file |

## ActionPlayer

`adbflow.recorder.player.ActionPlayer`

Replays recorded actions.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `play_async` | `actions, speed=1.0` | `None` | Play actions once |
| `play_loop_async` | `actions, count=1, speed=1.0` | `None` | Play actions in a loop |

### Example

```python
from adbflow.recorder import ActionPlayer

recorder = device.recorder
recorder.record_tap(500, 1000)
recorder.record_wait(0.5)
recorder.record_text("hello")
recorder.save("/tmp/actions.json")

player = ActionPlayer(device.transport, device.serial)
await player.play_async(recorder.actions)
await player.play_loop_async(recorder.actions, count=3, speed=2.0)
```
