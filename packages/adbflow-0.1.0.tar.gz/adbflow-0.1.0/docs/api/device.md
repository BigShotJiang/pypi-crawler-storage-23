# Device

`adbflow.device.device.Device`

The central user-facing object. All sub-modules (UI, gestures, apps, files, etc.) are accessible as lazy properties on `Device`.

```python
from adbflow import ADB

async def main():
    adb = ADB()
    device = await adb.device_async()
```

## Properties

| Property         | Type                    | Description                          |
| ---------------- | ----------------------- | ------------------------------------ |
| `serial`         | `str`                   | Device serial number                 |
| `transport`      | `SubprocessTransport`   | Underlying transport                 |

## Sub-Module Properties

All sub-modules are lazily initialized on first access via `cached_property`:

| Property          | Type                    | Description                          |
| ----------------- | ----------------------- | ------------------------------------ |
| `properties`      | `DeviceProperties`      | System property access               |
| `info`            | `DeviceInfo`            | Device information (model, SDK, etc) |
| `settings`        | `DeviceSettings`        | System/secure/global settings        |
| `power`           | `DevicePower`           | Power and screen controls            |
| `ime`             | `InputMethodManager`    | Input method management              |
| `files`           | [`FileManager`](files.md) | File operations                   |
| `apps`            | [`AppManager`](apps.md)   | App management                    |
| `media`           | [`MediaManager`](media.md) | Screenshots, recording, audio    |
| `logcat`          | [`LogcatManager`](logcat.md) | Log streaming and capture      |
| `network`         | [`NetworkManager`](network.md) | Network controls             |
| `gestures`        | [`GestureManager`](gestures.md) | Touch gestures              |
| `ui`              | [`UIManager`](ui.md)      | UI automation                      |
| `notifications`   | [`NotificationManager`](notifications.md) | Notification access |
| `accessibility`   | [`AccessibilityManager`](accessibility.md) | Accessibility services |
| `vision`          | [`VisionManager`](vision.md) | Template matching, color detection |
| `ocr`             | [`OCRManager`](ocr.md)    | Text recognition                   |
| `watchers`        | [`WatcherManager`](watchers.md) | Background UI watchers      |
| `recorder`        | [`ActionRecorder`](recorder.md) | Action recording            |

## Async Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `shell_async` | `command: str, timeout: float \| None = None` | `str` | Run shell command, return stdout |
| `shell_result_async` | `command: str, timeout: float \| None = None` | `Result` | Run shell command, return full result |
| `keyevent_async` | `key: KeyCode \| int` | `None` | Send a key event |
| `screenshot_async` | — | `bytes` | Capture screenshot as PNG bytes |
| `wait_for_text_async` | `text: str, timeout: float = 10.0` | `bool` | Wait for text in UI |
| `wait_for_activity_async` | `activity: str, timeout: float = 10.0` | `bool` | Wait for foreground activity |

## Sync Methods

| Method | Parameters | Returns |
| ------ | ---------- | ------- |
| `shell` | `command, timeout` | `str` |
| `shell_result` | `command, timeout` | `Result` |
| `keyevent` | `key` | `None` |

## DeviceProperties

`adbflow.device.properties.DeviceProperties`

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `get_async` | `name: str` | `str \| None` | Get a single property |
| `get_all_async` | `refresh: bool = False` | `dict[str, str]` | Get all properties |
| `set_async` | `name: str, value: str` | `None` | Set a property |
| `invalidate_cache` | — | `None` | Clear cached properties |

## DeviceInfo

`adbflow.device.info.DeviceInfo`

| Method | Returns | Description |
| ------ | ------- | ----------- |
| `model_async` | `str` | Device model name |
| `manufacturer_async` | `str` | Manufacturer |
| `android_version_async` | `str` | Android version string |
| `sdk_level_async` | `int` | SDK API level |
| `screen_size_async` | `Size \| None` | Screen resolution |
| `density_async` | `int \| None` | Display density (DPI) |
| `battery_async` | `BatteryInfo \| None` | Battery status |
| `ip_address_async` | `str \| None` | Device IP address |

## DeviceSettings

`adbflow.device.settings.DeviceSettings`

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `get_async` | `namespace, key` | `str \| None` | Get a setting |
| `put_async` | `namespace, key, value` | `None` | Set a setting |
| `delete_async` | `namespace, key` | `None` | Delete a setting |
| `list_async` | `namespace` | `dict[str, str]` | List all settings in namespace |

Namespace is one of `"system"`, `"secure"`, or `"global"`.

## DevicePower

`adbflow.device.power.DevicePower`

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `reboot_async` | `mode: RebootMode = SYSTEM` | `None` | Reboot device |
| `shutdown_async` | — | `None` | Shut down device |
| `wake_async` | — | `None` | Wake screen |
| `sleep_async` | — | `None` | Turn off screen |
| `lock_async` | — | `None` | Lock device |
| `unlock_async` | — | `None` | Unlock device |
| `is_screen_on_async` | — | `bool` | Check if screen is on |

## InputMethodManager

`adbflow.device.input_method.InputMethodManager`

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `list_async` | — | `list[str]` | List installed IMEs |
| `current_async` | — | `str \| None` | Get current IME |
| `set_async` | `ime_id: str` | `None` | Set active IME |
| `reset_async` | — | `None` | Reset to default IME |

## Example

```python
import asyncio
from adbflow import ADB

async def main():
    adb = ADB()
    device = await adb.device_async()

    # Device info
    model = await device.info.model_async()
    print(f"Model: {model}")

    # Shell command
    output = await device.shell_async("whoami")

    # Settings
    brightness = await device.settings.get_async("system", "screen_brightness")

    # Power
    await device.power.wake_async()
    is_on = await device.power.is_screen_on_async()

asyncio.run(main())
```
