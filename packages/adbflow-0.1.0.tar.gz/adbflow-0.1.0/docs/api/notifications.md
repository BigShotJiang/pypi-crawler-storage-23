# Notifications

## NotificationManager

`adbflow.notifications.manager.NotificationManager`

List, find, and wait for device notifications. Access via `device.notifications`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `list_async` | — | `list[Notification]` | List all notifications |
| `clear_all_async` | — | `None` | Clear all notifications |
| `find_async` | `package=None, title_contains=None, text_contains=None` | `list[Notification]` | Find matching notifications |
| `wait_for_async` | `package=None, title_contains=None, timeout=10.0, interval=1.0` | `Notification` | Wait for notification |

### Example

```python
# List all
notifications = await device.notifications.list_async()

# Find by package
msgs = await device.notifications.find_async(package="com.example.chat")

# Wait for a notification
notif = await device.notifications.wait_for_async(
    title_contains="Download complete",
    timeout=60.0
)
print(f"{notif.title}: {notif.text}")
```
