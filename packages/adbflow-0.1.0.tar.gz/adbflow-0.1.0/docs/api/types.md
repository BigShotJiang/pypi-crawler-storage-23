# Types

`adbflow.utils.types` — data types, enums, and protocols used throughout adbflow.

## Data Types

| Type | Fields | Description |
| ---- | ------ | ----------- |
| `Result` | `stdout, stderr, exit_code` | Shell command result |
| `DeviceListEntry` | `serial, state` | Device from `adb devices` |
| `Size` | `width, height` | Screen dimensions |
| `BatteryInfo` | `level, status, ...` | Battery state |
| `FileInfo` | `name, size, is_directory, ...` | File metadata |
| `FileChange` | `path, change_type, file_info` | File system change event |
| `SyncResult` | `transferred, skipped, ...` | Directory sync result |
| `PackageInfo` | `package, version_name, ...` | Package details |
| `PermissionInfo` | `name, granted` | Permission state |
| `RecordingOptions` | `time_limit, size, ...` | Screen recording config |
| `LogEntry` | `level, tag, message, ...` | Logcat entry |
| `CrashInfo` | `package, signal, ...` | Crash detection result |
| `ForwardRule` | `local, remote` | Port forward rule |
| `WifiInfo` | `ssid, ip_address, ...` | WiFi connection info |
| `ProxyConfig` | `host, port` | HTTP proxy config |
| `MatchResult` | `center, bounds, confidence` | Vision template match |
| `OCRResult` | `text, bounds, confidence` | OCR recognition result |
| `Notification` | `package, title, text, ...` | Device notification |
| `AccessibilityService` | `component, label, ...` | Accessibility service info |
| `RecordedAction` | `type, params, ...` | Recorded action for playback |

## Geometry

`adbflow.utils.geometry`

### Point

| Field/Method | Type | Description |
| ------------ | ---- | ----------- |
| `x` | `int` | X coordinate |
| `y` | `int` | Y coordinate |
| `offset(dx, dy)` | `Point` | Create offset point |
| `scale(factor)` | `Point` | Scale coordinates |
| `distance_to(other)` | `float` | Distance to another point |

### Rect

| Field/Method | Type | Description |
| ------------ | ---- | ----------- |
| `left, top, right, bottom` | `int` | Rectangle bounds |
| `center` | `Point` | Center point |
| `width, height, area` | `int` | Dimensions |
| `contains(point)` | `bool` | Point containment |
| `intersects(other)` | `bool` | Rectangle intersection test |
| `intersection(other)` | `Rect \| None` | Intersection rectangle |
| `from_ltwh(l, t, w, h)` | `Rect` | Create from left/top/width/height |
| `from_center(center, w, h)` | `Rect` | Create from center and size |

## Enums

| Enum | Values | Description |
| ---- | ------ | ----------- |
| `KeyCode` | `HOME, BACK, ENTER, VOLUME_UP, POWER, ...` | Android key codes |
| `SwipeDirection` | `UP, DOWN, LEFT, RIGHT` | Swipe directions |
| `Orientation` | `PORTRAIT, LANDSCAPE, ...` | Screen orientations |
| `InstallFlag` | `REPLACE, GRANT_PERMISSIONS, ...` | APK install flags |
| `DeviceState` | `DEVICE, OFFLINE, UNAUTHORIZED, ...` | ADB device states |
| `ConnectionType` | `USB, TCP` | Connection types |
| `RebootMode` | `SYSTEM, RECOVERY, BOOTLOADER` | Reboot modes |
| `PackageFilter` | `ALL, THIRD_PARTY, SYSTEM` | Package list filters |
| `IntentFlag` | Various Android intent flags | Intent flags |
| `AudioStream` | `MUSIC, NOTIFICATION, RING, ALARM, ...` | Audio stream types |
| `LogLevel` | `VERBOSE, DEBUG, INFO, WARNING, ERROR, FATAL` | Logcat levels |
| `FileChangeType` | `CREATED, MODIFIED, DELETED` | File change types |
| `ActionType` | `TAP, SWIPE, KEY, TEXT, WAIT, SHELL` | Recorded action types |
| `ErrorStrategy` | `STOP, SKIP` | Flow error handling |

## Exceptions

`adbflow.utils.exceptions`

| Exception | Base | Description |
| --------- | ---- | ----------- |
| `ADBFlowError` | `Exception` | Base exception for all adbflow errors |
| `ADBError` | `ADBFlowError` | General ADB command error |
| `DeviceNotFoundError` | `ADBFlowError` | No device found |
| `ElementNotFoundError` | `ADBFlowError` | UI element not found |
| `ADBTimeoutError` | `ADBFlowError` | Operation timed out |
| `ADBConnectionError` | `ADBFlowError` | Connection failure |
| `CommandBuildError` | `ADBFlowError` | Invalid command construction |
| `BinaryNotFoundError` | `ADBFlowError` | ADB binary not found |
| `FileOperationError` | `ADBFlowError` | File operation failure |
| `InstallError` | `ADBFlowError` | APK install failure |
| `PackageNotFoundError` | `ADBFlowError` | Package not on device |
| `VisionError` | `ADBFlowError` | Vision operation failure |
| `OCRError` | `ADBFlowError` | OCR operation failure |
| `WaitTimeoutError` | `ADBFlowError` | Wait condition timed out |

## Protocols

| Protocol | Method | Description |
| -------- | ------ | ----------- |
| `Condition` | `async __call__() -> bool` | Wait condition protocol |
| `TransportProtocol` | `execute, execute_shell, stream, ...` | Transport abstraction |

## Retry Utilities

`adbflow.utils.retry`

```python
from adbflow.utils.retry import retry, retry_call

# As decorator
@retry(max_attempts=3, delay=1.0, backoff=2.0, jitter=0.5)
async def flaky_operation():
    ...

# Direct call
result = await retry_call(func, max_attempts=3, delay=1.0)
```
