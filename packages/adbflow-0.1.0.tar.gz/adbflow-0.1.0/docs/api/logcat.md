# Logcat

## LogcatManager

`adbflow.logcat.stream.LogcatManager`

Stream, filter, and capture Android logs. Access via `device.logcat`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `stream_async` | `tags=None, level=None, pid=None, pattern=None, since=None` | `AsyncIterator[LogEntry]` | Stream log entries |
| `capture_async` | `output_path, duration=None, count=None, tags=None, level=None` | `None` | Capture logs to file |
| `clear_async` | — | `None` | Clear log buffer |
| `crash_detect_async` | `callback, packages=None` | `asyncio.Task[None]` | Monitor for crashes |

### Parameters

- `tags` — `list[str]` of logcat tags to filter
- `level` — `LogLevel` minimum level (VERBOSE, DEBUG, INFO, WARNING, ERROR, FATAL)
- `pid` — `int` process ID to filter
- `pattern` — `str` regex pattern to filter messages
- `since` — `str` timestamp to start from

### Example

```python
from adbflow.utils.types import LogLevel

# Stream errors from a specific tag
async for entry in device.logcat.stream_async(tags=["MyApp"], level=LogLevel.ERROR):
    print(f"{entry.tag}: {entry.message}")

# Capture logs for 10 seconds
await device.logcat.capture_async("/tmp/logs.txt", duration=10.0)

# Crash detection
def on_crash(info):
    print(f"Crash in {info.package}: {info.signal}")

task = await device.logcat.crash_detect_async(on_crash, packages=["com.example.app"])
```
