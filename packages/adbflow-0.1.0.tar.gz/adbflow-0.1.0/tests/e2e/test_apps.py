"""E2E tests for app management — install, start, stop, permissions, intents."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.apps.intent import Intent
from adbflow.device.device import Device
from adbflow.utils.types import PackageFilter

PKG = "com.adbflow.test"


class TestAppManagement:
    """App lifecycle operations."""

    async def test_is_installed(self, device: Device):
        assert await device.apps.is_installed_async(PKG)

    async def test_is_not_installed(self, device: Device):
        assert not await device.apps.is_installed_async("com.fake.nonexistent.pkg")

    async def test_list_all(self, device: Device):
        packages = await device.apps.list_async(PackageFilter.ALL)
        assert isinstance(packages, list)
        assert len(packages) > 0
        assert PKG in packages

    async def test_list_third_party(self, device: Device):
        packages = await device.apps.list_async(PackageFilter.THIRD_PARTY)
        assert PKG in packages

    async def test_list_system(self, device: Device):
        packages = await device.apps.list_async(PackageFilter.SYSTEM)
        assert PKG not in packages

    async def test_info(self, device: Device):
        info = await device.apps.info_async(PKG)
        assert info is not None
        assert info.package_name == PKG

    async def test_start_and_stop(self, device: Device):
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.5)
        current = await device.apps.current_async()
        assert current == PKG
        await device.apps.stop_async(PKG)

    async def test_current_app(self, device: Device):
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.5)
        current = await device.apps.current_async()
        assert current is not None
        assert current == PKG
        await device.apps.stop_async(PKG)

    async def test_clear_data(self, device: Device):
        """Write a marker file via the app, clear data, verify marker is gone."""
        marker = f"/sdcard/Android/data/{PKG}/files/launch_marker.txt"
        # Launch to create the marker
        await device.apps.start_async(PKG, ".MainActivity")
        import asyncio
        await asyncio.sleep(1.5)
        await device.apps.stop_async(PKG)

        # Marker should exist now
        exists = await device.files.exists_async(marker)
        assert exists, "launch_marker.txt should exist after launching the app"

        await device.apps.clear_data_async(PKG)
        await asyncio.sleep(0.5)

        # Marker should be gone after clear data
        exists = await device.files.exists_async(marker)
        assert not exists, "launch_marker.txt should be gone after clear_data"

    async def test_start_activity_with_intent(self, device: Device):
        intent = (
            Intent()
            .component(f"{PKG}/.SecondActivity")
            .extra_string("test_key", "hello")
        )
        await device.apps.start_activity_async(intent)
        await asyncio.sleep(1.5)
        # Verify SecondActivity is visible
        text_visible = await device.wait_for_text_async("Second Activity", timeout=5.0)
        assert text_visible
        await device.apps.stop_async(PKG)

    async def test_broadcast(self, device: Device):
        # Clear old markers
        await device.shell_async(
            f"rm -f /sdcard/Android/data/{PKG}/files/broadcast_marker.txt"
        )
        intent = Intent("com.adbflow.test.ACTION_TEST").component(
            f"{PKG}/.TestReceiver"
        )
        result = await device.apps.broadcast_async(intent)
        assert isinstance(result, str)
        await asyncio.sleep(1.0)
        # Check the broadcast marker was written
        exists = await device.files.exists_async(
            f"/sdcard/Android/data/{PKG}/files/broadcast_marker.txt"
        )
        assert exists


class TestAppPermissions:
    """Runtime permission management."""

    async def test_grant_and_is_granted(self, device: Device):
        perm = "android.permission.CAMERA"
        await device.apps.permissions.grant_async(PKG, perm)
        assert await device.apps.permissions.is_granted_async(PKG, perm)

    async def test_revoke(self, device: Device):
        perm = "android.permission.CAMERA"
        await device.apps.permissions.grant_async(PKG, perm)
        await device.apps.permissions.revoke_async(PKG, perm)
        assert not await device.apps.permissions.is_granted_async(PKG, perm)

    async def test_list_permissions(self, device: Device):
        permissions = await device.apps.permissions.list_async(PKG)
        assert isinstance(permissions, list)
        # Our app declares CAMERA, READ_CONTACTS, POST_NOTIFICATIONS
        perm_names = [p.name for p in permissions]
        assert any("CAMERA" in p for p in perm_names)
