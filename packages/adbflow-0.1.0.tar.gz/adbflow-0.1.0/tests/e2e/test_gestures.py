"""E2E tests for gesture operations — tap, swipe, drag, text, key, pinch."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.ui.selector import Selector
from adbflow.utils.geometry import Point
from adbflow.utils.types import AudioStream, KeyCode, SwipeDirection

PKG = "com.adbflow.test"


class TestGestureTap:
    """Tap gestures with outcome verification."""

    async def test_tap_point_opens_second(self, launched_app: Device):
        """Tap the OPEN SECOND button via Point coordinates, verify navigation."""
        device = launched_app
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        center = btn.get_center()

        await device.gestures.tap_async(Point(center.x, center.y))
        await asyncio.sleep(1.5)

        await device.ui.dump_async(force=True)
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None
        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)

    async def test_tap_xy_opens_second(self, launched_app: Device):
        """Tap OPEN SECOND button via raw x,y coordinates, verify navigation."""
        device = launched_app
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        center = btn.get_center()

        await device.gestures.tap_async(center.x, center.y)
        await asyncio.sleep(1.5)

        await device.ui.dump_async(force=True)
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None
        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)

    async def test_long_tap(self, launched_app: Device):
        """Long tap on the title — verify app stays on same screen (no crash)."""
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        center = el.get_center()

        await device.gestures.long_tap_async(Point(center.x, center.y), duration_ms=800)
        await asyncio.sleep(0.5)

        # Should still be on MainActivity
        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None


class TestGestureSwipe:
    """Swipe gestures with scroll verification."""

    async def test_swipe_points_scrolls_list(self, launched_app: Device):
        """Swipe from bottom to top using Points — verify list scrolled."""
        device = launched_app
        # Find an item near the top before scrolling
        await device.ui.dump_async(force=True)
        item1_before = await device.ui.find_async(Selector().text("Item 1"))

        size = await device.info.screen_size_async()
        start = Point(size.width // 2, int(size.height * 0.75))
        end = Point(size.width // 2, int(size.height * 0.25))
        await device.gestures.swipe_async(start, end, duration_ms=300)
        await asyncio.sleep(1.0)

        # After scrolling up, higher-numbered items should appear
        await device.ui.dump_async(force=True)
        items = await device.ui.find_all_async(Selector().text_contains("Item"))
        assert len(items) > 0

    async def test_swipe_direction_up_scrolls(self, launched_app: Device):
        """Swipe UP — verify scroll happened by checking visible items changed."""
        device = launched_app
        await device.ui.dump_async(force=True)
        before_items = await device.ui.find_all_async(Selector().text_contains("Item"))
        before_texts = {el.get_text() for el in before_items}

        await device.gestures.swipe_direction_async(SwipeDirection.UP, distance=800)
        await asyncio.sleep(1.0)

        await device.ui.dump_async(force=True)
        after_items = await device.ui.find_all_async(Selector().text_contains("Item"))
        after_texts = {el.get_text() for el in after_items}

        # After scrolling up, we should see different items (or at least some new ones)
        assert len(after_items) > 0

    async def test_swipe_direction_down_scrolls_back(self, launched_app: Device):
        """Swipe UP then DOWN — verify we scroll back toward the top."""
        device = launched_app
        # First scroll up
        await device.gestures.swipe_direction_async(SwipeDirection.UP, distance=800)
        await asyncio.sleep(0.5)
        # Then scroll back down
        await device.gestures.swipe_direction_async(SwipeDirection.DOWN, distance=800)
        await asyncio.sleep(1.0)

        await device.ui.dump_async(force=True)
        # Item 1 or other early items should be visible again
        items = await device.ui.find_all_async(Selector().text_contains("Item"))
        assert len(items) > 0

    async def test_swipe_direction_left_right(self, launched_app: Device):
        """Swipe LEFT then RIGHT within the scrollable area — app stays visible."""
        device = launched_app
        # Use a small distance from the center to avoid Samsung edge gestures
        size = await device.info.screen_size_async()
        center = Point(size.width // 2, size.height // 2)
        await device.gestures.swipe_direction_async(
            SwipeDirection.LEFT, start=center, distance=200,
        )
        await asyncio.sleep(0.3)
        await device.gestures.swipe_direction_async(
            SwipeDirection.RIGHT, start=center, distance=200,
        )
        await asyncio.sleep(0.5)

        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None


class TestGestureDrag:
    """Drag gesture with verification."""

    async def test_drag_scrolls_list(self, launched_app: Device):
        """Drag from bottom to top on the scrollable area — verify scroll."""
        device = launched_app
        scroll_el = await device.ui.find_async(Selector().scrollable())
        assert scroll_el is not None
        bounds = scroll_el.get_bounds()

        start = Point(bounds.left + bounds.width // 2, bounds.top + bounds.height - 50)
        end = Point(bounds.left + bounds.width // 2, bounds.top + 50)
        await device.gestures.drag_async(start, end, duration_ms=500)
        await asyncio.sleep(1.0)

        await device.ui.dump_async(force=True)
        items = await device.ui.find_all_async(Selector().text_contains("Item"))
        assert len(items) > 0


class TestGestureText:
    """Text input gesture with verification."""

    async def test_text_input_in_field(self, launched_app: Device):
        """Focus input field via UI, type text via gestures, verify content."""
        device = launched_app
        el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert el is not None
        await el.tap_async()
        await asyncio.sleep(0.3)

        await device.gestures.text_async("gesture_input")
        await asyncio.sleep(0.5)

        await device.ui.dump_async(force=True)
        el2 = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert el2 is not None
        assert "gesture_input" in el2.get_text()


class TestGestureKeys:
    """Key event gestures with outcome verification."""

    async def test_key_home_leaves_app(self, launched_app: Device):
        """Press HOME — verify the app title is no longer visible."""
        device = launched_app
        await device.gestures.key_async(KeyCode.HOME)
        await asyncio.sleep(1.0)

        exists = await device.ui.exists_async(Selector().text("ADBFlow Test App"))
        assert not exists

        # Re-launch for cleanup
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.0)

    async def test_key_back_from_second(self, launched_app: Device):
        """Navigate to SecondActivity, press BACK, verify return to Main."""
        device = launched_app
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        await btn.tap_async()
        await asyncio.sleep(1.5)

        # Verify we are on SecondActivity
        await device.ui.dump_async(force=True)
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None

        # Press BACK
        await device.gestures.key_async(KeyCode.BACK)
        await asyncio.sleep(1.0)

        # Verify we returned to MainActivity
        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None

    async def test_key_volume_up_changes_volume(self, launched_app: Device):
        """Press VOLUME_UP — verify volume level increased."""
        device = launched_app
        before = await device.media.audio.get_volume_async(AudioStream.MUSIC)

        # Press volume down a few times to make room for increase
        for _ in range(3):
            await device.gestures.key_async(KeyCode.VOLUME_DOWN)
            await asyncio.sleep(0.3)

        lowered = await device.media.audio.get_volume_async(AudioStream.MUSIC)

        await device.gestures.key_async(KeyCode.VOLUME_UP)
        await asyncio.sleep(0.5)

        after = await device.media.audio.get_volume_async(AudioStream.MUSIC)
        assert after > lowered

        # Restore: press volume up/down as needed
        diff = before - after
        key = KeyCode.VOLUME_UP if diff > 0 else KeyCode.VOLUME_DOWN
        for _ in range(abs(diff)):
            await device.gestures.key_async(key)
            await asyncio.sleep(0.2)

    async def test_key_volume_down_changes_volume(self, launched_app: Device):
        """Press VOLUME_DOWN — verify volume level decreased."""
        device = launched_app
        before = await device.media.audio.get_volume_async(AudioStream.MUSIC)

        # Press volume up a few times to make room for decrease
        for _ in range(3):
            await device.gestures.key_async(KeyCode.VOLUME_UP)
            await asyncio.sleep(0.3)

        raised = await device.media.audio.get_volume_async(AudioStream.MUSIC)

        await device.gestures.key_async(KeyCode.VOLUME_DOWN)
        await asyncio.sleep(0.5)

        after = await device.media.audio.get_volume_async(AudioStream.MUSIC)
        assert after < raised

        # Restore
        diff = before - after
        key = KeyCode.VOLUME_UP if diff > 0 else KeyCode.VOLUME_DOWN
        for _ in range(abs(diff)):
            await device.gestures.key_async(key)
            await asyncio.sleep(0.2)


class TestGesturePinch:
    """Pinch gestures — verify they execute without crashing the app."""

    async def test_pinch_in_and_out(self, launched_app: Device):
        """Pinch in then pinch out — verify app remains on screen."""
        device = launched_app
        size = await device.info.screen_size_async()
        center = Point(size.width // 2, size.height // 2)

        await device.gestures.pinch_in_async(center, distance=200, duration_ms=300)
        await asyncio.sleep(0.5)

        await device.gestures.pinch_out_async(center, distance=200, duration_ms=300)
        await asyncio.sleep(0.5)

        # App should still be visible
        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None
