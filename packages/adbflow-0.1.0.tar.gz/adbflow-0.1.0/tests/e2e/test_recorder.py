"""E2E tests for action recorder and player — visible interactions on device."""

from __future__ import annotations

import asyncio
import json
import tempfile
from pathlib import Path

import pytest

from adbflow.device.device import Device
from adbflow.recorder.player import ActionPlayer
from adbflow.recorder.recorder import ActionRecorder
from adbflow.ui.selector import Selector
from adbflow.utils.types import ActionType, KeyCode

PKG = "com.adbflow.test"


class TestActionRecorder:
    """Recording actions stores correct metadata."""

    async def test_record_tap(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_tap(540, 960)
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.TAP
        assert rec.actions[0].params == {"x": 540, "y": 960}

    async def test_record_swipe(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_swipe(100, 500, 100, 200, duration=400)
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.SWIPE
        assert rec.actions[0].params["duration"] == 400

    async def test_record_key(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_key(int(KeyCode.HOME))
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.KEY

    async def test_record_text(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_text("hello world")
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.TEXT
        assert rec.actions[0].params["text"] == "hello world"

    async def test_record_wait(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_wait(1.5)
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.WAIT

    async def test_record_shell(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_shell("echo test")
        assert len(rec.actions) == 1
        assert rec.actions[0].action_type == ActionType.SHELL

    async def test_clear(self, device: Device):
        rec = device.recorder
        rec.record_tap(1, 2)
        rec.clear()
        assert len(rec.actions) == 0


class TestRecorderSerialization:
    """JSON serialization and file save/load."""

    async def test_to_json_from_json(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_tap(100, 200)
        rec.record_text("abc")
        rec.record_wait(0.5)

        json_str = rec.to_json()
        data = json.loads(json_str)
        assert len(data) == 3

        restored = ActionRecorder.from_json(
            json_str, serial=device.serial, transport=device.transport,
        )
        assert len(restored.actions) == 3
        assert restored.actions[0].action_type == ActionType.TAP

    async def test_save_load(self, device: Device):
        rec = device.recorder
        rec.clear()
        rec.record_tap(10, 20)
        rec.record_key(4)

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name

        rec.save(path)
        assert Path(path).exists()

        loaded = ActionRecorder.load(
            path, serial=device.serial, transport=device.transport,
        )
        assert len(loaded.actions) == 2
        Path(path).unlink(missing_ok=True)


class TestActionPlayer:
    """Replaying recorded actions visibly on a real device."""

    async def test_play_tap_button(self, launched_app: Device):
        """Record tapping the 'OPEN SECOND' button, play it, verify navigation."""
        device = launched_app
        # Find the button to get its coordinates
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        center = btn.get_center()

        rec = device.recorder
        rec.clear()
        rec.record_tap(center.x, center.y)

        player = ActionPlayer(device.serial, device.transport)
        await player.play_async(rec.actions)
        await asyncio.sleep(1.5)

        # Verify we navigated to SecondActivity
        await device.ui.dump_async(force=True)
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None

        # Go back
        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)

    async def test_play_text_input(self, launched_app: Device):
        """Record typing text into the input field, play it, verify text appears."""
        device = launched_app

        # Tap the input field first to focus it
        el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert el is not None
        await el.tap_async()
        await asyncio.sleep(0.5)

        rec = device.recorder
        rec.clear()
        rec.record_text("recorder_test")

        player = ActionPlayer(device.serial, device.transport)
        await player.play_async(rec.actions)
        await asyncio.sleep(0.5)

        # Verify text was entered — force re-dump the UI
        await device.ui.dump_async(force=True)
        el2 = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field"),
        )
        assert el2 is not None
        assert "recorder_test" in el2.get_text()

    async def test_play_swipe_scroll(self, launched_app: Device):
        """Record a swipe gesture to scroll the list, play it."""
        device = launched_app
        await asyncio.sleep(0.5)

        # Check an item near the bottom isn't visible initially
        info = await device.info.screen_size_async()
        mid_x = info.width // 2
        start_y = int(info.height * 0.75)
        end_y = int(info.height * 0.25)

        rec = device.recorder
        rec.clear()
        rec.record_swipe(mid_x, start_y, mid_x, end_y, duration=300)

        player = ActionPlayer(device.serial, device.transport)
        await player.play_async(rec.actions)
        await asyncio.sleep(1.0)

        # After scrolling, later items should be visible
        await device.ui.dump_async(force=True)
        el = await device.ui.find_async(
            Selector().text_contains("Item"),
        )
        assert el is not None

    async def test_play_key_events(self, launched_app: Device):
        """Record key events (HOME then relaunch), play them, verify state."""
        device = launched_app

        rec = device.recorder
        rec.clear()
        rec.record_key(int(KeyCode.HOME))
        rec.record_wait(1.0)

        player = ActionPlayer(device.serial, device.transport)
        await player.play_async(rec.actions)
        await asyncio.sleep(0.5)

        # We should be at home screen — the app title should not be visible
        exists = await device.ui.exists_async(Selector().text("ADBFlow Test App"))
        assert not exists

        # Re-launch for cleanup
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.0)

    async def test_play_multi_step_workflow(self, launched_app: Device):
        """Record a full workflow: tap button → wait → go back. Play it twice."""
        device = launched_app

        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        center = btn.get_center()

        rec = device.recorder
        rec.clear()
        rec.record_tap(center.x, center.y)   # tap OPEN SECOND
        rec.record_wait(1.5)                   # wait for navigation
        rec.record_key(4)                      # BACK
        rec.record_wait(0.5)                   # settle

        player = ActionPlayer(device.serial, device.transport)

        # Play loop — do the workflow twice
        await player.play_loop_async(rec.actions, count=2)
        await asyncio.sleep(0.5)

        # Should be back on MainActivity after both loops
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None

    async def test_play_shell_command(self, launched_app: Device):
        """Record a shell command, play it, verify side effect."""
        device = launched_app
        marker = "/sdcard/Android/data/com.adbflow.test/files/recorder_test.txt"

        rec = device.recorder
        rec.clear()
        rec.record_shell(f"echo 'played' > {marker}")

        player = ActionPlayer(device.serial, device.transport)
        await player.play_async(rec.actions)
        await asyncio.sleep(0.5)

        # Verify file was created
        exists = await device.files.exists_async(marker)
        assert exists
        content = await device.files.cat_async(marker)
        assert "played" in content

        # Cleanup
        await device.files.rm_async(marker, force=True)

    async def test_play_loop_tap_second_and_type(self, launched_app: Device):
        """Tap OPEN SECOND → go back → type 'loop_test' in input field, loop 5 times."""
        device = launched_app

        # Get button coordinates
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        btn_center = btn.get_center()

        # Get input field coordinates
        input_el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert input_el is not None
        input_center = input_el.get_center()

        rec = device.recorder
        rec.clear()
        # Step 1: Tap "OPEN SECOND" button
        rec.record_tap(btn_center.x, btn_center.y)
        rec.record_wait(1.5)
        # Step 2: Press BACK to return to MainActivity
        rec.record_key(4)  # BACK
        rec.record_wait(1.0)
        # Step 3: Tap the input field to focus it
        rec.record_tap(input_center.x, input_center.y)
        rec.record_wait(0.3)
        # Step 4: Type "loop_test"
        rec.record_text("loop_test")
        rec.record_wait(0.5)
        # Step 5: Clear the input field for next iteration
        # Delete 9 chars ("loop_test") one by one
        for _ in range(9):
            rec.record_key(int(KeyCode.DELETE))
        rec.record_wait(0.3)

        player = ActionPlayer(device.serial, device.transport)
        await player.play_loop_async(rec.actions, count=5)
        await asyncio.sleep(0.5)

        # After 5 loops we should still be on MainActivity
        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None
