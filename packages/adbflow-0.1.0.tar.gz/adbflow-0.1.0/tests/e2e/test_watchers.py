"""E2E tests for UI watchers — real dialog auto-dismiss on device."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.ui.selector import Selector
from adbflow.watchers.manager import click_watcher, dismiss_watcher

PKG = "com.adbflow.test"


class TestWatcherLifecycle:
    """Watcher registration, start, stop — verified against device state."""

    async def test_register_start_stop_unregister(self, device: Device):
        """Full lifecycle: register a watcher, start polling, stop, unregister."""
        sel = Selector().text("Dummy")

        async def noop(el):
            pass

        device.watchers.register("lifecycle_w", sel, noop)
        assert "lifecycle_w" in device.watchers.list_watchers()
        assert not device.watchers.is_running

        await device.watchers.start_async(interval=2.0)
        assert device.watchers.is_running

        # Let it poll at least once (hitting the real device UI dump)
        await asyncio.sleep(3.0)

        await device.watchers.stop_async()
        assert not device.watchers.is_running

        device.watchers.unregister("lifecycle_w")
        assert "lifecycle_w" not in device.watchers.list_watchers()


class TestWatcherAutoDismiss:
    """Watchers that auto-dismiss dialogs on a real device."""

    async def test_auto_dismiss_dialog(self, launched_app: Device):
        """Register dismiss watcher, open DialogActivity, verify auto-dismissed."""
        device = launched_app

        name, sel, action = dismiss_watcher("dismiss_test", "Dismiss")
        device.watchers.register(name, sel, action)
        await device.watchers.start_async(interval=0.5)

        # Open DialogActivity — shows an AlertDialog with "Dismiss" button
        await device.apps.start_async(PKG, ".DialogActivity")
        await asyncio.sleep(3.0)

        # Dialog should have been auto-dismissed by the watcher
        await device.ui.dump_async(force=True)
        dialog_gone = not await device.ui.exists_async(Selector().text("Test Dialog"))
        assert dialog_gone

        await device.watchers.stop_async()
        device.watchers.unregister(name)

    async def test_auto_dismiss_dialog_multiple_times(self, launched_app: Device):
        """Open dialog 3 times in a row — watcher should dismiss each time."""
        device = launched_app

        name, sel, action = dismiss_watcher("dismiss_multi", "Dismiss")
        device.watchers.register(name, sel, action)
        await device.watchers.start_async(interval=0.5)

        for i in range(3):
            await device.apps.start_async(PKG, ".DialogActivity")
            await asyncio.sleep(2.5)

            await device.ui.dump_async(force=True)
            dialog_gone = not await device.ui.exists_async(Selector().text("Test Dialog"))
            assert dialog_gone, f"Dialog not dismissed on iteration {i + 1}"

        await device.watchers.stop_async()
        device.watchers.unregister(name)

    async def test_click_watcher_taps_button(self, launched_app: Device):
        """Click watcher auto-taps OPEN SECOND when it appears, causing navigation."""
        device = launched_app

        name, sel, action = click_watcher(
            "click_second", Selector().text("OPEN SECOND"),
        )
        device.watchers.register(name, sel, action)
        await device.watchers.start_async(interval=0.5)

        # The watcher should detect and click OPEN SECOND
        await asyncio.sleep(3.0)

        # We should have navigated to SecondActivity
        await device.ui.dump_async(force=True)
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None

        await device.watchers.stop_async()
        device.watchers.unregister(name)

        # Go back for cleanup
        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)
