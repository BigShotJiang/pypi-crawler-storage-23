"""E2E tests for notification management."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.apps.intent import Intent
from adbflow.device.device import Device
from adbflow.utils.exceptions import WaitTimeoutError

PKG = "com.adbflow.test"


class TestNotifications:
    """Notification listing, filtering, and waiting."""

    async def test_clear_all_and_verify_empty(self, device: Device):
        """Clear all notifications, then list — should find none from our package."""
        await device.notifications.clear_all_async()
        await asyncio.sleep(0.5)
        matches = await device.notifications.find_async(package=PKG)
        assert len(matches) == 0

    async def test_trigger_and_find_by_package(self, device: Device):
        """Trigger a notification via broadcast, find it by package."""
        await device.notifications.clear_all_async()
        await asyncio.sleep(0.5)

        # Grant POST_NOTIFICATIONS for Android 13+ (SDK 33+)
        sdk = await device.info.sdk_level_async()
        if sdk >= 33:
            await device.apps.permissions.grant_async(
                PKG, "android.permission.POST_NOTIFICATIONS",
            )

        # Trigger notification via broadcast with notify=true
        intent = (
            Intent("com.adbflow.test.ACTION_TEST")
            .component(f"{PKG}/.TestReceiver")
            .extra_bool("notify", True)
        )
        await device.apps.broadcast_async(intent)
        await asyncio.sleep(2.0)

        matches = await device.notifications.find_async(package=PKG)
        assert len(matches) >= 1

    async def test_find_by_title(self, device: Device):
        """Find notification by title (relies on previous test's notification)."""
        matches = await device.notifications.find_async(title_contains="ADBFlow Test")
        assert len(matches) >= 1

    async def test_find_by_text(self, device: Device):
        """Find notification by body text."""
        matches = await device.notifications.find_async(
            text_contains="Notification from test app"
        )
        assert len(matches) >= 1

    async def test_wait_for_immediate(self, device: Device):
        """Notification still exists — wait should resolve immediately."""
        notification = await device.notifications.wait_for_async(
            package=PKG, timeout=5.0
        )
        assert notification.package == PKG

    async def test_list_contains_notification(self, device: Device):
        """List all notifications — our test notification should appear."""
        notifications = await device.notifications.list_async()
        assert isinstance(notifications, list)
        assert any(n.package == PKG for n in notifications)

    async def test_wait_for_timeout(self, device: Device):
        """Clear notifications, wait for a non-existent one — should timeout."""
        await device.notifications.clear_all_async()
        await asyncio.sleep(0.5)
        with pytest.raises(WaitTimeoutError):
            await device.notifications.wait_for_async(
                title_contains="ThisWillNeverAppearXYZ999",
                timeout=2.0,
            )
