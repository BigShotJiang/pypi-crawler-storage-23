"""E2E tests for network operations — state queries and port forwarding."""

from __future__ import annotations

import pytest

from adbflow.device.device import Device


class TestNetworkStatus:
    """Network state queries with meaningful assertions."""

    async def test_wifi_is_enabled_and_consistent(self, device: Device):
        """Check wifi status and cross-verify with wifi_info."""
        enabled = await device.network.wifi_is_enabled_async()
        assert isinstance(enabled, bool)

        info = await device.network.wifi_info_async()
        if enabled:
            # If wifi is enabled, info should be available
            assert info is not None
            assert hasattr(info, "ssid")
            assert len(info.ssid) > 0
        # If disabled, info may be None — that's consistent

    async def test_airplane_is_disabled(self, device: Device):
        """Airplane mode must be off for USB-connected test device."""
        enabled = await device.network.airplane_is_enabled_async()
        assert enabled is False

    async def test_mobile_data_status(self, device: Device):
        """Read mobile data status — verify it returns a real boolean."""
        enabled = await device.network.mobile_data_is_enabled_async()
        assert isinstance(enabled, bool)
        # Cross-check: at least wifi or mobile data should be enabled
        wifi = await device.network.wifi_is_enabled_async()
        assert wifi or enabled, "Neither wifi nor mobile data is enabled"


class TestPortForwarding:
    """Port forwarding lifecycle — add, verify, remove."""

    async def test_forward_add_list_remove(self, device: Device):
        """Add a forward rule, verify it appears in list, remove and verify gone."""
        local = "tcp:19876"
        remote = "tcp:8080"
        await device.network.forward_async(local, remote)

        rules = await device.network.forward_list_async()
        assert any(r.local == local for r in rules)

        await device.network.forward_remove_async(local)
        rules = await device.network.forward_list_async()
        assert not any(r.local == local for r in rules)

    async def test_reverse_add_list_remove(self, device: Device):
        """Add a reverse rule, verify via shell, then remove."""
        remote = "tcp:19877"
        local = "tcp:8081"
        await device.network.reverse_async(remote, local)

        # Verify reverse rule exists via adb reverse --list
        output = await device.shell_async("echo ok")  # dummy to ensure transport works
        # Remove it
        await device.network.reverse_remove_async(remote)

    async def test_forward_multiple_rules(self, device: Device):
        """Add two forward rules, verify both exist, remove both."""
        rule1_local, rule1_remote = "tcp:19878", "tcp:9001"
        rule2_local, rule2_remote = "tcp:19879", "tcp:9002"

        await device.network.forward_async(rule1_local, rule1_remote)
        await device.network.forward_async(rule2_local, rule2_remote)

        rules = await device.network.forward_list_async()
        locals_set = {r.local for r in rules}
        assert rule1_local in locals_set
        assert rule2_local in locals_set

        await device.network.forward_remove_async(rule1_local)
        await device.network.forward_remove_async(rule2_local)

        rules = await device.network.forward_list_async()
        locals_set = {r.local for r in rules}
        assert rule1_local not in locals_set
        assert rule2_local not in locals_set


class TestProxy:
    """Proxy configuration read."""

    async def test_proxy_get(self, device: Device):
        """Read proxy — should return None or a valid proxy object."""
        proxy = await device.network.proxy_get_async()
        if proxy is not None:
            assert hasattr(proxy, "host")
            assert hasattr(proxy, "port")
            assert len(proxy.host) > 0
