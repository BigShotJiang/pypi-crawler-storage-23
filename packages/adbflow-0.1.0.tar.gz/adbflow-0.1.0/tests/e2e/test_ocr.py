"""E2E tests for OCR module — text recognition on live screen."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.utils.exceptions import OCRError, WaitTimeoutError

PKG = "com.adbflow.test"

try:
    import easyocr
    HAS_EASYOCR = True
except ImportError:
    HAS_EASYOCR = False

pytestmark = pytest.mark.skipif(not HAS_EASYOCR, reason="easyocr not installed")


class TestOCRReadScreen:
    """Read text from screen using OCR."""

    async def test_read_screen(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(1.0)
        results = await device.ocr.read_screen_async()
        assert isinstance(results, list)
        assert len(results) > 0
        # Should find some text from our app
        all_text = " ".join(r.text for r in results)
        assert len(all_text) > 0

    async def test_find_text(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(1.0)
        # Try to find a known text on screen
        # OCR may not match exactly, so use find_text_contains
        results = await device.ocr.find_text_contains_async("ADBFlow")
        assert len(results) >= 1

    async def test_find_text_not_found(self, launched_app: Device):
        device = launched_app
        result = await device.ocr.find_text_async("ZZZYYYXXX_NONEXISTENT_99")
        assert result is None


class TestOCRTap:
    """Tap on OCR-detected text."""

    async def test_tap_text(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(1.0)
        # Try tapping on a text that contains "Second" (button text)
        results = await device.ocr.find_text_contains_async("Second")
        if len(results) > 0:
            # Use tap_text with the exact matched text
            try:
                result = await device.ocr.tap_text_async(results[0].text)
                assert result is not None
                await asyncio.sleep(1.0)
                await device.keyevent_async(4)  # BACK
                await asyncio.sleep(0.5)
            except OCRError:
                pytest.skip("OCR text changed between find and tap")

    async def test_tap_text_not_found(self, launched_app: Device):
        device = launched_app
        with pytest.raises(OCRError):
            await device.ocr.tap_text_async("IMPOSSIBLE_TEXT_999_XYZ")


class TestOCRWait:
    """Wait for text to appear via OCR."""

    async def test_wait_for_text(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(1.0)
        # Text should already be on screen
        results = await device.ocr.find_text_contains_async("ADBFlow")
        if results:
            result = await device.ocr.wait_for_text_async(
                results[0].text, timeout=10.0,
            )
            assert result is not None
        else:
            pytest.skip("Could not find initial text via OCR")

    async def test_wait_for_text_timeout(self, launched_app: Device):
        device = launched_app
        with pytest.raises(WaitTimeoutError):
            await device.ocr.wait_for_text_async(
                "NEVER_APPEARING_TEXT_XYZ", timeout=3.0,
            )
