"""E2E tests for vision module — template matching and color detection."""

from __future__ import annotations

import asyncio
import io

import pytest
from PIL import Image

from adbflow.device.device import Device
from adbflow.utils.exceptions import VisionError, WaitTimeoutError

PKG = "com.adbflow.test"

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

pytestmark = pytest.mark.skipif(not HAS_OPENCV, reason="opencv not installed")


async def _crop_template(device: Device, x: int, y: int, w: int, h: int) -> Image.Image:
    """Capture screenshot and crop a region as a template."""
    data = await device.media.screenshot.capture_async()
    img = Image.open(io.BytesIO(data))
    return img.crop((x, y, x + w, y + h))


class TestVisionFindOnScreen:
    """Template matching against live screen."""

    async def test_find_on_screen(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(0.5)
        # Capture a template from the title area
        template = await _crop_template(device, 50, 50, 200, 60)
        result = await device.vision.find_on_screen_async(template, threshold=0.7)
        assert result is not None
        assert result.confidence >= 0.7

    async def test_find_on_screen_not_found(self, launched_app: Device):
        device = launched_app
        # Create a checkerboard pattern unlikely to match anything on screen
        template = Image.new("RGB", (100, 100), (0, 0, 0))
        pixels = template.load()
        for x in range(100):
            for y in range(100):
                if (x // 5 + y // 5) % 2 == 0:
                    pixels[x, y] = (255, 0, 255)
                else:
                    pixels[x, y] = (0, 255, 0)
        result = await device.vision.find_on_screen_async(template, threshold=0.9)
        assert result is None

    async def test_find_all_on_screen(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(0.5)
        template = await _crop_template(device, 50, 50, 200, 60)
        results = await device.vision.find_all_on_screen_async(template, threshold=0.7)
        assert isinstance(results, list)
        assert len(results) >= 1


class TestVisionTap:
    """Tap on template matches."""

    async def test_tap_template(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(0.5)
        # Capture a template from a button area
        btn = await device.ui.find_async(
            __import__("adbflow.ui.selector", fromlist=["Selector"]).Selector().text("OPEN SECOND")
        )
        if btn is not None:
            bounds = btn.get_bounds()
            template = await _crop_template(
                device, bounds.left, bounds.top, bounds.width, bounds.height,
            )
            result = await device.vision.tap_template_async(template, threshold=0.6)
            assert result is not None
            await asyncio.sleep(1.0)
            await device.keyevent_async(4)  # BACK
            await asyncio.sleep(0.5)

    async def test_tap_template_not_found(self, launched_app: Device):
        device = launched_app
        # Create a checkerboard pattern that won't match
        template = Image.new("RGB", (100, 100), (0, 0, 0))
        pixels = template.load()
        for x in range(100):
            for y in range(100):
                if (x // 5 + y // 5) % 2 == 0:
                    pixels[x, y] = (255, 0, 255)
                else:
                    pixels[x, y] = (0, 255, 0)
        with pytest.raises(VisionError):
            await device.vision.tap_template_async(template, threshold=0.9)


class TestVisionWait:
    """Wait for template to appear."""

    async def test_wait_and_tap(self, launched_app: Device):
        device = launched_app
        await asyncio.sleep(0.5)
        # Template already on screen
        template = await _crop_template(device, 50, 50, 200, 60)
        result = await device.vision.wait_and_tap_async(
            template, timeout=5.0, threshold=0.7,
        )
        assert result is not None


class TestVisionColor:
    """Color detection on screen."""

    async def test_find_color(self, launched_app: Device):
        device = launched_app
        # Take screenshot, pick a pixel color, and search for it
        data = await device.media.screenshot.capture_async()
        img = Image.open(io.BytesIO(data))
        # Get the color at (100, 100)
        pixel = img.getpixel((100, 100))
        if len(pixel) == 4:
            r, g, b = pixel[0], pixel[1], pixel[2]
        else:
            r, g, b = pixel[0], pixel[1], pixel[2]

        points = await device.vision.find_color_async((r, g, b), tolerance=10)
        assert isinstance(points, list)
        assert len(points) > 0
