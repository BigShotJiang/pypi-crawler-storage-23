"""E2E tests for flow engine — step execution with real device interactions."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.flow.engine import Flow
from adbflow.flow.step import FlowContext
from adbflow.ui.selector import Selector
from adbflow.utils.types import ErrorStrategy

PKG = "com.adbflow.test"


class TestFlow:
    """Flow execution with real device operations in every step."""

    async def test_simple_shell_flow(self, device: Device):
        """Flow that runs a shell command and captures its output."""
        flow = Flow("simple", device)

        async def run_echo(ctx: FlowContext):
            output = await ctx.device.shell_async("echo flow_works")
            return output.strip()

        flow.add_step("echo", action=run_echo)
        ctx = await flow.run_async()
        assert ctx.step_results["echo"] == "flow_works"

    async def test_multi_step_device_flow(self, device: Device):
        """Flow that writes a file, reads it back, and cleans up — all on device."""
        flow = Flow("file_ops", device)
        marker = f"/sdcard/Android/data/{PKG}/files/flow_test.txt"

        async def write_file(ctx: FlowContext):
            await ctx.device.shell_async(f"echo 'flow_data' > {marker}")
            return "written"

        async def read_file(ctx: FlowContext):
            content = await ctx.device.files.cat_async(marker)
            ctx.variables["content"] = content.strip()
            return content.strip()

        async def cleanup(ctx: FlowContext):
            await ctx.device.files.rm_async(marker, force=True)
            return "cleaned"

        flow.add_step("write", action=write_file)
        flow.add_step("read", action=read_file)
        flow.add_step("cleanup", action=cleanup)
        ctx = await flow.run_async()
        assert ctx.variables["content"] == "flow_data"
        assert ctx.step_results["write"] == "written"
        assert ctx.step_results["cleanup"] == "cleaned"

    async def test_condition_skip_based_on_device(self, device: Device):
        """Skip a step based on a device condition (app not running)."""
        flow = Flow("cond", device)
        await device.apps.stop_async(PKG)
        await asyncio.sleep(0.5)

        async def only_if_running(ctx: FlowContext) -> bool:
            current = await ctx.device.apps.current_async()
            return current == PKG

        async def should_not_run(ctx: FlowContext):
            ctx.variables["ran"] = True
            return "ran"

        async def always_runs(ctx: FlowContext):
            model = await ctx.device.info.model_async()
            ctx.variables["model"] = model
            return model

        flow.add_step("skip_me", action=should_not_run, condition=only_if_running)
        flow.add_step("always", action=always_runs)
        ctx = await flow.run_async()
        assert "ran" not in ctx.variables
        assert len(ctx.variables["model"]) > 0

    async def test_error_strategy_stop_on_device(self, device: Device):
        """Flow stops when a device operation step fails."""
        flow = Flow("stop", device)

        async def fail_step(ctx: FlowContext):
            # Try to read a non-existent file — force a failure
            raise RuntimeError("intentional device failure")

        async def after_step(ctx: FlowContext):
            ctx.variables["reached"] = True

        flow.add_step("fail", action=fail_step, on_error=ErrorStrategy.STOP)
        flow.add_step("after", action=after_step)
        with pytest.raises(RuntimeError, match="intentional"):
            await flow.run_async()

    async def test_error_strategy_skip_continues(self, device: Device):
        """Flow skips a failing step and continues with device operations."""
        flow = Flow("skip", device)

        async def fail_step(ctx: FlowContext):
            raise RuntimeError("skip me")

        async def get_sdk(ctx: FlowContext):
            sdk = await ctx.device.info.sdk_level_async()
            ctx.variables["sdk"] = sdk
            return sdk

        flow.add_step("fail", action=fail_step, on_error=ErrorStrategy.SKIP)
        flow.add_step("sdk", action=get_sdk)
        ctx = await flow.run_async()
        assert ctx.variables["sdk"] >= 26

    async def test_error_strategy_retry_with_device(self, device: Device):
        """Flow retries a flaky device step that succeeds on third attempt."""
        flow = Flow("retry", device)
        attempts = {"count": 0}

        async def flaky_shell(ctx: FlowContext):
            attempts["count"] += 1
            if attempts["count"] < 3:
                raise RuntimeError("not yet")
            output = await ctx.device.shell_async("echo retry_ok")
            return output.strip()

        flow.add_step("flaky", action=flaky_shell, on_error=ErrorStrategy.RETRY, retries=3)
        ctx = await flow.run_async()
        assert ctx.step_results["flaky"] == "retry_ok"
        assert attempts["count"] == 3

    async def test_full_ui_workflow(self, device: Device):
        """Launch app -> find title -> tap button -> verify navigation -> cleanup."""
        flow = Flow("full_workflow", device)

        async def launch(ctx: FlowContext):
            await ctx.device.apps.start_async(PKG, ".MainActivity")
            await asyncio.sleep(1.5)

        async def find_title(ctx: FlowContext):
            el = await ctx.device.ui.find_async(
                Selector().text("ADBFlow Test App")
            )
            assert el is not None
            ctx.variables["title"] = el.get_text()

        async def tap_second(ctx: FlowContext):
            el = await ctx.device.ui.wait_for_async(
                Selector().text("OPEN SECOND"), timeout=5.0,
            )
            await el.tap_async()
            await asyncio.sleep(1.5)

        async def verify_second(ctx: FlowContext):
            found = await ctx.device.wait_for_text_async(
                "Second Activity", timeout=5.0
            )
            assert found is True

        async def cleanup(ctx: FlowContext):
            await ctx.device.apps.stop_async(PKG)

        flow.add_step("launch", action=launch)
        flow.add_step("find_title", action=find_title)
        flow.add_step("tap_second", action=tap_second)
        flow.add_step("verify_second", action=verify_second)
        flow.add_step("cleanup", action=cleanup)

        ctx = await flow.run_async()
        assert ctx.variables["title"] == "ADBFlow Test App"
