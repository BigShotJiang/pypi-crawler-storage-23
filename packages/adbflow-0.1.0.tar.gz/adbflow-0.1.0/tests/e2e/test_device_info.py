"""E2E tests for device info, properties, settings, power, and shell."""

from __future__ import annotations

import pytest

from adbflow.device.device import Device
from adbflow.utils.types import KeyCode


class TestDeviceInfo:
    """Device information accessors."""

    async def test_model(self, device: Device):
        model = await device.info.model_async()
        assert isinstance(model, str)
        assert model != "unknown"

    async def test_manufacturer(self, device: Device):
        mfr = await device.info.manufacturer_async()
        assert isinstance(mfr, str)
        assert mfr != "unknown"

    async def test_android_version(self, device: Device):
        ver = await device.info.android_version_async()
        assert isinstance(ver, str)
        assert ver != "unknown"
        # Should be a version like "14" or "13"
        assert ver[0].isdigit()

    async def test_sdk_level(self, device: Device):
        sdk = await device.info.sdk_level_async()
        assert isinstance(sdk, int)
        assert sdk >= 26  # Min API we target

    async def test_screen_size(self, device: Device):
        size = await device.info.screen_size_async()
        assert size is not None
        assert size.width > 0
        assert size.height > 0

    async def test_density(self, device: Device):
        density = await device.info.density_async()
        assert density is not None
        assert density > 0

    async def test_battery(self, device: Device):
        battery = await device.info.battery_async()
        assert battery is not None
        assert 0 <= battery.level <= 100

    async def test_ip_address(self, device: Device):
        ip = await device.info.ip_address_async()
        # May be None if no network, but should return a string if connected
        if ip is not None:
            assert isinstance(ip, str)


class TestDeviceProperties:
    """Device property (getprop) access."""

    async def test_get_single(self, device: Device):
        val = await device.properties.get_async("ro.product.model")
        assert val is not None
        assert isinstance(val, str)

    async def test_get_all(self, device: Device):
        props = await device.properties.get_all_async()
        assert isinstance(props, dict)
        assert len(props) > 10
        assert "ro.product.model" in props


class TestDeviceSettings:
    """Android settings get/put/list."""

    async def test_get_setting(self, device: Device):
        val = await device.settings.get_async("global", "wifi_on")
        assert val is not None
        assert val in ("0", "1")

    async def test_put_and_get(self, device: Device):
        key = "adbflow_e2e_test_key"
        await device.settings.put_async("global", key, "42")
        val = await device.settings.get_async("global", key)
        assert val == "42"
        # Cleanup
        await device.settings.delete_async("global", key)

    async def test_list_settings(self, device: Device):
        settings = await device.settings.list_async("global")
        assert isinstance(settings, dict)
        assert len(settings) > 10


class TestDevicePower:
    """Power controls (non-destructive)."""

    async def test_sleep_then_wake_cycle(self, device: Device):
        """Put screen to sleep, verify off, wake, verify on."""
        await device.power.sleep_async()
        import asyncio
        await asyncio.sleep(1.0)
        is_on = await device.power.is_screen_on_async()
        assert is_on is False

        await device.power.wake_async()
        await asyncio.sleep(0.5)
        is_on = await device.power.is_screen_on_async()
        assert is_on is True
        await device.power.unlock_async()

    async def test_wake_and_screen_on(self, device: Device):
        await device.power.wake_async()
        is_on = await device.power.is_screen_on_async()
        assert is_on is True


class TestDeviceShell:
    """Direct shell commands and key events."""

    async def test_shell_echo(self, device: Device):
        result = await device.shell_async("echo hello")
        assert result.strip() == "hello"

    async def test_shell_result(self, device: Device):
        result = await device.shell_result_async("echo test")
        assert result.success
        assert result.output.strip() == "test"

    async def test_keyevent_home(self, device: Device):
        """Send HOME keyevent — verify we're at the home screen."""
        import asyncio
        await device.apps.start_async("com.adbflow.test", ".MainActivity")
        await asyncio.sleep(1.5)
        await device.keyevent_async(KeyCode.HOME)
        await asyncio.sleep(1.5)
        # App should no longer be in foreground
        current = await device.apps.current_async()
        assert current != "com.adbflow.test"
