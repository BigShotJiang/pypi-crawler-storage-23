"""E2E tests for logcat streaming and capture."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest

from adbflow.device.device import Device

PKG = "com.adbflow.test"


class TestLogcat:
    """Logcat streaming, filtering, and capture."""

    async def test_stream_collect_entries(self, device: Device):
        """Launch app, stream logcat, collect at least 10 entries."""
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.5)

        entries = []
        async for entry in device.logcat.stream_async():
            entries.append(entry)
            if len(entries) >= 10:
                break

        assert len(entries) >= 10
        await device.apps.stop_async(PKG)

    async def test_stream_with_tag_filter(self, device: Device):
        """Clear logcat, launch app, filter by ADBFlowTest tag, verify match."""
        await device.logcat.clear_async()
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(2.0)

        entries = []
        try:
            async for entry in device.logcat.stream_async(tags=["ADBFlowTest"]):
                entries.append(entry)
                if len(entries) >= 1:
                    break
        except asyncio.TimeoutError:
            pass

        assert len(entries) >= 1
        assert any("ADBFlowTest" in e.tag for e in entries)
        await device.apps.stop_async(PKG)

    async def test_clear_and_verify_empty(self, device: Device):
        """Clear logcat, then stream — first entries should be recent (not stale)."""
        await device.logcat.clear_async()
        # Generate a fresh log entry
        await device.shell_async("log -t ADBFlowClear 'clear_test_marker'")
        await asyncio.sleep(0.5)

        entries = []
        async for entry in device.logcat.stream_async():
            entries.append(entry)
            if len(entries) >= 5:
                break

        # After clear + new log, we should get fresh entries
        assert len(entries) >= 1

    async def test_capture_to_file(self, device: Device):
        """Launch app, capture 20 lines to file, verify non-empty output."""
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.5)

        with tempfile.NamedTemporaryFile(suffix=".log", delete=False) as f:
            log_path = f.name

        await device.logcat.capture_async(log_path, count=20)
        content = Path(log_path).read_text()
        assert len(content) > 0
        Path(log_path).unlink(missing_ok=True)
        await device.apps.stop_async(PKG)
