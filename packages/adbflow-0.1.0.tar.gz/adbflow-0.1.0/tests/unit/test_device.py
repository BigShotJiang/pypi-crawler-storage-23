"""Tests for Device with mocked transport."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.device.device import Device
from adbflow.utils.types import KeyCode, Result

from tests.conftest import make_result


@pytest.fixture
def device(mock_transport: object) -> Device:
    from adbflow.core.transport import SubprocessTransport

    assert isinstance(mock_transport, SubprocessTransport)
    return Device(serial="emulator-5554", transport=mock_transport)


class TestDeviceShell:
    async def test_shell_returns_output(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="hello world"),
        )
        result = await device.shell_async("echo hello world")
        assert result == "hello world"

    async def test_shell_result(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="ok", return_code=0),
        )
        result = await device.shell_result_async("echo ok")
        assert isinstance(result, Result)
        assert result.success

    async def test_keyevent(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await device.keyevent_async(KeyCode.HOME)
        device.transport.execute_shell.assert_called_once()  # type: ignore[union-attr]


class TestDeviceLazyProperties:
    def test_info_property(self, device: Device) -> None:
        info1 = device.info
        info2 = device.info
        assert info1 is info2

    def test_properties_property(self, device: Device) -> None:
        props1 = device.properties
        props2 = device.properties
        assert props1 is props2

    def test_settings_property(self, device: Device) -> None:
        settings1 = device.settings
        settings2 = device.settings
        assert settings1 is settings2

    def test_power_property(self, device: Device) -> None:
        power1 = device.power
        power2 = device.power
        assert power1 is power2

    def test_ime_property(self, device: Device) -> None:
        ime1 = device.ime
        ime2 = device.ime
        assert ime1 is ime2


class TestDeviceInfo:
    async def test_model(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Pixel 6"),
        )
        model = await device.info.model_async()
        assert model == "Pixel 6"

    async def test_sdk_level(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="33"),
        )
        sdk = await device.info.sdk_level_async()
        assert sdk == 33


class TestDeviceSettings:
    async def test_get_setting(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1"),
        )
        val = await device.settings.get_async("system", "screen_brightness")
        assert val == "1"

    async def test_put_setting(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await device.settings.put_async("system", "screen_brightness", "128")
        device.transport.execute_shell.assert_called_once()  # type: ignore[union-attr]


class TestDevicePhase2Properties:
    def test_files_property(self, device: Device) -> None:
        files1 = device.files
        files2 = device.files
        assert files1 is files2

    def test_apps_property(self, device: Device) -> None:
        apps1 = device.apps
        apps2 = device.apps
        assert apps1 is apps2

    def test_media_property(self, device: Device) -> None:
        media1 = device.media
        media2 = device.media
        assert media1 is media2

    def test_logcat_property(self, device: Device) -> None:
        logcat1 = device.logcat
        logcat2 = device.logcat
        assert logcat1 is logcat2

    def test_network_property(self, device: Device) -> None:
        network1 = device.network
        network2 = device.network
        assert network1 is network2


class TestDeviceScreenshot:
    async def test_screenshot_convenience(self, device: Device) -> None:
        from adbflow.utils.types import Result

        png_data = b"\x89PNG"
        device.transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=Result(
                stdout=png_data, stderr=b"", return_code=0, duration_ms=1.0,
            ),
        )
        data = await device.screenshot_async()
        assert data == png_data


class TestDevicePhase3Properties:
    def test_gestures_property(self, device: Device) -> None:
        from adbflow.gestures.manager import GestureManager

        g1 = device.gestures
        g2 = device.gestures
        assert g1 is g2
        assert isinstance(g1, GestureManager)

    def test_ui_property(self, device: Device) -> None:
        from adbflow.ui.manager import UIManager

        ui1 = device.ui
        ui2 = device.ui
        assert ui1 is ui2
        assert isinstance(ui1, UIManager)

    def test_ui_receives_gestures(self, device: Device) -> None:
        assert device.ui._gestures is device.gestures


class TestDeviceWaitConvenience:
    async def test_wait_for_text(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout='<node text="Hello" />'),
        )
        result = await device.wait_for_text_async("Hello", timeout=1.0)
        assert result is True

    async def test_wait_for_activity(self, device: Device) -> None:
        device.transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="mResumedActivity=com.app/.Main"),
        )
        result = await device.wait_for_activity_async("com.app/.Main", timeout=1.0)
        assert result is True


class TestDevicePhase4Properties:
    def test_notifications_property(self, device: Device) -> None:
        from adbflow.notifications.manager import NotificationManager

        n1 = device.notifications
        n2 = device.notifications
        assert n1 is n2
        assert isinstance(n1, NotificationManager)

    def test_accessibility_property(self, device: Device) -> None:
        from adbflow.accessibility.manager import AccessibilityManager

        a1 = device.accessibility
        a2 = device.accessibility
        assert a1 is a2
        assert isinstance(a1, AccessibilityManager)

    def test_vision_property(self, device: Device) -> None:
        from adbflow.vision.manager import VisionManager

        v1 = device.vision
        v2 = device.vision
        assert v1 is v2
        assert isinstance(v1, VisionManager)

    def test_ocr_property(self, device: Device) -> None:
        from adbflow.ocr.manager import OCRManager

        o1 = device.ocr
        o2 = device.ocr
        assert o1 is o2
        assert isinstance(o1, OCRManager)

    def test_watchers_property(self, device: Device) -> None:
        from adbflow.watchers.manager import WatcherManager

        w1 = device.watchers
        w2 = device.watchers
        assert w1 is w2
        assert isinstance(w1, WatcherManager)

    def test_recorder_property(self, device: Device) -> None:
        from adbflow.recorder.recorder import ActionRecorder

        r1 = device.recorder
        r2 = device.recorder
        assert r1 is r2
        assert isinstance(r1, ActionRecorder)


class TestDeviceRepr:
    def test_repr(self, device: Device) -> None:
        assert "emulator-5554" in repr(device)
