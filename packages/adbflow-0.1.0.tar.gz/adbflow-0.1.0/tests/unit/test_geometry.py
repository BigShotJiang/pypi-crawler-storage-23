"""Tests for Point and Rect geometry primitives."""

from __future__ import annotations

import pytest

from adbflow.utils.geometry import Point, Rect


class TestPoint:
    def test_creation(self) -> None:
        p = Point(10, 20)
        assert p.x == 10
        assert p.y == 20

    def test_offset(self) -> None:
        p = Point(10, 20).offset(5, -3)
        assert p == Point(15, 17)

    def test_scale(self) -> None:
        p = Point(10, 20).scale(2.0)
        assert p == Point(20, 40)

    def test_distance_to(self) -> None:
        a = Point(0, 0)
        b = Point(3, 4)
        assert a.distance_to(b) == pytest.approx(5.0)

    def test_add(self) -> None:
        assert Point(1, 2) + Point(3, 4) == Point(4, 6)

    def test_sub(self) -> None:
        assert Point(5, 7) - Point(2, 3) == Point(3, 4)

    def test_frozen(self) -> None:
        p = Point(1, 2)
        with pytest.raises(AttributeError):
            p.x = 10  # type: ignore[misc]


class TestRect:
    def test_creation(self) -> None:
        r = Rect(0, 0, 100, 200)
        assert r.width == 100
        assert r.height == 200

    def test_center(self) -> None:
        r = Rect(0, 0, 100, 200)
        assert r.center == Point(50, 100)

    def test_area(self) -> None:
        r = Rect(10, 20, 110, 220)
        assert r.area == 100 * 200

    def test_contains_point(self) -> None:
        r = Rect(0, 0, 100, 100)
        assert r.contains(Point(50, 50))
        assert r.contains(Point(0, 0))
        assert r.contains(Point(100, 100))
        assert not r.contains(Point(101, 50))

    def test_intersects(self) -> None:
        a = Rect(0, 0, 100, 100)
        b = Rect(50, 50, 150, 150)
        c = Rect(200, 200, 300, 300)
        assert a.intersects(b)
        assert not a.intersects(c)

    def test_intersection(self) -> None:
        a = Rect(0, 0, 100, 100)
        b = Rect(50, 50, 150, 150)
        result = a.intersection(b)
        assert result == Rect(50, 50, 100, 100)

    def test_intersection_none(self) -> None:
        a = Rect(0, 0, 10, 10)
        b = Rect(20, 20, 30, 30)
        assert a.intersection(b) is None

    def test_offset(self) -> None:
        r = Rect(10, 20, 30, 40).offset(5, 5)
        assert r == Rect(15, 25, 35, 45)

    def test_scale(self) -> None:
        r = Rect(10, 20, 30, 40).scale(2.0)
        assert r == Rect(20, 40, 60, 80)

    def test_from_ltwh(self) -> None:
        r = Rect.from_ltwh(10, 20, 100, 200)
        assert r == Rect(10, 20, 110, 220)

    def test_from_center(self) -> None:
        r = Rect.from_center(Point(50, 50), 100, 100)
        assert r.center == Point(50, 50)
        assert r.width == 100
        assert r.height == 100

    def test_validation_right_lt_left(self) -> None:
        with pytest.raises(ValueError, match="right"):
            Rect(100, 0, 50, 100)

    def test_validation_bottom_lt_top(self) -> None:
        with pytest.raises(ValueError, match="bottom"):
            Rect(0, 100, 50, 50)
