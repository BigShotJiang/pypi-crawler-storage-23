"""Tests for vision module."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import VisionError, WaitTimeoutError
from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import MatchResult
from tests.conftest import make_result


def _make_image(w: int = 100, h: int = 100, color: str = "red") -> Image.Image:
    """Create a test image."""
    return Image.new("RGB", (w, h), color)


class TestTemplateMatcher:
    """Tests for TemplateMatcher using mocked OpenCV."""

    def test_match_found(self) -> None:
        """Test match returns a result when confidence is above threshold."""
        from adbflow.vision.template import TemplateMatcher

        matcher = TemplateMatcher()

        expected = MatchResult(
            location=Rect(left=10, top=20, right=40, bottom=40),
            confidence=0.95,
            center=Point(x=25, y=30),
        )

        with patch.object(matcher, "match", return_value=expected):
            result = matcher.match(_make_image(), _make_image(30, 20), threshold=0.8)

        assert result is not None
        assert result.confidence == 0.95
        assert result.location == Rect(left=10, top=20, right=40, bottom=40)
        assert result.center == Point(x=25, y=30)

    def test_match_not_found(self) -> None:
        """Test match returns None when confidence is below threshold."""
        from adbflow.vision.template import TemplateMatcher

        matcher = TemplateMatcher()

        with patch.object(matcher, "match", return_value=None):
            result = matcher.match(_make_image(), _make_image(), threshold=0.8)

        assert result is None

    def test_opencv_not_installed(self) -> None:
        """Test that VisionError is raised when OpenCV is not installed."""
        from adbflow.vision.template import _require_opencv

        with patch("adbflow.vision.template._HAS_OPENCV", False):
            with pytest.raises(VisionError, match="opencv-python not installed"):
                _require_opencv()


class TestVisionManager:
    """Tests for VisionManager."""

    async def test_find_on_screen(self, mock_transport: SubprocessTransport) -> None:
        """Test find_on_screen_async delegates to TemplateMatcher."""
        # Create a fake PNG
        import io

        img = _make_image()
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        png_bytes = buf.getvalue()

        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=""),
        )
        # Override stdout to be raw bytes
        from adbflow.utils.types import Result

        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=Result(
                stdout=png_bytes, stderr=b"", return_code=0, duration_ms=1.0,
            ),
        )

        from adbflow.vision.manager import VisionManager

        mgr = VisionManager("emu", mock_transport)

        expected = MatchResult(
            location=Rect(0, 0, 10, 10),
            confidence=0.9,
            center=Point(5, 5),
        )

        with patch.object(mgr._matcher, "match", return_value=expected):
            result = await mgr.find_on_screen_async(_make_image(10, 10))

        assert result is not None
        assert result.confidence == 0.9

    async def test_tap_template_not_found(self, mock_transport: SubprocessTransport) -> None:
        """Test tap_template raises VisionError when template not found."""
        import io

        img = _make_image()
        buf = io.BytesIO()
        img.save(buf, format="PNG")

        from adbflow.utils.types import Result

        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=Result(
                stdout=buf.getvalue(), stderr=b"", return_code=0, duration_ms=1.0,
            ),
        )

        from adbflow.vision.manager import VisionManager

        mgr = VisionManager("emu", mock_transport)

        with patch.object(mgr._matcher, "match", return_value=None):
            with pytest.raises(VisionError, match="Template not found"):
                await mgr.tap_template_async(_make_image())
