"""Tests for parallel module."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.device.device import Device
from adbflow.parallel.pool import DevicePool
from tests.conftest import make_result


def _make_device(serial: str) -> Device:
    transport = SubprocessTransport.__new__(SubprocessTransport)
    transport._adb_path = "/usr/bin/adb"
    transport.execute = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    transport.execute_shell = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    return Device(serial, transport)


class TestDevicePool:
    def test_len(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2")])
        assert len(pool) == 2

    def test_iter(self) -> None:
        devices = [_make_device("d1"), _make_device("d2")]
        pool = DevicePool(devices)
        serials = [d.serial for d in pool]
        assert serials == ["d1", "d2"]

    def test_devices_property(self) -> None:
        devices = [_make_device("d1")]
        pool = DevicePool(devices)
        assert pool.devices[0].serial == "d1"
        # Verify it's a copy
        pool.devices.clear()
        assert len(pool.devices) == 1

    async def test_run_async_parallel(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2"), _make_device("d3")])

        async def get_serial(dev: Device) -> str:
            return dev.serial

        results = await pool.run_async(get_serial)
        assert sorted(str(r) for r in results) == ["d1", "d2", "d3"]

    async def test_run_async_returns_exceptions(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2")])

        async def fail_on_d1(dev: Device) -> str:
            if dev.serial == "d1":
                raise RuntimeError("boom")
            return dev.serial

        results = await pool.run_async(fail_on_d1)
        assert isinstance(results[0], RuntimeError)
        assert results[1] == "d2"

    async def test_run_sequential(self) -> None:
        order: list[str] = []
        pool = DevicePool([_make_device("d1"), _make_device("d2")])

        async def track_order(dev: Device) -> str:
            order.append(dev.serial)
            return dev.serial

        results = await pool.run_sequential_async(track_order)
        assert order == ["d1", "d2"]
        assert results == ["d1", "d2"]

    async def test_run_sequential_exceptions(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2")])

        async def fail_on_d1(dev: Device) -> str:
            if dev.serial == "d1":
                raise RuntimeError("boom")
            return dev.serial

        results = await pool.run_sequential_async(fail_on_d1)
        assert isinstance(results[0], RuntimeError)
        assert results[1] == "d2"

    async def test_filter(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2"), _make_device("d3")])

        async def starts_with_d1(dev: Device) -> bool:
            return dev.serial == "d1"

        filtered = await pool.filter_async(starts_with_d1)
        assert len(filtered) == 1
        assert filtered[0].serial == "d1"

    async def test_first_found(self) -> None:
        pool = DevicePool([_make_device("d1"), _make_device("d2")])

        async def is_d2(dev: Device) -> bool:
            return dev.serial == "d2"

        result = await pool.first_async(is_d2)
        assert result is not None
        assert result.serial == "d2"

    async def test_first_not_found(self) -> None:
        pool = DevicePool([_make_device("d1")])

        async def never_match(dev: Device) -> bool:
            return False

        result = await pool.first_async(never_match)
        assert result is None
