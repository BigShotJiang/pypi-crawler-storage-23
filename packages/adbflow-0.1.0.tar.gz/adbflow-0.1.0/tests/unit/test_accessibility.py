"""Tests for accessibility module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.accessibility.manager import AccessibilityManager
from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_accessibility_services
from tests.conftest import make_result

SAMPLE_DUMPSYS = """\
Service[com.example.app/com.example.AccessibilityService]
  isDefault:true
  description: Example accessibility service

Service[com.other.app/com.other.A11yService]
  isDefault:false
  description: Another service
"""


@pytest.fixture
def a11y_mgr(mock_transport: SubprocessTransport) -> AccessibilityManager:
    return AccessibilityManager("emu", mock_transport)


class TestParseAccessibilityServices:
    def test_parse_basic(self) -> None:
        results = parse_accessibility_services(SAMPLE_DUMPSYS)
        assert len(results) == 2
        assert results[0].component == "com.example.app/com.example.AccessibilityService"
        assert results[0].enabled is True
        assert results[0].description == "Example accessibility service"

    def test_parse_disabled(self) -> None:
        results = parse_accessibility_services(SAMPLE_DUMPSYS)
        assert results[1].enabled is False

    def test_parse_empty(self) -> None:
        assert parse_accessibility_services("") == []


class TestAccessibilityManager:
    async def test_list_services(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=SAMPLE_DUMPSYS),
        )
        result = await a11y_mgr.list_services_async()
        assert len(result) == 2

    async def test_get_enabled(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(
                stdout="com.example/Service1:com.other/Service2",
            ),
        )
        result = await a11y_mgr.get_enabled_async()
        assert result == ["com.example/Service1", "com.other/Service2"]

    async def test_get_enabled_null(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="null"),
        )
        result = await a11y_mgr.get_enabled_async()
        assert result == []

    async def test_is_enabled_true(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="com.example/Svc"),
        )
        assert await a11y_mgr.is_enabled_async("com.example/Svc") is True

    async def test_is_enabled_false(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="com.other/Svc"),
        )
        assert await a11y_mgr.is_enabled_async("com.example/Svc") is False

    async def test_enable(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        # First call returns current enabled, second call is the put
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            side_effect=[
                make_result(stdout="com.existing/Svc"),
                make_result(),
            ],
        )
        await a11y_mgr.enable_async("com.new/Svc")
        calls = mock_transport.execute_shell.call_args_list  # type: ignore[union-attr]
        assert len(calls) == 2
        put_cmd = calls[1][0][0]
        assert "com.existing/Svc:com.new/Svc" in put_cmd

    async def test_disable(
        self, a11y_mgr: AccessibilityManager, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            side_effect=[
                make_result(stdout="com.keep/Svc:com.remove/Svc"),
                make_result(),
            ],
        )
        await a11y_mgr.disable_async("com.remove/Svc")
        calls = mock_transport.execute_shell.call_args_list  # type: ignore[union-attr]
        put_cmd = calls[1][0][0]
        assert "com.keep/Svc" in put_cmd
        assert "com.remove/Svc" not in put_cmd
