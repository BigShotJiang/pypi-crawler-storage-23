"""Tests for the exception hierarchy."""

from __future__ import annotations

from adbflow.utils.exceptions import (
    ADBConnectionError,
    ADBError,
    ADBFlowError,
    ADBTimeoutError,
    BinaryNotFoundError,
    CommandBuildError,
    DeviceNotFoundError,
    ElementNotFoundError,
)


class TestExceptionHierarchy:
    def test_all_inherit_from_adbflow_error(self) -> None:
        for exc_class in [
            ADBError,
            DeviceNotFoundError,
            ElementNotFoundError,
            ADBTimeoutError,
            ADBConnectionError,
            CommandBuildError,
            BinaryNotFoundError,
        ]:
            assert issubclass(exc_class, ADBFlowError)

    def test_adb_error_attributes(self) -> None:
        exc = ADBError(command="adb shell ls", stderr="not found", return_code=1)
        assert exc.command == "adb shell ls"
        assert exc.stderr == "not found"
        assert exc.return_code == 1
        assert "adb shell ls" in str(exc)
        assert "not found" in str(exc)

    def test_adb_error_with_list_command(self) -> None:
        exc = ADBError(command=["adb", "shell", "ls"], stderr="", return_code=127)
        assert exc.command == "adb shell ls"
        assert exc.return_code == 127

    def test_device_not_found_with_serial(self) -> None:
        exc = DeviceNotFoundError("emulator-5554")
        assert exc.serial == "emulator-5554"
        assert "emulator-5554" in str(exc)

    def test_device_not_found_without_serial(self) -> None:
        exc = DeviceNotFoundError()
        assert "No device found" in str(exc)

    def test_timeout_error(self) -> None:
        exc = ADBTimeoutError(timeout=30.0, operation="install")
        assert exc.timeout == 30.0
        assert exc.operation == "install"
        assert "30" in str(exc)
        assert "install" in str(exc)

    def test_binary_not_found(self) -> None:
        exc = BinaryNotFoundError(["/usr/bin/adb", "/opt/adb"])
        assert len(exc.searched_paths) == 2
        assert "/usr/bin/adb" in str(exc)

    def test_binary_not_found_no_paths(self) -> None:
        exc = BinaryNotFoundError()
        assert exc.searched_paths == []
