"""Tests for apps module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.apps.intent import Intent
from adbflow.apps.manager import AppManager
from adbflow.apps.permissions import AppPermissions
from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import InstallError, PackageNotFoundError
from adbflow.utils.types import InstallFlag, IntentFlag, PackageFilter

from tests.conftest import make_result


@pytest.fixture
def app_manager(mock_transport: SubprocessTransport) -> AppManager:
    return AppManager(serial="emulator-5554", transport=mock_transport)


@pytest.fixture
def app_permissions(mock_transport: SubprocessTransport) -> AppPermissions:
    return AppPermissions(serial="emulator-5554", transport=mock_transport)


# ---------------------------------------------------------------------------
# Intent builder
# ---------------------------------------------------------------------------


class TestIntent:
    def test_action(self) -> None:
        args = Intent("android.intent.action.VIEW").build_am_args()
        assert args == ["-a", "android.intent.action.VIEW"]

    def test_data(self) -> None:
        args = Intent().action("android.intent.action.VIEW").data("https://x.com").build_am_args()
        assert "-d" in args
        assert "https://x.com" in args

    def test_mime_type(self) -> None:
        args = Intent().mime_type("text/plain").build_am_args()
        assert args == ["-t", "text/plain"]

    def test_category(self) -> None:
        args = Intent().category("android.intent.category.LAUNCHER").build_am_args()
        assert "-c" in args

    def test_component(self) -> None:
        args = Intent().component("com.example/.MainActivity").build_am_args()
        assert args == ["-n", "com.example/.MainActivity"]

    def test_extras(self) -> None:
        args = (
            Intent()
            .extra_string("key1", "val1")
            .extra_int("key2", 42)
            .extra_bool("key3", True)
            .extra_float("key4", 3.14)
            .build_am_args()
        )
        assert ["--es", "key1", "val1"] == args[0:3]
        assert ["--ei", "key2", "42"] == args[3:6]
        assert ["--ez", "key3", "true"] == args[6:9]
        assert ["--ef", "key4", "3.14"] == args[9:12]

    def test_flags(self) -> None:
        args = (
            Intent()
            .flags(IntentFlag.FLAG_ACTIVITY_NEW_TASK, IntentFlag.FLAG_ACTIVITY_CLEAR_TOP)
            .build_am_args()
        )
        assert "-f" in args
        expected = IntentFlag.FLAG_ACTIVITY_NEW_TASK | IntentFlag.FLAG_ACTIVITY_CLEAR_TOP
        assert str(expected) in args

    def test_full_intent(self) -> None:
        args = (
            Intent("android.intent.action.SEND")
            .data("content://something")
            .mime_type("text/plain")
            .component("com.example/.ShareActivity")
            .extra_string("android.intent.extra.TEXT", "Hello")
            .flags(IntentFlag.FLAG_ACTIVITY_NEW_TASK)
            .build_am_args()
        )
        assert "-a" in args
        assert "-d" in args
        assert "-t" in args
        assert "-n" in args
        assert "--es" in args
        assert "-f" in args


# ---------------------------------------------------------------------------
# AppManager
# ---------------------------------------------------------------------------


class TestAppManagerInstall:
    async def test_install_basic(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Success"),
        )
        await app_manager.install_async("/path/to/app.apk")
        args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["install", "/path/to/app.apk"]

    async def test_install_with_flags(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Success"),
        )
        await app_manager.install_async(
            "/path/to/app.apk",
            flags=[InstallFlag.REPLACE, InstallFlag.TEST],
        )
        args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert "-r" in args
        assert "-t" in args

    async def test_install_failure(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Failure [INSTALL_FAILED]", return_code=1),
        )
        with pytest.raises(InstallError):
            await app_manager.install_async("/path/to/bad.apk")

    async def test_install_multiple(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Success"),
        )
        await app_manager.install_multiple_async(["/a.apk", "/b.apk"])
        args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args[0] == "install-multiple"
        assert "/a.apk" in args
        assert "/b.apk" in args


class TestAppManagerUninstall:
    async def test_uninstall(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.uninstall_async("com.example.app")
        args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["uninstall", "com.example.app"]

    async def test_uninstall_keep_data(self, app_manager: AppManager) -> None:
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.uninstall_async("com.example.app", keep_data=True)
        args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert "-k" in args


class TestAppManagerList:
    async def test_list_all(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(
                stdout="package:com.android.settings\npackage:com.android.chrome\n"
            ),
        )
        pkgs = await app_manager.list_async()
        assert pkgs == ["com.android.settings", "com.android.chrome"]

    async def test_list_system(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="package:com.android.settings\n"),
        )
        await app_manager.list_async(filter=PackageFilter.SYSTEM)
        cmd = app_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "-s" in cmd


class TestAppManagerStartStop:
    async def test_start_with_activity(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.start_async("com.example", ".MainActivity")
        cmd = app_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "am start" in cmd
        assert "com.example/.MainActivity" in cmd

    async def test_start_without_activity(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.start_async("com.example")
        cmd = app_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "monkey" in cmd

    async def test_stop(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.stop_async("com.example")
        cmd = app_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "am force-stop" in cmd

    async def test_clear_data(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.clear_data_async("com.example")
        cmd = app_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "pm clear" in cmd


class TestAppManagerExtract:
    async def test_extract(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="package:/data/app/com.example/base.apk"),
        )
        app_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_manager.extract_async("com.example", "/local/output.apk")
        pull_args = app_manager._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert pull_args[0] == "pull"

    async def test_extract_not_found(self, app_manager: AppManager) -> None:
        app_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="", return_code=1),
        )
        with pytest.raises(PackageNotFoundError):
            await app_manager.extract_async("com.nonexistent", "/local/output.apk")


class TestAppManagerPermissions:
    async def test_grant(self, app_permissions: AppPermissions) -> None:
        app_permissions._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_permissions.grant_async("com.example", "android.permission.CAMERA")
        cmd = app_permissions._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "pm grant" in cmd

    async def test_revoke(self, app_permissions: AppPermissions) -> None:
        app_permissions._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await app_permissions.revoke_async("com.example", "android.permission.CAMERA")
        cmd = app_permissions._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "pm revoke" in cmd

    async def test_is_granted(self, app_permissions: AppPermissions) -> None:
        app_permissions._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(
                stdout="android.permission.CAMERA: granted=true"
            ),
        )
        assert await app_permissions.is_granted_async(
            "com.example", "android.permission.CAMERA"
        ) is True
