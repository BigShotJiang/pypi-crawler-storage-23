"""Tests for network module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.network.controls import NetworkManager
from adbflow.utils.types import ProxyConfig

from tests.conftest import make_result


@pytest.fixture
def network_mgr(mock_transport: SubprocessTransport) -> NetworkManager:
    return NetworkManager(serial="emulator-5554", transport=mock_transport)


class TestWifi:
    async def test_wifi_enable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.wifi_enable_async()
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "svc wifi enable" in cmd

    async def test_wifi_disable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.wifi_disable_async()
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "svc wifi disable" in cmd

    async def test_wifi_is_enabled(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1"),
        )
        assert await network_mgr.wifi_is_enabled_async() is True

    async def test_wifi_is_disabled(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="0"),
        )
        assert await network_mgr.wifi_is_enabled_async() is False

    async def test_wifi_info(self, network_mgr: NetworkManager) -> None:
        output = (
            "Wi-Fi is enabled\n"
            "  SSID: \"MyNetwork\"\n"
            "  Link speed: 72Mbps\n"
            "  RSSI: -55\n"
            "  mIpAddress /192.168.1.100\n"
        )
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=output),
        )
        info = await network_mgr.wifi_info_async()
        assert info is not None
        assert info.ssid == "MyNetwork"
        assert info.ip_address == "192.168.1.100"


class TestMobileData:
    async def test_enable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.mobile_data_enable_async()
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "svc data enable" in cmd

    async def test_disable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.mobile_data_disable_async()
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "svc data disable" in cmd

    async def test_is_enabled(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1"),
        )
        assert await network_mgr.mobile_data_is_enabled_async() is True


class TestAirplane:
    async def test_enable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.airplane_enable_async()
        calls = network_mgr._transport.execute_shell.call_args_list  # type: ignore[union-attr]
        cmds = [c[0][0] for c in calls]
        assert any("airplane_mode_on 1" in c for c in cmds)
        assert any("AIRPLANE_MODE" in c for c in cmds)

    async def test_disable(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.airplane_disable_async()
        calls = network_mgr._transport.execute_shell.call_args_list  # type: ignore[union-attr]
        cmds = [c[0][0] for c in calls]
        assert any("airplane_mode_on 0" in c for c in cmds)

    async def test_is_enabled(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1"),
        )
        assert await network_mgr.airplane_is_enabled_async() is True


class TestForwarding:
    async def test_forward(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.forward_async("tcp:8080", "tcp:80")
        args = network_mgr._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["forward", "tcp:8080", "tcp:80"]

    async def test_forward_remove(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.forward_remove_async("tcp:8080")
        args = network_mgr._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["forward", "--remove", "tcp:8080"]

    async def test_forward_list(self, network_mgr: NetworkManager) -> None:
        output = "emulator-5554 tcp:8080 tcp:80\nemulator-5554 tcp:9090 tcp:90\n"
        network_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=output),
        )
        rules = await network_mgr.forward_list_async()
        assert len(rules) == 2
        assert rules[0].local == "tcp:8080"
        assert rules[0].remote == "tcp:80"

    async def test_reverse(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.reverse_async("tcp:8080", "tcp:80")
        args = network_mgr._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["reverse", "tcp:8080", "tcp:80"]


class TestProxy:
    async def test_proxy_set(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.proxy_set_async(ProxyConfig(host="10.0.0.1", port=8080))
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "http_proxy" in cmd
        assert "10.0.0.1:8080" in cmd

    async def test_proxy_get(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="10.0.0.1:8080"),
        )
        config = await network_mgr.proxy_get_async()
        assert config is not None
        assert config.host == "10.0.0.1"
        assert config.port == 8080

    async def test_proxy_get_none(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="null"),
        )
        assert await network_mgr.proxy_get_async() is None

    async def test_proxy_clear(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.proxy_clear_async()
        assert network_mgr._transport.execute_shell.call_count >= 2  # type: ignore[union-attr]


class TestTcpdump:
    async def test_start(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.tcpdump_start_async("/sdcard/cap.pcap", interface="wlan0")
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "tcpdump" in cmd
        assert "-i wlan0" in cmd

    async def test_stop(self, network_mgr: NetworkManager) -> None:
        network_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await network_mgr.tcpdump_stop_async()
        cmd = network_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "tcpdump" in cmd
