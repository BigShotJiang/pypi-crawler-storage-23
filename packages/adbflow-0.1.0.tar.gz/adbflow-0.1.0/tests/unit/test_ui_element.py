"""Tests for UIElement."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from adbflow.gestures.manager import GestureManager
from adbflow.ui.element import UIElement
from adbflow.ui.hierarchy import UINode
from adbflow.ui.manager import UIManager
from adbflow.utils.geometry import Point, Rect


def _make_node(
    text: str = "Button",
    resource_id: str = "com.app:id/btn",
    bounds: Rect | None = None,
) -> UINode:
    return UINode(
        text=text,
        resource_id=resource_id,
        class_name="android.widget.Button",
        package="com.app",
        content_desc="",
        checkable=False,
        checked=False,
        clickable=True,
        enabled=True,
        focusable=False,
        focused=False,
        scrollable=False,
        long_clickable=False,
        selected=False,
        bounds=bounds or Rect(100, 200, 300, 400),
        index=0,
        children=(),
    )


@pytest.fixture
def mock_gestures() -> GestureManager:
    gm = MagicMock(spec=GestureManager)
    gm.tap_async = AsyncMock()
    gm.long_tap_async = AsyncMock()
    gm.swipe_direction_async = AsyncMock()
    gm.text_async = AsyncMock()
    return gm  # type: ignore[return-value]


@pytest.fixture
def mock_ui_manager() -> UIManager:
    um = MagicMock(spec=UIManager)
    um.invalidate_cache = MagicMock()
    um.exists_async = AsyncMock(return_value=True)
    um.wait_for_async = AsyncMock()
    return um  # type: ignore[return-value]


@pytest.fixture
def element(mock_gestures: GestureManager, mock_ui_manager: UIManager) -> UIElement:
    return UIElement(_make_node(), mock_gestures, mock_ui_manager)


class TestUIElementProperties:
    def test_get_text(self, element: UIElement) -> None:
        assert element.get_text() == "Button"

    def test_get_bounds(self, element: UIElement) -> None:
        assert element.get_bounds() == Rect(100, 200, 300, 400)

    def test_get_center(self, element: UIElement) -> None:
        center = element.get_center()
        assert center == Point(200, 300)

    def test_info(self, element: UIElement) -> None:
        assert element.info.text == "Button"
        assert element.info.resource_id == "com.app:id/btn"


class TestUIElementActions:
    async def test_tap(self, element: UIElement, mock_gestures: GestureManager) -> None:
        await element.tap_async()
        mock_gestures.tap_async.assert_called_once_with(Point(200, 300))  # type: ignore[union-attr]

    async def test_tap_invalidates_cache(
        self, element: UIElement, mock_ui_manager: UIManager
    ) -> None:
        await element.tap_async()
        mock_ui_manager.invalidate_cache.assert_called()  # type: ignore[union-attr]

    async def test_long_tap(
        self, element: UIElement, mock_gestures: GestureManager
    ) -> None:
        await element.long_tap_async(duration_ms=2000)
        mock_gestures.long_tap_async.assert_called_once_with(  # type: ignore[union-attr]
            Point(200, 300), duration_ms=2000,
        )

    async def test_text_input(
        self, element: UIElement, mock_gestures: GestureManager
    ) -> None:
        await element.text_input_async("hello")
        mock_gestures.tap_async.assert_called_once()  # type: ignore[union-attr]
        mock_gestures.text_async.assert_called_once_with("hello")  # type: ignore[union-attr]

    async def test_swipe(
        self, element: UIElement, mock_gestures: GestureManager
    ) -> None:
        from adbflow.utils.types import SwipeDirection

        await element.swipe_async(SwipeDirection.UP, distance=300, duration_ms=200)
        mock_gestures.swipe_direction_async.assert_called_once()  # type: ignore[union-attr]


class TestUIElementReQuery:
    async def test_exists(self, element: UIElement, mock_ui_manager: UIManager) -> None:
        result = await element.exists_async()
        assert result is True
        mock_ui_manager.exists_async.assert_called_once()  # type: ignore[union-attr]
