"""Tests for flow module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.device.device import Device
from adbflow.flow.engine import Flow
from adbflow.flow.step import FlowContext, Step
from adbflow.utils.types import ErrorStrategy
from tests.conftest import make_result


def _make_device() -> Device:
    transport = SubprocessTransport.__new__(SubprocessTransport)
    transport._adb_path = "/usr/bin/adb"
    transport.execute = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    transport.execute_shell = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    return Device("emu", transport)


class TestFlow:
    async def test_single_step(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def step1(ctx: FlowContext) -> str:
            return "done"

        flow.add_step("step1", step1)
        ctx = await flow.run_async()
        assert ctx.step_results["step1"] == "done"

    async def test_multi_step(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def step1(ctx: FlowContext) -> int:
            ctx.variables["counter"] = 1
            return 1

        async def step2(ctx: FlowContext) -> int:
            ctx.variables["counter"] += 1
            return ctx.variables["counter"]

        flow.add_step("step1", step1)
        flow.add_step("step2", step2)
        ctx = await flow.run_async()

        assert ctx.step_results["step1"] == 1
        assert ctx.step_results["step2"] == 2
        assert ctx.variables["counter"] == 2

    async def test_fluent_builder(self) -> None:
        device = _make_device()

        async def noop(ctx: FlowContext) -> None:
            pass

        flow = Flow("test", device).add_step("a", noop).add_step("b", noop)
        assert len(flow.steps) == 2

    async def test_condition_skip(self) -> None:
        device = _make_device()
        flow = Flow("test", device)
        executed: list[str] = []

        async def step1(ctx: FlowContext) -> None:
            executed.append("step1")

        async def step2(ctx: FlowContext) -> None:
            executed.append("step2")

        async def always_false(ctx: FlowContext) -> bool:
            return False

        flow.add_step("step1", step1)
        flow.add_step("step2", step2, condition=always_false)
        await flow.run_async()

        assert executed == ["step1"]

    async def test_condition_run(self) -> None:
        device = _make_device()
        flow = Flow("test", device)
        executed: list[str] = []

        async def step1(ctx: FlowContext) -> None:
            executed.append("step1")

        async def always_true(ctx: FlowContext) -> bool:
            return True

        flow.add_step("step1", step1, condition=always_true)
        await flow.run_async()

        assert executed == ["step1"]

    async def test_error_strategy_stop(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def failing(ctx: FlowContext) -> None:
            raise RuntimeError("boom")

        async def after(ctx: FlowContext) -> None:
            pass

        flow.add_step("fail", failing, on_error=ErrorStrategy.STOP)
        flow.add_step("after", after)

        with pytest.raises(RuntimeError, match="boom"):
            await flow.run_async()

    async def test_error_strategy_skip(self) -> None:
        device = _make_device()
        flow = Flow("test", device)
        executed: list[str] = []

        async def failing(ctx: FlowContext) -> None:
            raise RuntimeError("boom")

        async def after(ctx: FlowContext) -> None:
            executed.append("after")

        flow.add_step("fail", failing, on_error=ErrorStrategy.SKIP)
        flow.add_step("after", after)
        ctx = await flow.run_async()

        assert "after" in executed
        assert "fail" not in ctx.step_results

    async def test_error_strategy_retry(self) -> None:
        device = _make_device()
        flow = Flow("test", device)
        call_count = 0

        async def flaky(ctx: FlowContext) -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RuntimeError("flaky")
            return "ok"

        flow.add_step("flaky", flaky, on_error=ErrorStrategy.RETRY, retries=3)
        ctx = await flow.run_async()

        assert ctx.step_results["flaky"] == "ok"
        assert call_count == 3

    async def test_error_strategy_retry_exhausted(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def always_fail(ctx: FlowContext) -> None:
            raise RuntimeError("always fails")

        flow.add_step("fail", always_fail, on_error=ErrorStrategy.RETRY, retries=2)

        with pytest.raises(RuntimeError, match="always fails"):
            await flow.run_async()

    async def test_variables_shared(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def set_var(ctx: FlowContext) -> None:
            ctx.variables["key"] = "value"

        async def read_var(ctx: FlowContext) -> str:
            return ctx.variables["key"]

        flow.add_step("set", set_var)
        flow.add_step("read", read_var)
        ctx = await flow.run_async()

        assert ctx.step_results["read"] == "value"

    async def test_step_results_populated(self) -> None:
        device = _make_device()
        flow = Flow("test", device)

        async def return_42(ctx: FlowContext) -> int:
            return 42

        flow.add_step("answer", return_42)
        ctx = await flow.run_async()
        assert ctx.step_results == {"answer": 42}
