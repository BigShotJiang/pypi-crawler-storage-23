"""Tests for UIManager."""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.gestures.manager import GestureManager
from adbflow.ui.element import UIElement
from adbflow.ui.manager import UIManager
from adbflow.ui.selector import Selector
from adbflow.utils.exceptions import WaitTimeoutError

from tests.conftest import make_result

SIMPLE_HIERARCHY = """\
<?xml version="1.0" encoding="UTF-8"?>
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout"
        package="com.app" content-desc=""
        checkable="false" checked="false" clickable="false" enabled="true"
        focusable="false" focused="false" scrollable="false"
        long-clickable="false" selected="false" bounds="[0,0][1080,1920]">
    <node index="0" text="Login" resource-id="com.app:id/login"
          class="android.widget.Button" package="com.app" content-desc=""
          checkable="false" checked="false" clickable="true" enabled="true"
          focusable="false" focused="false" scrollable="false"
          long-clickable="false" selected="false" bounds="[100,200][300,400]" />
    <node index="1" text="Register" resource-id="com.app:id/register"
          class="android.widget.Button" package="com.app" content-desc=""
          checkable="false" checked="false" clickable="true" enabled="true"
          focusable="false" focused="false" scrollable="false"
          long-clickable="false" selected="false" bounds="[100,500][300,600]" />
  </node>
</hierarchy>
"""


@pytest.fixture
def mock_gestures() -> GestureManager:
    gm = MagicMock(spec=GestureManager)
    gm.tap_async = AsyncMock()
    return gm  # type: ignore[return-value]


@pytest.fixture
def ui_manager(
    mock_transport: SubprocessTransport,
    mock_gestures: GestureManager,
) -> UIManager:
    mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
        return_value=make_result(stdout=SIMPLE_HIERARCHY),
    )
    return UIManager("emu", mock_transport, mock_gestures)


class TestDump:
    # Each dump_async makes 3 execute_shell calls: uiautomator dump, cat, rm
    _CALLS_PER_DUMP = 3

    async def test_dump_calls_uiautomator(self, ui_manager: UIManager) -> None:
        root = await ui_manager.dump_async()
        assert root.class_name == "android.widget.FrameLayout"
        calls = ui_manager._transport.execute_shell.call_args_list  # type: ignore[union-attr]
        assert len(calls) == self._CALLS_PER_DUMP
        assert "uiautomator dump" in calls[0][0][0]

    async def test_dump_caches(self, ui_manager: UIManager) -> None:
        root1 = await ui_manager.dump_async()
        root2 = await ui_manager.dump_async()
        assert root1 is root2
        # Only one dump despite two dump_async calls (cached)
        assert ui_manager._transport.execute_shell.call_count == self._CALLS_PER_DUMP  # type: ignore[union-attr]

    async def test_dump_force_bypasses_cache(self, ui_manager: UIManager) -> None:
        await ui_manager.dump_async()
        await ui_manager.dump_async(force=True)
        assert ui_manager._transport.execute_shell.call_count == self._CALLS_PER_DUMP * 2  # type: ignore[union-attr]

    async def test_cache_expires(self, ui_manager: UIManager) -> None:
        await ui_manager.dump_async()
        # Manually expire cache
        ui_manager._cache_time = time.monotonic() - 10.0
        await ui_manager.dump_async()
        assert ui_manager._transport.execute_shell.call_count == self._CALLS_PER_DUMP * 2  # type: ignore[union-attr]


class TestFind:
    async def test_find_by_text(self, ui_manager: UIManager) -> None:
        elem = await ui_manager.find_async(Selector().text("Login"))
        assert elem is not None
        assert elem.get_text() == "Login"

    async def test_find_not_found(self, ui_manager: UIManager) -> None:
        elem = await ui_manager.find_async(Selector().text("Nonexistent"))
        assert elem is None

    async def test_find_all(self, ui_manager: UIManager) -> None:
        elems = await ui_manager.find_all_async(Selector().clickable())
        assert len(elems) == 2

    async def test_find_all_empty(self, ui_manager: UIManager) -> None:
        elems = await ui_manager.find_all_async(Selector().text("Nonexistent"))
        assert elems == []


class TestExists:
    async def test_exists_true(self, ui_manager: UIManager) -> None:
        assert await ui_manager.exists_async(Selector().text("Login")) is True

    async def test_exists_false(self, ui_manager: UIManager) -> None:
        assert await ui_manager.exists_async(Selector().text("Nonexistent")) is False


class TestWaitFor:
    async def test_wait_for_immediate(self, ui_manager: UIManager) -> None:
        elem = await ui_manager.wait_for_async(Selector().text("Login"), timeout=1.0)
        assert isinstance(elem, UIElement)
        assert elem.get_text() == "Login"

    async def test_wait_for_eventual(
        self,
        mock_transport: SubprocessTransport,
        mock_gestures: GestureManager,
    ) -> None:
        call_count = 0

        async def side_effect(*args: object, **kwargs: object) -> object:
            nonlocal call_count
            call_count += 1
            # The cat call (every 2nd of 3) carries the XML payload.
            # First few rounds return empty hierarchy, then the real one.
            if call_count < 8:
                return make_result(stdout='<hierarchy rotation="0"></hierarchy>')
            return make_result(stdout=SIMPLE_HIERARCHY)

        mock_transport.execute_shell = AsyncMock(side_effect=side_effect)  # type: ignore[assignment]
        mgr = UIManager("emu", mock_transport, mock_gestures)
        elem = await mgr.wait_for_async(
            Selector().text("Login"), timeout=2.0, interval=0.01,
        )
        assert elem.get_text() == "Login"

    async def test_wait_for_timeout(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout='<hierarchy rotation="0"></hierarchy>'),
        )
        gm = MagicMock(spec=GestureManager)
        mgr = UIManager("emu", mock_transport, gm)  # type: ignore[arg-type]
        with pytest.raises(WaitTimeoutError):
            await mgr.wait_for_async(
                Selector().text("Nope"), timeout=0.05, interval=0.01,
            )


class TestInvalidateCache:
    async def test_invalidate(self, ui_manager: UIManager) -> None:
        await ui_manager.dump_async()
        ui_manager.invalidate_cache()
        await ui_manager.dump_async()
        # Two full dumps (3 calls each)
        assert ui_manager._transport.execute_shell.call_count == 6  # type: ignore[union-attr]
