"""Tests for recorder module."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.recorder.player import ActionPlayer
from adbflow.recorder.recorder import ActionRecorder
from adbflow.utils.types import ActionType, RecordedAction
from tests.conftest import make_result


@pytest.fixture
def recorder(mock_transport: SubprocessTransport) -> ActionRecorder:
    return ActionRecorder("emu", mock_transport)


@pytest.fixture
def player(mock_transport: SubprocessTransport) -> ActionPlayer:
    return ActionPlayer("emu", mock_transport)


class TestActionRecorder:
    def test_record_tap(self, recorder: ActionRecorder) -> None:
        recorder.record_tap(100, 200)
        assert len(recorder.actions) == 1
        a = recorder.actions[0]
        assert a.action_type == ActionType.TAP
        assert a.params == {"x": 100, "y": 200}

    def test_record_swipe(self, recorder: ActionRecorder) -> None:
        recorder.record_swipe(10, 20, 100, 200, 500)
        a = recorder.actions[0]
        assert a.action_type == ActionType.SWIPE
        assert a.params["duration"] == 500

    def test_record_key(self, recorder: ActionRecorder) -> None:
        recorder.record_key(4)
        a = recorder.actions[0]
        assert a.action_type == ActionType.KEY
        assert a.params["keycode"] == 4

    def test_record_text(self, recorder: ActionRecorder) -> None:
        recorder.record_text("hello")
        a = recorder.actions[0]
        assert a.action_type == ActionType.TEXT
        assert a.params["text"] == "hello"

    def test_record_wait(self, recorder: ActionRecorder) -> None:
        recorder.record_wait(2.0)
        a = recorder.actions[0]
        assert a.action_type == ActionType.WAIT
        assert a.params["seconds"] == 2.0

    def test_record_shell(self, recorder: ActionRecorder) -> None:
        recorder.record_shell("ls /sdcard")
        a = recorder.actions[0]
        assert a.action_type == ActionType.SHELL
        assert a.params["command"] == "ls /sdcard"

    def test_clear(self, recorder: ActionRecorder) -> None:
        recorder.record_tap(10, 20)
        recorder.record_tap(30, 40)
        assert len(recorder.actions) == 2
        recorder.clear()
        assert len(recorder.actions) == 0

    def test_to_json_from_json_roundtrip(self, recorder: ActionRecorder) -> None:
        recorder.record_tap(100, 200)
        recorder.record_text("hello")
        recorder.record_wait(1.0)

        json_str = recorder.to_json()
        parsed = json.loads(json_str)
        assert len(parsed) == 3

        restored = ActionRecorder.from_json(json_str)
        assert len(restored.actions) == 3
        assert restored.actions[0].action_type == ActionType.TAP
        assert restored.actions[1].params["text"] == "hello"
        assert restored.actions[2].params["seconds"] == 1.0

    def test_save_load(self, recorder: ActionRecorder, tmp_path: Path) -> None:
        recorder.record_tap(50, 60)
        recorder.record_key(3)

        file_path = tmp_path / "actions.json"
        recorder.save(file_path)

        loaded = ActionRecorder.load(file_path)
        assert len(loaded.actions) == 2
        assert loaded.actions[0].action_type == ActionType.TAP
        assert loaded.actions[1].action_type == ActionType.KEY

    def test_actions_returns_copy(self, recorder: ActionRecorder) -> None:
        recorder.record_tap(10, 20)
        actions = recorder.actions
        actions.clear()
        assert len(recorder.actions) == 1


class TestActionPlayer:
    async def test_play_tap(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.TAP,
                params={"x": 100, "y": 200},
                timestamp=0.0,
                description="Tap",
            ),
        ]
        await player.play_async(actions)
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "input tap 100 200" in call

    async def test_play_swipe(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.SWIPE,
                params={"x1": 10, "y1": 20, "x2": 100, "y2": 200, "duration": 300},
                timestamp=0.0,
                description="Swipe",
            ),
        ]
        await player.play_async(actions, speed=1.0)
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "input swipe 10 20 100 200 300" in call

    async def test_play_speed_multiplier(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.SWIPE,
                params={"x1": 0, "y1": 0, "x2": 100, "y2": 100, "duration": 600},
                timestamp=0.0,
                description="Swipe",
            ),
        ]
        await player.play_async(actions, speed=2.0)
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "300" in call  # 600 / 2.0 = 300

    async def test_play_key(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.KEY,
                params={"keycode": 4},
                timestamp=0.0,
                description="Key",
            ),
        ]
        await player.play_async(actions)
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "input keyevent 4" in call

    async def test_play_shell(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.SHELL,
                params={"command": "echo hello"},
                timestamp=0.0,
                description="Shell",
            ),
        ]
        await player.play_async(actions)
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "echo hello" in call

    async def test_play_loop(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.TAP,
                params={"x": 10, "y": 20},
                timestamp=0.0,
                description="Tap",
            ),
        ]
        await player.play_loop_async(actions, count=3)
        assert mock_transport.execute_shell.call_count == 3  # type: ignore[union-attr]

    async def test_play_executes_in_order(
        self, player: ActionPlayer, mock_transport: SubprocessTransport,
    ) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        actions = [
            RecordedAction(
                action_type=ActionType.TAP,
                params={"x": 10, "y": 20},
                timestamp=0.0,
                description="Tap 1",
            ),
            RecordedAction(
                action_type=ActionType.KEY,
                params={"keycode": 4},
                timestamp=0.0,
                description="Key",
            ),
            RecordedAction(
                action_type=ActionType.TAP,
                params={"x": 30, "y": 40},
                timestamp=0.0,
                description="Tap 2",
            ),
        ]
        await player.play_async(actions)
        calls = mock_transport.execute_shell.call_args_list  # type: ignore[union-attr]
        assert "input tap 10 20" in calls[0][0][0]
        assert "input keyevent 4" in calls[1][0][0]
        assert "input tap 30 40" in calls[2][0][0]
