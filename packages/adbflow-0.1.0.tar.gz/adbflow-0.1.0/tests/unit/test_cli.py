"""Tests for CLI module."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from adbflow.cli.app import _build_parser, app
from adbflow.utils.types import DeviceListEntry, DeviceState


class TestCLIParser:
    def test_devices_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["devices"])
        assert args.command == "devices"

    def test_shell_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["shell", "emulator-5554", "echo", "hello"])
        assert args.command == "shell"
        assert args.serial == "emulator-5554"
        assert args.cmd == ["echo", "hello"]

    def test_screenshot_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["screenshot", "emu", "out.png"])
        assert args.command == "screenshot"
        assert args.serial == "emu"
        assert args.output == "out.png"

    def test_info_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["info", "emu"])
        assert args.command == "info"
        assert args.serial == "emu"

    def test_logcat_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["logcat", "emu", "--tag", "MyApp", "--level", "D"])
        assert args.command == "logcat"
        assert args.tag == "MyApp"
        assert args.level == "D"

    def test_play_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["play", "emu", "actions.json", "--speed", "2.0"])
        assert args.command == "play"
        assert args.speed == 2.0

    def test_no_subcommand(self) -> None:
        parser = _build_parser()
        args = parser.parse_args([])
        assert args.command is None


class TestCLIExecution:
    def test_devices_command(self, capsys: pytest.CaptureFixture[str]) -> None:
        entry = DeviceListEntry(
            serial="emulator-5554",
            state=DeviceState.DEVICE,
            model="sdk_phone",
        )
        mock_adb = MagicMock()
        mock_adb.return_value.devices_async = AsyncMock(return_value=[entry])

        with patch("adbflow.cli.app.ADB", mock_adb):
            with patch("sys.argv", ["adbflow", "devices"]):
                app()

        captured = capsys.readouterr()
        assert "emulator-5554" in captured.out
        assert "device" in captured.out

    def test_shell_command(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_adb = MagicMock()
        mock_device = MagicMock()
        mock_device.shell_async = AsyncMock(return_value="hello world")
        mock_adb.return_value.device.return_value = mock_device

        with patch("adbflow.cli.app.ADB", mock_adb):
            with patch("sys.argv", ["adbflow", "shell", "emu", "echo", "hello"]):
                app()

        captured = capsys.readouterr()
        assert "hello world" in captured.out

    def test_info_command(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_adb = MagicMock()
        mock_device = MagicMock()
        mock_device.info.model_async = AsyncMock(return_value="Pixel 6")
        mock_device.info.android_version_async = AsyncMock(return_value="13")
        mock_device.info.sdk_level_async = AsyncMock(return_value=33)
        mock_adb.return_value.device.return_value = mock_device

        with patch("adbflow.cli.app.ADB", mock_adb):
            with patch("sys.argv", ["adbflow", "info", "emu"]):
                app()

        captured = capsys.readouterr()
        assert "Pixel 6" in captured.out
        assert "13" in captured.out

    def test_no_command_prints_help(self, capsys: pytest.CaptureFixture[str]) -> None:
        with patch("sys.argv", ["adbflow"]):
            with pytest.raises(SystemExit):
                app()
