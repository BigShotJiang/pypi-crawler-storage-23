"""Shared test fixtures."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.types import Result


def make_result(
    stdout: str = "",
    stderr: str = "",
    return_code: int = 0,
    duration_ms: float = 1.0,
) -> Result:
    """Create a Result with string convenience."""
    return Result(
        stdout=stdout.encode(),
        stderr=stderr.encode(),
        return_code=return_code,
        duration_ms=duration_ms,
    )


@pytest.fixture
def mock_transport() -> SubprocessTransport:
    """A SubprocessTransport with mocked execute/execute_shell methods."""
    transport = SubprocessTransport.__new__(SubprocessTransport)
    transport._adb_path = "/usr/bin/adb"
    transport.execute = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    transport.execute_shell = AsyncMock(return_value=make_result())  # type: ignore[assignment]
    return transport
