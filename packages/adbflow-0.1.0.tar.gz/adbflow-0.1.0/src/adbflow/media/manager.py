"""Composite media manager."""

from __future__ import annotations

from functools import cached_property

from adbflow.core.transport import SubprocessTransport
from adbflow.media.audio import AudioManager
from adbflow.media.recording import ScreenRecorder
from adbflow.media.screenshot import ScreenshotManager


class MediaManager:
    """Composite manager for media operations (screenshot, recording, audio).

    Usage::

        data = await device.media.screenshot.capture_async()
        await device.media.recording.start_async()
        vol = await device.media.audio.get_volume_async(AudioStream.MUSIC)

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    @cached_property
    def screenshot(self) -> ScreenshotManager:
        """Screenshot capture manager."""
        return ScreenshotManager(self._serial, self._transport)

    @cached_property
    def recording(self) -> ScreenRecorder:
        """Screen recording manager."""
        return ScreenRecorder(self._serial, self._transport)

    @cached_property
    def audio(self) -> AudioManager:
        """Audio volume manager."""
        return AudioManager(self._serial, self._transport)
