"""Network controls — WiFi, mobile data, airplane, forwarding, proxy, tcpdump."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_forward_list, parse_wifi_info
from adbflow.utils.types import ForwardRule, ProxyConfig, WifiInfo


class NetworkManager:
    """Manages network settings on a connected device.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    # ------------------------------------------------------------------
    # WiFi
    # ------------------------------------------------------------------

    async def wifi_enable_async(self) -> None:
        """Enable WiFi."""
        result = await self._transport.execute_shell(
            "svc wifi enable", serial=self._serial,
        )
        result.raise_on_error("svc wifi enable")

    async def wifi_disable_async(self) -> None:
        """Disable WiFi."""
        result = await self._transport.execute_shell(
            "svc wifi disable", serial=self._serial,
        )
        result.raise_on_error("svc wifi disable")

    async def wifi_is_enabled_async(self) -> bool:
        """Check whether WiFi is enabled.

        Returns:
            True if WiFi is enabled.
        """
        result = await self._transport.execute_shell(
            "settings get global wifi_on", serial=self._serial,
        )
        return result.output.strip() == "1"

    async def wifi_info_async(self) -> WifiInfo | None:
        """Get current WiFi connection information.

        Returns:
            WifiInfo or None if not connected.
        """
        result = await self._transport.execute_shell(
            "dumpsys wifi", serial=self._serial,
        )
        if not result.success:
            return None
        return parse_wifi_info(result.output)

    async def wifi_connect_async(
        self,
        ssid: str,
        password: str | None = None,
        security: str | None = None,
    ) -> None:
        """Connect to a WiFi network.

        Args:
            ssid: Network SSID.
            password: Network password (None for open networks).
            security: Security type (e.g. ``WPA``, ``WEP``).
        """
        cmd = f"cmd wifi connect-network {ssid}"
        if security:
            cmd += f" {security}"
        else:
            cmd += " open"
        if password:
            cmd += f" {password}"
        result = await self._transport.execute_shell(cmd, serial=self._serial)
        result.raise_on_error(f"wifi connect {ssid}")

    # ------------------------------------------------------------------
    # Mobile data
    # ------------------------------------------------------------------

    async def mobile_data_enable_async(self) -> None:
        """Enable mobile data."""
        result = await self._transport.execute_shell(
            "svc data enable", serial=self._serial,
        )
        result.raise_on_error("svc data enable")

    async def mobile_data_disable_async(self) -> None:
        """Disable mobile data."""
        result = await self._transport.execute_shell(
            "svc data disable", serial=self._serial,
        )
        result.raise_on_error("svc data disable")

    async def mobile_data_is_enabled_async(self) -> bool:
        """Check whether mobile data is enabled.

        Returns:
            True if mobile data is enabled.
        """
        result = await self._transport.execute_shell(
            "settings get global mobile_data", serial=self._serial,
        )
        return result.output.strip() == "1"

    # ------------------------------------------------------------------
    # Airplane mode
    # ------------------------------------------------------------------

    async def airplane_enable_async(self) -> None:
        """Enable airplane mode."""
        await self._transport.execute_shell(
            "settings put global airplane_mode_on 1", serial=self._serial,
        )
        await self._transport.execute_shell(
            "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true",
            serial=self._serial,
        )

    async def airplane_disable_async(self) -> None:
        """Disable airplane mode."""
        await self._transport.execute_shell(
            "settings put global airplane_mode_on 0", serial=self._serial,
        )
        await self._transport.execute_shell(
            "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false",
            serial=self._serial,
        )

    async def airplane_is_enabled_async(self) -> bool:
        """Check whether airplane mode is enabled.

        Returns:
            True if airplane mode is on.
        """
        result = await self._transport.execute_shell(
            "settings get global airplane_mode_on", serial=self._serial,
        )
        return result.output.strip() == "1"

    # ------------------------------------------------------------------
    # Port forwarding (ADB-level, not shell)
    # ------------------------------------------------------------------

    async def forward_async(self, local: str, remote: str) -> None:
        """Set up port forwarding from host to device.

        Args:
            local: Local address (e.g. ``tcp:8080``).
            remote: Remote address (e.g. ``tcp:80``).
        """
        result = await self._transport.execute(
            ["forward", local, remote], serial=self._serial,
        )
        result.raise_on_error(f"forward {local} {remote}")

    async def forward_remove_async(self, local: str) -> None:
        """Remove a specific port forwarding rule.

        Args:
            local: Local address to remove (e.g. ``tcp:8080``).
        """
        result = await self._transport.execute(
            ["forward", "--remove", local], serial=self._serial,
        )
        result.raise_on_error(f"forward --remove {local}")

    async def forward_remove_all_async(self) -> None:
        """Remove all port forwarding rules."""
        result = await self._transport.execute(
            ["forward", "--remove-all"], serial=self._serial,
        )
        result.raise_on_error("forward --remove-all")

    async def forward_list_async(self) -> list[ForwardRule]:
        """List all active port forwarding rules.

        Returns:
            List of ForwardRule entries.
        """
        result = await self._transport.execute(
            ["forward", "--list"], serial=self._serial,
        )
        if not result.success:
            return []
        return parse_forward_list(result.output)

    # ------------------------------------------------------------------
    # Reverse port forwarding
    # ------------------------------------------------------------------

    async def reverse_async(self, remote: str, local: str) -> None:
        """Set up reverse port forwarding from device to host.

        Args:
            remote: Remote address on device (e.g. ``tcp:8080``).
            local: Local address on host (e.g. ``tcp:80``).
        """
        result = await self._transport.execute(
            ["reverse", remote, local], serial=self._serial,
        )
        result.raise_on_error(f"reverse {remote} {local}")

    async def reverse_remove_async(self, remote: str) -> None:
        """Remove a specific reverse forwarding rule.

        Args:
            remote: Remote address to remove.
        """
        result = await self._transport.execute(
            ["reverse", "--remove", remote], serial=self._serial,
        )
        result.raise_on_error(f"reverse --remove {remote}")

    async def reverse_remove_all_async(self) -> None:
        """Remove all reverse forwarding rules."""
        result = await self._transport.execute(
            ["reverse", "--remove-all"], serial=self._serial,
        )
        result.raise_on_error("reverse --remove-all")

    # ------------------------------------------------------------------
    # Proxy
    # ------------------------------------------------------------------

    async def proxy_set_async(self, config: ProxyConfig) -> None:
        """Set the HTTP proxy.

        Args:
            config: Proxy configuration.
        """
        proxy_str = f"{config.host}:{config.port}"
        await self._transport.execute_shell(
            f"settings put global http_proxy {proxy_str}",
            serial=self._serial,
        )
        if config.exclude:
            await self._transport.execute_shell(
                f"settings put global global_http_proxy_exclusion_list {config.exclude}",
                serial=self._serial,
            )

    async def proxy_clear_async(self) -> None:
        """Clear the HTTP proxy."""
        await self._transport.execute_shell(
            "settings delete global http_proxy", serial=self._serial,
        )
        await self._transport.execute_shell(
            "settings delete global global_http_proxy_host", serial=self._serial,
        )
        await self._transport.execute_shell(
            "settings delete global global_http_proxy_port", serial=self._serial,
        )

    async def proxy_get_async(self) -> ProxyConfig | None:
        """Get the current HTTP proxy configuration.

        Returns:
            ProxyConfig or None if no proxy is set.
        """
        result = await self._transport.execute_shell(
            "settings get global http_proxy", serial=self._serial,
        )
        value = result.output.strip()
        if not value or value == "null" or value == ":0":
            return None
        if ":" in value:
            host, _, port_str = value.rpartition(":")
            try:
                port = int(port_str)
            except ValueError:
                return None
            return ProxyConfig(host=host, port=port)
        return None

    # ------------------------------------------------------------------
    # Tcpdump
    # ------------------------------------------------------------------

    async def tcpdump_start_async(
        self,
        output_path: str,
        interface: str | None = None,
        filter_expr: str | None = None,
    ) -> None:
        """Start a tcpdump capture in the background.

        Args:
            output_path: Remote path to save the capture file.
            interface: Network interface to capture on (e.g. ``wlan0``).
            filter_expr: BPF filter expression.
        """
        cmd = f"tcpdump -w {output_path}"
        if interface:
            cmd += f" -i {interface}"
        if filter_expr:
            cmd += f" {filter_expr}"
        await self._transport.execute_shell(
            f"nohup {cmd} > /dev/null 2>&1 &", serial=self._serial,
        )

    async def tcpdump_stop_async(self) -> None:
        """Stop the running tcpdump capture."""
        await self._transport.execute_shell(
            "pkill -f tcpdump || killall tcpdump", serial=self._serial,
        )

    async def tcpdump_pull_async(
        self,
        local: str,
        remote: str = "/sdcard/capture.pcap",
    ) -> None:
        """Pull a tcpdump capture file from the device.

        Args:
            local: Local destination path.
            remote: Remote capture file path.
        """
        result = await self._transport.execute(
            ["pull", remote, local], serial=self._serial,
        )
        result.raise_on_error(f"pull {remote}")
