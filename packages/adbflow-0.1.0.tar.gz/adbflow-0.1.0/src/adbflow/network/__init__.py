"""Network controls module."""

from adbflow.network.controls import NetworkManager

__all__ = ["NetworkManager"]
