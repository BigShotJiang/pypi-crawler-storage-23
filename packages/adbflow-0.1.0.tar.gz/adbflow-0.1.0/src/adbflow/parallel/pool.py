"""Device pool — multi-device orchestration."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine, Iterator
from typing import Any, TypeVar

from adbflow.device.device import Device

T = TypeVar("T")


class DevicePool:
    """Orchestrates operations across multiple devices.

    Args:
        devices: List of ``Device`` objects to manage.
    """

    def __init__(self, devices: list[Device]) -> None:
        self._devices = list(devices)

    @property
    def devices(self) -> list[Device]:
        """The managed device list."""
        return list(self._devices)

    def __len__(self) -> int:
        return len(self._devices)

    def __iter__(self) -> Iterator[Device]:
        return iter(self._devices)

    async def run_async(
        self,
        fn: Callable[..., Coroutine[Any, Any, T]],
        *args: Any,
        **kwargs: Any,
    ) -> list[T | BaseException]:
        """Run an async function on all devices in parallel.

        Args:
            fn: Async callable that takes a ``Device`` as its first argument.
            *args: Additional positional arguments.
            **kwargs: Additional keyword arguments.

        Returns:
            List of results or exceptions (one per device).
        """
        tasks = [fn(dev, *args, **kwargs) for dev in self._devices]
        results: list[T | BaseException] = await asyncio.gather(
            *tasks, return_exceptions=True,
        )
        return results

    async def run_sequential_async(
        self,
        fn: Callable[..., Coroutine[Any, Any, T]],
        *args: Any,
        **kwargs: Any,
    ) -> list[T | BaseException]:
        """Run an async function on each device sequentially.

        Args:
            fn: Async callable that takes a ``Device`` as its first argument.
            *args: Additional positional arguments.
            **kwargs: Additional keyword arguments.

        Returns:
            List of results or exceptions (one per device).
        """
        results: list[T | BaseException] = []
        for dev in self._devices:
            try:
                result = await fn(dev, *args, **kwargs)
                results.append(result)
            except BaseException as exc:
                results.append(exc)
        return results

    async def filter_async(
        self,
        fn: Callable[[Device], Coroutine[Any, Any, bool]],
    ) -> list[Device]:
        """Filter devices by an async predicate.

        Args:
            fn: Async callable returning ``True`` to keep the device.

        Returns:
            List of devices matching the predicate.
        """
        results = await asyncio.gather(
            *[fn(dev) for dev in self._devices], return_exceptions=True,
        )
        return [
            dev
            for dev, result in zip(self._devices, results)
            if result is True
        ]

    async def first_async(
        self,
        fn: Callable[[Device], Coroutine[Any, Any, bool]],
    ) -> Device | None:
        """Return the first device matching an async predicate.

        Args:
            fn: Async callable returning ``True`` for a match.

        Returns:
            The first matching ``Device`` or ``None``.
        """
        for dev in self._devices:
            try:
                if await fn(dev):
                    return dev
            except Exception:
                continue
        return None
