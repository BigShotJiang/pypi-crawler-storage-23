"""Touch gesture controls (tap, swipe, drag, pinch, text, key)."""

from adbflow.gestures.manager import GestureManager

__all__ = ["GestureManager"]
