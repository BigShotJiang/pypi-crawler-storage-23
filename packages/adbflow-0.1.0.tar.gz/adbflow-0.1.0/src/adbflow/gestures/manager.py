"""Gesture manager — tap, swipe, drag, pinch, text, and key input."""

from __future__ import annotations

from adbflow.utils.geometry import Point
from adbflow.utils.types import KeyCode, SwipeDirection, TransportProtocol


def _escape_text(text: str) -> str:
    """Escape *text* for ``input text``: spaces become ``%s``."""
    return text.replace(" ", "%s")


class GestureManager:
    """Touch gesture controls for a device.

    All methods use ADB ``input`` shell commands.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport

    async def tap_async(self, x: int | Point, y: int | None = None) -> None:
        """Tap at the given coordinates.

        Args:
            x: X coordinate or a ``Point``.
            y: Y coordinate (required when *x* is an int).
        """
        if isinstance(x, Point):
            px, py = x.x, x.y
        else:
            assert y is not None, "y is required when x is an int"
            px, py = x, y
        await self._transport.execute_shell(
            f"input tap {px} {py}",
            serial=self._serial,
        )

    async def long_tap_async(
        self,
        point: Point,
        duration_ms: int = 1000,
    ) -> None:
        """Long-tap at *point* for *duration_ms* milliseconds.

        Implemented as a zero-distance swipe.
        """
        await self._transport.execute_shell(
            f"input swipe {point.x} {point.y} {point.x} {point.y} {duration_ms}",
            serial=self._serial,
        )

    async def swipe_async(
        self,
        start: Point,
        end: Point,
        duration_ms: int = 300,
    ) -> None:
        """Swipe from *start* to *end*.

        Args:
            start: Starting point.
            end: Ending point.
            duration_ms: Swipe duration in milliseconds.
        """
        await self._transport.execute_shell(
            f"input swipe {start.x} {start.y} {end.x} {end.y} {duration_ms}",
            serial=self._serial,
        )

    async def swipe_direction_async(
        self,
        direction: SwipeDirection,
        start: Point | None = None,
        distance: int = 500,
        duration_ms: int = 300,
        screen_size: tuple[int, int] = (1080, 1920),
    ) -> None:
        """Swipe in *direction* from *start* (or screen center).

        Args:
            direction: Swipe direction.
            start: Starting point (defaults to screen center).
            distance: Swipe distance in pixels.
            duration_ms: Swipe duration in milliseconds.
            screen_size: Screen width and height (for default center).
        """
        if start is None:
            start = Point(screen_size[0] // 2, screen_size[1] // 2)

        if direction is SwipeDirection.UP:
            end = Point(start.x, start.y - distance)
        elif direction is SwipeDirection.DOWN:
            end = Point(start.x, start.y + distance)
        elif direction is SwipeDirection.LEFT:
            end = Point(start.x - distance, start.y)
        else:  # RIGHT
            end = Point(start.x + distance, start.y)

        await self.swipe_async(start, end, duration_ms)

    async def drag_async(
        self,
        start: Point,
        end: Point,
        duration_ms: int = 1000,
    ) -> None:
        """Drag from *start* to *end* (longer default duration than swipe).

        Args:
            start: Starting point.
            end: Ending point.
            duration_ms: Drag duration in milliseconds.
        """
        await self._transport.execute_shell(
            f"input swipe {start.x} {start.y} {end.x} {end.y} {duration_ms}",
            serial=self._serial,
        )

    async def pinch_in_async(
        self,
        center: Point,
        distance: int = 200,
        duration_ms: int = 500,
    ) -> None:
        """Pinch inward at *center*.

        Uses multi-touch via shell script with ``input motionevent``.
        Requires Android 10+.

        Args:
            center: Center point for the pinch.
            distance: Initial finger distance from center.
            duration_ms: Pinch duration in milliseconds.
        """
        half = distance // 2
        script = (
            f"input motionevent DOWN {center.x - half} {center.y} && "
            f"input motionevent DOWN {center.x + half} {center.y} && "
            f"sleep $(echo 'scale=3; {duration_ms}/1000' | bc) && "
            f"input motionevent MOVE {center.x - 10} {center.y} && "
            f"input motionevent MOVE {center.x + 10} {center.y} && "
            f"input motionevent UP {center.x - 10} {center.y} && "
            f"input motionevent UP {center.x + 10} {center.y}"
        )
        await self._transport.execute_shell(script, serial=self._serial)

    async def pinch_out_async(
        self,
        center: Point,
        distance: int = 200,
        duration_ms: int = 500,
    ) -> None:
        """Pinch outward at *center*.

        Uses multi-touch via shell script with ``input motionevent``.
        Requires Android 10+.

        Args:
            center: Center point for the pinch.
            distance: Target finger distance from center.
            duration_ms: Pinch duration in milliseconds.
        """
        half = distance // 2
        script = (
            f"input motionevent DOWN {center.x - 10} {center.y} && "
            f"input motionevent DOWN {center.x + 10} {center.y} && "
            f"sleep $(echo 'scale=3; {duration_ms}/1000' | bc) && "
            f"input motionevent MOVE {center.x - half} {center.y} && "
            f"input motionevent MOVE {center.x + half} {center.y} && "
            f"input motionevent UP {center.x - half} {center.y} && "
            f"input motionevent UP {center.x + half} {center.y}"
        )
        await self._transport.execute_shell(script, serial=self._serial)

    async def text_async(self, text: str) -> None:
        """Type *text* on the device.

        Spaces are converted to ``%s`` for the ``input text`` command.

        Args:
            text: Text to type.
        """
        escaped = _escape_text(text)
        await self._transport.execute_shell(
            f"input text {escaped!r}",
            serial=self._serial,
        )

    async def key_async(self, code: KeyCode | int) -> None:
        """Send a key event.

        Args:
            code: Key code (``KeyCode`` enum or raw int).
        """
        await self._transport.execute_shell(
            f"input keyevent {int(code)}",
            serial=self._serial,
        )
