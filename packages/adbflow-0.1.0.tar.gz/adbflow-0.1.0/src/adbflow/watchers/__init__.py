"""UI watchers — auto-respond to UI conditions."""

from adbflow.watchers.manager import WatcherManager, click_watcher, dismiss_watcher

__all__ = ["WatcherManager", "click_watcher", "dismiss_watcher"]
