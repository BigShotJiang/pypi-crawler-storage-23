"""Flow engine — workflow execution."""

from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine
from typing import Any

from adbflow.device.device import Device
from adbflow.flow.step import FlowContext, Step
from adbflow.utils.types import ErrorStrategy

logger = logging.getLogger(__name__)


class Flow:
    """Workflow engine for executing a sequence of steps.

    Args:
        name: Flow name for logging.
        device: Target device.
    """

    def __init__(self, name: str, device: Device) -> None:
        self._name = name
        self._device = device
        self._steps: list[Step] = []

    @property
    def steps(self) -> list[Step]:
        """The registered steps."""
        return list(self._steps)

    def add_step(
        self,
        name: str,
        action: Callable[[FlowContext], Coroutine[Any, Any, Any]],
        condition: Callable[[FlowContext], Coroutine[Any, Any, bool]] | None = None,
        on_error: ErrorStrategy = ErrorStrategy.STOP,
        retries: int = 0,
    ) -> Flow:
        """Add a step to the flow.

        Args:
            name: Step name.
            action: Async action callable.
            condition: Optional condition; step skipped if ``False``.
            on_error: Error handling strategy.
            retries: Number of retries for ``RETRY`` strategy.

        Returns:
            Self for fluent chaining.
        """
        self._steps.append(
            Step(
                name=name,
                action=action,
                condition=condition,
                on_error=on_error,
                retries=retries,
            )
        )
        return self

    async def run_async(self) -> FlowContext:
        """Execute all steps in order.

        Returns:
            The ``FlowContext`` with all results and variables.

        Raises:
            Exception: Re-raises step exceptions when ``ErrorStrategy.STOP``.
        """
        ctx = FlowContext(device=self._device)

        for step in self._steps:
            # Check condition
            if step.condition is not None:
                should_run = await step.condition(ctx)
                if not should_run:
                    logger.info("Flow %r: skipping step %r (condition false)", self._name, step.name)
                    continue

            # Execute with error handling
            await self._run_step(step, ctx)

        return ctx

    async def _run_step(self, step: Step, ctx: FlowContext) -> None:
        """Execute a single step with error handling."""
        attempts = step.retries + 1 if step.on_error == ErrorStrategy.RETRY else 1

        for attempt in range(attempts):
            try:
                result = await step.action(ctx)
                ctx.step_results[step.name] = result
                return
            except Exception as exc:
                if step.on_error == ErrorStrategy.RETRY and attempt < attempts - 1:
                    logger.warning(
                        "Flow %r: step %r failed (attempt %d/%d): %s",
                        self._name, step.name, attempt + 1, attempts, exc,
                    )
                    continue
                if step.on_error == ErrorStrategy.SKIP:
                    logger.warning(
                        "Flow %r: step %r failed, skipping: %s",
                        self._name, step.name, exc,
                    )
                    return
                # STOP or exhausted retries
                raise
