"""Flow step and context definitions."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any

from adbflow.device.device import Device
from adbflow.utils.types import ErrorStrategy


@dataclass
class FlowContext:
    """Shared context passed between flow steps.

    Attributes:
        device: The target device.
        variables: Shared state between steps.
        step_results: Results keyed by step name.
    """

    device: Device
    variables: dict[str, Any] = field(default_factory=dict)
    step_results: dict[str, Any] = field(default_factory=dict)


class Step:
    """A single step in a flow.

    Args:
        name: Step name (used as key in ``step_results``).
        action: Async callable receiving ``FlowContext``.
        condition: Optional async predicate; step is skipped if ``False``.
        on_error: Error handling strategy.
        retries: Number of retries (only for ``ErrorStrategy.RETRY``).
    """

    def __init__(
        self,
        name: str,
        action: Callable[[FlowContext], Coroutine[Any, Any, Any]],
        condition: Callable[[FlowContext], Coroutine[Any, Any, bool]] | None = None,
        on_error: ErrorStrategy = ErrorStrategy.STOP,
        retries: int = 0,
    ) -> None:
        self.name = name
        self.action = action
        self.condition = condition
        self.on_error = on_error
        self.retries = retries
