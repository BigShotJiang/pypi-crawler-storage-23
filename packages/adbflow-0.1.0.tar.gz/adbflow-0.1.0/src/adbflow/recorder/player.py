"""Action player — replay recorded actions."""

from __future__ import annotations

import asyncio

from adbflow.utils.types import ActionType, RecordedAction, TransportProtocol


class ActionPlayer:
    """Replays recorded actions on a device.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport

    async def play_async(
        self,
        actions: list[RecordedAction],
        speed: float = 1.0,
    ) -> None:
        """Execute recorded actions sequentially.

        Args:
            actions: List of actions to replay.
            speed: Speed multiplier (2.0 = twice as fast).
        """
        for action in actions:
            await self._execute_action(action, speed)

    async def play_loop_async(
        self,
        actions: list[RecordedAction],
        count: int = 1,
        speed: float = 1.0,
    ) -> None:
        """Repeat recorded actions N times.

        Args:
            actions: List of actions to replay.
            count: Number of iterations.
            speed: Speed multiplier.
        """
        for _ in range(count):
            await self.play_async(actions, speed)

    async def _execute_action(self, action: RecordedAction, speed: float) -> None:
        """Execute a single recorded action."""
        params = action.params
        if action.action_type == ActionType.TAP:
            await self._transport.execute_shell(
                f"input tap {params['x']} {params['y']}",
                serial=self._serial,
            )
        elif action.action_type == ActionType.SWIPE:
            duration = int(params["duration"] / speed) if speed > 0 else params["duration"]
            await self._transport.execute_shell(
                f"input swipe {params['x1']} {params['y1']} "
                f"{params['x2']} {params['y2']} {duration}",
                serial=self._serial,
            )
        elif action.action_type == ActionType.KEY:
            await self._transport.execute_shell(
                f"input keyevent {params['keycode']}",
                serial=self._serial,
            )
        elif action.action_type == ActionType.TEXT:
            escaped = params["text"].replace(" ", "%s")
            await self._transport.execute_shell(
                f"input text {escaped}",
                serial=self._serial,
            )
        elif action.action_type == ActionType.WAIT:
            wait_time = params["seconds"] / speed if speed > 0 else params["seconds"]
            await asyncio.sleep(wait_time)
        elif action.action_type == ActionType.SHELL:
            await self._transport.execute_shell(
                params["command"],
                serial=self._serial,
            )
