"""UI manager — hierarchy dump, find, and wait operations."""

from __future__ import annotations

import asyncio
import time

from adbflow.gestures.manager import GestureManager
from adbflow.ui.element import UIElement
from adbflow.ui.hierarchy import UINode, parse_hierarchy
from adbflow.ui.selector import Selector
from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.utils.types import TransportProtocol

_CACHE_TTL = 2.0  # seconds
_DUMP_PATH = "/sdcard/window_dump.xml"


class UIManager:
    """UI automation: hierarchy dumps, element finding, and waiting.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
        gestures: Gesture manager for element interactions.
    """

    def __init__(
        self,
        serial: str,
        transport: TransportProtocol,
        gestures: GestureManager,
    ) -> None:
        self._serial = serial
        self._transport = transport
        self._gestures = gestures
        self._cached_root: UINode | None = None
        self._cache_time: float = 0.0

    async def dump_async(self, force: bool = False) -> UINode:
        """Dump the UI hierarchy.

        Args:
            force: If True, bypass the cache.

        Returns:
            Root ``UINode`` of the hierarchy.
        """
        now = time.monotonic()
        if not force and self._cached_root is not None:
            if now - self._cache_time < _CACHE_TTL:
                return self._cached_root

        await self._transport.execute_shell(
            f"uiautomator dump {_DUMP_PATH}",
            serial=self._serial,
        )
        result = await self._transport.execute_shell(
            f"cat {_DUMP_PATH}",
            serial=self._serial,
        )
        await self._transport.execute_shell(
            f"rm -f {_DUMP_PATH}",
            serial=self._serial,
        )
        xml = result.output
        # Strip any non-XML prefix (e.g. status messages)
        xml_start = xml.find("<?xml")
        if xml_start < 0:
            xml_start = xml.find("<hierarchy")
        if xml_start > 0:
            xml = xml[xml_start:]
        root = parse_hierarchy(xml)
        self._cached_root = root
        self._cache_time = time.monotonic()
        return root

    async def find_async(self, selector: Selector) -> UIElement | None:
        """Find the first element matching *selector*.

        Args:
            selector: Element selector.

        Returns:
            A ``UIElement`` or None if not found.
        """
        root = await self.dump_async()
        for node in root.iter_all():
            if selector.matches(node):
                return UIElement(node, self._gestures, self)
        return None

    async def find_all_async(self, selector: Selector) -> list[UIElement]:
        """Find all elements matching *selector*.

        Args:
            selector: Element selector.

        Returns:
            List of matching ``UIElement`` objects.
        """
        root = await self.dump_async()
        return [
            UIElement(node, self._gestures, self)
            for node in root.iter_all()
            if selector.matches(node)
        ]

    async def exists_async(self, selector: Selector) -> bool:
        """Check if any element matches *selector*.

        Forces a fresh hierarchy dump.

        Args:
            selector: Element selector.
        """
        self.invalidate_cache()
        root = await self.dump_async()
        return any(selector.matches(node) for node in root.iter_all())

    async def wait_for_async(
        self,
        selector: Selector,
        timeout: float = 10.0,
        interval: float = 0.5,
    ) -> UIElement:
        """Wait until an element matching *selector* appears.

        Args:
            selector: Element selector.
            timeout: Maximum wait time in seconds.
            interval: Polling interval in seconds.

        Returns:
            The first matching ``UIElement``.

        Raises:
            WaitTimeoutError: If no match within *timeout*.
        """
        start = time.monotonic()
        while True:
            self.invalidate_cache()
            root = await self.dump_async()
            for node in root.iter_all():
                if selector.matches(node):
                    return UIElement(node, self._gestures, self)
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise WaitTimeoutError(
                    timeout=timeout,
                    condition_name=selector.describe(),
                    elapsed=elapsed,
                )
            await asyncio.sleep(min(interval, timeout - elapsed))

    def invalidate_cache(self) -> None:
        """Clear the cached hierarchy root and timestamp."""
        self._cached_root = None
        self._cache_time = 0.0
