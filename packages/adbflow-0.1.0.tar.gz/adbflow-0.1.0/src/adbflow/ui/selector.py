"""Fluent UI element selector."""

from __future__ import annotations

from dataclasses import dataclass, field

from adbflow.ui.hierarchy import UINode


@dataclass
class Selector:
    """Mutable, fluent builder for matching ``UINode`` elements.

    Usage::

        sel = Selector().text("Login").clickable()
        if sel.matches(node):
            ...
    """

    _text: str | None = field(default=None, repr=False)
    _text_contains: str | None = field(default=None, repr=False)
    _text_starts_with: str | None = field(default=None, repr=False)
    _resource_id: str | None = field(default=None, repr=False)
    _resource_id_contains: str | None = field(default=None, repr=False)
    _class_name: str | None = field(default=None, repr=False)
    _package: str | None = field(default=None, repr=False)
    _description: str | None = field(default=None, repr=False)
    _description_contains: str | None = field(default=None, repr=False)
    _clickable: bool | None = field(default=None, repr=False)
    _enabled: bool | None = field(default=None, repr=False)
    _scrollable: bool | None = field(default=None, repr=False)
    _checkable: bool | None = field(default=None, repr=False)
    _checked: bool | None = field(default=None, repr=False)
    _focusable: bool | None = field(default=None, repr=False)
    _focused: bool | None = field(default=None, repr=False)
    _long_clickable: bool | None = field(default=None, repr=False)
    _selected: bool | None = field(default=None, repr=False)
    _index: int | None = field(default=None, repr=False)
    _child: Selector | None = field(default=None, repr=False)
    _sibling: Selector | None = field(default=None, repr=False)

    # ---- Fluent setters (return self for chaining) ----

    def text(self, value: str) -> Selector:
        """Match exact text."""
        self._text = value
        return self

    def text_contains(self, value: str) -> Selector:
        """Match text containing *value*."""
        self._text_contains = value
        return self

    def text_starts_with(self, value: str) -> Selector:
        """Match text starting with *value*."""
        self._text_starts_with = value
        return self

    def resource_id(self, value: str) -> Selector:
        """Match resource ID."""
        self._resource_id = value
        return self

    def resource_id_contains(self, value: str) -> Selector:
        """Match resource ID containing *value*."""
        self._resource_id_contains = value
        return self

    def class_name(self, value: str) -> Selector:
        """Match class name."""
        self._class_name = value
        return self

    def package(self, value: str) -> Selector:
        """Match package name."""
        self._package = value
        return self

    def description(self, value: str) -> Selector:
        """Match content description."""
        self._description = value
        return self

    def description_contains(self, value: str) -> Selector:
        """Match content description containing *value*."""
        self._description_contains = value
        return self

    def clickable(self, value: bool = True) -> Selector:
        """Match clickable state."""
        self._clickable = value
        return self

    def enabled(self, value: bool = True) -> Selector:
        """Match enabled state."""
        self._enabled = value
        return self

    def scrollable(self, value: bool = True) -> Selector:
        """Match scrollable state."""
        self._scrollable = value
        return self

    def checkable(self, value: bool = True) -> Selector:
        """Match checkable state."""
        self._checkable = value
        return self

    def checked(self, value: bool = True) -> Selector:
        """Match checked state."""
        self._checked = value
        return self

    def focusable(self, value: bool = True) -> Selector:
        """Match focusable state."""
        self._focusable = value
        return self

    def focused(self, value: bool = True) -> Selector:
        """Match focused state."""
        self._focused = value
        return self

    def long_clickable(self, value: bool = True) -> Selector:
        """Match long-clickable state."""
        self._long_clickable = value
        return self

    def selected(self, value: bool = True) -> Selector:
        """Match selected state."""
        self._selected = value
        return self

    def index(self, value: int) -> Selector:
        """Match node index."""
        self._index = value
        return self

    def child(self, selector: Selector) -> Selector:
        """Require a child matching *selector*."""
        self._child = selector
        return self

    def sibling(self, selector: Selector) -> Selector:
        """Require a sibling matching *selector* (stored for reference)."""
        self._sibling = selector
        return self

    # ---- Core matching ----

    def matches(self, node: UINode) -> bool:
        """Return True if *node* satisfies all selector criteria."""
        if self._text is not None and node.text != self._text:
            return False
        if self._text_contains is not None and self._text_contains not in node.text:
            return False
        if self._text_starts_with is not None and not node.text.startswith(
            self._text_starts_with
        ):
            return False
        if self._resource_id is not None and node.resource_id != self._resource_id:
            return False
        if (
            self._resource_id_contains is not None
            and self._resource_id_contains not in node.resource_id
        ):
            return False
        if self._class_name is not None and node.class_name != self._class_name:
            return False
        if self._package is not None and node.package != self._package:
            return False
        if self._description is not None and node.content_desc != self._description:
            return False
        if (
            self._description_contains is not None
            and self._description_contains not in node.content_desc
        ):
            return False
        if self._clickable is not None and node.clickable != self._clickable:
            return False
        if self._enabled is not None and node.enabled != self._enabled:
            return False
        if self._scrollable is not None and node.scrollable != self._scrollable:
            return False
        if self._checkable is not None and node.checkable != self._checkable:
            return False
        if self._checked is not None and node.checked != self._checked:
            return False
        if self._focusable is not None and node.focusable != self._focusable:
            return False
        if self._focused is not None and node.focused != self._focused:
            return False
        if self._long_clickable is not None and node.long_clickable != self._long_clickable:
            return False
        if self._selected is not None and node.selected != self._selected:
            return False
        if self._index is not None and node.index != self._index:
            return False
        if self._child is not None:
            if not any(self._child.matches(c) for c in node.children):
                return False
        return True

    def describe(self) -> str:
        """Return a human-readable summary of this selector's criteria."""
        parts: list[str] = []
        if self._text is not None:
            parts.append(f"text={self._text!r}")
        if self._text_contains is not None:
            parts.append(f"text_contains={self._text_contains!r}")
        if self._text_starts_with is not None:
            parts.append(f"text_starts_with={self._text_starts_with!r}")
        if self._resource_id is not None:
            parts.append(f"resource_id={self._resource_id!r}")
        if self._resource_id_contains is not None:
            parts.append(f"resource_id_contains={self._resource_id_contains!r}")
        if self._class_name is not None:
            parts.append(f"class_name={self._class_name!r}")
        if self._package is not None:
            parts.append(f"package={self._package!r}")
        if self._description is not None:
            parts.append(f"description={self._description!r}")
        if self._description_contains is not None:
            parts.append(f"description_contains={self._description_contains!r}")
        if self._clickable is not None:
            parts.append(f"clickable={self._clickable}")
        if self._enabled is not None:
            parts.append(f"enabled={self._enabled}")
        if self._scrollable is not None:
            parts.append(f"scrollable={self._scrollable}")
        if self._checkable is not None:
            parts.append(f"checkable={self._checkable}")
        if self._checked is not None:
            parts.append(f"checked={self._checked}")
        if self._focusable is not None:
            parts.append(f"focusable={self._focusable}")
        if self._focused is not None:
            parts.append(f"focused={self._focused}")
        if self._long_clickable is not None:
            parts.append(f"long_clickable={self._long_clickable}")
        if self._selected is not None:
            parts.append(f"selected={self._selected}")
        if self._index is not None:
            parts.append(f"index={self._index}")
        if self._child is not None:
            parts.append(f"child=[{self._child.describe()}]")
        if self._sibling is not None:
            parts.append(f"sibling=[{self._sibling.describe()}]")
        return f"Selector({', '.join(parts)})" if parts else "Selector(<any>)"
