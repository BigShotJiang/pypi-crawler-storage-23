"""Template matching — pure image operations using OpenCV."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable, Coroutine
from typing import Any

from PIL import Image

from adbflow.utils.exceptions import VisionError, WaitTimeoutError
from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import MatchResult

try:
    import cv2  # type: ignore[import-not-found]
    import numpy as np  # type: ignore[import-not-found]  # noqa: F401

    _HAS_OPENCV = True
except ImportError:
    _HAS_OPENCV = False


def _require_opencv() -> None:
    if not _HAS_OPENCV:
        raise VisionError(
            "opencv-python not installed. Install with: pip install adbflow[vision]"
        )


def _pil_to_cv(image: Image.Image) -> Any:
    """Convert PIL Image to OpenCV BGR numpy array."""
    import numpy as np  # noqa: F811  # type: ignore[import-not-found]

    rgb = image.convert("RGB")
    arr: Any = np.array(rgb)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


class TemplateMatcher:
    """Pure image template matching using OpenCV.

    All methods are synchronous and have no ADB dependency.
    """

    def match(
        self,
        screenshot: Image.Image,
        template: Image.Image,
        threshold: float = 0.8,
    ) -> MatchResult | None:
        """Find the best match of *template* in *screenshot*.

        Args:
            screenshot: The full screenshot image.
            template: The template image to search for.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            A ``MatchResult`` if found above threshold, else ``None``.
        """
        _require_opencv()

        sc = _pil_to_cv(screenshot)
        tp = _pil_to_cv(template)

        result: Any = cv2.matchTemplate(sc, tp, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)

        if max_val < threshold:
            return None

        h, w = tp.shape[:2]
        left, top = int(max_loc[0]), int(max_loc[1])
        rect = Rect(left=left, top=top, right=left + w, bottom=top + h)
        return MatchResult(
            location=rect,
            confidence=float(max_val),
            center=rect.center,
        )

    def match_all(
        self,
        screenshot: Image.Image,
        template: Image.Image,
        threshold: float = 0.8,
    ) -> list[MatchResult]:
        """Find all matches of *template* in *screenshot* above *threshold*.

        Uses non-maximum suppression to avoid overlapping results.

        Args:
            screenshot: The full screenshot image.
            template: The template image to search for.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            List of ``MatchResult`` objects.
        """
        _require_opencv()
        import numpy as np  # noqa: F811  # type: ignore[import-not-found]

        sc = _pil_to_cv(screenshot)
        tp = _pil_to_cv(template)

        result: Any = cv2.matchTemplate(sc, tp, cv2.TM_CCOEFF_NORMED)
        locations: Any = np.where(result >= threshold)

        h, w = tp.shape[:2]
        matches: list[MatchResult] = []
        used: list[Rect] = []

        for pt_y, pt_x in zip(locations[0], locations[1]):
            left, top = int(pt_x), int(pt_y)
            rect = Rect(left=left, top=top, right=left + w, bottom=top + h)

            # Non-max suppression: skip if overlapping an existing match
            if any(rect.intersects(u) for u in used):
                continue
            used.append(rect)

            conf = float(result[pt_y, pt_x])
            matches.append(
                MatchResult(location=rect, confidence=conf, center=rect.center)
            )

        return matches

    def match_color(
        self,
        screenshot: Image.Image,
        color_rgb: tuple[int, int, int],
        tolerance: int = 20,
        region: Rect | None = None,
    ) -> list[Point]:
        """Find pixels matching a specific color.

        Args:
            screenshot: The screenshot image.
            color_rgb: Target color as ``(R, G, B)``.
            tolerance: Maximum per-channel difference.
            region: Optional region to search within.

        Returns:
            List of ``Point`` coordinates matching the color.
        """
        _require_opencv()
        import numpy as np  # noqa: F811  # type: ignore[import-not-found]

        img = screenshot.convert("RGB")
        if region is not None:
            img = img.crop((region.left, region.top, region.right, region.bottom))

        arr: Any = np.array(img)
        target = np.array(color_rgb, dtype=np.int16)
        diff: Any = np.abs(arr.astype(np.int16) - target)
        mask: Any = np.all(diff <= tolerance, axis=2)
        ys, xs = np.where(mask)

        offset_x = region.left if region else 0
        offset_y = region.top if region else 0

        return [Point(x=int(x) + offset_x, y=int(y) + offset_y) for y, x in zip(ys, xs)]

    async def wait_for_template(
        self,
        get_screenshot: Callable[[], Coroutine[Any, Any, Image.Image]],
        template: Image.Image,
        timeout: float = 10.0,
        interval: float = 0.5,
        threshold: float = 0.8,
    ) -> MatchResult:
        """Poll screenshots until *template* is found.

        Args:
            get_screenshot: Async callable returning a PIL Image.
            template: The template image to search for.
            timeout: Maximum wait time in seconds.
            interval: Polling interval in seconds.
            threshold: Minimum confidence.

        Returns:
            The ``MatchResult`` when found.

        Raises:
            WaitTimeoutError: If template not found within *timeout*.
        """
        start = time.monotonic()
        while True:
            screenshot = await get_screenshot()
            result = self.match(screenshot, template, threshold)
            if result is not None:
                return result
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise WaitTimeoutError(
                    timeout=timeout,
                    condition_name="template match",
                    elapsed=elapsed,
                )
            await asyncio.sleep(min(interval, timeout - elapsed))
