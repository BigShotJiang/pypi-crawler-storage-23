"""Vision manager — ADB-integrated template matching and color detection."""

from __future__ import annotations

from PIL import Image

from adbflow.utils.exceptions import VisionError
from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import MatchResult, TransportProtocol
from adbflow.vision.template import TemplateMatcher


class VisionManager:
    """High-level vision operations integrated with ADB screenshots.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport
        self._matcher = TemplateMatcher()

    async def _capture_pil(self) -> Image.Image:
        """Capture a screenshot and return a PIL Image."""
        import io

        result = await self._transport.execute(
            ["exec-out", "screencap", "-p"], serial=self._serial,
        )
        result.raise_on_error("screencap")
        return Image.open(io.BytesIO(result.stdout))

    def _load_template(self, template: str | Image.Image) -> Image.Image:
        """Load a template from path or return as-is if already an Image."""
        if isinstance(template, str):
            return Image.open(template)
        return template

    async def find_on_screen_async(
        self,
        template: str | Image.Image,
        threshold: float = 0.8,
    ) -> MatchResult | None:
        """Find a template on the current screen.

        Args:
            template: Path to template image or PIL Image.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            A ``MatchResult`` if found, else ``None``.
        """
        screenshot = await self._capture_pil()
        tpl = self._load_template(template)
        return self._matcher.match(screenshot, tpl, threshold)

    async def find_all_on_screen_async(
        self,
        template: str | Image.Image,
        threshold: float = 0.8,
    ) -> list[MatchResult]:
        """Find all occurrences of a template on the current screen.

        Args:
            template: Path to template image or PIL Image.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            List of ``MatchResult`` objects.
        """
        screenshot = await self._capture_pil()
        tpl = self._load_template(template)
        return self._matcher.match_all(screenshot, tpl, threshold)

    async def tap_template_async(
        self,
        template: str | Image.Image,
        threshold: float = 0.8,
    ) -> MatchResult:
        """Find a template and tap its center.

        Args:
            template: Path to template image or PIL Image.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            The ``MatchResult`` that was tapped.

        Raises:
            VisionError: If template not found on screen.
        """
        result = await self.find_on_screen_async(template, threshold)
        if result is None:
            raise VisionError("Template not found on screen")
        await self._transport.execute_shell(
            f"input tap {result.center.x} {result.center.y}",
            serial=self._serial,
        )
        return result

    async def wait_and_tap_async(
        self,
        template: str | Image.Image,
        timeout: float = 10.0,
        threshold: float = 0.8,
    ) -> MatchResult:
        """Wait for a template to appear, then tap it.

        Args:
            template: Path to template image or PIL Image.
            timeout: Maximum wait time in seconds.
            threshold: Minimum confidence (0.0–1.0).

        Returns:
            The ``MatchResult`` that was tapped.

        Raises:
            WaitTimeoutError: If template not found within *timeout*.
        """
        tpl = self._load_template(template)
        result = await self._matcher.wait_for_template(
            self._capture_pil, tpl, timeout=timeout, threshold=threshold,
        )
        await self._transport.execute_shell(
            f"input tap {result.center.x} {result.center.y}",
            serial=self._serial,
        )
        return result

    async def find_color_async(
        self,
        color_rgb: tuple[int, int, int],
        tolerance: int = 20,
        region: Rect | None = None,
    ) -> list[Point]:
        """Find pixels matching a color on the current screen.

        Args:
            color_rgb: Target color as ``(R, G, B)``.
            tolerance: Maximum per-channel difference.
            region: Optional region to search within.

        Returns:
            List of ``Point`` coordinates matching the color.
        """
        screenshot = await self._capture_pil()
        return self._matcher.match_color(screenshot, color_rgb, tolerance, region)
