"""App management — install, uninstall, start, stop, and more."""

from __future__ import annotations

import re
from functools import cached_property

from adbflow.apps.intent import Intent
from adbflow.apps.permissions import AppPermissions
from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import InstallError, PackageNotFoundError
from adbflow.utils.parsers import parse_dumpsys_package, parse_pm_list_packages, parse_pm_path
from adbflow.utils.types import (
    InstallFlag,
    PackageFilter,
    PackageInfo,
    ProgressCallback,
)


class AppManager:
    """Manages applications on a connected device.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    @cached_property
    def permissions(self) -> AppPermissions:
        """Permission manager for this device."""
        return AppPermissions(self._serial, self._transport)

    async def install_async(
        self,
        apk_path: str,
        flags: list[InstallFlag] | None = None,
        progress: ProgressCallback | None = None,
    ) -> None:
        """Install an APK on the device.

        Args:
            apk_path: Local path to the APK file.
            flags: Optional install flags.
            progress: Optional progress callback ``(transferred, total)``.

        Raises:
            InstallError: If installation fails.
        """
        if progress:
            progress(0, 1)
        args = ["install"]
        if flags:
            args.extend(f.value for f in flags)
        args.append(apk_path)
        result = await self._transport.execute(args, serial=self._serial)
        if not result.success or "Failure" in result.output:
            raise InstallError(apk_path, result.output or result.error)
        if progress:
            progress(1, 1)

    async def install_multiple_async(
        self,
        apk_paths: list[str],
        flags: list[InstallFlag] | None = None,
    ) -> None:
        """Install a split APK (multiple APK files).

        Args:
            apk_paths: Local paths to the APK files.
            flags: Optional install flags.

        Raises:
            InstallError: If installation fails.
        """
        args = ["install-multiple"]
        if flags:
            args.extend(f.value for f in flags)
        args.extend(apk_paths)
        result = await self._transport.execute(args, serial=self._serial)
        if not result.success or "Failure" in result.output:
            raise InstallError(", ".join(apk_paths), result.output or result.error)

    async def uninstall_async(self, package: str, keep_data: bool = False) -> None:
        """Uninstall a package.

        Args:
            package: Package name.
            keep_data: Keep the app data and cache directories.
        """
        args = ["uninstall"]
        if keep_data:
            args.append("-k")
        args.append(package)
        result = await self._transport.execute(args, serial=self._serial)
        result.raise_on_error(f"uninstall {package}")

    async def list_async(self, filter: PackageFilter = PackageFilter.ALL) -> list[str]:
        """List installed packages.

        Args:
            filter: Package filter (ALL, SYSTEM, THIRD_PARTY, etc.).

        Returns:
            List of package names.
        """
        cmd = "pm list packages"
        if filter.value:
            cmd += f" {filter.value}"
        result = await self._transport.execute_shell(cmd, serial=self._serial)
        result.raise_on_error(cmd)
        return parse_pm_list_packages(result.output)

    async def info_async(self, package: str) -> PackageInfo | None:
        """Get information about an installed package.

        Args:
            package: Package name.

        Returns:
            PackageInfo or None if not found.
        """
        result = await self._transport.execute_shell(
            f"dumpsys package {package}", serial=self._serial,
        )
        if not result.success:
            return None
        return parse_dumpsys_package(result.output, package)

    async def is_installed_async(self, package: str) -> bool:
        """Check whether a package is installed.

        Args:
            package: Package name.
        """
        result = await self._transport.execute_shell(
            f"pm path {package}", serial=self._serial,
        )
        return result.success and result.output.startswith("package:")

    async def start_async(self, package: str, activity: str | None = None) -> None:
        """Start an app.

        Args:
            package: Package name.
            activity: Specific activity to launch. If None, uses monkey to launch.
        """
        if activity:
            cmd = f"am start -n {package}/{activity}"
        else:
            cmd = (
                f"monkey -p {package} -c android.intent.category.LAUNCHER 1"
            )
        result = await self._transport.execute_shell(cmd, serial=self._serial)
        result.raise_on_error(f"start {package}")

    async def stop_async(self, package: str) -> None:
        """Force-stop an app.

        Args:
            package: Package name.
        """
        result = await self._transport.execute_shell(
            f"am force-stop {package}", serial=self._serial,
        )
        result.raise_on_error(f"stop {package}")

    async def clear_data_async(self, package: str) -> None:
        """Clear app data and cache.

        Args:
            package: Package name.
        """
        result = await self._transport.execute_shell(
            f"pm clear {package}", serial=self._serial,
        )
        result.raise_on_error(f"clear {package}")

    async def current_async(self) -> str | None:
        """Get the currently focused app package name.

        Returns:
            Package name or None if not determinable.
        """
        result = await self._transport.execute_shell(
            "dumpsys activity activities"
            " | grep -E 'mResumedActivity|topResumedActivity|ResumedActivity'",
            serial=self._serial,
        )
        if not result.success:
            return None
        # Pattern: "ActivityRecord{... com.example/.Activity ...}"
        m = re.search(r"(\S+)/\S+", result.output)
        if m:
            pkg = m.group(1)
            # Strip everything before the package name
            if " " in pkg:
                pkg = pkg.rsplit(" ", 1)[-1]
            return pkg
        return None

    async def extract_async(self, package: str, output_path: str) -> None:
        """Extract an installed APK to the local filesystem.

        Args:
            package: Package name.
            output_path: Local path to save the APK.

        Raises:
            PackageNotFoundError: If the package is not installed.
        """
        result = await self._transport.execute_shell(
            f"pm path {package}", serial=self._serial,
        )
        apk_path = parse_pm_path(result.output)
        if not apk_path:
            raise PackageNotFoundError(package)
        pull_result = await self._transport.execute(
            ["pull", apk_path, output_path], serial=self._serial,
        )
        pull_result.raise_on_error(f"pull {apk_path}")

    async def broadcast_async(self, intent: Intent) -> str:
        """Send a broadcast.

        Args:
            intent: Intent to broadcast.

        Returns:
            Command output.
        """
        args = ["am", "broadcast"] + intent.build_am_args()
        result = await self._transport.execute_shell(
            " ".join(args), serial=self._serial,
        )
        result.raise_on_error("am broadcast")
        return result.output

    async def start_activity_async(self, intent: Intent) -> None:
        """Start an activity with an explicit intent.

        Args:
            intent: Intent describing the activity to start.
        """
        args = ["am", "start"] + intent.build_am_args()
        result = await self._transport.execute_shell(
            " ".join(args), serial=self._serial,
        )
        result.raise_on_error("am start")

    async def start_service_async(self, intent: Intent) -> None:
        """Start a service with an explicit intent.

        Args:
            intent: Intent describing the service to start.
        """
        args = ["am", "startservice"] + intent.build_am_args()
        result = await self._transport.execute_shell(
            " ".join(args), serial=self._serial,
        )
        result.raise_on_error("am startservice")
