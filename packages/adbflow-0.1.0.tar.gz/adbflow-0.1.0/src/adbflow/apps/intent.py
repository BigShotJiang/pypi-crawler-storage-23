"""Android Intent builder — no transport dependency."""

from __future__ import annotations

from adbflow.utils.types import IntentFlag


class Intent:
    """Fluent builder for Android Intent ``am`` arguments.

    Usage::

        intent = (
            Intent("android.intent.action.VIEW")
            .data("https://example.com")
            .category("android.intent.category.BROWSABLE")
            .flags(IntentFlag.FLAG_ACTIVITY_NEW_TASK)
            .build_am_args()
        )
    """

    def __init__(self, action: str | None = None) -> None:
        self._action = action
        self._data: str | None = None
        self._mime_type: str | None = None
        self._category: str | None = None
        self._component: str | None = None
        self._extras_string: list[tuple[str, str]] = []
        self._extras_int: list[tuple[str, int]] = []
        self._extras_bool: list[tuple[str, bool]] = []
        self._extras_float: list[tuple[str, float]] = []
        self._flags: int = 0

    def action(self, action: str) -> Intent:
        """Set the intent action.

        Args:
            action: Intent action string (e.g. ``android.intent.action.VIEW``).
        """
        self._action = action
        return self

    def data(self, uri: str) -> Intent:
        """Set the intent data URI.

        Args:
            uri: Data URI string.
        """
        self._data = uri
        return self

    def mime_type(self, mime: str) -> Intent:
        """Set the MIME type.

        Args:
            mime: MIME type string (e.g. ``text/plain``).
        """
        self._mime_type = mime
        return self

    def category(self, cat: str) -> Intent:
        """Set the intent category.

        Args:
            cat: Category string.
        """
        self._category = cat
        return self

    def component(self, comp: str) -> Intent:
        """Set the component (package/activity).

        Args:
            comp: Component string (e.g. ``com.example/.MainActivity``).
        """
        self._component = comp
        return self

    def extra_string(self, key: str, value: str) -> Intent:
        """Add a string extra.

        Args:
            key: Extra key.
            value: String value.
        """
        self._extras_string.append((key, value))
        return self

    def extra_int(self, key: str, value: int) -> Intent:
        """Add an integer extra.

        Args:
            key: Extra key.
            value: Integer value.
        """
        self._extras_int.append((key, value))
        return self

    def extra_bool(self, key: str, value: bool) -> Intent:
        """Add a boolean extra.

        Args:
            key: Extra key.
            value: Boolean value.
        """
        self._extras_bool.append((key, value))
        return self

    def extra_float(self, key: str, value: float) -> Intent:
        """Add a float extra.

        Args:
            key: Extra key.
            value: Float value.
        """
        self._extras_float.append((key, value))
        return self

    def flags(self, *flags: IntentFlag | int) -> Intent:
        """Set intent flags.

        Args:
            flags: One or more IntentFlag values or raw integers to OR together.
        """
        for flag in flags:
            self._flags |= int(flag)
        return self

    def build_am_args(self) -> list[str]:
        """Build the argument list for ``am start`` / ``am broadcast``.

        Returns:
            List of arguments (e.g. ``["-a", "android.intent.action.VIEW", ...]``).
        """
        args: list[str] = []

        if self._action:
            args.extend(["-a", self._action])
        if self._data:
            args.extend(["-d", self._data])
        if self._mime_type:
            args.extend(["-t", self._mime_type])
        if self._category:
            args.extend(["-c", self._category])
        if self._component:
            args.extend(["-n", self._component])

        for key, str_val in self._extras_string:
            args.extend(["--es", key, str_val])
        for key, int_val in self._extras_int:
            args.extend(["--ei", key, str(int_val)])
        for key, bool_val in self._extras_bool:
            args.extend(["--ez", key, str(bool_val).lower()])
        for key, float_val in self._extras_float:
            args.extend(["--ef", key, str(float_val)])

        if self._flags:
            args.extend(["-f", str(self._flags)])

        return args
