"""App permission management."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_pm_list_permissions
from adbflow.utils.types import PermissionInfo


class AppPermissions:
    """Manages runtime permissions for an app.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def list_async(self, package: str) -> list[PermissionInfo]:
        """List runtime permissions for a package.

        Args:
            package: Package name.

        Returns:
            List of PermissionInfo entries.
        """
        result = await self._transport.execute_shell(
            f"dumpsys package {package} | grep 'android.permission'",
            serial=self._serial,
        )
        if not result.success:
            return []
        return parse_pm_list_permissions(result.output)

    async def grant_async(self, package: str, permission: str) -> None:
        """Grant a runtime permission.

        Args:
            package: Package name.
            permission: Permission string (e.g. ``android.permission.CAMERA``).
        """
        result = await self._transport.execute_shell(
            f"pm grant {package} {permission}", serial=self._serial,
        )
        result.raise_on_error(f"pm grant {package} {permission}")

    async def revoke_async(self, package: str, permission: str) -> None:
        """Revoke a runtime permission.

        Args:
            package: Package name.
            permission: Permission string.
        """
        result = await self._transport.execute_shell(
            f"pm revoke {package} {permission}", serial=self._serial,
        )
        result.raise_on_error(f"pm revoke {package} {permission}")

    async def is_granted_async(self, package: str, permission: str) -> bool:
        """Check whether a permission is granted.

        Args:
            package: Package name.
            permission: Permission string.

        Returns:
            True if the permission is granted.
        """
        result = await self._transport.execute_shell(
            f"dumpsys package {package} | grep '{permission}'",
            serial=self._serial,
        )
        return "granted=true" in result.output
