"""App management module."""

from adbflow.apps.intent import Intent
from adbflow.apps.manager import AppManager
from adbflow.apps.permissions import AppPermissions

__all__ = ["AppManager", "Intent", "AppPermissions"]
