"""CLI entry point — ``adbflow`` command."""

from __future__ import annotations

import argparse
import asyncio
import sys

from adbflow.core.adb import ADB
from adbflow.recorder.player import ActionPlayer
from adbflow.recorder.recorder import ActionRecorder


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="adbflow",
        description="ADBFlow — Android device automation CLI",
    )
    sub = parser.add_subparsers(dest="command")

    # devices
    sub.add_parser("devices", help="List connected devices")

    # shell
    shell_p = sub.add_parser("shell", help="Run a shell command")
    shell_p.add_argument("serial", help="Device serial")
    shell_p.add_argument("cmd", nargs=argparse.REMAINDER, help="Shell command")

    # screenshot
    ss_p = sub.add_parser("screenshot", help="Capture a screenshot")
    ss_p.add_argument("serial", help="Device serial")
    ss_p.add_argument("output", help="Output file path")

    # install
    inst_p = sub.add_parser("install", help="Install an APK")
    inst_p.add_argument("serial", help="Device serial")
    inst_p.add_argument("apk", help="Path to APK file")

    # info
    info_p = sub.add_parser("info", help="Show device info")
    info_p.add_argument("serial", help="Device serial")

    # logcat
    log_p = sub.add_parser("logcat", help="Stream logcat")
    log_p.add_argument("serial", help="Device serial")
    log_p.add_argument("--tag", default=None, help="Filter by tag")
    log_p.add_argument("--level", default=None, help="Minimum log level")

    # record
    rec_p = sub.add_parser("record", help="Record actions (interactive)")
    rec_p.add_argument("serial", help="Device serial")
    rec_p.add_argument("output", help="Output JSON file path")

    # play
    play_p = sub.add_parser("play", help="Replay recorded actions")
    play_p.add_argument("serial", help="Device serial")
    play_p.add_argument("input", help="Input JSON file path")
    play_p.add_argument("--speed", type=float, default=1.0, help="Playback speed multiplier")

    return parser


async def _run_devices() -> None:
    adb = ADB()
    devices = await adb.devices_async()
    if not devices:
        print("No devices connected.")
        return
    for entry in devices:
        model = f" (model={entry.model})" if entry.model else ""
        print(f"{entry.serial}\t{entry.state.value}{model}")


async def _run_shell(serial: str, cmd: list[str]) -> None:
    adb = ADB()
    device = adb.device(serial)
    output = await device.shell_async(" ".join(cmd))
    print(output)


async def _run_screenshot(serial: str, output: str) -> None:
    adb = ADB()
    device = adb.device(serial)
    data = await device.screenshot_async()
    with open(output, "wb") as f:
        f.write(data)
    print(f"Screenshot saved to {output}")


async def _run_install(serial: str, apk: str) -> None:
    adb = ADB()
    device = adb.device(serial)
    await device.apps.install_async(apk)
    print(f"Installed {apk}")


async def _run_info(serial: str) -> None:
    adb = ADB()
    device = adb.device(serial)
    model = await device.info.model_async()
    android_ver = await device.info.android_version_async()
    sdk = await device.info.sdk_level_async()
    print(f"Serial:   {serial}")
    print(f"Model:    {model}")
    print(f"Android:  {android_ver}")
    print(f"SDK:      {sdk}")


async def _run_logcat(serial: str, tag: str | None, level: str | None) -> None:
    adb = ADB()
    device = adb.device(serial)
    cmd = "logcat -v threadtime"
    if tag and level:
        cmd += f" {tag}:{level} *:S"
    elif tag:
        cmd += f" {tag}:V *:S"
    elif level:
        cmd += f" *:{level}"
    output = await device.shell_async(cmd)
    print(output)


async def _run_play(serial: str, input_path: str, speed: float) -> None:
    adb = ADB()
    device = adb.device(serial)
    recorder = ActionRecorder.load(input_path)
    player = ActionPlayer(serial, device.transport)
    print(f"Playing {len(recorder.actions)} actions at {speed}x speed...")
    await player.play_async(recorder.actions, speed=speed)
    print("Playback complete.")


def app() -> None:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "devices":
        asyncio.run(_run_devices())
    elif args.command == "shell":
        asyncio.run(_run_shell(args.serial, args.cmd))
    elif args.command == "screenshot":
        asyncio.run(_run_screenshot(args.serial, args.output))
    elif args.command == "install":
        asyncio.run(_run_install(args.serial, args.apk))
    elif args.command == "info":
        asyncio.run(_run_info(args.serial))
    elif args.command == "logcat":
        asyncio.run(_run_logcat(args.serial, args.tag, args.level))
    elif args.command == "record":
        print("Interactive recording is not yet implemented.")
        print(f"Output would be saved to: {args.output}")
    elif args.command == "play":
        asyncio.run(_run_play(args.serial, getattr(args, "input"), args.speed))
    else:
        parser.print_help()
        sys.exit(1)
