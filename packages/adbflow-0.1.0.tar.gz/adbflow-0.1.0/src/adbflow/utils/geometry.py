"""Geometry primitives: Point and Rect."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class Point:
    """An (x, y) coordinate on screen."""

    x: int
    y: int

    def offset(self, dx: int, dy: int) -> Point:
        """Return a new Point offset by (dx, dy)."""
        return Point(self.x + dx, self.y + dy)

    def scale(self, factor: float) -> Point:
        """Return a new Point scaled by *factor*."""
        return Point(int(self.x * factor), int(self.y * factor))

    def distance_to(self, other: Point) -> float:
        """Euclidean distance to *other*."""
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def __add__(self, other: object) -> Point:
        if isinstance(other, Point):
            return Point(self.x + other.x, self.y + other.y)
        return NotImplemented

    def __sub__(self, other: object) -> Point:
        if isinstance(other, Point):
            return Point(self.x - other.x, self.y - other.y)
        return NotImplemented


@dataclass(frozen=True)
class Rect:
    """An axis-aligned rectangle defined by (left, top, right, bottom)."""

    left: int
    top: int
    right: int
    bottom: int

    def __post_init__(self) -> None:
        if self.right < self.left:
            raise ValueError(
                f"right ({self.right}) must be >= left ({self.left})"
            )
        if self.bottom < self.top:
            raise ValueError(
                f"bottom ({self.bottom}) must be >= top ({self.top})"
            )

    @property
    def center(self) -> Point:
        """Center point of the rectangle."""
        return Point((self.left + self.right) // 2, (self.top + self.bottom) // 2)

    @property
    def width(self) -> int:
        """Width of the rectangle."""
        return self.right - self.left

    @property
    def height(self) -> int:
        """Height of the rectangle."""
        return self.bottom - self.top

    @property
    def area(self) -> int:
        """Area of the rectangle."""
        return self.width * self.height

    def contains(self, point: Point) -> bool:
        """Check if the rectangle contains *point*."""
        return self.left <= point.x <= self.right and self.top <= point.y <= self.bottom

    def intersects(self, other: Rect) -> bool:
        """Check if this rectangle intersects with *other*."""
        return not (
            self.right < other.left
            or other.right < self.left
            or self.bottom < other.top
            or other.bottom < self.top
        )

    def intersection(self, other: Rect) -> Rect | None:
        """Return the intersection rectangle, or None if no overlap."""
        if not self.intersects(other):
            return None
        return Rect(
            left=max(self.left, other.left),
            top=max(self.top, other.top),
            right=min(self.right, other.right),
            bottom=min(self.bottom, other.bottom),
        )

    def offset(self, dx: int, dy: int) -> Rect:
        """Return a new Rect offset by (dx, dy)."""
        return Rect(self.left + dx, self.top + dy, self.right + dx, self.bottom + dy)

    def scale(self, factor: float) -> Rect:
        """Return a new Rect scaled by *factor*."""
        return Rect(
            int(self.left * factor),
            int(self.top * factor),
            int(self.right * factor),
            int(self.bottom * factor),
        )

    @classmethod
    def from_ltwh(cls, left: int, top: int, width: int, height: int) -> Rect:
        """Create a Rect from left, top, width, height."""
        return cls(left, top, left + width, top + height)

    @classmethod
    def from_center(cls, center: Point, width: int, height: int) -> Rect:
        """Create a Rect centered on *center* with given dimensions."""
        half_w = width // 2
        half_h = height // 2
        return cls(
            center.x - half_w,
            center.y - half_h,
            center.x - half_w + width,
            center.y - half_h + height,
        )
