"""Image utility helpers (requires Pillow)."""

from __future__ import annotations

import io
from pathlib import Path

from PIL import Image

from adbflow.utils.geometry import Rect


def decode_png(data: bytes) -> Image.Image:
    """Decode raw PNG bytes into a PIL Image."""
    return Image.open(io.BytesIO(data))


def crop_image(image: Image.Image, rect: Rect) -> Image.Image:
    """Crop *image* to the given *rect*."""
    return image.crop((rect.left, rect.top, rect.right, rect.bottom))


def compare_images(img_a: Image.Image, img_b: Image.Image) -> float:
    """Return pixel similarity ratio (0.0 to 1.0) between two same-size images.

    Images must have the same dimensions.
    """
    if img_a.size != img_b.size:
        raise ValueError(
            f"Image size mismatch: {img_a.size} vs {img_b.size}"
        )

    pixels_a = list(img_a.convert("RGB").getdata())
    pixels_b = list(img_b.convert("RGB").getdata())
    total = len(pixels_a)
    if total == 0:
        return 1.0

    matching = sum(1 for a, b in zip(pixels_a, pixels_b) if a == b)
    return matching / total


def save_image(image: Image.Image, path: str | Path, fmt: str = "PNG") -> None:
    """Save a PIL Image to *path*."""
    image.save(str(path), format=fmt)


def image_to_bytes(image: Image.Image, fmt: str = "PNG") -> bytes:
    """Convert a PIL Image to raw bytes."""
    buf = io.BytesIO()
    image.save(buf, format=fmt)
    return buf.getvalue()
