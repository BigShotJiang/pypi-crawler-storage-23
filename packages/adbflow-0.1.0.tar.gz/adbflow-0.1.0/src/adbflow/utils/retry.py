"""Async retry decorator with exponential backoff."""

from __future__ import annotations

import asyncio
import functools
import random
from collections.abc import Awaitable, Callable
from typing import Any, ParamSpec, TypeVar

from adbflow.utils.exceptions import ADBFlowError

P = ParamSpec("P")
T = TypeVar("T")

OnRetryCallback = Callable[[int, Exception, float], Any]


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    jitter: float = 0.5,
    exceptions: tuple[type[Exception], ...] = (ADBFlowError,),
    on_retry: OnRetryCallback | None = None,
) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, Awaitable[T]]]:
    """Retry decorator for async functions with exponential backoff.

    Args:
        max_attempts: Maximum number of attempts (including the first).
        delay: Initial delay in seconds between retries.
        backoff: Multiplier applied to delay after each attempt.
        jitter: Maximum random jitter added to delay (0 to disable).
        exceptions: Tuple of exception types to retry on.
        on_retry: Optional callback(attempt, exception, next_delay).
    """

    def decorator(func: Callable[P, Awaitable[T]]) -> Callable[P, Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            return await retry_call(
                func,
                args=args,
                kwargs=kwargs,
                max_attempts=max_attempts,
                delay=delay,
                backoff=backoff,
                jitter=jitter,
                exceptions=exceptions,
                on_retry=on_retry,
            )

        return wrapper

    return decorator


async def retry_call(
    func: Callable[..., Awaitable[T]],
    args: tuple[Any, ...] = (),
    kwargs: dict[str, Any] | None = None,
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    jitter: float = 0.5,
    exceptions: tuple[type[Exception], ...] = (ADBFlowError,),
    on_retry: OnRetryCallback | None = None,
) -> T:
    """Imperative retry interface for async callables.

    Args:
        func: Async callable to retry.
        args: Positional arguments.
        kwargs: Keyword arguments.
        max_attempts: Maximum number of attempts.
        delay: Initial delay between retries.
        backoff: Multiplier for delay after each attempt.
        jitter: Maximum random jitter added to delay.
        exceptions: Exception types to retry on.
        on_retry: Optional callback(attempt, exception, next_delay).
    """
    if kwargs is None:
        kwargs = {}

    current_delay = delay
    last_exc: Exception | None = None

    for attempt in range(1, max_attempts + 1):
        try:
            return await func(*args, **kwargs)
        except exceptions as exc:
            last_exc = exc
            if attempt == max_attempts:
                break

            actual_delay = current_delay + random.uniform(0, jitter)
            if on_retry is not None:
                on_retry(attempt, exc, actual_delay)

            await asyncio.sleep(actual_delay)
            current_delay *= backoff

    assert last_exc is not None  # noqa: S101
    raise last_exc
