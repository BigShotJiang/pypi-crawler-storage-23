"""ADB command builder."""

from __future__ import annotations

import re
import shlex

from adbflow.utils.exceptions import CommandBuildError


def escape_shell_arg(arg: str) -> str:
    """Escape a string for use in an Android shell command.

    Uses single-quote wrapping with special handling for existing single quotes.
    """
    if not arg:
        return "''"
    # If clean alphanumeric/safe chars, no escaping needed
    if re.match(r"^[a-zA-Z0-9._/=@:,-]+$", arg):
        return arg
    # Replace ' with '\'' (end quote, escaped quote, start quote)
    return "'" + arg.replace("'", "'\\''") + "'"


class ADBCommand:
    """Builder for ADB command lines.

    Usage::

        cmd = (
            ADBCommand()
            .serial("emulator-5554")
            .args("install", "-r")
            .flag("-t")
            .build()
        )
        # => ["adb", "-s", "emulator-5554", "install", "-r", "-t"]
    """

    def __init__(self, adb_path: str = "adb") -> None:
        self._adb_path = adb_path
        self._serial: str | None = None
        self._args: list[str] = []
        self._shell_cmd: str | None = None

    def serial(self, serial: str) -> ADBCommand:
        """Set the target device serial."""
        self._serial = serial
        return self

    def args(self, *args: str) -> ADBCommand:
        """Append positional arguments."""
        self._args.extend(args)
        return self

    def flag(self, flag: str) -> ADBCommand:
        """Append a flag argument."""
        self._args.append(flag)
        return self

    def shell(self, command: str) -> ADBCommand:
        """Set a shell command to execute on the device."""
        self._shell_cmd = command
        return self

    def build(self) -> list[str]:
        """Build the final command as a list of strings.

        Raises:
            CommandBuildError: If the command configuration is invalid.
        """
        if self._shell_cmd is not None and self._args:
            raise CommandBuildError(
                "Cannot combine .args() with .shell() — use one or the other"
            )

        parts: list[str] = [self._adb_path]

        if self._serial:
            parts.extend(["-s", self._serial])

        if self._shell_cmd is not None:
            parts.append("shell")
            parts.extend(shlex.split(self._shell_cmd))
        else:
            parts.extend(self._args)

        return parts

    def build_shell_string(self) -> str:
        """Build the command as a single shell string."""
        return shlex.join(self.build())
