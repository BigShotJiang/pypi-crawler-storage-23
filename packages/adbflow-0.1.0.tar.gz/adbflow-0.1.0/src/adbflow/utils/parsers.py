"""Pure-function parsers for ADB command output."""

from __future__ import annotations

import re

from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import (
    AccessibilityService,
    BatteryInfo,
    DeviceListEntry,
    DeviceState,
    FileInfo,
    ForwardRule,
    LogEntry,
    LogLevel,
    Notification,
    PackageInfo,
    PermissionInfo,
    Size,
    WifiInfo,
)


def parse_device_list(output: str) -> list[DeviceListEntry]:
    """Parse output of ``adb devices -l``.

    Example line::

        emulator-5554  device product:sdk model:sdk_phone transport_id:1
    """
    entries: list[DeviceListEntry] = []
    for line in output.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("List of devices"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue

        serial = parts[0]
        state_str = parts[1]
        try:
            state = DeviceState(state_str)
        except ValueError:
            state = DeviceState.OFFLINE

        props: dict[str, str] = {}
        for part in parts[2:]:
            if ":" in part:
                key, _, val = part.partition(":")
                props[key] = val

        entries.append(
            DeviceListEntry(
                serial=serial,
                state=state,
                model=props.get("model", ""),
                device=props.get("device", ""),
                transport_id=props.get("transport_id", ""),
            )
        )
    return entries


def parse_getprop(output: str) -> dict[str, str]:
    """Parse output of ``adb shell getprop``.

    Lines look like: ``[ro.build.display.id]: [ABC123]``
    """
    props: dict[str, str] = {}
    pattern = re.compile(r"^\[(.+?)\]:\s*\[(.*)?\]$")
    for line in output.strip().splitlines():
        m = pattern.match(line.strip())
        if m:
            props[m.group(1)] = m.group(2) or ""
    return props


def parse_dumpsys_battery(output: str) -> BatteryInfo | None:
    """Parse output of ``adb shell dumpsys battery``."""
    data: dict[str, str] = {}
    for line in output.strip().splitlines():
        line = line.strip()
        if ":" in line:
            key, _, val = line.partition(":")
            data[key.strip().lower()] = val.strip()

    try:
        level = int(data.get("level", "0"))
    except ValueError:
        level = 0

    powered = any(
        data.get(k, "false").lower() == "true"
        for k in ("ac powered", "usb powered", "wireless powered")
    )

    status = data.get("status", "unknown")
    try:
        temp = float(data.get("temperature", "0")) / 10.0
    except ValueError:
        temp = 0.0

    return BatteryInfo(level=level, powered=powered, status=status, temperature=temp)


def parse_screen_size(output: str) -> Size | None:
    """Parse output of ``adb shell wm size``.

    Expected: ``Physical size: 1080x1920``
    """
    m = re.search(r"(\d+)x(\d+)", output)
    if m:
        return Size(width=int(m.group(1)), height=int(m.group(2)))
    return None


def parse_screen_density(output: str) -> int | None:
    """Parse output of ``adb shell wm density``.

    Expected: ``Physical density: 480``
    """
    m = re.search(r"(\d+)", output)
    return int(m.group(1)) if m else None


def parse_pm_list_packages(output: str) -> list[str]:
    """Parse output of ``adb shell pm list packages``.

    Each line: ``package:com.example.app``
    """
    packages: list[str] = []
    for line in output.strip().splitlines():
        line = line.strip()
        if line.startswith("package:"):
            packages.append(line[8:])
    return packages


def parse_settings_value(output: str) -> str | None:
    """Parse output of ``adb shell settings get``.

    Returns None if value is ``null``.
    """
    val = output.strip()
    if not val or val == "null":
        return None
    return val


def parse_ip_address(output: str) -> str | None:
    """Parse IP from ``adb shell ip route`` or ``ifconfig`` output."""
    # Match "src <ip>" pattern from ip route
    m = re.search(r"src\s+(\d+\.\d+\.\d+\.\d+)", output)
    if m:
        return m.group(1)
    # Match inet pattern from ifconfig
    m = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", output)
    if m:
        return m.group(1)
    return None


def parse_bounds_string(bounds_str: str) -> Rect | None:
    """Parse Android bounds string like ``[0,0][1080,1920]``."""
    m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str)
    if m:
        return Rect(
            left=int(m.group(1)),
            top=int(m.group(2)),
            right=int(m.group(3)),
            bottom=int(m.group(4)),
        )
    return None


def _parse_center_from_bounds(bounds_str: str) -> Point | None:
    """Get center point from a bounds string."""
    rect = parse_bounds_string(bounds_str)
    if rect:
        return rect.center
    return None


# ---------------------------------------------------------------------------
# Phase 2 parsers
# ---------------------------------------------------------------------------


def parse_ls_la(output: str) -> list[FileInfo]:
    """Parse output of ``ls -la``.

    Example line::

        -rw-r--r-- 1 root root  1234 2024-01-15 10:30 somefile.txt
        drwxr-xr-x 2 root root  4096 2024-01-15 10:30 somedir
    """
    entries: list[FileInfo] = []
    for line in output.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("total"):
            continue
        parts = line.split(None, 7)
        if len(parts) < 7:
            continue

        perms = parts[0]
        is_dir = perms.startswith("d")
        owner = parts[2]
        group = parts[3]

        try:
            size = int(parts[4])
        except ValueError:
            size = 0

        # Date may be "2024-01-15 10:30" or just "2024-01-15"
        if len(parts) == 8:
            modified = parts[5] + " " + parts[6]
            name = parts[7]
        else:
            modified = parts[5]
            name = parts[6]

        # Strip trailing link targets (e.g. "foo -> bar")
        if " -> " in name:
            name = name.split(" -> ")[0]

        entries.append(
            FileInfo(
                name=name,
                size=size,
                permissions=perms,
                modified=modified,
                is_dir=is_dir,
                owner=owner,
                group=group,
            )
        )
    return entries


def parse_stat(output: str) -> FileInfo | None:
    """Parse output of ``stat`` command.

    Expected format (busybox/toybox)::

        File: /path/to/file
        Size: 1234  Blocks: 8  IO Block: 4096  regular file
        Access: (0644/-rw-r--r--)  Uid: ( 0/ root)   Gid: ( 0/ root)
        Modify: 2024-01-15 10:30:00.000000000 +0000
    """
    if not output.strip():
        return None

    name = ""
    size = 0
    permissions = ""
    modified = ""
    is_dir = False
    owner = ""
    group = ""
    path = ""

    for line in output.strip().splitlines():
        line = line.strip()
        if line.startswith("File:"):
            path = line.split(":", 1)[1].strip().strip("'\"")
            name = path.rsplit("/", 1)[-1] if "/" in path else path
        elif line.startswith("Size:"):
            m = re.search(r"Size:\s*(\d+)", line)
            if m:
                size = int(m.group(1))
            is_dir = "directory" in line.lower()
        elif line.startswith("Access:"):
            m = re.search(r"\([\d]+/([-rwxdlsStT.]+)\)", line)
            if m:
                permissions = m.group(1)
            uid_m = re.search(r"Uid:\s*\(\s*\d+/\s*(\w+)\)", line)
            if uid_m:
                owner = uid_m.group(1)
            gid_m = re.search(r"Gid:\s*\(\s*\d+/\s*(\w+)\)", line)
            if gid_m:
                group = gid_m.group(1)
        elif line.startswith("Modify:"):
            modified = line.split(":", 1)[1].strip()

    if not name:
        return None

    return FileInfo(
        name=name,
        size=size,
        permissions=permissions,
        modified=modified,
        is_dir=is_dir,
        owner=owner,
        group=group,
        path=path,
    )


def parse_dumpsys_package(output: str, package_name: str) -> PackageInfo | None:
    """Parse output of ``dumpsys package <name>`` for package information."""
    if not output.strip():
        return None

    data: dict[str, str] = {}
    for line in output.strip().splitlines():
        line = line.strip()
        if "=" in line:
            key, _, val = line.partition("=")
            data[key.strip()] = val.strip()
        elif ":" in line:
            key, _, val = line.partition(":")
            data[key.strip()] = val.strip()

    version_code = data.get("versionCode", "").split()[0] if data.get("versionCode") else ""
    version_name = data.get("versionName", "")
    install_time = data.get("firstInstallTime", "")
    update_time = data.get("lastUpdateTime", "")
    apk_path = data.get("codePath", "")

    is_system = "SYSTEM" in data.get("pkgFlags", "") or "system" in data.get("flags", "")

    enabled_str = data.get("enabled", "0")
    is_enabled = enabled_str not in ("2", "3", "4")  # DISABLED states

    return PackageInfo(
        package_name=package_name,
        version_code=version_code,
        version_name=version_name,
        install_time=install_time,
        update_time=update_time,
        apk_path=apk_path,
        is_system=is_system,
        is_enabled=is_enabled,
    )


def parse_pm_list_permissions(output: str) -> list[PermissionInfo]:
    """Parse output of runtime permissions dump for a package.

    Expects lines like::

        android.permission.CAMERA: granted=true
        android.permission.READ_CONTACTS: granted=false
    """
    permissions: list[PermissionInfo] = []
    for line in output.strip().splitlines():
        line = line.strip()
        # Pattern: "permission_name: granted=true/false"
        m = re.match(r"([\w.]+):\s*granted=(true|false)", line)
        if m:
            permissions.append(
                PermissionInfo(name=m.group(1), granted=m.group(2) == "true")
            )
    return permissions


def parse_pm_path(output: str) -> str | None:
    """Parse output of ``pm path <package>``.

    Expected: ``package:/data/app/com.example-1/base.apk``
    """
    for line in output.strip().splitlines():
        line = line.strip()
        if line.startswith("package:"):
            return line[8:]
    return None


_LOGCAT_PATTERN = re.compile(
    r"^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+)\s+"
    r"(\d+)\s+(\d+)\s+([VDIWEFS])\s+"
    r"(.+?)\s*:\s(.*)$"
)


def parse_logcat_line(line: str) -> LogEntry | None:
    """Parse a logcat line in threadtime format.

    Example::

        01-15 10:30:00.123  1234  5678 D MyTag   : Hello world
    """
    m = _LOGCAT_PATTERN.match(line.strip())
    if not m:
        return None

    level_str = m.group(4)
    try:
        level = LogLevel(level_str)
    except ValueError:
        return None

    return LogEntry(
        timestamp=m.group(1),
        pid=m.group(2),
        tid=m.group(3),
        level=level,
        tag=m.group(5).strip(),
        message=m.group(6),
    )


def parse_forward_list(output: str) -> list[ForwardRule]:
    """Parse output of ``adb forward --list``.

    Example::

        emulator-5554 tcp:8080 tcp:80
        emulator-5554 tcp:9090 localabstract:foo
    """
    rules: list[ForwardRule] = []
    for line in output.strip().splitlines():
        parts = line.strip().split()
        if len(parts) == 3:
            rules.append(ForwardRule(serial=parts[0], local=parts[1], remote=parts[2]))
    return rules


def parse_wifi_info(output: str) -> WifiInfo | None:
    """Parse WiFi info from ``dumpsys wifi`` or ``dumpsys netstats`` output."""
    ssid = ""
    ip_address = ""
    link_speed = 0
    rssi = 0

    for line in output.strip().splitlines():
        line = line.strip()
        if "SSID:" in line and not ssid:
            m = re.search(r'SSID:\s*"?([^",]+)"?', line)
            if m:
                ssid = m.group(1).strip()
        if "mIpAddress" in line or "ip_address" in line.lower():
            m = re.search(r"(\d+\.\d+\.\d+\.\d+)", line)
            if m:
                ip_address = m.group(1)
        if "Link speed:" in line or "linkSpeed" in line:
            m = re.search(r"(\d+)", line)
            if m:
                link_speed = int(m.group(1))
        if "RSSI:" in line or "rssi" in line.lower():
            m = re.search(r"(-?\d+)", line)
            if m:
                rssi = int(m.group(1))

    if not ssid and not ip_address:
        return None

    return WifiInfo(ssid=ssid, ip_address=ip_address, link_speed=link_speed, rssi=rssi)


# ---------------------------------------------------------------------------
# Phase 4 parsers
# ---------------------------------------------------------------------------


def parse_notifications(output: str) -> list[Notification]:
    """Parse output of ``dumpsys notification --noredact``.

    Extracts notification entries with key, package, title, text, time, and tag.
    """
    notifications: list[Notification] = []
    blocks = re.split(r"(?=NotificationRecord\()", output)

    for block in blocks:
        if not block.strip().startswith("NotificationRecord("):
            continue

        key = ""
        package = ""
        title = ""
        text = ""
        posted_time = ""
        tag = ""

        # Extract key from NotificationRecord(0x... pkg=... key=...)
        key_m = re.search(r"key=(\S+)", block)
        if key_m:
            key = key_m.group(1).rstrip(")")

        pkg_m = re.search(r"pkg=(\S+)", block)
        if pkg_m:
            package = pkg_m.group(1)

        # Extract android.title and android.text from extras
        title_m = re.search(r"android\.title=(?:String\s*\()?(.*?)(?:\)|$)", block)
        if title_m:
            title = title_m.group(1).strip()

        text_m = re.search(r"android\.text=(?:String\s*\()?(.*?)(?:\)|$)", block)
        if text_m:
            text = text_m.group(1).strip()

        posted_m = re.search(r"postTime=(\d+)", block)
        if posted_m:
            posted_time = posted_m.group(1)

        tag_m = re.search(r"tag=(\S+)", block)
        if tag_m:
            tag = tag_m.group(1)

        if package:
            notifications.append(
                Notification(
                    key=key,
                    package=package,
                    title=title,
                    text=text,
                    posted_time=posted_time,
                    tag=tag,
                )
            )

    return notifications


def parse_accessibility_services(output: str) -> list[AccessibilityService]:
    """Parse output of ``dumpsys accessibility``.

    Extracts service component names, enabled status, and descriptions.
    """
    services: list[AccessibilityService] = []
    # Match Service[component] lines
    blocks = re.split(r"(?=Service\[)", output)

    for block in blocks:
        if not block.strip().startswith("Service["):
            continue

        comp_m = re.search(r"Service\[(\S+?)\]", block)
        if not comp_m:
            continue
        component = comp_m.group(1)

        enabled = "isDefault:true" in block or "mIsDefault(true)" in block
        # Also check for enabled state
        if "is enabled" in block.lower():
            enabled = True

        desc = ""
        desc_m = re.search(r"description:\s*(.+)", block, re.IGNORECASE)
        if desc_m:
            desc = desc_m.group(1).strip()

        services.append(
            AccessibilityService(component=component, enabled=enabled, description=desc)
        )

    return services
