"""OCR — text recognition."""

from adbflow.ocr.engine import OCREngine
from adbflow.ocr.manager import OCRManager

__all__ = ["OCRManager", "OCREngine"]
