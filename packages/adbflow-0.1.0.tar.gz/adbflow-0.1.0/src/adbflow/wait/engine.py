"""Wait engine — poll a condition until met or timeout."""

from __future__ import annotations

import asyncio
import time

from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.utils.types import Condition


async def wait_for(
    condition: Condition,
    timeout: float = 10.0,
    interval: float = 0.5,
) -> bool:
    """Poll *condition* every *interval* seconds until it returns True.

    Args:
        condition: A ``Condition`` (async callable with ``.name``).
        timeout: Maximum wait time in seconds.
        interval: Polling interval in seconds.

    Returns:
        ``True`` when the condition is met.

    Raises:
        WaitTimeoutError: If the condition is not met within *timeout*.
    """
    start = time.monotonic()
    while True:
        if await condition():
            return True
        elapsed = time.monotonic() - start
        if elapsed >= timeout:
            raise WaitTimeoutError(
                timeout=timeout,
                condition_name=condition.name,
                elapsed=elapsed,
            )
        await asyncio.sleep(min(interval, timeout - elapsed))
