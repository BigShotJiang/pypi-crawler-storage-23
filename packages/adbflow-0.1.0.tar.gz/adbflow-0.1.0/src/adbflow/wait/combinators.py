"""Composable condition combinators."""

from __future__ import annotations

from adbflow.utils.types import Condition


class AnyOf:
    """True when *any* sub-condition is True."""

    def __init__(self, *conditions: Condition) -> None:
        self._conditions = conditions

    @property
    def name(self) -> str:
        """Human-readable combinator name."""
        names = ", ".join(c.name for c in self._conditions)
        return f"AnyOf({names})"

    async def __call__(self) -> bool:
        for condition in self._conditions:
            if await condition():
                return True
        return False


class AllOf:
    """True when *all* sub-conditions are True."""

    def __init__(self, *conditions: Condition) -> None:
        self._conditions = conditions

    @property
    def name(self) -> str:
        """Human-readable combinator name."""
        names = ", ".join(c.name for c in self._conditions)
        return f"AllOf({names})"

    async def __call__(self) -> bool:
        for condition in self._conditions:
            if not await condition():
                return False
        return True


class Not:
    """True when the sub-condition is False."""

    def __init__(self, condition: Condition) -> None:
        self._condition = condition

    @property
    def name(self) -> str:
        """Human-readable combinator name."""
        return f"Not({self._condition.name})"

    async def __call__(self) -> bool:
        return not await self._condition()


def any_of(*conditions: Condition) -> AnyOf:
    """Factory: True when any sub-condition is True."""
    return AnyOf(*conditions)


def all_of(*conditions: Condition) -> AllOf:
    """Factory: True when all sub-conditions are True."""
    return AllOf(*conditions)


def not_(condition: Condition) -> Not:
    """Factory: True when sub-condition is False."""
    return Not(condition)
