"""Built-in wait conditions for common ADB checks."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any

from adbflow.utils.types import TransportProtocol


class _BaseCondition:
    """Base class providing a ``name`` property."""

    _name: str

    @property
    def name(self) -> str:
        """Human-readable condition name."""
        return self._name


class TextVisible(_BaseCondition):
    """True when *text* appears in the UI hierarchy dump."""

    _DUMP_PATH = "/sdcard/window_dump.xml"

    def __init__(self, text: str, serial: str, transport: TransportProtocol) -> None:
        self._text = text
        self._serial = serial
        self._transport = transport
        self._name = f"TextVisible({text!r})"

    async def __call__(self) -> bool:
        await self._transport.execute_shell(
            f"uiautomator dump {self._DUMP_PATH}",
            serial=self._serial,
        )
        result = await self._transport.execute_shell(
            f"cat {self._DUMP_PATH}",
            serial=self._serial,
        )
        await self._transport.execute_shell(
            f"rm -f {self._DUMP_PATH}",
            serial=self._serial,
        )
        return self._text in result.output


class ActivityIs(_BaseCondition):
    """True when the foreground activity matches *activity*."""

    def __init__(self, activity: str, serial: str, transport: TransportProtocol) -> None:
        self._activity = activity
        self._serial = serial
        self._transport = transport
        self._name = f"ActivityIs({activity!r})"

    async def __call__(self) -> bool:
        result = await self._transport.execute_shell(
            "dumpsys activity activities",
            serial=self._serial,
        )
        return self._activity in result.output


class ScreenOn(_BaseCondition):
    """True when the display is ON."""

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport
        self._name = "ScreenOn"

    async def __call__(self) -> bool:
        result = await self._transport.execute_shell(
            "dumpsys power",
            serial=self._serial,
        )
        output = result.output
        # Standard AOSP: "Display Power: state=ON"
        if "Display Power: state=ON" in output:
            return True
        # Samsung / other OEMs: "mWakefulness=Awake"
        if "mWakefulness=Awake" in output:
            return True
        return False


class ScreenOff(_BaseCondition):
    """True when the display is OFF."""

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport
        self._name = "ScreenOff"

    async def __call__(self) -> bool:
        result = await self._transport.execute_shell(
            "dumpsys power",
            serial=self._serial,
        )
        output = result.output
        # Standard AOSP: "Display Power: state=OFF"
        if "Display Power: state=OFF" in output:
            return True
        # Samsung / other OEMs: "mWakefulness=Asleep" or "mWakefulness=Dozing"
        if "mWakefulness=Asleep" in output or "mWakefulness=Dozing" in output:
            return True
        # If we can detect ScreenOn positively, invert it
        if "Display Power: state=ON" in output or "mWakefulness=Awake" in output:
            return False
        return False


class PackageRunning(_BaseCondition):
    """True when *package* has a running process."""

    def __init__(self, package: str, serial: str, transport: TransportProtocol) -> None:
        self._package = package
        self._serial = serial
        self._transport = transport
        self._name = f"PackageRunning({package!r})"

    async def __call__(self) -> bool:
        result = await self._transport.execute_shell(
            f"pidof {self._package}",
            serial=self._serial,
        )
        return bool(result.output.strip())


class ElementExists(_BaseCondition):
    """True when the provided async *match_fn* returns True.

    This avoids a circular import between ``wait/`` and ``ui/`` by accepting
    an arbitrary async callable instead of referencing UI types directly.
    """

    def __init__(
        self,
        description: str,
        match_fn: Callable[[], Coroutine[Any, Any, bool]],
    ) -> None:
        self._match_fn = match_fn
        self._name = f"ElementExists({description!r})"

    async def __call__(self) -> bool:
        return await self._match_fn()
