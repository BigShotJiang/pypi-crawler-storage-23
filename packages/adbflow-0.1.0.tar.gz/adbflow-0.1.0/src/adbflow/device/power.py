"""Device power controls."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.types import KeyCode, RebootMode


class DevicePower:
    """Power-related device operations: reboot, wake, sleep, lock, unlock."""

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def reboot_async(self, mode: RebootMode = RebootMode.SYSTEM) -> None:
        """Reboot the device (async).

        Args:
            mode: Reboot mode (system, recovery, bootloader, sideload).
        """
        args = ["reboot"]
        if mode.value:
            args.append(mode.value)
        result = await self._transport.execute(args, serial=self._serial)
        result.raise_on_error(["adb", "reboot", mode.value])

    async def shutdown_async(self) -> None:
        """Shut down the device (async)."""
        result = await self._transport.execute_shell(
            "reboot -p",
            serial=self._serial,
        )
        result.raise_on_error("reboot -p")

    async def wake_async(self) -> None:
        """Wake the device screen (async)."""
        await self._transport.execute_shell(
            f"input keyevent {KeyCode.WAKEUP}",
            serial=self._serial,
        )

    async def sleep_async(self) -> None:
        """Put the device screen to sleep (async)."""
        await self._transport.execute_shell(
            f"input keyevent {KeyCode.SLEEP}",
            serial=self._serial,
        )

    async def lock_async(self) -> None:
        """Lock the device (async)."""
        if await self.is_screen_on_async():
            await self.sleep_async()

    async def unlock_async(self) -> None:
        """Unlock the device with a basic swipe (async).

        This performs WAKEUP + MENU, which unlocks devices without a PIN/pattern.
        For secured devices, additional steps are needed.
        """
        await self.wake_async()
        await self._transport.execute_shell(
            f"input keyevent {KeyCode.MENU}",
            serial=self._serial,
        )

    async def is_screen_on_async(self) -> bool:
        """Check if the screen is on (async)."""
        result = await self._transport.execute_shell(
            "dumpsys power",
            serial=self._serial,
        )
        output = result.output
        # Standard AOSP: "Display Power: state=ON"
        if "Display Power: state=ON" in output:
            return True
        # Samsung / other OEMs: "mWakefulness=Awake"
        if "mWakefulness=Awake" in output:
            return True
        return False
