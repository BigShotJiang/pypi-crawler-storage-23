"""Input Method Editor (IME) management."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport


class InputMethodManager:
    """Manage input method editors on the device."""

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def list_async(self) -> list[str]:
        """List installed IMEs (async)."""
        result = await self._transport.execute_shell(
            "ime list -s",
            serial=self._serial,
        )
        return [
            line.strip()
            for line in result.output.strip().splitlines()
            if line.strip()
        ]

    async def current_async(self) -> str | None:
        """Get the currently active IME (async)."""
        result = await self._transport.execute_shell(
            "settings get secure default_input_method",
            serial=self._serial,
        )
        val = result.output.strip()
        if not val or val == "null":
            return None
        return val

    async def set_async(self, ime_id: str) -> None:
        """Set the active IME (async).

        Args:
            ime_id: Full IME identifier (e.g. ``com.android.inputmethod.latin/.LatinIME``).
        """
        result = await self._transport.execute_shell(
            f"ime set {ime_id}",
            serial=self._serial,
        )
        result.raise_on_error(f"ime set {ime_id}")

    async def reset_async(self) -> None:
        """Reset IME to default (async)."""
        result = await self._transport.execute_shell(
            "ime reset",
            serial=self._serial,
        )
        result.raise_on_error("ime reset")
