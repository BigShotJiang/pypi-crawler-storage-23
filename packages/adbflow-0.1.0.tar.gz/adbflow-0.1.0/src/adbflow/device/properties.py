"""Device property (getprop/setprop) wrapper."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_getprop


class DeviceProperties:
    """Read and write Android system properties via ``getprop``/``setprop``."""

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport
        self._cache: dict[str, str] | None = None

    async def get_async(self, name: str) -> str | None:
        """Get a single property value (async).

        Returns None if the property doesn't exist.
        """
        result = await self._transport.execute_shell(
            f"getprop {name}",
            serial=self._serial,
        )
        val = result.output.strip()
        if not val:
            return None
        return val

    async def get_all_async(self, *, refresh: bool = False) -> dict[str, str]:
        """Get all device properties (async).

        Results are cached; pass ``refresh=True`` to force re-fetch.
        """
        if self._cache is None or refresh:
            result = await self._transport.execute_shell(
                "getprop",
                serial=self._serial,
            )
            self._cache = parse_getprop(result.output)
        return dict(self._cache)

    async def set_async(self, name: str, value: str) -> None:
        """Set a device property (async).

        Requires root on most devices.
        """
        result = await self._transport.execute_shell(
            f"setprop {name} {value}",
            serial=self._serial,
        )
        result.raise_on_error(f"setprop {name} {value}")
        # Invalidate cache
        self._cache = None

    def invalidate_cache(self) -> None:
        """Clear the property cache."""
        self._cache = None
