"""Logcat streaming, filtering, and crash detection."""

from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncIterator

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_logcat_line
from adbflow.utils.types import (
    AsyncCrashCallback,
    CrashCallback,
    CrashInfo,
    LogEntry,
    LogLevel,
)


class LogcatManager:
    """Manages logcat streaming, capture, and crash detection.

    Uses ``transport.stream_lines()`` for real-time log streaming.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def stream_async(
        self,
        tags: list[str] | None = None,
        level: LogLevel | None = None,
        pid: int | None = None,
        pattern: str | None = None,
        since: str | None = None,
    ) -> AsyncIterator[LogEntry]:
        """Stream logcat entries in real time.

        Args:
            tags: Filter by specific tags (e.g. ``["MyApp", "System"]``).
            level: Minimum log level.
            pid: Filter by process ID.
            pattern: Regex pattern to match against the message.
            since: Timestamp to start from (e.g. ``"01-15 10:30:00.000"``).

        Yields:
            Parsed LogEntry objects.
        """
        args = ["logcat", "-v", "threadtime"]
        if since:
            args.extend(["-T", since])
        if tags:
            # Format: "Tag:level *:S" — show only specified tags
            level_char = level.value if level else "V"
            tag_specs = [f"{tag}:{level_char}" for tag in tags]
            tag_specs.append("*:S")
            args.extend(tag_specs)
        elif level:
            args.extend(["*:" + level.value])

        compiled_pattern = re.compile(pattern) if pattern else None

        async for line in self._transport.stream_lines(args, serial=self._serial):
            entry = parse_logcat_line(line)
            if entry is None:
                continue
            if pid is not None and entry.pid != str(pid):
                continue
            if compiled_pattern and not compiled_pattern.search(entry.message):
                continue
            yield entry

    async def capture_async(
        self,
        output_path: str,
        duration: float | None = None,
        count: int | None = None,
        tags: list[str] | None = None,
        level: LogLevel | None = None,
    ) -> None:
        """Capture logcat output to a file.

        Args:
            output_path: Local file path to write logs.
            duration: Capture duration in seconds (None = until count reached).
            count: Maximum number of entries to capture.
            tags: Filter by specific tags.
            level: Minimum log level.
        """
        captured = 0
        with open(output_path, "w") as f:
            async for entry in self.stream_async(tags=tags, level=level):
                line = (
                    f"{entry.timestamp} {entry.pid} {entry.tid} "
                    f"{entry.level.value} {entry.tag}: {entry.message}\n"
                )
                f.write(line)
                captured += 1
                if count is not None and captured >= count:
                    break
                if duration is not None:
                    # Duration-based capture: rely on caller to cancel or use timeout
                    pass

    async def clear_async(self) -> None:
        """Clear the logcat buffer."""
        result = await self._transport.execute_shell(
            "logcat -c", serial=self._serial,
        )
        result.raise_on_error("logcat -c")

    async def crash_detect_async(
        self,
        callback: CrashCallback | AsyncCrashCallback,
        packages: list[str] | None = None,
    ) -> asyncio.Task[None]:
        """Start a background task that watches for crashes.

        Monitors logcat for ``FATAL EXCEPTION`` entries and invokes the callback
        when a crash is detected.

        Args:
            callback: Function called with CrashInfo when a crash is detected.
            packages: Optional list of package names to filter (None = all).

        Returns:
            The background asyncio.Task (cancel to stop watching).
        """

        async def _watch() -> None:
            crash_lines: list[str] = []
            in_crash = False
            crash_pkg = ""
            crash_pid = ""
            crash_timestamp = ""

            async for entry in self.stream_async(level=LogLevel.ERROR):
                if "FATAL EXCEPTION" in entry.message:
                    in_crash = True
                    crash_lines = [entry.message]
                    crash_pid = entry.pid
                    crash_timestamp = entry.timestamp
                    # Try to extract package from the tag or message
                    crash_pkg = entry.tag
                elif in_crash:
                    crash_lines.append(entry.message)
                    # Process: or package name often appears in crash trace
                    if "Process:" in entry.message:
                        m = re.search(r"Process:\s*(\S+)", entry.message)
                        if m:
                            crash_pkg = m.group(1)

                    # End of crash block — blank line or new non-crash entry
                    if not entry.message.strip() or (
                        entry.pid != crash_pid and "at " not in entry.message
                    ):
                        in_crash = False
                        if packages and crash_pkg not in packages:
                            continue

                        info = CrashInfo(
                            package=crash_pkg,
                            pid=crash_pid,
                            signal="",
                            stacktrace="\n".join(crash_lines),
                            timestamp=crash_timestamp,
                        )

                        result = callback(info)
                        if asyncio.iscoroutine(result):
                            await result

        task: asyncio.Task[None] = asyncio.create_task(_watch())
        return task
