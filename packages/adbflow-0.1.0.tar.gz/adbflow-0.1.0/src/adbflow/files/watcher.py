"""File system watcher using polling."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_ls_la
from adbflow.utils.types import FileChange, FileChangeType, FileInfo


class FileWatcher:
    """Watches a directory on the device for file changes by polling.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def watch_async(
        self, path: str, interval: float = 2.0,
    ) -> AsyncIterator[FileChange]:
        """Watch a directory for changes.

        Polls ``ls -la`` at the given interval and yields changes when detected.

        Args:
            path: Directory path on device.
            interval: Polling interval in seconds.

        Yields:
            FileChange objects for created, modified, and deleted files.
        """
        previous: dict[str, FileInfo] = {}

        # Initial snapshot
        result = await self._transport.execute_shell(
            f"ls -la {path}", serial=self._serial,
        )
        if result.success:
            for info in parse_ls_la(result.output):
                previous[info.name] = info

        while True:
            await asyncio.sleep(interval)

            result = await self._transport.execute_shell(
                f"ls -la {path}", serial=self._serial,
            )
            if not result.success:
                continue

            current: dict[str, FileInfo] = {}
            for info in parse_ls_la(result.output):
                current[info.name] = info

            # Detect created and modified files
            for name, info in current.items():
                if name not in previous:
                    yield FileChange(
                        path=f"{path}/{name}",
                        change_type=FileChangeType.CREATED,
                        file_info=info,
                    )
                elif info != previous[name]:
                    yield FileChange(
                        path=f"{path}/{name}",
                        change_type=FileChangeType.MODIFIED,
                        file_info=info,
                    )

            # Detect deleted files
            for name in previous:
                if name not in current:
                    yield FileChange(
                        path=f"{path}/{name}",
                        change_type=FileChangeType.DELETED,
                        file_info=previous[name],
                    )

            previous = current
