"""Directory synchronization between host and device."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.types import ProgressCallback, SyncResult


class DirectorySync:
    """Syncs directories between the host machine and the device.

    Uses md5sum checksums to detect changes and only transfers modified files.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def _remote_checksums(self, remote_dir: str) -> dict[str, str]:
        """Get md5 checksums for all files in a remote directory."""
        result = await self._transport.execute_shell(
            f"find {remote_dir} -type f -exec md5sum {{}} \\;",
            serial=self._serial,
        )
        checksums: dict[str, str] = {}
        if not result.success:
            return checksums
        for line in result.output.strip().splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                md5, path = parts
                # Store path relative to remote_dir
                rel = path
                if rel.startswith(remote_dir):
                    rel = rel[len(remote_dir):].lstrip("/")
                checksums[rel] = md5
        return checksums

    async def _remote_files(self, remote_dir: str) -> set[str]:
        """List all files in a remote directory (relative paths)."""
        result = await self._transport.execute_shell(
            f"find {remote_dir} -type f",
            serial=self._serial,
        )
        files: set[str] = set()
        if not result.success:
            return files
        for line in result.output.strip().splitlines():
            path = line.strip()
            if path.startswith(remote_dir):
                path = path[len(remote_dir):].lstrip("/")
            if path:
                files.add(path)
        return files

    async def sync_async(
        self,
        local_dir: str,
        remote_dir: str,
        direction: str = "push",
        delete_extra: bool = False,
        progress: ProgressCallback | None = None,
    ) -> SyncResult:
        """Synchronize a directory between host and device.

        Uses md5sum checksums to detect changes and only transfers modified files.

        Args:
            local_dir: Local directory path.
            remote_dir: Remote directory path on device.
            direction: ``"push"`` (local→device) or ``"pull"`` (device→local).
            delete_extra: Delete files on the destination not present in the source.
            progress: Optional progress callback ``(transferred, total)``.

        Returns:
            SyncResult with counts of transferred, skipped, deleted, and errors.
        """
        transferred = 0
        skipped = 0
        deleted = 0
        errors: list[str] = []

        remote_checksums = await self._remote_checksums(remote_dir)

        if direction == "push":
            # Get local checksums
            import hashlib
            import os

            local_dir = local_dir.rstrip("/")
            local_files: dict[str, str] = {}
            for root, _dirs, filenames in os.walk(local_dir):
                for fname in filenames:
                    full = os.path.join(root, fname)
                    rel = os.path.relpath(full, local_dir)
                    with open(full, "rb") as f:
                        local_files[rel] = hashlib.md5(f.read()).hexdigest()  # noqa: S324

            total = len(local_files)
            done = 0

            for rel_path, local_md5 in local_files.items():
                if progress:
                    progress(done, total)
                remote_path = f"{remote_dir}/{rel_path}"
                if remote_checksums.get(rel_path) == local_md5:
                    skipped += 1
                else:
                    # Ensure parent directory exists
                    parent = remote_path.rsplit("/", 1)[0]
                    await self._transport.execute_shell(
                        f"mkdir -p {parent}", serial=self._serial,
                    )
                    result = await self._transport.execute(
                        ["push", os.path.join(local_dir, rel_path), remote_path],
                        serial=self._serial,
                    )
                    if result.success:
                        transferred += 1
                    else:
                        errors.append(f"push {rel_path}: {result.error}")
                done += 1

            if delete_extra:
                for rel_path in remote_checksums:
                    if rel_path not in local_files:
                        result = await self._transport.execute_shell(
                            f"rm {remote_dir}/{rel_path}", serial=self._serial,
                        )
                        if result.success:
                            deleted += 1

            if progress:
                progress(total, total)

        else:  # pull
            import os

            local_dir = local_dir.rstrip("/")
            remote_files = await self._remote_files(remote_dir)
            total = len(remote_files)
            done = 0

            for rel_path in remote_files:
                if progress:
                    progress(done, total)
                local_path = os.path.join(local_dir, rel_path)
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                result = await self._transport.execute(
                    ["pull", f"{remote_dir}/{rel_path}", local_path],
                    serial=self._serial,
                )
                if result.success:
                    transferred += 1
                else:
                    errors.append(f"pull {rel_path}: {result.error}")
                done += 1

            if progress:
                progress(total, total)

        return SyncResult(
            transferred=transferred, skipped=skipped, deleted=deleted, errors=errors,
        )
