# ai-mcp-model-switcher tools module
"""
MCP tools for model switching and querying.
MCP工具：模型切换和查询。
"""

# Tool definitions are in submodules
# Each tool exports:
# - tool_schema: The MCP Tool definition
# - handle: The async handler function
