"""Continuity request helpers."""
