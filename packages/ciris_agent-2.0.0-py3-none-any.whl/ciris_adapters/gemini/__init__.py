"""
Gemini Adapter - Converted from CIRIS adapter: gemini

Gemini CLI for one-shot Q&A, summaries, and generation.

Original source: /home/emoore/clawdbot_lessons/clawdbot/skills/gemini/SKILL.md
"""

from .adapter import GeminiAdapter
from .service import GeminiToolService

# Export as Adapter for load_adapter() compatibility
Adapter = GeminiAdapter

__all__ = [
    "Adapter",
    "GeminiAdapter",
    "GeminiToolService",
]
