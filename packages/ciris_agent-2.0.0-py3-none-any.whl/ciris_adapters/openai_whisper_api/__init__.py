"""
OpenaiWhisperApi Adapter - Converted from CIRIS adapter: openai-whisper-api

Transcribe audio via OpenAI Audio Transcriptions API (Whisper).

Original source: /home/emoore/clawdbot_lessons/clawdbot/skills/openai-whisper-api/SKILL.md
"""

from .adapter import OpenaiWhisperApiAdapter
from .service import OpenaiWhisperApiToolService

# Export as Adapter for load_adapter() compatibility
Adapter = OpenaiWhisperApiAdapter

__all__ = [
    "Adapter",
    "OpenaiWhisperApiAdapter",
    "OpenaiWhisperApiToolService",
]
