"""API adapter package."""

from .adapter import ApiPlatform

Adapter = ApiPlatform
