"""AEX - AI Execution Kernel"""

__version__ = "2.0.0"
