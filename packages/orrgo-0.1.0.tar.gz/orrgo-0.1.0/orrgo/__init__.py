__version__ = "0.1.0"

def hello():
    return "Welcome to ORRGO"