# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Test inference with a selector agent.

This test loads a selector agent from amesa_core/tests/config and
verifies that inference works correctly with the selector and its child skills.
"""

import os

import pytest
import pytest_asyncio
from amesa_core.agent.agent import Agent

from amesa_inference import InferenceEngine


@pytest_asyncio.fixture
async def inference_engine():
    """Create an inference engine for testing."""
    os.environ["AMESA_EULA_AGREED"] = "1"
    engine = InferenceEngine(license="")
    yield engine
    await engine.close()


@pytest_asyncio.fixture
def selector_agent():
    """Load the selector agent from test config."""
    # Path to the test agent JSON file
    # From amesa_inference/tests, go up to workspace root, then to amesa_core/tests/config
    test_dir = os.path.dirname(__file__)
    # Go up from amesa_inference/tests to amesa_inference, then to workspace root, then to amesa_core/tests/config
    core_test_dir = os.path.join(
        os.path.dirname(test_dir), "..", "composabl_core", "tests", "config"
    )
    core_test_dir = os.path.abspath(core_test_dir)
    agent_path = os.path.join(core_test_dir, "test-agent.json")

    if not os.path.exists(agent_path):
        pytest.skip(
            f"Selector agent JSON not found at {agent_path}. "
            "Run test_trainer_skill_multi first to create the agent."
        )

    agent = Agent.load(agent_path)

    # Update checkpoint URI to point to the local config directory
    selector = agent.get_node_by_name("skill-selector")
    if selector is None:
        pytest.skip("Could not find selector skill in agent")

    # Set checkpoint URI to the local config directory
    selector_checkpoint_dir = os.path.join(core_test_dir, "skill-selector")
    if not os.path.exists(selector_checkpoint_dir):
        pytest.skip(
            f"Selector checkpoint directory not found at {selector_checkpoint_dir}. "
            "Run test_trainer_skill_multi first to create the checkpoint."
        )

    selector.set_checkpoint_uri(os.path.abspath(selector_checkpoint_dir))

    return agent


@pytest.mark.asyncio
async def test_load_selector_agent(mock_usb_license, inference_engine, selector_agent):
    """Test loading a selector agent."""
    await inference_engine.load_agent(selector_agent)
    assert inference_engine.agent is not None
    assert inference_engine.agent.id == selector_agent.id


@pytest.mark.asyncio
async def test_package_selector_agent(mock_usb_license, inference_engine, selector_agent):
    """Test packaging a selector agent for inference."""
    await inference_engine.load_agent(selector_agent)
    await inference_engine.package()
    assert inference_engine.skill_processor is not None


@pytest.mark.asyncio
async def test_execute_selector_inference(mock_usb_license, inference_engine, selector_agent):
    """Test executing inference on a selector agent."""
    await inference_engine.load_agent(selector_agent)
    await inference_engine.package()

    # Create a test observation matching the sensor space
    # The sensor space is a Dict with "counter" (Box with shape [1])
    obs = {"counter": [5.0]}

    # Execute inference
    action = await inference_engine.execute(obs)

    # Verify action is valid
    # The selector action space is Discrete with n=2 (for 2 children)
    # But the actual action returned will be from the selected child skill
    # which has a Dict action space with increment (Discrete), increment_box (Box), and nested_action (Dict)
    assert action is not None
    # The action should be a dict with the child skill's action structure
    assert isinstance(action, dict)
    assert "increment" in action
    assert "increment_box" in action
    assert "nested_action" in action


@pytest.mark.asyncio
async def test_execute_selector_inference_with_action_mask(mock_usb_license, inference_engine, selector_agent):
    """Test executing inference on a selector agent with action mask."""
    await inference_engine.load_agent(selector_agent)
    await inference_engine.package()

    # Create a test observation
    obs = {"counter": [3.0]}

    # Create an action mask for the selector (2 children, so mask of length 2)
    # Both actions allowed
    action_mask = [1.0, 1.0]

    # Execute inference with action mask
    action = await inference_engine.execute(obs, sim_action_mask=action_mask)

    # Verify action is valid
    assert action is not None
    assert isinstance(action, dict)
    assert "increment" in action
    assert "increment_box" in action
    assert "nested_action" in action


@pytest.mark.asyncio
async def test_execute_selector_inference_multiple_steps(mock_usb_license, inference_engine, selector_agent):
    """Test executing inference for multiple steps with selector agent."""
    await inference_engine.load_agent(selector_agent)
    await inference_engine.package()

    # Execute inference for multiple steps
    for i in range(5):
        obs = {"counter": [float(i)]}
        action = await inference_engine.execute(obs)

        # Verify action is valid for each step
        assert action is not None
        assert isinstance(action, dict)
        assert "increment" in action
        assert "increment_box" in action
        assert "nested_action" in action
