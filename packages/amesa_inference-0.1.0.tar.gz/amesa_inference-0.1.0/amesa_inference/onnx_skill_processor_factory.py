# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Factory function for creating ONNX-based skill processors.
This module provides a utility function to create the appropriate skill processor
based on the skill type, similar to make_skill_processor in amesa_train.
"""

import amesa_core.utils.logger as logger_util
from amesa_core import (
    Skill,
    SkillCoordinatedPopulation,
    SkillCoordinatedSet,
    SkillSelector,
)
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

from amesa_inference.skill_processor_base import BaseSkillProcessor

logger = logger_util.get_logger(__name__)


async def create_onnx_skill_processor(
    context: SkillProcessorContext,
) -> BaseSkillProcessor:
    """
    Create an ONNX-based skill processor based on the type of skill.

    This factory function inspects the skill type in the provided context and returns
    the appropriate ONNX skill processor implementation. It handles the abstraction
    for different skill types, allowing the calling code to work with any skill type
    without knowing the specific processor implementation.

    Supported skill types:
    - Skill: Basic skill using ONNXSkillProcessor
    - SkillSelector: Selector skill using ONNXSelectorProcessor
    - SkillCoordinatedSet: Coordinated set skills (not yet implemented)
    - SkillCoordinatedPopulation: Coordinated population skills (not yet implemented)

    Args:
        context: SkillProcessorContext containing:
            - agent: The agent instance
            - skill: The skill to create a processor for
            - network_mgr: Network manager for remote skills
            - is_training: Whether this is for training (should be False for ONNX)
            - is_validating: Whether this is for validation

    Returns:
        An initialized skill processor appropriate for the skill type.

    Raises:
        ValueError: If the skill type is not supported.
        RuntimeError: If the processor fails to initialize.

    Example:
        ```python
        from amesa_inference import create_onnx_skill_processor

        context = SkillProcessorContext(
            agent=agent,
            skill=skill,
            network_mgr=network_mgr,
            is_training=False,
        )
        processor = await create_onnx_skill_processor(context)
        action = await processor._execute(obs)
        ```
    """
    # Import processor classes here to avoid circular imports
    from amesa_inference.onnx_selector_processor import ONNXSelectorProcessor
    from amesa_inference.onnx_skill_processor import ONNXSkillProcessor

    skill_processor_cls = None
    skill = context.skill

    # Determine the appropriate processor class based on skill type
    if skill.is_controller():
        # Controller skills use ONNXSkillProcessor but may need special handling
        if isinstance(skill, SkillSelector):
            # Selector controller - use selector processor
            logger.info(
                f"Creating ONNXSelectorProcessor for selector controller: {skill.get_name()}"
            )
            skill_processor_cls = ONNXSelectorProcessor
        else:
            # Regular controller
            logger.info(
                f"Creating ONNXSkillProcessor for controller: {skill.get_name()}"
            )
            skill_processor_cls = ONNXSkillProcessor

    elif isinstance(skill, SkillSelector):
        # Selector skill with teacher - uses trained model for selection
        logger.info(
            f"Creating ONNXSelectorProcessor for selector: {skill.get_name()}"
        )
        skill_processor_cls = ONNXSelectorProcessor

    elif isinstance(skill, SkillCoordinatedSet):
        # Coordinated set skills - not yet implemented for ONNX inference
        raise NotImplementedError(
            f"ONNX inference for SkillCoordinatedSet is not yet implemented. "
            f"Skill: {skill.get_name()}"
        )

    elif isinstance(skill, SkillCoordinatedPopulation):
        # Coordinated population skills - not yet implemented for ONNX inference
        raise NotImplementedError(
            f"ONNX inference for SkillCoordinatedPopulation is not yet implemented. "
            f"Skill: {skill.get_name()}"
        )

    elif isinstance(skill, Skill):
        # Basic skill
        logger.info(
            f"Creating ONNXSkillProcessor for skill: {skill.get_name()}"
        )
        skill_processor_cls = ONNXSkillProcessor

    else:
        raise ValueError(
            f"Unsupported skill type for ONNX inference: {type(skill).__name__}. "
            f"Skill: {skill.get_name()}"
        )

    # Create and initialize the processor
    try:
        skill_processor_instance = skill_processor_cls(context)
        await skill_processor_instance.init()
        logger.info(
            f"Successfully created and initialized skill processor for: {skill.get_name()}"
        )
        return skill_processor_instance

    except Exception as e:
        logger.error(
            f"Failed to create skill processor for {skill.get_name()}: {e}"
        )

        raise RuntimeError(
            f"Failed to create ONNX skill processor for {skill.get_name()}: {e}"
        ) from e
