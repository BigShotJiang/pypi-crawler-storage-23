# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
ONNX helper utilities for amesa_inference.

This module contains utilities for working with ONNX models during inference,
including ensuring models have the correct input structure.
"""

import os
from typing import Optional

import amesa_core.utils.logger as logger_util
import onnx

logger = logger_util.get_logger(__name__)


def ensure_onnx_model_has_action_mask(
    onnx_path: str, action_space=None, skill=None
) -> bool:
    """
    Ensure an ONNX model has an action_mask input. If it doesn't, attempt to add it.

    This function is used after downloading ONNX models to ensure they have the
    action_mask input required for inference, especially for selectors.

    Args:
        onnx_path: Path to the ONNX model file
        action_space: Optional action space to determine action_mask shape
        skill: Optional skill object to get action space from

    Returns:
        True if the model was modified, False if it already had action_mask
    """
    try:
        onnx_model = onnx.load(onnx_path)

        # Check if action_mask input already exists
        input_names = [input.name for input in onnx_model.graph.input]
        has_action_mask = any("action_mask" in name.lower() for name in input_names)

        if has_action_mask:
            logger.debug(f"ONNX model at {onnx_path} already has action_mask input")
            return False

        # Determine action_mask shape
        action_mask_shape = None
        if action_space is not None:
            try:
                action_mask_space = action_space.get_action_mask_space()
                if hasattr(action_mask_space, 'shape'):
                    action_mask_shape = action_mask_space.shape
                elif hasattr(action_space, 'n'):
                    action_mask_shape = (action_space.n,)
                elif hasattr(action_space, 'shape'):
                    action_mask_shape = action_space.shape
            except Exception as e:
                logger.warning(f"Could not get action_mask shape from action_space: {e}")

        # If we have a skill, try to get action space from it
        if action_mask_shape is None and skill is not None:
            try:
                skill_action_space = skill.get_action_space()
                if skill_action_space is not None:
                    action_mask_space = skill_action_space.get_action_mask_space()
                    if hasattr(action_mask_space, 'shape'):
                        action_mask_shape = action_mask_space.shape
                    elif hasattr(skill_action_space, 'n'):
                        action_mask_shape = (skill_action_space.n,)
            except Exception as e:
                logger.warning(f"Could not get action_mask shape from skill: {e}")

        # Try to infer from action_dist_inputs output shape
        if action_mask_shape is None:
            try:
                output_names = [output.name for output in onnx_model.graph.output]
                if "action_dist_inputs" in output_names:
                    # Find the output and get its shape
                    for output in onnx_model.graph.output:
                        if output.name == "action_dist_inputs":
                            shape = [
                                dim.dim_value if dim.dim_value > 0 else 1
                                for dim in output.type.tensor_type.shape.dim
                            ]
                            if len(shape) >= 2:
                                # Shape is [batch, action_size], we want action_size
                                action_mask_shape = (shape[-1],)
                            elif len(shape) == 1:
                                action_mask_shape = (shape[0],)
                            break
            except Exception as e:
                logger.warning(f"Could not infer action_mask shape from model outputs: {e}")

        # Fallback to shape (1,)
        if action_mask_shape is None:
            logger.warning("Could not determine action_mask shape, using default (1,)")
            action_mask_shape = (1,)

        # Get observation input to determine batch dimension
        obs_input = None
        for input in onnx_model.graph.input:
            if "observation" in input.name.lower() or input.name == "observation":
                obs_input = input
                break

        if obs_input is None and len(onnx_model.graph.input) > 0:
            obs_input = onnx_model.graph.input[0]

        batch_dim = None
        if obs_input is not None:
            try:
                # Get batch dimension from observation input (usually first dimension)
                obs_shape = obs_input.type.tensor_type.shape.dim
                if len(obs_shape) > 0:
                    batch_dim = obs_shape[0]
            except Exception:
                pass

        # Create action_mask input
        # Use dynamic batch dimension if available, otherwise use 1
        if batch_dim is not None:
            action_mask_dims = [batch_dim]
        else:
            action_mask_dims = [onnx.TensorShapeProto.Dimension(dim_value=1)]

        for dim_size in action_mask_shape:
            action_mask_dims.append(onnx.TensorShapeProto.Dimension(dim_value=dim_size))

        action_mask_type = onnx.TypeProto()
        action_mask_type.tensor_type.elem_type = onnx.TensorProto.DOUBLE
        action_mask_type.tensor_type.shape.CopyFrom(onnx.TensorShapeProto(dim=action_mask_dims))

        action_mask_value_info = onnx.ValueInfoProto()
        action_mask_value_info.name = "action_mask"
        action_mask_value_info.type.CopyFrom(action_mask_type)

        # Add action_mask input to the graph
        onnx_model.graph.input.append(action_mask_value_info)

        # Validate and save
        onnx.checker.check_model(onnx_model)
        onnx.save(onnx_model, onnx_path)

        logger.info(f"Added action_mask input with shape {action_mask_shape} to ONNX model at {onnx_path}")
        return True

    except Exception as e:
        logger.error(f"Failed to ensure action_mask input in ONNX model at {onnx_path}: {e}")
        raise
