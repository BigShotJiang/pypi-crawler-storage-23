# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
InferenceNetworkMgr - NetworkMgr subclass for async-first usage.

This module provides a NetworkMgr designed for use with InferenceEngine,
which operates in async contexts. Unlike the base NetworkMgr which uses
async_to_sync() (which may case event loop conflicts in async contexts), this
class returns coroutines that callers await directly.
"""

import inspect
from typing import Callable

from amesa_core.networking.network_mgr import NetworkMgr


class InferenceNetworkMgr(NetworkMgr):
    """
    NetworkMgr subclass designed for async contexts.

    This class overrides _call_method() to return coroutines directly,
    which callers await. This avoids the event loop conflict entirely.

    Usage:
        mgr = InferenceNetworkMgr(config)
        result = await mgr.call_remote_perceptor_mgr("method", ...)
    """

    def _call_method(self, attr: Callable, *args, **kwargs):
        """
        Override base _call_method to return coroutines for async methods.

        Callers must await the result for async methods.
        """
        if inspect.iscoroutinefunction(attr):
            # Return coroutine directly - caller will await
            return attr(*args, **kwargs)
        else:
            # Sync method - call directly
            return attr(*args, **kwargs)

