# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
ONNX-based Selector Processor for inference that handles selector skills.
This processor performs selector inference, then walks the agent graph based on
selector actions and executes the appropriate child skills.
"""

import asyncio
import os
from typing import Dict, List, Optional

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util
import numpy as np
from amesa_core import SkillSelector
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.utils.space_utils import flatten_object_numpy

from amesa_inference.onnx_inference import ONNXInferenceEngine
from amesa_inference.skill_processor_base import BaseSkillProcessor

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class ONNXSelectorProcessor(BaseSkillProcessor):
    """
    ONNX-based Selector Processor for inference without PyTorch or Ray.
    Extends BaseSkillProcessor and handles selector skill inference, walking
    the agent graph based on selector actions to execute child skills.
    """

    def __init__(self, context: SkillProcessorContext) -> None:
        """
        Initialize the ONNX Selector Processor.

        Args:
            context: The context of the Skill Processor containing agent and skill info.

        Raises:
            Exception: If the skill is not a SkillSelector.
        """
        super().__init__(context)

        if not isinstance(self.context.skill, SkillSelector):
            raise Exception(
                f"ONNXSelectorProcessor must be used with a SkillSelector, "
                f"got {self.context.skill.get_name()}, {type(self.context.skill)}"
            )

        # Set the sim sensor space for all children
        for child_skill_name in self.context.skill.get_children():
            self.context.agent.get_node_by_name(child_skill_name).set_sim_sensor_space(
                self.sim_sensor_space
            )

        # Make the action space for a selector skill, based on discrete with children
        self.action_space = amesa_spaces.Discrete(
            len(self.context.skill.get_children())
        )
        self.context.skill.set_action_space(self.action_space)

        # Child skill processors (will be initialized in init())
        self.child_skill_processors: List[BaseSkillProcessor] = []

        # ONNX engine will be loaded in init()
        self.onnx_engine: Optional[ONNXInferenceEngine] = None

    async def init(self):
        """
        Initialize the selector processor and all child skill processors.
        """
        await super().init()

        # Load the ONNX model for selector inference
        # Note: Code is inlined here rather than in a separate method because
        # the @ensure_cls_is_initialized decorator wraps all methods (except __init__
        # and init) and throws an exception if called before init() completes.
        checkpoint_uri = self.context.skill.get_checkpoint_uri()
        if checkpoint_uri is None:
            logger.warning(
                f"No checkpoint URI found for skill {self.context.skill.get_name()}, "
                "cannot load ONNX model"
            )
        else:
            # Look for ONNX model file
            skill_name = self.context.skill.get_name()
            onnx_path = os.path.join(checkpoint_uri, f"{skill_name}.onnx")

            if not os.path.exists(onnx_path):
                # Try alternative path
                onnx_path = os.path.join(checkpoint_uri, f"{skill_name}", f"{skill_name}.onnx")

            if not os.path.exists(onnx_path):
                logger.warning(
                    f"ONNX model not found at {onnx_path} for skill {skill_name}"
                )
            else:
                # Ensure the ONNX model has action_mask input before loading
                try:
                    from amesa_inference.onnx_helper import ensure_onnx_model_has_action_mask

                    # Get action space from skill if available
                    action_space = None
                    try:
                        action_space = self.context.skill.get_action_space()
                    except Exception:
                        pass

                    # Ensure action_mask input exists
                    ensure_onnx_model_has_action_mask(onnx_path, action_space=action_space, skill=self.context.skill)
                except Exception as e:
                    logger.warning(f"Failed to ensure action_mask in ONNX model for selector {skill_name}: {e}")
                    # Continue anyway - the model might already be correct

                try:
                    self.onnx_engine = ONNXInferenceEngine(onnx_path)
                    logger.info(f"Loaded ONNX model for selector skill {skill_name} from {onnx_path}")
                except Exception as e:
                    logger.error(f"Failed to load ONNX model for selector skill {skill_name}: {e}")
                    raise

        # Import here to avoid circular imports
        from amesa_inference.onnx_skill_processor_factory import (
            create_onnx_skill_processor,
        )

        # Create skill processors for all children
        tasks = []
        for child_skill_name in self.context.skill.get_children():
            child_skill = self.context.agent.get_node_by_name(child_skill_name)
            child_context = SkillProcessorContext(
                agent=self.context.agent,
                skill=child_skill,
                network_mgr=self.context.network_mgr,
                is_training=False,
                is_validating=self.context.is_validating,
            )
            task = create_onnx_skill_processor(child_context)
            tasks.append(task)

        self.child_skill_processors = await asyncio.gather(*tasks)
        self._is_initialized = True

    async def reset(self):
        """Reset the selector and all child skill processors."""
        await asyncio.gather(
            *[
                child_processor.reset()
                for child_processor in self.child_skill_processors
            ]
        )
        await super().reset()

    async def _get_selector_action(
        self,
        sensors_filtered: Dict,
        sim_action_mask: Optional[np.ndarray] = None,
    ) -> int:
        """
        Get the selector action (which child skill to use) using ONNX inference.

        Args:
            sensors_filtered: Processed sensor observations.
            sim_action_mask: Optional action mask array.

        Returns:
            The index of the selected child skill.
        """
        if self.onnx_engine is None:
            raise RuntimeError(
                f"ONNX model not loaded for selector skill {self.context.skill.get_name()}"
            )

        # Get observation array
        obs = sensors_filtered["observation"]
        if isinstance(obs, dict):
            obs = np.array(list(obs.values()), dtype=np.float32)
        else:
            obs = np.array(obs, dtype=np.float32)

        # Get action mask if available
        action_mask = None
        if "action_mask" in sensors_filtered and sensors_filtered["action_mask"] is not None:
            action_mask = sensors_filtered["action_mask"]
            if isinstance(action_mask, dict):
                action_mask = flatten_object_numpy(action_mask).astype(np.float64)
            else:
                # Ensure action_mask is a numpy array with float64 dtype
                action_mask = np.asarray(action_mask, dtype=np.float64)

        # Run ONNX inference
        action_dist_inputs = self.onnx_engine.get_action_dist_inputs(obs, action_mask)

        # For selector (discrete action space): apply softmax and take argmax
        logits = action_dist_inputs[0] if action_dist_inputs.ndim > 1 else action_dist_inputs

        # Apply softmax for numerical stability
        exp_logits = np.exp(logits - np.max(logits))
        probs = exp_logits / np.sum(exp_logits)

        # Take argmax (deterministic)
        selector_action = int(np.argmax(probs))

        return selector_action

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        """
        Process the selector action and execute the selected child skill.

        Args:
            sim_sensors: Raw sensor data from the simulator.
            amesa_obs: Processed composabl observations.
            action: The selector action (child index).
            sim_action_mask: Optional action mask.
            unsquash_action: Whether to unsquash the action.

        Returns:
            Tuple of (child_action, selector_action).
        """
        # First, process selector action through parent (applies teacher transform)
        processed_selector_action = await super().process_action(
            sim_sensors,
            amesa_obs,
            action,
            sim_action_mask,
            unsquash_action=unsquash_action,
        )

        # Get the selected child processor
        selected_child_processor: BaseSkillProcessor = self.child_skill_processors[
            processed_selector_action
        ]

        # Execute the child skill to get the actual action
        child_action = await selected_child_processor._execute(
            sim_sensors,
            sim_action_mask,
            explore=False,
            is_coordinated=False,
            previous_action=None,
        )

        return child_action, processed_selector_action

    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        """
        Execute the selector processor:
        1. Process sensors
        2. Get selector action using ONNX inference
        3. Execute the selected child skill
        4. Return the child action

        Args:
            sim_sensors: Raw sensor data from the simulator.
            sim_action_mask: Optional action mask.
            explore: Whether to explore (unused for selectors).
            is_coordinated: Whether this is part of a coordinated skill.
            previous_action: Previous action taken.
            return_as_teacher_dict: Whether to return full teacher dict.

        Returns:
            The action from the selected child skill, or a teacher dict if requested.
        """
        if self.onnx_engine is None:
            raise RuntimeError(
                f"ONNX model not loaded for selector skill {self.context.skill.get_name()}"
            )

        # Process sensors using base class method
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, sim_action_mask, previous_action
        )

        # Get selector action (which child to use)
        selector_action = await self._get_selector_action(sensors_filtered, sim_action_mask)

        # Process action through teacher (may transform selector action)
        teacher_action = selector_action
        if self.teacher is not None:
            teacher_action = await self.teacher.transform_action(
                amesa_obs, selector_action
            )
            if isinstance(teacher_action, tuple):
                teacher_action = int(teacher_action[1])
            else:
                teacher_action = int(teacher_action)

        # If this is for a skill group, just return the selector action
        if self.context.for_skill_group:
            return teacher_action

        # Get the selected child processor and execute it
        selected_child_processor = self.child_skill_processors[teacher_action]
        child_action = await selected_child_processor._execute(
            sim_sensors,
            sim_action_mask,
            explore=False,
            is_coordinated=False,
            previous_action=None,
            return_as_teacher_dict=return_as_teacher_dict,
        )

        # Return the result
        if return_as_teacher_dict:
            if isinstance(child_action, dict):
                child_action["top_selector_action"] = teacher_action
                return child_action
            else:
                return {
                    "action": child_action,
                    "sensors_filtered": sensors_filtered,
                    "amesa_obs": amesa_obs,
                    "top_selector_action": teacher_action,
                }
        else:
            return child_action

    async def process_sim_sensors(
        self, obs, sim_action_mask=None, previous_action=None
    ):
        """
        Process sim sensors and compute the action mask for the selector.

        Args:
            obs: Raw observation from simulator.
            sim_action_mask: Optional sim action mask.
            previous_action: Previous action taken.

        Returns:
            Tuple of (filtered_obs, amesa_obs).
        """
        filtered_obs, amesa_obs = await super().process_sim_sensors(
            obs, sim_action_mask, previous_action
        )

        # Change the action mask according to the selector
        filtered_obs["action_mask"] = await self.compute_action_mask(
            amesa_obs, sim_action_mask, previous_action
        )

        return filtered_obs, amesa_obs

    def get_skill_name(self):
        """Get the skill name."""
        return self.context.skill.get_name()

    def get_action_space(self):
        """Get the action space."""
        return self.context.skill.get_action_space()

    def get_child_skill_processors(self) -> List[BaseSkillProcessor]:
        """Get all child skill processors."""
        return self.child_skill_processors

    def get_child_processor_by_index(self, index: int) -> Optional[BaseSkillProcessor]:
        """Get a child processor by index."""
        if 0 <= index < len(self.child_skill_processors):
            return self.child_skill_processors[index]
        return None

    def get_child_processor_by_name(self, name: str) -> Optional[BaseSkillProcessor]:
        """Get a child processor by skill name."""
        for processor in self.child_skill_processors:
            if processor.get_skill_name() == name:
                return processor
        return None
