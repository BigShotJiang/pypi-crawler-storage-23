# -*- coding: utf-8 -*-
from typing import List, Generic
from ddans.common.type import T


class Stack(Generic[T]):

    def __init__(self):
        """
        初始化一个空栈。
        """
        self.stack: List[T] = []

    def push(self, item: T) -> None:
        """
        将一个元素压入栈中。

        :param item: 要压入栈的元素
        """
        self.stack.append(item)

    def pop(self) -> T:
        """
        移除并返回栈顶元素。
        如果栈为空，则抛出 IndexError。

        :return: 栈顶元素
        :raises IndexError: 如果栈为空
        """
        if not self.is_empty():
            return self.stack.pop()
        else:
            raise IndexError("从空栈中弹出元素")

    def peek(self) -> T:
        """
        返回栈顶元素但不移除它。
        如果栈为空，则抛出 IndexError。

        :return: 栈顶元素
        :raises IndexError: 如果栈为空
        """
        if not self.is_empty():
            return self.stack[-1]
        else:
            raise IndexError("从空栈中窥视元素")

    def is_empty(self) -> bool:
        """
        检查栈是否为空。

        :return: 如果栈为空则返回 True，否则返回 False
        """
        return len(self.stack) == 0

    def size(self) -> int:
        """
        返回栈中元素的数量。

        :return: 栈中元素的数量
        """
        return len(self.stack)

    def clear(self) -> None:
        """
        移除栈中所有元素。
        """
        self.stack.clear()

    def __repr__(self) -> str:
        """
        返回栈的字符串表示。

        :return: 栈的字符串表示
        """
        return f"Stack({self.stack})"
