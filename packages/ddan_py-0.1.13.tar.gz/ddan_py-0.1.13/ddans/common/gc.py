# -*- coding: utf-8 -*-

import gc
import threading


class DGc:
    def __init__(self) -> None:
        self.timer = None
        pass

    def collect(self):
        gc.collect()  # 执行垃圾回收并等待结束
        return self

    def periodic_gc(self, interval):
        self.collect()

        # 使用定时器再次调度下一次垃圾回收
        self.timer = threading.Timer(interval, self.periodic_gc, [interval])
        self.timer.start()
        return self

    def close(self):
        if self.timer and self.timer.is_alive:
            self.timer.cancel()
