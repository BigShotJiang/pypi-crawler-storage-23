# -*- coding: utf-8 -*-

import re


# @dataclass
class Regex:
    version = r'^\d+.\d+.\d+$'
    number = r'^(0|[1-9]\d*)$'
    ip = r'^\d+.\d+.\d+.\d+$'
    # re.findall(r'(\w+)=(\w+)', 'set width=20 and height=10nihao')
    # pattern: str | re.Pattern[str] = None,

    intl = re.compile(r'intl\.t\(\s*([`"\'])([\s\S]*?)\1\s*(?:,|\))',
                      re.DOTALL)

    # 正则表达式模式，用于移除注释
    comment = re.compile(r'//.*?$|/\*[\s\S]*?\*/', re.MULTILINE)

    # 正则表达式模式，用于检查是否包含中文字符
    chinese = re.compile(r'[\u4e00-\u9fff]')

    bracketContent = re.compile(r'(\{.*?\})')

    git_date = re.compile(
        r'^\w{3} \w{3} \d{2} \d{2}:\d{2}:\d{2} \d{4} [+-]\d{4}$')

    gmt_date = re.compile(
        r'^[A-Za-z]{3}, \d{2} [A-Za-z]{3} \d{4} \d{2}:\d{2}:\d{2} GMT$')

    addrport = re.compile(r':\/\/([^:]+):(\d+)')

    id18 = re.compile(r'^\d{18}$')

    re_number = re.compile(number)

    @staticmethod
    def pattern(pattern: str):
        return f"{pattern}"
