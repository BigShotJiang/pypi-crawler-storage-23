# -*- coding: utf-8 -*-
import base64
import brotli

from ddans.native.log import NLog


class NBrotli:

    @staticmethod
    def compress(content: str):
        result = ""
        try:
            comporessed = brotli.compress(content.encode('utf-8'))
            result = str(base64.b64encode(comporessed), encoding='utf-8')
        except Exception as e:
            NLog.error(f'brotli compress failed! {e}')
        finally:
            return result

    @staticmethod
    def decompress(comporessed_content: str):
        result = ""
        try:
            comporessed = base64.b64decode(comporessed_content)
            decomporessed = brotli.decompress(comporessed)
            result = decomporessed.decode('utf-8')
        except Exception as e:
            NLog.error(f'brotli compress failed! {e}')
        finally:
            return result
