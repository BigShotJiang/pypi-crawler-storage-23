# -*- coding: utf-8 -*-
from datetime import datetime, timedelta, timezone
import time
from ddans.domain.regex import Regex

# import pytz
# target_timezone = pytz.timezone('Asia/Shanghai')

# from datetime import timezone;

# # 设置为 UTC 时区
# utc_time = utc_time.replace(tzinfo=timezone.utc)

# # 将 UTC 时间转换为东八区时间
# cn_time = utc_time.astimezone(timezone(timedelta(hours=8)))


class NTime():
    MINUTE_S = 60
    HOUR_S = MINUTE_S * 60
    DAY_S = HOUR_S * 24

    # time_str = dt_time.strftime('%Y/%#m/%d')
    # print(time_str)  # 2020/6/17
    @staticmethod
    def format(t: int | float | str | datetime = None,
               format="%Y-%m-%d %H:%M:%S"):

        if isinstance(t, (int | float | str)):
            _dateTime = NTime.time(t)
        elif isinstance(t, datetime):
            _dateTime = t
        else:
            _dateTime = NTime.now()
        if _dateTime is None:
            return ""

        return _dateTime.strftime(format)

    @staticmethod
    def now():
        return datetime.now()

    @staticmethod
    def today():
        return NTime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    @staticmethod
    def timestamp(dtime: datetime = None, delta: timedelta = None):
        # print(time.time())
        if not isinstance(dtime, datetime):
            return int(time.time())
        if isinstance(delta, timedelta):
            dtime += delta
        return int(dtime.timestamp())

    @staticmethod
    def get_time(time_str: str, format: str = '%Y-%m-%d %H:%M:%S'):
        return datetime.strptime(time_str, format)

    @staticmethod
    def time(t: int | float | str):
        """
        时间戳转时间

        参数:
        t: timestamp: 时间戳 | 时间格式 2024-05-17T18:46:37

        返回值:
        datetime: 时间
        """
        try:
            if isinstance(t, str):
                if len(t) > 0:
                    # 判断字符串是否符合模式
                    if Regex.git_date.search(t):
                        return datetime.strptime(t, '%a %b %d %H:%M:%S %Y %z')
                    elif Regex.gmt_date.search(t):
                        # return datetime.strptime(t,
                        #                          '%a, %d %b %Y %H:%M:%S %Z')
                        return NTime.formatGMTime(t)
                    return datetime.fromisoformat(t)
                else:
                    return None

            if not isinstance(t, (int | float)):
                return None

            if t < 0:
                return None
            if t > 1e10:
                t = t / 1000.0
            return datetime.fromtimestamp(t)
        except Exception:
            return None

    @staticmethod
    def formatGMTime(GMTstr: str):
        return datetime.strptime(
            GMTstr, '%a, %d %b %Y %H:%M:%S %Z') + timedelta(hours=8)

    def formatUTCTime(UtcStr: str):
        if not UtcStr.strip():
            return datetime(1970, 1, 1, tzinfo=timezone.utc)
        return datetime.strptime(
            UtcStr, '%Y-%m-%dT%H:%M:%S.%fZ') + timedelta(hours=8)

    # 2026-02-06T06:19:35.000Z

    @staticmethod
    def sleep(seconds: float):
        time.sleep(seconds)
