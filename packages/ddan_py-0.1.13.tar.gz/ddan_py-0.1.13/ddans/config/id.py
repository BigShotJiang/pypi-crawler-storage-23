# -*- coding: utf-8 -*-

DDAN_ID = "36f678c8a5563d9aaad7b0dcb8d7e740"
DDAN_UUID = "36f678c8-a556-3d9a-aad7-b0dcb8d7e740"
