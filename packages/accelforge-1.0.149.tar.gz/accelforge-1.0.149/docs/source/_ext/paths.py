import os
from pathlib import Path

PROJECT_ROOT = os.path.abspath(Path(__file__).parent.parent.parent.parent)