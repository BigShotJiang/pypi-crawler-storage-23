# Git Django

a plugin for git that build out django with poetry.

