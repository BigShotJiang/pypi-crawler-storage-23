#!/usr/bin/python3
#
# requires https://github.com/profclems/glab, screen, and firefox, works in linux desktop only
# https://learndjango.com/tutorials/django-custom-user-model (finish up the base.html and signup)

import os
import shutil

# import sys
import argparse

# import time

# is a string that presents the server and group string before (no slash)
# export GITLAB_SERVER_GROUP="git@custom_ssh_string:username"

server_group = os.environ.get("GITLAB_SERVER_GROUP")
uid = os.getuid()

modules = {
    "app": {
        "dirs": ["templates/registration", "skel/templates/skel"],
        "tmpls": [
            "skel/urls.py",
            "webprj/urls.py",
        ],
        "files": [
            "templates/registration/login.html",
            "skel/admin.py",
            "skel/templates/skel/authed.html",
            "skel/templates/skel/index.html",
            "skel/models.py",
            "skel/managers.py",
            "skel/forms.py",
            "skel/views.py",
            "skel/tests.py",
        ],
    },
    "base": {
        "tmpls": [
            "webprj/settings.py",
        ],
        "files": [
            "Makefile",
            ".gitignore",
            ".flake8",
        ],
    },
    "celery": {
        "tmpls": [
            "webprj/__init__.py",
            "webprj/celery.py",
        ],
        "files": [
            "skel/tasks.py",
        ],
    },
    "deploy": {
        "dirs": [
            "postgres",
            "restore",
            "deploy",
        ],
        "tmpls": [
            "deploy/web.sh",
            "docker-compose.yml",
        ],
        "files": [
            "deploy/Dockerfile.web",
            "deploy/Dockerfile.backup",
            "deploy/web.conf",
            "deploy/worker.conf",
            "deploy/worker.sh",
            "deploy/state.sh",
        ],
    },
}


class GitDjango(object):
    remote = True
    appname = "testong"

    def read_data_from_file(self, filename):
        # Get the directory of the current module
        module_dir = os.path.dirname(__file__)
        # Construct the full path to the file
        file_path = os.path.join(module_dir, filename)

        try:
            with open(file_path, "r") as f:
                content = f.read()
                return content
        except FileNotFoundError:
            return f"Error: File '{filename}' not found in the module's directory."

    def copy_template(self, link):
        o = self.read_data_from_file("skel/" + link + ".tmpl")
        dlink = link.replace("skel", self.appname)
        with open(dlink, "w") as f:
            f.write(o.replace("skel", self.appname))
        if link[-2:] == ".sh":
            os.chmod(dlink, 0o755)

    def copy_file(self, link):
        o = self.read_data_from_file("skel/" + link)
        dlink = link.replace("skel", self.appname)
        with open(dlink, "w") as f:
            f.write(o)
        if link[-2:] == ".sh":
            os.chmod(dlink, 0o755)

    def setup_files(self):
        for k in modules:
            if "dirs" in modules[k]:
                for d in modules[k]["dirs"]:
                    s = d.replace("skel", self.appname)
                    print(s)
                    os.makedirs(s, mode=0o755)
            if "files" in modules[k]:
                for f in modules[k]["files"]:
                    self.copy_file(f)
            if "tmpls" in modules[k]:
                for t in modules[k]["tmpls"]:
                    self.copy_template(t)

    def extrafiles(self):
        with open(".env", "w") as f:
            f.write(f"""USERID={uid}
GROUPID={uid}""")
        o = """---For the backup container, be sure to change the password
---host postgres repl all scram-sha-256
---host replication repl all scram-sha-256
CREATE ROLE repl WITH LOGIN REPLICATION PASSWORD 'password123';
SELECT pg_create_physical_replication_slot('repl', true, false);
"""
        with open("deploy/repl.sql", "w") as f:
            f.write(o)

    def no_remote(self):
        self.remote = False

    def poetry_setup(self):
        os.system(f"poetry new {self.appname}")
        os.chdir(self.appname)
        os.system("""sed -i -e 's/python = .*/python = "^3.13"/g' pyproject.toml""")

    def django_setup(self):
        if os.path.exists(self.appname):
            # for older versions of poetry
            shutil.rmtree(self.appname)
        os.system(
            "poetry add django django-extensions djangorestframework celery[redis] requests uwsgi psycopg2-binary setuptools"
        )
        os.system("poetry add --group dev flake8 black pytest safety")
        os.system("poetry run django-admin startproject webprj .")
        os.system(f"poetry run django-admin startapp {self.appname}")
        with open(f"{self.appname}/__init__.py", "w") as f:
            f.write("__version__ = '0.1.0'")

    def initial_commit(self):
        os.system("git init")
        os.system("git add .")
        os.system("git commit -a -m'initial commit'")
        if self.remote:
            os.system("glab repo create")
            os.system("git remote remove origin")
            os.system(f"git remote add origin {server_group}/{self.appname}.git")
            os.system("git push -u origin master")

    def after_setup_commit(self):
        os.system("git add .")
        os.system("git commit -a -m'project is prepared now'")

    def set_appname(self, appname):
        self.appname = appname

    def load(self):
        self.poetry_setup()
        self.django_setup()
        self.setup_files()
        self.extrafiles()
        self.initial_commit()
        os.system("git versionupdater install")
        os.system("git changelog install")
        self.after_setup_commit()
        if self.remote:
            os.system("git nextrelease")
        else:
            os.system("git nextrelease --no-remote")

        print(f"cd {self.appname}")
        print("make up")
        print(
            f"docker exec -it {self.appname}-web-1 python src/manage.py makemigrations"
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("appname", help="The name of the Django App")
    parser.add_argument(
        "--no-remote",
        help="Disable remote actions like pull and push",
        action="store_true",
    )
    args = parser.parse_args()
    gd = GitDjango()
    if args.no_remote:
        gd.no_remote()
    else:
        if not server_group or len(server_group) == 0:
            print(
                """please add 'export GITLAB_SERVER_GROUP="git@custom_ssh_string:username"'"""
            )
            print("switching to no-remote, or add --no-remote next time")
            gd.no_remote()
    gd.set_appname(args.appname)
    gd.load()


if __name__ == "__main__":
    main()
