#!/bin/bash

export PATH="$PATH:$HOME/.poetry/bin/"

# get the path of where this file is.
if [ -z "$1" ]; then
   echo "missing a work id"
   exit 1
fi

worker_name=$1

# Goto where the file is located
cd $(dirname "$(readlink -f "$0")")/..
# Get site config
# . .env
# aws configure set aws_access_key_id $AWS_ACCESS_KEY
# aws configure set aws_secret_access_key $AWS_SECRET_KEY
# aws configure set default.region us-east-1
# aws configure set default.format json
celery -A webprj:celery_app worker -l INFO --pool=solo -n worker${worker_name}@%h
# poetry run celery -A webprj:celery_app worker -l INFO --pool=solo -n worker${worker_name}@%h
