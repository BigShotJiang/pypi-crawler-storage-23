from django.shortcuts import render
from django.views.generic import ListView
from .models import Widget


class WidgetListView(ListView):
    model = Widget
    template_name = "widgets/widget_list.html"
    context_object_name = "widget"


# Create your views here.
def home(request):
    return render(request, "skel/index.html")


def authed(request):
    return render(request, "skel/authed.html")
