# Copyright (c) 2025 Lakshya A Agrawal and the GEPA contributors
# https://github.com/gepa-ai/gepa

from gepa.adapters.dspy_full_program_adapter.full_program_adapter import DspyAdapter

__all__ = ["DspyAdapter"]
