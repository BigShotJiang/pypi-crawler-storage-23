import numpy as np
import healpy as hp
import time, h5py
from .healpix import triangular_tessellation_sphere
from .geometry import cartesian2barycentric, barycentric2cartesian, triangle_contains_origin_array
from sklearn.neighbors import BallTree
from bisect import bisect_left, bisect_right


def search_galaxy_images(
    simFile: str,
    gal_lon,
    gal_lat,
    k_neighbors: int = 10,
    ignore_mult_img: bool = True,
    triangle_tessellation_external = None,
    tree_external = None,
):
    """Routine for finding galaxy image position given their source positions
    in the sky and given the rays' image (theta) and source (beta) positions.

    Parameters
    ----------
    simDir : str
        Path to the ray-tracing simulation file.
    gal_lon : array-like
        Longitudes of the galaxy source (true) positions, in degrees.
    gal_lat : array-like
        Latitudes of the galaxy source (true) positions, in degrees.
    k_neighbors : str
        Numbers of neighbors to look for when doing the BallTree search.
    ignore_mult_img : bool
        Whether to ingore the cases where none, or more than one images are found,
        if True, in such cases a value of np.nan is assigned to the corresponging
        image latitude and longitude.
    triangle_tessellation_external : numpy array.
        If None, the routine "triangular_tessellation_sphere" is called to compute 
        the tessellation array. Otherwise, if such array is already computed, it can
        be given here ar as argument. This can be useful if the image search routine
        is called multiple times in the same script with a fixed Nside.
    tree_external : BallTree frmo sklearn.
        If None, the routine "BallTree" is called to compute the ball tree on the 
        source plane. Otherwise, if such object is already computed, it can
        be given here ar as argument. This can be useful if the image search routine
        is called multiple times in the same script with the same tree.

    Returns
    -------
    gal_lon_obs : list of tuples
        Longitudes of the galaxy image (observed) positions, in degrees.
        Note that a certain galaxy can have multiple ima 
    gal_lat_obs : list of tuples
        Latitudes of the galaxy image (observed) positions, in degrees.
        Note that a certain galaxy can have multiple ima 
    """
    #print_logo()
    print(f"Looking for the image position(s) of {len(gal_lon)} galaxies")
    print(f"For each galaxy, the {k_neighbors} closest rays in the image plane are considered")
    
    # Load ray positions on the source plane
    with h5py.File(simFile, "r")as f:
        beta = np.array(f["Ray_position"]["Beta"])
    
    nside = hp.npix2nside(beta.shape[1])
    theta = np.array(hp.pix2ang(nside, np.arange(beta.shape[1])))
    print(f"Loaded ray positions from:{simFile}")

    # Build tree on the source plane
    t0 = time.time()
    if tree_external is None:
        beta_lonlat = np.degrees((beta[1], np.pi / 2 - beta[0]))
        print("Computing tree on the source plane...", flush=True)
        tree = BallTree(np.deg2rad(np.stack((beta_lonlat[1], beta_lonlat[0]), axis=-1)), metric="haversine")
    else:
        print("Loading tree on the source plane...", flush=True)
        tree = tree_external
    print(f"took {round(time.time()-t0,1)} s")

    # Get triangle tessellation
    t0 = time.time()
    if triangle_tessellation_external is None:
        print("Computing triangle tessellation...", flush=True)
        triangles = (triangular_tessellation_sphere(nside, return_sorted=True))
    else:
        print("Loading triangle tessellation...", flush=True)
        triangles = triangle_tessellation_external
    print(f"took {round(time.time()-t0,1)} s")

    # Iterate over all the galaxies 
    t0 = time.time()
    print("Iterating over all the galaxies ...", flush=True)
    gal_lon_obs, gal_lat_obs = [], []
    for i in range(len(gal_lon)):
        gal_lon_true, gal_lat_true = gal_lon[i], gal_lat[i]
        if not(ignore_mult_img):
            gal_lon_obs.append([])
            gal_lat_obs.append([])

        # Query closest k rays
        ind_neighbors = tree.query(np.array([np.deg2rad((gal_lat_true, gal_lon_true))]), k=k_neighbors, return_distance=False)

        # To find the relevant triangles, we assume that the set of k closest rays found
        # contains all three vertices of the triangle(s) containing our galaxy position.
        # Therefore, given the complete list T of triangles that tessellate the sphere
        # (where the three indeces of each triangle are sorted in ascending order, and
        # the triangles are sorted by their first entry) it will be sufficient to query
        # (using binary search) all the triangles whose first index is one of the k closest
        # rays. 
        # The selected triangles will be stored in one flat array, where every three consecutive
        # elements are the vertices of the triangles. I.e. the first triangle vertices are given
        # by selected_triangles[:3], the second one's by selected_triangles[3,6] and so on..

        selected_triangles = np.zeros(0, dtype=int)

        for ind in ind_neighbors[0]:
            sel = triangles[bisect_left(triangles[:,0], ind):bisect_right(triangles[:,0], ind)]
            selected_triangles = np.hstack([selected_triangles, sel.ravel()])

        # Project the selected points on the plane tangent to the galaxy position
        proj = hp.projector.GnomonicProj(rot = (gal_lon_true, gal_lat_true, 0))
        x_beta, y_beta = proj.ang2xy(theta=beta[0][selected_triangles], phi=beta[1][selected_triangles])
        x_theta, y_theta = proj.ang2xy(theta=theta[0][selected_triangles], phi=theta[1][selected_triangles])

        select = triangle_contains_origin_array(np.vstack((x_beta[0::3], y_beta[0::3])).T, 
                                                np.vstack((x_beta[1::3], y_beta[1::3])).T, 
                                                np.vstack((x_beta[2::3], y_beta[2::3])).T)

        idx_select = np.where(select == True)[0]

        if ignore_mult_img and (len(idx_select) != 1):
            gal_lon_obs.append(np.nan)
            gal_lat_obs.append(np.nan)
            continue

        for i in idx_select:
            x_beta_select, y_beta_select = x_beta[3*i:3*i+3] , y_beta[3*i:3*i+3]
            x_theta_select, y_theta_select = x_theta[3*i:3*i+3] , y_theta[3*i:3*i+3]
            
            # compute galaxy barycenter coordinates respective to the triangle in the source plane
            gal_bar = cartesian2barycentric(np.array((x_beta_select[0], y_beta_select[0])), 
                                            np.array((x_beta_select[1], y_beta_select[1])), 
                                            np.array((x_beta_select[2], y_beta_select[2])),
                                            np.array((0, 0)))
            
            x_gal_obs, y_gal_obs = barycentric2cartesian(np.array((x_theta_select[0], y_theta_select[0])), 
                                                        np.array((x_theta_select[1], y_theta_select[1])), 
                                                        np.array((x_theta_select[2], y_theta_select[2])),
                                                        gal_bar)

            gal_obs_lonlat = proj.xy2ang(x_gal_obs, y_gal_obs, lonlat=True)
            if ignore_mult_img:
                gal_lon_obs.append(gal_obs_lonlat[0]%360)
                gal_lat_obs.append(gal_obs_lonlat[1])
            else:
                gal_lon_obs[-1].append(gal_obs_lonlat[0]%360)
                gal_lat_obs[-1].append(gal_obs_lonlat[1])
    
    print(f"took {round(time.time()-t0,1)} s")

    return gal_lon_obs, gal_lat_obs


