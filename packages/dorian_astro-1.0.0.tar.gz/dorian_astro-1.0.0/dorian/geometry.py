import numpy as np
from numpy import cos, sin


def triangle_contains_origin(a, b, c):
    """Determine if the origin is within triangle formed by points a, b, and c.
    If so, the point will be on the same side of each of the half planes
    defined by vectors ab, bc, and ca. zval is positive if outside,
    negative if inside such a plane. All should be positive or all negative
    if point is within the triangle.

    Parameters
    ----------
    a : float array with shape (2)
        Cartesian coordinates of first vertex of the triangle.
    b : float array with shape (2)
        Cartesian coordinates of second vertex of the triangle.
    c : float array with shape (2)
        Cartesian coordinates of third vertex of the triangle.

    Returns
    -------
    Bool
        Whether or not the triangle contains the origin.

    """
    zval1 = np.cross(a,b)
    zval2 = np.cross(b,c)
    zval3 = np.cross(c,a)
    notanyneg = zval1 >= 0 and zval2 >= 0 and zval3 >= 0
    notanypos = zval1 <= 0 and zval2 <= 0 and zval3 <= 0
    return notanyneg or notanypos


def triangle_contains_origin_array(a, b, c):
    """Determines which of the N triangles provided contain the origin.
    This is the array version of the fuction triangle_contains_origin.

    Parameters
    ----------
    a : float array with shape (N, 2)
        First vertices of the triangles.
    b : float array with shape (N, 2)
        Second vertices of the triangles.
    c : float array with shape (N, 2)
        Third vertices of the triangles.

    Returns
    -------
    Bool array
        Whether or not the triangle contains the origin.
    """
    zval1 = np.cross(a,b)
    zval2 = np.cross(b,c)
    zval3 = np.cross(c,a)
    notanyneg = np.logical_and(np.logical_and(zval1 >= 0, zval2 >= 0), zval3 >= 0)
    notanypos = np.logical_and(np.logical_and(zval1 <= 0, zval2 <= 0), zval3 <= 0)
    return np.logical_or(notanyneg, notanypos)


def cartesian2barycentric(a, b, c, p):
    """Computes the barycentric coordinates (u,v,w) of the point p w.r.t. 
    the triangle abc given its cartesian coordinates.

    Parameters
    ----------
    a : Float array with shape (2)
        Cartesian coordinates of first vertex of the triangle.
    b : Float array with shape (2)
        Cartesian coordinates of second vertex of the triangle.
    c : Float array with shape (2)
        Cartesian coordinates of third vertex of the triangle.
    p : Float array with shape (2)
        Cartesian coordinates of point whithin the triangle.

    Returns
    -------
    Float array with shape (3)
        Barycentric coordinates of p.
    """
    v0, v1, v2 = b-a, c-a, p-a
    d00 = np.dot(v0, v0)
    d01 = np.dot(v0, v1)
    d11 = np.dot(v1, v1)
    d20 = np.dot(v2, v0)
    d21 = np.dot(v2, v1)
    denom = d00 * d11 - d01 * d01
    v = (d11 * d20 - d01 * d21) / denom
    w = (d00 * d21 - d01 * d20) / denom
    u = 1.0 - v - w
    return u, v, w


def barycentric2cartesian(a, b, c, p):
    """Computes the cartesian coordinates of the point p w.r.t. 
    the triangle abc given its barycentric coordinates (u,v,w).

    Parameters
    ----------
    a : Float array with shape (2)
        Cartesian coordinates of first vertex of the triangle.
    b : Float array with shape (2)
        Cartesian coordinates of second vertex of the triangle.
    c : Float array with shape (2)
        Cartesian coordinates of third vertex of the triangle.
    p : Float array with shape (3)
        Barycentric coordinates of point whithin the triangle.

    Returns
    -------
    Float array with shape (2)
        Cartesian coordinates of p.
    """
    x = a[0]*p[0] + b[0]*p[1] + c[0]*p[2]
    y = a[1]*p[0] + b[1]*p[1] + c[1]*p[2]
    return x, y


def project_tensor_on_cel_sphere(T, theta, phi):
    """Given a (shape) tensor in the form of a 3x3 matrix, it 
    projects it onto the tangential plane on a given point on 
    the celestial sphere (identified by theta and phi).
    This method is based on e.g. eqs. (2.2, 2.3, 2.4) of 
    arxiv.org/abs/2112.04484

    Parameters
    ----------
    T : float array with shape (3, 3)
        Shape tensor to project.
    theta : float
        Co-latitude of the point on the sphere where to project, in radians.
    phi : float
        Longitude of the point on the sphere where to project, in radians.

    Returns
    -------
    Complex
        Projected ellipticity. This is a complex quantity 
        eps = eps_1 + i*eps_2, where a positive eps_1
        corresponds to east-west elongation and positive 
        eps_2 to northeast-southwest elongation.
    """
    theta_hat = np.array([cos(theta)*cos(phi), cos(theta)*sin(phi), -sin(theta)])
    phi_hat = np.array([-sin(phi), cos(phi), 0.])

    m_p = (phi_hat - theta_hat*1j) / np.sqrt(2)
    m_m = (phi_hat + theta_hat*1j) / np.sqrt(2)
        
    T_p, norm = 0, 0
    for i in range(3):
        for j in range(3):
            T_p += m_m[i] * m_m[j] * T[i,j] 
            norm += m_m[i] * m_p[j] * T[i,j] 

    eps = T_p/norm
    return eps


def project_tensor_on_cel_sphere_array(T, theta, phi):
    """Array version of project_tensor_on_cel_sphere .

    Parameters
    ----------
    T : float array with shape (N, 3, 3)
        Array shape tensors to project.
    theta : float array with shape (N)
        Co-latitude of the points on the sphere where to project, in radians.
    phi : float array with shape (N)
        Longitude of the points on the sphere where to project, in radians.

    Returns
    -------
    Complex with shape (N)
        Projected ellipticities. This is a complex quantity 
        eps = eps_1 + i*eps_2, where a positive eps_1
        corresponds to east-west elongation and positive 
        eps_2 to northeast-southwest elongation.
    """
    theta_hat = np.array([cos(theta)*cos(phi), cos(theta)*sin(phi), -sin(theta)])
    phi_hat = np.array([-sin(phi), cos(phi), np.zeros(len(phi))])

    m_p = np.transpose((phi_hat - theta_hat*1j) / np.sqrt(2))
    m_m = np.transpose((phi_hat + theta_hat*1j) / np.sqrt(2))

    T_p, norm = np.zeros(T.shape[0], dtype=complex), np.zeros(T.shape[0], dtype=complex)
    for i in range(3):
        for j in range(3):
            T_p += m_m[:,i] * m_m[:,j] * T[:,i,j] 
            norm += m_m[:,i] * m_p[:,j] * T[:,i,j] 

    eps = T_p/norm
    return eps