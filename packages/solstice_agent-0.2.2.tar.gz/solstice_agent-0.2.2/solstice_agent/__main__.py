"""Allow running as: python -m solstice_agent"""
from .cli import main

main()
