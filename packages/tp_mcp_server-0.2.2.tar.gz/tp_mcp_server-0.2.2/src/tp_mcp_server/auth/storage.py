"""Cookie storage with multiple backends: env var, keyring, encrypted file."""

import logging
import os

from tp_mcp_server.config import get_config

logger = logging.getLogger("tp_mcp_server.auth")

KEYRING_SERVICE = "tp-mcp-server"
KEYRING_KEY = "tp_auth_cookie"


def get_cookie() -> str | None:
    """Retrieve auth cookie from available storage backends.

    Priority: env var > keyring > None
    """
    # 1. Environment variable (highest priority)
    config = get_config()
    if config.auth_cookie:
        return config.auth_cookie

    # 2. Keyring
    try:
        import keyring

        cookie = keyring.get_password(KEYRING_SERVICE, KEYRING_KEY)
        if cookie:
            logger.info("Loaded auth cookie from keyring.")
            return cookie
    except Exception:
        logger.debug("Keyring not available.")

    return None


def store_cookie(cookie: str) -> bool:
    """Store auth cookie in keyring. Returns True on success."""
    # Also update env for current session
    os.environ["TP_AUTH_COOKIE"] = cookie

    try:
        import keyring

        keyring.set_password(KEYRING_SERVICE, KEYRING_KEY, cookie)
        logger.info("Stored auth cookie in keyring.")
        return True
    except Exception:
        logger.warning("Could not store cookie in keyring.")
        return False


def clear_cookie() -> None:
    """Remove stored cookie from keyring."""
    try:
        import keyring

        keyring.delete_password(KEYRING_SERVICE, KEYRING_KEY)
    except Exception:
        pass
