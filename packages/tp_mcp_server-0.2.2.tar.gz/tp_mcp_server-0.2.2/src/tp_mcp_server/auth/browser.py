"""Optional automatic cookie extraction from browsers."""

import logging

logger = logging.getLogger("tp_mcp_server.auth.browser")


def extract_tp_cookie_from_browser() -> str | None:
    """Try to extract Production_tpAuth cookie from installed browsers.

    Attempts Chrome, Firefox, then Edge. Returns the cookie value
    or None if not found or browser-cookie3 is unavailable.
    """
    try:
        import browser_cookie3
    except ImportError:
        logger.debug("browser-cookie3 not installed.")
        return None

    domain = ".trainingpeaks.com"
    cookie_name = "Production_tpAuth"

    browsers = [
        ("Chrome", browser_cookie3.chrome),
        ("Firefox", browser_cookie3.firefox),
        ("Edge", browser_cookie3.edge),
    ]

    for name, loader in browsers:
        try:
            jar = loader(domain_name=domain)
            for cookie in jar:
                if cookie.name == cookie_name:
                    logger.info("Found %s cookie in %s.", cookie_name, name)
                    return cookie.value
        except Exception as e:
            logger.debug("Could not read %s cookies: %s", name, e)

    logger.info("No TrainingPeaks cookie found in any browser.")
    return None
