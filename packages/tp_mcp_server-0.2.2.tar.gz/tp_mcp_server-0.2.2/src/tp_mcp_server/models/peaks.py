"""Personal record / peak models."""

from dataclasses import dataclass
from typing import Any


# Map PR type codes to human-readable labels
PR_TYPE_LABELS = {
    "Pr5Seconds": "5 sec",
    "Pr10Seconds": "10 sec",
    "Pr12Seconds": "12 sec",
    "Pr20Seconds": "20 sec",
    "Pr30Seconds": "30 sec",
    "Pr1Minute": "1 min",
    "Pr2Minutes": "2 min",
    "Pr5Minutes": "5 min",
    "Pr6Minutes": "6 min",
    "Pr10Minutes": "10 min",
    "Pr12Minutes": "12 min",
    "Pr20Minutes": "20 min",
    "Pr30Minutes": "30 min",
    "Pr60Minutes": "60 min",
    "Pr90Minutes": "90 min",
    "Pr120Minutes": "120 min",
    "Pr1Hour": "60 min",
    # Running distances (API uses varied naming)
    "Pr400Meter": "400 m",
    "Pr400Meters": "400 m",
    "Pr800Meter": "800 m",
    "Pr800Meters": "800 m",
    "Pr1Kilometer": "1 km",
    "Pr1000Meters": "1 km",
    "Pr1Mile": "1 mile",
    "Pr5Kilometer": "5 km",
    "Pr5Km": "5 km",
    "Pr5Mile": "5 mile",
    "Pr10Kilometer": "10 km",
    "Pr10Km": "10 km",
    "PrHalfMarathon": "Half Marathon",
    "PrMarathon": "Marathon",
    "Pr50Km": "50 km",
}


@dataclass
class PeakRecord:
    id: int
    athlete_id: int
    workout_id: int
    workout_date: str
    workout_title: str
    pr_class: str  # "Power", "HeartRate", "Speed", etc.
    pr_type: str  # "Pr5Seconds", "Pr20Minutes", etc.
    time_frame_name: str  # "All-Time", "Last 90 Days", etc.
    value: float
    rank: int
    invalid: bool

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "PeakRecord":
        tf = data.get("timeFrame", {})
        return cls(
            id=data.get("id", 0),
            athlete_id=data.get("athleteId", 0),
            workout_id=data.get("workoutId", 0),
            workout_date=data.get("workoutDate", ""),
            workout_title=data.get("workoutTitle", ""),
            pr_class=data.get("class", ""),
            pr_type=data.get("type", ""),
            time_frame_name=tf.get("name", ""),
            value=data.get("value", 0.0),
            rank=data.get("rank", 0),
            invalid=data.get("invalid", False),
        )

    @property
    def type_label(self) -> str:
        return PR_TYPE_LABELS.get(self.pr_type, self.pr_type)

    def format_value(self) -> str:
        """Format value based on PR class."""
        if self.pr_class == "Power":
            return f"{self.value:.0f} W"
        if self.pr_class == "HeartRate":
            return f"{self.value:.0f} bpm"
        if self.pr_class == "Speed":
            # Speed PRs are in m/s — also show as min/km pace
            if self.value > 0:
                pace_sec_per_km = 1000 / self.value
                pace_min = int(pace_sec_per_km // 60)
                pace_sec = int(pace_sec_per_km % 60)
                return f"{self.value:.2f} m/s ({pace_min}:{pace_sec:02d} /km)"
            return f"{self.value:.2f} m/s"
        return f"{self.value:.1f}"

    def format(self) -> str:
        date = self.workout_date[:10] if self.workout_date else "?"
        return (
            f"#{self.rank} {self.type_label}: {self.format_value()} "
            f"({self.time_frame_name}) — {self.workout_title} ({date})"
        )
