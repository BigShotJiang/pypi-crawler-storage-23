"""Workout models matching TrainingPeaks API response."""

from dataclasses import dataclass
from typing import Any

from tp_mcp_server.utils.formatting import format_duration, format_distance

# Map workoutTypeValueId to human-readable names
WORKOUT_TYPES = {
    1: "Swim",
    2: "Bike",
    3: "Run",
    4: "Brick",
    5: "Cross Training",
    6: "Rest Day",
    7: "Strength",
    8: "Custom",
    9: "Walk",
    10: "Day Off",
    11: "Other",
    12: "XC Ski",
    13: "Hike",
    14: "Rowing",
    15: "Yoga",
}


@dataclass
class WorkoutSummary:
    workout_id: int
    athlete_id: int
    title: str
    workout_type: str
    workout_type_id: int
    workout_day: str
    start_time: str | None
    completed: bool | None
    # Actual metrics
    tss_actual: float | None
    tss_planned: float | None
    intensity_factor: float | None
    total_time: float | None  # hours
    total_time_planned: float | None
    distance: float | None  # meters
    distance_planned: float | None
    calories: float | None
    # HR
    hr_average: int | None
    hr_max: int | None
    hr_min: int | None
    # Power
    power_average: float | None
    power_max: float | None
    normalized_power: float | None
    # Speed
    velocity_average: float | None
    velocity_max: float | None
    # Elevation
    elevation_gain: float | None
    elevation_loss: float | None
    # Cadence
    cadence_average: int | None
    # Other
    feeling: int | None
    rpe: float | None
    personal_record_count: int
    description: str | None
    coach_comments: str | None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "WorkoutSummary":
        type_id = data.get("workoutTypeValueId", 0)
        return cls(
            workout_id=data.get("workoutId", 0),
            athlete_id=data.get("athleteId", 0),
            title=data.get("title", ""),
            workout_type=WORKOUT_TYPES.get(type_id, f"Type {type_id}"),
            workout_type_id=type_id,
            workout_day=data.get("workoutDay", ""),
            start_time=data.get("startTime"),
            completed=data.get("completed"),
            tss_actual=data.get("tssActual"),
            tss_planned=data.get("tssPlanned"),
            intensity_factor=data.get("if"),
            total_time=data.get("totalTime"),
            total_time_planned=data.get("totalTimePlanned"),
            distance=data.get("distance"),
            distance_planned=data.get("distancePlanned"),
            calories=data.get("calories"),
            hr_average=data.get("heartRateAverage"),
            hr_max=data.get("heartRateMaximum"),
            hr_min=data.get("heartRateMinimum"),
            power_average=data.get("powerAverage"),
            power_max=data.get("powerMaximum"),
            normalized_power=data.get("normalizedPowerActual"),
            velocity_average=data.get("velocityAverage"),
            velocity_max=data.get("velocityMaximum"),
            elevation_gain=data.get("elevationGain"),
            elevation_loss=data.get("elevationLoss"),
            cadence_average=data.get("cadenceAverage"),
            feeling=data.get("feeling"),
            rpe=data.get("rpe"),
            personal_record_count=data.get("personalRecordCount", 0),
            description=data.get("description"),
            coach_comments=data.get("coachComments"),
        )

    def format_summary(self) -> str:
        """One-line summary for list views."""
        day = self.workout_day[:10] if self.workout_day else "?"
        parts = [f"{day}  {self.workout_type}: {self.title or '(untitled)'}  (ID: {self.workout_id})"]

        metrics = []
        if self.total_time:
            metrics.append(format_duration(self.total_time))
        if self.distance:
            metrics.append(format_distance(self.distance))
        if self.tss_actual:
            metrics.append(f"TSS {self.tss_actual:.0f}")
        if self.intensity_factor:
            metrics.append(f"IF {self.intensity_factor:.2f}")
        if metrics:
            parts.append("  " + " | ".join(metrics))

        hr_parts = []
        if self.hr_average:
            hr_parts.append(f"Avg {self.hr_average}")
        if self.hr_max:
            hr_parts.append(f"Max {self.hr_max}")
        if hr_parts:
            parts.append(f"  HR: {' / '.join(hr_parts)} bpm")

        if self.power_average or self.normalized_power:
            pwr = []
            if self.power_average:
                pwr.append(f"Avg {self.power_average:.0f}")
            if self.normalized_power:
                pwr.append(f"NP {self.normalized_power:.0f}")
            parts.append(f"  Power: {' / '.join(pwr)} W")

        if self.personal_record_count:
            parts.append(f"  PRs: {self.personal_record_count}")

        return "\n".join(parts)

    def format_detail(self) -> str:
        """Full detail view for a single workout."""
        day = self.workout_day[:10] if self.workout_day else "?"
        lines = [
            f"# {self.title or '(untitled)'} — {self.workout_type}",
            f"Date: {day}",
        ]
        if self.start_time:
            lines.append(f"Start: {self.start_time}")
        lines.append(f"Workout ID: {self.workout_id}")
        lines.append("")

        # Key metrics
        lines.append("## Metrics")
        if self.total_time:
            lines.append(f"Duration: {format_duration(self.total_time)}")
        if self.total_time_planned:
            lines.append(f"Planned Duration: {format_duration(self.total_time_planned)}")
        if self.distance:
            lines.append(f"Distance: {format_distance(self.distance)}")
        if self.distance_planned:
            lines.append(f"Planned Distance: {format_distance(self.distance_planned)}")
        if self.tss_actual is not None:
            line = f"TSS: {self.tss_actual:.1f}"
            if self.tss_planned:
                line += f" (planned: {self.tss_planned:.1f})"
            lines.append(line)
        if self.intensity_factor:
            lines.append(f"IF: {self.intensity_factor:.2f}")
        if self.calories:
            lines.append(f"Calories: {self.calories:.0f}")

        # Heart Rate
        if self.hr_average or self.hr_max:
            lines.append("")
            lines.append("## Heart Rate")
            if self.hr_average:
                lines.append(f"Average: {self.hr_average} bpm")
            if self.hr_min:
                lines.append(f"Minimum: {self.hr_min} bpm")
            if self.hr_max:
                lines.append(f"Maximum: {self.hr_max} bpm")

        # Power
        if self.power_average or self.normalized_power:
            lines.append("")
            lines.append("## Power")
            if self.power_average:
                lines.append(f"Average: {self.power_average:.0f} W")
            if self.normalized_power:
                lines.append(f"Normalized: {self.normalized_power:.0f} W")
            if self.power_max:
                lines.append(f"Maximum: {self.power_max:.0f} W")
            if self.power_average and self.normalized_power and self.power_average > 0:
                vi = self.normalized_power / self.power_average
                lines.append(f"Variability Index: {vi:.2f}")

        # Speed
        if self.velocity_average:
            lines.append("")
            lines.append("## Speed")
            lines.append(f"Average: {self.velocity_average:.2f} m/s ({self.velocity_average * 3.6:.1f} km/h)")
            if self.velocity_max:
                lines.append(f"Maximum: {self.velocity_max:.2f} m/s ({self.velocity_max * 3.6:.1f} km/h)")

        # Elevation
        if self.elevation_gain:
            lines.append("")
            lines.append("## Elevation")
            lines.append(f"Gain: {self.elevation_gain:.0f} m")
            if self.elevation_loss:
                lines.append(f"Loss: {self.elevation_loss:.0f} m")

        # Cadence
        if self.cadence_average:
            lines.append("")
            lines.append(f"Cadence: {self.cadence_average} avg")

        # Feel
        if self.feeling or self.rpe:
            lines.append("")
            if self.feeling:
                feel_map = {1: "Terrible", 2: "Bad", 3: "Normal", 4: "Good", 5: "Awesome"}
                lines.append(f"Feeling: {feel_map.get(self.feeling, self.feeling)}")
            if self.rpe:
                lines.append(f"RPE: {self.rpe}")

        if self.personal_record_count:
            lines.append(f"\nPersonal Records: {self.personal_record_count}")

        # Comments
        if self.description:
            lines.append(f"\n## Description\n{self.description}")
        if self.coach_comments:
            lines.append(f"\n## Coach Comments\n{self.coach_comments}")

        return "\n".join(lines)

    def format_planned_summary(self) -> str:
        """One-line summary for planned/upcoming workout list views."""
        day = self.workout_day[:10] if self.workout_day else "?"
        status = "Completed" if self.completed else "Planned"
        parts = [f"{day}  [{status}] {self.workout_type}: {self.title or '(untitled)'}  (ID: {self.workout_id})"]

        metrics = []
        if self.total_time_planned:
            metrics.append(format_duration(self.total_time_planned))
        if self.distance_planned:
            metrics.append(format_distance(self.distance_planned))
        if self.tss_planned:
            metrics.append(f"TSS {self.tss_planned:.0f}")
        if metrics:
            parts.append("  Planned: " + " | ".join(metrics))

        if self.description:
            desc = self.description.strip()
            if len(desc) > 200:
                desc = desc[:200] + "..."
            parts.append(f"  Instructions: {desc}")

        return "\n".join(parts)

    def format_planned_detail(self) -> str:
        """Full detail view for a planned/upcoming workout."""
        day = self.workout_day[:10] if self.workout_day else "?"
        status = "Completed" if self.completed else "Planned"
        lines = [
            f"# {self.title or '(untitled)'} — {self.workout_type}",
            f"Date: {day}  |  Status: {status}",
        ]
        if self.start_time:
            lines.append(f"Start: {self.start_time}")
        lines.append(f"Workout ID: {self.workout_id}")

        # Description / coach instructions up front
        if self.description:
            lines.append(f"\n## Workout Instructions\n{self.description}")
        if self.coach_comments:
            lines.append(f"\n## Coach Comments\n{self.coach_comments}")

        # Planned metrics
        has_planned = self.total_time_planned or self.distance_planned or self.tss_planned
        if has_planned:
            lines.append("\n## Planned Metrics")
            if self.total_time_planned:
                lines.append(f"Duration: {format_duration(self.total_time_planned)}")
            if self.distance_planned:
                lines.append(f"Distance: {format_distance(self.distance_planned)}")
            if self.tss_planned:
                lines.append(f"TSS: {self.tss_planned:.1f}")

        # Actual metrics (if completed)
        if self.completed:
            has_actual = self.total_time or self.distance or self.tss_actual
            if has_actual:
                lines.append("\n## Actual Metrics")
                if self.total_time:
                    lines.append(f"Duration: {format_duration(self.total_time)}")
                if self.distance:
                    lines.append(f"Distance: {format_distance(self.distance)}")
                if self.tss_actual is not None:
                    lines.append(f"TSS: {self.tss_actual:.1f}")
                if self.intensity_factor:
                    lines.append(f"IF: {self.intensity_factor:.2f}")

        return "\n".join(lines)
