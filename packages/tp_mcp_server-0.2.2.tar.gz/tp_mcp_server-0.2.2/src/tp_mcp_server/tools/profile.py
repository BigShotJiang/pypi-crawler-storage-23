"""Athlete profile tool."""

from typing import Any

from tp_mcp_server.api.client import make_tp_request
from tp_mcp_server.api.endpoints import USER_URL
from tp_mcp_server.config import get_config
from tp_mcp_server.mcp_instance import mcp
from tp_mcp_server.models.profile import UserProfile


@mcp.tool()
async def tp_get_profile() -> str:
    """Get your TrainingPeaks athlete profile.

    Returns your name, athlete ID, email, and other profile information.
    The athlete ID is needed for other TrainingPeaks queries.
    """
    result: dict[str, Any] | list = await make_tp_request(USER_URL)

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching profile: {result.get('message')}"

    if isinstance(result, list):
        return "Unexpected response format from profile API."

    profile = UserProfile.from_api(result)

    # Auto-store athlete ID if not set
    config = get_config()
    if not config.athlete_id and profile.athlete_id:
        config.athlete_id = str(profile.athlete_id)

    return f"TrainingPeaks Profile:\n\n{profile.format()}"
