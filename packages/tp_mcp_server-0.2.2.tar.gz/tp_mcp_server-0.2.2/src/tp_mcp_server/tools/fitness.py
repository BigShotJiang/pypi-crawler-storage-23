"""Fitness (CTL/ATL/TSB) performance data tools."""

from typing import Any

from tp_mcp_server.api.client import make_tp_request
from tp_mcp_server.api.endpoints import FITNESS_URL
from tp_mcp_server.config import get_config
from tp_mcp_server.mcp_instance import mcp
from tp_mcp_server.models.fitness import (
    FitnessEntry,
    compute_ctl_atl_tsb,
    fitness_status_label,
)
from tp_mcp_server.utils.dates import parse_date_range, get_date_ago


def _resolve_athlete_id() -> tuple[str, str | None]:
    config = get_config()
    if not config.athlete_id:
        return "", (
            "No athlete ID available. Run tp_get_profile first to auto-detect it, "
            "or set ATHLETE_ID in your .env file."
        )
    return config.athlete_id, None


@mcp.tool()
async def tp_get_fitness(
    days: int = 90,
    start_date: str | None = None,
    end_date: str | None = None,
) -> str:
    """Get CTL (fitness), ATL (fatigue), and TSB (form) performance data.

    Args:
        days: Number of days to look back (default 90). Ignored if start_date is set.
        start_date: Start date (YYYY-MM-DD). Overrides days parameter.
        end_date: End date (YYYY-MM-DD). Defaults to today.

    Returns daily training load data with computed CTL/ATL/TSB values
    and current fitness status. To get accurate CTL/ATL values, the API
    fetches extra history for the exponential decay calculation.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    # Determine the display range
    if start_date:
        display_start, display_end = parse_date_range(start_date, end_date)
    else:
        display_start, display_end = parse_date_range(
            get_date_ago(days), end_date
        )

    # Fetch extra 90 days of history for accurate CTL/ATL warmup
    warmup_start = get_date_ago(days + 90) if not start_date else get_date_ago(
        # Calculate days from start_date to now, plus 90 warmup
        180
    )

    url = FITNESS_URL.format(
        athlete_id=aid, start_date=warmup_start, end_date=display_end
    )
    result: Any = await make_tp_request(url, method="POST", data={})

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching fitness data: {result.get('message')}"

    if not isinstance(result, list):
        return "Unexpected response format."

    # Parse and compute CTL/ATL/TSB
    entries = [FitnessEntry.from_api(e) for e in result]
    entries = compute_ctl_atl_tsb(entries)

    # Filter to display range only
    display_entries = [
        e for e in entries if e.workout_day[:10] >= display_start
    ]

    if not display_entries:
        return f"No fitness data between {display_start} and {display_end}."

    # Current status (last entry)
    current = display_entries[-1]
    status = fitness_status_label(current.tsb)

    lines = [
        f"Fitness Data ({display_start} to {display_end})",
        "",
        f"Current Status: {status}",
        f"  CTL (Fitness): {current.ctl:.1f}" if current.ctl is not None else "  CTL: N/A",
        f"  ATL (Fatigue): {current.atl:.1f}" if current.atl is not None else "  ATL: N/A",
        f"  TSB (Form):    {current.tsb:.1f}" if current.tsb is not None else "  TSB: N/A",
        "",
        "Daily Data (last 14 days):",
        f"{'Date':<12} {'TSS':>6} {'CTL':>6} {'ATL':>6} {'TSB':>6}  Status",
        "-" * 60,
    ]

    # Show last 14 days of data
    recent = display_entries[-14:]
    for e in recent:
        day = e.workout_day[:10]
        tss = f"{e.tss_actual:.0f}" if e.tss_actual else "0"
        ctl = f"{e.ctl:.1f}" if e.ctl is not None else "-"
        atl = f"{e.atl:.1f}" if e.atl is not None else "-"
        tsb = f"{e.tsb:.1f}" if e.tsb is not None else "-"
        st = fitness_status_label(e.tsb)
        lines.append(f"{day:<12} {tss:>6} {ctl:>6} {atl:>6} {tsb:>6}  {st}")

    return "\n".join(lines)
