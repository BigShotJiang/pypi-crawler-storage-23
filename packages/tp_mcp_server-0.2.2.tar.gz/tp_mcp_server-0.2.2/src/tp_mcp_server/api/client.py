"""Async HTTP client for TrainingPeaks API with cookie-to-token exchange."""

import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from tp_mcp_server.api.endpoints import TOKEN_URL
from tp_mcp_server.auth.storage import get_cookie
from tp_mcp_server.config import get_config

logger = logging.getLogger("tp_mcp_server.api")

# Global state
_httpx_client: httpx.AsyncClient | None = None
_bearer_token: str | None = None
_token_expires_at: float = 0.0
_token_lock = asyncio.Lock()
_last_request_time: float = 0.0
_REQUEST_THROTTLE_MS = 150


async def _get_httpx_client() -> httpx.AsyncClient:
    """Get or create the shared async HTTP client."""
    global _httpx_client
    if _httpx_client is None or _httpx_client.is_closed:
        _httpx_client = httpx.AsyncClient(timeout=30.0)
    return _httpx_client


@asynccontextmanager
async def setup_api_client(_app: FastMCP):
    """Lifespan context manager for httpx client cleanup."""
    try:
        yield
    finally:
        global _httpx_client
        if _httpx_client and not _httpx_client.is_closed:
            await _httpx_client.aclose()
            _httpx_client = None


async def _exchange_cookie_for_token() -> tuple[str, int] | None:
    """Exchange TP auth cookie for a bearer token.

    Calls GET /users/v3/token with the Production_tpAuth cookie.
    Returns (access_token, expires_in_seconds) or None on failure.
    """
    cookie = get_cookie()
    if not cookie:
        logger.error("No auth cookie available.")
        return None

    config = get_config()
    client = await _get_httpx_client()
    url = f"{config.tp_api_base_url}{TOKEN_URL}"

    try:
        response = await client.get(
            url,
            headers={
                "User-Agent": config.user_agent,
                "Cookie": f"Production_tpAuth={cookie}",
                "Accept": "application/json",
            },
        )
        response.raise_for_status()
        data = response.json()
        # Response shape: {"success": true, "token": {"access_token": "...", "expires_in": 3600}}
        token_data = data.get("token", data)
        if isinstance(token_data, dict):
            token = token_data.get("access_token")
            expires_in = token_data.get("expires_in", 3600)
        else:
            token = token_data
            expires_in = 3600
        if not token:
            logger.error("Token response missing access_token: %s", data)
            return None
        return token, expires_in
    except httpx.HTTPStatusError as e:
        logger.error("Token exchange failed (%d): %s", e.response.status_code, e)
        return None
    except Exception as e:
        logger.error("Token exchange error: %s", e)
        return None


async def _get_valid_token(force_refresh: bool = False) -> str | None:
    """Get a valid bearer token, refreshing if needed.

    Uses an async lock to prevent concurrent refresh races.
    Refreshes 60 seconds before expiry.
    """
    global _bearer_token, _token_expires_at

    async with _token_lock:
        now = time.time()
        if not force_refresh and _bearer_token and now < (_token_expires_at - 60):
            return _bearer_token

        logger.info("Refreshing bearer token...")
        result = await _exchange_cookie_for_token()
        if result:
            token, expires_in = result
            _bearer_token = token
            _token_expires_at = now + expires_in
            logger.info(
                "Bearer token refreshed (expires in %d min).", expires_in // 60
            )
        else:
            _bearer_token = None
            _token_expires_at = 0.0
        return _bearer_token


async def _throttle() -> None:
    """Enforce minimum delay between requests."""
    global _last_request_time
    now = time.time()
    elapsed_ms = (now - _last_request_time) * 1000
    if elapsed_ms < _REQUEST_THROTTLE_MS:
        await asyncio.sleep((_REQUEST_THROTTLE_MS - elapsed_ms) / 1000)
    _last_request_time = time.time()


def clear_token() -> None:
    """Clear cached bearer token (e.g., on 401)."""
    global _bearer_token, _token_expires_at
    _bearer_token = None
    _token_expires_at = 0.0


async def make_tp_request(
    url: str,
    method: str = "GET",
    params: dict[str, Any] | None = None,
    data: dict[str, Any] | None = None,
    _retry: bool = True,
) -> dict[str, Any] | list[dict[str, Any]]:
    """Make an authenticated request to the TrainingPeaks API.

    Features:
    - Automatic token management (cookie-to-token exchange)
    - Request throttling (150ms between requests)
    - 401 retry (clear token, re-auth, retry once)
    - Friendly error messages
    """
    config = get_config()

    # Get bearer token
    token = await _get_valid_token()
    if not token:
        return {
            "error": True,
            "message": (
                "Authentication failed. Please check your TP_AUTH_COOKIE. "
                "You may need to re-login to TrainingPeaks in your browser "
                "and extract a fresh Production_tpAuth cookie."
            ),
        }

    await _throttle()

    full_url = f"{config.tp_api_base_url}{url}"
    headers = {
        "User-Agent": config.user_agent,
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
    }
    if method in ("POST", "PUT"):
        headers["Content-Type"] = "application/json"

    client = await _get_httpx_client()

    try:
        if method in ("POST", "PUT") and data is not None:
            response = await client.request(
                method=method,
                url=full_url,
                headers=headers,
                params=params,
                content=json.dumps(data),
            )
        else:
            response = await client.request(
                method=method,
                url=full_url,
                headers=headers,
                params=params,
            )

        # Handle 401 with retry
        if response.status_code == 401 and _retry:
            logger.warning("Got 401, retrying with fresh token...")
            clear_token()
            return await make_tp_request(
                url, method=method, params=params, data=data, _retry=False
            )

        response.raise_for_status()
        return _parse_response(response)

    except httpx.HTTPStatusError as e:
        return _handle_http_error(e)
    except httpx.RequestError as e:
        logger.error("Request error: %s", e)
        return {
            "error": True,
            "message": f"Network error: {e}. Check your internet connection.",
        }


def _parse_response(
    response: httpx.Response,
) -> dict[str, Any] | list[dict[str, Any]]:
    """Parse JSON response, handling empty bodies."""
    if response.status_code == 204 or not response.content:
        return {"success": True}

    try:
        return response.json()
    except json.JSONDecodeError:
        return {"error": True, "message": "Invalid JSON response from API."}


def _handle_http_error(e: httpx.HTTPStatusError) -> dict[str, Any]:
    """Convert HTTP errors to user-friendly messages."""
    status = e.response.status_code
    messages = {
        401: (
            "Authentication expired. Please extract a fresh "
            "Production_tpAuth cookie from your browser."
        ),
        403: "Access denied. Your account may not have permission for this data.",
        404: "Resource not found. Check that the athlete ID or workout ID is correct.",
        429: "Rate limited. Please wait a moment and try again.",
        500: "TrainingPeaks server error. Try again later.",
        503: "TrainingPeaks is temporarily unavailable. Try again later.",
    }
    message = messages.get(status, f"HTTP {status}: {e.response.text[:200]}")
    logger.error("HTTP error %d: %s", status, message)
    return {"error": True, "message": message}


def is_authenticated() -> bool:
    """Check if we have a valid cached token."""
    return _bearer_token is not None and time.time() < (_token_expires_at - 60)
