from .service import MailingListsService

__all__ = ["MailingListsService"]
