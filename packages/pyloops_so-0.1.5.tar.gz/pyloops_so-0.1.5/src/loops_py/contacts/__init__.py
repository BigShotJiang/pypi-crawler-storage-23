from .service import ContactsService

__all__ = ["ContactsService"]
