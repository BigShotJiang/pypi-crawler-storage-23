import math
table=["히히", "히힣", "힣히", "힣힣", "히ㅣ","ㅣ히","ㅣㅣ","히힛"]
def settable(li):
    global table
    table=li
def encode(S):
    N = len(table)
    bits = math.ceil(math.log2(N))

    buff = ""
    output = []

    for c in S:
        temp = bin(ord(c))[2:]
        temp = "0" * (21 - len(temp)) + temp
        buff += temp

        while len(buff) >= bits:
            idx = int(buff[:bits], 2)
            if idx >= N:
                # index가 table 범위를 넘으면 버리고 다음 비트로 진행
                buff = buff[1:]
                continue
            output.append(table[idx])
            buff = buff[bits:]

    # 남은 비트 처리
    if len(buff):
        buff += "0" * (bits - len(buff))
        idx = int(buff, 2)
        if idx < N:
            output.append(table[idx])

    return ''.join(output)


def decode(S):
    N = len(table)
    bits = math.ceil(math.log2(N))
    length = len(table[0])

    B = ""

    for i in range(0, len(S), length):
        idx = table.index(S[i:i+length])
        temp = bin(idx)[2:]
        temp = "0" * (bits - len(temp)) + temp
        B += temp

    p = 0
    output = ''
    while p + 21 <= len(B):
        output += chr(int(B[p:p+21], 2))
        p += 21

    return output