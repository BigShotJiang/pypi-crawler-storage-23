import unittest
from unittest.mock import Mock

import requests

from poly_storage_sdk import PolyStorageAPIError, PolyStorageAuthError, PolyStorageClient


class _FakeResponse:
    def __init__(self, *, status_code=200, payload=None, text="") -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = text

    def json(self):
        if self._payload is None:
            raise ValueError("no json")
        return self._payload


class PolyStorageClientTests(unittest.TestCase):
    def test_base_url_appends_api_prefix(self):
        client = PolyStorageClient(api_key="k", base_url="https://api.entityml.com")
        self.assertEqual(client.base_url, "https://api.entityml.com/api/v1")

    def test_market_data_requires_api_key(self):
        client = PolyStorageClient(api_key=None)
        with self.assertRaises(PolyStorageAuthError):
            client.polymarket.get_market_data(
                condition_id="0xabc",
                date="2026-02-13",
            )

    def test_auth_failure_maps_to_auth_error(self):
        session = requests.Session()
        session.request = Mock(
            return_value=_FakeResponse(status_code=401, payload={"detail": "Invalid API key"})
        )
        client = PolyStorageClient(api_key="bad", session=session)

        with self.assertRaises(PolyStorageAuthError) as ctx:
            client.polymarket.get_market_data(condition_id="0xabc", date="2026-02-13")

        self.assertEqual(ctx.exception.status_code, 401)
        self.assertEqual(ctx.exception.detail, "Invalid API key")

    def test_non_auth_error_maps_to_api_error(self):
        session = requests.Session()
        session.request = Mock(
            return_value=_FakeResponse(status_code=500, payload={"detail": "boom"})
        )
        client = PolyStorageClient(api_key="good", session=session)

        with self.assertRaises(PolyStorageAPIError) as ctx:
            client.polymarket.get_orderbook_summary(
                condition_id="0xabc",
                date="2026-02-13",
                resolution=60,
            )

        self.assertEqual(ctx.exception.status_code, 500)
        self.assertEqual(ctx.exception.detail, "boom")

    def test_health_returns_json(self):
        session = requests.Session()
        session.request = Mock(
            return_value=_FakeResponse(status_code=200, payload={"status": "healthy"})
        )
        client = PolyStorageClient(session=session)

        health = client.system.health()

        self.assertEqual(health["status"], "healthy")


if __name__ == "__main__":
    unittest.main()
