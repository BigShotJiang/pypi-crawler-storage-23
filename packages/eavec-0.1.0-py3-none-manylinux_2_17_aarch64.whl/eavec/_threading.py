"""Multi-threaded batch wrappers. ctypes releases the GIL for true parallelism."""
from __future__ import annotations

import ctypes
import os
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from ._ops import _check_query_db

_pool: ThreadPoolExecutor | None = None
_pool_size: int = 0


def _get_pool(num_threads: int) -> ThreadPoolExecutor:
    global _pool, _pool_size
    if _pool is None or _pool_size != num_threads:
        if _pool is not None:
            _pool.shutdown(wait=False)
        _pool = ThreadPoolExecutor(max_workers=num_threads)
        _pool_size = num_threads
    return _pool


def _batch_mt(
    kernel_func: str,
    query: np.ndarray,
    db: np.ndarray,
    num_threads: int | None = None,
) -> np.ndarray:
    """Generic multi-threaded batch operation using raw ctypes pointers."""
    from . import _search

    query, db, dim, n_vecs = _check_query_db(query, db)
    if num_threads is None:
        num_threads = os.cpu_count() or 4

    lib = _search._lib
    func = getattr(lib, kernel_func)
    out = np.empty(n_vecs, dtype=np.float32)
    flat_db = np.ascontiguousarray(db.ravel())

    q_ptr = query.ctypes.data
    db_ptr = flat_db.ctypes.data
    out_ptr = out.ctypes.data
    sizeof_f32 = 4

    strips = []
    per = n_vecs // num_threads
    rem = n_vecs % num_threads
    start = 0
    for t in range(num_threads):
        count = per + (1 if t < rem else 0)
        if count == 0:
            continue
        strips.append((start, count))
        start += count

    def process_strip(s_start: int, s_count: int) -> None:
        db_off = s_start * dim * sizeof_f32
        out_off = s_start * sizeof_f32
        func(
            ctypes.cast(q_ptr, ctypes.POINTER(ctypes.c_float)),
            ctypes.cast(db_ptr + db_off, ctypes.POINTER(ctypes.c_float)),
            ctypes.c_int32(dim),
            ctypes.c_int32(s_count),
            ctypes.cast(out_ptr + out_off, ctypes.POINTER(ctypes.c_float)),
        )

    pool = _get_pool(num_threads)
    futures = [pool.submit(process_strip, *s) for s in strips]
    for f in futures:
        f.result()

    return out


def batch_dot_mt(
    query: np.ndarray,
    db: np.ndarray,
    num_threads: int | None = None,
) -> np.ndarray:
    """Multi-threaded batch dot product. Partitions db rows across threads."""
    return _batch_mt("batch_dot", query, db, num_threads)


def batch_cosine_mt(
    query: np.ndarray,
    db: np.ndarray,
    num_threads: int | None = None,
) -> np.ndarray:
    """Multi-threaded batch cosine similarity. Partitions db rows across threads."""
    return _batch_mt("batch_cosine", query, db, num_threads)


def batch_l2_mt(
    query: np.ndarray,
    db: np.ndarray,
    num_threads: int | None = None,
) -> np.ndarray:
    """Multi-threaded batch L2 squared distance. Partitions db rows across threads."""
    return _batch_mt("batch_l2", query, db, num_threads)
