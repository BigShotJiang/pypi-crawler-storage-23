"""Ctypes bindings for libsearch (batch vector operations)."""
import ctypes as _ct

import numpy as _np

from ._loader import load_library

_lib = load_library("search")

# batch_dot(query, db, dim, n_vecs, out)
_lib.batch_dot.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float),
    _ct.c_int32, _ct.c_int32, _ct.POINTER(_ct.c_float),
]
_lib.batch_dot.restype = None

# batch_cosine(query, db, dim, n_vecs, out)
_lib.batch_cosine.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float),
    _ct.c_int32, _ct.c_int32, _ct.POINTER(_ct.c_float),
]
_lib.batch_cosine.restype = None

# batch_l2(query, db, dim, n_vecs, out)
_lib.batch_l2.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float),
    _ct.c_int32, _ct.c_int32, _ct.POINTER(_ct.c_float),
]
_lib.batch_l2.restype = None

# normalize_vectors(db, dim, n_vecs, out)
_lib.normalize_vectors.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.c_int32, _ct.c_int32,
    _ct.POINTER(_ct.c_float),
]
_lib.normalize_vectors.restype = None

# threshold_filter(scores, n, threshold, out_indices, out_count)
_lib.threshold_filter.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.c_int32, _ct.c_float,
    _ct.POINTER(_ct.c_int32), _ct.POINTER(_ct.c_int32),
]
_lib.threshold_filter.restype = None

# top_k(scores, work, n, k, out_values, out_indices)
_lib.top_k.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float),
    _ct.c_int32, _ct.c_int32,
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_int32),
]
_lib.top_k.restype = None


def batch_dot(query: _np.ndarray, db: _np.ndarray, dim: int,
              n_vecs: int, out: _np.ndarray) -> None:
    if query.dtype != _np.float32:
        raise TypeError("query: expected float32")
    if db.dtype != _np.float32:
        raise TypeError("db: expected float32")
    if out.dtype != _np.float32:
        raise TypeError("out: expected float32")
    _lib.batch_dot(
        query.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        db.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(int(dim)),
        _ct.c_int32(int(n_vecs)),
        out.ctypes.data_as(_ct.POINTER(_ct.c_float)),
    )


def batch_cosine(query: _np.ndarray, db: _np.ndarray, dim: int,
                 n_vecs: int, out: _np.ndarray) -> None:
    if query.dtype != _np.float32:
        raise TypeError("query: expected float32")
    if db.dtype != _np.float32:
        raise TypeError("db: expected float32")
    if out.dtype != _np.float32:
        raise TypeError("out: expected float32")
    _lib.batch_cosine(
        query.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        db.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(int(dim)),
        _ct.c_int32(int(n_vecs)),
        out.ctypes.data_as(_ct.POINTER(_ct.c_float)),
    )


def batch_l2(query: _np.ndarray, db: _np.ndarray, dim: int,
             n_vecs: int, out: _np.ndarray) -> None:
    if query.dtype != _np.float32:
        raise TypeError("query: expected float32")
    if db.dtype != _np.float32:
        raise TypeError("db: expected float32")
    if out.dtype != _np.float32:
        raise TypeError("out: expected float32")
    _lib.batch_l2(
        query.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        db.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(int(dim)),
        _ct.c_int32(int(n_vecs)),
        out.ctypes.data_as(_ct.POINTER(_ct.c_float)),
    )


def normalize_vectors(db: _np.ndarray, dim: int, n_vecs: int,
                      out: _np.ndarray) -> None:
    if db.dtype != _np.float32:
        raise TypeError("db: expected float32")
    if out.dtype != _np.float32:
        raise TypeError("out: expected float32")
    _lib.normalize_vectors(
        db.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(int(dim)),
        _ct.c_int32(int(n_vecs)),
        out.ctypes.data_as(_ct.POINTER(_ct.c_float)),
    )


def threshold_filter(scores: _np.ndarray, threshold: float,
                     out_indices: _np.ndarray,
                     out_count: _np.ndarray) -> None:
    if scores.dtype != _np.float32:
        raise TypeError("scores: expected float32")
    if out_indices.dtype != _np.int32:
        raise TypeError("out_indices: expected int32")
    if out_count.dtype != _np.int32:
        raise TypeError("out_count: expected int32")
    _lib.threshold_filter(
        scores.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(scores.size),
        _ct.c_float(float(threshold)),
        out_indices.ctypes.data_as(_ct.POINTER(_ct.c_int32)),
        out_count.ctypes.data_as(_ct.POINTER(_ct.c_int32)),
    )


def top_k(scores: _np.ndarray, work: _np.ndarray, k: int,
          out_values: _np.ndarray, out_indices: _np.ndarray) -> None:
    if scores.dtype != _np.float32:
        raise TypeError("scores: expected float32")
    if work.dtype != _np.float32:
        raise TypeError("work: expected float32")
    if out_values.dtype != _np.float32:
        raise TypeError("out_values: expected float32")
    if out_indices.dtype != _np.int32:
        raise TypeError("out_indices: expected int32")
    _lib.top_k(
        scores.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        work.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(work.size),
        _ct.c_int32(int(k)),
        out_values.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        out_indices.ctypes.data_as(_ct.POINTER(_ct.c_int32)),
    )
