"""Platform detection and shared library loading."""
import ctypes
import platform
import sys
from pathlib import Path

_LIB_DIR = Path(__file__).parent / "lib"


def _detect_platform() -> str:
    """Detect platform and return a tag like 'linux_x86_64'."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == "linux":
        if machine in ("x86_64", "amd64"):
            return "linux_x86_64"
        if machine in ("aarch64", "arm64"):
            return "linux_aarch64"
    elif system == "windows":
        if machine in ("x86_64", "amd64", "amd64"):
            return "windows_x86_64"

    raise OSError(
        f"Unsupported platform: {system}/{machine}. "
        "eavec supports linux/x86_64, linux/aarch64, and windows/x86_64."
    )


def _lib_extension() -> str:
    """Return the shared library extension for the current platform."""
    if sys.platform == "win32":
        return ".dll"
    return ".so"


def load_library(name: str) -> ctypes.CDLL:
    """Load a shared library by name (e.g. 'similarity' -> libsimilarity.so)."""
    ext = _lib_extension()
    prefix = "" if sys.platform == "win32" else "lib"
    lib_path = _LIB_DIR / f"{prefix}{name}{ext}"

    if not lib_path.exists():
        raise OSError(
            f"eavec kernel library not found: {lib_path}\n"
            "This usually means the package was not built for your platform.\n"
            "Please install a pre-built wheel: pip install eavec"
        )

    return ctypes.CDLL(str(lib_path))
