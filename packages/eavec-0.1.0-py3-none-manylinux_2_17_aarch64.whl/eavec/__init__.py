"""eavec — SIMD-accelerated vector similarity search."""

__version__ = "0.1.0"

from eavec._ops import (
    batch_cosine,
    batch_dot,
    batch_l2,
    cosine,
    dot,
    l2_squared,
    norm,
    normalize,
    threshold_filter,
    top_k,
)
from eavec._threading import batch_cosine_mt, batch_dot_mt, batch_l2_mt

__all__ = [
    "dot",
    "norm",
    "cosine",
    "l2_squared",
    "batch_dot",
    "batch_cosine",
    "batch_l2",
    "normalize",
    "threshold_filter",
    "top_k",
    "batch_dot_mt",
    "batch_cosine_mt",
    "batch_l2_mt",
]
