"""Ctypes bindings for libsimilarity (single-pair vector primitives)."""
import ctypes as _ct

import numpy as _np

from ._loader import load_library

_lib = load_library("similarity")

# dot_f32(a: *restrict f32, b: *restrict f32, len: i32) -> f32
_lib.dot_f32.argtypes = [_ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float), _ct.c_int32]
_lib.dot_f32.restype = _ct.c_float

# norm_f32(a: *restrict f32, len: i32) -> f32
_lib.norm_f32.argtypes = [_ct.POINTER(_ct.c_float), _ct.c_int32]
_lib.norm_f32.restype = _ct.c_float

# cosine_f32(a: *restrict f32, b: *restrict f32, len: i32) -> f32
_lib.cosine_f32.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float), _ct.c_int32,
]
_lib.cosine_f32.restype = _ct.c_float

# l2_sq_f32(a: *restrict f32, b: *restrict f32, len: i32) -> f32
_lib.l2_sq_f32.argtypes = [
    _ct.POINTER(_ct.c_float), _ct.POINTER(_ct.c_float), _ct.c_int32,
]
_lib.l2_sq_f32.restype = _ct.c_float


def dot_f32(a: _np.ndarray, b: _np.ndarray) -> float:
    if a.dtype != _np.float32:
        raise TypeError("a: expected float32")
    if b.dtype != _np.float32:
        raise TypeError("b: expected float32")
    result = _lib.dot_f32(
        a.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        b.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(b.size),
    )
    return float(result)


def norm_f32(a: _np.ndarray) -> float:
    if a.dtype != _np.float32:
        raise TypeError("a: expected float32")
    result = _lib.norm_f32(
        a.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(a.size),
    )
    return float(result)


def cosine_f32(a: _np.ndarray, b: _np.ndarray) -> float:
    if a.dtype != _np.float32:
        raise TypeError("a: expected float32")
    if b.dtype != _np.float32:
        raise TypeError("b: expected float32")
    result = _lib.cosine_f32(
        a.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        b.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(b.size),
    )
    return float(result)


def l2_sq_f32(a: _np.ndarray, b: _np.ndarray) -> float:
    if a.dtype != _np.float32:
        raise TypeError("a: expected float32")
    if b.dtype != _np.float32:
        raise TypeError("b: expected float32")
    result = _lib.l2_sq_f32(
        a.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        b.ctypes.data_as(_ct.POINTER(_ct.c_float)),
        _ct.c_int32(b.size),
    )
    return float(result)
