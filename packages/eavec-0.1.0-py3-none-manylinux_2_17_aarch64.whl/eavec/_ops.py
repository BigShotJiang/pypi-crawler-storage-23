"""High-level numpy-friendly API for eavec SIMD kernels."""
from __future__ import annotations

import numpy as np


def _check_f32_1d(arr: np.ndarray, name: str) -> np.ndarray:
    """Validate a 1D float32 contiguous array."""
    if arr.dtype != np.float32:
        raise TypeError(f"{name}: expected float32, got {arr.dtype}")
    if arr.ndim != 1:
        raise ValueError(f"{name}: expected 1D array, got {arr.ndim}D")
    if not arr.flags["C_CONTIGUOUS"]:
        arr = np.ascontiguousarray(arr)
    return arr


def _check_f32_2d(arr: np.ndarray, name: str) -> np.ndarray:
    """Validate a 2D float32 contiguous array."""
    if arr.dtype != np.float32:
        raise TypeError(f"{name}: expected float32, got {arr.dtype}")
    if arr.ndim != 2:
        raise ValueError(f"{name}: expected 2D array, got {arr.ndim}D")
    if not arr.flags["C_CONTIGUOUS"]:
        arr = np.ascontiguousarray(arr)
    return arr


def _check_pair(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Validate two 1D float32 arrays of the same length."""
    a = _check_f32_1d(a, "a")
    b = _check_f32_1d(b, "b")
    if a.shape[0] != b.shape[0]:
        raise ValueError(
            f"dimension mismatch: a has {a.shape[0]} elements, b has {b.shape[0]}"
        )
    return a, b


def _check_query_db(
    query: np.ndarray, db: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, int, int]:
    """Validate query (1D) and db (2D) with matching dimensions."""
    query = _check_f32_1d(query, "query")
    db = _check_f32_2d(db, "db")
    n_vecs, dim = db.shape
    if query.shape[0] != dim:
        raise ValueError(
            f"dimension mismatch: query has {query.shape[0]} elements, "
            f"db has {dim} columns"
        )
    return query, db, dim, n_vecs


# ---------------------------------------------------------------------------
# Single-pair operations (libsimilarity)
# ---------------------------------------------------------------------------

def dot(a: np.ndarray, b: np.ndarray) -> float:
    """Dot product of two vectors. SIMD-accelerated."""
    from . import _similarity
    a, b = _check_pair(a, b)
    return _similarity.dot_f32(a, b)


def norm(a: np.ndarray) -> float:
    """L2 norm of a vector. SIMD-accelerated."""
    from . import _similarity
    a = _check_f32_1d(a, "a")
    return _similarity.norm_f32(a)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity of two vectors. SIMD-accelerated."""
    from . import _similarity
    a, b = _check_pair(a, b)
    return _similarity.cosine_f32(a, b)


def l2_squared(a: np.ndarray, b: np.ndarray) -> float:
    """Squared L2 distance between two vectors. SIMD-accelerated."""
    from . import _similarity
    a, b = _check_pair(a, b)
    return _similarity.l2_sq_f32(a, b)


# ---------------------------------------------------------------------------
# Batch operations (libsearch)
# ---------------------------------------------------------------------------

def batch_dot(query: np.ndarray, db: np.ndarray) -> np.ndarray:
    """Dot product of query against every row in db. Returns 1D float32(n,)."""
    from . import _search
    query, db, dim, n_vecs = _check_query_db(query, db)
    out = np.empty(n_vecs, dtype=np.float32)
    _search.batch_dot(query, db.ravel(), dim, n_vecs, out)
    return out


def batch_cosine(query: np.ndarray, db: np.ndarray) -> np.ndarray:
    """Cosine similarity of query against every row in db. Returns 1D float32(n,)."""
    from . import _search
    query, db, dim, n_vecs = _check_query_db(query, db)
    out = np.empty(n_vecs, dtype=np.float32)
    _search.batch_cosine(query, db.ravel(), dim, n_vecs, out)
    return out


def batch_l2(query: np.ndarray, db: np.ndarray) -> np.ndarray:
    """Squared L2 distance of query against every row in db. Returns 1D float32(n,)."""
    from . import _search
    query, db, dim, n_vecs = _check_query_db(query, db)
    out = np.empty(n_vecs, dtype=np.float32)
    _search.batch_l2(query, db.ravel(), dim, n_vecs, out)
    return out


def normalize(db: np.ndarray) -> np.ndarray:
    """L2-normalize each row of a 2D array. Returns new 2D float32(n, dim)."""
    from . import _search
    db = _check_f32_2d(db, "db")
    n_vecs, dim = db.shape
    out = np.empty_like(db)
    _search.normalize_vectors(db.ravel(), dim, n_vecs, out.ravel())
    return out


def threshold_filter(
    scores: np.ndarray, threshold: float,
) -> np.ndarray:
    """Return indices where score > threshold. Returns 1D int32."""
    from . import _search
    scores = _check_f32_1d(scores, "scores")
    n = scores.shape[0]
    out_indices = np.empty(n, dtype=np.int32)
    out_count = np.zeros(1, dtype=np.int32)
    _search.threshold_filter(scores, threshold, out_indices, out_count)
    count = int(out_count[0])
    return out_indices[:count].copy()


def top_k(
    scores: np.ndarray, k: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Find the k highest scores. Returns (values, indices) as float32 and int32."""
    from . import _search
    scores = _check_f32_1d(scores, "scores")
    n = scores.shape[0]
    if k <= 0:
        raise ValueError(f"k must be positive, got {k}")
    if k > n:
        raise ValueError(f"k ({k}) exceeds number of scores ({n})")
    work = scores.copy()
    out_values = np.empty(k, dtype=np.float32)
    out_indices = np.empty(k, dtype=np.int32)
    _search.top_k(scores, work, k, out_values, out_indices)
    return out_values, out_indices
