Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/sen6x_simpletest.py
    :caption: examples/sen6x_simpletest.py
    :linenos:
