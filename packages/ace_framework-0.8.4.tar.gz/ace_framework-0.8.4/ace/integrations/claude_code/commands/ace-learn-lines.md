Learn from the last N lines of your Claude Code session.

Use this for very long sessions where you only want to learn from recent activity.

Ask the user how many lines to analyze, then run:
```bash
ace-learn --lines <N>
```

For example, to learn from the last 500 lines:
```bash
ace-learn --lines 500
```

Show the user the output so they can see what was learned.
