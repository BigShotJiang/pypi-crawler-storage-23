Getting started
===============

Install acodex and run your first thread. These pages assume you already have a working Python
environment and access to the Codex CLI.

When to use this section
------------------------

- You are installing acodex for the first time.
- You want a minimal "hello world" to confirm the CLI + SDK work together.

.. toctree::
   :maxdepth: 2

   installation
   quickstart
