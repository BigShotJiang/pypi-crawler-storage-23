Guides
======

Focused, task-oriented documentation for common acodex workflows.

.. toctree::
   :maxdepth: 2

   streaming
   structured-output
   images
   threads-and-sessions
   safety-sandbox-approvals
   troubleshooting
