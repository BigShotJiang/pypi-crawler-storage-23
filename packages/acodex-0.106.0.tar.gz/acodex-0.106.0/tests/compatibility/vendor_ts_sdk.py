from __future__ import annotations

from tests.config import ROOT_DIR

VENDOR_TS_SDK_ROOT = ROOT_DIR / "vendor" / "codex-ts-sdk"
VENDOR_TS_SDK_SRC = VENDOR_TS_SDK_ROOT / "src"
