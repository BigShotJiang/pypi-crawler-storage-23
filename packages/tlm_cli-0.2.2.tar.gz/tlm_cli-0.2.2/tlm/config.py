"""Configuration — credential persistence + project config.

Credentials: ~/.tlm/credentials.json (chmod 600)
Project config: .tlm/config.json (per-project)
"""

import json
import os
from pathlib import Path

DEFAULT_SERVER_URL = "http://65.109.65.78:8003"
CREDENTIALS_PATH = str(Path.home() / ".tlm" / "credentials.json")


def save_credentials(server_url: str, api_key: str):
    """Save credentials to ~/.tlm/credentials.json with restricted permissions."""
    cred_path = Path(CREDENTIALS_PATH)
    cred_path.parent.mkdir(parents=True, exist_ok=True)

    data = {"server_url": server_url, "api_key": api_key}
    cred_path.write_text(json.dumps(data, indent=2))
    os.chmod(str(cred_path), 0o600)


def load_credentials() -> dict:
    """Load credentials from ~/.tlm/credentials.json. Returns {} if missing."""
    cred_path = Path(CREDENTIALS_PATH)
    if not cred_path.exists():
        return {}
    try:
        return json.loads(cred_path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def get_server_url() -> str:
    """Get server URL: env var > credentials file > default."""
    env = os.environ.get("TLM_SERVER_URL")
    if env:
        return env

    creds = load_credentials()
    if creds.get("server_url"):
        return creds["server_url"]

    return DEFAULT_SERVER_URL


def get_api_key() -> str:
    """Get API key: env var > credentials file > empty."""
    env = os.environ.get("TLM_API_KEY")
    if env:
        return env

    creds = load_credentials()
    return creds.get("api_key", "")


def save_project_config(project_root: str, config: dict):
    """Save/merge project config to .tlm/config.json."""
    config_path = Path(project_root) / ".tlm" / "config.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    existing.update(config)
    config_path.write_text(json.dumps(existing, indent=2))


def load_project_config(project_root: str) -> dict:
    """Load project config from .tlm/config.json. Returns {} if missing."""
    config_path = Path(project_root) / ".tlm" / "config.json"
    if not config_path.exists():
        return {}
    try:
        return json.loads(config_path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
