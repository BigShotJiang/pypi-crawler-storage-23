"""Tests for HTTP client — mock server responses."""

import pytest
import httpx
import respx

from tlm.client import TLMClient


@pytest.fixture
def tlm_client():
    return TLMClient(server_url="http://test-server:8000", api_key="test-key-123")


class TestTLMClient:
    @respx.mock
    @pytest.mark.asyncio
    async def test_assess_returns_recommendations(self, tlm_client):
        """assess() should return recommendations list."""
        respx.post("http://test-server:8000/api/v2/projects/1/assess").mock(
            return_value=httpx.Response(200, json={
                "recommendations": [
                    {"id": "cicd", "type": "cicd", "category": "CI/CD",
                     "severity": "critical", "description": "No CI/CD", "fixable": True}
                ],
                "profile": {"stack": "Python"},
            })
        )

        result = await tlm_client.assess(1, "file_tree", "samples")
        assert "recommendations" in result
        assert len(result["recommendations"]) == 1
        assert result["recommendations"][0]["id"] == "cicd"

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_interview_returns_questions(self, tlm_client):
        """get_interview() should return questions list."""
        respx.post(
            "http://test-server:8000/api/v2/projects/1/recommendations/cicd/interview"
        ).mock(
            return_value=httpx.Response(200, json={
                "questions": [
                    {"id": "deploy", "question": "Where?",
                     "options": ["AWS"], "default": "AWS", "context": ""}
                ],
                "intro": "Let's set up CI/CD.",
            })
        )

        result = await tlm_client.get_interview(1, "cicd", {}, "standard")
        assert "questions" in result
        assert len(result["questions"]) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_build_context_returns_prompt(self, tlm_client):
        """build_context() should return system_prompt and instructions."""
        respx.post(
            "http://test-server:8000/api/v2/projects/1/recommendations/cicd/context"
        ).mock(
            return_value=httpx.Response(200, json={
                "system_prompt": "You are setting up CI/CD.",
                "instructions": "Create workflow files.",
                "constraints": ["No hardcoded secrets"],
            })
        )

        result = await tlm_client.build_context(1, "cicd", {"deploy": "AWS"}, {}, "standard")
        assert "system_prompt" in result
        assert "instructions" in result
        assert len(result["system_prompt"]) > 0

    @respx.mock
    @pytest.mark.asyncio
    async def test_review_plan_returns_verdict(self, tlm_client):
        """review_plan() should return verdict and feedback."""
        respx.post(
            "http://test-server:8000/api/v2/projects/1/recommendations/cicd/review"
        ).mock(
            return_value=httpx.Response(200, json={
                "verdict": "pass",
                "feedback": [],
                "models_used": ["claude"],
            })
        )

        result = await tlm_client.review_plan(1, "cicd", "plan output", {}, "standard")
        assert result["verdict"] == "pass"
        assert "feedback" in result

    @respx.mock
    @pytest.mark.asyncio
    async def test_client_sends_auth_header(self, tlm_client):
        """Client should send Authorization header."""
        route = respx.post("http://test-server:8000/api/v2/projects/1/assess").mock(
            return_value=httpx.Response(200, json={"recommendations": [], "profile": {}})
        )

        await tlm_client.assess(1, "tree", "samples")
        assert route.called
        req = route.calls[0].request
        assert req.headers["Authorization"] == "Bearer test-key-123"

    @respx.mock
    @pytest.mark.asyncio
    async def test_client_handles_error_response(self, tlm_client):
        """Client should raise on error responses."""
        respx.post("http://test-server:8000/api/v2/projects/1/assess").mock(
            return_value=httpx.Response(500, json={"detail": "Server error"})
        )

        with pytest.raises(httpx.HTTPStatusError):
            await tlm_client.assess(1, "tree", "samples")


class TestClientV1Methods:
    """Tests for V1 API methods added to the client."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_create_project(self, tlm_client):
        """create_project() should POST to /api/v1/projects."""
        respx.post("http://test-server:8000/api/v1/projects").mock(
            return_value=httpx.Response(200, json={
                "project_id": 42,
                "name": "my-project",
                "fingerprint": "abc123",
            })
        )

        result = await tlm_client.create_project("my-project", "abc123")
        assert result["project_id"] == 42
        assert result["name"] == "my-project"

    @respx.mock
    @pytest.mark.asyncio
    async def test_me(self, tlm_client):
        """me() should GET /api/v1/auth/me."""
        respx.get("http://test-server:8000/api/v1/auth/me").mock(
            return_value=httpx.Response(200, json={
                "user_id": "user_1",
                "email": "test@example.com",
            })
        )

        result = await tlm_client.me()
        assert result["user_id"] == "user_1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_scan_v1(self, tlm_client):
        """scan() should POST to /api/v1/projects/{id}/scan."""
        respx.post("http://test-server:8000/api/v1/projects/1/scan").mock(
            return_value=httpx.Response(200, json={
                "gaps": [{"id": "cicd", "severity": "critical"}],
                "profile": {"stack": "Python"},
            })
        )

        result = await tlm_client.scan(1, "file_tree_data", "samples_data")
        assert "gaps" in result

    @respx.mock
    @pytest.mark.asyncio
    async def test_review_code(self, tlm_client):
        """review_code() should POST to /api/v2/review/code."""
        respx.post("http://test-server:8000/api/v2/review/code").mock(
            return_value=httpx.Response(200, json={
                "combined_verdict": "pass",
                "reviews": [],
                "models_used": ["claude"],
            })
        )

        result = await tlm_client.review_code(
            project_id=1,
            spec="spec content",
            code="diff content",
            files_changed=["app.py"],
        )
        assert result["combined_verdict"] == "pass"

    @respx.mock
    @pytest.mark.asyncio
    async def test_review_spec(self, tlm_client):
        """review_spec() should POST to /api/v2/review/spec."""
        respx.post("http://test-server:8000/api/v2/review/spec").mock(
            return_value=httpx.Response(200, json={
                "severity": "pass",
                "gaps": [],
                "models_used": ["claude"],
            })
        )

        result = await tlm_client.review_spec(
            project_id=1,
            spec="spec content",
            project_knowledge="rules",
            quality_level="high",
        )
        assert result["severity"] == "pass"


class TestFirebaseTokenExchange:
    """Tests for Firebase token exchange (unauthenticated endpoint)."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_exchange_firebase_token(self):
        """exchange_firebase_token() should POST to /api/v1/auth/firebase and return API key."""
        client = TLMClient(server_url="http://test-server:8000", api_key="")

        respx.post("http://test-server:8000/api/v1/auth/firebase").mock(
            return_value=httpx.Response(200, json={
                "api_key": "tlm_sk_abc123",
                "user_id": 1,
                "email": "user@example.com",
            })
        )

        result = await client.exchange_firebase_token("eyJhbGciOi.payload.signature")
        assert result["api_key"] == "tlm_sk_abc123"
        assert result["user_id"] == 1
        assert result["email"] == "user@example.com"

    @respx.mock
    @pytest.mark.asyncio
    async def test_no_auth_header_on_exchange(self):
        """exchange_firebase_token() should NOT send Authorization header."""
        client = TLMClient(server_url="http://test-server:8000", api_key="")

        route = respx.post("http://test-server:8000/api/v1/auth/firebase").mock(
            return_value=httpx.Response(200, json={
                "api_key": "tlm_sk_abc123",
                "user_id": 1,
                "email": "user@example.com",
            })
        )

        await client.exchange_firebase_token("eyJhbGciOi.payload.signature")
        req = route.calls[0].request
        assert "Authorization" not in req.headers

    @respx.mock
    @pytest.mark.asyncio
    async def test_exchange_invalid_token(self):
        """exchange_firebase_token() should raise on server error (invalid token)."""
        client = TLMClient(server_url="http://test-server:8000", api_key="")

        respx.post("http://test-server:8000/api/v1/auth/firebase").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid Firebase token"})
        )

        with pytest.raises(httpx.HTTPStatusError):
            await client.exchange_firebase_token("bad-token")
