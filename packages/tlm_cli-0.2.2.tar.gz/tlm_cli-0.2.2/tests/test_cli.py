"""Tests for CLI — auth, install, scan, gaps, check, _hook commands."""

import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main, _is_firebase_token, AUTH_URL


class TestIsFirebaseToken:
    def test_detects_firebase_jwt(self):
        """3-part dot-separated token >100 chars should be detected as Firebase."""
        # Realistic Firebase JWT structure (header.payload.signature)
        token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        assert _is_firebase_token(token) is True

    def test_rejects_tlm_api_key(self):
        """tlm_sk_ prefixed keys should NOT be detected as Firebase."""
        assert _is_firebase_token("tlm_sk_abc123") is False

    def test_rejects_short_token(self):
        """Short tokens should NOT be detected as Firebase."""
        assert _is_firebase_token("short.but.jwt") is False


class TestAuthCommand:
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_direct_api_key(self, mock_client_cls, mock_save):
        """tlm auth <tlm_sk_...> should verify and save directly."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_abc123"])

        assert result.exit_code == 0
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_firebase_exchange(self, mock_client_cls, mock_save):
        """tlm auth <firebase_jwt> should exchange for API key and save."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(return_value={
            "api_key": "tlm_sk_exchanged",
            "user_id": 1,
            "email": "user@example.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code == 0
        assert "user@example.com" in result.output
        mock_client.exchange_firebase_token.assert_called_once_with(firebase_token)
        # Should save the exchanged API key, not the Firebase token
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_exchanged"

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_interactive_prompt(self, mock_client_cls, mock_save):
        """tlm auth (no args) should show URL and prompt for token."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input="tlm_sk_from_prompt\n")

        assert result.exit_code == 0
        assert AUTH_URL in result.output
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_interactive_firebase(self, mock_client_cls, mock_save):
        """Interactive mode: pasting a Firebase JWT should exchange it."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(return_value={
            "api_key": "tlm_sk_interactive",
            "user_id": 1,
            "email": "firebase@x.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input=firebase_token + "\n")

        assert result.exit_code == 0
        assert "firebase@x.com" in result.output
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_interactive"

    def test_auth_invalid_token(self):
        """tlm auth <garbage> should show error."""
        runner = CliRunner()
        result = runner.invoke(main, ["auth", "not-a-valid-token"])

        assert result.exit_code != 0
        assert "invalid" in result.output.lower()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_custom_server(self, mock_client_cls, mock_save):
        """tlm auth --server should use custom server URL."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_key", "--server", "http://custom:9000"])

        assert result.exit_code == 0
        save_call = mock_save.call_args
        assert save_call[0][0] == "http://custom:9000"

    @patch("tlm.cli.TLMClient")
    def test_auth_exchange_failure(self, mock_client_cls):
        """Firebase exchange failure should show error."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(
            side_effect=Exception("Invalid Firebase token")
        )
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code != 0
        assert "failed" in result.output.lower()


class TestInstallCommand:
    @patch("tlm.cli.Installer")
    def test_install_runs_full_flow(self, mock_installer_cls, tmp_path):
        """tlm install should run scan → assess → quality → gaps → hooks."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        # Input: quality tier choice + gap handling (yes/no/choose)
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="\nn\n")

        assert result.exit_code == 0
        mock_installer.init_project_dir.assert_called_once()
        mock_installer.scan_project.assert_called_once()
        mock_installer.assess.assert_called_once()
        mock_installer.install_hooks.assert_called_once()
        mock_installer.finalize.assert_called_once()


class TestScanCommand:
    @patch("tlm.cli.Installer")
    def test_scan_shows_recommendations(self, mock_installer_cls, tmp_path):
        """tlm scan should display recommendations."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD pipeline", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output


class TestGapsCommand:
    def test_gaps_shows_active_gaps(self, tmp_path):
        """tlm gaps should show active gaps."""
        from tlm.gaps import add_gap
        from tlm.state import write_state

        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output

    def test_gaps_no_gaps(self, tmp_path):
        """tlm gaps should show message when no gaps."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "no" in result.output.lower() or "clean" in result.output.lower()


class TestHookCommand:
    def test_hook_session_start(self, tmp_path):
        """_hook session_start should call hook_session_start."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "session_start", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_prompt_submit(self, tmp_path):
        """_hook prompt_submit should return JSON."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "prompt_submit", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_guard(self, tmp_path):
        """_hook guard should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "guard", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0

    def test_hook_compliance(self, tmp_path):
        """_hook compliance should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({"command": "python -m pytest tests/"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "compliance", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0
