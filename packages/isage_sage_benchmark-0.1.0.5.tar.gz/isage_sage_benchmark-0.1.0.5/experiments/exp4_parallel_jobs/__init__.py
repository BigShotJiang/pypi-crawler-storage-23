"""
Experiment 4: Parallel Jobs Execution
======================================

Tests SAGE's ability to execute multiple pipelines concurrently.
"""
