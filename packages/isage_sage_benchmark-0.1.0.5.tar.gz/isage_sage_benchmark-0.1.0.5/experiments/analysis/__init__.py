"""Analysis utilities for benchmark result aggregation and reporting."""
