import urllib.request
import json


def check_latest_version(current_version: str):
    try:
        url = "https://pypi.org/pypi/dracula-ai/json"

        with urllib.request.urlopen(url, timeout=3) as response:
            data = json.loads(response.read().decode())
            latest_version = data["info"]["version"]

        if latest_version != current_version:
            print(
                f"\n⚠️  A new version of Dracula is available: "
                f"v{latest_version} (you have v{current_version})\n"
                f"   Upgrade with: pip install --upgrade dracula-ai\n"
            )

    except Exception:
        pass
