import npc_ephys


def test_import_package():
    pass
