#!/usr/bin/env python3

"""
@author: xi, liying50
"""

import math
from dataclasses import dataclass, field
import os
from collections import defaultdict
from typing import *

import cv2 as cv
import numpy as np
import torch
import torchvision
from loguru import logger
import visioncube as cube

from .hub import get_dir
from .alignment import  AlignmentOutput, LocalizationOutput
from .functional.imageio import chw_to_hwc
from ultralytics.models.sam import SAM2DynamicInteractivePredictor


MODEL_WEIGHT = {
    "tiny": "sam2.1_t.pt",
    "small": "sam2.1_s.pt",
    "base": "sam2.1_b.pt",
    "large": "sam2.1_l.pt",
}


@dataclass
class LocalizationConfig:
    template_path: str = None
    train_pts: Sequence[Sequence] = field(default_factory=list)  # [(x1, y1), (x2, y2), ...]
    roi_list: Sequence[Sequence] = field(default_factory=list)  # [[(x1, y1), (x2, y2)], ...]
    # target_list: Sequence[str] = field(default_factory=list)
    ignore_list: Sequence[Sequence] = field(default_factory=list)  # [[(x1, y1), (x2, y2), ...], ...]
    match_ignore_list: Sequence[Sequence] = field(default_factory=list)  # [[(x1, y1), (x2, y2), ...], ...]
    focus_list: Sequence[Sequence] = field(default_factory=list)  # [[(x1, y1), (x2, y2), ...], ...]
    model_size: str = field(default="tiny")  # 分割模型大小 (tiny, small, base, large)
    threshold: float = field(default=0.01)  # 推理结果的置信度阈值
    img_size: int = field(default=1024)  # 输入模型的图片大小
    use_mask: bool = field(default=True)  # 是否使用掩码
    use_image_width: bool = field(default=False)  # 是否使用图像宽度作为参考
    use_image_height: bool = field(default=False)  # 是否使用图像高度作为参考


class AbstractAlignment(object):
    """Abstract alignment
    """

    def __call__(self, image: np.ndarray) -> AlignmentOutput:
        raise NotImplementedError()


class SAM2TemplateMatching(AbstractAlignment):

    def __init__(
            self,
            template: np.ndarray,
            initial_bboxes,  # template标注 : List[List[int]]
            config: LocalizationConfig,
    ) -> None:
        self.config = config
        
        self.initial_bboxes = []
        for bbox in initial_bboxes:
            if isinstance(bbox, np.ndarray):
                self.initial_bboxes.append(list(bbox.flatten()))
            elif isinstance(bbox, tuple):
                self.initial_bboxes.append(list(bbox))
            else:
                self.initial_bboxes.append(bbox)
        if config.model_size not in MODEL_WEIGHT:
            raise ValueError(f"model_size {config.model_size} not in {MODEL_WEIGHT}")
        model_name = MODEL_WEIGHT[config.model_size]
        model_path = os.path.join(get_dir(), "sam2", model_name)
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"model_path {model_path} not found")

        # 初始化SAM2模型
        overrides = dict(
            conf=config.threshold, task="segment", mode="predict", 
            imgsz=config.img_size, model=model_path, save=False
        )
        self.predictor = SAM2DynamicInteractivePredictor(
            overrides=overrides, 
            max_obj_num=len(self.initial_bboxes)
        )
        
        # 预处理模板
        template = self._pre_process(template)

        # 初始化SAM2预测器
        obj_ids = [i for i in range(len(self.initial_bboxes))]
        self.predictor(
            source=template,
            bboxes=self.initial_bboxes,
            obj_ids=obj_ids,
            update_memory=True
        )

    def _pre_process(self, image: np.ndarray) -> np.ndarray:
        if len(image.shape) == 3:
            if image.shape[-1] != 3:
                raise ValueError(f'Invalid image shape {image.shape}.')
        elif len(image.shape) != 2:
            raise ValueError(f'Invalid image shape {image.shape}.')
        return image
    
    def masking_image(self, mask: torch.Tensor, image: np.ndarray) -> np.ndarray:
        mask = mask.cpu().numpy()   # [1, H, W]
        mask = chw_to_hwc(mask)    # [H, W, 1]
        img_3channel = np.repeat(mask, 3, axis=2)  # [H, W, 3]
        return img_3channel * image

    def __call__(self, image: np.ndarray):
        results = self.predictor(source=image)
        index_map = defaultdict(list)
        data = results[0]

        if self.config.use_mask:
            mask_image = self.masking_image(data.masks.data, image)
        else:
            mask_image = image

        boxes = data.boxes
        for cls, conf, bbox, polygon in zip(boxes.cls, boxes.conf, boxes.xyxy, data.masks.xy):
            cls = int(cls.item())
            conf = float(conf.item())
            bbox = list(map(int, bbox.cpu().numpy()))
            polygons = []
            for p in polygon:
                polygons.append([int(p[0]) - bbox[0], int(p[1]) - bbox[1]])
            index_map[cls].append((conf, bbox, polygons))
        
        boxes = []
        for i, bbox in enumerate(self.initial_bboxes):
            data = index_map[i]
            if len(data) == 0:
                logger.warning(f'No bbox found for class {i}, using initial bbox')
                data = [(1, bbox, None)]
            
            for conf, bbox, polygon in data:
                if not self.config.use_mask:
                    polygon = None
                boxes.append({'bbox': bbox, 'score': conf, 'class': i, 'polygon': polygon})
            
        return {
            'mask': mask_image,
            'boxes': boxes,
        }

def coord_transform(
        pts: List[List[int]],
        homography: np.ndarray,
) -> List[List[int]]:
    pts = np.float32([pts])
    dst_pts = cv.perspectiveTransform(pts, homography)[0]
    return dst_pts.astype(int).tolist()


class Localization:
    """Localization"""

    def __init__(self, config: LocalizationConfig):
        self.config = config
        if config.use_mask and (config.use_image_height or config.use_image_width):
            # 当有候选区时，在使用遮罩，而后在使用图像高度或宽度时，会导致结果错乱，因此抛出异常
            # 同时，使用图像高度或宽度时，如果有候选区，剔除区和保留区也会错乱。
            # 以上两个问题，因为遮罩、保留区、候选区是针对配准出的区域生效的，而使用图像宽度或高度会导致超过配准区域
            raise ValueError('Cannot use mask with image height or width.')

        self.roi_list = []
        for bbox in self.config.roi_list:
            try:
                bbox_np = np.asarray(bbox, dtype=np.int64).reshape((2, 2))
            except:
                raise ValueError(f'Invalid ROI definition {bbox}.')
            self.roi_list.append(bbox_np)
        if len(self.roi_list) == 0:
            self.roi_list = [None]
        
        train_pts = []
        for pt in self.config.train_pts:
            train_pts.append(np.asarray(pt, dtype=np.int64).reshape((2, 2)))

        self.sam2 = None
        if config.template_path is not None and os.path.exists(config.template_path) and train_pts:
            tamplate_img = cube.read_image(config.template_path)
            self.sam2: AbstractAlignment = SAM2TemplateMatching(
                template=tamplate_img,
                initial_bboxes=train_pts,
                config=self.config
            )
        self.ignore_list = []
        for poly in self.config.ignore_list:
            try:
                poly_np = np.asarray(poly, dtype=np.int64).reshape((-1, 2))
            except:
                raise ValueError(f'Invalid "ignore area" definition {poly}.')
            self.ignore_list.append(poly_np)

        self.focus_list = []
        for poly in self.config.focus_list:
            poly_np = np.asarray(poly, dtype=np.int64)
            if len(poly_np.shape) != 2 or poly_np.shape[-1] != 2:
                raise ValueError(f'Invalid "focus area" definition {poly}.')
            self.focus_list.append(poly_np)

    def _crop_from_roi(self, image: np.ndarray, roi_coord: Optional[np.ndarray] = None) -> LocalizationOutput:
        if roi_coord is not None:
            x1, y1, x2, y2 = roi_coord.ravel().tolist()
            y1 = min(max(0, y1), image.shape[0])
            y2 = min(max(0, y2), image.shape[0])
            x1 = min(max(0, x1), image.shape[1])
            x2 = min(max(0, x2), image.shape[1])
            y1, y2 = min(y1, y2), max(y1, y2)
            x1, x2 = min(x1, x2), max(x1, x2)
            roi = image[y1:y2, x1:x2, ...]
        else:
            x1, y1 = 0, 0
            y2, x2 = image.shape[:2]
            roi = image
        roi_data = [{'bbox': [x1, y1, x2, y2], 'score': 1, 'class': -1, 'polygon': None}]
        if self.sam2 is not None:
            output = self.sam2(image=roi)
            if self.config.use_mask:
                image = output['mask']
            for boxes in output['boxes']:
                # 得到的bbox 是基于roi 的，需要转换到原图
                bbox = boxes.get("bbox")
                bbox[0] += x1
                bbox[1] += y1
                bbox[2] += x1
                bbox[3] += y1
            roi_data = output['boxes']
        results = []
        for r_d in roi_data:
            x1, y1, x2, y2 = r_d['bbox']
            if self.config.use_image_width:
                x1, x2 = 0, image.shape[1]
            if self.config.use_image_height:
                y1, y2 = 0, image.shape[0]
            result = LocalizationOutput()
            roi = image[y1:y2, x1:x2, ...]
            result.crop = roi
            result.homography = np.array([
                [1, 0, x1],
                [0, 1, y1],
                [0, 0, 1]
            ], np.float32)
                
            pts = [
                [0, 0],
                [0, result.crop.shape[0]],
                [result.crop.shape[1], result.crop.shape[0]],
                [result.crop.shape[1], 0]
            ]

            result.roi = coord_transform(pts, result.homography)
            result.polygon = r_d['polygon']
            result.crop = self.masking_image(result.crop, self.ignore_list, self.focus_list)
            results.append(result)
        return results

    @staticmethod
    def masking_image(
            image: np.ndarray,
            ignore_list: List[np.ndarray],
            focus_list: List[np.ndarray]
    ) -> np.ndarray:
        masks = []

        if ignore_list is not None and len(ignore_list) > 0:
            mask_0 = np.ones(image.shape[:2], dtype=np.uint8)
            for poly in ignore_list:
                assert isinstance(poly, np.ndarray)
                assert len(poly.shape) == 2 and poly.shape[1] == 2
                cv.fillPoly(mask_0, [poly], color=0)
            masks.append(mask_0)

        if focus_list is not None and len(focus_list) > 0:
            mask_1 = np.zeros(image.shape[:2], dtype=np.uint8)
            for poly in focus_list:
                assert isinstance(poly, np.ndarray)
                assert len(poly.shape) == 2 and poly.shape[1] == 2
                cv.fillPoly(mask_1, [poly], color=1)
            masks.append(mask_1)

        if len(masks) == 0:
            return image
        else:
            mask = np.logical_and(masks[0], masks[1]) if len(masks) > 1 else masks[0]
            if len(image.shape) == 3:
                mask = np.stack([mask] * 3, axis=-1)
            return image * mask

    def __call__(self, image: np.ndarray) -> List[LocalizationOutput]:
        results = []
        for roi_coord in self.roi_list:
            results.extend(self._crop_from_roi(image, roi_coord))
        return results
