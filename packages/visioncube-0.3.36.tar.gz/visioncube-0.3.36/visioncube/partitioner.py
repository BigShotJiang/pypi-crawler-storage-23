import math
from typing import Sequence, Tuple, List, Optional
from enum import Enum
from dataclasses import dataclass


class SplitStrategy(Enum):
    """拆分策略枚举"""
    AUTO = "auto"          # 自动推荐策略
    FIXED = "fixed"        # 固定窗口大小
    DYNAMIC = "dynamic"    # 动态调整窗口大小
    STRICT = "strict"      # 严格按指定窗口拆分，不足部分裁剪


@dataclass
class SplitResult:
    """拆分结果"""
    windows: List[Tuple[int, int, int]]  # (start, end, overlap)
    strategy: SplitStrategy
    window_size: int
    overlap: int
    overlap_ratio: float
    num_windows: int


class SlidingWindow:
    """图片滑动窗口切分器"""
    
    def __init__(
        self, 
        win_size: Optional[int] = None,
        overlap_ratio: float = 0.05,
        min_win_size: int = 64,
        max_win_size: int = 10240,
        strategy: SplitStrategy = SplitStrategy.AUTO.value
    ):
        """
        初始化滑动窗口切分器
        
        Args:
            win_size: 窗口大小，为None时使用自动推荐
            overlap_ratio: 重叠比例 (0-1)
            min_win_size: 最小窗口大小
            max_win_size: 最大窗口大小
        """
        self.win_size = win_size
        self.overlap_ratio = max(0.0, min(0.5, overlap_ratio))  # 限制在0-0.5之间
        self.min_win_size = min_win_size
        self.max_win_size = max_win_size
        self.strategy = strategy
        
    def __call__(
        self, 
        size: int, 
        strategy: Optional[SplitStrategy] = None
    ) -> SplitResult:
        """
        执行切分
        
        Args:
            size: 原图大小
            strategy: 拆分策略，如果为None则使用初始化时的策略
            
        Returns:
            SplitResult: 拆分结果
        """
        use_strategy = strategy or self.strategy
        
        # 确定使用的窗口大小
        if self.win_size is None:
            win_size = self._suggest_win_size(size)
        else:
            win_size = self._clamp_win_size(min(self.win_size, size))
        
        # 根据策略选择切分方法
        if use_strategy == SplitStrategy.FIXED.value:
            return self._fixed_split(size, win_size)
        elif use_strategy == SplitStrategy.DYNAMIC.value:
            return self._dynamic_split(size, win_size)
        elif use_strategy == SplitStrategy.STRICT.value:
            return self._strict_split(size, win_size)
        else:  # AUTO or default
            return self._auto_split(size, win_size)
    
    def _clamp_win_size(self, win_size: int) -> int:
        """限制窗口大小在合理范围内"""
        return max(self.min_win_size, min(win_size, self.max_win_size))
    
    def _suggest_win_size(self, size: int) -> int:
        """自动推荐窗口大小"""
        if size <= self.max_win_size:
            # 如果图像小于最大窗口，使用图像大小或合适的倍数
            suggested = size
        else:
            # 寻找最接近的2的幂次方或黄金分割比例
            golden_ratio = 0.618
            suggested = int(size * golden_ratio)
        
        # 调整为8的倍数（对齐处理）
        suggested = ((suggested + 7) // 8) * 8
        return self._clamp_win_size(min(suggested, size))
    
    def _fixed_split(self, size: int, win_size: int) -> SplitResult:
        """固定窗口大小切分策略"""
        overlap = int(win_size * self.overlap_ratio)
        
        if size <= win_size:
            return SplitResult(
                windows=[(0, size, 0)],
                strategy=SplitStrategy.FIXED.value,
                window_size=win_size,
                overlap=0,
                overlap_ratio=self.overlap_ratio,
                num_windows=1
            )
        
        # 计算固定步长
        step = win_size - overlap
        num_windows = max(1, (size - overlap + step - 1) // step)
        
        windows = []
        for i in range(num_windows):
            start = min(i * step, max(0, size - win_size))
            end = min(start + win_size, size)
            actual_overlap = max(0, start - windows[-1][1] if windows else 0)
            windows.append((start, end, actual_overlap))
        
        return SplitResult(
            windows=windows,
            strategy=SplitStrategy.FIXED.value,
            window_size=win_size,
            overlap=overlap,
            overlap_ratio=self.overlap_ratio,
            num_windows=len(windows)
        )
    
    def _dynamic_split(self, size: int, win_size: int) -> SplitResult:
        """动态重叠：固定拆分尺寸，根据图片尺寸动态调整重叠区域大小"""
        if size <= win_size:
            return SplitResult(
                windows=[(0, size, 0)],
                strategy=SplitStrategy.DYNAMIC.value,
                window_size=win_size,
                overlap=0,
                overlap_ratio=self.overlap_ratio,
                num_windows=1
            )
        # 计算最优窗口数量（向上取整确保覆盖）
        num_windows = max(2, math.ceil(size / win_size))
        
        # 计算均匀分布的步长（浮点数）
        step = (size - win_size) / (num_windows - 1)
        theoretical_overlap = win_size - step  # 理论重叠值（可能为小数）
        
        windows = []
        for i in range(num_windows):
            # 计算理论起始位置并四舍五入取整
            start = int(round(i * step))
            end = start + win_size
            
            # 最后一个窗口强制对齐到图像末尾
            if i == num_windows - 1:
                start = size - win_size
                end = size
            
            # 计算实际重叠（与前一个窗口）
            actual_overlap = 0
            if i > 0:
                prev_end = windows[-1][1]
                actual_overlap = max(0, prev_end - start)  # 重叠区域 = 前窗口结束 - 当前窗口开始
            
            windows.append((start, end, actual_overlap))
        
        # 返回整数化的理论重叠值（用于参考）
        overlap = max(0, int(round(theoretical_overlap)))
        
        return SplitResult(
            windows=windows,
            strategy=SplitStrategy.DYNAMIC,
            window_size=win_size,
            overlap=overlap,
            overlap_ratio=round(overlap / win_size, 2),
            num_windows=num_windows
        )
    
    def _strict_split(self, size: int, win_size: int) -> SplitResult:
        """严格裁剪：固定拆分尺寸和重叠区域，不足部分裁剪"""
        overlap = int(win_size * self.overlap_ratio)
        
        # 计算步长
        step = win_size - overlap
        
        # 计算可以完整拆分的数量
        num_windows = max(1, (size - overlap) // step)
        
        windows = []
        for i in range(num_windows):
            start = i * step
            end = start + win_size
            
            # 如果超出边界，跳过这个窗口（裁剪）
            if end > size:
                continue
                
            windows.append((start, end, overlap))
        
        return SplitResult(
            windows=windows,
            strategy=SplitStrategy.STRICT.value,
            window_size=win_size,
            overlap=overlap,
            overlap_ratio=self.overlap_ratio,
            num_windows=len(windows)
        )
    
    def _auto_split(self, size: int, win_size: int) -> SplitResult:
        """
        size: 原图大小
        """
        if size <= win_size:
            return SplitResult(
                windows=[(0, size, 0)],
                strategy=SplitStrategy.AUTO.value,
                window_size=win_size,
                overlap=0,
                overlap_ratio=self.overlap_ratio,
                num_windows=1
            )

        overlap = int(win_size * self.overlap_ratio)
        num_wins = math.floor((size - win_size)/(win_size - overlap) + 0.5) + 1
        total = win_size + (num_wins - 1) * (win_size - overlap)
        remains = size - total
        if remains == 0:
            num_big_overlaps = total - size
            num_small_overlaps = num_wins - 1
        elif remains > 0:
            win_size += math.ceil(remains / num_wins)
            total = win_size + (num_wins - 1) * (win_size - overlap)
            num_big_overlaps = total - size
            num_small_overlaps = num_wins - 1 - num_big_overlaps
        else:
            win_size -= math.floor(-remains / num_wins)
            total = win_size + (num_wins - 1) * (win_size - overlap)
            num_big_overlaps = total - size
            num_small_overlaps = num_wins - 1 - num_big_overlaps

        overlaps = [overlap + 1] * num_big_overlaps + \
            [overlap] * num_small_overlaps
        win_list = [(0, win_size, 0)]
        pos = win_size
        for i in range(num_wins - 1):
            pos -= overlaps[i]
            win_list.append((pos, pos + win_size, overlaps[i]))
            pos += win_size
        return SplitResult(
            windows=win_list,
            strategy=SplitStrategy.AUTO.value,
            window_size=win_size,
            overlap=overlap,
            overlap_ratio=self.overlap_ratio,
            num_windows=len(win_list)
        )
    
    @classmethod
    def build_with_suggestion(
        cls,
        height: int,
        width: int,
        max_size: int,
        overlap_ratio: float = 0.05,
        strategy: SplitStrategy = SplitStrategy.AUTO.value
    ) -> Tuple[Optional['SlidingWindow'], Optional['SlidingWindow']]:
        """
        根据图像尺寸和最大限制推荐切分策略
        
        Args:
            height: 图像高度
            width: 图像宽度
            max_size: 最大窗口大小（面积或边长）
            overlap_ratio: 重叠比例
            strategy: 拆分策略
            
        Returns:
            Tuple[Optional[SlidingWindow], Optional[SlidingWindow]]: 高度和宽度方向的切分器
        """
        max_area = max_size * max_size
        
        if height * width < max_area:
            # 图像面积小于最大限制，无需切分
            return None, None
        
        # 计算推荐窗口大小
        def get_window_size(dim: int, other_dim: int) -> int:
            if dim < max_size:
                return dim
            elif other_dim < max_size:
                # 如果另一维度较小，使用面积约束
                return min(max_size, max_area // other_dim)
            else:
                return max_size
        
        win_h = get_window_size(height, width)
        win_w = get_window_size(width, height)
        
        # 创建切分器
        h_splitter = SlidingWindow(
            win_size=win_h,
            overlap_ratio=overlap_ratio,
            min_win_size=64,
            max_win_size=max_size,
            strategy=strategy
        )
        
        w_splitter = SlidingWindow(
            win_size=win_w,
            overlap_ratio=overlap_ratio,
            min_win_size=64,
            max_win_size=max_size,
            strategy=strategy
        )
        
        return h_splitter, w_splitter
    
    @classmethod
    def create_2d_splitter(
        cls,
        height: int,
        width: int,
        win_size: int,
        overlap_ratio: float = 0.05,
        strategy: SplitStrategy = SplitStrategy.AUTO.value
    ) -> Tuple['SlidingWindow', 'SlidingWindow']:
        """
        创建二维切分器
        
        Args:
            height: 图像高度
            width: 图像宽度
            win_size: 窗口大小
            overlap_ratio: 重叠比例
            strategy: 拆分策略
            
        Returns:
            Tuple[SlidingWindow, SlidingWindow]: 高度和宽度方向的切分器
        """
        h_splitter = cls(
            win_size=min(win_size, height),
            overlap_ratio=overlap_ratio,
            strategy=strategy
        )
        
        w_splitter = cls(
            win_size=min(win_size, width),
            overlap_ratio=overlap_ratio,
            strategy=strategy
        )
        
        return h_splitter, w_splitter
    
    def split_2d(
        self,
        height: int,
        width: int,
        h_splitter: 'SlidingWindow',
        w_splitter: 'SlidingWindow',
        strategy: Optional[SplitStrategy] = None
    ) -> List[Tuple[int, int, int, int, int, int]]:
        """
        执行二维切分
        
        Returns:
            List[Tuple[int, int, int, int, int, int]]: 
            (h_start, h_end, h_overlap, w_start, w_end, w_overlap)
        """
        h_result = h_splitter(height, strategy)
        w_result = w_splitter(width, strategy)
        
        windows_2d = []
        for h_start, h_end, h_overlap in h_result.windows:
            for w_start, w_end, w_overlap in w_result.windows:
                windows_2d.append((
                    h_start, h_end, h_overlap,
                    w_start, w_end, w_overlap
                ))
        
        return windows_2d


# 使用示例
if __name__ == "__main__":
    # 测试不同策略
    test_size = 1500
    
    print("=== 测试不同拆分策略 ===")
    
    # 1. 自动推荐策略
    splitter = SlidingWindow(overlap_ratio=0.1, strategy=SplitStrategy.AUTO.value)
    result = splitter(test_size)
    print(f"\n自动推荐策略:")
    print(f"  窗口大小: {result.window_size}")
    print(f"  重叠大小: {result.overlap}")
    print(f"  窗口数量: {result.num_windows}")
    print(f"  第一个窗口: {result.windows[0]}")
    print(f"  最后一个窗口: {result.windows[-1]}")
    
    # 2. 固定尺寸策略
    splitter = SlidingWindow(win_size=512, overlap_ratio=0.1, strategy=SplitStrategy.FIXED.value)
    result = splitter(test_size)
    print(f"\n固定尺寸策略:")
    print(f"  窗口大小: {result.window_size}")
    print(f"  重叠大小: {result.overlap}")
    print(f"  窗口数量: {result.num_windows}")
    print(f"  第一个窗口: {result.windows[0]}")
    print(f"  最后一个窗口: {result.windows[-1]}")
    
    # 3. 严格裁剪策略
    splitter = SlidingWindow(win_size=512, overlap_ratio=0.1, strategy=SplitStrategy.STRICT.value)
    result = splitter(test_size)
    print(f"\n严格裁剪策略:")
    print(f"  窗口大小: {result.window_size}")
    print(f"  重叠大小: {result.overlap}")
    print(f"  窗口数量: {result.num_windows}")
    if result.windows:
        print(f"  第一个窗口: {result.windows[0]}")
        print(f"  最后一个窗口: {result.windows[-1]}")
    
    # 4. 动态重叠策略
    splitter = SlidingWindow(win_size=512, overlap_ratio=0.1, strategy=SplitStrategy.DYNAMIC.value)
    result = splitter(test_size)
    print(f"\n动态重叠策略:")
    print(f"  窗口大小: {result.window_size}")
    print(f"  重叠大小: {result.overlap}")
    print(f"  窗口数量: {result.num_windows}")
    print(f"  第一个窗口: {result.windows[0]}")
    print(f"  最后一个窗口: {result.windows[-1]}")
    
    # 二维切分示例
    print("\n=== 二维切分示例 ===")
    h_splitter, w_splitter = SlidingWindow.build_with_suggestion(
        height=800,
        width=1200,
        max_size=512,
        overlap_ratio=0.1,
        strategy=SplitStrategy.AUTO.value
    )
    
    if h_splitter and w_splitter:
        windows_2d = SlidingWindow().split_2d(
            height=800,
            width=1200,
            h_splitter=h_splitter,
            w_splitter=w_splitter
        )
        print(f"二维切分: {len(windows_2d)} 个窗口")
        print(f"第一个窗口: {windows_2d[0]}")