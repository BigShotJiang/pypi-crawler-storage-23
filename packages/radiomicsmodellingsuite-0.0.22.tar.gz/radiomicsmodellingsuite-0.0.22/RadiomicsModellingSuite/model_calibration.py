import pandas as pd
from . import latex_reporting as lr
from sklearn.calibration import calibration_curve
import matplotlib.pyplot as plt
from sklearn.metrics import brier_score_loss
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.linear_model import LogisticRegression,  LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import brier_score_loss
from statsmodels.nonparametric.smoothers_lowess import lowess
from scipy.interpolate import UnivariateSpline
import matplotlib.pyplot as plt
import numpy as np
import xgboost as xgb
import random
from sklearn.frozen import FrozenEstimator
from lifelines.calibration import survival_probability_calibration 
from scipy.stats import chisquare
import os

def platt_scaling(model, X_train, y_train):
    """
    Apply Platt Scaling using CalibratedClassifierCV.
    
    Parameters:
    
    * model: A scikit-learn classifier
    
    * X_train: Training features
    
    * y_train: Training labels
    
    Returns:
    
    * Calibrated model with Platt scaling
    """
    # Flatten y_train to 1D
    y_train = np.ravel(y_train)
    # Use fewer folds to avoid single-class folds    
    cv = StratifiedShuffleSplit(n_splits=3, test_size=0.2, random_state=42)
    if not isinstance(model, xgb.sklearn.XGBClassifier):
        calibrated_model = CalibratedClassifierCV(estimator=model, method='sigmoid', cv=cv)
        calibrated_model.fit(X_train, y_train)
    else:
        #manual platt calibration as xgboost doesn't support calibrated classifier
        logits = get_logits(model.predict_proba(X_train))
        calibrated_model = LogisticRegression()
        calibrated_model.fit(logits, y_train)
    return calibrated_model

def get_logits(probs):
    """
    Function to get logits from probabilities

    Parameters:
    
    * probs (numpy array): n x 2 array, n is number of samples

    Returns:
    
    * logits (numpy array): 2D array of logits
    """
    probs = np.transpose(probs)[1]
    logits = np.log(probs/(1-probs))
    return logits.reshape(-1, 1)

def isotonic_regression(model, X_train, y_train):
    """
    Apply Isotonic Regression using CalibratedClassifierCV.

    Parameters:
    
    * model: A scikit-learn classifier
    
    * X_train: Training features
    
    * y_train: Training labels
    
    Returns:
    
    * Calibrated model with Isotonic Regression
    """
    y_train = np.ravel(y_train)
    if not isinstance(model, xgb.sklearn.XGBClassifier):
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
        calibrated_model = CalibratedClassifierCV(FrozenEstimator(model), method='isotonic', cv=cv)
        calibrated_model.fit(X_train, y_train)
    else:
        probs = model.predict_proba(X_train)[:, 1]
        data = pd.concat((pd.Series(probs, name='Probability'), pd.Series(y_train, name='Labels')), axis=1)
        data = data.sort_values(by="Probability", ascending=True)
        res = pava(data['Probability'], data['Labels'])
        calibrated_model = create_stepwise_function(data['Probability'], res)
    return calibrated_model

def pava(x, y):
    """
    Pool Adjacent Violators Algorithm (PAVA) using NumPy arrays.
    
    Args:
    
    * x (np.ndarray): Predictor values (must be sorted and unique).
        
    * y (np.ndarray): Response values.
    
    Returns:
        
    * tuple: (adjusted predictor values, adjusted response values)
    """
    if x.shape != y.shape:
        raise ValueError("Predictor and response arrays must have the same shape.")

    # Initialize blocks
    blocks = [np.array([val]) for val in y]
    x_blocks = [np.array([val]) for val in x]

    while True:
        block_means = np.array([block.mean() for block in blocks])
        block_diffs = np.diff(block_means)

        if np.all(block_diffs >= 0):
            y_result = np.concatenate(blocks)
            x_result = np.concatenate(x_blocks)
            return x_result, y_result

        # Find indices where monotonicity is violated
        j_indices = np.where(block_diffs < 0)[0]
        j = random.choice(j_indices)

        # Pool the violating blocks
        violators_y = np.concatenate((blocks[j], blocks[j+1]))
        violators_x = np.concatenate((x_blocks[j], x_blocks[j+1]))
        pool_mean = violators_y.mean()
        pooled_block_y = np.full(violators_y.shape, pool_mean)

        # Reconstruct blocks
        blocks = blocks[:j] + [pooled_block_y] + blocks[j+2:]
        x_blocks = x_blocks[:j] + [violators_x] + x_blocks[j+2:]

def create_stepwise_function(x, y):
    """
    Returns a stepwise constant function f(x) based on predictor values and adjusted responses.
    
    Args:
        
    * x (np.ndarray): Sorted predictor values.
        
    * y (np.ndarray): Adjusted response values from PAVA.
    
    Returns:
        
    * function: A function f(x_query) that returns the stepwise constant value for any x_query (float).
    """
    x = np.asarray(x)
    y = np.asarray(y)[1]
    def f(x_query):
            # Find the interval index
        idx = np.searchsorted(x, x_query, side='right') - 1
        # Clamp index to valid range
        idx = max(0, min(idx, len(y) - 1))
        return y[idx]

    return f


def observed_expected_ratio(y_true, y_pred):
    """
    Calculate the observed/expected ratio.

    Parameters:
    
    * observed (float): The observed value.
    
    * expected (float): The expected value.

    Returns:
    
    * float: The observed/expected ratio.
    """
    observed = (y_true == 1).sum()
    expected = (y_pred == 1).sum() 
    if expected == 0:
        return float('inf')  # Avoid division by zero
    elif isinstance(observed/expected, pd.Series):
        return (observed / expected).values[0]       
    else:
        return observed / expected
        

def generate_calibration_curve(y_true, y_prob, model_name, n_bins=10, normalise=False, show_curve=False, filename='calibration_curve.png'):
    """
    Generate calibration curve data.

    Parameters:
    
    * y_true (array-like): True binary labels.
    
    * y_prob (array-like): Predicted probabilities.
    
    * n_bins (int): Number of bins to use for calibration.
    
    * show_curve (bool): Whether to show the spline fit.

    Returns:
    
    * tuple: Binned probabilities, fraction of positives, and bin edges.
    """
    if normalise:
        # Normalize scores to [0, 1]
        y_prob = (y_prob - y_prob.min()) / (y_prob.max() - y_prob.min())
        
    # Compute calibration curve
    prob_true, prob_pred = calibration_curve(y_true, y_prob, n_bins=20)
    
    # Sort by prob_true for spline fitting
    sorted_indices = np.argsort(prob_pred)
    prob_true_sorted = prob_true[sorted_indices]
    prob_pred_sorted = prob_pred[sorted_indices]

    # Linear regression fit
    linear_model = LinearRegression()
    linear_model.fit(prob_pred.reshape(-1, 1), prob_true)
    slope = linear_model.coef_[0]
    intercept = linear_model.intercept_
    r2 = linear_model.score(prob_pred.reshape(-1, 1), prob_true)
    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(prob_pred, prob_true, 'o', label='Calibration Curve')
    plt.plot(prob_pred, slope * prob_pred + intercept, '--', color='red',
            label=f'Linear Fit: y = {slope:.2f}x + {intercept:.2f}, R² = {r2:.2f}')
    # LOESS smoothing
    loess_smoothed = lowess(prob_true_sorted, prob_pred_sorted, frac=0.6)
    plt.plot(loess_smoothed[:, 0], loess_smoothed[:, 1], color='green', label='LOESS Fit')
    if show_curve:       
        # Spline fit
        k = min(3, len(prob_pred_sorted)-1)
        spline = UnivariateSpline(prob_pred_sorted, prob_true_sorted, s=0.5, k=k)
        spline_x = np.linspace(0, 1, 100)
        spline_y = spline(spline_x)
        plt.plot(spline_x, spline_y, color='purple', label='Spline Fit')
    plt.plot([0, 1], [0, 1], '--', color='gray', label='Perfect Calibration')
    plt.xlabel('Mean Predicted Probability')
    plt.ylabel('Fraction of Positives')
    plt.title('Calibration Curve with LOESS, Spline, and Linear Fit')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    return filename, slope, intercept

def plot_score_distribution(model_name, score, train, kind='uncalibrated'):
    """
    Calibrate model on training data and return calibration metrics
    
    Parameters:
    
    * model_name (str): Name of the model
    
    * score (numpy array): array of scores
    
    * train (boolean): if True, the scores are from the training set
    
    * kind (str): 'uncalibrated' if getting metrics from base model, 'platt' if getting metrics from platt model, 'isotonic' if getting metrics from isotonic

    Returns:
    
    * plot_density (str): filename of density plot

    * plot_hist (str): filename of histogram
    """
    dataset = 'train' if train else 'test'
    pd.DataFrame(score).plot.kde()
    plt.xlabel('Model Output Probability')
    plt.savefig(f'{model_name}_{kind}_{dataset}_probability_density.png')     
    plt.close()
    plot_density = f'{model_name}_{kind}_{dataset}_probability_density.png'
    plt.hist(score)
    plt.xlabel('Model Output Probability')
    plt.savefig(f'{model_name}_{kind}_{dataset}_probability_histogram.png')     
    plt.close()
    plot_hist = f'{model_name}_{kind}_{dataset}_probability_histogram.png'
    return plot_density, plot_hist

def obtain_calibration_metrics(model, model_name, X_train, y_train, X_test, y_test, threshold, calibrated, base_model=None, evaluate_on_test=True, transform_logits=False, isotonic=False, show_curve=False, confidence=0.95, kind='uncalibrated'):
    """
    Calibrate model on training data and return calibration metrics
    
    Parameters:
    
    * model (sklearn model): Trained sklearn model to evaluate
    
    * model_name (str): Name of the model
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * threshold (float): Threshold for model predictions
    
    * calibrated (Boolean): If true, this model is calibrated and outputs probabilities
    
    * base_model (model): The uncalibrated model.
    
    * evaluate_on_test (Boolean): If True, evaluate calibration on test data
    
    * transform_logits (Boolean): If True, convert X_train to logits before inputting to model
    
    * show_curve (Boolean): If True, plot calibration curve
    
    * confidence (float): Confidence level to report for bootstrapping
    
    * kind (str): 'uncalibrated' if getting metrics from base model, 'platt' if getting metrics from platt model, 'isotonic' if getting metrics from isotonic

    Returns:
    
    * observed_expected_value_train (float): Observed/Expected Ratio for training data
    
    * observed_expected_value_test (float): Observed/Expected Ratio for testing data
    
    * calibration_curve_name (str): name of calibration curve
    
    * calibration_curve_filename_train (str): Filename of the calibration curve plot for training data
    
    * train_slope (float): Slope of the calibration curve for training data
    
    * train_intercept (float): Intercept of the calibration curve for training data
    
    * calibration_curve_filename_test (str): Filename of the calibration curve plot for testing data
    
    * test_slope (float): Slope of the calibration curve for testing data
    
    * test_intercept (float): Intercept of the calibration curve for testing data
    
    * brier_score_train (float): Brier score for training data
    
    * brier_score_test (float): Brier score for testing data
    """
    if transform_logits:
        X_train = get_logits(base_model.predict_proba(X_train))
        if evaluate_on_test:
            X_test = get_logits(base_model.predict_proba(X_test))    
    if hasattr(model, 'predict_proba'):
        train_score = model.predict_proba(X_train)[:, 1]    
        train_density_plot, train_hist_plot = plot_score_distribution(model_name, train_score, True, kind=kind) 
        if evaluate_on_test:
            test_score = model.predict_proba(X_test)[:, 1] 
            test_density_plot, test_hist_plot = plot_score_distribution(model_name, test_score, False, kind=kind)                 
    elif isinstance(base_model, xgb.sklearn.XGBClassifier) and isotonic:
        train_score = base_model.predict_proba(X_train)[:, 1]
        train_score = np.array([model(x) for x in train_score])
        train_density_plot, train_hist_plot = plot_score_distribution(model_name, train_score, True, kind=kind)
        if evaluate_on_test:
            test_score = base_model.predict_proba(X_test)[:, 1]
            test_score = np.array([model(x) for x in test_score])         
            test_density_plot, test_hist_plot = plot_score_distribution(model_name, test_score, False, kind=kind)
    else:
        train_score = model.decision_function(X_train)      
        train_density_plot, train_hist_plot = plot_score_distribution(model_name, (train_score >= threshold).astype(int), True, kind=kind)  
        if evaluate_on_test:
            test_score = model.decision_function(X_test)
            test_density_plot, test_hist_plot = plot_score_distribution(model_name, (test_score >= threshold).astype(int), False, kind=kind)
    y_train_pred = (train_score >= threshold).astype(int)                            
    observed_expected_value_train = observed_expected_ratio(y_train, y_train_pred)
    if evaluate_on_test:
        y_test_pred = (test_score >= threshold).astype(int) 
        observed_expected_value_test = observed_expected_ratio(y_test, y_test_pred)
    if hasattr(model, 'predict_proba') and not isotonic:
        if isinstance(model, DecisionTreeClassifier) and not calibrated:
            calibration_curve_filename_train = None       
            train_slope = np.nan
            train_intercept = np.nan
            if evaluate_on_test:
                calibration_curve_filename_test = None
                test_slope = np.nan
                test_intercept = np.nan
        else:
            calibration_curve_filename_train, train_slope, train_intercept = generate_calibration_curve(y_train, train_score, model_name, show_curve=show_curve, filename=f'calibration_curve_{kind}_{model_name}_train.png')
            if evaluate_on_test:
                calibration_curve_filename_test, test_slope, test_intercept = generate_calibration_curve(y_test, test_score, model_name, show_curve=show_curve, filename=f'calibration_curve_{kind}_{model_name}_test.png')                  
        brier_score_train = brier_score_loss(y_train, train_score)        
        if evaluate_on_test:
            brier_score_test = brier_score_loss(y_test, test_score)            
    elif isotonic:
        calibration_curve_filename_train, train_slope, train_intercept = generate_calibration_curve(y_train, train_score, model_name, show_curve=show_curve, filename=f'calibration_curve_{kind}_{model_name}_train.png')       
        brier_score_train = brier_score_loss(y_train, train_score)
        if evaluate_on_test:
            calibration_curve_filename_test, test_slope, test_intercept = generate_calibration_curve(y_test, test_score, model_name, show_curve=show_curve, filename=f'calibration_curve_{kind}_{model_name}_test.png')       
            brier_score_test = brier_score_loss(y_test, test_score)
    else:
        calibration_curve_filename_train = None      
        train_slope = np.nan
        train_intercept = np.nan
        brier_score_train = np.nan
        if evaluate_on_test:
            calibration_curve_filename_test = None
            test_slope = np.nan
            test_intercept = np.nan             
            brier_score_test = np.nan
    if evaluate_on_test:
        return observed_expected_value_train, observed_expected_value_test, calibration_curve_filename_train, train_slope, train_intercept, calibration_curve_filename_test, test_slope, test_intercept, brier_score_train, brier_score_test, train_density_plot, train_hist_plot, test_density_plot, test_hist_plot
    else:
        return observed_expected_value_train, calibration_curve_filename_train, train_slope, train_intercept, brier_score_train, train_density_plot, train_hist_plot

def calibrate_models(models, X_train, y_train, X_test, y_test, thresholds, author, show_curve=False, evaluate_on_test=True, confidence=0.95, directory=".//model_calibration", filename='model_calibration_results'):
    """
    Calibrate multiple models on training and testing data and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * thresholds (list): List of thresholds for model predictions
    
    * author (str): Author of the evaluation
    
    * show_curve (Boolean): If True, plot spline fit for calibration curve
    
    * evaluate_on_test (Boolean): If True, evaluate calibration on test data
    
    * confidence (float): Confidence level to report for bootstrapping

    * directory (str): directory to save results
    
    * filename (str): name of the CSV file to save results

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:

    * CSV file with calibration results

    * PDF and Latex report of calibration results
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    observed_expected_ratios = []
    calibration_curves = []
    score_plots = []
    platt_models = []
    isotonic_models = []
    os.chdir(directory)
    for i, (model_name, model) in enumerate(models):
        print('calibrating', model_name)
        X_train_new = X_train.loc[:, model.feature_names_in_]
        if evaluate_on_test:
            X_test_new = X_test.loc[:, model.feature_names_in_]
        else:
            X_test_new = None
        threshold = thresholds[i]
        if evaluate_on_test:
            observed_expected_value_train, observed_expected_value_test, calibration_curve_filename_train, train_slope, train_intercept, calibration_curve_filename_test, test_slope, test_intercept, brier_score_train, brier_score_test, train_density_plot, train_hist_plot, test_density_plot, test_hist_plot = obtain_calibration_metrics(model, model_name, X_train_new, y_train, X_test_new, y_test, threshold, False, evaluate_on_test=evaluate_on_test, show_curve=show_curve, confidence=0.95)
        else:
            observed_expected_value_train, calibration_curve_filename_train, train_slope, train_intercept, brier_score_train, train_density_plot, train_hist_plot = obtain_calibration_metrics(model, model_name, X_train_new, y_train, X_test_new, y_test, threshold, False, evaluate_on_test=evaluate_on_test, show_curve=show_curve, confidence=0.95) 
        platt_model = platt_scaling(model, X_train_new, y_train)
        isotonic_model = isotonic_regression(model, X_train_new, y_train)
        platt_models.append((model_name, platt_model))
        isotonic_models.append((model_name, isotonic_model)) 
        # print(platt_model.feature_names_in_)    
        transform_logits = 'xgb' in model_name.lower()  
        if evaluate_on_test: 
            observed_expected_value_train_platt, observed_expected_value_test_platt, calibration_curve_filename_train_platt, train_slope_platt, train_intercept_platt, calibration_curve_filename_test_platt, test_slope_platt, test_intercept_platt, brier_score_train_platt, brier_score_test_platt, density_plot_train_platt, hist_plot_train_platt, density_plot_test_platt, hist_plot_test_platt = obtain_calibration_metrics(platt_model, model_name, X_train_new, y_train, X_test_new, y_test, 0.5, True, confidence=0.95, evaluate_on_test=evaluate_on_test, base_model = model, transform_logits=transform_logits, show_curve=show_curve, kind='platt')
            observed_expected_value_train_isotonic, observed_expected_value_test_isotonic, calibration_curve_filename_train_isotonic, train_slope_isotonic, train_intercept_isotonic, calibration_curve_filename_test_isotonic, test_slope_isotonic, test_intercept_isotonic, brier_score_train_isotonic, brier_score_test_isotonic, density_plot_train_isotonic, hist_plot_train_isotonic, density_plot_test_isotonic, hist_plot_test_isotonic = obtain_calibration_metrics(isotonic_model, model_name, X_train_new, y_train, X_test_new, y_test, 0.5, True, confidence=0.95, evaluate_on_test=evaluate_on_test, isotonic=True, base_model=model, show_curve=show_curve, kind='isotonic')
            calibration_curves.append((model_name, calibration_curve_filename_train, calibration_curve_filename_test, calibration_curve_filename_train_platt, calibration_curve_filename_test_platt, calibration_curve_filename_train_isotonic, calibration_curve_filename_test_isotonic))
            score_plots.append((model_name, train_density_plot, train_hist_plot, test_density_plot, test_hist_plot, density_plot_train_platt, hist_plot_train_platt, density_plot_test_platt, hist_plot_test_platt, density_plot_train_isotonic, hist_plot_train_isotonic, density_plot_test_isotonic, hist_plot_test_isotonic))
            results.append({
                'Model': model_name,
                'Observed/Expected Train': observed_expected_value_train,
                'Observed/Expected Test': observed_expected_value_test,
                'Brier Score Train': brier_score_train,
                'Brier Score Test': brier_score_test,
                'Calibration Curve Slope Train': train_slope if calibration_curve_filename_train else np.nan,
                'Calibration Curve Intercept Train': train_intercept if calibration_curve_filename_train else np.nan,
                'Calibration Curve Slope Test': test_slope if calibration_curve_filename_test else np.nan,
                'Calibration Curve Intercept Test': test_intercept if calibration_curve_filename_test else np.nan,
                'Observed/Expected Platt Train': observed_expected_value_train_platt,
                'Observed/Expected Platt Test': observed_expected_value_test_platt,
                'Brier Score Platt Train': brier_score_train_platt,
                'Brier Score Platt Test': brier_score_test_platt,
                'Calibration Curve Slope Platt Train': train_slope_platt if calibration_curve_filename_train_platt else np.nan,
                'Calibration Curve Intercept Platt Train': train_intercept_platt if calibration_curve_filename_train_platt else np.nan,
                'Calibration Curve Slope Platt Test': test_slope_platt if calibration_curve_filename_test_platt else np.nan,
                'Calibration Curve Intercept Platt Test': test_intercept_platt if calibration_curve_filename_test_platt else np.nan,
                'Observed/Expected Isotonic Train': observed_expected_value_train_isotonic,
                'Observed/Expected Isotonic Test': observed_expected_value_test_isotonic,
                'Brier Score Isotonic Train': brier_score_train_isotonic,
                'Brier Score Isotonic Test': brier_score_test_isotonic,
                'Calibration Curve Slope Isotonic Train': train_slope_isotonic if calibration_curve_filename_train_isotonic else np.nan,
                'Calibration Curve Intercept Isotonic Train': train_intercept_isotonic if calibration_curve_filename_train_isotonic else np.nan,
                'Calibration Curve Slope Isotonic Test': test_slope_isotonic if calibration_curve_filename_test_isotonic else np.nan,
                'Calibration Curve Intercept Isotonic Test': test_intercept_isotonic if calibration_curve_filename_test_isotonic else np.nan
            })
        else:
            observed_expected_value_train_platt, calibration_curve_filename_train_platt, train_slope_platt, train_intercept_platt, brier_score_train_platt, density_plot_train_platt, hist_plot_train_platt = obtain_calibration_metrics(platt_model, model_name, X_train_new, y_train, X_test_new, y_test, 0.5, True, confidence=0.95, evaluate_on_test=evaluate_on_test, base_model = model, transform_logits=transform_logits, show_curve=show_curve, kind='platt')
            observed_expected_value_train_isotonic, calibration_curve_filename_train_isotonic, train_slope_isotonic, train_intercept_isotonic, brier_score_train_isotonic, density_plot_train_isotonic, hist_plot_train_isotonic = obtain_calibration_metrics(isotonic_model, model_name, X_train_new, y_train, X_test_new, y_test, 0.5, True, confidence=0.95, evaluate_on_test=evaluate_on_test, isotonic=True, base_model=model, show_curve=show_curve, kind='isotonic')
            calibration_curves.append((model_name, calibration_curve_filename_train, calibration_curve_filename_train_platt, calibration_curve_filename_train_isotonic))
            score_plots.append((model_name, train_density_plot, train_hist_plot, density_plot_train_platt, hist_plot_train_platt, density_plot_train_isotonic, hist_plot_train_isotonic))
            results.append({
                'Model': model_name,
                'Observed/Expected Train': observed_expected_value_train,
                'Brier Score Train': brier_score_train,
                'Calibration Curve Slope Train': train_slope if calibration_curve_filename_train else np.nan,
                'Calibration Curve Intercept Train': train_intercept if calibration_curve_filename_train else np.nan,
                'Observed/Expected Platt Train': observed_expected_value_train_platt,
                'Brier Score Platt Train': brier_score_train_platt,
                'Calibration Curve Slope Platt Train': train_slope_platt if calibration_curve_filename_train_platt else np.nan,
                'Calibration Curve Intercept Platt Train': train_intercept_platt if calibration_curve_filename_train_platt else np.nan,
                'Observed/Expected Isotonic Train': observed_expected_value_train_isotonic,
                'Brier Score Isotonic Train': brier_score_train_isotonic,
                'Calibration Curve Slope Isotonic Train': train_slope_isotonic if calibration_curve_filename_train_isotonic else np.nan,
                'Calibration Curve Intercept Isotonic Train': train_intercept_isotonic if calibration_curve_filename_train_isotonic else np.nan,
            })            
    results_df = pd.DataFrame(results)
    lr.calibration_report(author, results_df, calibration_curves, score_plots, evaluate_on_test=evaluate_on_test, filename=filename)
    results_df.set_index('Model', inplace=True)
    results_df.to_csv(f'{filename}.csv')
    os.chdir("..")
    return results_df, platt_models, isotonic_models

def calibrate_survival_models(models, X_train, y_train, X_test, y_test, times, filename='survival_model_calibration_results'):
    """
    Calibrate survival models on training data and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of tuples (str, model) containing trained models
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * times (list): list of times
    
    * author (str): Author of the evaluation
    
    * filename (str): name of the CSV file to save results

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:

    * CSV file with calibration results
    """
    train_df = pd.concat([X_train, y_train], axis=1)
    test_df = pd.concat([X_test, y_test], axis=1)
    results = []
    for name, model, file in models:
        # Predict survival function for each patient
        for time in times:            
            y_true_train = (y_train['target_survival'] <= time).astype(int)    
            y_true_test = (y_test['target_survival'] <= time).astype(int)               
            train_expected_events = model.predict_expectation(train_df)
            test_expected_events = model.predict_expectation(test_df)
            y_pred_train = (train_expected_events <= time).astype(int)
            y_pred_test = (test_expected_events <= time).astype(int)
            train_observed_expected = observed_expected_ratio(y_true_train, y_pred_train)
            test_observed_expected = observed_expected_ratio(y_true_test, y_pred_test)
            train_brier_score = brier_score_loss(y_true_train, y_pred_train)
            test_brier_score = brier_score_loss(y_true_test, y_pred_test)
            ax, train_ICI, train_E50 = survival_probability_calibration(model, train_df, time)
            fig = ax.get_figure()
            fig.savefig(f"{name}_train_calibration_curve_{time}.png", dpi=300)
            plt.close(fig)  
            ax, test_ICI, test_E50 = survival_probability_calibration(model, test_df, time)
            results.append({
                'Model': name,
                'Time': time,
                'Train ICI': train_ICI,
                'Train E50': train_E50,
                'Test ICI': test_ICI,
                'Test E50': test_E50,
                'Train Observed/Expected': train_observed_expected,
                'Test Observed/Expected': test_observed_expected,
                "Train Brier Score": train_brier_score,
                'Test Brier Score': test_brier_score
            })
            # Save the plot
            fig = ax.get_figure()
            fig.savefig(f"{name}_test_calibration_curve_{time}.png", dpi=300)
            plt.close(fig) 
    results_df = pd.DataFrame(results)
    results_df.to_csv(f'{filename}.csv')
    return results_df

def calibrate_km_model(times, kmf, bin_edges):
    """
    Calibrates a single model

    Parameters:
    
    * times (pandas Series): series of survival times
    
    * kmf (lifelines kaplan meier model): trained model
    
    * bin_edges (numpy array): array of histogram bin edges

    Returns:
    
    * p_value (float): p value
    """
    n_bins = len(bin_edges)
    survival = kmf.survival_function_.reset_index()
    survival_filtered = survival[survival['timeline'].isin(times)]
    bin_indices = np.digitize(survival_filtered['KM_estimate'], bin_edges)
    unique_values, counts = np.unique(bin_indices, return_counts=True)
    all_bin_counts = np.zeros(len(bin_edges))
    all_bin_counts[unique_values - 1] = counts
    expected_counts = np.ones(n_bins)*(len(survival_filtered)/n_bins)
    statistic, p_value = chisquare(all_bin_counts, expected_counts)
    return p_value

def calibrate_kaplan_meier_models(models, full_model, X_train, y_train, author, n_bins=4, filename='kaplan_meier_model_calibration_results'):
    """
    Calibrate survival models on training data and save results to a CSV file.
    
    Parameters:
    
    * models (dict): dictionary of Kaplan Meier models for each variable
    
    * full_model (kaplan meier model): kaplan meier model trained on full dataset
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * author (str): Author of the evaluation
    
    * n_bins (int): number of bins to use for evaluating survival function
    
    * filename (str): name of the CSV file to save results

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:

    * CSV file with calibration results

    * PDF and Latex report of calibration results
    """

    evaluation_results = []
    bin_edges = np.array([x/n_bins for x in range(n_bins)])
    data = pd.concat([X_train, y_train], axis=1)
    for col, kmfs in models.items():
        for i, kmf in enumerate(kmfs):
            
            if i == 0:
                if not col.startswith("categorical_"): 
                    median = X_train[col].median()
                    filtered_data = data[data[col] <= median]      
                else:
                    filtered_data = data[data[col] == 0]
            else:
                if not col.startswith("categorical_"): 
                    median = X_train[col].median()
                    filtered_data =data[data[col] > median]      
                else:
                    filtered_data = data[data[col] == 1]
            p_value = calibrate_km_model(filtered_data['target_survival'], kmf, bin_edges)
            if i == 0:
                evaluation_results.append({
                    'Model': f'{col} < Median',
                    'p-Value': p_value
                }) 
            else:
                evaluation_results.append({
                    'Model': f'{col} > Median',
                    'p-Value': p_value
                }) 
    p_value = calibrate_km_model(y_train['target_survival'], full_model, bin_edges)
    evaluation_results.append({
                    'Model': 'Full Model',
                    'p-Value': p_value
                })
    df = pd.DataFrame(evaluation_results)
    df.to_csv(f'{filename}.csv', index=False)
    lr.kaplan_meier_calibration_report(author, df, n_bins, alpha=0.95, filename="kaplan_meier_calibration")
    return df