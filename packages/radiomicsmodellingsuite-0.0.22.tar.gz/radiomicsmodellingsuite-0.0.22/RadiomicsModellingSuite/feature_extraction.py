import pydicom as dicom
import matplotlib.pyplot as plt
import radiomics
from radiomics import featureextractor, firstorder, glcm, gldm, glrlm, glszm, ngtdm, shape, shape2D
import six, numpy as np
import nibabel as nib
import SimpleITK as sitk
import pandas as pd
from collections import OrderedDict
import yaml
from . import latex_reporting as lr
import gc
from . import data_processing as dp
import os
def construct_feature_array(result):
  """
    Function to construct an array of all the radiomics features

    Parameters:
    
    * result (dict) - result of radiomics extraction

    Returns:
    
    * feature (numpy array) - array of all radiomics features extracted from the image
    """
  feature = np.array([]) #initialise feature array
  for key, value in six.iteritems(result): #loop through each item extracted
    #   print('\t', key, ':', value)
      if key.startswith("original_"):
          #only appends radiomics features extracted
          feature = np.append( feature, value)
  return feature

def streamline_features(features):
  """
    Function to rewrite features from a dictionary as a numpy array of all feature values

    Parameters:
    
    * features (dict) - keys are filter names and values are numpy arrays of feature values

    Returns:
    
    * feature_list (numpy array) - array of all features from the different filtered images
    """
  if type(features) is dict: #ensure features is a dictionary
    feature_list = [] #initialise list of features
    for filter, value in six.iteritems(features): #loop through each filter in features dictionary
        for label, array in six.iteritems(features[filter]): #loop through each segmentation label
            feature_list = feature_list + list(array) #concatenate the whole list of features from that filtered image to feature_list        
  return np.array(feature_list)

def normalised_hotspot_centroid_distance(image, segmentation, label):
    """
    Function to calculate normalised hotspot centroid distance

    Parameters:
    
    * image (sitk image) - patient image
    
    * segmentation (sitk image) - segmentation
    
    * label (int) - segmentation label to extract normalised hotspot centroid distance

    Returns:
    
    * distance (float) - normalised hotspot centroid distance
    """
    seg_array = sitk.GetArrayFromImage(segmentation)
    image_array = sitk.GetArrayFromImage(image)
    image_array = np.where(seg_array == label, image_array,0)
    seg_array = np.argwhere(seg_array == label)
    centroid = seg_array.mean(axis=0)
    max = np.argwhere(image_array == image_array.max())
    distance = np.linalg.norm(centroid - max)
    num_voxels = seg_array.shape[0]
    metabolic_spherical_radius = (num_voxels / (4/3 * np.pi))**(1/3) 
    return distance/metabolic_spherical_radius

def perform_extraction(image, segmentation, extractor, labels, processing_procedure, params=None, filter=""):
    """
    Function to perform feature extraction and save results

    Parameters:
    
    * image (sitk image) - patient image
    
    * segmentation (sitk image) - segmentation
    
    * extractor (pyradiomics extractor) - extractor configured with appropriate parameters
    
    * filter (str) - filter name
    
    * labels (list) - list of segmentation labels to extract radiomics features from
    
    * processing_procedure (list): image pre-processing pipeline

    * params (dict): dictionary of parameters for feature extraction.

    * filter (str): filter name

    Returns:

    * features (list or OrderedDict): all the radiomics features

    * results (OrderedDict): a dictionary with result from feature extraction
    
    * results_stripped (OrderedDict): a dictionary containing only radiomics features from image
    """
    results = OrderedDict([])
    results_stripped = OrderedDict([])
    if filter == "":
        features = []
    else:
        features = OrderedDict([])    
    # Cast segmentation to a supported integer type (e.g., sitk.sitkUInt8 or sitk.sitkInt16)
    segmentation_casted = sitk.Cast(segmentation, sitk.sitkUInt8)
    label_stats = sitk.LabelStatisticsImageFilter()
    label_stats.Execute(segmentation_casted, segmentation_casted)
    present_labels = np.array(list(label_stats.GetLabels()))
    valid_labels = present_labels[present_labels != 0]
    all_features = ['original_shape_Elongation', 'original_shape_Flatness', 'original_shape_LeastAxisLength', 'original_shape_MajorAxisLength', 'original_shape_Maximum2DDiameterColumn', 'original_shape_Maximum2DDiameterRow', 'original_shape_Maximum2DDiameterSlice', 'original_shape_Maximum3DDiameter', 'original_shape_MeshVolume', 'original_shape_MinorAxisLength', 'original_shape_Sphericity', 'original_shape_SurfaceArea', 'original_shape_SurfaceVolumeRatio', 'original_shape_VoxelVolume', 'original_firstorder_10Percentile', 'original_firstorder_90Percentile', 'original_firstorder_Energy', 'original_firstorder_Entropy', 'original_firstorder_InterquartileRange', 'original_firstorder_Kurtosis', 'original_firstorder_Maximum', 'original_firstorder_MeanAbsoluteDeviation', 'original_firstorder_Mean', 'original_firstorder_Median', 'original_firstorder_Minimum', 'original_firstorder_Range', 'original_firstorder_RobustMeanAbsoluteDeviation', 'original_firstorder_RootMeanSquared', 'original_firstorder_Skewness', 'original_firstorder_TotalEnergy', 'original_firstorder_Uniformity', 'original_firstorder_Variance', 'original_glcm_Autocorrelation', 'original_glcm_ClusterProminence', 'original_glcm_ClusterShade', 'original_glcm_ClusterTendency', 'original_glcm_Contrast', 'original_glcm_Correlation', 'original_glcm_DifferenceAverage', 'original_glcm_DifferenceEntropy', 'original_glcm_DifferenceVariance', 'original_glcm_Id', 'original_glcm_Idm', 'original_glcm_Idmn', 'original_glcm_Idn', 'original_glcm_Imc1', 'original_glcm_Imc2', 'original_glcm_InverseVariance', 'original_glcm_JointAverage', 'original_glcm_JointEnergy', 'original_glcm_JointEntropy', 'original_glcm_MCC', 'original_glcm_MaximumProbability', 'original_glcm_SumAverage', 'original_glcm_SumEntropy', 'original_glcm_SumSquares', 'original_gldm_DependenceEntropy', 'original_gldm_DependenceNonUniformity', 'original_gldm_DependenceNonUniformityNormalized', 'original_gldm_DependenceVariance', 'original_gldm_GrayLevelNonUniformity', 'original_gldm_GrayLevelVariance', 'original_gldm_HighGrayLevelEmphasis', 'original_gldm_LargeDependenceEmphasis', 'original_gldm_LargeDependenceHighGrayLevelEmphasis', 'original_gldm_LargeDependenceLowGrayLevelEmphasis', 'original_gldm_LowGrayLevelEmphasis', 'original_gldm_SmallDependenceEmphasis', 'original_gldm_SmallDependenceHighGrayLevelEmphasis', 'original_gldm_SmallDependenceLowGrayLevelEmphasis', 'original_glrlm_GrayLevelNonUniformity', 'original_glrlm_GrayLevelNonUniformityNormalized', 'original_glrlm_GrayLevelVariance', 'original_glrlm_HighGrayLevelRunEmphasis', 'original_glrlm_LongRunEmphasis', 'original_glrlm_LongRunHighGrayLevelEmphasis', 'original_glrlm_LongRunLowGrayLevelEmphasis', 'original_glrlm_LowGrayLevelRunEmphasis', 'original_glrlm_RunEntropy', 'original_glrlm_RunLengthNonUniformity', 'original_glrlm_RunLengthNonUniformityNormalized', 'original_glrlm_RunPercentage', 'original_glrlm_RunVariance', 'original_glrlm_ShortRunEmphasis', 'original_glrlm_ShortRunHighGrayLevelEmphasis', 'original_glrlm_ShortRunLowGrayLevelEmphasis', 'original_glszm_GrayLevelNonUniformity', 'original_glszm_GrayLevelNonUniformityNormalized', 'original_glszm_GrayLevelVariance', 'original_glszm_HighGrayLevelZoneEmphasis', 'original_glszm_LargeAreaEmphasis', 'original_glszm_LargeAreaHighGrayLevelEmphasis', 'original_glszm_LargeAreaLowGrayLevelEmphasis', 'original_glszm_LowGrayLevelZoneEmphasis', 'original_glszm_SizeZoneNonUniformity', 'original_glszm_SizeZoneNonUniformityNormalized', 'original_glszm_SmallAreaEmphasis', 'original_glszm_SmallAreaHighGrayLevelEmphasis', 'original_glszm_SmallAreaLowGrayLevelEmphasis', 'original_glszm_ZoneEntropy', 'original_glszm_ZonePercentage', 'original_glszm_ZoneVariance', 'original_ngtdm_Busyness', 'original_ngtdm_Coarseness', 'original_ngtdm_Complexity', 'original_ngtdm_Contrast', 'original_ngtdm_Strength','original_custom_NormalisedHotspotCentroidDistance']
    for label in labels:
        if label in valid_labels: #check if label is valid
            extractor.settings['label'] = label
            
            extractor.settings['verbosity'] = 3  # Enables detailed logging
            extractor.settings['enableCExtensions'] = False  # Forces Python mode (easier to debug)
            for step in processing_procedure:
                if step[0].lower() == 'discretise':
                    discretise_dictionary = step[1]
                    if 'bin_width' in discretise_dictionary.keys():
                        extractor.settings['binWidth'] = discretise_dictionary['bin_width']
                    elif 'num_bins' in discretise_dictionary.keys():
                        extractor.settings['binCount'] = discretise_dictionary['num_bins']
                    elif 'bin_count' in discretise_dictionary.keys():
                        extractor.settings['binCount'] = discretise_dictionary['bin_count']
             #extract radiomics features given the image and segmentation
            if 'featureClass' in params:
                if {k:v for k,v in params['featureClass'].items() if k != 'custom'} == {}:
                    print('only custom features specified, skipping pyradiomics extraction')
                    result = OrderedDict([])
                else:
                    result = extractor.execute(image,segmentation)                    
                if 'custom' in params['featureClass']:
                    result['original_custom_NormalisedHotspotCentroidDistance'] = normalised_hotspot_centroid_distance(image, segmentation, label)    
            else:
                try:
                    result = extractor.execute(image,segmentation)
                    result['original_custom_NormalisedHotspotCentroidDistance'] = normalised_hotspot_centroid_distance(image, segmentation, label)
                except Exception as e:
                    # your code to fill result with NaNs
                    if 'featureClass' not in params:
                        features_to_use = all_features
                    else:
                        features_to_use = []
                        for feature_class, features_to_extract in params['featureClass'].items():
                            if features == []:
                                features_to_use += [feature for feature in all_features if feature_class in feature]
                            else:
                                features_to_use += [f"original_{feature_class}_{feature}" for feature in features_to_extract]
                    result = OrderedDict((key, np.nan) for key in features_to_use)
                    result['original_custom_NormalisedHotspotCentroidDistance'] = np.nan
        else: 
            result = OrderedDict([])        
            # Create a dummy result filled with NaNs using expected keys
            if params is None: #check if parameters are specified   
                
                for key in all_features:
                    result[f'{key}'] = np.nan
            else:
                features_to_use = []                
                if 'featureClass' not in params:
                    #params['featureClass'] = extractor.enabledFeatures
                    features_to_use = all_features
                else:
                    for feature_class, features_to_extract in params['featureClass'].items():
                        if features == []:
                            features_to_use += [feature for feature in all_features if feature_class in feature]
                        else:
                            features_to_use += [f"original_{feature_class}_{feature}" for feature in features_to_extract]
                result = OrderedDict((key, np.nan) for key in features_to_use)
                result['original_custom_NormalisedHotspotCentroidDistance'] = np.nan
        result_edited = OrderedDict([]) #initialise edited result dictionary with label at front of each key
        result_stripped = OrderedDict([]) #initialise stripped result dictionary with label at front of each key, only containing features
        
        for key in result:
            #write edited result dictionary with label at front of each key
            if filter == "": #only include filter in key if filter is specified
                new_key = f"{label}_{key}"
            else:
                new_key = f"{filter}_{label}_{key}"
            result_edited[new_key] = result[key]
            if key.startswith('original_'): #only include radiomics features in result_stripped
                result_stripped[new_key] = result[key]
        results.update(result_edited)
        results_stripped.update(result_stripped)
        if filter == "":
            feature = construct_feature_array(result)

            features = list(features) + list(feature) if isinstance(features, list) else feature
        else:
            features.update({label: construct_feature_array(result)})
    return features, results, results_stripped

def extract_features(image, segmentation, features_modality, results_modality, streamlined_features_modality, processing_pipeline, params=None, filters=None, labels=[1]):
  """
    Function to extract features as a numpy array of all feature values

    Parameters:
    
    * image (sitk): patient image
    
    * segmentation (sitk): segmentation

    * features_modality (list): list of all features from patients for this modality

    * results_modality (list): list of results dictionaries from feature extraction for this modality

    * streamlined_features_modality (list): list of streamlined features arrays for this modality
    
    * processing_pipeline (list[tuple]): image pre-processing pipeline
    
    * params (dict or str): if str, filename of yaml file containing radiomics extraction parameters
    
    * filters (dict): dictionary of filters to filter image with
    
    * labels (list): list of segmentation labels to extract radiomics features from

    Returns:
    
    * features_modality (list): updated list of all features from patients for this modality
    
    * results_modality (list): list of results dictionaries from feature extraction for this modality

    * results_stripped - a dictionary containing only radiomics features from image

    * streamlined_features_modality (list): list of streamlined features arrays for this modality

    * results (dict): results of radiomics feature extraction.

    """
  if params is None:
    extractor = featureextractor.RadiomicsFeatureExtractor() #initialize extractor
    # Enable all features
    extractor.enableAllFeatures()
  else:
    if 'label' in params['setting'].keys():
        del params['setting']['label'] #remove label from params to avoid issues with extractor
    if 'featureClass' in params.keys() and 'custom' in params['featureClass'].keys():
        params_no_custom = params.copy()
        params_no_custom['featureClass'] = {k:v for k,v in params['featureClass'].items() if k != 'custom'}
    else:
        params_no_custom = params
    extractor = featureextractor.RadiomicsFeatureExtractor(params_no_custom) #initialize extractor with specified parameters
  if filters == None:
    features, results, results_stripped = perform_extraction(image, segmentation, extractor, labels, processing_pipeline, params=params)
    streamlined_features_modality.append(features)
  else:
    #initialise features and results dictionary
    results = {}
    features = {}
    results_stripped = OrderedDict([])
    features['baseline'], results['baseline'], results_stripped['baseline'] = perform_extraction(image, segmentation, extractor, labels, processing_pipeline, params=params, filter='baseline')
    for filter, value in six.iteritems(filters):
    #loop through filters to obtain filtered images and extract features
        print(f'filtering with: {filter}')
        filtered_image = value.Execute(image) #filter image using the specified filter
        features[filter], results[filter], results_stripped[filter] = perform_extraction(filtered_image, segmentation, extractor, labels, processing_pipeline, params=params, filter=filter)
    streamlined_features_modality.append(streamline_features(features))
  features_modality.append(features)
  results_modality.append(results)
  return features_modality, results_modality, results_stripped, streamlined_features_modality, results

def remove_extra_features(features, scan_types, filters=None):
    """
    Function to remove extra shape features

    Parameters:
    
    * features (pandas DataFrame): dataframe with features and feature names
    
    * scan_types (list[str]): list of scan types
    
    * filters (dict{str: sitk filter}): dictionary of filters used

    Returns:
    
    * features_stripped (pandas DataFrame): features dataframe with only shape features from one scan type and one filter
    """
    if len(scan_types) == 1 and filters == None:
        features_stripped = features
    else:
        if len(scan_types) == 1:
            extra_scans = []
        else:
            extra_scans = scan_types[1:]
        if filters is not None:
        # Drop columns that contain 'shape' but not 'baseline', and are not from the first scan
        # Also drop additional target or clinical features 
            columns_to_drop = [col for col in features.columns if 'shape' in col and ('baseline' not in col or any(substring in col for substring in extra_scans))]
            columns_to_drop += [col for col in features.columns if 'target' in col and any(substring in col for substring in extra_scans)]
            columns_to_drop += [col for col in features.columns if 'clinical' in col and any(substring in col for substring in extra_scans)]
        else:
            columns_to_drop = [col for col in features.columns if 'shape' in col and any(substring in col for substring in extra_scans)]
            columns_to_drop += [col for col in features.columns if 'target' in col and any(substring in col for substring in extra_scans)]
            columns_to_drop += [col for col in features.columns if 'clinical' in col and any(substring in col for substring in extra_scans)]
        features_stripped = features.drop(columns=columns_to_drop)
    return features_stripped

def report(author, results, labels=[1], filters=None, params=None, filename="radiomics_extraction.txt"):
    """
    Function to save the results of feature extraction to a text file

    Parameters:

    * author (str): name of author
    
    * results (dict): radiomics features extracted from image and parameters including software versions etc
    
    * labels (list): list of labels in segmentation that features were extracted from.

    * filters (dict){str: sitk filter}: filters used. Default is None.

    * params (dict or str): dictionary of feature extraction parameters or name of .yaml file with parameters. Default is None.
    
    * filename (str): name of file to save feature extraction information to. Default is radiomics_extraction.txt

    Output:
    
    * text file with software versions and features extracted

    * latex and pdf report of feature extraction
    """

    with open(filename, "w") as f:    
        
        if filters != None:
            items = list(six.iteritems(results['baseline']))
        else:
            items = list(six.iteritems(results))
            
        f.write("Software Versions Used:\n")
        new_category = False
        for i, (key, value) in enumerate(items):
            next_key = items[i + 1][0] if i + 1 < len(items) else []                    
            if filters is not None:
                    key = key[9:]  #strip segmentation label off header 
            if key.startswith(str(labels[0])):
                key = key[len(str(labels[0])) + 1:]  #strip segmentation label off header                   
                if "diagnostics_Versions_" in key:
                    f.write(f"{key[21:]}: {value}\n")
                    if "diagnostics_Versions_" not in next_key: #if current category finished, write the next category
                        new_category = True
                        f.write("\n")
                elif "original_shape_" in key:
                    if new_category:
                        f.write("Shape Features Extracted:\n")
                    f.write(f"{key[9:]}\n")
                    if "original_shape_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")      
                elif "original_firstorder_" in key:
                    f.write(f"{key[9:]}\n")
                    if "original_firstorder_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")                   
                elif "original_glcm_" in key:
                    f.write(f"{key[9:]}\n")
                    if "original_glcm_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")                  
                elif "original_gldm_" in key:
                    f.write(f"{key[9:]}\n")
                    if "original_gldm_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")
                elif "original_glrlm_" in key:
                    f.write(f"{key[9:]}\n")
                    if "original_glrlm_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")
                elif "original_glszm_" in key:
                    f.write(f"{key[9:]}\n")
                    if "original_glszm_" not in next_key:  #if current category finished, write the next category
                        new_category = True
                        f.write("\n")
                elif "original_ngtdm_" in key:
                    f.write(f"{key[9:]}\n")               
                    if "original_ngtdm_" not in next_key: #break when all features have                        
                        break
                #checking next category
                if new_category:
                    if "original_shape_" in next_key:
                        f.write("Shape Features Extracted:\n")
                        new_category = False
                    elif "original_firstorder_" in next_key:
                        f.write("First Order Features Extracted:\n")
                        new_category = False
                    elif "original_glcm_" in next_key:
                        f.write("GLCM Features Extracted:\n")
                        new_category = False 
                    elif "original_gldm_" in next_key:
                        f.write("GLDM Features Extracted:\n") 
                        new_category = False
                    elif "original_glrlm_" in next_key:
                        f.write("GLRLM Features Extracted:\n")
                        new_category = False 
                    elif "original_glszm_" in next_key:
                        f.write("GLSZM Features Extracted:\n") 
                        new_category = False
                    elif "original_ngtdm_" in next_key:
                        f.write("NGTDM Features Extracted:\n")
                        new_category = False                
        f.write("\n")
        if filters is not None:           
            f.write("Filters Used:\n")
            for key, value in six.iteritems(filters):
                f.write(f"{key}\n")
        else:
            f.write("No Filters were used\n")
        f.write("\n")
        f.write("Configuration Parameters\n")
        if params is None: #if parameters are unspecified, write default extraction parameters           
            extractor = featureextractor.RadiomicsFeatureExtractor()
            settings = extractor.settings
        elif isinstance(params, dict):   
            settings = params
            settings['setting']['label'] = labels
        else:           
            with open(params, 'r') as file:
                settings = yaml.safe_load(file)
            settings['setting']['label'] = labels
        for key, value in settings.items(): #write configuration parameters
            f.write(f"{key}: {value}\n")
        lr.extraction_report(author, results, settings, labels=labels, filters=filters, params=params, filename=filename[:-4])

def strip_results(results):
    """
    Function to remove keys in results

    Parameters:
    
    * results (ordered dict): radiomics features extracted from image
    
    Output:
    
    * results_stripped (ordered dict): dictionary with only keys containing features
    """
    results_stripped = results
    for key in list(results):
        if "original_" not in key:
            del results_stripped[key]
    return results_stripped

def save_features(results, features, filename, scan_types, filters=None, segmentation_labels=None, target=None, clinical=None):
    """
    Function to save the features to a csv file

    Parameters:
    
    * results (ordered dict): radiomics features extracted from image
    
    * features (list): list of all features from patients
    
    * filename (str) - name of file to save radiomics features to

    * scan_types (list[str]): list of scan types

    * filters (dict{str: sitk filter}): filters used

    * segmentation_labels (list): list of segmentation labels used

    * target (DataFrame, optional): Target features for each patient. Defaults to None.

    * clinical (DataFrame, optional): Clinical features for each patient. Defaults to None.
    
    Output:

    * csv file of features
    """
    headings = [] #initialise list of headings
    if filters == None: #check if filters are specified
        results = strip_results(results) #remove results values that are not radiomics features
        items = list(six.iteritems(results))
        if segmentation_labels == None:
            segmentation_labels = [1 for x in range(len(items))]
        for i, (key, value) in enumerate(items):
            #loop through each item extracted in results

            headings.append(f"{key}")
    else:
        index = 0 #counter to keep track of index
        total_items = []
        
        for filter in results: #loop through each filter
            stripped_results = strip_results(results[filter])
            items = list(six.iteritems(stripped_results)) 
            total_items += items
            for i, (key, value) in enumerate(items): 
                #loop through each item extracted in results   
                headings.append(key)
                    #increment indexd
                if key == items[-1][0]: #stop when last key is reached
                    break
                index += 1
        headings = [heading for (heading, value) in total_items]
    features = pd.DataFrame(np.array(features)) #convert features to dataframe
    features.columns = headings #rename columns to radiomics features
    if clinical is not None:
        clinical.rename(columns={col:f'clinical_{col}' for col in clinical.columns}, inplace=True)
        features = pd.concat([clinical, features], axis=1) #add clinical features if specified
    if target is not None:
        target = pd.DataFrame(target) #convert target to dataframe
        target.columns = [f'target_{col}' for col in target.columns] #rename target columns
        features = pd.concat([target, features], axis=1) #add target column if specified
        #features.rename(columns={target.columns[0]: f'target_{target.columns[0]}'}, inplace=True)
    features = remove_extra_features(features, scan_types, filters=filters)
    pd.DataFrame.to_csv(features, filename, index=False)

def combine_dfs(filenames, filename, scan_types=None, target=None):
    """
    Combines CSVs containing features extracted from each scan type.
    Each column is renamed to scan_type + original column name.

    Parameters:

        * filenames (list[str]): List of filenames to combine.
        * filename (str): Filename to save combined features CSV to.
        * scan_types (list, optional): List of scan types. Defaults to None.
        * target (DataFrame, optional): Target features for each patient. Defaults to None.
    
    Returns:

        * combined_features (DataFrame): Combined features dataframe.
    """
    
    if target is not None:
        dfs = [target]
    else:
        dfs = []
    if scan_types is None: #if scan_type is unspecified, do not rename columns
        for file in filenames:
            df = pd.read_csv(file)
            dfs.append(df)
    else:
        for file, scan_type in zip(filenames, scan_types):
            df = pd.read_csv(file)
            # Rename columns to include scan_type prefix
            df = df.rename(columns=lambda col: f"{scan_type}_{col}" if ("target" not in col and "clinical" not in col and "ID" not in col) else f"{col}")
            if scan_type != scan_types[0]:
                cols_to_drop = list(df.filter(like="target", axis=1).columns)
                cols_to_drop += list(df.filter(like="clinical", axis=1).columns)
                cols_to_drop += list(df.filter(like="ID", axis=1).columns)
                df = df.drop(columns=cols_to_drop, errors='ignore')  # Drop target columns if they exist
            dfs.append(df)

    # Combine all dataframes column-wise
    combined_features = pd.concat(dfs, axis=1)
    pd.DataFrame.to_csv(combined_features, filename, index=False)
    return combined_features

def nifti_to_sitk(nifti):
    """
    Convert nifti image to sitk.
    
    Parameters:

    * nifti (nifti): nifti image
    
    Returns:

    * sitk_image (sitk image): sitk image
    """
    nifti = nifti.get_fdata() #extract pixel array from image
    sitk_image = sitk.GetImageFromArray(nifti) #convert image to sitk image
    sitk_image = sitk.Cast(sitk_image, sitk.sitkFloat32)
    return sitk_image

def combine_batch_features(features_filename, num_batches, scan_types, ids_list=None, filters=None):
    """
    Combine features extracted from each batch and save to a single CSV file.

    Parameters:
        * features_filename (str): Filename to save combined features CSV to.
        * num_batches (int): Number of batches processed.
        * scan_types (list): List of scan types.
        * clinical (DataFrame, optional): Clinical features for each patient. Defaults to None.
        * filters (dict, optional): Dictionary of filters to apply. Defaults to None.

    Outputs:
    * CSV file combining results from all batches
    """
    for scan in scan_types:
        combined = pd.read_csv(f"features_{scan}_0.csv")
        for i in range(1, num_batches):
            # Read each saved features CSV for the current scan type
            df = pd.read_csv(f"features_{scan}_{i}.csv")
            combined = pd.concat([combined, df], ignore_index=True)
        if ids_list is not None:
            combined.insert(0, 'ID', ids_list[:len(combined)])
        # Save features for each scan type
            #combined.to_csv(f"{scan}_{features_filename}", index=True)
        # else:
        #     combined.to_csv(f"{scan}_{features_filename}", index=False)
        combined.to_csv(f"{scan}_{features_filename}", index=False)
    # Combine all saved features into one CSV.
    features_filenames = [scan_type + "_" + features_filename for scan_type in scan_types]
    combined_features = combine_dfs(features_filenames, features_filename, scan_types=scan_types)
    combined_features = remove_extra_features(combined_features, scan_types, filters=filters)
    # if clinical is None:
    #     pd.DataFrame.to_csv(combined_features, features_filename, index=False)
    # else:
    #     pd.DataFrame.to_csv(combined_features, features_filename, index=True)
    pd.DataFrame.to_csv(combined_features, features_filename, index=False)

def generate_batches(niftis_list, segmentations, batch_size):
    """
    Generator function for generating batches
    
    Parameters:
        
    * niftis_list (list[list[str]]): List of filenames for NIfTI images for each modality.

    * segmentations (list[str]): List of filenames for segmentation images.

    * batch_size (int): Size of each batch.
    
    Returns:
    
    * batch_start (int): starting index of batch
    
    * batch_end (int): ending index of batch
    
    * batch_niftis (list[list[niftis]]): list of niftis in the batch

    * batch_segmentations (list[niftis]): list of segmentations in the batch
    """
    for batch_start in range(0, len(niftis_list[0]), batch_size):
        batch_end = min(batch_start + batch_size, len(niftis_list[0]))
        batch_niftis = [niftis[batch_start:batch_end] for niftis in niftis_list]
        batch_segmentations = segmentations[batch_start:batch_end]
        yield batch_start, batch_end, [[nib.load(nifti) for nifti in lst] for lst in batch_niftis], [nib.load(segmentation) for segmentation in batch_segmentations]

def extract_features_from_niftis(niftis, segmentations, features_filename, scan_types, processing_procedure, author, nifti_directory = ".//raw_niftis", file_directory=None, delete_intermediate=True, params=None, filters=None, ids_list = None, labels=[1], info_filename="radiomics_extraction.txt", target=None, clinical=None, batch_size=5):
    """
    Extract radiomics features from a list of NIfTI images and their segmentations.
    
    Parameters:
    
    * niftis (list[list[str]]): List of list of filenames NIfTI scans for each patient
    
    * segmentations (list[str]): List of filenames for segmentation files in NIfTI format.
    
    * features_filename (str): Filename to save csv of features to
    
    * scan_types (list): list of scan types considered
    
    * processing_procedure (list[tuple]): image pre-processing pipeline
    
    * author (str): name of author
    
    * nifti_directory (str): location of Nifti files of segmentations and patient images
    
    * file_directory (str, optional): Directory to save feature files. Defaults to None, in which case files are saved in the current working directory.
    
    * delete_intermediate (boolean): If true, delete the intermediate files of features for each batch
    
    * params (dict or str, optional): dictionary or name of .yaml file for specifying parameters
    
    * filters (dict, optional): Dictionary of filters to apply. Defaults to None.
    
    * ids_list (list, optional): List of patient IDs. Defaults to None.
    
    * labels (list): list of segmentation labels to use when extracting features
    
    * info_filename (str): filename to store information
    
    * target (series): list of target values
    
    * clinical: clinical features for each patient
    
    * batch_size (int, optional): Number of patients to process in each batch. Defaults to 5.
    
    Returns:

    * features (np.ndarray): Array of extracted radiomics features.
    
    * results (dict): Dictionary containing detailed feature extraction results.

    * streamlined_features (np.ndarray): Array of streamlined radiomics features.
    """
    # Loop through each NIfTI and its corresponding segmentation
    features_list = []
    results_list = []
    results_stripped_list = []
    streamlined_features_list = []
    #change from list of list of niftis for each patient to list of list of niftis for each modality
    niftis_list = niftis
    niftis_list = list(np.transpose(np.array(niftis)))     
    niftis_list = [list(item) for item in niftis_list]   
    nifti_indices = list(range(len(niftis_list)))
    del niftis
    gc.collect()
    #features_filenames = []
    #all_features_files = []
    reported = False   
    # Convert generators to lists for batching (only indices, not loading data yet)
    #nifti_indices = list(range(len(niftis_list)))
    batch_num = 0
    if file_directory is not None:
        os.makedirs(file_directory, exist_ok=True) #creates file directory if it does not exist
    os.chdir(nifti_directory)
    print('Current working directory:', os.getcwd())
    for batch_start, batch_end, batch_niftis, batch_segmentations in generate_batches(niftis_list, segmentations, batch_size): #loop through each batch
        for i, niftis_modality in enumerate(batch_niftis): #loop through each modality
            scan_type = scan_types[i]
            features_modality = []
            results_modality = []
            streamlined_features_modality = []
            for j, nifti in enumerate(niftis_modality): #loop through each patient
                segmentation = batch_segmentations[j]
                nifti = nifti_to_sitk(nifti)
                segmentation = nifti_to_sitk(segmentation)
                segmentation = sitk.Cast(segmentation, sitk.sitkUInt8)
                features_modality, results_modality, results_stripped, streamlined_features_modality, results = extract_features(
                    nifti, segmentation,
                    features_modality, results_modality, streamlined_features_modality, processing_procedure,
                    params=params, filters=filters, labels=labels
                )
                if not reported:
                    report(author, results, filters=filters, labels=labels, params=params, filename=info_filename)
                    reported = True

                del nifti, segmentation, results
                gc.collect()
            os.chdir("..")
            if file_directory is not None:
                os.chdir(file_directory) #ensures files are saved in file directory if specified
            name = f"features_{scan_type}_{batch_num}.csv"
            target_save = {k: v.iloc[batch_start:batch_end].reset_index(drop=True) for k, v in target.items()} if isinstance(target,pd.DataFrame) else target
            clinical_save = clinical.iloc[batch_start:batch_end].reset_index(drop=True) if clinical is not None else clinical
            save_features(results_stripped, streamlined_features_modality, name,
                        [scan_types[i]], filters=filters, segmentation_labels=labels,
                        target=target_save, clinical=clinical_save)
            if file_directory is not None:
                os.chdir("..")
            os.chdir(nifti_directory)
            del results_stripped, streamlined_features_modality, features_modality, results_modality, name
            gc.collect()
        batch_num += 1
        del batch_niftis, batch_segmentations
        gc.collect()
    os.chdir("..")  
    if file_directory is not None:
        os.chdir(file_directory)
    combine_batch_features(features_filename, batch_num, scan_types, ids_list=ids_list, filters=None)
    # Optional: Delete intermediate CSVs
    if delete_intermediate:
        for scan in scan_types:
            for i in range(batch_num):
                try:
                    os.remove(f"features_{scan}_{i}.csv")
                except Exception as e:
                    print(f"Could not delete: {e}")
    return features_list, results_list, np.array(streamlined_features_list)