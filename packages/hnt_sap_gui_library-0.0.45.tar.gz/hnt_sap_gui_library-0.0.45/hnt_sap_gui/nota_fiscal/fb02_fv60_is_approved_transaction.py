import logging
from datetime import datetime
from hnt_sap_gui.common.tx_result import TxResult
from hnt_sap_gui.hnt_sap_exception import HntSapException
from hnt_sap_gui.common.sap_status_bar import sbar_extracted_text
logger = logging.getLogger(__name__)
MSG_SAP_CODIGO_DOCUMENTO = "^Documento ([0-9]*) só foi pré-editado$"
DOCUMENTO_NAO_EXISTE_NO_EXERCICIO = '^O documento [0-9]+ HFNT não existe no exercício ([0-9]{4})$'
STATUS_LIBERACAO_BLOQUEADO_1 = '1'
STATUS_LIBERACAO_LIBERADO_2 = '2'
class Fb02Fv60IsApprovedTransaction:
    def __init__(self) -> None:
        pass

    def execute(self, sapGuiLib, codigo_contabil, empresa):
        logger.info(f"Enter execute codigo_contabil:{codigo_contabil}")
        sapGuiLib.run_transaction('/nFB02')
        sapGuiLib.session.findById("wnd[0]/usr/txtRF05L-BELNR").Text = codigo_contabil # '[SAP: Nº documento | Doc contábil da FV60]
        sapGuiLib.session.findById("wnd[0]/usr/ctxtRF05L-BUKRS").Text = empresa#  '[SAP: Empresa | Constante]
        exercicio = str(datetime.now().year)
        sapGuiLib.session.findById("wnd[0]/usr/txtRF05L-GJAHR").Text = exercicio#  '[SAP: Exercício | Ano lçto do doc contábil]
        sapGuiLib.send_vkey(0)

        sbar = sapGuiLib.session.findById("wnd[0]/sbar").Text
        sbar_exercicio = sbar_extracted_text(DOCUMENTO_NAO_EXISTE_NO_EXERCICIO, sbar)
        if sbar_exercicio is not None:
            raise HntSapException(f"Exercício atual {exercicio} é diferente do documento, sbar:{sbar}")

        sbar = sapGuiLib.session.findById("wnd[0]/sbar").Text
        documento = sbar_extracted_text(MSG_SAP_CODIGO_DOCUMENTO, sbar)
        if documento == codigo_contabil:
            result = TxResult(STATUS_LIBERACAO_BLOQUEADO_1, sbar)
        else:
            result = TxResult(STATUS_LIBERACAO_LIBERADO_2, sbar)
        
        logger.info(f"Leave execute taxa:{result}")
        return {
                "indicador_liberacao": result.codigo,
                "data_ultima_consulta_liberacao": result.created_at
        }
