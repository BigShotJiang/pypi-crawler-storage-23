# Copyright (c) 2026 Emanuele Bellocchia
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

"""Module for Mavryk address encoding/decoding."""

# Imports
from enum import Enum, unique
from typing import Any, Union

from typing_extensions import override

from bip_utils.addr.addr_dec_utils import AddrDecUtils
from bip_utils.addr.addr_key_validator import AddrKeyValidator
from bip_utils.addr.iaddr_decoder import IAddrDecoder
from bip_utils.addr.iaddr_encoder import IAddrEncoder
from bip_utils.base58 import Base58ChecksumError, Base58Decoder, Base58Encoder
from bip_utils.ecc import IPublicKey
from bip_utils.utils.crypto import Blake2b160


@unique
class MvrkAddrPrefixes(Enum):
    """Enumerative for Mavryk address prefixes."""

    MV1 = b"\x05\xBA\xC4"
    MV2 = b"\x05\xBA\xC7"
    MV3 = b"\x05\xBA\xC9"


class MvrkAddrDecoder(IAddrDecoder):
    """
    Mavryk address decoder class.
    It allows the Mavryk address decoding.
    """

    @override
    @staticmethod
    def DecodeAddr(addr: str,
                   **kwargs: Any) -> bytes:
        """
        Decode a Mavryk address to bytes.

        Args:
            addr (str): Address string

        Other Parameters:
            prefix (MvrkAddrPrefixes): Expected address prefix

        Returns:
            bytes: Public key hash bytes

        Raises:
            ValueError: If the address encoding is not valid
            TypeError: If the prefix is not a MvrkAddrPrefixes enum
        """

        # Get and check prefix
        prefix = kwargs["prefix"]
        if not isinstance(prefix, MvrkAddrPrefixes):
            raise TypeError("Address type is not an enumerative of MvrkAddrPrefixes")

        # Decode from base58
        try:
            addr_dec_bytes = Base58Decoder.CheckDecode(addr)
        except Base58ChecksumError as ex:
            raise ValueError("Invalid base58 checksum") from ex

        # Validate length
        AddrDecUtils.ValidateLength(addr_dec_bytes,
                                    len(prefix.value) + Blake2b160.DigestSize())
        # Validate and remove prefix
        blake_bytes = AddrDecUtils.ValidateAndRemovePrefix(addr_dec_bytes, prefix.value)

        return blake_bytes


class MvrkAddrEncoder(IAddrEncoder):
    """
    Mavryk address encoder class.
    It allows the Mavryk address encoding.
    """

    @override
    @staticmethod
    def EncodeKey(pub_key: Union[bytes, IPublicKey],
                  **kwargs: Any) -> str:
        """
        Encode a public key to Mavryk address.

        Args:
            pub_key (bytes or IPublicKey): Public key bytes or object

        Other Parameters:
            prefix (MvrkAddrPrefixes): Address prefix

        Returns:
            str: Address string

        Raises:
            ValueError: If the public key is not valid
            TypeError: If the public key is not ed25519 or the prefix is not a MvrkAddrPrefixes enum
        """

        # Get and check prefix
        prefix = kwargs["prefix"]
        if not isinstance(prefix, MvrkAddrPrefixes):
            raise TypeError("Address type is not an enumerative of MvrkAddrPrefixes")

        # Get public key
        pub_key_obj = AddrKeyValidator.ValidateAndGetEd25519Key(pub_key)

        # Compute Blake2b and encode in base58 with checksum
        blake_bytes = Blake2b160.QuickDigest(pub_key_obj.RawCompressed().ToBytes()[1:])

        return Base58Encoder.CheckEncode(prefix.value + blake_bytes)


# Deprecated: only for compatibility, Encoder class shall be used instead
MvrkAddr = MvrkAddrEncoder
