"""TEDCHECK - UMAP Segment Validation Tool"""

__version__ = "0.1.0"
__author__ = "Tergel Munkhbaatar"

from .config import Config
from .features import (
    apply_umap_reduction,
    calculate_umap_metrics,
    plot_umap_by_segment,
)
from .utils import (
    get_color_pool,
    assign_colors_to_segments,
)

from .exceptions import (
    TEDCheckException,
    ConfigError,
    MissingColumnsError,
    InvalidPresetError,
    DataValidationError,
)
from .logger import setup_logger, get_logger

__all__ = [
    "Config",
    "apply_umap_reduction",
    "calculate_umap_metrics",
    "plot_umap_by_segment",
    "get_color_pool",
    "assign_colors_to_segments",
    "TEDCheckException",
    "ConfigError",
    "MissingColumnsError",
    "InvalidPresetError",
    "DataValidationError",
    "setup_logger",
    "get_logger",
]
