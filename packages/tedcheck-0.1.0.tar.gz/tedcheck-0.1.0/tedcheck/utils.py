"""Utility functions for tedcheck package"""
import random
from typing import List, Dict


def get_color_pool() -> List[str]:
    """Get color pool for visualizations"""
    return [
        "#ff671b", "#fff824", "#ff1edd",
        "#5cc1ff", "#a21bf6", "#29FFBF",
        "#ffc5a8", "#fffca0", "#ffaaf2",
        "#a5ddff", "#dda5ff", "#A8FFE5"
    ]

def assign_colors_to_segments(segments: List, color_pool: List[str],
                             default_color: str = '#7F7F7F') -> Dict:
    """Assign colors to segments
    
    Args:
        segments: List of segment values
        color_pool: List of hex color codes
        default_color: Default color for missing segments
        
    Returns:
        Dictionary mapping segment values to colors
    """
    unique_segments = [s for s in segments if s is not None]
    color_map = {}
    color_map[None] = default_color
    
    if len(unique_segments) <= len(color_pool):
        shuffled_pool = color_pool.copy()
        random.shuffle(shuffled_pool)
        for i, seg in enumerate(unique_segments):
            color_map[seg] = shuffled_pool[i]
    else:
        shuffled_pool = color_pool.copy()
        random.shuffle(shuffled_pool)
        for i, seg in enumerate(unique_segments):
            if i < len(color_pool):
                color_map[seg] = shuffled_pool[i]
            else:
                color_map[seg] = default_color
    
    return color_map
