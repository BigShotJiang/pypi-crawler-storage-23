"""Custom exceptions for tedcheck package"""


class TEDCheckException(Exception):
    """Base exception for tedcheck package"""
    pass


class ConfigError(TEDCheckException):
    """Raised when configuration is invalid"""
    pass


class MissingColumnsError(TEDCheckException):
    """Raised when required columns are missing from dataframe"""
    pass


class InvalidPresetError(TEDCheckException):
    """Raised when preset configuration is not found"""
    pass


class DataValidationError(TEDCheckException):
    """Raised when data validation fails"""
    pass
