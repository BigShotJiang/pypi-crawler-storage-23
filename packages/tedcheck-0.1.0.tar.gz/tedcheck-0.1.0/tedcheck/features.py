import pandas as pd
import numpy as np
import plotly.graph_objects as go
import umap
import umap.umap_ as umap_
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_array as sk_check_array
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from sklearn.metrics import silhouette_score, silhouette_samples, homogeneity_score, completeness_score
from sklearn.ensemble import RandomForestRegressor
from typing import Dict, List, Optional, Tuple

from .config import Config
from .utils import get_color_pool, assign_colors_to_segments

console = Console()

def _check_array_compat(X, **kwargs):
    kwargs.pop("ensure_all_finite", None)
    kwargs.pop("force_all_finite", None)
    return sk_check_array(X, **kwargs)

umap_.check_array = _check_array_compat

def apply_umap_reduction(df, config=None, **kwargs):

    if config is None:
        config = Config(**kwargs)
    else:
        for key, value in kwargs.items():
            setattr(config, key, value)
    
    missing = config.validate_columns(df)
    if missing:
        console.print(f"[red]✗ Missing columns: {missing}[/red]")
        console.print(f"[yellow]Available columns: {list(df.columns)}[/yellow]")
        raise ValueError(f"Required columns not found: {missing}")
    
    num_cols = [c for c in df.select_dtypes(include=[np.number]).columns 
                if c not in config.exclude_cols]
    
    if config.include_cols:
        num_cols = [c for c in config.include_cols if c in df.columns]
    
    console.print(f"[cyan]Selected numeric columns for UMAP:[/cyan] [yellow]{num_cols}[/yellow]")
    
    X = df[num_cols].fillna(0)
    X_scaled = StandardScaler().fit_transform(X)
    
    console.print(f"[magenta]Applying UMAP reduction...[/magenta]")
    reducer = umap.UMAP(n_neighbors=config.n_neighbors, min_dist=config.min_dist, 
                        random_state=config.random_state)
    embedding = reducer.fit_transform(X_scaled)
    
    umap_cols = [config.user_id_col, config.segment_col]
    if config.time_col in df.columns:
        umap_cols.insert(1, config.time_col)
    
    df_umap = df[umap_cols].copy()
    df_umap['UMAP1'] = embedding[:, 0]
    df_umap['UMAP2'] = embedding[:, 1]

    console.print(f"[bold green]✓ UMAP reduction completed![/bold green]")
    
    return df_umap, embedding, num_cols

def calculate_umap_metrics(df, X_scaled, embedding, num_cols, config=None):
    """Calculate explainability metrics for UMAP"""
    
    if config is None:
        config = Config()
    
    console.print(Panel.fit("[bold cyan]Calculating UMAP Metrics[/bold cyan]"))
    
    console.print("[yellow]Computing feature importance...[/yellow]")
    rf1 = RandomForestRegressor(n_estimators=100, random_state=config.random_state)
    rf2 = RandomForestRegressor(n_estimators=100, random_state=config.random_state)
    
    rf1.fit(X_scaled, embedding[:, 0])
    rf2.fit(X_scaled, embedding[:, 1])
    
    feature_imp = pd.DataFrame({
        'feature': num_cols,
        'UMAP1_importance': rf1.feature_importances_,
        'UMAP2_importance': rf2.feature_importances_,
        'total_importance': rf1.feature_importances_ + rf2.feature_importances_
    }).sort_values('total_importance', ascending=False)
   
    console.print("[yellow]Calculating silhouette scores...[/yellow]")
    segments = df[config.segment_col].dropna()
    valid_embedding = embedding[df[config.segment_col].notna()]
    
    silhouette_avg = silhouette_score(valid_embedding, segments)
    silhouette_vals = silhouette_samples(valid_embedding, segments)
    
    segment_silhouettes = {}
    for seg in segments.unique():
        seg_scores = silhouette_vals[segments == seg]
        segment_silhouettes[seg] = seg_scores.mean()
    
    console.print("[yellow]Computing segment dispersion...[/yellow]")
    segment_dispersion = {}
    for seg in df[config.segment_col].dropna().unique():
        seg_data = embedding[df[config.segment_col] == seg]
        variance = np.var(seg_data, axis=0)
        segment_dispersion[seg] = {
            'UMAP1_var': variance[0],
            'UMAP2_var': variance[1],
            'total_var': variance.sum()
        }
    
    purity_metrics = None
    if config.cluster_col in df.columns:
        console.print("[yellow]Calculating purity scores...[/yellow]")
        valid_df = df[df[config.segment_col].notna()]
        homogeneity = homogeneity_score(valid_df[config.segment_col], valid_df[config.cluster_col])
        completeness = completeness_score(valid_df[config.segment_col], valid_df[config.cluster_col])
        
        purity_metrics = {
            'homogeneity': homogeneity,
            'completeness': completeness,
            'v_measure': 2 * (homogeneity * completeness) / (homogeneity + completeness)
        }
    
    _display_metrics(feature_imp, silhouette_avg, segment_silhouettes, 
                     segment_dispersion, purity_metrics)
    
    return {
        'feature_importance': feature_imp,
        'silhouette_avg': silhouette_avg,
        'segment_silhouettes': segment_silhouettes,
        'segment_dispersion': segment_dispersion,
        'purity_metrics': purity_metrics
    }

def _display_metrics(feature_imp, silhouette_avg, segment_silhouettes, 
                     segment_dispersion, purity_metrics):
    """Display metrics in rich tables"""
    
    table = Table(title="Top 10 Feature Importance", show_header=True, header_style="bold cyan")
    table.add_column("Feature", style="yellow")
    table.add_column("UMAP1", style="green")
    table.add_column("UMAP2", style="green")
    table.add_column("Total", style="bold green")
    
    for _, row in feature_imp.head(10).iterrows():
        table.add_row(
            row['feature'],
            f"{row['UMAP1_importance']:.4f}",
            f"{row['UMAP2_importance']:.4f}",
            f"{row['total_importance']:.4f}"
        )
    console.print(table)
    
    console.print(f"\n[bold cyan]Overall Silhouette Score:[/bold cyan] [green]{silhouette_avg:.4f}[/green]")
    
    table2 = Table(title="Silhouette Score by Segment", show_header=True, header_style="bold cyan")
    table2.add_column("Segment", style="yellow")
    table2.add_column("Score", style="green")
    
    for seg, score in segment_silhouettes.items():
        color = "green" if score > 0.5 else "yellow" if score > 0.3 else "red"
        table2.add_row(str(seg), f"[{color}]{score:.4f}[/{color}]")
    console.print(table2)
    
    table3 = Table(title="Segment Dispersion (Variance)", show_header=True, header_style="bold cyan")
    table3.add_column("Segment", style="yellow")
    table3.add_column("UMAP1 Var", style="green")
    table3.add_column("UMAP2 Var", style="green")
    table3.add_column("Total Var", style="bold green")
    
    for seg, disp in segment_dispersion.items():
        table3.add_row(
            str(seg),
            f"{disp['UMAP1_var']:.4f}",
            f"{disp['UMAP2_var']:.4f}",
            f"{disp['total_var']:.4f}"
        )
    console.print(table3)
    
    if purity_metrics:
        console.print(f"\n[bold cyan]Purity Metrics:[/bold cyan]")
        console.print(f"  [yellow]Homogeneity:[/yellow] [green]{purity_metrics['homogeneity']:.4f}[/green]")
        console.print(f"  [yellow]Completeness:[/yellow] [green]{purity_metrics['completeness']:.4f}[/green]")
        console.print(f"  [yellow]V-Measure:[/yellow] [green]{purity_metrics['v_measure']:.4f}[/green]")

def plot_umap_by_segment(df_umap, config=None, segment_colors=None, base_month=None):
    """Plot UMAP visualization by segment"""
    
    if config is None:
        config = Config()

    if segment_colors is None:
        unique_segments = df_umap[config.segment_col].unique().tolist()
        segment_colors = assign_colors_to_segments(unique_segments, get_color_pool())
        console.print(f"[cyan]Auto-assigned colors for {len(unique_segments)} segments[/cyan]")
    
    has_time_col = config.time_col in df_umap.columns
    
    if has_time_col:
        months = sorted(df_umap[config.time_col].dropna().unique())
        
        if base_month is not None:
            months = [m for m in months if m == base_month]
            if not months:
                console.print(f"[bold red]✗ Error: base_month {base_month} not found in data[/bold red]")
                return
        
        console.print(Panel.fit(f"[bold cyan]Generating UMAP plots for {len(months)} month(s)[/bold cyan]"))
        
        for m in track(months, description="[green]Creating visualizations..."):
            df_m = df_umap[df_umap[config.time_col] == m]
            fig = go.Figure()
            
            for seg in df_m[config.segment_col].unique():
                df_seg = df_m[df_m[config.segment_col] == seg]
                if df_seg.empty:
                    continue
                
                color = segment_colors.get(seg, '#7F7F7F')
                
                fig.add_trace(
                    go.Scatter(
                        x=df_seg['UMAP1'],
                        y=df_seg['UMAP2'],
                        mode='markers',
                        name=str(seg),
                        marker=dict(size=5, color=color, opacity=0.7)
                    )
                )
            
            fig.update_layout(
                title=f'UMAP by segment - {config.time_col} {m}',
                xaxis_title='UMAP1',
                yaxis_title='UMAP2',
                height=600,
                width=800,
                template='plotly_white',
                xaxis=dict(showgrid=False),
                yaxis=dict(showgrid=False)
            )
            
            filename = f'umap_segment_{m}.html'
            fig.write_html(filename)
            console.print(f"[green]✓ Saved: {filename}[/green]")
    else:
        
        console.print(Panel.fit("[bold cyan]Generating UMAP plot (no time dimension)[/bold cyan]"))
        
        fig = go.Figure()
        
        for seg in df_umap[config.segment_col].unique():
            df_seg = df_umap[df_umap[config.segment_col] == seg]
            if df_seg.empty:
                continue
            
            color = segment_colors.get(seg, '#7F7F7F')
            
            fig.add_trace(
                go.Scatter(
                    x=df_seg['UMAP1'],
                    y=df_seg['UMAP2'],
                    mode='markers',
                    name=str(seg),
                    marker=dict(size=5, color=color, opacity=0.7)
                )
            )
        
        fig.update_layout(
            title='UMAP by segment',
            xaxis_title='UMAP1',
            yaxis_title='UMAP2',
            height=600,
            width=800,
            template='plotly_white',
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=False)
        )
        
        filename = 'umap_segment_all.html'
        fig.write_html(filename)
        console.print(f"[green]✓ Saved: {filename}[/green]")

def main():
    import sys
    import json
    
    console.print(Panel.fit("[bold magenta]UMAP Customer Segmentation Visualizer[/bold magenta]", border_style="magenta"))
    
    if len(sys.argv) < 2:
        console.print("[yellow]Usage:[/yellow] python features.py <csv_file> [OPTIONS]")
        console.print("[yellow]Options:[/yellow]")
        console.print("  --base-month <value>          Filter by specific month (e.g., 202512)")
        console.print("  --user-id <col>               User ID column name (default: user_id)")
        console.print("  --time-col <col>              Time column name (default: base_month)")
        console.print("  --segment-col <col>           Segment column name (default: segment)")
        console.print("  --cluster-col <col>           Cluster column name (default: cluster_kmeans)")
        console.print("  --exclude-cols <col1,col2>    Columns to exclude from UMAP")
        console.print("  --include-cols <col1,col2>    Columns to include only (overrides exclude)")
        console.print("  --n-neighbors <int>           UMAP n_neighbors (default: 50)")
        console.print("  --min-dist <float>            UMAP min_dist (default: 0.1)")
        console.print("  --metrics                     Calculate and save metrics")
        console.print("  --config <json_file>          Load configuration from JSON file")
        console.print("  --skip-time                   Skip time column (if not available)")
        console.print("\n[yellow]Examples:[/yellow]")
        console.print("  python features.py data.csv --base-month 202512")
        console.print("  python features.py data.csv --segment-col my_segment --exclude-cols id,month")
        console.print("  python features.py data.csv --skip-time (if no time column)")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    config_dict = {}
    base_month = None
    calculate_metrics = False
    
    i = 2
    while i < len(sys.argv):
        arg = sys.argv[i]
        
        if arg == '--metrics':
            calculate_metrics = True
        elif arg == '--skip-time':
            config_dict['skip_time'] = True
        elif arg == '--config' and i + 1 < len(sys.argv):
            config_file = sys.argv[i + 1]
            try:
                with open(config_file, 'r') as f:
                    config_dict = json.load(f)
                console.print(f"[cyan]Loaded config from: {config_file}[/cyan]")
            except Exception as e:
                console.print(f"[red]Error loading config: {e}[/red]")
            i += 1
        elif arg == '--base-month' and i + 1 < len(sys.argv):
            try:
                base_month = int(sys.argv[i + 1])
            except ValueError:
                console.print(f"[red]Invalid base-month value[/red]")
            i += 1
        elif arg == '--user-id' and i + 1 < len(sys.argv):
            config_dict['user_id_col'] = sys.argv[i + 1]
            i += 1
        elif arg == '--time-col' and i + 1 < len(sys.argv):
            config_dict['time_col'] = sys.argv[i + 1]
            i += 1
        elif arg == '--segment-col' and i + 1 < len(sys.argv):
            config_dict['segment_col'] = sys.argv[i + 1]
            i += 1
        elif arg == '--cluster-col' and i + 1 < len(sys.argv):
            config_dict['cluster_col'] = sys.argv[i + 1]
            i += 1
        elif arg == '--exclude-cols' and i + 1 < len(sys.argv):
            config_dict['exclude_cols'] = [c.strip() for c in sys.argv[i + 1].split(',')]
            i += 1
        elif arg == '--include-cols' and i + 1 < len(sys.argv):
            config_dict['include_cols'] = [c.strip() for c in sys.argv[i + 1].split(',')]
            i += 1
        elif arg == '--n-neighbors' and i + 1 < len(sys.argv):
            try:
                config_dict['n_neighbors'] = int(sys.argv[i + 1])
            except ValueError:
                console.print(f"[red]Invalid n-neighbors value[/red]")
            i += 1
        elif arg == '--min-dist' and i + 1 < len(sys.argv):
            try:
                config_dict['min_dist'] = float(sys.argv[i + 1])
            except ValueError:
                console.print(f"[red]Invalid min-dist value[/red]")
            i += 1
        
        i += 1
    
    config = Config(**config_dict)
    
    console.print(f"[cyan]Loading data from:[/cyan] [bold]{csv_file}[/bold]")
    df_segments_monthly = pd.read_csv(csv_file)
    
    missing = config.validate_columns(df_segments_monthly)
    if missing:
        console.print(f"[bold red]✗ Error: Missing required columns: {missing}[/bold red]")
        console.print(f"[yellow]Available columns: {list(df_segments_monthly.columns)}[/yellow]")
        console.print(f"[cyan]Use --skip-time to skip missing time column[/cyan]")
        sys.exit(1)
    
    console.print(Panel.fit("[bold cyan]Active Configuration[/bold cyan]"))
    console.print(f"  [yellow]User ID Column:[/yellow] [green]{config.user_id_col}[/green]")
    if config.time_col in df_segments_monthly.columns:
        console.print(f"  [yellow]Time Column:[/yellow] [green]{config.time_col}[/green]")
    else:
        console.print(f"  [yellow]Time Column:[/yellow] [red]Not available (skipped)[/red]")
    console.print(f"  [yellow]Segment Column:[/yellow] [green]{config.segment_col}[/green]")
    console.print(f"  [yellow]Cluster Column:[/yellow] [green]{config.cluster_col}[/green]")
    console.print(f"  [yellow]Exclude Columns:[/yellow] [green]{config.exclude_cols}[/green]")
    if config.include_cols:
        console.print(f"  [yellow]Include Columns:[/yellow] [green]{config.include_cols}[/green]")
    
    table = Table(title="Data Summary", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="yellow")
    table.add_column("Value", style="green")
    table.add_row("Total Records", f"{df_segments_monthly.shape[0]:,}")
    table.add_row("Total Columns", f"{df_segments_monthly.shape[1]}")
    table.add_row("Unique Users", f"{df_segments_monthly[config.user_id_col].nunique():,}")
    if config.time_col in df_segments_monthly.columns:
        table.add_row("Unique Months", f"{df_segments_monthly[config.time_col].nunique()}")
    console.print(table)
    
    df_umap, embedding, num_cols = apply_umap_reduction(df_segments_monthly, config=config)

    if calculate_metrics:
        exclude_cols = [c for c in config.exclude_cols if c in df_segments_monthly.columns]
        numeric_cols = [c for c in df_segments_monthly.select_dtypes(include=[np.number]).columns 
                       if c not in exclude_cols]
        
        if config.include_cols:
            numeric_cols = [c for c in config.include_cols if c in df_segments_monthly.columns]
        
        metrics = calculate_umap_metrics(
            df_umap, 
            StandardScaler().fit_transform(df_segments_monthly[numeric_cols].fillna(0)),
            embedding,
            numeric_cols,
            config=config
        )

        metrics_output = {
            'silhouette_avg': float(metrics['silhouette_avg']),
            'segment_silhouettes': {str(k): float(v) for k, v in metrics['segment_silhouettes'].items()},
            'purity_metrics': metrics['purity_metrics']
        }
        
        with open('umap_metrics.json', 'w') as f:
            json.dump(metrics_output, f, indent=2)
        
        metrics['feature_importance'].to_csv('feature_importance.csv', index=False)
        console.print("[green]✓ Metrics saved to umap_metrics.json and feature_importance.csv[/green]")
    
    plot_umap_by_segment(df_umap, config=config, base_month=base_month)
    
    output_file = csv_file.replace('.csv', '_umap_results.csv')
    df_umap.to_csv(output_file, index=False)
    
    console.print(Panel.fit(
        f"[bold green]✓ Processing Complete![/bold green]\n"
        f"[cyan]Results saved to:[/cyan] [bold]{output_file}[/bold]",
        border_style="green"
    ))

if __name__ == "__main__":
    main()
