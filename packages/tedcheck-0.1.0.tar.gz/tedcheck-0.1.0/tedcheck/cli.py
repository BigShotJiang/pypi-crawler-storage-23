import sys
import json
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

from .config import Config
from .features import apply_umap_reduction, calculate_umap_metrics, plot_umap_by_segment
from .exceptions import MissingColumnsError, ConfigError
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

def print_help():
    """Print help message"""
    console.print("[yellow]Usage:[/yellow] tedcheck <csv_file> [OPTIONS]")
    console.print("[yellow]Options:[/yellow]")
    console.print("  --base-month <value>          Filter by specific month")
    console.print("  --user-id <col>               User ID column name")
    console.print("  --time-col <col>              Time column name")
    console.print("  --segment-col <col>           Segment column name")
    console.print("  --cluster-col <col>           Cluster column name")
    console.print("  --exclude-cols <col1,col2>    Columns to exclude")
    console.print("  --include-cols <col1,col2>    Columns to include only")
    console.print("  --n-neighbors <int>           UMAP n_neighbors")
    console.print("  --min-dist <float>            UMAP min_dist")
    console.print("  --metrics                     Calculate metrics")
    console.print("  --config <json_file>          Load config from JSON")
    console.print("  --preset <name>               Load preset (default, ecommerce, saas)")
    console.print("  --skip-time                   Skip time column if not available")

def parse_args(args: list) -> dict:
    """Parse command line arguments"""
    config_dict = {}
    options = {
        'base_month': None,
        'calculate_metrics': False,
    }
    
    i = 0
    while i < len(args):
        arg = args[i]
        
        if arg == '--metrics':
            options['calculate_metrics'] = True
        elif arg == '--skip-time':
            config_dict['skip_time'] = True
        elif arg == '--config' and i + 1 < len(args):
            try:
                config_dict = json.loads(Path(args[i + 1]).read_text())
            except Exception as e:
                console.print(f"[red]Error loading config: {e}[/red]")
                sys.exit(1)
            i += 1
        elif arg == '--preset' and i + 1 < len(args):
            try:
                config = Config.from_preset(args[i + 1])
                config_dict = config.to_dict()
            except ValueError as e:
                console.print(f"[red]Error: {e}[/red]")
                sys.exit(1)
            i += 1
        elif arg == '--base-month' and i + 1 < len(args):
            try:
                options['base_month'] = int(args[i + 1])
            except ValueError:
                console.print("[red]Invalid base-month value[/red]")
            i += 1
        elif arg == '--user-id' and i + 1 < len(args):
            config_dict['user_id_col'] = args[i + 1]
            i += 1
        elif arg == '--time-col' and i + 1 < len(args):
            config_dict['time_col'] = args[i + 1]
            i += 1
        elif arg == '--segment-col' and i + 1 < len(args):
            config_dict['segment_col'] = args[i + 1]
            i += 1
        elif arg == '--cluster-col' and i + 1 < len(args):
            config_dict['cluster_col'] = args[i + 1]
            i += 1
        elif arg == '--exclude-cols' and i + 1 < len(args):
            config_dict['exclude_cols'] = [c.strip() for c in args[i + 1].split(',')]
            i += 1
        elif arg == '--include-cols' and i + 1 < len(args):
            config_dict['include_cols'] = [c.strip() for c in args[i + 1].split(',')]
            i += 1
        elif arg == '--n-neighbors' and i + 1 < len(args):
            try:
                config_dict['n_neighbors'] = int(args[i + 1])
            except ValueError:
                console.print("[red]Invalid n-neighbors value[/red]")
            i += 1
        elif arg == '--min-dist' and i + 1 < len(args):
            try:
                config_dict['min_dist'] = float(args[i + 1])
            except ValueError:
                console.print("[red]Invalid min-dist value[/red]")
            i += 1
        
        i += 1
    
    return config_dict, options

def main():
    """Main CLI entry point"""
    if len(sys.argv) < 2:
        print_help()
        sys.exit(1)
    
    csv_file = sys.argv[1]
    config_dict, options = parse_args(sys.argv[2:])
    
    try:
        config = Config(**config_dict)
    except Exception as e:
        console.print(f"[red]Error creating config: {e}[/red]")
        sys.exit(1)
    
    console.print(Panel.fit("[bold magenta]UMAP Customer Segmentation Visualizer[/bold magenta]", 
                           border_style="magenta"))
    
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        console.print(f"[red]Error: File not found: {csv_file}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error loading file: {e}[/red]")
        sys.exit(1)
    
    missing = config.validate_columns(df)
    if missing:
        console.print(f"[bold red]✗ Error: Missing required columns: {missing}[/bold red]")
        console.print(f"[yellow]Available columns: {list(df.columns)}[/yellow]")
        console.print(f"[cyan]Use --skip-time to skip missing time column[/cyan]")
        sys.exit(1)
    
    console.print(Panel.fit("[bold cyan]Active Configuration[/bold cyan]"))
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Setting", style="yellow")
    table.add_column("Value", style="green")
    for key, value in config.to_dict().items():
        table.add_row(key, str(value))
    console.print(table)
    
    data_table = Table(title="Data Summary", show_header=True, header_style="bold cyan")
    data_table.add_column("Metric", style="yellow")
    data_table.add_column("Value", style="green")
    data_table.add_row("Total Records", f"{df.shape[0]:,}")
    data_table.add_row("Total Columns", f"{df.shape[1]}")
    data_table.add_row("Unique Users", f"{df[config.user_id_col].nunique():,}")
    if config.time_col in df.columns:
        data_table.add_row("Unique Months", f"{df[config.time_col].nunique()}")
    console.print(data_table)
    
    try:
        df_umap, embedding, num_cols = apply_umap_reduction(df, config=config)
    except Exception as e:
        console.print(f"[red]Error during UMAP reduction: {e}[/red]")
        sys.exit(1)
    
    if options['calculate_metrics']:
        try:
            exclude_cols = [c for c in config.exclude_cols if c in df.columns]
            numeric_cols = [c for c in df.select_dtypes(include=[np.number]).columns 
                           if c not in exclude_cols]
            
            if config.include_cols:
                numeric_cols = [c for c in config.include_cols if c in df.columns]
            
            metrics = calculate_umap_metrics(
                df_umap,
                StandardScaler().fit_transform(df[numeric_cols].fillna(0)),
                embedding,
                numeric_cols,
                config=config
            )
            
            console.print("[green]✓ Metrics saved to umap_metrics.json and feature_importance.csv[/green]")
        except Exception as e:
            console.print(f"[red]Error calculating metrics: {e}[/red]")
    
    try:
        plot_umap_by_segment(df_umap, config=config, base_month=options['base_month'])
    except Exception as e:
        console.print(f"[red]Error creating visualizations: {e}[/red]")
        sys.exit(1)
    
    output_file = csv_file.replace('.csv', '_umap_results.csv')
    try:
        df_umap.to_csv(output_file, index=False)
    except Exception as e:
        console.print(f"[red]Error saving results: {e}[/red]")
        sys.exit(1)
    
    console.print(Panel.fit(
        f"[bold green]✓ Processing Complete![/bold green]\n[cyan]Results saved to: {output_file}[/cyan]",
        border_style="green"
    ))


if __name__ == '__main__':
    main()