import json
from pathlib import Path
from typing import Optional, List, Dict, Any

class Config:
    """Configuration class for UMAP analysis"""
    DEFAULT_CONFIG = {
        'user_id_col': 'user_id',
        'time_col': 'base_month',
        'segment_col': 'segment',
        'cluster_col': 'cluster_kmeans',
        'exclude_cols': ['user_id', 'base_month', 'segment', 'base_month_max'],
        'include_cols': None,
        'n_neighbors': 50,
        'min_dist': 0.1,
        'random_state': 42,
        'skip_time': False,
    }
    
    def __init__(self, **kwargs):
        """Initialize Config with default or custom values"""
        self.user_id_col = kwargs.get('user_id_col', self.DEFAULT_CONFIG['user_id_col'])
        self.time_col = kwargs.get('time_col', self.DEFAULT_CONFIG['time_col'])
        self.segment_col = kwargs.get('segment_col', self.DEFAULT_CONFIG['segment_col'])
        self.cluster_col = kwargs.get('cluster_col', self.DEFAULT_CONFIG['cluster_col'])
        self.exclude_cols = kwargs.get('exclude_cols', self.DEFAULT_CONFIG['exclude_cols'])
        self.include_cols = kwargs.get('include_cols', self.DEFAULT_CONFIG['include_cols'])
        self.n_neighbors = kwargs.get('n_neighbors', self.DEFAULT_CONFIG['n_neighbors'])
        self.min_dist = kwargs.get('min_dist', self.DEFAULT_CONFIG['min_dist'])
        self.random_state = kwargs.get('random_state', self.DEFAULT_CONFIG['random_state'])
        self.skip_time = kwargs.get('skip_time', self.DEFAULT_CONFIG['skip_time'])
    
    def validate_columns(self, df) -> List[str]:
        """Validate that required columns exist in dataframe"""
        missing = []
        if not self.skip_time and self.time_col not in df.columns:
            missing.append(self.time_col)
        if self.user_id_col not in df.columns:
            missing.append(self.user_id_col)
        if self.segment_col not in df.columns:
            missing.append(self.segment_col)
        return missing
    
    @classmethod
    def from_json(cls, filepath: str) -> 'Config':
        """Load config from JSON file"""
        with open(filepath, 'r') as f:
            config_dict = json.load(f)
        return cls(**config_dict)
    
    @classmethod
    def from_preset(cls, preset_name: str) -> 'Config':
        """Load config from preset (default, ecommerce, saas)"""
        presets_dir = Path(__file__).parent / 'configs'
        preset_file = presets_dir / f'{preset_name}.json'
        
        if not preset_file.exists():
            raise ValueError(f"Preset '{preset_name}' not found in {presets_dir}")
        
        return cls.from_json(str(preset_file))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return self.__dict__
    
    def to_json(self, filepath: str) -> None:
        """Save config to JSON file"""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    def update(self, **kwargs) -> None:
        """Update config values"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
    
    def __repr__(self) -> str:
        return f"Config({self.to_dict()})"