Examples
========

Practical examples demonstrating GPClarity features.

.. toctree::
   :maxdepth: 1

   basic_usage
   kernel_comparison
   uncertainty_calibration
   optimization_diagnostics