hyperparam_tracker module
=========================

.. automodule:: gpclarity.hyperparam_tracker
   :members:
   :undoc-members:
   :show-inheritance:

Classes
-------

.. autosummary::
   :nosignatures:

   HyperparameterTracker
   OptimizationState
   ConvergenceMetrics

Functions
---------

.. autosummary::
   :nosignatures:

   (none - all functionality via HyperparameterTracker class)