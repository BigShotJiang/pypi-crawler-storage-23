Advanced Topics
===============

.. toctree::
   :maxdepth: 1

   custom_scorers
   integration_sklearn
   performance_tuning