API Reference
=============

.. autosummary::
   :toctree: generated
   :recursive:

   gpclarity
