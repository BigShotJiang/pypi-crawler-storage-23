# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.2.1] - 2026-02-19

### Changed

- Upgraded `xapian_model` dependency from `>=0.3.0` to `>=0.3.1`.
- Upgraded transitive `pyxapiand` dependency from `>=2.0.0` to `>=2.1.0`.

## [0.2.0] - 2026-02-17

### Changed

- Upgraded `xapian_model` dependency from `>=0.2.0` to `>=0.3.0`.
- Fully async API: `create`, `get`, `filter`, `save`, and `delete` are now coroutines (via `pyxapiand>=2.0.0` with `httpx` backend).
- Updated copyright years to 2019-2026.

### Fixed

- `__version__` in `__init__.py` now matches `pyproject.toml`.

## [0.1.1] - 2025-01-01

### Changed

- Simplified `.envrc` to use manual venv creation.

### Fixed

- Fixed docstrings in `models.py`.
- Fixed `pyxapiand` import and simplified schema API.

## [0.1.0] - 2024-12-01

### Added

- Initial release of `xprofile` package.
- `XProfile` model class built on `xapian_model.base.BaseXapianModel`.
- Comprehensive profile schema with 30+ fields via `get_profile_schema()`.
- Profile type constants: `personal`, `business`, `reseller`, `referral`, `supplier`, `mashup`, `affinity`, `dssupplier`.
- Security design: `INDEX_TEMPLATE`, `_foreign` field, and admin constants must be defined per-application.
- Python 3.12+ support with full type hints.
- Hatchling-based build system with src layout.
- Published to PyPI as `xapian-profile`.
