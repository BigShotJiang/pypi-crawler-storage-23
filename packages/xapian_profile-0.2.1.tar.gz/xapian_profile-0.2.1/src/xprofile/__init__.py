"""XProfile package for Xapian-based user profile management.

This package provides the XProfile model class for storing and managing
user profiles in Xapian indexes with schema validation and routing.
"""
from __future__ import annotations

__version__ = "0.2.1"

from .models import XProfile

__all__ = ["XProfile"]
