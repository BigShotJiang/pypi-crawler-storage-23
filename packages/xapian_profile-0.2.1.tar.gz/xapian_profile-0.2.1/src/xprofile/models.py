"""
Dubalu Framework: xprofile
~~~~~~~~~~~~~~~~~~~~~~~~~~

:author: Dubalu Framework Team. See AUTHORS.
:copyright: Copyright (c) 2019-2026 Dubalu International LLC. All Rights Reserved.
:license: See LICENSE for license details.

"""
from __future__ import annotations

from xapian_model.base import BaseXapianModel

from .schemas import get_profile_schema


class XProfile(BaseXapianModel):
    """User profile model stored in Xapian index.

    This model extends BaseXapianModel to provide profile management
    with automatic index routing.

    Attributes:
        INDEX_TEMPLATE: The Xapian index name for profile storage.
        SCHEMA: The complete schema definition for profile fields.
    """
    INDEX_TEMPLATE = 'profiles'  # Example index
    SCHEMA = get_profile_schema(foreign_schema='.schemas/profile')  # Example foreign schema reference
