"""
Dubalu Framework: xprofile
~~~~~~~~~~~~~~~~~~~~~~~~~~

:author: Dubalu Framework Team. See AUTHORS.
:copyright: Copyright (c) 2019-2026 Dubalu International LLC. All Rights Reserved.
:license: See LICENSE for license details.

"""
from __future__ import annotations

from xapiand import constants as xconst

__all__ = [
    "PERSONAL_TYPE",
    "BUSINESS_TYPE",
    "RESELLER_TYPE",
    "REFERRAL_TYPE",
    "SUPPLIER_TYPE",
    "MASHUP_TYPE",
    "AFFINITY_TYPE",
    "DSSUPPLIER_TYPE",
    "get_profile_schema",
]

PERSONAL_TYPE = 'personal'
BUSINESS_TYPE = 'business'
RESELLER_TYPE = 'reseller'
REFERRAL_TYPE = 'referral'
SUPPLIER_TYPE = 'supplier'
MASHUP_TYPE = 'mashup'
AFFINITY_TYPE = 'affinity'
DSSUPPLIER_TYPE = 'dssupplier'


def get_profile_schema(foreign_schema: str) -> dict[str, dict[str, object]]:
    """Return the schema definition for user profiles.

    Args:
        foreign_schema: The foreign schema reference path for the profile
            (e.g. ``'.schemas/{PROFILE_SCHEMA_ID}'``).

    Returns:
        A dictionary mapping field names to their schema configuration,
        including type, index, validation, and help text metadata.
    """
    return {
        "_schema": {
            '_type': 'foreign/object',
            '_foreign': foreign_schema, # can be defined in your application code
            '_meta': {
                'description': 'Profile schema',
            }
        },
        'id': {
            '_type': 'uuid',
        },
        'visibility': {
            '_type': 'array/term',
            '_required': False,
            '_write_only': True,
        },
        'created_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
        },
        'updated_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
            '_accuracy': xconst.DAY_TO_YEAR_ACCURACY,
        },
        'deleted_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
            '_accuracy': xconst.DAY_TO_YEAR_ACCURACY,
        },
        'is_deleted': {
            '_type': 'boolean',
            '_required': False,
            '_default': False,
        },
        "name": {
            "_type": "string",
            "_index": "terms",
        },
        "mashup": {
            "_type": "uuid",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "is_active": {
            "_type": "boolean",
            "_index": "field_terms",
            "_default": False,
        },
        "is_guest": {
            "_type": "boolean",
            "_index": "field_terms",
            "_default": False,
        },
        "guest_prefix": {
            "_type": "term",
            "_index": "none",
            "_required": False,
            "_null": True,
        },
        "public_guest_key": {
            "_type": "term",
            "_index": "none",
            "_required": False,
            "_null": True,
        },
        "slug": {
            "_type": "string",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "store_id": {
            "_type": "uuid",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "subscriptions": {
            "_type": "json",
            "_index": "none",
            "_required": False,
            "_null": True,
        },
        "referral": {
            "_type": "uuid",
            "_index": "terms",
            "_required": False,
            "_null": True,
        },
        "campaign": {
            "_type": "term",
            "_index": "terms",
            "_required": False,
            "_null": True,
        },
        "click_id": {
            "_type": "term",
            "_index": "terms",
            "_required": False,
            "_null": True,
        },
        "main_type": {
            "_type": "term",
            "_index": "field_terms",
            "_choices": (PERSONAL_TYPE, BUSINESS_TYPE, RESELLER_TYPE,
                REFERRAL_TYPE, AFFINITY_TYPE, DSSUPPLIER_TYPE,
                SUPPLIER_TYPE, MASHUP_TYPE),
            "_required": False,
        },
        "is_proxy": {
            "_type": "boolean",
            "_index": "field_all",
            "_required": False,
            "_default": False,
        },
        "root_affinity_store_owner": {
            "_type": "uuid",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        # PRIVATE contact info
        "username_email": {
            "_type": "term",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "username_phone": {
            "_type": "term",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "contact_email": {
            "_type": "term",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "is_contact_email_active": {
            "_type": "boolean",
            "_index": "field_all",
            "_required": False,
        },
        "contact_phone": {
            "_type": "term",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "contact_country_code": {
            "_type": "term",
            "_index": "field_terms",
            "_required": False,
            "_null": True,
        },
        "is_contact_phone_active": {
            "_type": "boolean",
            "_index": "field_all",
            "_required": False,
        },
        "images": {
            "_type": "json",
            "_index": "none",
            "_required": False,
        },
        "heartbeat": {
            "_type": "date",
            "_index": "none",
            "_required": False,
            "_null": True,
        },
    }
