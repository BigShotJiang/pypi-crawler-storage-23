from __future__ import annotations

import csv
from pathlib import Path

from worai.errors import UsageError


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        item = value.strip()
        if not item or item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def load_urls_from_file(path: Path) -> list[str]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                return []
            lowered = [str(name).strip().lower() for name in reader.fieldnames]
            if "url" not in lowered:
                raise UsageError(f"CSV source '{path}' is missing required 'url' column.")
            idx = lowered.index("url")
            key = reader.fieldnames[idx]
            rows = [str((row or {}).get(key, "")).strip() for row in reader]
            return _dedupe(rows)

    lines = path.read_text(encoding="utf-8").splitlines()
    rows = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith("#")]
    return _dedupe(rows)
