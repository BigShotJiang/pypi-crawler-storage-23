"""Fetch and cache README files for Python dependencies."""

__version__ = "0.1.2"
