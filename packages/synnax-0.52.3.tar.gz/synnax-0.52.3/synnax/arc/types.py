#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.

from uuid import UUID

from pydantic import BaseModel

from synnax import task

TASK_TYPE = "arc"


class TaskConfig(BaseModel):
    """Configuration for an Arc task."""

    arc_key: str
    """The key of the Arc program to execute (UUID as string)."""
    auto_start: bool = False
    """Whether to start the task automatically when created."""


class Task(task.StarterStopperMixin, task.JSONConfigMixin, task.Protocol):
    """A task for executing Arc programs on a Synnax cluster."""

    TYPE = TASK_TYPE
    config: TaskConfig
    _internal: task.Task

    def __init__(
        self,
        internal: task.Task | None = None,
        *,
        name: str = "Arc Task",
        arc_key: UUID | str | None = None,
        auto_start: bool = False,
    ):
        """Initialize an Arc task.

        :param internal: Internal task object (used when loading from server).
        :param name: Human-readable name for the task.
        :param arc_key: The key of the Arc program to execute.
        :param auto_start: Whether to start the task automatically.
        """
        if internal is not None:
            self._internal = internal
            self.config = TaskConfig.model_validate(internal.config)
            return
        if arc_key is None:
            raise ValueError("arc_key is required when creating a new ArcTask")
        self._internal = task.Task(name=name, type=self.TYPE)
        self.config = TaskConfig(arc_key=str(arc_key), auto_start=auto_start)


from synnax.util.deprecation import deprecated_getattr

_DEPRECATED = {
    "ArcTask": "Task",
    "ArcTaskConfig": "TaskConfig",
}

__getattr__ = deprecated_getattr(__name__, _DEPRECATED, globals())
