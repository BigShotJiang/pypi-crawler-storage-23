"""Polars Avro tests."""
