---
title: CLI Plan – Parity Checklist (Make → ph)
type: checklist
date: 2026-01-14
tags: [cli, parity, make, checklist]
links:
  - ./v1_cli/CLI_CONTRACT.md
  - ./v0_make/MAKE_CONTRACT.md
---

# CLI Parity Checklist (Make → `ph`)

This checklist is the **exhaustive parity verification** for the Make-to-CLI mapping defined in `cli_plan/v1_cli/CLI_CONTRACT.md` (“Make-to-CLI mapping (exhaustive)”).

## Conventions

- Prefer running against a disposable copy of the handbook repo.
- Use explicit root selection for determinism: `ph --root <PH_ROOT> ...`
- Output paths are **PH_ROOT-relative** (POSIX style).
- This checklist targets the reference Make interface in `/Users/spensermcconnell/__Active_Code/oss-saas/project-handbook` (invoked as `pnpm make -- <target>` or `make <target>`).

## Checklist (exhaustive)

### Help

- [ ] `make help` → `ph help`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help`
  - Outputs to verify: (none; stdout only)
- [ ] `make help sprint` / `make help-sprint` → `ph help sprint`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help sprint`
  - Outputs to verify: (none; stdout only)
- [ ] `make help task` / `make help-task` → `ph help task`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help task`
  - Outputs to verify: (none; stdout only)
- [ ] `make help feature` / `make help-feature` → `ph help feature`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help feature`
  - Outputs to verify: (none; stdout only)
- [ ] `make help release` / `make help-release` → `ph help release`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help release`
  - Outputs to verify: (none; stdout only)
- [ ] `make help backlog` / `make help-backlog` → `ph help backlog`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help backlog`
  - Outputs to verify: (none; stdout only)
- [ ] `make help parking` / `make help-parking` → `ph help parking`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help parking`
  - Outputs to verify: (none; stdout only)
- [ ] `make help validation` / `make help-validation` → `ph help validation`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help validation`
  - Outputs to verify: (none; stdout only)
- [ ] `make help utilities` / `make help-utilities` → `ph help utilities`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> help utilities`
  - Outputs to verify: (none; stdout only)

### Daily (project)

- [ ] `make daily` → `ph daily generate`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> daily generate`
  - Outputs to verify: `status/daily/YYYY/MM/DD.md`
- [ ] `make daily-force` → `ph daily generate --force`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> daily generate --force`
  - Outputs to verify: `status/daily/YYYY/MM/DD.md`
- [ ] `make daily-check` → `ph daily check --verbose`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> daily check --verbose`
  - Outputs to verify: (none; stdout only)

### Sprint (project)

- [ ] `make sprint-plan` → `ph sprint plan`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> sprint plan`
  - Outputs to verify: `sprints/<year>/<SPRINT-...>/plan.md`, `sprints/current`
- [ ] `make sprint-open sprint=SPRINT-...` → `ph sprint open --sprint SPRINT-...`
  - Preconditions: `sprints/<year>/<SPRINT-...>/` exists
  - Command: `ph --root <PH_ROOT> sprint open --sprint SPRINT-...`
  - Outputs to verify: `sprints/current`
- [ ] `make sprint-status` → `ph sprint status`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> sprint status`
  - Outputs to verify: (none; stdout only)
- [ ] `make sprint-tasks` → `ph sprint tasks`
  - Preconditions: `sprints/current` exists
  - Command: `ph --root <PH_ROOT> sprint tasks`
  - Outputs to verify: (none; stdout only)
- [ ] `make burndown` → `ph sprint burndown`
  - Preconditions: `sprints/current` exists
  - Command: `ph --root <PH_ROOT> sprint burndown`
  - Outputs to verify: `sprints/<year>/<SPRINT-...>/burndown.md`
- [ ] `make sprint-capacity` → `ph sprint capacity`
  - Preconditions: `sprints/current` exists
  - Command: `ph --root <PH_ROOT> sprint capacity`
  - Outputs to verify: (none; stdout only)
- [ ] `make sprint-archive [sprint=SPRINT-...]` → `ph sprint archive [--sprint SPRINT-...]`
  - Preconditions: sprint exists (`sprints/<year>/<SPRINT-...>/`)
  - Command: `ph --root <PH_ROOT> sprint archive [--sprint SPRINT-...]`
  - Outputs to verify: `sprints/archive/**`, `sprints/archive/index.json`
- [ ] `make sprint-close` → `ph sprint close`
  - Preconditions: `sprints/current` exists
  - Command: `ph --root <PH_ROOT> sprint close`
  - Outputs to verify: `sprints/<year>/<SPRINT-...>/retrospective.md`, `sprints/archive/**`, `sprints/archive/index.json`

### Task (project)

- [ ] `make task-create ...` → `ph task create ...`
  - Preconditions: `sprints/current` exists; referenced feature exists; lane must not start with `handbook/`
  - Command: `ph --root <PH_ROOT> task create --title "..." --feature <name> --decision ADR-0000 --points 1 --lane ops --session task-execution`
  - Outputs to verify: `sprints/current/tasks/TASK-###-*/task.yaml` (and other task files under the same directory)
- [ ] `make task-list` → `ph task list`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> task list`
  - Outputs to verify: (none; stdout only)
- [ ] `make task-show id=TASK-###` → `ph task show --id TASK-###`
  - Preconditions: `sprints/**/tasks/TASK-###-*/` exists
  - Command: `ph --root <PH_ROOT> task show --id TASK-###`
  - Outputs to verify: (none; stdout only)
- [ ] `make task-status id=TASK-### status=doing [force=true]` → `ph task status --id TASK-### --status doing [--force]`
  - Preconditions: `sprints/**/tasks/TASK-###-*/task.yaml` exists
  - Command: `ph --root <PH_ROOT> task status --id TASK-### --status doing [--force]`
  - Outputs to verify: `sprints/**/tasks/TASK-###-*/task.yaml`

### Feature (project)

- [ ] `make feature-list` → `ph feature list`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> feature list`
  - Outputs to verify: (none; stdout only)
- [ ] `make feature-create name=<name>` → `ph feature create --name <name>`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> feature create --name <name>`
  - Outputs to verify: `features/<name>/`
- [ ] `make feature-status name=<name> stage=<stage>` → `ph feature status --name <name> --stage <stage>`
  - Preconditions: `features/<name>/` exists
  - Command: `ph --root <PH_ROOT> feature status --name <name> --stage <stage>`
  - Outputs to verify: `features/<name>/overview.md` (front matter/status fields updated)
- [ ] `make feature-update-status` → `ph feature update-status`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> feature update-status`
  - Outputs to verify: `features/**/status.md` (and/or other feature status artifacts written by updater)
- [ ] `make feature-summary` → `ph feature summary`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> feature summary`
  - Outputs to verify: (none; stdout only)
- [ ] `make feature-archive name=<name> [force=true]` → `ph feature archive --name <name> [--force]`
  - Preconditions: `features/<name>/` exists
  - Command: `ph --root <PH_ROOT> feature archive --name <name> [--force]`
  - Outputs to verify: `features/implemented/<name>/`

### Backlog (project)

- [ ] `make backlog-add ...` → `ph backlog add ...`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> backlog add --type bugs --title \"...\" --severity P2`
  - Outputs to verify: `backlog/index.json`, `backlog/<type>/<ID>/**`
- [ ] `make backlog-list ...` → `ph backlog list ...`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> backlog list ...`
  - Outputs to verify: (none; stdout only)
- [ ] `make backlog-triage issue=<ID>` → `ph backlog triage --issue <ID>`
  - Preconditions: `backlog/<type>/<ID>/` exists
  - Command: `ph --root <PH_ROOT> backlog triage --issue <ID>`
  - Outputs to verify: `backlog/index.json`, `backlog/<type>/<ID>/**` (triage metadata updated)
- [ ] `make backlog-assign issue=<ID> [sprint=current]` → `ph backlog assign --issue <ID> [--sprint current]`
  - Preconditions: `backlog/<type>/<ID>/` exists
  - Command: `ph --root <PH_ROOT> backlog assign --issue <ID> [--sprint current]`
  - Outputs to verify: `backlog/index.json`, `backlog/<type>/<ID>/**` (assignment metadata updated)
- [ ] `make backlog-rubric` → `ph backlog rubric`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> backlog rubric`
  - Outputs to verify: (none; stdout only)
- [ ] `make backlog-stats` → `ph backlog stats`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> backlog stats`
  - Outputs to verify: (none; stdout only)

### Parking (project)

- [ ] `make parking-add ...` → `ph parking add ...`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> parking add --type technical-debt --title \"...\"`
  - Outputs to verify: `parking-lot/index.json`, `parking-lot/<category>/<ID>/**`
- [ ] `make parking-list ...` → `ph parking list ...`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> parking list ...`
  - Outputs to verify: (none; stdout only)
- [ ] `make parking-review` → `ph parking review`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> parking review`
  - Outputs to verify: (none; stdout only)
- [ ] `make parking-promote item=<ID> [target=later]` → `ph parking promote --item <ID> [--target later]`
  - Preconditions: `parking-lot/<category>/<ID>/` exists
  - Command: `ph --root <PH_ROOT> parking promote --item <ID> [--target later]`
  - Outputs to verify: `parking-lot/index.json`, `parking-lot/<category>/<ID>/**` (promotion metadata updated)

### Validation + status

- [ ] `make validate` → `ph validate`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> validate`
  - Outputs to verify: `status/validation.json`
- [ ] `make validate-quick` → `ph validate --quick`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> validate --quick`
  - Outputs to verify: `status/validation.json`
- [ ] `make pre-exec-lint` → `ph pre-exec lint`
  - Preconditions: `sprints/current/tasks/` exists and contains tasks
  - Command: `ph --root <PH_ROOT> pre-exec lint`
  - Outputs to verify: (none; stdout only)
- [ ] `make pre-exec-audit [sprint=SPRINT-...] [date=YYYY-MM-DD] [evidence_dir=<path>]` → `ph pre-exec audit [...]`
  - Preconditions: `sprints/current/plan.md` exists (or `--sprint` is provided)
  - Command: `ph --root <PH_ROOT> pre-exec audit [--sprint SPRINT-...] [--date YYYY-MM-DD] [--evidence-dir <path>]`
  - Outputs to verify: `status/evidence/PRE-EXEC/<SPRINT-...>/<YYYY-MM-DD>/**` (when `--evidence-dir` is not provided)
- [ ] `make status` → `ph status`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> status`
  - Outputs to verify: `status/current.json`, `status/current_summary.md`

### Dashboards

- [ ] `make dashboard` → `ph dashboard`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> dashboard`
  - Outputs to verify: (none; stdout only)

### Roadmap (project only)

- [ ] `make roadmap` → `ph roadmap show`
  - Preconditions: `roadmap/now-next-later.md` exists (or create it first)
  - Command: `ph --root <PH_ROOT> roadmap show`
  - Outputs to verify: (none; stdout only)
- [ ] `make roadmap-show` → `ph roadmap show`
  - Preconditions: `roadmap/now-next-later.md` exists (or create it first)
  - Command: `ph --root <PH_ROOT> roadmap show`
  - Outputs to verify: (none; stdout only)
- [ ] `make roadmap-create` → `ph roadmap create`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> roadmap create`
  - Outputs to verify: `roadmap/now-next-later.md`
- [ ] `make roadmap-validate` → `ph roadmap validate`
  - Preconditions: `roadmap/now-next-later.md` exists
  - Command: `ph --root <PH_ROOT> roadmap validate`
  - Outputs to verify: (none; stdout only)

### Release (project only)

- [ ] `make release-plan ...` → `ph release plan ...`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> release plan [--version next] ...`
  - Outputs to verify: `releases/<version>/plan.md`, `releases/<version>/progress.md`, `releases/<version>/features.yaml`, `releases/current`
- [ ] `make release-activate release=<vX.Y.Z>` → `ph release activate --release <vX.Y.Z>`
  - Preconditions: `releases/<vX.Y.Z>/` exists
  - Command: `ph --root <PH_ROOT> release activate --release <vX.Y.Z>`
  - Outputs to verify: `releases/current`
- [ ] `make release-clear` → `ph release clear`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> release clear`
  - Outputs to verify: `releases/current` is absent
- [ ] `make release-status` → `ph release status`
  - Preconditions: `releases/current` exists and points at a valid `releases/<version>/`
  - Command: `ph --root <PH_ROOT> release status`
  - Outputs to verify: (none; stdout only)
- [ ] `make release-show` → `ph release show`
  - Preconditions: `releases/current` exists and points at a valid `releases/<version>/`
  - Command: `ph --root <PH_ROOT> release show`
  - Outputs to verify: (none; stdout only)
- [ ] `make release-progress` → `ph release progress`
  - Preconditions: `releases/current` exists and points at a valid `releases/<version>/`
  - Command: `ph --root <PH_ROOT> release progress`
  - Outputs to verify: `releases/<version>/progress.md`
- [ ] `make release-add-feature ...` → `ph release add-feature ...`
  - Preconditions: `releases/<version>/features.yaml` exists (created by `ph release plan`)
  - Command: `ph --root <PH_ROOT> release add-feature --release <vX.Y.Z> --feature <name> ...`
  - Outputs to verify: `releases/<version>/features.yaml`
- [ ] `make release-suggest version=<vX.Y.Z>` → `ph release suggest --version <vX.Y.Z>`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> release suggest --version <vX.Y.Z>`
  - Outputs to verify: (none; stdout only)
- [ ] `make release-list` → `ph release list`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> release list`
  - Outputs to verify: (none; stdout only)
- [ ] `make release-close version=<vX.Y.Z>` → `ph release close --version <vX.Y.Z>`
  - Preconditions: `releases/<version>/` exists
  - Command: `ph --root <PH_ROOT> release close --version <vX.Y.Z>`
  - Outputs to verify: `releases/<version>/plan.md`, `releases/<version>/changelog.md`

### Onboarding + sessions

- [ ] `make onboarding` → `ph onboarding`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> onboarding`
  - Outputs to verify: (none; stdout only)
- [ ] `make onboarding session list` → `ph onboarding session list`
  - Preconditions: `process/sessions/templates/*.md` exists
  - Command: `ph --root <PH_ROOT> onboarding session list`
  - Outputs to verify: (none; stdout only)
- [ ] `make onboarding session continue-session` → `ph onboarding session continue-session`
  - Preconditions: `process/sessions/logs/latest_summary.md` exists (or has been created by `ph end-session`)
  - Command: `ph --root <PH_ROOT> onboarding session continue-session`
  - Outputs to verify: (none; stdout only)
- [ ] `make onboarding session <template>` → `ph onboarding session <template>`
  - Preconditions: `process/sessions/templates/<template>.md` exists
  - Command: `ph --root <PH_ROOT> onboarding session <template>`
  - Outputs to verify: (none; stdout only)

### Session summarization

- [ ] `make end-session ...` → `ph end-session ...`
  - Preconditions: rollout log exists at `--log <path>`
  - Command: `ph --root <PH_ROOT> end-session --log <rollout.jsonl> [--skip-codex] ...`
  - Outputs to verify:
    - `process/sessions/logs/<YYYY-MM-DD_HHMM>_summary.md`
    - `process/sessions/logs/latest_summary.md`
    - `process/sessions/logs/manifest.json`
    - `process/sessions/session_end/session_end_index.json` (when `--session-end-mode` is not `none`)
    - `process/sessions/session_end/<workstream>/*` (when `--session-end-mode` is not `none`)

### Utilities

- [ ] `make clean` → `ph clean`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> clean`
  - Outputs to verify: (none; deletes `**/__pycache__/**` and `**/*.pyc` under PH_ROOT)
- [ ] `make install-hooks` → `ph hooks install`
  - Preconditions: `.git/` exists
  - Command: `ph --root <PH_ROOT> hooks install`
  - Outputs to verify: `.git/hooks/post-commit`, `.git/hooks/pre-push`
- [ ] `make check-all` → `ph check-all`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> check-all`
  - Outputs to verify: `status/validation.json`, `status/current.json`, `status/current_summary.md`
- [ ] `make test-system` → `ph test system`
  - Preconditions: none
  - Command: `ph --root <PH_ROOT> test system`
  - Outputs to verify: `status/validation.json`, `status/current.json`, `status/current_summary.md` (written by internal `ph validate` + `ph status`)

### CLI-only (not in reference Makefile)

- [ ] `ph reset` / `ph reset-smoke`
  - Note: the reference Make interface does not define `reset*` targets.
