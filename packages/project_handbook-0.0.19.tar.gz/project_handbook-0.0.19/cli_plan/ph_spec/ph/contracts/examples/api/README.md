---
title: API Contracts Registry
type: process
date: 2026-01-02
tags: [contracts, api]
links:
  - ./api-contracts.json
---

# API Contracts Registry

This directory contains **canonical API endpoint contracts** (one file per endpoint or logical pair) and a lightweight manifest (`api-contracts.json`) for discovery and auditing.

