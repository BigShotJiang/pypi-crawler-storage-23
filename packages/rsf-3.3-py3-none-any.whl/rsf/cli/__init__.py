"""RSF CLI package."""
