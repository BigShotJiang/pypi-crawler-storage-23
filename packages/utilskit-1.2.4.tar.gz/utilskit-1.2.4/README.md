# Install
```cmd
pip install utilskit
```

# 개요

이 패키지는 다양한 전처리 작업을 효율적으로 처리할 수 있도록 설계된 커스텀 유틸리티 모음입니다. 데이터 정제, 결측치 처리, 반복 패턴 탐지, 시계열 정렬 및 그룹화 이미지 생성 편의성 등 데이터 분석 전반에 걸친 반복 작업들을 간결하게 수행할 수 있도록 돕습니다. 분석가와 엔지니어 모두를 위한 실용적인 도구로, 빠르고 안정적인 데이터 분석 파이프라인 구축에 기여할 수 있습니다.

# Features

## - classificationutils

| 함수명                                        | 목적                  |
| --------------------------------------------- | --------------------- |
| [confucsion_matrix](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/confusion_matrix.md) | confusion matrix 생성 |

## - dataframeutils

| 함수명                                                       | 목적                  |
| ------------------------------------------------------------ | --------------------- |
| [read_df](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/read_df.md) | 데이터 불러오기       |
| [utc2kor](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/utc2kor.md) | 시간대 변경           |
| [adnormal2nan](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/adnormal2nan.md) | 이상치 --> 결측치     |
| [time_filling](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/time_filling.md) | 시간 확장             |
| [isdfvalid](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/isdfvalid.md) | dataframe 유효성 검증 |
| [fill_repeat_nan](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/fill_repeat_nan.md) | 반복성 결측치 보정    |
| [pin2nan](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/pin2nan.md) | 핀포인트 결측치 보정  |

## - dbutils

| 함수명                       | 목적                   |
| ---------------------------- | ---------------------- |
| [query2db](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/query2db.md) | Query 를 DB에 커밋     |
| [df2db](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/df2db.md)       | dataframe을 DB 에 삽입 |

## - hashutils

| 함수명                                                       | 목적                                                     |
| ------------------------------------------------------------ | -------------------------------------------------------- |
| [file2hash](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/file2hash.md) | 파일 해시값을 계산                                       |
| [dir2hash](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/dir2hash.md) | 폴더에 대한 해시값을 계산                                |
| [get_all_hash](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_all_hash.md) | 특정 디렉토리 내의 모든 파일 각각에 대한 해시를 계산     |
| [combined2hash](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/combined2hash.md) | 특정 디렉토리의 대상 파일 리스트 각각에 대한 해시를 계산 |
| [hashlist2hash](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/hashlist2hash.md) | 해시 리스트를 모아서 하나의 통합 해시를 계산             |

## - versionutils

| 함수명                                                       | 목적                                           |
| ------------------------------------------------------------ | ---------------------------------------------- |
| [version_up](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/version_up.md) | 대화형 인터페이스로 semantic versioning 수행   |
| [get_git_modified](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_git_modified.md) | Git 저장소의 수정된 파일 목록 추출             |
| [get_git_new](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_git_new.md) | Git 저장소의 추적되지 않는 새 파일 목록 추출   |
| [git_addcommit](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/git_addcommit.md) | Git 저장소의 모든 변경사항을 스테이징 및 커밋  |

## - plotutils

| 함수명                                                       | 목적                         |
| ------------------------------------------------------------ | ---------------------------- |
| [draw_plot](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/draw_plot.md) | 이미지 생성                  |
| [draw_subplot](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/draw_subplot.md) | 서브 플롯 형태의 이미지 생성 |

## - repeatutils

| 함수명                                 | 목적                      |
| -------------------------------------- | ------------------------- |
| [get_section](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_section.md)     | 반복 구간 산출            |
| [section_union](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/section_union.md) | 구간과 구간과의 겹침 연산 |

## - timeutils

| 함수명                                 | 목적                                       |
| -------------------------------------- | ------------------------------------------ |
| [get_now](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_now.md)             | 사용자 지정 방식의 현재 시간 추출          |
| [time_measure](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/time_measure.md)   | 정수 --> 시, 분, 초 변환                   |
| [get_date_list](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_date_list.md) | 입력한 기준값을 통해 전체 날짜 리스트 생성 |

## - utils

| 함수명                                                       | 목적                        |
| ------------------------------------------------------------ | --------------------------- |
| [envs_setting](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/envs_setting.md) | 각종 랜덤 시드 설정         |
| [get_error_info](https://github.com/Kim-YoonHyun/utilskit/blob/master/docs/get_error_info.md) | 에러 발생시의 메시지 객체화 |

# Version
## 2026-02-02 ver 1.1.0

- hashutils, versionutils 추가

## 2025-11-24 ver 0.2.18

에러수정

- repeatutils 의 section_union 함수에서 mode 에 -, +, & 외의 값 입력시 에러 도출하는 유효성 검증 부분 추가

최적화

- README, docs 구조 변경

### 1.2.4

- versionutils `get_git_new` 함수 사용시 첫 번째 경로 인자값을 Pathlib 변수로 넣지 않으면 에러가 나는 현상 수정

### 1.2.3

- 내부 오류 수정

### 1.2.2

- hashutils, versionutils 기능 추가

### 0.2.18.1

- README 의 하이퍼링크를 github 절대경로로 변경

### 0.2.18.2

- README 의 하이퍼링크를 github 절대경로로 변경(경로 수정)

## 0.2.17

- logutils 기능 완전 삭제 > logie 패키지로 분리
## 0.2.16
- repeatutils 의 section_union 에서 mode 를 & 으로 하고 sub 또는 main section 이 빈 리스트인 경우 빈리스트 [] 를 리턴 하도록 수정
### 0.2.16.1
- 조건문에서 & 앞에 띄어쓰기가 하나 포함되어있어 정상적 연산이 되지 않는 부분 수정
## 0.2.15
- repeatutils 의 section_union 에서 결과가 빈값일때 에러가 나는 현상 수정
## 0.2.14
- repeatutils 의 min_key 를 설정했을 때 min_equal=False 로 두는 경우 정상적인 구간 탐색을 못하는 현상 수정
## 0.2.13
- repeatutils 에 section_union 함수 추가
### 0.2.13.1
- rpu.get_section 을 써서 에러가 난 부분 수정
## 0.2.12
- dataframeutils 의 fill_repeat_nan 함수가 NaN 이 딱 하나만 있는 경우 보정하지 못하는 현상 수정
## 0.2.11
- dataframeutils 의 fill_repeat_nan 함수가 3 이하 반복되는 NaN 이 아닌 3 이상 반복되는 NaN 구간에 대해 보정하는 현상 수정
## 0.2.10
- repeatutils 에서 between 이 정상작동하지 않는 현상 수정
### 0.2.10.1
- 버전 업로드 에러 수정
### 0.2.10.2
- 함수 내부 print 제거
## 0.2.9
- repeatuils 에서 정수형 list 를 넣었을때 float 으로 변경되도록 수정
## 0.2.8
- dbutils 에서 db 의 컬럼명을 리스트로 추출하는 get_db_name 함수 추가
### 0.2.8.1
- __all__ 에 get_db_name 추가해서 사용가능하도록 설정
## 0.2.7
- repeatutils 에서 정수형 list 를 넣었을때 key 를 통한 구간 파악이 되지 않는 현상 수정
## 0.2.6
- dataframeutils 의 fill_repeat_nan 의 에러 수정
## 0.2.5
- xlsx 읽는 패키지 install 추가
## 0.2.4
- repeatutils 의 에러 제거
## 0.2.3
- dbutils 에 대한 업데이트 진행
## 0.2.2
- build 방식 변경
## 0.2.1
- repeatutila 에 get_section 함수 추가
## 0.2.0 
- 정식 최초 배포버전
- 각 함수의 사용성 강화 및 비활성 함수 지정
## 0.1.2
- repeatutils 의 get_repeat_section 에서 하나의 값이 여러 구간에서 반복될때 마지막 구간만 나오는 부분 수정
- repeatutils 의 get_repeat_section 및 get_stan_repeat_section 에서 추출되는 구간의 마지막 값이 +1 이 되는 부분 수정