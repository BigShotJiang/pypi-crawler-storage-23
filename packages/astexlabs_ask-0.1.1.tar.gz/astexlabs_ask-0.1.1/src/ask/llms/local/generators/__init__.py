"""Command generators for the local inference provider."""

from ask.llms.local.generators.base import CommandGenerator, CommandGeneratorRegistry

__all__ = ["CommandGenerator", "CommandGeneratorRegistry"]
