"""Local inference provider – offline command generation via string parsing."""
