import typer

from hyperchip import __version__

app = typer.Typer(no_args_is_help=True)


def version_callback(value: bool):
    if value:
        print(f"hyperchip {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True
    ),
):
    """Chip satellite imagery into ML-ready training data."""
