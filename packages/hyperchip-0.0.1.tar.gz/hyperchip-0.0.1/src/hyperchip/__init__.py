"""Chip satellite imagery into ML-ready training data."""

__version__ = "0.0.1"
