import time

from comms.client import JudgementClient

class Player:
    def __init__(self, host, port, server_ip, server_port):
        self.host = host
        self.port = port
        self.server_ip = server_ip
        self.server_port = server_port
        self.client = JudgementClient(host, port, server_ip, server_port)

    def start(self):
        # import pdb
        # pdb.set_trace()
        if self.client.start():
            # print("Connected to server!")
            pass
        init_scorecard = self.client.receive_message_from_server()
        print(init_scorecard)

        init_ready_msg = self.client.receive_message_from_server()
        print(init_ready_msg)
        
        # for i in range(5, 0, -1):
        #     print(f"\033[2K\rStarting game in {i}...", end="", flush=True)
        #     time.sleep(1)

        while True:
            msg = self.client.receive_message_from_server()
            if "action_mode" in msg:
                msg.replace("action_mode", "")
                msg = msg.strip()
                if not msg:
                    print(msg)
                action = self.client.receive_message_from_server()
                reply = input(action)
                self.client.send_message_to_server(reply)
            else:
                print(msg)

    def stop(self):
        self.client.close()

    def __del__(self):
        self.stop()
