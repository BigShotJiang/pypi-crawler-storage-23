from comms.server import JudgementServer
import copy
from display.cards import get_hand_str, get_hand_str_with_numbers, emoji_to_suite
from display.scorecard import get_scorecard_str
import random
import time

GAME_STATE = {
    "players": {},
    "player_seq": [],
    "rounds": [],
    "current_round": 0,
    "total_rounds": 0,
    "trump_seq": [],
    "current_player_start_idx": -1,
    "current_player_round_seq": [],
}

SUITE_MAP = {
    "h": "♥",
    "d": "♦",
    "c": "♣",
    "s": "♠",
}

suites = ["S", "H", "C", "D"]
ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
ALL_CARDS = [f"{rank}_{suite}" for rank in ranks for suite in suites]

class Game:
    def __init__(self, host, port, server_ip, server_port, players_count, rounds_num=3):
        self.host = host
        self.port = port
        self.server_ip = server_ip
        self.server_port = server_port
        self.server = JudgementServer(host, port)
        self.players_count = players_count

        self.trump_seq = ["S", "H", "C", "D"]
        self.rounds_num = rounds_num
        self.setup_comms()
        self.init_rounds()

    def setup_comms(self):
        for _ in range(self.players_count):
            player = self.server.get_player()
            GAME_STATE["players"][player] = {"scores": []}
            GAME_STATE["player_seq"].append(player)
            print(f"{player} joined the game")
        print("All players have joined the game")

    def get_cyclic_hand_seq(self, hand_won_player=None):
        current_player_seq = GAME_STATE["player_seq"]
        if hand_won_player is None:
            hand_won_player = current_player_seq[0]
        start_idx = current_player_seq.index(hand_won_player)
        pre_list = current_player_seq[:start_idx]
        post_list = current_player_seq[start_idx:]
        return post_list + pre_list

    def rotate_player_seq(self, round_num):
        idx = (round_num - 1) % self.players_count
        GAME_STATE["player_seq"] = GAME_STATE["player_seq"][idx:] + GAME_STATE["player_seq"][:idx]

    def init_rounds(self):
        if self.rounds_num == -1:
            self.rounds_num = 52 // self.players_count
        GAME_STATE["total_rounds"] = self.rounds_num
        GAME_STATE["trump_seq"] = self.trump_seq
        scorecard, trump_per_round = get_scorecard_str(GAME_STATE)
        GAME_STATE["trump_per_round"] = trump_per_round
        self.server.broadcast_message(scorecard)
        ready_msg = "\n\nAll players have joined the game.\n\n"
        self.server.broadcast_message(ready_msg)

    def distribute_cards(self):
        distribution = {}
        copy_cards = copy.deepcopy(ALL_CARDS)
        random.shuffle(copy_cards)
        for player in GAME_STATE["player_seq"]:
            cards = random.sample(copy_cards, GAME_STATE["total_rounds"] - GAME_STATE["current_round"] + 1)
            for card in cards:
                copy_cards.pop(copy_cards.index(card))
            distribution[player] = cards
            GAME_STATE[f"round_{GAME_STATE['current_round']}_map"][player]["cards"] = cards
            
        
        for player, cards in distribution.items():
            hand = [item.split("_") for item in cards]
            GAME_STATE["players"][player]["cards"] = hand
            hand_str = get_hand_str(hand)
            self.server.send_message(player, hand_str)
        
            
    def announce_player_seq(self):
        header_msg = "\n================================================\n"
        self.server.broadcast_message(header_msg)
        # import pdb; pdb.set_trace()
        
        trump_announce_msg = f"\nTrump card for this round => {GAME_STATE['trump_per_round'][GAME_STATE['current_round'] - 1][0]} ({GAME_STATE['trump_per_round'][GAME_STATE['current_round'] - 1][1]})\n"
        self.server.broadcast_message(trump_announce_msg)
        
        _current_round_idx = (GAME_STATE["current_round"] - 1) % self.players_count
        _current_round_seq = GAME_STATE["player_seq"]
        GAME_STATE["current_player_round_seq"] = _current_round_seq
        sequence_announce_msg = f"\nSequence: {' => '.join(_current_round_seq)}\n"
        self.server.broadcast_message(sequence_announce_msg)

        constraint_announce_msg = f"\nCONSTRAINT FOR THIS ROUND IS ON *{_current_round_seq[-1]}*\n"
        self.server.broadcast_message(constraint_announce_msg)

        footer_msg = "\n================================================\n"
        self.server.broadcast_message(footer_msg)

    def _get_player_judgement(self, player, constraint):
        audience_msg = f"\nWaiting for {player} to make a judgement...\n"
        self.server.broadcast_message_except_player(audience_msg, player)
        
        round_map = GAME_STATE[f"round_{GAME_STATE['current_round']}_map"]
        all_judgements = [item["judgement"] for item in round_map.values()]
        constraint_num = len(round_map[player]["cards"]) - sum(all_judgements) - 1

        if constraint:
            judgement_msg = f"\nYou cannot enter {constraint_num} as your judgement.\nEnter your judgement: "
        else:
            judgement_msg = f"\nEnter your judgement: "

        got_valid_judgement = False
        while not got_valid_judgement:
            judgement = self.server.get_reply_from_player(player, judgement_msg)
            try:
                judgement = int(judgement)
            except:
                judgement_msg = f"\n Invalid input. Please provide a number as your judgement.\n Enter your judgement: "
                continue
            if constraint and judgement == constraint_num:
                judgement_msg = f"\n You cannot enter {constraint_num} as your judgement.\nEnter your judgement: "
                continue
            got_valid_judgement = True
            GAME_STATE[f"round_{GAME_STATE['current_round']}_map"][player]["judgement"] = judgement

        self.server.broadcast_message_except_player(f"\n{player} has made a judgement: {judgement}\n", player)

    def _get_player_hand(self, player):
        # import pdb; pdb.set_trace()
        audience_msg = f"\nWaiting for {player} to play their card...\n"
        self.server.broadcast_message_except_player(audience_msg, player)
        time.sleep(0.5)

        if "current_suite" in GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]:
            current_pile = GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["cards_played"].values()
            current_pile_split = [item.split("_") for item in current_pile if item]
            # import pdb; pdb.set_trace()
            current_pile_str = get_hand_str(current_pile_split)
            current_pile_msg = f"\nCURRENT PILE:\n{current_pile_str}\n"
            self.server.send_message(player, current_pile_msg)
            time.sleep(0.5)

        current_cards = GAME_STATE[f"round_{GAME_STATE['current_round']}_map"][player]["cards"]
        round_num = GAME_STATE["current_round"]
        round_map = GAME_STATE[f"round_{round_num}_map"]
        hand = [item.split("_") for item in current_cards]
        hand_str = get_hand_str_with_numbers(hand)
        _msg = f"\nSelect a card to play, by typing its number: "
        
        self.server.send_message(player, "YOUR CARDS:\n" + hand_str)
        got_valid_hand = False
        while not got_valid_hand:
            hand_choice = self.server.get_reply_from_player(player, _msg)
            try:
                hand_choice = int(hand_choice)
            except:
                err_msg = "Invalid input. Please provide a number for your choice."
                self.server.send_message(player, err_msg)
                continue
            if hand_choice < 1 or hand_choice > len(current_cards):
                err_msg = "Invalid input. Please select the number from choices only."
                self.server.send_message(player, err_msg)
                continue
            _card_attempted, _card_suite_attempted = current_cards[hand_choice - 1].split("_")
            if "current_suite" not in GAME_STATE[f"round_{round_num}_judge"]:
                GAME_STATE[f"round_{round_num}_judge"]["current_suite"] = _card_suite_attempted
            else:
                if GAME_STATE[f"round_{round_num}_judge"]["current_suite"] != _card_suite_attempted:
                    # Did player had the current_suite card?
                    # import pdb; pdb.set_trace()
                    suites_in_hand = [item[1] for item in hand]
                    if GAME_STATE[f"round_{round_num}_judge"]["current_suite"] in suites_in_hand:
                        suite_emoji = SUITE_MAP[GAME_STATE[f"round_{round_num}_judge"]["current_suite"].lower()]
                        err_msg = "You do have running suite card in your hand => {}\n You must play a card of {} suite to continue.".format(GAME_STATE[f"round_{round_num}_judge"]["current_suite"], suite_emoji)
                        self.server.send_message(player, err_msg)

                        warning_msg = f"{player} has been warned for playing a card of a different suite."
                        self.server.broadcast_message_except_player(warning_msg, player)
                        continue

            # Card is now selected
            got_valid_hand = True
            # Clear the card from the player's hand
            GAME_STATE[f"round_{round_num}_judge"]["cards_played"][player] = GAME_STATE[f"round_{round_num}_map"][player]["cards"].pop(hand_choice - 1)
    
    def get_round_judgements(self):
        for player_idx in range(len(GAME_STATE["current_player_round_seq"])):
            player = GAME_STATE["current_player_round_seq"][player_idx]
            constraint = True if player_idx == len(GAME_STATE["current_player_round_seq"]) - 1 else False
            self._get_player_judgement(player, constraint)
    
    def judge_cards_played(self):
        face_card_values = {
            "J": 11,
            "Q": 12,
            "K": 13,
            "A": 14
        }
        current_suite = GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["current_suite"]
        current_trump = GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["current_trump"].upper()
        max_rank = None
        winner = None
        for player, card in GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["cards_played"].items():
            _card_rank, _card_suite = card.split("_")
            if _card_suite != current_suite:
                if _card_suite != current_trump:
                    continue
                current_suite = current_trump
                max_rank = None
            if _card_rank in face_card_values:
                _card_rank = face_card_values[_card_rank]
            else:
                _card_rank = int(_card_rank)
            if max_rank is None or _card_rank > max_rank:
                max_rank = _card_rank
                winner = player
        
        GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["hands_won"][winner] += 1
        del(GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["current_suite"])
        GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["cards_played"] = {_player: "" for _player in GAME_STATE["player_seq"]}
        hand_winner_msg = f"\n****** {winner} has won this hand. ****** \n"
        self.server.broadcast_message(hand_winner_msg)
        return winner
        
    
    def play_cards(self, round_num):
        round_map = GAME_STATE[f"round_{round_num}_map"]
        GAME_STATE[f"round_{round_num}_judge"] = {
            "current_trump": emoji_to_suite[GAME_STATE["trump_per_round"][round_num - 1][0]],
            "cards_played": {_player: "" for _player in GAME_STATE["player_seq"]},
            "hands_won": {_player: 0 for _player in GAME_STATE["player_seq"]}}
        hand_won_player = None
        hands_to_play = GAME_STATE["total_rounds"] - GAME_STATE["current_round"] + 1
        for hand_num in range(hands_to_play):
            cyclic_hand_seq = self.get_cyclic_hand_seq(hand_won_player)
            for player in cyclic_hand_seq:
                self._get_player_hand(player)
            hand_won_player = self.judge_cards_played()
        
    def update_scorecard(self):
        for player in GAME_STATE["player_seq"]:
            score = 0
            initial_judgement = GAME_STATE[f"round_{GAME_STATE['current_round']}_map"][player]["judgement"]
            hands_won = GAME_STATE[f"round_{GAME_STATE['current_round']}_judge"]["hands_won"][player]
            if hands_won == initial_judgement:
                score = initial_judgement + 10
            GAME_STATE["players"][player]["scores"].append(score)
        scorecard, _ = get_scorecard_str(GAME_STATE)
        self.server.broadcast_message(scorecard)

    def get_winner(self):
        max_score = 0
        winner = None
        for player in GAME_STATE["player_seq"]:
            score = sum(GAME_STATE["players"][player]["scores"])
            if score > max_score:
                max_score = score
                winner = player
        return winner

    def start_game(self):
        for round_num in range(self.rounds_num):
            msg = "\n\n****** ROUND: {} ******".format(round_num + 1)
            self.server.broadcast_message(msg)

            GAME_STATE["current_round"] += 1
            GAME_STATE[f"round_{GAME_STATE['current_round']}_map"] = {player: {"cards":[], "judgement": -1} for player in GAME_STATE["player_seq"]}
            
            msg = "\n Distributing cards..."
            self.server.broadcast_message(msg)
            time.sleep(3)

            self.distribute_cards()

            self.announce_player_seq()
            
            self.get_round_judgements()

            self.play_cards(GAME_STATE["current_round"])

            self.update_scorecard()

            self.rotate_player_seq(GAME_STATE["current_round"]+1)
        
        winner = self.get_winner()
        winner_msg = f"\n****** {winner} has won the game. ****** \n"
        self.server.broadcast_message(winner_msg)
        import pdb; pdb.set_trace()
        x = 1

    def stop(self):
        self.server.stop()

    def __del__(self):
        self.stop()



