suites = {
    "h": "♥",
    "d": "♦",
    "c": "♣",
    "s": "♠"
}
emoji_to_suite = {
    "♥": "h",
    "♦": "d",
    "♣": "c",
    "♠": "s"
}

ranks = {
    "2": "2",
    "3": "3",
    "4": "4",
    "5": "5",
    "6": "6",
    "7": "7",
    "8": "8",
    "9": "9",
    "10": "10",
    "j": "J",
    "q": "Q",
    "k": "K",
    "a": "A"
}



def get_card_lines(rank, suite):
    rank = rank.lower()
    suite = suite.lower()
    line2 = f"│{rank.upper():<10}│"
    line_2 = f"│{rank.upper():>10}│"
    blank = "│          │"
    center = f"│{suites[suite]:^10}│"
    bottom = "└──────────┘"
    top = "┌──────────┐"
    seq = [top, line2, blank, blank, center, blank, blank, line_2, bottom]
    return top, line2, blank, center, line_2, bottom

def get_hand_str(hand=[]):
    topLine = []
    bottomLine = []
    blankLine = []
    centerLine = []
    line2Line = []
    line_2Line = []
    for rank, suite in hand:
        top, line2, blank, center, line_2, bottom = get_card_lines(rank, suite)
        topLine.append(top)
        bottomLine.append(bottom)
        blankLine.append(blank)
        centerLine.append(center)
        line2Line.append(line2)
        line_2Line.append(line_2)
    
    final_top = " ".join(topLine)
    final_bottom = " ".join(bottomLine)
    final_blank = " ".join(blankLine)
    final_center = " ".join(centerLine)
    final_line2 = " ".join(line2Line)
    final_line_2 = " ".join(line_2Line)
    
    seq = [final_top, final_line2, final_blank, final_blank, final_center, final_blank, final_blank, final_line_2, final_bottom]
    return "\n".join(seq)

def get_hand_str_with_numbers(hand=[]):
    topLine = []
    bottomLine = []
    blankLine = []
    centerLine = []
    line2Line = []
    line_2Line = []
    numberLine = []
    
    for i, (rank, suite) in enumerate(hand):
        top, line2, blank, center, line_2, bottom = get_card_lines(rank, suite)
        topLine.append(top)
        bottomLine.append(bottom)
        blankLine.append(blank)
        centerLine.append(center)
        line2Line.append(line2)
        line_2Line.append(line_2)
        numberLine.append(f"    [{i+1}]     ")
    
    final_top = " ".join(topLine)
    final_bottom = " ".join(bottomLine)
    final_blank = " ".join(blankLine)
    final_center = " ".join(centerLine)
    final_line2 = " ".join(line2Line)
    final_line_2 = " ".join(line_2Line)
    final_numbers = " ".join(numberLine)
    final_numbers_with_offset = f" {final_numbers}"
    
    seq = [final_top, final_line2, final_blank, final_center, final_blank, final_line_2, final_bottom, final_numbers_with_offset]
    return "\n".join(seq)

def print_hand_with_numbers(hand=[]):
    topLine = []
    bottomLine = []
    blankLine = []
    centerLine = []
    line2Line = []
    line_2Line = []
    numberLine = []
    
    for i, (rank, suite) in enumerate(hand):
        top, line2, blank, center, line_2, bottom = get_card_lines(rank, suite)
        topLine.append(top)
        bottomLine.append(bottom)
        blankLine.append(blank)
        centerLine.append(center)
        line2Line.append(line2)
        line_2Line.append(line_2)
        numberLine.append(f"    [{i+1}]     ")
    
    final_top = " ".join(topLine)
    final_bottom = " ".join(bottomLine)
    final_blank = " ".join(blankLine)
    final_center = " ".join(centerLine)
    final_line2 = " ".join(line2Line)
    final_line_2 = " ".join(line_2Line)
    final_numbers = " ".join(numberLine)
    final_numbers_with_offset = f" {final_numbers}"
    
    seq = [final_top, final_line2, final_blank, final_center, final_blank, final_line_2, final_bottom, final_numbers_with_offset]
    for item in seq: 
        print(item)

def interactive_card_selection(hand):
    """Allow user to select cards by typing numbers"""
    print_hand_with_numbers(hand)
    print("\nSelect a card by typing its number (or 'q' to quit):")
    
    while True:
        try:
            choice = input("> ").strip().lower()
            if choice == 'q':
                break
            
            card_num = int(choice)
            if 1 <= card_num <= len(hand):
                rank, suite = hand[card_num - 1]
                print(f"You selected: {rank} of {suites[suite]}")
                # Add your card logic here
            else:
                print(f"Invalid choice. Please enter 1-{len(hand)} or 'q'")
                
        except ValueError:
            print("Invalid input. Please enter a number or 'q'")

# Test the interactive version
if __name__ == "__main__":
    # test_hand = [("10", "h"), ("10", "c"), ("A", "s"), ("4", "d"), ("10", "h"), ("10", "c"), ("A", "s"), ("4", "d"), ("10", "h"), ("10", "c"), ("A", "s"), ("4", "d")]
    test_hand = [("A", "h"), ("A", "c"), ("A", "s"), ("10", "d")]
    interactive_card_selection(test_hand)




