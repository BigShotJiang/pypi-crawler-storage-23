import socket
import time
import urllib.request
import json

class JudgementServer:
    def __init__(self, host="0.0.0.0", port=12345):
        """
        Initialize the server.
        
        Args:
            host: IP address to bind to. Use "0.0.0.0" to accept connections from any interface,
                  or a specific IP to bind to a particular network interface.
            port: Port number to listen on.
        """
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(7)
        self.player_map = {}
        
        self._accept_connections = True
        
        # Print server info
        if host == "0.0.0.0":
            local_ip = self.get_local_ip()
            public_ip = self.get_public_ip()
            print(f"Server listening on all interfaces (0.0.0.0:{port})")
            print(f"\n=== Connection Information ===")
            print(f"Local network:  {local_ip}:{port}")
            if public_ip:
                print(f"Internet (requires port forwarding): {public_ip}:{port}")
                print(f"\n⚠️  To allow internet connections:")
                print(f"   1. Forward port {port} on your router to {local_ip}:{port}")
                print(f"   2. Ensure Windows Firewall allows port {port}")
                print(f"   3. Players connect to: {public_ip}:{port}")
            else:
                print(f"Public IP: Could not determine")
            print(f"==============================\n")
        else:
            print(f"Server listening on {host}:{port}")
    
    @staticmethod
    def get_local_ip():
        """
        Get the local IP address of this machine.
        Useful for telling players which IP to connect to.
        """
        try:
            # Connect to a remote address to determine local IP
            # (doesn't actually send data)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))  # Google DNS
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except Exception:
            return "localhost"
    
    @staticmethod
    def get_public_ip():
        """
        Get the public IP address of this machine.
        Useful for internet connections (requires port forwarding).
        """
        try:
            # Try multiple services in case one is down
            services = [
                "https://api.ipify.org?format=json",
                "https://ifconfig.me/ip",
                "https://icanhazip.com",
            ]
            
            for service in services:
                try:
                    if "ipify" in service:
                        response = urllib.request.urlopen(service, timeout=3)
                        data = json.loads(response.read().decode())
                        return data.get("ip")
                    else:
                        response = urllib.request.urlopen(service, timeout=3)
                        return response.read().decode().strip()
                except Exception:
                    continue
            return None
        except Exception:
            return None

    @property
    def is_accepting_connections(self):
        return self._accept_connections
    
    def stop_accepting_connections(self):
        self._accept_connections = False
    
    def get_player(self):
        print("Waiting for player to join...")
        self.server_socket.settimeout(1)
        # import pdb
        # pdb.set_trace()
        while self.is_accepting_connections:
            try:
                client_socket, client_address = self.server_socket.accept()

                while True:
                    greet_msg = "Welcome to the game.\n What is your name?: "
                    client_socket.sendall(greet_msg.encode("utf-8"))

                    name = client_socket.recv(4096).decode("utf-8")
                    if name in self.player_map:
                        client_socket.sendall("Name already taken. Try with other name".encode("utf-8"))
                        continue
                    self.player_map[name] = {
                        "socket": client_socket,
                        "address": client_address
                    }
                    client_socket.sendall(f"Welcome {name}! Waiting for other players to join...\n".encode("utf-8"))
                    break

                return name 
            except socket.timeout:
                continue

    def send_message(self, player_name, message):
        if player_name in self.player_map:
            self.player_map[player_name]["socket"].sendall(message.encode("utf-8"))
        else:
            print(f"Player {player_name} not found")

    def receive_message(self, player_name):
        if player_name in self.player_map:
            return self.player_map[player_name]["socket"].recv(4096).decode("utf-8")
        else:
            print(f"Player {player_name} not found")
            return None
        
    def broadcast_message(self, message):
        for player in self.player_map.values():
            player["socket"].sendall(message.encode("utf-8"))

    def broadcast_message_except_player(self, message, player_except_name):
        for player, player_data in self.player_map.items():
            if player == player_except_name:
                continue
            player_data["socket"].sendall(message.encode("utf-8"))

    def get_reply_from_player(self, player_name, message):
        action_msg = "action_mode"
        self.send_message(player_name, action_msg)
        time.sleep(0.5)

        self.send_message(player_name, message)
        reply = self.receive_message(player_name)
        return reply
    
    def close_all_connections(self, close_server_socket=True):
        """
        Close all player connections and optionally the server socket.
        
        Args:
            close_server_socket (bool): If True, also closes the server socket.
        """
        # Stop accepting new connections
        self.stop_accepting_connections()
        
        # Close all player sockets
        for player_name, player_data in self.player_map.items():
            try:
                player_data["socket"].close()
                print(f"Closed connection for player: {player_name}")
            except Exception as e:
                print(f"Error closing connection for {player_name}: {e}")
        
        # Clear the player map
        self.player_map.clear()
        
        # Close server socket if requested
        if close_server_socket:
            try:
                self.server_socket.close()
                print("Server socket closed")
            except Exception as e:
                print(f"Error closing server socket: {e}")
    
    def stop(self):
        """Alias for close_all_connections for consistency."""
        self.close_all_connections()
            