"""
:mod:`tests.unit.test_u_ops_enums` module.

Unit tests for :mod:`etlplus.ops.enums` coercion helpers and behaviors.
"""

from __future__ import annotations

from typing import Any
from typing import cast

import pytest

from etlplus.ops.enums import AggregateName
from etlplus.ops.enums import OperatorName
from etlplus.ops.enums import PipelineStep

# SECTION: TESTS ============================================================ #


class TestAggregateName:
    """Unit tests for :class:`etlplus.ops.enums.AggregateName`."""

    @pytest.mark.parametrize(
        'nums',
        [
            pytest.param([1, 2, 3], id='ints'),
            pytest.param([1.0, 2.0, 3.0], id='floats'),
        ],
    )
    def test_funcs(self, nums: list[int | float]) -> None:
        """Test the aggregate functions across numeric inputs."""
        assert AggregateName.SUM.func(nums, len(nums)) == 6
        assert AggregateName.MAX.func(nums, len(nums)) == 3
        assert AggregateName.MIN.func(nums, len(nums)) == 1
        assert AggregateName.COUNT.func(nums, len(nums)) == 3
        assert AggregateName.AVG.func(nums, len(nums)) == pytest.approx(2.0)


class TestOperatorName:
    """Unit tests for :class:`etlplus.ops.enums.OperatorName`."""

    def test_func_property_defensive_fallthrough(self) -> None:
        """Test descriptor fallback when called with a non-enum self."""
        descriptor = cast(property, OperatorName.__dict__['func'])
        raw_func = descriptor.fget
        assert raw_func is not None
        assert raw_func(cast(Any, object())) is None

    def test_funcs(self) -> None:
        """Test the operator functions."""
        assert OperatorName.EQ.func(5, 5) is True
        assert OperatorName.NE.func(5, 6) is True
        assert OperatorName.GT.func(5, 2) is True
        assert OperatorName.LT.func(2, 5) is True
        assert OperatorName.LTE.func(5, 5) is True
        assert OperatorName.IN.func('a', 'abc') is True
        assert OperatorName.CONTAINS.func('alphabet', 'bet') is True


class TestPipelineStep:
    """Unit tests for :class:`etlplus.ops.enums.PipelineStep`."""

    def test_order(self) -> None:
        """Test the order values."""
        assert PipelineStep.FILTER.order == 0
        assert PipelineStep.AGGREGATE.order == 4
