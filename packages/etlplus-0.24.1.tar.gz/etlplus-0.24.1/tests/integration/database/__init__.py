"""
:mod:`tests.integration.database` subpackage.

Integration tests for the :mod:`etlplus.database` subpackage.
"""

from __future__ import annotations
