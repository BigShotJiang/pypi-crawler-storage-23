import urllib.request
import json
from ._version import __version__


def check_latest_version(current_version: str):
    try:
        url = "https://pypi.org/pypi/dracula-ai/json"
        with urllib.request.urlopen(url, timeout=3) as response:
            data = json.loads(response.read().decode())
            latest_version = data["info"]["version"]

        # Split version into parts and compare numerically
        current_parts = [int(x) for x in current_version.split(".")]
        latest_parts = [int(x) for x in latest_version.split(".")]

        if latest_parts > current_parts:
            print(
                f"\n⚠️  A new version of Dracula is available: "
                f"v{latest_version} (you have v{current_version})\n"
                f"   Upgrade with: pip install --upgrade dracula-ai\n"
            )

    except Exception:
        pass
