import json
import os
from .exceptions import ChatException


class Memory:
    """
    Manages conversation history for Dracula.

    Stores messages in a list and automatically removes the oldest
    messages when the history exceeds the maximum size.

    Args:
        max_messages (int): Maximum number of messages to keep. Defaults to 10.
    """

    def __init__(self, max_messages: int = 10):
        self.history = []
        self.max_messages = max_messages

    def add_message(self, role: str, content: str):
        """
        Add a new message to the history.

        Args:
            role (str): Either 'user' or 'model'.
            content (str): The message content.
        """

        self.history.append({"role": role, "content": content})

        if len(self.history) > self.max_messages:
            self.history.pop(0)

    def get_history(self):
        """
        Return the full conversation history.

        Returns:
            list: List of message dictionaries.
        """

        return self.history

    def clear(self):
        """Clear all messages from history."""

        self.history = []

    def save(self, filepath: str):
        """
        Save conversation history to a JSON file.

        Args:
            filepath (str): Path to save the file.

        Raises:
            ChatException: If the file cannot be saved.
        """

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(self.history, f, indent=4, ensure_ascii=False)

        except Exception as e:
            raise ChatException(f"Failed to save conversation: {str(e)}")

    def load(self, filepath: str):
        """
        Load conversation history from a JSON file.

        Args:
            filepath (str): Path to the file to load.

        Raises:
            ChatException: If the file does not exist or cannot be loaded.
        """

        try:
            if not os.path.exists(filepath):
                raise ChatException(f"File not found: {filepath}")

            with open(filepath, "r", encoding="utf-8") as f:
                self.history = json.load(f)

        except ChatException:
            raise
        except Exception as e:
            raise ChatException(f"Failed to load conversation: {str(e)}")
