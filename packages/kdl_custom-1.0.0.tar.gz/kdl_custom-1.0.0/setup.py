from setuptools import setup, find_packages

setup(
    name="kdl-custom",
    version="1.0.0",
    packages=["kdl"],
    package_dir={"kdl": "."},
    install_requires=["requests"],
)
