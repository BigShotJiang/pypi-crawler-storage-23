#!/usr/bin/env python3
"""
Example: Using multiple output adapters simultaneously.
"""
import logging
import threading
import time
from pathlib import Path
from typing import Callable, Dict

import dronecan
import numpy as np
import pymap3d as pm
from dronecan import uavcan

from multilat_solver import ConfigBuilder, MessageType, MultiLatLocalizerApp
from multilat_solver.input_adapters import InputAdapter
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter,
    FileOutputAdapter,
    MavlinkOutputAdapter,
)

# Optional: only treat heartbeats from the autopilot (PX4/ArduPilot), not from GCS (type 6)
MAV_AUTOPILOT_PX4 = 12
MAV_TYPE_GCS = 6
SYSTEM_ID = 1
COMPONENT_ID = 200
CONNECTION_STRING = "udp:127.0.0.1:14551"

ANCHOR_COORDINATES = [
    {"id": 0, "gps": {"lon": 48.741957, "lat": 55.748718, "alt": 214.956}},
    {"id": 1, "gps": {"lon": 48.742733, "lat": 55.749016, "alt": 214.956}},
    {"id": 2, "gps": {"lon": 48.742733, "lat": 55.749417, "alt": 214.956}},
    {"id": 3, "gps": {"lon": 48.743234, "lat": 55.749045, "alt": 214.956}},
    {"id": 4, "gps": {"lon": 48.743194, "lat": 55.748616, "alt": 214.956}},
    {"id": 5, "gps": {"lon": 48.743733, "lat": 55.749208, "alt": 214.956}},
    {"id": 6, "gps": {"lon": 48.743562, "lat": 55.749562, "alt": 214.956}},
    {"id": 7, "gps": {"lon": 48.743200, "lat": 55.749869, "alt": 214.956}},
    {"id": 8, "gps": {"lon": 48.744116, "lat": 55.749931, "alt": 214.956}},
    {"id": 9, "gps": {"lon": 48.744116, "lat": 55.750396, "alt": 214.956}},
    {"id": 10, "gps": {"lon": 48.746002, "lat": 55.749614, "alt": 214.956}},
    {"id": 11, "gps": {"lon": 48.745548, "lat": 55.750417, "alt": 214.956}},
    {"id": 12, "gps": {"lon": 48.743082, "lat": 55.751112, "alt": 214.956}},
    {"id": 13, "gps": {"lat": 55.749583, "lon": 48.741858, "alt": 214.956}},
    {"id": 14, "gps": {"lat": 55.750268, "lon": 48.742620, "alt": 214.956}},
    {"id": 15, "gps": {"lat": 55.749583, "lon": 48.741858, "alt": 214.956}},
    {"id": 16, "gps": {"lat": 55.748003, "lon": 48.739555, "alt": 214.956}},
    {"id": 17, "gps": {"lat": 55.746103, "lon": 48.744447, "alt": 214.956}},
    {"id": 18, "gps": {"lat": 55.747295, "lon": 48.746468, "alt": 214.956}},
    {"id": 19, "gps": {"lat": 55.747059, "lon": 48.744592, "alt": 214.956}},
    {"id": 20, "gps": {"lat": 55.747499, "lon": 48.743885, "alt": 214.956}},
    {"id": 21, "gps": {"lat": 55.747821, "lon": 48.742026, "alt": 214.956}},
    {"id": 22, "gps": {"lat": 55.747965, "lon": 48.744501, "alt": 214.956}},
    {"id": 23, "gps": {"lat": 55.749547, "lon": 48.745822, "alt": 214.956}},
    {"id": 24, "gps": {"lat": 55.749173, "lon": 48.748143, "alt": 214.956}},
    {"id": 25, "gps": {"lat": 55.748912, "lon": 48.747173, "alt": 214.956}},
    {"id": 26, "gps": {"lat": 55.748381, "lon": 48.746429, "alt": 214.956}},
    {"id": 27, "gps": {"lat": 55.750758, "lon": 48.746719, "alt": 214.956}},
    {"id": 28, "gps": {"lat": 55.751367, "lon": 48.744743, "alt": 214.956}},
    {"id": 29, "gps": {"lat": 55.752651, "lon": 48.744176, "alt": 214.956}},
    {"id": 30, "gps": {"lat": 55.752048, "lon": 48.742888, "alt": 214.956}},
    {"id": 31, "gps": {"lat": 55.752344, "lon": 48.746479, "alt": 214.956}},
    {"id": 32, "gps": {"lat": 55.751838, "lon": 48.747340, "alt": 214.956}},
    {"id": 33, "gps": {"lat": 55.752186, "lon": 48.744547, "alt": 214.956}},
]

INITIAL_POSITION = {"lat": 55.7487863, "lon": 48.7430517, "alt": 214.956}


timestamp = time.strftime("%Y%m%d_%H%M%S")
filename = timestamp + "_" + __file__.split("/")[-1].replace(".py", ".log")
path = Path(__file__).parent.parent.absolute() / "logs"

debug_log_name = "debug_" + filename.replace(".py", ".log")
log_name = filename

logging.basicConfig(filename=path / debug_log_name, encoding="utf-8", level=logging.DEBUG)
logging.basicConfig(filename=path / log_name, encoding="utf-8", level=logging.INFO)

logger = logging.getLogger(__name__)
logger.propagate = True


def get_distance(lat, lon, alt, lat1, lon1, alt1):
    """
    Get distance between two points in meters.
    """
    x, y, z = pm.geodetic2enu(
        lat=lat,
        lon=lon,
        h=alt,
        lat0=INITIAL_POSITION["lat"],
        lon0=INITIAL_POSITION["lon"],
        h0=INITIAL_POSITION["alt"],
    )
    x1, y1, z1 = pm.geodetic2enu(
        lat=lat1,
        lon=lon1,
        h=alt1,
        lat0=INITIAL_POSITION["lat"],
        lon0=INITIAL_POSITION["lon"],
        h0=INITIAL_POSITION["alt"],
    )
    return np.sqrt((x - x1) ** 2 + (y - y1) ** 2 + (z - z1) ** 2)


class UavcanInputAdapter(InputAdapter):
    """UAVCAN input adapter."""

    def __init__(self, node: dronecan.node.Node):
        """
        Initialize UAVCAN input adapter.
        """
        self.node: dronecan.node.Node = node
        self.running: bool = False

    def start(self, callback: Callable[[Dict[int, Dict[str, float]]], None]):
        """Start UAVCAN input adapter"""
        self.running = True
        self.callback = callback
        print("Start")

        self.node.add_handler(dronecan.uavcan.equipment.gnss.Fix2, self._handle_gnss_fix2)
        self.thread = threading.Thread(target=self._read_loop, daemon=True)

        self.node.mode = dronecan.uavcan.protocol.NodeStatus().MODE_OPERATIONAL
        self.thread.start()

    def stop(self):
        """Stop UAVCAN input adapter."""
        self.node.remove_handlers(uavcan.equipment.gnss.Fix2)
        self.node.close()

    def is_running(self) -> bool:
        """Check if UAVCAN input adapter is running."""
        return self.node.is_running()

    def _read_loop(self):
        """Read from UAVCAN."""
        while self.running:
            try:
                self.node.spin(timeout=0)
                time.sleep(0.01)
            except dronecan.transport.TransferError as e:
                logger.error(f"Transfer error: {e}")

    def _handle_gnss_fix2(self, msg: dronecan.node.TransferEvent):
        """Handle uavcan.equipment.gnss.Fix2 message."""
        payload = msg.message
        timestamp = payload.gnss_timestamp.usec
        # longitude_deg_1e8=854604409, latitude_deg_1e8=4739859546, height_ellipsoid_mm=10000,
        longitude = payload.longitude_deg_1e8 / 1e8
        latitude = payload.latitude_deg_1e8 / 1e8
        height = payload.height_ellipsoid_mm / 1000
        distances = {}
        for entry in ANCHOR_COORDINATES:
            # LOCAL_POSITION_NED: x, y, z in mm (NED)
            anchor_distance = get_distance(
                latitude,
                longitude,
                height,
                entry["gps"]["lat"],
                entry["gps"]["lon"],
                entry["gps"]["alt"],
            )
            distances[entry["id"]] = {"m": anchor_distance, "t": timestamp}
        self.callback(distances)


def main():
    """Run MultiLat Localizer with multiple outputs."""
    node = dronecan.node.make_node(can_device_name="slcan0", node_id=100, bitrate=1000000, baudrate=1000000)
    print(f"Node: {node}")
    config = (
        ConfigBuilder()
        .with_localization(
            anchor_positions=ANCHOR_COORDINATES,
            origin_coordinates=(INITIAL_POSITION["lat"], INITIAL_POSITION["lon"], INITIAL_POSITION["alt"]),
            z_sign=1,
            max_range=200.0,
        )
        .with_input("uavcan", UavcanInputAdapter(node=node))
        # Multiple outputs: console for debugging, MAVLink for flight controller
        .with_output(
            "console",
            ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10),
        )
        .with_output(
            "file",
            FileOutputAdapter(
                filepath=f"{path}/{filename}.csv",
                mode="a",
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .with_output(
            "mavlink",
            MavlinkOutputAdapter(
                connection_string=CONNECTION_STRING,  # must match mavlink-routerd -e port
                system_id=SYSTEM_ID,  # PX4 only accepts HIL_GPS when msg.sysid == MAV_SYS_ID (typically 1)
                component_id=COMPONENT_ID,  # MAV_COMP_ID_ONBOARD_COMPUTER - distinct from PX4's 1
                message_type=MessageType.GPS,
                frequency=10,
            ),
        )
        .build()
    )

    print(f"Config: {config}")
    logger.debug("Config: %s", config)
    app = MultiLatLocalizerApp(config)
    app.run()


if __name__ == "__main__":
    logger.info("Starting main")
    main()
