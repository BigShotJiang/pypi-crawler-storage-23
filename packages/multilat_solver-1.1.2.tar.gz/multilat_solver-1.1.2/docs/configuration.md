# Configuration API

The MultilocalizerApp is confusingly configured with a `MultiLatLocalizerConfig` object, which is composed of 3 config parts: localization, input, and output. To configure the app one must create `MultiLatLocalizerConfig` and pass it to the `MultiLatLocalizerApp` constructor.
The `MultiLatLocalizerConfig` can be created using a `ConfigBuilder` instance.


## Builder Pattern

The `ConfigBuilder` provides a fluent API to configure InputAdapters, OutputAdapters and LocalizationEngine separately.
Output adapters are configured by passing an **adapter instance** (constructor kwargs):

```python
from multilat_solver import ConfigBuilder, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter, FileOutputAdapter, MavlinkOutputAdapter,
)

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0), 4: (3, 3, 0)},
        origin_coordinates=(37.7749, -122.4194, 0.0),  # Optional: for GPS
        ellipsoid="wgs84",
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
        z_sign=0,
        min_range=0.0,
        max_range=100.0,
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800, timeout=1.0)
    # OR .with_udp_input(host="0.0.0.0", port=5005)
    # OR .with_file_input(filepath="distances.json", poll_interval=1.0)
    # OR .with_input("custom", MyInputAdapter(...))  # custom InputAdapter child class instance

    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .with_output("file", FileOutputAdapter(filepath="positions.jsonl", mode="a", message_type=MessageType.BOTH, frequency=10))
    .with_output("mavlink", MavlinkOutputAdapter(connection_string="udpout:127.0.0.1:14550", system_id=1, component_id=1, message_type=MessageType.BOTH, frequency=10))
    # OR .with_output("custom", MyOutputAdapter(...))  # custom OutputAdapter child class instance
    .build())
```

## Localization Parameters

### `with_localization()`

Configure the multilateration engine:

- **`anchor_positions`** (dict, required): Dictionary mapping anchor IDs to (x, y, z) positions in meters
    - Keys can be integers or strings; they must match the **anchor IDs in your distance data** (e.g. from UDP/Serial).
    - See [Anchor configuration formats](#anchor-configuration-formats) for more info.
- **`origin_coordinates`** (tuple, optional): (latitude, longitude, altitude) for GPS conversion. If not provided, GPS output will be disabled.
- **`ellipsoid`** (str, optional): Ellipsoid model for GPS conversion (default: "wgs84")
- **`calibration_type`** (CalibrationType, optional): Type of calibration to apply (default: CalibrationType.NONE)
- **`calibration_params`** (list, optional): Parameters for calibration function (see [Calibration Types](calibration.md))
- **`z_sign`** (int, optional): Z-axis sign detection (0=auto, +1=upper, -1=lower)
- **`min_range`** (float, optional): Minimum valid distance in meters (default: 0.0)
- **`max_range`** (float, optional): Maximum valid distance in meters (default: 100.0)

## Anchor configuration formats

Anchors can be given in two ways.

### 1. Dict: ID → (x, y, z) in meters

Use when you already have ENU (or local) coordinates:

```python
anchor_positions={1: (0.0, 0.0, 0.0), 2: (3.0, 0.0, 0.0), 3: (0.0, 3.0, 0.0)}
```

Keys can be integers or strings; they must match the **anchor IDs in your distance data** (e.g. from UDP/Serial).

### 2. List: YAML-style with `gps` or `relative`

Use for config files or when you have GPS coordinates. Each item is a dict:

- **GPS:** `{"id": "A1", "gps": [lat, lon, alt]}` — optional `id`; if omitted, IDs are assigned as `A0`, `A1`, …
- **Relative (ENU):** `{"id": 1, "relative": [x, y, z]}`

Example (matches `examples/udp_example.yaml`):

```python
anchor_positions=[
    {"gps": [55.751244, 37.618423, 144.2]},           # id becomes "A0"
    {"id": "A1", "gps": [55.7519, 37.6178, 146.0]},
    {"id": "A2", "gps": [55.7507, 37.6192, 143.1]},
    {"id": "A3", "relative": [10.0, 5.0, 0.0]},
],
origin_coordinates=(55.751244, 37.618423, 144.2),
```

**Important:** Anchor IDs in this list (e.g. `"A0"`, `"A1"`) must match the **keys in the distance messages** you send (e.g. UDP payload with `{"id": "A0", "m": 1.2}`). Same IDs = correct matching in the solver.

## Input Adapter Methods

### `with_serial_input(port, baud, timeout=1.0)`

Configure serial port input adapter.

- **`port`** (str): Serial port path (e.g., "/dev/ttyUSB0" or "COM3")
- **`baud`** (int): Baud rate (e.g., 460800)
- **`timeout`** (float, optional): Read timeout in seconds (default: 1.0)

### `with_mqtt_input(broker, port=1883, topic, client_id=None)`

Configure MQTT input adapter. Requires `multilat_solver[mqtt]`.

- **`broker`** (str): MQTT broker hostname or IP
- **`port`** (int, optional): MQTT broker port (default: 1883)
- **`topic`** (str): MQTT topic to subscribe to
- **`client_id`** (str, optional): MQTT client ID (auto-generated if not provided)

### `with_udp_input(host, port)`

Configure UDP input adapter.

- **`host`** (str): Host to bind to (e.g., "0.0.0.0" for all interfaces)
- **`port`** (int): UDP port to listen on

### `with_file_input(filepath, poll_interval=1.0)`

Configure file input adapter.

- **`filepath`** (str): Path to JSON file containing distance measurements
- **`poll_interval`** (float, optional): Polling interval in seconds (default: 1.0)

## Output Adapter Methods

### `with_output(name, adapter_instance)`

Add an output adapter. Can be called multiple times for multiple outputs.

- **`name`** (str): Unique name for this output
- **`adapter_instance`**: An instance of an output adapter (e.g. `ConsoleOutputAdapter(format="human", ...)`)

See [Output Adapters](output-adapters.md) for adapter-specific constructor options.
