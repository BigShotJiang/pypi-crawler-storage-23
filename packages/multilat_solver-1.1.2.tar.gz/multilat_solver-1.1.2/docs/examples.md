# Examples

Repository examples: `basic_usage.py`, `multi_output.py`, `mavlink_input_with_sim.py`, `uavcan_input_mavlink_output.py`.

## Basic Usage

Serial input, console output:

```python
from multilat_solver import ConfigBuilder, MultiLatLocalizerApp, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import ConsoleOutputAdapter
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0)},
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800)
    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .build())

app = MultiLatLocalizerApp(config)
app.run()
```

## Multiple Output Adapters

```python
from multilat_solver import ConfigBuilder, MultiLatLocalizerApp, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter, FileOutputAdapter, MavlinkOutputAdapter, UDPOutputAdapter,
)

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0), 4: (3, 3, 0)},
        origin_coordinates=(37.7749, -122.4194, 0.0),
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800)
    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .with_output("file", FileOutputAdapter(filepath="positions.jsonl", mode="a", message_type=MessageType.BOTH, frequency=10))
    .with_output("mavlink", MavlinkOutputAdapter(connection_string="udpout:127.0.0.1:14550", system_id=1, component_id=1, message_type=MessageType.BOTH, frequency=10))
    .with_output("udp", UDPOutputAdapter(host="127.0.0.1", port=5006, message_type=MessageType.BOTH, frequency=10))
    .build())

app = MultiLatLocalizerApp(config)
app.run()
```

## MQTT Input

Requires `pip install multilat_solver[mqtt]`:

```python
config = (ConfigBuilder()
    .with_localization(anchor_positions={1: (0,0,0), 2: (3,0,0), 3: (0,3,0)}, calibration_type=CalibrationType.NONE)
    .with_mqtt_input(broker="localhost", port=1883, topic="multilat/distances")
    .with_output("console", ConsoleOutputAdapter(format="json", message_type=MessageType.POSITION, frequency=10))
    .build())
```

## ROS2/MAVROS

Requires `pip install multilat_solver[ros2]`:

```python
from multilat_solver.output_adapters import MavrosOutputAdapter

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0,0,0), 2: (3,0,0), 3: (0,3,0)},
        origin_coordinates=(37.7749, -122.4194, 0.0),
        calibration_type=CalibrationType.QUADRATIC,
        calibration_params=[0.001, 1.0, 0.0],
    )
    .with_udp_input(host="0.0.0.0", port=5005)
    .with_output("mavros", MavrosOutputAdapter(topic_prefix="mavros", frame_id="map", message_type=MessageType.BOTH, frequency=20))
    .build())
```

## Custom input: UAVCAN

`examples/uavcan_input_mavlink_output.py` shows a custom input adapter that subscribes to UAVCAN `uavcan.equipment.gnss.Fix2`, converts to distances (or uses as position source), and outputs via MAVLink. Use `with_input("uavcan", UavcanInputAdapter(node=node))` with your adapter instance. See [Extension Guide](extension.md) for the adapter interface.
