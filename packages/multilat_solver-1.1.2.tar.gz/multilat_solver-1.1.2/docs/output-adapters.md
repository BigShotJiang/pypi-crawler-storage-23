# Output Adapters

Output adapters send calculated positions to various destinations. Multiple output adapters can be configured simultaneously.

## MAVLink Output

Sends position and GPS via MAVLink (ArduPilot, PX4).

```python
from multilat_solver.output_adapters import MavlinkOutputAdapter
from multilat_solver.common_types import MessageType

config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("mavlink", MavlinkOutputAdapter(
        connection_string="udpout:127.0.0.1:14550",  # or "tcp:127.0.0.1:5760"
        system_id=1,
        component_id=1,
        message_type=MessageType.BOTH,
        frequency=10,
    ))
    .build())
```

### Constructor options

- **`connection_string`**: `"udpout:host:port"` or `"tcp:host:port"`
- **`system_id`**, **`component_id`**: MAVLink IDs
- **`message_type`**: `MessageType.GPS`, `POSITION`, or `BOTH`
- **`frequency`**: Max message rate (Hz)

### Messages Sent

- `LOCAL_POSITION_NED` for position (ENU coordinates)
- `HIL_GPS` for GPS coordinates (if `origin_coordinates` is configured in localization settings)

## MAVROS Output (ROS2)

Requires `pip install multilat_solver[ros2]`. Publishes to ROS2 topics.

```python
from multilat_solver.output_adapters import MavrosOutputAdapter

config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("mavros", MavrosOutputAdapter(
        topic_prefix="mavros",
        frame_id="map",
        message_type=MessageType.BOTH,
        frequency=10,
    ))
    .build())
```

### Constructor options

- **`topic_prefix`**: Topic prefix (default `"mavros"`)
- **`frame_id`**: Frame for pose (default `"map"`)
- **`message_type`**, **`frequency`**: As above

### Topics Published

- `{topic_prefix}/fake_gps/mocap/pose` (geometry_msgs/PoseStamped) - Position in ENU coordinates
- `uwb/gps` (sensor_msgs/NavSatFix) - GPS coordinates (if `origin_coordinates` is configured)

## UDP Output

Sends position/GPS as JSON over UDP.

```python
from multilat_solver.output_adapters import UDPOutputAdapter

config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("udp", UDPOutputAdapter(host="127.0.0.1", port=5006, message_type=MessageType.BOTH, frequency=10))
    .build())
```

### Constructor options

- **`host`**, **`port`**: Target address
- **`message_type`**, **`frequency`**: As above

### Message Format

JSON format:
```json
{
  "position": {"x": 1.0, "y": 2.0, "z": 3.0},
  "gps": {"lat": 37.7749, "lon": -122.4194, "alt": 0.0},
  "t": 1234567890.0
}
```

If GPS is not configured, the `gps` field will be omitted.

## File Output

Writes position/GPS to a JSONL file (one JSON object per line).

```python
from multilat_solver.output_adapters import FileOutputAdapter

config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("file", FileOutputAdapter(filepath="positions.jsonl", mode="a", message_type=MessageType.BOTH, frequency=10))
    .build())
```

### Constructor options

- **`filepath`**: Output path
- **`mode`**: `"a"` (append) or `"w"` (overwrite)
- **`message_type`**, **`frequency`**: As above

### Message Format

JSONL format (one JSON object per line):
```json
{"position": {"x": 1.0, "y": 2.0, "z": 3.0}, "t": 1234567890.0}
{"position": {"x": 1.1, "y": 2.1, "z": 3.1}, "t": 1234567891.0}
```

## Console Output

Prints position/GPS to console (debugging).

```python
from multilat_solver.output_adapters import ConsoleOutputAdapter

config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .build())
```

### Constructor options

- **`format`**: `"human"` or `"json"`
- **`message_type`**, **`frequency`**: As above

### Formats

**Human format**:
```
Position: x=1.000, y=2.000, z=3.000
GPS: lat=37.7749, lon=-122.4194, alt=0.000
```

**JSON format**:
```json
{"position": {"x": 1.0, "y": 2.0, "z": 3.0}, "gps": {"lat": 37.7749, "lon": -122.4194, "alt": 0.0}, "t": 1234567890.0}
```
