# Extension Points

The library is designed to be extensible. You can add custom input or output adapters by following these steps.

## Creating a Custom Input Adapter

1. **Create the adapter class** (inherit from `InputAdapter`):

```python
from multilat_solver.input_adapters import InputAdapter

class MyInputAdapter(InputAdapter):
    def __init__(self, config):
        self.config = config
        self.running = False
        self.callback = None

    def start(self, callback):
        """Start receiving data and call callback with distance dict."""
        self.callback = callback
        self.running = True
        # Your implementation here
        # Call self.callback({"1": 2.5, "2": 3.1}) when data arrives

    def stop(self):
        """Stop receiving data."""
        self.running = False
        # Cleanup code here

    def is_running(self):
        return self.running
```

2. **Create a config dataclass**:

```python
from dataclasses import dataclass

@dataclass
class MyAdapterConfig:
    param1: str
    param2: int
```

3. **Use the adapter** with `with_input(name, instance)`:

```python
config = (ConfigBuilder()
    .with_localization(...)
    .with_input("my_input", MyInputAdapter(param1="value", param2=42))
    .with_output(...)
    .build())
```

Alternatively **register** and use a builder method (optional):

```python
from multilat_solver import ConfigBuilder
from multilat_solver.config import InputConfig

def with_my_input(self, param1: str, param2: int) -> 'ConfigBuilder':
    self._input = InputConfig(
        type="my_adapter",
        config=MyAdapterConfig(param1=param1, param2=param2)
    )
    return self

# Add to ConfigBuilder class
ConfigBuilder.with_my_input = with_my_input
```

## Creating a Custom Output Adapter

1. **Create the adapter class** (inherit from `OutputAdapter`):

```python
from multilat_solver.output_adapters import OutputAdapter
from multilat_solver.common_types import Position, GPSPosition

class MyOutputAdapter(OutputAdapter):
    def __init__(self, config):
        self.config = config
        self.running = False

    def start(self):
        """Initialize output channel."""
        self.running = True
        # Your initialization code here

    def stop(self):
        """Cleanup output channel."""
        self.running = False
        # Cleanup code here

    def send_position(self, position: Position, timestamp: float):
        """Send position data."""
        if not self.running:
            return
        # Your implementation here

    def send_gps(self, gps: GPSPosition, timestamp: float):
        """Send GPS data."""
        if not self.running:
            return
        # Your implementation here

    def is_running(self):
        return self.running
```

2. **Accept config in `__init__`** (e.g. `message_type`, `frequency` for throttling; see existing adapters).

3. **Use the adapter** (pass an instance):

```python
config = (ConfigBuilder()
    .with_localization(...)
    .with_serial_input(...)
    .with_output("my_output", MyOutputAdapter(param1="value", param2=42))
    .build())
```

## Adapter Interface Requirements

### InputAdapter

- Must implement `start(callback)` method that calls `callback(distance_dict)` when data arrives
- Must implement `stop()` method for cleanup
- Must implement `is_running()` method returning boolean

### OutputAdapter

- Must implement `start()` method for initialization
- Must implement `stop()` method for cleanup
- Must implement `send_position(position, timestamp)` method
- Must implement `send_gps(gps, timestamp)` method (can be no-op if GPS not supported)
- Must implement `is_running()` method returning boolean
- Should respect `message_type` and `frequency` (base class helpers available)
