"""Tests for MultiLat Localization System"""
