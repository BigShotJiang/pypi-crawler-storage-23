"""Allow running GeoSnag as: python -m geosnag"""

from geosnag.cli import main

if __name__ == "__main__":
    main()
