"""atlas.recon — Layer 1: Environment observation and modeling."""

from atlas.recon.engine import EnvironmentModel, ReconEngine
