"""Placeholder for a simple chat agent without any tool integrations or MCP capabilities."""
