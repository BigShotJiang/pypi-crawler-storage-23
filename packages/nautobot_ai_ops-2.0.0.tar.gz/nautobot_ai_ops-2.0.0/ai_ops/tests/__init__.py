"""Tests for AI Ops app."""
