"""REST API module for ai_ops app."""
