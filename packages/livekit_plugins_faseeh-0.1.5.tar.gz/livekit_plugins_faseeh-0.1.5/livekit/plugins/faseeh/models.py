from typing import Literal

TTSModels = Literal[
    "faseeh-v1-preview",
    "faseeh-mini-v1-preview",
]
