"""Shared sync helpers split out from main.py."""

