# Factory & Cascade

::: majordomo_llm.factory.get_llm_instance

::: majordomo_llm.factory.get_all_llm_instances

::: majordomo_llm.cascade.LLMCascade
