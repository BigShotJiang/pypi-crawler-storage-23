"""Internal helper classes for agent implementation."""

from __future__ import annotations

# This module previously contained ResponseContext for tracking feedback.
# That class was removed with ConversationalAgent in the SAIA refactor.
# Keep the module for future internal helpers if needed.
