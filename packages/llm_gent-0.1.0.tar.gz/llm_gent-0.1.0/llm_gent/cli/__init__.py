"""CLI for agent server and management."""

from .cli import main


__all__ = ["main"]
