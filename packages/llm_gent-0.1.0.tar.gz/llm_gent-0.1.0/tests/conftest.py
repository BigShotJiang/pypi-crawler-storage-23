"""Pytest configuration for llm-gent tests."""

pytest_plugins = ["appinfra.testing"]
