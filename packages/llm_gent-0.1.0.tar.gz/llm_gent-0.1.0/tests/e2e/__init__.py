"""End-to-end tests requiring real dependencies."""
