"""LLM module tests."""
