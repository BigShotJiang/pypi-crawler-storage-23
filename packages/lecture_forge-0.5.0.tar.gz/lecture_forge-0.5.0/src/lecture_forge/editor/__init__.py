"""
Web-based lecture editor module.
"""
