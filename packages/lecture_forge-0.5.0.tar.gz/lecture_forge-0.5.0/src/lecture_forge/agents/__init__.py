"""
Agents for LectureForge multi-agent system.
"""

# Import all agents here as they are implemented
# from lecture_forge.agents.content_collector import ContentCollectorAgent
# from lecture_forge.agents.image_collector import ImageCollectorAgent
# ...
