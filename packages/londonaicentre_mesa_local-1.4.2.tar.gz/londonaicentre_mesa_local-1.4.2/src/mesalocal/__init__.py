import asyncio
from argparse import ArgumentParser

from mesalocal.settings import ServerConfig, VLLMConfig
from mesalocal.types import MESALocalArguments
from mesalocal.weights import Weights
from mesalocal.inferrer import VLLM


def parse_args() -> MESALocalArguments:
    parser: ArgumentParser = ArgumentParser()
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Whether to print debug output",
    )
    return MESALocalArguments(**vars(parser.parse_args()))


def run() -> None:
    args: MESALocalArguments = parse_args()
    vllm_config: VLLMConfig = VLLMConfig()
    weights: Weights = Weights(vllm_config.model, args.verbose)
    if weights.download():
        asyncio.run(
            VLLM(weights.get_model_folder(), vllm_config, args.verbose).serve(
                ServerConfig().port
            )
        )
