import pandas as pd
import pytest

from kpi_engine import KPIEngine
from kpi_engine.models import Alert, KPIDefinition

orders_df = pd.DataFrame({
    "revenue": [1000, 2000, 1500, 3000],
    "order_date": pd.to_datetime([
        "2024-10-01", "2024-10-15",
        "2024-11-01", "2024-11-20",
    ]),
    "quantity": [1, 2, 1, 3],
})


def make_engine():
    kpi = KPIDefinition(
        name="total_revenue",
        label="Total Revenue",
        source="dataframe",
        aggregation="sum",
        unit="USD",
        query="orders.revenue",
        compare=["MoM"],
        alerts=[Alert(condition="< 0", severity="critical")],
    )
    return KPIEngine(kpis=[kpi], dataframes={"orders": orders_df})


def test_kpi_returns_result():
    results = make_engine().run(period="2024-11")
    assert len(results) == 1
    assert results[0].name == "total_revenue"


def test_value_is_numeric():
    results = make_engine().run(period="2024-11")
    assert isinstance(results[0].value, float)


def test_november_revenue():
    results = make_engine().run(period="2024-11")
    assert results[0].value == 4500.0


def test_alert_status_ok_for_positive():
    results = make_engine().run(period="2024-11")
    assert results[0].alert_status in ("ok", "warning", "critical")


def test_alert_not_triggered_for_positive_value():
    results = make_engine().run(period="2024-11")
    assert results[0].alert_status == "ok"
    assert results[0].alerts_triggered == []


def test_run_kpi_single():
    engine = make_engine()
    result = engine.run_kpi("total_revenue", period="2024-11")
    assert result.name == "total_revenue"
    assert result.value == 4500.0


def test_history_accumulates():
    engine = make_engine()
    engine.run(period="2024-11")
    engine.run(period="2024-10")
    h = engine.history("total_revenue")
    assert len(h) == 2


def test_derived_kpi():
    rev_kpi = KPIDefinition(
        name="revenue",
        label="Revenue",
        source="dataframe",
        aggregation="sum",
        query="orders.revenue",
    )
    cust_kpi = KPIDefinition(
        name="customers",
        label="Customers",
        source="dataframe",
        aggregation="count",
        query="orders.revenue",
    )
    derived = KPIDefinition(
        name="rev_per_customer",
        label="Revenue per Customer",
        source="derived",
        expression="revenue / customers",
        unit="USD",
    )
    engine = KPIEngine(
        kpis=[rev_kpi, cust_kpi, derived],
        dataframes={"orders": orders_df},
    )
    results = engine.run(period="2024-11")
    by_name = {r.name: r for r in results}
    assert by_name["rev_per_customer"].value == pytest.approx(2250.0)


def test_from_yaml(tmp_path):
    yaml_content = """
kpis:
  - name: total_revenue
    label: Total Revenue
    source: dataframe
    aggregation: sum
    unit: USD
    query: "orders.revenue"
    compare: []
    alerts: []
"""
    p = tmp_path / "kpis.yaml"
    p.write_text(yaml_content)
    engine = KPIEngine.from_yaml(str(p), dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert results[0].value == 4500.0
