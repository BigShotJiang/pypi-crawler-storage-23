import pandas as pd
import pytest

from kpi_engine import KPIEngine
from kpi_engine.alerts.evaluator import AlertEvaluator
from kpi_engine.models import Alert, KPIDefinition

evaluator = AlertEvaluator()


# ------------------------------------------------------------------
# Unit tests for AlertEvaluator
# ------------------------------------------------------------------

def test_threshold_below_triggers():
    results = evaluator.evaluate(500, [Alert(condition="< 1000", severity="critical")])
    assert results[0].triggered is True
    assert results[0].severity == "critical"


def test_threshold_above_not_triggered():
    results = evaluator.evaluate(2000, [Alert(condition="< 1000", severity="warning")])
    assert results[0].triggered is False


def test_greater_than_triggers():
    results = evaluator.evaluate(150, [Alert(condition="> 100", severity="warning")])
    assert results[0].triggered is True


def test_greater_than_not_triggered():
    results = evaluator.evaluate(50, [Alert(condition="> 100", severity="warning")])
    assert results[0].triggered is False


def test_lte_triggers_at_boundary():
    results = evaluator.evaluate(100, [Alert(condition="<= 100", severity="info")])
    assert results[0].triggered is True


def test_gte_triggers_at_boundary():
    results = evaluator.evaluate(100, [Alert(condition=">= 100", severity="info")])
    assert results[0].triggered is True


def test_equals_triggers():
    results = evaluator.evaluate(42.0, [Alert(condition="== 42.0", severity="info")])
    assert results[0].triggered is True


def test_multiple_alerts_mixed():
    alerts = [
        Alert(condition="< 100", severity="warning"),
        Alert(condition="> 1000", severity="critical"),
    ]
    results = evaluator.evaluate(50, alerts)
    assert results[0].triggered is True
    assert results[1].triggered is False


def test_custom_message_preserved():
    alert = Alert(condition="< 100", severity="warning", message="Revenue too low")
    results = evaluator.evaluate(50, [alert])
    assert results[0].message == "Revenue too low"


def test_default_message_generated():
    alert = Alert(condition="< 100", severity="warning")
    results = evaluator.evaluate(50, [alert])
    assert "50" in results[0].message


# ------------------------------------------------------------------
# Integration: alert status propagates through KPIEngine
# ------------------------------------------------------------------

orders_df = pd.DataFrame({
    "revenue": [-100],
    "order_date": pd.to_datetime(["2024-11-15"]),
})


def test_engine_sets_critical_status():
    kpi = KPIDefinition(
        name="revenue",
        label="Revenue",
        source="dataframe",
        aggregation="sum",
        query="orders.revenue",
        alerts=[Alert(condition="< 0", severity="critical")],
    )
    engine = KPIEngine(kpis=[kpi], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert results[0].alert_status == "critical"
    assert len(results[0].alerts_triggered) == 1


def test_engine_sets_ok_when_no_trigger():
    kpi = KPIDefinition(
        name="revenue",
        label="Revenue",
        source="dataframe",
        aggregation="sum",
        query="orders.revenue",
        alerts=[Alert(condition="> 1000000", severity="critical")],
    )
    engine = KPIEngine(kpis=[kpi], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert results[0].alert_status == "ok"
