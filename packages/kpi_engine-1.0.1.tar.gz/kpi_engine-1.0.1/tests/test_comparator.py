import pandas as pd
import pytest

from kpi_engine import KPIEngine
from kpi_engine.models import KPIDefinition

orders_df = pd.DataFrame({
    "revenue": [1000, 2000, 1500, 3000, 4000, 2500],
    "order_date": pd.to_datetime([
        "2024-09-05", "2024-09-15",
        "2024-10-01", "2024-10-15",
        "2024-11-01", "2024-11-20",
    ]),
})


def make_kpi(**kwargs):
    defaults = dict(
        name="revenue",
        label="Revenue",
        source="dataframe",
        aggregation="sum",
        unit="USD",
        query="orders.revenue",
        compare=["MoM"],
    )
    defaults.update(kwargs)
    return KPIDefinition(**defaults)


def test_mom_comparison_present():
    engine = KPIEngine(kpis=[make_kpi()], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert "MoM" in results[0].comparisons


def test_comparison_direction_valid():
    engine = KPIEngine(kpis=[make_kpi()], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    comp = results[0].comparisons["MoM"]
    assert comp.direction in ("up", "down", "flat")


def test_mom_values():
    engine = KPIEngine(kpis=[make_kpi()], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    comp = results[0].comparisons["MoM"]
    # Nov = 6500, Oct = 4500 → change = +2000
    assert comp.change_absolute == pytest.approx(2000.0)
    assert comp.direction == "up"


def test_is_improvement_higher_is_better():
    engine = KPIEngine(kpis=[make_kpi(polarity="higher_is_better")], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    comp = results[0].comparisons["MoM"]
    assert comp.is_improvement is True


def test_is_improvement_lower_is_better():
    engine = KPIEngine(kpis=[make_kpi(polarity="lower_is_better")], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    comp = results[0].comparisons["MoM"]
    assert comp.is_improvement is False


def test_yoy_comparison():
    engine = KPIEngine(kpis=[make_kpi(compare=["YoY"])], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert "YoY" in results[0].comparisons


def test_no_comparisons_when_empty():
    engine = KPIEngine(kpis=[make_kpi(compare=[])], dataframes={"orders": orders_df})
    results = engine.run(period="2024-11")
    assert results[0].comparisons == {}
