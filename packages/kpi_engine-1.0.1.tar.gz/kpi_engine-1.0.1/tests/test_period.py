import pytest
from datetime import datetime

from kpi_engine.period import resolve_period, Period


def test_yesterday():
    p = resolve_period("yesterday")
    assert p.label == "yesterday"
    assert (p.end - p.start).days == 1


def test_last_week():
    p = resolve_period("last_week")
    assert p.label == "last_week"
    assert (p.end - p.start).days == 7


def test_last_month_boundaries():
    p = resolve_period("last_month")
    assert p.label == "last_month"
    assert p.start.day == 1
    assert p.end.day == 1
    assert p.end > p.start


def test_last_quarter_three_months():
    p = resolve_period("last_quarter")
    assert (p.end - p.start).days in range(89, 93)


def test_quarter_format_q1():
    p = resolve_period("2024-Q1")
    assert p.start == datetime(2024, 1, 1)
    assert p.end == datetime(2024, 4, 1)


def test_quarter_format_q3():
    p = resolve_period("2024-Q3")
    assert p.start == datetime(2024, 7, 1)
    assert p.end == datetime(2024, 10, 1)


def test_month_format():
    p = resolve_period("2024-11")
    assert p.start == datetime(2024, 11, 1)
    assert p.end == datetime(2024, 12, 1)


def test_invalid_period():
    with pytest.raises(ValueError):
        resolve_period("not_a_period")


def test_shift_mom():
    p = resolve_period("last_month")
    prior = p.shift("MoM")
    assert prior.start < p.start


def test_shift_yoy():
    p = resolve_period("2024-11")
    prior = p.shift("YoY")
    assert prior.start.year == 2023
    assert prior.start.month == 11


def test_shift_dod():
    p = resolve_period("yesterday")
    prior = p.shift("DoD")
    assert (p.start - prior.start).days == 1


def test_shift_qoq():
    p = resolve_period("2024-Q3")
    prior = p.shift("QoQ")
    assert prior.start == datetime(2024, 4, 1)


def test_shift_unknown():
    p = resolve_period("yesterday")
    with pytest.raises(ValueError):
        p.shift("XoX")
