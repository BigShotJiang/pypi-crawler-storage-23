from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum


class ComparisonType(str, Enum):
    DOD = "DoD"
    WOW = "WoW"
    MOM = "MoM"
    QOQ = "QoQ"
    YOY = "YoY"


@dataclass
class Alert:
    condition: str          # e.g. "< 50000", "> 0.15"
    severity: str = "warning"   # "info" | "warning" | "critical"
    type: str = "threshold"     # "threshold" | "change_pct" | "anomaly" | "no_data"
    message: str = ""


@dataclass
class KPIDefinition:
    name: str
    label: str
    source: str                 # "sql" | "dataframe" | "derived"
    aggregation: str = "sum"    # "sum" | "avg" | "count" | "rate" | "last"
    unit: str = ""
    query: str = ""             # Jinja2 SQL template or "table.column" for dataframe
    denominator_query: str = "" # For "rate" aggregation
    expression: str = ""        # For "derived" source
    polarity: str = "higher_is_better"
    compare: List[str] = field(default_factory=list)
    alerts: List[Alert] = field(default_factory=list)
    params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComparisonResult:
    period_label: str
    previous_value: float
    change_absolute: float
    change_pct: float
    direction: str              # "up" | "down" | "flat"
    is_improvement: bool


@dataclass
class AlertResult:
    alert: Alert
    triggered: bool
    message: str
    severity: str


@dataclass
class KPIResult:
    name: str
    label: str
    value: float
    unit: str
    period_start: datetime
    period_end: datetime
    comparisons: Dict[str, ComparisonResult] = field(default_factory=dict)
    alert_status: str = "ok"    # "ok" | "warning" | "critical"
    alerts_triggered: List[AlertResult] = field(default_factory=list)
    computed_at: datetime = field(default_factory=datetime.utcnow)
    query_duration_ms: float = 0.0

    @property
    def mom_change_pct(self) -> Optional[float]:
        comp = self.comparisons.get("MoM")
        return comp.change_pct if comp else None

    @property
    def yoy_change_pct(self) -> Optional[float]:
        comp = self.comparisons.get("YoY")
        return comp.change_pct if comp else None
