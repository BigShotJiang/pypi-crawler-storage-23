from .base import BaseBackend


class DerivedBackend(BaseBackend):
    def __init__(self, computed_values: dict = None):
        self._computed = computed_values or {}

    def set_computed(self, computed_values: dict):
        self._computed = computed_values

    def compute(self, kpi, period, params=None):
        try:
            value = float(eval(kpi.expression, {"__builtins__": {}}, self._computed))
        except Exception:
            value = 0.0
        return value, 0.0
