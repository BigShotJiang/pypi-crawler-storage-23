from abc import ABC, abstractmethod


class BaseBackend(ABC):
    @abstractmethod
    def compute(self, kpi, period, params=None):
        """Compute the KPI value for the given period.

        Returns:
            tuple: (value: float, duration_ms: float)
        """
