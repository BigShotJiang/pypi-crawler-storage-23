import time
from jinja2 import Template
from sqlalchemy import text

from .base import BaseBackend


class SQLBackend(BaseBackend):
    def __init__(self, connection):
        self.connection = connection

    def compute(self, kpi, period, params=None):
        query = Template(kpi.query).render(
            period_start=period.start.isoformat(),
            period_end=period.end.isoformat(),
            **(params or {}),
            **(kpi.params or {})
        )
        t0 = time.time()
        with self.connection.connect() as conn:
            result = conn.execute(text(query)).scalar()
        elapsed = (time.time() - t0) * 1000

        if kpi.aggregation == "rate" and kpi.denominator_query:
            denom_query = Template(kpi.denominator_query).render(
                period_start=period.start.isoformat(),
                period_end=period.end.isoformat()
            )
            with self.connection.connect() as conn:
                denom = conn.execute(text(denom_query)).scalar()
            result = (result / denom) if denom else 0.0

        return float(result or 0), elapsed
