import time

from .base import BaseBackend


class DataFrameBackend(BaseBackend):
    def __init__(self, dataframes: dict):
        self.dataframes = dataframes

    def compute(self, kpi, period, params=None):
        t0 = time.time()

        # Resolve dataframe and column from query field ("table.column" or "column")
        df, col_name = self._resolve_source(kpi)
        if df is None:
            return 0.0, 0.0

        # Filter by period using any date-like column
        date_cols = [c for c in df.columns
                     if any(tok in c.lower() for tok in ("date", "time", "ts", "at", "created", "updated"))]
        if date_cols:
            date_col = date_cols[0]
            mask = (df[date_col] >= period.start) & (df[date_col] < period.end)
            filtered = df[mask]
        else:
            filtered = df

        # Fallback: use first numeric column if col_name is missing
        if col_name not in filtered.columns:
            num_cols = filtered.select_dtypes(include="number").columns.tolist()
            col_name = num_cols[0] if num_cols else None

        if col_name is None or col_name not in filtered.columns:
            return 0.0, (time.time() - t0) * 1000

        series = filtered[col_name]
        value = self._aggregate(kpi, series, filtered)
        return value, (time.time() - t0) * 1000

    def _resolve_source(self, kpi):
        if kpi.query and "." in kpi.query:
            df_name, col_name = kpi.query.split(".", 1)
            return self.dataframes.get(df_name), col_name

        if self.dataframes:
            df_name = next(iter(self.dataframes))
            df = self.dataframes[df_name]
            col_name = kpi.query if kpi.query and kpi.query in df.columns else None
            if col_name is None:
                num_cols = df.select_dtypes(include="number").columns.tolist()
                col_name = num_cols[0] if num_cols else None
            return df, col_name

        return None, None

    def _aggregate(self, kpi, series, filtered) -> float:
        agg = kpi.aggregation
        if agg == "sum":
            return float(series.sum())
        if agg == "avg":
            return float(series.mean()) if len(series) > 0 else 0.0
        if agg == "count":
            return float(len(series))
        if agg == "last":
            return float(series.iloc[-1]) if len(series) > 0 else 0.0
        if agg == "rate":
            num = float(series.sum())
            denom_col = kpi.denominator_query
            if denom_col and denom_col in filtered.columns:
                denom = float(filtered[denom_col].sum())
                return (num / denom) if denom != 0 else 0.0
            return num
        return float(series.sum())
