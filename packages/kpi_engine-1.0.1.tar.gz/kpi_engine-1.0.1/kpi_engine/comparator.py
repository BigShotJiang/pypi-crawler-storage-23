from .models import KPIDefinition, ComparisonResult
from .period import Period


class PeriodComparator:
    def __init__(self, backend):
        self.backend = backend

    def compare(self, kpi: KPIDefinition, current_value: float, period: Period) -> dict:
        results = {}
        for comp_type in kpi.compare:
            prior_period = period.shift(comp_type)
            prior_value, _ = self.backend.compute(kpi, prior_period)
            change_abs = current_value - prior_value
            change_pct = (change_abs / prior_value * 100) if prior_value != 0 else 0.0
            direction = "up" if change_abs > 0 else ("down" if change_abs < 0 else "flat")
            is_improvement = (
                (direction == "up" and kpi.polarity == "higher_is_better") or
                (direction == "down" and kpi.polarity == "lower_is_better")
            )
            results[comp_type] = ComparisonResult(
                period_label=comp_type,
                previous_value=prior_value,
                change_absolute=round(change_abs, 4),
                change_pct=round(change_pct, 2),
                direction=direction,
                is_improvement=is_improvement
            )
        return results
