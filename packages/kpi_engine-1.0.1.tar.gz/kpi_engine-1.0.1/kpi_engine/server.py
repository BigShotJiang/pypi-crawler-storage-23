from datetime import datetime
from typing import Dict, List

try:
    from fastapi import FastAPI, HTTPException, Query
    from pydantic import BaseModel
    _HAS_FASTAPI = True
except ImportError:
    _HAS_FASTAPI = False


if _HAS_FASTAPI:
    class _ComparisonSchema(BaseModel):
        period_label: str
        previous_value: float
        change_absolute: float
        change_pct: float
        direction: str
        is_improvement: bool

    class _KPIResultSchema(BaseModel):
        name: str
        label: str
        value: float
        unit: str
        period_start: datetime
        period_end: datetime
        alert_status: str
        computed_at: datetime
        query_duration_ms: float
        comparisons: Dict[str, _ComparisonSchema] = {}


def create_app(engine):
    if not _HAS_FASTAPI:
        raise ImportError("fastapi and uvicorn are required. pip install fastapi uvicorn")

    app = FastAPI(title="KPI Engine API", version="1.0.0")

    def _serialize(r):
        return {
            "name": r.name,
            "label": r.label,
            "value": r.value,
            "unit": r.unit,
            "period_start": r.period_start,
            "period_end": r.period_end,
            "alert_status": r.alert_status,
            "computed_at": r.computed_at,
            "query_duration_ms": r.query_duration_ms,
            "comparisons": {
                k: {
                    "period_label": v.period_label,
                    "previous_value": v.previous_value,
                    "change_absolute": v.change_absolute,
                    "change_pct": v.change_pct,
                    "direction": v.direction,
                    "is_improvement": v.is_improvement,
                }
                for k, v in r.comparisons.items()
            },
        }

    @app.get("/kpis", response_model=List[_KPIResultSchema])
    def run_all(period: str = Query(default="last_month")):
        return [_serialize(r) for r in engine.run(period=period)]

    @app.get("/kpis/{name}", response_model=_KPIResultSchema)
    def run_one(name: str, period: str = Query(default="last_month")):
        if name not in engine.kpis:
            raise HTTPException(status_code=404, detail=f"KPI '{name}' not found")
        result = engine.run_kpi(name=name, period=period)
        return _serialize(result)

    @app.get("/kpis/{name}/history")
    def history(name: str, n: int = Query(default=10)):
        return [_serialize(r) for r in engine.history(name=name, n=n)]

    return app
