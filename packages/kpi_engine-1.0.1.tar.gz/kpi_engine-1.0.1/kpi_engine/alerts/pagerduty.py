import requests

_SEVERITY_MAP = {"info": "info", "warning": "warning", "critical": "critical"}


class PagerDutyChannel:
    API_URL = "https://events.pagerduty.com/v2/enqueue"

    def __init__(self, integration_key: str):
        self.integration_key = integration_key

    def send(self, kpi, value, alert_result):
        payload = {
            "routing_key": self.integration_key,
            "event_action": "trigger",
            "payload": {
                "summary": f"KPI Alert: {kpi.label} — {alert_result.message}",
                "severity": _SEVERITY_MAP.get(alert_result.severity, "warning"),
                "source": "kpi-engine",
                "custom_details": {
                    "kpi_name": kpi.name,
                    "kpi_label": kpi.label,
                    "value": value,
                    "unit": kpi.unit,
                    "condition": alert_result.alert.condition,
                },
            },
        }
        response = requests.post(self.API_URL, json=payload, timeout=10)
        response.raise_for_status()
