from ..models import Alert, AlertResult


class AlertEvaluator:
    def evaluate(self, value: float, alerts: list) -> list:
        results = []
        for alert in alerts:
            triggered = self._check_condition(value, alert.condition)
            results.append(AlertResult(
                alert=alert,
                triggered=triggered,
                message=alert.message or f"KPI value {value} {alert.condition}",
                severity=alert.severity
            ))
        return results

    def _check_condition(self, value: float, condition: str) -> bool:
        """Evaluate a condition string like '< 50000' or '> 0.15'."""
        condition = condition.strip()
        if condition.startswith("<= "):
            return value <= float(condition[3:])
        if condition.startswith(">= "):
            return value >= float(condition[3:])
        if condition.startswith("== "):
            return value == float(condition[3:])
        if condition.startswith("< "):
            return value < float(condition[2:])
        if condition.startswith("> "):
            return value > float(condition[2:])
        return False
