import logging

logger = logging.getLogger(__name__)


class AlertDispatcher:
    def __init__(self, channels: list):
        self.channels = channels

    def dispatch(self, kpi, value, triggered_alerts):
        for alert_result in triggered_alerts:
            for channel in self.channels:
                try:
                    channel.send(kpi, value, alert_result)
                except Exception as e:
                    logger.warning("Failed to dispatch alert via %s: %s", channel.__class__.__name__, e)
