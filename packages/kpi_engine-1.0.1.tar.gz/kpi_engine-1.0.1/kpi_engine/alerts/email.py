import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List


class EmailChannel:
    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        from_email: str,
        to_emails: List[str],
        username: str = None,
        password: str = None,
        use_tls: bool = True,
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.from_email = from_email
        self.to_emails = to_emails
        self.username = username
        self.password = password
        self.use_tls = use_tls

    def send(self, kpi, value, alert_result):
        msg = MIMEMultipart()
        msg["From"] = self.from_email
        msg["To"] = ", ".join(self.to_emails)
        msg["Subject"] = f"KPI Alert [{alert_result.severity.upper()}]: {kpi.label}"

        body = (
            f"KPI Alert triggered.\n\n"
            f"KPI:      {kpi.label}\n"
            f"Value:    {value} {kpi.unit}\n"
            f"Severity: {alert_result.severity}\n"
            f"Message:  {alert_result.message}\n"
        )
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
            if self.use_tls:
                server.starttls()
            if self.username and self.password:
                server.login(self.username, self.password)
            server.sendmail(self.from_email, self.to_emails, msg.as_string())
