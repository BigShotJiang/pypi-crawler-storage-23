import requests


class SlackChannel:
    def __init__(self, webhook_url: str, channel: str = None):
        self.webhook_url = webhook_url
        self.channel = channel

    def send(self, kpi, value, alert_result):
        message = {
            "text": (
                f"*KPI Alert* [{alert_result.severity.upper()}]\n"
                f"*{kpi.label}*: {value} {kpi.unit}\n"
                f"{alert_result.message}"
            )
        }
        if self.channel:
            message["channel"] = self.channel
        response = requests.post(self.webhook_url, json=message, timeout=10)
        response.raise_for_status()
