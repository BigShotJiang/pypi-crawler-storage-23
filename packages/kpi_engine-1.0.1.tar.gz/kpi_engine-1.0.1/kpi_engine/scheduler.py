import logging
import threading
from datetime import datetime
from typing import Callable

logger = logging.getLogger(__name__)


class KPIScheduler:
    def __init__(self, engine):
        self.engine = engine
        self._threads: list = []
        self._running = False

    def schedule(self, cron: str, period_fn: Callable[[], str], callback: Callable = None):
        """Schedule the engine on a cron expression.

        Args:
            cron: Cron expression e.g. "0 9 * * 1" (every Monday 9am UTC)
            period_fn: Callable returning the period string for each run
            callback: Optional callable(results) invoked after each run
        """
        try:
            from croniter import croniter  # noqa: F401
        except ImportError:
            raise ImportError("croniter is required for scheduling. pip install croniter")

        self._running = True

        def _loop():
            import time
            from croniter import croniter as _croniter

            while self._running:
                now = datetime.utcnow()
                itr = _croniter(cron, now)
                next_run = itr.get_next(datetime)
                sleep_sec = (next_run - datetime.utcnow()).total_seconds()
                if sleep_sec > 0:
                    time.sleep(sleep_sec)
                if not self._running:
                    break
                try:
                    period = period_fn()
                    results = self.engine.run(period=period)
                    if callback:
                        callback(results)
                except Exception as e:
                    logger.error("Scheduled KPI run failed: %s", e)

        t = threading.Thread(target=_loop, daemon=True)
        t.start()
        self._threads.append(t)

    def stop(self):
        self._running = False
