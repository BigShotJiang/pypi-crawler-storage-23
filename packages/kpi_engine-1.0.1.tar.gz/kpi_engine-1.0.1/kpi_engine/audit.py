import csv
import json
import os
from typing import List

from .models import KPIResult


class AuditLog:
    """Writes KPI results to a CSV or SQLite audit trail."""

    _CSV_FIELDS = [
        "name", "label", "value", "unit",
        "period_start", "period_end", "alert_status",
        "computed_at", "query_duration_ms",
    ]

    def __init__(self, path: str):
        self.path = path
        self._sqlite = path.endswith(".db") or path.endswith(".sqlite")
        if self._sqlite:
            self._init_sqlite()

    def write(self, results: List[KPIResult]):
        if self._sqlite:
            self._write_sqlite(results)
        else:
            self._write_csv(results)

    # ------------------------------------------------------------------
    # CSV
    # ------------------------------------------------------------------

    def _write_csv(self, results: List[KPIResult]):
        file_exists = os.path.exists(self.path)
        with open(self.path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._CSV_FIELDS)
            if not file_exists:
                writer.writeheader()
            for r in results:
                writer.writerow({
                    "name": r.name,
                    "label": r.label,
                    "value": r.value,
                    "unit": r.unit,
                    "period_start": r.period_start.isoformat(),
                    "period_end": r.period_end.isoformat(),
                    "alert_status": r.alert_status,
                    "computed_at": r.computed_at.isoformat(),
                    "query_duration_ms": r.query_duration_ms,
                })

    # ------------------------------------------------------------------
    # SQLite
    # ------------------------------------------------------------------

    def _init_sqlite(self):
        import sqlite3
        with sqlite3.connect(self.path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS kpi_audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    label TEXT,
                    value REAL,
                    unit TEXT,
                    period_start TEXT,
                    period_end TEXT,
                    alert_status TEXT,
                    computed_at TEXT,
                    query_duration_ms REAL,
                    comparisons TEXT
                )
            """)

    def _write_sqlite(self, results: List[KPIResult]):
        import sqlite3
        rows = []
        for r in results:
            comparisons_json = json.dumps({
                k: {
                    "previous_value": v.previous_value,
                    "change_absolute": v.change_absolute,
                    "change_pct": v.change_pct,
                    "direction": v.direction,
                }
                for k, v in r.comparisons.items()
            })
            rows.append((
                r.name, r.label, r.value, r.unit,
                r.period_start.isoformat(), r.period_end.isoformat(),
                r.alert_status, r.computed_at.isoformat(),
                r.query_duration_ms, comparisons_json,
            ))
        with sqlite3.connect(self.path) as conn:
            conn.executemany(
                "INSERT INTO kpi_audit "
                "(name, label, value, unit, period_start, period_end, "
                "alert_status, computed_at, query_duration_ms, comparisons) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                rows,
            )
