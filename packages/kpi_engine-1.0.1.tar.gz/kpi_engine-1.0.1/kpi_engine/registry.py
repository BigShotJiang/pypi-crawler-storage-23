from typing import Dict, List, Optional

from .models import KPIDefinition


class KPIRegistry:
    def __init__(self):
        self._kpis: Dict[str, KPIDefinition] = {}

    def register(self, kpi: KPIDefinition):
        self._validate(kpi)
        self._kpis[kpi.name] = kpi

    def get(self, name: str) -> Optional[KPIDefinition]:
        return self._kpis.get(name)

    def all(self) -> List[KPIDefinition]:
        return list(self._kpis.values())

    def topological_order(self) -> List[KPIDefinition]:
        """Return KPIs in execution order: base KPIs first, then derived."""
        base = [k for k in self._kpis.values() if k.source != "derived"]
        derived = [k for k in self._kpis.values() if k.source == "derived"]
        return base + derived

    def _validate(self, kpi: KPIDefinition):
        if not kpi.name:
            raise ValueError("KPI must have a name")
        if kpi.source not in ("sql", "dataframe", "derived"):
            raise ValueError(f"Invalid source: '{kpi.source}'. Must be sql, dataframe, or derived.")
        if kpi.source == "sql" and not kpi.query:
            raise ValueError(f"SQL KPI '{kpi.name}' must have a query")
        if kpi.source == "derived" and not kpi.expression:
            raise ValueError(f"Derived KPI '{kpi.name}' must have an expression")
