import yaml
from typing import Dict, List, Optional

import pandas as pd

from .models import Alert, KPIDefinition, KPIResult
from .period import resolve_period
from .backends.sql import SQLBackend
from .backends.dataframe import DataFrameBackend
from .comparator import PeriodComparator
from .alerts.evaluator import AlertEvaluator
from .alerts.dispatcher import AlertDispatcher

_SEVERITY_RANK = {"ok": 0, "info": 1, "warning": 2, "critical": 3}


class KPIEngine:
    def __init__(
        self,
        kpis: List[KPIDefinition],
        connection=None,
        dataframes: Dict[str, pd.DataFrame] = None,
        alert_channels: list = None,
        audit_log: str = None,
    ):
        self.kpis = {k.name: k for k in kpis}
        self._sql_backend = SQLBackend(connection) if connection else None
        self._df_backend = DataFrameBackend(dataframes or {})
        self._alert_evaluator = AlertEvaluator()
        self._dispatcher = AlertDispatcher(alert_channels or [])
        self._history: List[KPIResult] = []
        self._audit = None
        if audit_log:
            from .audit import AuditLog
            self._audit = AuditLog(audit_log)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self, period: str = "last_month") -> List[KPIResult]:
        """Compute all KPIs for a period and return the results."""
        resolved = resolve_period(period)
        results: List[KPIResult] = []
        computed_values: Dict[str, float] = {}

        base_kpis = [k for k in self.kpis.values() if k.source != "derived"]
        derived_kpis = [k for k in self.kpis.values() if k.source == "derived"]

        for kpi in base_kpis + derived_kpis:
            result = self._compute_kpi(kpi, resolved, computed_values)
            computed_values[kpi.name] = result.value
            results.append(result)
            self._history.append(result)

        if self._audit:
            self._audit.write(results)

        return results

    def run_kpi(self, name: str, period: str = "last_month") -> KPIResult:
        """Compute a single KPI by name."""
        if name not in self.kpis:
            raise ValueError(f"KPI '{name}' not found")
        resolved = resolve_period(period)
        computed_values = {r.name: r.value for r in self._history}
        return self._compute_kpi(self.kpis[name], resolved, computed_values)

    def history(self, name: str, n: int = 10) -> List[KPIResult]:
        """Return the last n computed results for a named KPI."""
        return [r for r in self._history if r.name == name][-n:]

    def schedule(self, cron: str, period_fn, callback=None):
        """Schedule recurring runs. Returns a KPIScheduler you can .stop()."""
        from .scheduler import KPIScheduler
        scheduler = KPIScheduler(self)
        scheduler.schedule(cron, period_fn, callback)
        return scheduler

    def serve(self, port: int = 8000, host: str = "0.0.0.0"):
        """Start the built-in FastAPI REST server (blocking)."""
        try:
            import uvicorn
            from .server import create_app
            uvicorn.run(create_app(self), host=host, port=port)
        except ImportError:
            raise ImportError("fastapi and uvicorn are required. pip install fastapi uvicorn")

    # ------------------------------------------------------------------
    # Class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, path: str, connection=None, dataframes=None) -> "KPIEngine":
        with open(path) as f:
            config = yaml.safe_load(f)
        kpis = [
            KPIDefinition(
                alerts=[Alert(**a) for a in k.pop("alerts", [])],
                **k,
            )
            for k in config["kpis"]
        ]
        return cls(kpis=kpis, connection=connection, dataframes=dataframes)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_kpi(self, kpi: KPIDefinition, period, computed_values: dict) -> KPIResult:
        if kpi.source == "sql" and self._sql_backend:
            value, duration = self._sql_backend.compute(kpi, period)
        elif kpi.source == "derived":
            value = self._eval_expression(kpi.expression, computed_values)
            duration = 0.0
        else:
            value, duration = self._df_backend.compute(kpi, period)

        backend = self._sql_backend if kpi.source == "sql" else self._df_backend
        comparisons = PeriodComparator(backend).compare(kpi, value, period) if kpi.compare else {}

        alert_results = self._alert_evaluator.evaluate(value, kpi.alerts)
        triggered = [a for a in alert_results if a.triggered]
        alert_status = max(
            (a.severity for a in triggered),
            default="ok",
            key=lambda s: _SEVERITY_RANK.get(s, 0),
        )

        if triggered:
            self._dispatcher.dispatch(kpi, value, triggered)

        return KPIResult(
            name=kpi.name,
            label=kpi.label,
            value=round(value, 4),
            unit=kpi.unit,
            period_start=period.start,
            period_end=period.end,
            comparisons=comparisons,
            alert_status=alert_status,
            alerts_triggered=triggered,
            query_duration_ms=duration,
        )

    @staticmethod
    def _eval_expression(expression: str, computed: dict) -> float:
        try:
            return float(eval(expression, {"__builtins__": {}}, computed))
        except Exception:
            return 0.0
