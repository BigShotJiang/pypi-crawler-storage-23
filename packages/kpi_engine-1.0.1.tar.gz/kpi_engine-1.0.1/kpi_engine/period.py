from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dataclasses import dataclass


@dataclass
class Period:
    start: datetime
    end: datetime
    label: str

    def shift(self, comparison: str) -> "Period":
        """Return the equivalent prior period for a given comparison type."""
        if comparison == "DoD":
            delta = timedelta(days=1)
        elif comparison == "WoW":
            delta = timedelta(weeks=1)
        elif comparison == "MoM":
            delta = relativedelta(months=1)
        elif comparison == "QoQ":
            delta = relativedelta(months=3)
        elif comparison == "YoY":
            delta = relativedelta(years=1)
        else:
            raise ValueError(f"Unknown comparison type: {comparison}")
        return Period(start=self.start - delta, end=self.end - delta, label=f"prior_{comparison}")


def resolve_period(period_str: str) -> Period:
    now = datetime.utcnow()

    if period_str == "yesterday":
        d = now.date() - timedelta(days=1)
        start = datetime.combine(d, datetime.min.time())
        return Period(start=start, end=start + timedelta(days=1), label="yesterday")

    if period_str == "last_week":
        monday = now - timedelta(days=now.weekday() + 7)
        start = monday.replace(hour=0, minute=0, second=0, microsecond=0)
        return Period(start=start, end=start + timedelta(weeks=1), label="last_week")

    if period_str == "last_month":
        first = now.replace(day=1) - relativedelta(months=1)
        end = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        return Period(start=first.replace(hour=0, minute=0, second=0, microsecond=0),
                      end=end, label="last_month")

    if period_str == "last_quarter":
        current_q = (now.month - 1) // 3 + 1
        prev_q = current_q - 1 if current_q > 1 else 4
        year = now.year if current_q > 1 else now.year - 1
        start_month = (prev_q - 1) * 3 + 1
        start = datetime(year, start_month, 1)
        return Period(start=start, end=start + relativedelta(months=3), label="last_quarter")

    # "2024-Q3" format
    if "-Q" in period_str:
        year, qnum = period_str.split("-Q")
        month_start = (int(qnum) - 1) * 3 + 1
        start = datetime(int(year), month_start, 1)
        return Period(start=start, end=start + relativedelta(months=3), label=period_str)

    # "2024-11" format
    if len(period_str) == 7 and "-" in period_str:
        start = datetime.strptime(period_str, "%Y-%m")
        return Period(start=start, end=start + relativedelta(months=1), label=period_str)

    raise ValueError(f"Cannot parse period: '{period_str}'")
