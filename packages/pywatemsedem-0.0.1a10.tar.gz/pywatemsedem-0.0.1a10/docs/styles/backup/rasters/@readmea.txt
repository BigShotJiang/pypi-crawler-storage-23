uparea: van dov
sediout: op basis van analyse vlaandeeren
perceelskaart: petra
