=========
Changelog
=========

0.0.1
******
- First release of package
- compatible with `watem_sedem 5.0.3 <https://github.com/watem-sedem/watem-sedem/releases/tag/5.0.3>`_
- compatible with `saga 9.3.1 <https://sourceforge.net/projects/saga-gis/files/SAGA%20-%209/SAGA%20-%209.3.1/>`_
  with `WATEM tools <https://github.com/DOV-Vlaanderen/saga-watem/releases/tag/2025.6.11>`_
