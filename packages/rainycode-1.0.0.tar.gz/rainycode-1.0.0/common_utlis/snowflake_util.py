import os
import time
import socket
import uuid
import hashlib


class SnowflakeIDGenerator:
    """
    雪花算法ID生成器
    
    雪花ID结构：
    0 - 0000000000 0000000000 0000000000 0000000000 0 - 00000 - 00000 - 000000000000
    1位符号位 - 41位时间戳 - 5位数据中心ID - 5位机器ID - 12位序列号
    """
    
    def __init__(self, datacenter_id: int = 0, machine_id: int = 0):
        """
        初始化雪花ID生成器
        
        Args:
            datacenter_id: 数据中心ID，范围0-31
            machine_id: 机器ID，范围0-31
        """
        # 起始时间戳：2025-07-01 00:00:00
        self.twepoch = 1751328000000
        
        # 各部分占位长度
        self.datacenter_id_bits = 5  # 数据中心ID长度
        self.machine_id_bits = 5     # 机器ID长度
        self.sequence_bits = 12       # 序列号长度
        
        # 各部分最大值
        self.max_datacenter_id = -1 ^ (-1 << self.datacenter_id_bits)  # 31
        self.max_machine_id = -1 ^ (-1 << self.machine_id_bits)        # 31
        self.max_sequence = -1 ^ (-1 << self.sequence_bits)            # 4095
        
        # 各部分偏移量
        self.machine_id_shift = self.sequence_bits
        self.datacenter_id_shift = self.sequence_bits + self.machine_id_bits
        self.timestamp_shift = self.sequence_bits + self.machine_id_bits + self.datacenter_id_bits
        
        # 参数检查
        if datacenter_id > self.max_datacenter_id or datacenter_id < 0:
            raise ValueError(f"数据中心ID不能大于{self.max_datacenter_id}或小于0")
        if machine_id > self.max_machine_id or machine_id < 0:
            raise ValueError(f"机器ID不能大于{self.max_machine_id}或小于0")
            
        self.datacenter_id = datacenter_id
        self.machine_id = machine_id
        self.sequence = 0
        self.last_timestamp = -1
        
    def _gen_timestamp(self) -> int:
        """
        生成当前时间戳
        
        Returns:
            当前时间戳（毫秒）
        """
        return int(time.time() * 1000)
    
    def _til_next_millis(self, last_timestamp: int) -> int:
        """
        等待到下一个毫秒
        
        Args:
            last_timestamp: 上一个时间戳
            
        Returns:
            下一个时间戳
        """
        timestamp = self._gen_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self._gen_timestamp()
        return timestamp
    
    def get_id(self) -> int:
        """
        生成下一个ID
        
        Returns:
            雪花算法生成的ID
        
        Raises:
            RuntimeError: 当时钟回拨时抛出异常
        """
        timestamp = self._gen_timestamp()
        
        # 时钟回拨检查
        if timestamp < self.last_timestamp:
            raise RuntimeError(f"时钟回拨，拒绝生成ID，上一时间戳: {self.last_timestamp}, 当前时间戳: {timestamp}")
            
        # 同一毫秒内
        if timestamp == self.last_timestamp:
            self.sequence = (self.sequence + 1) & self.max_sequence
            # 同一毫秒内序列号用完
            if self.sequence == 0:
                timestamp = self._til_next_millis(self.last_timestamp)
        else:
            # 不同毫秒，序列号重置
            self.sequence = 0
            
        self.last_timestamp = timestamp
        
        # 生成ID
        return ((timestamp - self.twepoch) << self.timestamp_shift) | \
               (self.datacenter_id << self.datacenter_id_shift) | \
               (self.machine_id << self.machine_id_shift) | \
               self.sequence


def get_machine_info() -> tuple[int, int]:
    """
    获取机器信息，用于生成数据中心ID和机器ID
    
    使用多种机器特征信息生成稳定且唯一的ID：
    - 主机名
    - 完整IP地址
    - 完整MAC地址
    - 进程ID
    
    Returns:
        Tuple[int, int]: (datacenter_id, machine_id)
    """
    try:
        # 收集多种机器特征信息
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        mac = uuid.UUID(int=uuid.getnode()).hex
        pid = os.getpid()
        
        # 为数据中心ID创建特征字符串
        # 使用主机名和IP地址
        datacenter_feature = f"{hostname}:{ip}"
        datacenter_hash = int(hashlib.md5(datacenter_feature.encode()).hexdigest(), 16)
        datacenter_id = datacenter_hash % 32  # 确保在0-31范围内
        
        # 为机器ID创建特征字符串
        # 使用MAC地址和进程ID
        machine_feature = f"{mac}:{pid}"
        machine_hash = int(hashlib.md5(machine_feature.encode()).hexdigest(), 16)
        machine_id = machine_hash % 32  # 确保在0-31范围内
        
        return datacenter_id, machine_id
    except Exception as e:
        raise RuntimeError(f"获取机器信息失败: {e}")


# 单例模式，默认实例
_default_snowflake_generator: SnowflakeIDGenerator | None = None


def get_snowflake_id(datacenter_id: int | None = None, machine_id: int | None = None) -> int:
    """
    获取雪花算法生成的ID
    
    Args:
        datacenter_id: 数据中心ID，范围0-31，默认自动获取
        machine_id: 机器ID，范围0-31，默认自动获取
        
    Returns:
        雪花算法生成的ID
    """
    global _default_snowflake_generator
    
    if _default_snowflake_generator is None:
        # 如果未指定datacenter_id或machine_id，则自动获取
        if datacenter_id is None or machine_id is None:
            auto_datacenter_id, auto_machine_id = get_machine_info()
            datacenter_id = datacenter_id if datacenter_id is not None else auto_datacenter_id
            machine_id = machine_id if machine_id is not None else auto_machine_id
            
        _default_snowflake_generator = SnowflakeIDGenerator(datacenter_id, machine_id)
        
    return _default_snowflake_generator.get_id()


def test_snowflake_id():
    """
    测试雪花算法ID生成
    
    Returns:
        dict: 测试结果，包含生成的ID和相关信息
    """
    # 获取机器信息
    datacenter_id, machine_id = get_machine_info()
    
    # 生成ID
    snowflake_id = get_snowflake_id()
    
    # 返回测试结果
    return {
        "snowflake_id": snowflake_id,
        "datacenter_id": datacenter_id,
        "machine_id": machine_id,
        "binary": bin(snowflake_id),
        "hex": hex(snowflake_id),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    }


if __name__ == '__main__':
    result = test_snowflake_id()
    print(result)