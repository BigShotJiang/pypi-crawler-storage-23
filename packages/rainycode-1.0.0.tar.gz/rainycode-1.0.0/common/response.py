from pydantic import BaseModel, Field
from starlette.background import BackgroundTask
from starlette.responses import ContentStream, JSONResponse, StreamingResponse


class ResponseSchema(BaseModel):
    """响应模型"""
    data: object | None = Field(default=None, description="响应数据")
    msg: str | None = Field(description="响应消息")
    code: int = Field(description="业务状态码")


class SuccessReturn(JSONResponse):
    """成功响应类"""
    def __init__(
            self,
            data: object | None = None,
            msg: str | None  = None,
            code: int = 0,
            status_code: int = 200
    ) -> None:
        content = ResponseSchema(
            code=code,
            msg=msg,
            data=data,
        ).model_dump()
        super().__init__(content=content, status_code=status_code)


class ErrorReturn(JSONResponse):
    """错误响应类"""
    def __init__(
            self,
            data: object | None = None,
            msg: str | None = None,
            code: int = -1,
            status_code: int = 500,
    ) -> None:
        content = ResponseSchema(
            code=code,
            msg=msg,
            data=data,
        ).model_dump()
        super().__init__(content=content, status_code=status_code)


class StreamReturn(StreamingResponse):
    """流式响应类"""
    def __init__(
            self,
            data: ContentStream,
            status_code: int = 200,
            headers: dict[str, str] | None = None,
            media_type: str | None = None,
            background: BackgroundTask | None = None
    ) -> None:
        super().__init__(
            content=data, 
            status_code=status_code, 
            media_type=media_type, # 文件类型
            headers=headers, # 文件名
            background=background # 文件大小
        )
