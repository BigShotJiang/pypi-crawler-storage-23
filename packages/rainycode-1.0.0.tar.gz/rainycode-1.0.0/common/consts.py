REDIS_PREFIX_REFRESH_TOKEN: str = "auth:refresh:"
REDIS_PREFIX_USER_INFO: str = "user:info:"
REDIS_PREFIX_BLOCKLIST: str = "auth:blocklist:"
