from common.logging import logger
from typing import cast
from common.response import ErrorReturn
from fastapi import HTTPException, Request, status
from fastapi.exceptions import RequestValidationError, ResponseValidationError
from starlette.responses import JSONResponse


class CustomException(Exception):
    """自定义异常"""
    def __init__(
        self, 
        msg: str | None = None,
        code: int = 0, 
        data: object | None = None,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR
    ) -> None:
        super().__init__(msg)
        self.msg = msg
        self.code = code
        self.data = data
        self.status_code = status_code

    def __str__(self) -> str:
        return f'{self.msg}'

async def CustomExceptionHandler(request: Request, exc: CustomException) -> JSONResponse:
    """自定义异常处理器"""
    exc = cast(CustomException, exc)
    logger.error(f"请求地址: {request.url}, 错误信息: {exc.msg}, 错误详情: {exc.data}")
    return ErrorReturn(data=exc.data, msg=exc.msg, code=exc.code, status_code=exc.status_code)


async def HttpExceptionHandler(request: Request, exc: HTTPException) -> JSONResponse:
    """HTTP异常处理器"""
    logger.error(f"请求地址: {request.url}, 错误详情: {exc.detail}")
    return ErrorReturn(data=None, msg=exc.detail)

async def RequestValidationHandle(request: Request, exc: RequestValidationError):
    """请求参数验证异常处理器"""
    error_mapping = {
        "Field required": "请求失败，缺少必填项！",
        "value is not a valid list": "类型错误，提交参数应该为列表！", 
        "value is not a valid int": "类型错误，提交参数应该为整数！",
        "value could not be parsed to a boolean": "类型错误，提交参数应该为布尔值！",
        "Input should be a valid list": "类型错误，输入应该是一个有效的列表！"
    }
    msg = error_mapping.get(exc.errors()[0].get('msg'), exc.errors()[0].get('msg'))
    logger.error(f"请求地址: {request.url}, 错误信息: {msg}, 错误详情: {exc}")
    return ErrorReturn(data=None, msg=msg, status_code=status.HTTP_422_UNPROCESSABLE_ENTITY)


async def ResponseValidationHandle(request: Request, exc: ResponseValidationError) -> JSONResponse:
    """响应参数验证异常处理器"""
    logger.error(f"请求地址: {request.url}, 错误详情: {exc}")
    return ErrorReturn(data=exc.body, msg=str(exc), status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


async def ValueExceptionHandler(request: Request, exc: ValueError) -> JSONResponse:
    """值异常处理器"""
    logger.error(f"请求地址: {request.url}, 错误详情: {exc}")
    return ErrorReturn(data=None, msg=str(exc))


async def AllExceptionHandler(request: Request, exc: Exception) -> JSONResponse:
    """全局异常处理器"""
    logger.error(f"请求地址: {request.url}, 错误详情: {exc}")
    return ErrorReturn(data=str(exc), msg='服务器内部错误', status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)
