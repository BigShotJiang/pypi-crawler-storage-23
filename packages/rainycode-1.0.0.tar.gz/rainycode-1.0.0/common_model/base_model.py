import uuid
from collections.abc import Iterable
from typing_extensions import Self
from typing import Optional, Any
from tortoise import fields, BaseDBAsyncClient
from tortoise.expressions import Q
from tortoise.queryset import BulkCreateQuery, QuerySet, QuerySetSingle
from common_utlis.snowflake_util import get_snowflake_id
from core.databases.aiodb import MySQLUtils


class BaseModel(MySQLUtils):
    
    @classmethod
    async def create(
            cls,
            using_db: Optional[BaseDBAsyncClient] = None,
            **kwargs: Any
    ) -> Self:
        if not kwargs.get('id', 0) and 'id' in cls._meta.fields:
            # uuid生成id
            if kwargs.get('id_uuid', False):
                kwargs['id'] = str(uuid.uuid4()).replace('-', '')
            # 雪花算法生成id
            if kwargs.get('id_snowflake', False):
                kwargs['id'] = get_snowflake_id()
        return await super().create(using_db=using_db, **kwargs)

    @classmethod
    def get(
        cls,
        *args: Q, 
        using_db: BaseDBAsyncClient | None = None, 
        **kwargs: Any
    ) -> QuerySetSingle[Self]:
        if 'deleted' in cls._meta.fields and kwargs.get('deleted', None) is None:
            kwargs['deleted'] = False
        return super().get(*args, using_db=using_db, **kwargs)

    @classmethod
    def filter(
        cls, 
        *args: Q, 
        **kwargs: Any
    ) -> QuerySet[Self]:
        if 'deleted' in cls._meta.fields and kwargs.get('deleted', None) is None:
            kwargs['deleted'] = False
        return cls._meta.manager.get_queryset().filter(*args, **kwargs)

    @classmethod
    def bulk_create(
            cls,
            objects: Iterable[Self],
            batch_size: Optional[int] = None,
            ignore_conflicts: bool = False,
            update_fields: Optional[Iterable[str]] = None,
            on_conflict: Optional[Iterable[str]] = None,
            using_db: Optional[BaseDBAsyncClient] = None,
            **kwargs: Any
    ) -> "BulkCreateQuery[Self]":
        if 'id' in cls._meta.fields:
            for obj in objects:
                if not getattr(obj, 'id', 0):
                    # uuid生成id
                    if kwargs.get('id_uuid', False):
                        obj.id = str(uuid.uuid4()).replace('-', '')
                    # 雪花算法生成id
                    if kwargs.get('id_snowflake', False):
                        obj.id = get_snowflake_id()

        params = {
            "objects": objects,
            "batch_size": batch_size,
            "ignore_conflicts": ignore_conflicts,
            "update_fields": update_fields,
            "on_conflict": on_conflict,
            "using_db": using_db,
        }    
        return super().bulk_create(**params)

    async def save(
            self,
            using_db: Optional[BaseDBAsyncClient] = None,
            update_fields: Optional[Iterable[str]] = None,
            force_create: bool = False,
            force_update: bool = False,
            **kwargs: Any
    ) -> None:
        if not getattr(self, 'id', 0) and kwargs.get('uuid', False)  and 'id' in self._meta.fields:
            setattr(self, 'id', str(uuid.uuid4()).replace('-', ''))
        return await super().save(using_db=using_db, update_fields=update_fields, force_create=force_create,
                                  force_update=force_update)


class CreateModel(BaseModel):
    deleted = fields.BooleanField(default=False, description='是否已删除')
    create_time = fields.DatetimeField(auto_now_add=True, description='创建时间')
    creator = fields.CharField(max_length=50, null=True, description="创建人")

    class Meta:
        abstract = True


class UpdateModel(BaseModel):
    deleted = fields.BooleanField(default=False, description='是否已删除')
    create_time = fields.DatetimeField(auto_now_add=True, description='创建时间')
    update_time = fields.DatetimeField(auto_now=True, description='更新时间')
    creator = fields.CharField(max_length=50, null=True, description="创建人")
    updater = fields.CharField(max_length=50, null=True, description="更新人")

    class Meta:
        abstract = True


class DeleteModel(BaseModel):
    deleted = fields.BooleanField(default=False, description="是否已删除")
    create_time = fields.DatetimeField(auto_now_add=True, description="创建时间")
    update_time = fields.DatetimeField(auto_now=True, description="更新时间")


# class CreateRelatedMeta(type(Model)):
#     """元类：更新外键字段，解决用户related_name重复问题"""
#     def __new__(cls, name: str, bases: tuple, attrs: dict):
#         if name == 'UpdateModel':
#             return super().__new__(cls, name, bases, attrs)

#         creator_related_name = f"{name.lower()}_creator"
#         attrs["creator"] = fields.ForeignKeyField(
#             'main.SystemUserModel',
#             null=True,
#             related_name=creator_related_name,
#             db_constraint=False,
#             description="创建人"
#         )

#         new_class = super().__new__(cls, name, bases, attrs)
#         return new_class


# class CreateModel(BaseModel, metaclass=CreateRelatedMeta):
#     deleted = fields.BooleanField(default=False, description='是否已删除')
#     create_time = fields.DatetimeField(auto_now_add=True, description='创建时间')
#     creator = fields.ForeignKeyField(
#         'main.SystemUserModel',
#         null=True,
#         db_constraint=False,
#         description="创建人"
#     )

#     class Meta:
#         abstract = True


# class UpdateRelatedMeta(type(Model)):
#     """元类：更新外键字段，解决用户related_name重复问题"""
#     def __new__(cls, name: str, bases: tuple, attrs: dict):
#         if name == 'UpdateModel':
#             return super().__new__(cls, name, bases, attrs)

#         creator_related_name = f"{name.lower()}_creator"
#         attrs["creator"] = fields.ForeignKeyField(
#             'main.SystemUserModel',
#             null=True,
#             related_name=creator_related_name,
#             db_constraint=False,
#             description="创建人"
#         )

#         updater_related_name = f"{name.lower()}_updater"
#         attrs["updater"] = fields.ForeignKeyField(
#             'main.SystemUserModel',
#             null=True,
#             related_name=updater_related_name,
#             db_constraint=False,
#             description="更新人"
#         )

#         new_class = super().__new__(cls, name, bases, attrs)
#         return new_class

# class UpdateModel(BaseModel, metaclass=UpdateRelatedMeta):
#     deleted = fields.BooleanField(default=False, description='是否已删除')
#     create_time = fields.DatetimeField(auto_now_add=True, description='创建时间')
#     update_time = fields.DatetimeField(auto_now=True, description='更新时间')
#     creator = fields.ForeignKeyField(
#         'main.SystemUserModel',
#         null=True,
#         db_constraint=False,
#         description="创建人"
#     )

#     updater = fields.ForeignKeyField(
#         'main.SystemUserModel',
#         null=True,
#         db_constraint=False,
#         description="更新人"
#     )

#     class Meta:
#         abstract = True
