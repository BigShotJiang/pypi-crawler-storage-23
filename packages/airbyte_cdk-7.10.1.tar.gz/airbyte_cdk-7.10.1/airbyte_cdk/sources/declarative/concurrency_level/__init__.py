#
# Copyright (c) 2024 Airbyte, Inc., all rights reserved.
#

from airbyte_cdk.sources.declarative.concurrency_level.concurrency_level import ConcurrencyLevel

__all__ = ["ConcurrencyLevel"]
