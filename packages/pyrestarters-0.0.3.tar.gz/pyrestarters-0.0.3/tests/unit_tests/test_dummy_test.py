"""
Dummy unit tests until some get written
"""
def test_nothing() -> None:
    """
    an empty test to keep the CI happy as no tests is a error
    """
