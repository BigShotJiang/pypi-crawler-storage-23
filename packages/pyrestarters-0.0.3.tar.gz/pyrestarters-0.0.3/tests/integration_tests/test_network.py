"""
pyRestarters is a python wrapper for the restarters.net API
Copyright (C) 2026

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

This module test the Network API which gives access to all the Network ID and names
"""
from collections.abc import Iterator
import pytest

from pyRestarters import Networks as PyRestartersNetworks

@pytest.fixture(scope='session', name='pyrestarters_networks')
def pyrestarters_networks_implementation() -> Iterator[PyRestartersNetworks]:
    """
    A fixture that make a connection to the real restarters.net without the API key
    """
    yield PyRestartersNetworks()


@pytest.fixture(scope='session', name='pyrestarters_networks_test_server')
def pyrestarters_networks_test_server_implementation() -> Iterator[PyRestartersNetworks]:
    """
    A fixture that make a connection to the real restarters.net without the API key
    """
    yield PyRestartersNetworks(test_server=True)

def test_network_names(pyrestarters_networks: PyRestartersNetworks) -> None:
    """
    test the download of the group names and tags
    """
    assert isinstance(pyrestarters_networks, PyRestartersNetworks)
    networks = pyrestarters_networks.networks
    # network ID one is held by default Network
    assert networks[1].name == 'Default Network'

@pytest.mark.skip('test server does not work')
def test_network_names_test_server(pyrestarters_networks_test_server:PyRestartersNetworks) -> None:
    """
    test the download of the group names and tags on the test server
    """
    assert isinstance(pyrestarters_networks_test_server, PyRestartersNetworks)
    networks = pyrestarters_networks_test_server.networks
    # network ID one is held by default Network
    assert networks[1].name == 'Default Network'
