__version__ = "74.20260219.post3"
GIT_REF = "b415b53"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/b415b53"