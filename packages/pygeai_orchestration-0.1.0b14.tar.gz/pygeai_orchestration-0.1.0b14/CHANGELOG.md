# Changelog

All notable changes to PyGEAI-Orchestration will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- **CLI Pattern Commands**: Unified CLI interface for all orchestration patterns
  - `geai-orch execute-pattern` (aliases: `xp`, `pattern`) for executing patterns
  - Support for all 5 patterns: reflection, react, planning, tool-use, multi-agent
  - Pattern-specific options:
    - Reflection: `-i/--iterations` for refinement iterations
    - ReAct: `--max-steps` for reasoning steps
    - Planning: Single-shot execution
    - Tool Use: `--tools` for comma-separated tool names, `--max-iterations`
    - Multi-Agent: `-c/--config` for JSON configuration file
  - Common options: `-m/--model`, `-t/--task`, `--temperature`, `--max-tokens`, `--system-prompt`, `-o/--output`
  - `--verbose` flag (from parent framework) for execution metadata
  - JSON output format with success, result, iterations, and optional metadata
- **CLI Tool Management**: Commands for discovering and listing available tools
  - `geai-orch tools list` - List all available tools by category
  - Tool categories: data_tools, math_tools, system_tools, web_tools, utilities, geai_tools
  - 42 built-in tools across 8 categories
- **CLI Plugin System**: Commands for managing custom pattern plugins
  - `geai-orch plugins list` - List installed pattern plugins
  - `geai-orch plugins install` - Install custom pattern plugins
  - Automatic discovery of custom patterns from plugin directories
- **Comprehensive Documentation Updates**:
  - CLI Quick Start guide in quickstart.rst
  - Detailed CLI usage examples for all 5 patterns in patterns.rst
  - Real-world CLI workflow examples in examples.rst
  - CLI tool usage guide in tools.rst
  - Multi-agent JSON configuration format examples
  - When to use CLI vs Python API guidance
  - Complete CLI options reference
- **Unit and Integration Tests for CLI**:
  - Pattern command parsing tests
  - Pattern execution tests (reflection, react, planning, tool-use, multi-agent)
  - Helper function tests (agent creation, tool loading, output formatting)
  - Multi-agent config loading tests
  - Verbose output tests
  - Docker-based CLI integration tests
- Initial project structure and configuration
- Core base classes for agents, orchestrators, and patterns
- CLI framework with `geai-orch` command
- Reflection pattern for iterative improvement
- Tool Use pattern for function calling
- ReAct pattern for reasoning and acting
- Planning pattern for multi-step execution
- Multi-Agent pattern for collaborative workflows
- Comprehensive test suite with unit and integration tests
- Documentation and examples for all patterns
- GitHub Actions CI/CD workflows
- 9 working code snippets demonstrating all patterns:
  - `reflection_explanation.py` - Iterative explanation improvement
  - `reflection_code_review.py` - Code review with self-critique
  - `react_research.py` - Structured research tasks
  - `react_problem_solving.py` - Step-by-step problem solving
  - `planning_project.py` - Project planning and breakdown
  - `planning_analysis.py` - Data analysis planning
  - `tool_use_calculator.py` - Mathematical operations with tools
  - `tool_use_data_processing.py` - Data validation and transformation
  - `multi_agent_collaboration.py` - Collaborative multi-agent workflow

### Changed
- **CLI Command Structure**: Refactored CLI to use parent framework's `--verbose` flag
  - Replaced custom `--show-metadata` with standard `--verbose` / `-v` flag
  - Consistent with PyGEAI parent framework conventions
  - All CLI commands now properly respect verbose mode for detailed output
- **CLI Command Organization**: Improved command structure and help system
  - Added `help` and `version` command aliases
  - Renamed `plugin-mgmt` → `plugins` and `tool-mgmt` → `tools` for consistency
  - Centralized help text in `pygeai_orchestration/cli/texts/help.py`
  - Better command discovery and error messages
- **Documentation**: Comprehensive CLI documentation updates
  - Updated all 9 documentation files with CLI usage examples
  - Fixed version command syntax: `geai-orch version` (not `--version`)
  - Added CLI vs Python API guidance throughout
  - Verified all code examples work correctly
  - Added real-world workflow examples
- **BREAKING**: Refactored entire import system to use absolute imports only
  - All imports now use full module paths: `from pygeai_orchestration.core.base import ...`
  - Removed all relative imports (`.module` style)
- **BREAKING**: Removed `get_logger()` and `OrchestrationLogger` from public API
  - All modules now use standard `logging.getLogger("pygeai_orchestration")`
  - Logging disabled by default with `NullHandler` (follows PyGEAI pattern)
  - Users can enable logging by configuring the `"pygeai_orchestration"` logger
- **BREAKING**: Renamed all snippet files from `*_snippet.py` to `<pattern>_<topic>.py` format
  - More descriptive naming that indicates pattern and use case
  - Example: `reflection_snippet.py` → `reflection_explanation.py`
- Updated `GEAIAgent` to use actual PyGEAI Session and ChatManager APIs
  - Proper integration with PyGEAI chat completion
  - Correct credential loading from `~/.geai/credentials`
  - Support for provider-prefixed model names (e.g., `openai/gpt-4o-mini`)
- Tool system improvements:
  - `BaseTool` subclasses must implement `validate_parameters()` method
  - `ToolConfig` uses `parameters_schema` field (not `parameters`)
  - Clear ToolCategory enum values: SEARCH, COMPUTATION, DATA_ACCESS, COMMUNICATION, CUSTOM
- All pattern implementations updated to use absolute imports and standard logging

### Fixed
- **CLI Pattern Commands**: Fixed pattern execution and option parsing
  - Corrected verbose flag handling across all pattern commands
  - Fixed multi-agent config loading to properly parse JSON files
  - Fixed tool loading from comma-separated names
  - Improved error messages for missing required options
- **CLI Tests**: Updated all CLI tests to use `--verbose` instead of `--show-metadata`
  - Pattern command tests updated
  - Helper function tests updated
  - Docker integration tests updated
- **Documentation**: Fixed version command documentation
  - Changed `geai-orch --version` to `geai-orch version` in quickstart.rst
  - Verified all CLI examples work with actual execution
  - Tested all Python code examples from documentation
- PyGEAI integration now uses correct Session and ChatManager APIs
- Removed incorrect assumptions about `Session.agents` and `Session.chats` attributes
- Fixed message formatting to use proper PyGEAI `ChatMessageList` and `ChatMessage` models
- Fixed credential loading to delegate to PyGEAI's configuration system
- Corrected model naming to include provider prefix as required by PyGEAI

### Removed
- **BREAKING**: Removed PyGEAI availability checks
  - PyGEAI is now a required dependency
  - No fallback or mock implementations
- Removed `get_logger()` utility function from `pygeai_orchestration.core.utils`
- Removed `OrchestrationLogger` singleton class
- Removed all relative import statements across the codebase

## [0.1.0b1] - 2026-02-05

### Added
- Initial beta release of PyGEAI-Orchestration
- Foundation for agentic AI orchestration patterns
- Integration with PyGEAI SDK
- Basic project structure and tooling
