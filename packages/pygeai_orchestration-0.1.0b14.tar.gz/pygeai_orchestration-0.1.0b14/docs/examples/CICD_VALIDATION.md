# CI/CD Documentation Validation

This document describes the automated validation system for documentation examples in PyGEAI Orchestration.

## Overview

Every code example in the documentation is automatically tested to ensure it remains functional and accurate. This prevents documentation drift and ensures users can trust the examples.

## Workflow Details

### File Location
`.github/workflows/validate-docs-examples.yml`

### Trigger Conditions
The workflow runs on:
- **Push to `devel` branch** - Every commit triggers validation
- **Pull Request to `devel` branch** - PRs are validated before merge

### Scope
Validation is **isolated to the `devel` branch only**, as requested. This ensures:
- Development changes are validated
- Main branch deploys remain stable
- No unnecessary runs on other branches

## Workflow Steps

### 1. Environment Setup
- Checks out code
- Sets up Python 3.11
- Installs all dependencies
- Installs package in development mode

### 2. Run Example Tests
```bash
docs/examples/run_all_tests.sh
```

Executes all test files in `docs/examples/`:
- `test_basic_tool_usage.py`
- `test_json_parsing.py`
- `test_complete_workflow.py`
- `test_custom_calculator.py`

**Exit Code:** 0 if all pass, 1 if any fail

### 3. Build Documentation
```bash
cd docs && make html
```

Builds Sphinx documentation to ensure:
- RST files are valid
- Cross-references work
- No syntax errors

### 4. Check for Errors
Scans build output for ERROR messages (warnings are allowed).

### 5. Upload Artifacts
Uploads documentation build and logs for review, even if tests fail.

## Test Validation

### What Gets Tested

Each test file validates:
- **Code executes** without exceptions
- **Results are correct** (via assertions)
- **Output matches docs** (verified manually)
- **Tools work as documented**

### Current Test Coverage

| Test File | Documentation | Validates |
|-----------|---------------|-----------|
| `test_basic_tool_usage.py` | tools.rst | MathCalculatorTool basic usage |
| `test_json_parsing.py` | tools.rst | JSONParserTool with queries |
| `test_complete_workflow.py` | tools.rst | CSV + DataFrame workflow |
| `test_custom_calculator.py` | custom_tools.rst | Custom tool creation |

**Total Examples Tested:** 4  
**Pass Rate Required:** 100%

## Failure Handling

### When Tests Fail

The workflow **fails** if:
1. Any example test returns non-zero exit code
2. Any example raises an unhandled exception
3. Any assertion in a test fails
4. Sphinx build has ERROR messages

### Investigation Steps

1. **Check CI logs** - View full output in GitHub Actions
2. **Download artifacts** - Review built HTML and logs
3. **Reproduce locally** - Run failing test on your machine
4. **Identify root cause**:
   - API changed?
   - Documentation outdated?
   - Test incorrect?
   - Environment issue?

### Resolution

- **Fix the code** - If API broke the example
- **Update docs** - If example needs correction
- **Update test** - If test expectations wrong
- **Fix environment** - If CI configuration issue

## Environment Variables

### Currently Used
- `PYTHONPATH` - Set to workspace root

### Optional (Commented Out)
```yaml
# GEAI_API_KEY: ${{ secrets.GEAI_API_KEY }}
```

Uncomment if GEAI tools tests are added that require API access.

## Adding New Tests

When adding examples to documentation:

### 1. Create Test File
```bash
cd docs/examples
touch test_new_feature.py
```

### 2. Write Test
```python
"""
Test for new feature example from <doc>.rst
"""
import asyncio
from pygeai_orchestration.tools.builtin.new_tool import NewTool

async def main():
    # Code from documentation
    tool = NewTool()
    result = await tool.execute(param="value")
    
    assert result.success, f"Failed: {result.error}"
    assert result.result == expected, f"Expected {expected}, got {result.result}"
    print(f" New feature example validated")

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. Update Test Runner
Edit `run_all_tests.sh`:
```bash
run_test "test_new_feature.py"
```

### 4. Test Locally
```bash
./run_all_tests.sh
```

### 5. Commit
The CI will automatically run on push to `devel`.

## Monitoring

### GitHub Actions
View workflow runs in the Actions tab of your GitHub repository.

### Success Indicators
-  Green check mark on commit
- All steps pass
- "ALL TESTS PASSED!" in logs

### Failure Indicators
-  Red X on commit
- Failed step in workflow
- Error messages in logs

## Best Practices

### For Documentation Writers

1. **Test examples before committing**
   ```bash
   cd docs/examples
   ./run_all_tests.sh
   ```

2. **Keep examples simple** - Focus on clarity
3. **Use real data** - Not placeholders
4. **Show complete code** - No hidden imports
5. **Verify output** - Match what docs show

### For Developers

1. **Run tests after API changes**
   ```bash
   docs/examples/run_all_tests.sh
   ```

2. **Update docs with code** - Keep in sync
3. **Add tests for new features** - Document with examples
4. **Check CI before merging** - Ensure green build

### For Reviewers

1. **Check CI status** - Must be green
2. **Review test changes** - Verify correctness
3. **Validate examples** - Try them yourself
4. **Check documentation** - Read updated docs

## Troubleshooting

### Common Issues

#### Tests Pass Locally but Fail in CI

**Possible Causes:**
- Python version difference (CI uses 3.11)
- Missing environment variables
- Platform-specific code
- Network/filesystem differences

**Solution:**
- Match CI Python version locally
- Check workflow environment section
- Avoid platform-specific code in examples
- Mock external dependencies if needed

#### Sphinx Build Warnings

**Status:** Warnings are allowed, errors are not.

**Action:** Review warnings, fix if related to tools docs.

#### Timeout in CI

**Possible Causes:**
- Long-running example
- Network request hanging
- Infinite loop

**Solution:**
- Add timeouts to examples
- Mock slow operations
- Review example logic

## Maintenance

### Regular Tasks

- **Monthly:** Review all tests still pass
- **After releases:** Verify examples work with new version
- **When APIs change:** Update affected examples and tests

### Updating Workflow

Edit `.github/workflows/validate-docs-examples.yml`:
- Change Python version
- Add environment variables
- Modify validation steps
- Update artifact uploads

### Disabling Validation

To temporarily disable (not recommended):
```yaml
# Comment out the workflow trigger
# on:
#   push:
#     branches: [ devel ]
```

Or skip tests in a specific PR:
```
[skip ci]
```
in commit message.

## Metrics

### Current Status
- **Tests:** 4
- **Coverage:** 100% of documented examples
- **Pass Rate:** 100%
- **CI Integration:**  Active on `devel`

### Goals
- Keep pass rate at 100%
- Add tests for all new examples
- Maintain <1 minute test execution time
- Zero false failures

## Benefits

### For Users
-  Trust that examples work
-  Copy-paste ready code
-  Up-to-date documentation

### For Developers
-  Catch breaking changes early
-  Prevent documentation drift
-  Quality assurance automation

### For Project
-  Professional documentation
-  Reduced support burden
-  Better user experience

## Related Documentation

- **Test Files:** `docs/examples/*.py`
- **Test Runner:** `docs/examples/run_all_tests.sh`
- **Usage Guide:** `docs/examples/README.md`
- **Main Docs:** `docs/source/tools.rst`, `docs/source/custom_tools.rst`

## Support

For issues with CI/CD validation:
1. Check GitHub Actions logs
2. Run tests locally to reproduce
3. Review this documentation
4. Open an issue with details

---

**Last Updated:** 2026-02-05  
**Workflow Version:** 1.0  
**Status:**  Active on `devel` branch
