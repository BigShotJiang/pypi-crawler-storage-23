# Documentation Examples Tests

This directory contains **executable test files** that validate all code examples included in the PyGEAI Orchestration documentation.

## Purpose

Every code example in the documentation **must be functional**. These test files ensure:

1. **Code examples work** - All examples execute without errors
2. **Output is correct** - Results match documented expectations
3. **Examples stay in sync** - Changes to APIs don't break examples
4. **CI/CD validation** - Automated testing on every commit to `devel` branch

## Test Files

### From `tools.rst` (User Guide)

- **`test_basic_tool_usage.py`** - Basic tool instantiation and execution
  - Tests: MathCalculatorTool with add operation
  - Validates: Tool execution, result correctness, timing

- **`test_json_parsing.py`** - Working with data tools
  - Tests: JSONParserTool with queries
  - Validates: JSON parsing, nested path queries

- **`test_complete_workflow.py`** - Multi-step workflow example
  - Tests: CSVProcessorTool + DataFrameTool integration
  - Validates: CSV parsing, filtering, calculations

### From `custom_tools.rst` (Developer Guide)

- **`test_custom_calculator.py`** - Custom tool creation
  - Tests: Complete CalculatorTool implementation
  - Validates: Custom tool execution, parameter validation, metadata

## Running Tests

### Run All Tests

```bash
./run_all_tests.sh
```

### Run Individual Test

```bash
python3 test_basic_tool_usage.py
```

### From Project Root

```bash
cd /path/to/pygeai-orchestration
python3 docs/examples/test_basic_tool_usage.py
```

## Expected Output

```
=========================================
Running All Documentation Example Tests
=========================================

Testing basic examples from tools.rst:
---------------------------------------
Running: test_basic_tool_usage
Result: 60
Time: 0.000s
 Basic tool usage example validated successfully
 PASS: test_basic_tool_usage

Running: test_json_parsing
User: Alice
Skills: ['Python', 'JavaScript', 'Go']
 JSON parsing example validated successfully
 PASS: test_json_parsing

Running: test_complete_workflow
Loaded 5 products
Found 3 electronics
  Laptop: $14,999.85
  Mouse: $1,499.50
  Keyboard: $2,399.70

Total Electronics Value: $18,899.05

 Complete workflow example validated successfully
 PASS: test_complete_workflow


Testing custom tools examples from custom_tools.rst:
----------------------------------------------------
Running: test_custom_calculator
Result: 2678.0
Operation: average
Processed 5 values
 Custom calculator tool example validated successfully
 PASS: test_custom_calculator


=========================================
Test Summary
=========================================
Total Tests:  4
Passed:       4
Failed:       0

 ALL TESTS PASSED!
```

## CI/CD Integration

These tests run automatically on the `devel` branch via GitHub Actions:

- **Workflow:** `.github/workflows/validate-docs-examples.yml`
- **Trigger:** Push or PR to `devel` branch
- **Actions:**
  1. Install dependencies
  2. Run all example tests (`run_all_tests.sh`)
  3. Build Sphinx documentation
  4. Check for errors
  5. Upload artifacts

## Adding New Examples

When adding new code examples to documentation:

1. **Extract the code** into a test file in this directory
2. **Add assertions** to verify expected behavior
3. **Update `run_all_tests.sh`** to include the new test
4. **Run locally** to ensure it passes
5. **Document in this README** what the test validates

### Template for New Test

```python
"""
Test for <example name> from <doc file>
This file validates the "<section name>" example.
"""
import asyncio
from pygeai_orchestration.tools.builtin.some_tool import SomeTool

async def main():
    # Exact code from documentation
    tool = SomeTool()
    result = await tool.execute(param="value")
    
    # Validation
    if result.success:
        print(f"Result: {result.result}")
        assert result.result == expected_value, f"Expected {expected_value}, got {result.result}"
    else:
        raise AssertionError(f"Tool failed: {result.error}")

if __name__ == "__main__":
    asyncio.run(main())
    print(" Example validated successfully")
```

## Maintenance

### When to Update Tests

- **API changes** - If tool interfaces change, update tests
- **Documentation updates** - If examples change, update corresponding tests
- **New features** - Add tests for new examples in docs
- **Bug fixes** - If example had a bug, fix and verify with test

### Test Failures

If a test fails:

1. **Check if code changed** - Did the API change?
2. **Update documentation** - Does the doc need updating?
3. **Update test** - Does the test need updating?
4. **Fix the example** - Was the example wrong?

Never ignore failing tests - they indicate docs are out of sync with code.

## Best Practices

1. **Keep tests simple** - Test files should be readable and clear
2. **Match docs exactly** - Code should be identical to documentation
3. **Add assertions** - Verify expected outcomes
4. **Print output** - Show what the example produces
5. **Handle errors** - Fail clearly with helpful messages
6. **Run regularly** - Test before committing documentation changes

## Dependencies

Tests require:
- Python 3.11+
- pygeai-orchestration (installed in development mode)
- All dependencies from `requirements.txt`

Some tests may require:
- GEAI API credentials (for GEAI tools)
- Network access (for web tools)
- File system access (for file tools)

## Troubleshooting

### Test fails locally but example in docs is correct

- Check Python version (requires 3.11+)
- Ensure package installed: `pip install -e .`
- Check environment variables
- Verify dependencies installed

### Test passes locally but fails in CI

- Check CI Python version matches local
- Check environment variables in workflow
- Check for system-specific dependencies
- Review CI logs for specific errors

### All tests fail

- Reinstall package: `pip install -e .`
- Update dependencies: `pip install -r requirements.txt`
- Check Python version: `python3 --version`

## Contact

For questions or issues with documentation tests:
- Open an issue on GitHub
- Check documentation in `docs/source/tools.rst` and `docs/source/custom_tools.rst`
- Review the main documentation plan
