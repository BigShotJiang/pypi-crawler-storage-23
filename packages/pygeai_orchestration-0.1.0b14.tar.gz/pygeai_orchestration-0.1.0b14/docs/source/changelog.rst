Changelog
=========

All notable changes to PyGEAI Orchestration will be documented here.

Version 0.1.0b2 (2026-02-05)
----------------------------

CLI Enhancements
~~~~~~~~~~~~~~~~

* **New unified pattern execution command**: ``execute-pattern`` with aliases ``xp`` and ``pattern``

  - ``geai-orch execute-pattern <subcommand>`` - Full command name
  - ``geai-orch xp <subcommand>`` - Short alias (recommended)
  - ``geai-orch pattern <subcommand>`` - Alternative alias

* **Pattern subcommands**: All 5 patterns available as CLI subcommands

  - ``reflection`` - Iterative self-improvement pattern
  - ``react`` - Reasoning and acting pattern
  - ``planning`` - Task planning and execution pattern
  - ``tool-use`` - Tool-augmented execution pattern
  - ``multi-agent`` - Multi-agent collaboration pattern

* **Common CLI options** (available for all patterns):

  - ``-m, --model`` - Model name (required), e.g., ``openai/gpt-4o-mini``
  - ``-t, --task`` - Task description (required)
  - ``--temperature`` - Sampling temperature (0.0-1.0, default: 0.7)
  - ``--max-tokens`` - Maximum tokens to generate (default: 4096)
  - ``--system-prompt`` - Custom system prompt
  - ``-o, --output`` - Output file path (JSON format)
  - ``-v, --verbose`` - Include execution metadata in output

* **Pattern-specific options**:

  - Reflection: ``-i, --iterations`` - Max refinement iterations (default: 3)
  - ReAct: ``--max-steps`` - Max reasoning steps (default: 5)
  - Tool Use: ``--tools`` - Comma-separated tool names, ``--max-iterations``
  - Multi-Agent: ``-c, --config`` - Path to multi-agent JSON config

* **JSON output format**: Structured results with success, result, and iterations
* **Improved error handling**: Clear error messages to stderr, proper exit codes
* **File output support**: Save results to JSON files with ``--output``
* **Metadata output**: Optional execution metadata with ``--verbose``

Documentation
~~~~~~~~~~~~~

* Added comprehensive CLI documentation to quickstart guide
* Added CLI usage examples for all 5 patterns
* Updated pattern guide with CLI alternatives
* Added CLI vs Python API comparison section

Version 0.1.0b1 (2026-02-05)
----------------------------

Initial beta release.

Features
~~~~~~~~

* **5 Orchestration Patterns**:
  - Reflection Pattern for iterative refinement
  - Tool Use Pattern for dynamic tool execution
  - ReAct Pattern for reasoning and acting
  - Planning Pattern for task decomposition
  - Multi-Agent Pattern for collaborative workflows

* **Core Infrastructure**:
  - Base classes for agents, patterns, and tools
  - GEAIAgent implementation using PyGEAI SDK
  - State management with checkpointing
  - Memory management with eviction policies
  - Context management for data sharing

* **Error Handling**:
  - 7 custom exception classes
  - Centralized ErrorHandler
  - RetryHandler with exponential backoff

* **Utilities**:
  - Configuration validation
  - Logging infrastructure
  - Type-safe Pydantic models

Documentation
~~~~~~~~~~~~~

* Comprehensive API documentation
* Quick start guide
* Pattern usage guide
* Real-world examples
* Contributing guidelines

Quality
~~~~~~~

* 116 tests with 100% pass rate
* Full type hints coverage
* Ruff linting compliance
* Comprehensive docstrings

Dependencies
~~~~~~~~~~~~

* PyGEAI SDK >= 0.7.0b9
* Pydantic >= 2.0
* Python >= 3.9

Known Issues
~~~~~~~~~~~~

* None at release

Roadmap
-------

Version 0.2.0 (Planned)
~~~~~~~~~~~~~~~~~~~~~~~

* Additional patterns (Chain-of-Thought, Tree-of-Thoughts)
* Performance optimizations
* Advanced caching strategies
* Monitoring and metrics
* CLI enhancements

Version 0.3.0 (Planned)
~~~~~~~~~~~~~~~~~~~~~~~

* Async streaming support
* Parallel pattern execution
* Custom pattern composition
* Enhanced debugging tools

Version 1.0.0 (Planned)
~~~~~~~~~~~~~~~~~~~~~~~

* Stable API
* Production-ready
* Complete documentation
* Extensive examples
* Performance benchmarks
