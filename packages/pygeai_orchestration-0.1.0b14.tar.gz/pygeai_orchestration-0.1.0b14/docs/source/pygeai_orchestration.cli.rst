pygeai\_orchestration.cli package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai_orchestration.cli.commands

Submodules
----------

pygeai\_orchestration.cli.error\_handler module
-----------------------------------------------

.. automodule:: pygeai_orchestration.cli.error_handler
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.formatters module
-------------------------------------------

.. automodule:: pygeai_orchestration.cli.formatters
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.geai\_orch module
-------------------------------------------

.. automodule:: pygeai_orchestration.cli.geai_orch
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.interactive module
--------------------------------------------

.. automodule:: pygeai_orchestration.cli.interactive
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai_orchestration.cli
   :members:
   :show-inheritance:
   :undoc-members:
