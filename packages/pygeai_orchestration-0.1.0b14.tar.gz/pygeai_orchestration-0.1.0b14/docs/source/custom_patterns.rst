Custom Patterns Guide
=====================

This guide shows you how to create your own custom orchestration patterns by extending PyGEAI Orchestration's ``BasePattern`` class.

**Note**: Custom patterns can be used via CLI using the plugin system - see :doc:`plugins` for details.

Overview
--------

Custom patterns allow you to implement specialized orchestration logic beyond the built-in patterns (Reflection, ReAct, Planning, Tool Use, Multi-Agent). You can create patterns for:

* Adversarial reasoning (debate patterns)
* Quality-based refinement
* Multi-perspective synthesis
* Chain-of-thought reasoning
* Tree search algorithms
* Voting and consensus mechanisms

Pattern Interface
-----------------

All patterns inherit from ``BasePattern`` and must implement two methods:

.. code-block:: python

    from pygeai_orchestration.core.base import BasePattern, PatternConfig, PatternResult
    from typing import Any, Dict, Optional

    class CustomPattern(BasePattern):
        def __init__(self, agent, config: PatternConfig):
            super().__init__(config)
            self.agent = agent
            # Initialize pattern-specific state
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            """Main entry point - orchestrates the entire pattern"""
            self.reset()
            # Your pattern logic here
            return PatternResult(success=True, result="output")
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            """Execute a single iteration of the pattern"""
            # Your step logic here
            return {"done": False}
        
        def reset(self) -> None:
            """Reset pattern state for new execution"""
            super().reset()
            # Reset your custom state

Required Components
-------------------

PatternConfig
~~~~~~~~~~~~~

Every pattern requires a ``PatternConfig`` for initialization:

.. code-block:: python

    from pygeai_orchestration.core.base import PatternConfig, PatternType

    config = PatternConfig(
        name="my-pattern",
        pattern_type=PatternType.CUSTOM,
        max_iterations=5,
        timeout=None,  # Optional timeout in seconds
        verbose=False
    )

PatternResult
~~~~~~~~~~~~~

The ``execute()`` method must return a ``PatternResult``:

.. code-block:: python

    from pygeai_orchestration.core.base import PatternResult

    return PatternResult(
        success=True,              # Whether execution succeeded
        result="final answer",     # The actual result
        iterations=3,              # Number of iterations executed
        error=None,                # Error message if failed
        metadata={                 # Optional pattern-specific data
            "custom_data": "value"
        }
    )

Iteration Control
~~~~~~~~~~~~~~~~~

Use built-in iteration tracking:

.. code-block:: python

    # Reset iteration counter
    self.reset()
    
    # Check current iteration
    while self.current_iteration < self.config.max_iterations:
        # Increment counter
        self.increment_iteration()
        
        # Do work...

Example Patterns
----------------

Debate Pattern
~~~~~~~~~~~~~~

Generates arguments for and against a topic, then synthesizes a balanced conclusion.

.. code-block:: python

    import asyncio
    from typing import Any, Dict, Optional, List
    from pygeai_orchestration.core.base import (
        BasePattern, PatternConfig, PatternResult, PatternType
    )
    from pygeai_orchestration import GEAIAgent, AgentConfig

    class DebatePattern(BasePattern):
        def __init__(self, agent, config: PatternConfig):
            super().__init__(config)
            self.agent = agent
            self._arguments_for: List[str] = []
            self._arguments_against: List[str] = []
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            self.reset()
            
            try:
                # Generate arguments for and against
                for i in range(self.config.max_iterations):
                    self.increment_iteration()
                    
                    state = {
                        "task": task,
                        "iteration": self.current_iteration,
                        "arguments_for": self._arguments_for,
                        "arguments_against": self._arguments_against,
                    }
                    
                    step_result = await self.step(state)
                    self._arguments_for.append(step_result["for_argument"])
                    self._arguments_against.append(step_result["against_argument"])
                
                # Synthesize conclusion
                synthesis_prompt = f"""Given this debate on: {task}
                
                Arguments FOR:
                {chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_for))}
                
                Arguments AGAINST:
                {chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_against))}
                
                Provide a balanced conclusion considering both perspectives.
                """
                
                conclusion = await self.agent.generate(synthesis_prompt)
                
                return PatternResult(
                    success=True,
                    result=conclusion,
                    iterations=self.current_iteration,
                    metadata={
                        "arguments_for": self._arguments_for,
                        "arguments_against": self._arguments_against,
                    }
                )
            
            except Exception as e:
                return PatternResult(success=False, error=str(e))
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            task = state["task"]
            
            # Generate FOR argument
            for_prompt = f"Topic: {task}\n\nGenerate an argument SUPPORTING this topic."
            for_argument = await self.agent.generate(for_prompt)
            
            # Generate AGAINST argument
            against_prompt = f"Topic: {task}\n\nGenerate an argument OPPOSING this topic."
            against_argument = await self.agent.generate(against_prompt)
            
            return {
                "for_argument": for_argument,
                "against_argument": against_argument
            }
        
        def reset(self) -> None:
            super().reset()
            self._arguments_for = []
            self._arguments_against = []

    # Usage
    async def main():
        agent = GEAIAgent(config=AgentConfig(
            name="debater",
            model="openai/gpt-4o-mini"
        ))
        
        pattern = DebatePattern(
            agent=agent,
            config=PatternConfig(
                name="debate",
                pattern_type=PatternType.CUSTOM,
                max_iterations=3
            )
        )
        
        result = await pattern.execute("Remote work should be the default")
        print(result.result)

    asyncio.run(main())

Chain of Thought Pattern
~~~~~~~~~~~~~~~~~~~~~~~~~

Breaks down complex problems into explicit reasoning steps.

.. code-block:: python

    class ChainOfThoughtPattern(BasePattern):
        def __init__(self, agent, config: PatternConfig):
            super().__init__(config)
            self.agent = agent
            self._reasoning_steps: List[str] = []
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            self.reset()
            
            try:
                # Ask agent to plan the steps
                breakdown_prompt = f"""Problem: {task}
                
                Break this down into 3-5 clear reasoning steps.
                Format: Step 1: ..., Step 2: ..., etc.
                """
                breakdown = await self.agent.generate(breakdown_prompt)
                
                # Execute each reasoning step
                current_context = f"Problem: {task}\n\nPlanned steps:\n{breakdown}\n\n"
                
                while self.current_iteration < self.config.max_iterations:
                    self.increment_iteration()
                    
                    state = {
                        "task": task,
                        "iteration": self.current_iteration,
                        "context": current_context,
                    }
                    
                    step_result = await self.step(state)
                    self._reasoning_steps.append(step_result["reasoning"])
                    current_context += f"\nStep {self.current_iteration}: {step_result['reasoning']}\n"
                    
                    if step_result.get("is_final"):
                        break
                
                # Generate final answer
                final_prompt = f"{current_context}\n\nBased on the reasoning above, provide the final answer."
                final_answer = await self.agent.generate(final_prompt)
                
                return PatternResult(
                    success=True,
                    result=final_answer,
                    iterations=self.current_iteration,
                    metadata={"reasoning_steps": self._reasoning_steps}
                )
            
            except Exception as e:
                return PatternResult(success=False, error=str(e))
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            context = state["context"]
            iteration = state["iteration"]
            
            reasoning_prompt = f"""
{context}

Step {iteration}: Provide your reasoning for this step.
After reasoning, indicate if this is the final step (yes/no).
"""
            
            response = await self.agent.generate(reasoning_prompt)
            is_final = "final step: yes" in response.lower() or iteration >= 4
            
            return {"reasoning": response, "is_final": is_final}
        
        def reset(self) -> None:
            super().reset()
            self._reasoning_steps = []

Iterative Refinement Pattern
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Generates outputs and scores quality, refining until threshold met.

.. code-block:: python

    import re

    class IterativeRefinementPattern(BasePattern):
        def __init__(self, agent, config: PatternConfig, quality_threshold: float = 8.0):
            super().__init__(config)
            self.agent = agent
            self.quality_threshold = quality_threshold
            self._quality_history = []
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            self.reset()
            
            try:
                current_output = None
                current_score = 0.0
                
                while self.current_iteration < self.config.max_iterations:
                    self.increment_iteration()
                    
                    state = {
                        "task": task,
                        "current_output": current_output,
                        "current_score": current_score,
                    }
                    
                    step_result = await self.step(state)
                    current_output = step_result["output"]
                    current_score = step_result["score"]
                    
                    self._quality_history.append({
                        "iteration": self.current_iteration,
                        "score": current_score
                    })
                    
                    if current_score >= self.quality_threshold:
                        return PatternResult(
                            success=True,
                            result=current_output,
                            iterations=self.current_iteration,
                            metadata={
                                "final_score": current_score,
                                "threshold_met": True,
                                "quality_history": self._quality_history
                            }
                        )
                
                return PatternResult(
                    success=True,
                    result=current_output,
                    iterations=self.current_iteration,
                    metadata={
                        "final_score": current_score,
                        "threshold_met": False,
                        "quality_history": self._quality_history
                    }
                )
            
            except Exception as e:
                return PatternResult(success=False, error=str(e))
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            task = state["task"]
            current_output = state["current_output"]
            
            # Generate or refine
            if current_output is None:
                output = await self.agent.generate(f"Task: {task}\n\nGenerate a high-quality response.")
            else:
                output = await self.agent.generate(
                    f"Task: {task}\n\nPrevious: {current_output}\n\nImprove this response."
                )
            
            # Score the output
            evaluation = await self.agent.generate(f"""
Evaluate this response on a scale of 1-10.

Task: {task}
Response: {output}

Format: Score: [number]
""")
            
            score = self._extract_score(evaluation)
            return {"output": output, "score": score}
        
        def _extract_score(self, evaluation: str) -> float:
            match = re.search(r"Score:\s*(\d+\.?\d*)", evaluation)
            return float(match.group(1)) if match else 5.0
        
        def reset(self) -> None:
            super().reset()
            self._quality_history = []

Consensus Pattern
~~~~~~~~~~~~~~~~~

Generates responses from multiple perspectives, then synthesizes consensus.

.. code-block:: python

    class ConsensusPattern(BasePattern):
        def __init__(self, agent, config: PatternConfig, perspectives: List[str] = None):
            super().__init__(config)
            self.agent = agent
            self.perspectives = perspectives or [
                "analytical and data-driven",
                "creative and innovative",
                "practical and pragmatic",
            ]
            self._responses = []
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            self.reset()
            
            try:
                # Gather perspectives
                for perspective in self.perspectives:
                    self.increment_iteration()
                    
                    state = {"task": task, "perspective": perspective}
                    step_result = await self.step(state)
                    
                    self._responses.append({
                        "perspective": perspective,
                        "response": step_result["response"]
                    })
                
                # Synthesize consensus
                perspectives_text = "\n\n".join(
                    f"**{resp['perspective'].upper()}:**\n{resp['response']}"
                    for resp in self._responses
                )
                
                synthesis_prompt = f"""
Task: {task}

Perspectives:
{perspectives_text}

Synthesize these into a single consensus answer that captures the best insights.
"""
                
                consensus = await self.agent.generate(synthesis_prompt)
                
                return PatternResult(
                    success=True,
                    result=consensus,
                    iterations=self.current_iteration,
                    metadata={"perspectives": self._responses}
                )
            
            except Exception as e:
                return PatternResult(success=False, error=str(e))
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            task = state["task"]
            perspective = state["perspective"]
            
            prompt = f"""
You are approaching this from a {perspective} perspective.

Task: {task}

Provide your response emphasizing this perspective.
"""
            
            response = await self.agent.generate(prompt)
            return {"response": response}
        
        def reset(self) -> None:
            super().reset()
            self._responses = []

Best Practices
--------------

State Management
~~~~~~~~~~~~~~~~

* Store pattern-specific state in instance variables
* Reset all custom state in ``reset()`` method
* Don't rely on external state between executions

Error Handling
~~~~~~~~~~~~~~

* Wrap ``execute()`` in try/except
* Always return ``PatternResult`` even on failure
* Set ``success=False`` and populate ``error`` field
* Include ``iterations`` count even on failure

.. code-block:: python

    try:
        # Pattern logic
        return PatternResult(success=True, result=output)
    except Exception as e:
        return PatternResult(
            success=False,
            error=str(e),
            iterations=self.current_iteration
        )

Logging
~~~~~~~

Use Python's logging module for debugging:

.. code-block:: python

    import logging
    
    logger = logging.getLogger(__name__)
    
    class MyPattern(BasePattern):
        async def execute(self, task: str, context=None) -> PatternResult:
            logger.info(f"Starting pattern for: {task}")
            # ...
            logger.debug(f"Iteration {self.current_iteration} complete")

Configuration
~~~~~~~~~~~~~

* Use ``PatternConfig`` parameters:
  - ``max_iterations``: Control iteration limits
  - ``timeout``: Set execution timeout
  - ``verbose``: Enable detailed logging
  - ``metadata``: Store custom configuration

Agent Interaction
~~~~~~~~~~~~~~~~~

* Use ``self.agent.generate()`` for simple text generation
* Use ``self.agent.execute()`` for complex interactions
* Handle agent errors gracefully

Metadata
~~~~~~~~

Include useful debugging information in metadata:

.. code-block:: python

    return PatternResult(
        success=True,
        result=final_output,
        iterations=self.current_iteration,
        metadata={
            "intermediate_results": self._history,
            "convergence_step": convergence_iteration,
            "quality_metrics": self._scores,
        }
    )

Pattern Ideas
-------------

Here are some additional pattern ideas you can implement:

**Tree of Thought**
  Explore multiple reasoning paths in parallel, score each path, select best

**Self-Consistency**
  Generate multiple independent answers, use majority voting for final result

**Socratic Pattern**
  Question-driven exploration, iteratively refining understanding through questions

**Monte Carlo Search**
  Generate many candidate solutions, score and rank them, select optimal

**Bootstrapping**
  Self-training pattern that generates synthetic examples for improvement

**Ensemble Pattern**
  Combine outputs from multiple different approaches

**Verification Pattern**
  Generate answer, then verify correctness, repeat until verified

Working Examples
----------------

Complete working implementations are available in ``snippets/custom/``:

* ``debate_pattern.py`` - Full debate pattern with synthesis
* ``chain_of_thought_pattern.py`` - Step-by-step reasoning
* ``iterative_refinement_pattern.py`` - Quality-based refinement
* ``consensus_pattern.py`` - Multi-perspective consensus

Run examples::

    python snippets/custom/debate_pattern.py
    python snippets/custom/chain_of_thought_pattern.py

Testing Custom Patterns
------------------------

Test your custom pattern:

.. code-block:: python

    import asyncio
    from pygeai_orchestration import GEAIAgent, AgentConfig, PatternConfig, PatternType

    async def test_pattern():
        # Create agent
        agent = GEAIAgent(config=AgentConfig(
            name="test-agent",
            model="openai/gpt-4o-mini"
        ))
        
        # Create pattern
        config = PatternConfig(
            name="test",
            pattern_type=PatternType.CUSTOM,
            max_iterations=3
        )
        
        pattern = MyCustomPattern(agent=agent, config=config)
        
        # Execute
        result = await pattern.execute("Test task")
        
        # Verify
        assert result.success, f"Pattern failed: {result.error}"
        assert result.result is not None, "No result returned"
        assert result.iterations > 0, "No iterations executed"
        
        print(f"[OK] Pattern executed successfully in {result.iterations} iterations")
        print(f"Result: {result.result}")

    asyncio.run(test_pattern())

Next Steps
----------

* Try the example patterns in ``snippets/custom/``
* Implement your own custom pattern for your use case
* See :doc:`patterns` for built-in pattern reference
* Check :doc:`api/core` for complete API documentation
