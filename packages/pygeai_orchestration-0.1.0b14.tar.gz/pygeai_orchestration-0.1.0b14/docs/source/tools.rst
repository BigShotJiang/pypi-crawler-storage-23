Tools Guide
===========

This guide provides comprehensive information about tools in PyGEAI Orchestration.

Using Tools with CLI
---------------------

The CLI supports built-in tools via the ``tool-use`` pattern::

    geai-orch xp tool-use \
      -m "openai/gpt-4o-mini" \
      -t "Calculate the average of 10, 20, 30, 40, 50" \
      --tools "MathCalculatorTool"

**Multiple tools**::

    geai-orch xp tool-use \
      -m "openai/gpt-4o-mini" \
      -t "Read data.json, validate it, then calculate summary statistics" \
      --tools "FileReaderTool,DataValidatorTool,MathCalculatorTool" \
      --max-iterations 5

**List available tools**::

    geai-orch tools list

Overview
--------

Tools extend agent capabilities by providing access to:

* **External data sources**: Files, databases, APIs, documents
* **Computational operations**: Math, statistics, data processing
* **Web services**: Search, HTTP requests, webhooks
* **Communication channels**: Email, Slack, notifications
* **System operations**: Command execution, file management
* **GEAI capabilities**: Document parsing, embeddings, reranking

Tools enable agents to perform actions beyond text generation, making them practical for real-world tasks.

Tool Categories
~~~~~~~~~~~~~~~

Tools are organized into five categories:

* **SEARCH**: Web search, Wikipedia, knowledge retrieval
* **COMPUTATION**: Math, statistics, embeddings, data analysis
* **DATA_ACCESS**: Files, CSV, JSON, YAML, XML, databases, documents
* **COMMUNICATION**: Email, webhooks, Slack notifications
* **CUSTOM**: System commands, utilities, image processing

Why Use Tools?
~~~~~~~~~~~~~~

**Without tools**, an agent can only:

* Generate text responses
* Reason about information in its training data
* Process information you provide directly

**With tools**, an agent can:

* Read and write files
* Query databases
* Search the web
* Process structured data (CSV, JSON, etc.)
* Perform calculations
* Send notifications
* Parse documents
* And much more

Tool Interface
--------------

Understanding BaseTool
~~~~~~~~~~~~~~~~~~~~~~

All tools inherit from ``BaseTool`` and share a common interface.

**Key Components:**

.. code-block:: python

    from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory

    class MyTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="my_tool",
                description="What the tool does",
                category=ToolCategory.CUSTOM,
                parameters_schema={...}  # JSON Schema
            )
            super().__init__(config)
        
        def validate_parameters(self, parameters):
            # Validate input parameters
            return True
        
        async def execute(self, **kwargs):
            # Perform the tool's operation
            return ToolResult(success=True, result="output")

ToolConfig
~~~~~~~~~~

The ``ToolConfig`` defines tool metadata and parameters:

* ``name``: Unique tool identifier
* ``description``: Human-readable description of functionality
* ``category``: Tool category (SEARCH, COMPUTATION, etc.)
* ``parameters_schema``: JSON Schema defining accepted parameters
* ``timeout``: Optional execution timeout in seconds
* ``metadata``: Custom configuration data

ToolResult
~~~~~~~~~~

All tool executions return a ``ToolResult``:

* ``success``: Boolean indicating if execution succeeded
* ``result``: The actual output data
* ``error``: Error message if execution failed
* ``execution_time``: Time taken to execute (in seconds)
* ``metadata``: Additional context about execution

Using Tools
-----------

Basic Tool Usage
~~~~~~~~~~~~~~~~

**Direct instantiation and execution:**

.. code-block:: python

    import asyncio
    from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool

    async def main():
        # Create tool instance
        tool = MathCalculatorTool()
        
        # Execute tool
        result = await tool.execute(operation='add', values=[10, 20, 30])
        
        # Check result
        if result.success:
            print(f"Result: {result.result}")
            print(f"Time: {result.execution_time:.3f}s")
        else:
            print(f"Error: {result.error}")

    asyncio.run(main())

**Output:**

.. code-block:: text

    Result: 60
    Time: 0.001s

Working with Data Tools
~~~~~~~~~~~~~~~~~~~~~~~

**Example: Parsing JSON data**

.. code-block:: python

    import asyncio
    from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool

    async def main():
        tool = JSONParserTool()
        
        json_data = '''
        {
            "user": {
                "name": "Alice",
                "age": 30,
                "skills": ["Python", "JavaScript", "Go"]
            }
        }
        '''
        
        # Parse JSON
        result = await tool.execute(json_string=json_data)
        if result.success:
            print(f"User: {result.result['user']['name']}")
        
        # Query nested path
        result = await tool.execute(
            json_string=json_data,
            query="user.skills"
        )
        if result.success:
            print(f"Skills: {result.result}")

    asyncio.run(main())

**Output:**

.. code-block:: text

    User: Alice
    Skills: ['Python', 'JavaScript', 'Go']

Tool Registry
-------------

The ``ToolRegistry`` provides centralized tool management and discovery.

Registering Tools
~~~~~~~~~~~~~~~~~

.. code-block:: python

    from pygeai_orchestration.tools.registry import ToolRegistry
    from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool

    # Create registry
    registry = ToolRegistry()
    
    # Register a tool class
    registry.register(MathCalculatorTool)
    
    # Or register an instance
    tool = MathCalculatorTool()
    registry.register_instance(tool)

Discovering Tools
~~~~~~~~~~~~~~~~~

.. code-block:: python

    from pygeai_orchestration.tools.registry import ToolRegistry
    from pygeai_orchestration.core.base.tool import ToolCategory

    registry = ToolRegistry()
    
    # List all tools
    all_tools = registry.list_tools()
    print(f"Available tools: {all_tools}")
    
    # Filter by category
    computation_tools = registry.list_tools(category=ToolCategory.COMPUTATION)
    print(f"Computation tools: {computation_tools}")
    
    # Get specific tool
    tool = registry.get_tool("math_calculator")
    if tool:
        result = await tool.execute(operation='add', values=[5, 10])

Getting Tool Schemas
~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    registry = ToolRegistry()
    registry.register(MathCalculatorTool)
    
    # Get schema for a tool
    schema = registry.get_tool_schema("math_calculator")
    print(f"Tool name: {schema['name']}")
    print(f"Description: {schema['description']}")
    print(f"Parameters: {schema['parameters']}")

Built-in Tools
--------------

PyGEAI Orchestration includes 40+ ready-to-use tools across all categories.

Math & Statistics
~~~~~~~~~~~~~~~~~

**MathCalculatorTool**
    Perform mathematical calculations: add, subtract, multiply, divide, power, sqrt, trigonometry, logarithms.

.. code-block:: python

    from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool
    
    tool = MathCalculatorTool()
    result = await tool.execute(operation='power', values=[2, 10])
    # Result: 1024

**StatisticsAnalyzerTool**
    Calculate statistics: mean, median, mode, standard deviation, variance.

.. code-block:: python

    from pygeai_orchestration.tools.builtin.math_tools import StatisticsAnalyzerTool
    
    tool = StatisticsAnalyzerTool()
    result = await tool.execute(
        data=[1, 2, 3, 4, 5],
        metrics=['mean', 'median', 'stddev']
    )

Data Processing
~~~~~~~~~~~~~~~

**JSONParserTool**
    Parse and query JSON data with dot notation path queries.

**YAMLParserTool**
    Parse YAML configuration files.

**CSVProcessorTool**
    Read, write, and manipulate CSV data.

**XMLParserTool**
    Parse and query XML documents.

**DataFrameTool**
    Process tabular data with operations like filter, sort, group, and aggregate.

See the :ref:`data-tools-examples` section for complete examples.

File Operations
~~~~~~~~~~~~~~~

**FileReaderTool**
    Read files from filesystem with encoding support.

**FileWriterTool**
    Write data to files with atomic operations.

**FileSearchTool**
    Search for files matching patterns.

Web & Network
~~~~~~~~~~~~~

**WebSearchTool**
    Search the web using DuckDuckGo or Google.

**WikipediaTool**
    Search and retrieve Wikipedia articles.

**HTTPRequestTool**
    Make HTTP requests (GET, POST, PUT, DELETE).

**WebhookTool**
    Send data to webhook endpoints.

GEAI-Powered Tools
~~~~~~~~~~~~~~~~~~

**OmniParserTool**
    OCR and document parsing for PDFs, images, scanned documents.

**EmbeddingsGeneratorTool**
    Generate semantic embeddings for text.

**RerankTool**
    Rerank search results for improved relevance.

See :doc:`api/tools` for complete API reference of all built-in tools.

Integration with Patterns
--------------------------

Tool Use Pattern
~~~~~~~~~~~~~~~~

The ``ToolUsePattern`` enables agents to use tools to accomplish tasks.

.. code-block:: python

    import asyncio
    from pygeai_orchestration.core.base import (
        AgentConfig, PatternConfig, PatternType,
        BaseTool, ToolConfig, ToolResult, ToolCategory
    )
    from pygeai_orchestration.core.base.geai_agent import GEAIAgent
    from pygeai_orchestration.patterns import ToolUsePattern

    # Create a custom tool
    class CalculatorTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="calculator",
                description="Performs mathematical calculations",
                category=ToolCategory.COMPUTATION,
                parameters_schema={"input": "string"}
            )
            super().__init__(config)
        
        def validate_parameters(self, parameters):
            return "input" in parameters
        
        async def execute(self, input="", **kwargs):
            # Parse and calculate
            parts = input.strip().split()
            operation = parts[0].lower()
            numbers = [float(n) for n in parts[1].split(',')]
            
            if operation == "average":
                result = sum(numbers) / len(numbers)
            elif operation == "add":
                result = sum(numbers)
            else:
                return ToolResult(success=False, error="Unknown operation")
            
            return ToolResult(success=True, result=result)

    # Use tool with agent
    async def main():
        agent = GEAIAgent(config=AgentConfig(
            name="calculator_agent",
            model="openai/gpt-4o-mini",
            temperature=0.1
        ))
        
        pattern = ToolUsePattern(
            agent=agent,
            config=PatternConfig(
                name="calculator_usage",
                pattern_type=PatternType.TOOL_USE,
                max_iterations=3
            ),
            tools=[CalculatorTool()]
        )
        
        result = await pattern.execute(
            "Calculate the average of: 1250, 3400, 2100, 4750, 1890"
        )
        
        print(f"Result: {result.result}")

    asyncio.run(main())

See :doc:`patterns` for more on the Tool Use pattern.

.. _data-tools-examples:

Complete Workflow Example
~~~~~~~~~~~~~~~~~~~~~~~~~~

**Multi-step data processing workflow:**

.. code-block:: python

    import asyncio
    from pygeai_orchestration.tools.builtin.data_tools import (
        CSVProcessorTool, DataFrameTool
    )

    async def main():
        csv_tool = CSVProcessorTool()
        df_tool = DataFrameTool()
        
        # Step 1: Parse CSV data
        csv_data = """product,category,price,stock
    Laptop,Electronics,999.99,15
    Mouse,Electronics,29.99,50
    Desk,Furniture,299.99,10
    Chair,Furniture,199.99,25
    Keyboard,Electronics,79.99,30"""
        
        csv_result = await csv_tool.execute(
            operation="parse",
            csv_string=csv_data,
            has_header=True
        )
        
        if csv_result.success:
            print(f"Loaded {len(csv_result.result)} products")
            
            # Step 2: Filter electronics
            filtered = await df_tool.execute(
                data=csv_result.result,
                operation="filter",
                column="category",
                condition="eq",
                value="Electronics"
            )
            
            if filtered.success:
                print(f"Found {len(filtered.result)} electronics")
                
                # Step 3: Calculate inventory value
                total_value = 0
                for item in filtered.result:
                    value = float(item['price']) * int(item['stock'])
                    total_value += value
                    print(f"  {item['product']}: ${value:,.2f}")
                
                print(f"\nTotal Electronics Value: ${total_value:,.2f}")

    asyncio.run(main())

**Output:**

.. code-block:: text

    Loaded 5 products
    Found 3 electronics
      Laptop: $14,999.85
      Mouse: $1,499.50
      Keyboard: $2,399.70

    Total Electronics Value: $18,899.05

Best Practices
--------------

Error Handling
~~~~~~~~~~~~~~

Always check ``ToolResult.success`` before using results:

.. code-block:: python

    result = await tool.execute(**params)
    
    if result.success:
        # Use result.result
        process_data(result.result)
    else:
        # Handle error
        logger.error(f"Tool failed: {result.error}")
        # Implement fallback strategy

Parameter Validation
~~~~~~~~~~~~~~~~~~~~

Implement robust parameter validation:

.. code-block:: python

    def validate_parameters(self, parameters):
        required = ['field1', 'field2']
        if not all(key in parameters for key in required):
            return False
        
        # Type checking
        if not isinstance(parameters.get('field1'), str):
            return False
        
        return True

Security Considerations
~~~~~~~~~~~~~~~~~~~~~~~

****Critical Security Warning**

Some tools execute arbitrary code or system commands:

* ``CommandExecutorTool``: Executes system commands
* ``PythonREPLTool``: Executes Python code

**Security Best Practices:**

1. **Validate all inputs** before execution
2. **Restrict tool access** to trusted agents only
3. **Use sandboxing** for code execution tools
4. **Log all tool usage** for auditing
5. **Never expose to untrusted user input**

.. code-block:: python

    #  DANGEROUS - User input directly to command
    result = await command_tool.execute(command=user_input)
    
    #  SAFE - Validate and sanitize
    allowed_commands = ['ls', 'pwd', 'whoami']
    if user_command in allowed_commands:
        result = await command_tool.execute(command=user_command)

Performance Optimization
~~~~~~~~~~~~~~~~~~~~~~~~

**Use timeouts** for long-running operations:

.. code-block:: python

    config = ToolConfig(
        name="slow_tool",
        description="Slow operation",
        timeout=30.0  # 30 second timeout
    )

**Cache tool results** when appropriate:

.. code-block:: python

    class CachingTool(BaseTool):
        def __init__(self):
            super().__init__(config)
            self._cache = {}
        
        async def execute(self, query, **kwargs):
            if query in self._cache:
                return self._cache[query]
            
            result = await self._perform_operation(query)
            self._cache[query] = result
            return result

**Use Tool Registry** to avoid recreating tool instances:

.. code-block:: python

    #  Good - Reuse instance
    registry = ToolRegistry()
    registry.register(ExpensiveTool)
    tool = registry.get_tool("expensive_tool")  # Returns cached instance
    
    #  Bad - Create new instance every time
    tool = ExpensiveTool()

Tool Selection Strategies
~~~~~~~~~~~~~~~~~~~~~~~~~~

**Choose the right tool category:**

* Need to search information? → Use SEARCH tools
* Need calculations? → Use COMPUTATION tools
* Need to access data? → Use DATA_ACCESS tools
* Need to notify someone? → Use COMMUNICATION tools

**Combine multiple tools** for complex workflows:

.. code-block:: python

    # 1. Search for information
    search_result = await web_search_tool.execute(query="Python best practices")
    
    # 2. Process the results
    json_result = await json_parser_tool.execute(json_string=search_result.result)
    
    # 3. Store findings
    await file_writer_tool.execute(
        file_path="research.txt",
        content=json_result.result
    )

Next Steps
----------

* **Create custom tools**: See :doc:`custom_tools` for detailed guide
* **Explore all built-in tools**: See :doc:`api/tools` for complete API reference
* **Use tools with patterns**: See :doc:`patterns` for integration examples
* **View real-world examples**: See :doc:`examples` for complete applications
