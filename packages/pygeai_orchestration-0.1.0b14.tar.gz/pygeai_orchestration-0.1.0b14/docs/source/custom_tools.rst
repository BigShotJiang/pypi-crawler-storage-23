Custom Tools Guide
==================

This guide shows you how to create your own custom tools by extending PyGEAI Orchestration's ``BaseTool`` class.

**Note**: Custom tools can be used via CLI with the ``tool-use`` pattern by referencing their class names. See :doc:`tools` for CLI usage.

Overview
--------

Custom tools allow you to extend agent capabilities with specialized functionality beyond the built-in tools. You can create tools for:

* Domain-specific computations
* Custom API integrations
* Proprietary data sources
* Specialized data processing
* Business logic encapsulation
* Third-party service integration

Tool Interface
--------------

All tools inherit from ``BaseTool`` and must implement two methods:

.. code-block:: python

    from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
    from typing import Dict, Any

    class CustomTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="custom_tool",
                description="What the tool does",
                category=ToolCategory.CUSTOM,
                parameters_schema={...}  # JSON Schema
            )
            super().__init__(config)
        
        def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
            """Validate input parameters before execution"""
            # Your validation logic
            return True
        
        async def execute(self, **kwargs) -> ToolResult:
            """Execute the tool's operation"""
            # Your tool logic
            return ToolResult(success=True, result="output")

Required Components
-------------------

ToolConfig
~~~~~~~~~~

Every tool requires a ``ToolConfig`` for initialization:

.. code-block:: python

    from pygeai_orchestration.core.base.tool import ToolConfig, ToolCategory

    config = ToolConfig(
        name="my_tool",
        description="Clear description of what the tool does",
        category=ToolCategory.CUSTOM,
        parameters_schema={
            "type": "object",
            "properties": {
                "param1": {"type": "string"},
                "param2": {"type": "number"}
            },
            "required": ["param1"]
        },
        timeout=30.0,  # Optional timeout in seconds
        metadata={}    # Optional custom metadata
    )

**ToolCategory Options:**

* ``SEARCH``: Web search, knowledge retrieval
* ``COMPUTATION``: Math, statistics, data analysis
* ``DATA_ACCESS``: Files, databases, documents
* ``COMMUNICATION``: Email, notifications, webhooks
* ``CUSTOM``: Custom functionality

ToolResult
~~~~~~~~~~

The ``execute()`` method must return a ``ToolResult``:

.. code-block:: python

    from pygeai_orchestration.core.base.tool import ToolResult

    return ToolResult(
        success=True,              # Whether execution succeeded
        result="output",           # The actual result data
        error=None,                # Error message if failed
        execution_time=0.123,      # Time taken (auto-populated)
        metadata={                 # Optional execution metadata
            "details": "value"
        }
    )

Creating Your First Tool
-------------------------

Let's create a complete custom tool step by step.

Step 1: Define the Tool Class
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    import re
    from typing import Dict, Any
    from pygeai_orchestration.core.base.tool import (
        BaseTool, ToolConfig, ToolResult, ToolCategory
    )

    class CalculatorTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="calculator",
                description=(
                    "Performs mathematical calculations. "
                    "Supported operations: add, multiply, average, max, min. "
                    "Format: <operation> <comma-separated numbers>"
                ),
                category=ToolCategory.COMPUTATION,
                parameters_schema={
                    "type": "object",
                    "properties": {
                        "input": {
                            "type": "string",
                            "description": "Format: <operation> <numbers>"
                        }
                    },
                    "required": ["input"]
                }
            )
            super().__init__(config)

Step 2: Implement Parameter Validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate that input parameter exists"""
        return "input" in parameters

**Best practices:**

* Check required parameters exist
* Validate parameter types
* Check value ranges/constraints
* Return ``True`` if valid, ``False`` otherwise

Step 3: Implement Execute Method
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    async def execute(self, input: str = "", **kwargs) -> ToolResult:
        try:
            # Parse input
            parts = input.strip().split(maxsplit=1)
            if len(parts) < 2:
                return ToolResult(
                    success=False,
                    result=None,
                    error="Invalid format. Expected: <operation> <numbers>"
                )
            
            operation = parts[0].lower()
            numbers_str = parts[1]
            
            # Extract numbers
            values = []
            for num in re.findall(r'-?\\d+\\.?\\d*', numbers_str):
                values.append(float(num))
            
            if not values:
                return ToolResult(
                    success=False,
                    result=None,
                    error="No numbers found in input"
                )
            
            # Perform operation
            if operation == "add":
                result = sum(values)
            elif operation == "multiply":
                result = 1
                for v in values:
                    result *= v
            elif operation == "average":
                result = sum(values) / len(values) if values else 0
            elif operation == "max":
                result = max(values) if values else 0
            elif operation == "min":
                result = min(values) if values else 0
            else:
                return ToolResult(
                    success=False,
                    result=None,
                    error=f"Unknown operation: {operation}"
                )
            
            return ToolResult(
                success=True,
                result=result,
                metadata={
                    "operation": operation,
                    "input_count": len(values),
                    "values": values
                }
            )
        except Exception as e:
            return ToolResult(success=False, result=None, error=str(e))

Complete Tool Example
~~~~~~~~~~~~~~~~~~~~~

Here's the full working tool:

.. code-block:: python

    import asyncio
    import re
    from typing import Dict, Any
    from pygeai_orchestration.core.base.tool import (
        BaseTool, ToolConfig, ToolResult, ToolCategory
    )

    class CalculatorTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="calculator",
                description=(
                    "Performs mathematical calculations. "
                    "Supported operations: add, multiply, average, max, min. "
                    "Format: <operation> <comma-separated numbers>"
                ),
                category=ToolCategory.COMPUTATION,
                parameters_schema={"input": "string"}
            )
            super().__init__(config)
        
        def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
            return "input" in parameters
        
        async def execute(self, input: str = "", **kwargs) -> ToolResult:
            try:
                parts = input.strip().split(maxsplit=1)
                if len(parts) < 2:
                    return ToolResult(
                        success=False,
                        result=None,
                        error="Invalid format"
                    )
                
                operation = parts[0].lower()
                numbers_str = parts[1]
                
                values = []
                for num in re.findall(r'-?\\d+\\.?\\d*', numbers_str):
                    values.append(float(num))
                
                if not values:
                    return ToolResult(
                        success=False,
                        result=None,
                        error="No numbers found"
                    )
                
                if operation == "add":
                    result = sum(values)
                elif operation == "multiply":
                    result = 1
                    for v in values:
                        result *= v
                elif operation == "average":
                    result = sum(values) / len(values)
                elif operation == "max":
                    result = max(values)
                elif operation == "min":
                    result = min(values)
                else:
                    return ToolResult(
                        success=False,
                        result=None,
                        error=f"Unknown operation: {operation}"
                    )
                
                return ToolResult(
                    success=True,
                    result=result,
                    metadata={
                        "operation": operation,
                        "input_count": len(values),
                        "values": values
                    }
                )
            except Exception as e:
                return ToolResult(success=False, result=None, error=str(e))

    # Test the tool
    async def main():
        tool = CalculatorTool()
        
        result = await tool.execute(input="average 1250, 3400, 2100, 4750, 1890")
        
        if result.success:
            print(f"Result: {result.result}")
            print(f"Operation: {result.metadata['operation']}")
            print(f"Processed {result.metadata['input_count']} values")

    asyncio.run(main())

**Output:**

.. code-block:: text

    Result: 2678.0
    Operation: average
    Processed 5 values

Using Custom Tools with Agents
-------------------------------

Integration with ToolUsePattern
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Custom tools integrate seamlessly with the Tool Use pattern:

.. code-block:: python

    import asyncio
    from pygeai_orchestration.core.base import (
        AgentConfig, PatternConfig, PatternType
    )
    from pygeai_orchestration.core.base.geai_agent import GEAIAgent
    from pygeai_orchestration.patterns import ToolUsePattern

    async def main():
        # Create agent
        agent = GEAIAgent(config=AgentConfig(
            name="calculator_agent",
            model="openai/gpt-4o-mini",
            temperature=0.1
        ))
        
        # Create pattern with custom tool
        pattern = ToolUsePattern(
            agent=agent,
            config=PatternConfig(
                name="calculator_usage",
                pattern_type=PatternType.TOOL_USE,
                max_iterations=3
            ),
            tools=[CalculatorTool()]
        )
        
        # Execute task
        result = await pattern.execute(
            "Calculate the average of: 1250, 3400, 2100, 4750, 1890"
        )
        
        print(f"Success: {result.success}")
        print(f"Result: {result.result}")
        print(f"Tools used: {result.metadata.get('tools_used', [])}")

    asyncio.run(main())

**Output:**

.. code-block:: text

    Success: True
    Result: 2678.0
    Tools used: ['calculator']

Registering with ToolRegistry
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Register your custom tool for centralized management:

.. code-block:: python

    from pygeai_orchestration.tools.registry import ToolRegistry

    # Create registry
    registry = ToolRegistry()
    
    # Register the tool class
    registry.register(CalculatorTool)
    
    # Or register an instance
    calculator = CalculatorTool()
    registry.register_instance(calculator)
    
    # Get the tool later
    tool = registry.get_tool("calculator")
    result = await tool.execute(input="add 10, 20, 30")

Advanced Patterns
-----------------

Stateful Tools
~~~~~~~~~~~~~~

Tools can maintain internal state:

.. code-block:: python

    class CounterTool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="counter",
                description="Counts how many times it's been called",
                category=ToolCategory.CUSTOM,
                parameters_schema={"action": "string"}
            )
            super().__init__(config)
            self._count = 0
        
        def validate_parameters(self, parameters):
            return "action" in parameters
        
        async def execute(self, action="increment", **kwargs):
            if action == "increment":
                self._count += 1
            elif action == "reset":
                self._count = 0
            elif action == "get":
                pass  # Just return current count
            
            return ToolResult(
                success=True,
                result=self._count,
                metadata={"action": action}
            )

Tools with External Dependencies
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    import aiohttp
    from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory

    class ExternalAPITool(BaseTool):
        """Example tool that calls an external API (pattern only, not functional)"""
        def __init__(self, api_key: str, api_url: str):
            config = ToolConfig(
                name="external_api",
                description="Call an external API service",
                category=ToolCategory.CUSTOM,
                parameters_schema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"}
                    },
                    "required": ["query"]
                },
                timeout=10.0
            )
            super().__init__(config)
            self.api_key = api_key
            self.api_url = api_url
        
        def validate_parameters(self, parameters):
            return "query" in parameters and parameters["query"]
        
        async def execute(self, query: str, **kwargs):
            try:
                async with aiohttp.ClientSession() as session:
                    # Use your actual API endpoint
                    params = {"query": query, "key": self.api_key}
                    
                    async with session.get(self.api_url, params=params) as response:
                        if response.status == 200:
                            data = await response.json()
                            return ToolResult(
                                success=True,
                                result=data,
                                metadata={"query": query}
                            )
                        else:
                            return ToolResult(
                                success=False,
                                result=None,
                                error=f"API error: {response.status}"
                            )
            except Exception as e:
                return ToolResult(success=False, result=None, error=str(e))

Tools with Caching
~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from typing import Dict, Any
    import hashlib
    import json

    class CachedAPITool(BaseTool):
        def __init__(self):
            config = ToolConfig(
                name="cached_api",
                description="API tool with result caching",
                category=ToolCategory.CUSTOM,
                parameters_schema={"query": "string"}
            )
            super().__init__(config)
            self._cache: Dict[str, Any] = {}
        
        def _cache_key(self, **kwargs) -> str:
            """Generate cache key from parameters"""
            key_str = json.dumps(kwargs, sort_keys=True)
            return hashlib.md5(key_str.encode()).hexdigest()
        
        def validate_parameters(self, parameters):
            return "query" in parameters
        
        async def execute(self, query: str, **kwargs):
            cache_key = self._cache_key(query=query)
            
            # Check cache
            if cache_key in self._cache:
                return ToolResult(
                    success=True,
                    result=self._cache[cache_key],
                    metadata={"cached": True}
                )
            
            # Perform actual operation
            result = await self._fetch_data(query)
            
            # Store in cache
            self._cache[cache_key] = result
            
            return ToolResult(
                success=True,
                result=result,
                metadata={"cached": False}
            )
        
        async def _fetch_data(self, query: str):
            # Your actual data fetching logic
            return f"Data for: {query}"

Testing Custom Tools
---------------------

Unit Testing
~~~~~~~~~~~~

Always write unit tests for your custom tools:

.. code-block:: python

    import pytest
    from your_module import CalculatorTool

    @pytest.mark.asyncio
    async def test_calculator_add():
        tool = CalculatorTool()
        result = await tool.execute(input="add 10, 20, 30")
        
        assert result.success is True
        assert result.result == 60
        assert result.metadata["operation"] == "add"
        assert result.metadata["input_count"] == 3

    @pytest.mark.asyncio
    async def test_calculator_invalid_operation():
        tool = CalculatorTool()
        result = await tool.execute(input="divide 10, 5")
        
        assert result.success is False
        assert "Unknown operation" in result.error

    @pytest.mark.asyncio
    async def test_calculator_no_numbers():
        tool = CalculatorTool()
        result = await tool.execute(input="add abc, def")
        
        assert result.success is False
        assert "No numbers found" in result.error

Integration Testing
~~~~~~~~~~~~~~~~~~~

Test tools with actual agents:

.. code-block:: python

    import pytest
    from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
    from pygeai_orchestration.core.base.geai_agent import GEAIAgent
    from pygeai_orchestration.patterns import ToolUsePattern
    from your_module import CalculatorTool

    @pytest.mark.asyncio
    async def test_calculator_with_agent():
        agent = GEAIAgent(config=AgentConfig(
            name="test_agent",
            model="openai/gpt-4o-mini",
            temperature=0.1
        ))
        
        pattern = ToolUsePattern(
            agent=agent,
            config=PatternConfig(
                name="test",
                pattern_type=PatternType.TOOL_USE,
                max_iterations=3
            ),
            tools=[CalculatorTool()]
        )
        
        result = await pattern.execute("What is 10 + 20 + 30?")
        
        assert result.success is True
        assert "60" in str(result.result)

Best Practices
--------------

Error Handling
~~~~~~~~~~~~~~

Always wrap execute logic in try-except:

.. code-block:: python

    async def execute(self, **kwargs):
        try:
            # Your logic here
            return ToolResult(success=True, result=data)
        except ValueError as e:
            return ToolResult(success=False, result=None, error=f"Invalid value: {e}")
        except Exception as e:
            return ToolResult(success=False, result=None, error=str(e))

Parameter Validation
~~~~~~~~~~~~~~~~~~~~

Validate thoroughly:

.. code-block:: python

    def validate_parameters(self, parameters):
        # Check required fields
        if "required_field" not in parameters:
            return False
        
        # Check types
        if not isinstance(parameters.get("number"), (int, float)):
            return False
        
        # Check constraints
        if parameters.get("number", 0) < 0:
            return False
        
        return True

Documentation
~~~~~~~~~~~~~

Document your tools well:

.. code-block:: python

    class MyTool(BaseTool):
        """
        A tool that does X.
        
        This tool is useful for Y scenarios and requires Z.
        
        Parameters:
            param1 (str): Description of param1
            param2 (int): Description of param2
        
        Returns:
            ToolResult with:
                - success (bool): Whether operation succeeded
                - result (dict): Contains 'key1' and 'key2'
                - metadata (dict): Additional execution info
        
        Example:
            >>> tool = MyTool()
            >>> result = await tool.execute(param1="value", param2=42)
            >>> print(result.result)
        """

Logging
~~~~~~~

Add logging for debugging:

.. code-block:: python

    import logging

    class MyTool(BaseTool):
        def __init__(self):
            super().__init__(config)
            self.logger = logging.getLogger(self.__class__.__name__)
        
        async def execute(self, **kwargs):
            self.logger.debug(f"Executing with params: {kwargs}")
            try:
                result = await self._do_work(**kwargs)
                self.logger.info(f"Execution successful")
                return ToolResult(success=True, result=result)
            except Exception as e:
                self.logger.error(f"Execution failed: {e}")
                return ToolResult(success=False, result=None, error=str(e))

Security Considerations
~~~~~~~~~~~~~~~~~~~~~~~

****Security Warning**

Custom tools that interact with external systems pose security risks:

1. **Validate all inputs** - Never trust user input
2. **Sanitize file paths** - Prevent directory traversal
3. **Limit permissions** - Use minimal required permissions
4. **Timeout operations** - Prevent hanging
5. **Log security events** - Track potentially dangerous operations

.. code-block:: python

    import os
    from pathlib import Path

    class SecureFileTool(BaseTool):
        def __init__(self, allowed_directory: str):
            super().__init__(config)
            self.allowed_dir = Path(allowed_directory).resolve()
        
        async def execute(self, file_path: str, **kwargs):
            # Validate path is within allowed directory
            full_path = (self.allowed_dir / file_path).resolve()
            
            if not full_path.is_relative_to(self.allowed_dir):
                return ToolResult(
                    success=False,
                    result=None,
                    error="Path outside allowed directory"
                )
            
            # Safe to proceed
            # ...

Common Pitfalls
---------------

** Don't:**

1. Forget to validate parameters
2. Raise exceptions instead of returning ToolResult
3. Ignore timeouts for long operations
4. Store sensitive data in metadata
5. Block the event loop with synchronous I/O

** Do:**

1. Always return ToolResult
2. Use async/await for I/O operations
3. Implement proper error handling
4. Document parameters clearly
5. Write unit tests

Next Steps
----------

* **Explore built-in tools**: See :doc:`tools` for usage patterns
* **View API reference**: See :doc:`api/tools` for complete API
* **Learn tool integration**: See :doc:`patterns` for Tool Use pattern
* **See examples**: See :doc:`examples` for complete applications
