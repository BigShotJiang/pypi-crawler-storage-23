Patterns Module
===============

The patterns module provides five powerful orchestration patterns for building complex AI workflows.

Reflection Pattern
------------------

.. automodule:: pygeai_orchestration.patterns.reflection
   :members:
   :undoc-members:
   :show-inheritance:

Tool Use Pattern
----------------

.. automodule:: pygeai_orchestration.patterns.tool_use
   :members:
   :undoc-members:
   :show-inheritance:

ReAct Pattern
-------------

.. automodule:: pygeai_orchestration.patterns.react
   :members:
   :undoc-members:
   :show-inheritance:

Planning Pattern
----------------

.. automodule:: pygeai_orchestration.patterns.planning
   :members:
   :undoc-members:
   :show-inheritance:

Multi-Agent Pattern
-------------------

.. automodule:: pygeai_orchestration.patterns.multi_agent
   :members:
   :undoc-members:
   :show-inheritance:
