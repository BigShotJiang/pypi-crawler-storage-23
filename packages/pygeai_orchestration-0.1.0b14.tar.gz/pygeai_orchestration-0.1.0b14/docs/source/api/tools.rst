Tools Module
============

The tools module provides 40+ ready-to-use tools across five categories: SEARCH, COMPUTATION, DATA_ACCESS, COMMUNICATION, and CUSTOM.

Tool Registry
-------------

.. automodule:: pygeai_orchestration.tools.registry
   :members:
   :undoc-members:
   :show-inheritance:

Base Tool Classes
-----------------

.. automodule:: pygeai_orchestration.core.base.tool
   :members:
   :undoc-members:
   :show-inheritance:

Math Tools
----------

.. automodule:: pygeai_orchestration.tools.builtin.math_tools
   :members:
   :undoc-members:
   :show-inheritance:

Data Processing Tools
---------------------

.. automodule:: pygeai_orchestration.tools.builtin.data_tools
   :members:
   :undoc-members:
   :show-inheritance:

File Operations Tools
---------------------

.. automodule:: pygeai_orchestration.tools.builtin.file_tools
   :members:
   :undoc-members:
   :show-inheritance:

Web Tools
---------

.. automodule:: pygeai_orchestration.tools.builtin.web_tools
   :members:
   :undoc-members:
   :show-inheritance:

Text Processing Tools
---------------------

.. automodule:: pygeai_orchestration.tools.builtin.text_tools
   :members:
   :undoc-members:
   :show-inheritance:

System Tools
------------

.. automodule:: pygeai_orchestration.tools.builtin.system_tools
   :members:
   :undoc-members:
   :show-inheritance:

Communication Tools
-------------------

.. automodule:: pygeai_orchestration.tools.builtin.communication_tools
   :members:
   :undoc-members:
   :show-inheritance:

GEAI Tools
----------

.. automodule:: pygeai_orchestration.tools.builtin.geai_tools
   :members:
   :undoc-members:
   :show-inheritance:

Image Processing Tools
----------------------

.. automodule:: pygeai_orchestration.tools.builtin.image_tools
   :members:
   :undoc-members:
   :show-inheritance:

Document Extraction Tools
-------------------------

.. automodule:: pygeai_orchestration.tools.builtin.document_extraction
   :members:
   :undoc-members:
   :show-inheritance:

Utility Tools
-------------

.. automodule:: pygeai_orchestration.tools.builtin.utilities
   :members:
   :undoc-members:
   :show-inheritance:
