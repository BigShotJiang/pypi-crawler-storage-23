Core Module
===========

The core module provides the foundational classes and utilities for building orchestration workflows.

Base Classes
------------

Agents
~~~~~~

.. automodule:: pygeai_orchestration.core.base.agent
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: pygeai_orchestration.core.base.geai_agent.GEAIAgent
   :members:
   :undoc-members:
   :show-inheritance:

Patterns
~~~~~~~~

.. automodule:: pygeai_orchestration.core.base.pattern
   :members:
   :undoc-members:
   :show-inheritance:

Tools
~~~~~

.. automodule:: pygeai_orchestration.core.base.tool
   :members:
   :undoc-members:
   :show-inheritance:

Orchestrators
~~~~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.base.orchestrator
   :members:
   :undoc-members:
   :show-inheritance:

Common Utilities
----------------

State Management
~~~~~~~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.common.state
   :members:
   :undoc-members:
   :show-inheritance:

Memory Management
~~~~~~~~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.common.memory
   :members:
   :undoc-members:
   :show-inheritance:

Context Management
~~~~~~~~~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.common.context
   :members:
   :undoc-members:
   :show-inheritance:

Messages
~~~~~~~~

.. automodule:: pygeai_orchestration.core.common.message
   :members:
   :undoc-members:
   :show-inheritance:

Error Handling
--------------

Handlers
~~~~~~~~

.. automodule:: pygeai_orchestration.core.handlers
   :members:
   :undoc-members:
   :show-inheritance:

Utilities
---------

Configuration
~~~~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.utils.config
   :members:
   :undoc-members:
   :show-inheritance:

Validators
~~~~~~~~~~

.. automodule:: pygeai_orchestration.core.utils.validators
   :members:
   :undoc-members:
   :show-inheritance:
