Plugin System
=============

The ``geai-orch`` CLI includes a **plugin system** that allows you to create and use custom orchestration patterns without modifying the core codebase.

Overview
--------

The plugin system provides:

* **Automatic Discovery**: Patterns are automatically discovered from the plugins directory
* **Zero Configuration**: Drop a Python file in the plugins folder and it's immediately available
* **CLI Integration**: Custom patterns become CLI commands automatically
* **Pattern Validation**: Ensures plugins implement the required interface

Quick Start
-----------

Create a custom pattern plugin in 3 simple steps:

Step 1: Create Plugin Directory
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: bash

    mkdir -p ~/.geai-orch/plugins/

Step 2: Create Your Pattern
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Create a Python file that inherits from ``BasePattern``:

.. code-block:: python

    # ~/.geai-orch/plugins/my_pattern.py
    from typing import Any, Dict, Optional
    from pygeai_orchestration.core.base import BasePattern, PatternConfig, PatternResult

    class MyCustomPattern(BasePattern):
        """Short description of what this pattern does."""
        
        def __init__(self, agent, config: PatternConfig):
            super().__init__(config)
            self.agent = agent
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            self.reset()
            
            try:
                # Your pattern logic here
                result = await self.agent.generate(task)
                
                return PatternResult(
                    success=True,
                    result=result,
                    iterations=self.current_iteration
                )
            except Exception as e:
                return PatternResult(
                    success=False,
                    error=str(e)
                )
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            # Implement step logic if needed
            return state

Step 3: Use It Via CLI
~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: bash

    # Pattern is automatically discovered and available!
    geai-orch my-custom --task "Solve this problem"
    
    # Use with custom model
    geai-orch my-custom --task "..." --model openai/gpt-4o
    
    # Configure max iterations
    geai-orch my-custom --task "..." --max-iterations 10

Plugin Management
-----------------

List Plugins
~~~~~~~~~~~~

See all discovered custom patterns:

.. code-block:: bash

    geai-orch plugins list

Output:

.. code-block:: text

    Custom Patterns (2):
    ================================================================================
    
      debate
        Description: Custom pattern implementing adversarial debate between two viewpoints.
        Class: DebatePattern
        Source: /Users/user/.geai-orch/plugins/debate_pattern.py
    
      chain-of-thought
        Description: Break down complex problems into explicit reasoning steps.
        Class: ChainOfThoughtPattern
        Source: /Users/user/.geai-orch/plugins/chain_of_thought_pattern.py
    
    ================================================================================
    Plugin directory: /Users/user/.geai-orch/plugins

Get Plugin Info
~~~~~~~~~~~~~~~

Get detailed information about a specific pattern:

.. code-block:: bash

    geai-orch plugins info --name debate

Output shows:

* Full class name
* Complete docstring
* Source file location
* Usage examples

Pattern Naming
--------------

Class names are automatically converted to CLI-friendly names using kebab-case:

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - Class Name
     - CLI Command
   * - ``MyCustomPattern``
     - ``my-custom``
   * - ``ChainOfThoughtPattern``
     - ``chain-of-thought``
   * - ``DebatePattern``
     - ``debate``
   * - ``TreeOfThoughtPattern``
     - ``tree-of-thought``

The ``Pattern`` suffix is automatically removed if present.

Creating Plugins
----------------

Requirements
~~~~~~~~~~~~

A valid plugin must:

1. Inherit from ``BasePattern``
2. Implement ``execute()`` method (async)
3. Implement ``step()`` method (async)
4. Accept ``agent`` and ``config`` in ``__init__()``
5. Include a docstring (first line becomes CLI description)

Complete Example
~~~~~~~~~~~~~~~~

Here's a complete example implementing a debate pattern:

.. code-block:: python

    # ~/.geai-orch/plugins/debate_pattern.py
    from typing import Any, Dict, Optional, List
    from pygeai_orchestration.core.base import BasePattern, PatternConfig, PatternResult

    class DebatePattern(BasePattern):
        """Generate arguments for and against a topic, then synthesize conclusion."""
        
        def __init__(self, agent, config: PatternConfig):
            super().__init__(config)
            self.agent = agent
            self._arguments_for: List[str] = []
            self._arguments_against: List[str] = []
        
        async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> PatternResult:
            """
            Execute the debate pattern.
            
            :param task: The debate topic
            :param context: Optional context
            :return: PatternResult with conclusion
            """
            self.reset()
            
            try:
                # Generate arguments (use max_iterations for debate rounds)
                for i in range(self.config.max_iterations):
                    self.increment_iteration()
                    
                    state = {
                        "task": task,
                        "iteration": self.current_iteration,
                        "arguments_for": self._arguments_for,
                        "arguments_against": self._arguments_against,
                    }
                    
                    step_result = await self.step(state)
                    self._arguments_for.append(step_result["for_argument"])
                    self._arguments_against.append(step_result["against_argument"])
                
                # Synthesize conclusion
                synthesis_prompt = f"""
    Given this debate on: {task}
    
    Arguments FOR:
    {chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_for))}
    
    Arguments AGAINST:
    {chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_against))}
    
    Provide a balanced conclusion considering both perspectives.
    """
                
                conclusion = await self.agent.generate(synthesis_prompt)
                
                return PatternResult(
                    success=True,
                    result=conclusion,
                    iterations=self.current_iteration,
                    metadata={
                        "arguments_for": self._arguments_for,
                        "arguments_against": self._arguments_against,
                    }
                )
            
            except Exception as e:
                return PatternResult(success=False, error=str(e))
        
        async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
            """
            Execute one debate round.
            
            :param state: Current state with task and existing arguments
            :return: New arguments for and against
            """
            task = state["task"]
            
            # Generate FOR argument
            for_prompt = f"Topic: {task}\\n\\nGenerate a strong argument SUPPORTING this topic."
            for_argument = await self.agent.generate(for_prompt)
            
            # Generate AGAINST argument
            against_prompt = f"Topic: {task}\\n\\nGenerate a strong argument OPPOSING this topic."
            against_argument = await self.agent.generate(against_prompt)
            
            return {
                "for_argument": for_argument,
                "against_argument": against_argument
            }
        
        def reset(self) -> None:
            """Reset pattern state."""
            super().reset()
            self._arguments_for = []
            self._arguments_against = []

Usage:

.. code-block:: bash

    geai-orch debate --task "Remote work should be the default" --max-iterations 3

Using Existing Examples
~~~~~~~~~~~~~~~~~~~~~~~~

The ``snippets/custom/`` directory contains working examples you can use immediately:

.. code-block:: bash

    # Copy all examples
    cp snippets/custom/*.py ~/.geai-orch/plugins/
    
    # Or copy specific patterns
    cp snippets/custom/debate_pattern.py ~/.geai-orch/plugins/
    cp snippets/custom/chain_of_thought_pattern.py ~/.geai-orch/plugins/

Available examples:

* ``debate_pattern.py`` - Adversarial debate with synthesis
* ``chain_of_thought_pattern.py`` - Explicit step-by-step reasoning  
* ``iterative_refinement_pattern.py`` - Quality-based iterative improvement
* ``consensus_pattern.py`` - Multi-perspective consensus building

Configuration
-------------

Plugin Directory
~~~~~~~~~~~~~~~~

Default plugin directory: ``~/.geai-orch/plugins/``

Override with environment variable:

.. code-block:: bash

    export GEAI_ORCH_PLUGINS_DIR=/path/to/my/plugins
    geai-orch plugins list

Pattern Options
~~~~~~~~~~~~~~~

All plugin patterns support these CLI options:

* ``--task`` / ``-t``: Task description (required)
* ``--model`` / ``-m``: Model to use (default: ``openai/gpt-4o-mini``)
* ``--max-iterations`` / ``-i``: Maximum iterations (default: 5)

Example:

.. code-block:: bash

    geai-orch my-pattern \\
        --task "Analyze this problem" \\
        --model openai/gpt-4o \\
        --max-iterations 10

Best Practices
--------------

Documentation
~~~~~~~~~~~~~

* Always include a docstring in your pattern class
* First line of docstring becomes the CLI description
* Document parameters in ``execute()`` and ``step()``

State Management
~~~~~~~~~~~~~~~~

* Store pattern-specific state in instance variables
* Reset all state in ``reset()`` method override
* Don't rely on external state between executions

Error Handling
~~~~~~~~~~~~~~

* Always wrap ``execute()`` in try/except
* Return ``PatternResult`` with ``success=False`` on errors
* Include helpful error messages in ``error`` field

.. code-block:: python

    try:
        # Pattern logic
        return PatternResult(success=True, result=output)
    except Exception as e:
        return PatternResult(
            success=False,
            error=f"Pattern execution failed: {str(e)}",
            iterations=self.current_iteration
        )

Iteration Control
~~~~~~~~~~~~~~~~~

* Call ``self.reset()`` at start of ``execute()``
* Use ``self.increment_iteration()`` in loops
* Check ``self.current_iteration < self.config.max_iterations``

.. code-block:: python

    async def execute(self, task: str, context=None) -> PatternResult:
        self.reset()  # Reset counter
        
        while self.current_iteration < self.config.max_iterations:
            self.increment_iteration()
            # Do work...

Metadata
~~~~~~~~

Include useful debugging information in result metadata:

.. code-block:: python

    return PatternResult(
        success=True,
        result=final_output,
        iterations=self.current_iteration,
        metadata={
            "intermediate_results": self._history,
            "quality_scores": self._scores,
            "custom_data": self._data,
        }
    )

Troubleshooting
---------------

Plugin Not Discovered
~~~~~~~~~~~~~~~~~~~~~~

If your plugin doesn't appear in ``geai-orch plugins list``:

1. Check file is in correct directory: ``ls ~/.geai-orch/plugins/``
2. Check file ends with ``.py`` and doesn't start with ``_``
3. Check class inherits from ``BasePattern``
4. Check class is defined in the file (not imported)
5. Run with ``--verbose`` to see discovery errors:

.. code-block:: bash

    geai-orch --verbose plugins list

Validation Errors
~~~~~~~~~~~~~~~~~

If plugin fails validation, common issues:

* Missing ``execute()`` or ``step()`` methods
* Methods not declared as ``async``
* ``__init__()`` doesn't accept ``config`` parameter
* Not inheriting from ``BasePattern``

Check logs with ``--verbose`` for specific validation errors.

Import Errors
~~~~~~~~~~~~~

If plugin file has import errors:

* Ensure ``pygeai-orchestration`` is installed
* Check all imports are available
* Plugin directory is not a Python package (no ``__init__.py`` needed)

Next Steps
----------

* See :doc:`custom_patterns` for detailed pattern development guide
* See :doc:`patterns` for built-in pattern examples
* Check ``snippets/custom/`` for working plugin examples

---

**Plugin system makes it trivial to extend geai-orch with your own patterns!**
