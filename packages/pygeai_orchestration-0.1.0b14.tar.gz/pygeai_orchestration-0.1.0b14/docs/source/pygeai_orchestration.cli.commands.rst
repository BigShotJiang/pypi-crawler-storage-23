pygeai\_orchestration.cli.commands package
==========================================

Submodules
----------

pygeai\_orchestration.cli.commands.base module
----------------------------------------------

.. automodule:: pygeai_orchestration.cli.commands.base
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.commands.patterns module
--------------------------------------------------

.. automodule:: pygeai_orchestration.cli.commands.patterns
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.commands.plugins module
-------------------------------------------------

.. automodule:: pygeai_orchestration.cli.commands.plugins
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.cli.commands.tools module
-----------------------------------------------

.. automodule:: pygeai_orchestration.cli.commands.tools
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai_orchestration.cli.commands
   :members:
   :show-inheritance:
   :undoc-members:
