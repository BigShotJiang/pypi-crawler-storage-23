pygeai\_orchestration.patterns package
======================================

Submodules
----------

pygeai\_orchestration.patterns.multi\_agent module
--------------------------------------------------

.. automodule:: pygeai_orchestration.patterns.multi_agent
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.patterns.planning module
----------------------------------------------

.. automodule:: pygeai_orchestration.patterns.planning
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.patterns.react module
-------------------------------------------

.. automodule:: pygeai_orchestration.patterns.react
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.patterns.reflection module
------------------------------------------------

.. automodule:: pygeai_orchestration.patterns.reflection
   :members:
   :show-inheritance:
   :undoc-members:

pygeai\_orchestration.patterns.tool\_use module
-----------------------------------------------

.. automodule:: pygeai_orchestration.patterns.tool_use
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai_orchestration.patterns
   :members:
   :show-inheritance:
   :undoc-members:
