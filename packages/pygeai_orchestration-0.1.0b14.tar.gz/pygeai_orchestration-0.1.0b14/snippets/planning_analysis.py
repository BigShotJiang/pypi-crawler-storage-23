"""
Planning Pattern - Data Analysis Planning

Demonstrates using the PlanningPattern for structuring data analysis workflows,
including data collection, cleaning, exploration, and visualization steps.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import PlanningPattern


async def main():
    agent_config = AgentConfig(
        name="data_analyst",
        model="openai/gpt-4o-mini",
        temperature=0.4,
        system_prompt="You are a data analyst who creates comprehensive analysis plans with clear methodologies."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="analysis_planning",
        pattern_type=PatternType.PLANNING,
        max_iterations=1
    )
    
    pattern = PlanningPattern(agent=agent, config=pattern_config)
    
    task = """
    Plan a comprehensive analysis for customer churn prediction using a dataset with:
    - Customer demographics (age, location, account age)
    - Usage metrics (login frequency, features used, support tickets)
    - Transaction history (purchase amount, frequency, last purchase date)
    
    Include: data preprocessing, feature engineering, model selection, evaluation metrics.
    """
    
    print("Data Analysis Planning Task\n")
    
    result = await pattern.execute(task)
    
    print(f"\nPlanning Complete: {result.success}")
    print(f"\nAnalysis Plan:\n{result.result}")


if __name__ == "__main__":
    asyncio.run(main())
