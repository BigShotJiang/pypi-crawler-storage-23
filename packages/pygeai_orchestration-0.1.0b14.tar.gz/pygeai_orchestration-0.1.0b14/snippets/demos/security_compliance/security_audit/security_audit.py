#!/usr/bin/env python3
"""
Security Audit Tool

Scans codebase for security issues including hardcoded secrets, insecure patterns,
and sensitive data. Uses ReActPattern to reason about findings and generate
comprehensive security reports.
"""

import asyncio
import json
import re
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.file_tools import FileSearchTool, FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool
from pygeai_orchestration.tools.builtin.utilities import HashTool, ValidationTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_codebase(config):
    """Create sample codebase with security issues."""
    target_dir = Path(config["audit"]["target_dir"])
    target_dir.mkdir(parents=True, exist_ok=True)
    
    sample_files = {
        "app.py": """import os

API_KEY = "fakeapikey_abc123def456ghi789jkl012mno345pqr678"
DATABASE_URL = "postgresql://user:password@localhost/db"

def connect():
    token = "ghp_1234567890abcdefghijklmnopqrstuvwx"
    return token
""",
        "config.py": """
DEBUG = True
SECRET_KEY = "django-insecure-hardcoded-secret-key-12345"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

database = {
    'user': 'admin',
    'password': 'admin123'
}
""",
        "utils.py": """
def safe_function():
    return "This is safe"

def process_data(data):
    result = data.strip()
    return result
""",
        "api_client.js": """
const apiKey = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9';
const secretToken = 'my-secret-token-12345';

function authenticate() {
    return apiKey;
}
""",
        ".env.example": """
API_KEY=your-api-key-here
DATABASE_URL=your-database-url
""",
        "secure_module.py": """
import os
from getpass import getpass

def get_credentials():
    api_key = os.environ.get('API_KEY')
    if not api_key:
        raise ValueError('API_KEY not set')
    return api_key
"""
    }
    
    for file_path, content in sample_files.items():
        full_path = target_dir / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, 'w') as f:
            f.write(content)
    
    print(f"Created sample codebase with {len(sample_files)} files at {target_dir}")


async def main():
    """Execute the security audit workflow."""
    config = load_config()
    
    print("=" * 70)
    print("SECURITY AUDIT TOOL")
    print("=" * 70)
    print()
    
    await create_sample_codebase(config)
    
    search_tool = FileSearchTool()
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    hash_tool = HashTool()
    writer_tool = FileWriterTool()
    template_tool = TemplateRendererTool()
    
    print("\nScanning codebase for security issues...")
    
    target_extensions = config["audit"]["file_extensions"]
    pattern = "|".join(f"*{ext}" for ext in target_extensions)
    
    search_result = await search_tool.execute(
        directory=config["audit"]["target_dir"],
        pattern="*",
        recursive=True
    )
    
    if not search_result.success:
        print(f"Error searching files: {search_result.error}")
        return
    
    all_files = [f for f in search_result.result if any(f.endswith(ext) for ext in target_extensions)]
    print(f"Found {len(all_files)} files to audit")
    
    findings = []
    files_scanned = 0
    
    for file_path in all_files:
        files_scanned += 1
        
        read_result = await reader_tool.execute(
            path=file_path
        )
        
        if not read_result.success:
            continue
        
        content = read_result.result
        lines = content.split('\n')
        
        for pattern in config["audit"]["secret_patterns"]:
            regex_result = await regex_tool.execute(
                pattern=pattern,
                text=content,
                operation="findall",
                flags=["IGNORECASE"]
            )
            
            if regex_result.success and regex_result.result:
                for match in regex_result.result:
                    for line_num, line in enumerate(lines, 1):
                        if match in line:
                            finding = {
                                "file": file_path,
                                "line": line_num,
                                "pattern": pattern,
                                "severity": "HIGH",
                                "category": "Hardcoded Secret",
                                "description": f"Potential hardcoded secret matching pattern: {pattern}",
                                "context": line.strip()
                            }
                            
                            if config["settings"]["hash_sensitive_data"]:
                                hash_result = await hash_tool.execute(
                                    operation="string",
                                    data=match,
                                    algorithm="sha256"
                                )
                                if hash_result.success:
                                    finding["value_hash"] = hash_result.result[:16]
                            
                            findings.append(finding)
    
    findings.sort(key=lambda x: (x["severity"], x["file"]))
    
    high_severity = sum(1 for f in findings if f["severity"] == "HIGH")
    medium_severity = sum(1 for f in findings if f["severity"] == "MEDIUM")
    low_severity = sum(1 for f in findings if f["severity"] == "LOW")
    
    audit_report = {
        "audit_info": {
            "timestamp": datetime.now().isoformat(),
            "target_directory": config["audit"]["target_dir"],
            "files_scanned": files_scanned,
            "patterns_checked": len(config["audit"]["secret_patterns"])
        },
        "summary": {
            "total_findings": len(findings),
            "high_severity": high_severity,
            "medium_severity": medium_severity,
            "low_severity": low_severity
        },
        "findings": findings,
        "recommendations": [
            "Remove all hardcoded secrets from source code",
            "Use environment variables for sensitive configuration",
            "Implement secrets management system (e.g., HashiCorp Vault)",
            "Add pre-commit hooks to prevent secret commits",
            "Rotate any exposed credentials immediately"
        ]
    }
    
    report_json = json.dumps(audit_report, indent=2)
    
    json_write_result = await writer_tool.execute(
        path=config["paths"]["report_file"],
        content=report_json,
        mode="write"
    )
    
    if json_write_result.success:
        print(f"\nJSON report saved: {config['paths']['report_file']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Security Audit Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #c0392b; border-bottom: 3px solid #c0392b; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .metric { display: inline-block; margin: 10px 20px 10px 0; }
        .metric-value { font-size: 32px; font-weight: bold; }
        .metric-label { font-size: 14px; color: #666; }
        .high { color: #c0392b; }
        .medium { color: #f39c12; }
        .low { color: #3498db; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .finding-high { border-left: 4px solid #c0392b; background: #fef5f5; }
        .recommendations { background: #fff3cd; padding: 20px; border-left: 4px solid #ffc107; margin: 20px 0; }
    </style>
</head>
<body>
    <h1>Security Audit Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Target Directory:</strong> {{ target_dir }}</p>
    <p><strong>Files Scanned:</strong> {{ files_scanned }}</p>
    
    <div class="summary">
        <h2>Summary</h2>
        <div class="metric">
            <div class="metric-value high">{{ high_severity }}</div>
            <div class="metric-label">High Severity</div>
        </div>
        <div class="metric">
            <div class="metric-value medium">{{ medium_severity }}</div>
            <div class="metric-label">Medium Severity</div>
        </div>
        <div class="metric">
            <div class="metric-value low">{{ low_severity }}</div>
            <div class="metric-label">Low Severity</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ total_findings }}</div>
            <div class="metric-label">Total Findings</div>
        </div>
    </div>
    
    <h2>Findings</h2>
    <table>
        <thead>
            <tr>
                <th>Severity</th>
                <th>File</th>
                <th>Line</th>
                <th>Category</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
        {% for finding in findings %}
            <tr class="finding-{{ finding.severity|lower }}">
                <td><strong class="{{ finding.severity|lower }}">{{ finding.severity }}</strong></td>
                <td>{{ finding.file }}</td>
                <td>{{ finding.line }}</td>
                <td>{{ finding.category }}</td>
                <td>{{ finding.description }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <div class="recommendations">
        <h2>Recommendations</h2>
        <ul>
        {% for rec in recommendations %}
            <li>{{ rec }}</li>
        {% endfor %}
        </ul>
    </div>
</body>
</html>"""
    
    html_data = {
        "timestamp": audit_report["audit_info"]["timestamp"],
        "target_dir": audit_report["audit_info"]["target_directory"],
        "files_scanned": audit_report["audit_info"]["files_scanned"],
        "total_findings": audit_report["summary"]["total_findings"],
        "high_severity": audit_report["summary"]["high_severity"],
        "medium_severity": audit_report["summary"]["medium_severity"],
        "low_severity": audit_report["summary"]["low_severity"],
        "findings": findings,
        "recommendations": audit_report["recommendations"]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        html_write_result = await writer_tool.execute(
            path=config["paths"]["html_report"],
            content=html_result.result,
            mode="write"
        )
        if html_write_result.success:
            print(f"HTML report saved: {config['paths']['html_report']}")
    
    print()
    print("=" * 70)
    print("AUDIT SUMMARY")
    print("=" * 70)
    print(f"Files Scanned: {files_scanned}")
    print(f"Total Findings: {len(findings)}")
    print(f"  - High Severity: {high_severity}")
    print(f"  - Medium Severity: {medium_severity}")
    print(f"  - Low Severity: {low_severity}")
    
    if high_severity > 0:
        print("\nCRITICAL: High severity issues found!")
        print("Action required: Review and remediate immediately")
    
    print()
    print("Reports generated:")
    print(f"  - {config['paths']['report_file']}")
    print(f"  - {config['paths']['html_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
