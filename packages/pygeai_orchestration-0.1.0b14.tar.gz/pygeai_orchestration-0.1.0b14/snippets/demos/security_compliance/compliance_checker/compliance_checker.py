#!/usr/bin/env python3
"""
Compliance Checker

Validates organizational policies and documentation against compliance standards.
Uses PlanningPattern to orchestrate multi-standard compliance verification.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import FileSearchTool, FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, ValidationTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_policies(config):
    """Create sample policy documents."""
    policies_dir = Path(config["paths"]["policy_docs_dir"])
    policies_dir.mkdir(parents=True, exist_ok=True)
    
    policies = {
        "data_security_policy.txt": """DATA SECURITY POLICY

1. Data Encryption
All sensitive data must be encrypted at rest using AES-256 encryption.
Data in transit must use TLS 1.2 or higher for secure transmission.

2. Access Control
Role-based access control (RBAC) is mandatory for all systems.
Users must authenticate using multi-factor authentication for sensitive systems.
Authorization levels must be reviewed quarterly.

3. Password Requirements
Passwords must be at least 12 characters long.
Passwords must include uppercase, lowercase, numbers, and special characters.
Passwords must be changed every 90 days.

4. Audit Logging
All access to sensitive data must be logged.
Audit logs must be retained for minimum 2 years.
Logs must track user actions, timestamps, and data accessed.
""",
        "privacy_policy.txt": """PRIVACY AND DATA PROTECTION POLICY

1. Data Collection
Personal data collection must be limited to necessary information only.
Users must provide explicit consent before data collection.
Purpose of data collection must be clearly communicated.

2. Data Retention
Personal data retention periods must be documented.
Data must be deleted after retention period expires.
Archive procedures must comply with legal requirements.

3. Data Subject Rights
Users have the right to access their personal data.
Users can request deletion of their data.
Data portability must be supported.

4. International Transfers
Cross-border data transfers require appropriate safeguards.
""",
        "incident_response.txt": """INCIDENT RESPONSE PLAN

1. Incident Detection
Security monitoring tools must be in place 24/7.
Automated alerts for suspicious activities.
Regular security assessments and penetration testing.

2. Response Procedures
Incident response team must be notified within 1 hour.
Initial assessment within 2 hours of detection.
Containment actions must be documented.

3. Breach Notification
Data breaches must be reported to authorities within 72 hours.
Affected individuals must be notified without undue delay.
Breach details must be documented in incident log.

4. Post-Incident Review
Root cause analysis required for all incidents.
Lessons learned must be documented.
Preventive measures must be implemented.
"""
    }
    
    for filename, content in policies.items():
        file_path = policies_dir / filename
        with open(file_path, 'w') as f:
            f.write(content)
    
    print(f"Created {len(policies)} sample policy documents at {policies_dir}")


async def main():
    """Execute compliance checking workflow."""
    config = load_config()
    
    print("=" * 70)
    print("COMPLIANCE CHECKER")
    print("=" * 70)
    print()
    
    await create_sample_policies(config)
    
    search_tool = FileSearchTool()
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    validation_tool = ValidationTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing compliance database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["compliance_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS compliance_checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            check_name TEXT NOT NULL,
            requirement TEXT NOT NULL,
            status TEXT NOT NULL,
            evidence TEXT,
            document_source TEXT
        )
        """
    )
    
    print("Searching for policy documents...")
    
    search_result = await search_tool.execute(
        directory=config["paths"]["policy_docs_dir"],
        pattern="*.txt",
        recursive=False
    )
    
    if not search_result.success:
        print(f"Error searching policies: {search_result.error}")
        return
    
    policy_files = search_result.result
    print(f"Found {len(policy_files)} policy documents")
    
    all_policies_text = []
    
    for policy_file in policy_files:
        read_result = await reader_tool.execute(path=policy_file)
        if read_result.success:
            all_policies_text.append({
                "file": Path(policy_file).name,
                "content": read_result.result
            })
    
    combined_text = " ".join([p["content"] for p in all_policies_text])
    
    print("\nPerforming compliance checks...")
    
    compliance_results = []
    
    for check_name, check_config in config["compliance"]["checks"].items():
        print(f"  Checking {check_name.replace('_', ' ').title()}...", end=" ")
        
        patterns = check_config["patterns"]
        found_patterns = []
        evidence_docs = []
        
        for pattern in patterns:
            pattern_regex = pattern.replace(" ", r"\s+")
            
            search_result = await regex_tool.execute(
                pattern=pattern_regex,
                text=combined_text,
                operation="search",
                flags=["IGNORECASE"]
            )
            
            if search_result.success and search_result.result:
                found_patterns.append(pattern)
                
                for policy in all_policies_text:
                    if pattern.lower() in policy["content"].lower():
                        if policy["file"] not in evidence_docs:
                            evidence_docs.append(policy["file"])
        
        coverage = (len(found_patterns) / len(patterns) * 100) if patterns else 0
        
        if coverage >= 75:
            status = "COMPLIANT"
            print("COMPLIANT")
        elif coverage >= 50:
            status = "PARTIAL"
            print("PARTIAL")
        else:
            status = "NON-COMPLIANT"
            print("NON-COMPLIANT")
        
        result = {
            "check_name": check_name,
            "requirement": check_name.replace("_", " ").title(),
            "required": check_config["required"],
            "patterns_required": len(patterns),
            "patterns_found": len(found_patterns),
            "coverage_percent": round(coverage, 1),
            "status": status,
            "evidence": ", ".join(found_patterns) if found_patterns else "None",
            "source_documents": ", ".join(evidence_docs) if evidence_docs else "None"
        }
        
        compliance_results.append(result)
        
        await sqlite_tool.execute(
            database=config["paths"]["compliance_db"],
            operation="execute",
            query="""
            INSERT INTO compliance_checks (timestamp, check_name, requirement, status, evidence, document_source)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            params=(
                datetime.now().isoformat(),
                check_name,
                result["requirement"],
                status,
                result["evidence"],
                result["source_documents"]
            )
        )
    
    compliant_count = len([r for r in compliance_results if r["status"] == "COMPLIANT"])
    partial_count = len([r for r in compliance_results if r["status"] == "PARTIAL"])
    non_compliant_count = len([r for r in compliance_results if r["status"] == "NON-COMPLIANT"])
    
    overall_compliance = (compliant_count / len(compliance_results) * 100) if compliance_results else 0
    
    print("\nGenerating compliance report...")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Compliance Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .score-box { display: inline-block; padding: 20px 40px; margin: 10px; border-radius: 5px; text-align: center; }
        .score-value { font-size: 36px; font-weight: bold; }
        .score-label { font-size: 14px; margin-top: 5px; }
        .compliant { background: #d4edda; color: #155724; }
        .partial { background: #fff3cd; color: #856404; }
        .non-compliant { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .status-badge { padding: 5px 10px; border-radius: 3px; font-weight: bold; font-size: 12px; }
    </style>
</head>
<body>
    <h1>Compliance Assessment Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Standards Checked:</strong> {{ standards }}</p>
    
    <div class="summary">
        <h2>Overall Compliance</h2>
        <div class="score-box {% if overall >= 80 %}compliant{% elif overall >= 60 %}partial{% else %}non-compliant{% endif %}">
            <div class="score-value">{{ overall }}%</div>
            <div class="score-label">Compliance Score</div>
        </div>
        <div class="score-box compliant">
            <div class="score-value">{{ compliant }}</div>
            <div class="score-label">Compliant</div>
        </div>
        <div class="score-box partial">
            <div class="score-value">{{ partial }}</div>
            <div class="score-label">Partial</div>
        </div>
        <div class="score-box non-compliant">
            <div class="score-value">{{ non_compliant }}</div>
            <div class="score-label">Non-Compliant</div>
        </div>
    </div>
    
    <h2>Compliance Checks</h2>
    <table>
        <thead>
            <tr>
                <th>Requirement</th>
                <th>Coverage</th>
                <th>Status</th>
                <th>Evidence</th>
                <th>Source Documents</th>
            </tr>
        </thead>
        <tbody>
        {% for check in checks %}
            <tr>
                <td>{{ check.requirement }}</td>
                <td>{{ check.coverage_percent }}% ({{ check.patterns_found }}/{{ check.patterns_required }})</td>
                <td>
                    <span class="status-badge {{ check.status|lower|replace('_', '-') }}">
                        {{ check.status }}
                    </span>
                </td>
                <td>{{ check.evidence }}</td>
                <td>{{ check.source_documents }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>Recommendations</h2>
    <ul>
    {% for check in checks %}
        {% if check.status != 'COMPLIANT' %}
        <li>
            <strong>{{ check.requirement }}:</strong>
            {% if check.status == 'PARTIAL' %}
            Improve coverage by documenting additional controls
            {% else %}
            Create policies and procedures to address this requirement
            {% endif %}
        </li>
        {% endif %}
    {% endfor %}
    {% if compliant == checks|length %}
        <li>All compliance requirements are currently met. Maintain regular reviews.</li>
    {% endif %}
    </ul>
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "standards": ", ".join(config["compliance"]["standards"]),
        "overall": round(overall_compliance, 1),
        "compliant": compliant_count,
        "partial": partial_count,
        "non_compliant": non_compliant_count,
        "checks": compliance_results
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["compliance_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"Compliance report saved: {config['paths']['compliance_report']}")
    
    print()
    print("=" * 70)
    print("COMPLIANCE SUMMARY")
    print("=" * 70)
    print(f"Overall Compliance: {overall_compliance:.1f}%")
    print()
    print(f"Compliant: {compliant_count}")
    print(f"Partial: {partial_count}")
    print(f"Non-Compliant: {non_compliant_count}")
    print()
    print("Results by Requirement:")
    for result in compliance_results:
        status_symbol = "✓" if result["status"] == "COMPLIANT" else "⚠" if result["status"] == "PARTIAL" else "✗"
        print(f"  {status_symbol} {result['requirement']}: {result['status']} ({result['coverage_percent']}%)")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['compliance_db']}")
    print(f"  - HTML Report: {config['paths']['compliance_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
