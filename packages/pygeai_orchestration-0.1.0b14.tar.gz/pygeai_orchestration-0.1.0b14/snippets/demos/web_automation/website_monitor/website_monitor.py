#!/usr/bin/env python3
"""
Website Monitoring System

Monitors website availability and performance using HTTP requests and XPath validation.
Uses ReActPattern to reason about failures and generate alerts.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.web_tools import URLFetchTool, BeautifulSoupTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def setup_database(config):
    """Initialize monitoring database."""
    sqlite_tool = SQLiteTool()
    
    await sqlite_tool.execute(
        database=config["paths"]["results_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            site_name TEXT NOT NULL,
            url TEXT NOT NULL,
            status_code INTEGER,
            response_time_ms REAL,
            success INTEGER NOT NULL,
            error_message TEXT,
            xpath_validations TEXT
        )
        """
    )
    
    await sqlite_tool.execute(
        database=config["paths"]["results_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            site_name TEXT NOT NULL,
            alert_type TEXT NOT NULL,
            message TEXT NOT NULL
        )
        """
    )


async def check_website(target, config):
    """Perform health check on a single website."""
    http_tool = URLFetchTool()
    soup_tool = BeautifulSoupTool()
    
    check_result = {
        "timestamp": datetime.now().isoformat(),
        "site_name": target["name"],
        "url": target["url"],
        "status_code": None,
        "response_time_ms": None,
        "success": False,
        "error_message": None,
        "xpath_validations": []
    }
    
    start_time = datetime.now()
    
    http_result = await http_tool.execute(
        url=target["url"],
        method="GET",
        timeout=config["settings"]["timeout_seconds"]
    )
    
    end_time = datetime.now()
    response_time_ms = (end_time - start_time).total_seconds() * 1000
    
    check_result["response_time_ms"] = round(response_time_ms, 2)
    
    if http_result.success:
        response_data = http_result.result
        check_result["status_code"] = response_data.get("status_code")
        
        if 200 <= response_data.get("status_code", 0) < 300:
            check_result["success"] = True
            
            if "xpath_checks" in target and target["xpath_checks"]:
                html_content = response_data.get("text", "")
                
                for xpath_check in target["xpath_checks"]:
                    xpath_path = xpath_check["path"]
                    expected_text = xpath_check.get("expected_text")
                    
                    soup_result = await soup_tool.execute(
                        html=html_content,
                        operation="find",
                        selector=xpath_path.replace("//", "").replace("/", " ")
                    )
                    
                    xpath_validation = {
                        "path": xpath_path,
                        "found": soup_result.success and bool(soup_result.result),
                        "expected_text": expected_text,
                        "actual_text": None
                    }
                    
                    if soup_result.success and soup_result.result:
                        actual_text = soup_result.result[0].get("text", "").strip() if isinstance(soup_result.result, list) else str(soup_result.result).strip()
                        xpath_validation["actual_text"] = actual_text
                        
                        if expected_text and expected_text not in actual_text:
                            xpath_validation["match"] = False
                            check_result["success"] = False
                        else:
                            xpath_validation["match"] = True
                    else:
                        xpath_validation["match"] = False
                        check_result["success"] = False
                    
                    check_result["xpath_validations"].append(xpath_validation)
        else:
            check_result["success"] = False
            check_result["error_message"] = f"HTTP {response_data.get('status_code')}"
    else:
        check_result["error_message"] = str(http_result.error)
    
    return check_result


async def main():
    """Execute website monitoring workflow."""
    config = load_config()
    
    print("=" * 70)
    print("WEBSITE MONITORING SYSTEM")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    print("Initializing monitoring database...")
    await setup_database(config)
    
    sqlite_tool = SQLiteTool()
    writer_tool = FileWriterTool()
    template_tool = TemplateRendererTool()
    
    targets = config["monitoring"]["targets"]
    check_count = config["monitoring"]["check_count"]
    alert_threshold = config["monitoring"]["alert_threshold"]
    
    print(f"\nMonitoring {len(targets)} websites")
    print(f"Performing {check_count} checks per site")
    print()
    
    all_checks = []
    alerts = []
    
    for check_num in range(1, check_count + 1):
        print(f"Check {check_num}/{check_count}")
        
        for target in targets:
            print(f"  Checking {target['name']}...", end=" ")
            
            check_result = await check_website(target, config)
            all_checks.append(check_result)
            
            await sqlite_tool.execute(
                database=config["paths"]["results_db"],
                operation="execute",
                query="""
                INSERT INTO checks (timestamp, site_name, url, status_code, response_time_ms, success, error_message, xpath_validations)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                params=(
                    check_result["timestamp"],
                    check_result["site_name"],
                    check_result["url"],
                    check_result["status_code"],
                    check_result["response_time_ms"],
                    1 if check_result["success"] else 0,
                    check_result["error_message"],
                    json.dumps(check_result["xpath_validations"])
                )
            )
            
            if check_result["success"]:
                print(f"OK ({check_result['response_time_ms']}ms)")
            else:
                print(f"FAILED - {check_result['error_message']}")
        
        if check_num < check_count:
            await asyncio.sleep(1)
        
        print()
    
    print("Analyzing results...")
    
    for target in targets:
        site_checks = [c for c in all_checks if c["site_name"] == target["name"]]
        failed_checks = [c for c in site_checks if not c["success"]]
        
        if len(failed_checks) >= alert_threshold:
            alert = {
                "timestamp": datetime.now().isoformat(),
                "site_name": target["name"],
                "alert_type": "AVAILABILITY",
                "message": f"{len(failed_checks)}/{len(site_checks)} checks failed for {target['name']}"
            }
            alerts.append(alert)
            
            await sqlite_tool.execute(
                database=config["paths"]["results_db"],
                operation="execute",
                query="""
                INSERT INTO alerts (timestamp, site_name, alert_type, message)
                VALUES (?, ?, ?, ?)
                """,
                params=(alert["timestamp"], alert["site_name"], alert["alert_type"], alert["message"])
            )
        
        successful_checks = [c for c in site_checks if c["success"]]
        if successful_checks:
            avg_response_time = sum(c["response_time_ms"] for c in successful_checks) / len(successful_checks)
            
            if avg_response_time > 5000:
                alert = {
                    "timestamp": datetime.now().isoformat(),
                    "site_name": target["name"],
                    "alert_type": "PERFORMANCE",
                    "message": f"High average response time: {avg_response_time:.2f}ms for {target['name']}"
                }
                alerts.append(alert)
                
                await sqlite_tool.execute(
                    database=config["paths"]["results_db"],
                    operation="execute",
                    query="""
                    INSERT INTO alerts (timestamp, site_name, alert_type, message)
                    VALUES (?, ?, ?, ?)
                    """,
                    params=(alert["timestamp"], alert["site_name"], alert["alert_type"], alert["message"])
                )
    
    if alerts:
        alerts_json = json.dumps({"alerts": alerts}, indent=2)
        await writer_tool.execute(
            path=config["paths"]["alerts_log"],
            content=alerts_json,
            mode="write"
        )
        print(f"Generated {len(alerts)} alerts")
    
    stats_result = await sqlite_tool.execute(
        database=config["paths"]["results_db"],
        operation="query",
        query="""
        SELECT 
            site_name,
            COUNT(*) as total_checks,
            SUM(success) as successful_checks,
            AVG(response_time_ms) as avg_response_time,
            MIN(response_time_ms) as min_response_time,
            MAX(response_time_ms) as max_response_time
        FROM checks
        GROUP BY site_name
        """
    )
    
    site_stats = stats_result.result if stats_result.success else []
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Website Monitoring Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .success { color: #28a745; font-weight: bold; }
        .failure { color: #dc3545; font-weight: bold; }
        .alert { background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 10px 0; }
        .alert.critical { background: #f8d7da; border-left-color: #dc3545; }
    </style>
</head>
<body>
    <h1>Website Monitoring Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Monitoring Period:</strong> {{ check_count }} checks per site</p>
    
    <h2>Site Statistics</h2>
    <table>
        <thead>
            <tr>
                <th>Site Name</th>
                <th>Total Checks</th>
                <th>Successful</th>
                <th>Success Rate</th>
                <th>Avg Response Time</th>
                <th>Min/Max Time</th>
            </tr>
        </thead>
        <tbody>
        {% for stat in stats %}
            <tr>
                <td>{{ stat.site_name }}</td>
                <td>{{ stat.total_checks }}</td>
                <td class="{% if stat.successful_checks == stat.total_checks %}success{% else %}failure{% endif %}">
                    {{ stat.successful_checks }}/{{ stat.total_checks }}
                </td>
                <td>{{ (stat.successful_checks / stat.total_checks * 100) | round(1) }}%</td>
                <td>{{ stat.avg_response_time | round(2) }}ms</td>
                <td>{{ stat.min_response_time | round(2) }}ms / {{ stat.max_response_time | round(2) }}ms</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    {% if alerts %}
    <h2>Alerts ({{ alerts|length }})</h2>
    {% for alert in alerts %}
    <div class="alert {% if alert.alert_type == 'AVAILABILITY' %}critical{% endif %}">
        <strong>[{{ alert.alert_type }}]</strong> {{ alert.message }}
        <br><small>{{ alert.timestamp }}</small>
    </div>
    {% endfor %}
    {% else %}
    <div class="summary">
        <h2>No Alerts</h2>
        <p>All monitored websites are performing within expected parameters.</p>
    </div>
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "check_count": check_count,
        "stats": site_stats,
        "alerts": alerts
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["status_report"],
            content=html_result.result,
            mode="write"
        )
    
    print()
    print("=" * 70)
    print("MONITORING SUMMARY")
    print("=" * 70)
    
    for stat in site_stats:
        success_rate = (stat["successful_checks"] / stat["total_checks"] * 100) if stat["total_checks"] > 0 else 0
        print(f"\n{stat['site_name']}:")
        print(f"  Success Rate: {success_rate:.1f}% ({stat['successful_checks']}/{stat['total_checks']})")
        print(f"  Avg Response: {stat['avg_response_time']:.2f}ms")
        print(f"  Range: {stat['min_response_time']:.2f}ms - {stat['max_response_time']:.2f}ms")
    
    if alerts:
        print(f"\nAlerts Generated: {len(alerts)}")
        for alert in alerts:
            print(f"  [{alert['alert_type']}] {alert['message']}")
    else:
        print("\nNo alerts - all systems operational")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['results_db']}")
    print(f"  - Status Report: {config['paths']['status_report']}")
    if alerts:
        print(f"  - Alerts Log: {config['paths']['alerts_log']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
