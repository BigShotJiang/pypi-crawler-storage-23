#!/usr/bin/env python3
"""
API Integration Tester

Automated testing of REST API endpoints with validation and performance monitoring.
Uses ToolUsePattern to execute HTTP requests and validate responses.
"""

import asyncio
import json
import csv
import time
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.tool_use import ToolUsePattern
from pygeai_orchestration.tools.builtin.web_tools import URLFetchTool
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import ValidationTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def main():
    """Execute API integration testing workflow."""
    config = load_config()
    
    print("=" * 70)
    print("API INTEGRATION TESTER")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    http_tool = URLFetchTool()
    json_tool = JSONParserTool()
    validation_tool = ValidationTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    base_url = config["api_testing"]["base_url"]
    endpoints = config["api_testing"]["endpoints"]
    
    print(f"Testing API: {base_url}")
    print(f"Total endpoints: {len(endpoints)}")
    print()
    
    test_results = []
    performance_data = []
    
    for endpoint_config in endpoints:
        test_name = endpoint_config["name"]
        method = endpoint_config["method"]
        path = endpoint_config["path"]
        url = base_url + path
        expected_status = endpoint_config.get("expected_status", 200)
        
        print(f"Testing: {test_name} ({method} {path})")
        
        test_result = {
            "name": test_name,
            "method": method,
            "url": url,
            "expected_status": expected_status,
            "timestamp": datetime.now().isoformat(),
            "passed": False,
            "errors": []
        }
        
        retries = 0
        max_retries = config["settings"]["max_retries"] if config["settings"]["retry_failed_tests"] else 0
        
        while retries <= max_retries:
            try:
                start_time = time.time()
                
                request_params = {
                    "url": url,
                    "method": method,
                    "timeout": config["settings"]["timeout_seconds"]
                }
                
                if "body" in endpoint_config:
                    request_params["data"] = endpoint_config["body"]
                    request_params["headers"] = {"Content-Type": "application/json"}
                
                response = await http_tool.execute(**request_params)
                
                end_time = time.time()
                response_time_ms = (end_time - start_time) * 1000
                
                test_result["response_time_ms"] = round(response_time_ms, 2)
                test_result["actual_status"] = response.status_code if hasattr(response, 'status_code') else None
                
                performance_data.append({
                    "endpoint": test_name,
                    "method": method,
                    "response_time_ms": test_result["response_time_ms"],
                    "timestamp": test_result["timestamp"]
                })
                
                if not response.success:
                    test_result["errors"].append(f"Request failed: {response.error}")
                    if retries < max_retries:
                        retries += 1
                        print(f"  Retry {retries}/{max_retries}...")
                        await asyncio.sleep(1)
                        continue
                    break
                
                status_code = response.status_code if hasattr(response, 'status_code') else 200
                
                if status_code != expected_status:
                    test_result["errors"].append(
                        f"Status mismatch: expected {expected_status}, got {status_code}"
                    )
                
                if "validation" in endpoint_config:
                    validation = endpoint_config["validation"]
                    
                    try:
                        response_data = json.loads(response.result) if isinstance(response.result, str) else response.result
                    except json.JSONDecodeError:
                        test_result["errors"].append("Response is not valid JSON")
                        break
                    
                    if "response_type" in validation:
                        expected_type = validation["response_type"]
                        
                        if expected_type == "array" and not isinstance(response_data, list):
                            test_result["errors"].append(f"Expected array response, got {type(response_data).__name__}")
                        elif expected_type == "object" and not isinstance(response_data, dict):
                            test_result["errors"].append(f"Expected object response, got {type(response_data).__name__}")
                    
                    if "min_items" in validation and isinstance(response_data, list):
                        min_items = validation["min_items"]
                        if len(response_data) < min_items:
                            test_result["errors"].append(
                                f"Expected at least {min_items} items, got {len(response_data)}"
                            )
                    
                    if "required_fields" in validation and isinstance(response_data, dict):
                        required_fields = validation["required_fields"]
                        missing_fields = [f for f in required_fields if f not in response_data]
                        
                        if missing_fields:
                            test_result["errors"].append(
                                f"Missing required fields: {', '.join(missing_fields)}"
                            )
                
                perf_thresholds = config["api_testing"]["performance_thresholds"]
                
                if response_time_ms > perf_thresholds["max_response_time_ms"]:
                    test_result["errors"].append(
                        f"Response time exceeded maximum threshold: {response_time_ms:.2f}ms > {perf_thresholds['max_response_time_ms']}ms"
                    )
                elif response_time_ms > perf_thresholds["acceptable_response_time_ms"]:
                    test_result["warnings"] = test_result.get("warnings", [])
                    test_result["warnings"].append(
                        f"Response time exceeded acceptable threshold: {response_time_ms:.2f}ms"
                    )
                
                if not test_result["errors"]:
                    test_result["passed"] = True
                    print(f"  PASSED ({response_time_ms:.2f}ms)")
                else:
                    print(f"  FAILED: {'; '.join(test_result['errors'])}")
                
                break
                
            except Exception as e:
                test_result["errors"].append(f"Exception: {str(e)}")
                if retries < max_retries:
                    retries += 1
                    print(f"  Retry {retries}/{max_retries}...")
                    await asyncio.sleep(1)
                    continue
                print(f"  FAILED: {str(e)}")
                break
        
        test_results.append(test_result)
    
    results_json = json.dumps({"test_results": test_results}, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["test_results"],
        content=results_json,
        mode="write"
    )
    
    print(f"\nTest results saved: {config['paths']['test_results']}")
    
    perf_csv_path = config["paths"]["performance_log"]
    
    with open(perf_csv_path, 'w', newline='') as f:
        if performance_data:
            writer = csv.DictWriter(f, fieldnames=performance_data[0].keys())
            writer.writeheader()
            writer.writerows(performance_data)
    
    print(f"Performance log saved: {perf_csv_path}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>API Integration Test Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .stat-box { display: inline-block; padding: 20px 40px; margin: 10px; border-radius: 5px; text-align: center; }
        .stat-value { font-size: 36px; font-weight: bold; }
        .stat-label { font-size: 14px; margin-top: 5px; }
        .passed { background: #d4edda; color: #155724; }
        .failed { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .status-passed { color: #155724; font-weight: bold; }
        .status-failed { color: #721c24; font-weight: bold; }
        .error-list { color: #721c24; font-size: 12px; }
        .warning-list { color: #856404; font-size: 12px; }
        .response-time { font-family: monospace; }
        .fast { color: #155724; }
        .slow { color: #856404; }
        .very-slow { color: #721c24; }
    </style>
</head>
<body>
    <h1>API Integration Test Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Base URL:</strong> {{ base_url }}</p>
    <p><strong>Total Tests:</strong> {{ total_tests }}</p>
    
    <div class="summary">
        <h2>Test Summary</h2>
        <div class="stat-box passed">
            <div class="stat-value">{{ passed_count }}</div>
            <div class="stat-label">PASSED</div>
        </div>
        <div class="stat-box failed">
            <div class="stat-value">{{ failed_count }}</div>
            <div class="stat-label">FAILED</div>
        </div>
        <div class="stat-box">
            <div class="stat-value">{{ success_rate }}%</div>
            <div class="stat-label">SUCCESS RATE</div>
        </div>
        <div class="stat-box">
            <div class="stat-value">{{ avg_response_time }}ms</div>
            <div class="stat-label">AVG RESPONSE TIME</div>
        </div>
    </div>
    
    <h2>Test Results</h2>
    <table>
        <thead>
            <tr>
                <th>Test Name</th>
                <th>Method</th>
                <th>Expected Status</th>
                <th>Actual Status</th>
                <th>Response Time</th>
                <th>Status</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
        {% for test in test_results %}
            <tr>
                <td>{{ test.name }}</td>
                <td><strong>{{ test.method }}</strong></td>
                <td>{{ test.expected_status }}</td>
                <td>{{ test.actual_status if test.actual_status else 'N/A' }}</td>
                <td class="response-time {% if test.response_time_ms %}{% if test.response_time_ms < 500 %}fast{% elif test.response_time_ms < 1000 %}slow{% else %}very-slow{% endif %}{% endif %}">
                    {{ test.response_time_ms if test.response_time_ms else 'N/A' }}ms
                </td>
                <td class="status-{{ 'passed' if test.passed else 'failed' }}">
                    {{ 'PASSED' if test.passed else 'FAILED' }}
                </td>
                <td>
                    {% if test.errors %}
                    <div class="error-list">
                        <strong>Errors:</strong>
                        <ul>
                        {% for error in test.errors %}
                            <li>{{ error }}</li>
                        {% endfor %}
                        </ul>
                    </div>
                    {% endif %}
                    {% if test.warnings %}
                    <div class="warning-list">
                        <strong>Warnings:</strong>
                        <ul>
                        {% for warning in test.warnings %}
                            <li>{{ warning }}</li>
                        {% endfor %}
                        </ul>
                    </div>
                    {% endif %}
                    {% if test.passed and not test.warnings %}
                    All validations passed
                    {% endif %}
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</body>
</html>"""
    
    passed_count = len([t for t in test_results if t["passed"]])
    failed_count = len([t for t in test_results if not t["passed"]])
    success_rate = round((passed_count / len(test_results) * 100) if test_results else 0, 1)
    
    response_times = [t["response_time_ms"] for t in test_results if "response_time_ms" in t]
    avg_response_time = round(sum(response_times) / len(response_times), 2) if response_times else 0
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "base_url": base_url,
        "total_tests": len(test_results),
        "passed_count": passed_count,
        "failed_count": failed_count,
        "success_rate": success_rate,
        "avg_response_time": avg_response_time,
        "test_results": test_results
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["test_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"Test report saved: {config['paths']['test_report']}")
    
    print()
    print("=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    print(f"Total Tests: {len(test_results)}")
    print(f"Passed: {passed_count}")
    print(f"Failed: {failed_count}")
    print(f"Success Rate: {success_rate}%")
    print(f"Average Response Time: {avg_response_time}ms")
    print()
    
    if failed_count > 0:
        print("Failed Tests:")
        for test in test_results:
            if not test["passed"]:
                print(f"  - {test['name']}: {'; '.join(test['errors'])}")
        print()
    
    print("Output files:")
    print(f"  - Test Results: {config['paths']['test_results']}")
    print(f"  - Performance Log: {config['paths']['performance_log']}")
    print(f"  - Test Report: {config['paths']['test_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
