#!/usr/bin/env python3
"""
SEO Analyzer

Analyzes websites for SEO best practices and provides recommendations.
Uses ReActPattern to analyze HTML content and identify SEO issues.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.web_tools import BeautifulSoupTool, URLFetchTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def main():
    """Execute SEO analysis workflow."""
    config = load_config()
    
    print("=" * 70)
    print("SEO ANALYZER")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    soup_tool = BeautifulSoupTool()
    url_tool = URLFetchTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("Initializing SEO database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["seo_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS seo_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            check_type TEXT NOT NULL,
            status TEXT NOT NULL,
            score INTEGER,
            issues_found INTEGER,
            analyzed_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    all_results = []
    all_issues = []
    
    for url in config["analysis"]["urls"]:
        print(f"\nAnalyzing: {url}")
        print("-" * 70)
        
        try:
            fetch_result = await url_tool.execute(
                url=url,
                method="GET",
                headers={"User-Agent": config["settings"]["user_agent"]},
                timeout=config["settings"]["timeout"]
            )
            
            if not fetch_result.success:
                print(f"  Error fetching URL: {fetch_result.error}")
                continue
            
            html_content = fetch_result.result
            
            parse_result = await soup_tool.execute(
                html=html_content,
                operation="parse"
            )
            
            if not parse_result.success:
                print(f"  Error parsing HTML: {parse_result.error}")
                continue
            
            url_issues = []
            url_scores = {}
            
            if "title_tags" in config["analysis"]["checks"]:
                print("  Checking title tags...")
                
                title_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="title"
                )
                
                title_issues = []
                
                if title_result.success and title_result.result:
                    title_text = title_result.result[0].get("text", "").strip()
                    title_length = len(title_text)
                    
                    if not title_text:
                        title_issues.append("Missing title tag")
                    elif title_length < 30:
                        title_issues.append(f"Title too short ({title_length} chars, recommended 30-60)")
                    elif title_length > 60:
                        title_issues.append(f"Title too long ({title_length} chars, recommended 30-60)")
                else:
                    title_issues.append("No title tag found")
                
                title_score = 100 if not title_issues else max(0, 100 - len(title_issues) * 30)
                url_scores["title_tags"] = title_score
                
                url_issues.extend([{"check": "title_tags", "issue": issue, "severity": "high"} for issue in title_issues])
                
                await sqlite_tool.execute(
                    database=config["paths"]["seo_db"],
                    operation="execute",
                    query="INSERT INTO seo_analysis (url, check_type, status, score, issues_found) VALUES (?, ?, ?, ?, ?)",
                    params=(url, "title_tags", "completed", title_score, len(title_issues))
                )
            
            if "meta_descriptions" in config["analysis"]["checks"]:
                print("  Checking meta descriptions...")
                
                meta_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="meta[name='description']"
                )
                
                meta_issues = []
                
                if meta_result.success and meta_result.result:
                    meta_content = meta_result.result[0].get("content", "").strip()
                    meta_length = len(meta_content)
                    
                    if not meta_content:
                        meta_issues.append("Missing meta description")
                    elif meta_length < 120:
                        meta_issues.append(f"Meta description too short ({meta_length} chars, recommended 120-160)")
                    elif meta_length > 160:
                        meta_issues.append(f"Meta description too long ({meta_length} chars, recommended 120-160)")
                else:
                    meta_issues.append("No meta description found")
                
                meta_score = 100 if not meta_issues else max(0, 100 - len(meta_issues) * 30)
                url_scores["meta_descriptions"] = meta_score
                
                url_issues.extend([{"check": "meta_descriptions", "issue": issue, "severity": "high"} for issue in meta_issues])
                
                await sqlite_tool.execute(
                    database=config["paths"]["seo_db"],
                    operation="execute",
                    query="INSERT INTO seo_analysis (url, check_type, status, score, issues_found) VALUES (?, ?, ?, ?, ?)",
                    params=(url, "meta_descriptions", "completed", meta_score, len(meta_issues))
                )
            
            if "headings" in config["analysis"]["checks"]:
                print("  Checking heading structure...")
                
                heading_issues = []
                
                h1_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="h1"
                )
                
                h1_count = len(h1_result.result) if h1_result.success else 0
                
                if h1_count == 0:
                    heading_issues.append("No H1 heading found")
                elif h1_count > 1:
                    heading_issues.append(f"Multiple H1 headings found ({h1_count})")
                
                h2_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="h2"
                )
                
                h2_count = len(h2_result.result) if h2_result.success else 0
                
                if h2_count == 0:
                    heading_issues.append("No H2 headings found")
                
                heading_score = 100 if not heading_issues else max(0, 100 - len(heading_issues) * 25)
                url_scores["headings"] = heading_score
                
                url_issues.extend([{"check": "headings", "issue": issue, "severity": "medium"} for issue in heading_issues])
                
                await sqlite_tool.execute(
                    database=config["paths"]["seo_db"],
                    operation="execute",
                    query="INSERT INTO seo_analysis (url, check_type, status, score, issues_found) VALUES (?, ?, ?, ?, ?)",
                    params=(url, "headings", "completed", heading_score, len(heading_issues))
                )
            
            if "images" in config["analysis"]["checks"]:
                print("  Checking images...")
                
                img_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="img"
                )
                
                image_issues = []
                
                if img_result.success and img_result.result:
                    images_without_alt = 0
                    
                    for img in img_result.result:
                        if not img.get("alt", "").strip():
                            images_without_alt += 1
                    
                    if images_without_alt > 0:
                        image_issues.append(f"{images_without_alt} images missing alt text")
                
                image_score = 100 if not image_issues else max(0, 100 - len(image_issues) * 20)
                url_scores["images"] = image_score
                
                url_issues.extend([{"check": "images", "issue": issue, "severity": "medium"} for issue in image_issues])
                
                await sqlite_tool.execute(
                    database=config["paths"]["seo_db"],
                    operation="execute",
                    query="INSERT INTO seo_analysis (url, check_type, status, score, issues_found) VALUES (?, ?, ?, ?, ?)",
                    params=(url, "images", "completed", image_score, len(image_issues))
                )
            
            if "links" in config["analysis"]["checks"]:
                print("  Checking links...")
                
                link_result = await soup_tool.execute(
                    html=html_content,
                    operation="select",
                    selector="a"
                )
                
                link_issues = []
                
                if link_result.success and link_result.result:
                    broken_links = 0
                    
                    for link in link_result.result:
                        href = link.get("href", "")
                        
                        if not href or href.startswith("#"):
                            broken_links += 1
                    
                    if broken_links > 0:
                        link_issues.append(f"{broken_links} links with issues")
                
                link_score = 100 if not link_issues else max(0, 100 - len(link_issues) * 15)
                url_scores["links"] = link_score
                
                url_issues.extend([{"check": "links", "issue": issue, "severity": "low"} for issue in link_issues])
                
                await sqlite_tool.execute(
                    database=config["paths"]["seo_db"],
                    operation="execute",
                    query="INSERT INTO seo_analysis (url, check_type, status, score, issues_found) VALUES (?, ?, ?, ?, ?)",
                    params=(url, "links", "completed", link_score, len(link_issues))
                )
            
            overall_score = sum(url_scores.values()) // len(url_scores) if url_scores else 0
            
            all_results.append({
                "url": url,
                "overall_score": overall_score,
                "scores": url_scores,
                "total_issues": len(url_issues)
            })
            
            all_issues.extend([{**issue, "url": url} for issue in url_issues])
            
            print(f"  Overall SEO Score: {overall_score}/100")
            print(f"  Total Issues: {len(url_issues)}")
        
        except Exception as e:
            print(f"  Error analyzing URL: {str(e)}")
    
    issues_data = {
        "timestamp": datetime.now().isoformat(),
        "total_urls": len(config["analysis"]["urls"]),
        "total_issues": len(all_issues),
        "issues": all_issues
    }
    
    await writer_tool.execute(
        path=config["paths"]["issues_json"],
        content=json.dumps(issues_data, indent=2),
        mode="write"
    )
    
    print(f"\nIssues log saved: {config['paths']['issues_json']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>SEO Analysis Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .url-card { background: white; padding: 20px; margin: 20px 0; border-left: 5px solid #3498db; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .score { font-size: 48px; font-weight: bold; text-align: center; margin: 20px 0; }
        .score.excellent { color: #2ecc71; }
        .score.good { color: #27ae60; }
        .score.fair { color: #f39c12; }
        .score.poor { color: #e74c3c; }
        .checks { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .check-item { background: #f8f9fa; padding: 15px; border-radius: 5px; }
        .check-name { font-weight: bold; margin-bottom: 5px; }
        .check-score { font-size: 24px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .severity { padding: 4px 8px; border-radius: 3px; font-size: 12px; color: white; }
        .severity-high { background: #e74c3c; }
        .severity-medium { background: #f39c12; }
        .severity-low { background: #3498db; }
    </style>
</head>
<body>
    <h1>SEO Analysis Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>URLs Analyzed:</strong> {{ total_urls }}</p>
    
    {% for result in results %}
    <div class="url-card">
        <h2>{{ result.url }}</h2>
        <div class="score {% if result.overall_score >= 90 %}excellent{% elif result.overall_score >= 70 %}good{% elif result.overall_score >= 50 %}fair{% else %}poor{% endif %}">
            {{ result.overall_score }}/100
        </div>
        
        <div class="checks">
            {% for check, score in result.scores.items() %}
            <div class="check-item">
                <div class="check-name">{{ check.replace('_', ' ').title() }}</div>
                <div class="check-score" style="color: {% if score >= 80 %}#2ecc71{% elif score >= 60 %}#f39c12{% else %}#e74c3c{% endif %}">
                    {{ score }}/100
                </div>
            </div>
            {% endfor %}
        </div>
        
        <p><strong>Total Issues:</strong> {{ result.total_issues }}</p>
    </div>
    {% endfor %}
    
    {% if issues %}
    <h2>Issues Found</h2>
    <table>
        <thead>
            <tr>
                <th>URL</th>
                <th>Check</th>
                <th>Issue</th>
                <th>Severity</th>
            </tr>
        </thead>
        <tbody>
        {% for issue in issues[:50] %}
            <tr>
                <td>{{ issue.url }}</td>
                <td>{{ issue.check }}</td>
                <td>{{ issue.issue }}</td>
                <td><span class="severity severity-{{ issue.severity }}">{{ issue.severity|upper }}</span></td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% if issues|length > 50 %}
    <p><em>Showing 50 of {{ issues|length }} total issues. See issues.json for complete list.</em></p>
    {% endif %}
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "total_urls": len(config["analysis"]["urls"]),
        "results": all_results,
        "issues": all_issues
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["seo_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"SEO report saved: {config['paths']['seo_report']}")
    
    print()
    print("=" * 70)
    print("SEO ANALYSIS SUMMARY")
    print("=" * 70)
    print(f"URLs Analyzed: {len(all_results)}")
    print(f"Total Issues: {len(all_issues)}")
    print()
    print("Scores by URL:")
    for result in all_results:
        print(f"  {result['url']}: {result['overall_score']}/100")
    print()
    print("Output files:")
    print(f"  - SEO Database: {config['paths']['seo_db']}")
    print(f"  - SEO Report: {config['paths']['seo_report']}")
    print(f"  - Issues JSON: {config['paths']['issues_json']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
