#!/usr/bin/env python3
"""
Product Catalog Scraper

Scrapes product information from HTML, extracts structured data, stores in SQLite
database, and exports to CSV. Uses ReActPattern for reasoning about extraction
strategy based on HTML structure.
"""

import asyncio
import json
import random
from pathlib import Path
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.web_tools import BeautifulSoupTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_html(config):
    """Create sample product catalog HTML for scraping."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    categories = ["Electronics", "Books", "Clothing", "Home & Garden", "Sports"]
    brands = ["TechPro", "EliteGear", "Premium", "Quality", "ProLine"]
    
    products_html = []
    
    for i in range(config["scraping"]["num_products"]):
        name = f"{random.choice(brands)} {random.choice(['Pro', 'Elite', 'Max', 'Ultra'])} {random.choice(['2000', 'X', 'Plus'])}"
        price = round(random.uniform(19.99, 999.99), 2)
        rating = round(random.uniform(3.5, 5.0), 1)
        reviews = random.randint(10, 500)
        category = random.choice(categories)
        in_stock = random.choice([True, True, True, False])
        
        products_html.append(f"""
        <div class="product" data-id="PROD{i+1:04d}">
            <h3 class="product-name">{name}</h3>
            <div class="product-category">{category}</div>
            <div class="product-price">${price}</div>
            <div class="product-rating">{rating} stars</div>
            <div class="product-reviews">{reviews} reviews</div>
            <div class="product-stock">{'In Stock' if in_stock else 'Out of Stock'}</div>
        </div>
        """)
    
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Product Catalog</title>
    <style>
        .product {{
            border: 1px solid #ddd;
            padding: 15px;
            margin: 10px;
            border-radius: 5px;
        }}
        .product-name {{ font-weight: bold; color: #333; }}
        .product-price {{ color: #e74c3c; font-size: 20px; }}
        .product-rating {{ color: #f39c12; }}
    </style>
</head>
<body>
    <h1>Product Catalog</h1>
    <div class="catalog">
        {''.join(products_html)}
    </div>
</body>
</html>"""
    
    html_file = config["scraping"]["test_html_file"]
    with open(html_file, 'w') as f:
        f.write(html_content)
    
    print(f"Created sample HTML with {config['scraping']['num_products']} products at {html_file}")
    return html_content


async def main():
    """Execute the product scraping workflow."""
    config = load_config()
    
    print("=" * 70)
    print("PRODUCT CATALOG SCRAPER")
    print("=" * 70)
    print()
    
    html_content = await create_sample_html(config)
    
    soup_tool = BeautifulSoupTool()
    sqlite_tool = SQLiteTool()
    csv_tool = CSVProcessorTool()
    
    print("\nParsing HTML with BeautifulSoup...")
    
    parse_result = await soup_tool.execute(
        html=html_content,
        operation="find_all",
        selector={"name": "div", "class_": "product"}
    )
    
    if not parse_result.success:
        print(f"Error parsing HTML: {parse_result.error}")
        return
    
    product_elements = parse_result.result
    print(f"Found {len(product_elements)} products")
    
    print("\nExtracting product data...")
    products = []
    
    for elem in product_elements:
        product_id_result = await soup_tool.execute(
            html=str(elem),
            operation="get_attribute",
            selector={"name": "div", "attrs": {"class": "product"}},
            attribute="data-id"
        )
        
        name_result = await soup_tool.execute(
            html=str(elem),
            operation="find",
            selector={"name": "h3", "class_": "product-name"}
        )
        
        price_result = await soup_tool.execute(
            html=str(elem),
            operation="find",
            selector={"name": "div", "class_": "product-price"}
        )
        
        rating_result = await soup_tool.execute(
            html=str(elem),
            operation="find",
            selector={"name": "div", "class_": "product-rating"}
        )
        
        category_result = await soup_tool.execute(
            html=str(elem),
            operation="find",
            selector={"name": "div", "class_": "product-category"}
        )
        
        stock_result = await soup_tool.execute(
            html=str(elem),
            operation="find",
            selector={"name": "div", "class_": "product-stock"}
        )
        
        if all([name_result.success, price_result.success]):
            product = {
                "id": product_id_result.result if product_id_result.success else "N/A",
                "name": name_result.result.strip(),
                "price": float(price_result.result.replace('$', '').strip()),
                "rating": float(rating_result.result.split()[0]) if rating_result.success else 0.0,
                "category": category_result.result.strip() if category_result.success else "Unknown",
                "in_stock": "In Stock" in stock_result.result if stock_result.success else False
            }
            products.append(product)
    
    print(f"Extracted {len(products)} products")
    
    print("\nCreating SQLite database...")
    
    create_table_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            rating REAL,
            category TEXT,
            in_stock BOOLEAN
        )
        """
    )
    
    if not create_table_result.success:
        print(f"Error creating table: {create_table_result.error}")
        return
    
    print("Inserting products into database...")
    
    for product in products:
        insert_result = await sqlite_tool.execute(
            database=config["paths"]["database"],
            operation="execute",
            query="""
            INSERT OR REPLACE INTO products (id, name, price, rating, category, in_stock)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            params=(
                product["id"],
                product["name"],
                product["price"],
                product["rating"],
                product["category"],
                product["in_stock"]
            )
        )
    
    print(f"Inserted {len(products)} products into database")
    
    print("\nQuerying database for analytics...")
    
    avg_price_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="query",
        query="SELECT AVG(price) as avg_price FROM products WHERE in_stock = 1"
    )
    
    category_count_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="query",
        query="SELECT category, COUNT(*) as count FROM products GROUP BY category ORDER BY count DESC"
    )
    
    top_rated_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="query",
        query="SELECT name, price, rating FROM products WHERE in_stock = 1 ORDER BY rating DESC LIMIT 5"
    )
    
    print("\nExporting to CSV...")
    
    export_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="query",
        query="SELECT * FROM products ORDER BY category, rating DESC"
    )
    
    if export_result.success:
        csv_data = export_result.result
        csv_write_result = await csv_tool.execute(
            file_path=config["paths"]["export_csv"],
            operation="write",
            data=csv_data
        )
        
        if csv_write_result.success:
            print(f"Exported products to: {config['paths']['export_csv']}")
    
    print()
    print("=" * 70)
    print("SCRAPING SUMMARY")
    print("=" * 70)
    print(f"Total Products Scraped: {len(products)}")
    print(f"Products in Stock: {sum(1 for p in products if p['in_stock'])}")
    
    if avg_price_result.success and avg_price_result.result:
        avg_price = avg_price_result.result[0]["avg_price"]
        print(f"Average Price (in stock): ${avg_price:.2f}")
    
    if category_count_result.success:
        print("\nProducts by Category:")
        for row in category_count_result.result:
            print(f"  - {row['category']}: {row['count']}")
    
    if top_rated_result.success:
        print("\nTop 5 Rated Products (in stock):")
        for row in top_rated_result.result:
            print(f"  - {row['name']}: {row['rating']} stars (${row['price']})")
    
    print()
    print(f"Output files:")
    print(f"  - {config['paths']['database']}")
    print(f"  - {config['paths']['export_csv']}")
    print(f"  - {config['scraping']['test_html_file']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
