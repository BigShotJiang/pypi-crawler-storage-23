#!/usr/bin/env python3
"""
Markdown Documentation Generator

Generates comprehensive project documentation in Markdown format.
Uses PlanningPattern to structure and create multi-file documentation.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_api_spec(config):
    """Generate sample API specification."""
    api_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": config["documentation"]["project_name"],
            "version": config["documentation"]["version"],
            "description": "A powerful API for managing resources"
        },
        "endpoints": [
            {
                "path": "/api/users",
                "method": "GET",
                "description": "List all users",
                "parameters": [
                    {"name": "page", "type": "integer", "description": "Page number"},
                    {"name": "limit", "type": "integer", "description": "Items per page"}
                ],
                "responses": {
                    "200": "Success - Returns list of users"
                }
            },
            {
                "path": "/api/users/{id}",
                "method": "GET",
                "description": "Get user by ID",
                "parameters": [
                    {"name": "id", "type": "string", "description": "User ID"}
                ],
                "responses": {
                    "200": "Success - Returns user object",
                    "404": "User not found"
                }
            },
            {
                "path": "/api/users",
                "method": "POST",
                "description": "Create new user",
                "request_body": {
                    "name": "string",
                    "email": "string",
                    "role": "string"
                },
                "responses": {
                    "201": "User created successfully",
                    "400": "Invalid request data"
                }
            },
            {
                "path": "/api/users/{id}",
                "method": "PUT",
                "description": "Update user",
                "parameters": [
                    {"name": "id", "type": "string", "description": "User ID"}
                ],
                "request_body": {
                    "name": "string",
                    "email": "string",
                    "role": "string"
                },
                "responses": {
                    "200": "User updated successfully",
                    "404": "User not found"
                }
            },
            {
                "path": "/api/users/{id}",
                "method": "DELETE",
                "description": "Delete user",
                "parameters": [
                    {"name": "id", "type": "string", "description": "User ID"}
                ],
                "responses": {
                    "204": "User deleted successfully",
                    "404": "User not found"
                }
            }
        ]
    }
    
    with open(config["paths"]["api_spec"], 'w') as f:
        json.dump(api_spec, f, indent=2)
    
    print(f"Generated API spec: {config['paths']['api_spec']}")


async def main():
    """Execute documentation generation workflow."""
    config = load_config()
    
    print("=" * 70)
    print("MARKDOWN DOCUMENTATION GENERATOR")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    docs_dir = Path(config["paths"]["docs_output"])
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    await generate_api_spec(config)
    
    writer_tool = FileWriterTool()
    template_tool = TemplateRendererTool()
    json_tool = JSONParserTool()
    
    project_name = config["documentation"]["project_name"]
    version = config["documentation"]["version"]
    
    print("\nGenerating documentation sections...")
    
    readme_content = f"""# {project_name}

Version {version}

A comprehensive API for managing resources with powerful features and easy integration.

## Quick Start

```bash
npm install {project_name.lower()}
```

## Features

- RESTful API design
- Comprehensive documentation
- Easy integration
- Secure authentication
- Rate limiting
- Real-time updates

## Documentation

See the [full documentation](docs/index.md) for detailed information.

## Support

For issues and questions, please visit our issue tracker.

## License

MIT License - see LICENSE file for details.
"""
    
    await writer_tool.execute(
        path=config["paths"]["readme"],
        content=readme_content,
        mode="write"
    )
    
    print(f"  Created: README.md")
    
    intro_content = f"""# Introduction

Welcome to the {project_name} documentation!

{project_name} is a modern API platform designed to help developers build robust applications quickly and efficiently.

## What is {project_name}?

{project_name} provides a comprehensive set of RESTful endpoints for managing users, resources, and data. Built with performance and security in mind, it offers:

- **Simple Integration**: Get started in minutes with our SDKs
- **Scalable**: Designed to handle millions of requests
- **Secure**: Built-in authentication and authorization
- **Well-Documented**: Comprehensive API reference and guides

## Use Cases

- User management systems
- Content management platforms
- Data aggregation services
- Microservices architecture

## Getting Help

- Check our [Troubleshooting](troubleshooting.md) guide
- Review [Examples](examples.md)
- Contact support

---

Continue to [Installation](installation.md) →
"""
    
    await writer_tool.execute(
        path=str(docs_dir / "introduction.md"),
        content=intro_content,
        mode="write"
    )
    
    print(f"  Created: docs/introduction.md")
    
    installation_content = f"""# Installation

## Requirements

- Node.js 16+ or Python 3.8+
- Valid API key

## Installation Methods

### NPM (Node.js)

```bash
npm install {project_name.lower()}
```

### Python

```bash
pip install {project_name.lower()}
```

### Docker

```bash
docker pull {project_name.lower()}/{project_name.lower()}:latest
docker run -p 3000:3000 {project_name.lower()}/{project_name.lower()}
```

## Configuration

Create a configuration file:

```json
{{
  "api_key": "your-api-key-here",
  "base_url": "https://api.example.com",
  "timeout": 30
}}
```

## Verify Installation

```javascript
const client = require('{project_name.lower()}');
console.log(client.version); // {version}
```

---

← [Introduction](introduction.md) | [Configuration](configuration.md) →
"""
    
    await writer_tool.execute(
        path=str(docs_dir / "installation.md"),
        content=installation_content,
        mode="write"
    )
    
    print(f"  Created: docs/installation.md")
    
    config_content = f"""# Configuration

## Configuration Options

### API Key

Your API key authenticates requests to {project_name}.

```javascript
const client = new Client({{
  apiKey: 'your-api-key'
}});
```

### Base URL

Set the API base URL (default: https://api.example.com):

```javascript
const client = new Client({{
  apiKey: 'your-api-key',
  baseURL: 'https://custom-api.example.com'
}});
```

### Timeout

Configure request timeout in seconds (default: 30):

```javascript
const client = new Client({{
  apiKey: 'your-api-key',
  timeout: 60
}});
```

### Retries

Enable automatic retries for failed requests:

```javascript
const client = new Client({{
  apiKey: 'your-api-key',
  retries: 3,
  retryDelay: 1000
}});
```

## Environment Variables

Set configuration via environment variables:

```bash
export API_KEY="your-api-key"
export API_BASE_URL="https://api.example.com"
export API_TIMEOUT=30
```

---

← [Installation](installation.md) | [API Reference](api_reference.md) →
"""
    
    await writer_tool.execute(
        path=str(docs_dir / "configuration.md"),
        content=config_content,
        mode="write"
    )
    
    print(f"  Created: docs/configuration.md")
    
    api_spec_result = await json_tool.execute(
        file_path=config["paths"]["api_spec"],
        operation="read"
    )
    
    api_spec = api_spec_result.result if api_spec_result.success else {}
    
    api_ref_content = f"""# API Reference

## Overview

{project_name} {version} - {api_spec.get('info', {}).get('description', '')}

Base URL: `https://api.example.com`

## Authentication

All requests require an API key in the header:

```
Authorization: Bearer YOUR_API_KEY
```

## Endpoints

"""
    
    for endpoint in api_spec.get("endpoints", []):
        api_ref_content += f"""### {endpoint['method']} {endpoint['path']}

{endpoint['description']}

"""
        
        if endpoint.get("parameters"):
            api_ref_content += "**Parameters:**\n\n"
            for param in endpoint["parameters"]:
                api_ref_content += f"- `{param['name']}` ({param['type']}): {param['description']}\n"
            api_ref_content += "\n"
        
        if endpoint.get("request_body"):
            api_ref_content += "**Request Body:**\n\n```json\n"
            api_ref_content += json.dumps(endpoint["request_body"], indent=2)
            api_ref_content += "\n```\n\n"
        
        api_ref_content += "**Responses:**\n\n"
        for status, desc in endpoint.get("responses", {}).items():
            api_ref_content += f"- `{status}`: {desc}\n"
        api_ref_content += "\n"
    
    api_ref_content += "\n---\n\n← [Configuration](configuration.md) | [Examples](examples.md) →\n"
    
    await writer_tool.execute(
        path=str(docs_dir / "api_reference.md"),
        content=api_ref_content,
        mode="write"
    )
    
    print(f"  Created: docs/api_reference.md")
    
    examples_content = f"""# Examples

## Quick Examples

### List Users

```javascript
const client = new Client({{ apiKey: 'your-api-key' }});

const users = await client.users.list({{
  page: 1,
  limit: 10
}});

console.log(users);
```

### Get User by ID

```javascript
const user = await client.users.get('user_123');
console.log(user.name);
```

### Create User

```javascript
const newUser = await client.users.create({{
  name: 'John Doe',
  email: 'john@example.com',
  role: 'admin'
}});

console.log('Created user:', newUser.id);
```

### Update User

```javascript
const updated = await client.users.update('user_123', {{
  name: 'Jane Doe',
  email: 'jane@example.com'
}});
```

### Delete User

```javascript
await client.users.delete('user_123');
console.log('User deleted');
```

## Error Handling

```javascript
try {{
  const user = await client.users.get('invalid_id');
}} catch (error) {{
  if (error.status === 404) {{
    console.log('User not found');
  }} else {{
    console.error('Error:', error.message);
  }}
}}
```

## Pagination

```javascript
let page = 1;
const allUsers = [];

while (true) {{
  const response = await client.users.list({{ page, limit: 100 }});
  allUsers.push(...response.data);
  
  if (!response.hasMore) break;
  page++;
}}

console.log('Total users:', allUsers.length);
```

---

← [API Reference](api_reference.md) | [Troubleshooting](troubleshooting.md) →
"""
    
    await writer_tool.execute(
        path=str(docs_dir / "examples.md"),
        content=examples_content,
        mode="write"
    )
    
    print(f"  Created: docs/examples.md")
    
    troubleshooting_content = f"""# Troubleshooting

## Common Issues

### Authentication Errors

**Problem:** Receiving 401 Unauthorized errors

**Solution:**
- Verify your API key is correct
- Check that the API key is included in request headers
- Ensure the API key hasn't expired

### Rate Limiting

**Problem:** Receiving 429 Too Many Requests errors

**Solution:**
- Implement exponential backoff
- Reduce request frequency
- Consider upgrading your plan

### Timeout Errors

**Problem:** Requests timing out

**Solution:**
- Increase timeout configuration
- Check network connectivity
- Verify API service status

### Invalid Request Data

**Problem:** Receiving 400 Bad Request errors

**Solution:**
- Validate request payload against schema
- Check required fields are present
- Ensure data types are correct

## Debug Mode

Enable debug logging:

```javascript
const client = new Client({{
  apiKey: 'your-api-key',
  debug: true
}});
```

## Getting Support

If you continue to experience issues:

1. Check the [API Status Page](https://status.example.com)
2. Review [Examples](examples.md) for correct usage
3. Contact support with:
   - Request ID from error response
   - Timestamp of the issue
   - Steps to reproduce

---

← [Examples](examples.md) | [Changelog](changelog.md) →
"""
    
    await writer_tool.execute(
        path=str(docs_dir / "troubleshooting.md"),
        content=troubleshooting_content,
        mode="write"
    )
    
    print(f"  Created: docs/troubleshooting.md")
    
    changelog_content = f"""# Changelog

All notable changes to {project_name} will be documented in this file.

## [2.0.0] - {datetime.now().strftime('%Y-%m-%d')}

### Added
- New user management endpoints
- Improved error handling
- Rate limiting support
- Pagination for list endpoints
- Debug logging mode

### Changed
- Updated authentication flow
- Improved response times
- Enhanced documentation

### Fixed
- Fixed timeout handling
- Resolved memory leaks
- Corrected validation errors

## [1.5.0] - 2025-12-15

### Added
- Bulk operations support
- Webhook notifications
- Custom field support

### Changed
- Optimized database queries
- Updated dependencies

## [1.0.0] - 2025-06-01

### Added
- Initial release
- Basic CRUD operations
- Authentication support
- API documentation

---

← [Troubleshooting](troubleshooting.md)
"""
    
    await writer_tool.execute(
        path=config["paths"]["changelog"],
        content=changelog_content,
        mode="write"
    )
    
    print(f"  Created: CHANGELOG.md")
    
    if config["documentation"]["generate_index"]:
        index_content = f"""# {project_name} Documentation

Version {version}

## Table of Contents

1. [Introduction](introduction.md)
2. [Installation](installation.md)
3. [Configuration](configuration.md)
4. [API Reference](api_reference.md)
5. [Examples](examples.md)
6. [Troubleshooting](troubleshooting.md)
7. [Changelog](../CHANGELOG.md)

## Quick Links

- [GitHub Repository](https://github.com/example/{project_name.lower()})
- [API Status](https://status.example.com)
- [Support](https://support.example.com)

## Getting Started

New to {project_name}? Start with the [Introduction](introduction.md) to learn about the platform, then follow the [Installation](installation.md) guide to get set up.

## Documentation Version

This documentation is for {project_name} version {version}.

Last updated: {datetime.now().strftime('%Y-%m-%d')}
"""
        
        await writer_tool.execute(
            path=config["paths"]["index"],
            content=index_content,
            mode="write"
        )
        
        print(f"  Created: docs/index.md")
    
    print()
    print("=" * 70)
    print("DOCUMENTATION SUMMARY")
    print("=" * 70)
    print(f"Project: {project_name} v{version}")
    print(f"Sections Generated: {len(config['documentation']['sections'])}")
    print()
    print("Generated Files:")
    print("  - README.md")
    print("  - CHANGELOG.md")
    print("  - docs/index.md")
    print("  - docs/introduction.md")
    print("  - docs/installation.md")
    print("  - docs/configuration.md")
    print("  - docs/api_reference.md")
    print("  - docs/examples.md")
    print("  - docs/troubleshooting.md")
    print()
    print("Output directory:")
    print(f"  {work_dir}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
