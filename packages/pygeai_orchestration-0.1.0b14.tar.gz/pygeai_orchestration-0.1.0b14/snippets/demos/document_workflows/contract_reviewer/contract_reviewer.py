#!/usr/bin/env python3
"""
Contract Reviewer

Reviews legal contracts to identify key clauses, risks, and missing provisions.
Uses ReflectionPattern to analyze contract completeness and risk factors.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.reflection import ReflectionPattern
from pygeai_orchestration.tools.builtin.file_tools import FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import ValidationTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_contract(config):
    """Create sample service agreement contract."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    contract_text = """SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into as of January 1, 2024 ("Effective Date") 
by and between TechCorp Solutions Inc. ("Provider") and Global Industries LLC ("Client").

1. SERVICES

Provider agrees to provide software development and consulting services as outlined in 
attached Statement of Work. Services will be performed in a professional and workmanlike manner.

2. PAYMENT TERMS

Client shall pay Provider a monthly fee of $10,000 USD, payable within 30 days of invoice date.
Late payments will incur interest at 1.5% per month. All fees are non-refundable.

3. TERM AND TERMINATION

This Agreement shall commence on the Effective Date and continue for an initial term of 
twelve (12) months. Either party may terminate this Agreement with 30 days written notice.
Upon termination, Client shall pay for all services rendered through the termination date.

4. CONFIDENTIALITY

Each party agrees to maintain in confidence all Confidential Information received from the 
other party. Confidential Information shall not be disclosed to third parties without prior 
written consent. This obligation survives termination for a period of three (3) years.

5. INTELLECTUAL PROPERTY

All intellectual property created by Provider in the course of providing Services shall 
remain the property of Provider unless otherwise agreed in writing. Client receives a 
non-exclusive license to use deliverables for business purposes.

6. LIABILITY AND INDEMNIFICATION

Provider's total liability under this Agreement shall not exceed the fees paid by Client 
in the twelve (12) months preceding the claim. Provider makes no warranties, express or 
implied, including warranties of merchantability or fitness for a particular purpose.

Client agrees to indemnify and hold harmless Provider from any claims arising from Client's 
use of the Services.

7. DISPUTE RESOLUTION

Any disputes arising under this Agreement shall be resolved through binding arbitration in 
accordance with the rules of the American Arbitration Association. The arbitration shall 
take place in New York, NY.

8. GENERAL PROVISIONS

This Agreement constitutes the entire agreement between the parties. Any modifications must 
be in writing and signed by both parties. This Agreement shall be governed by the laws of 
the State of New York.

If any provision is found unenforceable, the remaining provisions shall continue in full force.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date.

TechCorp Solutions Inc.                    Global Industries LLC
_______________________                     _______________________
Authorized Signature                        Authorized Signature
"""
    
    contract_path = config["paths"]["contract_file"]
    with open(contract_path, 'w') as f:
        f.write(contract_text)
    
    print(f"Created sample contract at {contract_path}")


async def main():
    """Execute contract review workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CONTRACT REVIEWER")
    print("=" * 70)
    print()
    
    await create_sample_contract(config)
    
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    validation_tool = ValidationTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nReading contract...")
    
    read_result = await reader_tool.execute(path=config["paths"]["contract_file"])
    
    if not read_result.success:
        print(f"Error reading contract: {read_result.error}")
        return
    
    contract_text = read_result.result
    
    print(f"Contract length: {len(contract_text)} characters")
    
    print("\nAnalyzing contract structure...")
    
    section_pattern = r'^\d+\.\s+([A-Z\s]+)$'
    
    sections_result = await regex_tool.execute(
        pattern=section_pattern,
        text=contract_text,
        operation="findall",
        flags=["MULTILINE"]
    )
    
    sections_found = sections_result.result if sections_result.success else []
    sections_found = [s.strip() for s in sections_found]
    
    print(f"Found {len(sections_found)} sections: {', '.join(sections_found)}")
    
    print("\nChecking for required clauses...")
    
    clause_findings = []
    
    for clause in config["review"]["check_clauses"]:
        clause_pattern = clause.replace(" ", r"\s+")
        
        search_result = await regex_tool.execute(
            pattern=clause_pattern,
            text=contract_text,
            operation="search",
            flags=["IGNORECASE"]
        )
        
        found = search_result.success and search_result.result
        
        clause_findings.append({
            "clause": clause.title(),
            "present": found,
            "status": "FOUND" if found else "MISSING"
        })
    
    print("\nScanning for risk keywords...")
    
    risk_findings = []
    
    for keyword in config["review"]["risk_keywords"]:
        keyword_pattern = keyword.replace(" ", r"\s+")
        
        search_result = await regex_tool.execute(
            pattern=keyword_pattern,
            text=contract_text,
            operation="finditer",
            flags=["IGNORECASE"]
        )
        
        if search_result.success and search_result.result:
            matches = search_result.result if isinstance(search_result.result, list) else [search_result.result]
            
            for match in matches:
                context_start = max(0, contract_text.lower().find(keyword.lower()) - 50)
                context_end = min(len(contract_text), contract_text.lower().find(keyword.lower()) + len(keyword) + 50)
                context = contract_text[context_start:context_end].replace('\n', ' ')
                
                risk_findings.append({
                    "keyword": keyword,
                    "severity": "HIGH" if keyword in ["unlimited liability", "irrevocable", "exclusive rights"] else "MEDIUM",
                    "context": f"...{context}..."
                })
    
    print("\nExtracting key terms...")
    
    amount_pattern = r'\$[\d,]+(?:\.\d{2})?'
    amounts_result = await regex_tool.execute(
        pattern=amount_pattern,
        text=contract_text,
        operation="findall"
    )
    
    amounts = amounts_result.result if amounts_result.success else []
    
    date_pattern = r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'
    dates_result = await regex_tool.execute(
        pattern=date_pattern,
        text=contract_text,
        operation="findall"
    )
    
    dates = dates_result.result if dates_result.success else []
    
    duration_pattern = r'\b\d+\s+(?:days|months|years)\b'
    durations_result = await regex_tool.execute(
        pattern=duration_pattern,
        text=contract_text,
        operation="findall",
        flags=["IGNORECASE"]
    )
    
    durations = durations_result.result if durations_result.success else []
    
    print("\nGenerating review report...")
    
    missing_clauses = [c for c in clause_findings if not c["present"]]
    found_clauses = [c for c in clause_findings if c["present"]]
    
    completeness_score = (len(found_clauses) / len(clause_findings) * 100) if clause_findings else 0
    risk_score = min(100, len(risk_findings) * 15)
    
    review_data = {
        "review_timestamp": datetime.now().isoformat(),
        "contract_file": config["paths"]["contract_file"],
        "analysis": {
            "sections_count": len(sections_found),
            "sections": sections_found,
            "completeness_score": round(completeness_score, 1),
            "risk_score": risk_score,
            "word_count": len(contract_text.split())
        },
        "clause_review": {
            "total_checked": len(clause_findings),
            "found": len(found_clauses),
            "missing": len(missing_clauses),
            "findings": clause_findings
        },
        "risk_assessment": {
            "total_risks": len(risk_findings),
            "high_severity": len([r for r in risk_findings if r["severity"] == "HIGH"]),
            "medium_severity": len([r for r in risk_findings if r["severity"] == "MEDIUM"]),
            "findings": risk_findings
        },
        "key_terms": {
            "monetary_amounts": amounts,
            "dates": dates,
            "durations": durations
        },
        "recommendations": []
    }
    
    if missing_clauses:
        review_data["recommendations"].append(f"Add missing clauses: {', '.join([c['clause'] for c in missing_clauses])}")
    
    if risk_score > 30:
        review_data["recommendations"].append("Review and mitigate high-risk terms identified")
    
    if completeness_score < 70:
        review_data["recommendations"].append("Contract is missing several standard clauses")
    
    if not review_data["recommendations"]:
        review_data["recommendations"].append("Contract appears reasonably complete and balanced")
    
    report_json = json.dumps(review_data, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["review_report"],
        content=report_json,
        mode="write"
    )
    
    print(f"Review report saved: {config['paths']['review_report']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Contract Review Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .score-box { display: inline-block; padding: 20px 40px; margin: 10px; border-radius: 5px; text-align: center; }
        .score-value { font-size: 36px; font-weight: bold; }
        .score-label { font-size: 14px; color: #666; margin-top: 5px; }
        .good { background: #d4edda; color: #155724; }
        .warning { background: #fff3cd; color: #856404; }
        .danger { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .status-found { color: #28a745; font-weight: bold; }
        .status-missing { color: #dc3545; font-weight: bold; }
        .risk-high { background: #f8d7da; padding: 15px; margin: 10px 0; border-left: 4px solid #dc3545; }
        .risk-medium { background: #fff3cd; padding: 15px; margin: 10px 0; border-left: 4px solid #ffc107; }
        .recommendations { background: #d1ecf1; padding: 20px; border-left: 4px solid #0c5460; margin: 20px 0; }
    </style>
</head>
<body>
    <h1>Contract Review Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Contract:</strong> {{ contract_file }}</p>
    
    <div style="margin: 30px 0;">
        <div class="score-box {% if completeness >= 80 %}good{% elif completeness >= 60 %}warning{% else %}danger{% endif %}">
            <div class="score-value">{{ completeness }}%</div>
            <div class="score-label">Completeness Score</div>
        </div>
        <div class="score-box {% if risk_score < 30 %}good{% elif risk_score < 60 %}warning{% else %}danger{% endif %}">
            <div class="score-value">{{ risk_score }}</div>
            <div class="score-label">Risk Score</div>
        </div>
        <div class="score-box good">
            <div class="score-value">{{ sections_count }}</div>
            <div class="score-label">Sections</div>
        </div>
    </div>
    
    <h2>Clause Coverage</h2>
    <table>
        <thead>
            <tr>
                <th>Required Clause</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        {% for finding in clause_findings %}
            <tr>
                <td>{{ finding.clause }}</td>
                <td class="{% if finding.present %}status-found{% else %}status-missing{% endif %}">
                    {{ finding.status }}
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    {% if risk_findings %}
    <h2>Risk Findings ({{ risk_findings|length }})</h2>
    {% for risk in risk_findings %}
    <div class="risk-{{ risk.severity|lower }}">
        <strong>[{{ risk.severity }}]</strong> {{ risk.keyword }}
        <br><em>{{ risk.context }}</em>
    </div>
    {% endfor %}
    {% endif %}
    
    <div class="recommendations">
        <h2>Recommendations</h2>
        <ul>
        {% for rec in recommendations %}
            <li>{{ rec }}</li>
        {% endfor %}
        </ul>
    </div>
    
    <h2>Key Terms Extracted</h2>
    <p><strong>Monetary Amounts:</strong> {{ amounts|join(', ') or 'None found' }}</p>
    <p><strong>Dates:</strong> {{ dates|join(', ') or 'None found' }}</p>
    <p><strong>Durations:</strong> {{ durations|join(', ') or 'None found' }}</p>
</body>
</html>"""
    
    html_data = {
        "timestamp": review_data["review_timestamp"],
        "contract_file": review_data["contract_file"],
        "completeness": review_data["analysis"]["completeness_score"],
        "risk_score": review_data["analysis"]["risk_score"],
        "sections_count": review_data["analysis"]["sections_count"],
        "clause_findings": review_data["clause_review"]["findings"],
        "risk_findings": review_data["risk_assessment"]["findings"],
        "recommendations": review_data["recommendations"],
        "amounts": review_data["key_terms"]["monetary_amounts"],
        "dates": review_data["key_terms"]["dates"],
        "durations": review_data["key_terms"]["durations"]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["summary_html"],
            content=html_result.result,
            mode="write"
        )
        print(f"HTML summary saved: {config['paths']['summary_html']}")
    
    print()
    print("=" * 70)
    print("REVIEW SUMMARY")
    print("=" * 70)
    print(f"Completeness Score: {completeness_score:.1f}%")
    print(f"Risk Score: {risk_score}")
    print()
    print(f"Clauses Found: {len(found_clauses)}/{len(clause_findings)}")
    if missing_clauses:
        print(f"Missing Clauses: {', '.join([c['clause'] for c in missing_clauses])}")
    
    print()
    print(f"Risk Findings: {len(risk_findings)}")
    for risk in risk_findings[:3]:
        print(f"  [{risk['severity']}] {risk['keyword']}")
    
    print()
    print("Recommendations:")
    for rec in review_data["recommendations"]:
        print(f"  - {rec}")
    
    print()
    print("Output files:")
    print(f"  - JSON Report: {config['paths']['review_report']}")
    print(f"  - HTML Summary: {config['paths']['summary_html']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
