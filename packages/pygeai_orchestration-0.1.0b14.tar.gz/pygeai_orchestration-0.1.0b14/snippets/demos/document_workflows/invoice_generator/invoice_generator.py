#!/usr/bin/env python3
"""
Professional Invoice Generator

Generates professional PDF invoices from configuration data. Creates itemized
invoices with tax calculations, company branding, and client information using
template rendering and PDF generation tools.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.document_generation import PDFGeneratorTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


def create_invoice_template():
    """Create HTML template for the invoice."""
    return """<!DOCTYPE html>
<html>
<head>
    <title>Invoice {{ invoice_number }}</title>
    <style>
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            color: #333;
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            border-bottom: 3px solid #2c3e50;
            padding-bottom: 20px;
        }
        .company-info h1 {
            margin: 0 0 10px 0;
            color: #2c3e50;
            font-size: 28px;
        }
        .company-info p {
            margin: 3px 0;
            font-size: 14px;
            color: #666;
        }
        .invoice-details {
            text-align: right;
        }
        .invoice-details h2 {
            margin: 0 0 10px 0;
            color: #e74c3c;
            font-size: 32px;
        }
        .invoice-details p {
            margin: 3px 0;
            font-size: 14px;
        }
        .client-section {
            margin: 30px 0;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
        }
        .client-section h3 {
            margin: 0 0 10px 0;
            color: #2c3e50;
        }
        .client-section p {
            margin: 3px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
        }
        thead {
            background-color: #2c3e50;
            color: white;
        }
        th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        .text-right {
            text-align: right;
        }
        .totals {
            margin-top: 20px;
            float: right;
            width: 300px;
        }
        .totals table {
            margin: 0;
        }
        .totals td {
            border: none;
            padding: 8px 12px;
        }
        .totals .total-row {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            font-size: 18px;
        }
        .footer {
            clear: both;
            margin-top: 60px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .payment-terms {
            margin-top: 40px;
            padding: 15px;
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-info">
            <h1>{{ company.name }}</h1>
            <p>{{ company.address }}</p>
            <p>{{ company.city }}</p>
            <p>Phone: {{ company.phone }}</p>
            <p>Email: {{ company.email }}</p>
            <p>Tax ID: {{ company.tax_id }}</p>
        </div>
        <div class="invoice-details">
            <h2>INVOICE</h2>
            <p><strong>Invoice #:</strong> {{ invoice_number }}</p>
            <p><strong>Date:</strong> {{ invoice_date }}</p>
            <p><strong>Due Date:</strong> {{ due_date }}</p>
        </div>
    </div>
    
    <div class="client-section">
        <h3>Bill To:</h3>
        <p><strong>{{ client.name }}</strong></p>
        <p>Attn: {{ client.contact }}</p>
        <p>{{ client.address }}</p>
        <p>{{ client.city }}</p>
        <p>{{ client.email }}</p>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-right">Quantity</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Amount</th>
            </tr>
        </thead>
        <tbody>
        {% for item in items %}
            <tr>
                <td>{{ item.description }}</td>
                <td class="text-right">{{ item.quantity }}</td>
                <td class="text-right">{{ currency }}{{ item.unit_price }}</td>
                <td class="text-right">{{ currency }}{{ item.total }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <div class="totals">
        <table>
            <tr>
                <td>Subtotal:</td>
                <td class="text-right">{{ currency }}{{ subtotal }}</td>
            </tr>
            <tr>
                <td>Tax ({{ tax_rate_percent }}%):</td>
                <td class="text-right">{{ currency }}{{ tax_amount }}</td>
            </tr>
            <tr class="total-row">
                <td>TOTAL:</td>
                <td class="text-right">{{ currency }}{{ total }}</td>
            </tr>
        </table>
    </div>
    
    <div class="payment-terms">
        <strong>Payment Terms:</strong> Payment is due within 30 days of invoice date.
        Please reference invoice number {{ invoice_number }} with your payment.
    </div>
    
    <div class="footer">
        <p>Thank you for your business!</p>
        <p>{{ company.name }} | {{ company.email }} | {{ company.phone }}</p>
    </div>
</body>
</html>"""


async def main():
    """Execute the invoice generation workflow."""
    config = load_config()
    
    print("=" * 70)
    print("PROFESSIONAL INVOICE GENERATOR")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    pdf_tool = PDFGeneratorTool()
    file_tool = FileWriterTool()
    
    print(f"Generating invoice {config['invoice']['number']}...")
    
    items_with_totals = []
    subtotal = 0.0
    
    for item in config["invoice"]["items"]:
        item_total = item["quantity"] * item["unit_price"]
        items_with_totals.append({
            "description": item["description"],
            "quantity": item["quantity"],
            "unit_price": f"{item['unit_price']:.2f}",
            "total": f"{item_total:.2f}"
        })
        subtotal += item_total
    
    tax_amount = subtotal * config["invoice"]["tax_rate"]
    total = subtotal + tax_amount
    
    template_data = {
        "company": config["company"],
        "client": config["client"],
        "invoice_number": config["invoice"]["number"],
        "invoice_date": config["invoice"]["date"],
        "due_date": config["invoice"]["due_date"],
        "currency": config["invoice"]["currency"] + " ",
        "items": items_with_totals,
        "subtotal": f"{subtotal:.2f}",
        "tax_rate_percent": f"{config['invoice']['tax_rate'] * 100:.0f}",
        "tax_amount": f"{tax_amount:.2f}",
        "total": f"{total:.2f}"
    }
    
    print("Rendering invoice HTML...")
    
    html_result = await template_tool.execute(
        template=create_invoice_template(),
        data=template_data,
        engine="jinja2"
    )
    
    if not html_result.success:
        print(f"Error rendering template: {html_result.error}")
        return
    
    html_content = html_result.result
    
    html_write_result = await file_tool.execute(
        path=config["paths"]["output_html"],
        content=html_content,
        mode="write"
    )
    
    if html_write_result.success:
        print(f"HTML invoice saved to: {config['paths']['output_html']}")
    
    print("Generating PDF invoice...")
    
    pdf_result = await pdf_tool.execute(
        content=html_content,
        output_path=config["paths"]["output_pdf"],
        format="html"
    )
    
    if pdf_result.success:
        print(f"PDF invoice saved to: {config['paths']['output_pdf']}")
    else:
        print(f"Error generating PDF: {pdf_result.error}")
    
    print()
    print("=" * 70)
    print("INVOICE SUMMARY")
    print("=" * 70)
    print(f"Invoice Number: {config['invoice']['number']}")
    print(f"Client: {config['client']['name']}")
    print(f"Date: {config['invoice']['date']}")
    print(f"Due Date: {config['invoice']['due_date']}")
    print()
    print(f"Subtotal: {config['invoice']['currency']} {subtotal:.2f}")
    print(f"Tax ({config['invoice']['tax_rate'] * 100:.0f}%): {config['invoice']['currency']} {tax_amount:.2f}")
    print(f"TOTAL: {config['invoice']['currency']} {total:.2f}")
    print()
    print(f"Output files:")
    print(f"  - {config['paths']['output_html']}")
    print(f"  - {config['paths']['output_pdf']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
