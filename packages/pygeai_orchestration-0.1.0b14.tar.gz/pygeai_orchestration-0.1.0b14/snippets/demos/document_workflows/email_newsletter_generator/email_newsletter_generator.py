#!/usr/bin/env python3
"""
Email Newsletter Generator

Generates professional HTML email newsletters with responsive design.
Uses ToolUsePattern to combine templates, content, and styling.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.tool_use import ToolUsePattern
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


def generate_newsletter_content(config):
    """Generate sample newsletter content."""
    featured_articles = [
        {
            "title": "The Future of AI in Software Development",
            "summary": "Exploring how artificial intelligence is transforming the way we write and maintain code.",
            "link": "https://example.com/article/ai-software-dev",
            "author": "Jane Smith",
            "date": "2026-01-25"
        }
    ]
    
    news_items = [
        {
            "title": "Python 3.14 Released with Major Performance Improvements",
            "summary": "The latest Python release brings significant speed enhancements and new language features.",
            "link": "https://example.com/news/python-3.14",
            "date": "2026-01-22"
        },
        {
            "title": "WebAssembly Adoption Reaches New Heights",
            "summary": "Major browsers announce enhanced WASM support, enabling near-native performance for web apps.",
            "link": "https://example.com/news/wasm-adoption",
            "date": "2026-01-20"
        },
        {
            "title": "Cloud Costs: Survey Shows 60% of Companies Overspending",
            "summary": "New research reveals opportunities for significant cloud infrastructure savings.",
            "link": "https://example.com/news/cloud-costs",
            "date": "2026-01-18"
        }
    ]
    
    product_updates = [
        {
            "title": "New Dashboard Analytics Released",
            "summary": "Track your metrics in real-time with our enhanced analytics dashboard featuring custom widgets.",
            "link": "https://example.com/updates/dashboard-analytics",
            "version": "v2.5.0"
        },
        {
            "title": "API Rate Limits Increased for Pro Plans",
            "summary": "Pro tier users now enjoy 2x higher rate limits for all API endpoints.",
            "link": "https://example.com/updates/api-limits",
            "version": "API v3"
        }
    ]
    
    community_highlights = [
        {
            "title": "Community Meetup: San Francisco",
            "summary": "Join us for networking and tech talks on February 15th. Register now for early bird pricing.",
            "link": "https://example.com/events/sf-meetup",
            "date": "2026-02-15"
        },
        {
            "title": "Open Source Contribution Award Winners",
            "summary": "Congratulations to this month's top contributors to our open source projects.",
            "link": "https://example.com/community/awards",
            "date": "2026-01-30"
        }
    ]
    
    content = {
        "feature": featured_articles,
        "news": news_items,
        "updates": product_updates,
        "community": community_highlights
    }
    
    return content


async def main():
    """Execute newsletter generation workflow."""
    config = load_config()
    
    print("=" * 70)
    print("EMAIL NEWSLETTER GENERATOR")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    json_tool = JSONParserTool()
    
    print("Generating newsletter content...")
    
    content = generate_newsletter_content(config)
    
    content_json = json.dumps(content, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["content_data"],
        content=content_json,
        mode="write"
    )
    
    print(f"Content data saved: {config['paths']['content_data']}")
    
    print("Building newsletter sections...")
    
    newsletter_sections = []
    
    for section_config in config["newsletter"]["sections"]:
        section_title = section_config["title"]
        section_type = section_config["type"]
        max_items = section_config["items"]
        
        section_items = content.get(section_type, [])[:max_items]
        
        newsletter_sections.append({
            "title": section_title,
            "type": section_type,
            "items": section_items
        })
    
    html_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ newsletter_title }} - {{ edition }}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
        }
        .header {
            background: linear-gradient(135deg, {{ primary_color }} 0%, {{ secondary_color }} 100%);
            color: white;
            padding: 40px 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 28px;
        }
        .header p {
            margin: 10px 0 0 0;
            opacity: 0.9;
        }
        .content {
            padding: 30px 20px;
        }
        .section {
            margin-bottom: 40px;
        }
        .section-title {
            color: {{ secondary_color }};
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid {{ primary_color }};
        }
        .article {
            margin-bottom: 25px;
            padding-bottom: 25px;
            border-bottom: 1px solid #e0e0e0;
        }
        .article:last-child {
            border-bottom: none;
        }
        .article-title {
            font-size: 18px;
            font-weight: bold;
            color: {{ secondary_color }};
            margin-bottom: 10px;
        }
        .article-title a {
            color: {{ secondary_color }};
            text-decoration: none;
        }
        .article-title a:hover {
            color: {{ primary_color }};
        }
        .article-meta {
            font-size: 12px;
            color: #666;
            margin-bottom: 8px;
        }
        .article-summary {
            color: #555;
            font-size: 14px;
        }
        .read-more {
            display: inline-block;
            margin-top: 8px;
            color: {{ primary_color }};
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }
        .read-more:hover {
            color: {{ accent_color }};
        }
        .footer {
            background-color: {{ secondary_color }};
            color: white;
            padding: 30px 20px;
            text-align: center;
            font-size: 13px;
        }
        .footer a {
            color: {{ primary_color }};
            text-decoration: none;
        }
        .social-links {
            margin: 20px 0;
        }
        .social-links a {
            display: inline-block;
            margin: 0 10px;
            color: white;
            text-decoration: none;
            font-weight: 500;
        }
        @media only screen and (max-width: 600px) {
            .header h1 {
                font-size: 24px;
            }
            .section-title {
                font-size: 20px;
            }
            .article-title {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{ newsletter_title }}</h1>
            <p>{{ edition }} | {{ company_name }}</p>
        </div>
        
        <div class="content">
            {% for section in sections %}
            <div class="section">
                <div class="section-title">{{ section.title }}</div>
                
                {% for item in section.items %}
                <div class="article">
                    <div class="article-title">
                        <a href="{{ item.link }}">{{ item.title }}</a>
                    </div>
                    
                    {% if item.author %}
                    <div class="article-meta">By {{ item.author }} | {{ item.date }}</div>
                    {% elif item.date %}
                    <div class="article-meta">{{ item.date }}</div>
                    {% elif item.version %}
                    <div class="article-meta">{{ item.version }}</div>
                    {% endif %}
                    
                    <div class="article-summary">
                        {{ item.summary }}
                    </div>
                    
                    <a href="{{ item.link }}" class="read-more">Read more &rarr;</a>
                </div>
                {% endfor %}
            </div>
            {% endfor %}
        </div>
        
        <div class="footer">
            <div><strong>{{ company_name }}</strong></div>
            <div style="margin: 10px 0;">{{ company_address }}</div>
            
            <div class="social-links">
                {% if twitter %}
                <a href="{{ twitter }}">Twitter</a>
                {% endif %}
                {% if linkedin %}
                <a href="{{ linkedin }}">LinkedIn</a>
                {% endif %}
                {% if github %}
                <a href="{{ github }}">GitHub</a>
                {% endif %}
            </div>
            
            <div style="margin-top: 20px; opacity: 0.8;">
                <a href="{{ unsubscribe_link }}">Unsubscribe</a> from this newsletter
            </div>
        </div>
    </div>
</body>
</html>"""
    
    template_data = {
        "newsletter_title": config["newsletter"]["newsletter_title"],
        "edition": config["newsletter"]["edition"],
        "company_name": config["newsletter"]["company_name"],
        "primary_color": config["newsletter"]["theme"]["primary_color"],
        "secondary_color": config["newsletter"]["theme"]["secondary_color"],
        "accent_color": config["newsletter"]["theme"]["accent_color"],
        "sections": newsletter_sections,
        "company_address": config["newsletter"]["footer"]["company_address"],
        "unsubscribe_link": config["newsletter"]["footer"]["unsubscribe_link"],
        "twitter": config["newsletter"]["footer"]["social_links"].get("twitter"),
        "linkedin": config["newsletter"]["footer"]["social_links"].get("linkedin"),
        "github": config["newsletter"]["footer"]["social_links"].get("github")
    }
    
    print("Rendering HTML newsletter...")
    
    html_result = await template_tool.execute(
        template=html_template,
        data=template_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["newsletter_html"],
            content=html_result.result,
            mode="write"
        )
        print(f"HTML newsletter saved: {config['paths']['newsletter_html']}")
    
    if config["settings"]["generate_text_version"]:
        print("Generating plain text version...")
        
        text_lines = []
        text_lines.append("=" * 70)
        text_lines.append(f"{config['newsletter']['newsletter_title']}")
        text_lines.append(f"{config['newsletter']['edition']} | {config['newsletter']['company_name']}")
        text_lines.append("=" * 70)
        text_lines.append("")
        
        for section in newsletter_sections:
            text_lines.append("")
            text_lines.append(f"{section['title'].upper()}")
            text_lines.append("-" * 70)
            text_lines.append("")
            
            for item in section["items"]:
                text_lines.append(f"* {item['title']}")
                
                if "author" in item:
                    text_lines.append(f"  By {item['author']} | {item['date']}")
                elif "date" in item:
                    text_lines.append(f"  {item['date']}")
                elif "version" in item:
                    text_lines.append(f"  {item['version']}")
                
                text_lines.append(f"  {item['summary']}")
                text_lines.append(f"  Read more: {item['link']}")
                text_lines.append("")
        
        text_lines.append("")
        text_lines.append("=" * 70)
        text_lines.append(f"{config['newsletter']['company_name']}")
        text_lines.append(f"{config['newsletter']['footer']['company_address']}")
        text_lines.append("")
        
        for platform, link in config["newsletter"]["footer"]["social_links"].items():
            text_lines.append(f"{platform.capitalize()}: {link}")
        
        text_lines.append("")
        text_lines.append(f"Unsubscribe: {config['newsletter']['footer']['unsubscribe_link']}")
        text_lines.append("=" * 70)
        
        text_content = "\n".join(text_lines)
        
        await writer_tool.execute(
            path=config["paths"]["newsletter_text"],
            content=text_content,
            mode="write"
        )
        
        print(f"Text newsletter saved: {config['paths']['newsletter_text']}")
    
    total_items = sum(len(section["items"]) for section in newsletter_sections)
    
    print()
    print("=" * 70)
    print("NEWSLETTER SUMMARY")
    print("=" * 70)
    print(f"Title: {config['newsletter']['newsletter_title']}")
    print(f"Edition: {config['newsletter']['edition']}")
    print(f"Sections: {len(newsletter_sections)}")
    print(f"Total Items: {total_items}")
    print()
    print("Sections:")
    for section in newsletter_sections:
        print(f"  - {section['title']}: {len(section['items'])} items")
    print()
    print("Output files:")
    print(f"  - Content Data: {config['paths']['content_data']}")
    print(f"  - HTML Newsletter: {config['paths']['newsletter_html']}")
    if config["settings"]["generate_text_version"]:
        print(f"  - Text Newsletter: {config['paths']['newsletter_text']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
