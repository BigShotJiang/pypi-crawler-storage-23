#!/usr/bin/env python3
"""
Customer Insights Dashboard

Analyzes customer data to generate actionable business insights.
Uses PlanningPattern to coordinate data analysis, segmentation, and visualization.
"""

import asyncio
import json
import csv
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, MathCalculatorTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_sample_data(config):
    """Generate sample customer and transaction data."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    customer_count = config["analytics"]["customer_count"]
    date_range_days = config["analytics"]["date_range_days"]
    
    print("Generating customer data...")
    
    with open(config["paths"]["customer_data"], 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["customer_id", "name", "email", "signup_date", "country", "plan_type"])
        
        for i in range(1, customer_count + 1):
            signup_date = (datetime.now() - timedelta(days=random.randint(1, 365))).strftime("%Y-%m-%d")
            country = random.choice(["USA", "UK", "Canada", "Germany", "France", "Australia"])
            plan_type = random.choice(["Free", "Basic", "Pro", "Enterprise"])
            
            writer.writerow([
                f"CUST{i:05d}",
                f"Customer {i}",
                f"customer{i}@example.com",
                signup_date,
                country,
                plan_type
            ])
    
    print(f"Generated {customer_count} customers")
    
    print("Generating transaction data...")
    
    with open(config["paths"]["transactions_data"], 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["transaction_id", "customer_id", "date", "amount", "type"])
        
        txn_id = 1
        for i in range(1, customer_count + 1):
            customer_id = f"CUST{i:05d}"
            num_transactions = random.randint(0, 20)
            
            for _ in range(num_transactions):
                txn_date = (datetime.now() - timedelta(days=random.randint(0, date_range_days))).strftime("%Y-%m-%d")
                amount = round(random.uniform(10, 500), 2)
                txn_type = random.choice(["purchase", "subscription", "upgrade", "refund"])
                
                if txn_type == "refund":
                    amount = -abs(amount)
                
                writer.writerow([
                    f"TXN{txn_id:08d}",
                    customer_id,
                    txn_date,
                    amount,
                    txn_type
                ])
                txn_id += 1
    
    print(f"Generated {txn_id - 1} transactions")


async def main():
    """Execute customer insights analysis workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CUSTOMER INSIGHTS DASHBOARD")
    print("=" * 70)
    print()
    
    await generate_sample_data(config)
    
    csv_tool = CSVProcessorTool()
    sqlite_tool = SQLiteTool()
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing analytics database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id TEXT PRIMARY KEY,
            name TEXT,
            email TEXT,
            signup_date TEXT,
            country TEXT,
            plan_type TEXT
        )
        """
    )
    
    await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id TEXT PRIMARY KEY,
            customer_id TEXT,
            date TEXT,
            amount REAL,
            type TEXT,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        )
        """
    )
    
    print("Loading customer data...")
    
    customers_result = await csv_tool.execute(
        file_path=config["paths"]["customer_data"],
        operation="read"
    )
    
    if customers_result.success:
        customers = customers_result.result
        
        for customer in customers:
            await sqlite_tool.execute(
                database=config["paths"]["insights_db"],
                operation="execute",
                query="""
                INSERT INTO customers (customer_id, name, email, signup_date, country, plan_type)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                params=(
                    customer["customer_id"],
                    customer["name"],
                    customer["email"],
                    customer["signup_date"],
                    customer["country"],
                    customer["plan_type"]
                )
            )
        
        print(f"Loaded {len(customers)} customers")
    
    print("Loading transaction data...")
    
    transactions_result = await csv_tool.execute(
        file_path=config["paths"]["transactions_data"],
        operation="read"
    )
    
    if transactions_result.success:
        transactions = transactions_result.result
        
        for txn in transactions:
            await sqlite_tool.execute(
                database=config["paths"]["insights_db"],
                operation="execute",
                query="""
                INSERT INTO transactions (transaction_id, customer_id, date, amount, type)
                VALUES (?, ?, ?, ?, ?)
                """,
                params=(
                    txn["transaction_id"],
                    txn["customer_id"],
                    txn["date"],
                    float(txn["amount"]),
                    txn["type"]
                )
            )
        
        print(f"Loaded {len(transactions)} transactions")
    
    print("\nCalculating customer metrics...")
    
    revenue_result = await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="query",
        query="""
        SELECT 
            SUM(amount) as total_revenue,
            AVG(amount) as avg_transaction,
            COUNT(*) as total_transactions
        FROM transactions
        WHERE amount > 0
        """
    )
    
    revenue_metrics = revenue_result.result[0] if revenue_result.success else {}
    
    clv_result = await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="query",
        query="""
        SELECT 
            customer_id,
            SUM(amount) as lifetime_value,
            COUNT(*) as total_transactions,
            MIN(date) as first_transaction,
            MAX(date) as last_transaction
        FROM transactions
        GROUP BY customer_id
        """
    )
    
    customer_values = clv_result.result if clv_result.success else []
    
    avg_clv = sum(c["lifetime_value"] for c in customer_values) / len(customer_values) if customer_values else 0
    
    active_customers = len([c for c in customer_values if c["total_transactions"] > 0])
    total_customers = len(customers) if customers_result.success else 0
    
    churn_rate = ((total_customers - active_customers) / total_customers * 100) if total_customers > 0 else 0
    
    plan_distribution = await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="query",
        query="""
        SELECT 
            plan_type,
            COUNT(*) as customer_count,
            CAST(COUNT(*) AS FLOAT) / (SELECT COUNT(*) FROM customers) * 100 as percentage
        FROM customers
        GROUP BY plan_type
        ORDER BY customer_count DESC
        """
    )
    
    plan_stats = plan_distribution.result if plan_distribution.success else []
    
    country_distribution = await sqlite_tool.execute(
        database=config["paths"]["insights_db"],
        operation="query",
        query="""
        SELECT 
            country,
            COUNT(*) as customer_count
        FROM customers
        GROUP BY country
        ORDER BY customer_count DESC
        LIMIT 5
        """
    )
    
    country_stats = country_distribution.result if country_distribution.success else []
    
    print("Performing customer segmentation...")
    
    segments = {
        "high_value": [],
        "at_risk": [],
        "new_customers": [],
        "loyal_customers": [],
        "inactive": []
    }
    
    for customer_value in customer_values:
        customer_id = customer_value["customer_id"]
        lifetime_value = customer_value["lifetime_value"]
        total_txns = customer_value["total_transactions"]
        last_txn_date = datetime.strptime(customer_value["last_transaction"], "%Y-%m-%d")
        days_since_last = (datetime.now() - last_txn_date).days
        
        if lifetime_value > avg_clv * 1.5:
            segments["high_value"].append(customer_id)
        
        if total_txns >= 5 and days_since_last > 60:
            segments["at_risk"].append(customer_id)
        
        if total_txns >= 10:
            segments["loyal_customers"].append(customer_id)
        
        if days_since_last > 90:
            segments["inactive"].append(customer_id)
    
    for customer in customers:
        signup_date = datetime.strptime(customer["signup_date"], "%Y-%m-%d")
        days_since_signup = (datetime.now() - signup_date).days
        
        if days_since_signup <= 30:
            segments["new_customers"].append(customer["customer_id"])
    
    recommendations = []
    
    if len(segments["at_risk"]) > 0:
        recommendations.append({
            "priority": "HIGH",
            "segment": "At-Risk Customers",
            "count": len(segments["at_risk"]),
            "action": "Launch re-engagement campaign with personalized offers"
        })
    
    if len(segments["high_value"]) > 0:
        recommendations.append({
            "priority": "HIGH",
            "segment": "High-Value Customers",
            "count": len(segments["high_value"]),
            "action": "Implement VIP program with exclusive benefits and dedicated support"
        })
    
    if len(segments["inactive"]) > 0:
        recommendations.append({
            "priority": "MEDIUM",
            "segment": "Inactive Customers",
            "count": len(segments["inactive"]),
            "action": "Send win-back email campaign with incentives to return"
        })
    
    if churn_rate > 20:
        recommendations.append({
            "priority": "HIGH",
            "segment": "Overall",
            "count": total_customers,
            "action": f"Address high churn rate ({churn_rate:.1f}%) - investigate customer satisfaction"
        })
    
    insights = {
        "timestamp": datetime.now().isoformat(),
        "overview": {
            "total_customers": total_customers,
            "active_customers": active_customers,
            "total_revenue": round(revenue_metrics.get("total_revenue", 0), 2),
            "avg_transaction": round(revenue_metrics.get("avg_transaction", 0), 2),
            "avg_customer_lifetime_value": round(avg_clv, 2),
            "churn_rate": round(churn_rate, 2)
        },
        "segmentation": {k: len(v) for k, v in segments.items()},
        "plan_distribution": plan_stats,
        "top_countries": country_stats,
        "recommendations": recommendations
    }
    
    insights_json = json.dumps(insights, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["insights_report"],
        content=insights_json,
        mode="write"
    )
    
    print(f"Insights report saved: {config['paths']['insights_report']}")
    
    print("Generating dashboard...")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Customer Insights Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 { color: #2c3e50; margin-bottom: 10px; }
        .timestamp { color: #7f8c8d; font-size: 14px; margin-bottom: 30px; }
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .metric-card { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-label { font-size: 14px; color: #7f8c8d; margin-bottom: 8px; text-transform: uppercase; }
        .metric-value { font-size: 36px; font-weight: bold; color: #2c3e50; }
        .metric-unit { font-size: 18px; color: #95a5a6; }
        .section { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .section-title { font-size: 20px; font-weight: bold; color: #2c3e50; margin-bottom: 20px; }
        .segment-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .segment-box { background: #ecf0f1; padding: 15px; border-radius: 5px; text-align: center; }
        .segment-count { font-size: 28px; font-weight: bold; color: #3498db; }
        .segment-label { font-size: 14px; color: #7f8c8d; margin-top: 5px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #34495e; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #ecf0f1; }
        .priority-high { background: #e74c3c; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .priority-medium { background: #f39c12; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .bar-container { background: #ecf0f1; height: 25px; border-radius: 3px; overflow: hidden; margin-top: 5px; }
        .bar-fill { background: #3498db; height: 100%; display: flex; align-items: center; padding: 0 8px; color: white; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Customer Insights Dashboard</h1>
        <div class="timestamp">Generated: {{ timestamp }}</div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">Total Customers</div>
                <div class="metric-value">{{ total_customers }}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Active Customers</div>
                <div class="metric-value">{{ active_customers }}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Total Revenue</div>
                <div class="metric-value">${{ total_revenue }}<span class="metric-unit"></span></div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Avg Customer LTV</div>
                <div class="metric-value">${{ avg_clv }}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Churn Rate</div>
                <div class="metric-value">{{ churn_rate }}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Avg Transaction</div>
                <div class="metric-value">${{ avg_transaction }}</div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Customer Segmentation</div>
            <div class="segment-grid">
                <div class="segment-box">
                    <div class="segment-count">{{ high_value_count }}</div>
                    <div class="segment-label">High Value</div>
                </div>
                <div class="segment-box">
                    <div class="segment-count">{{ at_risk_count }}</div>
                    <div class="segment-label">At Risk</div>
                </div>
                <div class="segment-box">
                    <div class="segment-count">{{ new_customers_count }}</div>
                    <div class="segment-label">New Customers</div>
                </div>
                <div class="segment-box">
                    <div class="segment-count">{{ loyal_count }}</div>
                    <div class="segment-label">Loyal</div>
                </div>
                <div class="segment-box">
                    <div class="segment-count">{{ inactive_count }}</div>
                    <div class="segment-label">Inactive</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Plan Distribution</div>
            {% for plan in plan_distribution %}
            <div style="margin-bottom: 15px;">
                <div>{{ plan.plan_type }}: {{ plan.customer_count }} customers</div>
                <div class="bar-container">
                    <div class="bar-fill" style="width: {{ plan.percentage }}%">{{ plan.percentage|round(1) }}%</div>
                </div>
            </div>
            {% endfor %}
        </div>
        
        <div class="section">
            <div class="section-title">Top Countries</div>
            <table>
                <thead>
                    <tr>
                        <th>Country</th>
                        <th>Customers</th>
                    </tr>
                </thead>
                <tbody>
                {% for country in top_countries %}
                    <tr>
                        <td>{{ country.country }}</td>
                        <td>{{ country.customer_count }}</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
        
        {% if recommendations %}
        <div class="section">
            <div class="section-title">Recommended Actions</div>
            <table>
                <thead>
                    <tr>
                        <th>Priority</th>
                        <th>Segment</th>
                        <th>Customers</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                {% for rec in recommendations %}
                    <tr>
                        <td><span class="priority-{{ rec.priority|lower }}">{{ rec.priority }}</span></td>
                        <td>{{ rec.segment }}</td>
                        <td>{{ rec.count }}</td>
                        <td>{{ rec.action }}</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
    </div>
</body>
</html>"""
    
    dashboard_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_customers": insights["overview"]["total_customers"],
        "active_customers": insights["overview"]["active_customers"],
        "total_revenue": f"{insights['overview']['total_revenue']:,.2f}",
        "avg_clv": f"{insights['overview']['avg_customer_lifetime_value']:,.2f}",
        "churn_rate": f"{insights['overview']['churn_rate']:.1f}",
        "avg_transaction": f"{insights['overview']['avg_transaction']:.2f}",
        "high_value_count": insights["segmentation"]["high_value"],
        "at_risk_count": insights["segmentation"]["at_risk"],
        "new_customers_count": insights["segmentation"]["new_customers"],
        "loyal_count": insights["segmentation"]["loyal_customers"],
        "inactive_count": insights["segmentation"]["inactive"],
        "plan_distribution": insights["plan_distribution"],
        "top_countries": insights["top_countries"],
        "recommendations": insights["recommendations"]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=dashboard_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["dashboard_html"],
            content=html_result.result,
            mode="write"
        )
        print(f"Dashboard saved: {config['paths']['dashboard_html']}")
    
    print()
    print("=" * 70)
    print("INSIGHTS SUMMARY")
    print("=" * 70)
    print(f"Total Customers: {insights['overview']['total_customers']}")
    print(f"Active Customers: {insights['overview']['active_customers']}")
    print(f"Total Revenue: ${insights['overview']['total_revenue']:,.2f}")
    print(f"Avg Customer LTV: ${insights['overview']['avg_customer_lifetime_value']:,.2f}")
    print(f"Churn Rate: {insights['overview']['churn_rate']:.1f}%")
    print()
    print("Customer Segments:")
    for segment, count in insights["segmentation"].items():
        print(f"  {segment.replace('_', ' ').title()}: {count}")
    print()
    if recommendations:
        print(f"Recommended Actions: {len(recommendations)}")
        for rec in recommendations:
            print(f"  [{rec['priority']}] {rec['segment']}: {rec['action']}")
        print()
    print("Output files:")
    print(f"  - Insights Database: {config['paths']['insights_db']}")
    print(f"  - Insights Report: {config['paths']['insights_report']}")
    print(f"  - Dashboard: {config['paths']['dashboard_html']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
