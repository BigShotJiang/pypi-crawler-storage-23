#!/usr/bin/env python3
"""
Social Media Analytics

Analyzes social media performance across multiple platforms.
Uses ReflectionPattern to analyze metrics and generate insights.
"""

import asyncio
import json
import random
import csv
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.reflection import ReflectionPattern
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, MathCalculatorTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


def generate_sample_metrics(config):
    """Generate sample social media metrics."""
    metrics = []
    
    start_date = datetime.now() - timedelta(days=config["analytics"]["time_period_days"])
    
    for platform in config["analytics"]["platforms"]:
        for i in range(config["analytics"]["posts_per_platform"]):
            post_date = start_date + timedelta(
                days=random.randint(0, config["analytics"]["time_period_days"])
            )
            
            base_engagement = random.randint(100, 5000)
            
            if platform == "twitter":
                reach = random.randint(1000, 50000)
                impressions = int(reach * random.uniform(1.2, 3.0))
            elif platform == "facebook":
                reach = random.randint(500, 30000)
                impressions = int(reach * random.uniform(1.5, 4.0))
            else:
                reach = random.randint(800, 40000)
                impressions = int(reach * random.uniform(1.3, 3.5))
            
            clicks = int(impressions * random.uniform(0.01, 0.05))
            shares = int(base_engagement * random.uniform(0.1, 0.3))
            comments = int(base_engagement * random.uniform(0.05, 0.2))
            likes = base_engagement
            
            engagement = likes + shares + comments + clicks
            engagement_rate = (engagement / impressions * 100) if impressions > 0 else 0
            
            metrics.append({
                "platform": platform,
                "post_id": f"{platform}_{i+1}",
                "date": post_date.strftime("%Y-%m-%d"),
                "reach": reach,
                "impressions": impressions,
                "clicks": clicks,
                "shares": shares,
                "comments": comments,
                "likes": likes,
                "engagement": engagement,
                "engagement_rate": round(engagement_rate, 2)
            })
    
    return metrics


async def main():
    """Execute social media analytics workflow."""
    config = load_config()
    
    print("=" * 70)
    print("SOCIAL MEDIA ANALYTICS")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    csv_tool = CSVProcessorTool()
    sqlite_tool = SQLiteTool()
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("Generating sample metrics...")
    
    metrics = generate_sample_metrics(config)
    
    print(f"Generated {len(metrics)} social media posts")
    
    print("\nInitializing analytics database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["analytics_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS social_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            post_id TEXT NOT NULL,
            post_date TEXT,
            reach INTEGER,
            impressions INTEGER,
            clicks INTEGER,
            shares INTEGER,
            comments INTEGER,
            likes INTEGER,
            engagement INTEGER,
            engagement_rate REAL
        )
        """
    )
    
    print("Storing metrics in database...")
    
    for metric in metrics:
        await sqlite_tool.execute(
            database=config["paths"]["analytics_db"],
            operation="execute",
            query="""
            INSERT INTO social_metrics 
            (platform, post_id, post_date, reach, impressions, clicks, shares, comments, likes, engagement, engagement_rate)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            params=(
                metric["platform"],
                metric["post_id"],
                metric["date"],
                metric["reach"],
                metric["impressions"],
                metric["clicks"],
                metric["shares"],
                metric["comments"],
                metric["likes"],
                metric["engagement"],
                metric["engagement_rate"]
            )
        )
    
    print(f"\nSaving metrics to CSV: {config['paths']['metrics_csv']}")
    
    with open(config["paths"]["metrics_csv"], 'w', newline='') as f:
        if metrics:
            writer = csv.DictWriter(f, fieldnames=metrics[0].keys())
            writer.writeheader()
            writer.writerows(metrics)
    
    print("\nAnalyzing platform performance...")
    
    platform_stats = {}
    
    for platform in config["analytics"]["platforms"]:
        platform_metrics = [m for m in metrics if m["platform"] == platform]
        
        if not platform_metrics:
            continue
        
        total_reach = sum(m["reach"] for m in platform_metrics)
        total_impressions = sum(m["impressions"] for m in platform_metrics)
        total_engagement = sum(m["engagement"] for m in platform_metrics)
        total_clicks = sum(m["clicks"] for m in platform_metrics)
        
        avg_engagement_rate = sum(m["engagement_rate"] for m in platform_metrics) / len(platform_metrics)
        
        platform_stats[platform] = {
            "posts": len(platform_metrics),
            "total_reach": total_reach,
            "total_impressions": total_impressions,
            "total_engagement": total_engagement,
            "total_clicks": total_clicks,
            "avg_engagement_rate": round(avg_engagement_rate, 2),
            "avg_reach": int(total_reach / len(platform_metrics)),
            "avg_impressions": int(total_impressions / len(platform_metrics))
        }
        
        print(f"\n  {platform.upper()}:")
        print(f"    Posts: {platform_stats[platform]['posts']}")
        print(f"    Total Reach: {platform_stats[platform]['total_reach']:,}")
        print(f"    Total Impressions: {platform_stats[platform]['total_impressions']:,}")
        print(f"    Total Engagement: {platform_stats[platform]['total_engagement']:,}")
        print(f"    Avg Engagement Rate: {platform_stats[platform]['avg_engagement_rate']:.2f}%")
    
    insights = {
        "timestamp": datetime.now().isoformat(),
        "time_period_days": config["analytics"]["time_period_days"],
        "total_posts": len(metrics),
        "platforms": platform_stats,
        "top_posts": []
    }
    
    if config["settings"]["calculate_trends"]:
        print("\n\nCalculating trends...")
        
        sorted_by_engagement = sorted(metrics, key=lambda x: x["engagement_rate"], reverse=True)
        
        insights["top_posts"] = [
            {
                "platform": post["platform"],
                "post_id": post["post_id"],
                "date": post["date"],
                "engagement_rate": post["engagement_rate"],
                "engagement": post["engagement"]
            }
            for post in sorted_by_engagement[:5]
        ]
        
        print("  Top 5 Posts by Engagement Rate:")
        for i, post in enumerate(insights["top_posts"], 1):
            print(f"    {i}. {post['platform']} - {post['post_id']}: {post['engagement_rate']:.2f}%")
    
    if config["settings"]["generate_recommendations"]:
        print("\n\nGenerating recommendations...")
        
        recommendations = []
        
        best_platform = max(platform_stats.items(), key=lambda x: x[1]["avg_engagement_rate"])
        recommendations.append(
            f"Focus on {best_platform[0]} - highest avg engagement rate ({best_platform[1]['avg_engagement_rate']:.2f}%)"
        )
        
        for platform, stats in platform_stats.items():
            if stats["avg_engagement_rate"] < 2.0:
                recommendations.append(
                    f"Improve {platform} content strategy - engagement rate below 2%"
                )
        
        insights["recommendations"] = recommendations
        
        print("  Recommendations:")
        for i, rec in enumerate(recommendations, 1):
            print(f"    {i}. {rec}")
    
    await writer_tool.execute(
        path=config["paths"]["insights_json"],
        content=json.dumps(insights, indent=2),
        mode="write"
    )
    
    print(f"\n\nInsights saved: {config['paths']['insights_json']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Social Media Analytics Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1400px; margin: 40px auto; padding: 20px; background: #f5f5f5; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .platforms { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0; }
        .platform-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .platform-name { font-size: 24px; font-weight: bold; color: #2c3e50; margin-bottom: 15px; }
        .metric { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #ecf0f1; }
        .metric-label { color: #7f8c8d; }
        .metric-value { font-weight: bold; color: #2c3e50; }
        .engagement-rate { font-size: 36px; font-weight: bold; text-align: center; margin: 15px 0; color: #3498db; }
        .top-posts { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .recommendations { background: #fff3cd; padding: 20px; border-radius: 8px; border-left: 5px solid #ffc107; margin: 20px 0; }
        .recommendation-item { margin: 10px 0; padding-left: 20px; }
    </style>
</head>
<body>
    <h1>Social Media Analytics Dashboard</h1>
    
    <div class="summary">
        <h2>Overview</h2>
        <p><strong>Period:</strong> Last {{ time_period_days }} days</p>
        <p><strong>Total Posts:</strong> {{ total_posts }}</p>
        <p><strong>Generated:</strong> {{ timestamp }}</p>
    </div>
    
    <h2>Platform Performance</h2>
    <div class="platforms">
        {% for platform, stats in platforms.items() %}
        <div class="platform-card">
            <div class="platform-name">{{ platform.upper() }}</div>
            <div class="engagement-rate">{{ stats.avg_engagement_rate }}%</div>
            <div style="text-align: center; color: #7f8c8d; margin-bottom: 15px;">Avg Engagement Rate</div>
            <div class="metric">
                <span class="metric-label">Posts</span>
                <span class="metric-value">{{ stats.posts }}</span>
            </div>
            <div class="metric">
                <span class="metric-label">Total Reach</span>
                <span class="metric-value">{{ "{:,}".format(stats.total_reach) }}</span>
            </div>
            <div class="metric">
                <span class="metric-label">Total Impressions</span>
                <span class="metric-value">{{ "{:,}".format(stats.total_impressions) }}</span>
            </div>
            <div class="metric">
                <span class="metric-label">Total Engagement</span>
                <span class="metric-value">{{ "{:,}".format(stats.total_engagement) }}</span>
            </div>
        </div>
        {% endfor %}
    </div>
    
    {% if top_posts %}
    <div class="top-posts">
        <h2>Top Performing Posts</h2>
        <table>
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Platform</th>
                    <th>Post ID</th>
                    <th>Date</th>
                    <th>Engagement Rate</th>
                    <th>Total Engagement</th>
                </tr>
            </thead>
            <tbody>
            {% for post in top_posts %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td>{{ post.platform }}</td>
                    <td>{{ post.post_id }}</td>
                    <td>{{ post.date }}</td>
                    <td>{{ post.engagement_rate }}%</td>
                    <td>{{ "{:,}".format(post.engagement) }}</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
    {% endif %}
    
    {% if recommendations %}
    <div class="recommendations">
        <h2>Recommendations</h2>
        {% for rec in recommendations %}
        <div class="recommendation-item">{{ loop.index }}. {{ rec }}</div>
        {% endfor %}
    </div>
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "time_period_days": config["analytics"]["time_period_days"],
        "total_posts": len(metrics),
        "platforms": platform_stats,
        "top_posts": insights.get("top_posts", []),
        "recommendations": insights.get("recommendations", [])
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["dashboard"],
            content=html_result.result,
            mode="write"
        )
        print(f"Dashboard saved: {config['paths']['dashboard']}")
    
    print()
    print("=" * 70)
    print("ANALYTICS SUMMARY")
    print("=" * 70)
    print(f"Time Period: {config['analytics']['time_period_days']} days")
    print(f"Total Posts: {len(metrics)}")
    print(f"Platforms: {', '.join(config['analytics']['platforms'])}")
    print()
    print("Output files:")
    print(f"  - Analytics Database: {config['paths']['analytics_db']}")
    print(f"  - Metrics CSV: {config['paths']['metrics_csv']}")
    print(f"  - Dashboard: {config['paths']['dashboard']}")
    print(f"  - Insights: {config['paths']['insights_json']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
