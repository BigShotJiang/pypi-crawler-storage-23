#!/usr/bin/env python3
"""
Code Quality Reporter

Analyzes Python codebase to generate quality metrics including line counts,
function/class counts, docstring coverage, and complexity. Uses planning pattern
to orchestrate analysis and report generation.
"""

import asyncio
import json
import re
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import FileSearchTool, FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import CodeBlockExtractorTool
from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_project(config):
    """Create sample Python project for analysis."""
    target_dir = Path(config["analysis"]["target_dir"])
    target_dir.mkdir(parents=True, exist_ok=True)
    
    sample_files = {
        "main.py": '''"""Main application module."""

def main():
    """Entry point for the application."""
    print("Application started")
    return 0

class Application:
    """Main application class."""
    
    def __init__(self):
        """Initialize the application."""
        self.status = "initialized"
    
    def run(self):
        """Run the application."""
        return self.status

if __name__ == "__main__":
    main()
''',
        "utils.py": '''"""Utility functions for the application."""

def helper_one(x, y):
    """Add two numbers."""
    return x + y

def helper_two(data):
    """Process data."""
    result = []
    for item in data:
        if item:
            result.append(item)
    return result

class DataProcessor:
    """Process various data types."""
    
    def process(self, data):
        return data.strip()
    
    def validate(self, data):
        """Validate input data."""
        return len(data) > 0
''',
        "models.py": '''class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email
    
    def get_name(self):
        return self.name

class Product:
    def __init__(self, id, name, price):
        self.id = id
        self.name = name
        self.price = price
''',
        "services.py": '''"""Service layer for business logic."""

class UserService:
    """Handle user-related operations."""
    
    def create_user(self, name, email):
        """Create a new user."""
        return {"name": name, "email": email}
    
    def update_user(self, user_id, data):
        """Update existing user."""
        return data

def calculate_total(items):
    """Calculate total price of items."""
    total = 0
    for item in items:
        total += item.get("price", 0)
    return total
'''
    }
    
    for file_path, content in sample_files.items():
        full_path = target_dir / file_path
        with open(full_path, 'w') as f:
            f.write(content)
    
    print(f"Created sample project with {len(sample_files)} files at {target_dir}")


async def main():
    """Execute the code quality analysis workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CODE QUALITY REPORTER")
    print("=" * 70)
    print()
    
    await create_sample_project(config)
    
    search_tool = FileSearchTool()
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    code_tool = CodeBlockExtractorTool()
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nAnalyzing Python files...")
    
    search_result = await search_tool.execute(
        directory=config["analysis"]["target_dir"],
        pattern="*.py",
        recursive=True
    )
    
    if not search_result.success:
        print(f"Error searching files: {search_result.error}")
        return
    
    python_files = search_result.result
    print(f"Found {len(python_files)} Python files")
    
    file_metrics = []
    total_lines = 0
    total_functions = 0
    total_classes = 0
    total_docstrings = 0
    total_comments = 0
    
    for file_path in python_files:
        read_result = await reader_tool.execute(path=file_path)
        
        if not read_result.success:
            continue
        
        content = read_result.result
        lines = content.split('\n')
        
        line_count = len(lines)
        code_lines = len([l for l in lines if l.strip() and not l.strip().startswith('#')])
        comment_lines = len([l for l in lines if l.strip().startswith('#')])
        blank_lines = len([l for l in lines if not l.strip()])
        
        function_pattern = r'^\s*def\s+\w+\s*\('
        class_pattern = r'^\s*class\s+\w+'
        docstring_pattern = r'""".*?"""'
        
        function_result = await regex_tool.execute(
            pattern=function_pattern,
            text=content,
            operation="findall",
            flags=["MULTILINE"]
        )
        functions = len(function_result.result) if function_result.success else 0
        
        class_result = await regex_tool.execute(
            pattern=class_pattern,
            text=content,
            operation="findall",
            flags=["MULTILINE"]
        )
        classes = len(class_result.result) if class_result.success else 0
        
        docstring_result = await regex_tool.execute(
            pattern=docstring_pattern,
            text=content,
            operation="findall",
            flags=["DOTALL"]
        )
        docstrings = len(docstring_result.result) if docstring_result.success else 0
        
        file_metric = {
            "file": Path(file_path).name,
            "path": file_path,
            "total_lines": line_count,
            "code_lines": code_lines,
            "comment_lines": comment_lines,
            "blank_lines": blank_lines,
            "functions": functions,
            "classes": classes,
            "docstrings": docstrings
        }
        
        file_metrics.append(file_metric)
        
        total_lines += line_count
        total_functions += functions
        total_classes += classes
        total_docstrings += docstrings
        total_comments += comment_lines
    
    avg_lines_per_file = total_lines / len(file_metrics) if file_metrics else 0
    docstring_coverage = (total_docstrings / (total_functions + total_classes) * 100) if (total_functions + total_classes) > 0 else 0
    comment_ratio = (total_comments / total_lines * 100) if total_lines > 0 else 0
    
    quality_report = {
        "analysis_info": {
            "timestamp": datetime.now().isoformat(),
            "target_directory": config["analysis"]["target_dir"],
            "files_analyzed": len(file_metrics)
        },
        "summary": {
            "total_lines": total_lines,
            "total_functions": total_functions,
            "total_classes": total_classes,
            "total_docstrings": total_docstrings,
            "avg_lines_per_file": round(avg_lines_per_file, 2),
            "docstring_coverage_percent": round(docstring_coverage, 2),
            "comment_ratio_percent": round(comment_ratio, 2)
        },
        "files": file_metrics,
        "recommendations": []
    }
    
    if docstring_coverage < 50:
        quality_report["recommendations"].append("Improve docstring coverage (currently below 50%)")
    if comment_ratio < 10:
        quality_report["recommendations"].append("Add more code comments for better maintainability")
    if avg_lines_per_file > 300:
        quality_report["recommendations"].append("Consider breaking down large files (avg > 300 lines)")
    
    if not quality_report["recommendations"]:
        quality_report["recommendations"].append("Code quality metrics look good!")
    
    report_json = json.dumps(quality_report, indent=2)
    
    json_write_result = await writer_tool.execute(
        path=config["paths"]["report_json"],
        content=report_json,
        mode="write"
    )
    
    if json_write_result.success:
        print(f"\nJSON report saved: {config['paths']['report_json']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Code Quality Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .metric { display: inline-block; margin: 10px 30px 10px 0; }
        .metric-value { font-size: 28px; font-weight: bold; color: #3498db; }
        .metric-label { font-size: 14px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .recommendations { background: #d4edda; padding: 20px; border-left: 4px solid #28a745; margin: 20px 0; }
        .warning { background: #fff3cd; border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <h1>Code Quality Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Target Directory:</strong> {{ target_dir }}</p>
    <p><strong>Files Analyzed:</strong> {{ files_analyzed }}</p>
    
    <div class="summary">
        <h2>Quality Metrics</h2>
        <div class="metric">
            <div class="metric-value">{{ total_lines }}</div>
            <div class="metric-label">Total Lines</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ total_functions }}</div>
            <div class="metric-label">Functions</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ total_classes }}</div>
            <div class="metric-label">Classes</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ docstring_coverage }}%</div>
            <div class="metric-label">Docstring Coverage</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ comment_ratio }}%</div>
            <div class="metric-label">Comment Ratio</div>
        </div>
    </div>
    
    <h2>File Breakdown</h2>
    <table>
        <thead>
            <tr>
                <th>File</th>
                <th>Lines</th>
                <th>Functions</th>
                <th>Classes</th>
                <th>Docstrings</th>
            </tr>
        </thead>
        <tbody>
        {% for file in files %}
            <tr>
                <td>{{ file.file }}</td>
                <td>{{ file.total_lines }}</td>
                <td>{{ file.functions }}</td>
                <td>{{ file.classes }}</td>
                <td>{{ file.docstrings }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <div class="recommendations {% if docstring_coverage < 50 %}warning{% endif %}">
        <h2>Recommendations</h2>
        <ul>
        {% for rec in recommendations %}
            <li>{{ rec }}</li>
        {% endfor %}
        </ul>
    </div>
</body>
</html>"""
    
    html_data = {
        "timestamp": quality_report["analysis_info"]["timestamp"],
        "target_dir": quality_report["analysis_info"]["target_directory"],
        "files_analyzed": quality_report["analysis_info"]["files_analyzed"],
        "total_lines": quality_report["summary"]["total_lines"],
        "total_functions": quality_report["summary"]["total_functions"],
        "total_classes": quality_report["summary"]["total_classes"],
        "docstring_coverage": quality_report["summary"]["docstring_coverage_percent"],
        "comment_ratio": quality_report["summary"]["comment_ratio_percent"],
        "files": file_metrics,
        "recommendations": quality_report["recommendations"]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        html_write_result = await writer_tool.execute(
            path=config["paths"]["report_html"],
            content=html_result.result,
            mode="write"
        )
        if html_write_result.success:
            print(f"HTML report saved: {config['paths']['report_html']}")
    
    print()
    print("=" * 70)
    print("QUALITY ANALYSIS SUMMARY")
    print("=" * 70)
    print(f"Files Analyzed: {len(file_metrics)}")
    print(f"Total Lines: {total_lines}")
    print(f"Functions: {total_functions}")
    print(f"Classes: {total_classes}")
    print(f"Docstring Coverage: {docstring_coverage:.1f}%")
    print(f"Comment Ratio: {comment_ratio:.1f}%")
    print()
    print("Reports generated:")
    print(f"  - {config['paths']['report_json']}")
    print(f"  - {config['paths']['report_html']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
