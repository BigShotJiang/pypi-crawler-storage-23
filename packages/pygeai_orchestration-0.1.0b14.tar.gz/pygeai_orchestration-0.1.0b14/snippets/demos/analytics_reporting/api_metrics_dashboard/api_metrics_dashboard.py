#!/usr/bin/env python3
"""
API Metrics Dashboard

Analyzes API request logs to generate performance metrics and visualizations.
Uses PlanningPattern to orchestrate log parsing, metrics calculation, and reporting.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool, MathCalculatorTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_api_logs(config):
    """Generate simulated API request logs."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    num_requests = config["simulation"]["num_requests"]
    endpoints = config["simulation"]["endpoints"]
    methods = config["simulation"]["methods"]
    status_codes = config["simulation"]["status_codes"]
    
    print(f"Generating {num_requests} API request logs...")
    
    base_time = datetime.now() - timedelta(hours=1)
    
    with open(config["paths"]["raw_logs"], 'w') as f:
        for i in range(num_requests):
            timestamp = base_time + timedelta(seconds=i * 7.2)
            timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
            
            endpoint = random.choice(endpoints)
            method = random.choice(methods)
            
            if endpoint == "/api/auth/login" and method == "POST":
                status = random.choices([200, 401, 400], weights=[0.8, 0.15, 0.05])[0]
            elif method == "GET":
                status = random.choices([200, 404, 500], weights=[0.9, 0.08, 0.02])[0]
            elif method in ["POST", "PUT"]:
                status = random.choices([201, 400, 500], weights=[0.85, 0.12, 0.03])[0]
            else:
                status = random.choice(status_codes)
            
            if status >= 500:
                response_time = random.randint(2000, 5000)
            elif status >= 400:
                response_time = random.randint(50, 300)
            else:
                if endpoint == "/api/search":
                    response_time = random.randint(200, 1500)
                elif endpoint == "/api/orders":
                    response_time = random.randint(100, 800)
                else:
                    response_time = random.randint(20, 400)
            
            user_id = f"user_{random.randint(1, 100)}"
            
            log_line = f"{timestamp_str} | {method} {endpoint} | Status: {status} | {response_time}ms | User: {user_id}\n"
            f.write(log_line)
    
    print(f"Generated logs at {config['paths']['raw_logs']}")


async def main():
    """Execute API metrics analysis workflow."""
    config = load_config()
    
    print("=" * 70)
    print("API METRICS DASHBOARD")
    print("=" * 70)
    print()
    
    await generate_api_logs(config)
    
    reader_tool = FileReaderTool()
    sqlite_tool = SQLiteTool()
    stats_tool = MathCalculatorTool()
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing metrics database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS api_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            method TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            status_code INTEGER NOT NULL,
            response_time_ms INTEGER NOT NULL,
            user_id TEXT
        )
        """
    )
    
    print("Parsing API logs...")
    
    read_result = await reader_tool.execute(path=config["paths"]["raw_logs"])
    
    if not read_result.success:
        print(f"Error reading logs: {read_result.error}")
        return
    
    log_content = read_result.result
    log_lines = log_content.strip().split('\n')
    
    print(f"Parsing {len(log_lines)} log entries...")
    
    for line in log_lines:
        parts = line.split('|')
        if len(parts) != 5:
            continue
        
        timestamp = parts[0].strip()
        method_endpoint = parts[1].strip().split()
        method = method_endpoint[0]
        endpoint = method_endpoint[1]
        status_code = int(parts[2].strip().replace("Status: ", ""))
        response_time = int(parts[3].strip().replace("ms", ""))
        user_id = parts[4].strip().replace("User: ", "")
        
        await sqlite_tool.execute(
            database=config["paths"]["metrics_db"],
            operation="execute",
            query="""
            INSERT INTO api_requests (timestamp, method, endpoint, status_code, response_time_ms, user_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            params=(timestamp, method, endpoint, status_code, response_time, user_id)
        )
    
    print(f"Loaded {len(log_lines)} requests into database")
    
    print("\nCalculating metrics...")
    
    total_requests_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="SELECT COUNT(*) as count FROM api_requests"
    )
    
    total_requests = total_requests_result.result[0]["count"] if total_requests_result.success else 0
    
    success_count_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="SELECT COUNT(*) as count FROM api_requests WHERE status_code < 400"
    )
    
    success_count = success_count_result.result[0]["count"] if success_count_result.success else 0
    success_rate = (success_count / total_requests * 100) if total_requests > 0 else 0
    
    endpoint_stats_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="""
        SELECT 
            endpoint,
            COUNT(*) as request_count,
            AVG(response_time_ms) as avg_response_time,
            MIN(response_time_ms) as min_response_time,
            MAX(response_time_ms) as max_response_time,
            SUM(CASE WHEN status_code < 400 THEN 1 ELSE 0 END) as success_count,
            SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as error_count
        FROM api_requests
        GROUP BY endpoint
        ORDER BY request_count DESC
        """
    )
    
    endpoint_stats = endpoint_stats_result.result if endpoint_stats_result.success else []
    
    for stat in endpoint_stats:
        stat["success_rate"] = (stat["success_count"] / stat["request_count"] * 100) if stat["request_count"] > 0 else 0
    
    status_distribution_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="""
        SELECT 
            status_code,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM api_requests), 2) as percentage
        FROM api_requests
        GROUP BY status_code
        ORDER BY count DESC
        """
    )
    
    status_distribution = status_distribution_result.result if status_distribution_result.success else []
    
    response_times_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="SELECT response_time_ms FROM api_requests ORDER BY response_time_ms"
    )
    
    response_times = [r["response_time_ms"] for r in response_times_result.result] if response_times_result.success else []
    
    if response_times:
        stats_result = await stats_tool.execute(
            data=response_times,
            operations=["mean", "median", "std", "min", "max"]
        )
        
        response_time_stats = stats_result.result if stats_result.success else {}
        
        def calculate_percentile(data, percentile):
            sorted_data = sorted(data)
            index = int(len(sorted_data) * percentile / 100)
            return sorted_data[min(index, len(sorted_data) - 1)]
        
        percentiles = {}
        for p in config["analysis"]["percentiles"]:
            percentiles[f"p{p}"] = calculate_percentile(response_times, p)
    else:
        response_time_stats = {}
        percentiles = {}
    
    slow_requests_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query=f"""
        SELECT endpoint, method, response_time_ms, status_code
        FROM api_requests
        WHERE response_time_ms > {config["analysis"]["slow_threshold_ms"]}
        ORDER BY response_time_ms DESC
        LIMIT 10
        """
    )
    
    slow_requests = slow_requests_result.result if slow_requests_result.success else []
    
    method_stats_result = await sqlite_tool.execute(
        database=config["paths"]["metrics_db"],
        operation="query",
        query="""
        SELECT 
            method,
            COUNT(*) as count,
            AVG(response_time_ms) as avg_response_time
        FROM api_requests
        GROUP BY method
        ORDER BY count DESC
        """
    )
    
    method_stats = method_stats_result.result if method_stats_result.success else []
    
    summary_data = {
        "analysis_timestamp": datetime.now().isoformat(),
        "total_requests": total_requests,
        "success_rate": round(success_rate, 2),
        "response_time_stats": {
            "mean": round(response_time_stats.get("mean", 0), 2),
            "median": round(response_time_stats.get("median", 0), 2),
            "std": round(response_time_stats.get("std", 0), 2),
            "min": response_time_stats.get("min", 0),
            "max": response_time_stats.get("max", 0)
        },
        "percentiles": percentiles,
        "endpoint_stats": endpoint_stats,
        "status_distribution": status_distribution,
        "method_stats": method_stats,
        "slow_requests": slow_requests
    }
    
    summary_json = json.dumps(summary_data, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["summary_json"],
        content=summary_json,
        mode="write"
    )
    
    print(f"Summary saved: {config['paths']['summary_json']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>API Metrics Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1400px; margin: 40px auto; padding: 20px; background: #f5f5f5; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-value { font-size: 48px; font-weight: bold; color: #3498db; }
        .metric-label { font-size: 14px; color: #666; margin-top: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; background: white; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .good { color: #28a745; }
        .warning { color: #ffc107; }
        .error { color: #dc3545; }
        .section { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <h1>API Metrics Dashboard</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    
    <div class="dashboard">
        <div class="card">
            <div class="metric-value">{{ total_requests }}</div>
            <div class="metric-label">Total Requests</div>
        </div>
        <div class="card">
            <div class="metric-value {% if success_rate >= 95 %}good{% elif success_rate >= 90 %}warning{% else %}error{% endif %}">
                {{ success_rate }}%
            </div>
            <div class="metric-label">Success Rate</div>
        </div>
        <div class="card">
            <div class="metric-value">{{ mean_response }}ms</div>
            <div class="metric-label">Avg Response Time</div>
        </div>
        <div class="card">
            <div class="metric-value">{{ p95 }}ms</div>
            <div class="metric-label">P95 Response Time</div>
        </div>
    </div>
    
    <div class="section">
        <h2>Response Time Distribution</h2>
        <table>
            <tr>
                <th>Metric</th>
                <th>Value (ms)</th>
            </tr>
            <tr><td>Minimum</td><td>{{ min_response }}</td></tr>
            <tr><td>P50 (Median)</td><td>{{ p50 }}</td></tr>
            <tr><td>P90</td><td>{{ p90 }}</td></tr>
            <tr><td>P95</td><td>{{ p95 }}</td></tr>
            <tr><td>P99</td><td>{{ p99 }}</td></tr>
            <tr><td>Maximum</td><td>{{ max_response }}</td></tr>
            <tr><td>Mean</td><td>{{ mean_response }}</td></tr>
            <tr><td>Std Dev</td><td>{{ std_response }}</td></tr>
        </table>
    </div>
    
    <div class="section">
        <h2>Endpoint Performance</h2>
        <table>
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Requests</th>
                    <th>Avg Response (ms)</th>
                    <th>Success Rate</th>
                    <th>Errors</th>
                </tr>
            </thead>
            <tbody>
            {% for endpoint in endpoints %}
                <tr>
                    <td>{{ endpoint.endpoint }}</td>
                    <td>{{ endpoint.request_count }}</td>
                    <td>{{ endpoint.avg_response_time|round(2) }}</td>
                    <td class="{% if endpoint.success_rate >= 95 %}good{% elif endpoint.success_rate >= 90 %}warning{% else %}error{% endif %}">
                        {{ endpoint.success_rate|round(2) }}%
                    </td>
                    <td>{{ endpoint.error_count }}</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
    
    <div class="section">
        <h2>Status Code Distribution</h2>
        <table>
            <thead>
                <tr>
                    <th>Status Code</th>
                    <th>Count</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
            {% for status in statuses %}
                <tr>
                    <td class="{% if status.status_code < 400 %}good{% elif status.status_code < 500 %}warning{% else %}error{% endif %}">
                        {{ status.status_code }}
                    </td>
                    <td>{{ status.count }}</td>
                    <td>{{ status.percentage }}%</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
    
    {% if slow_requests %}
    <div class="section">
        <h2>Slowest Requests (> {{ threshold }}ms)</h2>
        <table>
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Method</th>
                    <th>Response Time (ms)</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            {% for req in slow_requests %}
                <tr>
                    <td>{{ req.endpoint }}</td>
                    <td>{{ req.method }}</td>
                    <td class="error">{{ req.response_time_ms }}</td>
                    <td>{{ req.status_code }}</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": summary_data["analysis_timestamp"],
        "total_requests": total_requests,
        "success_rate": summary_data["success_rate"],
        "mean_response": summary_data["response_time_stats"]["mean"],
        "median_response": summary_data["response_time_stats"]["median"],
        "std_response": summary_data["response_time_stats"]["std"],
        "min_response": summary_data["response_time_stats"]["min"],
        "max_response": summary_data["response_time_stats"]["max"],
        "p50": percentiles.get("p50", 0),
        "p90": percentiles.get("p90", 0),
        "p95": percentiles.get("p95", 0),
        "p99": percentiles.get("p99", 0),
        "endpoints": endpoint_stats,
        "statuses": status_distribution,
        "methods": method_stats,
        "slow_requests": slow_requests,
        "threshold": config["analysis"]["slow_threshold_ms"]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["dashboard_html"],
            content=html_result.result,
            mode="write"
        )
        print(f"Dashboard saved: {config['paths']['dashboard_html']}")
    
    print()
    print("=" * 70)
    print("METRICS SUMMARY")
    print("=" * 70)
    print(f"Total Requests: {total_requests}")
    print(f"Success Rate: {success_rate:.2f}%")
    print()
    print("Response Times:")
    print(f"  Mean: {summary_data['response_time_stats']['mean']:.2f}ms")
    print(f"  P50: {percentiles.get('p50', 0)}ms")
    print(f"  P95: {percentiles.get('p95', 0)}ms")
    print(f"  P99: {percentiles.get('p99', 0)}ms")
    
    print()
    print("Top Endpoints by Traffic:")
    for endpoint in endpoint_stats[:5]:
        print(f"  {endpoint['endpoint']}: {endpoint['request_count']} requests, {endpoint['avg_response_time']:.1f}ms avg")
    
    print()
    print(f"Slow Requests (>{config['analysis']['slow_threshold_ms']}ms): {len(slow_requests)}")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['metrics_db']}")
    print(f"  - Summary: {config['paths']['summary_json']}")
    print(f"  - Dashboard: {config['paths']['dashboard_html']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
