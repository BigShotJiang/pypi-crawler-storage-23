#!/usr/bin/env python3
"""
Chatbot Trainer

Creates training data for chatbot intents with variations.
Uses MultiAgentPattern to generate, validate, and optimize training examples.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.multi_agent import MultiAgentPattern
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


def generate_intent_examples(intent, count=5):
    """Generate example utterances for an intent."""
    templates = {
        "greeting": [
            "Hello",
            "Hi there",
            "Good morning",
            "Hey",
            "Greetings",
            "Hello, how are you?",
            "Hi, I need help",
            "Good afternoon"
        ],
        "order_status": [
            "Where is my order?",
            "What's the status of my order?",
            "Can you check my order status?",
            "I want to track my order",
            "Order status for order #{}".format(random.randint(1000, 9999)),
            "Has my order shipped?",
            "When will my order arrive?",
            "Track order number {}".format(random.randint(1000, 9999))
        ],
        "refund_request": [
            "I want a refund",
            "Can I get my money back?",
            "How do I request a refund?",
            "I'd like to return this product",
            "Refund policy",
            "I'm not satisfied, I want a refund",
            "Can you process a refund for me?",
            "Return and refund"
        ],
        "product_inquiry": [
            "Do you have this product in stock?",
            "Tell me about your products",
            "What products do you offer?",
            "Product information",
            "Is this available?",
            "Can you recommend a product?",
            "Product specifications",
            "How much does this cost?"
        ],
        "technical_support": [
            "I'm having technical issues",
            "The product isn't working",
            "Technical support needed",
            "How do I fix this problem?",
            "Something is broken",
            "I need help with setup",
            "Troubleshooting assistance",
            "Error message help"
        ],
        "complaint": [
            "I want to file a complaint",
            "This is unacceptable",
            "I'm very disappointed",
            "Your service is terrible",
            "I'd like to speak to a manager",
            "This is not what I ordered",
            "Poor quality product",
            "Worst experience ever"
        ],
        "farewell": [
            "Goodbye",
            "Thanks, bye",
            "That's all, thank you",
            "See you later",
            "Have a good day",
            "Thank you for your help",
            "Bye",
            "Take care"
        ]
    }
    
    examples = templates.get(intent, [f"Example for {intent}"])
    
    selected = random.sample(examples, min(count, len(examples)))
    
    if len(selected) < count:
        while len(selected) < count:
            selected.append(random.choice(examples))
    
    return selected


def generate_variations(text):
    """Generate variations of a text example."""
    variations = [text]
    
    if "?" in text:
        variations.append(text.replace("?", ""))
    
    if text[0].isupper():
        variations.append(text.lower())
    
    variations.append(f"{text}, please")
    variations.append(f"Can you help me with: {text.lower()}")
    
    return variations[:3]


async def main():
    """Execute chatbot training workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CHATBOT TRAINER")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    json_tool = JSONParserTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    writer_tool = FileWriterTool()
    
    print(f"Training Domain: {config['training']['domain']}")
    print(f"Intents: {len(config['training']['intents'])}")
    print()
    
    print("Initializing intents database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["intents_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS intents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            intent_name TEXT NOT NULL,
            example_count INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    await sqlite_tool.execute(
        database=config["paths"]["intents_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS training_examples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            intent_name TEXT NOT NULL,
            utterance TEXT NOT NULL,
            is_variation INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    print("\nGenerating training data...")
    
    training_data = {
        "domain": config["training"]["domain"],
        "timestamp": datetime.now().isoformat(),
        "intents": []
    }
    
    total_examples = 0
    total_variations = 0
    
    for intent in config["training"]["intents"]:
        print(f"\n  Intent: {intent}")
        
        examples = generate_intent_examples(intent, config["training"]["min_examples_per_intent"])
        
        print(f"    Generated {len(examples)} base examples")
        
        await sqlite_tool.execute(
            database=config["paths"]["intents_db"],
            operation="execute",
            query="INSERT INTO intents (intent_name, example_count) VALUES (?, ?)",
            params=(intent, len(examples))
        )
        
        all_examples = []
        
        for example in examples:
            all_examples.append(example)
            
            await sqlite_tool.execute(
                database=config["paths"]["intents_db"],
                operation="execute",
                query="INSERT INTO training_examples (intent_name, utterance, is_variation) VALUES (?, ?, ?)",
                params=(intent, example, 0)
            )
            
            total_examples += 1
            
            if config["training"]["generate_variations"]:
                variations = generate_variations(example)
                
                for variation in variations:
                    if variation != example and variation not in all_examples:
                        all_examples.append(variation)
                        
                        await sqlite_tool.execute(
                            database=config["paths"]["intents_db"],
                            operation="execute",
                            query="INSERT INTO training_examples (intent_name, utterance, is_variation) VALUES (?, ?, ?)",
                            params=(intent, variation, 1)
                        )
                        
                        total_variations += 1
        
        print(f"    Total examples (with variations): {len(all_examples)}")
        
        training_data["intents"].append({
            "name": intent,
            "examples": all_examples
        })
    
    await writer_tool.execute(
        path=config["paths"]["training_data"],
        content=json.dumps(training_data, indent=2),
        mode="write"
    )
    
    print(f"\nTraining data saved: {config['paths']['training_data']}")
    
    print("\nValidating training data...")
    
    validation_results = {
        "total_intents": len(config["training"]["intents"]),
        "total_examples": total_examples + total_variations,
        "base_examples": total_examples,
        "variations": total_variations,
        "validation_checks": []
    }
    
    for intent_data in training_data["intents"]:
        intent_name = intent_data["name"]
        examples = intent_data["examples"]
        
        unique_examples = len(set(examples))
        duplicates = len(examples) - unique_examples
        
        avg_length = sum(len(ex) for ex in examples) / len(examples) if examples else 0
        
        validation_results["validation_checks"].append({
            "intent": intent_name,
            "total_examples": len(examples),
            "unique_examples": unique_examples,
            "duplicates": duplicates,
            "avg_length": round(avg_length, 1)
        })
    
    print(f"  Total Examples: {validation_results['total_examples']}")
    print(f"  Base Examples: {validation_results['base_examples']}")
    print(f"  Variations: {validation_results['variations']}")
    
    if config["settings"]["validation_enabled"]:
        print("\n  Validation Results:")
        for check in validation_results["validation_checks"]:
            print(f"    {check['intent']}: {check['total_examples']} examples, {check['duplicates']} duplicates")
    
    test_split = config["settings"]["test_split"]
    test_size = int(validation_results["total_examples"] * test_split)
    train_size = validation_results["total_examples"] - test_size
    
    model_metadata = {
        "domain": config["training"]["domain"],
        "version": "1.0.0",
        "created_at": datetime.now().isoformat(),
        "intents": config["training"]["intents"],
        "total_intents": len(config["training"]["intents"]),
        "total_examples": validation_results["total_examples"],
        "train_size": train_size,
        "test_size": test_size,
        "settings": {
            "min_examples_per_intent": config["training"]["min_examples_per_intent"],
            "generate_variations": config["training"]["generate_variations"],
            "test_split": test_split
        }
    }
    
    await writer_tool.execute(
        path=config["paths"]["model_metadata"],
        content=json.dumps(model_metadata, indent=2),
        mode="write"
    )
    
    print(f"\nModel metadata saved: {config['paths']['model_metadata']}")
    
    test_results = {
        "timestamp": datetime.now().isoformat(),
        "train_size": train_size,
        "test_size": test_size,
        "validation": validation_results
    }
    
    await writer_tool.execute(
        path=config["paths"]["test_results"],
        content=json.dumps(test_results, indent=2),
        mode="write"
    )
    
    print(f"Test results saved: {config['paths']['test_results']}")
    
    print()
    print("=" * 70)
    print("TRAINING SUMMARY")
    print("=" * 70)
    print(f"Domain: {config['training']['domain']}")
    print(f"Total Intents: {len(config['training']['intents'])}")
    print(f"Total Examples: {validation_results['total_examples']}")
    print(f"  - Base Examples: {validation_results['base_examples']}")
    print(f"  - Variations: {validation_results['variations']}")
    print()
    print(f"Train/Test Split: {train_size}/{test_size}")
    print()
    print("Output files:")
    print(f"  - Training Data: {config['paths']['training_data']}")
    print(f"  - Intents Database: {config['paths']['intents_db']}")
    print(f"  - Model Metadata: {config['paths']['model_metadata']}")
    print(f"  - Test Results: {config['paths']['test_results']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
