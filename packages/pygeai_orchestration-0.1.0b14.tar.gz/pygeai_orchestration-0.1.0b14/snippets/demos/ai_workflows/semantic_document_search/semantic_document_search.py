#!/usr/bin/env python3
"""
Semantic Document Search

Implements semantic search over a document collection using embeddings and
reranking. Uses ReActPattern to reason about search strategy and result ranking.
"""

import asyncio
import json
import os
from pathlib import Path
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.file_tools import DirectoryListerTool, FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.geai_tools import EmbeddingsGeneratorTool, RerankTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_documents(config):
    """Create sample document collection."""
    docs_dir = Path(config["search"]["documents_dir"])
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    documents = {
        "ml_fundamentals.md": """# Machine Learning Fundamentals

Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed.

## Key Concepts
- Supervised Learning: Training with labeled data
- Unsupervised Learning: Finding patterns in unlabeled data
- Reinforcement Learning: Learning through rewards and penalties

## Best Practices
- Always split data into training and testing sets
- Use cross-validation for model evaluation
- Monitor for overfitting and underfitting
- Feature engineering is crucial for model performance
""",
        "data_preprocessing.md": """# Data Preprocessing Guide

Data preprocessing is a critical step in any machine learning pipeline. Clean, well-prepared data leads to better model performance.

## Steps in Data Preprocessing
1. Data Cleaning: Handle missing values and outliers
2. Data Transformation: Normalize or standardize features
3. Feature Engineering: Create meaningful features from raw data
4. Data Splitting: Separate training, validation, and test sets

## Common Techniques
- Imputation for missing values
- Scaling and normalization
- Encoding categorical variables
- Handling imbalanced datasets
""",
        "neural_networks.md": """# Neural Networks Overview

Neural networks are computing systems inspired by biological neural networks. They consist of interconnected nodes (neurons) organized in layers.

## Architecture Components
- Input Layer: Receives raw data
- Hidden Layers: Process information
- Output Layer: Produces predictions

## Training Process
- Forward propagation
- Loss calculation
- Backpropagation
- Weight updates using gradient descent

Deep learning uses neural networks with many hidden layers to learn complex patterns.
""",
        "model_evaluation.md": """# Model Evaluation Techniques

Evaluating machine learning models is essential to understand their performance and generalization capabilities.

## Evaluation Metrics
- Classification: Accuracy, Precision, Recall, F1-Score, ROC-AUC
- Regression: MSE, RMSE, MAE, R-squared
- Clustering: Silhouette Score, Davies-Bouldin Index

## Validation Strategies
- Holdout validation
- K-fold cross-validation
- Stratified sampling
- Time series cross-validation

Always evaluate on unseen data to assess true model performance.
""",
        "deployment_best_practices.md": """# ML Model Deployment Best Practices

Deploying machine learning models to production requires careful planning and implementation.

## Deployment Checklist
- Model versioning and tracking
- API design and documentation
- Monitoring and logging
- Performance optimization
- Security considerations

## Infrastructure
- Containerization with Docker
- Orchestration with Kubernetes
- CI/CD pipelines
- A/B testing framework

## Monitoring
- Track prediction latency
- Monitor model drift
- Log prediction requests and responses
- Set up alerts for anomalies
"""
    }
    
    for filename, content in documents.items():
        file_path = docs_dir / filename
        with open(file_path, 'w') as f:
            f.write(content)
    
    print(f"Created {len(documents)} sample documents at {docs_dir}")


async def main():
    """Execute the semantic search workflow."""
    config = load_config()
    
    print("=" * 70)
    print("SEMANTIC DOCUMENT SEARCH")
    print("=" * 70)
    print()
    
    api_key = config["geai"]["api_key"]
    if api_key == "your-geai-api-key-here":
        print("WARNING: Using example API key. Set your GEAI API key in config.json")
        print("         or set GEAI_API_KEY environment variable.")
        print()
        api_key = os.environ.get("GEAI_API_KEY", api_key)
    
    await create_sample_documents(config)
    
    lister_tool = DirectoryListerTool()
    reader_tool = FileReaderTool()
    embeddings_tool = EmbeddingsGeneratorTool()
    rerank_tool = RerankTool()
    writer_tool = FileWriterTool()
    
    print(f"\nQuery: {config['search']['query']}")
    print("Indexing documents...")
    
    list_result = await lister_tool.execute(
        path=config["search"]["documents_dir"],
        recursive=False
    )
    
    if not list_result.success:
        print(f"Error listing documents: {list_result.error}")
        return
    
    doc_files = [f for f in list_result.result if f.endswith('.md')]
    print(f"Found {len(doc_files)} documents")
    
    documents = []
    for doc_file in doc_files:
        read_result = await reader_tool.execute(path=doc_file)
        if read_result.success:
            documents.append({
                "file": doc_file,
                "filename": Path(doc_file).name,
                "content": read_result.result
            })
    
    print("\nGenerating embeddings for documents...")
    
    doc_texts = [doc["content"] for doc in documents]
    
    embeddings_result = await embeddings_tool.execute(
        texts=doc_texts,
        api_key=api_key
    )
    
    if not embeddings_result.success:
        print(f"Error generating embeddings: {embeddings_result.error}")
        print("Note: This demo requires a valid GEAI API key")
        print("      Set it in config.json or GEAI_API_KEY environment variable")
        return
    
    doc_embeddings = embeddings_result.result
    
    print("Generating query embedding...")
    
    query_embedding_result = await embeddings_tool.execute(
        texts=[config["search"]["query"]],
        api_key=api_key
    )
    
    if not query_embedding_result.success:
        print(f"Error generating query embedding: {query_embedding_result.error}")
        return
    
    query_embedding = query_embedding_result.result[0]
    
    print("Calculating similarity scores...")
    
    def cosine_similarity(vec1, vec2):
        """Calculate cosine similarity between two vectors."""
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a * a for a in vec1) ** 0.5
        magnitude2 = sum(b * b for b in vec2) ** 0.5
        return dot_product / (magnitude1 * magnitude2) if magnitude1 * magnitude2 > 0 else 0
    
    scored_docs = []
    for i, doc in enumerate(documents):
        similarity = cosine_similarity(query_embedding, doc_embeddings[i])
        scored_docs.append({
            "document": doc,
            "similarity_score": similarity
        })
    
    scored_docs.sort(key=lambda x: x["similarity_score"], reverse=True)
    top_results = scored_docs[:config["search"]["top_k"]]
    
    if config["search"]["rerank"]:
        print("Reranking top results...")
        
        rerank_docs = [r["document"]["content"] for r in top_results]
        
        rerank_result = await rerank_tool.execute(
            query=config["search"]["query"],
            documents=rerank_docs,
            api_key=api_key
        )
        
        if rerank_result.success:
            reranked_scores = rerank_result.result
            
            for i, result in enumerate(top_results):
                result["rerank_score"] = reranked_scores[i] if i < len(reranked_scores) else 0
            
            top_results.sort(key=lambda x: x.get("rerank_score", 0), reverse=True)
    
    results_data = {
        "query": config["search"]["query"],
        "total_documents": len(documents),
        "results": [
            {
                "rank": i + 1,
                "filename": result["document"]["filename"],
                "file_path": result["document"]["file"],
                "similarity_score": round(result["similarity_score"], 4),
                "rerank_score": round(result.get("rerank_score", 0), 4) if config["search"]["rerank"] else None,
                "preview": result["document"]["content"][:200] + "..."
            }
            for i, result in enumerate(top_results)
        ]
    }
    
    results_json = json.dumps(results_data, indent=2)
    
    write_result = await writer_tool.execute(
        path=config["paths"]["results_file"],
        content=results_json,
        mode="write"
    )
    
    if write_result.success:
        print(f"\nResults saved to: {config['paths']['results_file']}")
    
    print()
    print("=" * 70)
    print("SEARCH RESULTS")
    print("=" * 70)
    print(f"Query: {config['search']['query']}")
    print(f"Documents Searched: {len(documents)}")
    print(f"Top {config['search']['top_k']} Results:")
    print()
    
    for i, result in enumerate(top_results, 1):
        print(f"{i}. {result['document']['filename']}")
        print(f"   Similarity: {result['similarity_score']:.4f}")
        if config["search"]["rerank"]:
            print(f"   Rerank Score: {result.get('rerank_score', 0):.4f}")
        preview = result["document"]["content"][:150].replace('\n', ' ')
        print(f"   Preview: {preview}...")
        print()
    
    print(f"Full results: {config['paths']['results_file']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
