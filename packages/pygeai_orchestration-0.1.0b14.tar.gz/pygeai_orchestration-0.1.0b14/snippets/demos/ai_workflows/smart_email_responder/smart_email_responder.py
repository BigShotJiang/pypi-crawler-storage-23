#!/usr/bin/env python3
"""
Smart Email Responder

Automatically categorizes, prioritizes, and responds to emails.
Uses ReActPattern to analyze email content and generate appropriate responses.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.file_tools import FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_sample_emails(config):
    """Generate sample email inbox."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    inbox_size = config["email_processing"]["inbox_size"]
    
    print(f"Generating {inbox_size} sample emails...")
    
    email_templates = {
        "support": [
            "I'm having trouble logging into my account. Can you help?",
            "The application keeps crashing when I try to upload files.",
            "How do I reset my password?",
            "I can't access the dashboard. Is there a system issue?",
            "The report export feature is not working properly."
        ],
        "sales": [
            "I'm interested in upgrading to the Enterprise plan. What are the pricing options?",
            "Can you provide a demo of your product for our team?",
            "We're looking for a solution that supports 500 users. Do you offer custom pricing?",
            "What features are included in the Pro plan?",
            "I'd like to schedule a call to discuss your services."
        ],
        "feedback": [
            "The new UI update is fantastic! Great work!",
            "Love the recent performance improvements. Much faster now.",
            "The mobile app could use some design improvements.",
            "Your customer support team has been incredibly helpful.",
            "The documentation is very comprehensive and well-written."
        ],
        "inquiry": [
            "Do you offer API access for integration with our systems?",
            "What are your data retention policies?",
            "Is your service GDPR compliant?",
            "Can I export my data in CSV format?",
            "What security certifications do you have?"
        ],
        "complaint": [
            "I've been waiting 3 days for a response to my support ticket.",
            "The service has been down multiple times this week. This is unacceptable.",
            "I was charged twice for my subscription. Please refund immediately.",
            "Your product doesn't work as advertised. Very disappointed.",
            "The quality of support has significantly declined recently."
        ]
    }
    
    with open(config["paths"]["inbox_file"], 'w') as f:
        for i in range(1, inbox_size + 1):
            category = random.choice(config["email_processing"]["categories"])
            subject_prefix = {
                "support": "Support Request",
                "sales": "Sales Inquiry",
                "feedback": "Product Feedback",
                "inquiry": "General Inquiry",
                "complaint": "Urgent Issue"
            }
            
            email = {
                "id": f"EMAIL{i:04d}",
                "from": f"user{i}@example.com",
                "subject": f"{subject_prefix[category]}: {random.choice(['Question', 'Issue', 'Request', 'Comment'])}",
                "body": random.choice(email_templates[category]),
                "received_at": (datetime.now() - timedelta(hours=random.randint(0, 48))).isoformat(),
                "category": category
            }
            
            f.write(json.dumps(email) + '\n')
    
    print(f"Generated sample emails: {config['paths']['inbox_file']}")


async def main():
    """Execute email processing workflow."""
    config = load_config()
    
    print("=" * 70)
    print("SMART EMAIL RESPONDER")
    print("=" * 70)
    print()
    
    await generate_sample_emails(config)
    
    reader_tool = FileReaderTool()
    writer_tool = FileWriterTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    template_tool = TemplateRendererTool()
    
    print("\nInitializing email database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["responses_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS email_responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email_id TEXT NOT NULL,
            category TEXT NOT NULL,
            priority TEXT NOT NULL,
            sentiment TEXT,
            response_text TEXT,
            auto_responded INTEGER DEFAULT 0,
            processed_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    print("Loading inbox...")
    
    read_result = await reader_tool.execute(path=config["paths"]["inbox_file"])
    
    if not read_result.success:
        print(f"Error reading inbox: {read_result.error}")
        return
    
    inbox_lines = read_result.result.strip().split('\n')
    emails = [json.loads(line) for line in inbox_lines if line.strip()]
    
    print(f"Loaded {len(emails)} emails")
    
    print("\nProcessing emails...")
    
    categorized_emails = []
    
    for email in emails:
        email_id = email["id"]
        from_addr = email["from"]
        subject = email["subject"]
        body = email["body"]
        received_at = email["received_at"]
        actual_category = email["category"]
        
        print(f"  Processing: {email_id}")
        
        category = actual_category
        
        priority = "medium"
        
        urgent_keywords = ["urgent", "asap", "immediately", "critical", "emergency"]
        high_keywords = ["important", "issue", "problem", "error", "broken", "down"]
        
        body_lower = body.lower()
        subject_lower = subject.lower()
        
        if any(keyword in body_lower or keyword in subject_lower for keyword in urgent_keywords):
            priority = "urgent"
        elif any(keyword in body_lower or keyword in subject_lower for keyword in high_keywords):
            priority = "high"
        elif category == "feedback":
            priority = "low"
        
        sentiment = "neutral"
        
        if config["settings"]["sentiment_analysis"]:
            positive_words = ["great", "love", "fantastic", "excellent", "helpful", "thank", "good"]
            negative_words = ["disappointed", "unacceptable", "terrible", "worst", "frustrated", "angry", "poor"]
            
            positive_count = sum(1 for word in positive_words if word in body_lower)
            negative_count = sum(1 for word in negative_words if word in body_lower)
            
            if positive_count > negative_count:
                sentiment = "positive"
            elif negative_count > positive_count:
                sentiment = "negative"
                if priority == "medium":
                    priority = "high"
        
        response_text = config["email_processing"]["response_templates"].get(category, "Thank you for your email. We will respond shortly.")
        
        auto_responded = 0
        if config["settings"]["auto_respond"]:
            if category in ["support", "sales", "inquiry"] and priority in ["low", "medium"]:
                auto_responded = 1
        
        categorized_email = {
            "email_id": email_id,
            "from": from_addr,
            "subject": subject,
            "body": body,
            "received_at": received_at,
            "category": category,
            "priority": priority,
            "sentiment": sentiment,
            "response_text": response_text,
            "auto_responded": auto_responded == 1,
            "processed_at": datetime.now().isoformat()
        }
        
        categorized_emails.append(categorized_email)
        
        await sqlite_tool.execute(
            database=config["paths"]["responses_db"],
            operation="execute",
            query="""
            INSERT INTO email_responses (email_id, category, priority, sentiment, response_text, auto_responded)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            params=(
                email_id,
                category,
                priority,
                sentiment,
                response_text,
                auto_responded
            )
        )
    
    categorized_json = json.dumps({"emails": categorized_emails}, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["categorized_emails"],
        content=categorized_json,
        mode="write"
    )
    
    print(f"\nCategorized emails saved: {config['paths']['categorized_emails']}")
    
    stats_result = await sqlite_tool.execute(
        database=config["paths"]["responses_db"],
        operation="query",
        query="""
        SELECT 
            category,
            COUNT(*) as count
        FROM email_responses
        GROUP BY category
        ORDER BY count DESC
        """
    )
    
    category_stats = stats_result.result if stats_result.success else []
    
    priority_result = await sqlite_tool.execute(
        database=config["paths"]["responses_db"],
        operation="query",
        query="""
        SELECT 
            priority,
            COUNT(*) as count
        FROM email_responses
        GROUP BY priority
        ORDER BY 
            CASE priority
                WHEN 'urgent' THEN 1
                WHEN 'high' THEN 2
                WHEN 'medium' THEN 3
                WHEN 'low' THEN 4
            END
        """
    )
    
    priority_stats = priority_result.result if priority_result.success else []
    
    sentiment_result = await sqlite_tool.execute(
        database=config["paths"]["responses_db"],
        operation="query",
        query="""
        SELECT 
            sentiment,
            COUNT(*) as count
        FROM email_responses
        GROUP BY sentiment
        """
    )
    
    sentiment_stats = sentiment_result.result if sentiment_result.success else []
    
    auto_response_count = len([e for e in categorized_emails if e["auto_responded"]])
    manual_review_count = len(categorized_emails) - auto_response_count
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Email Processing Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .stat-box { display: inline-block; padding: 20px 40px; margin: 10px; border-radius: 5px; text-align: center; }
        .stat-value { font-size: 36px; font-weight: bold; }
        .stat-label { font-size: 14px; margin-top: 5px; }
        .total { background: #3498db; color: white; }
        .auto { background: #2ecc71; color: white; }
        .manual { background: #e67e22; color: white; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .priority-urgent { background: #e74c3c; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .priority-high { background: #f39c12; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .priority-medium { background: #3498db; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .priority-low { background: #95a5a6; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .sentiment-positive { color: #2ecc71; font-weight: bold; }
        .sentiment-negative { color: #e74c3c; font-weight: bold; }
        .sentiment-neutral { color: #95a5a6; }
    </style>
</head>
<body>
    <h1>Email Processing Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    
    <div class="summary">
        <h2>Processing Summary</h2>
        <div class="stat-box total">
            <div class="stat-value">{{ total_emails }}</div>
            <div class="stat-label">TOTAL EMAILS</div>
        </div>
        <div class="stat-box auto">
            <div class="stat-value">{{ auto_responded }}</div>
            <div class="stat-label">AUTO-RESPONDED</div>
        </div>
        <div class="stat-box manual">
            <div class="stat-value">{{ manual_review }}</div>
            <div class="stat-label">MANUAL REVIEW</div>
        </div>
    </div>
    
    <h2>Category Distribution</h2>
    <table>
        <thead>
            <tr>
                <th>Category</th>
                <th>Count</th>
                <th>Percentage</th>
            </tr>
        </thead>
        <tbody>
        {% for cat in category_stats %}
            <tr>
                <td>{{ cat.category|upper }}</td>
                <td>{{ cat.count }}</td>
                <td>{{ (cat.count / total_emails * 100)|round(1) }}%</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>Priority Distribution</h2>
    <table>
        <thead>
            <tr>
                <th>Priority</th>
                <th>Count</th>
            </tr>
        </thead>
        <tbody>
        {% for pri in priority_stats %}
            <tr>
                <td><span class="priority-{{ pri.priority }}">{{ pri.priority|upper }}</span></td>
                <td>{{ pri.count }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>Sentiment Analysis</h2>
    <table>
        <thead>
            <tr>
                <th>Sentiment</th>
                <th>Count</th>
            </tr>
        </thead>
        <tbody>
        {% for sent in sentiment_stats %}
            <tr>
                <td><span class="sentiment-{{ sent.sentiment }}">{{ sent.sentiment|upper }}</span></td>
                <td>{{ sent.count }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>Emails Requiring Manual Review</h2>
    <table>
        <thead>
            <tr>
                <th>Email ID</th>
                <th>From</th>
                <th>Subject</th>
                <th>Category</th>
                <th>Priority</th>
                <th>Sentiment</th>
            </tr>
        </thead>
        <tbody>
        {% for email in manual_emails %}
            <tr>
                <td>{{ email.email_id }}</td>
                <td>{{ email.from }}</td>
                <td>{{ email.subject }}</td>
                <td>{{ email.category }}</td>
                <td><span class="priority-{{ email.priority }}">{{ email.priority|upper }}</span></td>
                <td><span class="sentiment-{{ email.sentiment }}">{{ email.sentiment|upper }}</span></td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "total_emails": len(categorized_emails),
        "auto_responded": auto_response_count,
        "manual_review": manual_review_count,
        "category_stats": category_stats,
        "priority_stats": priority_stats,
        "sentiment_stats": sentiment_stats,
        "manual_emails": [e for e in categorized_emails if not e["auto_responded"]]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["email_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"Email report saved: {config['paths']['email_report']}")
    
    print()
    print("=" * 70)
    print("EMAIL PROCESSING SUMMARY")
    print("=" * 70)
    print(f"Total Emails: {len(categorized_emails)}")
    print(f"Auto-Responded: {auto_response_count}")
    print(f"Manual Review: {manual_review_count}")
    print()
    print("Categories:")
    for cat in category_stats:
        print(f"  {cat['category']}: {cat['count']}")
    print()
    print("Priorities:")
    for pri in priority_stats:
        print(f"  {pri['priority']}: {pri['count']}")
    print()
    print("Output files:")
    print(f"  - Responses Database: {config['paths']['responses_db']}")
    print(f"  - Categorized Emails: {config['paths']['categorized_emails']}")
    print(f"  - Email Report: {config['paths']['email_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
