#!/usr/bin/env python3
"""
Content Moderator

Automatically moderates user-generated content using pattern matching and classification.
Uses ReActPattern to reason about content safety and flag violations.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.react import ReActPattern
from pygeai_orchestration.tools.builtin.file_tools import FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, ValidationTool, HashTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_sample_content(config):
    """Generate sample user-generated content."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    content_count = config["moderation"]["content_count"]
    
    safe_messages = [
        "Great product! Really enjoying it so far.",
        "Can someone help me with installation?",
        "Thanks for the quick response to my question.",
        "The new features are awesome, keep up the good work!",
        "Looking forward to the next update.",
        "Documentation is very clear and helpful.",
        "This solved my problem perfectly, thank you!",
        "Excellent customer service experience."
    ]
    
    spam_messages = [
        "Buy now and get 50% off! Click here: https://spam-site.example.com",
        "Limited time offer! Act now to claim your free money!",
        "You won't believe this! Click here: https://scam.example.com",
        "Make money fast! Contact us at money@spam.example.com",
        "Exclusive deal! Buy now before it's too late!",
        "Free gift! Click this link: https://gift-scam.example.com"
    ]
    
    offensive_messages = [
        "This is terrible and you should feel bad about it.",
        "Worst service ever, complete waste of time.",
        "I hate this product, it's absolutely useless.",
        "The people behind this are incompetent.",
        "This offensive comment contains inappropriate language."
    ]
    
    print(f"Generating {content_count} content samples...")
    
    with open(config["paths"]["content_file"], 'w') as f:
        for i in range(1, content_count + 1):
            rand = random.random()
            
            if rand < 0.6:
                text = random.choice(safe_messages)
                expected_category = "safe"
            elif rand < 0.8:
                text = random.choice(spam_messages)
                expected_category = "spam"
            else:
                text = random.choice(offensive_messages)
                expected_category = "offensive"
            
            content_item = {
                "id": f"content_{i:04d}",
                "user_id": f"user_{random.randint(1, 50)}",
                "timestamp": datetime.now().isoformat(),
                "text": text,
                "platform": random.choice(["web", "mobile", "api"])
            }
            
            f.write(json.dumps(content_item) + '\n')
    
    print(f"Generated content samples at {config['paths']['content_file']}")


async def main():
    """Execute content moderation workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CONTENT MODERATOR")
    print("=" * 70)
    print()
    
    await generate_sample_content(config)
    
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    validation_tool = ValidationTool()
    hash_tool = HashTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing moderation database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["moderation_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS content_reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            moderation_status TEXT NOT NULL,
            flags TEXT,
            confidence_score REAL,
            reviewed_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    print("Loading content for moderation...")
    
    read_result = await reader_tool.execute(path=config["paths"]["content_file"])
    
    if not read_result.success:
        print(f"Error reading content: {read_result.error}")
        return
    
    content_lines = read_result.result.strip().split('\n')
    content_items = [json.loads(line) for line in content_lines if line.strip()]
    
    print(f"Loaded {len(content_items)} content items")
    
    print("\nAnalyzing content...")
    
    moderation_results = []
    flagged_items = []
    
    for item in content_items:
        content_id = item["id"]
        user_id = item["user_id"]
        text = item["text"]
        timestamp = item["timestamp"]
        
        hash_result = await hash_tool.execute(
            operation="string",
            data=text,
            algorithm="sha256"
        )
        
        content_hash = hash_result.result if hash_result.success else None
        
        flags = []
        confidence_scores = []
        
        if config["settings"]["auto_flag_spam"]:
            spam_detected = False
            for spam_pattern in config["moderation"]["filters"]["spam_patterns"]:
                pattern_result = await regex_tool.execute(
                    pattern=spam_pattern,
                    text=text,
                    operation="search",
                    flags=["IGNORECASE"]
                )
                
                if pattern_result.success and pattern_result.result:
                    spam_detected = True
                    flags.append(f"spam_keyword:{spam_pattern}")
            
            url_result = await regex_tool.execute(
                pattern=config["moderation"]["filters"]["url_pattern"],
                text=text,
                operation="search"
            )
            
            if url_result.success and url_result.result:
                flags.append("contains_url")
                if spam_detected:
                    confidence_scores.append(0.9)
            
            email_result = await regex_tool.execute(
                pattern=config["moderation"]["filters"]["email_pattern"],
                text=text,
                operation="search"
            )
            
            if email_result.success and email_result.result:
                flags.append("contains_email")
        
        if config["settings"]["auto_flag_offensive"]:
            for keyword in config["moderation"]["filters"]["profanity_keywords"]:
                keyword_result = await regex_tool.execute(
                    pattern=keyword,
                    text=text,
                    operation="search",
                    flags=["IGNORECASE"]
                )
                
                if keyword_result.success and keyword_result.result:
                    flags.append(f"profanity:{keyword}")
                    confidence_scores.append(0.85)
        
        text_lower = text.lower()
        if any(word in text_lower for word in ["hate", "worst", "terrible", "useless", "incompetent"]):
            flags.append("negative_sentiment")
            confidence_scores.append(0.7)
        
        if flags:
            if any("spam" in f or "profanity" in f for f in flags):
                status = "FLAGGED"
            else:
                status = "REVIEW"
        else:
            status = "APPROVED"
        
        confidence = max(confidence_scores) if confidence_scores else 0.5
        
        result = {
            "content_id": content_id,
            "user_id": user_id,
            "timestamp": timestamp,
            "text": text,
            "status": status,
            "flags": flags,
            "confidence": round(confidence, 2)
        }
        
        moderation_results.append(result)
        
        if status in ["FLAGGED", "REVIEW"]:
            flagged_items.append(result)
        
        await sqlite_tool.execute(
            database=config["paths"]["moderation_db"],
            operation="execute",
            query="""
            INSERT INTO content_reviews (content_id, user_id, timestamp, content_hash, moderation_status, flags, confidence_score)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            params=(
                content_id,
                user_id,
                timestamp,
                content_hash,
                status,
                json.dumps(flags),
                confidence
            )
        )
    
    flagged_json = json.dumps({"flagged_content": flagged_items}, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["flagged_content"],
        content=flagged_json,
        mode="write"
    )
    
    print(f"Flagged content saved: {config['paths']['flagged_content']}")
    
    stats_result = await sqlite_tool.execute(
        database=config["paths"]["moderation_db"],
        operation="query",
        query="""
        SELECT 
            moderation_status,
            COUNT(*) as count
        FROM content_reviews
        GROUP BY moderation_status
        """
    )
    
    status_stats = stats_result.result if stats_result.success else []
    
    user_stats_result = await sqlite_tool.execute(
        database=config["paths"]["moderation_db"],
        operation="query",
        query="""
        SELECT 
            user_id,
            COUNT(*) as total_posts,
            SUM(CASE WHEN moderation_status = 'FLAGGED' THEN 1 ELSE 0 END) as flagged_posts
        FROM content_reviews
        GROUP BY user_id
        HAVING flagged_posts > 0
        ORDER BY flagged_posts DESC
        LIMIT 10
        """
    )
    
    user_stats = user_stats_result.result if user_stats_result.success else []
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Content Moderation Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .stat-box { display: inline-block; padding: 20px 40px; margin: 10px; border-radius: 5px; text-align: center; }
        .stat-value { font-size: 36px; font-weight: bold; }
        .stat-label { font-size: 14px; margin-top: 5px; }
        .approved { background: #d4edda; color: #155724; }
        .review { background: #fff3cd; color: #856404; }
        .flagged { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .flag-badge { display: inline-block; background: #dc3545; color: white; padding: 3px 8px; border-radius: 3px; margin: 2px; font-size: 11px; }
        .content-text { max-width: 400px; overflow: hidden; text-overflow: ellipsis; }
    </style>
</head>
<body>
    <h1>Content Moderation Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Total Content Reviewed:</strong> {{ total_items }}</p>
    
    <div class="summary">
        <h2>Moderation Summary</h2>
        {% for stat in status_stats %}
        <div class="stat-box {{ stat.moderation_status|lower }}">
            <div class="stat-value">{{ stat.count }}</div>
            <div class="stat-label">{{ stat.moderation_status }}</div>
        </div>
        {% endfor %}
    </div>
    
    {% if flagged_items %}
    <h2>Flagged Content ({{ flagged_items|length }})</h2>
    <table>
        <thead>
            <tr>
                <th>Content ID</th>
                <th>User ID</th>
                <th>Text</th>
                <th>Status</th>
                <th>Flags</th>
                <th>Confidence</th>
            </tr>
        </thead>
        <tbody>
        {% for item in flagged_items %}
            <tr>
                <td>{{ item.content_id }}</td>
                <td>{{ item.user_id }}</td>
                <td class="content-text">{{ item.text[:100] }}{% if item.text|length > 100 %}...{% endif %}</td>
                <td><span class="stat-box {{ item.status|lower }}" style="padding: 5px 10px; margin: 0;">{{ item.status }}</span></td>
                <td>
                    {% for flag in item.flags %}
                    <span class="flag-badge">{{ flag }}</span>
                    {% endfor %}
                </td>
                <td>{{ (item.confidence * 100)|round }}%</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% endif %}
    
    {% if user_stats %}
    <h2>Users with Flagged Content</h2>
    <table>
        <thead>
            <tr>
                <th>User ID</th>
                <th>Total Posts</th>
                <th>Flagged Posts</th>
                <th>Flag Rate</th>
            </tr>
        </thead>
        <tbody>
        {% for user in user_stats %}
            <tr>
                <td>{{ user.user_id }}</td>
                <td>{{ user.total_posts }}</td>
                <td class="flagged">{{ user.flagged_posts }}</td>
                <td>{{ (user.flagged_posts / user.total_posts * 100)|round(1) }}%</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "total_items": len(content_items),
        "status_stats": status_stats,
        "flagged_items": flagged_items,
        "user_stats": user_stats
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["moderation_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"Moderation report saved: {config['paths']['moderation_report']}")
    
    approved = len([r for r in moderation_results if r["status"] == "APPROVED"])
    review = len([r for r in moderation_results if r["status"] == "REVIEW"])
    flagged = len([r for r in moderation_results if r["status"] == "FLAGGED"])
    
    print()
    print("=" * 70)
    print("MODERATION SUMMARY")
    print("=" * 70)
    print(f"Total Content Reviewed: {len(content_items)}")
    print()
    print(f"Approved: {approved}")
    print(f"Needs Review: {review}")
    print(f"Flagged: {flagged}")
    
    if flagged_items:
        print()
        print(f"Top Violation Types:")
        all_flags = []
        for item in flagged_items:
            all_flags.extend(item["flags"])
        
        flag_counts = {}
        for flag in all_flags:
            flag_type = flag.split(':')[0]
            flag_counts[flag_type] = flag_counts.get(flag_type, 0) + 1
        
        for flag_type, count in sorted(flag_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
            print(f"  {flag_type}: {count}")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['moderation_db']}")
    print(f"  - Flagged Content: {config['paths']['flagged_content']}")
    print(f"  - Report: {config['paths']['moderation_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
