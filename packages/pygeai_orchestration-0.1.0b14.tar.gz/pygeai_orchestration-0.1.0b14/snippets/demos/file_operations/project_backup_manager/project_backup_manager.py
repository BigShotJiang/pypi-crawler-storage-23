#!/usr/bin/env python3
"""
Project Backup Manager

Creates incremental backups of project files with checksum verification. Uses
planning pattern to orchestrate the backup workflow including file discovery,
archiving, checksum generation, and manifest creation.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import DirectoryListerTool, FileWriterTool, FileReaderTool
from pygeai_orchestration.tools.builtin.utilities import ArchiveTool, HashTool
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_project(config):
    """Create a sample project directory with files to backup."""
    source_dir = Path(config["backup"]["source_dir"])
    source_dir.mkdir(parents=True, exist_ok=True)
    
    sample_files = {
        "main.py": """#!/usr/bin/env python3
def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()
""",
        "config.json": json.dumps({"app": "demo", "version": "1.0.0"}, indent=2),
        "README.md": """# Sample Project

This is a sample project for backup demonstration.

## Features
- Feature 1
- Feature 2
""",
        "requirements.txt": """requests>=2.28.0
python-dateutil>=2.8.2
""",
        "src/utils.py": """def helper_function():
    return "Helper"
""",
        "src/__init__.py": "",
        "data/sample.txt": "Sample data file content\n" * 10,
        "docs/guide.md": """# User Guide

## Getting Started

Follow these steps...
"""
    }
    
    for file_path, content in sample_files.items():
        full_path = source_dir / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, 'w') as f:
            f.write(content)
    
    print(f"Created sample project with {len(sample_files)} files at {source_dir}")


async def main():
    """Execute the backup workflow."""
    config = load_config()
    
    print("=" * 70)
    print("PROJECT BACKUP MANAGER")
    print("=" * 70)
    print()
    
    await create_sample_project(config)
    
    work_dir = Path(config["paths"]["work_dir"])
    backup_dir = Path(config["backup"]["backup_dir"])
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    lister_tool = DirectoryListerTool()
    archive_tool = ArchiveTool()
    hash_tool = HashTool()
    file_writer_tool = FileWriterTool()
    
    print("\nScanning project directory...")
    
    list_result = await lister_tool.execute(
        path=config["backup"]["source_dir"],
        recursive=True
    )
    
    if not list_result.success:
        print(f"Error listing directory: {list_result.error}")
        return
    
    all_files = list_result.result
    include_patterns = config["backup"]["include_patterns"]
    exclude_patterns = config["backup"]["exclude_patterns"]
    
    files_to_backup = []
    for file_path in all_files:
        path = Path(file_path)
        
        excluded = False
        for pattern in exclude_patterns:
            if pattern in str(path):
                excluded = True
                break
        
        if excluded:
            continue
        
        included = False
        for pattern in include_patterns:
            if path.match(pattern):
                included = True
                break
        
        if included and path.is_file():
            files_to_backup.append(str(path))
    
    print(f"Found {len(all_files)} total files")
    print(f"Selected {len(files_to_backup)} files for backup")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_name = f"{config['backup']['archive_name']}_{timestamp}.tar.gz"
    archive_path = backup_dir / archive_name
    
    print(f"\nCreating archive: {archive_name}")
    
    archive_result = await archive_tool.execute(
        operation="create",
        archive_path=str(archive_path),
        source_paths=[config["backup"]["source_dir"]],
        format="tar.gz"
    )
    
    if not archive_result.success:
        print(f"Error creating archive: {archive_result.error}")
        return
    
    print(f"Archive created: {archive_path}")
    print(f"Archive size: {Path(archive_path).stat().st_size / 1024:.2f} KB")
    
    if config["settings"]["verify_checksums"]:
        print("\nGenerating checksums...")
        
        file_checksums = {}
        for file_path in files_to_backup:
            hash_result = await hash_tool.execute(
                operation="file",
                data=file_path,
                algorithm="sha256"
            )
            
            if hash_result.success:
                file_checksums[file_path] = hash_result.result
        
        archive_hash_result = await hash_tool.execute(
            operation="file",
            data=str(archive_path),
            algorithm="sha256"
        )
        
        if archive_hash_result.success:
            print(f"Archive checksum (SHA256): {archive_hash_result.result[:16]}...")
        
        manifest = {
            "backup_info": {
                "timestamp": timestamp,
                "source_directory": config["backup"]["source_dir"],
                "archive_name": archive_name,
                "archive_path": str(archive_path),
                "archive_size_bytes": Path(archive_path).stat().st_size,
                "archive_checksum": archive_hash_result.result if archive_hash_result.success else None
            },
            "files": {
                "total_files": len(files_to_backup),
                "files_list": files_to_backup
            },
            "checksums": file_checksums,
            "settings": {
                "include_patterns": include_patterns,
                "exclude_patterns": exclude_patterns
            }
        }
        
        manifest_json = json.dumps(manifest, indent=2)
        
        manifest_write_result = await file_writer_tool.execute(
            path=config["paths"]["manifest_file"],
            content=manifest_json,
            mode="write"
        )
        
        if manifest_write_result.success:
            print(f"Backup manifest saved: {config['paths']['manifest_file']}")
    
    print()
    print("=" * 70)
    print("BACKUP SUMMARY")
    print("=" * 70)
    print(f"Backup Created: {timestamp}")
    print(f"Source Directory: {config['backup']['source_dir']}")
    print(f"Files Backed Up: {len(files_to_backup)}")
    print(f"Archive: {archive_path}")
    print(f"Archive Size: {Path(archive_path).stat().st_size / 1024:.2f} KB")
    
    if config["settings"]["verify_checksums"]:
        print(f"Checksums Verified: {len(file_checksums)} files")
        print(f"Manifest: {config['paths']['manifest_file']}")
    
    print()
    print("To restore from backup:")
    print(f"  tar -xzf {archive_path} -C /path/to/restore/")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
