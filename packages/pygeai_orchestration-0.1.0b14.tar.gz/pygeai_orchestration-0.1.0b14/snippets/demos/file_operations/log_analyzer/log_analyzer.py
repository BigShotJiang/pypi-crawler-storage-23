#!/usr/bin/env python3
"""
Log File Analyzer

Analyzes application log files to extract errors, warnings, and patterns.
Uses PlanningPattern to orchestrate parsing, classification, and reporting.
"""

import asyncio
import json
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.file_tools import FileSearchTool, FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool
from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_logs(config):
    """Generate sample application log files."""
    log_dir = Path(config["analysis"]["log_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    
    log_count = config["analysis"]["log_count"]
    entries_per_log = config["analysis"]["entries_per_log"]
    
    error_messages = [
        "Connection timeout to database server",
        "Failed to parse configuration file",
        "Out of memory exception",
        "Null pointer exception in module UserAuth",
        "File not found: /etc/config.yaml",
        "Permission denied accessing resource",
        "Network unreachable - retrying",
        "Invalid credentials for user admin",
        "Disk quota exceeded on /var/log",
        "SSL certificate verification failed"
    ]
    
    warning_messages = [
        "Deprecated API endpoint called",
        "Cache miss ratio above threshold",
        "High memory usage detected",
        "Slow query performance on table users",
        "Session timeout approaching",
        "Temporary file cleanup pending",
        "Resource pool running low",
        "Retry attempt 3 of 5"
    ]
    
    info_messages = [
        "Application started successfully",
        "User login successful",
        "Request processed in 45ms",
        "Cache refreshed",
        "Scheduled task completed",
        "Configuration reloaded",
        "Health check passed",
        "Backup completed successfully"
    ]
    
    base_time = datetime.now() - timedelta(hours=24)
    
    print(f"Generating {log_count} log files with {entries_per_log} entries each...")
    
    for log_num in range(1, log_count + 1):
        log_file = log_dir / f"application_{log_num}.log"
        
        with open(log_file, 'w') as f:
            for entry_num in range(entries_per_log):
                timestamp = base_time + timedelta(minutes=entry_num * 2)
                timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
                
                rand = random.random()
                if rand < 0.15:
                    level = "ERROR"
                    message = random.choice(error_messages)
                elif rand < 0.35:
                    level = "WARNING"
                    message = random.choice(warning_messages)
                else:
                    level = "INFO"
                    message = random.choice(info_messages)
                
                log_entry = f"[{timestamp_str}] [{level}] {message}\n"
                f.write(log_entry)
    
    print(f"Created {log_count} log files at {log_dir}")


async def main():
    """Execute log analysis workflow."""
    config = load_config()
    
    print("=" * 70)
    print("LOG FILE ANALYZER")
    print("=" * 70)
    print()
    
    await create_sample_logs(config)
    
    search_tool = FileSearchTool()
    reader_tool = FileReaderTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    stats_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing analysis database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["analysis_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS log_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_name TEXT NOT NULL,
            timestamp TEXT,
            level TEXT NOT NULL,
            message TEXT NOT NULL
        )
        """
    )
    
    print("Searching for log files...")
    
    search_result = await search_tool.execute(
        directory=config["analysis"]["log_dir"],
        pattern="*.log",
        recursive=False
    )
    
    if not search_result.success:
        print(f"Error searching log files: {search_result.error}")
        return
    
    log_files = search_result.result
    print(f"Found {len(log_files)} log files")
    
    print("\nParsing log entries...")
    
    total_entries = 0
    
    for log_file in log_files:
        file_name = Path(log_file).name
        print(f"  Processing {file_name}...", end=" ")
        
        read_result = await reader_tool.execute(path=log_file)
        
        if not read_result.success:
            print(f"Failed: {read_result.error}")
            continue
        
        content = read_result.result
        lines = content.split('\n')
        
        file_entry_count = 0
        
        for line in lines:
            if not line.strip():
                continue
            
            timestamp_match = await regex_tool.execute(
                pattern=config["analysis"]["patterns"]["timestamp"],
                text=line,
                operation="search"
            )
            
            timestamp = timestamp_match.result if timestamp_match.success and timestamp_match.result else None
            
            level = None
            if "ERROR" in line or "CRITICAL" in line or "FATAL" in line:
                level = "ERROR"
            elif "WARN" in line or "WARNING" in line:
                level = "WARNING"
            elif "INFO" in line:
                level = "INFO"
            else:
                level = "UNKNOWN"
            
            message_parts = line.split(']', 2)
            message = message_parts[-1].strip() if len(message_parts) >= 3 else line
            
            await sqlite_tool.execute(
                database=config["paths"]["analysis_db"],
                operation="execute",
                query="""
                INSERT INTO log_entries (file_name, timestamp, level, message)
                VALUES (?, ?, ?, ?)
                """,
                params=(file_name, timestamp, level, message)
            )
            
            file_entry_count += 1
            total_entries += 1
        
        print(f"{file_entry_count} entries")
    
    print(f"\nTotal entries parsed: {total_entries}")
    
    print("\nAnalyzing log patterns...")
    
    stats_result = await sqlite_tool.execute(
        database=config["paths"]["analysis_db"],
        operation="query",
        query="""
        SELECT 
            level,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM log_entries), 2) as percentage
        FROM log_entries
        GROUP BY level
        ORDER BY count DESC
        """
    )
    
    level_stats = stats_result.result if stats_result.success else []
    
    errors_result = await sqlite_tool.execute(
        database=config["paths"]["analysis_db"],
        operation="query",
        query=f"""
        SELECT 
            message,
            COUNT(*) as occurrence_count,
            MIN(timestamp) as first_seen,
            MAX(timestamp) as last_seen
        FROM log_entries
        WHERE level = 'ERROR'
        GROUP BY message
        ORDER BY occurrence_count DESC
        LIMIT {config['settings']['top_errors']}
        """
    )
    
    top_errors = errors_result.result if errors_result.success else []
    
    files_result = await sqlite_tool.execute(
        database=config["paths"]["analysis_db"],
        operation="query",
        query="""
        SELECT 
            file_name,
            COUNT(*) as total_entries,
            SUM(CASE WHEN level = 'ERROR' THEN 1 ELSE 0 END) as error_count,
            SUM(CASE WHEN level = 'WARNING' THEN 1 ELSE 0 END) as warning_count
        FROM log_entries
        GROUP BY file_name
        ORDER BY error_count DESC
        """
    )
    
    file_stats = files_result.result if files_result.success else []
    
    summary_data = {
        "analysis_timestamp": datetime.now().isoformat(),
        "files_analyzed": len(log_files),
        "total_entries": total_entries,
        "level_distribution": level_stats,
        "top_errors": top_errors,
        "file_statistics": file_stats
    }
    
    summary_json = json.dumps(summary_data, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["summary_report"],
        content=summary_json,
        mode="write"
    )
    
    print(f"Summary report saved: {config['paths']['summary_report']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Log Analysis Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .metric { display: inline-block; margin: 10px 30px 10px 0; }
        .metric-value { font-size: 32px; font-weight: bold; color: #3498db; }
        .metric-label { font-size: 14px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .error { color: #dc3545; font-weight: bold; }
        .warning { color: #ffc107; font-weight: bold; }
        .info { color: #28a745; }
        .chart { margin: 20px 0; }
    </style>
</head>
<body>
    <h1>Log Analysis Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Files Analyzed:</strong> {{ files_count }}</p>
    
    <div class="summary">
        <h2>Overview</h2>
        <div class="metric">
            <div class="metric-value">{{ total_entries }}</div>
            <div class="metric-label">Total Entries</div>
        </div>
        {% for stat in level_stats %}
        <div class="metric">
            <div class="metric-value">{{ stat.count }}</div>
            <div class="metric-label">{{ stat.level }} ({{ stat.percentage }}%)</div>
        </div>
        {% endfor %}
    </div>
    
    <h2>Top Errors</h2>
    <table>
        <thead>
            <tr>
                <th>Error Message</th>
                <th>Occurrences</th>
                <th>First Seen</th>
                <th>Last Seen</th>
            </tr>
        </thead>
        <tbody>
        {% for error in top_errors %}
            <tr>
                <td class="error">{{ error.message }}</td>
                <td>{{ error.occurrence_count }}</td>
                <td>{{ error.first_seen or 'N/A' }}</td>
                <td>{{ error.last_seen or 'N/A' }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>File Statistics</h2>
    <table>
        <thead>
            <tr>
                <th>Log File</th>
                <th>Total Entries</th>
                <th>Errors</th>
                <th>Warnings</th>
            </tr>
        </thead>
        <tbody>
        {% for file in file_stats %}
            <tr>
                <td>{{ file.file_name }}</td>
                <td>{{ file.total_entries }}</td>
                <td class="error">{{ file.error_count }}</td>
                <td class="warning">{{ file.warning_count }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</body>
</html>"""
    
    html_data = {
        "timestamp": summary_data["analysis_timestamp"],
        "files_count": summary_data["files_analyzed"],
        "total_entries": summary_data["total_entries"],
        "level_stats": level_stats,
        "top_errors": top_errors,
        "file_stats": file_stats
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["error_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"HTML report saved: {config['paths']['error_report']}")
    
    print()
    print("=" * 70)
    print("ANALYSIS SUMMARY")
    print("=" * 70)
    print(f"Files Analyzed: {len(log_files)}")
    print(f"Total Entries: {total_entries}")
    print()
    print("Log Level Distribution:")
    for stat in level_stats:
        print(f"  {stat['level']}: {stat['count']} ({stat['percentage']}%)")
    
    print()
    print(f"Top {len(top_errors)} Errors:")
    for i, error in enumerate(top_errors[:5], 1):
        print(f"  {i}. {error['message']} ({error['occurrence_count']} times)")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['analysis_db']}")
    print(f"  - Summary: {config['paths']['summary_report']}")
    print(f"  - HTML Report: {config['paths']['error_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
