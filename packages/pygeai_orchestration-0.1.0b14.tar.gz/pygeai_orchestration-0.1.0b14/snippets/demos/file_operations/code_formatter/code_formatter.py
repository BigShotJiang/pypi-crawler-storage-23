#!/usr/bin/env python3
"""
Code Formatter

Automatically formats code files in multiple languages with validation.
Uses ReflectionPattern to analyze, format, and verify code quality.
"""

import asyncio
import json
import shutil
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.reflection import ReflectionPattern
from pygeai_orchestration.tools.builtin.file_tools import FileReaderTool, FileWriterTool
from pygeai_orchestration.tools.builtin.data_tools import JSONParserTool, XMLParserTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool
from pygeai_orchestration.tools.builtin.utilities import ValidationTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_sample_files(config):
    """Generate sample unformatted code files."""
    source_dir = Path(config["paths"]["source_files"])
    source_dir.mkdir(parents=True, exist_ok=True)
    
    print("Generating sample code files...")
    
    python_code = '''def calculate(x,y,operation):
    if operation=="add":
        return x+y
    elif operation=="subtract":
        return x-y
    elif operation=="multiply":
        return x*y
    elif operation=="divide":
        if y!=0:
            return x/y
        else:
            raise ValueError("Cannot divide by zero")
    else:
        raise ValueError("Unknown operation")

class Calculator:
    def __init__(self,name):
        self.name=name
        self.history=[]
    
    def add(self,x,y):
        result=x+y
        self.history.append({"op":"add","x":x,"y":y,"result":result})
        return result
    
    def get_history(self):
        return self.history
'''
    
    with open(source_dir / "calculator.py", 'w') as f:
        f.write(python_code)
    
    javascript_code = '''function processData(data,options){
if(!data){return null}
const results=[]
for(let i=0;i<data.length;i++){
const item=data[i]
if(options.filter&&!options.filter(item)){continue}
const processed={id:item.id,value:item.value*2,timestamp:new Date().toISOString()}
results.push(processed)
}
return results
}

class DataProcessor{
constructor(config){
this.config=config
this.cache=new Map()
}

process(data){
const key=JSON.stringify(data)
if(this.cache.has(key)){return this.cache.get(key)}
const result=processData(data,this.config)
this.cache.set(key,result)
return result
}
}
'''
    
    with open(source_dir / "processor.js", 'w') as f:
        f.write(javascript_code)
    
    json_data = '''{"name":"Test Project","version":"1.0.0","dependencies":{"express":"^4.18.0","lodash":"^4.17.21"},"scripts":{"start":"node index.js","test":"jest"},"author":"Developer","license":"MIT"}'''
    
    with open(source_dir / "package.json", 'w') as f:
        f.write(json_data)
    
    xml_data = '''<?xml version="1.0" encoding="UTF-8"?><configuration><database><host>localhost</host><port>5432</port><name>mydb</name><credentials><username>admin</username><password>secret</password></credentials></database><logging><level>INFO</level><output>console</output></logging></configuration>'''
    
    with open(source_dir / "config.xml", 'w') as f:
        f.write(xml_data)
    
    print(f"Generated sample files in {source_dir}")


def format_python_code(code, config):
    """Format Python code."""
    lines = code.split('\n')
    formatted_lines = []
    indent_level = 0
    indent_size = config["formatting"]["python"]["indent_size"]
    
    for line in lines:
        stripped = line.strip()
        
        if not stripped:
            formatted_lines.append('')
            continue
        
        if stripped.startswith(('return', 'pass', 'break', 'continue', 'raise')) or stripped.startswith('#'):
            formatted_lines.append(' ' * (indent_level * indent_size) + stripped)
        elif stripped.startswith(('elif ', 'else:', 'except:', 'except ', 'finally:')):
            indent_level = max(0, indent_level - 1)
            formatted_lines.append(' ' * (indent_level * indent_size) + stripped)
            indent_level += 1
        else:
            if formatted_lines and formatted_lines[-1].strip().endswith(':'):
                indent_level += 1
            
            formatted_lines.append(' ' * (indent_level * indent_size) + stripped)
        
        if stripped.endswith(':'):
            if not any(stripped.startswith(kw) for kw in ['elif ', 'else:', 'except:', 'except ', 'finally:']):
                pass
    
    formatted_code = '\n'.join(formatted_lines)
    
    formatted_code = formatted_code.replace('==', ' == ')
    formatted_code = formatted_code.replace('!=', ' != ')
    formatted_code = formatted_code.replace('=', ' = ')
    formatted_code = formatted_code.replace('  =  =', ' ==')
    formatted_code = formatted_code.replace('!  =', ' !=')
    formatted_code = formatted_code.replace(',', ', ')
    formatted_code = formatted_code.replace('+', ' + ')
    formatted_code = formatted_code.replace('-', ' - ')
    formatted_code = formatted_code.replace('*', ' * ')
    formatted_code = formatted_code.replace('/', ' / ')
    
    while '  ' in formatted_code:
        formatted_code = formatted_code.replace('  ', ' ')
    
    return formatted_code


def format_javascript_code(code, config):
    """Format JavaScript code."""
    lines = code.split('\n')
    formatted_lines = []
    indent_level = 0
    indent_size = config["formatting"]["javascript"]["indent_size"]
    
    for line in lines:
        stripped = line.strip()
        
        if not stripped:
            formatted_lines.append('')
            continue
        
        if stripped.startswith('}'):
            indent_level = max(0, indent_level - 1)
        
        formatted_line = ' ' * (indent_level * indent_size) + stripped
        
        if config["formatting"]["javascript"]["use_semicolons"]:
            if not stripped.endswith((';', '{', '}')):
                if not stripped.startswith(('if', 'for', 'while', 'function', 'class')):
                    formatted_line += ';'
        
        formatted_lines.append(formatted_line)
        
        if stripped.endswith('{'):
            indent_level += 1
    
    formatted_code = '\n'.join(formatted_lines)
    
    formatted_code = formatted_code.replace('=', ' = ')
    formatted_code = formatted_code.replace('  = ', ' = ')
    formatted_code = formatted_code.replace(',', ', ')
    formatted_code = formatted_code.replace('+', ' + ')
    
    while '  ' in formatted_code:
        formatted_code = formatted_code.replace('  ', ' ')
    
    return formatted_code


async def main():
    """Execute code formatting workflow."""
    config = load_config()
    
    print("=" * 70)
    print("CODE FORMATTER")
    print("=" * 70)
    print()
    
    await generate_sample_files(config)
    
    formatted_dir = Path(config["paths"]["formatted_files"])
    formatted_dir.mkdir(parents=True, exist_ok=True)
    
    reader_tool = FileReaderTool()
    writer_tool = FileWriterTool()
    json_tool = JSONParserTool()
    xml_tool = XMLParserTool()
    regex_tool = RegexTool()
    validation_tool = ValidationTool()
    
    source_dir = Path(config["paths"]["source_files"])
    source_files = list(source_dir.glob('*'))
    
    print(f"\nFound {len(source_files)} files to format")
    print()
    
    format_results = []
    
    for source_file in source_files:
        if not source_file.is_file():
            continue
        
        file_name = source_file.name
        file_ext = source_file.suffix.lower()
        
        print(f"Processing: {file_name}")
        
        result = {
            "file": file_name,
            "original_path": str(source_file),
            "formatted_path": str(formatted_dir / file_name),
            "success": False,
            "changes_made": False
        }
        
        if config["settings"]["backup_originals"]:
            backup_path = source_dir / f"{file_name}.bak"
            shutil.copy2(source_file, backup_path)
            result["backup_path"] = str(backup_path)
        
        read_result = await reader_tool.execute(path=str(source_file))
        
        if not read_result.success:
            result["error"] = f"Failed to read file: {read_result.error}"
            format_results.append(result)
            print(f"  Error reading file: {read_result.error}")
            continue
        
        original_content = read_result.result
        formatted_content = original_content
        
        try:
            if file_ext == '.py':
                formatted_content = format_python_code(original_content, config)
                result["language"] = "python"
                
            elif file_ext == '.js':
                formatted_content = format_javascript_code(original_content, config)
                result["language"] = "javascript"
                
            elif file_ext == '.json':
                json_result = await json_tool.execute(
                    file_path=str(source_file),
                    operation="read"
                )
                
                if json_result.success:
                    data = json_result.result
                    indent = config["formatting"]["json"]["indent_size"]
                    sort_keys = config["formatting"]["json"]["sort_keys"]
                    formatted_content = json.dumps(data, indent=indent, sort_keys=sort_keys)
                    result["language"] = "json"
                
            elif file_ext == '.xml':
                xml_result = await xml_tool.execute(
                    file_path=str(source_file),
                    operation="read"
                )
                
                if xml_result.success:
                    formatted_content = xml_result.result
                    result["language"] = "xml"
            
            result["original_lines"] = len(original_content.split('\n'))
            result["formatted_lines"] = len(formatted_content.split('\n'))
            result["original_size"] = len(original_content)
            result["formatted_size"] = len(formatted_content)
            result["changes_made"] = original_content != formatted_content
            
            write_result = await writer_tool.execute(
                path=str(formatted_dir / file_name),
                content=formatted_content,
                mode="write"
            )
            
            if write_result.success:
                result["success"] = True
                if result["changes_made"]:
                    print(f"  Formatted successfully ({result['original_size']} -> {result['formatted_size']} bytes)")
                else:
                    print(f"  No changes needed")
            else:
                result["error"] = f"Failed to write file: {write_result.error}"
                print(f"  Error writing file: {write_result.error}")
            
        except Exception as e:
            result["error"] = str(e)
            print(f"  Error formatting: {str(e)}")
        
        format_results.append(result)
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "total_files": len(format_results),
        "successful": len([r for r in format_results if r["success"]]),
        "failed": len([r for r in format_results if not r["success"]]),
        "modified": len([r for r in format_results if r.get("changes_made", False)]),
        "results": format_results
    }
    
    report_json = json.dumps(report, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["format_report"],
        content=report_json,
        mode="write"
    )
    
    print()
    print("=" * 70)
    print("FORMAT SUMMARY")
    print("=" * 70)
    print(f"Total Files: {report['total_files']}")
    print(f"Successful: {report['successful']}")
    print(f"Failed: {report['failed']}")
    print(f"Modified: {report['modified']}")
    print()
    
    if report['modified'] > 0:
        print("Modified Files:")
        for r in format_results:
            if r.get("changes_made"):
                size_change = r['formatted_size'] - r['original_size']
                print(f"  - {r['file']}: {r['original_size']} -> {r['formatted_size']} bytes ({size_change:+d})")
        print()
    
    print("Output files:")
    print(f"  - Formatted Files: {formatted_dir}")
    print(f"  - Format Report: {config['paths']['format_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
