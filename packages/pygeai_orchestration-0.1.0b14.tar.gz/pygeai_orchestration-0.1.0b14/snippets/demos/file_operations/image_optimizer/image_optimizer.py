#!/usr/bin/env python3
"""
Image Optimizer

Optimizes images for web by resizing and compressing.
Uses ToolUsePattern to process image files efficiently.
"""

import asyncio
import json
import base64
from pathlib import Path
from datetime import datetime
from io import BytesIO
from PIL import Image
from pygeai_orchestration.patterns.tool_use import ToolUsePattern
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool, FileReaderTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


def create_sample_images(source_dir, count=5):
    """Create sample images for optimization."""
    source_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Creating {count} sample images...")
    
    for i in range(1, count + 1):
        width = 2400 + (i * 100)
        height = 1600 + (i * 50)
        
        img = Image.new('RGB', (width, height), color=(
            (i * 50) % 256,
            (i * 30) % 256,
            (i * 70) % 256
        ))
        
        for x in range(0, width, 100):
            for y in range(0, height, 100):
                color = (
                    (x + y) % 256,
                    (x - y) % 256,
                    (x * y // 100) % 256
                )
                for dx in range(50):
                    for dy in range(50):
                        if x + dx < width and y + dy < height:
                            img.putpixel((x + dx, y + dy), color)
        
        img_path = source_dir / f"image_{i}.jpg"
        img.save(img_path, 'JPEG', quality=95)
        
        print(f"  Created: {img_path.name} ({width}x{height})")


def optimize_image(image_path, output_path, max_width, max_height, quality):
    """Optimize a single image."""
    img = Image.open(image_path)
    
    original_size = image_path.stat().st_size
    original_width, original_height = img.size
    
    if img.width > max_width or img.height > max_height:
        img.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
    
    img.save(output_path, 'JPEG', quality=quality, optimize=True)
    
    optimized_size = output_path.stat().st_size
    new_width, new_height = img.size
    
    return {
        "original_size": original_size,
        "optimized_size": optimized_size,
        "size_reduction": original_size - optimized_size,
        "reduction_percent": ((original_size - optimized_size) / original_size * 100) if original_size > 0 else 0,
        "original_dimensions": f"{original_width}x{original_height}",
        "optimized_dimensions": f"{new_width}x{new_height}"
    }


def create_thumbnail(image_path, thumbnail_path, size):
    """Create thumbnail from image."""
    img = Image.open(image_path)
    img.thumbnail((size, size), Image.Resampling.LANCZOS)
    img.save(thumbnail_path, 'JPEG', quality=85)


async def main():
    """Execute image optimization workflow."""
    config = load_config()
    
    print("=" * 70)
    print("IMAGE OPTIMIZER")
    print("=" * 70)
    print()
    
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    source_dir = Path(config["optimization"]["source_dir"])
    output_dir = Path(config["optimization"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    
    if config["optimization"]["generate_thumbnails"]:
        thumbnails_dir = output_dir / "thumbnails"
        thumbnails_dir.mkdir(parents=True, exist_ok=True)
    
    if not list(source_dir.glob("*")):
        create_sample_images(source_dir)
    else:
        print(f"Using existing images in {source_dir}")
    
    sqlite_tool = SQLiteTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing optimization database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["stats_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS optimization_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            original_size INTEGER,
            optimized_size INTEGER,
            size_reduction INTEGER,
            reduction_percent REAL,
            original_dimensions TEXT,
            optimized_dimensions TEXT,
            optimized_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    print("\nOptimizing images...")
    
    image_files = []
    for fmt in config["optimization"]["formats"]:
        image_files.extend(list(source_dir.glob(f"*.{fmt}")))
    
    if not image_files:
        print("No images found to optimize!")
        return
    
    print(f"Found {len(image_files)} images to optimize")
    print()
    
    optimization_results = []
    total_original_size = 0
    total_optimized_size = 0
    
    for img_file in image_files:
        print(f"Processing: {img_file.name}")
        
        output_path = output_dir / img_file.name
        
        stats = optimize_image(
            img_file,
            output_path,
            config["optimization"]["max_width"],
            config["optimization"]["max_height"],
            config["optimization"]["quality"]
        )
        
        total_original_size += stats["original_size"]
        total_optimized_size += stats["optimized_size"]
        
        print(f"  Original: {stats['original_size']:,} bytes ({stats['original_dimensions']})")
        print(f"  Optimized: {stats['optimized_size']:,} bytes ({stats['optimized_dimensions']})")
        print(f"  Saved: {stats['size_reduction']:,} bytes ({stats['reduction_percent']:.1f}%)")
        
        await sqlite_tool.execute(
            database=config["paths"]["stats_db"],
            operation="execute",
            query="""
            INSERT INTO optimization_stats 
            (filename, original_size, optimized_size, size_reduction, reduction_percent, 
             original_dimensions, optimized_dimensions)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            params=(
                img_file.name,
                stats["original_size"],
                stats["optimized_size"],
                stats["size_reduction"],
                stats["reduction_percent"],
                stats["original_dimensions"],
                stats["optimized_dimensions"]
            )
        )
        
        if config["optimization"]["generate_thumbnails"]:
            thumbnail_path = thumbnails_dir / f"thumb_{img_file.name}"
            create_thumbnail(output_path, thumbnail_path, config["optimization"]["thumbnail_size"])
            print(f"  Thumbnail: {thumbnail_path.name}")
        
        optimization_results.append({
            "filename": img_file.name,
            "original_size": stats["original_size"],
            "optimized_size": stats["optimized_size"],
            "size_reduction": stats["size_reduction"],
            "reduction_percent": round(stats["reduction_percent"], 2),
            "original_dimensions": stats["original_dimensions"],
            "optimized_dimensions": stats["optimized_dimensions"]
        })
        
        print()
    
    total_reduction = total_original_size - total_optimized_size
    total_reduction_percent = (total_reduction / total_original_size * 100) if total_original_size > 0 else 0
    
    report_data = {
        "timestamp": datetime.now().isoformat(),
        "total_images": len(image_files),
        "total_original_size": total_original_size,
        "total_optimized_size": total_optimized_size,
        "total_size_reduction": total_reduction,
        "total_reduction_percent": round(total_reduction_percent, 2),
        "settings": {
            "max_width": config["optimization"]["max_width"],
            "max_height": config["optimization"]["max_height"],
            "quality": config["optimization"]["quality"]
        },
        "results": optimization_results
    }
    
    await writer_tool.execute(
        path=config["paths"]["report"],
        content=json.dumps(report_data, indent=2),
        mode="write"
    )
    
    print("=" * 70)
    print("OPTIMIZATION SUMMARY")
    print("=" * 70)
    print(f"Images Processed: {len(image_files)}")
    print(f"Total Original Size: {total_original_size:,} bytes ({total_original_size / 1024 / 1024:.2f} MB)")
    print(f"Total Optimized Size: {total_optimized_size:,} bytes ({total_optimized_size / 1024 / 1024:.2f} MB)")
    print(f"Total Saved: {total_reduction:,} bytes ({total_reduction / 1024 / 1024:.2f} MB)")
    print(f"Reduction: {total_reduction_percent:.1f}%")
    print()
    print("Output locations:")
    print(f"  - Optimized images: {output_dir}")
    if config["optimization"]["generate_thumbnails"]:
        print(f"  - Thumbnails: {thumbnails_dir}")
    print(f"  - Statistics database: {config['paths']['stats_db']}")
    print(f"  - Report: {config['paths']['report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
