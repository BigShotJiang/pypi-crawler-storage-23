#!/usr/bin/env python3
"""
ETL Pipeline

Extract, Transform, Load pipeline processing data from multiple sources.
Uses PlanningPattern to orchestrate the multi-stage ETL workflow.
"""

import asyncio
import json
import csv
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool, JSONParserTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, ValidationTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_source_data(config):
    """Generate sample source data files."""
    source_dir = Path(config["paths"]["source_dir"])
    source_dir.mkdir(parents=True, exist_ok=True)
    
    staging_dir = Path(config["paths"]["staging_dir"])
    staging_dir.mkdir(parents=True, exist_ok=True)
    
    print("Generating source data...")
    
    customers_csv = source_dir / "customers.csv"
    with open(customers_csv, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["customer_id", "name", "email", "city", "country", "signup_date"])
        
        cities = ["New York", "London", "Tokyo", "Paris", "Sydney"]
        countries = ["USA", "UK", "Japan", "France", "Australia"]
        
        for i in range(1, 101):
            name = f"Customer {i}"
            email = f"customer{i}@example.com"
            city = random.choice(cities)
            country = random.choice(countries)
            signup_date = (datetime.now() - timedelta(days=random.randint(1, 365))).strftime("%Y-%m-%d")
            
            writer.writerow([f"CUST{i:04d}", name, email, city, country, signup_date])
    
    print(f"Created customers CSV: {customers_csv}")
    
    transactions_json = source_dir / "transactions.json"
    transactions = []
    
    for i in range(1, 201):
        transaction = {
            "transaction_id": f"TXN{i:06d}",
            "customer_id": f"CUST{random.randint(1, 100):04d}",
            "amount": round(random.uniform(10, 1000), 2),
            "currency": "USD",
            "status": random.choice(["completed", "pending", "failed"]),
            "transaction_date": (datetime.now() - timedelta(days=random.randint(1, 90))).isoformat(),
            "payment_method": random.choice(["credit_card", "debit_card", "paypal"])
        }
        transactions.append(transaction)
    
    with open(transactions_json, 'w') as f:
        json.dump(transactions, f, indent=2)
    
    print(f"Created transactions JSON: {transactions_json}")


async def main():
    """Execute ETL pipeline workflow."""
    config = load_config()
    
    print("=" * 70)
    print("ETL PIPELINE")
    print("=" * 70)
    print()
    
    await generate_source_data(config)
    
    csv_tool = CSVProcessorTool()
    json_tool = JSONParserTool()
    sqlite_tool = SQLiteTool()
    validation_tool = ValidationTool()
    regex_tool = RegexTool()
    writer_tool = FileWriterTool()
    
    etl_log = []
    
    def log_step(stage, message, status="INFO"):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "stage": stage,
            "status": status,
            "message": message
        }
        etl_log.append(entry)
        print(f"[{stage}] {message}")
    
    log_step("START", "ETL Pipeline execution started")
    
    print("\n" + "=" * 70)
    print("STAGE 1: EXTRACT")
    print("=" * 70)
    
    log_step("EXTRACT", "Reading customer data from CSV")
    
    customers_result = await csv_tool.execute(
        file_path=str(Path(config["paths"]["source_dir"]) / "customers.csv"),
        operation="read"
    )
    
    if not customers_result.success:
        log_step("EXTRACT", f"Failed to read customers: {customers_result.error}", "ERROR")
        return
    
    customers = customers_result.result
    log_step("EXTRACT", f"Extracted {len(customers)} customer records")
    
    log_step("EXTRACT", "Reading transaction data from JSON")
    
    transactions_result = await json_tool.execute(
        file_path=str(Path(config["paths"]["source_dir"]) / "transactions.json"),
        operation="read"
    )
    
    if not transactions_result.success:
        log_step("EXTRACT", f"Failed to read transactions: {transactions_result.error}", "ERROR")
        return
    
    transactions = transactions_result.result
    log_step("EXTRACT", f"Extracted {len(transactions)} transaction records")
    
    print("\n" + "=" * 70)
    print("STAGE 2: TRANSFORM")
    print("=" * 70)
    
    log_step("TRANSFORM", "Validating customer data")
    
    valid_customers = []
    invalid_count = 0
    
    for customer in customers:
        is_valid = True
        
        if config["transform"]["validation_rules"]["email_required"]:
            email_check = await regex_tool.execute(
                pattern=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
                text=customer.get("email", ""),
                operation="match"
            )
            
            if not email_check.success or not email_check.result:
                is_valid = False
        
        if is_valid:
            customer["email"] = customer["email"].lower()
            customer["name"] = customer["name"].strip()
            valid_customers.append(customer)
        else:
            invalid_count += 1
    
    log_step("TRANSFORM", f"Validated customers: {len(valid_customers)} valid, {invalid_count} invalid")
    
    log_step("TRANSFORM", "Deduplicating customer records")
    
    seen_emails = set()
    deduplicated_customers = []
    duplicate_count = 0
    
    for customer in valid_customers:
        email = customer["email"]
        if email not in seen_emails:
            seen_emails.add(email)
            deduplicated_customers.append(customer)
        else:
            duplicate_count += 1
    
    log_step("TRANSFORM", f"Removed {duplicate_count} duplicate records")
    
    log_step("TRANSFORM", "Validating and transforming transactions")
    
    valid_transactions = []
    invalid_txn_count = 0
    
    for txn in transactions:
        amount = txn.get("amount", 0)
        
        if (amount >= config["transform"]["validation_rules"]["amount_min"] and 
            amount <= config["transform"]["validation_rules"]["amount_max"]):
            
            txn["amount"] = round(amount, 2)
            valid_transactions.append(txn)
        else:
            invalid_txn_count += 1
    
    log_step("TRANSFORM", f"Validated transactions: {len(valid_transactions)} valid, {invalid_txn_count} invalid")
    
    log_step("TRANSFORM", "Enriching transaction data with customer info")
    
    customer_lookup = {c["customer_id"]: c for c in deduplicated_customers}
    enriched_transactions = []
    
    for txn in valid_transactions:
        customer_id = txn["customer_id"]
        if customer_id in customer_lookup:
            customer = customer_lookup[customer_id]
            enriched_txn = {
                **txn,
                "customer_name": customer["name"],
                "customer_email": customer["email"],
                "customer_country": customer["country"]
            }
            enriched_transactions.append(enriched_txn)
    
    log_step("TRANSFORM", f"Enriched {len(enriched_transactions)} transactions")
    
    print("\n" + "=" * 70)
    print("STAGE 3: LOAD")
    print("=" * 70)
    
    log_step("LOAD", "Creating target database schema")
    
    await sqlite_tool.execute(
        database=config["load"]["target_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            city TEXT,
            country TEXT,
            signup_date TEXT,
            loaded_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    await sqlite_tool.execute(
        database=config["load"]["target_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            amount REAL NOT NULL,
            currency TEXT,
            status TEXT,
            transaction_date TEXT,
            payment_method TEXT,
            customer_name TEXT,
            customer_email TEXT,
            customer_country TEXT,
            loaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        )
        """
    )
    
    log_step("LOAD", "Loading customer data into database")
    
    loaded_customers = 0
    
    for customer in deduplicated_customers:
        insert_result = await sqlite_tool.execute(
            database=config["load"]["target_db"],
            operation="execute",
            query="""
            INSERT OR REPLACE INTO customers (customer_id, name, email, city, country, signup_date)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            params=(
                customer["customer_id"],
                customer["name"],
                customer["email"],
                customer["city"],
                customer["country"],
                customer["signup_date"]
            )
        )
        
        if insert_result.success:
            loaded_customers += 1
    
    log_step("LOAD", f"Loaded {loaded_customers} customers into database")
    
    log_step("LOAD", "Loading transaction data into database")
    
    loaded_transactions = 0
    
    for txn in enriched_transactions:
        insert_result = await sqlite_tool.execute(
            database=config["load"]["target_db"],
            operation="execute",
            query="""
            INSERT OR REPLACE INTO transactions 
            (transaction_id, customer_id, amount, currency, status, transaction_date, payment_method, 
             customer_name, customer_email, customer_country)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            params=(
                txn["transaction_id"],
                txn["customer_id"],
                txn["amount"],
                txn["currency"],
                txn["status"],
                txn["transaction_date"],
                txn["payment_method"],
                txn["customer_name"],
                txn["customer_email"],
                txn["customer_country"]
            )
        )
        
        if insert_result.success:
            loaded_transactions += 1
    
    log_step("LOAD", f"Loaded {loaded_transactions} transactions into database")
    
    if config["load"]["create_indexes"]:
        log_step("LOAD", "Creating database indexes")
        
        await sqlite_tool.execute(
            database=config["load"]["target_db"],
            operation="execute",
            query="CREATE INDEX IF NOT EXISTS idx_customer_email ON customers(email)"
        )
        
        await sqlite_tool.execute(
            database=config["load"]["target_db"],
            operation="execute",
            query="CREATE INDEX IF NOT EXISTS idx_transaction_customer ON transactions(customer_id)"
        )
        
        await sqlite_tool.execute(
            database=config["load"]["target_db"],
            operation="execute",
            query="CREATE INDEX IF NOT EXISTS idx_transaction_date ON transactions(transaction_date)"
        )
        
        log_step("LOAD", "Indexes created successfully")
    
    log_step("LOAD", "Verifying data integrity")
    
    verify_result = await sqlite_tool.execute(
        database=config["load"]["target_db"],
        operation="query",
        query="""
        SELECT 
            (SELECT COUNT(*) FROM customers) as customer_count,
            (SELECT COUNT(*) FROM transactions) as transaction_count,
            (SELECT SUM(amount) FROM transactions WHERE status = 'completed') as total_revenue
        """
    )
    
    if verify_result.success and verify_result.result:
        verification = verify_result.result[0]
        log_step("LOAD", f"Verification: {verification['customer_count']} customers, {verification['transaction_count']} transactions, ${verification['total_revenue']:.2f} revenue")
    
    log_step("COMPLETE", "ETL Pipeline execution completed successfully")
    
    summary = {
        "execution_timestamp": datetime.now().isoformat(),
        "stages": {
            "extract": {
                "customers_extracted": len(customers),
                "transactions_extracted": len(transactions)
            },
            "transform": {
                "customers_validated": len(valid_customers),
                "customers_deduplicated": len(deduplicated_customers),
                "customers_invalid": invalid_count,
                "transactions_validated": len(valid_transactions),
                "transactions_enriched": len(enriched_transactions),
                "transactions_invalid": invalid_txn_count
            },
            "load": {
                "customers_loaded": loaded_customers,
                "transactions_loaded": loaded_transactions,
                "target_database": config["load"]["target_db"]
            }
        },
        "execution_log": etl_log
    }
    
    summary_json = json.dumps(summary, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["summary_report"],
        content=summary_json,
        mode="write"
    )
    
    print()
    print("=" * 70)
    print("ETL SUMMARY")
    print("=" * 70)
    print(f"Customers: {len(customers)} extracted -> {loaded_customers} loaded")
    print(f"Transactions: {len(transactions)} extracted -> {loaded_transactions} loaded")
    print()
    print("Data Quality:")
    print(f"  Invalid customers removed: {invalid_count}")
    print(f"  Duplicate customers removed: {duplicate_count}")
    print(f"  Invalid transactions removed: {invalid_txn_count}")
    print()
    print("Output files:")
    print(f"  - Target Database: {config['load']['target_db']}")
    print(f"  - Summary Report: {config['paths']['summary_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
