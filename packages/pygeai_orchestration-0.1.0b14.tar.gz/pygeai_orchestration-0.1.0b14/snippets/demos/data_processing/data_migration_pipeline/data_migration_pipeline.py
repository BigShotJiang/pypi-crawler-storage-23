#!/usr/bin/env python3
"""
Data Migration Pipeline

Migrates employee data from CSV to SQLite database with comprehensive validation,
integrity checking, and reporting. Uses PlanningPattern to orchestrate the
multi-step migration workflow.
"""

import asyncio
import json
import csv
import random
from pathlib import Path
from datetime import datetime, date
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, ValidationTool, HashTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def create_sample_csv(config):
    """Create sample employee CSV data."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    csv_path = config["paths"]["source_csv"]
    num_employees = config["data"]["num_employees"]
    departments = config["data"]["departments"]
    
    first_names = ["John", "Jane", "Michael", "Sarah", "David", "Emily", "Robert", "Lisa", "James", "Mary"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
    
    print(f"Generating {num_employees} employee records...")
    
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            "employee_id", "name", "email", "department", "salary", "hire_date", "status"
        ])
        
        for i in range(1, num_employees + 1):
            first_name = random.choice(first_names)
            last_name = random.choice(last_names)
            name = f"{first_name} {last_name}"
            email = f"{first_name.lower()}.{last_name.lower()}{i}@company.example.com"
            department = random.choice(departments)
            salary = random.randint(40000, 150000)
            
            year = random.randint(2015, 2023)
            month = random.randint(1, 12)
            day = random.randint(1, 28)
            hire_date = date(year, month, day).isoformat()
            
            status = "Active" if random.random() > 0.1 else "Inactive"
            
            writer.writerow([
                f"EMP{i:04d}",
                name,
                email,
                department,
                salary,
                hire_date,
                status
            ])
    
    with open(csv_path, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            "EMP9999",
            "Invalid User",
            "not-an-email",
            "Unknown",
            25000,
            "2020-01-01",
            "Active"
        ])
    
    print(f"Created CSV with {num_employees + 1} records at {csv_path}")
    print("(Includes 1 invalid record for validation testing)")


async def main():
    """Execute the data migration pipeline."""
    config = load_config()
    
    print("=" * 70)
    print("DATA MIGRATION PIPELINE")
    print("=" * 70)
    print()
    
    await create_sample_csv(config)
    
    csv_tool = CSVProcessorTool()
    sqlite_tool = SQLiteTool()
    validation_tool = ValidationTool()
    regex_tool = RegexTool()
    hash_tool = HashTool()
    writer_tool = FileWriterTool()
    
    migration_log = []
    
    def log_step(step, status, message):
        """Log migration step."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "step": step,
            "status": status,
            "message": message
        }
        migration_log.append(entry)
        print(f"[{status}] {step}: {message}")
    
    log_step("START", "INFO", "Beginning data migration")
    
    print("\nStep 1: Reading source CSV...")
    
    csv_result = await csv_tool.execute(
        file_path=config["paths"]["source_csv"],
        operation="read"
    )
    
    if not csv_result.success:
        log_step("READ_CSV", "ERROR", f"Failed to read CSV: {csv_result.error}")
        return
    
    source_data = csv_result.result
    log_step("READ_CSV", "SUCCESS", f"Read {len(source_data)} records from CSV")
    
    print("\nStep 2: Validating data...")
    
    validation_errors = []
    valid_records = []
    
    for idx, record in enumerate(source_data, 1):
        errors = []
        
        for field in config["validation"]["required_fields"]:
            if field not in record or not record[field]:
                errors.append(f"Missing required field: {field}")
        
        if "email" in record:
            email_validation = await regex_tool.execute(
                pattern=config["validation"]["email_pattern"],
                text=record["email"],
                operation="match"
            )
            
            if not email_validation.success or not email_validation.result:
                errors.append(f"Invalid email format: {record.get('email', '')}")
        
        if "salary" in record:
            try:
                salary = float(record["salary"])
                if salary < config["validation"]["min_salary"] or salary > config["validation"]["max_salary"]:
                    errors.append(f"Salary out of range: {salary}")
            except (ValueError, TypeError):
                errors.append(f"Invalid salary value: {record.get('salary', '')}")
        
        if errors:
            validation_errors.append({
                "record_index": idx,
                "employee_id": record.get("employee_id", "UNKNOWN"),
                "errors": errors
            })
        else:
            valid_records.append(record)
    
    log_step(
        "VALIDATE",
        "WARNING" if validation_errors else "SUCCESS",
        f"Validated {len(source_data)} records: {len(valid_records)} valid, {len(validation_errors)} invalid"
    )
    
    print("\nStep 3: Creating database schema...")
    
    create_table_result = await sqlite_tool.execute(
        database=config["paths"]["database"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS employees (
            employee_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            department TEXT NOT NULL,
            salary REAL NOT NULL,
            hire_date TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            checksum TEXT
        )
        """
    )
    
    if not create_table_result.success:
        log_step("CREATE_SCHEMA", "ERROR", f"Failed to create schema: {create_table_result.error}")
        return
    
    log_step("CREATE_SCHEMA", "SUCCESS", "Database schema created")
    
    print("\nStep 4: Migrating valid records...")
    
    migrated_count = 0
    migration_errors = []
    
    for record in valid_records:
        record_str = json.dumps(record, sort_keys=True)
        hash_result = await hash_tool.execute(
            operation="string",
            data=record_str,
            algorithm="sha256"
        )
        
        checksum = hash_result.result if hash_result.success else None
        
        insert_result = await sqlite_tool.execute(
            database=config["paths"]["database"],
            operation="execute",
            query="""
            INSERT INTO employees (employee_id, name, email, department, salary, hire_date, status, checksum)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            params=(
                record["employee_id"],
                record["name"],
                record["email"],
                record["department"],
                float(record["salary"]),
                record["hire_date"],
                record["status"],
                checksum
            )
        )
        
        if insert_result.success:
            migrated_count += 1
        else:
            migration_errors.append({
                "employee_id": record["employee_id"],
                "error": str(insert_result.error)
            })
    
    log_step("MIGRATE", "SUCCESS", f"Migrated {migrated_count} records to database")
    
    if config["settings"]["verify_integrity"]:
        print("\nStep 5: Verifying data integrity...")
        
        count_result = await sqlite_tool.execute(
            database=config["paths"]["database"],
            operation="query",
            query="SELECT COUNT(*) as count FROM employees"
        )
        
        if count_result.success and count_result.result:
            db_count = count_result.result[0]["count"]
            
            if db_count == migrated_count:
                log_step("VERIFY", "SUCCESS", f"Integrity check passed: {db_count} records in database")
            else:
                log_step("VERIFY", "ERROR", f"Integrity mismatch: expected {migrated_count}, found {db_count}")
        
        stats_result = await sqlite_tool.execute(
            database=config["paths"]["database"],
            operation="query",
            query="""
            SELECT 
                department,
                COUNT(*) as count,
                AVG(salary) as avg_salary,
                MIN(salary) as min_salary,
                MAX(salary) as max_salary
            FROM employees
            GROUP BY department
            ORDER BY count DESC
            """
        )
        
        if stats_result.success:
            log_step("STATS", "INFO", f"Generated statistics for {len(stats_result.result)} departments")
    
    validation_report = {
        "migration_summary": {
            "timestamp": datetime.now().isoformat(),
            "source_file": config["paths"]["source_csv"],
            "database": config["paths"]["database"],
            "total_records": len(source_data),
            "valid_records": len(valid_records),
            "invalid_records": len(validation_errors),
            "migrated_records": migrated_count,
            "migration_errors": len(migration_errors)
        },
        "validation_errors": validation_errors,
        "migration_errors": migration_errors,
        "department_stats": stats_result.result if stats_result.success else [],
        "migration_log": migration_log
    }
    
    report_json = json.dumps(validation_report, indent=2)
    
    report_write_result = await writer_tool.execute(
        path=config["paths"]["validation_report"],
        content=report_json,
        mode="write"
    )
    
    if report_write_result.success:
        log_step("REPORT", "SUCCESS", f"Validation report saved to {config['paths']['validation_report']}")
    
    log_step("COMPLETE", "SUCCESS", "Data migration completed")
    
    print()
    print("=" * 70)
    print("MIGRATION SUMMARY")
    print("=" * 70)
    print(f"Source Records: {len(source_data)}")
    print(f"Valid Records: {len(valid_records)}")
    print(f"Invalid Records: {len(validation_errors)}")
    print(f"Successfully Migrated: {migrated_count}")
    
    if validation_errors:
        print(f"\nValidation Errors: {len(validation_errors)}")
        for error in validation_errors[:3]:
            print(f"  - Record {error['record_index']} ({error['employee_id']}): {', '.join(error['errors'])}")
        if len(validation_errors) > 3:
            print(f"  ... and {len(validation_errors) - 3} more")
    
    if stats_result.success:
        print("\nDepartment Statistics:")
        for dept in stats_result.result:
            print(f"  - {dept['department']}: {dept['count']} employees, avg salary: ${dept['avg_salary']:.2f}")
    
    print()
    print("Output files:")
    print(f"  - Database: {config['paths']['database']}")
    print(f"  - Validation Report: {config['paths']['validation_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
