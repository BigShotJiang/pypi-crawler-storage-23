#!/usr/bin/env python3
"""
Data Quality Monitor

Monitors data quality metrics and identifies data issues.
Uses ReflectionPattern to analyze, validate, and improve data quality.
"""

import asyncio
import json
import csv
import random
from pathlib import Path
from datetime import datetime
from pygeai_orchestration.patterns.reflection import ReflectionPattern
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.text_tools import RegexTool, TemplateRendererTool
from pygeai_orchestration.tools.builtin.utilities import SQLiteTool, ValidationTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def generate_sample_dataset(config):
    """Generate sample dataset with quality issues."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    dataset_size = config["quality_checks"]["dataset_size"]
    
    print(f"Generating dataset with {dataset_size} records...")
    
    with open(config["paths"]["dataset"], 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["id", "name", "email", "phone", "age", "status", "country"])
        
        for i in range(1, dataset_size + 1):
            rand = random.random()
            
            if rand < 0.05:
                email = ""
            elif rand < 0.08:
                email = f"invalid-email-{i}"
            else:
                email = f"user{i}@example.com"
            
            if random.random() < 0.10:
                phone = ""
            elif random.random() < 0.12:
                phone = "123"
            else:
                phone = f"+1555{random.randint(1000000, 9999999)}"
            
            if random.random() < 0.03:
                age = ""
            elif random.random() < 0.05:
                age = str(random.randint(1, 17))
            elif random.random() < 0.07:
                age = str(random.randint(121, 200))
            else:
                age = str(random.randint(18, 80))
            
            if random.random() < 0.04:
                status = ""
            elif random.random() < 0.06:
                status = "unknown"
            else:
                status = random.choice(["active", "inactive", "pending"])
            
            if random.random() < 0.02:
                name = ""
            else:
                name = f"User {i}"
            
            country = random.choice(["USA", "UK", "Canada", "Germany", ""])
            
            writer.writerow([i, name, email, phone, age, status, country])
    
    duplicate_count = int(dataset_size * 0.03)
    
    with open(config["paths"]["dataset"], 'a', newline='') as f:
        writer = csv.writer(f)
        
        for i in range(duplicate_count):
            dup_id = random.randint(1, dataset_size)
            writer.writerow([
                dup_id,
                f"User {dup_id}",
                f"user{dup_id}@example.com",
                f"+1555{random.randint(1000000, 9999999)}",
                random.randint(18, 80),
                random.choice(["active", "inactive", "pending"]),
                random.choice(["USA", "UK", "Canada"])
            ])
    
    print(f"Generated dataset: {config['paths']['dataset']}")


async def main():
    """Execute data quality monitoring workflow."""
    config = load_config()
    
    print("=" * 70)
    print("DATA QUALITY MONITOR")
    print("=" * 70)
    print()
    
    await generate_sample_dataset(config)
    
    csv_tool = CSVProcessorTool()
    regex_tool = RegexTool()
    sqlite_tool = SQLiteTool()
    validation_tool = ValidationTool()
    template_tool = TemplateRendererTool()
    writer_tool = FileWriterTool()
    
    print("\nInitializing quality metrics database...")
    
    await sqlite_tool.execute(
        database=config["paths"]["quality_db"],
        operation="execute",
        query="""
        CREATE TABLE IF NOT EXISTS quality_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            check_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            threshold REAL NOT NULL,
            passed INTEGER NOT NULL,
            issues_count INTEGER,
            checked_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    print("Loading dataset...")
    
    dataset_result = await csv_tool.execute(
        file_path=config["paths"]["dataset"],
        operation="read"
    )
    
    if not dataset_result.success:
        print(f"Error loading dataset: {dataset_result.error}")
        return
    
    records = dataset_result.result
    total_records = len(records)
    
    print(f"Loaded {total_records} records")
    
    print("\nPerforming quality checks...")
    
    all_issues = []
    quality_results = []
    
    print("  1. Completeness Check")
    
    required_fields = [field for field, rules in config["quality_checks"]["fields"].items() if rules.get("required", False)]
    
    missing_counts = {field: 0 for field in required_fields}
    
    for record in records:
        for field in required_fields:
            if not record.get(field) or str(record.get(field)).strip() == "":
                missing_counts[field] += 1
                all_issues.append({
                    "record_id": record.get("id"),
                    "issue_type": "missing_value",
                    "field": field,
                    "severity": "high"
                })
    
    total_missing = sum(missing_counts.values())
    total_required_values = len(required_fields) * total_records
    completeness_score = ((total_required_values - total_missing) / total_required_values * 100) if total_required_values > 0 else 100
    
    completeness_threshold = next((c["threshold"] for c in config["quality_checks"]["checks"] if c["name"] == "completeness"), 95)
    completeness_passed = completeness_score >= completeness_threshold
    
    print(f"    Completeness Score: {completeness_score:.2f}% (Threshold: {completeness_threshold}%)")
    print(f"    Status: {'PASSED' if completeness_passed else 'FAILED'}")
    
    await sqlite_tool.execute(
        database=config["paths"]["quality_db"],
        operation="execute",
        query="INSERT INTO quality_metrics (check_name, metric_value, threshold, passed, issues_count) VALUES (?, ?, ?, ?, ?)",
        params=("completeness", completeness_score, completeness_threshold, 1 if completeness_passed else 0, total_missing)
    )
    
    quality_results.append({
        "check": "completeness",
        "score": round(completeness_score, 2),
        "threshold": completeness_threshold,
        "passed": completeness_passed,
        "issues": total_missing
    })
    
    print("  2. Uniqueness Check")
    
    id_counts = {}
    for record in records:
        record_id = record.get("id")
        id_counts[record_id] = id_counts.get(record_id, 0) + 1
    
    duplicate_count = sum(1 for count in id_counts.values() if count > 1)
    
    for record_id, count in id_counts.items():
        if count > 1:
            all_issues.append({
                "record_id": record_id,
                "issue_type": "duplicate",
                "field": "id",
                "severity": "medium",
                "duplicate_count": count
            })
    
    uniqueness_score = ((total_records - duplicate_count) / total_records * 100) if total_records > 0 else 100
    uniqueness_threshold = next((c["threshold"] for c in config["quality_checks"]["checks"] if c["name"] == "uniqueness"), 99)
    uniqueness_passed = uniqueness_score >= uniqueness_threshold
    
    print(f"    Uniqueness Score: {uniqueness_score:.2f}% (Threshold: {uniqueness_threshold}%)")
    print(f"    Status: {'PASSED' if uniqueness_passed else 'FAILED'}")
    
    await sqlite_tool.execute(
        database=config["paths"]["quality_db"],
        operation="execute",
        query="INSERT INTO quality_metrics (check_name, metric_value, threshold, passed, issues_count) VALUES (?, ?, ?, ?, ?)",
        params=("uniqueness", uniqueness_score, uniqueness_threshold, 1 if uniqueness_passed else 0, duplicate_count)
    )
    
    quality_results.append({
        "check": "uniqueness",
        "score": round(uniqueness_score, 2),
        "threshold": uniqueness_threshold,
        "passed": uniqueness_passed,
        "issues": duplicate_count
    })
    
    print("  3. Validity Check")
    
    invalid_count = 0
    
    for record in records:
        for field, rules in config["quality_checks"]["fields"].items():
            value = str(record.get(field, ""))
            
            if not value or value.strip() == "":
                continue
            
            if "pattern" in rules:
                pattern_result = await regex_tool.execute(
                    pattern=rules["pattern"],
                    text=value,
                    operation="match"
                )
                
                if not (pattern_result.success and pattern_result.result):
                    invalid_count += 1
                    all_issues.append({
                        "record_id": record.get("id"),
                        "issue_type": "invalid_format",
                        "field": field,
                        "value": value[:50],
                        "severity": "high"
                    })
            
            if "min" in rules or "max" in rules:
                try:
                    num_value = float(value)
                    
                    if "min" in rules and num_value < rules["min"]:
                        invalid_count += 1
                        all_issues.append({
                            "record_id": record.get("id"),
                            "issue_type": "out_of_range",
                            "field": field,
                            "value": value,
                            "severity": "medium"
                        })
                    
                    if "max" in rules and num_value > rules["max"]:
                        invalid_count += 1
                        all_issues.append({
                            "record_id": record.get("id"),
                            "issue_type": "out_of_range",
                            "field": field,
                            "value": value,
                            "severity": "medium"
                        })
                except ValueError:
                    invalid_count += 1
                    all_issues.append({
                        "record_id": record.get("id"),
                        "issue_type": "invalid_type",
                        "field": field,
                        "value": value[:50],
                        "severity": "high"
                    })
            
            if "allowed_values" in rules:
                if value not in rules["allowed_values"]:
                    invalid_count += 1
                    all_issues.append({
                        "record_id": record.get("id"),
                        "issue_type": "invalid_value",
                        "field": field,
                        "value": value,
                        "severity": "medium"
                    })
    
    total_validatable = len(config["quality_checks"]["fields"]) * total_records
    validity_score = ((total_validatable - invalid_count) / total_validatable * 100) if total_validatable > 0 else 100
    validity_threshold = next((c["threshold"] for c in config["quality_checks"]["checks"] if c["name"] == "validity"), 98)
    validity_passed = validity_score >= validity_threshold
    
    print(f"    Validity Score: {validity_score:.2f}% (Threshold: {validity_threshold}%)")
    print(f"    Status: {'PASSED' if validity_passed else 'FAILED'}")
    
    await sqlite_tool.execute(
        database=config["paths"]["quality_db"],
        operation="execute",
        query="INSERT INTO quality_metrics (check_name, metric_value, threshold, passed, issues_count) VALUES (?, ?, ?, ?, ?)",
        params=("validity", validity_score, validity_threshold, 1 if validity_passed else 0, invalid_count)
    )
    
    quality_results.append({
        "check": "validity",
        "score": round(validity_score, 2),
        "threshold": validity_threshold,
        "passed": validity_passed,
        "issues": invalid_count
    })
    
    issues_log = {
        "timestamp": datetime.now().isoformat(),
        "total_issues": len(all_issues),
        "issues": all_issues
    }
    
    issues_json = json.dumps(issues_log, indent=2)
    
    await writer_tool.execute(
        path=config["paths"]["issues_log"],
        content=issues_json,
        mode="write"
    )
    
    print(f"\nIssues log saved: {config['paths']['issues_log']}")
    
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>Data Quality Report</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 40px auto; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .metric-card { background: white; padding: 20px; margin: 10px 0; border-left: 5px solid #3498db; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-card.passed { border-left-color: #2ecc71; }
        .metric-card.failed { border-left-color: #e74c3c; }
        .metric-name { font-size: 18px; font-weight: bold; color: #2c3e50; }
        .metric-score { font-size: 32px; font-weight: bold; margin: 10px 0; }
        .metric-score.passed { color: #2ecc71; }
        .metric-score.failed { color: #e74c3c; }
        .metric-details { color: #7f8c8d; font-size: 14px; }
        .progress-bar { background: #ecf0f1; height: 30px; border-radius: 5px; overflow: hidden; margin: 10px 0; }
        .progress-fill { height: 100%; background: #3498db; display: flex; align-items: center; padding: 0 10px; color: white; font-weight: bold; }
        .progress-fill.passed { background: #2ecc71; }
        .progress-fill.failed { background: #e74c3c; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .severity-high { background: #e74c3c; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; }
        .severity-medium { background: #f39c12; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; }
    </style>
</head>
<body>
    <h1>Data Quality Report</h1>
    <p><strong>Generated:</strong> {{ timestamp }}</p>
    <p><strong>Total Records:</strong> {{ total_records }}</p>
    <p><strong>Total Issues:</strong> {{ total_issues }}</p>
    
    <div class="summary">
        <h2>Quality Metrics</h2>
        {% for result in quality_results %}
        <div class="metric-card {{ 'passed' if result.passed else 'failed' }}">
            <div class="metric-name">{{ result.check|upper }}</div>
            <div class="metric-score {{ 'passed' if result.passed else 'failed' }}">{{ result.score }}%</div>
            <div class="progress-bar">
                <div class="progress-fill {{ 'passed' if result.passed else 'failed' }}" style="width: {{ result.score }}%">
                    {{ result.score }}%
                </div>
            </div>
            <div class="metric-details">
                Threshold: {{ result.threshold }}% | Issues Found: {{ result.issues }} | 
                Status: {{ 'PASSED' if result.passed else 'FAILED' }}
            </div>
        </div>
        {% endfor %}
    </div>
    
    {% if top_issues %}
    <h2>Top Issues (Sample)</h2>
    <table>
        <thead>
            <tr>
                <th>Record ID</th>
                <th>Issue Type</th>
                <th>Field</th>
                <th>Severity</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
        {% for issue in top_issues %}
            <tr>
                <td>{{ issue.record_id }}</td>
                <td>{{ issue.issue_type }}</td>
                <td>{{ issue.field }}</td>
                <td><span class="severity-{{ issue.severity }}">{{ issue.severity|upper }}</span></td>
                <td>{{ issue.value if issue.value else '-' }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% endif %}
</body>
</html>"""
    
    html_data = {
        "timestamp": datetime.now().isoformat(),
        "total_records": total_records,
        "total_issues": len(all_issues),
        "quality_results": quality_results,
        "top_issues": all_issues[:20]
    }
    
    html_result = await template_tool.execute(
        template=html_template,
        data=html_data,
        engine="jinja2"
    )
    
    if html_result.success:
        await writer_tool.execute(
            path=config["paths"]["quality_report"],
            content=html_result.result,
            mode="write"
        )
        print(f"Quality report saved: {config['paths']['quality_report']}")
    
    print()
    print("=" * 70)
    print("QUALITY SUMMARY")
    print("=" * 70)
    print(f"Total Records: {total_records}")
    print(f"Total Issues: {len(all_issues)}")
    print()
    print("Quality Checks:")
    for result in quality_results:
        status = "PASSED" if result["passed"] else "FAILED"
        print(f"  {result['check'].upper()}: {result['score']:.2f}% ({status})")
    print()
    print("Output files:")
    print(f"  - Quality Database: {config['paths']['quality_db']}")
    print(f"  - Issues Log: {config['paths']['issues_log']}")
    print(f"  - Quality Report: {config['paths']['quality_report']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
