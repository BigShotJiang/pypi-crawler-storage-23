#!/usr/bin/env python3
"""
Quarterly Sales Report Generator

Generates comprehensive quarterly sales reports from CSV data. Calculates totals,
averages, growth rates, and produces both HTML and PDF outputs using a planning
pattern to orchestrate the workflow.
"""

import asyncio
import json
import csv
import random
from pathlib import Path
from datetime import datetime, timedelta
from pygeai_orchestration.patterns.planning import PlanningPattern, PlanStep
from pygeai_orchestration.tools.builtin.data_tools import CSVProcessorTool
from pygeai_orchestration.tools.builtin.math_tools import MathCalculatorTool
from pygeai_orchestration.tools.builtin.text_tools import TemplateRendererTool
from pygeai_orchestration.tools.builtin.document_generation import PDFGeneratorTool
from pygeai_orchestration.tools.builtin.file_tools import FileWriterTool

DEMO_DIR = Path(__file__).parent
CONFIG_FILE = DEMO_DIR / "config.json"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}\n"
            f"Please copy config.example.json to config.json and update values."
        )
    
    with open(CONFIG_FILE) as f:
        return json.load(f)


async def setup_demo_data(config):
    """Create realistic sales CSV data."""
    work_dir = Path(config["paths"]["work_dir"])
    work_dir.mkdir(parents=True, exist_ok=True)
    
    csv_path = config["paths"]["input_csv"]
    num_records = config["data"]["num_records"]
    departments = config["data"]["departments"]
    
    start_date = datetime(2024, 10, 1)
    
    products = [
        "Enterprise License", "Professional License", "Starter License",
        "Support Contract", "Consulting Hours", "Training Package"
    ]
    
    print(f"Generating {num_records} sales records...")
    
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            "Date", "Department", "Product", "Quantity", "Unit_Price", "Total"
        ])
        
        for i in range(num_records):
            date = start_date + timedelta(days=random.randint(0, 90))
            department = random.choice(departments)
            product = random.choice(products)
            quantity = random.randint(1, 20)
            unit_price = random.randint(500, 10000)
            total = quantity * unit_price
            
            writer.writerow([
                date.strftime("%Y-%m-%d"),
                department,
                product,
                quantity,
                unit_price,
                total
            ])
    
    print(f"Created sales data at {csv_path}")


def create_report_template():
    """Create HTML template for the sales report."""
    return """<!DOCTYPE html>
<html>
<head>
    <title>{{ title }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
        }
        h1 { color: #333; border-bottom: 3px solid #0066cc; padding-bottom: 10px; }
        h2 { color: #0066cc; margin-top: 30px; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th {
            background-color: #0066cc;
            color: white;
            padding: 12px;
            text-align: left;
        }
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover { background-color: #f5f5f5; }
        .summary {
            background-color: #f0f8ff;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .metric {
            display: inline-block;
            margin: 10px 20px 10px 0;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #0066cc;
        }
        .metric-label {
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <h1>{{ title }}</h1>
    <p><strong>Company:</strong> {{ company_name }}</p>
    <p><strong>Period:</strong> {{ quarter }} {{ fiscal_year }}</p>
    <p><strong>Generated:</strong> {{ generated_date }}</p>
    
    <div class="summary">
        <h2>Executive Summary</h2>
        <div class="metric">
            <div class="metric-value">{{ currency }}{{ total_revenue }}</div>
            <div class="metric-label">Total Revenue</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ total_transactions }}</div>
            <div class="metric-label">Transactions</div>
        </div>
        <div class="metric">
            <div class="metric-value">{{ currency }}{{ avg_transaction }}</div>
            <div class="metric-label">Avg Transaction</div>
        </div>
    </div>
    
    <h2>Sales by Department</h2>
    <table>
        <thead>
            <tr>
                <th>Department</th>
                <th>Revenue</th>
                <th>Transactions</th>
                <th>Avg Sale</th>
            </tr>
        </thead>
        <tbody>
        {% for dept in departments %}
            <tr>
                <td>{{ dept.name }}</td>
                <td>{{ currency }}{{ dept.revenue }}</td>
                <td>{{ dept.transactions }}</td>
                <td>{{ currency }}{{ dept.avg_sale }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    
    <h2>Top Products</h2>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Revenue</th>
                <th>Units Sold</th>
            </tr>
        </thead>
        <tbody>
        {% for product in products %}
            <tr>
                <td>{{ product.name }}</td>
                <td>{{ currency }}{{ product.revenue }}</td>
                <td>{{ product.units }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</body>
</html>"""


async def main():
    """Execute the sales report generation workflow."""
    config = load_config()
    
    print("=" * 70)
    print("QUARTERLY SALES REPORT GENERATOR")
    print("=" * 70)
    print()
    
    await setup_demo_data(config)
    
    csv_tool = CSVProcessorTool()
    math_tool = MathCalculatorTool()
    template_tool = TemplateRendererTool()
    pdf_tool = PDFGeneratorTool()
    file_tool = FileWriterTool()
    
    print("\nProcessing sales data...")
    
    csv_result = await csv_tool.execute(
        file_path=config["paths"]["input_csv"],
        operation="read"
    )
    
    if not csv_result.success:
        print(f"Error reading CSV: {csv_result.error}")
        return
    
    sales_data = csv_result.result
    
    total_revenue = sum(float(row["Total"]) for row in sales_data)
    total_transactions = len(sales_data)
    avg_transaction = total_revenue / total_transactions if total_transactions > 0 else 0
    
    dept_stats = {}
    for row in sales_data:
        dept = row["Department"]
        if dept not in dept_stats:
            dept_stats[dept] = {"revenue": 0, "count": 0}
        dept_stats[dept]["revenue"] += float(row["Total"])
        dept_stats[dept]["count"] += 1
    
    departments = [
        {
            "name": dept,
            "revenue": f"{stats['revenue']:,.2f}",
            "transactions": stats["count"],
            "avg_sale": f"{stats['revenue'] / stats['count']:,.2f}"
        }
        for dept, stats in sorted(dept_stats.items(), key=lambda x: x[1]["revenue"], reverse=True)
    ]
    
    product_stats = {}
    for row in sales_data:
        product = row["Product"]
        if product not in product_stats:
            product_stats[product] = {"revenue": 0, "units": 0}
        product_stats[product]["revenue"] += float(row["Total"])
        product_stats[product]["units"] += int(row["Quantity"])
    
    products = [
        {
            "name": product,
            "revenue": f"{stats['revenue']:,.2f}",
            "units": stats["units"]
        }
        for product, stats in sorted(product_stats.items(), key=lambda x: x[1]["revenue"], reverse=True)
    ]
    
    template_data = {
        "title": f"Quarterly Sales Report - {config['data']['quarter']}",
        "company_name": config["data"]["company_name"],
        "quarter": config["data"]["quarter"],
        "fiscal_year": config["data"]["fiscal_year"],
        "generated_date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "currency": config["settings"]["currency"] + " ",
        "total_revenue": f"{total_revenue:,.2f}",
        "total_transactions": total_transactions,
        "avg_transaction": f"{avg_transaction:,.2f}",
        "departments": departments,
        "products": products
    }
    
    print("Rendering HTML report...")
    
    html_result = await template_tool.execute(
        template=create_report_template(),
        data=template_data,
        engine="jinja2"
    )
    
    if not html_result.success:
        print(f"Error rendering template: {html_result.error}")
        return
    
    html_content = html_result.result
    
    html_write_result = await file_tool.execute(
        path=config["paths"]["output_html"],
        content=html_content,
        mode="write"
    )
    
    if html_write_result.success:
        print(f"HTML report saved to: {config['paths']['output_html']}")
    
    print("Generating PDF report...")
    
    pdf_result = await pdf_tool.execute(
        content=html_content,
        output_path=config["paths"]["output_pdf"],
        format="html"
    )
    
    if pdf_result.success:
        print(f"PDF report saved to: {config['paths']['output_pdf']}")
    else:
        print(f"Error generating PDF: {pdf_result.error}")
    
    print()
    print("=" * 70)
    print("REPORT SUMMARY")
    print("=" * 70)
    print(f"Total Revenue: {config['settings']['currency']} {total_revenue:,.2f}")
    print(f"Total Transactions: {total_transactions}")
    print(f"Average Transaction: {config['settings']['currency']} {avg_transaction:,.2f}")
    print(f"\nTop Department: {departments[0]['name']} ({config['settings']['currency']} {departments[0]['revenue']})")
    print(f"Top Product: {products[0]['name']} ({config['settings']['currency']} {products[0]['revenue']})")
    print()
    print(f"Output files:")
    print(f"  - {config['paths']['output_html']}")
    print(f"  - {config['paths']['output_pdf']}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
