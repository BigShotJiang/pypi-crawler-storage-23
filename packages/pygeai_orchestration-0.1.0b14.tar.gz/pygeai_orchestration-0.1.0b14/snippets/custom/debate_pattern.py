"""
Debate Pattern - Custom orchestration pattern for adversarial reasoning.

This pattern creates a debate between two perspectives to explore a topic
thoroughly. It alternates between supporting and opposing viewpoints before
synthesizing a balanced conclusion.
"""

import asyncio
import logging
from typing import Any, Dict, Optional

from pygeai_orchestration.core.base import (
    BasePattern,
    PatternConfig,
    PatternResult,
    PatternType,
)
from pygeai_orchestration import GEAIAgent, AgentConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DebatePattern(BasePattern):
    """
    Custom pattern implementing adversarial debate between two viewpoints.

    The pattern alternates between supporting and opposing arguments,
    then synthesizes a balanced conclusion from both perspectives.
    """

    def __init__(self, agent, config: PatternConfig):
        """
        Initialize the debate pattern.

        Args:
            agent: The agent to use for generating arguments
            config: Pattern configuration
        """
        super().__init__(config)
        self.agent = agent
        self._arguments_for = []
        self._arguments_against = []

    async def execute(
        self, task: str, context: Optional[Dict[str, Any]] = None
    ) -> PatternResult:
        """
        Execute the debate pattern.

        Args:
            task: The topic or question to debate
            context: Optional additional context

        Returns:
            PatternResult with the synthesized conclusion
        """
        self.reset()
        logger.info(f"Starting debate on: {task}")

        try:
            # Generate arguments for and against
            for i in range(self.config.max_iterations):
                self.increment_iteration()

                state = {
                    "task": task,
                    "iteration": self.current_iteration,
                    "arguments_for": self._arguments_for,
                    "arguments_against": self._arguments_against,
                }

                step_result = await self.step(state)

                if step_result.get("for_argument"):
                    self._arguments_for.append(step_result["for_argument"])

                if step_result.get("against_argument"):
                    self._arguments_against.append(step_result["against_argument"])

            # Synthesize final conclusion
            synthesis_prompt = f"""
Given this debate on: {task}

Arguments FOR:
{chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_for))}

Arguments AGAINST:
{chr(10).join(f"{i+1}. {arg}" for i, arg in enumerate(self._arguments_against))}

Provide a balanced, nuanced conclusion that considers both perspectives.
"""

            conclusion = await self.agent.generate(synthesis_prompt)

            return PatternResult(
                success=True,
                result=conclusion,
                iterations=self.current_iteration,
                metadata={
                    "arguments_for": self._arguments_for,
                    "arguments_against": self._arguments_against,
                    "total_arguments": len(self._arguments_for)
                    + len(self._arguments_against),
                },
            )

        except Exception as e:
            logger.error(f"Debate pattern failed: {e}")
            return PatternResult(
                success=False, error=str(e), iterations=self.current_iteration
            )

    async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one debate iteration (generate both for and against arguments).

        Args:
            state: Current debate state

        Returns:
            Dictionary with generated arguments
        """
        task = state["task"]
        iteration = state["iteration"]

        # Generate argument FOR
        for_prompt = f"""
Topic: {task}

Previous arguments in favor: {state['arguments_for']}

Generate a new, distinct argument SUPPORTING this topic.
Focus on a different aspect than previous arguments.
"""

        for_argument = await self.agent.generate(for_prompt)
        logger.info(f"Iteration {iteration} - FOR: {for_argument[:100]}...")

        # Generate argument AGAINST
        against_prompt = f"""
Topic: {task}

Previous arguments against: {state['arguments_against']}

Generate a new, distinct argument OPPOSING this topic.
Focus on a different aspect than previous arguments.
"""

        against_argument = await self.agent.generate(against_prompt)
        logger.info(f"Iteration {iteration} - AGAINST: {against_argument[:100]}...")

        return {"for_argument": for_argument, "against_argument": against_argument}

    def reset(self) -> None:
        """Reset debate state for new execution."""
        super().reset()
        self._arguments_for = []
        self._arguments_against = []


async def main():
    """Example usage of the Debate pattern."""
    # Create agent
    agent_config = AgentConfig(
        name="debater", model="openai/gpt-4o-mini", temperature=0.8
    )
    agent = GEAIAgent(config=agent_config)

    # Create debate pattern
    pattern_config = PatternConfig(
        name="debate-example",
        pattern_type=PatternType.CUSTOM,
        max_iterations=3,  # 3 rounds of debate
    )

    pattern = DebatePattern(agent=agent, config=pattern_config)

    # Execute debate
    result = await pattern.execute(
        "Remote work should be the default for knowledge workers"
    )

    print(f"\n{'=' * 80}")
    print("DEBATE CONCLUSION")
    print(f"{'=' * 80}\n")
    print(result.result)
    print(f"\n{'=' * 80}")
    print(f"Total arguments generated: {result.metadata['total_arguments']}")
    print(f"Arguments for: {len(result.metadata['arguments_for'])}")
    print(f"Arguments against: {len(result.metadata['arguments_against'])}")
    print(f"{'=' * 80}\n")


if __name__ == "__main__":
    asyncio.run(main())
