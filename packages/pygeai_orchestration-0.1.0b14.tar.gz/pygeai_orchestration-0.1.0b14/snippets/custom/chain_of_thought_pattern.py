"""
Chain of Thought Pattern - Custom orchestration pattern for step-by-step reasoning.

This pattern breaks down complex problems into smaller reasoning steps,
explicitly tracking the thought process before arriving at a conclusion.
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional

from pygeai_orchestration.core.base import (
    BasePattern,
    PatternConfig,
    PatternResult,
    PatternType,
)
from pygeai_orchestration import GEAIAgent, AgentConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ChainOfThoughtPattern(BasePattern):
    """
    Custom pattern implementing explicit chain-of-thought reasoning.

    This pattern guides the agent to break down complex problems into
    sequential reasoning steps, making the thought process transparent
    and improving accuracy on complex tasks.
    """

    def __init__(self, agent, config: PatternConfig):
        """
        Initialize the chain-of-thought pattern.

        Args:
            agent: The agent to use for reasoning
            config: Pattern configuration
        """
        super().__init__(config)
        self.agent = agent
        self._reasoning_steps: List[str] = []

    async def execute(
        self, task: str, context: Optional[Dict[str, Any]] = None
    ) -> PatternResult:
        """
        Execute chain-of-thought reasoning.

        Args:
            task: The problem to solve
            context: Optional additional context

        Returns:
            PatternResult with final answer and reasoning steps
        """
        self.reset()
        logger.info(f"Starting chain-of-thought for: {task}")

        try:
            # Initial breakdown: ask agent to identify reasoning steps
            breakdown_prompt = f"""
Problem: {task}

Before solving this, break it down into clear reasoning steps.
List 3-5 specific steps needed to solve this problem.
Format: Step 1: ..., Step 2: ..., etc.
"""

            breakdown = await self.agent.generate(breakdown_prompt)
            logger.info(f"Problem breakdown:\n{breakdown}")

            # Execute each reasoning step
            current_context = f"Problem: {task}\n\nPlanned steps:\n{breakdown}\n\n"

            while self.current_iteration < self.config.max_iterations:
                self.increment_iteration()

                state = {
                    "task": task,
                    "iteration": self.current_iteration,
                    "context": current_context,
                    "steps_completed": self._reasoning_steps,
                }

                step_result = await self.step(state)

                if step_result.get("reasoning"):
                    self._reasoning_steps.append(step_result["reasoning"])
                    current_context += (
                        f"\nStep {self.current_iteration}: {step_result['reasoning']}\n"
                    )

                if step_result.get("is_final"):
                    # Generate final answer based on reasoning chain
                    final_prompt = f"""
{current_context}

Based on the reasoning steps above, provide the final answer to: {task}
"""
                    final_answer = await self.agent.generate(final_prompt)

                    return PatternResult(
                        success=True,
                        result=final_answer,
                        iterations=self.current_iteration,
                        metadata={
                            "reasoning_steps": self._reasoning_steps,
                            "breakdown": breakdown,
                            "total_steps": len(self._reasoning_steps),
                        },
                    )

            # Max iterations reached
            summary_prompt = f"""
{current_context}

Maximum steps reached. Provide the best answer you can based on the reasoning so far for: {task}
"""
            final_answer = await self.agent.generate(summary_prompt)

            return PatternResult(
                success=True,
                result=final_answer,
                iterations=self.current_iteration,
                metadata={
                    "reasoning_steps": self._reasoning_steps,
                    "breakdown": breakdown,
                    "total_steps": len(self._reasoning_steps),
                },
            )

        except Exception as e:
            logger.error(f"Chain-of-thought pattern failed: {e}")
            return PatternResult(
                success=False, error=str(e), iterations=self.current_iteration
            )

    async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one reasoning step.

        Args:
            state: Current reasoning state

        Returns:
            Dictionary with reasoning and completion status
        """
        iteration = state["iteration"]
        context = state["context"]

        reasoning_prompt = f"""
{context}

Current step: {iteration}

Provide the reasoning for this step. Be specific and show your work.
After your reasoning, indicate if this is the final step needed (yes/no).

Format:
Reasoning: [your reasoning here]
Final step: [yes/no]
"""

        response = await self.agent.generate(reasoning_prompt)
        logger.info(f"Step {iteration} reasoning:\n{response[:200]}...")

        # Simple heuristic: check if agent says this is final
        is_final = "final step: yes" in response.lower() or iteration >= 4

        return {"reasoning": response, "is_final": is_final}

    def reset(self) -> None:
        """Reset reasoning state for new execution."""
        super().reset()
        self._reasoning_steps = []


async def main():
    """Example usage of the Chain-of-Thought pattern."""
    # Create agent
    agent_config = AgentConfig(
        name="thinker", model="openai/gpt-4o-mini", temperature=0.5
    )
    agent = GEAIAgent(config=agent_config)

    # Create chain-of-thought pattern
    pattern_config = PatternConfig(
        name="cot-example",
        pattern_type=PatternType.CUSTOM,
        max_iterations=5,
    )

    pattern = ChainOfThoughtPattern(agent=agent, config=pattern_config)

    # Execute on a complex problem
    result = await pattern.execute(
        "A farmer has 100 acres and wants to plant corn and wheat. "
        "Corn requires 2 hours of labor per acre and yields $500 profit per acre. "
        "Wheat requires 1 hour of labor per acre and yields $300 profit per acre. "
        "The farmer has 150 hours of labor available. "
        "How many acres of each should be planted to maximize profit?"
    )

    print(f"\n{'=' * 80}")
    print("CHAIN OF THOUGHT REASONING")
    print(f"{'=' * 80}\n")

    print("Reasoning Steps:")
    for i, step in enumerate(result.metadata["reasoning_steps"], 1):
        print(f"\n--- Step {i} ---")
        print(step[:300] + "..." if len(step) > 300 else step)

    print(f"\n{'=' * 80}")
    print("FINAL ANSWER")
    print(f"{'=' * 80}\n")
    print(result.result)
    print(f"\n{'=' * 80}")
    print(f"Total reasoning steps: {result.metadata['total_steps']}")
    print(f"Success: {result.success}")
    print(f"{'=' * 80}\n")


if __name__ == "__main__":
    asyncio.run(main())
