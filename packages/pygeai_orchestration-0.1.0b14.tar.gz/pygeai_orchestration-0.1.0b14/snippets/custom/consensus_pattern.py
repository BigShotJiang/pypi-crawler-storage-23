"""
Consensus Pattern - Custom orchestration pattern for multi-perspective consensus.

This pattern generates multiple independent perspectives on a task, then
synthesizes them into a consensus answer that captures the best insights.
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional

from pygeai_orchestration.core.base import (
    BasePattern,
    PatternConfig,
    PatternResult,
    PatternType,
)
from pygeai_orchestration import GEAIAgent, AgentConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ConsensusPattern(BasePattern):
    """
    Custom pattern implementing consensus through multiple independent perspectives.

    This pattern generates multiple independent responses to a task with different
    "perspectives" or approaches, then synthesizes them into a single consensus
    answer that combines the best insights from all perspectives.
    """

    def __init__(
        self,
        agent,
        config: PatternConfig,
        perspectives: Optional[List[str]] = None,
    ):
        """
        Initialize the consensus pattern.

        Args:
            agent: The agent to use for generation
            config: Pattern configuration (max_iterations = number of perspectives)
            perspectives: List of perspective descriptions. If None, uses defaults.
        """
        super().__init__(config)
        self.agent = agent
        self.perspectives = perspectives or [
            "analytical and data-driven",
            "creative and innovative",
            "practical and pragmatic",
            "critical and skeptical",
        ]
        self._responses: List[Dict[str, str]] = []

    async def execute(
        self, task: str, context: Optional[Dict[str, Any]] = None
    ) -> PatternResult:
        """
        Execute consensus pattern by gathering multiple perspectives.

        Args:
            task: The task or question to answer
            context: Optional additional context

        Returns:
            PatternResult with consensus answer and all perspectives
        """
        self.reset()
        logger.info(f"Starting consensus pattern for: {task}")
        logger.info(f"Gathering {len(self.perspectives)} perspectives")

        try:
            # Gather responses from each perspective
            for i, perspective in enumerate(self.perspectives):
                self.increment_iteration()

                state = {
                    "task": task,
                    "perspective": perspective,
                    "iteration": self.current_iteration,
                }

                step_result = await self.step(state)
                self._responses.append(
                    {
                        "perspective": perspective,
                        "response": step_result["response"],
                    }
                )

            # Synthesize consensus
            consensus = await self._synthesize_consensus(task)

            return PatternResult(
                success=True,
                result=consensus,
                iterations=self.current_iteration,
                metadata={
                    "perspectives": self._responses,
                    "num_perspectives": len(self._responses),
                },
            )

        except Exception as e:
            logger.error(f"Consensus pattern failed: {e}")
            return PatternResult(
                success=False, error=str(e), iterations=self.current_iteration
            )

    async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate response from one perspective.

        Args:
            state: Current state with perspective information

        Returns:
            Dictionary with perspective response
        """
        task = state["task"]
        perspective = state["perspective"]
        iteration = state["iteration"]

        perspective_prompt = f"""
You are approaching this task from a {perspective} perspective.

Task: {task}

Provide your response focusing on insights that a {perspective} thinker would emphasize.
Be thorough but concise.
"""

        response = await self.agent.generate(perspective_prompt)
        logger.info(
            f"Perspective {iteration} ({perspective}): {response[:100]}..."
        )

        return {"response": response}

    async def _synthesize_consensus(self, task: str) -> str:
        """
        Synthesize all perspectives into a consensus answer.

        Args:
            task: Original task

        Returns:
            Consensus answer combining all perspectives
        """
        # Build synthesis prompt with all perspectives
        perspectives_text = "\n\n".join(
            f"**{i+1}. {resp['perspective'].upper()} PERSPECTIVE:**\n{resp['response']}"
            for i, resp in enumerate(self._responses)
        )

        synthesis_prompt = f"""
Task: {task}

Multiple independent perspectives have been gathered:

{perspectives_text}

Synthesize these perspectives into a single, coherent consensus answer that:
1. Captures the best insights from each perspective
2. Resolves any contradictions or tensions
3. Provides a balanced, comprehensive response
4. Highlights where perspectives align and where they diverge

Provide the consensus answer:
"""

        consensus = await self.agent.generate(synthesis_prompt)
        logger.info("Consensus synthesized from all perspectives")

        return consensus

    def reset(self) -> None:
        """Reset consensus state for new execution."""
        super().reset()
        self._responses = []


async def main():
    """Example usage of the Consensus pattern."""
    # Create agent
    agent_config = AgentConfig(
        name="consensus-agent",
        model="openai/gpt-4o-mini",
        temperature=0.8,  # Higher temperature for diverse perspectives
    )
    agent = GEAIAgent(config=agent_config)

    # Create consensus pattern with custom perspectives
    pattern_config = PatternConfig(
        name="consensus-example",
        pattern_type=PatternType.CUSTOM,
        max_iterations=4,  # One per perspective
    )

    custom_perspectives = [
        "technical and engineering-focused",
        "business and ROI-focused",
        "user experience and human-centered",
        "security and risk-focused",
    ]

    pattern = ConsensusPattern(
        agent=agent, config=pattern_config, perspectives=custom_perspectives
    )

    # Execute consensus
    result = await pattern.execute(
        "Should our company adopt a microservices architecture for our new product?"
    )

    print(f"\n{'=' * 80}")
    print("INDIVIDUAL PERSPECTIVES")
    print(f"{'=' * 80}\n")

    for i, perspective_data in enumerate(result.metadata["perspectives"], 1):
        print(f"\n--- Perspective {i}: {perspective_data['perspective'].upper()} ---\n")
        print(perspective_data["response"])
        print()

    print(f"{'=' * 80}")
    print("CONSENSUS ANSWER")
    print(f"{'=' * 80}\n")
    print(result.result)

    print(f"\n{'=' * 80}")
    print(f"Perspectives gathered: {result.metadata['num_perspectives']}")
    print(f"Success: {result.success}")
    print(f"{'=' * 80}\n")


if __name__ == "__main__":
    asyncio.run(main())
