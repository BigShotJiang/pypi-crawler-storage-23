"""
Iterative Refinement Pattern - Custom orchestration pattern with quality scoring.

This pattern generates outputs and scores their quality, continuing to refine
until a quality threshold is met or maximum iterations reached.
"""

import asyncio
import logging
import re
from typing import Any, Dict, Optional

from pygeai_orchestration.core.base import (
    BasePattern,
    PatternConfig,
    PatternResult,
    PatternType,
)
from pygeai_orchestration import GEAIAgent, AgentConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IterativeRefinementPattern(BasePattern):
    """
    Custom pattern implementing quality-based iterative refinement.

    This pattern generates outputs, scores them on quality metrics,
    and iteratively improves until quality threshold is met.
    """

    def __init__(
        self,
        agent,
        config: PatternConfig,
        quality_threshold: float = 8.0,
        scoring_criteria: Optional[str] = None,
    ):
        """
        Initialize the iterative refinement pattern.

        Args:
            agent: The agent to use for generation
            config: Pattern configuration
            quality_threshold: Minimum quality score (1-10) to accept
            scoring_criteria: Custom criteria for quality scoring
        """
        super().__init__(config)
        self.agent = agent
        self.quality_threshold = quality_threshold
        self.scoring_criteria = scoring_criteria or (
            "clarity, accuracy, completeness, and usefulness"
        )
        self._quality_history = []

    async def execute(
        self, task: str, context: Optional[Dict[str, Any]] = None
    ) -> PatternResult:
        """
        Execute iterative refinement until quality threshold met.

        Args:
            task: The task to complete
            context: Optional additional context

        Returns:
            PatternResult with refined output meeting quality threshold
        """
        self.reset()
        logger.info(f"Starting iterative refinement for: {task}")
        logger.info(f"Quality threshold: {self.quality_threshold}/10")

        try:
            current_output = None
            current_score = 0.0

            while self.current_iteration < self.config.max_iterations:
                self.increment_iteration()

                state = {
                    "task": task,
                    "iteration": self.current_iteration,
                    "current_output": current_output,
                    "current_score": current_score,
                    "quality_history": self._quality_history,
                }

                step_result = await self.step(state)

                current_output = step_result["output"]
                current_score = step_result["score"]

                self._quality_history.append(
                    {"iteration": self.current_iteration, "score": current_score}
                )

                logger.info(
                    f"Iteration {self.current_iteration}: Quality score = {current_score}/10"
                )

                # Check if quality threshold met
                if current_score >= self.quality_threshold:
                    logger.info(
                        f"Quality threshold met! Score: {current_score}/{self.quality_threshold}"
                    )
                    return PatternResult(
                        success=True,
                        result=current_output,
                        iterations=self.current_iteration,
                        metadata={
                            "final_score": current_score,
                            "quality_history": self._quality_history,
                            "threshold_met": True,
                        },
                    )

            # Max iterations reached without meeting threshold
            logger.warning(
                f"Max iterations reached. Best score: {current_score}/{self.quality_threshold}"
            )
            return PatternResult(
                success=True,
                result=current_output,
                iterations=self.current_iteration,
                metadata={
                    "final_score": current_score,
                    "quality_history": self._quality_history,
                    "threshold_met": False,
                },
            )

        except Exception as e:
            logger.error(f"Iterative refinement pattern failed: {e}")
            return PatternResult(
                success=False, error=str(e), iterations=self.current_iteration
            )

    async def step(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one refinement iteration with quality scoring.

        Args:
            state: Current refinement state

        Returns:
            Dictionary with output and quality score
        """
        iteration = state["iteration"]
        task = state["task"]
        current_output = state["current_output"]
        current_score = state["current_score"]

        # Generate or refine output
        if iteration == 1:
            # Initial generation
            generation_prompt = f"""
Task: {task}

Generate a high-quality response. Focus on {self.scoring_criteria}.
"""
            output = await self.agent.generate(generation_prompt)
        else:
            # Refinement based on score feedback
            refinement_prompt = f"""
Task: {task}

Previous attempt (scored {current_score}/10):
{current_output}

Improve this response to score higher. Focus on {self.scoring_criteria}.
Address any weaknesses and enhance quality.
"""
            output = await self.agent.generate(refinement_prompt)

        # Score the output
        scoring_prompt = f"""
Evaluate this response on a scale of 1-10 based on {self.scoring_criteria}.

Task: {task}

Response:
{output}

Provide:
1. Brief analysis of strengths and weaknesses
2. Overall score (1-10)

Format your response exactly as:
Analysis: [your analysis]
Score: [number between 1-10]
"""

        evaluation = await self.agent.generate(scoring_prompt)

        # Extract score from evaluation
        score = self._extract_score(evaluation)

        logger.debug(f"Evaluation:\n{evaluation}")

        return {"output": output, "score": score, "evaluation": evaluation}

    def _extract_score(self, evaluation: str) -> float:
        """
        Extract numeric score from evaluation text.

        Args:
            evaluation: Evaluation text containing score

        Returns:
            Extracted score as float, defaults to 5.0 if not found
        """
        # Try to find "Score: X" or "Score: X/10" pattern
        patterns = [
            r"Score:\s*(\d+\.?\d*)",
            r"score:\s*(\d+\.?\d*)",
            r"(\d+\.?\d*)\s*/\s*10",
            r"(\d+\.?\d*)\s*out of 10",
        ]

        for pattern in patterns:
            match = re.search(pattern, evaluation)
            if match:
                try:
                    score = float(match.group(1))
                    return max(1.0, min(10.0, score))  # Clamp to 1-10
                except ValueError:
                    continue

        logger.warning("Could not extract score from evaluation, using default 5.0")
        return 5.0

    def reset(self) -> None:
        """Reset refinement state for new execution."""
        super().reset()
        self._quality_history = []


async def main():
    """Example usage of the Iterative Refinement pattern."""
    # Create agent
    agent_config = AgentConfig(
        name="refiner", model="openai/gpt-4o-mini", temperature=0.7
    )
    agent = GEAIAgent(config=agent_config)

    # Create refinement pattern
    pattern_config = PatternConfig(
        name="refinement-example",
        pattern_type=PatternType.CUSTOM,
        max_iterations=5,
    )

    pattern = IterativeRefinementPattern(
        agent=agent,
        config=pattern_config,
        quality_threshold=8.5,
        scoring_criteria="clarity, technical accuracy, practical examples, and completeness",
    )

    # Execute refinement
    result = await pattern.execute(
        "Explain how microservices architecture differs from monolithic architecture, "
        "including pros, cons, and when to use each approach."
    )

    print(f"\n{'=' * 80}")
    print("ITERATIVE REFINEMENT RESULTS")
    print(f"{'=' * 80}\n")

    print("Quality Progression:")
    for entry in result.metadata["quality_history"]:
        print(f"  Iteration {entry['iteration']}: {entry['score']}/10")

    print(f"\n{'=' * 80}")
    print("FINAL OUTPUT")
    print(f"{'=' * 80}\n")
    print(result.result)

    print(f"\n{'=' * 80}")
    print(f"Final Score: {result.metadata['final_score']}/10")
    print(f"Threshold Met: {result.metadata['threshold_met']}")
    print(f"Total Iterations: {result.iterations}")
    print(f"{'=' * 80}\n")


if __name__ == "__main__":
    asyncio.run(main())
