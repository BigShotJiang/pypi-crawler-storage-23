"""
Example usage of data processing tools.

This snippet demonstrates how to use the built-in data tools:
- JSONParserTool: Parse and query JSON data
- YAMLParserTool: Parse YAML files
- CSVProcessorTool: Read, write, and manipulate CSV data
- XMLParserTool: Parse and query XML documents
- DataFrameTool: Process tabular data
"""

import asyncio
from pygeai_orchestration.tools.builtin.data_tools import (
    JSONParserTool,
    YAMLParserTool,
    CSVProcessorTool,
    XMLParserTool,
    DataFrameTool
)


async def example_json_parser():
    """Example: Parse and query JSON data."""
    print("=" * 60)
    print("JSONParserTool Example")
    print("=" * 60)
    
    tool = JSONParserTool()
    
    json_data = '''
    {
        "user": {
            "name": "Alice",
            "age": 30,
            "skills": ["Python", "JavaScript", "Go"]
        },
        "projects": [
            {"name": "Project A", "status": "active"},
            {"name": "Project B", "status": "completed"}
        ]
    }
    '''
    
    print("Example 1: Parse JSON")
    result = await tool.execute(json_string=json_data)
    if result.success:
        print(f"  ✓ Parsed successfully")
        print(f"  User: {result.result['user']['name']}")
    
    print("\nExample 2: Query nested path")
    result = await tool.execute(
        json_string=json_data,
        query="user.skills"
    )
    if result.success:
        print(f"  ✓ Skills: {result.result}")
    
    print("\nExample 3: Query array element")
    result = await tool.execute(
        json_string=json_data,
        query="projects.0.name"
    )
    if result.success:
        print(f"  ✓ First project: {result.result}")
    print()


async def example_yaml_parser():
    """Example: Parse YAML configuration."""
    print("=" * 60)
    print("YAMLParserTool Example")
    print("=" * 60)
    
    tool = YAMLParserTool()
    
    yaml_config = """
app:
  name: MyApp
  version: 1.2.0
  debug: true
database:
  host: localhost
  port: 5432
  name: mydb
"""
    
    result = await tool.execute(yaml_string=yaml_config)
    
    if result.success:
        print(f"  ✓ Parsed YAML configuration")
        print(f"  App: {result.result.get('app', {}).get('name')}")
        print(f"  Version: {result.result.get('app', {}).get('version')}")
        print(f"  Database: {result.result.get('database', {}).get('host')}")
        print(f"  Keys found: {result.metadata.get('keys')}")
    print()


async def example_csv_processor():
    """Example: Process CSV data."""
    print("=" * 60)
    print("CSVProcessorTool Example")
    print("=" * 60)
    
    tool = CSVProcessorTool()
    
    csv_data = """name,age,city
Alice,30,NYC
Bob,25,LA
Charlie,35,SF
David,28,NYC"""
    
    print("Example 1: Parse CSV string")
    result = await tool.execute(
        operation="parse",
        csv_string=csv_data,
        has_header=True
    )
    
    if result.success:
        print(f"  ✓ Parsed {result.metadata['rows']} rows")
        for row in result.result[:2]:
            print(f"    {row['name']}, {row['age']}, {row['city']}")
    
    print("\nExample 2: Write CSV to file")
    data_to_write = [
        {"name": "Eve", "age": 32, "city": "Boston"},
        {"name": "Frank", "age": 29, "city": "Seattle"}
    ]
    
    result = await tool.execute(
        operation="write",
        file_path="/tmp/example_output.csv",
        data=data_to_write,
        has_header=True
    )
    
    if result.success:
        print(f"  ✓ {result.result}")
    print()


async def example_xml_parser():
    """Example: Parse and query XML."""
    print("=" * 60)
    print("XMLParserTool Example")
    print("=" * 60)
    
    tool = XMLParserTool()
    
    xml_data = '''<?xml version="1.0"?>
<catalog>
    <book id="1" category="fiction">
        <title>The Great Novel</title>
        <author>Jane Doe</author>
        <price>29.99</price>
    </book>
    <book id="2" category="tech">
        <title>Python Guide</title>
        <author>John Smith</author>
        <price>39.99</price>
    </book>
</catalog>'''
    
    print("Example 1: Parse XML structure")
    result = await tool.execute(xml_string=xml_data)
    if result.success:
        print(f"  ✓ Root tag: {result.result['tag']}")
        print(f"  Children: {len(result.result.get('children', []))}")
    
    print("\nExample 2: Query specific element")
    result = await tool.execute(
        xml_string=xml_data,
        query="book"
    )
    if result.success:
        print(f"  ✓ First book title: {result.result['children'][0]['text']}")
        print(f"    Category: {result.result['attributes']['category']}")
    
    print("\nExample 3: Find all books")
    result = await tool.execute(
        xml_string=xml_data,
        query="book",
        find_all=True
    )
    if result.success:
        print(f"  ✓ Found {len(result.result)} books")
        for i, book in enumerate(result.result, 1):
            title = book['children'][0]['text']
            print(f"    Book {i}: {title}")
    print()


async def example_dataframe():
    """Example: Process tabular data."""
    print("=" * 60)
    print("DataFrameTool Example")
    print("=" * 60)
    
    tool = DataFrameTool()
    
    data = [
        {"name": "Alice", "age": 30, "city": "NYC", "salary": 75000},
        {"name": "Bob", "age": 25, "city": "LA", "salary": 65000},
        {"name": "Charlie", "age": 35, "city": "SF", "salary": 95000},
        {"name": "David", "age": 28, "city": "NYC", "salary": 70000},
        {"name": "Eve", "age": 32, "city": "SF", "salary": 85000}
    ]
    
    print("Example 1: Filter data")
    result = await tool.execute(
        data=data,
        operation="filter",
        column="age",
        condition="gt",
        value=28
    )
    if result.success:
        print(f"  ✓ Found {len(result.result)} people over 28")
        for row in result.result:
            print(f"    {row['name']}: {row['age']} years")
    
    print("\nExample 2: Sort by salary")
    result = await tool.execute(
        data=data,
        operation="sort",
        column="salary",
        ascending=False
    )
    if result.success:
        print(f"  ✓ Sorted by salary (descending)")
        for row in result.result[:3]:
            print(f"    {row['name']}: ${row['salary']:,}")
    
    print("\nExample 3: Group by city")
    result = await tool.execute(
        data=data,
        operation="group",
        column="city"
    )
    if result.success:
        print(f"  ✓ Grouped into {result.metadata['groups']} cities")
        for city, people in result.result.items():
            print(f"    {city}: {len(people)} people")
    
    print("\nExample 4: Calculate statistics")
    result = await tool.execute(
        data=data,
        operation="stats",
        column="salary"
    )
    if result.success:
        print(f"  ✓ Salary statistics:")
        print(f"    Count: {result.result['count']}")
        print(f"    Average: ${result.result['mean']:,.2f}")
        print(f"    Min: ${result.result['min']:,}")
        print(f"    Max: ${result.result['max']:,}")
    
    print("\nExample 5: Select specific columns")
    result = await tool.execute(
        data=data,
        operation="select",
        columns=["name", "city"]
    )
    if result.success:
        print(f"  ✓ Selected columns: {result.metadata['selected_columns']}")
        for row in result.result[:3]:
            print(f"    {row}")
    print()


async def example_workflow():
    """Example: Complete data processing workflow."""
    print("=" * 60)
    print("Complete Data Processing Workflow")
    print("=" * 60)
    
    csv_tool = CSVProcessorTool()
    df_tool = DataFrameTool()
    json_tool = JSONParserTool()
    
    print("Step 1: Parse CSV data")
    csv_data = """product,category,price,stock
Laptop,Electronics,999.99,15
Mouse,Electronics,29.99,50
Desk,Furniture,299.99,10
Chair,Furniture,199.99,25
Keyboard,Electronics,79.99,30"""
    
    csv_result = await csv_tool.execute(
        operation="parse",
        csv_string=csv_data,
        has_header=True
    )
    
    if csv_result.success:
        print(f"  ✓ Loaded {len(csv_result.result)} products")
        
        print("\nStep 2: Filter electronics")
        filtered = await df_tool.execute(
            data=csv_result.result,
            operation="filter",
            column="category",
            condition="eq",
            value="Electronics"
        )
        
        if filtered.success:
            print(f"  ✓ Found {len(filtered.result)} electronics")
            
            print("\nStep 3: Calculate inventory value")
            total_value = 0
            for item in filtered.result:
                price = float(item['price'])
                stock = int(item['stock'])
                value = price * stock
                total_value += value
                print(f"    {item['product']}: ${value:,.2f}")
            
            print(f"\n  Total Electronics Value: ${total_value:,.2f}")
    print()


async def main():
    """Run all examples."""
    print("\n" + "=" * 60)
    print("Data Processing Tools - Examples")
    print("=" * 60 + "\n")
    
    await example_json_parser()
    await example_yaml_parser()
    await example_csv_processor()
    await example_xml_parser()
    await example_dataframe()
    await example_workflow()
    
    print("=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
