"""
Example usage of GEAI integration tools.

This snippet demonstrates how to use the GEAI-powered tools:
- OmniParserTool: Document parsing with OCR
- FileUploadTool: Upload files to cloud storage
- FileDownloadTool: Download files from URLs
- EmbeddingsGeneratorTool: Generate embeddings for semantic search
- RerankTool: Rerank search results for relevance
"""

import asyncio
import tempfile
from pathlib import Path
from pygeai_orchestration.tools.builtin.geai_tools import (
    OmniParserTool,
    FileUploadTool,
    FileDownloadTool,
    EmbeddingsGeneratorTool,
    RerankTool
)


async def example_omni_parser():
    """Example: OCR and document parsing with OmniParser."""
    print("=" * 60)
    print("EXAMPLE 1: OmniParser - Document Parsing")
    print("=" * 60)
    
    tool = OmniParserTool()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write("Sample document content for parsing.\nMultiple lines of text.")
        temp_file = f.name
    
    try:
        result = await tool.execute(
            file_path=temp_file,
            mode="text"
        )
        
        print(f"✓ Success: {result.success}")
        print(f"✓ File: {result.result['file_name']}")
        print(f"✓ Content: {result.result['content']}")
        print(f"✓ Time: {result.execution_time:.3f}s\n")
    finally:
        Path(temp_file).unlink()


async def example_file_upload():
    """Example: File upload to cloud storage."""
    print("=" * 60)
    print("EXAMPLE 2: FileUpload - Upload to Cloud")
    print("=" * 60)
    
    tool = FileUploadTool()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write("Data to upload")
        temp_file = f.name
    
    try:
        result = await tool.execute(
            file_path=temp_file,
            destination="cloud_storage/documents",
            metadata={"author": "demo", "version": "1.0"}
        )
        
        print(f"✓ Success: {result.success}")
        print(f"✓ File: {result.result['file_name']}")
        print(f"✓ Size: {result.result['file_size']} bytes")
        print(f"✓ Destination: {result.result['destination']}")
        print(f"✓ Status: {result.result.get('status', 'N/A')}")
        print(f"✓ Time: {result.execution_time:.3f}s\n")
    finally:
        Path(temp_file).unlink()


async def example_embeddings():
    """Example: Generate embeddings for semantic search."""
    print("=" * 60)
    print("EXAMPLE 3: Embeddings - Semantic Search")
    print("=" * 60)
    
    tool = EmbeddingsGeneratorTool()
    
    texts = [
        "Python is a high-level programming language",
        "Machine learning enables computers to learn from data",
        "Natural language processing deals with text"
    ]
    
    result = await tool.execute(
        text=texts,
        dimensions=128,
        normalize=True
    )
    
    print(f"✓ Success: {result.success}")
    print(f"✓ Texts processed: {result.result['count']}")
    print(f"✓ Dimensions: {result.result['dimensions']}")
    print(f"✓ First embedding (preview): {result.result['embeddings'][0][:5]}...")
    print(f"✓ Time: {result.execution_time:.3f}s\n")
    
    # Single text embedding
    single_result = await tool.execute(
        text="Search query example",
        dimensions=128
    )
    
    print(f"✓ Single embedding dimensions: {len(single_result.result['embeddings'])}")
    print(f"✓ Time: {single_result.execution_time:.3f}s\n")


async def example_reranking():
    """Example: Rerank search results for improved relevance."""
    print("=" * 60)
    print("EXAMPLE 4: Reranking - Improve Search Results")
    print("=" * 60)
    
    tool = RerankTool()
    
    query = "python machine learning tutorial"
    
    documents = [
        "A comprehensive guide to web development with JavaScript",
        "Python machine learning tutorial for beginners",
        "Introduction to deep learning with Python",
        "Database design principles and best practices",
        "Advanced Python techniques for ML engineers",
        "Machine learning algorithms explained"
    ]
    
    result = await tool.execute(
        query=query,
        documents=documents,
        top_k=3,
        return_scores=True
    )
    
    print(f"✓ Success: {result.success}")
    print(f"✓ Query: {result.result['query']}")
    print(f"✓ Top {len(result.result['results'])} results:\n")
    
    for i, item in enumerate(result.result['results'], 1):
        print(f"  {i}. [Score: {item['score']:.3f}] {item['document']}")
    
    print(f"\n✓ Time: {result.execution_time:.3f}s\n")


async def example_semantic_search_pipeline():
    """Example: Complete semantic search pipeline."""
    print("=" * 60)
    print("EXAMPLE 5: Semantic Search Pipeline")
    print("=" * 60)
    
    embeddings_tool = EmbeddingsGeneratorTool()
    rerank_tool = RerankTool()
    
    # Document corpus
    documents = [
        "Python is great for data science and machine learning",
        "JavaScript is the language of the web",
        "Machine learning models require training data",
        "Deep learning uses neural networks",
        "Python libraries like scikit-learn are popular"
    ]
    
    # User query
    query = "machine learning with python"
    
    # Step 1: Generate embeddings for documents
    print("Step 1: Generating embeddings...")
    doc_result = await embeddings_tool.execute(
        text=documents,
        dimensions=64
    )
    print(f"  ✓ Generated {doc_result.result['count']} embeddings")
    
    # Step 2: Generate embedding for query
    query_result = await embeddings_tool.execute(
        text=query,
        dimensions=64
    )
    print(f"  ✓ Generated query embedding")
    
    # Step 3: Rerank results
    print("\nStep 2: Reranking results...")
    rerank_result = await rerank_tool.execute(
        query=query,
        documents=documents,
        top_k=3
    )
    
    print(f"\n✓ Top 3 most relevant documents:\n")
    for i, item in enumerate(rerank_result.result['results'], 1):
        print(f"  {i}. [Score: {item['score']:.3f}]")
        print(f"     {item['document']}\n")
    
    print(f"Total time: {doc_result.execution_time + query_result.execution_time + rerank_result.execution_time:.3f}s\n")


async def example_tool_schemas():
    """Example: Inspect tool schemas."""
    print("=" * 60)
    print("EXAMPLE 6: Tool Schemas")
    print("=" * 60)
    
    tools = [
        OmniParserTool(),
        EmbeddingsGeneratorTool(),
        RerankTool()
    ]
    
    for tool in tools:
        schema = tool.get_schema()
        print(f"\n{schema['name'].upper()}")
        print(f"  Category: {schema['category']}")
        print(f"  Description: {schema['description']}")
        print(f"  Required params: {schema['parameters'].get('required', [])}")
        print(f"  All params: {list(schema['parameters']['properties'].keys())}")


async def main():
    """Run all examples."""
    print("\n" + "=" * 60)
    print("GEAI TOOLS EXAMPLES")
    print("=" * 60 + "\n")
    
    await example_omni_parser()
    await example_file_upload()
    await example_embeddings()
    await example_reranking()
    await example_semantic_search_pipeline()
    await example_tool_schemas()
    
    print("=" * 60)
    print("ALL EXAMPLES COMPLETED")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
