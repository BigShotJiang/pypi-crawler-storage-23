"""
Example usage of file operation tools.

This snippet demonstrates how to use the built-in file tools:
- FileReaderTool: Read file contents
- FileWriterTool: Write content to files
- FileSearchTool: Search for files by pattern
- DirectoryListerTool: List directory contents
"""

import asyncio
from pathlib import Path
from pygeai_orchestration.tools.builtin.file_tools import (
    FileReaderTool,
    FileWriterTool,
    FileSearchTool,
    DirectoryListerTool
)


async def example_file_reader():
    """Example: Read file contents."""
    print("=" * 60)
    print("FileReaderTool Example")
    print("=" * 60)
    
    tool = FileReaderTool()
    
    result = await tool.execute(
        file_path="README.md",
        max_lines=10
    )
    
    if result.success:
        print(f"✓ Read {result.metadata['lines_read']} lines")
        print(f"  File size: {result.metadata['size_bytes']} bytes")
        print(f"  Execution time: {result.execution_time:.3f}s")
        print(f"\nFirst 10 lines:\n{result.result[:200]}...")
    else:
        print(f"✗ Error: {result.error}")
    print()


async def example_file_writer():
    """Example: Write content to files."""
    print("=" * 60)
    print("FileWriterTool Example")
    print("=" * 60)
    
    tool = FileWriterTool()
    
    result = await tool.execute(
        file_path="/tmp/example_output.txt",
        content="Hello from FileWriterTool!\nThis is a test file.\n",
        create_dirs=True
    )
    
    if result.success:
        print(f"✓ {result.result}")
        print(f"  Bytes written: {result.metadata['bytes_written']}")
        print(f"  Execution time: {result.execution_time:.3f}s")
    else:
        print(f"✗ Error: {result.error}")
    
    result_append = await tool.execute(
        file_path="/tmp/example_output.txt",
        content="Appended line!\n",
        append=True
    )
    
    if result_append.success:
        print(f"✓ Appended successfully")
    print()


async def example_file_search():
    """Example: Search for files by pattern."""
    print("=" * 60)
    print("FileSearchTool Example")
    print("=" * 60)
    
    tool = FileSearchTool()
    
    result = await tool.execute(
        directory="pygeai_orchestration",
        pattern="*.py",
        recursive=True,
        max_results=5
    )
    
    if result.success:
        print(f"✓ Found {result.metadata['total_matches']} Python files")
        print(f"  Execution time: {result.execution_time:.3f}s")
        print("\nFirst 5 matches:")
        for file_path in result.result:
            print(f"  - {file_path}")
    else:
        print(f"✗ Error: {result.error}")
    print()


async def example_directory_lister():
    """Example: List directory contents."""
    print("=" * 60)
    print("DirectoryListerTool Example")
    print("=" * 60)
    
    tool = DirectoryListerTool()
    
    result = await tool.execute(
        directory="pygeai_orchestration/tools",
        include_hidden=False,
        include_metadata=True
    )
    
    if result.success:
        print(f"✓ Listed {result.metadata['total_items']} items")
        print(f"  Execution time: {result.execution_time:.3f}s")
        print("\nDirectory contents:")
        for item in result.result[:5]:
            if isinstance(item, dict):
                print(f"  - {item['name']} ({item['type']}, {item.get('size', 'N/A')} bytes)")
            else:
                print(f"  - {Path(item).name}")
    else:
        print(f"✗ Error: {result.error}")
    print()


async def example_workflow():
    """Example: Complete workflow using multiple file tools."""
    print("=" * 60)
    print("Complete Workflow Example")
    print("=" * 60)
    
    search_tool = FileSearchTool()
    reader_tool = FileReaderTool()
    writer_tool = FileWriterTool()
    
    print("Step 1: Search for Python test files")
    search_result = await search_tool.execute(
        directory="tests",
        pattern="test_*.py",
        recursive=True,
        max_results=3
    )
    
    if search_result.success:
        print(f"  Found {len(search_result.result)} test files")
        
        print("\nStep 2: Read first test file")
        if search_result.result:
            first_file = search_result.result[0]
            read_result = await reader_tool.execute(
                file_path=first_file,
                max_lines=5
            )
            
            if read_result.success:
                print(f"  Read {read_result.metadata['lines_read']} lines from {Path(first_file).name}")
                
                print("\nStep 3: Create summary report")
                summary = f"""File Analysis Report
====================

File: {first_file}
Size: {read_result.metadata['size_bytes']} bytes
Lines analyzed: {read_result.metadata['lines_read']}

Preview:
{read_result.result[:200]}...
"""
                
                write_result = await writer_tool.execute(
                    file_path="/tmp/file_analysis.txt",
                    content=summary
                )
                
                if write_result.success:
                    print(f"  ✓ Report saved to /tmp/file_analysis.txt")
    print()


async def main():
    """Run all examples."""
    print("\n" + "=" * 60)
    print("File Operations Tools - Examples")
    print("=" * 60 + "\n")
    
    await example_file_reader()
    await example_file_writer()
    await example_file_search()
    await example_directory_lister()
    await example_workflow()
    
    print("=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
