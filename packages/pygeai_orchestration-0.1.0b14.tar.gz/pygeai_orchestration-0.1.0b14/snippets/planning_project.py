"""
Planning Pattern - Project Planning

Demonstrates using the PlanningPattern to break down complex projects
into structured, actionable steps with dependencies.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import PlanningPattern


async def main():
    agent_config = AgentConfig(
        name="project_planner",
        model="openai/gpt-4o-mini",
        temperature=0.5,
        system_prompt="You are an expert project manager who creates detailed, actionable plans."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="project_planning",
        pattern_type=PatternType.PLANNING,
        max_iterations=1
    )
    
    pattern = PlanningPattern(agent=agent, config=pattern_config)
    
    task = """
    Create a detailed project plan for building a REST API for a task management application.
    Include: architecture, database design, authentication, CRUD operations, testing, and deployment.
    """
    
    print(f"Project Planning Task:\n{task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nPlanning Complete: {result.success}")
    print(f"\nProject Plan:\n{result.result}")


if __name__ == "__main__":
    asyncio.run(main())
