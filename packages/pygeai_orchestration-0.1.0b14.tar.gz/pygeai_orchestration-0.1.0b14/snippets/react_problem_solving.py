"""
ReAct Pattern - Problem Solving

Demonstrates using ReAct (Reasoning + Acting) for structured problem solving
with step-by-step reasoning and action planning.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import ReActPattern


async def main():
    agent_config = AgentConfig(
        name="problem_solver",
        model="openai/gpt-4o-mini",
        temperature=0.7,
        system_prompt="You are a systematic problem solver. Think through problems step by step."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="problem_solving",
        pattern_type=PatternType.REACT,
        max_iterations=5
    )
    
    pattern = ReActPattern(agent=agent, config=pattern_config)
    
    task = """
    Problem: A train leaves Station A at 60 mph heading towards Station B, 300 miles away.
    Another train leaves Station B at the same time heading towards Station A at 40 mph.
    When will they meet and how far from Station A?
    """
    
    print(f"Problem:\n{task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nSolved: {result.success}")
    print(f"Reasoning Steps: {result.iterations}")
    print(f"\nSolution:\n{result.result}")


if __name__ == "__main__":
    asyncio.run(main())
