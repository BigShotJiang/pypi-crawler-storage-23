"""
Multi-Agent Pattern - Collaborative Agents

This snippet demonstrates multi-agent collaboration where specialized
agents work together on a complex task.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import MultiAgentPattern, AgentRole


async def main():
    researcher_config = AgentConfig(
        name="researcher",
        model="openai/gpt-4o-mini",
        temperature=0.5,
        system_prompt="You are a research specialist who gathers and analyzes information."
    )
    researcher = GEAIAgent(config=researcher_config)
    
    writer_config = AgentConfig(
        name="writer",
        model="openai/gpt-4o-mini",
        temperature=0.7,
        system_prompt="You are a skilled writer who creates clear, engaging content."
    )
    writer = GEAIAgent(config=writer_config)
    
    coordinator_config = AgentConfig(
        name="coordinator",
        model="openai/gpt-4o-mini",
        temperature=0.3,
        system_prompt="You are a project coordinator who plans tasks and synthesizes results."
    )
    coordinator = GEAIAgent(config=coordinator_config)
    
    agent_roles = [
        AgentRole(
            name="researcher",
            agent=researcher,
            role_description="Researches topics and gathers relevant information"
        ),
        AgentRole(
            name="writer",
            agent=writer,
            role_description="Writes reports and documentation based on research"
        )
    ]
    
    pattern_config = PatternConfig(
        name="multi_agent_example",
        pattern_type=PatternType.MULTI_AGENT,
        max_iterations=10
    )
    
    pattern = MultiAgentPattern(
        agents=agent_roles,
        coordinator_agent=coordinator,
        config=pattern_config
    )
    
    task = "Create a comprehensive report on the impact of AI on healthcare"
    print(f"Task: {task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nSuccess: {result.success}")
    print(f"\nFinal Report:\n{result.result}")
    
    if result.metadata.get("agent_contributions"):
        print("\n--- Agent Contributions ---")
        for agent_name, contributions in result.metadata["agent_contributions"].items():
            print(f"\n{agent_name.upper()}:")
            for i, contribution in enumerate(contributions, 1):
                print(f"  {i}. {contribution[:100]}...")


if __name__ == "__main__":
    asyncio.run(main())
