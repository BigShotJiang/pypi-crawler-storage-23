"""
Reflection Pattern - Iterative Self-Improvement

This snippet demonstrates using the ReflectionPattern to iteratively
improve responses through self-critique.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import ReflectionPattern


async def main():
    agent_config = AgentConfig(
        name="reflector",
        model="openai/gpt-4o-mini",
        temperature=0.7,
        system_prompt="You are a helpful AI assistant focused on providing clear, accurate responses."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="reflection_example",
        pattern_type=PatternType.REFLECTION,
        max_iterations=3
    )
    
    pattern = ReflectionPattern(agent=agent, config=pattern_config)
    
    task = "Explain quantum computing in simple terms"
    print(f"Task: {task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nSuccess: {result.success}")
    print(f"Iterations: {result.iterations}")
    print(f"\nFinal Result:\n{result.result}")


if __name__ == "__main__":
    asyncio.run(main())
