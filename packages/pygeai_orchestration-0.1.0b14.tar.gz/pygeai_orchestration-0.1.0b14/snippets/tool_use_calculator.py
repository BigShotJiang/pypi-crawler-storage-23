"""
Tool Use Pattern - Calculator Operations

Demonstrates using the ToolUsePattern to enable agents to use external tools
for mathematical calculations and data processing.
"""
import asyncio
import re
from typing import Dict, Any
from pygeai_orchestration.core.base import (
    AgentConfig, PatternConfig, PatternType,
    BaseTool, ToolConfig, ToolResult, ToolCategory
)
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import ToolUsePattern


class CalculatorTool(BaseTool):
    def __init__(self):
        config = ToolConfig(
            name="calculator",
            description=(
                "Performs mathematical calculations. "
                "Supported operations: add, multiply, average, max, min. "
                "Format: <operation> <comma-separated numbers>"
            ),
            category=ToolCategory.COMPUTATION,
            parameters_schema={"input": "string"}
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "input" in parameters
    
    async def execute(self, input: str = "", **kwargs) -> ToolResult:
        try:
            parts = input.strip().split(maxsplit=1)
            if len(parts) < 2:
                return ToolResult(
                    success=False,
                    result=None,
                    error="Invalid input format. Expected: <operation> <numbers>"
                )
            
            operation = parts[0].lower()
            numbers_str = parts[1]
            
            values = []
            for num in re.findall(r'-?\d+\.?\d*', numbers_str):
                values.append(float(num))
            
            if not values:
                return ToolResult(
                    success=False,
                    result=None,
                    error="No numbers found in input"
                )
            
            if operation == "add":
                result = sum(values)
            elif operation == "multiply":
                result = 1
                for v in values:
                    result *= v
            elif operation == "average":
                result = sum(values) / len(values) if values else 0
            elif operation == "max":
                result = max(values) if values else 0
            elif operation == "min":
                result = min(values) if values else 0
            else:
                return ToolResult(
                    success=False,
                    result=None,
                    error=f"Unknown operation: {operation}. Supported: add, multiply, average, max, min"
                )
            
            return ToolResult(
                success=True,
                result=result,
                metadata={"operation": operation, "input_count": len(values), "values": values}
            )
        except Exception as e:
            return ToolResult(success=False, result=None, error=str(e))


async def main():
    agent_config = AgentConfig(
        name="calculator_agent",
        model="openai/gpt-4o-mini",
        temperature=0.1,
        system_prompt=(
            "You are a mathematical assistant that uses tools to perform calculations. "
            "Use the calculator tool with this format: TOOL_CALL: calculator <operation> <numbers>. "
            "Example: TOOL_CALL: calculator average 1250, 3400, 2100, 4750, 1890"
        )
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="calculator_usage",
        pattern_type=PatternType.TOOL_USE,
        max_iterations=3
    )
    
    calculator = CalculatorTool()
    pattern = ToolUsePattern(agent=agent, config=pattern_config, tools=[calculator])
    
    task = "Calculate the average of these sales figures: 1250, 3400, 2100, 4750, 1890"
    print(f"Task: {task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nSuccess: {result.success}")
    print(f"Result: {result.result}")
    if result.metadata:
        print(f"Tools used: {result.metadata.get('tools_used', [])}")


if __name__ == "__main__":
    asyncio.run(main())
