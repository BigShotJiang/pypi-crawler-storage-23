"""
ReAct Pattern - Reasoning + Acting Loop

This snippet demonstrates the ReAct pattern for step-by-step
problem solving with reasoning and actions.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import ReActPattern


async def main():
    agent_config = AgentConfig(
        name="react_agent",
        model="openai/gpt-4o-mini",
        temperature=0.7,
        system_prompt="You are an analytical AI that thinks step-by-step and takes deliberate actions."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="react_example",
        pattern_type=PatternType.REACT,
        max_iterations=5
    )
    
    pattern = ReActPattern(agent=agent, config=pattern_config)
    
    task = "Research and summarize the key benefits of renewable energy"
    print(f"Task: {task}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nSuccess: {result.success}")
    print(f"Iterations: {result.iterations}")
    print(f"\nFinal Result:\n{result.result}")
    
    if result.metadata.get("steps"):
        print("\n--- Reasoning Steps ---")
        for i, step in enumerate(result.metadata["steps"], 1):
            print(f"\nStep {i}:")
            print(f"  Action: {step.get('action', 'N/A')}")
            if step.get("observation"):
                print(f"  Observation: {step.get('observation')}")


if __name__ == "__main__":
    asyncio.run(main())
