"""
Reflection Pattern - Code Review

Demonstrates using reflection to review and improve code quality
through iterative self-critique and refinement.
"""
import asyncio
from pygeai_orchestration.core.base import AgentConfig, PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import ReflectionPattern


async def main():
    agent_config = AgentConfig(
        name="code_reviewer",
        model="openai/gpt-4o-mini",
        temperature=0.3,
        system_prompt="You are an expert code reviewer focused on clean code, best practices, and security."
    )
    
    agent = GEAIAgent(config=agent_config)
    
    pattern_config = PatternConfig(
        name="code_review",
        pattern_type=PatternType.REFLECTION,
        max_iterations=3
    )
    
    pattern = ReflectionPattern(agent=agent, config=pattern_config)
    
    code_to_review = """
def calculate_total(items):
    total = 0
    for i in range(len(items)):
        total = total + items[i]['price'] * items[i]['qty']
    return total
"""
    
    task = f"Review this Python code and suggest improvements:\n{code_to_review}"
    print(f"Code Review Task:\n{code_to_review}\n")
    
    result = await pattern.execute(task)
    
    print(f"\nReview Complete: {result.success}")
    print(f"Iterations: {result.iterations}")
    print(f"\nFinal Review:\n{result.result}")


if __name__ == "__main__":
    asyncio.run(main())
