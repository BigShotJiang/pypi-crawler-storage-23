import sys

from pygeai_orchestration.cli.geai_orch import main as geai_orch


def main():
    sys.exit(geai_orch())


if __name__ == "__main__":
    main()
