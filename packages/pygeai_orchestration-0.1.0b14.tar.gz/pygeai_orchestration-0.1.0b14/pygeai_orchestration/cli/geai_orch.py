import sys
import logging
from typing import List, Optional

logging.getLogger("pygeai_orchestration").setLevel(logging.CRITICAL)

from pygeai_orchestration.cli.commands.base import base_commands, base_options
from pygeai_orchestration.cli.commands import ArgumentsEnum, Command
from pygeai.cli.parsers import CommandParser
from pygeai.cli.geai import setup_verbose_logging
from pygeai.cli.geai import CLIDriver as BaseCLIDriver
from pygeai_orchestration.cli.texts.help import CLI_USAGE
from pygeai_orchestration.cli.error_handler import ErrorHandler, ExitCode

from pygeai.core.base.session import get_session
from pygeai.core.common.exceptions import (
    UnknownArgumentError,
    MissingRequirementException,
    WrongArgumentError,
)
from pygeai.core.utils.console import Console
from pygeai import logger


def main() -> int:
    """
    Main entry point for the geai-orch CLI application.

    :return: int - Exit code indicating success or error.
    """
    try:
        driver = CLIDriver()
        return driver.main()
    except MissingRequirementException as e:
        error_msg = ErrorHandler.handle_missing_requirement(str(e))
        Console.write_stderr(error_msg)
        return ExitCode.MISSING_REQUIREMENT


class CLIDriver(BaseCLIDriver):
    """
    Orchestration CLI driver extending the base GEAI CLI driver.

    Adds orchestration-specific features:
    - Custom credentials file support
    - Enhanced error handling with ErrorHandler
    - Verbose logging mode
    """

    def __init__(self, session=None, credentials_file=None) -> None:
        """
        Initialize the CLI driver with optional session and credentials file.

        Sets up the session to be used while running commands, either with a
        specified alias, environment variables, or function parameters.
        Once the session is defined, it won't change during the execution.

        :param session: Optional session object. If None, uses 'default' or
                       alias-specified session from command-line arguments.
        :param credentials_file: Optional path to custom credentials file.
        """
        from pygeai.core.common.config import get_settings

        arguments = sys.argv

        if credentials_file or "--credentials" in arguments or "--creds" in arguments:
            if not credentials_file:
                credentials_file = self._get_credentials_file(arguments)
            get_settings(credentials_file=credentials_file)
            logger.debug(f"Using custom credentials file: {credentials_file}")

        super().__init__(session=session)

    def _get_credentials_file(self, arguments: List[str]) -> str:
        """
        Retrieves and removes credentials file path and flag from argument list.

        :param arguments: List[str] - Command line arguments.
        :return: str - The credentials file path.
        :raises MissingRequirementException: If credentials flag is present but no value provided.
        """
        creds_index = None

        if "--credentials" in arguments:
            creds_index = arguments.index("--credentials")
        elif "--creds" in arguments:
            creds_index = arguments.index("--creds")

        try:
            _ = arguments.pop(creds_index)
            credentials_file = arguments.pop(creds_index)
            return credentials_file
        except IndexError:
            Console.write_stderr(
                "--creds/--credentials option requires a file path. Please provide a valid path after the option."
            )
            raise MissingRequirementException("Couldn't find a valid path in parameter list.")

    def main(self, args: Optional[List[str]] = None) -> int:
        """
        Execute the CLI command with enhanced error handling and verbose mode.

        Extends base main() with:
        - Verbose logging support
        - ErrorHandler for user-friendly messages
        - Exit code constants

        :param args: Optional[List[str]] - Command line arguments. If None, uses sys.argv.
        :return: int - Exit code (0 for success, non-zero for errors).
        """
        try:
            argv = sys.argv if args is None else args

            if "--verbose" in argv or "-v" in argv:
                setup_verbose_logging()
                argv_copy = [a for a in argv if a not in ("--verbose", "-v")]
                if args is None:
                    sys.argv = argv_copy
                else:
                    args = argv_copy
                argv = argv_copy

            logger.debug(f"Running geai-orch with: {' '.join(a for a in argv)}")
            logger.debug(
                f"Session: {self.session.alias if hasattr(self.session, 'alias') else 'default'}"
            )

            if len(argv) > 1:
                arg = argv[1] if args is None else args[1]
                arguments = argv[2:] if args is None else args[2:]

                logger.debug(f"Identifying command for argument: {arg}")
                command = CommandParser(base_commands, base_options).identify_command(arg)
                logger.debug(f"Command identified: {command.name}")
            else:
                logger.debug("No arguments provided, defaulting to help command")
                command = base_commands[0]
                arguments = []

            self.process_command(command, arguments)
            logger.debug("Command completed successfully")
            return ExitCode.SUCCESS
        except UnknownArgumentError as e:
            if hasattr(e, "available_commands") and e.available_commands:
                error_msg = ErrorHandler.handle_unknown_command(e.arg, e.available_commands)
            elif hasattr(e, "available_options") and e.available_options:
                error_msg = ErrorHandler.handle_unknown_option(e.arg, e.available_options)
            else:
                error_msg = ErrorHandler.format_error("Unknown Argument", str(e))

            Console.write_stderr(error_msg)
            return ExitCode.USER_INPUT_ERROR
        except WrongArgumentError as e:
            error_msg = ErrorHandler.handle_wrong_argument(str(e), CLI_USAGE)
            Console.write_stderr(error_msg)
            return ExitCode.USER_INPUT_ERROR
        except MissingRequirementException as e:
            error_msg = ErrorHandler.handle_missing_requirement(str(e))
            Console.write_stderr(error_msg)
            return ExitCode.MISSING_REQUIREMENT
        except KeyboardInterrupt:
            message = ErrorHandler.handle_keyboard_interrupt()
            Console.write_stdout(message)
            return ExitCode.KEYBOARD_INTERRUPT
        except Exception as e:
            error_msg = ErrorHandler.handle_unexpected_error(e)
            Console.write_stderr(error_msg)
            return ExitCode.UNEXPECTED_ERROR
