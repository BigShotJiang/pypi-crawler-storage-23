"""
Base commands for the geai-orch CLI.
"""

import logging
from typing import List, Tuple

from pygeai.core.utils.console import Console
from pygeai_orchestration import __version__
from pygeai_orchestration.cli.commands import Command, Option, ArgumentsEnum
from pygeai_orchestration.cli.texts.help import (
    CLI_USAGE,
    VERSION_TEXT,
    HELP_REFLECTION,
    HELP_TOOL_USE,
    HELP_REACT,
    HELP_PLANNING,
    HELP_MULTI_AGENT,
    HELP_PLUGINS,
    HELP_TOOLS,
)

logger = logging.getLogger("pygeai_orchestration")


def show_help(option_list: List[Tuple[Option, str]] = None):
    """
    Display help information for geai-orch CLI.

    :param option_list: Optional list of options (unused, for compatibility)
    """
    Console.write_stdout(CLI_USAGE)


def show_version(option_list: List[Tuple[Option, str]] = None):
    """
    Display version information.

    :param option_list: Optional list of options (unused, for compatibility)
    """
    Console.write_stdout(VERSION_TEXT.format(version=__version__))


def show_reflection_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for reflection command."""
    Console.write_stdout(HELP_REFLECTION)


def show_tool_use_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for tool-use command."""
    Console.write_stdout(HELP_TOOL_USE)


def show_react_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for react command."""
    Console.write_stdout(HELP_REACT)


def show_planning_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for planning command."""
    Console.write_stdout(HELP_PLANNING)


def show_multi_agent_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for multi-agent command."""
    Console.write_stdout(HELP_MULTI_AGENT)


def show_plugins_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for plugins command."""
    Console.write_stdout(HELP_PLUGINS)


def show_tools_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for tools command."""
    Console.write_stdout(HELP_TOOLS)


def placeholder_handler(option_list: List[Tuple[Option, str]] = None):
    """
    Placeholder handler for commands not yet implemented.

    :param option_list: List of parsed options
    """
    Console.write_stdout("[WARNING] This command is not yet implemented.")
    Console.write_stdout("This feature is under development and will be available soon.")


help_command = Command(
    name="help",
    identifiers=["help", "h"],
    description="Show help information",
    action=show_help,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[],
    options=[],
)

version_command = Command(
    name="version",
    identifiers=["version", "v"],
    description="Show version information",
    action=show_version,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[],
    options=[],
)

# Import pattern execution handlers
from pygeai_orchestration.cli.commands.patterns import (
    execute_reflection,
    execute_react,
    execute_planning,
    execute_tool_use,
    execute_multi_agent,
)

# Discover and load plugin pattern commands
plugin_pattern_subcommands = []
try:
    from pygeai_orchestration.cli.commands.plugins import discover_plugin_commands
    
    plugin_pattern_subcommands = discover_plugin_commands()
    logger.debug(f"Discovered {len(plugin_pattern_subcommands)} plugin pattern(s)")
except Exception as e:
    logger.warning(f"Failed to load plugin patterns: {e}")
    logger.debug("Plugin pattern loading error details:", exc_info=True)

# Execute pattern command with subcommands (builtin + plugins)
execute_pattern_command = Command(
    name="execute-pattern",
    identifiers=["execute-pattern", "xp", "pattern"],
    description="Execute orchestration patterns",
    action=None,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[
        Command(
            name="reflection",
            identifiers=["reflection"],
            description="Iterative self-improvement pattern",
            action=execute_reflection,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option("model", ["-m", "--model"], "Model name (e.g., openai/gpt-4o-mini)", True),
                Option("temperature", ["--temperature"], "Temperature (0.0-2.0)", True),
                Option("system-prompt", ["--system-prompt"], "System prompt for agent", True),
                Option("max-tokens", ["--max-tokens"], "Maximum tokens for generation", True),
                Option("task", ["-t", "--task"], "Task to execute", True),
                Option("iterations", ["-i", "--iterations"], "Max reflection iterations", True),
                Option("output", ["-o", "--output"], "Output file path", True),
                Option("verbose", ["--verbose"], "Include metadata in output", False),
            ],
        ),
        Command(
            name="react",
            identifiers=["react"],
            description="Reasoning and acting pattern",
            action=execute_react,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option("model", ["-m", "--model"], "Model name (e.g., openai/gpt-4o-mini)", True),
                Option("temperature", ["--temperature"], "Temperature (0.0-2.0)", True),
                Option("system-prompt", ["--system-prompt"], "System prompt for agent", True),
                Option("max-tokens", ["--max-tokens"], "Maximum tokens for generation", True),
                Option("task", ["-t", "--task"], "Task to execute", True),
                Option("max-steps", ["--max-steps"], "Maximum reasoning steps", True),
                Option("output", ["-o", "--output"], "Output file path", True),
                Option("verbose", ["--verbose"], "Include metadata in output", False),
            ],
        ),
        Command(
            name="planning",
            identifiers=["planning"],
            description="Task planning and decomposition pattern",
            action=execute_planning,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option("model", ["-m", "--model"], "Model name (e.g., openai/gpt-4o-mini)", True),
                Option("temperature", ["--temperature"], "Temperature (0.0-2.0)", True),
                Option("system-prompt", ["--system-prompt"], "System prompt for agent", True),
                Option("max-tokens", ["--max-tokens"], "Maximum tokens for generation", True),
                Option("task", ["-t", "--task"], "Task to execute", True),
                Option("output", ["-o", "--output"], "Output file path", True),
                Option("verbose", ["--verbose"], "Include metadata in output", False),
            ],
        ),
        Command(
            name="tool-use",
            identifiers=["tool-use"],
            description="Tool-augmented execution pattern",
            action=execute_tool_use,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option("model", ["-m", "--model"], "Model name (e.g., openai/gpt-4o-mini)", True),
                Option("temperature", ["--temperature"], "Temperature (0.0-2.0)", True),
                Option("system-prompt", ["--system-prompt"], "System prompt for agent", True),
                Option("max-tokens", ["--max-tokens"], "Maximum tokens for generation", True),
                Option("task", ["-t", "--task"], "Task to execute", True),
                Option("tools", ["--tools"], "Comma-separated tool names", True),
                Option("iterations", ["-i", "--iterations"], "Max iterations", True),
                Option("output", ["-o", "--output"], "Output file path", True),
                Option("verbose", ["--verbose"], "Include metadata in output", False),
            ],
        ),
        Command(
            name="multi-agent",
            identifiers=["multi-agent"],
            description="Multi-agent collaboration pattern",
            action=execute_multi_agent,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option("config", ["-c", "--config"], "Multi-agent config file path", True),
                Option("task", ["-t", "--task"], "Task to execute", True),
                Option("max-iterations", ["--max-iterations"], "Maximum iterations", True),
                Option("output", ["-o", "--output"], "Output file path", True),
                Option("verbose", ["--verbose"], "Include metadata in output", False),
            ],
        ),
    ] + plugin_pattern_subcommands,  # Add discovered plugin patterns as subcommands
    options=[],
)

# Plugin management command
from pygeai_orchestration.cli.commands.plugins import (
    list_plugins_command,
    plugin_info_command,
)

plugins_command = Command(
    name="plugins",
    identifiers=["plugins", "plugin"],
    description="Manage custom pattern plugins",
    action=None,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[
        Command(
            name="help",
            identifiers=["help", "h"],
            description="Show help for plugins command",
            action=show_plugins_help,
            additional_args=ArgumentsEnum.NOT_AVAILABLE,
            subcommands=[],
            options=[],
        ),
        Command(
            name="list",
            identifiers=["list", "ls"],
            description="List all discovered custom patterns",
            action=list_plugins_command,
            additional_args=ArgumentsEnum.NOT_AVAILABLE,
            subcommands=[],
            options=[],
        ),
        Command(
            name="info",
            identifiers=["info"],
            description="Show detailed info about a pattern",
            action=plugin_info_command,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option(
                    name="--name",
                    identifiers=["--name", "-n"],
                    description="Pattern name",
                    requires_args=True,
                )
            ],
        ),
    ],
    options=[],
)

# Tool management command
from pygeai_orchestration.cli.commands.tools import (
    list_tools_command,
    tool_info_command,
)

tools_command = Command(
    name="tools",
    identifiers=["tools", "tool"],
    description="Manage and inspect builtin tools",
    action=None,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[
        Command(
            name="help",
            identifiers=["help", "h"],
            description="Show help for tools command",
            action=show_tools_help,
            additional_args=ArgumentsEnum.NOT_AVAILABLE,
            subcommands=[],
            options=[],
        ),
        Command(
            name="list",
            identifiers=["list", "ls"],
            description="List all available builtin tools",
            action=list_tools_command,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option(
                    name="--category",
                    identifiers=["--category", "-c"],
                    description="Filter by category (e.g., math_tools, file_tools)",
                    requires_args=True,
                )
            ],
        ),
        Command(
            name="info",
            identifiers=["info"],
            description="Show detailed info about a specific tool",
            action=tool_info_command,
            additional_args=ArgumentsEnum.OPTIONAL,
            subcommands=[],
            options=[
                Option(
                    name="--name",
                    identifiers=["--name", "-n"],
                    description="Tool name",
                    requires_args=True,
                )
            ],
        ),
    ],
    options=[],
)

base_commands = [
    help_command,
    version_command,
    execute_pattern_command,
    plugins_command,
    tools_command,
]

base_options = [
    Option("alias", ["-a", "--alias"], "Use a specific credentials profile", True),
    Option("credentials", ["--credentials", "--creds"], "Path to custom credentials file", True),
    Option("verbose", ["-v", "--verbose"], "Enable verbose logging", False),
]
