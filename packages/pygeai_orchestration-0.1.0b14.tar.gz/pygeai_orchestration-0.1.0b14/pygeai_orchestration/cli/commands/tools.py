"""Tool management and discovery commands."""

import importlib
import inspect
from typing import Dict, List, Type

from pygeai.core.utils.console import Console
from pygeai_orchestration.core.base.tool import BaseTool
from pygeai_orchestration.core.tools import ToolLoader, CustomTool

BUILTIN_TOOL_MODULES = [
    'pygeai_orchestration.tools.builtin.math_tools',
    'pygeai_orchestration.tools.builtin.file_tools',
    'pygeai_orchestration.tools.builtin.text_tools',
    'pygeai_orchestration.tools.builtin.data_tools',
    'pygeai_orchestration.tools.builtin.web_tools',
    'pygeai_orchestration.tools.builtin.system_tools',
    'pygeai_orchestration.tools.builtin.communication_tools',
    'pygeai_orchestration.tools.builtin.document_extraction',
    'pygeai_orchestration.tools.builtin.document_generation',
    'pygeai_orchestration.tools.builtin.utilities',
    'pygeai_orchestration.tools.builtin.image_tools',
    'pygeai_orchestration.tools.builtin.geai_tools',
]


def discover_builtin_tools() -> Dict[str, List[Type[BaseTool]]]:
    """
    Discover all builtin tools organized by category.
    
    Returns:
        Dict mapping category name to list of tool classes
    """
    tools_by_category = {}

    for module_name in BUILTIN_TOOL_MODULES:
        try:
            module = importlib.import_module(module_name)
            category = module_name.split('.')[-1]
            tools = []

            for name, obj in inspect.getmembers(module, inspect.isclass):
                if (issubclass(obj, BaseTool) and
                        obj != BaseTool and
                        obj.__module__ == module_name):
                    tools.append(obj)

            if tools:
                tools_by_category[category] = sorted(tools, key=lambda t: t.__name__)

        except Exception:
            pass

    return tools_by_category


def discover_custom_tools() -> Dict[str, CustomTool]:
    """
    Discover custom tools from ~/.geai-orch/tools/
    
    Returns:
        Dict mapping tool name to CustomTool metadata
    """
    loader = ToolLoader()
    return loader.discover_tools()


def list_tools_command(options=None):
    """List all available tools (builtin + custom)."""
    category_filter = None

    if options:
        for opt, value in options:
            if opt.name in ["--category", "-c"]:
                category_filter = value

    builtin_tools = discover_builtin_tools()
    custom_tools = discover_custom_tools()

    if category_filter:
        if category_filter == "custom":
            builtin_tools = {}
        elif category_filter not in builtin_tools:
            Console.write_stderr(f"Error: Category '{category_filter}' not found")
            Console.write_stderr("Available categories:")
            for cat in sorted(builtin_tools.keys()):
                Console.write_stderr(f"  - {cat}")
            Console.write_stderr("  - custom")
            return
        else:
            builtin_tools = {category_filter: builtin_tools[category_filter]}
            custom_tools = {}

    builtin_count = sum(len(tools) for tools in builtin_tools.values())
    custom_count = len(custom_tools)
    total_tools = builtin_count + custom_count

    Console.write_stdout(f"\nAvailable Tools ({total_tools} total)\n")
    Console.write_stdout("=" * 80)
    Console.write_stdout("")

    if builtin_tools:
        Console.write_stdout(f"Built-in Tools ({builtin_count}):")
        Console.write_stdout("")
        for category in sorted(builtin_tools.keys()):
            tools = builtin_tools[category]
            Console.write_stdout(f"  {category} ({len(tools)}):")
            for tool_class in tools:
                Console.write_stdout(f"    - {tool_class.__name__}")
            Console.write_stdout("")

    if custom_tools and not category_filter or category_filter == "custom":
        Console.write_stdout(f"Custom Tools ({custom_count}):")
        Console.write_stdout("")
        for tool in sorted(custom_tools.values(), key=lambda t: t.name):
            Console.write_stdout(f"  - {tool.tool_class.__name__} [CUSTOM]")
            Console.write_stdout(f"      Description: {tool.description}")
            Console.write_stdout(f"      Source: {tool.source_file}")
        Console.write_stdout("")

    if not builtin_tools and not custom_tools:
        Console.write_stdout("No tools found.")
        Console.write_stdout("")

    Console.write_stdout("=" * 80)
    
    if custom_tools:
        loader = ToolLoader()
        Console.write_stdout(f"Custom tools directory: {loader.tools_dir}\n")


def tool_info_command(options):
    """Show detailed information about a specific tool (builtin or custom)."""
    tool_name = None

    for opt, value in options:
        if opt.name in ["--name", "-n"]:
            tool_name = value

    if not tool_name:
        Console.write_stderr("Error: --name is required")
        Console.write_stderr("Usage: geai-orch tools info --name <ToolName>")
        return

    builtin_tools = discover_builtin_tools()
    custom_tools = discover_custom_tools()

    found_tool = None
    found_category = None
    is_custom = False

    for category, tools in builtin_tools.items():
        for tool_class in tools:
            if tool_class.__name__ == tool_name:
                found_tool = tool_class
                found_category = category
                break
        if found_tool:
            break

    if not found_tool:
        for custom_tool in custom_tools.values():
            if custom_tool.tool_class.__name__ == tool_name:
                found_tool = custom_tool.tool_class
                found_category = custom_tool.category
                is_custom = True
                custom_tool_metadata = custom_tool
                break

    if not found_tool:
        Console.write_stderr(f"Tool '{tool_name}' not found\n")
        Console.write_stderr("Available tools:")
        Console.write_stderr("\nBuilt-in:")
        for category in sorted(builtin_tools.keys()):
            for tool_class in builtin_tools[category]:
                Console.write_stderr(f"  - {tool_class.__name__}")
        if custom_tools:
            Console.write_stderr("\nCustom:")
            for custom_tool in custom_tools.values():
                Console.write_stderr(f"  - {custom_tool.tool_class.__name__}")
        return

    tool_type = "[CUSTOM]" if is_custom else "[BUILTIN]"
    Console.write_stdout(f"\nTool: {found_tool.__name__} {tool_type}\n")
    Console.write_stdout("=" * 80)
    Console.write_stdout("")
    Console.write_stdout(f"Category: {found_category}")
    
    if is_custom:
        Console.write_stdout(f"Source File: {custom_tool_metadata.source_file}")
    else:
        Console.write_stdout(f"Module: {found_tool.__module__}")

    if found_tool.__doc__:
        doc_lines = found_tool.__doc__.strip().split('\n')
        description = doc_lines[0].strip() if doc_lines else "No description available"
        Console.write_stdout(f"Description: {description}")
    else:
        Console.write_stdout("Description: No description available")

    Console.write_stdout("")

    if found_tool.__doc__:
        Console.write_stdout("Documentation:")
        Console.write_stdout("-" * 80)
        Console.write_stdout("")
        Console.write_stdout(found_tool.__doc__.strip())
        Console.write_stdout("")
        Console.write_stdout("-" * 80)
        Console.write_stdout("")

    Console.write_stdout("Usage:")
    if is_custom:
        Console.write_stdout(f"  # Custom tool from: {custom_tool_metadata.source_file}")
        Console.write_stdout(f"  from {custom_tool_metadata.source_file.replace('.py', '').replace('/', '.')} import {found_tool.__name__}")
    else:
        Console.write_stdout(f"  from {found_tool.__module__} import {found_tool.__name__}")
    Console.write_stdout(f"  tool = {found_tool.__name__}()")
    Console.write_stdout(f"  result = await tool.execute(...)")
