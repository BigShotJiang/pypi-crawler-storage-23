"""
Pattern execution commands for the geai-orch CLI.
"""

import asyncio
import json
import logging
from typing import List, Tuple, Dict, Any, Optional

from pygeai.core.utils.console import Console
from pygeai_orchestration.cli.commands import Option
from pygeai_orchestration.core.base import (
    AgentConfig,
    PatternConfig,
    PatternType,
    PatternResult,
)
from pygeai_orchestration.core.base.geai_agent import GEAIAgent
from pygeai_orchestration.patterns import (
    ReflectionPattern,
    ReActPattern,
    PlanningPattern,
    ToolUsePattern,
    MultiAgentPattern,
    AgentRole,
)

logger = logging.getLogger("pygeai_orchestration")


def parse_options(option_list: List[Tuple[Option, str]]) -> Dict[str, str]:
    """
    Convert option list to dictionary.
    
    :param option_list: List of (Option, value) tuples
    :return: Dictionary mapping option names to values
    """
    opts = {}
    for option, value in option_list:
        opts[option.name] = value
    return opts


def create_agent_from_cli(opts: Dict[str, str], session=None) -> GEAIAgent:
    """
    Create GEAIAgent from CLI options.
    
    :param opts: Parsed options dictionary
    :param session: Optional PyGEAI session
    :return: GEAIAgent instance
    """
    agent_config = AgentConfig(
        name=opts.get('name', 'cli_agent'),
        model=opts['model'],
        temperature=float(opts.get('temperature', 0.7)),
        system_prompt=opts.get('system-prompt', 'You are a helpful AI assistant.'),
        max_tokens=int(opts.get('max-tokens', 4096))
    )
    return GEAIAgent(config=agent_config, session=session)


def create_agent_from_spec(spec: Dict[str, Any], session=None) -> GEAIAgent:
    """
    Create GEAIAgent from dictionary specification.
    
    :param spec: Agent specification dictionary
    :param session: Optional PyGEAI session
    :return: GEAIAgent instance
    """
    agent_config = AgentConfig(
        name=spec['name'],
        model=spec.get('model', 'openai/gpt-4o-mini'),
        temperature=float(spec.get('temperature', 0.7)),
        system_prompt=spec.get('system_prompt', ''),
        max_tokens=int(spec.get('max_tokens', 4096))
    )
    return GEAIAgent(config=agent_config, session=session)


def load_tools_from_names(tool_names: List[str]) -> List:
    """
    Load tools from registry by names.
    
    :param tool_names: List of tool names
    :return: List of tool instances
    """
    from pygeai_orchestration.tools.registry import ToolRegistry
    
    registry = ToolRegistry()
    tools = []
    
    for name in tool_names:
        if name.strip():
            try:
                tool = registry.get_tool(name.strip())
                if tool:
                    tools.append(tool)
                    logger.debug(f"Loaded tool: {name.strip()}")
                else:
                    logger.warning(f"Tool not found: {name.strip()}")
            except Exception as e:
                logger.error(f"Failed to load tool '{name.strip()}': {e}")
    
    return tools


def load_multi_agent_config(config_file: str) -> Dict[str, Any]:
    """
    Load multi-agent configuration from JSON file.
    
    :param config_file: Path to JSON config file
    :return: Configuration dictionary
    """
    with open(config_file, 'r') as f:
        return json.load(f)


def run_async_pattern(coro):
    """
    Run async coroutine in sync context.
    
    :param coro: Async coroutine
    :return: Coroutine result
    """
    return asyncio.run(coro)


def output_pattern_result(result: PatternResult, output_file: Optional[str], verbose: bool):
    """
    Format and output PatternResult.
    
    :param result: PatternResult to output
    :param output_file: Optional output file path
    :param verbose: Include metadata and iterations
    """
    output_data = {
        "success": result.success,
        "result": result.result,
    }
    
    if verbose:
        output_data["iterations"] = result.iterations
        output_data["metadata"] = result.metadata
    
    output_text = json.dumps(output_data, indent=2)
    
    if output_file:
        with open(output_file, 'w') as f:
            f.write(output_text)
        Console.write_stdout(f"Result written to {output_file}")
    else:
        Console.write_stdout(output_text)


def execute_reflection(option_list: List[Tuple[Option, str]]):
    """
    Execute reflection pattern.
    
    :param option_list: List of parsed options
    """
    try:
        opts = parse_options(option_list)
        
        # Validate required params
        if 'task' not in opts:
            Console.write_stderr("Error: --task is required")
            return
        if 'model' not in opts:
            Console.write_stderr("Error: --model is required")
            return
        
        # Create agent
        agent = create_agent_from_cli(opts)
        
        # Create pattern config
        config = PatternConfig(
            name="cli_reflection",
            pattern_type=PatternType.REFLECTION,
            max_iterations=int(opts.get('iterations', 3))
        )
        
        # Create and execute pattern
        pattern = ReflectionPattern(agent=agent, config=config)
        result = run_async_pattern(pattern.execute(opts['task']))
        
        # Output
        verbose = 'verbose' in opts
        output_pattern_result(result, opts.get('output'), verbose)
        
    except Exception as e:
        logger.error(f"Reflection pattern execution failed: {e}", exc_info=True)
        Console.write_stderr(f"Error: {str(e)}")


def execute_react(option_list: List[Tuple[Option, str]]):
    """
    Execute ReAct pattern.
    
    :param option_list: List of parsed options
    """
    try:
        opts = parse_options(option_list)
        
        # Validate required params
        if 'task' not in opts:
            Console.write_stderr("Error: --task is required")
            return
        if 'model' not in opts:
            Console.write_stderr("Error: --model is required")
            return
        
        # Create agent
        agent = create_agent_from_cli(opts)
        
        # Create pattern config
        config = PatternConfig(
            name="cli_react",
            pattern_type=PatternType.REACT,
            max_iterations=int(opts.get('max-steps', 5))
        )
        
        # Create and execute pattern
        pattern = ReActPattern(agent=agent, config=config)
        result = run_async_pattern(pattern.execute(opts['task']))
        
        # Output
        verbose = 'verbose' in opts
        output_pattern_result(result, opts.get('output'), verbose)
        
    except Exception as e:
        logger.error(f"ReAct pattern execution failed: {e}", exc_info=True)
        Console.write_stderr(f"Error: {str(e)}")


def execute_planning(option_list: List[Tuple[Option, str]]):
    """
    Execute planning pattern.
    
    :param option_list: List of parsed options
    """
    try:
        opts = parse_options(option_list)
        
        # Validate required params
        if 'task' not in opts:
            Console.write_stderr("Error: --task is required")
            return
        if 'model' not in opts:
            Console.write_stderr("Error: --model is required")
            return
        
        # Create agent
        agent = create_agent_from_cli(opts)
        
        # Create pattern config
        config = PatternConfig(
            name="cli_planning",
            pattern_type=PatternType.PLANNING,
            max_iterations=1  # Planning is typically single-shot
        )
        
        # Create and execute pattern
        pattern = PlanningPattern(agent=agent, config=config)
        result = run_async_pattern(pattern.execute(opts['task']))
        
        # Output
        verbose = 'verbose' in opts
        output_pattern_result(result, opts.get('output'), verbose)
        
    except Exception as e:
        logger.error(f"Planning pattern execution failed: {e}", exc_info=True)
        Console.write_stderr(f"Error: {str(e)}")


def execute_tool_use(option_list: List[Tuple[Option, str]]):
    """
    Execute tool use pattern.
    
    :param option_list: List of parsed options
    """
    try:
        opts = parse_options(option_list)
        
        # Validate required params
        if 'task' not in opts:
            Console.write_stderr("Error: --task is required")
            return
        if 'model' not in opts:
            Console.write_stderr("Error: --model is required")
            return
        
        # Create agent
        agent = create_agent_from_cli(opts)
        
        # Load tools if specified
        tools = []
        if 'tools' in opts:
            tool_names = opts['tools'].split(',')
            tools = load_tools_from_names(tool_names)
        
        # Create pattern config
        config = PatternConfig(
            name="cli_tool_use",
            pattern_type=PatternType.TOOL_USE,
            max_iterations=int(opts.get('iterations', 3))
        )
        
        # Create and execute pattern
        pattern = ToolUsePattern(agent=agent, tools=tools, config=config)
        result = run_async_pattern(pattern.execute(opts['task']))
        
        # Output
        verbose = 'verbose' in opts
        output_pattern_result(result, opts.get('output'), verbose)
        
    except Exception as e:
        logger.error(f"Tool use pattern execution failed: {e}", exc_info=True)
        Console.write_stderr(f"Error: {str(e)}")


def execute_multi_agent(option_list: List[Tuple[Option, str]]):
    """
    Execute multi-agent pattern.
    
    :param option_list: List of parsed options
    """
    try:
        opts = parse_options(option_list)
        
        # Validate required params
        if 'config' not in opts:
            Console.write_stderr("Error: --config is required for multi-agent pattern")
            return
        if 'task' not in opts:
            Console.write_stderr("Error: --task is required")
            return
        
        # Load multi-agent config from file
        config_data = load_multi_agent_config(opts['config'])
        
        # Create agents from config
        agent_roles = []
        for agent_spec in config_data.get('agents', []):
            agent = create_agent_from_spec(agent_spec)
            role = AgentRole(
                name=agent_spec['name'],
                agent=agent,
                role_description=agent_spec.get('role_description', '')
            )
            agent_roles.append(role)
        
        # Create coordinator agent
        coordinator_spec = config_data.get('coordinator', {})
        coordinator = create_agent_from_spec(coordinator_spec)
        
        # Create pattern config
        pattern_config = PatternConfig(
            name="cli_multi_agent",
            pattern_type=PatternType.MULTI_AGENT,
            max_iterations=int(opts.get('max-iterations', 10))
        )
        
        # Create and execute pattern
        pattern = MultiAgentPattern(
            agents=agent_roles,
            coordinator_agent=coordinator,
            config=pattern_config
        )
        
        result = run_async_pattern(pattern.execute(opts['task']))
        
        # Output
        verbose = 'verbose' in opts
        output_pattern_result(result, opts.get('output'), verbose)
        
    except Exception as e:
        logger.error(f"Multi-agent pattern execution failed: {e}", exc_info=True)
        Console.write_stderr(f"Error: {str(e)}")
