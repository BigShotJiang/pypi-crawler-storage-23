"""Dynamic CLI command generation for plugin patterns."""

import asyncio
import logging
from typing import List

from pygeai.core.utils.console import Console
from pygeai_orchestration.cli.commands import ArgumentsEnum, Command, Option
from pygeai_orchestration.core.base import PatternConfig, PatternType
from pygeai_orchestration.core.base.geai_agent import GEAIAgent, AgentConfig
from pygeai_orchestration.core.plugins import PluginLoader, PluginPattern

logger = logging.getLogger("pygeai_orchestration")


def discover_plugin_commands() -> List[Command]:
    """
    Discover plugins and generate CLI commands.

    Scans the plugin directory for custom patterns and creates
    CLI commands for each discovered pattern.

    :return: List of Command objects for discovered patterns
    """
    loader = PluginLoader()
    patterns = loader.discover_patterns()

    commands = []
    for pattern in patterns.values():
        command = create_pattern_command(pattern)
        commands.append(command)

    return commands


def create_pattern_command(pattern: PluginPattern) -> Command:
    """
    Create a CLI command for a pattern plugin.

    :param pattern: PluginPattern metadata
    :return: Command object configured for this pattern
    """
    return Command(
        name=pattern.name,
        identifiers=[pattern.name],
        description=pattern.description,
        action=create_pattern_executor(pattern),
        additional_args=ArgumentsEnum.OPTIONAL,
        subcommands=[],
        options=[
            Option(
                name="--task",
                identifiers=["--task", "-t"],
                description="Task description for the pattern",
                requires_args=True,
            ),
            Option(
                name="--model",
                identifiers=["--model", "-m"],
                description="Model to use (default: openai/gpt-4o-mini)",
                requires_args=True,
            ),
            Option(
                name="--max-iterations",
                identifiers=["--max-iterations", "-i"],
                description="Maximum iterations (default: 5)",
                requires_args=True,
            ),
        ],
    )


def create_pattern_executor(pattern: PluginPattern):
    """
    Create the executor function for a pattern.

    :param pattern: PluginPattern metadata
    :return: Executor function that can be called by CLI
    """

    def executor(options: List):
        """Execute the custom pattern."""
        # Parse options - options is a list of (Option, value) tuples
        task = None
        model = "openai/gpt-4o-mini"
        max_iterations = 5

        for opt, value in options:
            if opt.name in ["--task", "-t"]:
                task = value
            elif opt.name in ["--model", "-m"]:
                model = value
            elif opt.name in ["--max-iterations", "-i"]:
                try:
                    max_iterations = int(value)
                except ValueError:
                    Console.write_stderr(
                        f"Error: --max-iterations must be a number, got: {value}"
                    )
                    return

        if not task:
            Console.write_stderr("Error: --task is required")
            Console.write_stderr(
                f'Usage: geai-orch xp {pattern.name} --task "your task here"'
            )
            return

        # Create agent
        agent_config = AgentConfig(name=f"{pattern.name}-agent", model=model)
        agent = GEAIAgent(config=agent_config)

        # Create pattern config
        pattern_config = PatternConfig(
            name=pattern.name,
            pattern_type=PatternType.CUSTOM,
            max_iterations=max_iterations,
        )

        # Instantiate pattern
        try:
            pattern_instance = pattern.pattern_class(
                agent=agent, config=pattern_config
            )
        except Exception as e:
            Console.write_stderr(f"Error initializing pattern: {e}")
            logger.error("Pattern initialization failed", exc_info=True)
            return

        # Execute
        async def run():
            try:
                result = await pattern_instance.execute(task)

                Console.write_stdout(f"\n{'=' * 80}")
                Console.write_stdout(
                    f"{pattern.name.upper().replace('-', ' ')} PATTERN RESULT"
                )
                Console.write_stdout(f"{'=' * 80}\n")

                if result.success:
                    Console.write_stdout(result.result)
                    Console.write_stdout(f"\n{'=' * 80}")
                    Console.write_stdout(f"Iterations: {result.iterations}")
                    Console.write_stdout("Success: [OK]")
                    Console.write_stdout(f"{'=' * 80}\n")
                else:
                    Console.write_stderr(f"\n{'=' * 80}")
                    Console.write_stderr("Error executing pattern:")
                    Console.write_stderr(result.error or "Unknown error")
                    Console.write_stderr(f"{'=' * 80}\n")

            except Exception as e:
                Console.write_stderr(f"\nError: {e}")
                logger.error("Pattern execution failed", exc_info=True)

        asyncio.run(run())

    return executor


def list_plugins_command():
    """List all discovered plugin patterns."""
    loader = PluginLoader()
    patterns = loader.discover_patterns()

    if not patterns:
        Console.write_stdout("No custom patterns found.\n")
        Console.write_stdout(f"Plugin directory: {loader.plugin_dir}\n")
        Console.write_stdout(f"Create it with: mkdir -p {loader.plugin_dir}\n")
        Console.write_stdout(
            "Then add your custom pattern files (*.py) to that directory.\n"
        )
        Console.write_stdout(
            "\nExample patterns are available in snippets/custom/\n"
        )
        Console.write_stdout(
            "Copy them with: cp snippets/custom/*.py ~/.geai-orch/plugins/\n"
        )
        return

    Console.write_stdout(f"\nCustom Patterns ({len(patterns)}):\n")
    Console.write_stdout("=" * 80)
    Console.write_stdout("")

    for pattern in patterns.values():
        Console.write_stdout(f"  {pattern.name}")
        Console.write_stdout(f"    Description: {pattern.description}")
        Console.write_stdout(f"    Class: {pattern.pattern_class.__name__}")
        Console.write_stdout(f"    Source: {pattern.source_file}")
        Console.write_stdout("")

    Console.write_stdout("=" * 80)
    Console.write_stdout(f"Plugin directory: {loader.plugin_dir}\n")


def plugin_info_command(options):
    """Show detailed info about a specific plugin."""
    pattern_name = None
    for opt, value in options:
        if opt.name in ["--name", "-n"]:
            pattern_name = value

    if not pattern_name:
        Console.write_stderr("Error: --name is required")
        Console.write_stderr("Usage: geai-orch plugins info --name <pattern-name>")
        return

    loader = PluginLoader()
    patterns = loader.discover_patterns()

    pattern = patterns.get(pattern_name)
    if not pattern:
        Console.write_stderr(f"Pattern '{pattern_name}' not found")
        Console.write_stderr("\nAvailable patterns:")
        for name in patterns.keys():
            Console.write_stderr(f"  - {name}")
        return

    Console.write_stdout(f"\nPattern: {pattern.name}")
    Console.write_stdout("=" * 80)
    Console.write_stdout(f"Class: {pattern.pattern_class.__name__}")
    Console.write_stdout(f"Description: {pattern.description}")
    Console.write_stdout(f"Source File: {pattern.source_file}")
    Console.write_stdout("")

    if pattern.pattern_class.__doc__:
        Console.write_stdout("Documentation:")
        Console.write_stdout("-" * 80)
        Console.write_stdout(pattern.pattern_class.__doc__)
        Console.write_stdout("-" * 80)

    Console.write_stdout("\nUsage:")
    Console.write_stdout(f'  geai-orch xp {pattern.name} --task "your task here"')
    Console.write_stdout(f'  geai-orch pattern {pattern.name} --task "..." --model openai/gpt-4o')
    Console.write_stdout(
        f'  geai-orch execute-pattern {pattern.name} --task "..." --max-iterations 10'
    )
    Console.write_stdout("")
