"""
CLI module for PyGEAI-Orchestration.

Provides the geai-orch command-line interface for orchestration patterns.
"""

__all__ = []
