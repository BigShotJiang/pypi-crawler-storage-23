"""
Error handling for the geai-orch CLI.
"""

from typing import List
from enum import IntEnum


class ExitCode(IntEnum):
    """Exit codes for the CLI."""

    SUCCESS = 0
    USER_INPUT_ERROR = 1
    MISSING_REQUIREMENT = 2
    SERVICE_ERROR = 3
    ORCHESTRATION_ERROR = 4
    KEYBOARD_INTERRUPT = 130
    UNEXPECTED_ERROR = 255


class ErrorHandler:
    """Handles error formatting and display for the CLI."""

    @staticmethod
    def format_error(title: str, message: str) -> str:
        """
        Format an error message with a title.

        :param title: str - Error title
        :param message: str - Error message
        :return: str - Formatted error message
        """
        return f"\n[ERROR] {title}\n{message}\n"

    @staticmethod
    def handle_unknown_command(arg: str, available_commands: List) -> str:
        """
        Handle unknown command error.

        :param arg: str - The unknown argument
        :param available_commands: List - List of available commands
        :return: str - Formatted error message
        """
        commands_str = ", ".join([cmd.name for cmd in available_commands])
        message = (
            f"'{arg}' is not a recognized command.\n\n"
            f"Available commands: {commands_str}\n\n"
            f"Use 'geai-orch help' for more information."
        )
        return ErrorHandler.format_error("Unknown Command", message)

    @staticmethod
    def handle_unknown_option(arg: str, available_options: List) -> str:
        """
        Handle unknown option error.

        :param arg: str - The unknown argument
        :param available_options: List - List of available options
        :return: str - Formatted error message
        """
        options_str = ", ".join(["/".join(opt.identifiers) for opt in available_options])
        message = (
            f"'{arg}' is not a recognized option.\n\n"
            f"Available options: {options_str}\n\n"
            f"Use 'geai-orch help' for more information."
        )
        return ErrorHandler.format_error("Unknown Option", message)

    @staticmethod
    def handle_wrong_argument(message: str, usage: str) -> str:
        """
        Handle wrong argument error.

        :param message: str - Error message
        :param usage: str - Usage information
        :return: str - Formatted error message
        """
        full_message = f"{message}\n\n{usage}"
        return ErrorHandler.format_error("Invalid Argument", full_message)

    @staticmethod
    def handle_missing_requirement(message: str) -> str:
        """
        Handle missing requirement error.

        :param message: str - Error message
        :return: str - Formatted error message
        """
        return ErrorHandler.format_error("Missing Requirement", message)

    @staticmethod
    def handle_orchestration_error(message: str) -> str:
        """
        Handle orchestration-specific errors.

        :param message: str - Error message
        :return: str - Formatted error message
        """
        return ErrorHandler.format_error("Orchestration Error", message)

    @staticmethod
    def handle_keyboard_interrupt() -> str:
        """
        Handle keyboard interrupt (Ctrl+C).

        :return: str - Formatted message
        """
        return "\n\n[WARNING] Operation cancelled by user.\n"

    @staticmethod
    def handle_unexpected_error(exception: Exception) -> str:
        """
        Handle unexpected errors.

        :param exception: Exception - The exception that occurred
        :return: str - Formatted error message
        """
        message = (
            f"An unexpected error occurred: {str(exception)}\n\n"
            f"Please report this issue at:\n"
            f"https://github.com/genexus-books/pygeai-orchestration/issues"
        )
        return ErrorHandler.format_error("Unexpected Error", message)
