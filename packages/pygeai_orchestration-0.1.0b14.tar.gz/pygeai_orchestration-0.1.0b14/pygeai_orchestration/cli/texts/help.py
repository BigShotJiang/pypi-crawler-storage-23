"""
Help text for the geai-orch CLI.
"""

CLI_USAGE = """
geai-orch - Agentic AI Orchestration CLI for Globant Enterprise AI

USAGE:
    geai-orch [OPTIONS] <COMMAND> [ARGS]

OPTIONS:
    -a, --alias <ALIAS>         Use a specific credentials profile
    --credentials <FILE>        Path to custom credentials file
    -v, --verbose              Enable verbose logging
    -h, --help                 Show help information

COMMANDS:
    help, h                    Show help information
    version, v                 Show version information
    
    execute-pattern (xp, pattern)  Execute orchestration patterns
        reflection             Iterative self-improvement pattern
        react                  Reasoning and acting pattern
        planning               Task planning and decomposition
        tool-use               Tool-augmented execution
        multi-agent            Multi-agent collaboration
    
    plugins                    Manage custom pattern plugins
        list                   List installed plugins
        install                Install a plugin
    
    tools                      Manage and inspect builtin tools
        list                   List all available tools

EXAMPLES:
    # Show help
    geai-orch help

    # Show version
    geai-orch version

    # List all available builtin tools
    geai-orch tools list

    # Run reflection pattern
    geai-orch execute-pattern reflection -m openai/gpt-4o-mini -t "Improve this text" -i 3

    # Execute ReAct pattern (using alias)
    geai-orch xp react -m openai/gpt-4o-mini -t "Solve complex problem" --max-steps 10

    # Run planning pattern (using alias)
    geai-orch pattern planning -m openai/gpt-4o-mini -t "Create project plan"

    # Tool-use pattern with specific tools
    geai-orch xp tool-use -m openai/gpt-4o-mini -t "Calculate statistics" --tools MathCalculatorTool

    # Multi-agent collaboration
    geai-orch xp multi-agent -m openai/gpt-4o-mini -t "Collaborative task" -c agents.json

    # Use specific credentials profile
    geai-orch --alias production xp reflection -m openai/gpt-4o-mini -t "Task"

    # Verbose output with metadata
    geai-orch xp reflection -m openai/gpt-4o-mini -t "Task" --verbose

"""

VERSION_TEXT = """
geai-orch version {version}
PyGEAI-Orchestration - Agentic AI Orchestration Patterns

Copyright © 2026 Globant
Licensed under the MIT License
"""

HELP_REFLECTION = """
reflection - Run reflection pattern for iterative improvement

USAGE:
    geai-orch execute-pattern reflection [OPTIONS]
    geai-orch xp reflection [OPTIONS]
    geai-orch pattern reflection [OPTIONS]

REQUIRED OPTIONS:
    -m, --model <NAME>         Model name (e.g., openai/gpt-4o-mini)
    -t, --task <TEXT>          Task or text to improve

OPTIONAL OPTIONS:
    -i, --iterations <N>       Number of reflection iterations (default: 3)
    --temperature <N>          Temperature for generation (0.0-2.0, default: 0.7)
    --system-prompt <TEXT>     System prompt for agent
    --max-tokens <N>           Maximum tokens for generation (default: 4096)
    -o, --output <FILE>        Output file for results
    --verbose                  Show detailed output with metadata

DESCRIPTION:
    The reflection pattern enables agents to self-critique and iteratively
    improve their outputs through multiple reflection cycles.

EXAMPLES:
    geai-orch xp reflection -m openai/gpt-4o-mini -t "Write a summary" -i 5
    geai-orch pattern reflection -m openai/gpt-4o-mini -t "Improve this code" -o result.txt --verbose
"""

HELP_TOOL_USE = """
tool-use - Execute tool use pattern with function calling

USAGE:
    geai-orch execute-pattern tool-use [OPTIONS]
    geai-orch xp tool-use [OPTIONS]
    geai-orch pattern tool-use [OPTIONS]

REQUIRED OPTIONS:
    -m, --model <NAME>         Model name (e.g., openai/gpt-4o-mini)
    -t, --task <TEXT>          Task description

OPTIONAL OPTIONS:
    --tools <NAMES>            Comma-separated tool names to use
    -i, --iterations <N>       Maximum iterations (default: 10)
    --temperature <N>          Temperature for generation (0.0-2.0, default: 0.7)
    --system-prompt <TEXT>     System prompt for agent
    --max-tokens <N>           Maximum tokens for generation (default: 4096)
    -o, --output <FILE>        Output file for results
    --verbose                  Show detailed output with metadata

DESCRIPTION:
    The tool use pattern integrates function calling and external tool
    execution into agent workflows.

EXAMPLES:
    geai-orch xp tool-use -m openai/gpt-4o-mini -t "Search for info" --tools URLFetchTool,JSONParserTool
    geai-orch pattern tool-use -m openai/gpt-4o-mini -t "Execute calculation" --tools MathCalculatorTool
"""

HELP_REACT = """
react - Run ReAct (Reasoning + Acting) pattern

USAGE:
    geai-orch execute-pattern react [OPTIONS]
    geai-orch xp react [OPTIONS]
    geai-orch pattern react [OPTIONS]

REQUIRED OPTIONS:
    -m, --model <NAME>         Model name (e.g., openai/gpt-4o-mini)
    -t, --task <TEXT>          Task to solve

OPTIONAL OPTIONS:
    --max-steps <N>            Maximum reasoning-acting steps (default: 10)
    --temperature <N>          Temperature for generation (0.0-2.0, default: 0.7)
    --system-prompt <TEXT>     System prompt for agent
    --max-tokens <N>           Maximum tokens for generation (default: 4096)
    -o, --output <FILE>        Output file for results
    --verbose                  Show detailed reasoning trace with metadata

DESCRIPTION:
    The ReAct pattern implements a Reasoning + Acting loop for step-by-step
    problem solving with explicit reasoning traces.

EXAMPLES:
    geai-orch xp react -m openai/gpt-4o-mini -t "Research topic" --max-steps 15
    geai-orch pattern react -m openai/gpt-4o-mini -t "Multi-step problem" --verbose
"""

HELP_PLANNING = """
planning - Execute planning pattern for multi-step tasks

USAGE:
    geai-orch execute-pattern planning [OPTIONS]
    geai-orch xp planning [OPTIONS]
    geai-orch pattern planning [OPTIONS]

REQUIRED OPTIONS:
    -m, --model <NAME>         Model name (e.g., openai/gpt-4o-mini)
    -t, --task <TEXT>          Task to plan and execute

OPTIONAL OPTIONS:
    --temperature <N>          Temperature for generation (0.0-2.0, default: 0.7)
    --system-prompt <TEXT>     System prompt for agent
    --max-tokens <N>           Maximum tokens for generation (default: 4096)
    -o, --output <FILE>        Output file for results
    --verbose                  Show detailed execution trace with metadata

DESCRIPTION:
    The planning pattern creates and executes multi-step plans with
    adaptive execution and progress tracking.

EXAMPLES:
    geai-orch xp planning -m openai/gpt-4o-mini -t "Build web app"
    geai-orch pattern planning -m openai/gpt-4o-mini -t "Complex project" --verbose
"""

HELP_MULTI_AGENT = """
multi-agent - Run multi-agent coordination pattern

USAGE:
    geai-orch execute-pattern multi-agent [OPTIONS]
    geai-orch xp multi-agent [OPTIONS]
    geai-orch pattern multi-agent [OPTIONS]

REQUIRED OPTIONS:
    -m, --model <NAME>         Model name (e.g., openai/gpt-4o-mini)
    -t, --task <TEXT>          Task for agents to collaborate on
    -c, --config <FILE>        Agent configuration file (JSON)

OPTIONAL OPTIONS:
    --temperature <N>          Temperature for generation (0.0-2.0, default: 0.7)
    --system-prompt <TEXT>     System prompt for coordinator agent
    --max-tokens <N>           Maximum tokens for generation (default: 4096)
    -o, --output <FILE>        Output file for results
    --verbose                  Show agent communication details with metadata

DESCRIPTION:
    The multi-agent pattern coordinates multiple agents working
    collaboratively on complex tasks with defined roles.

CONFIG FILE FORMAT (JSON):
    {
      "coordinator": {"name": "coordinator", "model": "openai/gpt-4o-mini"},
      "agents": [
        {"name": "researcher", "role": "researcher", "model": "openai/gpt-4o-mini"},
        {"name": "writer", "role": "writer", "model": "openai/gpt-4o-mini"}
      ]
    }

EXAMPLES:
    geai-orch xp multi-agent -m openai/gpt-4o-mini -t "Research report" -c agents.json
    geai-orch pattern multi-agent -m openai/gpt-4o-mini -t "Complex analysis" -c team.json --verbose
"""

HELP_PLUGINS = """
plugins - Manage custom pattern plugins

USAGE:
    geai-orch plugins <SUBCOMMAND> [OPTIONS]

SUBCOMMANDS:
    help                       Show this help message
    list, ls                   List all discovered custom patterns
    info                       Show detailed info about a pattern

OPTIONS:
    --name, -n <NAME>          Pattern name (for info command)

DESCRIPTION:
    Manage and inspect custom orchestration pattern plugins. Plugins are
    discovered automatically from the plugins directory and can extend
    the CLI with new pattern commands.

EXAMPLES:
    geai-orch plugins list
    geai-orch plugins info --name debate
    geai-orch plugins help
"""

HELP_TOOLS = """
tools - Manage and inspect built-in tools

USAGE:
    geai-orch tools <SUBCOMMAND> [OPTIONS]

SUBCOMMANDS:
    help                       Show this help message
    list, ls                   List all available built-in tools
    info                       Show detailed info about a specific tool

OPTIONS:
    --category, -c <CAT>       Filter tools by category (for list command)
    --name, -n <NAME>          Tool name (for info command)

DESCRIPTION:
    Inspect and explore the built-in tools available for orchestration
    patterns. Tools can be filtered by category or examined individually
    for detailed information.

CATEGORIES:
    math_tools                 Mathematical operations
    file_tools                 File system operations
    web_tools                  Web scraping and HTTP requests
    data_tools                 Data processing and transformation

EXAMPLES:
    geai-orch tools list
    geai-orch tools list --category math_tools
    geai-orch tools info --name MathCalculatorTool
    geai-orch tools help
"""
