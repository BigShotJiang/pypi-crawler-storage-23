"""
Tool registry for discovering and managing available tools.

This module provides a centralized registry for tool discovery, registration,
and retrieval, enabling dynamic tool management in orchestration patterns.
"""

from typing import Dict, List, Optional, Type
from pygeai_orchestration.core.base.tool import BaseTool, ToolCategory


class ToolRegistry:
    """
    Registry for managing and discovering tools.
    
    The ToolRegistry provides a centralized location for:
    - Registering new tools
    - Discovering available tools
    - Filtering tools by category
    - Retrieving tool instances by name
    
    Example:
        >>> registry = ToolRegistry()
        >>> registry.register(FileReaderTool)
        >>> tool = registry.get_tool("file_reader")
        >>> all_tools = registry.list_tools()
    """
    
    def __init__(self):
        """Initialize the tool registry."""
        self._tools: Dict[str, Type[BaseTool]] = {}
        self._instances: Dict[str, BaseTool] = {}
    
    def register(self, tool_class: Type[BaseTool], name: Optional[str] = None) -> None:
        """
        Register a tool class in the registry.
        
        :param tool_class: The tool class to register (must inherit from BaseTool)
        :param name: Optional custom name for the tool. If not provided, uses tool's config name.
        :raises ValueError: If tool_class is not a BaseTool subclass
        """
        if not issubclass(tool_class, BaseTool):
            raise ValueError(f"{tool_class.__name__} must inherit from BaseTool")
        
        # Create temporary instance to get the name if not provided
        if name is None:
            temp_instance = tool_class()
            name = temp_instance.name
        
        self._tools[name] = tool_class
    
    def register_instance(self, tool_instance: BaseTool) -> None:
        """
        Register a tool instance directly.
        
        :param tool_instance: An instantiated tool object
        :raises ValueError: If tool_instance is not a BaseTool instance
        """
        if not isinstance(tool_instance, BaseTool):
            raise ValueError(f"{tool_instance} must be an instance of BaseTool")
        
        name = tool_instance.name
        self._instances[name] = tool_instance
        self._tools[name] = type(tool_instance)
    
    def get_tool(self, name: str, create_new: bool = False) -> Optional[BaseTool]:
        """
        Get a tool instance by name.
        
        :param name: The name of the tool to retrieve
        :param create_new: If True, creates a new instance. Otherwise returns cached instance.
        :return: Tool instance or None if not found
        """
        if name not in self._tools:
            return None
        
        if create_new or name not in self._instances:
            self._instances[name] = self._tools[name]()
        
        return self._instances[name]
    
    def list_tools(self, category: Optional[ToolCategory] = None) -> List[str]:
        """
        List all registered tool names, optionally filtered by category.
        
        :param category: Optional category filter
        :return: List of tool names
        """
        if category is None:
            return list(self._tools.keys())
        
        # Filter by category
        filtered = []
        for name in self._tools.keys():
            tool = self.get_tool(name)
            if tool and tool.category == category:
                filtered.append(name)
        
        return filtered
    
    def get_all_tools(self, category: Optional[ToolCategory] = None) -> List[BaseTool]:
        """
        Get all tool instances, optionally filtered by category.
        
        :param category: Optional category filter
        :return: List of tool instances
        """
        tool_names = self.list_tools(category)
        return [self.get_tool(name) for name in tool_names if self.get_tool(name) is not None]
    
    def get_tool_schema(self, name: str) -> Optional[Dict]:
        """
        Get the schema for a specific tool.
        
        :param name: Tool name
        :return: Tool schema dictionary or None if not found
        """
        tool = self.get_tool(name)
        return tool.get_schema() if tool else None
    
    def unregister(self, name: str) -> bool:
        """
        Remove a tool from the registry.
        
        :param name: Name of the tool to remove
        :return: True if tool was removed, False if not found
        """
        if name in self._tools:
            del self._tools[name]
            if name in self._instances:
                del self._instances[name]
            return True
        return False
    
    def clear(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()
        self._instances.clear()


# Global registry instance
_global_registry = ToolRegistry()


def get_registry() -> ToolRegistry:
    """
    Get the global tool registry instance.
    
    :return: The global ToolRegistry instance
    """
    return _global_registry


def register_builtin_tools() -> None:
    """
    Register all built-in tools with the global registry.
    
    This function discovers and registers all tools from the builtin module.
    Called automatically when importing from pygeai_orchestration.tools.
    """
    # Import will be implemented as we add tools
    # For now, this is a placeholder for auto-registration
    pass
