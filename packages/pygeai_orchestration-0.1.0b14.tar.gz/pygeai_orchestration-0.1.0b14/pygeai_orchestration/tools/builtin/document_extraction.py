"""
Document extraction tools for pygeai-orchestration.

Provides tools for:
- PDF text extraction
- PDF metadata extraction
- Page-specific extraction
"""

from typing import Any, Dict, Optional
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time

try:
    import PyPDF2
    PYPDF2_AVAILABLE = True
    PdfReader = PyPDF2.PdfReader
except ImportError:
    PYPDF2_AVAILABLE = False
    PdfReader = Any


class PDFReaderTool(BaseTool):
    """
    Extract text and metadata from PDF files.
    
    Requires: PyPDF2
    
    Features:
    - Extract all text from PDF
    - Extract specific pages
    - Get PDF metadata (title, author, page count)
    - Get page count
    """
    
    def __init__(self):
        config = ToolConfig(
            name="pdf_reader",
            description="Extract text, metadata, and information from PDF files",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "pdf_file": {
                        "type": "string",
                        "description": "Path to PDF file"
                    },
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["extract_text", "extract_page", "metadata", "page_count"],
                        "default": "extract_text"
                    },
                    "page_number": {
                        "type": "integer",
                        "description": "Specific page number to extract (0-based)",
                        "minimum": 0
                    },
                    "start_page": {
                        "type": "integer",
                        "description": "Start page for range extraction (0-based)",
                        "minimum": 0
                    },
                    "end_page": {
                        "type": "integer",
                        "description": "End page for range extraction (0-based, exclusive)",
                        "minimum": 0
                    }
                },
                "required": ["pdf_file"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if not PYPDF2_AVAILABLE:
            return False
        
        if "pdf_file" not in parameters:
            return False
        
        operation = parameters.get("operation", "extract_text")
        if operation == "extract_page" and "page_number" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute PDF extraction."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not PYPDF2_AVAILABLE:
                    error_msg = "PyPDF2 library not installed"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            pdf_file = kwargs["pdf_file"]
            operation = kwargs.get("operation", "extract_text")
            
            with open(pdf_file, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                
                if operation == "page_count":
                    result = len(reader.pages)
                elif operation == "metadata":
                    result = self._extract_metadata(reader)
                elif operation == "extract_page":
                    page_number = kwargs["page_number"]
                    result = self._extract_page(reader, page_number)
                elif operation == "extract_text":
                    start_page = kwargs.get("start_page", 0)
                    end_page = kwargs.get("end_page", len(reader.pages))
                    result = self._extract_text(reader, start_page, end_page)
                else:
                    return ToolResult(
                        success=False,
                        error=f"Unknown operation: {operation}",
                        execution_time=time.time() - start
                    )
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation}
            )
            
        except FileNotFoundError:
            return ToolResult(
                success=False,
                error=f"PDF file not found: {pdf_file}",
                execution_time=time.time() - start
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _extract_metadata(self, reader: Any) -> Dict[str, Any]:
        """Extract PDF metadata."""
        metadata = reader.metadata
        
        result = {
            "page_count": len(reader.pages),
            "title": metadata.get("/Title") if metadata else None,
            "author": metadata.get("/Author") if metadata else None,
            "subject": metadata.get("/Subject") if metadata else None,
            "creator": metadata.get("/Creator") if metadata else None,
            "producer": metadata.get("/Producer") if metadata else None,
        }
        
        return result
    
    def _extract_page(self, reader: Any, page_number: int) -> str:
        """Extract text from a specific page."""
        if page_number >= len(reader.pages):
            raise ValueError(f"Page {page_number} does not exist (total pages: {len(reader.pages)})")
        
        page = reader.pages[page_number]
        return page.extract_text()
    
    def _extract_text(self, reader: Any, start_page: int, end_page: int) -> str:
        """Extract text from a range of pages."""
        text_parts = []
        
        actual_end = min(end_page, len(reader.pages))
        
        for page_num in range(start_page, actual_end):
            page = reader.pages[page_num]
            text_parts.append(page.extract_text())
        
        return "\n\n".join(text_parts)
