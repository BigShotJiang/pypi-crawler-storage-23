"""
Image processing tools for pygeai-orchestration.

Provides tools for:
- Image manipulation (resize, crop, rotate, etc.)
- Format conversion
- Image information extraction
"""

from typing import Any, Dict, Tuple, Optional
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time
import base64
import io

try:
    from PIL import Image, ImageOps, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


class ImageProcessorTool(BaseTool):
    """
    Image processing and manipulation tool.
    
    Requires: Pillow (PIL)
    
    Supports operations:
    - info: Get image information (size, format, mode)
    - resize: Resize image to specific dimensions
    - crop: Crop image to region
    - rotate: Rotate image by degrees
    - flip: Flip horizontally or vertically
    - convert: Convert image format
    - thumbnail: Create thumbnail
    - grayscale: Convert to grayscale
    - blur: Apply blur filter
    - sharpen: Apply sharpen filter
    """
    
    def __init__(self):
        config = ToolConfig(
            name="image_processor",
            description="Process and manipulate images: resize, crop, rotate, convert formats, apply filters",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["info", "resize", "crop", "rotate", "flip", "convert", 
                                "thumbnail", "grayscale", "blur", "sharpen"]
                    },
                    "image_path": {
                        "type": "string",
                        "description": "Path to input image file"
                    },
                    "image_data": {
                        "type": "string",
                        "description": "Base64-encoded image data (alternative to image_path)"
                    },
                    "output_path": {
                        "type": "string",
                        "description": "Path to output image file"
                    },
                    "width": {
                        "type": "integer",
                        "description": "Target width for resize/thumbnail"
                    },
                    "height": {
                        "type": "integer",
                        "description": "Target height for resize/thumbnail"
                    },
                    "box": {
                        "type": "array",
                        "description": "Crop box [left, top, right, bottom]",
                        "items": {"type": "integer"}
                    },
                    "angle": {
                        "type": "number",
                        "description": "Rotation angle in degrees"
                    },
                    "direction": {
                        "type": "string",
                        "description": "Flip direction: 'horizontal' or 'vertical'",
                        "enum": ["horizontal", "vertical"]
                    },
                    "format": {
                        "type": "string",
                        "description": "Output image format (JPEG, PNG, etc.)"
                    },
                    "maintain_aspect": {
                        "type": "boolean",
                        "description": "Maintain aspect ratio for resize",
                        "default": True
                    },
                    "return_base64": {
                        "type": "boolean",
                        "description": "Return image as base64 string",
                        "default": False
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if not PIL_AVAILABLE:
            return False
        
        if "operation" not in parameters:
            return False
        
        operation = parameters["operation"]
        valid_ops = ["info", "resize", "crop", "rotate", "flip", "convert", 
                    "thumbnail", "grayscale", "blur", "sharpen"]
        
        if operation not in valid_ops:
            return False
        
        if "image_path" not in parameters and "image_data" not in parameters:
            return False
        
        if operation in ["resize", "thumbnail"] and ("width" not in parameters or "height" not in parameters):
            return False
        
        if operation == "crop" and "box" not in parameters:
            return False
        
        if operation == "rotate" and "angle" not in parameters:
            return False
        
        if operation == "flip" and "direction" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute image processing operation."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not PIL_AVAILABLE:
                    error_msg = "Pillow (PIL) not installed"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            
            img = self._load_image(kwargs)
            
            if operation == "info":
                result = self._get_info(img)
            elif operation == "resize":
                result = self._resize(img, kwargs)
            elif operation == "crop":
                result = self._crop(img, kwargs)
            elif operation == "rotate":
                result = self._rotate(img, kwargs)
            elif operation == "flip":
                result = self._flip(img, kwargs)
            elif operation == "convert":
                result = self._convert(img, kwargs)
            elif operation == "thumbnail":
                result = self._thumbnail(img, kwargs)
            elif operation == "grayscale":
                result = self._grayscale(img, kwargs)
            elif operation == "blur":
                result = self._blur(img, kwargs)
            elif operation == "sharpen":
                result = self._sharpen(img, kwargs)
            else:
                return ToolResult(
                    success=False,
                    error=f"Unknown operation: {operation}",
                    execution_time=time.time() - start
                )
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _load_image(self, params: Dict[str, Any]) -> Image.Image:
        """Load image from path or base64 data."""
        if "image_path" in params:
            return Image.open(params["image_path"])
        else:
            image_data = base64.b64decode(params["image_data"])
            return Image.open(io.BytesIO(image_data))
    
    def _save_or_encode(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Save image to file or return as base64."""
        if params.get("return_base64", False):
            buffer = io.BytesIO()
            fmt = params.get("format", img.format or "PNG")
            img.save(buffer, format=fmt)
            return base64.b64encode(buffer.getvalue()).decode()
        else:
            output_path = params.get("output_path")
            if output_path:
                fmt = params.get("format")
                if fmt:
                    img.save(output_path, format=fmt)
                else:
                    img.save(output_path)
                return {"saved": True, "path": output_path}
            else:
                return {"warning": "No output_path or return_base64 specified"}
    
    def _get_info(self, img: Image.Image) -> Dict[str, Any]:
        """Get image information."""
        return {
            "width": img.width,
            "height": img.height,
            "format": img.format,
            "mode": img.mode,
            "size_bytes": len(img.tobytes()) if hasattr(img, 'tobytes') else None
        }
    
    def _resize(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Resize image."""
        width = params["width"]
        height = params["height"]
        maintain_aspect = params.get("maintain_aspect", True)
        
        if maintain_aspect:
            img.thumbnail((width, height), Image.Resampling.LANCZOS)
        else:
            img = img.resize((width, height), Image.Resampling.LANCZOS)
        
        return self._save_or_encode(img, params)
    
    def _crop(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Crop image."""
        box = tuple(params["box"])
        img = img.crop(box)
        return self._save_or_encode(img, params)
    
    def _rotate(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Rotate image."""
        angle = params["angle"]
        img = img.rotate(angle, expand=True)
        return self._save_or_encode(img, params)
    
    def _flip(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Flip image."""
        direction = params["direction"]
        if direction == "horizontal":
            img = ImageOps.mirror(img)
        else:
            img = ImageOps.flip(img)
        return self._save_or_encode(img, params)
    
    def _convert(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Convert image format."""
        return self._save_or_encode(img, params)
    
    def _thumbnail(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Create thumbnail."""
        width = params["width"]
        height = params["height"]
        img.thumbnail((width, height), Image.Resampling.LANCZOS)
        return self._save_or_encode(img, params)
    
    def _grayscale(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Convert to grayscale."""
        img = ImageOps.grayscale(img)
        return self._save_or_encode(img, params)
    
    def _blur(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Apply blur filter."""
        img = img.filter(ImageFilter.BLUR)
        return self._save_or_encode(img, params)
    
    def _sharpen(self, img: Image.Image, params: Dict[str, Any]) -> Any:
        """Apply sharpen filter."""
        img = img.filter(ImageFilter.SHARPEN)
        return self._save_or_encode(img, params)
