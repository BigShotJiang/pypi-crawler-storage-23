"""
Built-in tools for pygeai-orchestration.

This module provides a comprehensive set of ready-to-use tools for common tasks:
- File operations (read, write, search, list)
- Data processing (JSON, YAML, CSV, XML, DataFrames)
- Text processing (regex, formatting, templates)
- Web tools (URL fetch, HTML parsing, BeautifulSoup)
- Image processing (resize, crop, format conversion)
- Document workflows (PDF, DOCX, Markdown generation and extraction)
- System utilities (command execution, datetime, environment)
- GEAI-powered tools (OmniParser, embeddings, reranking)

All tools inherit from BaseTool and follow consistent patterns for
configuration, validation, and execution.
"""

from typing import Any, Dict
from pygeai_orchestration.core.base.tool import ToolResult


class ValidationError(Exception):
    """Raised when parameter validation fails."""
    pass


class ToolExecutionError(Exception):
    """Raised when tool execution encounters an error."""
    pass


def validate_required_params(params: Dict[str, Any], required: list) -> bool:
    """
    Validate that all required parameters are present.
    
    :param params: Parameter dictionary to validate
    :param required: List of required parameter names
    :return: True if all required params present
    :raises ValidationError: If any required parameter is missing
    """
    missing = [key for key in required if key not in params]
    if missing:
        raise ValidationError(f"Missing required parameters: {', '.join(missing)}")
    return True


def create_error_result(error: Exception, execution_time: float = 0.0) -> ToolResult:
    """
    Create a standardized error ToolResult.
    
    :param error: The exception that occurred
    :param execution_time: Time taken before error occurred
    :return: ToolResult with error information
    """
    return ToolResult(
        success=False,
        error=str(error),
        execution_time=execution_time
    )


def create_success_result(result: Any, execution_time: float, metadata: Dict[str, Any] = None) -> ToolResult:
    """
    Create a standardized success ToolResult.
    
    :param result: The successful result data
    :param execution_time: Time taken to execute
    :param metadata: Optional additional metadata
    :return: ToolResult with success information
    """
    return ToolResult(
        success=True,
        result=result,
        execution_time=execution_time,
        metadata=metadata or {}
    )


__all__ = [
    "ValidationError",
    "ToolExecutionError",
    "validate_required_params",
    "create_error_result",
    "create_success_result",
]
