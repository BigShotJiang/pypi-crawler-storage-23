"""
Utility tools for pygeai-orchestration.

Provides tools for:
- Archive creation/extraction (ZIP, TAR)
- Hashing (MD5, SHA256, SHA512)
- Encoding/decoding (Base64, URL)
- Text diffing
- Code block extraction
- Network utilities (ping, DNS, port check)
- UUID generation
- SQLite operations
- Email sending
- Config file parsing (INI, YAML, TOML)
- Validation (JSON, email, URL, regex)
"""

from typing import Any, Dict, List, Optional, Union
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time
import hashlib
import base64
import urllib.parse
import difflib
import re
import uuid
import sqlite3
import json
import configparser
import io
from pathlib import Path

try:
    import zipfile
    import tarfile
    ARCHIVE_AVAILABLE = True
except ImportError:
    ARCHIVE_AVAILABLE = False

try:
    import socket
    SOCKET_AVAILABLE = True
except ImportError:
    SOCKET_AVAILABLE = False

try:
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    EMAIL_AVAILABLE = True
except ImportError:
    EMAIL_AVAILABLE = False

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    import tomli
    TOML_AVAILABLE = True
except ImportError:
    try:
        import tomllib
        TOML_AVAILABLE = True
        tomli = tomllib
    except ImportError:
        TOML_AVAILABLE = False


class ArchiveTool(BaseTool):
    """
    Create and extract ZIP and TAR archives.
    
    Supports:
    - ZIP and TAR formats
    - Compression (gzip, bzip2 for TAR)
    - List archive contents
    - Extract to specific directory
    """
    
    def __init__(self):
        config = ToolConfig(
            name="archive",
            description="Create and extract ZIP/TAR archives",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["create", "extract", "list"],
                        "default": "create"
                    },
                    "archive_path": {
                        "type": "string",
                        "description": "Path to archive file"
                    },
                    "format": {
                        "type": "string",
                        "description": "Archive format",
                        "enum": ["zip", "tar", "tar.gz", "tar.bz2"],
                        "default": "zip"
                    },
                    "source_path": {
                        "type": "string",
                        "description": "Source file/directory for create operation"
                    },
                    "extract_path": {
                        "type": "string",
                        "description": "Destination directory for extract operation"
                    }
                },
                "required": ["archive_path"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if not ARCHIVE_AVAILABLE:
            return False
        if "archive_path" not in parameters:
            return False
        operation = parameters.get("operation", "create")
        if operation == "create" and "source_path" not in parameters:
            return False
        if operation == "extract" and "extract_path" not in parameters:
            return False
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not ARCHIVE_AVAILABLE:
                    error_msg = "Archive libraries not available"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            operation = kwargs.get("operation", "create")
            archive_path = kwargs["archive_path"]
            format_type = kwargs.get("format", "zip")
            
            if operation == "create":
                result = self._create_archive(
                    archive_path,
                    kwargs["source_path"],
                    format_type
                )
            elif operation == "extract":
                result = self._extract_archive(
                    archive_path,
                    kwargs["extract_path"],
                    format_type
                )
            elif operation == "list":
                result = self._list_archive(archive_path, format_type)
            else:
                return ToolResult(
                    success=False,
                    error=f"Unknown operation: {operation}",
                    execution_time=time.time() - start
                )
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation, "format": format_type}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _create_archive(self, archive_path: str, source_path: str, format_type: str) -> str:
        source = Path(source_path)
        
        if format_type == "zip":
            with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                if source.is_file():
                    zf.write(source, source.name)
                else:
                    for file in source.rglob('*'):
                        if file.is_file():
                            zf.write(file, file.relative_to(source.parent))
        else:
            mode = 'w:gz' if format_type == 'tar.gz' else 'w:bz2' if format_type == 'tar.bz2' else 'w'
            with tarfile.open(archive_path, mode) as tf:
                tf.add(source, arcname=source.name)
        
        return f"Archive created: {archive_path}"
    
    def _extract_archive(self, archive_path: str, extract_path: str, format_type: str) -> str:
        Path(extract_path).mkdir(parents=True, exist_ok=True)
        
        if format_type == "zip":
            with zipfile.ZipFile(archive_path, 'r') as zf:
                zf.extractall(extract_path)
        else:
            with tarfile.open(archive_path, 'r:*') as tf:
                tf.extractall(extract_path)
        
        return f"Archive extracted to: {extract_path}"
    
    def _list_archive(self, archive_path: str, format_type: str) -> List[str]:
        if format_type == "zip":
            with zipfile.ZipFile(archive_path, 'r') as zf:
                return zf.namelist()
        else:
            with tarfile.open(archive_path, 'r:*') as tf:
                return tf.getnames()


class HashTool(BaseTool):
    """
    Generate cryptographic hashes.
    
    Supports:
    - MD5, SHA1, SHA256, SHA512
    - File hashing
    - String hashing
    """
    
    def __init__(self):
        config = ToolConfig(
            name="hash",
            description="Generate cryptographic hashes (MD5, SHA256, SHA512)",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "data": {
                        "type": "string",
                        "description": "Data to hash (string or file path)"
                    },
                    "algorithm": {
                        "type": "string",
                        "description": "Hash algorithm",
                        "enum": ["md5", "sha1", "sha256", "sha512"],
                        "default": "sha256"
                    },
                    "is_file": {
                        "type": "boolean",
                        "description": "Whether data is a file path",
                        "default": False
                    }
                },
                "required": ["data"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "data" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            data = kwargs["data"]
            algorithm = kwargs.get("algorithm", "sha256")
            is_file = kwargs.get("is_file", False)
            
            hash_obj = hashlib.new(algorithm)
            
            if is_file:
                with open(data, 'rb') as f:
                    while chunk := f.read(8192):
                        hash_obj.update(chunk)
            else:
                hash_obj.update(data.encode('utf-8'))
            
            result = hash_obj.hexdigest()
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"algorithm": algorithm, "is_file": is_file}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class EncodingTool(BaseTool):
    """
    Encode and decode data.
    
    Supports:
    - Base64 encoding/decoding
    - URL encoding/decoding
    - Hex encoding/decoding
    """
    
    def __init__(self):
        config = ToolConfig(
            name="encoding",
            description="Encode and decode data (Base64, URL, Hex)",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "data": {
                        "type": "string",
                        "description": "Data to encode/decode"
                    },
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["encode", "decode"],
                        "default": "encode"
                    },
                    "encoding": {
                        "type": "string",
                        "description": "Encoding type",
                        "enum": ["base64", "url", "hex"],
                        "default": "base64"
                    }
                },
                "required": ["data"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "data" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            data = kwargs["data"]
            operation = kwargs.get("operation", "encode")
            encoding = kwargs.get("encoding", "base64")
            
            if encoding == "base64":
                if operation == "encode":
                    result = base64.b64encode(data.encode()).decode()
                else:
                    result = base64.b64decode(data).decode()
            elif encoding == "url":
                if operation == "encode":
                    result = urllib.parse.quote(data)
                else:
                    result = urllib.parse.unquote(data)
            elif encoding == "hex":
                if operation == "encode":
                    result = data.encode().hex()
                else:
                    result = bytes.fromhex(data).decode()
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation, "encoding": encoding}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class DiffTool(BaseTool):
    """
    Compare text and generate diffs.
    
    Supports:
    - Unified diff format
    - Context diff format
    - Line-by-line comparison
    """
    
    def __init__(self):
        config = ToolConfig(
            name="diff",
            description="Compare text and generate diffs",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "text1": {
                        "type": "string",
                        "description": "First text to compare"
                    },
                    "text2": {
                        "type": "string",
                        "description": "Second text to compare"
                    },
                    "format": {
                        "type": "string",
                        "description": "Diff format",
                        "enum": ["unified", "context", "ndiff"],
                        "default": "unified"
                    },
                    "context_lines": {
                        "type": "integer",
                        "description": "Number of context lines",
                        "default": 3,
                        "minimum": 0
                    }
                },
                "required": ["text1", "text2"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "text1" in parameters and "text2" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            text1 = kwargs["text1"].splitlines(keepends=True)
            text2 = kwargs["text2"].splitlines(keepends=True)
            format_type = kwargs.get("format", "unified")
            context_lines = kwargs.get("context_lines", 3)
            
            if format_type == "unified":
                diff = difflib.unified_diff(text1, text2, n=context_lines)
            elif format_type == "context":
                diff = difflib.context_diff(text1, text2, n=context_lines)
            elif format_type == "ndiff":
                diff = difflib.ndiff(text1, text2)
            
            result = ''.join(diff)
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"format": format_type}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class CodeBlockExtractorTool(BaseTool):
    """
    Extract code blocks from markdown or text.
    
    Supports:
    - Fenced code blocks (```)
    - Indented code blocks
    - Language-specific extraction
    """
    
    def __init__(self):
        config = ToolConfig(
            name="code_block_extractor",
            description="Extract code blocks from markdown or text",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Text containing code blocks"
                    },
                    "language": {
                        "type": "string",
                        "description": "Filter by language (optional)"
                    },
                    "include_metadata": {
                        "type": "boolean",
                        "description": "Include language and line number metadata",
                        "default": False
                    }
                },
                "required": ["text"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "text" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            text = kwargs["text"]
            language = kwargs.get("language")
            include_metadata = kwargs.get("include_metadata", False)
            
            code_blocks = self._extract_code_blocks(text, language, include_metadata)
            
            return ToolResult(
                success=True,
                result=code_blocks,
                execution_time=time.time() - start,
                metadata={"count": len(code_blocks)}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _extract_code_blocks(self, text: str, language: Optional[str], include_metadata: bool) -> List[Union[str, Dict[str, Any]]]:
        blocks = []
        pattern = r'```(\w+)?\n(.*?)```'
        
        for match in re.finditer(pattern, text, re.DOTALL):
            lang = match.group(1) or "plain"
            code = match.group(2)
            
            if language and lang != language:
                continue
            
            if include_metadata:
                blocks.append({
                    "language": lang,
                    "code": code.strip(),
                    "start_pos": match.start()
                })
            else:
                blocks.append(code.strip())
        
        return blocks


class NetworkTool(BaseTool):
    """
    Network utility operations.
    
    Supports:
    - DNS lookup
    - Port checking
    - Basic connectivity test
    """
    
    def __init__(self):
        config = ToolConfig(
            name="network",
            description="Network utilities (DNS lookup, port check)",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["dns_lookup", "port_check", "get_hostname"],
                        "default": "dns_lookup"
                    },
                    "host": {
                        "type": "string",
                        "description": "Hostname or IP address"
                    },
                    "port": {
                        "type": "integer",
                        "description": "Port number for port check",
                        "minimum": 1,
                        "maximum": 65535
                    },
                    "timeout": {
                        "type": "number",
                        "description": "Timeout in seconds",
                        "default": 5.0
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if not SOCKET_AVAILABLE:
            return False
        operation = parameters.get("operation")
        if operation in ["dns_lookup", "port_check"] and "host" not in parameters:
            return False
        if operation == "port_check" and "port" not in parameters:
            return False
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not SOCKET_AVAILABLE:
                    error_msg = "Socket library not available"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            timeout = kwargs.get("timeout", 5.0)
            
            if operation == "dns_lookup":
                result = socket.gethostbyname(kwargs["host"])
            elif operation == "port_check":
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                result = sock.connect_ex((kwargs["host"], kwargs["port"])) == 0
                sock.close()
            elif operation == "get_hostname":
                result = socket.gethostname()
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class UUIDGeneratorTool(BaseTool):
    """
    Generate UUIDs.
    
    Supports:
    - UUID v1 (timestamp-based)
    - UUID v4 (random)
    - UUID v5 (namespace + name)
    """
    
    def __init__(self):
        config = ToolConfig(
            name="uuid_generator",
            description="Generate UUIDs (v1, v4, v5)",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "version": {
                        "type": "integer",
                        "description": "UUID version",
                        "enum": [1, 4, 5],
                        "default": 4
                    },
                    "namespace": {
                        "type": "string",
                        "description": "Namespace for v5 (dns, url, oid, x500)",
                        "enum": ["dns", "url", "oid", "x500"]
                    },
                    "name": {
                        "type": "string",
                        "description": "Name for v5 UUID"
                    },
                    "count": {
                        "type": "integer",
                        "description": "Number of UUIDs to generate",
                        "default": 1,
                        "minimum": 1,
                        "maximum": 100
                    }
                }
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        version = parameters.get("version", 4)
        if version == 5:
            return "namespace" in parameters and "name" in parameters
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters (v5 requires namespace and name)",
                    execution_time=time.time() - start
                )
            
            version = kwargs.get("version", 4)
            count = kwargs.get("count", 1)
            
            uuids = []
            for _ in range(count):
                if version == 1:
                    new_uuid = uuid.uuid1()
                elif version == 4:
                    new_uuid = uuid.uuid4()
                elif version == 5:
                    namespace_map = {
                        "dns": uuid.NAMESPACE_DNS,
                        "url": uuid.NAMESPACE_URL,
                        "oid": uuid.NAMESPACE_OID,
                        "x500": uuid.NAMESPACE_X500
                    }
                    ns = namespace_map[kwargs["namespace"]]
                    new_uuid = uuid.uuid5(ns, kwargs["name"])
                
                uuids.append(str(new_uuid))
            
            result = uuids[0] if count == 1 else uuids
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"version": version, "count": count}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class SQLiteTool(BaseTool):
    """
    Execute SQLite operations.
    
    Supports:
    - Query execution
    - Database creation
    - Table operations
    """
    
    def __init__(self):
        config = ToolConfig(
            name="sqlite",
            description="Execute SQLite database operations",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "db_path": {
                        "type": "string",
                        "description": "Path to SQLite database file"
                    },
                    "query": {
                        "type": "string",
                        "description": "SQL query to execute"
                    },
                    "params": {
                        "type": "array",
                        "description": "Query parameters",
                        "items": {"type": "string"}
                    },
                    "fetch": {
                        "type": "boolean",
                        "description": "Whether to fetch results",
                        "default": True
                    }
                },
                "required": ["db_path", "query"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "db_path" in parameters and "query" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            db_path = kwargs["db_path"]
            query = kwargs["query"]
            params = kwargs.get("params", [])
            fetch = kwargs.get("fetch", True)
            
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            cursor.execute(query, params)
            
            if fetch and query.strip().upper().startswith("SELECT"):
                result = cursor.fetchall()
            else:
                conn.commit()
                result = {"rows_affected": cursor.rowcount}
            
            conn.close()
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class EmailTool(BaseTool):
    """
    Send emails via SMTP.
    
    Supports:
    - Plain text emails
    - HTML emails
    - Multiple recipients
    - Attachments (basic)
    """
    
    def __init__(self):
        config = ToolConfig(
            name="email",
            description="Send emails via SMTP",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "smtp_host": {
                        "type": "string",
                        "description": "SMTP server host"
                    },
                    "smtp_port": {
                        "type": "integer",
                        "description": "SMTP server port",
                        "default": 587
                    },
                    "username": {
                        "type": "string",
                        "description": "SMTP username"
                    },
                    "password": {
                        "type": "string",
                        "description": "SMTP password"
                    },
                    "from_addr": {
                        "type": "string",
                        "description": "Sender email address"
                    },
                    "to_addrs": {
                        "type": "array",
                        "description": "Recipient email addresses",
                        "items": {"type": "string"}
                    },
                    "subject": {
                        "type": "string",
                        "description": "Email subject"
                    },
                    "body": {
                        "type": "string",
                        "description": "Email body"
                    },
                    "html": {
                        "type": "boolean",
                        "description": "Whether body is HTML",
                        "default": False
                    },
                    "use_tls": {
                        "type": "boolean",
                        "description": "Use TLS encryption",
                        "default": True
                    }
                },
                "required": ["smtp_host", "from_addr", "to_addrs", "subject", "body"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if not EMAIL_AVAILABLE:
            return False
        required = ["smtp_host", "from_addr", "to_addrs", "subject", "body"]
        return all(k in parameters for k in required)
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not EMAIL_AVAILABLE:
                    error_msg = "Email libraries not available"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            smtp_host = kwargs["smtp_host"]
            smtp_port = kwargs.get("smtp_port", 587)
            username = kwargs.get("username")
            password = kwargs.get("password")
            from_addr = kwargs["from_addr"]
            to_addrs = kwargs["to_addrs"]
            subject = kwargs["subject"]
            body = kwargs["body"]
            is_html = kwargs.get("html", False)
            use_tls = kwargs.get("use_tls", True)
            
            msg = MIMEMultipart() if is_html else MIMEText(body)
            msg['From'] = from_addr
            msg['To'] = ', '.join(to_addrs)
            msg['Subject'] = subject
            
            if is_html:
                msg.attach(MIMEText(body, 'html'))
            
            server = smtplib.SMTP(smtp_host, smtp_port)
            if use_tls:
                server.starttls()
            if username and password:
                server.login(username, password)
            
            server.send_message(msg)
            server.quit()
            
            return ToolResult(
                success=True,
                result=f"Email sent to {len(to_addrs)} recipient(s)",
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class ConfigParserTool(BaseTool):
    """
    Parse configuration files.
    
    Supports:
    - INI files (built-in)
    - YAML files (requires PyYAML)
    - TOML files (requires tomli/tomllib)
    - JSON files (built-in)
    """
    
    def __init__(self):
        config = ToolConfig(
            name="config_parser",
            description="Parse configuration files (INI, YAML, TOML, JSON)",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to config file"
                    },
                    "format": {
                        "type": "string",
                        "description": "Config file format",
                        "enum": ["ini", "yaml", "toml", "json"],
                        "default": "json"
                    },
                    "section": {
                        "type": "string",
                        "description": "Section to read (INI only)"
                    }
                },
                "required": ["file_path"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if "file_path" not in parameters:
            return False
        format_type = parameters.get("format", "json")
        if format_type == "yaml" and not YAML_AVAILABLE:
            return False
        if format_type == "toml" and not TOML_AVAILABLE:
            return False
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters or missing library",
                    execution_time=time.time() - start
                )
            
            file_path = kwargs["file_path"]
            format_type = kwargs.get("format", "json")
            section = kwargs.get("section")
            
            if format_type == "json":
                with open(file_path, 'r') as f:
                    result = json.load(f)
            elif format_type == "ini":
                parser = configparser.ConfigParser()
                parser.read(file_path)
                if section:
                    result = dict(parser[section])
                else:
                    result = {s: dict(parser[s]) for s in parser.sections()}
            elif format_type == "yaml":
                with open(file_path, 'r') as f:
                    result = yaml.safe_load(f)
            elif format_type == "toml":
                with open(file_path, 'rb') as f:
                    result = tomli.load(f)
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"format": format_type}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class ValidationTool(BaseTool):
    """
    Validate data against various formats.
    
    Supports:
    - JSON validation
    - Email validation
    - URL validation
    - Regex pattern matching
    """
    
    def __init__(self):
        config = ToolConfig(
            name="validation",
            description="Validate data (JSON, email, URL, regex)",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "data": {
                        "type": "string",
                        "description": "Data to validate"
                    },
                    "validation_type": {
                        "type": "string",
                        "description": "Type of validation",
                        "enum": ["json", "email", "url", "regex"],
                        "default": "json"
                    },
                    "pattern": {
                        "type": "string",
                        "description": "Regex pattern for regex validation"
                    }
                },
                "required": ["data", "validation_type"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if "data" not in parameters or "validation_type" not in parameters:
            return False
        if parameters.get("validation_type") == "regex" and "pattern" not in parameters:
            return False
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            data = kwargs["data"]
            validation_type = kwargs["validation_type"]
            
            is_valid = False
            error_msg = None
            
            if validation_type == "json":
                try:
                    json.loads(data)
                    is_valid = True
                except json.JSONDecodeError as e:
                    error_msg = str(e)
            elif validation_type == "email":
                email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
                is_valid = bool(re.match(email_pattern, data))
            elif validation_type == "url":
                url_pattern = r'^https?://[^\s/$.?#].[^\s]*$'
                is_valid = bool(re.match(url_pattern, data))
            elif validation_type == "regex":
                pattern = kwargs["pattern"]
                is_valid = bool(re.match(pattern, data))
            
            result = {
                "valid": is_valid,
                "data": data,
                "validation_type": validation_type
            }
            if error_msg:
                result["error"] = error_msg
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
