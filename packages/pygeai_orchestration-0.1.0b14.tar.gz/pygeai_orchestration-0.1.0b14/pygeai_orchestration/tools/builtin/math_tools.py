"""
Math calculation tools for pygeai-orchestration.

This module provides mathematical computation capabilities.
"""

import time
import math
from typing import Any, Dict, List, Union

from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
from pygeai_orchestration.tools.builtin import (
    validate_required_params,
    create_error_result,
    create_success_result,
    ValidationError,
)


class MathCalculatorTool(BaseTool):
    """
    Perform mathematical calculations and operations.
    
    Supports basic arithmetic, trigonometry, logarithms, and more.
    
    Example:
        >>> tool = MathCalculatorTool()
        >>> result = await tool.execute(
        ...     operation='add',
        ...     values=[10, 20, 30]
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="math_calculator",
            description="Perform mathematical calculations and operations",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": [
                            "add", "subtract", "multiply", "divide",
                            "power", "sqrt", "abs", "round",
                            "floor", "ceil", "min", "max",
                            "sin", "cos", "tan", "log", "log10", "exp",
                            "mean", "median", "sum", "product"
                        ],
                        "description": "Mathematical operation to perform"
                    },
                    "values": {
                        "type": "array",
                        "description": "Numbers to operate on",
                        "items": {"type": "number"}
                    },
                    "value": {
                        "type": "number",
                        "description": "Single number for unary operations"
                    },
                    "precision": {
                        "type": "integer",
                        "description": "Decimal precision for rounding (default: 2)",
                        "default": 2
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["operation"])
            
            operation = parameters.get("operation")
            multi_value_ops = ["add", "multiply", "min", "max", "mean", "median", "sum", "product"]
            single_value_ops = ["sqrt", "abs", "floor", "ceil", "sin", "cos", "tan", "log", "log10", "exp"]
            
            if operation in multi_value_ops:
                if "values" not in parameters or not parameters["values"]:
                    raise ValidationError(f"{operation} requires 'values' array")
            elif operation in single_value_ops:
                if "value" not in parameters:
                    raise ValidationError(f"{operation} requires 'value' parameter")
            elif operation in ["subtract", "divide", "power"]:
                if "values" not in parameters or len(parameters["values"]) < 2:
                    raise ValidationError(f"{operation} requires at least 2 values")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            precision = kwargs.get("precision", 2)
            
            if operation == "add":
                result = sum(kwargs["values"])
            elif operation == "subtract":
                values = kwargs["values"]
                result = values[0] - sum(values[1:])
            elif operation == "multiply":
                result = 1
                for v in kwargs["values"]:
                    result *= v
            elif operation == "divide":
                values = kwargs["values"]
                result = values[0]
                for v in values[1:]:
                    if v == 0:
                        return create_error_result(
                            ZeroDivisionError("Division by zero"),
                            time.time() - start
                        )
                    result /= v
            elif operation == "power":
                values = kwargs["values"]
                result = values[0] ** values[1]
            elif operation == "sqrt":
                value = kwargs["value"]
                if value < 0:
                    return create_error_result(
                        ValueError("Cannot take square root of negative number"),
                        time.time() - start
                    )
                result = math.sqrt(value)
            elif operation == "abs":
                result = abs(kwargs["value"])
            elif operation == "round":
                value = kwargs.get("value") or kwargs["values"][0]
                result = round(value, precision)
            elif operation == "floor":
                result = math.floor(kwargs["value"])
            elif operation == "ceil":
                result = math.ceil(kwargs["value"])
            elif operation == "min":
                result = min(kwargs["values"])
            elif operation == "max":
                result = max(kwargs["values"])
            elif operation == "sin":
                result = math.sin(kwargs["value"])
            elif operation == "cos":
                result = math.cos(kwargs["value"])
            elif operation == "tan":
                result = math.tan(kwargs["value"])
            elif operation == "log":
                value = kwargs["value"]
                if value <= 0:
                    return create_error_result(
                        ValueError("Logarithm requires positive number"),
                        time.time() - start
                    )
                result = math.log(value)
            elif operation == "log10":
                value = kwargs["value"]
                if value <= 0:
                    return create_error_result(
                        ValueError("Logarithm requires positive number"),
                        time.time() - start
                    )
                result = math.log10(value)
            elif operation == "exp":
                result = math.exp(kwargs["value"])
            elif operation == "mean":
                values = kwargs["values"]
                result = sum(values) / len(values)
            elif operation == "median":
                values = sorted(kwargs["values"])
                n = len(values)
                if n % 2 == 0:
                    result = (values[n//2 - 1] + values[n//2]) / 2
                else:
                    result = values[n//2]
            elif operation == "sum":
                result = sum(kwargs["values"])
            else:  # product
                result = 1
                for v in kwargs["values"]:
                    result *= v
            
            if isinstance(result, float) and operation not in ["sin", "cos", "tan", "log", "log10", "exp"]:
                result = round(result, precision)
            
            metadata = {
                "operation": operation,
                "precision": precision
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)
