"""
Web and HTTP tools for pygeai-orchestration.

This module provides web scraping and HTTP capabilities:
- URLFetchTool: Fetch content from URLs
- HTMLParserTool: Parse HTML and extract elements
- BeautifulSoupTool: Advanced HTML/XML parsing
- EnvironmentTool: Access environment variables
"""

import time
import os
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, urljoin
import html.parser as html_parser

from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
from pygeai_orchestration.tools.builtin import (
    validate_required_params,
    create_error_result,
    create_success_result,
    ValidationError,
)


class URLFetchTool(BaseTool):
    """
    Fetch content from URLs using urllib (no external dependencies).
    
    Supports GET requests with basic error handling.
    
    Example:
        >>> tool = URLFetchTool()
        >>> result = await tool.execute(
        ...     url='https://example.com',
        ...     timeout=10
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="url_fetch",
            description="Fetch content from URLs (read-only, GET requests)",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "URL to fetch"
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Request timeout in seconds (default: 30)",
                        "default": 30
                    },
                    "headers": {
                        "type": "object",
                        "description": "Custom HTTP headers"
                    },
                    "decode": {
                        "type": "boolean",
                        "description": "Decode response as text (default: true)",
                        "default": True
                    }
                },
                "required": ["url"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["url"])
            
            url = parameters.get("url")
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                raise ValidationError("Invalid URL format")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            import urllib.request
            import urllib.error
            
            url = kwargs["url"]
            timeout = kwargs.get("timeout", 30)
            headers = kwargs.get("headers", {})
            decode = kwargs.get("decode", True)
            
            req = urllib.request.Request(url)
            for key, value in headers.items():
                req.add_header(key, value)
            
            with urllib.request.urlopen(req, timeout=timeout) as response:
                content = response.read()
                status_code = response.getcode()
                response_headers = dict(response.headers)
            
            if decode:
                encoding = response_headers.get('Content-Type', '')
                if 'charset=' in encoding:
                    charset = encoding.split('charset=')[1].split(';')[0].strip()
                else:
                    charset = 'utf-8'
                
                result = content.decode(charset, errors='replace')
            else:
                result = content
            
            metadata = {
                "url": url,
                "status_code": status_code,
                "content_length": len(content),
                "content_type": response_headers.get('Content-Type', 'unknown')
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except urllib.error.HTTPError as e:
            return create_error_result(
                Exception(f"HTTP Error {e.code}: {e.reason}"),
                time.time() - start
            )
        except urllib.error.URLError as e:
            return create_error_result(
                Exception(f"URL Error: {e.reason}"),
                time.time() - start
            )
        except Exception as e:
            return create_error_result(e, time.time() - start)


class HTMLParserTool(BaseTool):
    """
    Parse HTML and extract elements using Python's built-in parser.
    
    Extract text, links, and specific tags from HTML content.
    
    Example:
        >>> tool = HTMLParserTool()
        >>> result = await tool.execute(
        ...     html='<html><a href="/link">text</a></html>',
        ...     extract='links'
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="html_parser",
            description="Parse HTML and extract elements, text, and links",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "html": {
                        "type": "string",
                        "description": "HTML content to parse"
                    },
                    "extract": {
                        "type": "string",
                        "enum": ["text", "links", "images", "tags", "all"],
                        "description": "What to extract from HTML"
                    },
                    "tag": {
                        "type": "string",
                        "description": "Specific tag to extract (for tags mode)"
                    },
                    "base_url": {
                        "type": "string",
                        "description": "Base URL for resolving relative links"
                    }
                },
                "required": ["html", "extract"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["html", "extract"])
            
            extract = parameters.get("extract")
            if extract not in ["text", "links", "images", "tags", "all"]:
                raise ValidationError("Invalid extract option")
            
            if extract == "tags" and "tag" not in parameters:
                raise ValidationError("tag parameter required for tags extraction")
            
            return True
        except ValidationError:
            return False
    
    class _HTMLExtractor(html_parser.HTMLParser):
        def __init__(self, base_url=None):
            super().__init__()
            self.text_parts = []
            self.links = []
            self.images = []
            self.tags = {}
            self.current_tag = None
            self.base_url = base_url
        
        def handle_starttag(self, tag, attrs):
            self.current_tag = tag
            attrs_dict = dict(attrs)
            
            if tag == 'a' and 'href' in attrs_dict:
                href = attrs_dict['href']
                if self.base_url:
                    href = urljoin(self.base_url, href)
                self.links.append({
                    'url': href,
                    'text': ''
                })
            
            if tag == 'img' and 'src' in attrs_dict:
                src = attrs_dict['src']
                if self.base_url:
                    src = urljoin(self.base_url, src)
                self.images.append({
                    'src': src,
                    'alt': attrs_dict.get('alt', '')
                })
            
            if tag not in self.tags:
                self.tags[tag] = []
            self.tags[tag].append(attrs_dict)
        
        def handle_data(self, data):
            stripped = data.strip()
            if stripped:
                self.text_parts.append(stripped)
                
                if self.current_tag == 'a' and self.links:
                    self.links[-1]['text'] = stripped
        
        def handle_endtag(self, tag):
            self.current_tag = None
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            html_content = kwargs["html"]
            extract = kwargs["extract"]
            base_url = kwargs.get("base_url")
            
            parser = self._HTMLExtractor(base_url)
            parser.feed(html_content)
            
            if extract == "text":
                result = " ".join(parser.text_parts)
            elif extract == "links":
                result = parser.links
            elif extract == "images":
                result = parser.images
            elif extract == "tags":
                tag = kwargs["tag"]
                result = parser.tags.get(tag, [])
            else:  # all
                result = {
                    "text": " ".join(parser.text_parts),
                    "links": parser.links,
                    "images": parser.images,
                    "tags": list(parser.tags.keys())
                }
            
            metadata = {
                "extract_type": extract,
                "links_found": len(parser.links),
                "images_found": len(parser.images)
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class BeautifulSoupTool(BaseTool):
    """
    Advanced HTML/XML parsing using BeautifulSoup.
    
    Provides powerful CSS selector and find operations.
    
    Example:
        >>> tool = BeautifulSoupTool()
        >>> result = await tool.execute(
        ...     html='<div class="content">Hello</div>',
        ...     operation='find',
        ...     selector='div.content'
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="beautifulsoup",
            description="Advanced HTML/XML parsing with CSS selectors",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "html": {
                        "type": "string",
                        "description": "HTML/XML content to parse"
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["find", "find_all", "select", "get_text"],
                        "description": "Parsing operation"
                    },
                    "selector": {
                        "type": "string",
                        "description": "CSS selector or tag name"
                    },
                    "attributes": {
                        "type": "object",
                        "description": "Tag attributes to match"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum results to return (default: 100)",
                        "default": 100
                    }
                },
                "required": ["html", "operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["html", "operation"])
            
            operation = parameters.get("operation")
            if operation not in ["find", "find_all", "select", "get_text"]:
                raise ValidationError("Invalid operation")
            
            if operation in ["find", "find_all", "select"] and "selector" not in parameters:
                raise ValidationError("selector required for this operation")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            try:
                from bs4 import BeautifulSoup
            except ImportError:
                return create_error_result(
                    ImportError("BeautifulSoup4 not installed"),
                    time.time() - start
                )
            
            html_content = kwargs["html"]
            operation = kwargs["operation"]
            limit = kwargs.get("limit", 100)
            
            soup = BeautifulSoup(html_content, 'html.parser')
            
            if operation == "get_text":
                result = soup.get_text(strip=True)
            
            elif operation == "find":
                selector = kwargs["selector"]
                attrs = kwargs.get("attributes", {})
                
                element = soup.find(selector, attrs=attrs)
                if element:
                    result = {
                        "tag": element.name,
                        "text": element.get_text(strip=True),
                        "attributes": dict(element.attrs)
                    }
                else:
                    result = None
            
            elif operation == "find_all":
                selector = kwargs["selector"]
                attrs = kwargs.get("attributes", {})
                
                elements = soup.find_all(selector, attrs=attrs, limit=limit)
                result = [
                    {
                        "tag": elem.name,
                        "text": elem.get_text(strip=True),
                        "attributes": dict(elem.attrs)
                    }
                    for elem in elements
                ]
            
            else:  # select
                selector = kwargs["selector"]
                elements = soup.select(selector, limit=limit)
                result = [
                    {
                        "tag": elem.name,
                        "text": elem.get_text(strip=True),
                        "attributes": dict(elem.attrs)
                    }
                    for elem in elements
                ]
            
            metadata = {
                "operation": operation,
                "result_count": len(result) if isinstance(result, list) else (1 if result else 0)
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class EnvironmentTool(BaseTool):
    """
    Access and manage environment variables.
    
    Read environment variables with optional defaults.
    
    Example:
        >>> tool = EnvironmentTool()
        >>> result = await tool.execute(
        ...     operation='get',
        ...     key='HOME'
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="environment",
            description="Access environment variables",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["get", "list", "exists"],
                        "description": "Operation to perform"
                    },
                    "key": {
                        "type": "string",
                        "description": "Environment variable key"
                    },
                    "default": {
                        "type": "string",
                        "description": "Default value if key not found"
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["operation"])
            
            operation = parameters.get("operation")
            if operation not in ["get", "list", "exists"]:
                raise ValidationError("Invalid operation")
            
            if operation in ["get", "exists"] and "key" not in parameters:
                raise ValidationError("key required for this operation")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            
            if operation == "get":
                key = kwargs["key"]
                default = kwargs.get("default")
                result = os.environ.get(key, default)
            
            elif operation == "exists":
                key = kwargs["key"]
                result = key in os.environ
            
            else:  # list
                result = dict(os.environ)
            
            metadata = {
                "operation": operation
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)
