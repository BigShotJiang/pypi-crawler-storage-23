"""
Document generation tools for pygeai-orchestration.

Provides tools for:
- Markdown rendering
- PDF generation
- DOCX generation
- Document format conversion
"""

from typing import Any, Dict, Optional
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time
import os

try:
    import markdown
    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False

try:
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import inch
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

try:
    from docx import Document
    from docx.shared import Inches, Pt
    PYTHON_DOCX_AVAILABLE = True
except ImportError:
    PYTHON_DOCX_AVAILABLE = False


class MarkdownRendererTool(BaseTool):
    """
    Render Markdown to HTML.
    
    Requires: markdown
    
    Features:
    - Convert markdown text to HTML
    - Support for extensions (tables, fenced_code, etc.)
    - Custom CSS styling
    """
    
    def __init__(self):
        config = ToolConfig(
            name="markdown_renderer",
            description="Convert Markdown text to HTML with optional extensions and styling",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "markdown_text": {
                        "type": "string",
                        "description": "Markdown text to convert"
                    },
                    "extensions": {
                        "type": "array",
                        "description": "Markdown extensions to enable",
                        "items": {"type": "string"},
                        "default": ["tables", "fenced_code", "codehilite"]
                    },
                    "output_file": {
                        "type": "string",
                        "description": "Optional output HTML file path"
                    },
                    "include_css": {
                        "type": "boolean",
                        "description": "Include basic CSS styling",
                        "default": False
                    }
                },
                "required": ["markdown_text"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if not MARKDOWN_AVAILABLE:
            return False
        
        if "markdown_text" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute markdown rendering."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not MARKDOWN_AVAILABLE:
                    error_msg = "markdown library not installed"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            markdown_text = kwargs["markdown_text"]
            extensions = kwargs.get("extensions", ["tables", "fenced_code", "codehilite"])
            output_file = kwargs.get("output_file")
            include_css = kwargs.get("include_css", False)
            
            html = markdown.markdown(markdown_text, extensions=extensions)
            
            if include_css:
                html = self._wrap_with_css(html)
            
            if output_file:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(html)
                result = {"html": html, "file": output_file}
            else:
                result = html
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _wrap_with_css(self, html: str) -> str:
        """Wrap HTML with basic CSS styling."""
        css = """
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            code { background: #f4f4f4; padding: 2px 5px; border-radius: 3px; }
            pre { background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }
            table { border-collapse: collapse; width: 100%; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
        </style>
        """
        return f"<!DOCTYPE html><html><head><meta charset='utf-8'>{css}</head><body>{html}</body></html>"


class PDFGeneratorTool(BaseTool):
    """
    Generate PDF documents.
    
    Requires: reportlab
    
    Features:
    - Create PDF from text content
    - Simple formatting (paragraphs, headings)
    - Page size configuration
    """
    
    def __init__(self):
        config = ToolConfig(
            name="pdf_generator",
            description="Generate PDF documents from text content with basic formatting",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "output_file": {
                        "type": "string",
                        "description": "Output PDF file path"
                    },
                    "content": {
                        "type": "array",
                        "description": "List of content items (dict with 'type' and 'text')",
                        "items": {"type": "object"}
                    },
                    "title": {
                        "type": "string",
                        "description": "Document title"
                    },
                    "page_size": {
                        "type": "string",
                        "description": "Page size: 'letter' or 'A4'",
                        "default": "letter"
                    }
                },
                "required": ["output_file", "content"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if not REPORTLAB_AVAILABLE:
            return False
        
        if "output_file" not in parameters or "content" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute PDF generation."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not REPORTLAB_AVAILABLE:
                    error_msg = "reportlab library not installed"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            output_file = kwargs["output_file"]
            content = kwargs["content"]
            title = kwargs.get("title", "Document")
            page_size = A4 if kwargs.get("page_size") == "A4" else letter
            
            doc = SimpleDocTemplate(output_file, pagesize=page_size)
            styles = getSampleStyleSheet()
            story = []
            
            for item in content:
                item_type = item.get("type", "paragraph")
                text = item.get("text", "")
                
                if item_type == "heading":
                    story.append(Paragraph(text, styles['Heading1']))
                elif item_type == "heading2":
                    story.append(Paragraph(text, styles['Heading2']))
                else:
                    story.append(Paragraph(text, styles['Normal']))
                
                story.append(Spacer(1, 0.2*inch))
            
            doc.build(story)
            
            return ToolResult(
                success=True,
                result={"file": output_file, "size": os.path.getsize(output_file)},
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class DOCXGeneratorTool(BaseTool):
    """
    Generate DOCX documents.
    
    Requires: python-docx
    
    Features:
    - Create DOCX from content
    - Headings, paragraphs, lists
    - Basic formatting
    """
    
    def __init__(self):
        config = ToolConfig(
            name="docx_generator",
            description="Generate DOCX documents with headings, paragraphs, and basic formatting",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "output_file": {
                        "type": "string",
                        "description": "Output DOCX file path"
                    },
                    "content": {
                        "type": "array",
                        "description": "List of content items (dict with 'type' and 'text')",
                        "items": {"type": "object"}
                    },
                    "title": {
                        "type": "string",
                        "description": "Document title"
                    }
                },
                "required": ["output_file", "content"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if not PYTHON_DOCX_AVAILABLE:
            return False
        
        if "output_file" not in parameters or "content" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute DOCX generation."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not PYTHON_DOCX_AVAILABLE:
                    error_msg = "python-docx library not installed"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            output_file = kwargs["output_file"]
            content = kwargs["content"]
            title = kwargs.get("title", "Document")
            
            doc = Document()
            
            if title:
                doc.add_heading(title, 0)
            
            for item in content:
                item_type = item.get("type", "paragraph")
                text = item.get("text", "")
                
                if item_type == "heading":
                    doc.add_heading(text, level=1)
                elif item_type == "heading2":
                    doc.add_heading(text, level=2)
                elif item_type == "heading3":
                    doc.add_heading(text, level=3)
                else:
                    doc.add_paragraph(text)
            
            doc.save(output_file)
            
            return ToolResult(
                success=True,
                result={"file": output_file, "size": os.path.getsize(output_file)},
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class DocumentConverterTool(BaseTool):
    """
    Convert between document formats.
    
    Supports:
    - Markdown to HTML
    - HTML to plain text
    - Text to Markdown (basic)
    """
    
    def __init__(self):
        config = ToolConfig(
            name="document_converter",
            description="Convert between document formats (markdown, HTML, text)",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "input_content": {
                        "type": "string",
                        "description": "Input content to convert"
                    },
                    "from_format": {
                        "type": "string",
                        "description": "Source format",
                        "enum": ["markdown", "html", "text"]
                    },
                    "to_format": {
                        "type": "string",
                        "description": "Target format",
                        "enum": ["markdown", "html", "text"]
                    },
                    "output_file": {
                        "type": "string",
                        "description": "Optional output file path"
                    }
                },
                "required": ["input_content", "from_format", "to_format"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        required = ["input_content", "from_format", "to_format"]
        if not all(k in parameters for k in required):
            return False
        
        valid_formats = ["markdown", "html", "text"]
        if parameters["from_format"] not in valid_formats:
            return False
        if parameters["to_format"] not in valid_formats:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute document conversion."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            input_content = kwargs["input_content"]
            from_format = kwargs["from_format"]
            to_format = kwargs["to_format"]
            output_file = kwargs.get("output_file")
            
            if from_format == to_format:
                result = input_content
            elif from_format == "markdown" and to_format == "html":
                if MARKDOWN_AVAILABLE:
                    result = markdown.markdown(input_content)
                else:
                    return ToolResult(
                        success=False,
                        error="markdown library not installed",
                        execution_time=time.time() - start
                    )
            elif from_format == "html" and to_format == "text":
                from html.parser import HTMLParser
                class HTMLTextExtractor(HTMLParser):
                    def __init__(self):
                        super().__init__()
                        self.text = []
                    def handle_data(self, data):
                        self.text.append(data)
                    def get_text(self):
                        return ''.join(self.text)
                
                parser = HTMLTextExtractor()
                parser.feed(input_content)
                result = parser.get_text()
            elif from_format == "text" and to_format == "markdown":
                lines = input_content.split('\n')
                result = '\n\n'.join(lines)
            else:
                return ToolResult(
                    success=False,
                    error=f"Conversion from {from_format} to {to_format} not supported",
                    execution_time=time.time() - start
                )
            
            if output_file:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(result)
                result = {"content": result, "file": output_file}
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
