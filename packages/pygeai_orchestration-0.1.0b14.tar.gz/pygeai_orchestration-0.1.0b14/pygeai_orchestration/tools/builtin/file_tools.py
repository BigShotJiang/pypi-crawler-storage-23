"""
File operation tools for pygeai-orchestration.

This module provides tools for common file system operations:
- FileReaderTool: Read file contents with encoding support
- FileWriterTool: Write content to files
- FileSearchTool: Search for files by pattern
- DirectoryListerTool: List directory contents
"""

import time
from pathlib import Path
from typing import Any, Dict, Optional, List
import os
import fnmatch

from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
from pygeai_orchestration.tools.builtin import (
    validate_required_params,
    create_error_result,
    create_success_result,
    ValidationError,
)


class FileReaderTool(BaseTool):
    """
    Read file contents with encoding support.
    
    This tool reads text files and returns their contents with support for
    different encodings and optional line limiting.
    
    Example:
        >>> tool = FileReaderTool()
        >>> result = await tool.execute(file_path="/path/to/file.txt")
        >>> print(result.result)
    """
    
    def __init__(self):
        config = ToolConfig(
            name="file_reader",
            description="Read file contents with encoding support",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to read"
                    },
                    "encoding": {
                        "type": "string",
                        "description": "File encoding (default: utf-8)",
                        "default": "utf-8"
                    },
                    "max_lines": {
                        "type": "integer",
                        "description": "Maximum number of lines to read (optional)",
                        "minimum": 1
                    }
                },
                "required": ["file_path"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["file_path"])
            
            file_path = parameters.get("file_path")
            if not isinstance(file_path, str):
                raise ValidationError("file_path must be a string")
            
            max_lines = parameters.get("max_lines")
            if max_lines is not None and (not isinstance(max_lines, int) or max_lines < 1):
                raise ValidationError("max_lines must be a positive integer")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            file_path = Path(kwargs["file_path"])
            encoding = kwargs.get("encoding", "utf-8")
            max_lines = kwargs.get("max_lines")
            
            if not file_path.exists():
                return create_error_result(
                    FileNotFoundError(f"File not found: {file_path}"),
                    time.time() - start
                )
            
            if not file_path.is_file():
                return create_error_result(
                    ValueError(f"Path is not a file: {file_path}"),
                    time.time() - start
                )
            
            with open(file_path, "r", encoding=encoding) as f:
                if max_lines:
                    lines = []
                    for i, line in enumerate(f):
                        if i >= max_lines:
                            break
                        lines.append(line)
                    content = "".join(lines)
                else:
                    content = f.read()
            
            metadata = {
                "file_path": str(file_path),
                "encoding": encoding,
                "size_bytes": file_path.stat().st_size,
                "lines_read": len(content.splitlines()) if content else 0
            }
            
            return create_success_result(
                content,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class FileWriterTool(BaseTool):
    """
    Write content to files with encoding support.
    
    This tool writes text content to files with optional append mode
    and encoding specification.
    
    Example:
        >>> tool = FileWriterTool()
        >>> result = await tool.execute(
        ...     file_path="/path/to/file.txt",
        ...     content="Hello, World!"
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="file_writer",
            description="Write content to files with encoding support",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to write"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file"
                    },
                    "encoding": {
                        "type": "string",
                        "description": "File encoding (default: utf-8)",
                        "default": "utf-8"
                    },
                    "append": {
                        "type": "boolean",
                        "description": "Append to file instead of overwriting (default: false)",
                        "default": False
                    },
                    "create_dirs": {
                        "type": "boolean",
                        "description": "Create parent directories if they don't exist (default: true)",
                        "default": True
                    }
                },
                "required": ["file_path", "content"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["file_path", "content"])
            
            if not isinstance(parameters.get("file_path"), str):
                raise ValidationError("file_path must be a string")
            
            if not isinstance(parameters.get("content"), str):
                raise ValidationError("content must be a string")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            file_path = Path(kwargs["file_path"])
            content = kwargs["content"]
            encoding = kwargs.get("encoding", "utf-8")
            append = kwargs.get("append", False)
            create_dirs = kwargs.get("create_dirs", True)
            
            if create_dirs and not file_path.parent.exists():
                file_path.parent.mkdir(parents=True, exist_ok=True)
            
            mode = "a" if append else "w"
            with open(file_path, mode, encoding=encoding) as f:
                f.write(content)
            
            metadata = {
                "file_path": str(file_path),
                "encoding": encoding,
                "bytes_written": len(content.encode(encoding)),
                "mode": "append" if append else "write"
            }
            
            return create_success_result(
                f"Successfully wrote {len(content)} characters to {file_path}",
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class FileSearchTool(BaseTool):
    """
    Search for files by pattern in a directory.
    
    This tool searches for files matching a pattern (glob or fnmatch)
    within a directory, with optional recursive search.
    
    Example:
        >>> tool = FileSearchTool()
        >>> result = await tool.execute(
        ...     directory="/path/to/search",
        ...     pattern="*.py",
        ...     recursive=True
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="file_search",
            description="Search for files by pattern in a directory",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory to search in"
                    },
                    "pattern": {
                        "type": "string",
                        "description": "File pattern to match (e.g., '*.py', 'test_*.txt')"
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "Search recursively in subdirectories (default: false)",
                        "default": False
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results to return (optional)",
                        "minimum": 1
                    }
                },
                "required": ["directory", "pattern"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["directory", "pattern"])
            
            if not isinstance(parameters.get("directory"), str):
                raise ValidationError("directory must be a string")
            
            if not isinstance(parameters.get("pattern"), str):
                raise ValidationError("pattern must be a string")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            directory = Path(kwargs["directory"])
            pattern = kwargs["pattern"]
            recursive = kwargs.get("recursive", False)
            max_results = kwargs.get("max_results")
            
            if not directory.exists():
                return create_error_result(
                    FileNotFoundError(f"Directory not found: {directory}"),
                    time.time() - start
                )
            
            if not directory.is_dir():
                return create_error_result(
                    ValueError(f"Path is not a directory: {directory}"),
                    time.time() - start
                )
            
            matches = []
            glob_pattern = f"**/{pattern}" if recursive else pattern
            
            for file_path in directory.glob(glob_pattern):
                if file_path.is_file():
                    matches.append(str(file_path))
                    if max_results and len(matches) >= max_results:
                        break
            
            metadata = {
                "directory": str(directory),
                "pattern": pattern,
                "recursive": recursive,
                "total_matches": len(matches)
            }
            
            return create_success_result(
                matches,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class DirectoryListerTool(BaseTool):
    """
    List directory contents with filtering options.
    
    This tool lists files and directories in a given path with options
    to filter by type and include metadata.
    
    Example:
        >>> tool = DirectoryListerTool()
        >>> result = await tool.execute(
        ...     directory="/path/to/list",
        ...     include_hidden=False
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="directory_lister",
            description="List directory contents with filtering options",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory to list"
                    },
                    "include_hidden": {
                        "type": "boolean",
                        "description": "Include hidden files/directories (default: false)",
                        "default": False
                    },
                    "files_only": {
                        "type": "boolean",
                        "description": "List only files (default: false)",
                        "default": False
                    },
                    "dirs_only": {
                        "type": "boolean",
                        "description": "List only directories (default: false)",
                        "default": False
                    },
                    "include_metadata": {
                        "type": "boolean",
                        "description": "Include file metadata (size, modified time, etc.)",
                        "default": False
                    }
                },
                "required": ["directory"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["directory"])
            
            if not isinstance(parameters.get("directory"), str):
                raise ValidationError("directory must be a string")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            directory = Path(kwargs["directory"])
            include_hidden = kwargs.get("include_hidden", False)
            files_only = kwargs.get("files_only", False)
            dirs_only = kwargs.get("dirs_only", False)
            include_metadata = kwargs.get("include_metadata", False)
            
            if not directory.exists():
                return create_error_result(
                    FileNotFoundError(f"Directory not found: {directory}"),
                    time.time() - start
                )
            
            if not directory.is_dir():
                return create_error_result(
                    ValueError(f"Path is not a directory: {directory}"),
                    time.time() - start
                )
            
            items = []
            for item in directory.iterdir():
                if not include_hidden and item.name.startswith('.'):
                    continue
                
                if files_only and not item.is_file():
                    continue
                
                if dirs_only and not item.is_dir():
                    continue
                
                if include_metadata:
                    stat = item.stat()
                    item_data = {
                        "name": item.name,
                        "path": str(item),
                        "type": "file" if item.is_file() else "directory",
                        "size": stat.st_size if item.is_file() else None,
                        "modified": stat.st_mtime
                    }
                    items.append(item_data)
                else:
                    items.append(str(item))
            
            metadata = {
                "directory": str(directory),
                "total_items": len(items),
                "include_hidden": include_hidden,
                "filter": "files" if files_only else ("directories" if dirs_only else "all")
            }
            
            return create_success_result(
                items,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)
