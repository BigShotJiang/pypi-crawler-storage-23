"""
Data processing tools for pygeai-orchestration.

This module provides tools for processing structured data formats:
- JSONParserTool: Parse and query JSON data
- YAMLParserTool: Parse and process YAML files
- CSVProcessorTool: Read, write, and manipulate CSV data
- XMLParserTool: Parse and query XML documents
- DataFrameTool: Process data using pandas-like operations
"""

import time
import json
import csv
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from io import StringIO

from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
from pygeai_orchestration.tools.builtin import (
    validate_required_params,
    create_error_result,
    create_success_result,
    ValidationError,
)


class JSONParserTool(BaseTool):
    """
    Parse and query JSON data.
    
    This tool can parse JSON from strings or files and optionally
    query specific paths using dot notation.
    
    Example:
        >>> tool = JSONParserTool()
        >>> result = await tool.execute(
        ...     json_string='{"name": "test", "value": 42}',
        ...     query="name"
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="json_parser",
            description="Parse and query JSON data from strings or files",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "json_string": {
                        "type": "string",
                        "description": "JSON string to parse"
                    },
                    "file_path": {
                        "type": "string",
                        "description": "Path to JSON file to parse"
                    },
                    "query": {
                        "type": "string",
                        "description": "Dot notation path to query (e.g., 'user.name')"
                    },
                    "indent": {
                        "type": "integer",
                        "description": "Indentation for pretty-printing (optional)",
                        "minimum": 0
                    }
                },
                "oneOf": [
                    {"required": ["json_string"]},
                    {"required": ["file_path"]}
                ]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            if "json_string" not in parameters and "file_path" not in parameters:
                raise ValidationError("Either json_string or file_path must be provided")
            
            if "json_string" in parameters and "file_path" in parameters:
                raise ValidationError("Provide either json_string or file_path, not both")
            
            return True
        except ValidationError:
            return False
    
    def _query_path(self, data: Any, path: str) -> Any:
        """Query nested data using dot notation."""
        parts = path.split(".")
        result = data
        for part in parts:
            if isinstance(result, dict):
                result = result.get(part)
            elif isinstance(result, list) and part.isdigit():
                idx = int(part)
                result = result[idx] if idx < len(result) else None
            else:
                return None
            
            if result is None:
                return None
        
        return result
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            if "json_string" in kwargs:
                data = json.loads(kwargs["json_string"])
                source = "string"
            else:
                file_path = Path(kwargs["file_path"])
                if not file_path.exists():
                    return create_error_result(
                        FileNotFoundError(f"File not found: {file_path}"),
                        time.time() - start
                    )
                with open(file_path, "r") as f:
                    data = json.load(f)
                source = str(file_path)
            
            query = kwargs.get("query")
            if query:
                result = self._query_path(data, query)
            else:
                result = data
            
            indent = kwargs.get("indent")
            if indent is not None:
                formatted = json.dumps(result, indent=indent)
            else:
                formatted = result
            
            metadata = {
                "source": source,
                "query": query,
                "result_type": type(result).__name__
            }
            
            return create_success_result(
                formatted if indent is not None else result,
                time.time() - start,
                metadata
            )
            
        except json.JSONDecodeError as e:
            return create_error_result(
                ValueError(f"Invalid JSON: {e}"),
                time.time() - start
            )
        except Exception as e:
            return create_error_result(e, time.time() - start)


class YAMLParserTool(BaseTool):
    """
    Parse and process YAML files.
    
    This tool parses YAML files and returns structured data.
    Note: Uses basic YAML parsing (safe subset).
    
    Example:
        >>> tool = YAMLParserTool()
        >>> result = await tool.execute(file_path="config.yaml")
    """
    
    def __init__(self):
        config = ToolConfig(
            name="yaml_parser",
            description="Parse YAML files and return structured data",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to YAML file to parse"
                    },
                    "yaml_string": {
                        "type": "string",
                        "description": "YAML string to parse"
                    }
                },
                "oneOf": [
                    {"required": ["file_path"]},
                    {"required": ["yaml_string"]}
                ]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            if "file_path" not in parameters and "yaml_string" not in parameters:
                raise ValidationError("Either file_path or yaml_string must be provided")
            
            return True
        except ValidationError:
            return False
    
    def _parse_yaml_simple(self, content: str) -> Dict[str, Any]:
        """Simple YAML parser for basic key-value pairs and lists."""
        result = {}
        current_key = None
        indent_stack = [(-1, result)]
        
        for line in content.split('\n'):
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#'):
                continue
            
            indent = len(line) - len(stripped)
            
            if ':' in stripped:
                key, value = stripped.split(':', 1)
                key = key.strip()
                value = value.strip()
                
                while indent_stack and indent <= indent_stack[-1][0]:
                    indent_stack.pop()
                
                parent = indent_stack[-1][1]
                
                if value:
                    if value.lower() == 'true':
                        parent[key] = True
                    elif value.lower() == 'false':
                        parent[key] = False
                    elif value.isdigit():
                        parent[key] = int(value)
                    else:
                        try:
                            parent[key] = float(value)
                        except ValueError:
                            parent[key] = value
                else:
                    parent[key] = {}
                    indent_stack.append((indent, parent[key]))
            
            elif stripped.startswith('-'):
                item = stripped[1:].strip()
                while indent_stack and indent <= indent_stack[-1][0]:
                    indent_stack.pop()
                
                parent = indent_stack[-1][1]
                if not isinstance(parent, list):
                    parent = indent_stack[-2][1]
                    last_key = list(parent.keys())[-1]
                    parent[last_key] = []
                    parent = parent[last_key]
                
                if item:
                    parent.append(item)
        
        return result
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            if "yaml_string" in kwargs:
                content = kwargs["yaml_string"]
                source = "string"
            else:
                file_path = Path(kwargs["file_path"])
                if not file_path.exists():
                    return create_error_result(
                        FileNotFoundError(f"File not found: {file_path}"),
                        time.time() - start
                    )
                content = file_path.read_text()
                source = str(file_path)
            
            data = self._parse_yaml_simple(content)
            
            metadata = {
                "source": source,
                "keys": list(data.keys()) if isinstance(data, dict) else None
            }
            
            return create_success_result(
                data,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class CSVProcessorTool(BaseTool):
    """
    Read, write, and manipulate CSV data.
    
    This tool can read CSV files, parse CSV strings, and convert
    between CSV and other formats.
    
    Example:
        >>> tool = CSVProcessorTool()
        >>> result = await tool.execute(
        ...     file_path="data.csv",
        ...     operation="read",
        ...     has_header=True
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="csv_processor",
            description="Read, write, and manipulate CSV data",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["read", "write", "parse"],
                        "description": "Operation to perform: read file, write file, or parse string"
                    },
                    "file_path": {
                        "type": "string",
                        "description": "Path to CSV file"
                    },
                    "csv_string": {
                        "type": "string",
                        "description": "CSV string to parse"
                    },
                    "data": {
                        "type": "array",
                        "description": "Data to write (for write operation)"
                    },
                    "has_header": {
                        "type": "boolean",
                        "description": "Whether CSV has header row (default: true)",
                        "default": True
                    },
                    "delimiter": {
                        "type": "string",
                        "description": "CSV delimiter (default: ',')",
                        "default": ","
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["operation"])
            
            operation = parameters.get("operation")
            if operation not in ["read", "write", "parse"]:
                raise ValidationError("operation must be 'read', 'write', or 'parse'")
            
            if operation == "read" and "file_path" not in parameters:
                raise ValidationError("file_path required for read operation")
            
            if operation == "write" and ("file_path" not in parameters or "data" not in parameters):
                raise ValidationError("file_path and data required for write operation")
            
            if operation == "parse" and "csv_string" not in parameters:
                raise ValidationError("csv_string required for parse operation")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            has_header = kwargs.get("has_header", True)
            delimiter = kwargs.get("delimiter", ",")
            
            if operation == "read":
                file_path = Path(kwargs["file_path"])
                if not file_path.exists():
                    return create_error_result(
                        FileNotFoundError(f"File not found: {file_path}"),
                        time.time() - start
                    )
                
                with open(file_path, "r", newline='') as f:
                    if has_header:
                        reader = csv.DictReader(f, delimiter=delimiter)
                        data = list(reader)
                    else:
                        reader = csv.reader(f, delimiter=delimiter)
                        data = list(reader)
                
                metadata = {
                    "source": str(file_path),
                    "rows": len(data),
                    "has_header": has_header
                }
                
            elif operation == "parse":
                csv_string = kwargs["csv_string"]
                f = StringIO(csv_string)
                
                if has_header:
                    reader = csv.DictReader(f, delimiter=delimiter)
                    data = list(reader)
                else:
                    reader = csv.reader(f, delimiter=delimiter)
                    data = list(reader)
                
                metadata = {
                    "source": "string",
                    "rows": len(data),
                    "has_header": has_header
                }
                
            else:  # write
                file_path = Path(kwargs["file_path"])
                data_to_write = kwargs["data"]
                
                if not data_to_write:
                    return create_error_result(
                        ValueError("data cannot be empty"),
                        time.time() - start
                    )
                
                with open(file_path, "w", newline='') as f:
                    if isinstance(data_to_write[0], dict):
                        writer = csv.DictWriter(f, fieldnames=data_to_write[0].keys(), delimiter=delimiter)
                        if has_header:
                            writer.writeheader()
                        writer.writerows(data_to_write)
                    else:
                        writer = csv.writer(f, delimiter=delimiter)
                        writer.writerows(data_to_write)
                
                data = f"Successfully wrote {len(data_to_write)} rows to {file_path}"
                metadata = {
                    "destination": str(file_path),
                    "rows_written": len(data_to_write)
                }
            
            return create_success_result(
                data,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class XMLParserTool(BaseTool):
    """
    Parse and query XML documents.
    
    This tool parses XML from strings or files and can extract
    elements using XPath-like queries.
    
    Example:
        >>> tool = XMLParserTool()
        >>> result = await tool.execute(
        ...     xml_string='<root><item>value</item></root>',
        ...     query="item"
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="xml_parser",
            description="Parse and query XML documents",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "xml_string": {
                        "type": "string",
                        "description": "XML string to parse"
                    },
                    "file_path": {
                        "type": "string",
                        "description": "Path to XML file to parse"
                    },
                    "query": {
                        "type": "string",
                        "description": "Element tag to find"
                    },
                    "find_all": {
                        "type": "boolean",
                        "description": "Find all matching elements (default: false)",
                        "default": False
                    }
                },
                "oneOf": [
                    {"required": ["xml_string"]},
                    {"required": ["file_path"]}
                ]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            if "xml_string" not in parameters and "file_path" not in parameters:
                raise ValidationError("Either xml_string or file_path must be provided")
            
            return True
        except ValidationError:
            return False
    
    def _element_to_dict(self, element: ET.Element) -> Dict[str, Any]:
        """Convert XML element to dictionary."""
        result = {
            "tag": element.tag,
            "text": element.text.strip() if element.text else None,
            "attributes": dict(element.attrib) if element.attrib else {}
        }
        
        children = list(element)
        if children:
            result["children"] = [self._element_to_dict(child) for child in children]
        
        return result
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            if "xml_string" in kwargs:
                root = ET.fromstring(kwargs["xml_string"])
                source = "string"
            else:
                file_path = Path(kwargs["file_path"])
                if not file_path.exists():
                    return create_error_result(
                        FileNotFoundError(f"File not found: {file_path}"),
                        time.time() - start
                    )
                tree = ET.parse(file_path)
                root = tree.getroot()
                source = str(file_path)
            
            query = kwargs.get("query")
            find_all = kwargs.get("find_all", False)
            
            if query:
                if find_all:
                    elements = root.findall(f".//{query}")
                    result = [self._element_to_dict(elem) for elem in elements]
                else:
                    element = root.find(f".//{query}")
                    result = self._element_to_dict(element) if element is not None else None
            else:
                result = self._element_to_dict(root)
            
            metadata = {
                "source": source,
                "root_tag": root.tag,
                "query": query
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except ET.ParseError as e:
            return create_error_result(
                ValueError(f"Invalid XML: {e}"),
                time.time() - start
            )
        except Exception as e:
            return create_error_result(e, time.time() - start)


class DataFrameTool(BaseTool):
    """
    Process data using pandas-like operations.
    
    This tool provides basic data manipulation operations on
    tabular data without requiring pandas dependency.
    
    Example:
        >>> tool = DataFrameTool()
        >>> result = await tool.execute(
        ...     data=[{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}],
        ...     operation="filter",
        ...     column="age",
        ...     condition="gt",
        ...     value=26
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="dataframe",
            description="Process tabular data with filtering, sorting, and aggregation",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "data": {
                        "type": "array",
                        "description": "Array of dictionaries representing rows"
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["filter", "sort", "group", "select", "stats"],
                        "description": "Operation to perform"
                    },
                    "column": {
                        "type": "string",
                        "description": "Column name for operation"
                    },
                    "columns": {
                        "type": "array",
                        "description": "List of column names (for select operation)"
                    },
                    "condition": {
                        "type": "string",
                        "enum": ["eq", "gt", "lt", "gte", "lte", "contains"],
                        "description": "Filter condition"
                    },
                    "value": {
                        "description": "Value for filter condition"
                    },
                    "ascending": {
                        "type": "boolean",
                        "description": "Sort order (default: true)",
                        "default": True
                    }
                },
                "required": ["data", "operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["data", "operation"])
            
            if not isinstance(parameters["data"], list):
                raise ValidationError("data must be an array")
            
            operation = parameters.get("operation")
            if operation not in ["filter", "sort", "group", "select", "stats"]:
                raise ValidationError("Invalid operation")
            
            if operation in ["filter", "sort", "group", "stats"] and "column" not in parameters:
                raise ValidationError(f"column required for {operation} operation")
            
            if operation == "select" and "columns" not in parameters:
                raise ValidationError("columns required for select operation")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            data = kwargs["data"]
            operation = kwargs["operation"]
            
            if operation == "filter":
                column = kwargs["column"]
                condition = kwargs.get("condition", "eq")
                value = kwargs.get("value")
                
                filtered = []
                for row in data:
                    row_value = row.get(column)
                    if condition == "eq" and row_value == value:
                        filtered.append(row)
                    elif condition == "gt" and row_value > value:
                        filtered.append(row)
                    elif condition == "lt" and row_value < value:
                        filtered.append(row)
                    elif condition == "gte" and row_value >= value:
                        filtered.append(row)
                    elif condition == "lte" and row_value <= value:
                        filtered.append(row)
                    elif condition == "contains" and value in str(row_value):
                        filtered.append(row)
                
                result = filtered
                metadata = {"original_rows": len(data), "filtered_rows": len(filtered)}
                
            elif operation == "sort":
                column = kwargs["column"]
                ascending = kwargs.get("ascending", True)
                
                result = sorted(data, key=lambda x: x.get(column, ""), reverse=not ascending)
                metadata = {"sorted_by": column, "ascending": ascending}
                
            elif operation == "select":
                columns = kwargs["columns"]
                result = [{col: row.get(col) for col in columns} for row in data]
                metadata = {"selected_columns": columns}
                
            elif operation == "group":
                column = kwargs["column"]
                groups = {}
                for row in data:
                    key = row.get(column)
                    if key not in groups:
                        groups[key] = []
                    groups[key].append(row)
                
                result = {str(k): v for k, v in groups.items()}
                metadata = {"grouped_by": column, "groups": len(groups)}
                
            else:  # stats
                column = kwargs["column"]
                values = [row.get(column) for row in data if isinstance(row.get(column), (int, float))]
                
                if values:
                    result = {
                        "count": len(values),
                        "sum": sum(values),
                        "mean": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values)
                    }
                else:
                    result = {"error": "No numeric values found"}
                
                metadata = {"column": column}
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)
