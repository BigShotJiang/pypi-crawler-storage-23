"""
Text processing tools for pygeai-orchestration.

This module provides tools for text manipulation:
- RegexTool: Pattern matching and text extraction
- TextFormatterTool: Format and transform text
- TemplateRendererTool: Render templates with variable substitution
"""

import time
import re
from typing import Any, Dict, List, Optional, Union
from string import Template

from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
from pygeai_orchestration.tools.builtin import (
    validate_required_params,
    create_error_result,
    create_success_result,
    ValidationError,
)


class RegexTool(BaseTool):
    """
    Pattern matching and text extraction using regular expressions.
    
    This tool supports match, search, findall, replace, and split operations.
    
    Example:
        >>> tool = RegexTool()
        >>> result = await tool.execute(
        ...     pattern=r'\\d+',
        ...     text='Age: 25 years',
        ...     operation='search'
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="regex",
            description="Pattern matching and text extraction using regular expressions",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regular expression pattern"
                    },
                    "text": {
                        "type": "string",
                        "description": "Text to process"
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["match", "search", "findall", "replace", "split"],
                        "description": "Regex operation to perform"
                    },
                    "replacement": {
                        "type": "string",
                        "description": "Replacement text (for replace operation)"
                    },
                    "flags": {
                        "type": "array",
                        "description": "Regex flags: IGNORECASE, MULTILINE, DOTALL",
                        "items": {"type": "string"}
                    },
                    "max_splits": {
                        "type": "integer",
                        "description": "Maximum splits (for split operation, default: 0 = unlimited)",
                        "default": 0
                    }
                },
                "required": ["pattern", "text", "operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["pattern", "text", "operation"])
            
            operation = parameters.get("operation")
            if operation not in ["match", "search", "findall", "replace", "split"]:
                raise ValidationError("Invalid operation")
            
            if operation == "replace" and "replacement" not in parameters:
                raise ValidationError("replacement required for replace operation")
            
            return True
        except ValidationError:
            return False
    
    def _get_flags(self, flag_list: Optional[List[str]]) -> int:
        """Convert flag names to re flags."""
        if not flag_list:
            return 0
        
        flags = 0
        flag_map = {
            "IGNORECASE": re.IGNORECASE,
            "MULTILINE": re.MULTILINE,
            "DOTALL": re.DOTALL
        }
        
        for flag in flag_list:
            flags |= flag_map.get(flag.upper(), 0)
        
        return flags
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            pattern = kwargs["pattern"]
            text = kwargs["text"]
            operation = kwargs["operation"]
            flags = self._get_flags(kwargs.get("flags"))
            
            if operation == "match":
                match = re.match(pattern, text, flags)
                result = {
                    "matched": match is not None,
                    "groups": list(match.groups()) if match else None,
                    "span": match.span() if match else None
                }
                
            elif operation == "search":
                match = re.search(pattern, text, flags)
                result = {
                    "found": match is not None,
                    "match": match.group(0) if match else None,
                    "groups": list(match.groups()) if match else None,
                    "span": match.span() if match else None
                }
                
            elif operation == "findall":
                matches = re.findall(pattern, text, flags)
                result = {
                    "matches": matches,
                    "count": len(matches)
                }
                
            elif operation == "replace":
                replacement = kwargs["replacement"]
                new_text = re.sub(pattern, replacement, text, flags=flags)
                result = {
                    "text": new_text,
                    "changed": new_text != text
                }
                
            else:  # split
                max_splits = kwargs.get("max_splits", 0)
                parts = re.split(pattern, text, maxsplit=max_splits, flags=flags)
                result = {
                    "parts": parts,
                    "count": len(parts)
                }
            
            metadata = {
                "operation": operation,
                "pattern": pattern,
                "flags": kwargs.get("flags", [])
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except re.error as e:
            return create_error_result(
                ValueError(f"Invalid regex pattern: {e}"),
                time.time() - start
            )
        except Exception as e:
            return create_error_result(e, time.time() - start)


class TextFormatterTool(BaseTool):
    """
    Format and transform text using various operations.
    
    Supports case conversion, trimming, padding, word wrapping,
    and other text transformations.
    
    Example:
        >>> tool = TextFormatterTool()
        >>> result = await tool.execute(
        ...     text='  hello world  ',
        ...     operation='trim'
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="text_formatter",
            description="Format and transform text with various operations",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Text to format"
                    },
                    "operation": {
                        "type": "string",
                        "enum": [
                            "uppercase", "lowercase", "titlecase", "capitalize",
                            "trim", "ltrim", "rtrim",
                            "pad_left", "pad_right", "center",
                            "wrap", "truncate", "reverse",
                            "remove_extra_spaces", "slugify"
                        ],
                        "description": "Formatting operation to perform"
                    },
                    "width": {
                        "type": "integer",
                        "description": "Width for padding/wrapping/truncate operations",
                        "minimum": 1
                    },
                    "fill_char": {
                        "type": "string",
                        "description": "Character for padding (default: space)",
                        "default": " "
                    },
                    "suffix": {
                        "type": "string",
                        "description": "Suffix for truncate (default: '...')",
                        "default": "..."
                    }
                },
                "required": ["text", "operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["text", "operation"])
            
            operation = parameters.get("operation")
            valid_ops = [
                "uppercase", "lowercase", "titlecase", "capitalize",
                "trim", "ltrim", "rtrim",
                "pad_left", "pad_right", "center",
                "wrap", "truncate", "reverse",
                "remove_extra_spaces", "slugify"
            ]
            
            if operation not in valid_ops:
                raise ValidationError("Invalid operation")
            
            if operation in ["pad_left", "pad_right", "center", "wrap", "truncate"]:
                if "width" not in parameters:
                    raise ValidationError(f"width required for {operation} operation")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            text = kwargs["text"]
            operation = kwargs["operation"]
            
            if operation == "uppercase":
                result = text.upper()
            elif operation == "lowercase":
                result = text.lower()
            elif operation == "titlecase":
                result = text.title()
            elif operation == "capitalize":
                result = text.capitalize()
            elif operation == "trim":
                result = text.strip()
            elif operation == "ltrim":
                result = text.lstrip()
            elif operation == "rtrim":
                result = text.rstrip()
            elif operation == "pad_left":
                width = kwargs["width"]
                fill_char = kwargs.get("fill_char", " ")
                result = text.rjust(width, fill_char)
            elif operation == "pad_right":
                width = kwargs["width"]
                fill_char = kwargs.get("fill_char", " ")
                result = text.ljust(width, fill_char)
            elif operation == "center":
                width = kwargs["width"]
                fill_char = kwargs.get("fill_char", " ")
                result = text.center(width, fill_char)
            elif operation == "wrap":
                width = kwargs["width"]
                words = text.split()
                lines = []
                current_line = []
                current_length = 0
                
                for word in words:
                    word_len = len(word)
                    if current_length + word_len + len(current_line) <= width:
                        current_line.append(word)
                        current_length += word_len
                    else:
                        if current_line:
                            lines.append(" ".join(current_line))
                        current_line = [word]
                        current_length = word_len
                
                if current_line:
                    lines.append(" ".join(current_line))
                
                result = "\n".join(lines)
            elif operation == "truncate":
                width = kwargs["width"]
                suffix = kwargs.get("suffix", "...")
                if len(text) <= width:
                    result = text
                else:
                    result = text[:width - len(suffix)] + suffix
            elif operation == "reverse":
                result = text[::-1]
            elif operation == "remove_extra_spaces":
                result = " ".join(text.split())
            else:  # slugify
                result = re.sub(r'[^\w\s-]', '', text.lower())
                result = re.sub(r'[-\s]+', '-', result).strip('-')
            
            metadata = {
                "operation": operation,
                "original_length": len(text),
                "result_length": len(result)
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except Exception as e:
            return create_error_result(e, time.time() - start)


class TemplateRendererTool(BaseTool):
    """
    Render templates with variable substitution.
    
    Supports simple variable substitution using ${var} syntax.
    
    Example:
        >>> tool = TemplateRendererTool()
        >>> result = await tool.execute(
        ...     template='Hello ${name}!',
        ...     variables={'name': 'World'}
        ... )
    """
    
    def __init__(self):
        config = ToolConfig(
            name="template_renderer",
            description="Render templates with variable substitution",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "template": {
                        "type": "string",
                        "description": "Template string with ${variable} placeholders"
                    },
                    "variables": {
                        "type": "object",
                        "description": "Dictionary of variable names and values"
                    },
                    "safe_substitute": {
                        "type": "boolean",
                        "description": "Use safe substitution (leave missing vars as-is)",
                        "default": False
                    }
                },
                "required": ["template", "variables"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        try:
            validate_required_params(parameters, ["template", "variables"])
            
            if not isinstance(parameters.get("variables"), dict):
                raise ValidationError("variables must be a dictionary")
            
            return True
        except ValidationError:
            return False
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            template_str = kwargs["template"]
            variables = kwargs["variables"]
            safe = kwargs.get("safe_substitute", False)
            
            template = Template(template_str)
            
            if safe:
                result = template.safe_substitute(variables)
            else:
                result = template.substitute(variables)
            
            metadata = {
                "variables_used": list(variables.keys()),
                "template_length": len(template_str),
                "result_length": len(result)
            }
            
            return create_success_result(
                result,
                time.time() - start,
                metadata
            )
            
        except KeyError as e:
            return create_error_result(
                ValueError(f"Missing variable: {e}"),
                time.time() - start
            )
        except Exception as e:
            return create_error_result(e, time.time() - start)
