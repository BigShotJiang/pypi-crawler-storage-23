"""
System operation tools for pygeai-orchestration.

Provides tools for:
- Command execution (with security controls)
- Date/time operations
"""

from typing import Any, Dict, Optional
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time
import subprocess
import shlex
from datetime import datetime, timedelta, timezone
import dateutil.parser


class DateTimeTool(BaseTool):
    """
    Date and time operations tool.
    
    Supports operations:
    - now: Get current date/time
    - parse: Parse date string
    - format: Format datetime
    - add: Add time delta
    - subtract: Subtract time delta
    - diff: Calculate difference between dates
    - timestamp: Convert to/from Unix timestamp
    """
    
    def __init__(self):
        config = ToolConfig(
            name="datetime_tool",
            description="Perform date and time operations including parsing, formatting, and calculations",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform",
                        "enum": ["now", "parse", "format", "add", "subtract", "diff", "timestamp"]
                    },
                    "date_string": {
                        "type": "string",
                        "description": "Date string to parse or format"
                    },
                    "format_string": {
                        "type": "string",
                        "description": "Format string for output (strftime format)",
                        "default": "%Y-%m-%d %H:%M:%S"
                    },
                    "timezone": {
                        "type": "string",
                        "description": "Timezone (e.g., 'UTC', 'local')",
                        "default": "local"
                    },
                    "days": {
                        "type": "integer",
                        "description": "Days to add/subtract",
                        "default": 0
                    },
                    "hours": {
                        "type": "integer",
                        "description": "Hours to add/subtract",
                        "default": 0
                    },
                    "minutes": {
                        "type": "integer",
                        "description": "Minutes to add/subtract",
                        "default": 0
                    },
                    "seconds": {
                        "type": "integer",
                        "description": "Seconds to add/subtract",
                        "default": 0
                    },
                    "date_string2": {
                        "type": "string",
                        "description": "Second date for diff operation"
                    },
                    "timestamp": {
                        "type": "number",
                        "description": "Unix timestamp"
                    }
                },
                "required": ["operation"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if "operation" not in parameters:
            return False
        
        operation = parameters["operation"]
        valid_ops = ["now", "parse", "format", "add", "subtract", "diff", "timestamp"]
        
        if operation not in valid_ops:
            return False
        
        if operation in ["parse", "format", "add", "subtract"] and "date_string" not in parameters:
            return False
        
        if operation == "diff" and ("date_string" not in parameters or "date_string2" not in parameters):
            return False
        
        if operation == "timestamp" and "timestamp" not in parameters and "date_string" not in parameters:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute date/time operation."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            operation = kwargs["operation"]
            
            if operation == "now":
                result = self._get_now(kwargs)
            elif operation == "parse":
                result = self._parse_date(kwargs)
            elif operation == "format":
                result = self._format_date(kwargs)
            elif operation == "add":
                result = self._add_time(kwargs)
            elif operation == "subtract":
                result = self._subtract_time(kwargs)
            elif operation == "diff":
                result = self._diff_dates(kwargs)
            elif operation == "timestamp":
                result = self._handle_timestamp(kwargs)
            else:
                return ToolResult(
                    success=False,
                    error=f"Unknown operation: {operation}",
                    execution_time=time.time() - start
                )
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"operation": operation}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _get_now(self, params: Dict[str, Any]) -> str:
        """Get current date/time."""
        tz = params.get("timezone", "local")
        fmt = params.get("format_string", "%Y-%m-%d %H:%M:%S")
        
        if tz == "UTC":
            dt = datetime.now(timezone.utc)
        else:
            dt = datetime.now()
        
        return dt.strftime(fmt)
    
    def _parse_date(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Parse date string."""
        date_string = params["date_string"]
        dt = dateutil.parser.parse(date_string)
        
        return {
            "year": dt.year,
            "month": dt.month,
            "day": dt.day,
            "hour": dt.hour,
            "minute": dt.minute,
            "second": dt.second,
            "weekday": dt.strftime("%A"),
            "iso_format": dt.isoformat()
        }
    
    def _format_date(self, params: Dict[str, Any]) -> str:
        """Format date string."""
        date_string = params["date_string"]
        fmt = params.get("format_string", "%Y-%m-%d %H:%M:%S")
        
        dt = dateutil.parser.parse(date_string)
        return dt.strftime(fmt)
    
    def _add_time(self, params: Dict[str, Any]) -> str:
        """Add time to date."""
        date_string = params["date_string"]
        dt = dateutil.parser.parse(date_string)
        
        delta = timedelta(
            days=params.get("days", 0),
            hours=params.get("hours", 0),
            minutes=params.get("minutes", 0),
            seconds=params.get("seconds", 0)
        )
        
        result_dt = dt + delta
        fmt = params.get("format_string", "%Y-%m-%d %H:%M:%S")
        return result_dt.strftime(fmt)
    
    def _subtract_time(self, params: Dict[str, Any]) -> str:
        """Subtract time from date."""
        date_string = params["date_string"]
        dt = dateutil.parser.parse(date_string)
        
        delta = timedelta(
            days=params.get("days", 0),
            hours=params.get("hours", 0),
            minutes=params.get("minutes", 0),
            seconds=params.get("seconds", 0)
        )
        
        result_dt = dt - delta
        fmt = params.get("format_string", "%Y-%m-%d %H:%M:%S")
        return result_dt.strftime(fmt)
    
    def _diff_dates(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate difference between two dates."""
        date1 = dateutil.parser.parse(params["date_string"])
        date2 = dateutil.parser.parse(params["date_string2"])
        
        diff = date2 - date1
        
        return {
            "total_seconds": diff.total_seconds(),
            "days": diff.days,
            "hours": diff.seconds // 3600,
            "minutes": (diff.seconds % 3600) // 60,
            "seconds": diff.seconds % 60
        }
    
    def _handle_timestamp(self, params: Dict[str, Any]) -> Any:
        """Convert to/from Unix timestamp."""
        if "timestamp" in params:
            ts = params["timestamp"]
            dt = datetime.fromtimestamp(ts)
            fmt = params.get("format_string", "%Y-%m-%d %H:%M:%S")
            return dt.strftime(fmt)
        else:
            date_string = params["date_string"]
            dt = dateutil.parser.parse(date_string)
            return dt.timestamp()


class CommandExecutorTool(BaseTool):
    """
    Execute system commands with security controls.
    
    SECURITY WARNING: This tool can execute arbitrary commands.
    Use with extreme caution and only in trusted environments.
    
    Features:
    - Command execution with timeout
    - Working directory specification
    - Environment variable control
    - Output capture (stdout/stderr)
    - Return code checking
    """
    
    def __init__(self, allowed_commands: Optional[list] = None, max_timeout: int = 300):
        """
        Initialize command executor.
        
        Args:
            allowed_commands: List of allowed command prefixes (whitelist). None = all allowed.
            max_timeout: Maximum execution timeout in seconds (default: 300)
        """
        self.allowed_commands = allowed_commands
        self.max_timeout = max_timeout
        
        config = ToolConfig(
            name="command_executor",
            description="Execute system commands with security controls and timeout",
            category=ToolCategory.CUSTOM,
            parameters_schema={
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Command to execute"
                    },
                    "shell": {
                        "type": "boolean",
                        "description": "Execute in shell (default: False for security)",
                        "default": False
                    },
                    "cwd": {
                        "type": "string",
                        "description": "Working directory"
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds",
                        "default": 30
                    },
                    "capture_output": {
                        "type": "boolean",
                        "description": "Capture stdout/stderr",
                        "default": True
                    }
                },
                "required": ["command"]
            }
        )
        super().__init__(config)
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        """Validate input parameters."""
        if "command" not in parameters:
            return False
        
        command = parameters["command"]
        
        if self.allowed_commands is not None:
            allowed = any(command.startswith(cmd) for cmd in self.allowed_commands)
            if not allowed:
                return False
        
        timeout = parameters.get("timeout", 30)
        if timeout > self.max_timeout:
            return False
        
        return True
    
    async def execute(self, **kwargs) -> ToolResult:
        """Execute command."""
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters or command not allowed",
                    execution_time=time.time() - start
                )
            
            command = kwargs["command"]
            shell = kwargs.get("shell", False)
            cwd = kwargs.get("cwd")
            timeout = kwargs.get("timeout", 30)
            capture_output = kwargs.get("capture_output", True)
            
            if not shell:
                command_list = shlex.split(command)
            else:
                command_list = command
            
            result = subprocess.run(
                command_list,
                shell=shell,
                cwd=cwd,
                timeout=timeout,
                capture_output=capture_output,
                text=True
            )
            
            return ToolResult(
                success=result.returncode == 0,
                result={
                    "stdout": result.stdout if capture_output else None,
                    "stderr": result.stderr if capture_output else None,
                    "return_code": result.returncode
                },
                execution_time=time.time() - start,
                metadata={
                    "command": command,
                    "return_code": result.returncode
                }
            )
            
        except subprocess.TimeoutExpired:
            return ToolResult(
                success=False,
                error=f"Command timed out after {timeout} seconds",
                execution_time=time.time() - start
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
