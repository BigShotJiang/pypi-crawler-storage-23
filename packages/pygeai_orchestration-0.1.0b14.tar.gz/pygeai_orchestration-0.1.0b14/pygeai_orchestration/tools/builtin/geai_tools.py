"""
GEAI integration tools for pygeai-orchestration.

Provides tools for:
- OmniParser (OCR, document parsing)
- File upload/download
- Embeddings generation
- Reranking
"""

from typing import Any, Dict, List, Optional, Union
from pygeai_orchestration.core.base.tool import BaseTool, ToolConfig, ToolResult, ToolCategory
import time
import json
import base64
from pathlib import Path

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


class OmniParserTool(BaseTool):
    """
    Parse documents using OmniParser (OCR, PDF extraction, image analysis).
    
    Features:
    - OCR from images
    - PDF text extraction
    - Table extraction
    - Document structure analysis
    
    Note: Requires GEAI API access or compatible endpoint.
    """
    
    def __init__(self, api_endpoint: Optional[str] = None, api_key: Optional[str] = None):
        config = ToolConfig(
            name="omni_parser",
            description="Parse documents with OCR and structure extraction",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to file to parse"
                    },
                    "mode": {
                        "type": "string",
                        "description": "Parsing mode",
                        "enum": ["ocr", "text", "table", "structure"],
                        "default": "text"
                    },
                    "language": {
                        "type": "string",
                        "description": "Language for OCR",
                        "default": "en"
                    },
                    "extract_tables": {
                        "type": "boolean",
                        "description": "Extract tables from document",
                        "default": False
                    },
                    "extract_images": {
                        "type": "boolean",
                        "description": "Extract images from document",
                        "default": False
                    }
                },
                "required": ["file_path"]
            }
        )
        super().__init__(config)
        self.api_endpoint = api_endpoint
        self.api_key = api_key
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "file_path" in parameters and Path(parameters["file_path"]).exists()
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters or file not found",
                    execution_time=time.time() - start
                )
            
            file_path = kwargs["file_path"]
            mode = kwargs.get("mode", "text")
            
            result = self._parse_document_local(
                file_path,
                mode,
                kwargs.get("extract_tables", False),
                kwargs.get("extract_images", False)
            )
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start,
                metadata={"mode": mode, "file": file_path}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _parse_document_local(
        self,
        file_path: str,
        mode: str,
        extract_tables: bool,
        extract_images: bool
    ) -> Dict[str, Any]:
        """Local fallback parser (basic functionality)."""
        path = Path(file_path)
        result = {
            "file_name": path.name,
            "file_type": path.suffix,
            "mode": mode,
            "content": None,
            "tables": [] if extract_tables else None,
            "images": [] if extract_images else None
        }
        
        if path.suffix == ".txt":
            result["content"] = path.read_text()
        elif path.suffix == ".json":
            result["content"] = json.loads(path.read_text())
        else:
            result["content"] = f"Binary file: {path.suffix} ({path.stat().st_size} bytes)"
            result["note"] = "Full parsing requires GEAI API integration"
        
        return result


class FileUploadTool(BaseTool):
    """
    Upload files to cloud storage or API endpoint.
    
    Features:
    - File upload to endpoint
    - Progress tracking
    - Metadata support
    - Multiple file support
    """
    
    def __init__(self, upload_endpoint: Optional[str] = None, api_key: Optional[str] = None):
        config = ToolConfig(
            name="file_upload",
            description="Upload files to cloud storage or API",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to file to upload"
                    },
                    "destination": {
                        "type": "string",
                        "description": "Destination path or identifier"
                    },
                    "metadata": {
                        "type": "object",
                        "description": "Additional metadata for upload"
                    },
                    "overwrite": {
                        "type": "boolean",
                        "description": "Overwrite existing file",
                        "default": False
                    }
                },
                "required": ["file_path"]
            }
        )
        super().__init__(config)
        self.upload_endpoint = upload_endpoint
        self.api_key = api_key
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if not REQUESTS_AVAILABLE:
            return False
        return "file_path" in parameters and Path(parameters["file_path"]).exists()
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters or file not found"
                if not REQUESTS_AVAILABLE:
                    error_msg = "requests library not available"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            file_path = kwargs["file_path"]
            destination = kwargs.get("destination", "default")
            metadata = kwargs.get("metadata", {})
            
            path = Path(file_path)
            file_info = {
                "file_name": path.name,
                "file_size": path.stat().st_size,
                "destination": destination,
                "metadata": metadata,
                "status": "simulated_upload"
            }
            
            if self.upload_endpoint:
                result = self._upload_to_endpoint(file_path, destination, metadata)
            else:
                result = file_info
                result["note"] = "No upload endpoint configured - simulation mode"
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _upload_to_endpoint(
        self,
        file_path: str,
        destination: str,
        metadata: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Upload file to configured endpoint."""
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        with open(file_path, 'rb') as f:
            files = {'file': f}
            data = {'destination': destination, 'metadata': json.dumps(metadata)}
            response = requests.post(self.upload_endpoint, files=files, data=data, headers=headers)
        
        response.raise_for_status()
        return response.json()


class FileDownloadTool(BaseTool):
    """
    Download files from URLs or cloud storage.
    
    Features:
    - HTTP/HTTPS download
    - Progress tracking
    - Resume support (if server supports)
    - Checksum verification
    """
    
    def __init__(self, api_key: Optional[str] = None):
        config = ToolConfig(
            name="file_download",
            description="Download files from URLs or cloud storage",
            category=ToolCategory.DATA_ACCESS,
            parameters_schema={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "URL to download from"
                    },
                    "destination": {
                        "type": "string",
                        "description": "Local path to save file"
                    },
                    "chunk_size": {
                        "type": "integer",
                        "description": "Download chunk size in bytes",
                        "default": 8192
                    },
                    "timeout": {
                        "type": "number",
                        "description": "Download timeout in seconds",
                        "default": 30
                    },
                    "verify_ssl": {
                        "type": "boolean",
                        "description": "Verify SSL certificates",
                        "default": True
                    }
                },
                "required": ["url", "destination"]
            }
        )
        super().__init__(config)
        self.api_key = api_key
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        if not REQUESTS_AVAILABLE:
            return False
        return "url" in parameters and "destination" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                error_msg = "Invalid parameters"
                if not REQUESTS_AVAILABLE:
                    error_msg = "requests library not available"
                return ToolResult(
                    success=False,
                    error=error_msg,
                    execution_time=time.time() - start
                )
            
            url = kwargs["url"]
            destination = kwargs["destination"]
            chunk_size = kwargs.get("chunk_size", 8192)
            timeout = kwargs.get("timeout", 30)
            verify_ssl = kwargs.get("verify_ssl", True)
            
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            response = requests.get(url, stream=True, headers=headers, timeout=timeout, verify=verify_ssl)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            Path(destination).parent.mkdir(parents=True, exist_ok=True)
            
            with open(destination, 'wb') as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
            
            result = {
                "url": url,
                "destination": destination,
                "size": downloaded,
                "total_size": total_size,
                "status": "completed"
            }
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )


class EmbeddingsGeneratorTool(BaseTool):
    """
    Generate embeddings for semantic search and similarity.
    
    Features:
    - Text embeddings
    - Batch processing
    - Multiple embedding models
    - Dimension normalization
    """
    
    def __init__(self, api_endpoint: Optional[str] = None, api_key: Optional[str] = None):
        config = ToolConfig(
            name="embeddings_generator",
            description="Generate embeddings for semantic search",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": ["string", "array"],
                        "description": "Text or list of texts to embed"
                    },
                    "model": {
                        "type": "string",
                        "description": "Embedding model to use",
                        "default": "default"
                    },
                    "normalize": {
                        "type": "boolean",
                        "description": "Normalize embeddings to unit length",
                        "default": True
                    },
                    "dimensions": {
                        "type": "integer",
                        "description": "Target embedding dimensions",
                        "default": 768
                    }
                },
                "required": ["text"]
            }
        )
        super().__init__(config)
        self.api_endpoint = api_endpoint
        self.api_key = api_key
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "text" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            text = kwargs["text"]
            model = kwargs.get("model", "default")
            normalize = kwargs.get("normalize", True)
            dimensions = kwargs.get("dimensions", 768)
            
            if isinstance(text, str):
                texts = [text]
            else:
                texts = text
            
            if self.api_endpoint:
                embeddings = self._generate_via_api(texts, model, normalize, dimensions)
            else:
                embeddings = self._generate_simple_embeddings(texts, dimensions)
            
            result = {
                "embeddings": embeddings if isinstance(text, list) else embeddings[0],
                "model": model,
                "dimensions": dimensions,
                "count": len(texts)
            }
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _generate_simple_embeddings(self, texts: List[str], dimensions: int) -> List[List[float]]:
        """Simple hash-based embeddings for testing (not for production)."""
        import hashlib
        embeddings = []
        for text in texts:
            hash_bytes = hashlib.sha256(text.encode()).digest()
            values = [float(b) / 255.0 for b in hash_bytes[:dimensions]]
            while len(values) < dimensions:
                values.append(0.0)
            embeddings.append(values[:dimensions])
        return embeddings
    
    def _generate_via_api(
        self,
        texts: List[str],
        model: str,
        normalize: bool,
        dimensions: int
    ) -> List[List[float]]:
        """Generate embeddings via API endpoint."""
        if not REQUESTS_AVAILABLE:
            raise RuntimeError("requests library required for API access")
        
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        payload = {
            "texts": texts,
            "model": model,
            "normalize": normalize,
            "dimensions": dimensions
        }
        
        response = requests.post(self.api_endpoint, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["embeddings"]


class RerankTool(BaseTool):
    """
    Rerank search results for improved relevance.
    
    Features:
    - Query-document relevance scoring
    - Batch reranking
    - Multiple reranking models
    - Score normalization
    """
    
    def __init__(self, api_endpoint: Optional[str] = None, api_key: Optional[str] = None):
        config = ToolConfig(
            name="rerank",
            description="Rerank search results for improved relevance",
            category=ToolCategory.COMPUTATION,
            parameters_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query"
                    },
                    "documents": {
                        "type": "array",
                        "description": "List of documents to rerank",
                        "items": {"type": "string"}
                    },
                    "model": {
                        "type": "string",
                        "description": "Reranking model to use",
                        "default": "default"
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "Return top K results",
                        "default": 10
                    },
                    "return_scores": {
                        "type": "boolean",
                        "description": "Include relevance scores",
                        "default": True
                    }
                },
                "required": ["query", "documents"]
            }
        )
        super().__init__(config)
        self.api_endpoint = api_endpoint
        self.api_key = api_key
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> bool:
        return "query" in parameters and "documents" in parameters
    
    async def execute(self, **kwargs) -> ToolResult:
        start = time.time()
        
        try:
            if not self.validate_parameters(kwargs):
                return ToolResult(
                    success=False,
                    error="Invalid parameters",
                    execution_time=time.time() - start
                )
            
            query = kwargs["query"]
            documents = kwargs["documents"]
            model = kwargs.get("model", "default")
            top_k = kwargs.get("top_k", 10)
            return_scores = kwargs.get("return_scores", True)
            
            if self.api_endpoint:
                ranked = self._rerank_via_api(query, documents, model, top_k)
            else:
                ranked = self._rerank_simple(query, documents, top_k)
            
            if not return_scores:
                ranked = [{"document": item["document"], "index": item["index"]} for item in ranked]
            
            result = {
                "query": query,
                "results": ranked,
                "model": model,
                "count": len(ranked)
            }
            
            return ToolResult(
                success=True,
                result=result,
                execution_time=time.time() - start
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _rerank_simple(
        self,
        query: str,
        documents: List[str],
        top_k: int
    ) -> List[Dict[str, Any]]:
        """Simple keyword-based reranking (for testing)."""
        query_words = set(query.lower().split())
        
        scored = []
        for idx, doc in enumerate(documents):
            doc_words = set(doc.lower().split())
            score = len(query_words & doc_words) / max(len(query_words), 1)
            scored.append({
                "document": doc,
                "index": idx,
                "score": score
            })
        
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]
    
    def _rerank_via_api(
        self,
        query: str,
        documents: List[str],
        model: str,
        top_k: int
    ) -> List[Dict[str, Any]]:
        """Rerank via API endpoint."""
        if not REQUESTS_AVAILABLE:
            raise RuntimeError("requests library required for API access")
        
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        payload = {
            "query": query,
            "documents": documents,
            "model": model,
            "top_k": top_k
        }
        
        response = requests.post(self.api_endpoint, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["results"]
