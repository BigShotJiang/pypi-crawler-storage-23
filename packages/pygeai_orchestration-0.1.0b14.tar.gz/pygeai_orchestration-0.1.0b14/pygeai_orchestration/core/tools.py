"""Simple directory-based tool discovery for custom tools."""

import importlib.util
import inspect
import logging
import os
import re
from pathlib import Path
from typing import Dict, Optional, Type

from pygeai_orchestration.core.base.tool import BaseTool, ToolCategory

logger = logging.getLogger("pygeai_orchestration")


class CustomTool:
    """Metadata about a discovered custom tool."""

    def __init__(
        self,
        name: str,
        tool_class: Type[BaseTool],
        description: str,
        source_file: str,
        category: str = "custom",
    ):
        """
        Initialize custom tool metadata.

        :param name: CLI-friendly tool name (e.g., 'my-api-tool', 'calculator')
        :param tool_class: The tool class (must inherit from BaseTool)
        :param description: Short description of what the tool does
        :param source_file: Path to the source file
        :param category: Tool category (defaults to 'custom')
        """
        self.name = name
        self.tool_class = tool_class
        self.description = description
        self.source_file = source_file
        self.category = category


class ToolLoader:
    """Discovers and loads tools from tools directory."""

    def __init__(self, tools_dir: Optional[str] = None):
        """
        Initialize tool loader.

        :param tools_dir: Path to tools directory.
                          Defaults to ~/.geai-orch/tools/
                          Can be overridden with GEAI_ORCH_TOOLS_DIR env var
        """
        if tools_dir:
            self.tools_dir = Path(tools_dir)
        else:
            self.tools_dir = Path(
                os.environ.get(
                    "GEAI_ORCH_TOOLS_DIR", Path.home() / ".geai-orch" / "tools"
                )
            )

        self.tools: Dict[str, CustomTool] = {}

    def discover_tools(self) -> Dict[str, CustomTool]:
        """
        Discover all tools in tools directory.

        Scans the tools directory for Python files, imports them, and finds
        all classes that inherit from BaseTool. Validates each tool
        and registers it if valid.

        :return: Dict mapping tool name to CustomTool metadata
        """
        if not self.tools_dir.exists():
            logger.debug(f"Tools directory not found: {self.tools_dir}")
            logger.debug("Create it with: mkdir -p ~/.geai-orch/tools/")
            return {}

        logger.debug(f"Scanning for tools in: {self.tools_dir}")

        for tool_file in self.tools_dir.glob("*.py"):
            if tool_file.name.startswith("_"):
                continue

            try:
                self._load_tool_file(tool_file)
            except Exception as e:
                logger.error(f"Failed to load {tool_file.name}: {e}")
                logger.debug("Error details:", exc_info=True)

        logger.info(f"Discovered {len(self.tools)} custom tool(s)")
        return self.tools

    def _load_tool_file(self, tool_file: Path) -> None:
        """
        Load tools from a single file.

        :param tool_file: Path to the tool file
        """
        module_name = f"geai_orch_tool_{tool_file.stem}"

        spec = importlib.util.spec_from_file_location(module_name, tool_file)
        if not spec or not spec.loader:
            logger.warning(f"Could not load spec for {tool_file}")
            return

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        for name, obj in inspect.getmembers(module, inspect.isclass):
            if self._is_valid_tool_class(obj, module_name):
                tool_name = self._to_cli_name(name)

                description = self._extract_description(obj)
                category = self._extract_category(obj)

                custom_tool = CustomTool(
                    name=tool_name,
                    tool_class=obj,
                    description=description,
                    source_file=str(tool_file),
                    category=category,
                )

                self.tools[tool_name] = custom_tool
                logger.info(
                    f"Loaded tool '{tool_name}' "
                    f"({obj.__name__}) from {tool_file.name}"
                )

    def _is_valid_tool_class(self, obj: Type, module_name: str) -> bool:
        """
        Check if class is a valid tool.

        :param obj: Class to validate
        :param module_name: Expected module name
        :return: True if valid, False otherwise
        """
        try:
            if not issubclass(obj, BaseTool):
                return False
        except TypeError:
            return False

        if obj is BaseTool:
            return False

        if obj.__module__ != module_name:
            return False

        required_methods = ["execute", "validate_parameters"]
        for method in required_methods:
            if not hasattr(obj, method):
                logger.warning(
                    f"Tool {obj.__name__} missing required method: {method}"
                )
                return False

        return True

    @staticmethod
    def _to_cli_name(class_name: str) -> str:
        """
        Convert class name to CLI-friendly name.

        Examples:
          MyAPITool -> my-api-tool
          CalculatorTool -> calculator
          CustomWebScraper -> custom-web-scraper

        :param class_name: Python class name
        :return: CLI-friendly kebab-case name
        """
        name = class_name.replace("Tool", "")

        name = re.sub("([A-Z]+)", r"-\1", name).lower().strip("-")

        return name

    @staticmethod
    def _extract_description(tool_class: Type) -> str:
        """
        Extract short description from class docstring.

        :param tool_class: Tool class
        :return: First line of docstring or default description
        """
        doc = tool_class.__doc__
        if not doc:
            return f"Custom tool: {tool_class.__name__}"

        lines = [line.strip() for line in doc.split("\n") if line.strip()]
        return lines[0] if lines else f"Custom tool: {tool_class.__name__}"

    @staticmethod
    def _extract_category(tool_class: Type) -> str:
        """
        Extract category from class attribute or default to 'custom'.

        :param tool_class: Tool class
        :return: Category string
        """
        if hasattr(tool_class, "category"):
            category = tool_class.category
            if isinstance(category, ToolCategory):
                return category.value
            return str(category)
        return "custom"
