"""Simple directory-based plugin discovery for custom patterns."""

import importlib.util
import inspect
import logging
import os
import re
from pathlib import Path
from typing import Dict, Optional, Type

from pygeai_orchestration.core.base import BasePattern

logger = logging.getLogger("pygeai_orchestration")


class PluginPattern:
    """Metadata about a discovered pattern."""

    def __init__(
        self,
        name: str,
        pattern_class: Type[BasePattern],
        description: str,
        source_file: str,
    ):
        """
        Initialize plugin pattern metadata.

        :param name: CLI-friendly pattern name (e.g., 'debate', 'chain-of-thought')
        :param pattern_class: The pattern class (must inherit from BasePattern)
        :param description: Short description of what the pattern does
        :param source_file: Path to the source file
        """
        self.name = name
        self.pattern_class = pattern_class
        self.description = description
        self.source_file = source_file


class PluginLoader:
    """Discovers and loads patterns from plugins directory."""

    def __init__(self, plugin_dir: Optional[str] = None):
        """
        Initialize plugin loader.

        :param plugin_dir: Path to plugins directory.
                          Defaults to ~/.geai-orch/plugins/
                          Can be overridden with GEAI_ORCH_PLUGINS_DIR env var
        """
        if plugin_dir:
            self.plugin_dir = Path(plugin_dir)
        else:
            self.plugin_dir = Path(
                os.environ.get(
                    "GEAI_ORCH_PLUGINS_DIR", Path.home() / ".geai-orch" / "plugins"
                )
            )

        self.patterns: Dict[str, PluginPattern] = {}

    def discover_patterns(self) -> Dict[str, PluginPattern]:
        """
        Discover all patterns in plugin directory.

        Scans the plugin directory for Python files, imports them, and finds
        all classes that inherit from BasePattern. Validates each pattern
        and registers it if valid.

        :return: Dict mapping pattern name to PluginPattern metadata
        """
        if not self.plugin_dir.exists():
            logger.debug(f"Plugin directory not found: {self.plugin_dir}")
            logger.debug("Create it with: mkdir -p ~/.geai-orch/plugins/")
            return {}

        logger.debug(f"Scanning for plugins in: {self.plugin_dir}")

        for pattern_file in self.plugin_dir.glob("*.py"):
            # Skip __init__.py and private files
            if pattern_file.name.startswith("_"):
                continue

            try:
                self._load_pattern_file(pattern_file)
            except Exception as e:
                logger.error(f"Failed to load {pattern_file.name}: {e}")
                logger.debug("Error details:", exc_info=True)

        logger.info(f"Discovered {len(self.patterns)} custom pattern(s)")
        return self.patterns

    def _load_pattern_file(self, pattern_file: Path) -> None:
        """
        Load patterns from a single file.

        :param pattern_file: Path to the pattern file
        """
        module_name = f"geai_orch_plugin_{pattern_file.stem}"

        # Load the module
        spec = importlib.util.spec_from_file_location(module_name, pattern_file)
        if not spec or not spec.loader:
            logger.warning(f"Could not load spec for {pattern_file}")
            return

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        # Find all BasePattern subclasses
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if self._is_valid_pattern_class(obj, module_name):
                pattern_name = self._to_cli_name(name)

                # Extract description from docstring
                description = self._extract_description(obj)

                plugin = PluginPattern(
                    name=pattern_name,
                    pattern_class=obj,
                    description=description,
                    source_file=str(pattern_file),
                )

                self.patterns[pattern_name] = plugin
                logger.info(
                    f"Loaded pattern '{pattern_name}' "
                    f"({obj.__name__}) from {pattern_file.name}"
                )

    def _is_valid_pattern_class(self, obj: Type, module_name: str) -> bool:
        """
        Check if class is a valid pattern.

        :param obj: Class to validate
        :param module_name: Expected module name
        :return: True if valid, False otherwise
        """
        try:
            # Must be a subclass of BasePattern
            if not issubclass(obj, BasePattern):
                return False
        except TypeError:
            return False

        # Must not be BasePattern itself
        if obj is BasePattern:
            return False

        # Must be defined in this module (not imported)
        if obj.__module__ != module_name:
            return False

        # Validate required methods
        required_methods = ["execute", "step"]
        for method in required_methods:
            if not hasattr(obj, method):
                logger.warning(
                    f"Pattern {obj.__name__} missing required method: {method}"
                )
                return False

        return True

    @staticmethod
    def _to_cli_name(class_name: str) -> str:
        """
        Convert class name to CLI-friendly name.

        Examples:
          DebatePattern -> debate
          ChainOfThoughtPattern -> chain-of-thought
          MyCustomPattern -> my-custom

        :param class_name: Python class name
        :return: CLI-friendly kebab-case name
        """
        # Remove 'Pattern' suffix if present
        name = class_name.replace("Pattern", "")

        # Convert CamelCase to kebab-case
        name = re.sub("([A-Z]+)", r"-\1", name).lower().strip("-")

        return name

    @staticmethod
    def _extract_description(pattern_class: Type) -> str:
        """
        Extract short description from class docstring.

        :param pattern_class: Pattern class
        :return: First line of docstring or default description
        """
        doc = pattern_class.__doc__
        if not doc:
            return f"Custom pattern: {pattern_class.__name__}"

        # Get first non-empty line
        lines = [line.strip() for line in doc.split("\n") if line.strip()]
        return lines[0] if lines else f"Custom pattern: {pattern_class.__name__}"
