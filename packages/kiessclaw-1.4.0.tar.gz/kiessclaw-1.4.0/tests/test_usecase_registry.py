"""Tests for built-in use case registry behavior."""

from __future__ import annotations

import unittest

from kiessclaw.usecases.registry import get_usecase, list_usecases, validate_usecase
from kiessclaw.usecases.schema import UseCaseSpec


class UseCaseRegistryTest(unittest.TestCase):
    """Validate default registry inventory and schema constraints."""

    def test_list_usecases_returns_six(self) -> None:
        """Registry should expose the six default v1.2 use cases."""
        specs = list_usecases()
        self.assertEqual(6, len(specs))
        self.assertEqual("client_onboarding", specs[0].id)

    def test_get_usecase_has_required_fields(self) -> None:
        """Single use case should include all required prompt templates and inputs."""
        spec = get_usecase("outreach_sdr")
        self.assertEqual("outreach_sdr", spec.id)
        self.assertIn("system", spec.prompt_templates)
        self.assertIn("task", spec.prompt_templates)
        self.assertGreaterEqual(len(spec.required_inputs), 1)

    def test_validate_usecase_fails_for_missing_templates(self) -> None:
        """Schema validation should fail loudly on malformed use case specs."""
        broken = UseCaseSpec(
            id="broken",
            title="Broken",
            description="Broken spec",
            required_inputs=["x"],
            outputs=["y"],
            recommended_agents=["KPRO"],
            workflows=["w"],
            prompt_templates={"system": "x"},
            scaffold_templates=["agent.py.tmpl"],
        )
        with self.assertRaises(ValueError):
            validate_usecase(broken)


if __name__ == "__main__":
    unittest.main()
