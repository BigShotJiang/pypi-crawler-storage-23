"""Mock provider implementation for offline-safe defaults."""

from __future__ import annotations

from kiessclaw.providers.base import BaseProvider
from kiessclaw.providers.models import ProviderResult


class MockProvider(BaseProvider):
    """Provider that returns deterministic low-confidence synthetic data."""

    name = "mock"
    kind = "enrichment"

    def find_email(self, first: str, last: str, domain: str) -> ProviderResult:
        """Return plausible deterministic email guess."""
        local_first = (first or "user").strip().lower().replace(" ", ".")
        local_last = (last or "contact").strip().lower().replace(" ", ".")
        safe_domain = (domain or "example.com").strip().lower()
        email = f"{local_first}.{local_last}@{safe_domain}"
        return ProviderResult(
            ok=True,
            data={"email": email, "source": "mock"},
            provider=self.name,
            confidence=0.1,
        )

    def enrich_contact(self, email: str) -> ProviderResult:
        """Return synthetic enrichment payload for one email."""
        value = (email or "user@example.com").strip().lower()
        local = value.split("@", 1)[0]
        domain = value.split("@", 1)[1] if "@" in value else "example.com"
        first = local.split(".", 1)[0].title()
        last = local.split(".", 1)[1].title() if "." in local else ""
        return ProviderResult(
            ok=True,
            data={
                "email": value,
                "first_name": first,
                "last_name": last,
                "company_domain": domain,
                "title": "Unknown",
                "source": "mock",
            },
            provider=self.name,
            confidence=0.1,
        )

    def health_check(self) -> bool:
        """Always healthy for offline usage."""
        return True
