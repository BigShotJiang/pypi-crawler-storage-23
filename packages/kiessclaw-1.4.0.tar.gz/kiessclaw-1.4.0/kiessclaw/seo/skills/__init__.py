"""SEO skill implementations."""

