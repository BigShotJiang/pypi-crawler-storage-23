"""Schema models for KIESSCLAW use case definitions."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class UseCaseSpec:
    """Declarative contract for one CLI use case."""

    id: str
    title: str
    description: str
    required_inputs: list[str]
    outputs: list[str]
    recommended_agents: list[str]
    workflows: list[str]
    prompt_templates: dict[str, str]
    scaffold_templates: list[str] = field(default_factory=list)
