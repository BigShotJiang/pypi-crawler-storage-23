"""Account data model - represents a company/organization."""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import uuid


@dataclass
class Account:
    """
    Represents a company/organization being prospected.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    domain: str = ""
    name: str = ""
    industry: Optional[str] = None
    employee_count: Optional[int] = None
    revenue_range: Optional[str] = None
    technologies: list[str] = field(default_factory=list)
    location: Optional[str] = None
    linkedin_url: Optional[str] = None
    icp_score: int = 0
    enrichment_data: dict = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "domain": self.domain,
            "name": self.name,
            "industry": self.industry,
            "employee_count": self.employee_count,
            "revenue_range": self.revenue_range,
            "technologies": self.technologies,
            "location": self.location,
            "linkedin_url": self.linkedin_url,
            "icp_score": self.icp_score,
            "enrichment_data": self.enrichment_data,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> Account:
        """Create Account from dictionary."""
        data = data.copy()
        if "created_at" in data and isinstance(data["created_at"], str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])
        if "updated_at" in data and isinstance(data["updated_at"], str):
            data["updated_at"] = datetime.fromisoformat(data["updated_at"])
        return cls(**data)

    def update(self, **kwargs) -> None:
        """Update account fields."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.updated_at = datetime.now()
