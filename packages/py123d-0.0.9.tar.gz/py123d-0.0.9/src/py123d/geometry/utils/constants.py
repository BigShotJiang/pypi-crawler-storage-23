from typing import Final

# TODO: Figure out, if there is a more elegant way to handle geometric constants.

DEFAULT_Z: Final[float] = 0.0
DEFAULT_ROLL: Final[float] = 0.0
DEFAULT_PITCH: Final[float] = 0.0
