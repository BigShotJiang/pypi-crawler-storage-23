import logging
from pathlib import Path
from typing import Dict

import numpy as np

from py123d.conversion.registry.lidar_index_registry import KITTI360LiDARIndex
from py123d.datatypes.metadata import LogMetadata
from py123d.datatypes.sensors.lidar import LiDARType
from py123d.geometry.pose import PoseSE3
from py123d.geometry.transform.transform_se3 import reframe_points_3d_array


def load_kitti360_lidar_pcs_from_file(filepath: Path, log_metadata: LogMetadata) -> Dict[LiDARType, np.ndarray]:
    """Loads KITTI-360 LiDAR point clouds the original binary files."""

    if not filepath.exists():
        logging.warning(f"LiDAR file does not exist: {filepath}. Returning empty point cloud.")
        return {LiDARType.LIDAR_TOP: np.zeros((1, len(KITTI360LiDARIndex)), dtype=np.float32)}

    lidar_extrinsic = log_metadata.lidar_metadata[LiDARType.LIDAR_TOP].extrinsic
    lidar_pc = np.fromfile(filepath, dtype=np.float32)
    lidar_pc = np.reshape(lidar_pc, [-1, len(KITTI360LiDARIndex)])

    assert lidar_extrinsic is not None, "LiDAR extrinsic must be available in log metadata."

    lidar_pc[..., KITTI360LiDARIndex.XYZ] = reframe_points_3d_array(
        from_origin=lidar_extrinsic,
        to_origin=PoseSE3(0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
        points_3d_array=lidar_pc[..., KITTI360LiDARIndex.XYZ],  # type: ignore
    )

    return {LiDARType.LIDAR_TOP: lidar_pc}
