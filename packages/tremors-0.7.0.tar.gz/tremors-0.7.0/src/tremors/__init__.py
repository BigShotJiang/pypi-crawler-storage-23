"""The tremors package."""

from importlib import metadata

from tremors.decorator import async_logged, from_logged, logged
from tremors.logger import ENTER_KEY, EXIT_KEY, EXTRA_KEY, Collector, Logger

__project__ = "Tremors"
__distribution__ = "tremors"
__version__ = metadata.version("tremors")
__authors__ = ["Narvin Singh"]

__all__ = [
    "ENTER_KEY",
    "EXIT_KEY",
    "EXTRA_KEY",
    "Collector",
    "Logger",
    "__version__",
    "async_logged",
    "from_logged",
    "logged",
]
