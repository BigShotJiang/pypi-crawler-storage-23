"""Check types."""

from tremors.collector import counter
from tremors.decorator import async_logged, from_logged, logged
from tremors.logger import Logger


@logged
def fn(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(counter.factory())
def fn2(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(counter.factory(), counter.factory())
def fn3(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(counter.factory(), name="fn4")
def fn4(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(counter.factory(), logger_name="check")
def fn5(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(counter.factory(), name="fn6", logger_name="check")
def fn6(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(name="fn7")
def fn7(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(logger_name="check")
def fn8(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@logged(name="fn9", logger_name="check")
def fn9(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged
async def afn(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(counter.factory())
async def afn2(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(counter.factory(), counter.factory())
async def afn3(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(counter.factory(), name="afn4")
async def afn4(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(counter.factory(), logger_name="check")
async def afn5(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(counter.factory(), name="afn6", logger_name="check")
async def afn6(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(name="afn7")
async def afn7(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(logger_name="check")
async def afn8(*, logger: Logger = from_logged) -> None:
    """Regular function."""


@async_logged(name="afn9", logger_name="check")
async def afn9(*, logger: Logger = from_logged) -> None:
    """Regular function."""


counter.factory(step=1)
