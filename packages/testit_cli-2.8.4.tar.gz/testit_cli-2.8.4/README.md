# Test IT CLI

[![Release
Status](https://img.shields.io/pypi/v/testit-cli?style=plastic)](https://pypi.python.org/pypi/testit-cli)
[![Downloads](https://img.shields.io/pypi/dm/testit-cli?style=plastic)](https://pypi.python.org/pypi/testit-cli)

This tool is the command line wrapper of Test IT allowing you to upload the test results in real time to Test IT.
You can see more information in [official documentation](https://docs.testit.software/user-guide/integrations/cli.html)

## Compatibility

| Test IT | Test IT CLI    |
|---------|----------------|
| 3.5+    | 0.1            |
| 4.4     | 1.0            |
| 4.5     | 1.2            |
| 4.6     | 1.5            |
| 5.0     | 2.0            |
| 5.2     | 2.1            |
| 5.2.2   | 2.2.1.post522  |
| 5.2.3   | 2.3.0.post523  |
| 5.3     | 2.4.5.post530  |
| 5.4     | 2.4.11.post540 |
| 5.5     | 2.7.2.post550  |
| 5.6     | 2.8.1.post560  |
| Cloud   | 2.8.0 +        |

1. For current versions, see the releases tab.
2. Starting with 5.2, we have added a TMS postscript, which means that the utility is compatible with a specific enterprise version.
3. If you are in doubt about which version to use, check with the support staff. support@yoonion.ru
