"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'ares_scripting_service.proto')
_sym_db = _symbol_database.Default()
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from .scripting import autocomplete_catalog_pb2 as scripting_dot_autocomplete__catalog__pb2
from .scripting import completion_pb2 as scripting_dot_completion__pb2
from .scripting import diagnostic_pb2 as scripting_dot_diagnostic__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1cares_scripting_service.proto\x12\rares.services\x1a\x1bgoogle/protobuf/empty.proto\x1a$scripting/autocomplete_catalog.proto\x1a\x1ascripting/completion.proto\x1a\x1ascripting/diagnostic.proto"(\n\x16ScriptExecutionRequest\x12\x0e\n\x06script\x18\x01 \x01(\t"\'\n\x15ScriptExecutionOutput\x12\x0e\n\x06output\x18\x01 \x01(\t"\'\n\x15ValidateScriptRequest\x12\x0e\n\x06script\x18\x01 \x01(\t"S\n\x16ValidateScriptResponse\x129\n\x0bdiagnostics\x18\x01 \x03(\x0b2$.ares.datamodel.scripting.Diagnostic"]\n\x1bAutocompleteCatalogResponse\x12>\n\x07catalog\x18\x01 \x01(\x0b2-.ares.datamodel.scripting.AutocompleteCatalog"j\n\x11CompletionRequest\x12\x0e\n\x06script\x18\x01 \x01(\t\x12\x13\n\x0bcursor_line\x18\x02 \x01(\x05\x12\x15\n\rcursor_column\x18\x03 \x01(\x05\x12\x19\n\x11trigger_character\x18\x04 \x01(\t"M\n\x12CompletionResponse\x127\n\x05items\x18\x01 \x03(\x0b2(.ares.datamodel.scripting.CompletionItem2\x8a\x03\n\x14AresScriptingService\x12^\n\rExecuteScript\x12%.ares.services.ScriptExecutionRequest\x1a$.ares.services.ScriptExecutionOutput0\x01\x12\\\n\x16GetAutocompleteCatalog\x12\x16.google.protobuf.Empty\x1a*.ares.services.AutocompleteCatalogResponse\x12U\n\x0eGetCompletions\x12 .ares.services.CompletionRequest\x1a!.ares.services.CompletionResponse\x12]\n\x0eValidateScript\x12$.ares.services.ValidateScriptRequest\x1a%.ares.services.ValidateScriptResponseb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'ares_scripting_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_SCRIPTEXECUTIONREQUEST']._serialized_start = 170
    _globals['_SCRIPTEXECUTIONREQUEST']._serialized_end = 210
    _globals['_SCRIPTEXECUTIONOUTPUT']._serialized_start = 212
    _globals['_SCRIPTEXECUTIONOUTPUT']._serialized_end = 251
    _globals['_VALIDATESCRIPTREQUEST']._serialized_start = 253
    _globals['_VALIDATESCRIPTREQUEST']._serialized_end = 292
    _globals['_VALIDATESCRIPTRESPONSE']._serialized_start = 294
    _globals['_VALIDATESCRIPTRESPONSE']._serialized_end = 377
    _globals['_AUTOCOMPLETECATALOGRESPONSE']._serialized_start = 379
    _globals['_AUTOCOMPLETECATALOGRESPONSE']._serialized_end = 472
    _globals['_COMPLETIONREQUEST']._serialized_start = 474
    _globals['_COMPLETIONREQUEST']._serialized_end = 580
    _globals['_COMPLETIONRESPONSE']._serialized_start = 582
    _globals['_COMPLETIONRESPONSE']._serialized_end = 659
    _globals['_ARESSCRIPTINGSERVICE']._serialized_start = 662
    _globals['_ARESSCRIPTINGSERVICE']._serialized_end = 1056