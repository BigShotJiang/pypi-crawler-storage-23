"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'scripting/completion.proto')
_sym_db = _symbol_database.Default()
from .. import ares_data_schema_pb2 as ares__data__schema__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1ascripting/completion.proto\x12\x18ares.datamodel.scripting\x1a\x16ares_data_schema.proto"\xa4\x03\n\x0eCompletionItem\x12\r\n\x05label\x18\x01 \x01(\t\x12\x13\n\x0binsert_text\x18\x02 \x01(\t\x12F\n\x12insert_text_format\x18\x03 \x01(\x0e2*.ares.datamodel.scripting.InsertTextFormat\x12\x11\n\tsort_text\x18\x04 \x01(\t\x12\x0e\n\x06detail\x18\x05 \x01(\t\x12\x15\n\rdocumentation\x18\x06 \x01(\t\x12:\n\x04kind\x18\x07 \x01(\x0e2,.ares.datamodel.scripting.CompletionItemKind\x12\x19\n\x11parent_identifier\x18\x08 \x01(\t\x124\n\x0cinput_schema\x18\t \x01(\x0b2\x1e.ares.datamodel.AresDataSchema\x122\n\routput_schema\x18\n \x01(\x0b2\x1b.ares.datamodel.SchemaEntry\x12+\n\x06schema\x18\x0b \x01(\x0b2\x1b.ares.datamodel.SchemaEntry*U\n\x10InsertTextFormat\x12!\n\x1dINSERT_TEXT_FORMAT_PLAIN_TEXT\x10\x00\x12\x1e\n\x1aINSERT_TEXT_FORMAT_SNIPPET\x10\x01*\xa9\x02\n\x12CompletionItemKind\x12$\n COMPLETION_ITEM_KIND_UNSPECIFIED\x10\x00\x12\x1f\n\x1bCOMPLETION_ITEM_KIND_DEVICE\x10\x01\x12!\n\x1dCOMPLETION_ITEM_KIND_FUNCTION\x10\x02\x12!\n\x1dCOMPLETION_ITEM_KIND_VARIABLE\x10\x03\x12\x1f\n\x1bCOMPLETION_ITEM_KIND_STRUCT\x10\x04\x12 \n\x1cCOMPLETION_ITEM_KIND_KEYWORD\x10\x05\x12 \n\x1cCOMPLETION_ITEM_KIND_PLANNER\x10\x06\x12!\n\x1dCOMPLETION_ITEM_KIND_ANALYZER\x10\x07b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'scripting.completion_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_INSERTTEXTFORMAT']._serialized_start = 503
    _globals['_INSERTTEXTFORMAT']._serialized_end = 588
    _globals['_COMPLETIONITEMKIND']._serialized_start = 591
    _globals['_COMPLETIONITEMKIND']._serialized_end = 888
    _globals['_COMPLETIONITEM']._serialized_start = 81
    _globals['_COMPLETIONITEM']._serialized_end = 501