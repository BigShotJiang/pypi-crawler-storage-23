"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'scripting/autocomplete_catalog.proto')
_sym_db = _symbol_database.Default()
from ..scripting import function_symbol_pb2 as scripting_dot_function__symbol__pb2
from ..scripting import global_variable_symbol_pb2 as scripting_dot_global__variable__symbol__pb2
from ..scripting import namespace_symbol_pb2 as scripting_dot_namespace__symbol__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n$scripting/autocomplete_catalog.proto\x12\x18ares.datamodel.scripting\x1a\x1fscripting/function_symbol.proto\x1a&scripting/global_variable_symbol.proto\x1a scripting/namespace_symbol.proto"\xf2\x01\n\x13AutocompleteCatalog\x12\x17\n\x0fcatalog_version\x18\x01 \x01(\t\x12=\n\nnamespaces\x18\x02 \x03(\x0b2).ares.datamodel.scripting.NamespaceSymbol\x12B\n\x10global_functions\x18\x03 \x03(\x0b2(.ares.datamodel.scripting.FunctionSymbol\x12?\n\x07globals\x18\x04 \x03(\x0b2..ares.datamodel.scripting.GlobalVariableSymbolb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'scripting.autocomplete_catalog_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_AUTOCOMPLETECATALOG']._serialized_start = 174
    _globals['_AUTOCOMPLETECATALOG']._serialized_end = 416