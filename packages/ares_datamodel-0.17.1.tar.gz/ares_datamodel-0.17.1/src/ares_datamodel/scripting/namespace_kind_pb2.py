"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'scripting/namespace_kind.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1escripting/namespace_kind.proto\x12\x18ares.datamodel.scripting*\x83\x01\n\rNamespaceKind\x12\x1e\n\x1aNAMESPACE_KIND_UNSPECIFIED\x10\x00\x12\x19\n\x15NAMESPACE_KIND_DEVICE\x10\x01\x12\x1a\n\x16NAMESPACE_KIND_PLANNER\x10\x02\x12\x1b\n\x17NAMESPACE_KIND_ANALYZER\x10\x03b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'scripting.namespace_kind_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_NAMESPACEKIND']._serialized_start = 61
    _globals['_NAMESPACEKIND']._serialized_end = 192