"""Tests package for MCP Suno server."""
