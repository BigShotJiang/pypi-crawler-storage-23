from mars.modeling.strategies import MarsXGBStrategy, MarsLGBStrategy

class MarsAutoModelTuner():
    pass