"""CornerdataStore MCP client — connects AI agents to SEC financial data."""

__version__ = "0.1.1"
