# this file is @generated

from .common import BaseModel


class AirwallexConfig(BaseModel):
    secret: str
