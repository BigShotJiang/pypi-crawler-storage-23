# this file is @generated

from .common import BaseModel


class CreateStreamEventsOut(BaseModel):
    pass
