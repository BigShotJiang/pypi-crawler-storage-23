# this file is @generated
import typing as t

from .common import BaseModel


class SinkTransformationOut(BaseModel):
    code: t.Optional[str] = None

    enabled: bool
