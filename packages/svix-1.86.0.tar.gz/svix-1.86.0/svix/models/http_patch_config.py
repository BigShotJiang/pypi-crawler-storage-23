# this file is @generated
import typing as t

from .common import BaseModel


class HttpPatchConfig(BaseModel):
    url: t.Optional[str] = None
