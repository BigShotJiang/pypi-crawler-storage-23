# this file is @generated

from .common import BaseModel


class StripeConfig(BaseModel):
    secret: str
