from enum import Enum
from typing import Optional, List
from datetime import date, datetime
from common.models.common import Platform
from common.models.clip import ClipBase
from common.models.stream_signal import TikTokSettings

from pydantic import BaseModel


class PostStatus(str, Enum):
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    FAILED = "failed"
    CANCELLED = "cancelled"
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"


class PostStatusElement(BaseModel):
    id: int
    status: str


class ScheduledPostBase(BaseModel):
    clip_id: int
    scheduled_datetime: datetime
    user_id: Optional[int] = None
    title: Optional[str] = None
    status: PostStatus = PostStatus.SCHEDULED
    caption: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    tiktok_settings: Optional[TikTokSettings] = None


class ScheduledPostUpdate(BaseModel):
    scheduled_datetime: Optional[datetime]
    platforms: Optional[List[Platform]] = None
    title: Optional[str] = None
    status: PostStatus = PostStatus.SCHEDULED
    caption: Optional[str] = None
    tiktok_settings: Optional[TikTokSettings] = None


class ScheduledPostCreate(ScheduledPostBase):
    platforms: List[Platform]
    tiktok_settings: Optional[TikTokSettings] = None


class PlatformData(BaseModel):
    platform: Platform
    status: PostStatus
    id: Optional[int] = None


class PlatformInfo(BaseModel):
    name: str
    is_enabled: bool


class ScheduledPostFetch(ScheduledPostBase):
    id: int
    platforms: List[PlatformData]
    clip: Optional[ClipBase] = None
    tiktok_settings: Optional[TikTokSettings] = None


class ScheduledPostFilters(BaseModel):
    date_ini: date
    date_end: date
    user_id: Optional[int] = None


class JobPublishingData(BaseModel):
    scheduled_plaform_id: int
    platform: Platform
    caption: Optional[str]
    title: Optional[str]
    clip_id: int
    user_id: int
    tiktok_settings: TikTokSettings


class JobData(BaseModel):
    clip_url: str
    post_id: int
    data_for_job: List[JobPublishingData]
