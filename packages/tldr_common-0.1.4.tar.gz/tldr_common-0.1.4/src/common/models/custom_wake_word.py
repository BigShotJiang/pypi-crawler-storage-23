# common/models/custom_wake_word.py
from pydantic import BaseModel


class CustomWakeWord(BaseModel):
    id: int
    user_id: int
    word: str
    language: str
