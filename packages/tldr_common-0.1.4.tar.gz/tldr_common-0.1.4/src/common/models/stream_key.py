"""
Models for stream keys.

Stream keys are used for direct stream ingestion and are encrypted at rest.
"""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class StreamKeyBase(BaseModel):
    """Base model for stream key data."""

    user_id: int
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: bool = True
    consumer_active: bool = False
    encrypted_key: str


class StreamKeyCreate(StreamKeyBase):
    """Model for creating a new stream key."""

    id: int  # Database ID


class StreamKeyUpdate(BaseModel):
    """Model for updating stream key data."""

    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class StreamKey(StreamKeyBase):
    """Complete stream key model including database ID and timestamps."""

    id: int  # Database ID
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
