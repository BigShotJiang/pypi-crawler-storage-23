# common/pulsar_client.py

from dotenv import find_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict


class MQConfig(BaseSettings):
    """
    Configuration settings for the Message Queue.
    """

    mq_service_url: str = "amqp://guest:guest@localhost:5672"
    mq_username: str = "guest"
    mq_password: str = "guest"

    model_config = SettingsConfigDict(
        env_file=find_dotenv(), env_file_encoding="utf-8", extra="ignore"
    )
