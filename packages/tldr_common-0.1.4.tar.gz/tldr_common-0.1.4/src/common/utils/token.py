from typing import TypeVar, Callable, Awaitable

T = TypeVar("T")
AsyncFn = Callable[..., Awaitable[T]]
