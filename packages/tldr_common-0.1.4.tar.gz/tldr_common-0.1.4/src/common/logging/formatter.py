import colorlog


def get_formatter():
    return colorlog.ColoredFormatter(
        "%(asctime)s %(log_color)s%(bold)s%(levelname)-5s%(reset)s [%(process)d] %(name)s:%(lineno)d | %(message)s",
        log_colors={
            "DEBUG": "cyan",
            "INFO": "green",
            "WARNING": "yellow",
            "ERROR": "red",
            "CRITICAL": "red,bg_white",
        },
    )
