from .cli.cli import main

main()
