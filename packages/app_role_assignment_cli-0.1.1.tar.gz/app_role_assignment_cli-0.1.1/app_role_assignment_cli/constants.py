CLIENT_ID = 'client_id'
CLIENT_SECRET_VALUE = 'client_secret_value'
TENANT_ID = 'tenant_id'
