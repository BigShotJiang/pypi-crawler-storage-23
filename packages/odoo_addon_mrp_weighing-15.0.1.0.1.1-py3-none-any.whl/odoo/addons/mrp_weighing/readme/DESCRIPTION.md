Weighing production finished moves
