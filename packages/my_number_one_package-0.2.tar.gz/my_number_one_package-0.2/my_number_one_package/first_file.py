def printer():
    print("You are in printer")