from .first_file import printer
from .seconde_file import games

printer()
games()