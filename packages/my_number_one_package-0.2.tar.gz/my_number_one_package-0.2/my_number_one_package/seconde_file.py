def games():
    print("You are in Games")