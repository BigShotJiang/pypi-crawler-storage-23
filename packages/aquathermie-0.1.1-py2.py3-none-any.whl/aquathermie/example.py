class Aquathermie :
    def __init__ (self):
        print("Hello aquathermie")