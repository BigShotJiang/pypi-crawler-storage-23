# Analogical reasoning components
