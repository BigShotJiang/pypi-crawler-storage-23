# Sparse computation components
