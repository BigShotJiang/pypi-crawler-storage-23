"""
╔══════════════════════════════════════════════════════════════╗
║                  ZENTEL PRO 1.0.1                            ║
║         Fast Telegram Bot Framework for Python               ║
║                                                              ║
║  Features:                                                   ║
║  • Ultra-fast async Telegram bot engine                      ║
║  • YouTube & media video downloader                          ║
║  • Currency exchange rates                                   ║
║  • Wikipedia → PDF converter                                 ║
║  • QR Code generator                                         ║
╚══════════════════════════════════════════════════════════════╝
"""

__version__ = "1.0.1"
__author__ = "Zentel Team"
__license__ = "MIT"

from zentel_pro.bot import ZentelBot
from zentel_pro.downloader import VideoDownloader
from zentel_pro.currency import CurrencyConverter
from zentel_pro.wiki import WikiToPDF
from zentel_pro.qrcode_gen import QRGenerator
from zentel_pro.filters import Router
from zentel_pro.filters import Filter
from zentel_pro.context import Context

__all__ = [
    "ZentelBot",
    "VideoDownloader",
    "CurrencyConverter",
    "WikiToPDF",
    "QRGenerator",
    "Router",
    "Filter",
    "Context",
]
