"""SSH Auto Port Forwarder - Automatically forward ports from remote SSH servers."""

from ssh_auto_forward.__version__ import __version__

__all__ = ["__version__"]
