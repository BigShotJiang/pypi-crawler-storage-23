"""Full package smoke tests — mocked, no external deps required."""

import os
import re
import subprocess
import sys
import tempfile
from datetime import UTC

from tigunny_memory import (
    AuditBlock,
    AuditChainError,
    BackendType,
    ConfigurationError,
    ConnectionError,
    EmbeddingError,
    EmbeddingProvider,
    GovernanceBackend,
    GovernanceDecision,
    GovernanceViolationError,
    InjectionDetectedError,
    MemoryConfig,
    MemoryEntry,
    MemoryPoisoningError,
    OutcomeScore,
    PIIDetectedError,
    RecallResult,
    ScanResult,
    TigunnyMemory,
    TigunnyMemoryError,
    TTLViolationError,
    __author__,
    __license__,
    __version__,
)
from tigunny_memory.audit.chain import FileAuditBackend, HashChainAuditWriter
from tigunny_memory.governance.dlp import DLPScanner
from tigunny_memory.sync.noop import NoopSwarmSync
from tigunny_memory.types import AuditEventType


class TestImportAllPublicSymbols:
    def test_core_class(self):
        assert TigunnyMemory is not None

    def test_config(self):
        assert MemoryConfig is not None

    def test_types(self):
        assert MemoryEntry is not None
        assert RecallResult is not None
        assert OutcomeScore is not None
        assert ScanResult is not None
        assert GovernanceDecision is not None
        assert AuditBlock is not None

    def test_enums(self):
        assert EmbeddingProvider.OPENAI.value == "openai"
        assert BackendType.QDRANT.value == "qdrant"
        assert GovernanceBackend.MEMORY.value == "memory"

    def test_exceptions(self):
        assert issubclass(ConnectionError, TigunnyMemoryError)
        assert issubclass(EmbeddingError, TigunnyMemoryError)
        assert issubclass(PIIDetectedError, GovernanceViolationError)
        assert issubclass(TTLViolationError, GovernanceViolationError)
        assert issubclass(AuditChainError, TigunnyMemoryError)
        assert issubclass(InjectionDetectedError, TigunnyMemoryError)
        assert issubclass(MemoryPoisoningError, TigunnyMemoryError)
        assert issubclass(ConfigurationError, TigunnyMemoryError)


class TestConfigFromEnv:
    def test_from_env_with_vars(self, monkeypatch):
        monkeypatch.setenv("TIGUNNY_MEMORY_QDRANT_URL", "http://custom:6333")
        monkeypatch.setenv("TIGUNNY_MEMORY_TENANT_ID", "test-tenant")
        monkeypatch.setenv("TIGUNNY_MEMORY_EMBEDDING_PROVIDER", "ollama")
        config = MemoryConfig.from_env()
        assert config.qdrant_url == "http://custom:6333"
        assert config.tenant_id == "test-tenant"


class TestConfigDefaults:
    def test_defaults(self):
        config = MemoryConfig()
        assert config.qdrant_url == "http://localhost:6333"
        assert config.embedding_provider == EmbeddingProvider.OLLAMA
        assert config.tenant_id == "default"
        assert config.max_ttl_days == 90
        assert config.enable_dlp is True
        assert config.enable_audit_chain is True
        assert config.enable_swarm_sync is False
        assert config.recall_top_k == 10
        assert config.outcome_weight == 0.3

    def test_minimal(self):
        config = MemoryConfig.minimal()
        assert config.enable_swarm_sync is False
        assert config.enable_injection_detection is False


class TestVersionIsValidSemver:
    def test_version_format(self):
        assert re.match(r"^\d+\.\d+\.\d+$", __version__)

    def test_author(self):
        assert __author__ == "Tigunny LLC"

    def test_license(self):
        assert __license__ == "Apache-2.0"


class TestCLIVersionExits0:
    def test_cli_version(self):
        result = subprocess.run(
            [sys.executable, "-m", "tigunny_memory.cli", "version"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "tigunny-memory v" in result.stdout


class TestAuditChainFileBackend:
    async def test_five_events_verify_chain(self):
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            path = f.name
        try:
            backend = FileAuditBackend(path)
            await backend.initialize()
            writer = HashChainAuditWriter(backend)

            for i in range(5):
                await writer.append(
                    event_type=AuditEventType.MEMORY_STORE,
                    agent_id="test-agent",
                    tenant_id="test",
                    outcome="allowed",
                    metadata={"index": i},
                )

            result = await writer.verify_chain()
            assert result["valid"] is True
            assert result["checked"] == 5
            assert result["broken_at_sequence"] is None
        finally:
            os.unlink(path)


class TestDLPRedactsEmailSSNAPIKeys:
    def test_redacts_email(self):
        scanner = DLPScanner()
        result = scanner.scan("user@example.com")
        assert result.detected
        assert "[EMAIL_REDACTED]" in result.safe_text

    def test_redacts_ssn(self):
        scanner = DLPScanner()
        result = scanner.scan("SSN: 123-45-6789")
        assert result.detected
        assert "[SSN_REDACTED]" in result.safe_text

    def test_redacts_openai_key(self):
        scanner = DLPScanner()
        text = "key=sk-abcdefghijklmnopqrstuvwxyz"
        result = scanner.scan(text)
        assert result.detected
        assert "sk-" not in result.safe_text


class TestGovernanceBlocksOversizedContent:
    def test_blocks_large(self):
        from tigunny_memory.governance.gate import GovernanceGate
        from tigunny_memory.governance.rules import GovernanceRuleLoader

        rules = GovernanceRuleLoader.default_rules()
        gate = GovernanceGate(rules=rules)
        decision = gate.evaluate_store(
            content={"data": "x" * 60000},
            agent_id="agent-1",
            tenant_id="test",
        )
        assert not decision.allowed


class TestNoopSwarmSyncIsDefault:
    def test_noop_not_active(self):
        sync = NoopSwarmSync()
        assert sync.is_active is False

    async def test_noop_operations(self):
        sync = NoopSwarmSync()
        await sync.publish_discovery(memory_id="x", agent_id="a", tags=[], content_hash="h")
        await sync.publish_outcome(memory_id="x", agent_id="a", outcome_score=0.5)
        await sync.close()


class TestOutcomeRerankingMath:
    def test_weighted_formula(self):
        config = MemoryConfig.minimal()
        mem = TigunnyMemory(config)

        from datetime import datetime

        from tigunny_memory.types import MemoryEntry

        entry = MemoryEntry(
            memory_id="test",
            agent_id="agent-1",
            tenant_id="test",
            content={"data": "test"},
            content_hash="abc",
            outcome_score=0.8,
            outcome_count=5,
            created_at=datetime.now(UTC),
        )

        results = [(entry, 0.9)]
        reranked = mem._rerank_by_outcome(results, outcome_weight=0.3)

        _, semantic, weighted = reranked[0]
        expected = 0.9 * (1.0 + 0.3 * 0.8)  # 0.9 * 1.24 = 1.116
        assert abs(weighted - expected) < 0.001
        assert semantic == 0.9

    def test_new_memory_neutral(self):
        config = MemoryConfig.minimal()
        mem = TigunnyMemory(config)

        from datetime import datetime

        from tigunny_memory.types import MemoryEntry

        entry = MemoryEntry(
            memory_id="new",
            agent_id="agent-1",
            tenant_id="test",
            content={"data": "test"},
            content_hash="abc",
            outcome_score=0.5,
            outcome_count=0,  # New memory
            created_at=datetime.now(UTC),
        )

        results = [(entry, 0.9)]
        reranked = mem._rerank_by_outcome(results, outcome_weight=0.3)
        _, _, weighted = reranked[0]
        expected = 0.9 * (1.0 + 0.3 * 0.5)  # neutral 0.5
        assert abs(weighted - expected) < 0.001
