"""Unit tests for swarm sync and outcome learning."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock

from tigunny_memory.config import EmbeddingProvider, GovernanceBackend, MemoryConfig
from tigunny_memory.memory import TigunnyMemory
from tigunny_memory.sync.noop import NoopSwarmSync
from tigunny_memory.types import MemoryEntry


class TestNoopSwarmSync:
    def test_is_not_active(self):
        sync = NoopSwarmSync()
        assert sync.is_active is False

    async def test_publish_discovery_noop(self):
        sync = NoopSwarmSync()
        await sync.publish_discovery(memory_id="x", agent_id="a", tags=[], content_hash="h")

    async def test_publish_outcome_noop(self):
        sync = NoopSwarmSync()
        await sync.publish_outcome(memory_id="x", agent_id="a", outcome_score=0.5)

    async def test_subscribe_noop(self):
        sync = NoopSwarmSync()
        await sync.subscribe(callback=lambda x: x)

    async def test_close_noop(self):
        sync = NoopSwarmSync()
        await sync.close()


class TestOutcomeReranking:
    def _make_entry(self, memory_id, outcome_score, outcome_count):
        return MemoryEntry(
            memory_id=memory_id,
            agent_id="agent-1",
            tenant_id="test",
            content={"data": "test"},
            content_hash="abc",
            outcome_score=outcome_score,
            outcome_count=outcome_count,
            created_at=datetime.now(UTC),
        )

    def test_rerank_favors_high_outcome(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)

        results = [
            (self._make_entry("low", 0.2, 5), 0.9),   # high semantic, low outcome
            (self._make_entry("high", 0.9, 5), 0.85),  # lower semantic, high outcome
        ]

        reranked = mem._rerank_by_outcome(results, outcome_weight=0.3)
        assert reranked[0][0].memory_id == "high"

    def test_rerank_neutral_for_new_memories(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)

        results = [
            (self._make_entry("new", 0.5, 0), 0.8),     # new, neutral
            (self._make_entry("poor", 0.1, 10), 0.8),    # old, poor outcome
        ]

        reranked = mem._rerank_by_outcome(results, outcome_weight=0.3)
        assert reranked[0][0].memory_id == "new"  # neutral beats poor

    def test_rerank_pure_semantic_when_weight_zero(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)

        results = [
            (self._make_entry("a", 0.9, 5), 0.7),
            (self._make_entry("b", 0.1, 5), 0.9),
        ]

        reranked = mem._rerank_by_outcome(results, outcome_weight=0.0)
        assert reranked[0][0].memory_id == "b"  # higher semantic wins

    def test_weighted_score_formula(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)

        results = [
            (self._make_entry("test", 0.8, 3), 0.9),
        ]

        reranked = mem._rerank_by_outcome(results, outcome_weight=0.3)
        entry, semantic, weighted = reranked[0]
        expected = 0.9 * (1.0 + 0.3 * 0.8)  # = 0.9 * 1.24 = 1.116
        assert abs(weighted - expected) < 0.001


class TestOutcomeLearning:
    async def test_rolling_average_formula(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)
        mem._connected = True

        mock_backend = AsyncMock()
        mock_backend.get_outcome = AsyncMock(
            return_value={"outcome_score": 0.6, "outcome_count": 4}
        )
        mock_backend.update_outcome = AsyncMock()
        mem._vector_backend = mock_backend
        mem._swarm_sync = NoopSwarmSync()
        mem._audit_writer = None

        result = await mem.learn("agent-1", "mem-1", 1.0)
        # (0.6 * 4 + 1.0) / 5 = 3.4 / 5 = 0.68
        assert abs(result.new_score - 0.68) < 0.01
        assert result.outcome_count == 5

    async def test_capped_count_at_10(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_injection_detection=False,
            enable_audit_chain=False,
            enable_dlp=False,
        )
        mem = TigunnyMemory(config)
        mem._connected = True

        mock_backend = AsyncMock()
        mock_backend.get_outcome = AsyncMock(
            return_value={"outcome_score": 0.5, "outcome_count": 20}
        )
        mock_backend.update_outcome = AsyncMock()
        mem._vector_backend = mock_backend
        mem._swarm_sync = NoopSwarmSync()
        mem._audit_writer = None

        result = await mem.learn("agent-1", "mem-1", 1.0)
        # capped_count = min(20, 10) = 10
        # (0.5 * 10 + 1.0) / 11 = 6.0 / 11 ≈ 0.5454
        assert abs(result.new_score - (6.0 / 11)) < 0.01
