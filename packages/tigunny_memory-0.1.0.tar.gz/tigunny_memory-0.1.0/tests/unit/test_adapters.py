"""Unit tests for embedding adapters — mocked, no real API calls."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tigunny_memory.adapters.base import EmbeddingAdapterFactory
from tigunny_memory.adapters.custom import CustomEmbeddingAdapter
from tigunny_memory.adapters.ollama import OllamaEmbeddingAdapter
from tigunny_memory.adapters.openai import OpenAIEmbeddingAdapter
from tigunny_memory.adapters.voyage import VoyageEmbeddingAdapter
from tigunny_memory.config import EmbeddingProvider, MemoryConfig
from tigunny_memory.exceptions import ConfigurationError, EmbeddingError


class TestOpenAIAdapter:
    def test_dimensions_small(self):
        adapter = OpenAIEmbeddingAdapter(api_key="test", model="text-embedding-3-small")
        assert adapter.dimensions == 1536

    def test_dimensions_large(self):
        adapter = OpenAIEmbeddingAdapter(api_key="test", model="text-embedding-3-large")
        assert adapter.dimensions == 3072

    def test_model_name(self):
        adapter = OpenAIEmbeddingAdapter(api_key="test")
        assert adapter.model_name == "text-embedding-3-small"

    async def test_embed_success(self):
        adapter = OpenAIEmbeddingAdapter(api_key="test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 1536}]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            result = await adapter.embed("test text")
            assert len(result) == 1536

    async def test_embed_batch(self):
        adapter = OpenAIEmbeddingAdapter(api_key="test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [
                {"index": 0, "embedding": [0.1] * 1536},
                {"index": 1, "embedding": [0.2] * 1536},
            ]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            results = await adapter.embed_batch(["text1", "text2"])
            assert len(results) == 2


class TestOllamaAdapter:
    def test_default_model(self):
        adapter = OllamaEmbeddingAdapter()
        assert adapter.model_name == "nomic-embed-text"
        assert adapter.dimensions == 768

    async def test_embed_success(self):
        adapter = OllamaEmbeddingAdapter()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"embedding": [0.1] * 768}

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            result = await adapter.embed("test")
            assert len(result) == 768

    async def test_model_not_found(self):
        adapter = OllamaEmbeddingAdapter(model="nonexistent")
        mock_response = MagicMock()
        mock_response.status_code = 404

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            with pytest.raises(EmbeddingError, match="ollama pull"):
                await adapter.embed("test")

    async def test_health_check_with_model_present(self):
        adapter = OllamaEmbeddingAdapter()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "models": [{"name": "nomic-embed-text:latest"}]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.get = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            assert await adapter.health_check() is True


class TestVoyageAdapter:
    def test_default_model(self):
        adapter = VoyageEmbeddingAdapter(api_key="test")
        assert adapter.model_name == "voyage-3"
        assert adapter.dimensions == 1024

    async def test_embed(self):
        adapter = VoyageEmbeddingAdapter(api_key="test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 1024}]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            result = await adapter.embed("test")
            assert len(result) == 1024


class TestCustomAdapter:
    def test_requires_url(self):
        with pytest.raises(ConfigurationError, match="custom_embedding_url"):
            CustomEmbeddingAdapter(endpoint_url="", dimensions=768)

    def test_requires_dimensions(self):
        with pytest.raises(ConfigurationError, match="embedding_dimensions"):
            CustomEmbeddingAdapter(endpoint_url="http://localhost:8080", dimensions=0)

    async def test_embed(self):
        adapter = CustomEmbeddingAdapter(
            endpoint_url="http://localhost:8080/embeddings",
            dimensions=768,
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 768}]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_cls.return_value = mock_client

            result = await adapter.embed("test")
            assert len(result) == 768


class TestAdapterFactory:
    def test_creates_openai(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.OPENAI,
            openai_api_key="test-key",
        )
        adapter = EmbeddingAdapterFactory.from_config(config)
        assert isinstance(adapter, OpenAIEmbeddingAdapter)

    def test_creates_ollama(self):
        config = MemoryConfig(embedding_provider=EmbeddingProvider.OLLAMA)
        adapter = EmbeddingAdapterFactory.from_config(config)
        assert isinstance(adapter, OllamaEmbeddingAdapter)

    def test_creates_voyage(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.VOYAGE,
            voyage_api_key="test-key",
        )
        adapter = EmbeddingAdapterFactory.from_config(config)
        assert isinstance(adapter, VoyageEmbeddingAdapter)

    def test_creates_custom(self):
        config = MemoryConfig(
            embedding_provider=EmbeddingProvider.CUSTOM,
            custom_embedding_url="http://localhost:8080/embed",
            embedding_dimensions=768,
        )
        adapter = EmbeddingAdapterFactory.from_config(config)
        assert isinstance(adapter, CustomEmbeddingAdapter)
