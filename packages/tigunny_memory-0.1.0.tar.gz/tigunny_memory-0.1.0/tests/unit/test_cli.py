"""Unit tests for CLI commands."""

import subprocess
import sys

import pytest


class TestCLI:
    def test_version_command(self):
        result = subprocess.run(
            [sys.executable, "-m", "tigunny_memory.cli", "version"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0
        assert "tigunny-memory v0.1.0" in result.stdout
        assert "Optional dependencies:" in result.stdout

    def test_no_command_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "tigunny_memory.cli"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0

    def test_stats_command(self):
        result = subprocess.run(
            [sys.executable, "-m", "tigunny_memory.cli", "stats"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0
        assert "tigunny-memory" in result.stdout

    def test_version_info_function(self):
        from tigunny_memory.cli import _get_version_info
        info = _get_version_info()
        assert "version" in info
        assert info["version"] == "0.1.0"
        assert "optional_deps" in info

    def test_cmd_version_returns_0(self):
        import argparse

        from tigunny_memory.cli import cmd_version
        args = argparse.Namespace()
        assert cmd_version(args) == 0

    def test_cmd_stats_returns_0(self):
        import argparse

        from tigunny_memory.cli import cmd_stats
        args = argparse.Namespace()
        assert cmd_stats(args) == 0


class TestCLIMain:
    def test_main_no_args(self):
        import sys

        from tigunny_memory.cli import main
        old_argv = sys.argv
        sys.argv = ["tigunny-memory"]
        try:
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0
        finally:
            sys.argv = old_argv

    def test_main_version(self):
        import sys

        from tigunny_memory.cli import main
        old_argv = sys.argv
        sys.argv = ["tigunny-memory", "version"]
        try:
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0
        finally:
            sys.argv = old_argv
