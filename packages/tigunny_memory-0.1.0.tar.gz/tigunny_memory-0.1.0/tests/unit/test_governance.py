"""Unit tests for governance gate, DLP scanner, and audit chain."""

import os
import tempfile

import pytest

from tigunny_memory.audit.chain import FileAuditBackend, HashChainAuditWriter
from tigunny_memory.exceptions import PIIDetectedError
from tigunny_memory.governance.dlp import DLPScanner
from tigunny_memory.governance.gate import GovernanceGate
from tigunny_memory.governance.rules import GovernanceRuleLoader
from tigunny_memory.types import AuditEventType


class TestDLPScanner:
    def setup_method(self):
        self.scanner = DLPScanner()

    def test_detects_email(self):
        result = self.scanner.scan("Contact me at user@example.com")
        assert result.detected
        assert any(f.pattern_name == "email" for f in result.findings)

    def test_detects_ssn(self):
        result = self.scanner.scan("SSN: 123-45-6789")
        assert result.detected
        assert any(f.pattern_name == "ssn" for f in result.findings)

    def test_detects_credit_card(self):
        result = self.scanner.scan("Card: 4111-1111-1111-1111")
        assert result.detected

    def test_detects_openai_key(self):
        result = self.scanner.scan("key: sk-abcdefghijklmnopqrstuvwxyz")
        assert result.detected

    def test_detects_anthropic_key(self):
        result = self.scanner.scan("key: sk-ant-abcdefghijklmnopqrstuvwxyz")
        assert result.detected

    def test_detects_aws_key(self):
        result = self.scanner.scan("AKIAIOSFODNN7EXAMPLE")
        assert result.detected

    def test_clean_text_passes(self):
        result = self.scanner.scan("This is a normal task description with no PII")
        assert not result.detected

    def test_redact_replaces_email(self):
        text = "Email: user@example.com"
        redacted = self.scanner.redact(text)
        assert "[EMAIL_REDACTED]" in redacted
        assert "user@example.com" not in redacted

    def test_redact_replaces_ssn(self):
        text = "SSN: 123-45-6789"
        redacted = self.scanner.redact(text)
        assert "[SSN_REDACTED]" in redacted

    def test_scan_dict_recursive(self):
        data = {
            "name": "John",
            "email": "john@example.com",
            "nested": {"ssn": "123-45-6789"},
        }
        result = self.scanner.scan_dict(data)
        assert result.detected
        assert len(result.findings) >= 2


class TestGovernanceRuleLoader:
    def test_default_rules_include_retention(self):
        rules = GovernanceRuleLoader.default_rules()
        ids = {r.rule_id for r in rules}
        assert "default-retention" in ids

    def test_default_rules_include_size(self):
        rules = GovernanceRuleLoader.default_rules()
        ids = {r.rule_id for r in rules}
        assert "default-size" in ids

    def test_default_rules_dlp_when_enabled(self):
        rules = GovernanceRuleLoader.default_rules(enable_dlp=True)
        ids = {r.rule_id for r in rules}
        assert "default-dlp" in ids

    def test_default_rules_no_dlp_when_disabled(self):
        rules = GovernanceRuleLoader.default_rules(enable_dlp=False)
        ids = {r.rule_id for r in rules}
        assert "default-dlp" not in ids


class TestGovernanceGate:
    def setup_method(self):
        rules = GovernanceRuleLoader.default_rules()
        self.gate = GovernanceGate(rules=rules, dlp=DLPScanner())

    def test_allows_clean_content(self):
        decision = self.gate.evaluate_store(
            content={"task": "analyze data", "result": "done"},
            agent_id="agent-1",
            tenant_id="test",
        )
        assert decision.allowed

    def test_blocks_oversized_content(self):
        large_content = {"data": "x" * 60000}
        decision = self.gate.evaluate_store(
            content=large_content,
            agent_id="agent-1",
            tenant_id="test",
        )
        assert not decision.allowed
        assert "bytes" in (decision.reason or "")

    def test_blocks_pii(self):
        with pytest.raises(PIIDetectedError):
            self.gate.evaluate_store(
                content={"data": "Email: user@example.com"},
                agent_id="agent-1",
                tenant_id="test",
            )

    def test_redacts_credentials_silently(self):
        decision = self.gate.evaluate_store(
            content={"key": "sk-abcdefghijklmnopqrstuvwxyz"},
            agent_id="agent-1",
            tenant_id="test",
        )
        assert decision.allowed
        assert decision.modified_payload is not None
        assert "sk-" not in str(decision.modified_payload)

    def test_recall_always_allowed(self):
        decision = self.gate.evaluate_recall(
            agent_id="agent-1", tenant_id="test"
        )
        assert decision.allowed


class TestHashChainAuditWriter:
    async def test_append_creates_chain(self):
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            path = f.name
        try:
            backend = FileAuditBackend(path)
            await backend.initialize()
            writer = HashChainAuditWriter(backend)

            block1 = await writer.append(
                event_type=AuditEventType.MEMORY_STORE,
                agent_id="agent-1",
                tenant_id="test",
                outcome="allowed",
            )
            assert block1.sequence == 1
            assert block1.prev_hash == "0" * 64

            block2 = await writer.append(
                event_type=AuditEventType.MEMORY_RECALL,
                agent_id="agent-1",
                tenant_id="test",
                outcome="allowed",
            )
            assert block2.sequence == 2
            assert block2.prev_hash == block1.block_hash
        finally:
            os.unlink(path)

    async def test_verify_chain_valid(self):
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            path = f.name
        try:
            backend = FileAuditBackend(path)
            await backend.initialize()
            writer = HashChainAuditWriter(backend)

            for i in range(5):
                await writer.append(
                    event_type=AuditEventType.MEMORY_STORE,
                    agent_id="agent-1",
                    tenant_id="test",
                    outcome="allowed",
                    metadata={"index": i},
                )

            result = await writer.verify_chain()
            assert result["valid"] is True
            assert result["checked"] == 5
        finally:
            os.unlink(path)

    async def test_export_creates_file(self):
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            audit_path = f.name
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            export_path = f.name
        try:
            backend = FileAuditBackend(audit_path)
            await backend.initialize()
            writer = HashChainAuditWriter(backend)

            await writer.append(
                event_type=AuditEventType.MEMORY_STORE,
                agent_id="agent-1",
                tenant_id="test",
                outcome="allowed",
            )

            blocks = await writer.export(output_path=export_path)
            assert len(blocks) == 1
            assert os.path.exists(export_path)
        finally:
            os.unlink(audit_path)
            os.unlink(export_path)

    async def test_resume_from_existing_file(self):
        with tempfile.NamedTemporaryFile(suffix=".ndjson", delete=False) as f:
            path = f.name
        try:
            # Write initial blocks
            backend1 = FileAuditBackend(path)
            await backend1.initialize()
            writer1 = HashChainAuditWriter(backend1)
            await writer1.append(
                event_type=AuditEventType.MEMORY_STORE,
                agent_id="agent-1",
                tenant_id="test",
                outcome="allowed",
            )

            # Reinitialize (simulates restart)
            backend2 = FileAuditBackend(path)
            await backend2.initialize()
            writer2 = HashChainAuditWriter(backend2)
            block = await writer2.append(
                event_type=AuditEventType.MEMORY_RECALL,
                agent_id="agent-1",
                tenant_id="test",
                outcome="allowed",
            )
            assert block.sequence == 2

            result = await writer2.verify_chain()
            assert result["valid"] is True
            assert result["checked"] == 2
        finally:
            os.unlink(path)
