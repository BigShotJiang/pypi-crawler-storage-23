"""Integration tests for Qdrant backend — requires running Qdrant instance."""

import contextlib
import os
import uuid
from datetime import UTC, datetime

import pytest

from tigunny_memory.backends.qdrant import QdrantBackend
from tigunny_memory.config import MemoryConfig
from tigunny_memory.types import MemoryEntry

QDRANT_URL = os.environ.get("QDRANT_URL")
pytestmark = pytest.mark.skipif(not QDRANT_URL, reason="QDRANT_URL not set")

DIMENSIONS = 128  # Small for fast tests


def _make_config() -> MemoryConfig:
    return MemoryConfig(
        qdrant_url=QDRANT_URL or "http://localhost:6333",
        collection_name=f"test_{uuid.uuid4().hex[:8]}",
    )


def _make_entry(
    tenant_id: str = "tenant-a",
    agent_id: str = "agent-1",
    tags: list[str] | None = None,
) -> tuple[MemoryEntry, list[float]]:
    entry = MemoryEntry(
        memory_id=str(uuid.uuid4()),
        agent_id=agent_id,
        tenant_id=tenant_id,
        content={"data": f"test-{uuid.uuid4().hex[:6]}"},
        content_hash=uuid.uuid4().hex,
        tags=tags or ["test"],
        created_at=datetime.now(UTC),
    )
    import random
    embedding = [random.random() for _ in range(DIMENSIONS)]
    return entry, embedding


@pytest.fixture
async def backend():
    config = _make_config()
    backend = QdrantBackend(config)
    await backend.connect()
    await backend.ensure_collection(DIMENSIONS)
    yield backend
    # Cleanup
    with contextlib.suppress(Exception):
        await backend._client.delete_collection(config.collection_name)
    await backend.close()


class TestQdrantBackend:
    async def test_connect_and_ensure_collection(self, backend):
        health = await backend.health_check()
        assert health is True

    async def test_ensure_collection_idempotent(self, backend):
        await backend.ensure_collection(DIMENSIONS)  # second call
        assert await backend.health_check()

    async def test_upsert_and_search(self, backend):
        entry, embedding = _make_entry()
        await backend.upsert(entry, embedding)

        results = await backend.search(
            embedding=embedding,
            tenant_id=entry.tenant_id,
            top_k=5,
        )
        assert len(results) >= 1
        found = results[0][0]
        assert found.memory_id == entry.memory_id

    async def test_tenant_isolation(self, backend):
        entry_a, emb_a = _make_entry(tenant_id="tenant-a")
        entry_b, emb_b = _make_entry(tenant_id="tenant-b")
        await backend.upsert(entry_a, emb_a)
        await backend.upsert(entry_b, emb_b)

        results_a = await backend.search(embedding=emb_a, tenant_id="tenant-a")
        results_b = await backend.search(embedding=emb_b, tenant_id="tenant-b")

        a_ids = {r[0].memory_id for r in results_a}
        b_ids = {r[0].memory_id for r in results_b}

        assert entry_a.memory_id in a_ids
        assert entry_b.memory_id not in a_ids
        assert entry_b.memory_id in b_ids
        assert entry_a.memory_id not in b_ids

    async def test_outcome_update(self, backend):
        entry, embedding = _make_entry()
        await backend.upsert(entry, embedding)

        await backend.update_outcome(entry.memory_id, 0.9, 3)
        outcome = await backend.get_outcome(entry.memory_id)
        assert outcome["outcome_score"] == 0.9
        assert outcome["outcome_count"] == 3

    async def test_delete(self, backend):
        entry, embedding = _make_entry()
        await backend.upsert(entry, embedding)
        await backend.delete(entry.memory_id)

        results = await backend.search(
            embedding=embedding,
            tenant_id=entry.tenant_id,
        )
        found_ids = {r[0].memory_id for r in results}
        assert entry.memory_id not in found_ids

    async def test_tag_filtering(self, backend):
        entry1, emb1 = _make_entry(tags=["research"])
        entry2, emb2 = _make_entry(tags=["code"])
        await backend.upsert(entry1, emb1)
        await backend.upsert(entry2, emb2)

        results = await backend.search(
            embedding=emb1,
            tenant_id=entry1.tenant_id,
            tags=["research"],
        )
        found_tags = set()
        for r in results:
            found_tags.update(r[0].tags)
        assert "research" in found_tags

    async def test_large_batch(self, backend):
        entries = []
        for _ in range(100):
            entry, emb = _make_entry()
            await backend.upsert(entry, emb)
            entries.append(entry)

        results = await backend.search(
            embedding=[0.5] * DIMENSIONS,
            tenant_id="tenant-a",
            top_k=50,
        )
        assert len(results) <= 50
