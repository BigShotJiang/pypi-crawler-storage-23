"""tigunny-memory CLI — first thing a client runs after pip install."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any


def _get_version_info() -> dict[str, Any]:
    """Get version and installed optional deps."""
    from tigunny_memory import __version__

    deps: dict[str, str] = {}
    for name in ["openai", "ollama", "voyageai", "asyncpg", "redis", "anthropic"]:
        try:
            mod = __import__(name)
            deps[name] = getattr(mod, "__version__", "installed")
        except ImportError:
            deps[name] = "not installed"

    return {"version": __version__, "python": sys.version, "optional_deps": deps}


def cmd_version(args: argparse.Namespace) -> int:
    info = _get_version_info()
    print(f"tigunny-memory v{info['version']}")
    print(f"Python: {info['python'].split()[0]}")
    print("\nOptional dependencies:")
    for name, status in info["optional_deps"].items():
        marker = "+" if status != "not installed" else "-"
        print(f"  [{marker}] {name}: {status}")
    return 0


def cmd_health(args: argparse.Namespace) -> int:
    from tigunny_memory import MemoryConfig, TigunnyMemory

    async def _check() -> dict[str, Any]:
        try:
            config = MemoryConfig.from_env()
        except Exception as e:
            return {"error": f"Configuration error: {e}"}

        try:
            mem = TigunnyMemory(config)
            await mem.connect()
            result = await mem.health()
            await mem.close()
            return result
        except Exception as e:
            return {"error": str(e)}

    result = asyncio.run(_check())
    if "error" in result:
        print(f"Health check failed: {result['error']}")
        hint = result["error"]
        if "connect" in hint.lower() or "qdrant" in hint.lower():
            print("\nHint: Is Qdrant running?")
            print("  docker run -p 6333:6333 qdrant/qdrant")
        return 1

    print("Backend health:")
    for key, value in result.items():
        if key == "overall_healthy":
            continue
        is_ok = value is True or (isinstance(value, dict) and value.get("healthy"))
        status = "OK" if is_ok else "FAIL"
        print(f"  {key}: {status}")
    overall = result.get("overall_healthy", False)
    print(f"\nOverall: {'HEALTHY' if overall else 'UNHEALTHY'}")
    return 0 if overall else 1


def cmd_init(args: argparse.Namespace) -> int:
    """Interactive setup wizard."""
    print("tigunny-memory setup wizard")
    print("=" * 40)

    providers = {"1": "ollama", "2": "openai", "3": "voyage", "4": "custom"}
    print("\nEmbedding provider:")
    print("  1. Ollama (free, local)")
    print("  2. OpenAI (API key required)")
    print("  3. Voyage AI (API key required)")
    print("  4. Custom endpoint")

    choice = input("\nSelect provider [1]: ").strip() or "1"
    provider = providers.get(choice, "ollama")

    env_lines: list[str] = [
        f"TIGUNNY_MEMORY_EMBEDDING_PROVIDER={provider}",
        "TIGUNNY_MEMORY_QDRANT_URL=http://localhost:6333",
        "TIGUNNY_MEMORY_TENANT_ID=default",
    ]

    if provider == "openai":
        key = input("OpenAI API key: ").strip()
        if key:
            env_lines.append(f"TIGUNNY_MEMORY_OPENAI_API_KEY={key}")
    elif provider == "voyage":
        key = input("Voyage AI API key: ").strip()
        if key:
            env_lines.append(f"TIGUNNY_MEMORY_VOYAGE_API_KEY={key}")
    elif provider == "custom":
        url = input("Custom embedding endpoint URL: ").strip()
        dims = input("Embedding dimensions: ").strip()
        if url:
            env_lines.append(f"TIGUNNY_MEMORY_CUSTOM_EMBEDDING_URL={url}")
        if dims:
            env_lines.append(f"TIGUNNY_MEMORY_EMBEDDING_DIMENSIONS={dims}")

    with open(".env", "w") as f:
        f.write("\n".join(env_lines) + "\n")

    print(f"\nWrote .env with {provider} provider")
    print("Next: docker run -p 6333:6333 qdrant/qdrant")
    print("Then: tigunny-memory health")
    return 0


def cmd_store(args: argparse.Namespace) -> int:
    from tigunny_memory import MemoryConfig, TigunnyMemory

    async def _store() -> int:
        config = MemoryConfig.from_env()
        async with TigunnyMemory(config) as mem:
            content = json.loads(args.content)
            tags = args.tags.split(",") if args.tags else []
            entry = await mem.store(
                agent_id=args.agent,
                content=content,
                tags=tags,
                ttl_days=args.ttl,
            )
            print(f"Stored: {entry.memory_id}")
            print(f"  Agent: {entry.agent_id}")
            print(f"  Tags: {entry.tags}")
            print(f"  Hash: {entry.content_hash[:16]}...")
        return 0

    try:
        return asyncio.run(_store())
    except Exception as e:
        print(f"Error: {e}")
        return 1


def cmd_recall(args: argparse.Namespace) -> int:
    from tigunny_memory import MemoryConfig, TigunnyMemory

    async def _recall() -> int:
        config = MemoryConfig.from_env()
        async with TigunnyMemory(config) as mem:
            results = await mem.recall(
                agent_id=args.agent,
                query=args.query,
                top_k=args.top_k,
            )
            if not results:
                print("No memories found.")
                return 0
            for r in results:
                print(f"\n--- Rank {r.rank} (score: {r.weighted_score:.3f}) ---")
                print(f"  ID: {r.memory.memory_id}")
                print(f"  Content: {json.dumps(r.memory.content, indent=2)[:200]}")
                print(f"  Tags: {r.memory.tags}")
                print(f"  Outcome: {r.memory.outcome_score:.2f} ({r.memory.outcome_count} evals)")
        return 0

    try:
        return asyncio.run(_recall())
    except Exception as e:
        print(f"Error: {e}")
        return 1


def cmd_audit_verify(args: argparse.Namespace) -> int:
    from tigunny_memory import MemoryConfig, TigunnyMemory

    async def _verify() -> int:
        config = MemoryConfig.from_env()
        async with TigunnyMemory(config) as mem:
            result = await mem.verify_integrity()
            if result["valid"]:
                print(f"Audit chain VERIFIED ({result['checked']} blocks)")
            else:
                print(f"INTEGRITY VIOLATION at block {result['broken_at_sequence']}")
                return 1
        return 0

    try:
        return asyncio.run(_verify())
    except Exception as e:
        print(f"Error: {e}")
        return 1


def cmd_audit_export(args: argparse.Namespace) -> int:
    from tigunny_memory import MemoryConfig, TigunnyMemory

    async def _export() -> int:
        config = MemoryConfig.from_env()
        async with TigunnyMemory(config) as mem:
            blocks = await mem.export_audit(output_path=args.output)
            print(f"Exported {len(blocks)} audit blocks to {args.output}")
        return 0

    try:
        return asyncio.run(_export())
    except Exception as e:
        print(f"Error: {e}")
        return 1


def cmd_stats(args: argparse.Namespace) -> int:
    info = _get_version_info()
    print(f"tigunny-memory v{info['version']}")
    print("\nTo view detailed learning stats, use the Python API:")
    print("  from tigunny_memory import TigunnyMemory, MemoryConfig")
    print("  async with TigunnyMemory(MemoryConfig.from_env()) as mem:")
    print("      health = await mem.health()")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tigunny-memory",
        description="Governance-aware agent memory — CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # version
    subparsers.add_parser("version", help="Show version and installed deps")

    # health
    subparsers.add_parser("health", help="Check backend health")

    # init
    subparsers.add_parser("init", help="Interactive setup wizard")

    # store
    sp_store = subparsers.add_parser("store", help="Store a memory")
    sp_store.add_argument("--agent", required=True, help="Agent ID")
    sp_store.add_argument("--content", required=True, help="JSON content string")
    sp_store.add_argument("--tags", default=None, help="Comma-separated tags")
    sp_store.add_argument("--ttl", type=int, default=None, help="TTL in days")

    # recall
    sp_recall = subparsers.add_parser("recall", help="Recall memories")
    sp_recall.add_argument("--agent", required=True, help="Agent ID")
    sp_recall.add_argument("--query", required=True, help="Semantic search query")
    sp_recall.add_argument("--top-k", type=int, default=5, help="Number of results")

    # audit
    sp_audit = subparsers.add_parser("audit", help="Audit log operations")
    audit_sub = sp_audit.add_subparsers(dest="audit_cmd")
    audit_sub.add_parser("verify", help="Verify audit chain integrity")
    sp_export = audit_sub.add_parser("export", help="Export audit log")
    sp_export.add_argument("--output", default="./audit.ndjson", help="Output path")

    # stats
    subparsers.add_parser("stats", help="Show learning statistics")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "version": cmd_version,
        "health": cmd_health,
        "init": cmd_init,
        "store": cmd_store,
        "recall": cmd_recall,
        "stats": cmd_stats,
    }

    if args.command == "audit":
        if args.audit_cmd == "verify":
            sys.exit(cmd_audit_verify(args))
        elif args.audit_cmd == "export":
            sys.exit(cmd_audit_export(args))
        else:
            sp_audit.print_help()
            sys.exit(0)
    elif args.command in commands:
        sys.exit(commands[args.command](args))
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
