"""
tigunny-memory — Governance-aware agent memory for production AI systems.

Built by Tigunny LLC — SDVOSB · TX HUB Certified.

Quick Start::

    from tigunny_memory import TigunnyMemory, MemoryConfig

    config = MemoryConfig.from_env()
    async with TigunnyMemory(config) as mem:
        entry = await mem.store("agent-1", {"task": "research", "result": "findings..."})
        results = await mem.recall("agent-1", "What did we find about X?")
        await mem.learn("agent-1", entry.memory_id, outcome_score=0.9)

Apache 2.0 License. https://github.com/tigunny/tigunny-memory
"""

from tigunny_memory.config import BackendType, EmbeddingProvider, GovernanceBackend, MemoryConfig
from tigunny_memory.exceptions import (
    AuditChainError,
    ConfigurationError,
    ConnectionError,
    EmbeddingError,
    GovernanceViolationError,
    InjectionDetectedError,
    MemoryPoisoningError,
    PIIDetectedError,
    TigunnyMemoryError,
    TTLViolationError,
)
from tigunny_memory.memory import TigunnyMemory
from tigunny_memory.types import (
    AuditBlock,
    GovernanceDecision,
    MemoryEntry,
    OutcomeScore,
    RecallResult,
    ScanResult,
)

__version__ = "0.1.0"
__author__ = "Tigunny LLC"
__license__ = "Apache-2.0"

__all__ = [
    # Core
    "TigunnyMemory",
    "MemoryConfig",
    # Enums
    "EmbeddingProvider",
    "BackendType",
    "GovernanceBackend",
    # Types
    "MemoryEntry",
    "RecallResult",
    "OutcomeScore",
    "ScanResult",
    "GovernanceDecision",
    "AuditBlock",
    # Exceptions
    "TigunnyMemoryError",
    "ConnectionError",
    "EmbeddingError",
    "GovernanceViolationError",
    "PIIDetectedError",
    "TTLViolationError",
    "AuditChainError",
    "InjectionDetectedError",
    "MemoryPoisoningError",
    "ConfigurationError",
]
