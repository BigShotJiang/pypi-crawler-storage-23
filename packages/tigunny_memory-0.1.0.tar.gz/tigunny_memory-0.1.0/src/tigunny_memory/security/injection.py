"""Prompt injection and memory poisoning detector."""

from __future__ import annotations

import hashlib
import re
import time
import unicodedata
from typing import Optional

from tigunny_memory.types import ScanResult

FAST_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("role_override", re.compile(
        r"(?i)(you are now|ignore (?:all )?(?:previous|prior|above) instructions|"
        r"forget (?:everything|all|your)|disregard (?:all|your|the)|"
        r"new instructions|override (?:system|instructions))"
    )),
    ("persona_injection", re.compile(
        r"(?i)(act as|pretend (?:to be|you(?:'re| are))|"
        r"you(?:'re| are) (?:now |actually )?(?:a |an )?(?:different|new|evil|unrestricted))"
    )),
    ("system_extraction", re.compile(
        r"(?i)((?:show|reveal|repeat|print|output|display) "
        r"(?:your )?(?:system ?prompt|instructions|rules)|"
        r"what (?:are|is) your (?:system|initial) (?:prompt|instructions|message))"
    )),
    ("delimiter_injection", re.compile(
        r"(?:<\|(?:im_start|system|endoftext)\|>|"
        r"\[INST\]|\[/INST\]|<\|(?:user|assistant)\|>|"
        r"```system|<system>|</system>)"
    )),
    ("jailbreak", re.compile(
        r"(?i)(DAN|do anything now|jailbreak|bypass (?:safety|filter|restriction)|"
        r"developer mode|god mode|unlocked mode)"
    )),
    ("encoded_injection", re.compile(
        r"(?:(?:eval|exec|import)\s*\(|base64\.(?:b64decode|decode)|"
        r"\\x[0-9a-fA-F]{2}|\\u[0-9a-fA-F]{4})"
    )),
]


class InjectionDetector:
    """Detects prompt injection attempts in memory content.

    Fast pattern scan runs first. Semantic scan (via Claude) runs on
    borderline or longer content if anthropic_api_key is configured.
    """

    def __init__(
        self,
        anthropic_api_key: Optional[str] = None,
        model: str = "claude-haiku-4-5-20251001",
        cache_ttl_seconds: int = 60,
    ) -> None:
        self._api_key = anthropic_api_key
        self._model = model
        self._cache_ttl = cache_ttl_seconds
        self._cache: dict[str, tuple[ScanResult, float]] = {}

    def _normalize(self, text: str) -> str:
        return unicodedata.normalize("NFKC", text)

    def fast_scan(self, text: str) -> ScanResult:
        normalized = self._normalize(text)
        for technique, pattern in FAST_PATTERNS:
            if pattern.search(normalized):
                return ScanResult(
                    is_safe=False,
                    blocked=True,
                    technique=technique,
                    confidence=0.9,
                    details=f"Fast pattern match: {technique}",
                    scan_type="fast",
                )
        return ScanResult(is_safe=True, blocked=False, scan_type="fast")

    async def semantic_scan(self, text: str) -> ScanResult:
        if not self._api_key:
            return ScanResult(is_safe=True, blocked=False, scan_type="semantic")

        cache_key = hashlib.sha256(text.encode()).hexdigest()
        now = time.time()
        if cache_key in self._cache:
            result, cached_at = self._cache[cache_key]
            if now - cached_at < self._cache_ttl:
                return result

        try:
            import httpx

            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": self._api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": self._model,
                        "max_tokens": 100,
                        "system": (
                            "Security classifier. Reply ONLY JSON: "
                            '{"injection": bool, "confidence": 0.0-1.0, "technique": string|null}'
                        ),
                        "messages": [{"role": "user", "content": text}],
                    },
                )
                response.raise_for_status()
                data = response.json()
                content_text = data["content"][0]["text"]

                import json
                result_data = json.loads(content_text)
                is_injection = result_data.get("injection", False)
                confidence = result_data.get("confidence", 0.0)
                technique = result_data.get("technique")

                result = ScanResult(
                    is_safe=not is_injection,
                    blocked=is_injection and confidence >= 0.7,
                    technique=technique,
                    confidence=confidence,
                    details=f"Semantic scan: {'injection' if is_injection else 'safe'}",
                    scan_type="semantic",
                )
                self._cache[cache_key] = (result, now)
                return result

        except Exception:
            # Fail closed
            return ScanResult(
                is_safe=False,
                blocked=True,
                technique="scan_failure",
                confidence=1.0,
                details="Semantic scan failed — fail closed",
                scan_type="semantic",
            )

    async def scan(self, text: str) -> ScanResult:
        fast_result = self.fast_scan(text)
        if fast_result.blocked:
            return fast_result

        # Semantic scan for longer content if API key available
        if self._api_key and len(text) > 200:
            return await self.semantic_scan(text)

        return fast_result
