"""Memory sanitizer — runs injection + DLP checks before every write."""

from __future__ import annotations

import hashlib
import json
from typing import Any


class MemorySanitizer:
    """Sanitizes content before storage and after recall."""

    def __init__(
        self,
        config: Any,
        detector: Any = None,
        dlp: Any = None,
    ) -> None:
        self._config = config
        self._detector = detector
        self._dlp = dlp
        self._max_bytes = 51200  # 50KB

    async def sanitize_for_store(
        self,
        content: dict[str, Any],
        agent_id: str,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {"content": content, "safe": True}

        # 1. Injection scan
        if self._detector:
            content_text = json.dumps(content, default=str)
            scan = await self._detector.scan(content_text)
            if scan.blocked:
                result["safe"] = False
                result["scan_result"] = scan
                return result

        # 2. DLP redaction
        if self._dlp:
            content_text = json.dumps(content, default=str)
            dlp_result = self._dlp.scan(content_text)
            if dlp_result.detected:
                result["content"] = json.loads(
                    self._dlp.redact(json.dumps(content, default=str))
                ) if isinstance(content, dict) else content

        # 3. Size check
        serialized = json.dumps(result["content"], default=str)
        if len(serialized.encode()) > self._max_bytes:
            result["safe"] = False
            result["reason"] = "Content exceeds size limit"
            return result

        # 4. Content hash
        result["content_hash"] = hashlib.sha256(
            json.dumps(result["content"], sort_keys=True, default=str).encode()
        ).hexdigest()

        return result

    def sanitize_for_recall(self, memories: list[Any]) -> list[Any]:
        if not self._detector:
            return memories
        safe_memories = []
        for memory in memories:
            content_text = json.dumps(memory.content, default=str)
            scan = self._detector.fast_scan(content_text)
            if not scan.blocked:
                safe_memories.append(memory)
        return safe_memories
