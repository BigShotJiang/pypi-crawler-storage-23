"""TigunnyMemory — main interface for governance-aware agent memory."""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any, Optional

from tigunny_memory.config import MemoryConfig
from tigunny_memory.types import (
    AuditBlock,
    AuditEventType,
    MemoryEntry,
    OutcomeScore,
    RecallResult,
)


class TigunnyMemory:
    """Governance-aware agent memory with semantic recall, audit, and swarm sync.

    Usage::

        config = MemoryConfig.from_env()
        async with TigunnyMemory(config) as mem:
            entry = await mem.store("agent-1", {"task": "...", "result": "..."})
            results = await mem.recall("agent-1", "semantic query")
            await mem.learn("agent-1", entry.memory_id, outcome_score=0.9)
    """

    def __init__(self, config: MemoryConfig) -> None:
        self.config = config
        self._connected = False
        self._embedding_adapter: Any = None
        self._vector_backend: Any = None
        self._governance_gate: Any = None
        self._audit_writer: Any = None
        self._swarm_sync: Any = None
        self._injection_detector: Any = None
        self._sanitizer: Any = None

    async def connect(self) -> None:
        """Initialize all backend connections lazily."""
        if self._connected:
            return

        # Embedding adapter
        from tigunny_memory.adapters.base import EmbeddingAdapterFactory

        self._embedding_adapter = EmbeddingAdapterFactory.from_config(self.config)

        # Vector backend
        from tigunny_memory.backends.qdrant import QdrantBackend

        self._vector_backend = QdrantBackend(self.config)
        await self._vector_backend.connect()
        await self._vector_backend.ensure_collection(self._embedding_adapter.dimensions)

        # Governance gate
        from tigunny_memory.governance.dlp import DLPScanner
        from tigunny_memory.governance.gate import GovernanceGate
        from tigunny_memory.governance.rules import GovernanceRuleLoader

        rules = GovernanceRuleLoader.default_rules(
            max_ttl_days=self.config.max_ttl_days,
            enable_dlp=self.config.enable_dlp,
        )
        dlp = DLPScanner() if self.config.enable_dlp else None
        self._governance_gate = GovernanceGate(rules=rules, dlp=dlp)

        # Audit writer
        if self.config.enable_audit_chain:
            from tigunny_memory.audit.chain import HashChainAuditWriter

            self._audit_writer = await HashChainAuditWriter.build(self.config)

        # Swarm sync
        if self.config.enable_swarm_sync and self.config.redis_url:
            try:
                from tigunny_memory.sync.redis import RedisSwarmSync

                self._swarm_sync = RedisSwarmSync()
                await self._swarm_sync.connect(
                    self.config.redis_url, self.config.tenant_id
                )
            except ImportError:
                from tigunny_memory.sync.noop import NoopSwarmSync

                self._swarm_sync = NoopSwarmSync()
        else:
            from tigunny_memory.sync.noop import NoopSwarmSync

            self._swarm_sync = NoopSwarmSync()

        # Injection detector
        if self.config.enable_injection_detection:
            from tigunny_memory.security.injection import InjectionDetector

            self._injection_detector = InjectionDetector(
                anthropic_api_key=self.config.anthropic_api_key,
                model=self.config.injection_detection_model,
                cache_ttl_seconds=self.config.cache_ttl_seconds,
            )

        # Sanitizer
        from tigunny_memory.security.sanitizer import MemorySanitizer

        self._sanitizer = MemorySanitizer(
            config=self.config,
            detector=self._injection_detector,
            dlp=dlp,
        )

        self._connected = True

    async def close(self) -> None:
        """Close all backend connections."""
        if self._vector_backend:
            await self._vector_backend.close()
        if self._swarm_sync:
            await self._swarm_sync.close()
        self._connected = False

    async def __aenter__(self) -> TigunnyMemory:
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    def _content_hash(self, content: dict[str, Any]) -> str:
        serialized = json.dumps(content, sort_keys=True, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()

    async def store(
        self,
        agent_id: str,
        content: dict[str, Any],
        tags: Optional[list[str]] = None,
        ttl_days: Optional[int] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> MemoryEntry:
        """Store a memory with governance checks, embedding, and audit logging.

        Flow: injection_scan -> governance_gate -> generate_embedding
              -> vector_store -> audit_log -> swarm_sync -> return entry
        """
        tags = tags or []
        metadata = metadata or {}

        # 1. Injection scan
        if self._injection_detector:
            content_text = json.dumps(content, default=str)
            scan_result = await self._injection_detector.scan(content_text)
            if scan_result.blocked:
                if self._audit_writer:
                    await self._audit_writer.append(
                        event_type=AuditEventType.INJECTION_BLOCKED,
                        agent_id=agent_id,
                        tenant_id=self.config.tenant_id,
                        outcome="blocked",
                        content_hash=self._content_hash(content),
                        metadata={"technique": scan_result.technique},
                    )
                from tigunny_memory.exceptions import InjectionDetectedError

                raise InjectionDetectedError(
                    f"Injection detected: {scan_result.technique}"
                )

        # 2. Governance gate
        decision = self._governance_gate.evaluate_store(
            content=content,
            agent_id=agent_id,
            tenant_id=self.config.tenant_id,
            ttl_days=ttl_days,
        )
        if not decision.allowed:
            if self._audit_writer:
                await self._audit_writer.append(
                    event_type=AuditEventType.GOVERNANCE_BLOCK,
                    agent_id=agent_id,
                    tenant_id=self.config.tenant_id,
                    outcome="blocked",
                    content_hash=self._content_hash(content),
                    metadata={"rule": decision.rule_name, "reason": decision.reason},
                )
            from tigunny_memory.exceptions import GovernanceViolationError

            raise GovernanceViolationError(
                f"Blocked by {decision.rule_name}: {decision.reason}"
            )

        # Apply redactions if any
        if decision.modified_payload:
            content = decision.modified_payload
            if self._audit_writer:
                await self._audit_writer.append(
                    event_type=AuditEventType.GOVERNANCE_REDACT,
                    agent_id=agent_id,
                    tenant_id=self.config.tenant_id,
                    outcome="redacted",
                    content_hash=self._content_hash(content),
                    metadata={"redactions": decision.redactions},
                )

        # 3. Generate embedding
        content_text = json.dumps(content, default=str)
        embedding = await self._embedding_adapter.embed(content_text)

        # 4. Build memory entry
        now = datetime.now(UTC)
        effective_ttl = ttl_days
        if effective_ttl and effective_ttl > self.config.max_ttl_days:
            effective_ttl = self.config.max_ttl_days

        entry = MemoryEntry(
            memory_id=str(uuid.uuid4()),
            agent_id=agent_id,
            tenant_id=self.config.tenant_id,
            content=content,
            content_hash=self._content_hash(content),
            tags=tags,
            ttl_days=effective_ttl,
            metadata=metadata,
            outcome_score=0.5,
            outcome_count=0,
            created_at=now,
            expires_at=now + timedelta(days=effective_ttl) if effective_ttl else None,
        )

        # 5. Store in vector backend
        await self._vector_backend.upsert(entry, embedding)

        # 6. Audit log
        if self._audit_writer:
            await self._audit_writer.append(
                event_type=AuditEventType.MEMORY_STORE,
                agent_id=agent_id,
                tenant_id=self.config.tenant_id,
                outcome="allowed",
                content_hash=entry.content_hash,
                metadata={"memory_id": entry.memory_id, "tags": tags},
            )

        # 7. Swarm sync
        if self._swarm_sync and self._swarm_sync.is_active:
            await self._swarm_sync.publish_discovery(
                memory_id=entry.memory_id,
                agent_id=agent_id,
                tags=tags,
                content_hash=entry.content_hash,
            )

        return entry

    async def recall(
        self,
        agent_id: str,
        query: str,
        top_k: Optional[int] = None,
        tags: Optional[list[str]] = None,
        min_score: float = 0.0,
    ) -> list[RecallResult]:
        """Recall memories using semantic search with outcome-weighted ranking."""
        top_k = top_k or self.config.recall_top_k

        # Embed query
        query_embedding = await self._embedding_adapter.embed(query)

        # Vector search with structural tenant filter
        raw_results = await self._vector_backend.search(
            embedding=query_embedding,
            tenant_id=self.config.tenant_id,
            agent_id=agent_id,
            tags=tags,
            top_k=top_k,
            min_score=min_score,
        )

        # Outcome-weighted reranking
        reranked = self._rerank_by_outcome(raw_results, self.config.outcome_weight)

        # Build results
        results = []
        for rank, (entry, semantic_score, weighted_score) in enumerate(reranked, 1):
            results.append(
                RecallResult(
                    memory=entry,
                    semantic_score=semantic_score,
                    weighted_score=weighted_score,
                    rank=rank,
                )
            )

        # Audit log
        if self._audit_writer:
            await self._audit_writer.append(
                event_type=AuditEventType.MEMORY_RECALL,
                agent_id=agent_id,
                tenant_id=self.config.tenant_id,
                outcome="allowed",
                content_hash=None,
                metadata={
                    "query_hash": hashlib.sha256(query.encode()).hexdigest()[:16],
                    "results_count": len(results),
                    "top_k": top_k,
                },
            )

        return results

    def _rerank_by_outcome(
        self,
        results: list[tuple[MemoryEntry, float]],
        outcome_weight: float,
    ) -> list[tuple[MemoryEntry, float, float]]:
        """Apply outcome-weighted reranking to search results."""
        reranked = []
        for entry, semantic_score in results:
            # New memories (no outcomes) get neutral score
            effective_outcome = entry.outcome_score if entry.outcome_count > 0 else 0.5
            weighted_score = semantic_score * (1.0 + outcome_weight * effective_outcome)
            reranked.append((entry, semantic_score, weighted_score))

        reranked.sort(key=lambda x: x[2], reverse=True)
        return reranked

    async def learn(
        self,
        agent_id: str,
        memory_id: str,
        outcome_score: float,
        feedback: Optional[str] = None,
    ) -> OutcomeScore:
        """Record an outcome score for a memory to improve future recall ranking."""
        if not 0.0 <= outcome_score <= 1.0:
            raise ValueError("outcome_score must be between 0.0 and 1.0")

        # Get current score from backend
        current = await self._vector_backend.get_outcome(memory_id)
        current_score = current.get("outcome_score", 0.5)
        current_count = current.get("outcome_count", 0)

        # Rolling weighted average with recency bias window
        capped_count = min(current_count, 10)
        new_score = (current_score * capped_count + outcome_score) / (capped_count + 1)
        new_count = current_count + 1

        # Update backend
        await self._vector_backend.update_outcome(
            memory_id=memory_id,
            outcome_score=new_score,
            outcome_count=new_count,
        )

        result = OutcomeScore(
            memory_id=memory_id,
            agent_id=agent_id,
            previous_score=current_score,
            new_score=new_score,
            outcome_count=new_count,
            feedback=feedback,
        )

        # Audit log
        if self._audit_writer:
            await self._audit_writer.append(
                event_type=AuditEventType.MEMORY_LEARN,
                agent_id=agent_id,
                tenant_id=self.config.tenant_id,
                outcome="allowed",
                content_hash=None,
                metadata={
                    "memory_id": memory_id,
                    "score_delta": round(new_score - current_score, 4),
                    "new_score": round(new_score, 4),
                },
            )

        # Broadcast to swarm
        if self._swarm_sync and self._swarm_sync.is_active:
            await self._swarm_sync.publish_outcome(
                memory_id=memory_id,
                agent_id=agent_id,
                outcome_score=new_score,
            )

        return result

    async def forget(
        self,
        agent_id: str,
        memory_id: str,
        reason: str = "explicit_deletion",
    ) -> None:
        """Delete a memory with audit trail."""
        await self._vector_backend.delete(memory_id)

        if self._audit_writer:
            await self._audit_writer.append(
                event_type=AuditEventType.MEMORY_DELETE,
                agent_id=agent_id,
                tenant_id=self.config.tenant_id,
                outcome="allowed",
                content_hash=None,
                metadata={"memory_id": memory_id, "reason": reason},
            )

    async def health(self) -> dict[str, Any]:
        """Check health of all backend services."""
        statuses: dict[str, Any] = {}

        # Embedding adapter
        try:
            statuses["embedding"] = await self._embedding_adapter.health_check()
        except Exception as e:
            statuses["embedding"] = {"healthy": False, "error": str(e)}

        # Vector backend
        try:
            statuses["vector_backend"] = await self._vector_backend.health_check()
        except Exception as e:
            statuses["vector_backend"] = {"healthy": False, "error": str(e)}

        # Audit
        if self._audit_writer:
            statuses["audit"] = {"healthy": True, "type": type(self._audit_writer).__name__}
        else:
            statuses["audit"] = {"healthy": True, "type": "disabled"}

        # Swarm
        statuses["swarm_sync"] = {
            "healthy": True,
            "active": self._swarm_sync.is_active if self._swarm_sync else False,
        }

        statuses["overall_healthy"] = all(
            (s.get("healthy", s) if isinstance(s, dict) else s)
            for s in statuses.values()
        )
        return statuses

    async def export_audit(
        self,
        start_seq: int = 0,
        output_path: Optional[str] = None,
    ) -> list[AuditBlock]:
        """Export audit log entries as NDJSON."""
        if not self._audit_writer:
            return []
        path = output_path or self.config.audit_export_path
        result: list[AuditBlock] = await self._audit_writer.export(
            output_path=path, start_seq=start_seq
        )
        return result

    async def verify_integrity(self) -> dict[str, Any]:
        """Verify hash-chain integrity of the audit log."""
        if not self._audit_writer:
            return {"valid": True, "checked": 0, "broken_at_sequence": None}
        result: dict[str, Any] = await self._audit_writer.verify_chain()
        return result
