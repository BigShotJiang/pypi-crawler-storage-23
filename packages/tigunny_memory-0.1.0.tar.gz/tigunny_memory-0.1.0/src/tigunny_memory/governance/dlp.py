"""DLP (Data Loss Prevention) scanner. Full implementation in S12D."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

PII_PATTERNS: dict[str, re.Pattern[str]] = {
    "email": re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),
    "phone_us": re.compile(r"\b(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}\b"),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
    "api_key_anthropic": re.compile(r"sk-ant-[a-zA-Z0-9_-]{20,}"),
    "api_key_openai": re.compile(r"sk-[a-zA-Z0-9]{20,}"),
    "api_key_google": re.compile(r"AIza[a-zA-Z0-9_-]{35}"),
    "vault_token": re.compile(r"hvs\.[a-zA-Z0-9_-]{20,}"),
    "private_key_block": re.compile(r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----"),
    "aws_key": re.compile(r"AKIA[A-Z0-9]{16}"),
    "generic_credential": re.compile(
        r"(?i)(?:password|secret|token|api_key|apikey)\s*[:=]\s*['\"]?[a-zA-Z0-9_\-/.+]{8,}"
    ),
}

REDACTION_MAP: dict[str, str] = {
    "email": "[EMAIL_REDACTED]",
    "phone_us": "[PHONE_REDACTED]",
    "ssn": "[SSN_REDACTED]",
    "credit_card": "[CREDIT_CARD_REDACTED]",
    "api_key_anthropic": "[ANTHROPIC_KEY_REDACTED]",
    "api_key_openai": "[OPENAI_KEY_REDACTED]",
    "api_key_google": "[GOOGLE_KEY_REDACTED]",
    "vault_token": "[VAULT_TOKEN_REDACTED]",
    "private_key_block": "[PRIVATE_KEY_REDACTED]",
    "aws_key": "[AWS_KEY_REDACTED]",
    "generic_credential": "[CREDENTIAL_REDACTED]",
}


@dataclass
class DLPFinding:
    pattern_name: str
    matched_text: str
    start: int
    end: int


@dataclass
class DLPResult:
    detected: bool = False
    findings: list[DLPFinding] = field(default_factory=list)
    safe_text: str = ""


class DLPScanner:
    def scan(self, text: str) -> DLPResult:
        findings: list[DLPFinding] = []
        for name, pattern in PII_PATTERNS.items():
            for match in pattern.finditer(text):
                findings.append(
                    DLPFinding(
                        pattern_name=name,
                        matched_text=match.group(),
                        start=match.start(),
                        end=match.end(),
                    )
                )
        return DLPResult(
            detected=len(findings) > 0,
            findings=findings,
            safe_text=self.redact(text) if findings else text,
        )

    def scan_dict(self, data: Any) -> DLPResult:
        if isinstance(data, str):
            return self.scan(data)
        if isinstance(data, dict):
            all_findings: list[DLPFinding] = []
            for value in data.values():
                result = self.scan_dict(value)
                all_findings.extend(result.findings)
            return DLPResult(detected=len(all_findings) > 0, findings=all_findings)
        if isinstance(data, list):
            all_findings = []
            for item in data:
                result = self.scan_dict(item)
                all_findings.extend(result.findings)
            return DLPResult(detected=len(all_findings) > 0, findings=all_findings)
        return DLPResult()

    def redact(self, text: str) -> str:
        for name, pattern in PII_PATTERNS.items():
            text = pattern.sub(REDACTION_MAP.get(name, "[REDACTED]"), text)
        return text
