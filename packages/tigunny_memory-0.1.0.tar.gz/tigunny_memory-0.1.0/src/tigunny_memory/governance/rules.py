"""Governance rule definitions and loader. Full implementation in S12D."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class GovernanceRule:
    rule_id: str
    rule_name: str
    rule_type: str  # retention | dlp | size | classification | rate_limit
    config: dict[str, Any] = field(default_factory=dict)
    is_active: bool = True


class GovernanceRuleLoader:
    @staticmethod
    def default_rules(
        max_ttl_days: int = 90,
        enable_dlp: bool = True,
    ) -> list[GovernanceRule]:
        rules = [
            GovernanceRule(
                rule_id="default-retention",
                rule_name="Default Retention Policy",
                rule_type="retention",
                config={"max_ttl_days": max_ttl_days},
            ),
            GovernanceRule(
                rule_id="default-size",
                rule_name="Default Size Limit",
                rule_type="size",
                config={"max_bytes": 51200},
            ),
        ]
        if enable_dlp:
            rules.append(
                GovernanceRule(
                    rule_id="default-dlp",
                    rule_name="Default DLP Policy",
                    rule_type="dlp",
                    config={"block_pii": True},
                )
            )
        return rules
