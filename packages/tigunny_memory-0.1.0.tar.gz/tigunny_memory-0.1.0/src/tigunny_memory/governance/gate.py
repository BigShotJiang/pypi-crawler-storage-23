"""Governance gate — evaluates operations against rules. Full implementation in S12D."""

from __future__ import annotations

import json
from typing import Any, Optional

from tigunny_memory.governance.dlp import DLPScanner
from tigunny_memory.governance.rules import GovernanceRule
from tigunny_memory.types import GovernanceDecision


class GovernanceGate:
    def __init__(
        self,
        rules: list[GovernanceRule],
        dlp: Optional[DLPScanner] = None,
    ) -> None:
        self.rules = {r.rule_id: r for r in rules if r.is_active}
        self.dlp = dlp

    def evaluate_store(
        self,
        content: dict[str, Any],
        agent_id: str,
        tenant_id: str,
        ttl_days: Optional[int] = None,
    ) -> GovernanceDecision:
        content_text = json.dumps(content, default=str)

        # Size check
        size_rule = self.rules.get("default-size")
        if size_rule:
            max_bytes = size_rule.config.get("max_bytes", 51200)
            if len(content_text.encode()) > max_bytes:
                return GovernanceDecision(
                    allowed=False,
                    rule_id="default-size",
                    rule_name="Default Size Limit",
                    reason=f"Content exceeds {max_bytes} bytes",
                )

        # DLP scan
        if self.dlp:
            dlp_rule = self.rules.get("default-dlp")
            if dlp_rule and dlp_rule.config.get("block_pii", True):
                result = self.dlp.scan_dict(content)
                if result.detected:
                    pii_types = {f.pattern_name for f in result.findings}
                    credential_types = {
                        "api_key_anthropic", "api_key_openai", "api_key_google",
                        "vault_token", "private_key_block", "aws_key",
                        "generic_credential",
                    }
                    pii_only = pii_types - credential_types
                    if pii_only:
                        from tigunny_memory.exceptions import PIIDetectedError

                        raise PIIDetectedError(
                            f"PII detected: {', '.join(pii_only)}"
                        )
                    # Credentials are silently redacted, not blocked
                    redacted = self._redact_dict(content)
                    return GovernanceDecision(
                        allowed=True,
                        modified_payload=redacted,
                        redactions=list(pii_types & credential_types),
                    )

        return GovernanceDecision(allowed=True)

    def evaluate_recall(
        self,
        agent_id: str,
        tenant_id: str,
    ) -> GovernanceDecision:
        return GovernanceDecision(allowed=True)

    def _redact_dict(self, data: Any) -> Any:
        if not self.dlp:
            return data
        if isinstance(data, str):
            return self.dlp.redact(data)
        if isinstance(data, dict):
            return {k: self._redact_dict(v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._redact_dict(item) for item in data]
        return data
