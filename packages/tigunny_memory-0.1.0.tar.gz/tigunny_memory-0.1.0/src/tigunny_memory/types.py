"""Core data types for tigunny-memory."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class MemoryEntry(BaseModel):
    """A stored memory entry."""

    memory_id: str = Field(description="Unique identifier for this memory")
    agent_id: str = Field(description="Agent that created this memory")
    tenant_id: str = Field(description="Tenant this memory belongs to")
    content: dict[str, Any] = Field(description="The memory content payload")
    content_hash: str = Field(description="SHA-256 hash of the serialized content")
    tags: list[str] = Field(default_factory=list, description="Searchable tags")
    ttl_days: Optional[int] = Field(default=None, description="Retention period in days")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    outcome_score: float = Field(default=0.5, description="Outcome quality score 0.0-1.0")
    outcome_count: int = Field(default=0, description="Number of outcome evaluations")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = Field(default=None)


class RecallResult(BaseModel):
    """A memory entry returned from a recall query."""

    memory: MemoryEntry = Field(description="The recalled memory entry")
    semantic_score: float = Field(description="Raw semantic similarity score 0.0-1.0")
    weighted_score: float = Field(
        description="Final score after outcome weighting"
    )
    rank: int = Field(description="Position in result set (1-based)")


class OutcomeScore(BaseModel):
    """Result of recording an outcome for a memory."""

    memory_id: str = Field(description="Memory that was scored")
    agent_id: str = Field(description="Agent that provided the outcome")
    previous_score: float = Field(description="Score before this update")
    new_score: float = Field(description="Score after this update")
    outcome_count: int = Field(description="Total number of evaluations")
    feedback: Optional[str] = Field(default=None, description="Optional text feedback")


class ScanResult(BaseModel):
    """Result of an injection or content scan."""

    is_safe: bool = Field(description="Whether the content passed all checks")
    blocked: bool = Field(default=False, description="Whether the content was blocked")
    technique: Optional[str] = Field(
        default=None, description="Detected injection technique if any"
    )
    confidence: float = Field(default=0.0, description="Detection confidence 0.0-1.0")
    details: Optional[str] = Field(default=None, description="Human-readable explanation")
    scan_type: str = Field(default="fast", description="fast or semantic")


class GovernanceDecision(BaseModel):
    """Result of a governance evaluation."""

    allowed: bool = Field(description="Whether the operation is permitted")
    rule_id: Optional[str] = Field(default=None, description="Rule that triggered the decision")
    rule_name: Optional[str] = Field(default=None, description="Human-readable rule name")
    reason: Optional[str] = Field(default=None, description="Explanation for block/modification")
    modified_payload: Optional[dict[str, Any]] = Field(
        default=None, description="Modified content if redaction was applied"
    )
    redactions: list[str] = Field(
        default_factory=list, description="List of redaction types applied"
    )


class AuditEventType(str, Enum):
    """Types of auditable events."""

    MEMORY_STORE = "memory_store"
    MEMORY_RECALL = "memory_recall"
    MEMORY_LEARN = "memory_learn"
    MEMORY_DELETE = "memory_delete"
    GOVERNANCE_BLOCK = "governance_block"
    GOVERNANCE_REDACT = "governance_redact"
    INJECTION_BLOCKED = "injection_blocked"
    MEMORY_QUARANTINE = "memory_quarantine"
    CHAIN_VERIFIED = "chain_verified"
    CHAIN_BREACH = "chain_breach"
    TENANT_VIOLATION = "tenant_violation"
    EXPORT_REQUESTED = "export_requested"


class AuditBlock(BaseModel):
    """A single block in the hash-chained audit log."""

    sequence: int = Field(description="Monotonically increasing sequence number")
    event_type: AuditEventType = Field(description="Type of auditable event")
    agent_id: str = Field(description="Agent involved in the event")
    tenant_id: str = Field(description="Tenant context for the event")
    outcome: str = Field(description="allowed, blocked, redacted, error")
    content_hash: Optional[str] = Field(
        default=None, description="SHA-256 of affected content"
    )
    metadata: dict[str, Any] = Field(default_factory=dict, description="Event-specific data")
    prev_hash: str = Field(description="Hash of the previous block")
    block_hash: str = Field(description="SHA-256 hash of this block")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
