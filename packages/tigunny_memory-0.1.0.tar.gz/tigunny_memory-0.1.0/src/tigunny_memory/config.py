"""Configuration models for tigunny-memory."""

from __future__ import annotations

import os
from enum import Enum
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field, model_validator


class EmbeddingProvider(str, Enum):
    """Supported embedding providers."""

    OPENAI = "openai"
    OLLAMA = "ollama"
    VOYAGE = "voyage"
    CUSTOM = "custom"


class BackendType(str, Enum):
    """Supported vector store backends."""

    QDRANT = "qdrant"


class GovernanceBackend(str, Enum):
    """Where governance rules are loaded from."""

    POSTGRES = "postgres"
    MEMORY = "memory"
    NONE = "none"


class MemoryConfig(BaseModel):
    """Configuration for TigunnyMemory.

    All fields can be set via environment variables prefixed with TIGUNNY_MEMORY_
    using the from_env() class method.
    """

    # Vector store
    qdrant_url: str = Field(default="http://localhost:6333", description="Qdrant server URL")
    qdrant_api_key: Optional[str] = Field(default=None, description="Qdrant API key")
    collection_name: str = Field(default="tigunny_memories", description="Qdrant collection name")

    # Embedding provider
    embedding_provider: EmbeddingProvider = Field(
        default=EmbeddingProvider.OLLAMA, description="Embedding provider to use"
    )
    embedding_model: Optional[str] = Field(
        default=None,
        description="Model name override (defaults vary by provider)",
    )
    embedding_dimensions: Optional[int] = Field(
        default=None,
        description="Embedding dimensions (required for CUSTOM provider)",
    )
    openai_api_key: Optional[str] = Field(default=None, description="OpenAI API key")
    ollama_base_url: str = Field(
        default="http://localhost:11434", description="Ollama server URL"
    )
    voyage_api_key: Optional[str] = Field(default=None, description="Voyage AI API key")
    custom_embedding_url: Optional[str] = Field(
        default=None, description="Custom OpenAI-compatible embedding endpoint"
    )

    # Governance
    governance_backend: GovernanceBackend = Field(
        default=GovernanceBackend.MEMORY,
        description="Where to load governance rules from",
    )
    governance_db_url: Optional[str] = Field(
        default=None, description="PostgreSQL URL for governance rules"
    )
    tenant_id: str = Field(
        default="default", description="Tenant identifier for multi-tenant isolation"
    )
    max_ttl_days: int = Field(default=90, description="Maximum memory retention in days")
    enable_dlp: bool = Field(default=True, description="Enable DLP/PII scanning")

    # Audit
    enable_audit_chain: bool = Field(
        default=True, description="Enable hash-chained audit logging"
    )
    audit_db_url: Optional[str] = Field(
        default=None, description="PostgreSQL URL for audit log (uses file backend if unset)"
    )
    audit_export_path: Optional[str] = Field(
        default=None, description="Default path for audit NDJSON export"
    )

    # Swarm sync
    enable_swarm_sync: bool = Field(default=False, description="Enable Redis swarm sync")
    redis_url: Optional[str] = Field(default=None, description="Redis URL for swarm sync")

    # Security
    enable_injection_detection: bool = Field(
        default=True, description="Enable prompt injection detection"
    )
    injection_detection_model: str = Field(
        default="claude-haiku-4-5-20251001",
        description="Model for semantic injection detection",
    )
    anthropic_api_key: Optional[str] = Field(
        default=None, description="Anthropic API key for semantic injection detection"
    )

    # Recall tuning
    recall_top_k: int = Field(default=10, description="Default number of results for recall")
    outcome_weight: float = Field(
        default=0.3,
        description="Weight of outcome score in recall ranking (0.0 = pure semantic)",
    )

    # Cache
    cache_ttl_seconds: int = Field(default=60, description="TTL for injection detection cache")

    @model_validator(mode="after")
    def _validate_provider_config(self) -> MemoryConfig:
        if self.embedding_provider == EmbeddingProvider.OPENAI and not self.openai_api_key:
            raise ValueError("openai_api_key is required when embedding_provider is OPENAI")
        if self.embedding_provider == EmbeddingProvider.VOYAGE and not self.voyage_api_key:
            raise ValueError("voyage_api_key is required when embedding_provider is VOYAGE")
        if self.embedding_provider == EmbeddingProvider.CUSTOM and not self.custom_embedding_url:
            raise ValueError(
                "custom_embedding_url is required when embedding_provider is CUSTOM"
            )
        return self

    @classmethod
    def from_env(cls, dotenv_path: Optional[str] = None) -> MemoryConfig:
        """Load configuration from environment variables.

        All fields map to TIGUNNY_MEMORY_<FIELD_NAME> env vars.
        Also loads from .env file if present.
        """
        load_dotenv(dotenv_path)
        prefix = "TIGUNNY_MEMORY_"
        env_values: dict[str, str] = {}
        for key, value in os.environ.items():
            if key.startswith(prefix):
                field_name = key[len(prefix) :].lower()
                env_values[field_name] = value
        return cls.model_validate(env_values)

    @classmethod
    def minimal(cls) -> MemoryConfig:
        """Create a minimal configuration for quick testing.

        Uses Ollama (free, local) with all defaults.
        """
        return cls(
            embedding_provider=EmbeddingProvider.OLLAMA,
            governance_backend=GovernanceBackend.MEMORY,
            enable_swarm_sync=False,
            enable_injection_detection=False,
        )
