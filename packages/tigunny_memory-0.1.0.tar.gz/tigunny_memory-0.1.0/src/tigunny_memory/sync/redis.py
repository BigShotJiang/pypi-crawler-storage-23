"""Redis-based swarm sync for multi-agent discovery and outcome learning."""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, Optional


class RedisSwarmSync:
    """Redis pub/sub based swarm sync.

    Requires: pip install tigunny-memory[redis]
    """

    def __init__(self) -> None:
        self._redis: Any = None
        self._pubsub: Any = None
        self._tenant_id: str = "default"
        self._task: Any = None

    @property
    def is_active(self) -> bool:
        return self._redis is not None

    async def connect(self, redis_url: str, tenant_id: str) -> None:
        try:
            import redis.asyncio as aioredis
        except ImportError as err:
            raise ImportError(
                "Redis support requires: pip install tigunny-memory[redis]"
            ) from err
        self._redis = aioredis.from_url(redis_url)
        self._tenant_id = tenant_id

    async def publish_discovery(
        self,
        memory_id: str,
        agent_id: str,
        tags: list[str],
        content_hash: str,
        **kwargs: Any,
    ) -> None:
        if not self._redis:
            return
        channel = f"tigunny:memory:discovery:{self._tenant_id}"
        payload = json.dumps({
            "memory_id": memory_id,
            "agent_id": agent_id,
            "tags": tags,
            "content_hash": content_hash,
            "timestamp": datetime.now(UTC).isoformat(),
        })
        await self._redis.publish(channel, payload)

    async def publish_outcome(
        self,
        memory_id: str,
        agent_id: str,
        outcome_score: float,
        **kwargs: Any,
    ) -> None:
        if not self._redis:
            return
        channel = f"tigunny:memory:outcome:{self._tenant_id}"
        payload = json.dumps({
            "memory_id": memory_id,
            "agent_id": agent_id,
            "outcome_score": outcome_score,
            "timestamp": datetime.now(UTC).isoformat(),
        })
        await self._redis.publish(channel, payload)

    async def subscribe(self, callback: Optional[Callable[..., Any]] = None) -> None:
        if not self._redis or not callback:
            return
        import asyncio

        self._pubsub = self._redis.pubsub()
        await self._pubsub.subscribe(
            f"tigunny:memory:discovery:{self._tenant_id}",
            f"tigunny:memory:outcome:{self._tenant_id}",
        )

        async def _listen() -> None:
            async for message in self._pubsub.listen():
                if message["type"] == "message":
                    data = json.loads(message["data"])
                    await callback(data)

        self._task = asyncio.create_task(_listen())

    async def close(self) -> None:
        if self._task:
            self._task.cancel()
        if self._pubsub:
            await self._pubsub.unsubscribe()
        if self._redis:
            await self._redis.close()
