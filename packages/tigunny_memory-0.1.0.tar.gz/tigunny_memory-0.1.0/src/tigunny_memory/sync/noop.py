"""No-op swarm sync — default, zero overhead, no Redis required."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Optional


class NoopSwarmSync:
    """Default swarm sync that does nothing. Zero overhead."""

    @property
    def is_active(self) -> bool:
        return False

    async def publish_discovery(self, **kwargs: Any) -> None:
        pass

    async def publish_outcome(self, **kwargs: Any) -> None:
        pass

    async def subscribe(self, callback: Optional[Callable[..., Any]] = None) -> None:
        pass

    async def close(self) -> None:
        pass
