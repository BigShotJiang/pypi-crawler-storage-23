"""Hash-chained audit writer with file and PostgreSQL backends."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import UTC, datetime
from typing import Any, Optional

from tigunny_memory.types import AuditBlock, AuditEventType


class FileAuditBackend:
    """NDJSON file-based audit backend — works anywhere, no DB required."""

    def __init__(self, file_path: str = "tigunny_audit.ndjson") -> None:
        self.file_path = file_path
        self._sequence = 0
        self._prev_hash = "0" * 64

    async def initialize(self) -> None:
        if os.path.exists(self.file_path):
            with open(self.file_path) as f:
                for line in f:
                    if line.strip():
                        block = json.loads(line)
                        self._sequence = block["sequence"]
                        self._prev_hash = block["block_hash"]

    async def append(self, block: AuditBlock) -> None:
        data = block.model_dump(mode="json")
        data["event_type"] = block.event_type.value
        line = json.dumps(data, default=str) + "\n"
        # Atomic write via temp file + rename
        dir_name = os.path.dirname(self.file_path) or "."
        fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
        try:
            # Copy existing content
            if os.path.exists(self.file_path):
                with open(self.file_path, "rb") as src:
                    os.write(fd, src.read())
            os.write(fd, line.encode())
            os.close(fd)
            os.replace(tmp_path, self.file_path)
        except Exception:
            os.close(fd) if not os.path.exists(tmp_path) else None
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

    async def read_all(self) -> list[AuditBlock]:
        blocks: list[AuditBlock] = []
        if not os.path.exists(self.file_path):
            return blocks
        with open(self.file_path) as f:
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    data["event_type"] = AuditEventType(data["event_type"])
                    blocks.append(AuditBlock(**data))
        return blocks

    @property
    def sequence(self) -> int:
        return self._sequence

    @property
    def prev_hash(self) -> str:
        return self._prev_hash


class HashChainAuditWriter:
    """Hash-chain audit writer that supports file and PostgreSQL backends."""

    def __init__(self, backend: FileAuditBackend) -> None:
        self._backend = backend

    @staticmethod
    async def build(config: Any) -> HashChainAuditWriter:
        if config.audit_db_url:
            # PostgreSQL backend — lazy import
            try:
                from tigunny_memory.audit._postgres import PostgresAuditBackend

                backend = PostgresAuditBackend(config.audit_db_url)
                await backend.initialize()
                return HashChainAuditWriter(backend)  # type: ignore[arg-type]
            except ImportError:
                pass
        # Default to file backend
        export_path = config.audit_export_path or "tigunny_audit.ndjson"
        backend = FileAuditBackend(export_path)
        await backend.initialize()
        return HashChainAuditWriter(backend)

    @staticmethod
    def _compute_hash(
        seq: int,
        prev_hash: str,
        event_type: str,
        agent_id: str,
        tenant_id: str,
        outcome: str,
        ts_ns: int,
        metadata_json: str,
    ) -> str:
        payload = (
            f"{seq}:{prev_hash}:{event_type}:{agent_id}"
            f":{tenant_id}:{outcome}:{ts_ns}:{metadata_json}"
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    async def append(
        self,
        event_type: AuditEventType,
        agent_id: str,
        tenant_id: str,
        outcome: str,
        content_hash: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> AuditBlock:
        metadata = metadata or {}
        now = datetime.now(UTC)
        ts_ns = int(now.timestamp() * 1_000_000_000)
        seq = self._backend.sequence + 1
        prev_hash = self._backend.prev_hash
        metadata_json = json.dumps(metadata, sort_keys=True, default=str)

        block_hash = self._compute_hash(
            seq, prev_hash, event_type.value, agent_id, tenant_id,
            outcome, ts_ns, metadata_json,
        )

        block = AuditBlock(
            sequence=seq,
            event_type=event_type,
            agent_id=agent_id,
            tenant_id=tenant_id,
            outcome=outcome,
            content_hash=content_hash,
            metadata=metadata,
            prev_hash=prev_hash,
            block_hash=block_hash,
            timestamp=now,
        )

        await self._backend.append(block)
        self._backend._sequence = seq
        self._backend._prev_hash = block_hash

        return block

    async def verify_chain(self) -> dict[str, Any]:
        blocks = await self._backend.read_all()
        if not blocks:
            return {"valid": True, "checked": 0, "broken_at_sequence": None}

        expected_prev = "0" * 64
        for block in blocks:
            if block.prev_hash != expected_prev:
                return {
                    "valid": False,
                    "checked": block.sequence,
                    "broken_at_sequence": block.sequence,
                }
            # Recompute hash
            ts_ns = int(block.timestamp.timestamp() * 1_000_000_000)
            metadata_json = json.dumps(block.metadata, sort_keys=True, default=str)
            computed = self._compute_hash(
                block.sequence, block.prev_hash, block.event_type.value,
                block.agent_id, block.tenant_id, block.outcome,
                ts_ns, metadata_json,
            )
            if computed != block.block_hash:
                return {
                    "valid": False,
                    "checked": block.sequence,
                    "broken_at_sequence": block.sequence,
                }
            expected_prev = block.block_hash

        return {"valid": True, "checked": len(blocks), "broken_at_sequence": None}

    async def export(
        self,
        output_path: Optional[str] = None,
        start_seq: int = 0,
    ) -> list[AuditBlock]:
        blocks = await self._backend.read_all()
        filtered = [b for b in blocks if b.sequence >= start_seq]

        if output_path:
            with open(output_path, "w") as f:
                for block in filtered:
                    data = block.model_dump(mode="json")
                    data["event_type"] = block.event_type.value
                    f.write(json.dumps(data, default=str) + "\n")

        return filtered
