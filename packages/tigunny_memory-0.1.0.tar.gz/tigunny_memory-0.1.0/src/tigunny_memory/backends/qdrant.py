"""Qdrant vector backend implementation."""

from __future__ import annotations

import contextlib
import hashlib
from datetime import UTC, datetime
from typing import Any, Optional

from tigunny_memory.backends.base import VectorBackend
from tigunny_memory.config import MemoryConfig
from tigunny_memory.types import MemoryEntry


class QdrantBackend(VectorBackend):
    """Qdrant vector store backend with structural tenant isolation."""

    def __init__(self, config: MemoryConfig) -> None:
        self._config = config
        self._client: Any = None

    async def connect(self) -> None:
        from qdrant_client import AsyncQdrantClient

        self._client = AsyncQdrantClient(
            url=self._config.qdrant_url,
            api_key=self._config.qdrant_api_key,
        )

    async def close(self) -> None:
        if self._client:
            await self._client.close()

    async def ensure_collection(self, dimensions: int) -> None:
        from qdrant_client.models import (
            Distance,
            HnswConfigDiff,
            PayloadSchemaType,
            VectorParams,
        )

        collections = await self._client.get_collections()
        existing = [c.name for c in collections.collections]

        if self._config.collection_name not in existing:
            await self._client.create_collection(
                collection_name=self._config.collection_name,
                vectors_config=VectorParams(
                    size=dimensions,
                    distance=Distance.COSINE,
                    hnsw_config=HnswConfigDiff(m=16, ef_construct=100),
                ),
            )

        # Create payload indexes
        for field_name in ["tenant_id", "agent_id", "tags"]:
            with contextlib.suppress(Exception):
                await self._client.create_payload_index(
                    collection_name=self._config.collection_name,
                    field_name=field_name,
                    field_schema=PayloadSchemaType.KEYWORD,
                )

    async def upsert(self, entry: MemoryEntry, embedding: list[float]) -> None:
        from qdrant_client.models import PointStruct

        payload = {
            "memory_id": entry.memory_id,
            "agent_id": entry.agent_id,
            "tenant_id": entry.tenant_id,
            "content": entry.content,
            "content_hash": entry.content_hash,
            "tags": entry.tags,
            "ttl_days": entry.ttl_days,
            "metadata": entry.metadata,
            "outcome_score": entry.outcome_score,
            "outcome_count": entry.outcome_count,
            "created_at": entry.created_at.isoformat(),
            "expires_at": entry.expires_at.isoformat() if entry.expires_at else None,
        }

        # Use deterministic int ID from UUID
        point_id_int = int(hashlib.md5(entry.memory_id.encode()).hexdigest(), 16) % (2**63)

        await self._client.upsert(
            collection_name=self._config.collection_name,
            points=[
                PointStruct(
                    id=point_id_int,
                    vector=embedding,
                    payload=payload,
                )
            ],
        )

    async def search(
        self,
        embedding: list[float],
        tenant_id: str,
        agent_id: Optional[str] = None,
        tags: Optional[list[str]] = None,
        top_k: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryEntry, float]]:
        from qdrant_client.models import FieldCondition, Filter, MatchAny, MatchValue

        # STRUCTURAL tenant filter — always applied
        must_conditions = [
            FieldCondition(key="tenant_id", match=MatchValue(value=tenant_id))
        ]
        if agent_id:
            must_conditions.append(
                FieldCondition(key="agent_id", match=MatchValue(value=agent_id))
            )
        if tags:
            must_conditions.append(
                FieldCondition(key="tags", match=MatchAny(any=tags))
            )

        try:
            results = await self._client.query_points(
                collection_name=self._config.collection_name,
                query=embedding,
                query_filter=Filter(must=must_conditions),  # type: ignore[arg-type]
                limit=top_k,
                score_threshold=min_score if min_score > 0 else None,
            )
            points = results.points
        except AttributeError:
            # Fallback for older qdrant-client versions
            results = await self._client.search(  # type: ignore[attr-defined]
                collection_name=self._config.collection_name,
                query_vector=embedding,
                query_filter=Filter(must=must_conditions),  # type: ignore[arg-type]
                limit=top_k,
                score_threshold=min_score if min_score > 0 else None,
            )
            points = results  # type: ignore[assignment]

        entries = []
        for hit in points:
            payload = hit.payload or {}
            created_at = payload.get("created_at")
            expires_at = payload.get("expires_at")
            entry = MemoryEntry(
                memory_id=payload.get("memory_id", ""),
                agent_id=payload.get("agent_id", ""),
                tenant_id=payload.get("tenant_id", ""),
                content=payload.get("content", {}),
                content_hash=payload.get("content_hash", ""),
                tags=payload.get("tags", []),
                ttl_days=payload.get("ttl_days"),
                metadata=payload.get("metadata", {}),
                outcome_score=payload.get("outcome_score", 0.5),
                outcome_count=payload.get("outcome_count", 0),
                created_at=datetime.fromisoformat(created_at) if created_at else datetime.now(UTC),
                expires_at=datetime.fromisoformat(expires_at) if expires_at else None,
            )
            entries.append((entry, hit.score))

        return entries

    async def get_outcome(self, memory_id: str) -> dict[str, Any]:
        point_id = int(hashlib.md5(memory_id.encode()).hexdigest(), 16) % (2**63)
        try:
            points = await self._client.retrieve(
                collection_name=self._config.collection_name,
                ids=[point_id],
            )
            if points:
                payload = points[0].payload or {}
                return {
                    "outcome_score": payload.get("outcome_score", 0.5),
                    "outcome_count": payload.get("outcome_count", 0),
                }
        except Exception:
            pass
        return {"outcome_score": 0.5, "outcome_count": 0}

    async def update_outcome(
        self,
        memory_id: str,
        outcome_score: float,
        outcome_count: int,
    ) -> None:
        point_id = int(hashlib.md5(memory_id.encode()).hexdigest(), 16) % (2**63)
        await self._client.set_payload(
            collection_name=self._config.collection_name,
            payload={
                "outcome_score": outcome_score,
                "outcome_count": outcome_count,
            },
            points=[point_id],
        )

    async def delete(self, memory_id: str) -> None:
        from qdrant_client.models import PointIdsList

        point_id = int(hashlib.md5(memory_id.encode()).hexdigest(), 16) % (2**63)
        await self._client.delete(
            collection_name=self._config.collection_name,
            points_selector=PointIdsList(points=[point_id]),
        )

    async def health_check(self) -> bool:
        try:
            await self._client.get_collections()
            return True
        except Exception:
            return False
