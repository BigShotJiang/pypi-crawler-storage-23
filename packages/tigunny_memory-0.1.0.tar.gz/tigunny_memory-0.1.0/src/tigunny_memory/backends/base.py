"""Base vector backend interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from tigunny_memory.types import MemoryEntry


class VectorBackend(ABC):
    """Abstract base class for vector store backends.

    All implementations MUST apply tenant_id filtering structurally
    in search queries — this is a security invariant that cannot be bypassed.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the vector store."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Close the connection."""
        ...

    @abstractmethod
    async def ensure_collection(self, dimensions: int) -> None:
        """Create or verify the collection exists with correct dimensions."""
        ...

    @abstractmethod
    async def upsert(self, entry: MemoryEntry, embedding: list[float]) -> None:
        """Insert or update a memory entry with its embedding vector."""
        ...

    @abstractmethod
    async def search(
        self,
        embedding: list[float],
        tenant_id: str,
        agent_id: Optional[str] = None,
        tags: Optional[list[str]] = None,
        top_k: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryEntry, float]]:
        """Search for similar memories.

        MUST always filter by tenant_id structurally.
        Returns list of (MemoryEntry, semantic_score) tuples.
        """
        ...

    @abstractmethod
    async def get_outcome(self, memory_id: str) -> dict[str, Any]:
        """Get current outcome score and count for a memory."""
        ...

    @abstractmethod
    async def update_outcome(
        self,
        memory_id: str,
        outcome_score: float,
        outcome_count: int,
    ) -> None:
        """Update the outcome score for a memory."""
        ...

    @abstractmethod
    async def delete(self, memory_id: str) -> None:
        """Delete a memory entry by ID."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the backend is healthy and reachable."""
        ...
