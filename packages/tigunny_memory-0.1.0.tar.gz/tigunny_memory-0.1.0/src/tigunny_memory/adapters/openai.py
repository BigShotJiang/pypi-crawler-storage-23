"""OpenAI embedding adapter using httpx (no SDK dependency)."""

from __future__ import annotations

import asyncio
from typing import Optional

import httpx

from tigunny_memory.adapters.base import EmbeddingAdapter
from tigunny_memory.exceptions import EmbeddingError

_MODEL_DIMENSIONS = {
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
}


class OpenAIEmbeddingAdapter(EmbeddingAdapter):
    """OpenAI embeddings via httpx — no openai SDK required."""

    def __init__(
        self,
        api_key: str,
        model: Optional[str] = None,
        base_url: str = "https://api.openai.com/v1",
    ) -> None:
        self._api_key = api_key
        self._model = model or "text-embedding-3-small"
        self._base_url = base_url.rstrip("/")
        self._dimensions = _MODEL_DIMENSIONS.get(self._model, 1536)

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model_name(self) -> str:
        return self._model

    async def embed(self, text: str) -> list[float]:
        results = await self.embed_batch([text])
        return results[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        max_retries = 3
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    response = await client.post(
                        f"{self._base_url}/embeddings",
                        headers={
                            "Authorization": f"Bearer {self._api_key}",
                            "Content-Type": "application/json",
                        },
                        json={"model": self._model, "input": texts},
                    )
                    if response.status_code in (429, 500, 503) and attempt < max_retries - 1:
                            await asyncio.sleep(2 ** attempt)
                            continue
                    response.raise_for_status()
                    data = response.json()
                    # Sort by index to maintain order
                    embeddings = sorted(data["data"], key=lambda x: x["index"])
                    return [e["embedding"] for e in embeddings]
            except httpx.HTTPStatusError as e:
                if attempt == max_retries - 1:
                    raise EmbeddingError(
                        f"OpenAI embedding failed after {max_retries} attempts: {e}"
                    ) from e
            except httpx.RequestError as e:
                if attempt == max_retries - 1:
                    raise EmbeddingError(f"OpenAI connection error: {e}") from e
                await asyncio.sleep(2 ** attempt)

        raise EmbeddingError("OpenAI embedding failed: max retries exceeded")

    async def health_check(self) -> bool:
        try:
            await self.embed("health check")
            return True
        except Exception:
            return False
