"""Custom OpenAI-compatible embedding adapter."""

from __future__ import annotations

from typing import Optional

import httpx

from tigunny_memory.adapters.base import EmbeddingAdapter
from tigunny_memory.exceptions import ConfigurationError, EmbeddingError


class CustomEmbeddingAdapter(EmbeddingAdapter):
    """Any OpenAI-compatible embedding endpoint (Azure OpenAI, vLLM, LM Studio)."""

    def __init__(
        self,
        endpoint_url: str,
        dimensions: int,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> None:
        if not endpoint_url:
            raise ConfigurationError("custom_embedding_url is required for CUSTOM provider")
        if not dimensions:
            raise ConfigurationError(
                "embedding_dimensions is required for CUSTOM provider"
            )
        self._endpoint_url = endpoint_url.rstrip("/")
        self._dimensions = dimensions
        self._model = model or "custom"
        self._api_key = api_key

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model_name(self) -> str:
        return self._model

    async def embed(self, text: str) -> list[float]:
        results = await self.embed_batch([text])
        return results[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self._endpoint_url,
                    headers=headers,
                    json={"model": self._model, "input": texts},
                )
                response.raise_for_status()
                data = response.json()
                embeddings = sorted(data["data"], key=lambda x: x["index"])
                return [e["embedding"] for e in embeddings]
        except httpx.HTTPStatusError as e:
            raise EmbeddingError(f"Custom embedding endpoint error: {e}") from e
        except httpx.RequestError as e:
            raise EmbeddingError(
                f"Cannot reach custom embedding endpoint at {self._endpoint_url}: {e}"
            ) from e
