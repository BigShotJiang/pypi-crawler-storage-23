"""Ollama embedding adapter using httpx."""

from __future__ import annotations

from typing import Optional

import httpx

from tigunny_memory.adapters.base import EmbeddingAdapter
from tigunny_memory.exceptions import EmbeddingError

_MODEL_DIMENSIONS = {
    "nomic-embed-text": 768,
    "all-minilm": 384,
    "mxbai-embed-large": 1024,
}


class OllamaEmbeddingAdapter(EmbeddingAdapter):
    """Ollama local embeddings via REST API."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: Optional[str] = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model or "nomic-embed-text"
        self._dimensions = _MODEL_DIMENSIONS.get(self._model, 768)

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model_name(self) -> str:
        return self._model

    async def embed(self, text: str) -> list[float]:
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{self._base_url}/api/embeddings",
                    json={"model": self._model, "prompt": text},
                )
                if response.status_code == 404:
                    raise EmbeddingError(
                        f"Model '{self._model}' not found. "
                        f"Run: ollama pull {self._model}"
                    )
                response.raise_for_status()
                data = response.json()
                embedding = data.get("embedding", [])
                if not embedding:
                    raise EmbeddingError("Ollama returned empty embedding")
                self._dimensions = len(embedding)
                return list(embedding)
        except httpx.ConnectError as e:
            raise EmbeddingError(
                f"Cannot connect to Ollama at {self._base_url}. "
                "Is Ollama running? Start with: ollama serve"
            ) from e
        except httpx.HTTPStatusError as e:
            raise EmbeddingError(f"Ollama embedding error: {e}") from e

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self._base_url}/api/tags")
                if response.status_code != 200:
                    return False
                data = response.json()
                models = [m.get("name", "").split(":")[0] for m in data.get("models", [])]
                return self._model in models
        except Exception:
            return False
