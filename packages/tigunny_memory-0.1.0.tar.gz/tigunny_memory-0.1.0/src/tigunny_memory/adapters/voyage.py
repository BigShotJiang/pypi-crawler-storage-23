"""Voyage AI embedding adapter using httpx."""

from __future__ import annotations

from typing import Optional

import httpx

from tigunny_memory.adapters.base import EmbeddingAdapter
from tigunny_memory.exceptions import EmbeddingError

_MODEL_DIMENSIONS = {
    "voyage-3": 1024,
    "voyage-3-lite": 512,
    "voyage-2": 1024,
}


class VoyageEmbeddingAdapter(EmbeddingAdapter):
    """Voyage AI embeddings via httpx."""

    def __init__(
        self,
        api_key: str,
        model: Optional[str] = None,
    ) -> None:
        self._api_key = api_key
        self._model = model or "voyage-3"
        self._dimensions = _MODEL_DIMENSIONS.get(self._model, 1024)

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model_name(self) -> str:
        return self._model

    async def embed(self, text: str) -> list[float]:
        results = await self.embed_batch([text])
        return results[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    "https://api.voyageai.com/v1/embeddings",
                    headers={
                        "Authorization": f"Bearer {self._api_key}",
                        "Content-Type": "application/json",
                    },
                    json={"model": self._model, "input": texts},
                )
                response.raise_for_status()
                data = response.json()
                embeddings = sorted(data["data"], key=lambda x: x["index"])
                return [e["embedding"] for e in embeddings]
        except httpx.HTTPStatusError as e:
            raise EmbeddingError(f"Voyage AI embedding failed: {e}") from e
        except httpx.RequestError as e:
            raise EmbeddingError(f"Voyage AI connection error: {e}") from e

    async def health_check(self) -> bool:
        try:
            await self.embed("health check")
            return True
        except Exception:
            return False
