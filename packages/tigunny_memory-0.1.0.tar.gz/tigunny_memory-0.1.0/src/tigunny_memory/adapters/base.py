"""Base embedding adapter interface and factory."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tigunny_memory.config import MemoryConfig


class EmbeddingAdapter(ABC):
    """Abstract base class for embedding providers."""

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Return the dimensionality of embeddings produced by this adapter."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return the model identifier used by this adapter."""
        ...

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Generate an embedding vector for a single text."""
        ...

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embedding vectors for multiple texts.

        Default implementation calls embed() sequentially.
        Adapters with native batch support should override this.
        """
        return [await self.embed(text) for text in texts]

    async def health_check(self) -> bool:
        """Check if the embedding provider is reachable and working."""
        try:
            result = await self.embed("health check")
            return len(result) == self.dimensions
        except Exception:
            return False


class EmbeddingAdapterFactory:
    """Factory for creating embedding adapters from configuration."""

    @staticmethod
    def from_config(config: MemoryConfig) -> EmbeddingAdapter:
        """Create the appropriate embedding adapter based on config.

        Uses lazy imports so optional provider SDKs are only required
        when actually selected.
        """
        from tigunny_memory.config import EmbeddingProvider

        if config.embedding_provider == EmbeddingProvider.OPENAI:
            from tigunny_memory.adapters.openai import OpenAIEmbeddingAdapter

            return OpenAIEmbeddingAdapter(
                api_key=config.openai_api_key or "",
                model=config.embedding_model,
            )

        if config.embedding_provider == EmbeddingProvider.OLLAMA:
            from tigunny_memory.adapters.ollama import OllamaEmbeddingAdapter

            return OllamaEmbeddingAdapter(
                base_url=config.ollama_base_url,
                model=config.embedding_model,
            )

        if config.embedding_provider == EmbeddingProvider.VOYAGE:
            from tigunny_memory.adapters.voyage import VoyageEmbeddingAdapter

            return VoyageEmbeddingAdapter(
                api_key=config.voyage_api_key or "",
                model=config.embedding_model,
            )

        if config.embedding_provider == EmbeddingProvider.CUSTOM:
            from tigunny_memory.adapters.custom import CustomEmbeddingAdapter
            from tigunny_memory.exceptions import ConfigurationError

            if not config.embedding_dimensions:
                raise ConfigurationError(
                    "embedding_dimensions is required for CUSTOM provider"
                )
            return CustomEmbeddingAdapter(
                endpoint_url=config.custom_embedding_url or "",
                dimensions=config.embedding_dimensions,
                model=config.embedding_model,
                api_key=config.openai_api_key,
            )

        from tigunny_memory.exceptions import ConfigurationError

        raise ConfigurationError(
            f"Unknown embedding provider: {config.embedding_provider}"
        )
