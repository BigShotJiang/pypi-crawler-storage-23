"""Exception hierarchy for tigunny-memory."""


class TigunnyMemoryError(Exception):
    """Base exception for all tigunny-memory errors."""


class ConnectionError(TigunnyMemoryError):
    """Failed to connect to a backend service (Qdrant, Redis, PostgreSQL)."""


class EmbeddingError(TigunnyMemoryError):
    """Failed to generate embeddings from the configured provider."""


class GovernanceViolationError(TigunnyMemoryError):
    """A governance rule blocked the operation."""


class PIIDetectedError(GovernanceViolationError):
    """PII was detected in content and the governance policy blocks PII storage."""


class TTLViolationError(GovernanceViolationError):
    """The requested TTL exceeds the maximum allowed by governance policy."""


class AuditChainError(TigunnyMemoryError):
    """The hash-chain audit log has an integrity violation."""


class InjectionDetectedError(TigunnyMemoryError):
    """Prompt injection or memory poisoning attempt detected in content."""


class MemoryPoisoningError(TigunnyMemoryError):
    """Attempted manipulation of stored memories detected."""


class ConfigurationError(TigunnyMemoryError):
    """Invalid or missing configuration for a required feature."""
