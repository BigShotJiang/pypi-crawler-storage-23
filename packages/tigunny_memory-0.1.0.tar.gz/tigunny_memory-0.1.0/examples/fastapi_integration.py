"""
FastAPI integration example — TigunnyMemory as a shared lifespan dependency.

Prerequisites:
  pip install tigunny-memory fastapi uvicorn
  docker run -p 6333:6333 qdrant/qdrant

Usage:
  uvicorn examples.fastapi_integration:app --reload
"""

from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from tigunny_memory import MemoryConfig, TigunnyMemory

# Shared instance — created once, used by all requests
memory: TigunnyMemory | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize TigunnyMemory on startup, close on shutdown."""
    global memory
    config = MemoryConfig.from_env()
    memory = TigunnyMemory(config)
    await memory.connect()
    yield
    await memory.close()


app = FastAPI(title="Agent Memory API", lifespan=lifespan)


class ExecuteRequest(BaseModel):
    agent_id: str
    task: str
    tags: list[str] = []


class LearnRequest(BaseModel):
    agent_id: str
    memory_id: str
    outcome_score: float
    feedback: str | None = None


@app.post("/agent/execute")
async def execute_with_memory(req: ExecuteRequest) -> dict[str, Any]:
    """Execute a task with memory-augmented context."""
    assert memory is not None

    # Recall relevant past experiences
    past = await memory.recall(req.agent_id, req.task, top_k=5)
    context = [
        {"content": r.memory.content, "score": r.weighted_score}
        for r in past
    ]

    # In production, you would call an LLM here with the context
    result = f"Executed '{req.task}' with {len(context)} relevant memories"

    # Store the new experience
    entry = await memory.store(
        agent_id=req.agent_id,
        content={"task": req.task, "result": result},
        tags=req.tags,
    )

    return {
        "memory_id": entry.memory_id,
        "result": result,
        "memories_used": len(context),
    }


@app.get("/agent/{agent_id}/memories")
async def list_memories(agent_id: str, query: str = "recent work") -> list[dict[str, Any]]:
    """List recent memories for an agent."""
    assert memory is not None
    results = await memory.recall(agent_id, query, top_k=10)
    return [
        {
            "memory_id": r.memory.memory_id,
            "content": r.memory.content,
            "tags": r.memory.tags,
            "score": r.weighted_score,
            "outcome": r.memory.outcome_score,
        }
        for r in results
    ]


@app.post("/agent/learn")
async def record_outcome(req: LearnRequest) -> dict[str, Any]:
    """Record an outcome score for a memory."""
    assert memory is not None
    try:
        result = await memory.learn(
            req.agent_id, req.memory_id, req.outcome_score, req.feedback
        )
        return {
            "memory_id": result.memory_id,
            "previous_score": result.previous_score,
            "new_score": result.new_score,
            "outcome_count": result.outcome_count,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/health")
async def health_check() -> dict[str, Any]:
    """Check all backend health."""
    assert memory is not None
    return await memory.health()
