"""
Basic tigunny-memory usage — store, recall, and learn.

Prerequisites:
  pip install tigunny-memory
  docker run -p 6333:6333 qdrant/qdrant
  ollama pull nomic-embed-text  # or use OpenAI

Usage:
  python examples/basic_usage.py
"""

import asyncio
import json
from tigunny_memory import TigunnyMemory, MemoryConfig, EmbeddingProvider


async def main() -> None:
    # Create config — uses Ollama (free, local) by default
    config = MemoryConfig(
        embedding_provider=EmbeddingProvider.OLLAMA,
        tenant_id="demo-project",
        collection_name="demo_memories",
    )

    async with TigunnyMemory(config) as mem:
        print("Connected to tigunny-memory\n")

        # ─── Store memories ─────────────────────────────────
        print("Storing 5 agent experiences...")
        entries = []

        experiences = [
            {
                "content": {"task": "market research", "result": "Q4 revenue grew 23% YoY"},
                "tags": ["research", "finance"],
            },
            {
                "content": {"task": "code review", "result": "Found SQL injection in user endpoint"},
                "tags": ["security", "code"],
            },
            {
                "content": {"task": "document analysis", "result": "Contract expires March 2025"},
                "tags": ["legal", "contracts"],
            },
            {
                "content": {"task": "competitor analysis", "result": "Competitor X launched AI product"},
                "tags": ["research", "competitive"],
            },
            {
                "content": {"task": "architecture review", "result": "Recommend microservices migration"},
                "tags": ["engineering", "architecture"],
            },
        ]

        for exp in experiences:
            entry = await mem.store(
                agent_id="analyst-agent",
                content=exp["content"],
                tags=exp["tags"],
                ttl_days=30,
            )
            entries.append(entry)
            print(f"  Stored: {entry.memory_id[:8]}... [{', '.join(exp['tags'])}]")

        # ─── Recall with semantic query ─────────────────────
        print("\n--- Recall: 'What security issues did we find?' ---")
        results = await mem.recall("analyst-agent", "What security issues did we find?", top_k=3)
        for r in results:
            print(f"  [{r.rank}] score={r.weighted_score:.3f}  {json.dumps(r.memory.content)[:80]}")

        # ─── Record outcomes ────────────────────────────────
        print("\n--- Recording outcomes ---")
        # The security finding was very useful
        score1 = await mem.learn("analyst-agent", entries[1].memory_id, 0.95, "Led to critical fix")
        print(f"  Security finding: {score1.previous_score:.2f} -> {score1.new_score:.2f}")

        # The market research was somewhat useful
        score2 = await mem.learn("analyst-agent", entries[0].memory_id, 0.6)
        print(f"  Market research: {score2.previous_score:.2f} -> {score2.new_score:.2f}")

        # The architecture review wasn't relevant to what we needed
        score3 = await mem.learn("analyst-agent", entries[4].memory_id, 0.2)
        print(f"  Architecture review: {score3.previous_score:.2f} -> {score3.new_score:.2f}")

        # ─── Recall again — rankings should shift ───────────
        print("\n--- Recall after learning: 'What security issues did we find?' ---")
        results = await mem.recall("analyst-agent", "What security issues did we find?", top_k=3)
        for r in results:
            print(f"  [{r.rank}] score={r.weighted_score:.3f}  outcome={r.memory.outcome_score:.2f}  {json.dumps(r.memory.content)[:60]}")

        # ─── Export audit trail ─────────────────────────────
        print("\n--- Audit trail ---")
        integrity = await mem.verify_integrity()
        print(f"  Chain valid: {integrity['valid']}, blocks checked: {integrity['checked']}")

        blocks = await mem.export_audit(output_path="./demo_audit.ndjson")
        print(f"  Exported {len(blocks)} audit blocks to demo_audit.ndjson")

        # ─── Health check ───────────────────────────────────
        print("\n--- Health ---")
        health = await mem.health()
        for k, v in health.items():
            if k != "overall_healthy":
                status = "OK" if (v is True or (isinstance(v, dict) and v.get("healthy"))) else "?"
                print(f"  {k}: {status}")

    print("\nDone!")


if __name__ == "__main__":
    asyncio.run(main())
