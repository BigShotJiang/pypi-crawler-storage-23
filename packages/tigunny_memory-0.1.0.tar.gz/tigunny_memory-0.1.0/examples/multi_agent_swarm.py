"""
Multi-agent swarm sync example — agents share discoveries via Redis.

Prerequisites:
  pip install tigunny-memory[redis]
  docker run -p 6333:6333 qdrant/qdrant
  docker run -p 6379:6379 redis:latest

Usage:
  python examples/multi_agent_swarm.py
"""

import asyncio
import json
from tigunny_memory import TigunnyMemory, MemoryConfig, EmbeddingProvider


async def main() -> None:
    # Both agents share the same Qdrant + Redis, same tenant
    base_config = dict(
        embedding_provider=EmbeddingProvider.OLLAMA,
        tenant_id="swarm-demo",
        collection_name="swarm_memories",
        enable_swarm_sync=True,
        redis_url="redis://localhost:6379",
    )

    config_a = MemoryConfig(**base_config)
    config_b = MemoryConfig(**base_config)

    discoveries: list[dict] = []

    async def on_discovery(event: dict) -> None:
        """Callback when Agent B receives a discovery notification."""
        discoveries.append(event)
        print(f"  Agent B received discovery: {event['memory_id'][:8]}... tags={event.get('tags')}")

    async with TigunnyMemory(config_a) as agent_a, TigunnyMemory(config_b) as agent_b:
        # Agent B subscribes to discovery events
        await agent_b._swarm_sync.subscribe(on_discovery)
        await asyncio.sleep(0.5)  # Let subscription establish

        # Agent A stores a discovery
        print("Agent A storing discovery...")
        entry = await agent_a.store(
            agent_id="agent-a",
            content={
                "finding": "Competitor launched new AI product",
                "source": "press release",
                "confidence": 0.9,
            },
            tags=["competitive-intel", "ai"],
        )
        print(f"  Stored: {entry.memory_id[:8]}...")

        # Give Redis a moment to deliver
        await asyncio.sleep(1.0)

        # Agent B can now recall from the shared Qdrant store
        print("\nAgent B recalling shared knowledge...")
        results = await agent_b.recall("agent-b", "What do we know about competitor AI?")
        for r in results:
            print(f"  [{r.rank}] {json.dumps(r.memory.content)[:80]}")

        # Agent B records that this was useful
        if results:
            score = await agent_b.learn("agent-b", results[0].memory.memory_id, 0.85)
            print(f"\n  Agent B scored memory: {score.new_score:.2f}")

        print(f"\nDiscovery events received by Agent B: {len(discoveries)}")

    print("\nSwarm demo complete!")


if __name__ == "__main__":
    asyncio.run(main())
