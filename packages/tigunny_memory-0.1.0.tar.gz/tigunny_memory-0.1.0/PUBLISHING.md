# Publishing tigunny-memory to PyPI

## Pre-Publish Checklist

- [ ] All unit tests pass: `pytest tests/unit/ -v --cov=tigunny_memory --cov-fail-under=80`
- [ ] No lint errors: `ruff check src/ tests/`
- [ ] Type check passes: `mypy src/tigunny_memory/ --ignore-missing-imports`
- [ ] Build succeeds: `python -m build`
- [ ] Package check passes: `twine check dist/*`
- [ ] README renders correctly (check PyPI preview)
- [ ] Version in `pyproject.toml` matches `__init__.py`
- [ ] CHANGELOG updated (if applicable)
- [ ] All examples run without import errors

## Step-by-Step Publish

### 1. Run full test suite

```bash
pytest tests/unit/ -v --cov=tigunny_memory --cov-fail-under=80
ruff check src/ tests/
mypy src/tigunny_memory/ --ignore-missing-imports
```

### 2. Build the package

```bash
rm -rf dist/ build/
python -m build
```

### 3. Verify the build

```bash
twine check dist/*
# Should output: PASSED for both .tar.gz and .whl
```

### 4. Test install from wheel

```bash
pip install dist/tigunny_memory-0.1.0-py3-none-any.whl
python -c "from tigunny_memory import TigunnyMemory; print('Import OK')"
tigunny-memory version
```

### 5. Upload to TestPyPI (optional but recommended)

```bash
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ tigunny-memory
```

### 6. Upload to PyPI

```bash
twine upload dist/*
# Or use GitHub Actions: push a tag
git tag -a v0.1.0 -m "tigunny-memory v0.1.0"
git push origin v0.1.0
```

### 7. Post-publish smoke test

```bash
pip install tigunny-memory
python -c "from tigunny_memory import TigunnyMemory, __version__; print(f'v{__version__} OK')"
tigunny-memory version
```

## Automated Publishing

The GitHub Actions workflow at `.github/workflows/publish.yml` automatically:

1. Runs the test suite
2. Builds the package
3. Uploads to PyPI using `PYPI_TOKEN` secret
4. Creates a GitHub Release

Trigger: push a tag matching `v*.*.*` to the repository.

## Secrets Required

| Secret | Where | Description |
|--------|-------|-------------|
| `PYPI_TOKEN` | GitHub repo settings > Secrets | PyPI API token for `tigunny-memory` |
