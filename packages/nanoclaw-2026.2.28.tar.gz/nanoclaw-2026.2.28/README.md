# NanoClaw — Docker Container Management & Remote Agent Deployment for Python

[![PyPI](https://img.shields.io/pypi/v/nanoclaw.svg)](https://pypi.org/project/nanoclaw/) [![Python](https://img.shields.io/pypi/pyversions/nanoclaw.svg)](https://pypi.org/project/nanoclaw/) [![license](https://img.shields.io/pypi/l/nanoclaw.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

NanoClaw delivers robust Docker management Python developers need for remote container deployment. Unlike Dockerode, Portainer, or even the Docker SDK, NanoClaw directly integrates containerized AI agent deployment using a lightweight Docker SDK Node. Build, manage, and scale your container deployments with Python.

## Features

- Orchestrate Docker container deployment across diverse remote environments.
- Automate container lifecycle management using Python scripts.
- Extend existing applications with containerized AI agent capabilities.
- Integrate with existing Docker infrastructure via Python.
- Manage Docker images and volumes with ease.
- Monitor container health and resource utilization.

## Use Cases

- Deploy and manage Docker containers on remote machines
- Stream container logs and monitor running services
- Automate container lifecycle with AI agents

## Installation

```bash
pip install nanoclaw
```

## Quick Start

```python
from nanoclaw import NanoClaw

client = NanoClaw.remote(api_key="cmdop_live_xxx")

client.deploy("nginx:latest", port=8080, name="web")

for c in client.containers():
    print(c.get("Names"), c.get("Status"))

print(client.logs("web", tail=100))
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [nanoclaw on PyPI](https://pypi.org/project/nanoclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
