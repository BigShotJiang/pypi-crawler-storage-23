import os
from setuptools import find_packages, setup

os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

with open('README.md') as f:
    long_description = f.read()

setup(
    name='numpy-rolling-ball',
    packages=find_packages(),
    version='1.0.1',
    description='Now function returns both result image and subtracted background',
    long_description=long_description,
    long_description_content_type='text/markdown',
    license='MIT License',
    author='Maksym Balatsko adapted by Dr. Alberto Lencina',
    author_email='alencina@azul.faa.unicen.edu.ar',
    url='https://github.com/alencina-faa/numpy-rolling-ball',
    download_url='',
    install_requires=[
        'numpy'
    ],
    keywords=['numpy', 'background subtraction', 'rolling ball algorithm'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.0',
        'Programming Language :: Python :: 3.1',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering :: Image Recognition'
    ]
)
