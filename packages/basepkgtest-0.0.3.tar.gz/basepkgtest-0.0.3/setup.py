import os
from setuptools import setup, find_packages

# these things are needed for the README.md show on pypi (if you dont need delete it)
here = os.path.abspath(os.path.dirname(__file__))

# 读取当前项目的 README.md 文件, 生成包的详细描述文本
with open(os.path.join(here, "README.md"), encoding="utf-8") as fh:
    long_description = "\n" + fh.read()

# 需要修改的变量
# 代码包版本号
VERSION = '0.0.3'
# 基本的包描述
DESCRIPTION = '一个 lg 上传的测试代码包, 可以被其他任何人进行引入使用。'
LONG_DESCRIPTION = '支持多个操作系统进行使用, 如: windows, linux, mac 等等。'

setup(
    name="basepkgtest", # 包的名称, 固定
    version=VERSION, # 包的版本号
    author="lg", # 包的开发者/作者
    author_email="44555@163.com", # 作者邮箱号
    description=DESCRIPTION, # 基本描述
    long_description_content_type="text/markdown", # 详细描述的内容格式
    long_description=long_description, # 详细描述
    packages=find_packages(), # 相关包
    install_requires=['pyotp'], # 当前包使用时, 需要引入的其他依赖包
    keywords=['python', 'util', 'lg','windows','mac','linux'], # 指定一些自定义的包信息关键词, 便于被其他人搜索到
    classifiers=[ # 指定一些标识信息, 如当前包基于的 python 解释器版本号
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)
