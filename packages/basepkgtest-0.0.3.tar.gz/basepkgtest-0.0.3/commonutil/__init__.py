
print('导入 LG 的基础工具包!')