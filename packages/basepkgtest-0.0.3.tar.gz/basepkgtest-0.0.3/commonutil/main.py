
import time
import pyotp

def return_time_helloworld() -> str:
    '''
    定义函数, 用于生成与当前时间相关的字符串, 如返回: '2026-02-21 20:16:16 hello world.'
    :return:
    '''
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + ' hello world.'

def twofa_gen_verification_code(src_key: str) -> str:
    '''
    2fa 校验的随时间变化的动态密码生成
    @param: param src_key: 2fa 生成随时间变化的基础字符串
    @return: 返回相关的动态验证码
    '''
    if src_key is None or len(src_key) == 0:
        raise Exception('2fa 生成随时间变化的基础字符串未指定!')
    # 参数: 2fa 校验生成动态密码的参数字符串
    totp = pyotp.TOTP(src_key)
    print('2fa 生成的动态验证码为', totp.now())
    return totp.now()

if __name__ == '__main__':
    s = return_time_helloworld()
    print(s)
    print(twofa_gen_verification_code(''))

