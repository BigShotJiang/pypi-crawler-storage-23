# py-base-pkg 包描述

- 作者是：LG。一个 lg 上传的测试代码包, 可以被其他任何人进行引入使用。
- 支持系统：支持多个操作系统进行使用, 如: windows, linux, mac 等等。

示例代码
```python
# This is a sample Python script.
import time

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, 我的 LG 基础包代码 print_hi 函数 {name}')  # Press Ctrl+F8 to toggle the breakpoint.

def return_time_helloworld() -> str:
    '''
    定义函数, 用于生成与当前时间相关的字符串, 如返回: '2026-02-21 20:16:16 hello world.'
    :return:
    '''
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + ' hello world.'

if __name__ == '__main__':
    print_hi('lgd')
    s = return_time_helloworld()
    print(s)
```

响应结果
![img.png](dist/img.png)


# 更新日志

- 0.0.1: 初始化代码包
  - 提供 `return_time_helloworld()` 函数可供调用

# 代码包更新步骤

1. 修改 `setup.py` 文件
2. 执行测试命令: `python setup.py deploy`
3. 执行打包命令: `python3 setup.py sdist`
4. 执行上传命令, 使用 `twine` 工具: `twine upload dist/*`