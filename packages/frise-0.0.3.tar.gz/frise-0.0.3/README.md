# Frise Chronologique

Historical timeline.

Optionally, requires the `pyfiglet` module for pretty tiltles.

## Installation:

```bash
$ python -m pip install frise
```

## Examples

Look at the [examples/](examples/) subfolder for more examples, notably [asimov.py](examples/asimov.py) which shows colors usage.

```bash
$ uv run examples/alien.py
 _______        _____ _______ __   _
 |_____| |        |   |______ | \  |
 |     | |_____ __|__ |______ |  \_|

      2089 • Prometheus
           |
      2104 • Alien: Covenant
      2120 • Alien: Earth
      2122 • Alien
           |
      2142 • Alien: Romulus
           |
           |
      2179 • Aliens
           • Alien³
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
           |
      2381 • Alien: Resurrection
```
