"""Utilities for cookbook examples (data path resolution, helpers)."""
