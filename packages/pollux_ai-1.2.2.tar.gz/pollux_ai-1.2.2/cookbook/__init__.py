"""Pollux Cookbook

Collection of practical examples and recipes for using the pollux library.
"""
