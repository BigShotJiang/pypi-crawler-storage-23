"""Brand resource for Agent Berlin SDK."""

from typing import List, Optional

from .._http import HTTPClient
from ..models.brand import BrandProfileResponse, BrandProfileUpdateResponse
from ..utils import get_project_domain


class BrandResource:
    """Resource for brand profile operations.

    Example:
        # Get brand profile
        profile = client.brand.get_profile()
        print(f"Domain Authority: {profile.domain_authority}")
        print(f"Competitors: {profile.competitors}")
        print(f"Topics: {[t.value for t in profile.topics]}")

        # Update brand profile (multiple fields at once)
        result = client.brand.update_profile(
            context="Updated business context",
            competitors=["competitor1.com", "competitor2.com"],
            personas=["Enterprise buyer", "Technical lead"],
            topics=["SEO", "Content Marketing"]
        )
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def get_profile(self) -> BrandProfileResponse:
        """Get the complete brand profile including personas and topics.

        The project domain is automatically populated.

        Returns:
            BrandProfileResponse with all brand configuration, personas, and topics.
        """
        data = self._http.post(
            "/brand/profile",
            json={"project_domain": get_project_domain()},
        )
        return BrandProfileResponse.model_validate(data)

    def update_profile(
        self,
        *,
        name: Optional[str] = None,
        context: Optional[str] = None,
        competitors: Optional[List[str]] = None,
        industries: Optional[List[str]] = None,
        business_models: Optional[List[str]] = None,
        company_size: Optional[str] = None,
        target_customer_segments: Optional[List[str]] = None,
        geographies: Optional[List[str]] = None,
        personas: Optional[List[str]] = None,
        topics: Optional[List[str]] = None,
    ) -> BrandProfileUpdateResponse:
        """Update brand profile fields.

        Only provided fields are updated. Fields set to None are ignored
        (not cleared). To clear a field, pass an empty string or empty list.

        Args:
            name: Project name
            context: Business description
            competitors: List of competitor domains
            industries: List of industries
            business_models: List of business models
            company_size: Company size (solo, early_startup, startup, smb, mid_market, enterprise)
            target_customer_segments: List of target segments
            geographies: List of geographic regions
            personas: List of persona descriptions (text)
            topics: List of topic values (text)

        Returns:
            BrandProfileUpdateResponse with success status and updated profile.

        Note:
            - Fields not provided (None) are NOT modified
            - To clear a list field, pass an empty list []
            - To clear a string field, pass an empty string ""
        """
        payload: dict = {"project_domain": get_project_domain()}

        # Only include fields that are explicitly provided (not None)
        if name is not None:
            payload["name"] = name
        if context is not None:
            payload["context"] = context
        if competitors is not None:
            payload["competitors"] = competitors
        if industries is not None:
            payload["industries"] = industries
        if business_models is not None:
            payload["business_models"] = business_models
        if company_size is not None:
            payload["company_size"] = company_size
        if target_customer_segments is not None:
            payload["target_customer_segments"] = target_customer_segments
        if geographies is not None:
            payload["geographies"] = geographies
        if personas is not None:
            payload["personas"] = personas
        if topics is not None:
            payload["topics"] = topics

        data = self._http.post("/brand/profile/update", json=payload)
        return BrandProfileUpdateResponse.model_validate(data)
