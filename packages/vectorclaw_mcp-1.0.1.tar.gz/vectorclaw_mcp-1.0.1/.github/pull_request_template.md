## Summary

Describe what changed and why.

## Changes

- 

## Testing

- [ ] `pytest -q`
- [ ] `python -m build` (if packaging/metadata changed)
- [ ] Manual verification (if robot-dependent behavior changed)

## Notes

Include any setup, migration, or follow-up information reviewers should know.
