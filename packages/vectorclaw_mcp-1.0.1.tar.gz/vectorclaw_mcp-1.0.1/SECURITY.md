# Security Policy

## Supported Versions

Security fixes are applied to the latest release on `main`.

## Reporting a Vulnerability

Please do not open public GitHub issues for security vulnerabilities.

**Report privately via GitHub Security Advisories:**

Go to [Security → Advisories](/security/advisories) and click "Report a vulnerability."

Alternatively, email: **danmartinez78@gmail.com**

Include:

- A clear description of the issue
- Impact and affected components
- Steps to reproduce or a proof of concept
- Any suggested mitigations

## Response Expectations

- Initial acknowledgment target: within 72 hours
- Status updates: at least weekly while investigating
- Coordinated disclosure after a fix is available

## Scope Notes

VectorClaw interacts with physical robots. Please include any safety implications (unexpected movement, unsafe behavior, or privacy/data exposure from sensors) in your report.
