"""Sandbox helpers for agent execution."""

from __future__ import annotations

import shutil
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def create_agent_sandbox_dir(
    base_dir: Path | None = None, prefix: str = "ansel-"
) -> Iterator[Path]:
    """
    Create a temporary agent sandbox dir.

    Caller is responsible for cleanup via the context manager.
    """
    sandbox_path = Path(tempfile.mkdtemp(prefix=prefix, dir=str(base_dir) if base_dir else None))
    try:
        yield sandbox_path
    finally:
        shutil.rmtree(sandbox_path, ignore_errors=True)


def resolve_sandbox_path(path: str, sandbox_dir: Path, /) -> Path:
    """
    Resolve a path within the agent sandbox dir.

    Accepts relative paths and validates absolute paths stay under the sandbox dir.
    """
    candidate = Path(path)
    resolved_workdir = sandbox_dir.resolve()
    if candidate.is_absolute():
        resolved_path = candidate.resolve()
    else:
        resolved_path = (resolved_workdir / candidate).resolve()
    try:
        _ = resolved_path.relative_to(resolved_workdir)
    except ValueError as exc:
        raise ValueError(f"Output file is outside sandbox dir: {path}") from exc
    return resolved_path
