"""
Agent: Forecast Target Analyst
    Extracts the most recent target data from user files for forecasting.
    Input: Series, forecast settings, FilesManifest, user files,
           empty target snapshot file
    Output: Populated target_snapshot.csv (time series)

Agent: Forecaster
    Fills in forecast values using model instructions and target data.
    Input: Target snapshot, model instructions, pre-staged forecast template
    Output: forecast_result.csv with target column populated
"""

from __future__ import annotations

from pydantic import BaseModel

from ..file_schemas import (
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TARGET_SNAPSHOT,
)
from ..models import FileAggregation
from .base import Agent

# ============================================
# FORECAST TARGET ANALYST
# ============================================


class ForecastTargetAnalystInput(BaseModel):
    """Input for the Forecast Target Analyst agent."""

    # Series context
    series_name: str
    series_aggregation: FileAggregation

    # Forecast settings
    target: str
    interval: str
    horizon: int

    # File references (sandbox-relative paths)
    files_manifest_path: str
    target_snapshot_path: str


_TARGET_ANALYST_SYSTEM_PROMPT = f"""
You are a data preparation agent. Given a series and user-provided data files,
extract the most recent target data suitable for generating a forecast.

Read the files manifest at {FILES_MANIFEST.filename} to discover available data
files. Analyze the data and extract a clean, consolidated time series for the
specified series and target variable.

Write the target data to {TARGET_SNAPSHOT.filename}. Include all available data —
do not hold out any data. The file has been created with headers already in
place — read the existing headers first, then append rows using those exact
columns. Do not modify or replace the headers.
"""

_TARGET_ANALYST_QUERY_TEMPLATE = """
Extract target data for series: {series_name} (aggregation: {series_aggregation}).
Target: {target}. Interval: {interval}. Horizon: {horizon}.
Use the files manifest at: {files_manifest_path}.
Populate the target snapshot at: {target_snapshot_path}.
"""


class ForecastTargetAnalyst(Agent[ForecastTargetAnalystInput]):
    """Agent that extracts target data from user files for forecasting."""

    system_prompt: str = _TARGET_ANALYST_SYSTEM_PROMPT
    query_template: str = _TARGET_ANALYST_QUERY_TEMPLATE


FORECAST_TARGET_ANALYST = ForecastTargetAnalyst()


# ============================================
# FORECASTER
# ============================================


class ForecasterInput(BaseModel):
    """Input for the Forecaster agent."""

    # Series context
    series_name: str
    series_aggregation: FileAggregation

    # Forecast settings
    target: str
    interval: str
    horizon: int

    # File references (sandbox-relative paths)
    target_snapshot_path: str = TARGET_SNAPSHOT.filename
    model_instructions_path: str = MODEL_INSTRUCTIONS.filename
    forecast_result_path: str


_FORECASTER_SYSTEM_PROMPT = f"""
You are a forecasting agent. Given target data and model instructions,
fill in the predicted values in the forecast result file.

Read the model instructions at {MODEL_INSTRUCTIONS.filename} for guidance on
how to produce forecasts. Read the target snapshot to understand recent data
patterns.

Edit the existing forecast result file — it contains one row per future period to
forecast, with dates already filled in. The number of rows and the interval between
dates define the forecast horizon. Do not modify the date column. Only fill in the
target column with your predicted values.
"""

_FORECASTER_QUERY_TEMPLATE = """
Generate a forecast for series: {series_name} (aggregation: {series_aggregation}).
Target: {target}. Interval: {interval}. Horizon: {horizon}.
Read the model instructions at: {model_instructions_path}.
Read the target snapshot at: {target_snapshot_path}.
Fill in the target column in the forecast result at: {forecast_result_path}.
"""


class Forecaster(Agent[ForecasterInput]):
    """Agent that fills in forecast values using model instructions and target data."""

    system_prompt: str = _FORECASTER_SYSTEM_PROMPT
    query_template: str = _FORECASTER_QUERY_TEMPLATE


FORECASTER = Forecaster()
