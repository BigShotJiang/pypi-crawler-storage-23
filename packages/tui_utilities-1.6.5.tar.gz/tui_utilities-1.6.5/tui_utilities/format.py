def decimal_format(number, decimals = None):
    if isinstance(number, float) and number.is_integer(): number = int(number)
    if decimals is not None:
        formated_number = f"{number:,.{decimals}f}"
        if "." in formated_number: formated_number = formated_number.rstrip("0").rstrip(".")
    else: formated_number = f"{number:,}"
    return formated_number.replace(",", "X").replace(".", ",").replace("X", ".")

def format_datetime(datetime):
    day = datetime.strftime("%d")
    month = datetime.strftime("%m")
    year = decimal_format(datetime.year)
    hour = datetime.strftime("%H")
    minute = datetime.strftime("%M")
    second = datetime.strftime("%S")
    return f"{day}/{month}/{year} - {hour}:{minute}:{second}"

def id_format(id):
    if "." in id: return id
    elif len(id) == 8: return f"{id[0:2]}.{id[2:5]}.{id[5:8]}"
    elif len(id) == 7: return f"{id[0:1]}.{id[1:4]}.{id[4:7]}"

def cellphone_number_format(cellphone_number):
    formated_cellphone_number = "".join(filter(str.isdigit, cellphone_number))
    return f"{formated_cellphone_number[0:4]} - {formated_cellphone_number[4:10]}"