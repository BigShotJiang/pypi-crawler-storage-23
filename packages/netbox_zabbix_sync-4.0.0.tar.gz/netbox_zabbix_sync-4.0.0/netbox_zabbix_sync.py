#!/usr/bin/env python3

from netbox_zabbix_sync.modules.cli import parse_cli

if __name__ == "__main__":
    parse_cli()
