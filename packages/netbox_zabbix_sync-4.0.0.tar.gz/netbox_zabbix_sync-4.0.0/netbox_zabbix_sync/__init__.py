"""
Makes core module sync function available at package level for easier imports.
"""

from netbox_zabbix_sync.modules.core import Sync as Sync
