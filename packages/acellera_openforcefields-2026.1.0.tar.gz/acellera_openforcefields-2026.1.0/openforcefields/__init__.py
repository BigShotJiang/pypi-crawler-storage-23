"""
OpenFF Force fields
"""

from openforcefields.openforcefields import get_forcefield_dirs_paths

from . import _version

__version__ = _version.get_versions()["version"]
