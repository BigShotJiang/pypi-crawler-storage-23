* `jc.csv`: Data taken from Table 5 in https://pubs.acs.org/doi/10.1021/jp8001614
* `ionslm_126_opc.csv` taken from $AMBERHOME/dat/leap/parm/frcmod.ionslm_126_opc in ambertools-22.0-py310h206695f
* `ionslm_126_opc3.csv` taken from $AMBERHOME/dat/leap/parm/frcmod.ionslm_126_opc3 in ambertools-22.0-py310h206695f
* `ionslm_126_fb3.csv` taken from $AMBERHOME/dat/leap/parm/frcmod.ionslm_126_fb3 in ambertools-22.0-py310h206695f
* `ionslm_126_fb4.csv` taken from $AMBERHOME/dat/leap/parm/frcmod.ionslm_126_fb4 in ambertools-22.0-py310h206695f
