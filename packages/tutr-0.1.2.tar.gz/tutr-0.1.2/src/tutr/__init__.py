"""tutr - a CLI tool."""

__version__ = "0.1.2"
