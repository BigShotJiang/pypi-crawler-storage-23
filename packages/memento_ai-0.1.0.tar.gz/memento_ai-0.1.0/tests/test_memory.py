"""Tests for memory CRUD."""

from memento_ai.memory import (
    clear_memory,
    delete_module,
    list_modules,
    read_all_memory,
    read_module,
    write_module,
)


def test_write_and_read(tmp_path):
    write_module(tmp_path, "test", "# Test\nContent here")
    content = read_module(tmp_path, "test")
    assert content == "# Test\nContent here"


def test_read_nonexistent(tmp_path):
    assert read_module(tmp_path, "nope") is None


def test_list_modules(tmp_path):
    write_module(tmp_path, "alpha", "a")
    write_module(tmp_path, "beta", "b")
    modules = list_modules(tmp_path)
    assert modules == ["alpha", "beta"]


def test_delete_module(tmp_path):
    write_module(tmp_path, "to-delete", "content")
    assert delete_module(tmp_path, "to-delete")
    assert not delete_module(tmp_path, "to-delete")
    assert read_module(tmp_path, "to-delete") is None


def test_read_all_memory(tmp_path):
    write_module(tmp_path, "one", "first")
    write_module(tmp_path, "two", "second")
    all_mem = read_all_memory(tmp_path)
    assert all_mem == {"one": "first", "two": "second"}


def test_clear_memory(tmp_path):
    write_module(tmp_path, "a", "1")
    write_module(tmp_path, "b", "2")
    count = clear_memory(tmp_path)
    assert count == 2
    assert list_modules(tmp_path) == []
