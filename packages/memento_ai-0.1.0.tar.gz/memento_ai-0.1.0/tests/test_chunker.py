"""Tests for diff chunking."""

from memento_ai.chunker import chunk_diff


def test_small_diff_no_split():
    diff = "small diff"
    chunks = chunk_diff(diff, max_size=100)
    assert len(chunks) == 1
    assert chunks[0] == diff


def test_split_by_files():
    diff = (
        "diff --git a/file1.py b/file1.py\n"
        "--- a/file1.py\n+++ b/file1.py\n@@ -1 +1 @@\n-old\n+new\n"
        "\ndiff --git a/file2.py b/file2.py\n"
        "--- a/file2.py\n+++ b/file2.py\n@@ -1 +1 @@\n-old2\n+new2\n"
    )
    chunks = chunk_diff(diff, max_size=80)
    assert len(chunks) >= 2


def test_empty_diff():
    chunks = chunk_diff("", max_size=100)
    assert len(chunks) == 1


def test_hard_split():
    diff = "x" * 500
    chunks = chunk_diff(diff, max_size=100)
    assert all(len(c) <= 100 for c in chunks)
    assert "".join(chunks) == diff
