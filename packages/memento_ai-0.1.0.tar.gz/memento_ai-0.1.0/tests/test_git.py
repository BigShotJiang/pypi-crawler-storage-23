"""Tests for git operations."""

from memento_ai.git import get_changed_files, get_commits, get_current_commit, get_diff, is_git_repo


def test_is_git_repo(temp_git_repo):
    assert is_git_repo(cwd=temp_git_repo)


def test_is_not_git_repo(tmp_path):
    assert not is_git_repo(cwd=tmp_path)


def test_get_commits_all(temp_git_repo):
    commits = get_commits(cwd=temp_git_repo)
    assert len(commits) == 3
    assert commits[0].message == "Initial commit"
    assert commits[2].message == "Add utils module"


def test_get_commits_since(temp_git_repo):
    all_commits = get_commits(cwd=temp_git_repo)
    since = all_commits[0].hash
    commits = get_commits(since=since, cwd=temp_git_repo)
    assert len(commits) == 2
    assert commits[0].message == "Add bye function"


def test_get_diff(temp_git_repo):
    commits = get_commits(cwd=temp_git_repo)
    diff = get_diff(commits[1].hash, cwd=temp_git_repo)
    assert "hello world" in diff
    assert "bye" in diff


def test_get_changed_files(temp_git_repo):
    commits = get_commits(cwd=temp_git_repo)
    files = get_changed_files(commits[2].hash, cwd=temp_git_repo)
    assert "utils.py" in files


def test_get_current_commit(temp_git_repo):
    current = get_current_commit(cwd=temp_git_repo)
    assert current is not None
    assert len(current) == 40
