"""Shared fixtures for memento tests."""

from __future__ import annotations

import os
import subprocess

import pytest

from memento_ai.providers.base import LLMProvider, LLMResponse


class MockProvider(LLMProvider):
    """Mock LLM provider for testing."""

    def __init__(self, responses: list[str] | None = None):
        self._responses = responses or []
        self._call_index = 0
        self.calls: list[dict] = []

    def name(self) -> str:
        return "mock"

    def complete(self, system: str, user: str) -> LLMResponse:
        self.calls.append({"system": system, "user": user})
        if self._call_index < len(self._responses):
            content = self._responses[self._call_index]
            self._call_index += 1
        else:
            content = self._default_response(user)
        return LLMResponse(content=content, model="mock", input_tokens=10, output_tokens=20)

    def _default_response(self, user: str) -> str:
        if "Analyze this git commit" in user:
            return (
                "summary: Updated code\n"
                "modules_affected:\n"
                "  - core\n"
                "key_changes:\n"
                "  - Modified main logic\n"
                "patterns_noticed:\n"
                "  - Standard pattern"
            )
        if "decide which memory modules" in user:
            return (
                "updates:\n"
                "  - module: core\n"
                "    action: update\n"
                "    reason: Core logic changed"
            )
        if "updating a project memory module" in user:
            return "# Core\n\n- Main logic updated\n- Standard patterns used"
        if "SUMMARY.md" in user:
            return "# Project Summary\n\nA software project with core logic."
        if "Answer the question" in user:
            return "Based on the memory, this project has core logic modules."
        return "OK"


@pytest.fixture
def mock_provider():
    return MockProvider()


@pytest.fixture
def temp_git_repo(tmp_path):
    """Create a temporary git repo with a few commits."""
    repo = tmp_path / "repo"
    repo.mkdir()

    env = {
        **os.environ,
        "GIT_AUTHOR_NAME": "Test",
        "GIT_AUTHOR_EMAIL": "test@test.com",
        "GIT_COMMITTER_NAME": "Test",
        "GIT_COMMITTER_EMAIL": "test@test.com",
    }

    def _run(args):
        subprocess.run(args, cwd=repo, capture_output=True, env=env)

    _run(["git", "init"])

    # Commit 1
    (repo / "main.py").write_text("def hello():\n    return 'hello'\n")
    _run(["git", "add", "."])
    _run(["git", "commit", "-m", "Initial commit"])

    # Commit 2
    (repo / "main.py").write_text(
        "def hello():\n    return 'hello world'\n\n"
        "def bye():\n    return 'bye'\n"
    )
    _run(["git", "add", "."])
    _run(["git", "commit", "-m", "Add bye function"])

    # Commit 3
    (repo / "utils.py").write_text("def helper():\n    pass\n")
    _run(["git", "add", "."])
    _run(["git", "commit", "-m", "Add utils module"])

    return repo


@pytest.fixture
def memento_dir(temp_git_repo):
    """Create a .memento dir inside the temp repo."""
    md = temp_git_repo / ".memento"
    md.mkdir()
    (md / "memory").mkdir()
    return md
