"""Tests for config loading."""

from memento_ai.config import find_memento_dir, load_config


def test_load_defaults(tmp_path):
    config = load_config(memento_dir=tmp_path)
    assert config["llm"]["provider"] == "claude-cli"
    assert config["processing"]["chunk_size"] == 4000


def test_load_from_file(tmp_path):
    config_content = b'[llm]\nprovider = "openai"\nmodel = "gpt-4o"\n'
    (tmp_path / "config.toml").write_bytes(config_content)
    config = load_config(memento_dir=tmp_path)
    assert config["llm"]["provider"] == "openai"
    assert config["llm"]["model"] == "gpt-4o"
    # Defaults preserved for unset keys
    assert config["processing"]["chunk_size"] == 4000


def test_find_memento_dir(memento_dir):
    repo = memento_dir.parent
    found = find_memento_dir(start=repo)
    assert found == memento_dir


def test_find_memento_dir_not_found(tmp_path):
    found = find_memento_dir(start=tmp_path)
    assert found is None
