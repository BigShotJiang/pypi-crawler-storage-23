"""Tests for provider factory."""

import pytest

from memento_ai.providers import get_provider
from memento_ai.providers.anthropic import AnthropicProvider
from memento_ai.providers.claude_cli import ClaudeCLIProvider
from memento_ai.providers.openai_compat import OpenAICompatProvider


def test_get_openai_provider():
    config = {"llm": {"provider": "openai", "model": "gpt-4o-mini"}}
    provider = get_provider(config, api_key="test-key")
    assert isinstance(provider, OpenAICompatProvider)


def test_get_anthropic_provider():
    config = {"llm": {"provider": "anthropic"}}
    provider = get_provider(config, api_key="test-key")
    assert isinstance(provider, AnthropicProvider)


def test_anthropic_requires_key():
    config = {"llm": {"provider": "anthropic"}}
    with pytest.raises(ValueError, match="requires"):
        get_provider(config, api_key=None)


def test_get_claude_cli_provider():
    config = {"llm": {"provider": "claude-cli"}}
    provider = get_provider(config)
    assert isinstance(provider, ClaudeCLIProvider)


def test_unknown_provider():
    config = {"llm": {"provider": "unknown"}}
    with pytest.raises(ValueError, match="Unknown provider"):
        get_provider(config)


def test_default_provider():
    config = {}
    provider = get_provider(config)
    assert isinstance(provider, ClaudeCLIProvider)
