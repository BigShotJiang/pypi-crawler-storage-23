"""Tests for CLI commands."""

import os
import subprocess

from click.testing import CliRunner

from memento_ai.cli import cli


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_init(tmp_path):
    """Test memento init in a fresh git repo."""
    env = {**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
           "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"}
    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, env=env)
    # Need at least one commit for git to work properly
    (tmp_path / "README.md").write_text("# Test")
    subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True, env=env)
    subprocess.run(["git", "commit", "-m", "init"], cwd=tmp_path, capture_output=True, env=env)

    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        os.chdir(tmp_path)
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0
        assert (tmp_path / ".memento").is_dir()
        assert (tmp_path / ".memento" / "config.toml").exists()
        assert (tmp_path / ".memento" / "memory").is_dir()


def test_init_not_git(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    result = runner.invoke(cli, ["init"])
    assert result.exit_code == 1


def test_status(memento_dir):
    runner = CliRunner()
    os.chdir(memento_dir.parent)
    result = runner.invoke(cli, ["status"])
    assert result.exit_code == 0
    assert "memento status" in result.output


def test_forget(memento_dir):
    from memento_ai.memory import write_module
    memory_dir = memento_dir / "memory"
    write_module(memory_dir, "test", "content")

    runner = CliRunner()
    os.chdir(memento_dir.parent)
    result = runner.invoke(cli, ["forget", "--yes"])
    assert result.exit_code == 0
    assert "Cleared" in result.output
