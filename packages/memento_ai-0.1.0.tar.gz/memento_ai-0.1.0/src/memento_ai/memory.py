"""CRUD operations for memory files."""

from __future__ import annotations

from pathlib import Path


def get_memory_dir(memento_dir: Path, config: dict) -> Path:
    """Get the memory directory path."""
    subdir = config.get("memory", {}).get("dir", "memory")
    memory_dir = memento_dir / subdir
    memory_dir.mkdir(parents=True, exist_ok=True)
    return memory_dir


def list_modules(memory_dir: Path) -> list[str]:
    """List all memory module names (without .md extension)."""
    if not memory_dir.exists():
        return []
    return sorted(p.stem for p in memory_dir.glob("*.md"))


def read_module(memory_dir: Path, name: str) -> str | None:
    """Read content of a memory module."""
    path = memory_dir / f"{name}.md"
    if not path.exists():
        return None
    return path.read_text()


def write_module(memory_dir: Path, name: str, content: str) -> None:
    """Write content to a memory module."""
    memory_dir.mkdir(parents=True, exist_ok=True)
    path = memory_dir / f"{name}.md"
    path.write_text(content)


def delete_module(memory_dir: Path, name: str) -> bool:
    """Delete a memory module. Returns True if it existed."""
    path = memory_dir / f"{name}.md"
    if path.exists():
        path.unlink()
        return True
    return False


def read_all_memory(memory_dir: Path) -> dict[str, str]:
    """Read all memory modules into a dict."""
    result = {}
    for name in list_modules(memory_dir):
        content = read_module(memory_dir, name)
        if content is not None:
            result[name] = content
    return result


def clear_memory(memory_dir: Path) -> int:
    """Delete all memory files. Returns count of deleted files."""
    count = 0
    if memory_dir.exists():
        for path in memory_dir.glob("*.md"):
            path.unlink()
            count += 1
    return count
