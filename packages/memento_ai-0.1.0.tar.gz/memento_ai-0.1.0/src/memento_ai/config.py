"""Configuration loading and defaults."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

DEFAULT_CONFIG: dict[str, Any] = {
    "llm": {
        "provider": "claude-cli",
        "model": None,
        "base_url": None,
        "temperature": 0.3,
        "max_tokens": 2048,
    },
    "processing": {
        "chunk_size": 4000,
        "summary_every": 10,
        "ignore_patterns": [
            "*.lock",
            "package-lock.json",
            "yarn.lock",
            "pnpm-lock.yaml",
            "poetry.lock",
            "Pipfile.lock",
            "dist/*",
            "build/*",
            "node_modules/*",
            ".git/*",
            "__pycache__/*",
            "*.pyc",
            "*.min.js",
            "*.min.css",
            "*.map",
            "*.wasm",
            "*.png",
            "*.jpg",
            "*.jpeg",
            "*.gif",
            "*.ico",
            "*.svg",
            "*.woff",
            "*.woff2",
            "*.ttf",
            "*.eot",
        ],
    },
    "memory": {
        "dir": "memory",
        "max_module_size": 5000,
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def find_memento_dir(start: Path | None = None) -> Path | None:
    """Walk up from start to find .memento/ directory."""
    current = start or Path.cwd()
    for parent in [current, *current.parents]:
        candidate = parent / ".memento"
        if candidate.is_dir():
            return candidate
    return None


def load_config(memento_dir: Path | None = None) -> dict[str, Any]:
    """Load config from .memento/config.toml, merged with defaults."""
    if memento_dir is None:
        memento_dir = find_memento_dir()
    if memento_dir is None:
        return DEFAULT_CONFIG.copy()

    config_path = memento_dir / "config.toml"
    if not config_path.exists():
        return DEFAULT_CONFIG.copy()

    with open(config_path, "rb") as f:
        user_config = tomllib.load(f)

    return _deep_merge(DEFAULT_CONFIG, user_config)


def get_api_key(config: dict[str, Any]) -> str | None:
    """Resolve API key from env vars."""
    provider = config.get("llm", {}).get("provider", "")
    key = os.environ.get("MEMENTO_API_KEY")
    if key:
        return key
    if provider == "openai":
        return os.environ.get("OPENAI_API_KEY")
    if provider == "anthropic":
        return os.environ.get("ANTHROPIC_API_KEY")
    return None


def get_project_root(memento_dir: Path) -> Path:
    """Get the project root (parent of .memento/)."""
    return memento_dir.parent
