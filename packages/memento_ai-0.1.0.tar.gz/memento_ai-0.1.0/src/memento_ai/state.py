"""State management — tracks last processed commit."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _default_state() -> dict[str, Any]:
    return {
        "last_commit": None,
        "commits_processed": 0,
        "last_run": None,
        "version": "0.1.0",
    }


def load_state(memento_dir: Path) -> dict[str, Any]:
    """Load state from .memento/state.json."""
    state_path = memento_dir / "state.json"
    if not state_path.exists():
        return _default_state()
    with open(state_path) as f:
        return json.load(f)


def save_state(memento_dir: Path, state: dict[str, Any]) -> None:
    """Save state to .memento/state.json."""
    state["last_run"] = datetime.now(timezone.utc).isoformat()
    state_path = memento_dir / "state.json"
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)
