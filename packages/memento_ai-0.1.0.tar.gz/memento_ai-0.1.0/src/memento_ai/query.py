"""Logic for 'memento ask' — query project memory."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .memory import get_memory_dir, read_all_memory
from .prompts import ANSWER_QUESTION
from .providers import LLMProvider


def ask(
    question: str,
    provider: LLMProvider,
    memento_dir: Path,
    config: dict[str, Any],
) -> str:
    """Ask a question about the project using its memory."""
    memory_dir = get_memory_dir(memento_dir, config)
    all_memory = read_all_memory(memory_dir)

    if not all_memory:
        return "No memory found. Run `memento process` first to build project memory."

    memory_text = ""
    for name, content in all_memory.items():
        memory_text += f"\n## {name}\n{content}\n"

    prompt = ANSWER_QUESTION.replace("{memory}", memory_text)
    prompt = prompt.replace("{question}", question)

    response = provider.complete("You are a helpful project assistant.", prompt)
    return response.content
