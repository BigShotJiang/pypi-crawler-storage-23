"""Prompt templates for LLM calls."""

from __future__ import annotations

ANALYZE_DIFF = """You are a code analyst. Analyze this git commit diff and extract structured information.

Commit: {commit_hash} by {author}
Message: {message}
Date: {date}

Respond in YAML format ONLY (no markdown fences):
summary: <one-line summary of what changed>
modules_affected:
  - <module_name>
key_changes:
  - <change description>
patterns_noticed:
  - <any architectural patterns, conventions, or notable decisions>

Diff:
{diff}"""

ROUTE_MEMORY = """You manage a project's living memory. Given the analysis of a commit, decide which memory modules to update or create.

Existing modules: {existing_modules}

Commit analysis:
{analysis}

Respond in YAML format ONLY (no markdown fences):
updates:
  - module: <module_name>
    action: update|create
    reason: <why this module needs updating>

Rules:
- Module names should be lowercase, hyphenated (e.g. "api-endpoints", "auth-system", "database-schema")
- Create new modules only when changes don't fit existing ones
- SUMMARY is auto-generated, don't include it
- Keep module count manageable (prefer updating over creating)"""

UPDATE_MODULE = """You are updating a project memory module. Integrate the new changes while preserving important existing information.

Module: {module_name}

Current content:
{current_content}

New changes to integrate:
{changes}

Write the COMPLETE updated module content in markdown. Rules:
- Keep it concise and factual
- Use bullet points for lists
- Include file paths when referencing specific code
- Don't repeat information
- Structure with ## headers for sections
- Maximum ~200 lines"""

GENERATE_SUMMARY = """You maintain a project's SUMMARY.md — a high-level overview of the entire project based on its memory modules.

Memory modules:
{all_memory}

Write a concise SUMMARY.md that covers:
- What the project does (1-2 sentences)
- Key components/modules
- Tech stack and architecture
- Notable patterns and conventions
- Recent significant changes

Keep it under 100 lines. Use markdown headers and bullet points."""

ANSWER_QUESTION = """You are a project assistant with access to the project's memory. Answer the question based ONLY on the provided memory.

Project memory:
{memory}

Question: {question}

If the memory doesn't contain enough information to answer, say so. Be concise and specific."""
