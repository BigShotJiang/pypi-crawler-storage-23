"""Split large diffs into manageable chunks."""

from __future__ import annotations


def chunk_diff(diff: str, max_size: int = 4000) -> list[str]:
    """Split a diff into chunks, respecting file boundaries.

    Tries to split at file boundaries (diff --git lines).
    Falls back to splitting at hunk boundaries (@@).
    Last resort: hard split at max_size.
    """
    if len(diff) <= max_size:
        return [diff]

    # Split by file boundaries
    files = _split_by_files(diff)
    chunks: list[str] = []
    current = ""

    for file_diff in files:
        if len(file_diff) > max_size:
            # File diff itself is too large, split by hunks
            if current:
                chunks.append(current)
                current = ""
            chunks.extend(_split_large_file(file_diff, max_size))
        elif len(current) + len(file_diff) > max_size:
            if current:
                chunks.append(current)
            current = file_diff
        else:
            current += file_diff

    if current:
        chunks.append(current)

    return chunks


def _split_by_files(diff: str) -> list[str]:
    """Split diff into per-file sections."""
    parts = diff.split("\ndiff --git ")
    result = []
    for i, part in enumerate(parts):
        if i == 0:
            if part.strip():
                result.append(part)
        else:
            result.append("diff --git " + part)
    return result


def _split_large_file(file_diff: str, max_size: int) -> list[str]:
    """Split a single file's diff by hunks, then by hard limit."""
    lines = file_diff.split("\n")
    header_lines: list[str] = []
    hunks: list[list[str]] = []
    current_hunk: list[str] = []

    for line in lines:
        if line.startswith("@@"):
            if current_hunk:
                hunks.append(current_hunk)
            current_hunk = [line]
        elif not hunks and not current_hunk:
            header_lines.append(line)
        else:
            current_hunk.append(line)

    if current_hunk:
        hunks.append(current_hunk)

    header = "\n".join(header_lines)
    chunks: list[str] = []
    current = header

    for hunk in hunks:
        hunk_text = "\n".join(hunk)
        if len(current) + len(hunk_text) + 1 > max_size:
            if current.strip():
                chunks.append(current)
            current = header + "\n" + hunk_text
        else:
            current += "\n" + hunk_text

    if current.strip():
        chunks.append(current)

    # Hard split any remaining oversized chunks
    final: list[str] = []
    for chunk in chunks:
        if len(chunk) <= max_size:
            final.append(chunk)
        else:
            for i in range(0, len(chunk), max_size):
                final.append(chunk[i : i + max_size])

    return final
