# Changelog

## [0.1.0] - 2026-02-28

### Added
- Initial release
- CLI with 6 commands: init, process, ask, status, forget
- Multi-provider LLM support: OpenAI-compatible, Anthropic, Claude CLI, local (llama-cpp-python)
- Incremental commit processing with chunking for large diffs
- Markdown memory files in `.memento/memory/`
- Git post-commit hook integration
- Offline-first: works with Ollama or embedded local models
