# -*- coding: utf-8 -*-
"""
Memory backend protocol and GRKMemory adapter for AtendentePro.

Provides long-context memory: search before run, inject context, save after run.
Install with: pip install atendentepro[memory]
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class MemoryBackend(Protocol):
    """
    Protocol for memory backends used by run_with_memory.

    Implementations must provide async search (return formatted string for LLM)
    and async save_conversation.
    """

    async def search_async(
        self,
        query: str,
        *,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        method: str = "graph",
        limit: int = 5,
        threshold: float = 0.3,
    ) -> str:
        """
        Search for relevant memories and return a single string for prompt injection.

        Returns:
            Formatted context string (e.g. TOON or plain text). Empty string if no results.
        """
        ...

    async def save_conversation_async(
        self,
        messages: List[Dict[str, Any]],
        *,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> None:
        """Persist the conversation turn for future retrieval."""
        ...


def _format_grk_results(results: List[Dict[str, Any]]) -> str:
    """
    Convert GRKMemory search results to a single string for LLM context.

    GRK search returns list of dicts with 'memoria' and 'similaridade'.
    Each 'memoria' may have 'summary', 'tags', 'entities', etc.
    """
    if not results:
        return ""
    parts: List[str] = []
    for item in results:
        memoria = item.get("memoria") if isinstance(item, dict) else None
        if not isinstance(memoria, dict):
            continue
        summary = memoria.get("summary") or memoria.get("content") or ""
        if isinstance(summary, str) and summary.strip():
            parts.append(summary.strip())
    return "\n\n".join(parts) if parts else ""


class GRKMemoryBackend:
    """
    Memory backend that wraps GRKMemory or AuthenticatedGRK.

    Uses search_async to retrieve relevant memories and format_memory_context
    (or internal formatting) to produce a string for prompt injection.
    Save is delegated to save_conversation_async.

    The grk_instance can be either:
    - GRKMemory(config=...)
    - AuthenticatedGRK(GRKMemory(), api_key=...)
    """

    def __init__(self, grk_instance: Any) -> None:
        """
        Initialize the backend with an already-configured GRKMemory or AuthenticatedGRK.

        Args:
            grk_instance: GRKMemory or AuthenticatedGRK instance (must have
                search_async and save_conversation_async; for formatting we use
                the underlying GRKMemory if wrapped).
        """
        self._grk = grk_instance
        # AuthenticatedGRK wraps .grkmemory; use it for format_memory_context when available
        self._grk_core = getattr(grk_instance, "grkmemory", grk_instance)

    async def search_async(
        self,
        query: str,
        *,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        method: str = "graph",
        limit: int = 5,
        threshold: float = 0.3,
    ) -> str:
        """Search GRKMemory and return formatted context string."""
        try:
            results = await self._grk.search_async(
                query,
                method=method,
                limit=limit,
                user_id=user_id,
                session_id=session_id,
            )
        except Exception as exc:
            logger.warning("GRKMemory search_async failed: %s", exc)
            return ""

        if not results:
            return ""

        # Prefer format_memory_context when available (uses repository.format_background)
        format_fn = getattr(self._grk_core, "format_memory_context", None)
        if callable(format_fn):
            try:
                return format_fn(results) or ""
            except Exception as exc:
                logger.warning("format_memory_context failed, using fallback: %s", exc)

        return _format_grk_results(results)

    async def save_conversation_async(
        self,
        messages: List[Dict[str, Any]],
        *,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> None:
        """Persist the conversation turn via GRKMemory."""
        try:
            await self._grk.save_conversation_async(
                messages,
                user_id=user_id,
                session_id=session_id,
            )
        except Exception as exc:
            logger.warning("GRKMemory save_conversation_async failed: %s", exc)


def create_grk_backend(
    api_key: Optional[str] = None,
    config: Optional[Any] = None,
    use_auth: bool = True,
) -> "GRKMemoryBackend":
    """
    Create a GRKMemoryBackend from API key and optional config.

    Requires: pip install atendentepro[memory]

    Args:
        api_key: GRKMemory API key (or from env GRKMEMORY_API_KEY if not set).
            If use_auth is True and api_key is provided, uses AuthenticatedGRK.
        config: Optional grkmemory.MemoryConfig or dict for GRKMemory(config).
        use_auth: If True and api_key is set, wrap with AuthenticatedGRK.

    Returns:
        GRKMemoryBackend instance.
    """
    import os
    from grkmemory import GRKMemory, GRKAuth, AuthenticatedGRK
    from grkmemory.core.config import MemoryConfig as GRKMemoryConfig

    grk_config = None
    if config is not None:
        if isinstance(config, dict):
            fields = getattr(GRKMemoryConfig, "__dataclass_fields__", {})
            grk_config = GRKMemoryConfig(**{k: v for k, v in config.items() if k in fields})
        else:
            grk_config = config

    grk = GRKMemory(config=grk_config)

    key = api_key or os.environ.get("GRKMEMORY_API_KEY")
    if use_auth and key:
        secure = AuthenticatedGRK(grk, key)
        return GRKMemoryBackend(secure)

    return GRKMemoryBackend(grk)
