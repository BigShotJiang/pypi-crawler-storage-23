# -*- coding: utf-8 -*-
"""
AtendentePro - Sistema de Licenciamento

Este módulo gerencia a validação de tokens de acesso para uso da biblioteca.

Uso:
    from atendentepro import activate
    
    # Ativar com token
    activate("seu-token-de-acesso")
    
    # Agora pode usar a biblioteca normalmente
    from atendentepro import create_standard_network
"""

import os
import hashlib
import hmac
import time
import json
import threading
import warnings
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from pathlib import Path

# Chave secreta carregada obrigatoriamente de variável de ambiente.
# A chave NÃO pode ser hardcoded no código-fonte distribuído.
def _get_secret_key() -> str:
    """
    Retorna a chave HMAC para assinatura de tokens.

    Lê de ATENDENTEPRO_LICENSE_SECRET (obrigatório para operadores).
    Levanta RuntimeError se não configurada, evitando operação com segredo vazio.
    """
    key = os.environ.get("ATENDENTEPRO_LICENSE_SECRET")
    if not key or not key.strip():
        raise RuntimeError(
            "ATENDENTEPRO_LICENSE_SECRET nao configurada. "
            "Esta variavel de ambiente e obrigatoria para operadores do framework. "
            "Defina-a no ambiente antes de usar funcoes de licenciamento."
        )
    return key.strip()


# Lock para acesso thread-safe ao estado global de licença.
_license_lock = threading.Lock()

# Estado global de ativação
_license_state: Dict[str, Any] = {
    "activated": False,
    "token": None,
    "expiration": None,
    "features": [],
    "organization": None,
}


@dataclass
class LicenseInfo:
    """Informações da licença ativa."""
    valid: bool
    organization: Optional[str] = None
    expiration: Optional[str] = None
    features: Optional[List[Any]] = None
    message: str = ""

    def __post_init__(self) -> None:
        if self.features is None:
            self.features = []


class LicenseError(Exception):
    """Erro de licenciamento."""
    pass


class LicenseNotActivatedError(LicenseError):
    """Biblioteca não foi ativada com um token válido."""

    def __init__(self) -> None:
        super().__init__(
            "\n\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║          ATENDENTEPRO - LICENÇA NÃO ATIVADA                  ║\n"
            "╠══════════════════════════════════════════════════════════════╣\n"
            "║                                                              ║\n"
            "║  A biblioteca AtendentePro requer ativação para uso.        ║\n"
            "║                                                              ║\n"
            "║  Para ativar, use:                                          ║\n"
            "║                                                              ║\n"
            "║    from atendentepro import activate                        ║\n"
            "║    activate('seu-token-de-acesso')                          ║\n"
            "║                                                              ║\n"
            "║  Ou defina a variável de ambiente:                          ║\n"
            "║                                                              ║\n"
            "║    export ATENDENTEPRO_LICENSE_KEY='seu-token'              ║\n"
            "║                                                              ║\n"
            "║  Para obter um token, entre em contato:                     ║\n"
            "║  📧 contato@monkai.com.br                                    ║\n"
            "║                                                              ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        )


class LicenseExpiredError(LicenseError):
    """Token de licença expirado."""

    def __init__(self, expiration: str) -> None:
        super().__init__(
            f"\n\n"
            f"╔══════════════════════════════════════════════════════════════╗\n"
            f"║          ATENDENTEPRO - LICENÇA EXPIRADA                    ║\n"
            f"╠══════════════════════════════════════════════════════════════╣\n"
            f"║                                                              ║\n"
            f"║  Sua licença expirou em: {expiration:<36}║\n"
            f"║                                                              ║\n"
            f"║  Para renovar, entre em contato:                            ║\n"
            f"║  📧 contato@monkai.com.br                                    ║\n"
            f"║                                                              ║\n"
            f"╚══════════════════════════════════════════════════════════════╝\n"
        )


class InvalidTokenError(LicenseError):
    """Token inválido."""

    def __init__(self) -> None:
        super().__init__(
            "\n\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║          ATENDENTEPRO - TOKEN INVÁLIDO                       ║\n"
            "╠══════════════════════════════════════════════════════════════╣\n"
            "║                                                              ║\n"
            "║  O token fornecido não é válido.                            ║\n"
            "║                                                              ║\n"
            "║  Verifique se o token está correto ou entre em contato:     ║\n"
            "║  📧 contato@monkai.com.br                                    ║\n"
            "║                                                              ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        )


def _generate_token(
    organization: str,
    expiration_timestamp: Optional[int] = None,
    features: Optional[List[Any]] = None,
    secret_key: Optional[str] = None,
) -> str:
    """
    Gera um token de licença.
    
    USO INTERNO - Para gerar tokens para clientes.
    
    Args:
        organization: Nome da organização
        expiration_timestamp: Unix timestamp de expiração (None = sem expiração)
        features: Lista de features habilitadas
        secret_key: Chave secreta para assinatura
        
    Returns:
        Token codificado em base64
    """
    import base64
    
    if secret_key is None:
        secret_key = _get_secret_key()
    
    if features is None:
        features = ["full"]
    
    # Payload do token
    payload = {
        "org": organization,
        "exp": expiration_timestamp,
        "feat": features,
        "v": 1,  # versão do token
    }
    
    # Serializar payload
    payload_json = json.dumps(payload, separators=(",", ":"))
    payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).decode()
    
    # Gerar assinatura
    signature = hmac.new(
        secret_key.encode(),
        payload_b64.encode(),
        hashlib.sha256
    ).hexdigest()[:16]
    
    # Token final: payload.signature
    token = f"ATP_{payload_b64}.{signature}"
    
    return token


def _validate_token_local(token: str, secret_key: Optional[str] = None) -> LicenseInfo:
    """
    Valida um token localmente via HMAC-SHA256.
    
    Args:
        token: Token de licença
        secret_key: Chave secreta para validação
        
    Returns:
        LicenseInfo com informações da validação
    """
    import base64
    
    if secret_key is None:
        secret_key = _get_secret_key()
    
    try:
        # Verificar formato
        if not token.startswith("ATP_"):
            return LicenseInfo(valid=False, message="Formato de token inválido")
        
        token_body = token[4:]  # Remover "ATP_"
        
        if "." not in token_body:
            return LicenseInfo(valid=False, message="Token malformado")
        
        payload_b64, signature = token_body.rsplit(".", 1)
        
        # Verificar assinatura
        expected_signature = hmac.new(
            secret_key.encode(),
            payload_b64.encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        
        if not hmac.compare_digest(signature, expected_signature):
            return LicenseInfo(valid=False, message="Assinatura inválida")
        
        # Decodificar payload
        try:
            payload_json = base64.urlsafe_b64decode(payload_b64).decode()
            payload = json.loads(payload_json)
        except Exception:
            return LicenseInfo(valid=False, message="Payload inválido")
        
        # Verificar expiração
        expiration = payload.get("exp")
        expiration_str = None
        
        if expiration is not None:
            expiration_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(expiration))
            if time.time() > expiration:
                return LicenseInfo(
                    valid=False,
                    expiration=expiration_str,
                    message="Token expirado"
                )
        
        # Token válido
        return LicenseInfo(
            valid=True,
            organization=payload.get("org", "Unknown"),
            expiration=expiration_str,
            features=payload.get("feat", ["full"]),
            message="Token válido"
        )
        
    except Exception as e:
        return LicenseInfo(valid=False, message=f"Erro na validação: {str(e)}")


def _is_production_mode() -> bool:
    """Return True if ATENDENTEPRO_PRODUCTION is set (1, true, yes)."""
    v = (os.environ.get("ATENDENTEPRO_PRODUCTION") or "").strip().lower()
    return v in ("1", "true", "yes")


def _validate_token_online(token: str, api_url: Optional[str] = None) -> LicenseInfo:
    """
    Valida um token online através de API de revogação em tempo real.

    Se ATENDENTEPRO_VALIDATION_URL (ou api_url) estiver configurada, faz uma
    requisição POST ao endpoint de validação. Em caso de falha de rede ou ausência
    de URL, emite RuntimeWarning e faz fallback para validação local.

    Args:
        token: Token de licença
        api_url: URL do endpoint de validação (sobrepõe a variável de ambiente)

    Returns:
        LicenseInfo com informações da validação
    """
    import httpx

    endpoint = api_url or os.environ.get("ATENDENTEPRO_VALIDATION_URL")

    if not endpoint:
        warnings.warn(
            "ATENDENTEPRO_VALIDATION_URL nao configurada. "
            "Usando validacao local. Para suporte a revogacao em tempo real, "
            "configure a URL do endpoint de validacao.",
            RuntimeWarning,
            stacklevel=2,
        )
        return _validate_token_local(token)

    try:
        resp = httpx.post(
            endpoint,
            json={"token": token},
            timeout=5.0,
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()
        data = resp.json()
        return LicenseInfo(
            valid=bool(data.get("valid", False)),
            organization=data.get("organization"),
            expiration=data.get("expiration"),
            features=data.get("features", ["full"]),
            message=data.get("message", ""),
        )
    except Exception as exc:
        warnings.warn(
            f"Validacao online falhou ({exc}). Usando validacao local como fallback.",
            RuntimeWarning,
            stacklevel=2,
        )
        return _validate_token_local(token)


def activate(
    token: Optional[str] = None,
    validate_online: bool = False,
    silent: bool = False,
) -> LicenseInfo:
    """
    Ativa a biblioteca AtendentePro com um token de licença.
    
    Args:
        token: Token de licença. Se não fornecido, tenta usar
               a variável de ambiente ATENDENTEPRO_LICENSE_KEY
        validate_online: Se True, valida o token online (requer internet).
               Se ATENDENTEPRO_PRODUCTION=1, a validação online é sempre usada
               e ATENDENTEPRO_VALIDATION_URL é obrigatória.
        silent: Se True, não imprime mensagens de sucesso
        
    Returns:
        LicenseInfo com informações da licença
        
    Raises:
        InvalidTokenError: Se o token for inválido
        LicenseExpiredError: Se o token estiver expirado
        
    Exemplo:
        >>> from atendentepro import activate
        >>> activate("ATP_eyJvcmciOiJNaW5oYUVtcHJlc2EiLCJleHAiOm51bGwsImZlYXQiOlsiZnVsbCJdLCJ2IjoxfQ.abc123")
        ✅ AtendentePro ativado para: MinhaEmpresa
    """
    global _license_state
    
    # Tentar obter token de variável de ambiente
    if token is None:
        token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
    
    if token is None:
        raise LicenseNotActivatedError()
    
    # Produção: forçar validação online; segredo fica só no servidor de validação
    use_online = validate_online or _is_production_mode()
    if _is_production_mode():
        validation_url = os.environ.get("ATENDENTEPRO_VALIDATION_URL") or ""
        if not validation_url.strip():
            raise LicenseError(
                "Em modo producao (ATENDENTEPRO_PRODUCTION=1) e obrigatorio configurar "
                "ATENDENTEPRO_VALIDATION_URL com o endpoint de validacao. "
                "O segredo (ATENDENTEPRO_LICENSE_SECRET) deve ficar apenas no servidor de validacao."
            )
    # Validar token
    if use_online:
        license_info = _validate_token_online(token)
    else:
        license_info = _validate_token_local(token)
    
    if not license_info.valid:
        if "expirado" in license_info.message.lower():
            raise LicenseExpiredError(license_info.expiration or "Data desconhecida")
        raise InvalidTokenError()
    
    # Atualizar estado global com lock para thread-safety
    with _license_lock:
        _license_state["activated"] = True
        _license_state["token"] = token
        _license_state["expiration"] = license_info.expiration
        _license_state["features"] = license_info.features
        _license_state["organization"] = license_info.organization
    
    if not silent:
        exp_msg = f" (expira: {license_info.expiration})" if license_info.expiration else " (sem expiração)"
        print(f"✅ AtendentePro ativado para: {license_info.organization}{exp_msg}")
    
    return license_info


def deactivate() -> None:
    """Desativa a biblioteca (útil para testes)."""
    global _license_state
    with _license_lock:
        _license_state = {
            "activated": False,
            "token": None,
            "expiration": None,
            "features": [],
            "organization": None,
        }


def is_activated() -> bool:
    """Verifica se a biblioteca está ativada."""
    with _license_lock:
        return _license_state["activated"]


def get_license_info() -> LicenseInfo:
    """Retorna informações da licença atual."""
    with _license_lock:
        activated = _license_state["activated"]
        if not activated:
            return LicenseInfo(valid=False, message="Não ativado")
        return LicenseInfo(
            valid=True,
            organization=_license_state["organization"],
            expiration=_license_state["expiration"],
            features=_license_state["features"],
            message="Ativo"
        )


def require_activation() -> None:
    """
    Decorator/função para verificar se a biblioteca está ativada.

    Raises:
        LicenseNotActivatedError: Se não estiver ativada
    """
    with _license_lock:
        already_active = _license_state["activated"]

    if not already_active:
        env_token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
        if env_token:
            try:
                activate(env_token, silent=True)
            except LicenseError:
                pass

    with _license_lock:
        if not _license_state["activated"]:
            raise LicenseNotActivatedError()


def has_feature(feature: str) -> bool:
    """Verifica se uma feature específica está habilitada."""
    with _license_lock:
        if not _license_state["activated"]:
            return False
        features = _license_state.get("features", [])
    return "full" in features or feature in features


# ============================================================================
# AUTO-ATIVAÇÃO VIA VARIÁVEL DE AMBIENTE
# ============================================================================

def _try_auto_activate() -> None:
    """Tenta ativar automaticamente via variável de ambiente."""
    env_token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
    with _license_lock:
        already = _license_state["activated"]
    if env_token and not already:
        try:
            activate(env_token, silent=True)
        except LicenseError:
            pass  # Silenciosamente ignora erros de auto-ativação


# Tentar auto-ativar ao importar o módulo
_try_auto_activate()



