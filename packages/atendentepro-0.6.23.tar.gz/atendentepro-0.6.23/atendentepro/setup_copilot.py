# -*- coding: utf-8 -*-
"""Setup Copilot: escreve o guia de setup no projeto do usuário."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional, Union


def setup(path: Optional[Union[str, Path]] = None) -> str:
    """Grava o guia de setup do Copilot em um arquivo no projeto do usuário.

    Útil para quem instalou via PyPI e não tem acesso ao repositório.
    O arquivo gerado pode ser compartilhado com o Copilot para configurar
    o projeto conforme o guia.

    Args:
        path: Caminho do arquivo a ser criado. Se None, usa
            `atendentepro_setup_copilot.md` no diretório atual.

    Returns:
        Caminho absoluto do arquivo escrito (string).

    Raises:
        FileNotFoundError: Se o recurso embutido não for encontrado
            (instalação incompleta).
    """
    from importlib.resources import files as resource_files

    try:
        content = (
            resource_files("atendentepro") / "setup_copilot.md"
        ).read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(
            "Recurso setup_copilot.md não encontrado. "
            "Instale o pacote novamente: pip install atendentepro"
        ) from None

    if path is None:
        dest = Path.cwd() / "atendentepro_setup_copilot.md"
    else:
        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)

    dest.write_text(content, encoding="utf-8")
    abs_path = dest.resolve()
    print(
        f"Arquivo criado: {abs_path}. "
        "Compartilhe este arquivo com o Copilot para configurar o projeto conforme o guia."
    )
    return str(abs_path)


def main() -> None:
    """Entry point para o comando de linha atendentepro-setup."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Gera o guia de setup do Copilot no projeto."
    )
    parser.add_argument(
        "output",
        nargs="?",
        default=None,
        help="Caminho do arquivo de saída (padrão: atendentepro_setup_copilot.md no diretório atual)",
    )
    args = parser.parse_args()
    setup(path=args.output)
    sys.exit(0)
