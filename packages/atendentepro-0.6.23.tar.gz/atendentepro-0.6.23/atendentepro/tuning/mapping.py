# -*- coding: utf-8 -*-
"""
Mapping from agent_name (from feedback) to YAML config file for client setup.

Used by the tuning module to decide which YAML file to suggest changes for
when a record has feedback with agent_name.
"""

from typing import Dict, Optional

# Agent name (as in conversation_message_feedback.agent_name) -> yaml filename
AGENT_TO_YAML: Dict[str, Optional[str]] = {
    "Triage Agent": "triage_config.yaml",
    "Flow Agent": "flow_config.yaml",
    "Interview Agent": "interview_config.yaml",
    "Answer Agent": "answer_config.yaml",
    "Knowledge Agent": "knowledge_config.yaml",
    "Confirmation Agent": "confirmation_config.yaml",
    "Usage Agent": None,  # No dedicated YAML in template
    "Onboarding Agent": "onboarding_config.yaml",
    "Escalation Agent": "escalation_config.yaml",
    "Feedback Agent": "feedback_config.yaml",
}

# All customizable YAML files for client setup (for reference and applier)
CUSTOMIZABLE_YAML_FILES = [
    "triage_config.yaml",
    "flow_config.yaml",
    "interview_config.yaml",
    "answer_config.yaml",
    "knowledge_config.yaml",
    "confirmation_config.yaml",
    "onboarding_config.yaml",
    "escalation_config.yaml",
    "feedback_config.yaml",
    "guardrails_config.yaml",
    "style_config.yaml",
    "single_reply_config.yaml",
    "access_config.yaml",
]


def get_yaml_for_agent(agent_name: str) -> Optional[str]:
    """Return the YAML filename for the given agent, or None if not configurable."""
    return AGENT_TO_YAML.get(agent_name)
