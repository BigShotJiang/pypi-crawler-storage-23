# -*- coding: utf-8 -*-
"""
Single entry point: run_tuning_pipeline (fetch -> merge -> run_analysis -> optionally apply).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from atendentepro.tuning.analyzer import run_analysis as _run_analysis
from atendentepro.tuning.applier import (
    apply_suggestions as _apply_suggestions,
    write_suggestions_to_folder as _write_suggestions_to_folder,
)
from atendentepro.tuning.client import (
    fetch_feedback,
    load_trace_records,
    merge_feedback_with_records,
)
from atendentepro.tuning.suggestions import Suggestion


def run_tuning_pipeline(
    namespace: str,
    client: str,
    templates_root: Path,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    user_ids: Optional[List[str]] = None,
    tracer_token: Optional[str] = None,
    feedback_value: str = "negative",
    limit_feedback: int = 500,
    limit_records: int = 100,
    apply: bool = False,
    dry_run: bool = True,
    backup: bool = True,
    write_to_suggested_folder: bool = True,
    suggested_subdir: str = "_suggested",
) -> Dict[str, Any]:
    """
    Run full tuning pipeline: fetch feedback and records -> merge -> analyze -> optionally apply.

    Args:
        namespace: Workspace/namespace (Supabase and Trace).
        client: Client key (folder name under templates_root).
        templates_root: Root path for client YAMLs.
        start_date: Optional ISO date filter.
        end_date: Optional ISO date filter.
        user_ids: Optional list of user_id to restrict feedback.
        tracer_token: Optional MonkAI Trace token.
        feedback_value: "negative" or "positive".
        limit_feedback: Max feedback rows.
        limit_records: Max trace records.
        apply: If True, write suggestions (to suggested folder or in-place).
        dry_run: If True and apply=True and not write_to_suggested_folder, do not write files.
        backup: If True and apply=True and not write_to_suggested_folder and not dry_run, backup.
        write_to_suggested_folder: If True and apply=True, write to client/suggested_subdir.
        suggested_subdir: Subfolder name when write_to_suggested_folder=True (default "_suggested").

    Returns:
        Dict with keys: feedback_count, records_count, enriched_count, suggestions (list),
        apply_results (list of (suggestion, status) if apply=True),
        and when write_to_suggested_folder: suggested_folder, report_path, written_files.
    """
    feedback_rows = fetch_feedback(
        namespace=namespace,
        start_date=start_date,
        end_date=end_date,
        user_ids=user_ids,
        feedback_value=feedback_value,
        limit=limit_feedback,
    )
    records = load_trace_records(
        namespace=namespace,
        tracer_token=tracer_token,
        start_date=start_date,
        end_date=end_date,
        limit=limit_records,
    )
    enriched = merge_feedback_with_records(feedback_rows, records)
    suggestions: List[Suggestion] = _run_analysis(enriched, deduplicate=True)

    out: Dict[str, Any] = {
        "feedback_count": len(feedback_rows),
        "records_count": len(records),
        "enriched_count": len(enriched),
        "suggestions": suggestions,
        "apply_results": [],
    }

    if apply and suggestions:
        if write_to_suggested_folder:
            write_result = _write_suggestions_to_folder(
                client=client,
                suggestions=suggestions,
                templates_root=templates_root,
                suggested_subdir=suggested_subdir,
            )
            out["apply_results"] = write_result["per_suggestion"]
            out["suggested_folder"] = write_result["suggested_folder"]
            out["report_path"] = write_result["report_path"]
            out["written_files"] = write_result["written_files"]
        else:
            apply_results = _apply_suggestions(
                client=client,
                suggestions=suggestions,
                templates_root=templates_root,
                dry_run=dry_run,
                backup=backup,
            )
            out["apply_results"] = [(s, status) for s, status in apply_results]

    return out
