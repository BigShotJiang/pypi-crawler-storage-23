import pytest  # noqa: F401
import pytest_asyncio  # noqa: F401


from tests.fixtures.pb import ( # noqa: F401
    fully_registered_core

)