
class Schema:
    def __init__(self, name, description, fields):
        self.name = name
        self.description = description
        self.fields = fields


