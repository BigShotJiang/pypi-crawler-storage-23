# This file previously contained legacy storage management queue definitions
# (StorageManagementRequest, StorageManagementResponse, and related topics).
#
# These have been removed as collection management now uses a config-based
# approach via CollectionConfigHandler instead of request/response queues.
#
# This file is kept for potential future storage-related schema definitions.

