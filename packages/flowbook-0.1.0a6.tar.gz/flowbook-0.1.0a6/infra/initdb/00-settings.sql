-- ローカル運用の観測性を上げる最低限
ALTER DATABASE flowbook SET timezone TO 'Asia/Tokyo';
