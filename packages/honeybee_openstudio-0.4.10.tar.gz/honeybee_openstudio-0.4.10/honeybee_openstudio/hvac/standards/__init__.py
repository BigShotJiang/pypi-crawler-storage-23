"""Sub-package containing a Python version of the OpenStudio-standards prototype module.

https://github.com/NREL/openstudio-standards/tree/master/lib/openstudio-standards/prototypes/common/objects
"""
