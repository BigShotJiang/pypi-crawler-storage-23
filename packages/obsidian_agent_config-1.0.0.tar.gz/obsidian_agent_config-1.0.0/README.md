# agent-config

Auto-generated tool for ai_agent_tools

## Installation

```bash
pip install agent-config
```

## Usage

```bash
agent_config --help
agent_config --json
```

## Python API

```python
from agent_config.core import run
result = run()
```

## License

MIT
