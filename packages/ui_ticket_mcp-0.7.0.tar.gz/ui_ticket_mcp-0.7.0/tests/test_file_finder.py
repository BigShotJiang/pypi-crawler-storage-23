"""Tests for file_finder.py."""

from __future__ import annotations

from review_mcp.file_finder import (
    _to_segments,
    _to_camel,
    _to_kebab,
    find_source_file,
)


# --------------- helpers ---------------


def test_to_segments_dashes():
    assert _to_segments("user-profile") == ["user", "profile"]


def test_to_segments_underscores():
    assert _to_segments("user_profile") == ["user", "profile"]


def test_to_segments_slashes():
    assert _to_segments("user/profile") == ["user", "profile"]


def test_to_segments_mixed():
    assert _to_segments("user-profile_page/view") == ["user", "profile", "page", "view"]


def test_to_segments_empty():
    assert _to_segments("") == []


def test_to_camel():
    assert _to_camel(["user", "profile"]) == "UserProfile"


def test_to_camel_single():
    assert _to_camel(["dashboard"]) == "Dashboard"


def test_to_kebab():
    assert _to_kebab(["user", "profile"]) == "user-profile"


def test_to_kebab_single():
    assert _to_kebab(["dashboard"]) == "dashboard"


# --------------- find_source_file ---------------


def test_find_by_kebab(project_tree):
    results = find_source_file("user-profile", str(project_tree))
    filenames = [r.split("/")[-1] for r in results]
    assert "user-profile.component.ts" in filenames
    assert "user-profile.component.html" in filenames


def test_find_by_camel(project_tree):
    results = find_source_file("user-profile", str(project_tree))
    filenames = [r.split("/")[-1] for r in results]
    assert "UserProfile.ts" in filenames


def test_find_skips_node_modules(project_tree):
    results = find_source_file("user-profile", str(project_tree))
    for r in results:
        assert "node_modules" not in r


def test_find_dashboard(project_tree):
    results = find_source_file("dashboard", str(project_tree))
    assert len(results) >= 1
    assert any("dashboard.component.ts" in r for r in results)


def test_find_no_match(project_tree):
    results = find_source_file("nonexistent-page", str(project_tree))
    assert results == []


def test_find_empty_page_id(project_tree):
    results = find_source_file("", str(project_tree))
    assert results == []


def test_find_invalid_root():
    results = find_source_file("user-profile", "/nonexistent/path/xyz")
    assert results == []


def test_find_empty_root():
    results = find_source_file("user-profile", "")
    assert results == []
