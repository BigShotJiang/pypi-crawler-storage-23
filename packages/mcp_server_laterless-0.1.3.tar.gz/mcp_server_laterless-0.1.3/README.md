# Laterless MCP Server

Access your [Laterless](https://laterless.com) bookmarks knowledge base from AI tools.

## Features

| Tool | Description |
|------|-------------|
| `search_bookmarks` | Semantic search — find bookmarks by meaning |
| `list_bookmarks` | Browse recent bookmarks |
| `get_bookmark` | Read full bookmark content |
| `add_bookmark` | Save a URL as a bookmark |
| `add_brain_dump` | Record a thought or idea |
| `get_profile` | View your profile and stats |

## Setup

### 1. Get an API Key

Go to your Laterless profile → API Keys → Generate a new key.

### 2. Install

```bash
# Recommended: run directly with uvx (no install needed)
uvx mcp-server-laterless

# Or install with pip
pip install mcp-server-laterless
```

### 3. Configure Your AI Tool

#### OpenClaw

Add to `~/.config/openclaw/openclaw.json`:

```json
{
  "mcpServers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### Claude Code

```bash
claude mcp add laterless \
  -e LATERLESS_API_KEY=ltls_your_key_here \
  -- uvx mcp-server-laterless
```

#### Cursor

Add to `.cursor/mcp.json` in your project, or configure via Settings → MCP → Add new MCP Server:

```json
{
  "mcpServers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### Antigravity

Add to `mcp_servers.json` in your project root:

```json
{
  "servers": [
    {
      "name": "laterless",
      "transport": "stdio",
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "enabled": true,
      "env": {
        "LATERLESS_API_KEY": "${LATERLESS_API_KEY}"
      }
    }
  ]
}
```

Then add to your `.env`:

```
LATERLESS_API_KEY=ltls_your_key_here
```

#### Codex

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.laterless]
command = "uvx"
args = ["mcp-server-laterless"]
env = { LATERLESS_API_KEY = "ltls_your_key_here" }
```

#### Gemini CLI

Add to `~/.gemini/settings.json`:

```json
{
  "mcpServers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### Windsurf

Add to `~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### VS Code (GitHub Copilot)

Add to `.vscode/mcp.json` in your project:

```json
{
  "servers": {
    "laterless": {
      "command": "uvx",
      "args": ["mcp-server-laterless"],
      "env": {
        "LATERLESS_API_KEY": "ltls_your_key_here"
      }
    }
  }
}
```

#### Zed

Add to Zed settings JSON:

```json
{
  "context_servers": {
    "laterless": {
      "command": {
        "path": "uvx",
        "args": ["mcp-server-laterless"],
        "env": {
          "LATERLESS_API_KEY": "ltls_your_key_here"
        }
      }
    }
  }
}
```

#### Others

For any MCP-compatible client not listed above, use these settings:

| Setting | Value |
|---------|-------|
| **Command** | `uvx` |
| **Arguments** | `mcp-server-laterless` |
| **Transport** | `stdio` |
| **Environment** | `LATERLESS_API_KEY=ltls_your_key_here` |

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LATERLESS_API_KEY` | Yes | — | Your API key (`ltls_...`) |
| `LATERLESS_API_URL` | No | `https://gate.laterless.com` | API base URL (for development) |

## Development

```bash
# Install dependencies
uv sync

# Run locally
LATERLESS_API_KEY=ltls_xxx uv run mcp-server-laterless

# Test with MCP Inspector
npx @modelcontextprotocol/inspector uv run mcp-server-laterless
```

## License

MIT
