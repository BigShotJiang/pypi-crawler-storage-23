"""
Laterless MCP Server configuration.

Environment variables:
- LATERLESS_API_KEY (required): API key from your Laterless profile -> API Keys
- LATERLESS_API_URL (optional): API base URL, defaults to https://gate.laterless.com
"""

import os


def get_api_key() -> str:
    """Get API key from env. Raises ValueError if not set (handled by lifespan)."""
    key = os.environ.get("LATERLESS_API_KEY", "")
    if not key:
        raise ValueError(
            "LATERLESS_API_KEY environment variable is required. "
            "Get your API key at: https://laterless.com"
        )
    return key


def get_api_url() -> str:
    """Get API base URL from env. Defaults to https://gate.laterless.com"""
    return os.environ.get("LATERLESS_API_URL", "https://gate.laterless.com")
