import atrace  # noqa

lst = [x**2 for x in range(4)]
