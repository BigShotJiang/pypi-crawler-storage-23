import atrace  # noqa

x = 0
while x < 2:
    x = x + 1
