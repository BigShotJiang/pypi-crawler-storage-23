# type: ignore
import atrace  # noqa

x = 1

f(x)  # noqa
