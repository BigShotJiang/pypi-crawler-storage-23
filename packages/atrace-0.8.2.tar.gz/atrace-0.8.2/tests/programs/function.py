import atrace  # noqa


def double(a):
    result = a * 2
    return result


x = double(3)
