"""FastAPI application and routes."""

from payroll_engine.api.app import create_app

__all__ = ["create_app"]
