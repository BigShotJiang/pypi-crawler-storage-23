"""
Client for the Rayobrowse Daemon.

Provides helper functions for creating and managing browsers through the daemon.
"""

import logging
import os
import subprocess
import sys
import time
from typing import Optional, Dict, Any, List

import requests

logger = logging.getLogger(__name__)

# Default daemon endpoint
DEFAULT_ENDPOINT = "http://localhost:9222"


class DaemonNotRunning(Exception):
    """Raised when the daemon is not running and couldn't be started."""
    pass


class BrowserCreateError(Exception):
    """Raised when browser creation fails."""
    pass


class LicenseLimitExceeded(Exception):
    """Raised when the concurrent browser limit is exceeded."""
    def __init__(self, message: str, retry_after: int = 5):
        super().__init__(message)
        self.retry_after = retry_after


class TermsNotAccepted(Exception):
    """Raised when terms of service have not been accepted yet."""
    pass


def _get_endpoint() -> str:
    """Get the daemon endpoint from environment or default."""
    return os.environ.get("RAYOBYTE_ENDPOINT", DEFAULT_ENDPOINT)


def _is_daemon_running(endpoint: str = None) -> bool:
    """Check if the daemon is running."""
    endpoint = endpoint or _get_endpoint()
    try:
        resp = requests.get(f"{endpoint}/health", timeout=2)
        return resp.status_code == 200
    except Exception:
        return False


def _start_daemon(timeout: float = 15.0) -> bool:
    """
    Attempt to start the daemon in the background.
    
    Returns True if daemon is running after this call.
    """
    endpoint = _get_endpoint()
    
    # Already running?
    if _is_daemon_running(endpoint):
        return True
    
    logger.info("Starting Rayobrowse daemon...")
    
    # Try to start the daemon
    try:
        # Try as installed CLI first
        import shutil
        daemon_cmd = shutil.which("rayobrowse-daemon")
        
        if daemon_cmd:
            subprocess.Popen(
                [daemon_cmd, "run"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        else:
            # Fall back to module execution
            subprocess.Popen(
                [sys.executable, "-m", "rayobrowse.daemon", "run"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        
        # Wait for it to be ready
        start = time.time()
        while time.time() - start < timeout:
            if _is_daemon_running(endpoint):
                logger.info("Daemon started successfully")
                return True
            time.sleep(0.2)
        
        logger.warning("Daemon did not become ready in time")
        return False
        
    except Exception as e:
        logger.error(f"Failed to start daemon: {e}")
        return False


def ensure_daemon_running(endpoint: str = None) -> bool:
    """
    Ensure the daemon is running, starting it if necessary.
    
    Args:
        endpoint: Daemon endpoint URL (default: http://localhost:9222)
    
    Returns:
        True if daemon is running
    
    Raises:
        DaemonNotRunning: If daemon couldn't be started
    """
    endpoint = endpoint or _get_endpoint()
    
    if _is_daemon_running(endpoint):
        return True
    
    if _start_daemon():
        return True
    
    raise DaemonNotRunning(
        f"Daemon is not running at {endpoint} and could not be started. "
        f"Try running: python -m rayobrowse run"
    )


def create_browser(
    *,
    headless: bool = False,
    proxy: Optional[str] = None,
    target_os: str | List[str] = "linux",
    browser_name: str = "chrome",
    browser_version_min: Optional[int] = None,
    browser_version_max: Optional[int] = None,
    browser_language: Optional[str] = None,
    ui_language: Optional[str] = None,
    enable_cache_headers: bool = False,
    last_n_versions: Optional[int] = None,
    min_fp_required: Optional[int] = None,
    auto_expand: Optional[bool] = None,
    screen_width_min: Optional[int] = None,
    screen_height_min: Optional[int] = None,
    fingerprint_file: Optional[str] = None,
    launch_args: Optional[List[str]] = None,
    mitm: bool = False,
    api_key: Optional[str] = None,
    endpoint: Optional[str] = None,
    auto_start_daemon: bool = True,
) -> str:
    """
    Create a new browser instance and return the CDP WebSocket URL.
    
    Args:
        headless: Run browser without GUI (default: False)
        proxy: Proxy URL in format http://user:pass@host:port
        target_os: Target OS for fingerprint (linux, windows, macos, android)
            Can be a string or list of strings (one will be chosen randomly)
        browser_name: Browser type for fingerprint (default: chrome)
        browser_version_min: Minimum browser version for fingerprint
        browser_version_max: Maximum browser version for fingerprint
        browser_language: Browser language (e.g., "ko,en;q=0.9" or "zh-TW,zh;q=0.9")
            Sets navigator.language, navigator.languages, and Accept-Language header
        ui_language: UI language override (e.g., "en-US" to keep English menus)
        enable_cache_headers: Enable cache headers (default: False)
        last_n_versions: Only consider fingerprints from last N browser versions
        min_fp_required: Minimum fingerprints required from API
        auto_expand: Auto-expand version range if not enough fingerprints
        screen_width_min: Minimum screen width for fingerprint selection
        screen_height_min: Minimum screen height for fingerprint selection
        fingerprint_file: Path to static fingerprint JSON file (bypasses API)
        launch_args: Additional Chromium launch arguments
        mitm: Route traffic through mitmproxy for inspection (default: False).
            When True, mitmproxy is started server-side (inside Docker / the
            daemon process) with ``proxy`` as the upstream, the browser connects
            to the local mitmproxy instead, and the mitmproxy CA is trusted via
            SPKI pinning.  Requires a ``proxy`` to be set (mitmproxy needs an
            upstream).  The mitmweb UI is available at http://localhost:8090
            (mapped from the container port 8090).
        api_key: API key for paid plans (default: from RAYOBYTE_API_KEY env)
        endpoint: Daemon endpoint URL (default: http://localhost:9222)
        auto_start_daemon: Automatically start daemon if not running
    
    Returns:
        WebSocket URL for CDP connection (e.g., ws://localhost:9222/cdp/br_abc123)
    
    Raises:
        DaemonNotRunning: When daemon is not running and couldn't be started
        LicenseLimitExceeded: When concurrent browser limit reached
        BrowserCreateError: When browser creation fails
    
    Example:
        from rayobrowse import create_browser
        from playwright.sync_api import sync_playwright
        
        ws_url = create_browser(headless=False, proxy="http://user:pass@proxy.com:8000")
        
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(ws_url)
            page = browser.new_page()
            page.goto("https://example.com")
            browser.close()
    
    MITM example:
        # Traffic is routed through mitmproxy — inspect at http://127.0.0.1:8090
        ws_url = create_browser(
            proxy="http://user:pass@proxy.com:8000",
            target_os="android",
            mitm=True,
        )
    """
    endpoint = endpoint or _get_endpoint()
    
    # Ensure daemon is running
    if auto_start_daemon:
        ensure_daemon_running(endpoint)
    elif not _is_daemon_running(endpoint):
        raise DaemonNotRunning(f"Daemon is not running at {endpoint}")
    
    # Build request payload
    payload: Dict[str, Any] = {
        "headless": headless,
        "os": target_os,
        "browser_name": browser_name,
    }

    if mitm:
        payload["mitm"] = True
    
    if proxy:
        payload["proxy"] = proxy
    if browser_version_min is not None:
        payload["browser_version_min"] = browser_version_min
    if browser_version_max is not None:
        payload["browser_version_max"] = browser_version_max
    if browser_language:
        payload["browser_language"] = browser_language
    if ui_language:
        payload["ui_language"] = ui_language
    if enable_cache_headers:
        payload["enable_cache_headers"] = enable_cache_headers
    if last_n_versions is not None:
        payload["last_n_versions"] = last_n_versions
    if min_fp_required is not None:
        payload["min_fp_required"] = min_fp_required
    if auto_expand is not None:
        payload["auto_expand"] = auto_expand
    if screen_width_min is not None:
        payload["screen_width_min"] = screen_width_min
    if screen_height_min is not None:
        payload["screen_height_min"] = screen_height_min
    if fingerprint_file:
        payload["fingerprint_file"] = fingerprint_file
    if launch_args:
        payload["launch_args"] = launch_args
    
    # Use API key from parameter or env
    resolved_api_key = api_key or os.environ.get("RAYOBYTE_API_KEY") or os.environ.get("STEALTH_BROWSER_API_KEY")
    if resolved_api_key:
        payload["api_key"] = resolved_api_key
    
    # Create browser
    try:
        resp = requests.post(
            f"{endpoint}/browser",
            json=payload,
            timeout=60,  # Browser creation can take a while
        )
        
        data = resp.json()
        
        if not data.get("success"):
            error = data.get("error", {})
            code = error.get("code", "UNKNOWN")
            message = error.get("message", "Unknown error")
            
            if code == "CONCURRENT_LIMIT_EXCEEDED":
                retry_after = error.get("retry_after_seconds", 5)
                raise LicenseLimitExceeded(message, retry_after=retry_after)
            
            if code == "TERMS_REQUIRED":
                raise TermsNotAccepted(message)
            
            raise BrowserCreateError(f"{code}: {message}")
        
        ws_endpoint = data["data"]["ws_endpoint"]

        # The daemon reports its internal address (e.g. ws://0.0.0.0:9222/...).
        # When the client connects via a different host/port (e.g. Docker port
        # mapping), rewrite the WS URL to match the endpoint we actually used.
        from urllib.parse import urlparse
        daemon_parsed = urlparse(endpoint)
        ws_parsed = urlparse(ws_endpoint)
        if (daemon_parsed.hostname not in (ws_parsed.hostname, None)
                or daemon_parsed.port != ws_parsed.port):
            ws_endpoint = ws_endpoint.replace(
                f"{ws_parsed.hostname}:{ws_parsed.port}",
                f"{daemon_parsed.hostname}:{daemon_parsed.port}",
                1,
            )

        logger.info(f"Browser created: {ws_endpoint}")

        # Log noVNC URL if VNC viewer is enabled
        vnc_url = data["data"].get("vnc_url")
        if vnc_url:
            logger.info(f"View browser via noVNC (open any local browser to this URL): {vnc_url}")

        # Log mitmweb URL when mitm=True
        mitmweb_url = data["data"].get("mitmweb_url")
        if mitmweb_url:
            logger.info(f"Inspect traffic via mitmweb (open in any local browser): {mitmweb_url}")

        return ws_endpoint
        
    except requests.RequestException as e:
        raise BrowserCreateError(f"Failed to create browser: {e}")


def close_browser(browser_id: str, endpoint: Optional[str] = None) -> bool:
    """
    Force close a browser by ID.
    
    Args:
        browser_id: Browser ID (e.g., br_abc123)
        endpoint: Daemon endpoint URL
    
    Returns:
        True if browser was closed, False if not found
    """
    endpoint = endpoint or _get_endpoint()
    
    try:
        resp = requests.delete(f"{endpoint}/browser/{browser_id}", timeout=10)
        data = resp.json()
        return data.get("success", False)
    except Exception:
        return False


def list_browsers(endpoint: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    List all active browsers.
    
    Args:
        endpoint: Daemon endpoint URL
    
    Returns:
        List of browser info dictionaries
    """
    endpoint = endpoint or _get_endpoint()
    
    try:
        resp = requests.get(f"{endpoint}/browsers", timeout=10)
        data = resp.json()
        if data.get("success"):
            return data["data"]["browsers"]
        return []
    except Exception:
        return []


def get_daemon_status(endpoint: Optional[str] = None) -> Dict[str, Any]:
    """
    Get daemon status and health information.
    
    Args:
        endpoint: Daemon endpoint URL
    
    Returns:
        Status dictionary with health info, or error info if not running
    """
    endpoint = endpoint or _get_endpoint()
    
    try:
        resp = requests.get(f"{endpoint}/health", timeout=5)
        data = resp.json()
        if data.get("success"):
            return {
                "running": True,
                **data["data"],
            }
        return {"running": False, "error": "Unknown error"}
    except requests.RequestException as e:
        return {"running": False, "error": str(e)}
