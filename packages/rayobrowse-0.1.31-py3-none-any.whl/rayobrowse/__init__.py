"""
Rayobyte Stealth Browser SDK

Lightweight client for the Rayobrowse daemon (Docker or cloud).
Talks to the daemon over HTTP -- no local Chromium or fonts needed.

Usage:
    from rayobrowse import create_browser
    ws_url = create_browser(headless=True, proxy="http://user:pass@host:port")
"""

import logging
import os

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

from importlib.metadata import version as _get_version
try:
    __version__ = _get_version("rayobrowse")
except Exception:
    __version__ = "0.0.0"

from .client import (
    create_browser,
    close_browser,
    list_browsers,
    get_daemon_status,
    ensure_daemon_running,
    DaemonNotRunning,
    BrowserCreateError,
    LicenseLimitExceeded,
    TermsNotAccepted,
)

__all__ = [
    "create_browser",
    "close_browser",
    "list_browsers",
    "get_daemon_status",
    "ensure_daemon_running",
    "DaemonNotRunning",
    "BrowserCreateError",
    "LicenseLimitExceeded",
    "TermsNotAccepted",
    "__version__",
]


def _check_sdk_version():
    """Background check for newer SDK versions (non-blocking)."""
    try:
        import requests as _requests
        resp = _requests.get(
            "https://cdn.sb.rayobyte.com/manifest.json", timeout=5
        )
        latest = resp.json().get("latest_versions", {}).get("sdk")
        if latest and latest != __version__ and __version__ != "0.0.0":
            logger.warning(
                "A newer rayobrowse SDK is available: v%s (you have v%s). "
                "Update with: pip install --upgrade rayobrowse",
                latest,
                __version__,
            )
    except Exception:
        pass


import threading
threading.Thread(target=_check_sdk_version, daemon=True).start()
