from setuptools import setup, find_packages

setup(
name="chaitanya", # Your package name
version="0.1", # Version number
packages=find_packages(), # Automatically find packages
install_requires=[], # List dependencies if any
author="chaitanya", # Your name
author_email="chaitanyakarnati11@gmail.com",# Your email
description="This is a package for fun",
url="https://github.com/yourusername/my_package", # Your project URL
)
