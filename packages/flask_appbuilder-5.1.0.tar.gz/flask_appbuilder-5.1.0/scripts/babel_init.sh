pybabel init -i ./babel/messages.pot -d ./flask_appbuilder/translations -l $1
pybabel compile -d ./flask_appbuilder/translations

