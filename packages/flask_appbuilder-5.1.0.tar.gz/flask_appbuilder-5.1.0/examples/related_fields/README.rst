Related Fields
--------------

Simple example with two select2 related fields.

Insert test data::

    $ python testdata.py

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run

