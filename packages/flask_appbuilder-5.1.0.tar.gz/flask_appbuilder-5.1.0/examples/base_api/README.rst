Base Api example
----------------

Simple example showing how to use *BaseApi* class

Run it::

    $ flask run

For Swagger view go to: http://localhost:5000/swagger/v1
