# PyLk
A package to calculate linking properties of polymer configurations
