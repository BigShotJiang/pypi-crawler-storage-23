# pyConDev
Module for conditional decorators
