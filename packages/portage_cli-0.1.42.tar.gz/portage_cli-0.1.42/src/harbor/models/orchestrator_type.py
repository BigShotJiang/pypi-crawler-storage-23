from enum import Enum


class OrchestratorType(str, Enum):
    LOCAL = "local"
    QUEUE = "queue"
