# Task Name

A brief description of what this task evaluates and why it is difficult.

## Overview

Describe the task scenario, what the agent is expected to do, and what skills or capabilities it tests.

## Verification

Describe how the task is verified (e.g., unit tests, output matching, etc.).
