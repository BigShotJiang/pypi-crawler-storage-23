# MCP Prompts for Code Puppy
