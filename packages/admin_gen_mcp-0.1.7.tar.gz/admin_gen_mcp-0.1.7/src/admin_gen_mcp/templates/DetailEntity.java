package com.worsoft.worsoft.hr.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.worsoft.worsoft.common.core.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@TableName("contract_sign_batch_detail")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "合同批量签订从表")
public class ContractSignBatchDetailEntity extends BaseEntity<ContractSignBatchDetailEntity> {

	@TableId(type = IdType.ASSIGN_ID)
	@Schema(description = "id")
	private Long id;

	@Schema(description = "主表ID")
	private Long mainId;

	// --- 业务字段示例 ---

	@Schema(description = "员工ID")
	private Long personId;

	@Schema(description = "员工姓名")
	private String person;

	@Schema(description = "合同编号")
	private String contractCode;

	@Schema(description = "出生日期")
	private LocalDate birthDate;

	@Schema(description = "租户ID")
	private Long tenantId;

	@TableField(exist = false)
	@Schema(description = "行状态.取值范围0:正常; -1:删除;")
	private Integer rowStatus = 0;
}
