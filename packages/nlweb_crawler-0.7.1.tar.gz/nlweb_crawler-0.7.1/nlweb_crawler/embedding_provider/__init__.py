"""
Embedding providers for vector database
"""
