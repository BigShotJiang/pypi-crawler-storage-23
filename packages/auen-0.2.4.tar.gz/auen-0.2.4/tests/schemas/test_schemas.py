"""Schema derivation tests."""

from __future__ import annotations

from sqlmodel import SQLModel
from tests.conftest import Book

from auen import derive_schemas


class NoPkModel(SQLModel):
    """Model without table=True — PK detection fallback."""

    name: str


def test_derive_schemas_with_include() -> None:
    schemas = derive_schemas(Book, include={"title", "isbn", "id"})
    assert "pages" not in schemas.create.model_fields


def test_derive_schemas_with_exclude() -> None:
    schemas = derive_schemas(Book, exclude={"pages"})
    assert "pages" not in schemas.create.model_fields


def test_derive_schemas_pk_fallback() -> None:
    schemas = derive_schemas(NoPkModel)
    assert "name" in schemas.create.model_fields
