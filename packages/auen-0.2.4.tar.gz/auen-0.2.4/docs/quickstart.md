# Quickstart

## 1. Install

```bash
pip install auen
```

## 2. Define your model

```python
from sqlmodel import Field, SQLModel

class Book(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    title: str
    isbn: str
    author_id: int | None = Field(default=None, foreign_key="author.id")
```

## 3. Create your app

Without auen, you'd write five async endpoint functions, wire up request/response models, handle 404s, manage database sessions, and implement pagination — roughly 150 lines of code that looks the same in every FastAPI project. With auen:

```python
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession

from auen import CrudRouterBuilder

engine = create_async_engine("sqlite+aiosqlite:///bookstore.db")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)
    yield


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSession(engine) as session:
        yield session


app = FastAPI(lifespan=lifespan)
app.include_router(CrudRouterBuilder.for_model(Book, get_session).build())
```

## 4. Run it

```bash
uvicorn app:app --reload
```

Visit `http://localhost:8000/docs` to see your auto-generated API.
