"""Auen - Auto-generate FastAPI CRUD endpoints from SQLModel models."""

from importlib.metadata import PackageNotFoundError, version

from auen.config import (
    ALL_OPERATIONS,
    AuthConfig,
    FilterConfig,
    FilterFieldConfig,
    FilterOp,
    HooksConfig,
    Operation,
    PaginationConfig,
    SchemaConfig,
)
from auen.exceptions import (
    AuenError,
    ConfigurationError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
)
from auen.policy import AllowAll, CrudPolicy
from auen.repository import AsyncCrudRepository, AsyncSqlModelRepository
from auen.router import CrudRouterBuilder
from auen.schemas import derive_schemas

try:
    __version__ = version("auen")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "ALL_OPERATIONS",
    "AllowAll",
    "AsyncCrudRepository",
    "AsyncSqlModelRepository",
    "AuenError",
    "AuthConfig",
    "ConfigurationError",
    "ConflictError",
    "CrudPolicy",
    "CrudRouterBuilder",
    "FilterConfig",
    "FilterFieldConfig",
    "FilterOp",
    "ForbiddenError",
    "HooksConfig",
    "NotFoundError",
    "Operation",
    "PaginationConfig",
    "SchemaConfig",
    "__version__",
    "derive_schemas",
]
