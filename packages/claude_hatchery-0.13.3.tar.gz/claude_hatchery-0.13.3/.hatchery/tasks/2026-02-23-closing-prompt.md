# Task: closing-prompt

**Status**: complete
**Branch**: hatchery/closing-prompt
**Created**: 2026-02-23 09:24

## Objective

We added a closing prompt. However, it doesn't appear to be firing.

Can you check why that is?

## Summary

**Root cause:** `docker.launch_docker` used `os.execvp("docker", cmd)` (line 354 of `docker.py`), which *replaces* the current process with the Docker process. After the container exits, the Python process is gone — `_post_exit_check` never gets called.

**Fix (2 files, 3 lines changed):**

1. `src/claude_hatchery/docker.py` — changed `os.execvp("docker", cmd)` → `subprocess.run(cmd)` so control returns to the caller after the container exits.

2. `src/claude_hatchery/cli.py` — in `_launch_claude_new` and `_launch_claude_resume`, moved `_post_exit_check(name, repo, worktree)` out of the `else` branch so it runs for *both* Docker and native paths (was only reached on the native path before).

**Pattern to watch:** Any future "run something then check" logic must use `subprocess.run` (child process) rather than `os.execvp` (process replacement). The existing `_launch_claude_finalize` had the same structure but is called after the user explicitly chooses "wrap up" — its docker path also had no `_post_exit_check`, but since finalize already passes `_WRAP_UP_PROMPT` directly to Claude, that's intentional.
