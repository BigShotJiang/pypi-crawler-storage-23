# Task: fix-startup

**Status**: complete
**Branch**: hatchery/fix-startup
**Created**: 2026-02-22 16:36

## Objective

Currently, when claude-hatchery starts up, you get a prompt "do you trust this folder?"

When starting in a sandbox (docker), we should auto-accept this or bypass this if possible.

## Agreed Plan (v2 — supersedes original)

1. Add version line to `_print_banner()` in `cli.py`.
2. Remove `prepare_container_settings()` from `docker.py`; remove `container_settings` param from `docker_mounts()` and its bind-mount.
3. In `launch_docker()`, inject `{"skipDangerousModePermissionPrompt": true}` via `claude --settings <json>` flag.
4. Remove `TestPrepareContainerSettings` (5 tests) from `test_subprocess.py`.

## Progress Log

- [x] Step 1: Update task file
- [x] Step 2: Implement changes in `docker.py`
- [x] Step 3: Add tests
- [x] Step 4: Run tests + linter, fix any issues
- [x] Step 5: Commit
- [x] Step 6 (v2): Add version banner, switch to --settings flag, remove tests

## Summary

**Problem**: Docker-sandboxed Claude sessions showed "Do you trust the files in this folder?" workspace trust dialog on startup. Also, no version shown at startup.

**Root cause (trust dialog)**: The bind-mount approach required ordering guarantees and file-system operations; the previous fix likely wasn't taking effect because users running an old installed version missed the fix, or the mount ordering wasn't working as expected.

**Final fix**: Two-part solution:
1. **Version in banner** — `_print_banner()` now prints `Version: <version>` so users can immediately confirm which installed version is running. Labels aligned to 9-char padding (`Task:`, `Repo:`, `Version:`).
2. **`--settings` flag** — Instead of writing a per-session `settings.json` and bind-mounting it, `launch_docker()` now passes `{"skipDangerousModePermissionPrompt": true}` directly to `claude --settings`. This requires no file-system operations, no mount ordering, and is robust across restarts.

**Key pattern**: `claude --settings <json>` accepts a JSON string directly on the command line — simpler than file mounts for one-off overrides.

**Files changed**:
- `src/claude_hatchery/cli.py` — added `Version:` line to `_print_banner()`
- `src/claude_hatchery/docker.py` — removed `prepare_container_settings()`, removed `container_settings` param from `docker_mounts()`, switched to `--settings` flag in `launch_docker()`
- `tests/test_subprocess.py` — removed `TestPrepareContainerSettings` (5 tests); 163 tests pass
