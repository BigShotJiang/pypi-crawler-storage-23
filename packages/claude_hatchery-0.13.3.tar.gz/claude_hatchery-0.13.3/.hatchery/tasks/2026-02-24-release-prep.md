# Task: release-prep

**Status**: complete
**Branch**: hatchery/release-prep
**Created**: 2026-02-24 15:43

## Objective

Prepare the repo for public release on GitHub: add a license, scrub internal hostnames, update project metadata, and replace GitLab CI with GitHub Actions workflows.

## Context

The repo was configured for an internal GitLab/Nexus environment. This task converts it to a standard public GitHub project.

## Summary

### Files changed

| File | Change |
|---|---|
| `LICENSE` | Created — MIT, copyright 2026 Logan Grado |
| `pyproject.toml` | Added `license`, `license-files`, `maintainers`, `[project.urls]` |
| `src/claude_hatchery/cli.py` | Replaced Nexus URL with `pypi.org/simple/claude-hatchery/`; fixed version-parsing regex for PyPI format |
| `README.md` | Simplified install block; MR→PR throughout; GitLab settings → GitHub settings |
| `.github/workflows/ci.yml` | Created — validate-pr-title, lint, test |
| `.github/workflows/release.yml` | Created — compute-version, create-release, publish-pypi |
| `.gitlab-ci.yml` | Deleted |
| `.gitlab/` | Deleted entire directory |

### Key decisions

- **PyPI regex fix**: The Nexus simple index used `/packages/claude-hatchery/VERSION/` paths, but PyPI uses filenames like `claude_hatchery-0.7.1-py3-none-any.whl`. The regex was updated to `r"claude.hatchery-([0-9]+\.[0-9]+\.[0-9]+)"` so the update-check feature actually works.
- **Release workflow**: Uses `git log -1 --format='%s'` to read the squash commit title directly (simpler than the GitLab approach of querying the API for the associated MR). Works correctly because GitHub squash merges set the commit subject to the PR title.
- **`PYPI_TOKEN` secret**: Must be added in GitHub repo Settings → Secrets before the first release.
- **`pyproject.toml` URL**: `[project.urls] Repository` set to `https://github.com/Seekr-Technologies/claude-hatchery`.
