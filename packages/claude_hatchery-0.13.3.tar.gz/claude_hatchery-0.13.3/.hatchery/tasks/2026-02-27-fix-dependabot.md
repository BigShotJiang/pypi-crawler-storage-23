# Task: fix-dependabot

**Status**: complete
**Branch**: hatchery/fix-dependabot
**Created**: 2026-02-27 17:07

## Objective

Add a github action to automatically update dependencies. we use UV

## Summary

Created `.github/dependabot.yml` with two ecosystems:

1. **`uv`** — uses GitHub's native uv support to keep `pyproject.toml` / `uv.lock` current. Weekly schedule, `chore:` prefix.
2. **`github-actions`** — keeps action version pins (e.g. `astral-sh/setup-uv@v5`) current. Weekly schedule, `ci:` prefix.

**Key decision**: `commit-message.prefix` is set to `chore` and `ci` respectively so Dependabot PR titles like `chore: bump click from 8.3.1 to 8.3.2` pass the Conventional Commits regex enforced in `ci.yml`'s `validate-pr-title` job. Without this, default Dependabot titles (e.g. "Bump click from 8.3.1 to 8.3.2") would fail CI.

**Files changed**: `.github/dependabot.yml` (new file)

**Activation**: Dependabot activates automatically once this file lands on the default branch. Verify at GitHub → Insights → Dependency graph → Dependabot.
