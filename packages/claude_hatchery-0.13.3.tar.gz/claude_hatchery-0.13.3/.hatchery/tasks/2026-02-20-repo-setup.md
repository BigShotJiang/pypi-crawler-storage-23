# Task: repo-setup

**Status**: complete
**Branch**: hatchery/repo-setup
**Created**: 2026-02-20 15:43

## Objective

We are setting up a new repo. Help take care of boilerplate

## Context

We are setting up a new repo. The repo already has the core file (claude-hatchery). I want you to help set up the boilerplate of the repo:

- Make sure uv is configured well
- Make sure we have good code formatting/linting
- Make sure the package provides `claude-hatchery` CLI
- Update the project to use uv-dynamic-versioning

## Agreed Plan

1. Add `.python-version` with `3.12`
2. Rewrite `pyproject.toml` — dynamic versioning, CLI entry point, uv-dynamic-versioning
3. Create `.ruff.toml` — py312 target, 120 line length, isort with first-party claude_hatchery
4. Clear placeholder from `src/claude_hatchery/__init__.py`
5. Run `uv sync` — generates lockfile, installs editable
6. Run `ruff format` and `ruff check --fix` — clean up source

## Progress Log

- [x] Step 1 — `.python-version` created
- [x] Step 2 — `pyproject.toml` rewritten with dynamic versioning and CLI entry point
- [x] Step 2b — `.ruff.toml` created
- [x] Step 3 — `__init__.py` placeholder removed
- [x] Step 4 — `uv sync` ran successfully; lockfile generated
- [x] Step 5 — `ruff format` and `ruff check --fix` applied; all checks pass

## Notes

- `ruff` was not installed initially; added as a dev dependency via `uv add --dev ruff`
- `uv-dynamic-versioning` resolves to `0.0.0.post3.dev0+5e7773a` without a version tag (expected)

## Summary

**What was done:** Set up standard packaging boilerplate for the claude-hatchery project.

**Key decisions:**
- `ruff` added as a `[dependency-groups] dev` dep (not runtime) — the `uv add --dev` command placed it under `[dependency-groups]` which is the uv-native dev group syntax
- `uv-dynamic-versioning` is build-time only (in `[build-system].requires`), not in runtime deps
- `.ruff.toml` kept separate from `pyproject.toml` for clarity

**Patterns established:**
- Version comes from git tags matching `v*.*.*`; without a tag defaults to `0.0.0.dev0`
- CLI entry point: `claude-hatchery = "claude_hatchery.claude_hatchery:main"`
- Dev tooling run via `uv run ruff ...`

**Verification:** `uv run claude-hatchery --help` works; `ruff format --check` and `ruff check` both pass clean.
