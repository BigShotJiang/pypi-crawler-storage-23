# Task: feat-archive

**Status**: complete
**Branch**: hatchery/feat-archive
**Created**: 2026-02-24 09:53

## Objective

Add an `archive` command that parks a task mid-flight: worktree is removed, branch is preserved, and the task can later be resumed — with `resume` re-creating the worktree from the existing branch.

## Context

Tasks could be `done` (worktree removed, branch kept, status → complete), `delete`d (worktree + branch + metadata removed), or `abort`ed (worktree removed, branch kept, status → aborted). The gap: aborted tasks couldn't be resumed because `cmd_resume` hard-exited when the worktree was missing.

`archive` fills this gap with a dedicated status and updated resume logic.

## Summary

### Changes made

**`src/claude_hatchery/cli.py`** — only file changed.

1. **Added `cmd_archive`** (after `cmd_abort`, ~line 604):
   - Rejects `no_worktree` tasks (nothing to archive)
   - If worktree exists and has uncommitted changes, offers a checkpoint commit (Y/n, default Y) — same UX as `done`
   - Removes the worktree (not force-removed; clean only)
   - Sets `meta["status"] = "archived"` and saves
   - Prints the branch name and a `resume` hint

2. **Updated `cmd_resume`** (lines 532–541):
   - Replaced the hard-exit on missing worktree with a branch on `status == "archived"`
   - Re-creates the worktree via `git.create_worktree(repo, branch, worktree, branch)` — passing the branch as both the branch name and base keeps it at its current HEAD
   - Updates status back to `"in-progress"` before launching Claude

### Key decisions

- No schema version bump needed — `"archived"` is just a new value for the existing `meta["status"]` string field.
- `archive` does **not** force-remove the worktree. If there are uncommitted changes and the user declines the checkpoint commit, the archive is aborted. This avoids silent data loss.
- `resume` restores status to `"in-progress"` **before** launching Claude so that a crash/interrupt during launch doesn't leave it stuck in `"archived"`.
- The `list` command already filters on `status == "in-progress"` by default; archived tasks correctly appear only under `--all`.
