# Task: fix-task-name-db

**Status**: complete
**Branch**: hatchery/fix-task-name-db
**Created**: 2026-02-22 13:05

## Objective

Currently, claude hatchery task names are global across repos.

If I try to create a new task, named `some-task` in repo A, and then again in repo B, I get an error.

We should be able to create tasks with the same name in different repos.

Also, we should propose a plan for being able to re-use task names for old tasks that were complete (done).

## Agreed Plan

1. **Add `repo_id()`** to `tasks.py` — stable hash-based repo identifier
2. **Update `task_db_path()`** signature to `(repo: Path, name: str) -> Path` → scoped to `~/.hatchery/tasks/{repo-id}/{name}.json`
3. **Update `save_task()`** to use repo-scoped path (creates parent dirs)
4. **Update `load_task()`** with new signature `(repo: Path, name: str)` and flat-path migration fallback (move old flat files to new scoped path)
5. **Update `repo_tasks_for_current_repo()`** to scan scoped subdir + flat files for backward compat
6. **Update CLI commands** (`resume`, `done`, `abort`, `delete`, `status`) to call `git.git_root()` and pass repo to `load_task()`
7. **Allow name reuse** in `cmd_new` for completed/aborted tasks (status-aware check)
8. **Status line UX**: replace `os.execvp` with `subprocess.run` to allow post-session code; print banner before and reminder after Claude exits
9. **Update tests**: conftest.py, test_pure.py, test_task_io.py

## Progress Log

- [x] Step 1-2: Add `repo_id()` and update `task_db_path()`
- [x] Step 3-5: Update `save_task()`, `load_task()`, `repo_tasks_for_current_repo()`
- [x] Step 6-7: Update CLI commands + allow name reuse
- [x] Step 8: Status line banner + exit reminder
- [x] Step 9: Update tests, run tests + lint (142 passing)

## Notes

- Migration: flat-path fallback in `load_task()` moves old files to new scoped location (lazy one-time migration)
- `cmd_new` and `cmd_list` already call `git.git_root()` — no additional repo lookup needed
- Banner uses box-drawing characters for visual clarity
- Docker path uses `docker.launch_docker` which already runs a subprocess — same banner/reminder wrapper applies

## Summary

### Key decisions

**Repo scoping**: `repo_id()` generates a `{basename}-{sha256[:8]}` slug so task namespaces are per-repo. Tasks live at `~/.hatchery/tasks/{repo-id}/{name}.json`. Two repos with the same directory basename (e.g. `/alice/myapp` vs `/bob/myapp`) still get distinct IDs due to the hash.

**Lazy migration**: `load_task()` falls back to the old flat path (`~/.hatchery/tasks/{name}.json`) and moves the file to the scoped path on first access — no migration script needed.

**Name reuse**: `cmd_new` reads the existing DB record and only blocks if `status == "in-progress"`. Completed/aborted tasks are silently overwritten (the git task file in `.hatchery/tasks/` is the permanent record).

**Session UX**: Replaced `os.execvp` (which replaces the process) with `subprocess.run` so code can run after Claude exits. A banner prints before the session and a reminder after. Both Docker and non-Docker paths get the same wrapper.

### Patterns established

- All CLI commands that act on a named task now call `git.git_root()` to resolve the repo, then pass it to `load_task(repo, name)`.
- `save_task(meta)` derives the repo from `meta["repo"]` — callers don't pass it separately.
- CLI tests for commands that call `git.git_root()` should mock `claude_hatchery.cli.git.git_root`.

### Files changed

- `src/claude_hatchery/tasks.py` — `repo_id()`, new `task_db_path()`, `save_task()`, `load_task()`, `repo_tasks_for_current_repo()`
- `src/claude_hatchery/cli.py` — banner helpers, `subprocess.run`, `git.git_root()` in 5 commands, `cmd_new` name-reuse logic
- `tests/conftest.py` — `sample_meta` writes to scoped path
- `tests/test_pure.py` — `TestRepoId` (new), `TestTaskDbPath` updated
- `tests/test_task_io.py` — `TestSaveTask`, `TestLoadTask`, `TestRepoTasksForCurrentRepo` updated
- `tests/test_cli.py` — `TestCmdStatus` updated to mock `git.git_root()`
