# Task: fix-rebase

**Status**: complete
**Branch**: hatchery/fix-rebase
**Created**: 2026-02-23 11:42

## Objective

Fix `git rebase` (and cherry-pick, merge) failing inside the Docker sandbox with:
```
error: Unable to create '/repo/.git/packed-refs.lock': Read-only file system
```

## Context

The sandbox mounts `/repo` read-only, then selectively overrides specific `.git/`
subdirectories with read-write mounts. Git's ref transaction code (files backend)
**always** acquires a lock on `packed-refs` during any ref update — even when
updating a loose ref not in `packed-refs`. It does so by creating
`/repo/.git/packed-refs.lock` at the `.git/` root. Since `.git/` root was
inherited as read-only from the `/repo:ro` parent mount, this lock creation failed.

Pre-creating the lock file as a sentinel is not viable: git uses `O_CREAT | O_EXCL`
which fails if the file exists, causing git to think another process holds the lock.

## Summary

**Fix:** Added one bind mount in `docker_mounts()` (`src/claude_hatchery/docker.py`)
immediately after the `/repo:ro` parent mount:

```python
f"{git_dir}:{tasks.CONTAINER_REPO_ROOT}/.git:rw",
```

In Linux/Docker, a more-specific mount path overrides its parent's mount options
at that subtree. So `/repo/.git:rw` takes precedence over `/repo:ro` for everything
under `.git/`, while the source tree (everything outside `.git/`) remains read-only.

**Existing sub-mounts kept as-is** — technically redundant now (subsumed by
`.git:rw`) but harmless. The sentinel file mounts for `COMMIT_EDITMSG`/`ORIG_HEAD`
are also kept: they give each task session its own per-task copy, preventing
concurrent task sessions from clobbering each other's state.

**Security trade-off:** `.git/:rw` is a medium-risk hole — the container can now
modify files at the `.git/` root: `config`, `packed-refs`, `FETCH_HEAD`,
`MERGE_HEAD`, etc., enabling modification of refs for any branch. This is
accepted since the pre-existing HIGH risk (`.git/objects:rw`) is already worse.
Documented in the "Known security holes" docstring comment.

**Files changed:**
- `src/claude_hatchery/docker.py` — `docker_mounts()`: added `.git:rw` mount,
  updated "Mount layout" docstring, updated "Known security holes" comment.
