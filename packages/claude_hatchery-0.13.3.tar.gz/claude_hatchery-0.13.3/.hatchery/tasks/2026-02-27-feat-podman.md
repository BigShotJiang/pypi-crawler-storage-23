# Task: feat-podman

**Status**: complete
**Branch**: hatchery/feat-podman
**Created**: 2026-02-27

## Objective

Add Podman as the preferred outer container runtime, providing rootless sandboxing with better security than Docker.

## Context

Hatchery previously required Docker as the outer runtime. Docker's daemon runs as root and containers are root by default, so any container escape has elevated host privileges. Podman is daemonless and rootless-native — UID 0 inside the sandbox maps to the calling user on the host, not real root. Making Podman the preferred runtime improves the security baseline for all hatchery sandboxes without any opt-in required.

## Summary

### Runtime auto-detection

`detect_runtime()` probes `podman info` first, then `docker info`. Podman is preferred unconditionally — even repos that don't need nested containers get the rootless security benefit when Podman is installed.

If the Podman binary is installed but `podman info` fails (e.g. `podman machine` not started on macOS), hatchery exits with a clear error rather than silently falling back to Docker. The user installed Podman intentionally and should not be silently downgraded to a less-secure runtime.

### Podman outer-container flags

Added for every Podman invocation (not just special modes):
- `--userns=keep-id` — maps the calling user to the same UID inside the container so bind-mounted host files (owned by the calling user) are writable by the `claude` user (also UID 1000 by default)
- `--security-opt label=disable` — disables SELinux/AppArmor label confinement on mounts, which would otherwise block access to host-owned bind-mount directories

### Template extraction

`Dockerfile.template` and `docker.yaml.template` moved from inline strings embedded in `docker.py` to standalone files in `src/claude_hatchery/resources/`. They are read at runtime via `Path(__file__).parent / "resources"`. Easier to read and edit without touching Python source.

### Runtime enum

`Runtime(Enum)` with `PODMAN = "PODMAN"` and `DOCKER = "DOCKER"`. Values are ALL_CAPS to signal enum membership. A `binary` property returns `self.value.lower()` — used in subprocess calls — separating the constant name from the CLI binary name.

`detect_runtime() -> Runtime` always returns a `Runtime` or exits (never `None`). `resolve_runtime(repo, worktree, no_docker) -> Runtime | None` replaces the old `resolve_docker() -> bool`: returns `None` for native execution (no Dockerfile or `--no-docker`), otherwise calls `detect_runtime()`. This combines the "should we containerise?" check with runtime detection so the runtime is threaded through to launch functions without re-detection.

### Files changed

| File | Change |
|------|--------|
| `src/claude_hatchery/docker.py` | `Runtime(Enum)` with `binary` property; `podman_available()`; `detect_runtime() -> Runtime` (prefers Podman, hard-errors if installed but not running); `resolve_runtime() -> Runtime | None` (replaces `resolve_docker() -> bool`); `build_docker_image(runtime=)`; `_run_container(runtime=)` with Podman-specific flags; `launch_docker` + `launch_docker_no_worktree` accept `runtime: Runtime` directly; template string constants replaced with `Path` references |
| `src/claude_hatchery/cli.py` | Helpers updated: `use_docker: bool` → `runtime: docker.Runtime | None` |
| `src/claude_hatchery/resources/Dockerfile.template` | Starter Dockerfile extracted from inline string |
| `src/claude_hatchery/resources/docker.yaml.template` | Starter docker.yaml extracted from inline string |
| `README.md` | Runtime auto-detection section documenting Podman preference and macOS setup |
| `tests/test_subprocess.py` | `TestPodmanAvailable`, `TestDetectRuntime`, `TestResolveRuntime`; `TestRunContainerRuntime` covering runtime binary selection, Podman flags, and `--privileged` regression guard |

### Key decisions

- **Podman preferred unconditionally** — not just for DinD or special modes. The rootless security benefit applies to all sandboxes.
- **Hard error on broken Podman** — if the binary exists but `podman info` fails, exit rather than fall back to Docker. Silent fallback would mean the user's security expectation is violated without warning.
- **`--userns=keep-id` for all Podman runs** — bind-mount writability depends on UID matching. Works correctly when the calling user's UID matches `claude`'s UID in the Dockerfile (1000, the default).
- **`Runtime(Enum)` not `StrEnum`** — values are ALL_CAPS constants; the `binary` property provides the lowercase CLI name. This keeps the enum value semantically distinct from the shell binary it represents.

### Gotchas

- On macOS, Podman requires a running `podman machine`. If it is not started, hatchery will error with a hint: `podman machine start` (or `podman machine init && podman machine start` on first use).
- If the host user has a UID other than 1000, `--userns=keep-id` maps them correctly into the container, but the `claude` user (created at UID 1000 by `useradd`) won't match — mount writes will fail. Workaround: pass `--build-arg USER_UID=$(id -u)` and parameterise the `useradd` call in the Dockerfile. Not implemented here; documented as a known limitation.
