# Task: fix-final-commit

**Status**: complete
**Branch**: hatchery/fix-final-commit
**Created**: 2026-02-24 08:57

## Objective

When closing a task, it asks if you want to commit uncommitted changes.
However, it does not tell the user what these are.

We should print a list of files, and perhaps number of lines added/deleted so the user has better context.

## Context

This is what the complete dialog looked like before the fix:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Task appears complete.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Mark task 'feat-custom-mounts' as done? [Y/n]
2026-02-24 08:56:54,706  WARNING  claude-hatchery: worktree has uncommitted changes.
Warning: worktree has uncommitted changes.
Commit them as a final checkpoint before removing? [Y/n] n
Worktree removed: /Users/lgrado/Code/tools/claude-hatchery/.hatchery/worktrees/feat-custom-mounts
Branch retained: hatchery/feat-custom-mounts
Task 'feat-custom-mounts' marked complete.
```

## Summary

Added `uncommitted_changes_summary(cwd: Path) -> str` to `src/claude_hatchery/git.py` (after `has_uncommitted_changes`). The function runs `git status --short` to get the file list and `git diff HEAD --stat` to get the summary line (e.g. "2 files changed, 18 insertions(+), 2 deletions(-)"), combining them into a single string.

In `src/claude_hatchery/cli.py`, `_do_mark_done` now calls this helper and prints its output between the warning message and the `[Y/n]` prompt.

After the fix the dialog reads:

```
Warning: worktree has uncommitted changes.
 M src/claude_hatchery/cli.py
 M src/claude_hatchery/git.py
?? scratch.py
  (2 files changed, 18 insertions(+), 2 deletions(-))
Commit them as a final checkpoint before removing? [Y/n]
```

Four unit tests were added to `tests/test_subprocess.py` (`TestUncommittedChangesSummary`) covering: staged file in output, untracked file in output, diff-stat summary line present, and empty output when repo is clean.
