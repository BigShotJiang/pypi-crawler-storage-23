# Task: fix-normalize-image-tag

**Status**: complete
**Branch**: hatchery/fix-normalize-image-tag
**Created**: 2026-02-24 10:33

## Objective

Normalize the Docker image name derived from the repo directory name so that
special characters (`.`, `+`, spaces, leading dots) don't produce invalid
`docker build -t` invocations.

## Context

`docker_image_name()` only lowercased the repo directory name. Characters
outside `[a-z0-9._-]` — and specifically leading dots or `+` — make a Docker
image name invalid, causing `docker build` to fail when run from directories
like `my.project` or `foo+bar`.

`tasks.to_name()` already existed and produced a valid slug: it lowercases,
replaces every non-alphanumeric run with `-`, strips leading/trailing dashes,
and caps at 50 chars. `docker.py` already imported `tasks`, so the fix was
a one-liner.

## Summary

**Files changed:**
- `src/claude_hatchery/docker.py` — `docker_image_name` now calls
  `tasks.to_name(repo.name)` instead of `repo.name.lower()`
- `tests/test_pure.py` — added 4 new cases to `TestDockerImageName` covering
  dots, plus, spaces, and leading-dot directory names

**Key decisions:**
- Reused `tasks.to_name()` rather than duplicating normalization logic; that
  function is already the canonical slug-maker for this project.
- The existing tests (`test_format`, `test_lowercases_repo_name`) remain green
  because `to_name("my-project")` → `"my-project"` and
  `to_name("MyProject")` → `"myproject"`.

**Gotcha:** `to_name` caps at 50 characters — image names with very long
directory names will be silently truncated. This matches the existing behaviour
for task names and is acceptable.
