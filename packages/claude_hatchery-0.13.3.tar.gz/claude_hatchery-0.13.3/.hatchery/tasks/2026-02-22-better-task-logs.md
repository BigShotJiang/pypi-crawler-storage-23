# Task: better-task-logs

**Status**: complete
**Branch**: hatchery/better-task-logs
**Created**: 2026-02-22 17:04

## Objective

Currently, claude-hatchery instructs agents to leave task files as a record of work. However, I want to re-evaluate that as a good idea.

## Context

I asked a running agent if it found them useful, here was it's response:

  question for you:                                                                                                                                                             
                                                                                                                                                                                
  by now there are several task files from previous agents.                                                                                                                     
                                                                                                                                                                                
  Do you think these are actually helpful? Or are they just clutter?                                                                                                            

● Read 1 file (ctrl+o to expand)

● Honestly — mixed value, leaning toward useful when the Summary section is good.

  What actually helped me this session:

  The cleanup.md note "The argo submit -n argo-workflows in _argo_submit() still hardcodes the Argo namespace" was directly relevant — I used that to explain the namespace bug I
  fixed. And the delete-command.md summary gave me immediate context on what delete() did and why, without having to re-read the implementation.

  Where they fall short:

  - The Progress Log (checkboxes) is noise once a task is complete — nobody reads it after the fact.
  - The Agreed Plan section duplicates what git commits already capture.
  - Two tasks in one day means the files are easy to find, but as the repo ages and tasks accumulate, scanning a flat directory of 50 task files will be painful.

  My honest take:

  The Summary section at the bottom is the genuinely useful part — key decisions, patterns established, gotchas. That's exactly what a future agent (or developer) needs. The rest
  (status, plan, progress log) is scaffolding that serves the agent while it's working but has little value afterward.

  If I were redesigning it: keep the Summary as a lightweight ADR (Architecture Decision Record) format, drop the rest. Or consider consolidating them into a single
  docs/developer/decisions.md as the repo grows, rather than a file-per-task structure.

Evaluate its suggestion, and determine if we should update the format and how

## Summary

The agent feedback was accurate: the Progress Log and Agreed Plan are useful scaffolding during execution but become noise in the permanent record. The Summary section is the only part that provides durable value to future agents.

**Decision:** Task files now function as lightweight ADRs. On completion, agents strip the working scaffolding (Agreed Plan, Progress Log) and leave only: metadata header → Objective → Context → Summary.

**Files changed:**
- `src/claude_hatchery/tasks.py` — two edits:
  1. `SESSION_SYSTEM` step 5: updated to explicitly instruct agents to remove Agreed Plan and Progress Log sections when marking a task complete, and describes the expected final shape of the file.
  2. `write_task_file()` template: replaced unused `## Notes` section with `## Summary` containing a placeholder that tells agents what to put there before they start working.

**Pattern established:** The `## Summary` placeholder is now visible from the moment a task is created, so agents don't have to invent the format at the end — they see the expected content categories (decisions, patterns, files changed, gotchas) up front.
