# .hatchery

Each file under `tasks/` is a record of a completed task, written by the agent
that performed the work. Named `YYYY-MM-DD-<task-name>.md`.

Future agents should browse these files for context on past decisions,
patterns, and gotchas before starting new work.
