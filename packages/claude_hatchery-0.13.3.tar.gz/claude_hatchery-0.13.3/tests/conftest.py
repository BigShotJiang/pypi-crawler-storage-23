"""Shared fixtures for claude-hatchery tests."""

import json
from pathlib import Path

import pytest

import claude_hatchery.tasks as tasks


@pytest.fixture()
def fake_tasks_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect TASKS_DB_DIR to a temp directory."""
    db = tmp_path / "tasks_db"
    db.mkdir()
    monkeypatch.setattr(tasks, "TASKS_DB_DIR", db)
    return db


@pytest.fixture()
def sample_meta(fake_tasks_db: Path) -> dict:
    """A valid task metadata dict (already saved to fake_tasks_db)."""
    meta = {
        "name": "my-task",
        "branch": "hatchery/my-task",
        "worktree": "/some/repo/.hatchery/worktrees/my-task",
        "repo": "/some/repo",
        "status": "in-progress",
        "created": "2026-01-15T10:00:00",
        "session_id": "abc-123",
        "schema_version": 1,
    }
    # Write to the scoped path matching repo="/some/repo"
    scoped_dir = fake_tasks_db / tasks.repo_id(Path("/some/repo"))
    scoped_dir.mkdir(parents=True, exist_ok=True)
    (scoped_dir / "my-task.json").write_text(json.dumps(meta))
    return meta


@pytest.fixture()
def fake_repo(tmp_path: Path) -> Path:
    """A temp directory with a .git subdirectory (no real git init needed for most tests)."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    return repo
