Add attachments to orders directly from your Pos Frontend.
