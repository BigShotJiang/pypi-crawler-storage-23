from typing import AsyncIterator
from openai.types.chat import ChatCompletionChunk
from openai.types.chat.chat_completion_chunk import Choice
from loguru import logger
import copy


class ThinkingHijackTemplate:
    """
    用于拦截和处理 <think>...</think> 标签的模板类
    将 <think> 标签内的内容转移到 reasoning_content 字段中
    """
    
    def __init__(self):
        self.buffer = ""
        self.in_thinking = False
        self.thinking_finished = False
        
    async def hijack_stream(self, chunks: AsyncIterator[ChatCompletionChunk]):
        """
        拦截流式响应，处理 <think> 标签
        
        Args:
            chunks: 原始的流式响应块
            
        Yields:
            ChatCompletionChunk: 处理后的响应块
        """
        self.in_thinking=False
        self.thinking_finished=False
        self.buffer = ""
        
        # logger.debug("ThinkingHijackTemplate: 开始处理流")
        
        async for chunk in chunks:
            if chunk is None:
                continue
                
            # 检查chunk是否有有效的content
            if (not chunk.choices or 
                len(chunk.choices) == 0 or 
                chunk.choices[0].delta.content is None):
                # logger.debug("ThinkingHijackTemplate: 跳过无content的chunk")
                yield chunk
                continue
                
            content = chunk.choices[0].delta.content
            # logger.debug(f"ThinkingHijackTemplate: 接收到内容chunk: '{content}', 当前状态: in_thinking={self.in_thinking}, thinking_finished={self.thinking_finished}")
            
            # 如果思考已经结束，直接透传所有内容
            if self.thinking_finished:
                # logger.debug(f"ThinkingHijackTemplate: 思考已结束，直接透传内容: '{content}'")
                yield chunk
                continue
                
            # 将当前内容添加到缓冲区
            self.buffer += content
            # logger.debug(f"ThinkingHijackTemplate: 当前缓冲区: '{self.buffer}'")
            
            # 处理缓冲区内容
            processed_chunks = self._process_buffer(chunk)
            for processed_chunk in processed_chunks:
                yield processed_chunk
    
    def _process_buffer(self, original_chunk: ChatCompletionChunk):
        """
        处理缓冲区内容，识别 <think> 和 </think> 标签
        
        Args:
            original_chunk: 原始chunk，用作模板
            
        Returns:
            List[ChatCompletionChunk]: 处理后的chunk列表
        """
        results = []
        
        while True:
            if not self.in_thinking:
                # 不在思考模式，查找 <think> 开始标签
                think_start_pos = self.buffer.find('<think>')
                
                if think_start_pos >= 0:
                    # 找到了开始标签
                    logger.debug(f"ThinkingHijackTemplate: 找到<think>标签，位置: {think_start_pos}")
                    # 输出标签前的内容（如果有）
                    if think_start_pos > 0:
                        content_before = self.buffer[:think_start_pos]
                        logger.debug(f"ThinkingHijackTemplate: 输出<think>标签前的内容: '{content_before}'")
                        content_chunk = self._create_content_chunk(original_chunk, content_before)
                        results.append(content_chunk)
                    
                    # 切换到思考模式，移除已处理的内容和标签
                    self.in_thinking = True
                    self.buffer = self.buffer[think_start_pos + 7:]  # 7 = len('<think>')
                    logger.debug(f"ThinkingHijackTemplate: 进入思考模式，剩余缓冲区: '{self.buffer}'")
                    continue
                
                else:
                    # 没有找到开始标签
                    # 检查缓冲区末尾是否可能是 <think> 的前缀
                    if self._is_potential_start_tag():
                        # 可能是标签前缀，保留缓冲区等待更多内容
                        break
                    else:
                        # 不是标签前缀，输出所有内容
                        if self.buffer:
                            content_chunk = self._create_content_chunk(original_chunk, self.buffer)
                            results.append(content_chunk)
                            self.buffer = ""
                        break
            
            else:
                # 在思考模式，查找 </think> 结束标签
                think_end_pos = self.buffer.find('</think>')
                
                if think_end_pos >= 0:
                    # 找到了结束标签
                    logger.debug(f"ThinkingHijackTemplate: 找到</think>标签，位置: {think_end_pos}")
                    # 输出标签前的思考内容（如果有）
                    if think_end_pos > 0:
                        thinking_content = self.buffer[:think_end_pos]
                        logger.debug(f"ThinkingHijackTemplate: 输出思考内容: '{thinking_content}'")
                        reasoning_chunk = self._create_reasoning_chunk(original_chunk, thinking_content)
                        results.append(reasoning_chunk)
                    
                    # 思考结束，切换回普通模式
                    self.in_thinking = False
                    self.thinking_finished = True
                    self.buffer = self.buffer[think_end_pos + 8:]  # 8 = len('</think>')
                    logger.debug(f"ThinkingHijackTemplate: 退出思考模式，剩余缓冲区: '{self.buffer}'")
                    
                    # 继续处理剩余内容
                    if self.buffer:
                        logger.debug(f"ThinkingHijackTemplate: 输出</think>标签后的内容: '{self.buffer}'")
                        content_chunk = self._create_content_chunk(original_chunk, self.buffer)
                        results.append(content_chunk)
                        self.buffer = ""
                    break
                
                else:
                    # 没有找到结束标签
                    # 检查缓冲区末尾是否可能是 </think> 的前缀
                    if self._is_potential_end_tag():
                        # 可能是标签前缀，保留缓冲区等待更多内容
                        logger.debug(f"ThinkingHijackTemplate: 缓冲区末尾可能是</think>前缀，等待更多内容")
                        break
                    else:
                        # 不是标签前缀，输出所有思考内容
                        if self.buffer:
                            logger.debug(f"ThinkingHijackTemplate: 输出缓冲区中的思考内容: '{self.buffer}'")
                            reasoning_chunk = self._create_reasoning_chunk(original_chunk, self.buffer)
                            results.append(reasoning_chunk)
                            self.buffer = ""
                        break
        
        return results
    
    def _is_potential_start_tag(self) -> bool:
        """检查缓冲区末尾是否可能是 <think> 标签的前缀"""
        tag = '<think>'
        for i in range(1, min(len(tag), len(self.buffer) + 1)):
            if self.buffer.endswith(tag[:i]):
                return True
        return False
    
    def _is_potential_end_tag(self) -> bool:
        """检查缓冲区末尾是否可能是 </think> 标签的前缀"""
        tag = '</think>'
        for i in range(1, min(len(tag), len(self.buffer) + 1)):
            if self.buffer.endswith(tag[:i]):
                return True
        return False
    
    def _create_content_chunk(self, original_chunk: ChatCompletionChunk, content: str) -> ChatCompletionChunk:
        """
        创建包含普通内容的chunk
        
        Args:
            original_chunk: 原始chunk
            content: 内容文本
            
        Returns:
            ChatCompletionChunk: 包含内容的新chunk
        """
        # logger.debug(f"ThinkingHijackTemplate: 创建普通内容chunk: '{content}'")
        new_chunk = copy.deepcopy(original_chunk)
        if new_chunk.choices and len(new_chunk.choices) > 0:
            new_chunk.choices[0].delta.content = content
        return new_chunk
    
    def _create_reasoning_chunk(self, original_chunk: ChatCompletionChunk, reasoning_text: str) -> ChatCompletionChunk:
        """
        创建包含推理内容的chunk
        
        Args:
            original_chunk: 原始chunk
            reasoning_text: 推理文本
            
        Returns:
            ChatCompletionChunk: 包含推理内容的新chunk
        """
        logger.debug(f"ThinkingHijackTemplate: 创建思考内容chunk: '{reasoning_text}'")
        new_chunk = copy.deepcopy(original_chunk)
        
        if new_chunk.choices and len(new_chunk.choices) > 0:
            new_chunk.choices[0].delta.content = None
            new_chunk.choices[0].delta.reasoning_content = reasoning_text
            # # 使用 ReasoningChoiceDelta 替换原来的 delta
            # reasoning_delta = ReasoningChoiceDelta(
            #     content="",  # 清空content，因为这部分内容应该在reasoning_content中
            #     reasoning_content=reasoning_text
            # )
            
            # # 创建新的 Choice 对象
            # new_choice = Choice(
            #     delta=reasoning_delta,
            #     finish_reason=new_chunk.choices[0].finish_reason,
            #     index=new_chunk.choices[0].index,
            #     logprobs=new_chunk.choices[0].logprobs
            # )
            
            # new_chunk.choices[0] = new_choice
        
        return new_chunk