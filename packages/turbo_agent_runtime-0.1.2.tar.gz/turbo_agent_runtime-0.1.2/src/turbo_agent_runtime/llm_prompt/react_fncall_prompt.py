import copy
import json
import os
from typing import List, Literal, Union

from loguru import logger
from prisma.models import Message, MessageAction
from .basic import NamedTool
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    BaseMessageChunk,
    ChatMessage,
    ChatMessageChunk,
    HumanMessage,
    HumanMessageChunk,
    InvalidToolCall,
    SystemMessage,
    SystemMessageChunk,
    ToolCall,
    ToolMessage,
    ToolMessageChunk,
)

TOOL_DESC = (
    '{name_for_model}: Call this tool to interact with the {name_for_human} API. '
    'What is the {name_for_human} API useful for? {description_for_model} Parameters: {parameters} {args_format}')

# PROMPT_REACT = """Answer the following questions as best you can. You have access to the following tools:

# {tool_descs}

# Use the following format:

# Question: the input question you must answer
# Thought: you should always think about what to do
# Action: the action to take, should be one of [{tool_names}]
# Action Input: the input to the action
# Observation: the result of the action
# ... (this Thought/Action/Action Input/Observation can be repeated zero or more times)
# Thought: I now know the final answer
# Final Answer: the final answer to the original input question

# Begin!

# Question: {query}
# """

PROMPT_REACT="""回答以下问题时，尽你所能地给出最佳答案。你可以使用以下工具：

{tool_descs}

不要编造猜测其它工具名称，充分利用以上工具或者凭借自有知识完成任务，如果确实遇到问题或者遇到无法绕开的错误，请向用户反馈。
请严格按照下面的格式书写（保持顺序和大小写一致；括号内说明仅作解释，不要写入答案）：

Question: 输入问题
Thought: 你在思考接下来要做什么——用中文书写
Action: 要调用的工具，应为 [{tool_names}] 中的一个，不要编造猜测其它工具名称，充分利用已有工具。
Action Input: （传递给该工具的输入）
Observation: 执行该工具后得到的结果

…（上述 Thought / Action / Action Input / Observation 块可重复出现零次或多次，直到你得出答案）

Thought: 我思考的结果并且知道该如何回复用户了。
Final Answer: 用中文给出对原始问题的最终回答

Begin!

Question: {query}"""

TOOL_CALL_TEMPLATE ="""
Action: {action}
Action Input: {action_input}
Observation: {observation}
"""


class ReActFnCallPrompt:
       
    def patch_tooluse_message(self, messages: List[Union[AIMessage, SystemMessage, ToolMessage, HumanMessage]], tools:List[NamedTool]) -> List[Union[AIMessage, SystemMessage, HumanMessage]]:
        """Patch the tool use messages with the provided tools."""
        if not messages:
            return messages
        messages = copy.deepcopy(messages)
        final_messages = []
        # self._prepend_react_prompt(messages,tools)
        #用于拼接 连续的tool信息
        current_message_content = []
        tool_message_map = {message.tool_call_id: message.content for message in messages if isinstance(message, ToolMessage)}

        other_messages = [message for message in messages if not isinstance(message, ToolMessage)]
        for msg in other_messages:
            logger.info(f"Processing message: {msg}")
            if isinstance(msg, SystemMessage):
                final_messages.append(msg)
            elif isinstance(msg, HumanMessage):
                if  current_message_content:
                    final_messages.append(
                        AIMessage(content=current_message_content)
                    )
                    current_message_content = []
                if isinstance(msg.content, list):
                    new_content = []
                    for item in msg.content:
                        logger.info(f"Processing HumanMessage content item: {item},isinstance(item, dict): {isinstance(item, dict)}")
                        if isinstance(item, dict) and item.get("type") == "file":
                            new_item = {}
                            new_item["type"]  = "text"
                            new_item["text"] = "注：用户上传了文件："+json.dumps(item.get("data", ""),ensure_ascii=False, separators=(',', ':'))+"。 由于文件内容一般情况下非常大，为避免上下文溢出，所以可以通过使用工具 getDetail(file_id,type='file',instruction='（此处指定具体要获取什么样文件内容，或者要形成什么样的结果，什么样格式的输出等需求描述）') 来定向获取文件的关键内容，或者对文件整体内容的压缩内容，或者目录结构。"
                            new_content.append(new_item)
                        else:
                            new_content.append(copy.deepcopy(item))
                    msg.content = new_content
                    final_messages.append(msg)
                else:
                    final_messages.append(msg)
            elif isinstance(msg, AIMessage):
                new_content = ""
                thought = msg.additional_kwargs.get("reasoning_content",None)
                if thought:
                    new_content += f"Thought: {thought}\n"
                if msg.tool_calls:
                    [logger.debug(f"AIMessage tool_calls: {tool['id']} {tool['args']} {tool['name']} {tool_message_map[tool['id']]}" ) for tool in msg.tool_calls]
                    try:
                        new_content += "\n".join([TOOL_CALL_TEMPLATE.format(action=tool["name"], action_input=json.dumps(tool["args"],ensure_ascii=False), observation=tool_message_map[tool["id"]]) for tool in msg.tool_calls])
                    except KeyError as e:
                        # Handle the case where tool_message_map does not contain the tool call id
                        logger.exception(e)
                        raise Exception(f"\nError: Tool call {e} not found in tool_message_map.\n this may be due to a missing ToolMessage for the tool call id. Ensure that all tool calls have corresponding ToolMessages.") from e
                    
                if msg.content and isinstance(msg.content, str):
                    new_content += "\nFinal Answer: " + msg.content
                    current_message_content.append(
                        {
                            "type": "text",
                            "text": new_content
                        }
                    )
                elif msg.content and isinstance(msg.content, list):
                    if msg.content[0]["type"] == "text":
                        new_content += "\nFinal Answer: " + msg.content[0]["text"]+"\n"
                        current_message_content.append(
                            {
                                "type": "text",
                                "text": new_content
                            }
                        )
                        current_message_content.extend(msg.content[1:])
                    else:
                        new_content += "\nFinal Answer: \n"
                        current_message_content.append(
                            {
                                "type": "text",
                                "text": new_content
                            }
                        )
                        current_message_content.extend(msg.content)
                else:
                    if len(new_content.strip())>0:
                        current_message_content.append(
                            {
                                "type": "text",
                                "text": new_content+"\n"
                            }
                        )
        if current_message_content:
            final_messages.append(
                AIMessage(content=current_message_content)
            )
        
        if final_messages and isinstance(final_messages[-1], AIMessage) and isinstance(messages[-1], ToolMessage):
            final_messages.append(
                HumanMessage(content="工具结果已返回，继续执行直到完成当前任务。")
            )
            logger.info(f"react messages: {final_messages}")
            return final_messages
        elif final_messages and isinstance(final_messages[-1], HumanMessage):
            final_messages = self._prepend_react_prompt(final_messages, tools)
            logger.info(f"react messages: {final_messages}")
            return final_messages
        else:
            raise ValueError(f"最后一条消息必须是 HumanMessage 类型、或ToolMessage。请检查输入的消息列表。\n---------------\nmessages:{messages}\n====================\nfinal_messages:{final_messages}")

    def _prepend_react_prompt(self, messages: List[Union[AIMessage,SystemMessage,ToolMessage,HumanMessage]], tools:List[NamedTool]) -> List[Union[AIMessage,SystemMessage,ToolMessage,HumanMessage]]:
        if not isinstance(messages[-1], HumanMessage):
            return messages
        tool_descs = []
        for tool in tools:
            name_for_human = tool.name_for_human
            name_for_human = tool.name_for_human
            name_for_model = tool.name
            assert name_for_human and name_for_model
            tool_descs.append(
                TOOL_DESC.format(name_for_human=name_for_human,
                                 name_for_model=name_for_model,
                                 description_for_model=tool.description,
                                 parameters=json.dumps(tool.args_schema, ensure_ascii=False),
                                 args_format="").rstrip())
        tool_descs = '\n\n'.join(tool_descs)
        tool_names = ','.join(tool.name for tool in tools)
        human_content = ""
        if isinstance(messages[-1].content, str):
            human_content = messages[-1].content
        elif isinstance(messages[-1].content, list) and messages[-1].content:
            for item in messages[-1].content:
                if isinstance(item, dict) and "text" in item:
                    human_content += item["text"]
                elif isinstance(item, str):
                    human_content += item
        messages[-1].content = PROMPT_REACT.format(
            tool_descs=tool_descs,
            tool_names=tool_names,
            query=human_content,
        )
        return messages