# #基础库依赖
# import json
# import pytz
# from loguru import logger
# from datetime import datetime
# from typing import List, cast,Literal

# #外部依赖
# import html2text
# import markdown
# from langchain_core.runnables import RunnableConfig
# from turbo_agent_runtime.llm_prompt.basic import NamedTool
# from langchain_core.messages import SystemMessage, AIMessage, ToolMessage,HumanMessage,BaseMessage
# from langchain.tools import tool

# #数据库依赖
# from prisma.partials import AgentForChat,ToolForRun
# from prisma.models import BusinessSetting,Model,ModelParameters

# #内部依赖
# from turbo_agent_runtime.agent.state import AgentState,InteractiveMode,SerializableWorkset
# from turbo_agent_runtime.agent.model import get_model

# from turbo_agent_store.db.workset import (
#     WorksetModel,
#     create_workset,
#     get_workset_by_id,
#     bind_knowledge_resource_to_workset,
#     bind_tool_call_to_workset,
#     bind_multiple_knowledge_resources_to_workset,
#     bind_multiple_tool_calls_to_workset
# )
# from turbo_agent_store.rag.init_index_manticore import query_knowledge_record, update_knowledge_file_index



# @tool
# def WriteReport(report: str,mode:Literal['append','overwrite']): # pylint: disable=invalid-name,unused-argument
#     """撰写报告内容的工具，结果将直接呈现给用户,mode 有两种： 'append' 为续写,'overwrite' 为覆盖 """

# @tool
# def WriteReportTitle(report_title: str): # pylint: disable=invalid-name,unused-argument
#     """拟定报告标题的工具，结果将直接呈现给用户"""

# @tool
# def useToolOneTime(tool_name:str,refer_doc_ids:List[str],operation_require:str,):
#     """指定使用某个工具，完成某项任务，参考特定资料, 并以指定返回内容所必须包含的信息"""
#     pass

# beijing_tz = pytz.timezone('Asia/Shanghai')

# @tool
# def GetCurrentTime(timezone: str = "Asia/Shanghai"):
#     """
#     一个可以用于获取指定时区（或城市）当前日期和时间的工具。
#     参数:
#       timezone: 时区名称（如 'Asia/Shanghai', 'UTC', 'America/New_York' 等），或常见城市名（如 '北京', '纽约', '伦敦'）。
#     """
#     pass

# def append_knowledge_resource(messages: List[BaseMessage], setting_id: str|None, workset_id: str|None):
#     """
#     将知识资源添加到工作集的工具。
#     """
#     limit=4000

    
#     latest_queries = []
#     for message in messages:
#         if isinstance(message, HumanMessage) and isinstance(message.content, list):
#             latest_query = "用户："
#             for item in message.content:
#                 if isinstance(item, dict) and item.get("type") == "text":
#                     latest_query += item.get("text", "")
#                 elif isinstance(item, str):
#                     latest_query += item
#         elif isinstance(message, HumanMessage) and isinstance(message.content, str):
#             latest_query = "用户："
#             latest_query += message.content
#         elif isinstance(message, AIMessage) and isinstance(message.content, str):
#             latest_query = "助手："
#             latest_query += message.content
#         latest_queries.append(latest_query)
    
#     # 从后往前累加 latest_queries 内容，当长度大于5000时停止
#     accumulated_query = ""
#     for query in reversed(latest_queries):
#         if len(accumulated_query) + len(query) > limit:
#             break
#         accumulated_query = query + accumulated_query

#     docs = query_knowledge_record("对于以下对话记录：\n\n对话记录开始\n\n"+latest_query+"\n\n对话记录停止\n能够帮助助手回答用户最新问题的内容有什么？",setting_ids=[setting_id] if setting_id else [], workset_ids=[workset_id] if workset_id else [])
    
#     # 取出docs中的content，拼接成记忆片段
#     if docs is None or len(docs) == 0:
#         return None
#     memory_segments = "\n\n".join([f"<知识片段{i}>\n" + doc["content"]+f"\n</知识片段{i}>" for i, doc in enumerate(docs)])
#     return memory_segments

# async def GetCurrentTimeImply(timezone:str):
#      # 城市到时区的简单映射
#     city_timezone_map = {
#         "北京": "Asia/Shanghai",
#         "上海": "Asia/Shanghai",
#         "纽约": "America/New_York",
#         "伦敦": "Europe/London",
#         "东京": "Asia/Tokyo",
#         "洛杉矶": "America/Los_Angeles",
#         "巴黎": "Europe/Paris",
#         "柏林": "Europe/Berlin",
#         "悉尼": "Australia/Sydney",
#         "UTC": "UTC",
#     }
#     tz_name = city_timezone_map.get(timezone, timezone)
#     try:
#         tz = pytz.timezone(tz_name)
#         now = datetime.now(tz)
#         return now.strftime('%Y-%m-%d %H:%M:%S')
#     except Exception as e:
#         return f"无法识别时区或城市: {timezone}，请使用标准时区名如 'Asia/Shanghai' 或常见城市名。错误信息: {e}"

# async def construct_chat_node(name:str|None,local_model:Model,user_id:str,assistant_id:str,parameters:ModelParameters,setting:BusinessSetting|None,langchain_tools:List[NamedTool],assistants:List[AgentForChat],mode:InteractiveMode=InteractiveMode.chat):
#     if mode==InteractiveMode.report:
#         langchain_tools.append(NamedTool(
#             name="WriteReport",
#             description=WriteReport.description,
#             name_for_human="撰写报告内容",
#             args_schema=WriteReport.args_schema.model_json_schema(),
#         ))
#         langchain_tools.append(NamedTool(
#             name_for_human="报告标题编辑工具",
#             name="WriteReportTitle",
#             description=WriteReportTitle.description,
#             args_schema=WriteReportTitle.args_schema.model_json_schema(),
#         ))
    
#     langchain_tools.append(NamedTool(name_for_human="获取当前时间",name="GetCurrentTime",\
#                                      args_schema={
#                                         "type": "object",
#                                         "properties": {
#                                             "timezone": {
#                                                 "type": "string",
#                                                 "description": "时区名称（如 'Asia/Shanghai'）或常见城市名（如 '北京'）",
#                                                 "default": "Asia/Shanghai",
#                                                 "examples": ["UTC", "America/New_York", "伦敦"]
#                                             }
#                                         },
#                                         "required": []
#                                     }))
#     call_tool_mapping = {}
#     call_tool_mapping["GetCurrentTime"] = ("查看当前时间",GetCurrentTimeImply)
        
#     async def chat_node(state: AgentState, config: RunnableConfig):
#         """
#         Chat Node
#         """
#         # logger.info(f"messages : ${messages}")
#         logger.info(f"new chat node is working logger: ${state}")
#         # state["logs"] = state.get("logs", [])
#         if state.logs is None:
#             state.logs = []
#         state.logs = []
#         need_workset_update = False
#         workset = state.workset
#         content=f"""
#                 你是一个乐于助人的助手
#                 """
#         if name and not setting:
#             content=f"""
#                 你是一个乐于助人的助手，你的名字叫：{name}
#                 """
#         elif setting:
#             content = f"""
#                 你是一个乐于助人的助手，你的名字叫：{name}
  
#                 以下是你的主要职责：
#                 {setting.business_logic}

#             """
#             if setting.business_rules:
#                 setting.business_rules.sort(key=lambda x: x.index)
#                 rules = "\n".join([ f"规则{rule.index}: {rule.content}" for rule in setting.business_rules])
#                 content+=f"""以下是你完成任务过程中需要遵守的基本原则:
#                                 {rules} \n\n"""
#         else:
#             content=f"""
#                 你是一个乐于助人的助手，你的名字叫：{name}
#                 """
#         if len(langchain_tools) >0:
#             content += "特殊说明：如果用户提出的问题需要多次使用工具才能完成，请请持续执行多步工具操作，直到任务完成，再停止。如果用户的问题基于当前状态就能够回答，直接回答问题，不需要进一步调用工具。如果尝试使用工具失败超过三次，则暂停使用工具，并反馈用户。"
            
#         if mode==InteractiveMode.report:
#             # report_title = state.get("report_title", "<无>")
#             report_title = state.report_title or "<无>"
#             report = state.report or "<无>"
#             # report = state.get("report", "<无>")
#             report = html2text.html2text(report)
#             content += f"""当前是报告模式，用户的主要目标可能是完成报告。
#             当前报告标题如下：
#             {report_title}

#             当前报告内容如下：
#             {report}

#             当用户要求撰写报告或修改标题时，必须优先使用工具而非直接输出文本：
#             任何时候标题拟定或者变化，必须调用WriteReportTitle写入，用户可以直接看到WriteReportTitle的写入结果。
#             内容扩展时必须通过WriteReport函数写入而非通过文本告知用户，用户可以直接看到WriteReport的写入结果。
#             示例场景1： 用户说"修改标题 " → 必须先调用WriteReportTitle重置标题，再调用WriteReport更新章节
#             示例场景1： 用户说"撰写报告 " → 必须先调用WriteReport输出内容。后告知用户已完成。
#             """
        
#         new_files = []
#         if isinstance(state.messages[-1], HumanMessage) and isinstance(state.messages[-1].content, list):
#             for item in state.messages[-1].content:
#                 if isinstance(item, dict) and item.get("type") == "file":
#                     new_files.append(item)

#         if new_files:
#             if not workset:
#                 workset = await create_workset(
#                     name="",
#                     description="",
#                     ownerId=user_id,
#                     assistant_id=assistant_id
#                 )
#             logger.info("new files:"+json.dumps(new_files,ensure_ascii=False)+f" {workset}")
#             await bind_multiple_knowledge_resources_to_workset(
#                 workset_id=workset.id,
#                 knowledge_resource_ids=[item.get("data",{}).get("id") for item in new_files],
#                 user_id=user_id,
#                 assistant_id=assistant_id
#             )
#             need_workset_update = True
#             for item in new_files:
#                 update_knowledge_file_index(knowledge_id=item.get("data",{}).get("id"), workset_ids=[workset.id])
        
#         logger.debug(f"current memmory is searched from: setting: {setting.id if setting else None} workset :{workset.id if workset else None}")
#         mems = append_knowledge_resource(state.messages, setting_id=setting.id if setting else None, workset_id=workset.id if workset else None)
#         if mems:
#             content += "以下记忆片段或许对你回答用户问题有一定帮助：\n"+mems+"\n"
#             logger.info("memory segments: "+mems)
#         content += "请你尽最大可能帮助用户解决问题。如果尝试使用工具失败超过三次，则暂停使用工具! 如果尝试使用工具失败超过三次，则暂停使用工具!"
#         systemMessage = SystemMessage(
#             content=content
#         )
#         # config = copilotkit_customize_config(
#         #     config,
#         #     emit_intermediate_state=[
#         #         {
#         #             "state_key": "report",
#         #             "tool": "WriteReport",
#         #             "tool_argument": "report",
#         #         }, {
#         #             "state_key": "report_title",
#         #             "tool": "WriteReportTitle",
#         #             "tool_argument": "report_title",
#         #         }
#         #     ],
#         #     emit_tool_calls="DeleteResources"
#         # )

#         resources = []

#         model,has_function_call = get_model(model=local_model,parameters=parameters)
#         # Prepare the kwargs for the ainvoke method
#         ainvoke_kwargs = {}
#         if model.__class__.__name__ in ["ChatOpenAI"]:
#             ainvoke_kwargs["parallel_tool_calls"] = False
#         ainvoke_kwargs["parallel_tool_calls"] = False
#         # logger.info("system_message"+ systemMessage.model_dump_json())
#         # logger.info(f"langchain_tools: ${langchain_tools}")
#         if has_function_call:
#             response = await model.bind_tools(langchain_tools,**ainvoke_kwargs).ainvoke([
#                 systemMessage,
#                 *state.messages,
#             ], config)
#         else:
#             response = await model.ainvoke([
#                 systemMessage,
#                 *state.messages,
#             ], config)
        
#         ai_message = cast(AIMessage, response)
#         ai_message.additional_kwargs["reasoning_content"] = response.additional_kwargs.get("reasoning_content", "")
#         if ai_message.additional_kwargs["reasoning_content"]:
#             ai_message.additional_kwargs["reasoning_content"] = ai_message.additional_kwargs["reasoning_content"].strip()
#         # logger.info(f"new response: {response.model_dump_json()}")
#         # logger.info(f"ai_message: {ai_message}")

#         tool_messages = []
#         if need_workset_update and workset:
#             workset =await get_workset_by_id(workset.id, user_id)
#         state.workset = workset
#         if ai_message.tool_calls:
            
#             for tool_call in ai_message.tool_calls:
#                 logger.info("tool call"+str(tool_call))
#                 try:
#                     if  tool_call["name"] == "WriteReport":
#                         # logger.info("tool call"+ str())
#                         edit_mode = tool_call["args"].get("mode", "append")
#                         if edit_mode=="append":
#                             report =state.report+"\n"+  tool_call["args"].get("report", "")
#                         else:
#                             report = tool_call["args"].get("report", "")
#                         state.report = report
#                         tool_messages.append(ToolMessage(
#                                 tool_call_id=tool_call["id"],
#                                 content="报告已写入，并同步给用户前端，用户可以看到，不需要再重复叙述"
#                             ))
#                     elif tool_call["name"] == "WriteReportTitle":
#                         state.report_title = tool_call["args"].get("report_title", "")
#                         tool_messages.append(ToolMessage(
#                                 tool_call_id=tool_call["id"],
#                                 content="报告题目已写入，并同步给用户前端，用户可以看到，不需要再重复叙述"
#                             ))
#                     elif tool_call["name"] == "GetCurrentTime":
#                         timezone = tool_call["args"].get("timezone", "Asia/Shanghai")
#                         current_time = await GetCurrentTimeImply(timezone)
#                         state.current_time = current_time
#                         tool_messages.append(ToolMessage(
#                                 tool_call_id=tool_call["id"],
#                                 content=current_time
#                             ))
                    
#                 except Exception as e:
#                     logger.error(f"tool_run error: {e}")
#                     tool_messages.append(ToolMessage(
#                             tool_call_id=tool_call["id"],
#                             content=json.dumps({"error":str(e)},ensure_ascii=False)
#                         ))
#             messages = [ ai_message, *tool_messages]
#             logger.info(f"final messages: {messages} ")
#             return AgentState(**state.model_dump(exclude_unset=True, exclude={"messages"}), messages=messages)
#         else:
#             messages = [ ai_message]
#             logger.info(f"final messages: {messages} ")
#             return AgentState(**state.model_dump(exclude_unset=True, exclude={"messages"}), messages=messages)
#     return chat_node