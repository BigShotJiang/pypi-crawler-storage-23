import copy
from langchain_openai import ChatOpenAI
from langchain_core.language_models.chat_models import (
    BaseChatModel,
    LangSmithParams,
    agenerate_from_stream,
    generate_from_stream,
)
from .basic_fncall_prompt import BaseFnCallPrompt
from langchain_core.messages.ai import (
    InputTokenDetails,
    OutputTokenDetails,
    UsageMetadata,
)
from .basic import NamedTool
from langchain_core.messages.tool import tool_call_chunk
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    BaseMessageChunk,
    ChatMessage,
    ChatMessageChunk,
    FunctionMessage,
    FunctionMessageChunk,
    HumanMessage,
    HumanMessageChunk,
    InvalidToolCall,
    SystemMessage,
    SystemMessageChunk,
    ToolCall,
    ToolMessage,
    ToolMessageChunk,
)
from langchain_core.runnables import (
    Runnable,
    RunnableLambda,
    RunnableMap,
    RunnablePassthrough,
)
from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.utils.function_calling import (
    convert_to_openai_function,
    convert_to_openai_tool,
)
from langchain_core.language_models import LanguageModelInput
from typing import (
    Any,
    AsyncIterator,
    Callable,
    Dict,
    Iterator,
    List,
    Literal,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypedDict,
    TypeVar,
    Union,
    cast,
    override,
)
import openai
from litellm import acompletion, completion_cost 
import json
import warnings
from langchain_core.runnables.config import run_in_executor
from loguru import logger
from langchain_core.tools import BaseTool
from .schemas import (
    ASSISTANT,
    DEFAULT_SYSTEM_MESSAGE,
    SYSTEM,
    USER,
    FUNCTION,
    Message,
    FunctionCall,
    ContentItem,
)

from .nous_fncall_prompt import NousFnCallPrompt
from .react_fncall_prompt import  ReActFnCallPrompt
from .tool_call_template import  FnCallCommonTemplate
from .react_template import ReActCommonTemplate
from .thinking_hijack_template import ThinkingHijackTemplate
from .utils import repair_surrogates

def _handle_openai_bad_request(e: openai.BadRequestError) -> None:
    if (
        "'response_format' of type 'json_schema' is not supported with this model"
    ) in e.message:
        message = (
            "This model does not support OpenAI's structured output feature, which "
            "is the default method for `with_structured_output` as of "
            "langchain-openai==0.3. To use `with_structured_output` with this model, "
            'specify `method="function_calling"`.'
        )
        warnings.warn(message)
        raise e
    elif "Invalid schema for response_format" in e.message:
        message = (
            "Invalid schema for OpenAI's structured output feature, which is the "
            "default method for `with_structured_output` as of langchain-openai==0.3. "
            'Specify `method="function_calling"` instead or update your schema. '
            "See supported schemas: "
            "https://platform.openai.com/docs/guides/structured-outputs#supported-schemas"  # noqa: E501
        )
        warnings.warn(message)
        raise e
    else:
        raise

def langchain_content_to_qwen_content(content:Union[str, list[Union[str, dict]]]) -> List[ContentItem]:
    """Convert LangChain content to Qwen content format."""
    result_content = []
    if isinstance(content, str):
        return [ContentItem(text=content)]
    elif isinstance(content, list):
        for item in content:
            if isinstance(item, str):
                result_content.append(ContentItem(text=item))
            elif isinstance(item, dict) :
                # Ensure the item has 'type' keys
                if "type" not in item:
                    raise ValueError("Each item in the list must be a string or a dict with 'type'  key.")
                if item["type"] == "text":
                    result_content.append(ContentItem(text=item.get("text", "")))
                elif item["type"] == "image":
                    result_content.append(ContentItem(
                        image=item.get("data", "")
                    ))
                elif item["type"] == "file":
                    #TODO: handle file content
                    # 从 turbo-agent.rag.router.analyze_file 中获取文件内容
                    result_content.append(ContentItem(
                        text="注：用户上传了文件："+json.dumps(item.get("data", ""),ensure_ascii=False, separators=(',', ':'))+"。 由于文件内容一般情况下非常大，为避免上下文溢出，所以可以通过使用工具 getDetail(file_id,type='file',instruction='（此处指定具体要获取什么样文件内容，或者要形成什么样的结果，什么样格式的输出等需求描述）') 来定向获取文件的关键内容，或者对文件整体内容的压缩内容，或者目录结构。"
                    ))
        return result_content
    else:
        raise ValueError(f"Unsupported content type: {type(content)}")

def langchainMsg_qwenMsg(msg:Union[AIMessage,SystemMessage,ToolMessage,HumanMessage]):
    result = []
    message_dict: Dict[str, Any] = {"content": langchain_content_to_qwen_content(msg.content)}
    if isinstance(msg, ChatMessage):
        message_dict["role"] = msg.role
        result = [message_dict]
    elif isinstance(msg, HumanMessage):
        message_dict["role"] = USER
        result = [message_dict]
    elif isinstance(msg, SystemMessage):
        message_dict["role"] = SYSTEM
        message_dict["content"] = [ContentItem(text=msg.content)]
        result = [message_dict]
    elif isinstance(msg, AIMessage):
        message_dict["role"] = ASSISTANT
        message_dict["content"] = [ContentItem(text=msg.content)]
        result = [message_dict]
        if msg.tool_calls or msg.invalid_tool_calls:
            new_message_dict = {}
            for tool_call in msg.tool_calls:
                new_message_dict["role"] = ASSISTANT
                new_message_dict["content"] = []
                new_message_dict["function_call"] = FunctionCall(tool_call["name"],arguments=json.dumps(tool_call["args"]))
                result.append(new_message_dict)
            
            # message_dict["tool_calls"] = [
            #     _lc_tool_call_to_openai_tool_call(tc) for tc in message.tool_calls
            # ] + [
            #     _lc_invalid_tool_call_to_openai_tool_call(tc)
            #     for tc in message.invalid_tool_calls
            # ]
            pass
    elif isinstance(msg, ToolMessage):
        message_dict["role"] = FUNCTION
        message_dict["content"] = [ContentItem(text=msg.content)]
        result = [message_dict]
    else:
        logger.warning(f"not implemented: {msg}")
        return None
    
    return [Message(**item) for item in result]

def _create_usage_metadata(oai_token_usage: dict) -> UsageMetadata:
    input_tokens = oai_token_usage.get("prompt_tokens", 0)
    output_tokens = oai_token_usage.get("completion_tokens", 0)
    total_tokens = oai_token_usage.get("total_tokens", input_tokens + output_tokens)
    input_token_details: dict = {
        "audio": (oai_token_usage.get("prompt_tokens_details") or {}).get(
            "audio_tokens"
        ),
        "cache_read": (oai_token_usage.get("prompt_tokens_details") or {}).get(
            "cached_tokens"
        ),
    }
    output_token_details: dict = {
        "audio": (oai_token_usage.get("completion_tokens_details") or {}).get(
            "audio_tokens"
        ),
        "reasoning": (oai_token_usage.get("completion_tokens_details") or {}).get(
            "reasoning_tokens"
        ),
    }
    return UsageMetadata(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        input_token_details=InputTokenDetails(
            **{k: v for k, v in input_token_details.items() if v is not None}
        ),
        output_token_details=OutputTokenDetails(
            **{k: v for k, v in output_token_details.items() if v is not None}
        ),
    )


def patch_tooluse_message(messages:List[BaseMessage],fncall_prompt:BaseFnCallPrompt,tools:List[BaseTool],is_pure_text=False):
    raw_messages = []
    for m in messages:
        message_dict_list = langchainMsg_qwenMsg(m)
        # logger.info(f"message_dict_list: {message_dict_list}")
        if not message_dict_list:
            continue
        raw_messages.extend(message_dict_list)
    
    # logger.info(f"raw_messages: {raw_messages}")

    raw_messages = fncall_prompt.preprocess_fncall_messages(
        messages=raw_messages,
        functions=tools,
        lang="zh",
        parallel_function_calls=True,
        function_choice='auto',
    )
    new_messages = []
    for m in raw_messages:
        new_content = m.content
        if isinstance(m.content, list):
            new_content = [{"type":c.type,"text":repair_surrogates(c.text)} for c in m.content]

        if m.role==SYSTEM:
            new_messages.append(SystemMessage(content=new_content))
        elif m.role==USER:
            new_messages.append(HumanMessage(content=new_content))
        elif m.role==ASSISTANT:
            new_messages.append(AIMessage(content=new_content))
        else:
            logger.warning(f"not implemented: {m}")
            continue
    if is_pure_text:
        for m in new_messages:
            if isinstance(m.content,list):
                m.content = "\n".join([c["text"] for c in m.content])
    return new_messages

# def post_process_tooluse_message(messages:Iterator[BaseMessage],fncall_prompt:BaseFnCallPrompt):
#     pre_msg = []
#     full_response = ''
#     pre_response = ''
#     final_response = ''
#     buff :List[Message] = []
#     for pre_msg in messages:
#         if isinstance(pre_msg.content,str):
#             full_response += pre_msg.content
#         elif isinstance(pre_msg.content,list):
#             for item in pre_msg.content:
#                 if item["type"] == "text":
#                     full_response += pre_msg.content
#         new_msg = Message(role=ASSISTANT,content=full_response)    
#         # multimodal_msg = format_as_multimodal_message(new_msg,
#         #                                  add_upload_info=False,
#         #                                  add_multimodel_upload_info=False,
#         #                                  add_audio_upload_info=False)
        
#         pre_msgs = fncall_prompt.postprocess_fncall_messages(
#             messages=[new_msg],
#             parallel_function_calls= True,
#             function_choice="auto",
#             thought_in_content=False
#         )
#         final_response = pre_msg.content
#         if isinstance(pre_msg.content, list):
#             final_response = "".join([c.text for c in pre_msg.content])
#         if len(buff)>4:
#             msg = buff.pop()
#             new_content = msg.content
#             temp_res = msg.content
#             if isinstance(msg.content, list):
#                 new_content = [{"type":c.type,"text":c.text} for c in msg.content]
#                 temp_res = "".join([c.text for c in msg.content])
#             temp_res = temp_res.replace(pre_response,"")
#             if final_response.replace(pre_response,"").find(temp_res)==0:
#                 yield AIMessageChunk(content=temp_res)
        
#         buff.append(pre_msg)
        


def _convert_delta_to_message_chunk(
    _dict: Mapping[str, Any], default_class: Type[BaseMessageChunk]
) -> BaseMessageChunk:
    id_ = _dict.get("id")
    role = cast(str, _dict.get("role"))
    content = cast(str, _dict.get("content") or "")
    # logger.info(f"convert delta to message chunk: {role}, {_dict}")
    reasoning_content = cast(str, _dict.get("reasoning_content") or "")
    additional_kwargs: Dict = {}
    additional_kwargs["reasoning_content"] = reasoning_content
    if _dict.get("function_call"):
        function_call = dict(_dict["function_call"])
        if "name" in function_call and function_call["name"] is None:
            function_call["name"] = ""
        additional_kwargs["function_call"] = function_call
    tool_call_chunks = []
    if raw_tool_calls := _dict.get("tool_calls"):
        additional_kwargs["tool_calls"] = raw_tool_calls
        try:
            tool_call_chunks = [
                tool_call_chunk(
                    name=rtc["function"].get("name"),
                    args=rtc["function"].get("arguments"),
                    id=rtc.get("id"),
                    index=rtc["index"],
                )
                for rtc in raw_tool_calls
            ]
        except KeyError:
            pass

    if role == "user" or default_class == HumanMessageChunk:
        return HumanMessageChunk(content=content, id=id_)
    elif role == "assistant" or default_class == AIMessageChunk:
        return AIMessageChunk(
            content=content,
            additional_kwargs=additional_kwargs,
            id=id_,
            tool_call_chunks=tool_call_chunks,  # type: ignore[arg-type]
        )
    elif role in ("system", "developer") or default_class == SystemMessageChunk:
        if role == "developer":
            additional_kwargs = {"__openai_role__": "developer"}
        else:
            additional_kwargs = {}
        return SystemMessageChunk(
            content=content, id=id_, additional_kwargs=additional_kwargs
        )
    elif role == "function" or default_class == FunctionMessageChunk:
        return FunctionMessageChunk(content=content, name=_dict["name"], id=id_)
    elif role == "tool" or default_class == ToolMessageChunk:
        return ToolMessageChunk(
            content=content, tool_call_id=_dict["tool_call_id"], id=id_
        )
    elif role or default_class == ChatMessageChunk:
        return ChatMessageChunk(content=content, role=role, id=id_)
    else:
        return default_class(content=content, id=id_)  # type: ignore




class CommonFnCallModel(ChatOpenAI):
    fncall_prompt: NousFnCallPrompt=NousFnCallPrompt()
    fncall_template:FnCallCommonTemplate=FnCallCommonTemplate()
    thinking_hijack_template: ThinkingHijackTemplate=ThinkingHijackTemplate()
    is_pure_text: bool=False
    tools: List[BaseTool] = []
    def _convert_chunk_to_generation_chunk(
        self,
        chunk: dict,
        default_chunk_class: Type,
        base_generation_info: Optional[Dict],
    ) -> Optional[ChatGenerationChunk]:
        if chunk.get("type") == "content.delta":  # from beta.chat.completions.stream
            return None
        token_usage = chunk.get("usage")
        choices = (
            chunk.get("choices", [])
            # from beta.chat.completions.stream
            or chunk.get("chunk", {}).get("choices", [])
        )

        usage_metadata: Optional[UsageMetadata] = (
            _create_usage_metadata(token_usage) if token_usage else None
        )
        if len(choices) == 0:
            # logprobs is implicitly None
            generation_chunk = ChatGenerationChunk(
                message=default_chunk_class(content="", usage_metadata=usage_metadata)
            )
            return generation_chunk

        choice = choices[0]
        if choice["delta"] is None:
            return None

        message_chunk = _convert_delta_to_message_chunk(
            choice["delta"], default_chunk_class
        )
        # logger.info(f"message_chunk: {message_chunk}")
        generation_info = {**base_generation_info} if base_generation_info else {}

        if finish_reason := choice.get("finish_reason"):
            generation_info["finish_reason"] = finish_reason
            if model_name := chunk.get("model"):
                generation_info["model_name"] = model_name
            if system_fingerprint := chunk.get("system_fingerprint"):
                generation_info["system_fingerprint"] = system_fingerprint

        logprobs = choice.get("logprobs")
        if logprobs:
            generation_info["logprobs"] = logprobs

        if usage_metadata and isinstance(message_chunk, AIMessageChunk):
            message_chunk.usage_metadata = usage_metadata

        generation_chunk = ChatGenerationChunk(
            message=message_chunk, generation_info=generation_info or None
        )
        return generation_chunk

    async def __aastream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
        ):
        kwargs["stream"] = True
        payload = self._get_request_payload(messages, stop=stop, **kwargs)
        default_chunk_class: Type[BaseMessageChunk] = AIMessageChunk
        base_generation_info = {}
        payload_str = json.dumps(payload,ensure_ascii=False)
        logger.debug(f"just before final calling openapi: \n--------------- {payload_str} \n----------------------")
        if "response_format" in payload:
            if self.include_response_headers:
                warnings.warn(
                    "Cannot currently include response headers when response_format is "
                    "specified."
                )
            payload.pop("stream")
            response_stream = self.root_async_client.beta.chat.completions.stream(
                **payload
            )
            context_manager = response_stream
        else:
            if self.include_response_headers:
                raw_response = await self.async_client.with_raw_response.create(
                    **payload
                )
                response = raw_response.parse()
                base_generation_info = {"headers": dict(raw_response.headers)}
            else:
                response = await self.async_client.create(**payload)
            context_manager = response
        try:
            async with context_manager as response:
                is_first_chunk = True
                # 根据配置选择是否启用thinking hijack
                # async for chunk in self.fncall_template.hijack_stream(response):
                async for chunk in self.fncall_template.hijack_stream(
                    self.thinking_hijack_template.hijack_stream(response)):
                    # async for chunk in response:
                        if not isinstance(chunk, dict):
                            chunk = chunk.model_dump()
                            
                        # logger.info(f"stream chunks: {chunk}")

                        generation_chunk = self._convert_chunk_to_generation_chunk(
                            chunk,
                            default_chunk_class,
                            base_generation_info if is_first_chunk else {},
                        )
                        if generation_chunk is None:
                            continue
                        default_chunk_class = generation_chunk.message.__class__
                        logprobs = (generation_chunk.generation_info or {}).get("logprobs")
                        if run_manager:
                            await run_manager.on_llm_new_token(
                                generation_chunk.text,
                                chunk=generation_chunk,
                                logprobs=logprobs,
                            )
                        is_first_chunk = False
                        yield generation_chunk
        except openai.BadRequestError as e:
            logger.error(f"OpenAI BadRequestError: {e}")
            _handle_openai_bad_request(e)
        if hasattr(response, "get_final_completion") and "response_format" in payload:
            final_completion = await response.get_final_completion()
            generation_chunk = self._get_generation_chunk_from_completion(
                final_completion
            )
            if run_manager:
                await run_manager.on_llm_new_token(
                    generation_chunk.text, chunk=generation_chunk
                )
            yield generation_chunk
    
    @override
    async def _astream(
        self, messages: List[BaseMessage],*args: Any, stream_usage: Optional[bool] = None, **kwargs: Any
    ) -> AsyncIterator[ChatGenerationChunk]:
        """Set default stream_options."""
        stream_usage = self._should_stream_usage(stream_usage, **kwargs)
        if stream_usage:
            kwargs["stream_options"] = {"include_usage": stream_usage}
        # logger.debug(
        #     f"_astream: Original messages ：{messages}"
        # )
        # TODO: deepseek 不支持 content为list
        try:
            messages = patch_tooluse_message(messages,self.fncall_prompt,self.tools,is_pure_text=self.is_pure_text)
        except Exception as e:
            logger.error("Error in patch_tooluse_message:")
            logger.exception(e)
        # logger.info(
        #     f"Patched messages ：{messages}"
        # )
        async for chunk in self.__aastream(messages=messages,*args, **kwargs):
            # logger.info(
            #     f"CommonFnCallModel chunk ：{chunk}"
            # )
            yield chunk

    def set_pure_text(self):
        self.is_pure_text=True
    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ):
        logger.info(f"amessages: {messages}")
        if self.streaming:
            logger.info(f"messages: {messages}")
            stream_iter = self._astream(
                messages, stop=stop, run_manager=run_manager, **kwargs
            )
            return await agenerate_from_stream(stream_iter)
        payload = self._get_request_payload(messages, stop=stop, **kwargs)
        generation_info = None
        if "response_format" in payload:
            if self.include_response_headers:
                warnings.warn(
                    "Cannot currently include response headers when response_format is "
                    "specified."
                )
            payload.pop("stream")
            try:
                response = await self.root_async_client.beta.chat.completions.parse(
                    **payload
                )
            except openai.BadRequestError as e:
                _handle_openai_bad_request(e)
        elif self.include_response_headers:
            raw_response = await self.async_client.with_raw_response.create(**payload)
            response = raw_response.parse()
            generation_info = {"headers": dict(raw_response.headers)}
        else:
            response = await self.async_client.create(**payload)
        return await run_in_executor(
            None, self._create_chat_result, response, generation_info
        )
    def bind_tools(
        self,
        tools: List[NamedTool],
        *,
        tool_choice: Optional[
            Union[dict, str, Literal["auto", "none", "required", "any"], bool]
        ] = None,
        strict: Optional[bool] = None,
        parallel_tool_calls: Optional[bool] = None,
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, BaseMessage]:
        """Bind tool-like objects to this chat model.

        Assumes model is compatible with OpenAI tool-calling API.

        Args:
            tools: A list of tool definitions to bind to this chat model.
                Supports any tool definition handled by
                :meth:`langchain_core.utils.function_calling.convert_to_openai_tool`.
            tool_choice: Which tool to require the model to call. Options are:

                - str of the form ``"<<tool_name>>"``: calls <<tool_name>> tool.
                - ``"auto"``: automatically selects a tool (including no tool).
                - ``"none"``: does not call a tool.
                - ``"any"`` or ``"required"`` or ``True``: force at least one tool to be called.
                - dict of the form ``{"type": "function", "function": {"name": <<tool_name>>}}``: calls <<tool_name>> tool.
                - ``False`` or ``None``: no effect, default OpenAI behavior.
            strict: If True, model output is guaranteed to exactly match the JSON Schema
                provided in the tool definition. If True, the input schema will be
                validated according to
                https://platform.openai.com/docs/guides/structured-outputs/supported-schemas.
                If False, input schema will not be validated and model output will not
                be validated.
                If None, ``strict`` argument will not be passed to the model.
            parallel_tool_calls: Set to ``False`` to disable parallel tool use.
                Defaults to ``None`` (no specification, which allows parallel tool use).
            kwargs: Any additional parameters are passed directly to
                :meth:`~langchain_openai.chat_models.base.ChatOpenAI.bind`.

        .. versionchanged:: 0.1.21

            Support for ``strict`` argument added.

        """  # noqa: E501

        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
        formatted_tools = [
            convert_to_openai_tool(tool, strict=strict) for tool in tools
        ]

        # logger.info(f"formatted_tools: {formatted_tools}")
        # return super().bind(tools=formatted_tools, **kwargs)
        self.tools = formatted_tools
        return self

    


class ReActFnCallModel(CommonFnCallModel):
    """ReActFnCallModel is a chat model that supports ReAct function calling."""

    fncall_prompt: ReActFnCallPrompt = ReActFnCallPrompt()
    fncall_template: ReActCommonTemplate = None

    
    def bind_tools(
        self,
        tools: List[NamedTool],
        parallel_tool_calls: Optional[bool] = None,
    ) -> Runnable[LanguageModelInput, BaseMessage]:
        """Bind tool-like objects to this chat model.

        Assumes model is compatible with OpenAI tool-calling API.

        Args:
            tools: A list of tool definitions to bind to this chat model.
                Supports any tool definition handled by
                :meth:`langchain_core.utils.function_calling.convert_to_openai_tool`.

        .. versionchanged:: 0.1.21

            Support for ``strict`` argument added.

        """  # noqa: E501
        self.tools = tools
        self.fncall_template = ReActCommonTemplate(tool_names=[tool.name for tool in tools])
        return self
    
    async def __aastream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ):
        kwargs["stream"] = True
        payload = self._get_request_payload(messages, stop=stop, **kwargs)
        default_chunk_class: Type[BaseMessageChunk] = AIMessageChunk
        base_generation_info = {}

        if "response_format" in payload:
            if self.include_response_headers:
                warnings.warn(
                    "Cannot currently include response headers when response_format is "
                    "specified."
                )
            payload.pop("stream")
            response_stream = self.root_async_client.beta.chat.completions.stream(
                **payload
            )
            context_manager = response_stream
        else:
            if self.include_response_headers:
                raw_response = await self.async_client.with_raw_response.create(
                    **payload
                )
                response = raw_response.parse()
                base_generation_info = {"headers": dict(raw_response.headers)}
            else:
                response = await self.async_client.create(**payload)
            context_manager = response
        try:
            async with context_manager as response:
                is_first_chunk = True
                async for chunk in self.fncall_template.hijack_stream(response):
                # async for chunk in response:
                    if not isinstance(chunk, dict):
                        chunk = chunk.model_dump()
                    # logger.info(f"stream chunks: {chunk}")

                    generation_chunk = self._convert_chunk_to_generation_chunk(
                        chunk,
                        default_chunk_class,
                        base_generation_info if is_first_chunk else {},
                    )
                    if generation_chunk is None:
                        continue
                    default_chunk_class = generation_chunk.message.__class__
                    logprobs = (generation_chunk.generation_info or {}).get("logprobs")
                    if run_manager:
                        await run_manager.on_llm_new_token(
                            generation_chunk.text,
                            chunk=generation_chunk,
                            logprobs=logprobs,
                        )
                    is_first_chunk = False
                    yield generation_chunk
        except openai.BadRequestError as e:
            _handle_openai_bad_request(e)
        if hasattr(response, "get_final_completion") and "response_format" in payload:
            final_completion = await response.get_final_completion()
            generation_chunk = self._get_generation_chunk_from_completion(
                final_completion
            )
            if run_manager:
                await run_manager.on_llm_new_token(
                    generation_chunk.text, chunk=generation_chunk
                )
            yield generation_chunk
    

    async def _astream(
        self, messages: List[BaseMessage],*args: Any, stream_usage: Optional[bool] = None, **kwargs: Any
    ) -> AsyncIterator[ChatGenerationChunk]:
        """Set default stream_options."""
        stream_usage = self._should_stream_usage(stream_usage, **kwargs)
        if stream_usage:
            kwargs["stream_options"] = {"include_usage": stream_usage}
        # logger.info(
        #     f"Original messages ：{messages}"
        # )
        # TODO: deepseek 不支持 content为list
        messages = self.fncall_prompt.patch_tooluse_message(messages,self.tools)
        # logger.info(
        #     f"Patched messages ：{messages}"
        # )
        async for chunk in self.__aastream(messages=messages,*args, **kwargs):
            # logger.info(
            #     f"CommonFnCallModel chunk ：{chunk}"
            # )
            yield chunk

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ):
        logger.info(f"amessages: {messages}")
        if self.streaming:
            logger.info(f"messages: {messages}")
            stream_iter = self._astream(
                messages, stop=stop, run_manager=run_manager, **kwargs
            )
            return await agenerate_from_stream(stream_iter)
        payload = self._get_request_payload(messages, stop=stop, **kwargs)
        generation_info = None
        if "response_format" in payload:
            if self.include_response_headers:
                warnings.warn(
                    "Cannot currently include response headers when response_format is "
                    "specified."
                )
            payload.pop("stream")
            try:
                response = await self.root_async_client.beta.chat.completions.parse(
                    **payload
                )
            except openai.BadRequestError as e:
                _handle_openai_bad_request(e)
        elif self.include_response_headers:
            raw_response = await self.async_client.with_raw_response.create(**payload)
            response = raw_response.parse()
            generation_info = {"headers": dict(raw_response.headers)}
        else:
            response = await self.async_client.create(**payload)
        return await run_in_executor(
            None, self._create_chat_result, response, generation_info
        )
