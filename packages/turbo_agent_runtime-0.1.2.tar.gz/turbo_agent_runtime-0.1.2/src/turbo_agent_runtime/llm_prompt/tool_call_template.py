import copy
import json
import os
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk,Choice,ChoiceDelta,ChoiceDeltaToolCall,ChoiceDeltaToolCallFunction
from typing import List, Literal, Union,Dict,Iterator,AsyncIterator
from loguru import logger
from .nous_fncall_prompt import extract_fn as common_extract_fn
import uuid

# 创建Tool call初始Chunk

def create_tool_call_chunk(ori_chunk:ChatCompletionChunk,tool_call_index:int,content:str,tool_name:str,args:str,is_init:bool=False):
    new_tool_call_chunk  = ori_chunk.model_copy(deep=True)

    new_tool_call_chunk.choices=[
        Choice(
            delta=ChoiceDelta(
                content=content if content else None,
                tool_calls=[
                    ChoiceDeltaToolCall(
                        index=tool_call_index,
                        id="call-"+str(tool_call_index)+"-"+str(uuid.uuid4()) if is_init else None,
                        function=ChoiceDeltaToolCallFunction(name=tool_name,arguments=args) if is_init else ChoiceDeltaToolCallFunction(arguments=args)
                    )
                ] if tool_call_index>=0 else None
            ),
            index=0
        )
    ]
    # logger.info(f"create_tool_call_chunk: {new_tool_call_chunk}")
    return new_tool_call_chunk

def validate_and_extract(sa, b):
    """
    校验 b 是否与 sa 的结尾一致，并取出 b 中与 sa 一致的最长结尾字符串。

    参数:
        sa (str): 标准字符串。
        b (str): 待校验的字符串。

    返回:
        tuple: (是否通过校验, 最长匹配后缀)
    """
    # 初始化最长匹配后缀为空字符串
    longest_match = ""
    
    # 遍历 sa 的所有后缀，从最长到最短
    for i in range(len(sa)):
        suffix = sa[i:]  # 获取 sa 的后缀
        if b.endswith(suffix):  # 检查 b 是否以该后缀结尾
            longest_match = suffix  # 更新最长匹配后缀
            break  # 找到最长匹配后缀后立即退出循环
    
    # 校验是否通过
    is_valid = bool(longest_match)  # 如果找到匹配后缀，则校验通过
    
    return is_valid, longest_match

# 输出类似 "f47ac10b-58cc-4372-a567-0e02b2c3d479"
class FnCallCommonTemplate:
    def __init__(self):
        self.start_tag = "<tool_call>"
        self.end_tag = "</tool_call>"
        self.xml_prefix = "```xml\n"
        self.xml_prefix_len = len(self.xml_prefix)
        self.xml_suffix = "\n```"
        self.xml_suffix_len = len(self.xml_suffix)
    
    

    async def hijack_stream(self,chunks:AsyncIterator[ChatCompletionChunk]):
        start_tag = self.start_tag
        end_tag = self.end_tag
        xml_prefix = self.xml_prefix
        current_xml_prefix = 0
        current_xml_sufix = 0
        xml_prefix_len = self.xml_prefix_len
        xml_suffix = self.xml_suffix
        xml_suffix_len = self.xml_suffix_len
        filter_xml_wrapper = False  # 标记是否需要过滤XML包裹
        filter_xml_end = False


        in_call_block = False
        call_block_start = -1
        call_block = []
        to_be_pushed = None
        current_tag = start_tag
        current_prefix = 0
        tool_call_index = 0
        tool_call_id = None
        function_name_pushed = False
        arg_beign=False
        pre_arg_block = []

        buffer = []

        async for ori_chunk in chunks:
            if ori_chunk is None:
                break
            # logger.debug(f"ori_chunk: {ori_chunk}")
            if not isinstance(ori_chunk, ChatCompletionChunk):
                logger.debug(f"chunk illegal： {ori_chunk}")
                yield ori_chunk
                continue
            if not ori_chunk.choices or ori_chunk.choices[0].delta.content is None :
            # or len(ori_chunk.choices[0].delta.content)==0 or  ori_chunk.choices[0].delta.reasoning_content is None or len(ori_chunk.choices[0].delta.reasoning_content)==0:
                logger.debug(f"not compatible: {ori_chunk}")
                yield ori_chunk
                continue
            new_chunk = ori_chunk.model_copy(deep=True)
            # if new_chunk.choices[0].delta.reasoning_content:
            #     buffer.extend(list(new_chunk.choices[0].delta.reasoning_content))
            # else:
            buffer.extend(list(new_chunk.choices[0].delta.content))
            output = []
            arg_block = pre_arg_block
            pre_arg_block = []
            i = 0
            while i < len(buffer):
                char = buffer[i]
                if not in_call_block:
                    # 非劫持模式下确认xml tag信息
                    
                    # 处理非劫持模式，匹配开始标记
                    if char == current_tag[current_prefix]:
                        current_prefix += 1
                        i += 1
                        filter_xml_end = False #任意命中说明不是xml 结尾tag
                        if current_xml_sufix>0:
                            output.extend(list(xml_suffix[:current_xml_sufix]))
                            current_xml_sufix = 0

                        if current_prefix == len(current_tag):
                            # 匹配成功，进入劫持模式
                            in_call_block = True
                            # call_block.extend(buffer[i-current_prefix:i])
                            current_tag = end_tag
                            current_prefix = 0
                            print("postion when start hijack:",buffer[:i])
                            if filter_xml_wrapper:
                                filter_xml_wrapper = False
                            elif current_xml_prefix>0:
                                output.extend(list(xml_prefix[:current_xml_prefix]))
                                current_xml_prefix = 0
                    else:
                        if current_prefix > 0:
                            # 匹配失败，将已匹配的部分输出，其余部分插入缓冲区
                            buffer = buffer[i:]
                            if filter_xml_wrapper:
                                #xml tag输出:
                                output.extend(list(xml_prefix)+list(current_tag[:current_prefix]))
                                filter_xml_wrapper= False
                            else:    
                                output.extend(list(current_tag[:current_prefix]))
                            current_prefix = 0
                            filter_xml_end = False #任意命中说明不是xml 结尾tag
                            i = 0
                        else:
                            should_output= True
                            if filter_xml_wrapper:
                                output.extend(list(xml_prefix))
                                filter_xml_wrapper= False
                            if filter_xml_end: #前置</tool_call>结束，检测 是否有xml 结尾tag（仅出现在此条件下）
                                if char == xml_suffix[current_xml_sufix]: #持续匹配则继续
                                    current_xml_sufix+=1
                                    print(f"命中后缀：{xml_suffix[:current_xml_sufix]}")
                                    should_output=False
                                    if current_xml_sufix == len(xml_suffix):
                                        
                                        current_xml_sufix = 0
                                else: #匹配失败则输出
                                    filter_xml_end=False #退出xml结尾tag匹配模式
                                    if current_xml_sufix>0:
                                        output.extend(list(xml_suffix[:current_xml_sufix]))
                                    current_xml_sufix = 0
                                    
                            elif char.lower() == xml_prefix[current_xml_prefix]:
                                current_xml_prefix +=1
                                should_output=False
                                print(f"命中前缀：{xml_prefix[:current_xml_prefix]}")
                                if current_xml_prefix == len(xml_prefix):
                                    filter_xml_wrapper = True #xmltag 启动，xml tag被缓存
                                    current_xml_prefix = 0
                                    # should_output=False
                            # 当前字符不匹配，直接输出
                            else:
                                if current_xml_prefix>0:
                                    output.extend(list(xml_prefix[:current_xml_prefix]))
                                current_xml_prefix = 0
                            if should_output:
                                
                                output.append(char)
                                # print("output 添加新char",output)
                            
                            i += 1
                            
                else:
                    # 处理劫持模式，匹配结束标记, 劫持模式下不考虑xml 标记
                    if char == current_tag[current_prefix]:
                        current_prefix += 1
                        i += 1
                        if current_prefix == len(current_tag):
                            # 匹配成功，退出劫持模式
                            in_call_block = False
                            filter_xml_end = True # 启动xml wrapper 结束标签过滤
                            # call_block.extend(buffer[i-current_prefix:i])
                            #劫持tool chunk尚未创建：
                            if not function_name_pushed:
                                # print("匹配成功，退出劫持模式 创建初始chunk",function_name_pushed,)
                                f_name,f_args = common_extract_fn("".join(call_block))
                                f_args = f_args.strip()[:-1]
                                if f_name:
                                    tool_call_chunk = create_tool_call_chunk(
                                        ori_chunk=ori_chunk,
                                        tool_call_index=tool_call_index,
                                        tool_name=f_name,
                                        args=f_args,
                                        content=None,
                                        is_init=True
                                        )
                                    yield tool_call_chunk
                            elif arg_block :
                                args = "".join(arg_block)
                                x = args.rfind("}")
                                if x>=0:
                                    args=args[:x]
                                if args:
                                    # print("匹配成功，退出劫持模式 创建补充chunk",args,)
                                    #部分劫持参数尚未推送：
                                    tool_call_chunk = create_tool_call_chunk(
                                        ori_chunk=ori_chunk,
                                        tool_call_index=tool_call_index,
                                        tool_name=None,
                                        args=args,
                                        content=None,
                                        is_init=False
                                        )
                                    yield tool_call_chunk


                            #劫持状态重置
                            tool_call_index+=1
                            function_name_pushed = False
                            arg_block = []
                            call_block = []
                            current_tag = start_tag
                            current_prefix = 0
                    else:
                        if current_prefix > 0:
                            # 匹配失败，将已匹配的部分重新插入缓冲区
                            # buffer = list(current_tag[:current_prefix]) + buffer[i:]
                            call_block.extend(current_tag[:current_prefix])
                            if function_name_pushed:
                                arg_block.extend(list(current_tag[:current_prefix]))
                            current_prefix = 0
                            # i += 1
                            # i = 0
                            # continue
                        else:
                            # print("new char in call_block:",char)
                            # 处于劫持模式，当前字符为调用体
                            call_block.append(char)

                            # 处于劫持模式，且已创建tool chunk，其余部分写入参数
                            if function_name_pushed:
                                f_name,f_args = common_extract_fn("".join(call_block))
                                # print("check arg_block","|",f_name,"|", f_args,"|", "".join(arg_block),"|",char )
                                if f_args:
                                    arg_block.append(char)
                                    x= f_args.rfind("".join(arg_block)) 
                                    if x<0:
                                        arg_block.pop()
                                # print("final arg_block","|",f_name,"|", f_args, "|","".join(arg_block),"|",char )
                                    
                            i += 1

                        #劫持模式下，如工具名未确定，则校验工具名：
                        if not function_name_pushed:
                            f_name,f_args = common_extract_fn("".join(call_block))
                            # print(f_name, f_args)
                            #劫持模式下，如工具名确定，则创建初始tool chunk：
                            if f_name:
                                # print(tool_call_index,f_name,f_args)
                                #劫持模式下，此时工具名已确定，之前生成参数体一次性准备输出：
                                tool_call_init_chunk = create_tool_call_chunk(
                                    ori_chunk=ori_chunk,
                                    tool_call_index=tool_call_index,
                                    tool_name=f_name,
                                    args=f_args,
                                    content=None,
                                    is_init=True
                                    )
                                yield tool_call_init_chunk
                                function_name_pushed = True
                        
            # 处理剩余缓冲区
            buffer = buffer[i:]
            
            # 处理剩余前缀
            # if current_prefix > 0:
            buffer = list(xml_prefix[:current_xml_prefix])+list(current_tag[:current_prefix]) +list(xml_suffix[:current_xml_sufix])+ buffer
            current_prefix = 0
            current_xml_prefix = 0
            current_xml_sufix=0
            # print(buffer)
            # 发送输出
            if output or arg_block:
                if in_call_block and function_name_pushed and arg_block:
                    args = "".join(arg_block)
                    x = args.rfind("}")
                    if x>=0:
                        pre_arg_block = list(args[x:])
                        args=args[:x]
                        
                    # print("创建补充chunk",args,)
                    if args:
                        new_chunk = create_tool_call_chunk(
                            ori_chunk=ori_chunk,
                            tool_call_index=tool_call_index if in_call_block and function_name_pushed else -1,
                            tool_name=None,
                            args=args if args else None,
                            content="".join(output) if output else None
                        )
                        yield new_chunk
                else:
                    # print("仅content输出：","".join(output),)
                    new_chunk = create_tool_call_chunk(
                        ori_chunk=ori_chunk,
                        tool_call_index= -1,
                        tool_name=None,
                        args= None,
                        content="".join(output) if output else None
                    )
                    yield new_chunk

# 示例用法
if __name__ == "__main__":
    
    def yeild_samples():
        inputs = [
            "我需要了解天气情况。<abc_call> 今天天气晴朗。</abc_call> 晴朗 <abc_call> 今天天气晴朗2。</abc_call> ",
            "我需要了解天气情况。<ab",
        "c_call> 今天天气晴朗。",
        "另一个测试<abcd>。",
        "可能的前缀</ab",
        "cd>未命中。",
        "命中前缀<abc_call>被过滤。",
        "</abc_call>结束",
        ]
        for inp in inputs:
            print(f"输入: {inp!r} → ")
            yield inp
    

