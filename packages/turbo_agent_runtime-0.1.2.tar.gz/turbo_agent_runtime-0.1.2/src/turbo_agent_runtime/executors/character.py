from __future__ import annotations

from typing import AsyncIterator, Iterator, Optional, List, Union
from loguru import logger
from pydantic import Field

from turbo_agent_core.schema.events import (
    BaseEvent,
)
from turbo_agent_core.schema.agents import Character, APITool, LLMTool, AgentTool, Tool
from turbo_agent_core.schema.states import Conversation, Message, MessageRole

from turbo_agent_runtime.utils.executor_identity import build_executor_id
from .agent import AgentRuntime

class CharacterRuntime(Character):
    tools: List[Union[APITool, LLMTool, AgentTool, Tool]] = Field(default_factory=list)

    def run(self, input: Conversation, **kwargs) -> Message:
        """
        Character 运行时：构造 Agent -> 代理执行。
        要求：仅接受 Conversation；
        """
        agent = AgentRuntime(
            id=self.id,
            name=self.name,
            name_id=self.name_id,
            belongToProjectId=self.belongToProjectId,
            model=self.model,
            modelParameter=self.modelParameter,
            setting=self.setting,
            tools=self.tools or []
        )
        
        return agent.run(input, **kwargs)

    def stream(self, input: Conversation, **kwargs) -> Iterator[BaseEvent]:
        """
        同步流式：仅接受 Conversation；事件直接透传。
        """
        agent = AgentRuntime(
            id=self.id,
            name=self.name,
            name_id=self.name_id,
            belongToProjectId=self.belongToProjectId,
            model=self.model,
            modelParameter=self.modelParameter,
            setting=self.setting,
            tools=self.tools or []
        )
        
        inner_executor_id = build_executor_id(agent, agent.run_type)
        outer_executor_id = build_executor_id(self, self.run_type)

        # 直接透传底层 Agent 的事件
        for event in agent.stream(input, **kwargs):
            # Patch identity to ensure consistency
            if event.executor_id == inner_executor_id:
                event.executor_id = outer_executor_id
                event.executor_type = self.run_type
            
            if event.executor_path:
                event.executor_path = [
                    outer_executor_id if x == inner_executor_id else x 
                    for x in event.executor_path
                ]

            # Character 只是 Agent 的一层壳，但为了保持 Character 的身份，
            # 我们需要拦截 run.lifecycle created 事件，并替换 executor_metadata
            if event.type == "run.lifecycle.created":
                if event.executor_metadata:
                    # 覆盖为 Character 的元数据
                    event.executor_metadata.id = self.id
                    event.executor_metadata.name = self.name
                    event.executor_metadata.name_id = self.name_id
                    event.executor_metadata.description = self.description
                    event.executor_metadata.avatar_uri = self.avatar_uri
                    event.executor_metadata.run_type = self.run_type
                    event.executor_metadata.version_id = self.version_id
                    event.executor_metadata.version = self.version_tag
                
                # 同时也修正 executor_type
                event.executor_type = self.run_type
            
            yield event

    async def a_run(self, input: Conversation, **kwargs) -> Message:
        agent = AgentRuntime(
            id=self.id,
            name=self.name,
            name_id=self.name_id,
            belongToProjectId=self.belongToProjectId,
            model=self.model,
            modelParameter=self.modelParameter,
            setting=self.setting,
            tools=self.tools or []
        )
        
        return await agent.a_run(input, **kwargs)

    async def a_stream(self, input: Conversation, **kwargs) -> AsyncIterator[BaseEvent]:
        """
        异步流式：仅接受 Conversation；事件直接透传。
        """
        agent = AgentRuntime(
            id=self.id,
            name=self.name,
            name_id=self.name_id,
            belongToProjectId=self.belongToProjectId,
            model=self.model,
            modelParameter=self.modelParameter,
            setting=self.setting,
            tools=self.tools or []
        )
        
        inner_executor_id = build_executor_id(agent, agent.run_type)
        outer_executor_id = build_executor_id(self, self.run_type)

        async for event in agent.a_stream(input, **kwargs):
            # Patch identity to ensure consistency
            if event.executor_id == inner_executor_id:
                event.executor_id = outer_executor_id
                event.executor_type = self.run_type
            
            if event.executor_path:
                event.executor_path = [
                    outer_executor_id if x == inner_executor_id else x 
                    for x in event.executor_path
                ]

            # Character 只是 Agent 的一层壳，但为了保持 Character 的身份，
            # 我们需要拦截 run.lifecycle created 事件，并替换 executor_metadata
            if event.type == "run.lifecycle.created":
                if event.executor_metadata:
                    # 覆盖为 Character 的元数据
                    event.executor_metadata.id = self.id
                    event.executor_metadata.name = self.name
                    event.executor_metadata.name_id = self.name_id
                    event.executor_metadata.description = self.description
                    event.executor_metadata.avatar_uri = self.avatar_uri
                    event.executor_metadata.run_type = self.run_type
                    event.executor_metadata.version_id = self.version_id
                    event.executor_metadata.version = self.version_tag
                
                # 同时也修正 executor_type
                event.executor_type = self.run_type
            
            yield event
