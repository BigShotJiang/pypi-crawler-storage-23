from __future__ import annotations

# This file is deprecated and will be removed in future versions.
# EntityRuntime registry pattern is replaced by direct inheritance and patching.
# See turbo_agent_runtime.utils.patch for details.

# from .context import ExecutionContext

__all__ = []
