# import json
# from loguru import logger
# from litellm import acompletion 
# from turbo_agent.config import settings
# from litellm import acompletion, completion_cost 
# from prisma.models import Model
# from typing import cast, Any, Literal
# import re

# async def parse_tool_summary_result(result:str,output_schema_str:str):
#     logger.debug(f"parsing tool_summary_result: {result}")
    
#     # 移除 <think> </think> 标签及其包含的内容
#     result = re.sub(r'<think>.*?</think>', '', result, flags=re.DOTALL)
#     logger.debug(f"result after removing think tags: {result}")
    
#     begin = result.find("```json")
#     end = result.rfind("```")
#     try:
#         if begin >=0:
#             output_raw = result[begin+7:end]
#             output_raw = output_raw.replace("\" \"","\"")
#             final_result =  json.loads(output_raw, strict=False)
#         else:
#             final_result = json.loads(result, strict=False)
#     except json.JSONDecodeError as e:
#         logger.error(f"JSON decode error: {e}")
        
#         try:
#             await correct_json_by_llm(output_schema_str, result, str(e))
#         except Exception as e2:
#             logger.error(f"二次纠正JSON格式错误失败: {e2}")
#             logger.error(f"JSON格式错误: {output_raw} {result}")
#         return {"error": str(e)}
#     return final_result

# async def summary_knowledge_tool(model:Model,task_instruction: str,mark_down_content:str) -> str:
#     """
#     Summarize the knowledge content into a JSON format.
#     """
#     if len(model.instances) <=0:
#         return None
    
#     instance = model.instances[0]
#     model_id = model.version_id
#     if instance.request_model_id:
#         model_id = instance.request_model_id
#     endpoint = instance.endpoint
#     logger.info(f"selected model: {model_id}, base_url:{endpoint.url}, api_key:{endpoint.accessKeyOrToken}")
#     output_schema_str="""
#         {
#         "report" : string, （基于文档内容，对用户需求响应形成的报告）
#             "refer_origin_segs": list[string] (报告中所引用的的重要原文内容片段)
#         }
#        """
#     # 构造大模型对话输入
#     system_prompt = """你是一个智能助手，专注于对文档内容进行整理。根据用户提供的阅读需要，返回满足用户需要的报告，以及相关重要的原文内容. json结构如下：
#     {
#         "report" : string, （基于文档内容，对用户需求响应形成的报告）
#         "refer_origin_segs": list[string] (报告中所引用的的重要原文内容片段)
#     }。
#     注意：只需要返回json结果，不要包含任何其他信息， refer_origin_segs中的文本片段必须与原文一致！！！！
#     """
#     is_broken = ""
#     if len(mark_down_content) > 20192:
#         is_broken = ".......(数据过大，后续部分省略)...."
#         mark_down_content = mark_down_content[:20192]

#     summary_prompt = f"本次阅读原文内容如下：\n-------原文开始-------"
#     summary_prompt += f"{mark_down_content}\n{is_broken}\n"
#     summary_prompt += f"""------- 原文结束----- \
#     请基于以上文档内容,按照以下要求生成最终结果的.json文件 \
#     内容要求如下：\
#     {task_instruction}\
    
#     输出格式要求如下:
#     {{
#         "report" : string, （基于文档内容，对用户需求响应形成的报告）
#         "refer_origin_segs": list[string] (报告中所引用的的重要原文内容片段)
#     }}。
#     注意：只需要返回json结果，不要包含任何其他信息， refer_origin_segs中的文本片段必须与原文一致！！！
#     """

#     response = await acompletion(
#         model=f"openai/{model_id}",  # add `openai/` prefix to model so litellm knows to route to OpenAI
#         api_key=endpoint.accessKeyOrToken,
#         api_base=endpoint.url,
#         messages=[
#             {
#                 "role": "system",
#                 "content": system_prompt
#             },
#             {
#                 "role": "user",
#                 "content": summary_prompt
#             }
#         ],
#         temperature=0.1
#         # max_tokens=8192
#     )
#     final_content = ""
#     if response.choices:
#         final_content =  response.choices[0].message.content

#         logger.info(f"大模型概要结果: {final_content}")

#         summary_data = await parse_tool_summary_result(final_content,output_schema_str)
#         result = {
#             "notice": "数据过大，已进行压缩概况。",
#             "report": summary_data.get("report", "概要"),
#             "refer_origin_segs": summary_data.get("refer_origin_segs", "无概要")
#         }
#         return result
#     else:
#         logger.warning("大模型概要结果为空")
#         return {
#             "notice": "大模型概要结果为空",
#             "summary": "无概要",
#             "refer_origin_segs": "无概要"
#         }



# async def summary_tool(model:Model,parameters:ModelParameters, show_name: str, task_instruction: str, tool_args: dict[str, Any], result: dict[str, Any]) -> str:
#     """
#     Summarize the tool call result into a JSON format.
#     """
#     if len(model.instances) <=0:
#         return None
    
#     instance = model.instances[0]
#     model_id = model.version_id
#     if instance.request_model_id:
#         model_id = instance.request_model_id
    
#     endpoint = instance.endpoint
#     logger.info(f"selected model: {model_id}, base_url:{endpoint.url}, api_key:{endpoint.accessKeyOrToken}")

#     # 构造大模型对话输入
#     system_prompt = """你是一个智能助手，专注于对工具调用情况进行记录。根据用户提供的工具名称、调用参数、调用目标和返回结果，生成调用情况概况的json 结果. json结构如下：
#     {
#         "title" : string, （调用记录标题，一句话描述通过使用什么工具完成了什么任务，结果如何）
#         "content": string (工具返回结果概要。根据描述工具的调用目标，对工具的返回结果结果的内容进行概括，如果没有特殊要求，内容应当尽可能压缩到1000字以内。)
#     }。
#     注意：只需要返回json结果，不要包含任何其他信息。
#     """
    
#     summary_prompt = f"本次调用情况如下：\n使用工具名称: {model.name} \n 输入参数：{json.dumps(tool_args, ensure_ascii=False)} \n 工具调用目标: {task_instruction or '无'}\n"
#     tool_result = json.dumps(result, ensure_ascii=False)
    
#     is_broken = ""
#     if len(tool_result) > 20192:
#         is_broken = "数据过大，后续部分省略。"
#         tool_result = tool_result[:20192]
#     output_schema_str = f"""
#         {{
#             "tool_use_title" : string, //调用记录标题
#             "tool_result_summary": string //本字段包含对工具返回的结果进行汇总。
#         }}
#     """

#     # 构造大模型对话输入
#     system_prompt = f"""你是一个智能助手，专注于对工具调用情况进行记录。根据用户提供的工具名称、调用参数、调用目标和返回结果，生成调用情况概况的json 结果. json结构如下：\n 
#     {{
#         "tool_use_title" : string, //调用记录标题，一句话描述通过使用什么工具完成了什么任务，结果如何
#         "tool_result_summary": string //本字段包含对工具返回的所有结果进行汇总，形成一份markdown报告，以满足工具调用目标：{task_instruction or '无'}的要求。如果没有特殊要求，内容应当尽可能压缩到2000字以内。
#     }}。 
#     注意：只需要返回json结果，不要包含任何其他信息。
#     """
#     summary_prompt = f"本次调用情况如下：\n使用工具名称: {show_name} \n 输入参数：{json.dumps(tool_args,ensure_ascii=False)} \n"
#     summary_prompt += f"工具返回结果如下: \n {tool_result}\n{is_broken}\n"
#     summary_prompt += f"""-------  
#     请基于以调用信息生成最终结果.json 格式如下:
#     {{
#         "tool_use_title" : string, 调用记录标题，一句话描述通过使用什么工具完成了什么任务，结果如何
#         "tool_result_summary": string 本字段包含对工具返回的所有结果进行汇总，形成一份markdown报告，以满足工具调用目标：{task_instruction or '无'}的要求。如果没有特殊要求，内容应当尽可能压缩到2000字以内。
#     }}。
#     """
#     response = await acompletion(
#         model=f"openai/{model_id}",  # add `openai/` prefix to model so litellm knows to route to OpenAI
#         api_key=endpoint.accessKeyOrToken,
#         api_base=endpoint.url,
#         messages=[
#             {
#                 "role": "system",
#                 "content": system_prompt
#             },
#             {
#                 "role": "user",
#                 "content": summary_prompt
#             }
#         ],
#         temperature=0.1
#         # max_tokens=4096
#     )
#     final_content = ""
#     if response.choices:
#         final_content =  response.choices[0].message.content

#         logger.info(f"大模型概要结果: {final_content}")

#         summary_data = await parse_tool_summary_result(final_content,output_schema_str)
#         result = {
#             "notice": "数据过大，已进行压缩概况。",
#             "summary_title": summary_data.get("tool_use_title", "概要"),
#             "summary_content": summary_data.get("tool_result_summary", summary_data.get("tool_reult_summary", "无概要"))
#         }
#         return result
#     else:
#         logger.warning("大模型概要结果为空")
#         return {
#             "notice": "大模型概要结果为空",
#             "summary_title": "无概要",
#             "summary_content": "无概要"
#         }


# async def correct_json_by_llm(output_schema_str:str,result_str: str,err:str) -> str:
#     """
#     使用LLM纠正JSON格式错误
#     :param result_str: 需要纠正的JSON字符串
#     :return: 纠正后的JSON字符串
#     """
#     if output_schema_str:
#         messages = [
#             {
#                 "role": "system",
#                 "content": "你是一个JSON格式校验和修正助手，请帮助用户修正JSON格式错误"
#             },
#             {
#                 "role": "user",
#                 "content": f"以下是预期的输出schema：\n{output_schema_str}\n\n以下错误的json格式数据：\n{result_str} \n\n json.loads报错：{err}\n请基于预期的输出schema和格式错误的json数据，生成符合预期的JSON格式数据。请注意，输出的JSON必须符合预期的输出schema，并且不能包含任何额外的注释或说明。"
#             }
#         ]
#     else:
#         messages = [
#             {
#                 "role": "system",
#                 "content": "你是一个JSON格式校验和修正助手，请帮助用户修正JSON格式错误"
#             },
#             {
#                 "role": "user",
#                 "content": f"以下错误的json格式数据：\n{result_str}\n\n请基于该错误数据生成正确的JSON格式数据，并且不能包含任何额外的注释或说明。"
#             }
#         ]
#     response = await acompletion(
#         model=f"openai/{settings.JSON_CHECK_MODEL}",  # add `openai/` prefix to model so litellm knows to route to OpenAI
#         api_key=settings.JSON_CHECK_MODEL_API_KEY,
#         api_base=settings.JSON_CHECK_MODEL_API_URL,
#         messages=messages,
#         temperature=0.1
#         # max_tokens=8192
#     )
#     if response.choices:
#         return response.choices[0].message.content
#     else:
#         raise ValueError("二次校验LLM未返回任何结果，无法纠正JSON格式错误。请检查模型配置或输入数据。")
