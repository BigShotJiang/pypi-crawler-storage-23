# import jinja2
# from prisma.partials import ToolForRun
# from prisma.models import BusinessSetting,Model,ModelInstance
# from turbo_agent.utils.schema_tool import json_schema_to_pydantic_model,json_schema_to_signature
# from pydantic import ValidationError
# from litellm import acompletion, completion_cost 
# from turbo_agent.config import settings
# from turbo_agent.db.agents import get_available_instances,get_model_instance
# import json
# import re
# from loguru import logger

# async def construct_tool_runner(tool:ToolForRun,user_id:str):
#     instances=await get_available_instances(model_id=tool.defaultVersion.modelId,project_id=tool.belongToProjectId,user_id=user_id)
#     return LLMFunction(tool,instances[0])


# def parameters_to_prompt(parameters, depth=1):
#     if len(parameters)<=0:
#         return "无"
#     indent = "  ".join(["" for i in range(0,depth)])
#     param_descs = []
#     for param in parameters:
#         required =  "必填" if param.get("required", False) else "非必填"

#         param_desc=indent+str(param["id"])+". "+param["name"]+": "+param["type"]+", （"+required+"。"+param["description"]+"。"
#         if param["type"] == "object" :
#             param_desc+="该参数为对象类型，其属性及含义如下：\n "+parameters_to_prompt(parameters=param["parameters"],depth=depth+1)
#         elif param["type"] == "array" and param["type_ref"]=="object":
#             param_desc+="该参数为数组类型，其元素包含如下字段：\n "+parameters_to_prompt(parameters=param["parameters"],depth=depth+1)
#         elif param["type"] == "array" and param["type_ref"]=="enum":
#             param_desc+="该参数为数组类型，其元素为枚举类型，具体可选枚举值如下：\n ["+", ".join(param["enum_values"])+"]"
#         elif param["type"] == "array" :
#             param_desc+="该参数为数组类型，其元素均为\""+param["type_ref"]+"\"类型。"
#         elif param["type"] == "enum":
#             param_desc+="该参数为枚举类型，其枚举值如下：\n ["+", ".join(param["enum_values"])+"]"
#         else:
#             param_desc += "默认值为："+param["default"] if param["default"] else ""

#         param_desc+= "）"
#         param_descs.append(param_desc)
#     return "\n".join(param_descs)
    

        


# class LLMFunction:
#     def __init__(self,tool:ToolForRun,modelInstance:ModelInstance):
#         input_schema = tool.defaultVersion.input_schema
#         output_schema = tool.defaultVersion.output_schema
#         if not tool.defaultVersion.output_schema:
#             raise Exception(f"output_schema is not defined for tool {tool.name} version: {tool.defaultVersion.version_id}. an output parameter must be set")
#         # logger.info(f"tool.defaultVersion.input_schema: {input_schema}")
#         # logger.info(f"tool.defaultVersion.output_schema: {output_schema}")
#         self.model_parameters = tool.defaultVersion.modelParameter
#         self.model = tool.defaultModel
#         self.input_schema = input_schema
#         self.output_schema = output_schema
        
#         self.input_model = json_schema_to_pydantic_model(input_schema)
#         self.output_model = json_schema_to_pydantic_model(output_schema)
#         self.instance = modelInstance
#         self.endpoint = self.instance.endpoint
#         self.request_model_id = self.instance.request_model_id
#         self.api_url = self.endpoint.url
#         self.api_key = self.endpoint.accessKeyOrToken
#         self.func_name = tool.name_en
#         self.param_list =[]
#         self.__chuncks =[]
#         # logger.info(f"tool.defaultVersion: {tool.defaultVersion}")
#         if len(tool.defaultVersion.input)>0:
#             tool.defaultVersion.input.sort(key=lambda x: x["idx"])
#             self.param_list = [input["name"] for input in tool.defaultVersion.input]
#         self.__construct_template(tool)
#         # logger.info(f"self.__business_template: {self.__business_template}")
    
#     def get_input_schema(self):
#         return self.input_schema

#     def get_output_schema(self):
#         return self.output_schema
    
    
#     def __construct_input(self,**kwargs):
#         input_str = ""
#         para_strs = []
#         for name in self.param_list:
#             value = kwargs.get(name,None)
#             para_strs.append(json.dumps(value,ensure_ascii=False))
#         input_str = ",".join(para_strs) 
#         return f"""{self.func_name}({input_str})"""
        

#     def __construct_template(self,tool:ToolForRun):
#         input_schema_str = json.dumps(tool.defaultVersion.input_schema,ensure_ascii=False,) if tool.defaultVersion.input_schema else "无输入"
#         output_schema_str = json.dumps(tool.defaultVersion.output_schema,ensure_ascii=False,) if tool.defaultVersion.output_schema else ""
#         input_name_list_str = ""
#         if len(self.param_list)>0:
#             input_name_list_str = ",".join(self.param_list)
        
#         setting:BusinessSetting = tool.defaultVersion.setting
#         input_desc = ""
#         if len(tool.defaultVersion.input)>0:
#             input_desc= "我提供给你的输入参数含义如下：\n"+parameters_to_prompt(tool.defaultVersion.input,depth=4)
        
#         output_desc = parameters_to_prompt(tool.defaultVersion.output,depth=4)

#         rules_prompt = ""
#         if setting.business_rules:
#             setting.business_rules.sort(key=lambda x: x.index)
#             rules = [f"规则{rule.index}: {rule.content}" for rule in setting.business_rules]
#             rule_str = "\n".join(rules)
#             rules_prompt = f"""
#             在完成以本任务的过程中同时也一定要注意遵守以下行为规则：
#             {rule_str}
#             """
#         self.__business_template = f"""
# 你好，希望你一切都好。我正在寻求你的帮助，想要解决一个特定的功能。我知道你有处理信息和执行各种任务的能力，这是基于提供的指示。为了帮助你更容易地理解我的请求，我将使用一个模板来描述函数、输入数据schema和对输入的处理方法,其中输入输出的格式与含义使用json schema表示。请在下面找到详细信息：
#         function_name：[{tool.name_en}]
#         input：[{input_name_list_str}]
#         rule：[
#             函数输入格式是:
#             {tool.name_en}({input_name_list_str})。
#             {input_desc}

#                 我需要你作为一个功能函数的任务核心目标描述如下：
#             {setting.business_logic}
#             {rules_prompt}

#             请以JSON形式输出最终结果，不需要要提供任何额外注释和说明，具体输出结果的应该包含的字段名称、类型要求及含义请遵循以下结构:
#             {output_desc}
#         ]
# -----------------------------------------------------------------
# 我恳请你根据我提供的细节为这个函数提供输出。非常感谢你的帮助！谢谢！
# 我将使用方括号内的相关信息替换函数所需执行的内容。这个详细的介绍应该能够帮助你更高效地理解我的请求并提供所需的输出。
# 以上是对需求的全部描述，如果你理解了，请仅用一个词"OK"回答。
# """
#     def add_buffer(self,chunck):
#         self.__chuncks.append(chunck)
    
#     def get_buffer(self,chunck):
#         return self.__chuncks

#     async def __call__(self, *args, **kwargs):
#         try:
#             self.input_model(**kwargs)
#         except ValidationError as e:
#             raise ValueError(f"输入验证失败: {e}")
#         # 当实例被调用时执行此方法
#         self.__chuncks = []
#         messages = self.__construct_messages(**kwargs)
#         temperature=self.model_parameters["temperature"]
#         logger.debug(f"constructed messages: {json.dumps(messages,ensure_ascii=False)}")
#         logger.info(f"requesting model: {self.request_model_id}, url: {self.api_url}")
#         response =await acompletion(
#             model=f"openai/{self.request_model_id}",               # add `openai/` prefix to model so litellm knows to route to OpenAI
#             api_key=self.api_key,                  # api key to your openai compatible endpoint
#             api_base=self.api_url,     # set API Base of your Custom OpenAI Endpoint
#             messages=messages,
#             # temperature=temperature,
#             # input_cost_per_token=0.005,
#             # output_cost_per_token=1,
#             timeout=300
#         )
#         # cost = completion_cost(completion_response=response)
#         # logger.info("cost:"+str(cost))
#         output = None
#         if response.choices:
#             response_text = response.choices[0].message.content
#             # response_text = response_text.replace("```json","```json\nfdsaf")
#             output = await self.__parse_result(response_text)
#             logger.info(f"parsed output_model: {self.output_model.model_json_schema()}")
#             try:
#                 self.output_model(**output)
#             except Exception as e:
#                 logger.error(f"输出验证失败: {e}")
#                 raise ValueError(f"输入验证失败: {e}")
        
#         return output

#     def __construct_messages(self,**kwargs):
#         # 输入验证
#         input_message = self.__construct_input(**kwargs)
#         messages = [
#             {
#                 "role":"system",
#                 "content":"你是一个乐于助人的助手，请尽全力帮助用户完成他需要你帮助他完成的功能"
#             },
#             {
#                 "role":"user",
#                 "content":self.__business_template
#             },
#             {
#                 "role":"assistant",
#                 "content":"OK"
#             },
#             {
#                 "role":"user",
#                 "content":input_message
#             }
#         ]
#         return messages
#     def construct_knowledges(self):
#         pass

#     def constuct_exmaples(self):
#         """ {{#if setting.examples}}
#     下面是一些执行该过程函数的输入输出样例样例，供你参考。
#     {{#each setting.examples}}

#     函数输入：{{{this.input}}}
#     函数输出：{{{this.output}}}"""
#         pass

#     async def __correct_json_by_llm(self, result_str: str, error_message: str) -> str:
#         """
#         使用LLM纠正JSON格式错误
#         :param result_str: 需要纠正的JSON字符串
#         :param error_message: 错误信息
#         :return: 纠正后的JSON字符串
#         """
#         output_schema_str = json.dumps(self.output_schema,ensure_ascii=False,) if self.output_schema else None
#         if output_schema_str:
#             messages = [
#                 {
#                     "role": "system",
#                     "content": "你是一个JSON格式校验和修正助手，请帮助用户修正JSON格式错误"
#                 },
#                 {
#                     "role": "user",
#                     "content": f"以下是预期的输出schema：\n{output_schema_str}\n\n以下错误的json格式数据：\n{result_str} \n\n 格式错误原因是：{error_message} \n\n请基于预期的输出schema和格式错误的json数据，生成符合预期的JSON格式数据。请注意，输出的JSON必须符合预期的输出schema，并且不能包含任何额外的注释或说明。"
#                 }
#             ]
#         else:
#             messages = [
#                 {
#                     "role": "system",
#                     "content": "你是一个JSON格式校验和修正助手，请帮助用户修正JSON格式错误"
#                 },
#                 {
#                     "role": "user",
#                     "content": f"以下错误的json格式数据：\n{result_str}\n\n请基于该错误数据生成正确的JSON格式数据，并且不能包含任何额外的注释或说明。"
#                 }
#             ]
#         response = await acompletion(
#             model=f"openai/{settings.JSON_CHECK_MODEL}",  # add `openai/` prefix to model so litellm knows to route to OpenAI
#             api_key=settings.JSON_CHECK_MODEL_API_KEY,
#             api_base=settings.JSON_CHECK_MODEL_API_URL,
#             messages=messages,
#             temperature=0.1
#         )
#         if response.choices:
#             return response.choices[0].message.content
#         else:
#             raise ValueError("二次校验LLM未返回任何结果，无法纠正JSON格式错误。请检查模型配置或输入数据。")

#     async def __parse_result(self,result:str,is_nested=False):
#         logger.debug(f"parsing result: {result}")
        
#         # 移除 <think> </think> 标签及其包含的内容
#         logger.debug(f"result before removing think tags: \n-----------------\n{result}\n-------------------\n")
#         result = re.sub(r'<think>.*?</think>', '', result, flags=re.DOTALL)
#         logger.debug(f"result after removing think tags: {result}")
        
#         begin = result.find("```json")
#         end = result.rfind("```")
#         output_raw = result
#         try:
#             if begin >=0:
#                 output_raw = result[begin+7:end]
#                 output_raw = output_raw.replace("\" \"","\"")
#                 final_result =  json.loads(output_raw, strict=False)
#             else:
#                 final_result = json.loads(result, strict=False)
#             self.output_model(**final_result)
#         except Exception as e:
#             logger.error(f"JSON decode error: {e}")
#             logger.error(f"JSON格式错误: {output_raw} {result}")
#             # 处理 JSON 解码错误
#             if is_nested:
#                 raise ValueError(f"无法再次解析JSON结果: {result}")
#             else:
#                 logger.warning("尝试使用LLM纠正JSON格式错误")
#                 # 使用 LLM 纠正 JSON 格式错误  
#                 result = await self.__correct_json_by_llm(result,str(e))
#                 logger.info(f"纠正后的结果: {result}")
#                 # 尝试再次解析为嵌套JSON
#                 final_result = await self.__parse_result(result, is_nested=True)
#         return final_result
