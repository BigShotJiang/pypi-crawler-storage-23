from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain.prompts import PromptTemplate
from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from litellm import acompletion, completion_cost 
from langchain_litellm import ChatLiteLLM
# Chunker 类用于将文本分块并可选地为每个分块生成上下文摘要
class Chunker:
    def __init__(self, model_id=None, base_url=None, api_key=None, summarize=True, mock=False):
        """
        初始化 Chunker
        :param model_id: LLM 模型 ID
        :param base_url: LLM 服务基础 URL
        :param api_key: LLM API 密钥
        :param summarize: 是否对上下文进行摘要
        :param mock: 是否使用 mock 摘要（用于测试）
        """
        self.model_id = model_id
        self.base_url = base_url
        self.api_key = api_key
        self.summarize = summarize
        self.mock = mock
        self.llm = self._init_llm() if summarize and not mock else None

    def _init_llm(self):
        """
        初始化 LLM，使用 litellm 作为大模型聊天后端
        """
        return ChatLiteLLM(
            model=self.model_id or "gpt-3.5-turbo",  # 默认模型
            base_url=self.base_url,
            api_key=self.api_key,
            temperature=0.1,
            max_tokens=250,
        )

    def chunk_markdown(self, markdown_text, chunk_size=500, chunk_overlap=50, window_size=1):
        """
        将 markdown 文本分块，并为每个分块生成上下文摘要或原始上下文
        :param markdown_text: 输入的 markdown 文本
        :param chunk_size: 每个分块的最大字符数
        :param chunk_overlap: 分块之间的重叠字符数
        :param window_size: 上下文窗口大小
        :return: 包含上下文信息的 Document 列表
        """
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n", "\n", ".", " ", ""]
        )
        base_chunks = splitter.split_text(markdown_text)
        enriched_documents = []

        if self.summarize and not self.mock:
            # 构建摘要提示模板
            summary_prompt = PromptTemplate.from_template(
                "Provide a brief summary of the following text:\n\n{text}\n\nSummary:"
            )
            summary_chain = LLMChain(llm=self.llm, prompt=summary_prompt)
            combine_documents_chain = StuffDocumentsChain(
                llm_chain=summary_chain,
                document_variable_name="text"
            )

        for i, chunk in enumerate(base_chunks):
            # 计算当前分块的上下文窗口
            window_start = max(0, i - window_size)
            window_end = min(len(base_chunks), i + window_size + 1)
            window = base_chunks[window_start:window_end]
            context_chunks = [c for j, c in enumerate(window) if j != i - window_start]
            context_text = " ".join(context_chunks)
            metadata = {
                "chunk_id": i,
                "total_chunks": len(base_chunks),
                "chunk_size": len(chunk),
                "window_start_idx": window_start,
                "window_end_idx": window_end - 1,
                "has_context": len(context_chunks) > 0
            }

            if context_chunks and self.summarize:
                try:
                    if self.mock:
                        # mock 模式下直接截取部分文本作为摘要
                        context_summary = f"Summary: {context_text[:100]}..."
                    else:
                        # 使用 LLM 生成上下文摘要
                        context_docs = [Document(page_content=context_text)]
                        context_summary = combine_documents_chain.invoke(context_docs)
                    metadata["context"] = context_summary
                    metadata["context_type"] = "summary"
                    enriched_text = f"Context: {context_summary}\n\nContent: {chunk}"
                except Exception as e:
                    # 摘要失败时，直接使用原始上下文
                    metadata["context"] = context_text
                    metadata["context_type"] = "raw_text"
                    metadata["summary_error"] = str(e)
                    enriched_text = f"Context: {context_text}\n\nContent: {chunk}"
            elif context_chunks:
                # 仅有原始上下文，无摘要
                metadata["context"] = context_text
                metadata["context_type"] = "raw_text"
                enriched_text = f"Context: {context_text}\n\nContent: {chunk}"
            else:
                # 没有上下文
                metadata["context"] = ""
                metadata["context_type"] = "none"
                enriched_text = chunk

            doc = Document(page_content=enriched_text, metadata=metadata)
            enriched_documents.append(doc)
        return enriched_documents