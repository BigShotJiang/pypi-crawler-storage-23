# # -*- coding: utf-8 -*-
# import os
# import json
# from prisma.models import BusinessSetting,Model,ModelInstance
# from prisma.enums import RequestMethod,ToolCallStatus
# import requests

# from turbo_agent.llm_prompt.basic import NamedTool
# from turbo_agent.db.records import create_tool_call_records,update_tool_call_records
# from turbo_agent.utils.parse_url import build_query_string
# from prisma.partials import AgentForChat,CharacterForChat,ToolForRun
# from turbo_agent.utils.schema_tool import json_schema_to_pydantic_model,json_schema_to_signature
# # from utils.timer import timing_decorator
# from loguru import logger
# # from dspy import Predict,Example,ChainOfThought,asyncify
# from pydantic import ValidationError
# from turbo_agent.tool.schema import ToolRunResult
# from turbo_agent.rag.schema import ToolRecordChunk,ToolVersionInfo,AgentInfo,ChunkFieldType
# from turbo_agent.rag.init_index_manticore import index_action_record
# import httpx
# from httpx import RequestError, HTTPStatusError, ProxyError as HttpxProxyError
# import copy
# import time
# from turbo_agent.tool.tool_template import construct_tool_runner

# try:
#     import requests
#     from requests_oauthlib import OAuth1 as RequestsOAuth1
#     _REQUESTS_AVAILABLE = True
#     _REQUESTS_OAUTH1_AVAILABLE = True
# except ImportError:
#     requests = None
#     RequestsOAuth1 = None
#     _REQUESTS_AVAILABLE = False
#     _REQUESTS_OAUTH1_AVAILABLE = False

# class NetworkError(Exception):
#     """网络相关错误基类"""
#     pass

# class ConnectionFailedError(NetworkError):
#     """连接失败（如DNS解析失败、服务器不可达）"""
#     pass

# class TimeoutError(NetworkError):
#     """请求超时（连接超时或读取超时）"""
#     pass

# class HTTPError(NetworkError):
#     """HTTP 状态码错误（非2xx响应）"""
#     def __init__(self, status_code, message):
#         self.status_code = status_code
#         super().__init__(message)

# class ProxyError(NetworkError):
#     """代理配置或连接异常"""
#     pass

# def tool_decorator(func,):
#     def wrapper(*args, **kwargs):
#         start = time.time()
#         result = func(*args, **kwargs)
#         end = time.time()
#         logger.info(f"{func.__name__} 耗时：{end - start:.4f}秒")
#         return result
#     return wrapper


# class PlatformToolRunner:
#     def __init__(self,tool:ToolForRun,user_id:str=None,secret=None,auth_config=None, auth_params=None):
#         self.toolVersion = tool.defaultVersion
#         self.tool = tool
#         self.endpoint = self.tool.platform.endpoint
#         self.protocol =  "http://" if self.endpoint.protocol=="HTTP" else "https://"
#         self.rela_path_template = tool.defaultVersion.url_path_template if tool.defaultVersion.url_path_template else "/"
#         self.input = tool.defaultVersion.input
#         self.input_model = json_schema_to_pydantic_model(tool.defaultVersion.input_schema)
#         self.input_schema= tool.defaultVersion.input_schema
#         self.output_schema = tool.defaultVersion.output_schema
#         self.needAccessSecret = tool.needAccessSecret
#         self.auth_config = auth_config
#         self.secret = secret
#         self.auth_params = auth_params

            
#         # 获取工具关联的认证配置

#     def get_input_schema(self):
#         return self.input_schema

#     def get_output_schema(self):
#         return self.output_schema

#     async def __call__(self, **kwargs):
#         # logger.debug("tool args: "+json.dumps(kwargs,ensure_ascii=False))
#         # logger.debug("input_model: "+json.dumps(self.input_model.model_json_schema(),ensure_ascii=False))
#         if self.needAccessSecret and (not self.secret or not self.auth_config) and not self.auth_params:
#             raise Exception(f"Tool {self.tool.name}@{self.tool.belongToProjectId} need access secret but not found for user")
        
#         headers_extra = {}
#         query_dict = {}
#         body_dict= {}
#         cookies_extra = {}
        
#         if self.auth_params:
#             headers_extra.update(self.auth_params.get("headers", {}))
#             query_dict.update(self.auth_params.get("query", {}))
#             body_dict.update(self.auth_params.get("body", {}))
#             cookies_extra.update(self.auth_params.get("cookies", {}))

#         if self.auth_config and self.secret:
#             headers_extra = {**self.auth_config.headers, **self.secret.secretInfo.get("headers", {})}
#             if self.auth_config.authType == "JWT" and self.secret.secretInfo.get("access_token"):
#                 apiKeyName = self.auth_config.apiKeyName if self.auth_config.apiKeyName else "Authorization"
#                 if self.auth_config.apiKeyPrefix:
#                     headers_extra[apiKeyName] = f"{self.auth_config.apiKeyPrefix} {self.secret.secretInfo.get('access_token')}"
#                 else:
#                     headers_extra[apiKeyName] = f"{self.secret.secretInfo.get('access_token')}"
#             elif self.auth_config.authType == "APIKey" and self.auth_config.keyLocation == "Header" and self.auth_config.apiKeyName:
#                 headers_extra[self.auth_config.apiKeyName] = f"{self.auth_config.apiKeyPrefix} "+self.secret.secretInfo.get("apiKey") if self.auth_config.apiKeyPrefix else self.secret.secretInfo.get("apiKey")
#         try:
#             input = json.loads(self.input_model(**kwargs).model_dump_json())
#             logger.debug(f"input: {input}")
#         except ValidationError as e:
#             raise ValueError(f"输入验证失败: {e}")
#         query = None
#         rela_path = self.rela_path_template
#         if self.input:
#             param_dict = {}
#             for para in self.input:
#                 a = para
#                 # logger.debug("para: "+json.dumps(para,ensure_ascii=False))
#                 if a["position"]=="query":
#                     query_dict[a["name"]] = input.get(a["name"],None)
#                 elif (self.toolVersion.method==RequestMethod.POST or self.toolVersion.method==RequestMethod.PATCH) and a["position"]=="body":
#                     body_dict[a["name"]] = input.get(a["name"],None)
#                 elif a["position"]=="urlpath":
#                     param_dict[a["name"]] = input.get(a["name"],None)
#             if param_dict:
#                 rela_path = self.rela_path_template.format(**param_dict)
        
#         if query_dict:
#             query = build_query_string(query_dict)
#         final_url = f"{self.protocol}{self.endpoint.baseURL}{rela_path}"
#         if query: 
#             logger.info("query: "+query)
#             final_url = f"{self.protocol}{self.endpoint.baseURL}{rela_path}?{query}"
        
#         # Check for OAuth1
#         oauth1_meta = None
#         if self.auth_params:
#              oauth1_meta = self.auth_params.get("metadata", {}).get("oauth1")
        
#         if oauth1_meta and _REQUESTS_AVAILABLE and _REQUESTS_OAUTH1_AVAILABLE:
#              # Use requests + requests_oauthlib for OAuth1 (Sync)
#              logger.info(f"Using OAuth1 for {final_url}")
             
#              # We need secret data for OAuth1 signing
#              secret_data = {}
#              if self.secret:
#                  secret_data = self.secret.secretInfo if hasattr(self.secret, 'secretInfo') else self.secret.data
#              elif self.auth_params and "metadata" in self.auth_params:
#                  # Try to find data in metadata if we put it there, but prepare_http puts it in metadata only for SMTP/POP3 or OAuth1 specific fields
#                  # For OAuth1, client_helper puts consumer_key etc in metadata if stype is OAuth1
#                  secret_data = self.auth_params.get("metadata", {})

#              consumer_key = secret_data.get(oauth1_meta.get("consumerKeyField", "consumer_key"))
#              consumer_secret = secret_data.get(oauth1_meta.get("consumerSecretField", "consumer_secret"))
#              token = secret_data.get(oauth1_meta.get("tokenField", "oauth_token")) or secret_data.get("access_token")
#              token_secret = secret_data.get(oauth1_meta.get("tokenSecretField", "oauth_token_secret")) or secret_data.get("access_token_secret")
#              sig_method = oauth1_meta.get("signatureMethod", "HMAC-SHA1")

#              auth = RequestsOAuth1(
#                 client_key=consumer_key,
#                 client_secret=consumer_secret,
#                 resource_owner_key=token,
#                 resource_owner_secret=token_secret,
#                 signature_method=sig_method,
#              )
             
#              # Since requests is sync, we should ideally run this in a thread, but for now we call it directly as per user request to use the library
#              # Note: This blocks the async loop. In production, use run_in_executor.
#              import asyncio
#              from functools import partial
             
#              def _sync_request():
#                  with requests.Session() as rs:
#                      return rs.request(
#                         method=self.toolVersion.method,
#                         url=final_url,
#                         headers=headers_extra or None,
#                         params=None, # query is already in final_url
#                         cookies=cookies_extra or None,
#                         json=body_dict if self.toolVersion.method == RequestMethod.POST else None,
#                         timeout=180,
#                         auth=auth
#                      )
            
#              loop = asyncio.get_running_loop()
#              res = await loop.run_in_executor(None, _sync_request)
             
#              if res.status_code == 200:
#                  return res.json()
#              else:
#                  res.raise_for_status()
             
#              return # End here for OAuth1

#         # logger.info("final_url: "+final_url)
#         async with httpx.AsyncClient() as client:  # 创建异步客户端（支持连接池）[[9]]
#             # client.headers.update({"Accept": "application/json"})
#             if headers_extra:
#                 client.headers.update(headers_extra)
#             if cookies_extra:
#                 client.cookies.update(cookies_extra)
#             # logger.info("headers: "+json.dumps(client.headers,ensure_ascii=False))
#             logger.info(f"Making {self.toolVersion.method} request to {final_url}, headers: {client.headers} ")
#             if self.toolVersion.method == RequestMethod.POST:
#                 logger.info("body_dict: "+json.dumps(body_dict,ensure_ascii=False))
#                 res = await client.post(final_url, json=body_dict,timeout=180)  # 异步POST请求，自动序列化JSON [[4]][[5]]
#             elif self.toolVersion.method == RequestMethod.GET:
#                 res = await client.get(final_url,timeout=180)  # 异步GET请求 [[2]]
#             if res.status_code==200:
#                 result = res.json()
#                 return result
#             else:
#                 res.raise_for_status()
            
# def build_platform_tool_run(tool:ToolForRun):
#     if tool.drivenByGenAI or not tool.platform:
#         raise Exception(f"tool : {tool.name}@{tool.belongToProjectId} is not a plaform")
#     tool_runner = PlatformToolRunner(tool)
#     return tool_runner

# # 设置OpenAI API密钥
# async def construct_tool(tool:ToolForRun,caller_type:str,caller_id:str,user_id:str, secret_id:str=None):
#     show_name = tool.name
#     belongToProjectId = tool.belongToProjectId.lower().replace("/","_")
#     call_name = f"{tool.name_en}__{belongToProjectId}"
#     # 在 input_schema 基础上添加 @task_instruction 字段
    
#     input_schema = copy.deepcopy(tool.defaultVersion.input_schema)
#     if 'properties' in input_schema and isinstance(input_schema['properties'], dict):
#         input_schema['properties']['@task_instruction'] = {
#             'title': '工具调用任务说明',
#             'type': 'string',
#             'description': '描述调用本工具的主要目标，和应该输出的必要信息，结果过大时用于将指令发给大模型生成概要。',
#             'default': ''
#         }
#         if 'required' in input_schema and isinstance(input_schema['required'], list):
#             # 可选：不强制 required
#             input_schema['required'].append('@task_instruction')
#             pass
#     else:
#         # fallback: 构造 properties
#         input_schema['properties'] = {
#             '@task_instruction': {
#                 'title': '工具调用任务说明',
#                 'type': 'string',
#                 'description': '描述调用本工具的主要目标，和应该输出的必要信息，结果过大时用于将指令发给大模型生成概要。',
#                 'default': ''
#             }
#         }
#     langchain_tool = NamedTool(
#         name_for_human=show_name,
#         name=call_name,
#         description=tool.description,
#         args_schema=input_schema
#     )
#     tool_runner = None
#     if tool.drivenByGenAI:
#         tool_runner =await construct_tool_runner(tool,user_id)
#         # logger.info("tool_runner: "+json.dumps(tool_runner,ensure_ascii=False))
#     elif tool.platform:
#         auth_params = None
#         secret = None
#         auth_config = None
#         used_secret_id = secret_id
        
#         tool_runner = PlatformToolRunner(tool,user_id,secret,auth_config, auth_params=auth_params)

#     async def tool_run(**kwargs):
#         logger.debug("tool args: "+json.dumps(kwargs,ensure_ascii=False))
#         task_instruction = kwargs.pop("@task_instruction", None)
#         #检查输入参数中是否有 task_instruction
#         record = None
#         start = time.time()
#         result = None
#         input_schema = tool_runner.get_input_schema()
#         output_schema = tool_runner.get_output_schema()
        
#         try:
#             record = await create_tool_call_records(input=kwargs,tool_version=tool.defaultVersion,caller_id=caller_id,caller_type=caller_type,user_id=user_id,intent=task_instruction)
#             # index_action_record(
#             #     record,
#             #     fieldtype=ChunkFieldType.INPUT,
#             #     tool_name=tool.name,
#             #     tool_type=tool.type,
#             #     data_schema=input_schema
#             # )
#             result = await tool_runner(**kwargs)
#             end = time.time()
#             # 记录工具调用的耗时,并存储结果
#             record = await update_tool_call_records(record.id,status=ToolCallStatus.success,result=result,error_info="",user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#             # 对调用结果建立索引
#             # index_action_record(
#             #     record,
#             #     fieldtype=ChunkFieldType.OUTPUT,
#             #     tool_name=tool.name,
#             #     tool_type=tool.type,
#             #     data_schema=output_schema
#             # )

#             return ToolRunResult(
#                 request_id=record.id,
#                 result=result,
#                 error=None,
#                 status="success",
#                 status_code=200
#             )
#         except httpx.ConnectError as e:
#             logger.exception(e)
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#                 return ToolRunResult(
#                     request_id=record.id,
#                     result=None,
#                     error=f"连接失败: {str(e)}",
#                     status="connect_error",
#                     status_code=503
#                 )
#             else:
#                 return ToolRunResult(
#                     request_id=None,
#                     result=None,
#                     error=f"连接失败: {str(e)}",
#                     status="connect_error",
#                     status_code=503
#                 )


#         except httpx.ReadTimeout as e:
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#                 return ToolRunResult(
#                     request_id=record.id,
#                     result=None,
#                     error=f"读取超时: {str(e)}",
#                     status="timeout",
#                     status_code=504
#                 )
#             else:
#                 return ToolRunResult(
#                     request_id=None,
#                     result=None,
#                     error=f"读取超时: {str(e)}",
#                     status="timeout",
#                     status_code=504
#                 )
#         except httpx.ConnectTimeout as e:
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#             return ToolRunResult(
#                 request_id=record.id,
#                 result=None,
#                 error=f"连接超时: {str(e)}",
#                 status="timeout",
#                 status_code=504
#             )
#         except httpx.ProxyError as e:
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#             return ToolRunResult(
#                 request_id=record.id,
#                 result=None,
#                 error=f"代理错误: {str(e)}",
#                 status="proxy_error",
#                 status_code=502
#             )
#         except httpx.HTTPStatusError as e:
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#             return ToolRunResult(
#                 request_id=record.id,
#                 result=None,
#                 error=f"HTTP错误: {e.response.status_code} - {e.response.text}",
#                 status="http_error",
#                 status_code=e.response.status_code if hasattr(e, 'response') and hasattr(e.response, 'status_code') else 500
#             )
#         except httpx.RequestError as e:
#             # 捕获请求错误（如连接失败、超时等）
#             logger.exception(f"请求错误: {str(e)}")
#             if record:
#                 end = time.time()
#                 record = await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(e),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#             return ToolRunResult(
#                 request_id=record.id,
#                 result=None,
#                 error=f"请求异常: {str(e)}",
#                 status="request_error",
#                 status_code=400
#             )
#         except Exception as ex:
#             if record:
#                 end = time.time()
#                 await update_tool_call_records(record.id,status=ToolCallStatus.error,result=None,error_info=str(ex),user_id=user_id,time_cost=(end-start), secret_id=used_secret_id)
#                 # index_action_record(
#                 #     record,
#                 #     fieldtype=ChunkFieldType.ERROR,
#                 #     tool_name=tool.name,
#                 #     tool_type=tool.type
#                 # )
#             logger.exception(ex)
#             return ToolRunResult(
#                 request_id=record.id,
#                 result=None,
#                 error=f"本地服务错误: {str(ex)}",
#                 status="internal_error",
#                 status_code=500
#             )
        
#     return show_name,call_name,langchain_tool,tool_run
# #