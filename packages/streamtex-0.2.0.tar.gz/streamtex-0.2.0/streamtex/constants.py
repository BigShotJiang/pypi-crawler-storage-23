"""Centralized constants for StreamTeX."""

PAGE_WIDTH = "100%"
PAGE_PADDING = "36pt"
