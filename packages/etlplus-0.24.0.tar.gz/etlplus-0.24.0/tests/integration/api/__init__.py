"""
:mod:`tests.integration.api` subpackage.

Integration tests for the :mod:`etlplus.api` subpackage.
"""

from __future__ import annotations
