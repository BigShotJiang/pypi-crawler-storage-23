# mcpzoo-calc

> 数学计算 — 安全地对数学表达式求值

## Installation

```bash
uvx mcpzoo-calc
```

## uvx JSON

```json
{
  "mcpServers": {
    "calc": {
      "args": ["mcpzoo-calc"],
      "command": "uvx"
    }
  }
}
```
