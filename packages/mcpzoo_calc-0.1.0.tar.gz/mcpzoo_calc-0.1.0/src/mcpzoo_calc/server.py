import ast
import operator
import math
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("calc")

# Safe math functions mapping
safe_funcs = {
    'abs': abs, 'round': round, 'min': min, 'max': max,
    'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
    'sqrt': math.sqrt, 'log': math.log, 'log10': math.log10,
    'pow': math.pow, 'pi': math.pi, 'e': math.e,
}

# Supported operators
operators = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.BitXor: operator.xor,
    ast.USub: operator.neg, ast.UAdd: operator.pos
}

def safe_eval(node):
    if isinstance(node, ast.Num):
        return node.n
    elif isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError(f"不受支持的常量: {node.value}")
    elif isinstance(node, ast.BinOp):
        return operators[type(node.op)](safe_eval(node.left), safe_eval(node.right))
    elif isinstance(node, ast.UnaryOp):
        return operators[type(node.op)](safe_eval(node.operand))
    elif isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise ValueError("函数名称必须是标识符")
        func = safe_funcs.get(node.func.id)
        if not func:
            raise ValueError(f"不受支持的函数: {node.func.id}")
        args = [safe_eval(arg) for arg in node.args]
        return func(*args)
    elif isinstance(node, ast.Name):
        val = safe_funcs.get(node.id)
        if isinstance(val, float):
            return val
        raise ValueError(f"不受支持的变量或操作: {node.id}")
    else:
        raise ValueError(f"不受支持的表达式节点: {type(node).__name__}")

@mcp.tool()
def calculate(expression: str) -> str:
    """安全地对数学表达式求值。"""
    try:
        expr = ast.parse(expression, mode='eval').body
        result = safe_eval(expr)
        return str(result)
    except SyntaxError:
        return f"语法错误: 未能正确解析表达式 '{expression}'"
    except Exception as e:
        return f"计算错误: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
