"""Nativ MCP Server — AI-powered localization from any MCP-compatible tool."""

__version__ = "0.1.3"
