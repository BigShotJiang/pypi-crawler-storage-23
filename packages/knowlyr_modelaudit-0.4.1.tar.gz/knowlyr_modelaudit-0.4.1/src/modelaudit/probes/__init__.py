"""探测 prompt 管理."""

from modelaudit.probes.prompts import DEFAULT_PROBES, get_probes

__all__ = ["DEFAULT_PROBES", "get_probes"]
