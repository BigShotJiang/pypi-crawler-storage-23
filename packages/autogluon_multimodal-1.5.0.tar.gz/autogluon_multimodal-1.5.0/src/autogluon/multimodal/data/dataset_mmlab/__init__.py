try:
    from .multi_image_mix_dataset import MultiImageMixDataset
except ImportError:
    MultiImageMixDataset = None
