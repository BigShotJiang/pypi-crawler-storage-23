_base_ = ["./dino-5scale_swin-l_8xb2-36e_coco.py", "./dino_tta.py"]
