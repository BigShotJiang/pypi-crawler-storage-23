"""
GPU BigInt - Arbitrary Precision Integer Arithmetic on GPU

DEPRECATED: Use ModularRational from simgen.vla.modular instead.

ModularRational uses Chinese Remainder Theorem for O(1) memory per value,
while GPUBigInt/GPURational have exponential limb growth.

>>> from simgen import vla
>>> x = vla.ModularRational.from_fraction(1, 3)  # TRUE ZERO, O(1) memory

---
Original module docstring:

Enables TRUE ZERO error for complex rational arithmetic by storing
integers as arrays of int64 "limbs" on GPU.

This is the foundation for exact rational arithmetic that can handle
equations like Lorenz attractors with millions of steps.
"""

import torch
from typing import Tuple, Union, Optional

# Base for limbs: 2^62 to avoid overflow in multiplication
# (2^62)^2 = 2^124 which fits in int128, and intermediate sums fit in int64
LIMB_BITS = 62
LIMB_BASE = 1 << LIMB_BITS
LIMB_MASK = LIMB_BASE - 1


class GPUBigInt:
    """
    Arbitrary precision integer on GPU.

    Stores integers as arrays of int64 limbs in little-endian order.
    Each limb stores 62 bits to allow safe multiplication without overflow.

    Examples:
        >>> x = GPUBigInt.from_int(12345678901234567890)
        >>> y = GPUBigInt.from_int(98765432109876543210)
        >>> z = x * y  # Exact multiplication
        >>> print(z.to_int())  # Full precision result
    """

    def __init__(self, limbs: torch.Tensor, sign: int = 1, device: str = 'cuda'):
        """
        Create GPUBigInt from limbs tensor.

        Args:
            limbs: 1D int64 tensor of limbs (little-endian)
            sign: 1 for positive, -1 for negative, 0 for zero
            device: 'cuda' or 'cpu'
        """
        self.limbs = limbs.to(device)
        self.sign = sign
        self.device = device
        self._normalize()

    def _normalize(self):
        """Remove leading zero limbs and handle sign of zero."""
        # Find last non-zero limb
        nonzero = (self.limbs != 0).nonzero(as_tuple=True)[0]
        if len(nonzero) == 0:
            # All zeros
            self.limbs = torch.zeros(1, dtype=torch.int64, device=self.device)
            self.sign = 0
        else:
            last_nonzero = nonzero[-1].item()
            self.limbs = self.limbs[:last_nonzero + 1]

    @classmethod
    def from_int(cls, value: int, device: str = 'cuda') -> 'GPUBigInt':
        """Create GPUBigInt from Python int."""
        if value == 0:
            return cls(torch.zeros(1, dtype=torch.int64, device=device), sign=0, device=device)

        sign = 1 if value > 0 else -1
        value = abs(value)

        limbs = []
        while value > 0:
            limbs.append(value & LIMB_MASK)
            value >>= LIMB_BITS

        return cls(torch.tensor(limbs, dtype=torch.int64, device=device), sign=sign, device=device)

    @classmethod
    def zero(cls, device: str = 'cuda') -> 'GPUBigInt':
        """Create zero."""
        return cls(torch.zeros(1, dtype=torch.int64, device=device), sign=0, device=device)

    @classmethod
    def one(cls, device: str = 'cuda') -> 'GPUBigInt':
        """Create one."""
        return cls(torch.ones(1, dtype=torch.int64, device=device), sign=1, device=device)

    def to_int(self) -> int:
        """Convert to Python int (may be slow for huge numbers)."""
        if self.sign == 0:
            return 0

        result = 0
        limbs_cpu = self.limbs.cpu().tolist()
        for i, limb in enumerate(limbs_cpu):
            result += int(limb) << (LIMB_BITS * i)

        return result * self.sign

    def __len__(self) -> int:
        """Number of limbs."""
        return len(self.limbs)

    def is_zero(self) -> bool:
        return self.sign == 0

    def is_positive(self) -> bool:
        return self.sign > 0

    def is_negative(self) -> bool:
        return self.sign < 0

    # =========================================================================
    # Comparison
    # =========================================================================

    def _compare_magnitude(self, other: 'GPUBigInt') -> int:
        """Compare absolute values. Returns -1, 0, or 1."""
        if len(self.limbs) != len(other.limbs):
            return 1 if len(self.limbs) > len(other.limbs) else -1

        # Compare from most significant limb
        for i in range(len(self.limbs) - 1, -1, -1):
            a = self.limbs[i].item()
            b = other.limbs[i].item()
            if a != b:
                return 1 if a > b else -1
        return 0

    def __eq__(self, other: Union['GPUBigInt', int]) -> bool:
        if isinstance(other, int):
            other = GPUBigInt.from_int(other, device=self.device)
        if self.sign != other.sign:
            return False
        if self.sign == 0:
            return True
        return self._compare_magnitude(other) == 0

    def __lt__(self, other: Union['GPUBigInt', int]) -> bool:
        if isinstance(other, int):
            other = GPUBigInt.from_int(other, device=self.device)
        if self.sign != other.sign:
            return self.sign < other.sign
        if self.sign == 0:
            return False
        cmp = self._compare_magnitude(other)
        return (cmp < 0) if self.sign > 0 else (cmp > 0)

    def __le__(self, other: Union['GPUBigInt', int]) -> bool:
        return self == other or self < other

    def __gt__(self, other: Union['GPUBigInt', int]) -> bool:
        return not self <= other

    def __ge__(self, other: Union['GPUBigInt', int]) -> bool:
        return not self < other

    # =========================================================================
    # Arithmetic
    # =========================================================================

    def __neg__(self) -> 'GPUBigInt':
        """Negate."""
        return GPUBigInt(self.limbs.clone(), sign=-self.sign, device=self.device)

    def __abs__(self) -> 'GPUBigInt':
        """Absolute value."""
        return GPUBigInt(self.limbs.clone(), sign=abs(self.sign), device=self.device)

    def _add_magnitude(self, other: 'GPUBigInt') -> torch.Tensor:
        """Add absolute values, return new limbs tensor."""
        # Pad to same length + 1 for carry
        max_len = max(len(self.limbs), len(other.limbs)) + 1
        a = torch.zeros(max_len, dtype=torch.int64, device=self.device)
        b = torch.zeros(max_len, dtype=torch.int64, device=self.device)
        a[:len(self.limbs)] = self.limbs
        b[:len(other.limbs)] = other.limbs

        result = torch.zeros(max_len, dtype=torch.int64, device=self.device)
        carry = 0

        # Sequential carry propagation (could be parallelized with prefix sum)
        for i in range(max_len):
            total = int(a[i].item()) + int(b[i].item()) + carry
            result[i] = total & LIMB_MASK
            carry = total >> LIMB_BITS

        return result

    def _sub_magnitude(self, other: 'GPUBigInt') -> Tuple[torch.Tensor, int]:
        """
        Subtract absolute values (self - other).
        Returns (result_limbs, result_sign).
        Assumes self >= other in magnitude.
        """
        cmp = self._compare_magnitude(other)
        if cmp == 0:
            return torch.zeros(1, dtype=torch.int64, device=self.device), 0

        # Ensure we're subtracting smaller from larger
        if cmp < 0:
            result, _ = other._sub_magnitude(self)
            return result, -1

        max_len = len(self.limbs)
        a = self.limbs.clone()
        b = torch.zeros(max_len, dtype=torch.int64, device=self.device)
        b[:len(other.limbs)] = other.limbs

        result = torch.zeros(max_len, dtype=torch.int64, device=self.device)
        borrow = 0

        for i in range(max_len):
            diff = int(a[i].item()) - int(b[i].item()) - borrow
            if diff < 0:
                diff += LIMB_BASE
                borrow = 1
            else:
                borrow = 0
            result[i] = diff

        return result, 1

    def __add__(self, other: Union['GPUBigInt', int]) -> 'GPUBigInt':
        """Add two BigInts."""
        if isinstance(other, int):
            other = GPUBigInt.from_int(other, device=self.device)

        if self.sign == 0:
            return GPUBigInt(other.limbs.clone(), sign=other.sign, device=self.device)
        if other.sign == 0:
            return GPUBigInt(self.limbs.clone(), sign=self.sign, device=self.device)

        if self.sign == other.sign:
            # Same sign: add magnitudes
            result = self._add_magnitude(other)
            return GPUBigInt(result, sign=self.sign, device=self.device)
        else:
            # Different signs: subtract magnitudes
            result, result_sign = self._sub_magnitude(other)
            final_sign = self.sign * result_sign if result_sign != 0 else 0
            return GPUBigInt(result, sign=final_sign, device=self.device)

    def __radd__(self, other: int) -> 'GPUBigInt':
        return self.__add__(other)

    def __sub__(self, other: Union['GPUBigInt', int]) -> 'GPUBigInt':
        """Subtract."""
        if isinstance(other, int):
            other = GPUBigInt.from_int(other, device=self.device)
        return self + (-other)

    def __rsub__(self, other: int) -> 'GPUBigInt':
        return GPUBigInt.from_int(other, device=self.device) - self

    def __mul__(self, other: Union['GPUBigInt', int]) -> 'GPUBigInt':
        """Multiply (schoolbook algorithm - can be optimized with Karatsuba)."""
        if isinstance(other, int):
            other = GPUBigInt.from_int(other, device=self.device)

        if self.sign == 0 or other.sign == 0:
            return GPUBigInt.zero(device=self.device)

        result_sign = self.sign * other.sign

        # Result has at most len(a) + len(b) limbs
        result_len = len(self.limbs) + len(other.limbs)
        result = torch.zeros(result_len, dtype=torch.int64, device=self.device)

        # Schoolbook multiplication
        for i in range(len(self.limbs)):
            carry = 0
            for j in range(len(other.limbs)):
                # Use Python int to avoid overflow
                product = int(self.limbs[i].item()) * int(other.limbs[j].item())
                product += int(result[i + j].item()) + carry
                result[i + j] = product & LIMB_MASK
                carry = product >> LIMB_BITS
            if carry:
                result[i + len(other.limbs)] += carry

        return GPUBigInt(result, sign=result_sign, device=self.device)

    def __rmul__(self, other: int) -> 'GPUBigInt':
        return self.__mul__(other)

    def __repr__(self) -> str:
        if len(self.limbs) <= 4:
            return f"GPUBigInt({self.to_int()})"
        return f"GPUBigInt({self.sign}, {len(self.limbs)} limbs, ~{len(self.limbs) * 19} digits)"


class GPURational:
    """
    Exact rational arithmetic on GPU using GPUBigInt.

    Stores rationals as (numerator, denominator) pairs with arbitrary
    precision. ALL arithmetic is EXACT with TRUE ZERO error.

    Examples:
        >>> x = GPURational.from_fraction(1, 1000)  # Exactly 0.001
        >>> y = GPURational.from_fraction(8, 3)     # Exactly 8/3
        >>> z = x * y                                # Exact result
    """

    def __init__(self, numerator: GPUBigInt, denominator: GPUBigInt):
        """Create rational from numerator and denominator BigInts."""
        if denominator.is_zero():
            raise ValueError("Denominator cannot be zero")

        self.num = numerator
        self.denom = denominator

        # Normalize sign to numerator
        if self.denom.is_negative():
            self.num = -self.num
            self.denom = -self.denom

        self._reduce()

    def _reduce(self):
        """Reduce fraction to lowest terms using GCD."""
        if self.num.is_zero():
            self.denom = GPUBigInt.one(device=self.num.device)
            return

        # Skip GCD for large numbers (too slow)
        # Only reduce for small numbers where it's fast
        if len(self.num) <= 2 and len(self.denom) <= 2:
            a_int = self.num.to_int()
            b_int = self.denom.to_int()
            from math import gcd
            g = gcd(abs(a_int), abs(b_int))
            if g > 1:
                self.num = GPUBigInt.from_int(a_int // g, device=self.num.device)
                self.denom = GPUBigInt.from_int(b_int // g, device=self.denom.device)

    @classmethod
    def from_fraction(cls, numerator: int, denominator: int, device: str = 'cuda') -> 'GPURational':
        """Create from integer fraction."""
        return cls(
            GPUBigInt.from_int(numerator, device=device),
            GPUBigInt.from_int(denominator, device=device)
        )

    @classmethod
    def from_int(cls, value: int, device: str = 'cuda') -> 'GPURational':
        """Create from integer."""
        return cls.from_fraction(value, 1, device=device)

    @classmethod
    def from_decimal_str(cls, s: str, device: str = 'cuda') -> 'GPURational':
        """
        Parse decimal string exactly.

        "0.001" -> 1/1000
        "3.14159" -> 314159/100000
        """
        s = s.strip()
        negative = s.startswith('-')
        if negative:
            s = s[1:]

        if '.' in s:
            integer_part, decimal_part = s.split('.')
            integer_part = integer_part.lstrip('0') or '0'
            combined = integer_part + decimal_part
            combined = combined.lstrip('0') or '0'
            numerator = int(combined)
            denominator = 10 ** len(decimal_part)
        else:
            numerator = int(s)
            denominator = 1

        if negative:
            numerator = -numerator

        return cls.from_fraction(numerator, denominator, device=device)

    def to_float(self) -> float:
        """Convert to float (loses precision)."""
        return self.num.to_int() / self.denom.to_int()

    def to_decimal(self):
        """Convert to Python Decimal."""
        from decimal import Decimal
        return Decimal(self.num.to_int()) / Decimal(self.denom.to_int())

    # =========================================================================
    # Arithmetic
    # =========================================================================

    def __add__(self, other: Union['GPURational', int]) -> 'GPURational':
        """Exact addition: a/b + c/d = (ad + bc) / bd"""
        if isinstance(other, int):
            other = GPURational.from_int(other, device=self.num.device)

        new_num = self.num * other.denom + self.denom * other.num
        new_denom = self.denom * other.denom
        return GPURational(new_num, new_denom)

    def __radd__(self, other: int) -> 'GPURational':
        return self.__add__(other)

    def __sub__(self, other: Union['GPURational', int]) -> 'GPURational':
        """Exact subtraction."""
        if isinstance(other, int):
            other = GPURational.from_int(other, device=self.num.device)

        new_num = self.num * other.denom - self.denom * other.num
        new_denom = self.denom * other.denom
        return GPURational(new_num, new_denom)

    def __rsub__(self, other: int) -> 'GPURational':
        return GPURational.from_int(other, device=self.num.device) - self

    def __mul__(self, other: Union['GPURational', int]) -> 'GPURational':
        """Exact multiplication."""
        if isinstance(other, int):
            other = GPURational.from_int(other, device=self.num.device)

        new_num = self.num * other.num
        new_denom = self.denom * other.denom
        return GPURational(new_num, new_denom)

    def __rmul__(self, other: int) -> 'GPURational':
        return self.__mul__(other)

    def __truediv__(self, other: Union['GPURational', int]) -> 'GPURational':
        """Exact division."""
        if isinstance(other, int):
            other = GPURational.from_int(other, device=self.num.device)

        new_num = self.num * other.denom
        new_denom = self.denom * other.num
        return GPURational(new_num, new_denom)

    def __rtruediv__(self, other: int) -> 'GPURational':
        return GPURational.from_int(other, device=self.num.device) / self

    def __neg__(self) -> 'GPURational':
        return GPURational(-self.num, GPUBigInt(self.denom.limbs.clone(), sign=self.denom.sign, device=self.denom.device))

    def __eq__(self, other: Union['GPURational', int]) -> bool:
        if isinstance(other, int):
            other = GPURational.from_int(other, device=self.num.device)
        # a/b == c/d iff a*d == b*c
        return (self.num * other.denom) == (self.denom * other.num)

    def __repr__(self) -> str:
        n = self.num.to_int()
        d = self.denom.to_int()
        if abs(n) < 10**15 and d < 10**15:
            return f"GPURational({n}/{d} = {n/d:.15g})"
        return f"GPURational(~{len(self.num)} + {len(self.denom)} limbs)"


# Export for use in vla module
__all__ = ['GPUBigInt', 'GPURational', 'LIMB_BITS', 'LIMB_BASE']
