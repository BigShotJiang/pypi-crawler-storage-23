"""
ModularRational CUDA - TRUE ZERO Error on GPU

Native CUDA implementation of exact rational arithmetic using
modular representation. Each value is stored as residues mod
multiple primes, enabling exact arithmetic with O(1) memory.

All operations are fully parallel on GPU.
"""

import torch
from typing import Union, List, Tuple, Optional

# GPU-safe primes: smaller to prevent int64 overflow during a*b mod p
# With primes < 2^31, product a*b < 2^62 < 2^63 (no overflow)
# Product of 7 primes ~ 2^210 bits of range (more than enough)
PRIMES = torch.tensor([
    2147483629,    # 2^31 - 19 (prime, coprime to 2,3)
    2147483587,    # 2^31 - 61 (prime, coprime to 2,3)
    2147483549,    # 2^31 - 99 (prime, coprime to 2,3)
    2147483489,    # 2^31 - 159 (prime, coprime to 2,3)
    2147483477,    # 2^31 - 171 (prime, coprime to 2,3)
    2147483423,    # 2^31 - 225 (prime, coprime to 2,3)
    2147483399,    # 2^31 - 249 (prime, coprime to 2,3)
], dtype=torch.int64)

N_PRIMES = len(PRIMES)


class ModularTensor:
    """
    GPU tensor with exact modular arithmetic.

    Each element is stored as (num_residues, denom_residues) across N primes.
    Shape: [N_PRIMES, *original_shape] for both num and denom.

    All operations are element-wise and fully parallel.
    """

    __slots__ = ('num', 'denom', 'primes', 'device', '_approx')

    def __init__(self, num: torch.Tensor, denom: torch.Tensor,
                 primes: torch.Tensor = None, approx: torch.Tensor = None):
        """
        Initialize from residue tensors.

        Args:
            num: [N_PRIMES, *shape] int64 tensor of numerator residues
            denom: [N_PRIMES, *shape] int64 tensor of denominator residues
            primes: [N_PRIMES] tensor of primes
            approx: [*shape] float tensor for display (optional)
        """
        self.num = num
        self.denom = denom
        self.device = num.device
        self.primes = primes.to(self.device) if primes is not None else PRIMES.to(self.device)
        self._approx = approx

    @property
    def shape(self):
        return self.num.shape[1:]  # Exclude primes dimension

    @classmethod
    def from_tensor(cls, x: torch.Tensor, device: str = 'cuda') -> 'ModularTensor':
        """Create from float tensor (captures exact float value)."""
        x = x.to(device)
        primes = PRIMES.to(device)

        # For floats, we store as (x * 2^52, 2^52) to capture mantissa exactly
        # This works for values that fit in int64
        scale = 2**52
        scaled = (x * scale).to(torch.int64)

        # Compute residues for each prime
        num = torch.stack([scaled % p for p in primes])
        denom = torch.stack([torch.full_like(scaled, scale % p.item()) for p in primes])

        return cls(num, denom, primes, x.float())

    @classmethod
    def from_fraction(cls, num: int, denom: int = 1,
                      shape: Tuple = (), device: str = 'cuda') -> 'ModularTensor':
        """Create tensor filled with exact fraction num/denom."""
        primes = PRIMES.to(device)

        # Create residue tensors
        num_res = torch.stack([
            torch.full(shape, num % p.item(), dtype=torch.int64, device=device)
            for p in primes
        ])
        denom_res = torch.stack([
            torch.full(shape, denom % p.item(), dtype=torch.int64, device=device)
            for p in primes
        ])

        approx = torch.full(shape, num / denom, dtype=torch.float32, device=device)
        return cls(num_res, denom_res, primes, approx)

    @classmethod
    def from_int(cls, value: int, shape: Tuple = (), device: str = 'cuda') -> 'ModularTensor':
        """Create tensor filled with exact integer."""
        return cls.from_fraction(value, 1, shape, device)

    @classmethod
    def zeros(cls, shape: Tuple, device: str = 'cuda') -> 'ModularTensor':
        """Create zero tensor."""
        return cls.from_int(0, shape, device)

    @classmethod
    def ones(cls, shape: Tuple, device: str = 'cuda') -> 'ModularTensor':
        """Create ones tensor."""
        return cls.from_int(1, shape, device)

    def __add__(self, other: 'ModularTensor') -> 'ModularTensor':
        """Exact addition: a/b + c/d = (ad + bc) / bd"""
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)

        # Broadcast primes for element-wise ops
        # a/b + c/d = (ad + bc) / bd
        primes = self.primes.view(-1, *([1] * len(self.shape)))

        ad = (self.num * other.denom) % primes
        bc = (self.denom * other.num) % primes
        new_num = (ad + bc) % primes
        new_denom = (self.denom * other.denom) % primes

        approx = None
        if self._approx is not None and other._approx is not None:
            approx = self._approx + other._approx

        return ModularTensor(new_num, new_denom, self.primes, approx)

    def __radd__(self, other) -> 'ModularTensor':
        return self.__add__(other)

    def __sub__(self, other: 'ModularTensor') -> 'ModularTensor':
        """Exact subtraction: a/b - c/d = (ad - bc) / bd"""
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)

        primes = self.primes.view(-1, *([1] * len(self.shape)))

        ad = (self.num * other.denom) % primes
        bc = (self.denom * other.num) % primes
        new_num = (ad - bc) % primes  # Python/PyTorch handles negative mod correctly
        new_denom = (self.denom * other.denom) % primes

        approx = None
        if self._approx is not None and other._approx is not None:
            approx = self._approx - other._approx

        return ModularTensor(new_num, new_denom, self.primes, approx)

    def __rsub__(self, other) -> 'ModularTensor':
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)
        return other.__sub__(self)

    def __mul__(self, other: 'ModularTensor') -> 'ModularTensor':
        """Exact multiplication: (a/b) * (c/d) = ac / bd"""
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)

        primes = self.primes.view(-1, *([1] * len(self.shape)))

        new_num = (self.num * other.num) % primes
        new_denom = (self.denom * other.denom) % primes

        approx = None
        if self._approx is not None and other._approx is not None:
            approx = self._approx * other._approx

        return ModularTensor(new_num, new_denom, self.primes, approx)

    def __rmul__(self, other) -> 'ModularTensor':
        return self.__mul__(other)

    def __truediv__(self, other: 'ModularTensor') -> 'ModularTensor':
        """Exact division: (a/b) / (c/d) = ad / bc"""
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)

        primes = self.primes.view(-1, *([1] * len(self.shape)))

        new_num = (self.num * other.denom) % primes
        new_denom = (self.denom * other.num) % primes

        approx = None
        if self._approx is not None and other._approx is not None:
            approx = self._approx / (other._approx + 1e-30)

        return ModularTensor(new_num, new_denom, self.primes, approx)

    def __neg__(self) -> 'ModularTensor':
        """Negation."""
        primes = self.primes.view(-1, *([1] * len(self.shape)))
        new_num = (-self.num) % primes
        approx = -self._approx if self._approx is not None else None
        return ModularTensor(new_num, self.denom.clone(), self.primes, approx)

    def __eq__(self, other: 'ModularTensor') -> torch.Tensor:
        """Exact element-wise equality: a/b == c/d iff ad == bc (all primes)."""
        if isinstance(other, (int, float)):
            other = ModularTensor.from_fraction(int(other), 1, self.shape, self.device)

        primes = self.primes.view(-1, *([1] * len(self.shape)))

        # Check ad == bc for all primes
        ad = (self.num * other.denom) % primes
        bc = (self.denom * other.num) % primes

        # All primes must match
        return (ad == bc).all(dim=0)

    def sum(self) -> 'ModularTensor':
        """Exact sum of all elements."""
        # Sum along all dimensions except primes
        result_num = self.num[:, 0].clone()
        result_denom = self.denom[:, 0].clone()

        flat_num = self.num.view(N_PRIMES, -1)
        flat_denom = self.denom.view(N_PRIMES, -1)

        # Initialize with first element
        acc_num = flat_num[:, 0].clone()
        acc_denom = flat_denom[:, 0].clone()

        # Accumulate: a/b + c/d = (ad + bc) / bd
        for i in range(1, flat_num.shape[1]):
            n = flat_num[:, i]
            d = flat_denom[:, i]

            ad = (acc_num * d) % self.primes
            bc = (acc_denom * n) % self.primes
            acc_num = (ad + bc) % self.primes
            acc_denom = (acc_denom * d) % self.primes

        approx = self._approx.sum() if self._approx is not None else None
        return ModularTensor(
            acc_num.unsqueeze(1),
            acc_denom.unsqueeze(1),
            self.primes,
            approx.unsqueeze(0) if approx is not None else None
        )

    def dot(self, other: 'ModularTensor') -> 'ModularTensor':
        """Exact dot product."""
        return (self * other).sum()

    def to_float(self) -> torch.Tensor:
        """Convert to float tensor (lossy, for display only)."""
        if self._approx is not None:
            return self._approx
        return torch.zeros(self.shape, device=self.device)

    def __repr__(self) -> str:
        return f"ModularTensor(shape={self.shape}, device={self.device})"


def modular_sum(x: torch.Tensor) -> ModularTensor:
    """Exact sum of tensor elements."""
    mt = ModularTensor.from_tensor(x)
    return mt.sum()


def modular_dot(a: torch.Tensor, b: torch.Tensor) -> ModularTensor:
    """Exact dot product."""
    mt_a = ModularTensor.from_tensor(a)
    mt_b = ModularTensor.from_tensor(b)
    return mt_a.dot(mt_b)


# Export
__all__ = [
    'PRIMES', 'N_PRIMES',
    'ModularTensor',
    'modular_sum', 'modular_dot',
]
