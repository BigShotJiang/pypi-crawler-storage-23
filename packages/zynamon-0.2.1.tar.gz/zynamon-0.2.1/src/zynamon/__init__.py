__version__ = '0.2.1'
__all__ = []

from zynamon.zeit import TimeSeries


example = [
    "from zynamon.zeit import TimeSeries",
    "",
    "print('1. Creating empty time-series...')",
    "ts = TimeSeries('MyNew1')",
    "ts.tags_register({'location': 'Erlangen', 'reason': 'Just-a-test'})",
    "ts.print()",
    "ts.stats()",
    "",
    "print('2. Adding samples...')",
    "apples = [0.1, 1.1, 2.95, 2.6, 3.4, 4, 3.2, 5.1777]",
    "pears  = [10, 20, 30, 40, 50, 60, 70, 80]",
    "ts.samples_add(zip(apples, pears))",
    "ts.print()",
    "ts.stats()",
    "",
    "print('3. Make time-series causal, i.e. sort samples in time...')",
    "ts.time_causalise()",
    "ts.print()",
    "ts.stats()",
    "",
    "print('4. Align samples acc. to fixed 0.5 scale and by averaging of values (if required)')",
    "ts.time_align(res=0.5, shift='bwd', recon='avg')",
    "ts.print(25)",
    "ts.stats(content='time')"
]

def demo():   
    print("This is a demo for the 'zynamon' package.")
    print("")
    print("Usage example:")    
    for line in example:
        print(" "*4+line)
    print("")
    chk = input('Do you want to run this now? (y/N)')
    mylocals = {}
    if (chk.lower() == 'y'):
        print("\n\n")
        for line in example[1:]:
            exec(line, globals(), mylocals) if line else print("\n")

    print("Have phun! :)")
    return