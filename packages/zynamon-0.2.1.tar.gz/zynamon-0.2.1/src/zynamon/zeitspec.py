"""
Time-series for managing datapoint objects w/ samples from arbitrary time instants.
"""
import re
import numpy as np
import pandas as pd
import datetime as dt

from zdev.searchstr import S_NUMBER


# EXPORTED DATA
MAP_TIME = {
    float: 'stamp', np.float32: 'stamp', np.float64: 'stamp',
    int: 'stamp_ns',
    str: 'iso',
    dt.datetime: 'obj_dt', dt.date: 'obj_dt',
    pd.Timestamp: 'obj_pd'
    }
TS_ISO_FORMAT = '%Y-%m-%d %H:%M:%S'

# INTERNAL PARAMETERS & DEFAULTS
# (SET) -> dates
_RX_SET_DATE_HYPH_Y4F_MNUM = re.compile(r'%Y-%m-%d')    # 'YYYY-mm-dd'
_RX_SET_DATE_HYPH_Y2F_MNUM = re.compile(r'%y-%m-%d')    # 'yy-mm-dd'
_RX_SET_DATE_HYPH_Y4F_MNAME = re.compile(r'%Y-%b-%d')   # 'YYYY-bbb-dd'
_RX_SET_DATE_HYPH_Y2F_MNAME = re.compile(r'%y-%b-%d')   # 'yy-bbb-dd'
_RX_SET_DATE_DASH_Y4F_MNUM = re.compile(r'%Y/%m/%d')    # 'YYYY/mm/dd'
_RX_SET_DATE_DASH_Y2F_MNUM = re.compile(r'%y/%m/%d')    # 'yy/mm/dd'
_RX_SET_DATE_DASH_Y4F_MNAME = re.compile(r'%Y/%b/%d')   # 'YYYY/bbb/dd'
_RX_SET_DATE_DASH_Y2F_MNAME = re.compile(r'%y/%b/%d')   # 'yy/bbb/dd'
# (SET) -> times
_RX_SET_TIME_USEC_DOT = re.compile(r'%H:%M:%S.%f')      # HH:MM:SS.usec
_RX_SET_TIME_USEC_COMMA = re.compile(r'%H:%M:%S,%f')    # HH:MM:SS,usec
_RX_SET_TIME_SEC = re.compile(r'%H:%M:%S')              # HH:MM:SS
_RX_SET_TIME_MIN = re.compile(r'%H:%M')                 # HH:MM
# regex search patterns for COMMON DATE/TIME SETTINGS (e.g. 'YYYY-mm-dd HH:MM:SS:usec')
# (DAT) -> dates
_RX_DAT_DATE_HYPH_Y4F_MNUM = re.compile(r'\d{4}-\d{2}-\d{2}')           # 'YYYY-mm-dd'
_RX_DAT_DATE_HYPH_Y2F_MNUM = re.compile(r'\d{2}-\d{2}-\d{2}')           # 'yy-mm-dd'
_RX_DAT_DATE_HYPH_Y4F_MNAME = re.compile(r'\d{4}-[a-zA-Z]{3}-\d{2}')    # 'YYYY-bbb-dd'
_RX_DAT_DATE_HYPH_Y2F_MNAME = re.compile(r'\d{2}-[a-zA-Z]{3}-\d{2}')    # 'yy-bbb-dd'
_RX_DAT_DATE_DASH_Y4F_MNUM = re.compile(r'\d{4}/\d{2}/\d{2}')           # 'YYYY/mm/dd'
_RX_DAT_DATE_DASH_Y2F_MNUM = re.compile(r'\d{2}/\d{2}/\d{2}')           # 'yy/mm/dd'
_RX_DAT_DATE_DASH_Y4F_MNAME = re.compile(r'\d{4}/[a-zA-Z]{3}/\d{2}')    # 'YYYY/bbb/dd'
_RX_DAT_DATE_DASH_Y2F_MNAME = re.compile(r'\d{2}/[a-zA-Z]{3}/\d{2}')    # 'yy/bbb/dd'
_RX_DAT_DATE_DASH_Y4L_MNUM = re.compile(r'\d{2}/\d{2}/\d{4}')           # 'dd/mm/YYYY'
_RX_DAT_DATE_DASH_Y2L_MNUM = re.compile(r'\d{2}/\d{2}/\d{2}')           # 'dd/mm/yy'
# (DAT) -> times
_RX_DAT_TIME_USEC_DOT = re.compile(r'\d{2}:\d{2}:\d{2}[.]{1}\d')    # 'HH:MM:SS.usec'
_RX_DAT_TIME_USEC_COMMA = re.compile(r'\d{2}:\d{2}:\d{2}[,]{1}\d')  # 'HH:MM:SS,usec'
_RX_DAT_TIME_SEC = re.compile(r'\d{2}:\d{2}:\d{2}')                 # 'HH:MM:SS'
_RX_DAT_TIME_MIN = re.compile(r'\d{2}:\d{2}')                       # 'HH:MM'
# (DAT) -> time-zone
_RX_DAT_TZONE = re.compile(r'[+,-]\d{4}')                 # +0130'
_RX_DAT_TZONE_COLONS = re.compile(r'[+,-]\d{2}[:]\d{2}')  # -01:30'
# Notes: 
# (1) The above regex search patterns for common date/time settings cover:
#   - "European-style dates" (using hyphens, 4/2-digit years first, numeric/named months)
#   - "US-style dates" (using dashes, 4/2-digit years, year first/last, numeric/named months)
#   - "times" (w/ various precisions)
# (2) Further differentiation has to be made w.r.t. to operating regime, i.e. if applied to
#   - parameter 'settings' to *define* the format (SET)
#   - or given 'data' from which time values are inferred (DAT)
# (3) For the date, it is emphasized that the "all-two-digits" formats cannot be fully 
#     differentiated when inferring from data! (i.e. 'yy/mm/dd' ~ 'dd/mm/yy' might be confused)
# (4) For time zones, the special "Z" (zulu) notation is captured as well but will be suppressed
#     during conversions.


class TimeSpec():
    """ Basic time specification (e.g. used for class 'zynamon.zeit.TimeSeries'). """
   
    def __init__(self, x=None):
        """ Initializes a 'TimeSpec' instance (i.e. an empty one or for input 'x').

        The main purpose of this class is to provide a unified handling for the different ways
        of describing time instants by a mapping of the definitions acc. to 'MAP_TIME'!

        Specification (str|type|example)                  => Description
        ----------------------------------------------------------------------------------------
        'stamp_ns'|int         |1657186852027276032       => Integer timestamp [ns], e.g. InfluxDB
        'stamp'   |float       |1657186852.027276         => POSIX timestamp [s], e.g. 'datetime'
        'iso'     |str         |'2022-10-20 19:02:44'     => String in default '_TS_ISO_FORMAT'
        'obj_dt'  |dt.datetime |dt.datetime(2025 [,...])  => Object 'dt.datetime' (w/ fields)
        'obj_pd'  |pd.Timestamp|Timestamp('2025-...')     => Object 'pd.Timestamp' (w/ fields)

        ...or...
        detailed formats e.g.  |'%y/%b/%d %H:%M:%S.%z'    => arbitrary string formats
        ----------------------------------------------------------------------------------------
        """

        # general attributes
        self.python_type = None # original Python type of input (e.g. pd.Series or list)
        self.type = None        # defined  type [str] ('stamp'|'stamp_ns'|'iso'|'obj_dt'|'obj_pd')
        self.fmt = ''           # detailed time format/precision [str] (only for 'iso' type)

        # array-specific attributes (only reasonable for associated array)
        self.Ts = -1        # sampling interval [s] (will typically be averaged)
        self.scale = 1.0    # scaling factor [float]
        self.shift = 0.0    # temporal offset [float]
        self.stat = None    # advanced statistics [dict]
        # Note: The 'stat' is initialized to 'None' to indicate that no analysis has been done.

        # apply proper mapping on input 'x' (if already provided)
        if (x is not None): # ACTUAL DATA...?
            if ((type(x) in (int, float, dt.date, dt.datetime, pd.Timestamp, # scalars...
                             list, np.ndarray, pd.Series))                  # ...arrays...  
                or ((type(x) is str) and re.search(S_NUMBER, x))):          # ...str incl. numbers                
                self.from_data(x)  
            # ...or SPECIFICATION?        
            elif ((x in MAP_TIME.keys())                             # some type...
                  or ((type(x) is str) and (x in MAP_TIME.values())) # ...str w/ "type name"...
                  or ((type(x) is str) and (True))):                 # ... str w/ detailed format ;) 
                self.from_param(x)

        return
    
    def __repr__ (self): # -> used for direct statement in console
        return f"TimeSpec '{self.type}' w/ fmt='{self.fmt}'"
    
    def __str__(self): # -> used for 'print()'
        return f"TimeSpec '{self.type}' w/ fmt='{self.fmt}'"

    def __eq__(self, other):
        """ Checks equality of own properties with those of 'other'. """
        return ((self.type == other.type) and (self.fmt == other.fmt)) 
    

    def get(self):
        """ Returns basic type/format (e.g. as "target" to enforce onto other objects). """
        if (self.fmt != ''):
            return self.fmt
        else:
            return self.type


    def set(self, scale=None, shift=None, Ts=None):
        """ Sets none or more parameters for the interpretation of the time array.
         
        Notes: 
        (1) Modifiers 'scale' and 'shift' should be exclusively set in this way!
        (2) Both of these values are applied "accumulatively", i.e.:
                any 'scale' will be *multiplied* w/ the existing one
                any 'shift' will be *added* to the existing one (using proper sign)
        (3) Setting 'Ts' through the method should only be used for imports (in order to avoid
            re-conversion operations in case of string-based time formats)

        Args: 
            scale (float, optional): Scaling factor (for compression of stretching of axis).
            shift (float, optional): Offset (for shifting to past/future time instants).
            Ts (float, optional): Sampling time as previously determined by a call to 
                'TimeSeries.time_analyse()'.

        Returns:
            --
        """       
        if (scale is not None):
            self.scale *= scale
        if (shift is not None):
            self.shift += shift   
        if (Ts is not None):
            self.Ts = Ts # hard over-write!
        return


    def from_param(self, t_par, check_known=False):
        """ Sets time specification acc. to a desired in 't_par' (i.e. either type or strings).

        Arg:
            t_par (type or str): Time specification to be set w/ possible ways of parametric 
                definition acc. to type|str|formatted string (see examples below).
            check_known (bool, optional): Switch to check if the provided format matches *any*
                known pattern, only applicable for 'iso'. Defaults to 'False'.

        Returns:
            --

        Note: If no other/detailed format is given 'TS_ISO_FORMAT' is used for string types/'iso'!

        Examples:
            (type)     't_par':   int       |float  |str  |dt.datetime
            (string)   't_par':   'stamp_ns'|'stamp'|'iso'|'obj_dt'|'obj_pd'
            (detailed) 't_par':   '%Y-%m-%d %H:%M:%S.%f' (acc. to ISO 8601 / RFC3339)
        """
        self.python_type = type(t_par)
        
        # determine internal type
        if (self.python_type is type):
            self.type = MAP_TIME[t_par]
        elif (t_par in set(MAP_TIME.values())):
            self.type = t_par
        elif (self.python_type is str):
            self.type = 'iso'
        else:
            raise ValueError(f"Unknown parameter input '{t_par}'")      

        # determine (detailed) format
        if (self.type == 'iso'):
            if ((t_par is str) or (t_par == 'iso')):
                self.fmt = TS_ISO_FORMAT
            else:
                if (check_known):
                    # try to match w/ known DATE patterns...
                    if ((_RX_SET_DATE_HYPH_Y4F_MNUM.match(t_par) is not None) or
                        (_RX_SET_DATE_HYPH_Y2F_MNUM.match(t_par) is not None) or
                        (_RX_SET_DATE_HYPH_Y4F_MNAME.match(t_par) is not None) or
                        (_RX_SET_DATE_HYPH_Y2F_MNAME.match(t_par) is not None) or
                        (_RX_SET_DATE_DASH_Y4F_MNUM.match(t_par) is not None) or
                        (_RX_SET_DATE_DASH_Y2F_MNUM.match(t_par) is not None) or
                        (_RX_SET_DATE_DASH_Y4F_MNAME.match(t_par) is not None) or
                        (_RX_SET_DATE_DASH_Y2F_MNAME.match(t_par) is not None)): # -> date ok
                        # ...then try to match w/ known TIME pattern / precision
                        if ((_RX_SET_TIME_USEC_DOT.search(t_par) is not None) or
                            (_RX_SET_TIME_USEC_COMMA.search(t_par) is not None) or
                            (_RX_SET_TIME_SEC.search(t_par) is not None) or
                            (_RX_SET_TIME_MIN.search(t_par) is not None)): # -> time ok
                            self.fmt = t_par
                        else:
                            raise ValueError(f"Unknown time pattern in '{t_par}'")
                    else:
                        raise ValueError(f"Unknown date pattern in '{t_par}'")
                else:
                    self.fmt = t_par # i.e. apply w/o checking
        else:
            self.fmt = ''

        return


    def from_data(self, t_dat):
        """ Sets time specification acc. to time data in 't_dat' (i.e. scalar or array).

        Args:
            t_dat (scalar or array): Data sample or array from which to derive the infomration. 
                For arrays, only the 1st item is analysed sicne assuming a "homogeneous" structure.

        Returns:
            --

        Examples:
            (scalar) 't_dat':   '2022-10-20 19:02'  or '2025-07-07T19:02:44.123456Z'
            (array)  't_dat':   [1657186852.027276, 1657188744.037128, ... ]
        """
        self.python_type = type(t_dat)

        # get 1st element (= prototype) for further analysis
        if (self.python_type in (list, np.ndarray)):
            t_chk = t_dat[0]
        elif (self.python_type is pd.Series):
            t_chk = t_dat.iloc[0]
        else:
            if (self.python_type is str):
                try:
                    t_chk = int(t_dat)
                except:
                    try:
                        t_chk = float(t_dat)
                    except:
                        t_chk = t_dat
            else:
                t_chk = t_dat
        # Note: Even if input data is a string, try to map it to a number (int? / float?).
        # This is done for more robust importing of CSV-data where read items may often be 
        # surrounded by superfluous '' or "" ;)

        # determine internal type
        if (type(t_chk) in (int, np.int64)): # Note: 'np.int32' can't hold 'stamp_ns' precision!
            self.type = 'stamp_ns'
        elif (type(t_chk) in (float, np.float32, np.float64)):
            self.type = 'stamp'
        elif (type(t_chk) in (dt.date, dt.datetime)):
              self.type = 'obj_dt'
        elif (type(t_chk) is pd.Timestamp):
            self.type = 'obj_pd'
        elif (type(t_chk) is str):
            if (t_chk.find('.') >= 0):
                try:
                    t_chk = float(t_chk)
                    self.type =  'stamp'
                except:
                    try:
                        t_chk = int(t_chk)
                        self.type =  'stamp_ns'
                    except:
                        self.type = 'iso'
            else: # if no decimal point
                try: 
                    t_chk = int(t_chk)
                    self.type =  'stamp_ns'
                except:
                    self.type = 'iso'
        else:
            raise ValueError(f"Unknown data input '{t_dat}'")

        # determine (detailed) format
        if (self.type == 'iso'):
            self.fmt = infer_iso_fmt_from_data(t_chk)
        else:
            self.fmt = ''

        return


    # def force_spec(self, ts):
    #     """ Force same TimeSpec as represented by 'self' onto TimeSeries 'ts'.

    #     Args:
    #         ts (:obj:): TimeSeries object ("slave").

    #     Returns:
    #         ts_mod (:obj:): Output object w/ converted time representation (if required).
    #     """

    #     if (self == ts.time):
    #         return ts
    #     else: # i.e. time-specs are different
    #         if (self.fmt != ''):
    #             return convert_time(ts, self.fmt)
    #         else:
    #             return convert_time(ts, self.type)   





#-----------------------------------------------------------------------------------------------
# MODULE FUNCTIONS
#-----------------------------------------------------------------------------------------------

def convert_time(t_in, target, factor=None, offset=None):
    """ Converts 't_in' to the given 'target' (w/ optional 'factor' and 'offset').

    Input 't_in' will typically refer to a time array; however, scalar inputs are also handeled
    in the same way (e.g. for representing time intervals). The function works in a "lazy" way,
    trying to avoid conversion work if not required and may thus return quickly if no changes
    apply. Modifications on a time array may be enforced by using the 'factor' (multiplicative)
    and 'offset' (additive) options.

    Notes:
    (1) Modifications (factor / offset) are only available for 'stamp'-type inputs!
    (2) For more information on used time formats, refer to 'zynamon.zeitspec.TimeSpec'.

    Args:
        t_in (array or scalar): Input time value(s). For speed & simplicity, all elements are
            assumed to be of same type such that case-switching needs to be done only once.
        target (scalar): Desired time specification.
        factor (float, optional): Scaling factor for stretching (> 1.0) or squeezing (< 1.0)
            consecutive samples along the time axis. Defaults to 'None'.
        offset (scalar, optional): Additional offset that can be given in *any format* supported
            by 'zynamon.zeit.TimeSpec' and which shall be applied to all array elements before
            conversion (but *after* factor). Defaults to 'None'.

    Returns:
        t_out (scalar or list): Properly converted time value(s) of same dimension as 't_in'.
    """
    t_out = []
    
    # determine specifications of input & desired output
    src = TimeSpec(t_in)
    tgt = TimeSpec(target)
    if (src.python_type is str):
        scalar_input = True
    else:
        try:
            len(t_in)
            scalar_input = False
        except:
            scalar_input = True
     
    # ensure consistency of scaling & offset (only for 'stamp'/'stamp_ns' inputs)
    fac, off = 1.0, 0.0
    if ((src.type == 'stamp') or (src.type == 'stamp_ns')):
        if (factor is not None):
            try:
                fac = float(factor)
            except:
                raise ValueError(f"Unknown scaling {factor} specified!")
        if (offset is not None):
            try:
                off = convert_time(offset, 'stamp')
            except:
                raise ValueError(f"Unknown offset {offset} specified!")
    # Note: For any other source type, these settings (if any) are ignored!
    
    # "laziness checks" (i.e. bypass if actually nothing to do ;)   
    if (src.type == tgt.type):       
        if ((tgt.type in ('stamp', 'stamp_ns')) and (off == 0.0) and (fac == 1.0)):           
            return t_in
        elif ((tgt.type == 'iso') and (src.fmt == tgt.fmt)):            
            return t_in
        elif (tgt.type == 'obj_dt'):             
            # enforce conversion for "date-only" inputs!
            if (scalar_input):              
                if (type(t_in) is dt.date):
                    return dt.datetime(t_in.year, t_in.month, t_in.day)
                else:
                    return t_in
            elif (type(t_in[0]) is dt.date):               
                for tn in t_in:
                    tmp = dt.datetime(tn.year, tn.month, tn.day)
                    t_out.append(tmp)
                return t_out
            else:
                return t_in
        else: # (tgt.type == 'obj_pd'):           
            return t_in 

    # init conversion
    if (scalar_input):
        t_in = [t_in] 
    
    # convert to desired output type
    if (src.type == 'stamp'):
        for tn in t_in:
            tmp = tn*fac + off
            if (tgt.type == 'stamp'):
                t_out.append( tmp )
            elif (tgt.type == 'stamp_ns'):
                t_out.append( int(1e9*tmp) )
            elif (tgt.type == 'iso'):
                obj = pd.Timestamp(1e9*tmp)
                t_out.append( obj.strftime(tgt.fmt) )
            elif (tgt.type == 'obj_dt'):
                t_out.append( dt.datetime.fromtimestamp(tmp, tz=dt.timezone.utc) )
            elif (tgt.type == 'obj_pd'):
                t_out.append( pd.Timestamp(1e9*tmp) )

    elif (src.type == 'stamp_ns'):
        for tn in t_in:
            tmp = (float(tn)/1e9)*fac + off
            if (tgt.type == 'stamp'):
                t_out.append( tmp )
            elif (tgt.type == 'stamp_ns'):
                t_out.append( int(1e9*tmp) )
            elif (tgt.type == 'iso'):
                obj = pd.Timestamp(1e9*tmp)
                t_out.append( obj.strftime(tgt.fmt) )
            elif (tgt.type == 'obj_dt'):
                t_out.append( dt.datetime.fromtimestamp(tmp, tz=dt.timezone.utc) )
            elif (tgt.type == 'obj_pd'):
                t_out.append( pd.Timestamp(1e9*tmp) )

    elif (src.type == 'iso'):
        for tn in t_in:
            # handle & suppress special "zulu" time zone (if required)
            if (src.fmt.endswith('%Z')):
                try:
                    tmp = pd.to_datetime(tn[:-1], format=src.fmt[:-2]) # i.e. remove 'Z'
                except:
                    # we have mixed formats?!?
                    tmp = pd.to_datetime(tn) ##, format='mixed')
            else:               
                try:
                    tmp = pd.to_datetime(tn, format=src.fmt)
                except: 
                    # we have mixed formats?!?
                    tmp = pd.to_datetime(tn) ##, format='mixed')
            #fixme: above is a quick hack, but we don't know what's going on! :( 
            #todo: better approach would be to explicitly allow a "mixed-format approach"  

            # normal data conversion
            if (tgt.type == 'stamp'):
                t_out.append( tmp.timestamp() )
            elif (tgt.type == 'stamp_ns'):
                t_out.append( int(1e9*tmp.timestamp()) )
            elif (tgt.type == 'iso'):
                t_out.append( tmp.strftime(tgt.fmt) )
            elif (tgt.type == 'obj_dt'):
                t_out.append( dt.datetime.fromtimestamp(tmp.timestamp(), tz=dt.timezone.utc) )
            elif (tgt.type == 'obj_pd'):
                t_out.append( tmp )

    elif (src.type == 'obj_dt'):
        for tn in t_in:            
            # handle "date-only" inputs
            if (type(tn) is dt.date):
                tmp = dt.datetime(tn.year, tn.month, tn.day)
            else:
                tmp = tn

            # normal data conversion
            if (tgt.type == 'stamp'):
                t_out.append( tmp.timestamp() )
            elif (tgt.type == 'stamp_ns'):
                t_out.append( int(1e9*tmp.timestamp()) )
            elif (tgt.type == 'iso'):
                t_out.append( tmp.strftime(tgt.fmt) )
            # elif (tgt.type == 'obj_dt'):
            #     t_out.append( tmp ) 
            elif (tgt.type == 'obj_pd'):
                t_out.append( pd.Timestamp(tmp) )
       
    elif (src.type == 'obj_pd'):
        for tn in t_in:
            tmp = tn
            if (tgt.type == 'stamp'):
                t_out.append( tmp.timestamp() )
            elif (tgt.type == 'stamp_ns'):
                t_out.append( int(1e9*tmp.timestamp()) )
            elif (tgt.type == 'iso'):
                t_out.append( tmp.strftime(tgt.fmt) )
            elif (tgt.type == 'obj_dt'):
                t_out.append( dt.datetime.fromtimestamp(tmp.timestamp(), tz=dt.timezone.utc) )
            # elif (tgt.type == 'obj_pd'):
            #     t_out.append( tmp )

    # Note: Missing/commented branches are already covered by the "laziness checks" above! ;)
    
    # return output (matching to input type/shape)
    if (src.python_type is pd.Series):
        return pd.Series(t_out) # Note: This will inherently convert 'obj_dt' type to 'obj_pd'
    elif (src.python_type is np.ndarray):
        return np.array(t_out)
    elif (scalar_input):
        return t_out[0]
    else:
        return t_out


def infer_iso_fmt_from_data(t_str):
    """ todo 
    
    Note: Although the (powerful) pandas call 'pd.to_datetime(t_str, format='ISO8601)' works
    perfectly, it will *NOT* provide information on the actually used format.

    Args:
        t_str (str): String representing a time instant as data.

    Returns:
        full_fmt (str): Pattern string matching the found data format using the placeholders
            common to formatting (e.g. '%Y-%m-%dT%H:%M:%S.%f%z').
    """
    full_fmt = ''

    # step 1: try to match w/ known DATE patterns
    if (_RX_DAT_DATE_HYPH_Y4F_MNUM.match(t_str) is not None):
        fmt_date = '%Y-%m-%d'
    elif (_RX_DAT_DATE_HYPH_Y2F_MNUM.match(t_str) is not None):
        fmt_date = '%y-%m-%d'
    elif (_RX_DAT_DATE_HYPH_Y4F_MNAME.match(t_str) is not None):
        fmt_date = '%Y-%b-%d'
    elif (_RX_DAT_DATE_HYPH_Y2F_MNAME.match(t_str) is not None):
        fmt_date = '%y-%b-%d'
    elif (_RX_DAT_DATE_DASH_Y4F_MNUM.match(t_str) is not None):
        fmt_date = '%Y/%m/%d'
    elif (_RX_DAT_DATE_DASH_Y2F_MNUM.match(t_str) is not None):
        fmt_date = '%y/%m/%d'
    elif (_RX_DAT_DATE_DASH_Y4F_MNAME.match(t_str) is not None):
        fmt_date = '%Y/%b/%d'
    elif (_RX_DAT_DATE_DASH_Y2F_MNAME.match(t_str) is not None):
        fmt_date = '%y/%b/%d'
    elif (_RX_DAT_DATE_DASH_Y4L_MNUM.match(t_str) is not None):
        fmt_date = '%d/%m/%Y'
    elif (_RX_DAT_DATE_DASH_Y2L_MNUM.match(t_str) is not None):
        fmt_date = '%d/%m/%y'
    else:
        fmt_date = ''        
    # Note: The last one actually cannot be reached since "all-two-digits" formats may
    # be mixed up --> i.e. 'yy/mm/dd' ~ 'dd/mm/yy'!
     
    # step 2: try to match w/ known TIME pattern & precision           
    if (_RX_DAT_TIME_USEC_DOT.search(t_str) is not None):
        fmt_time = '%H:%M:%S.%f'
    elif (_RX_DAT_TIME_USEC_COMMA.search(t_str) is not None):
        fmt_time = '%H:%M:%S,%f'
    elif (_RX_DAT_TIME_SEC.search(t_str) is not None):
        fmt_time = '%H:%M:%S'
    elif (_RX_DAT_TIME_MIN.search(t_str) is not None):
        fmt_time = '%H:%M'
    else:
        fmt_time = ''

    # step 3: combining things...
    if ((fmt_date == '') or (fmt_time == '')):
        sep = '' # no separator required
    elif ('T' in t_str):
        sep = 'T'
    else:
        sep = ' '
    full_fmt = fmt_date + sep + fmt_time
    # Note that the above data and/or time detection allows for both "date-only" 
    # ('2022-10-08') as well as "time-only" ('12:07:32') formats to be ingested...

    # step 4: handling of time-zones
    if (_RX_DAT_TZONE.search(t_str) is not None):
        full_fmt += '%z'
    elif (_RX_DAT_TZONE_COLONS.search(t_str) is not None):
        full_fmt += '%z'
    elif (t_str[-1] == 'Z'):
        full_fmt += '%Z' # catch & signal special "zulu" notation
    else:
        pass

    return full_fmt



################################################################################################
# EXPLANATIONS
################################################################################################
#
# Format Codes for 'strftime()' and 'strptime()'
# [ https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior ]
#
#   %Y      Year with century as a decimal number.              0001, …, 2013, 2014, …, 9999
#   %y      Year w/o century as a zero-padded decimal number.   00, 01, …, 99
#   %m      Month as a zero-padded decimal number.              01, 02, …, 12
#   %d      Day of the month as a zero-padded decimal number.   01, 02, …, 31
#
#
#   %H      Hour (24-hour) as a zero-padded decimal number.     00, 01, …, 23
#   %M      Minute as a zero-padded decimal number.             00, 01, …, 59
#   %S      Second as a zero-padded decimal number.             00, 01, …, 59
#   %f      Microsecond as a decimal number, zero-padded.       000000, 000001, …, 999999
#
#   %b      Month as locale’s abbreviated name.                 Jan, Feb, …, Dec (en_US)
#                                                               Jan, Feb, …, Dez (de_DE)
#
#   %a      Weekday as locale’s abbreviated name.               Sun, Mon, …, Sat (en_US)
#                                                               So, Mo, …, Sa (de_DE)
#
#   %A      Weekday as locale’s full name.                      Sunday, Monday, …, Sat. (en_US)
#                                                               Sonntag, Montag, …, Sam. (de_DE)
#
################################################################################################