"""
Time-series for managing datapoint objects w/ samples from arbitrary time instants.
"""
import os
import h5py
import json
import numpy as np
import pickle as pk
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from scipy.signal import lfilter

from zynamon.zeitspec import TimeSpec, convert_time, MAP_TIME
from zdev.core import local_val
from zdev.indexing import get_num_digits
from zdev.validio import valid_prec, valid_str_name


# EXPORTED DATA
MAP_VALUE = {
    float: 'float', np.float32: 'float', np.float64: 'float',
    int: 'int', np.int32: 'int', np.int64: 'int',
    bool: 'bool',
    str: 'str'
    }
TS_SAVE_FORMATS = ('pk', 'h5', 'json', 'parquet')
TS_INDEX_LIMIT = int(1e12)
# Note: The 'TS_INDEX_LIMIT' is used to enable & differentiate a NORMAL, "DIRECT" INDEXING for
# time arrays.That is, integer values < 'TS_INDEX_LIMIT' are *not* interpreted as 'stamp_ns' but
# as actual array indices. This implies the following (negligible ;) restrictions:
#   (i) direct indexing is limited to arrays up to ~ 1 trillion samples length
#   (ii) very small times of type 'stamp_ns' cannot be represented by 'TimeSeries', however:
#        int(1e12) as 'stamp_ns'  ==>  '1970-01-01 00:16:40.000000' as 'iso'

# INTERNAL PARAMETERS & DEFAULTS
_JSON_INDENT = 4        # define JSON export (options: [int]|'None' -> one line, very small!)
_HDF5_STR_ENC = 'utf-8' # encoding for HDF5 export w/ string arrays (options 'ascii'|'utf-8')
_HDF5_ZIP_LEVEL = 4     # compression level for 'gzip' (default: 4, 0=min to 9=max)
_HDF5_SHUFFLE = True    # switch for data shuffeling (Note: May improve data compression!)
_PRINT_ONELINE = True   # switch to print preview on single line (otherwise: vertically)
_FILTER_MODES = (
    'FIR_LP_MA',
    'IIR_1pole', 'IIR_flexpole',
    'NL_max', 'NL_min', 'NL_median',
    'box_avg', 'box_max', 'box_min', 'box_median',
)
_DF_TIME = 't'  # !! DO NOT CHANGE !! internal dataframe's time label !! DO NOT CHANGE !!
_DF_VALUE = 'x' # !! DO NOT CHANGE !! internal dataframe's values label !! DO NOT CHANGE !!


class TimeSeries():
    """ Time-series based on 'pandas.DataFrame' w/ additional container information. """

    def __init__(self, name, tags=None):
        """ Initializes an empty time-series object.

        Args:
            name (str): Unique name identifying the time-series. This may contain '.' or '_'.
            tags (dict, optional): Dictionary of 'keyword: value' pairs descibring the context
                of the time-series data (e.g. 'location: Erlangen' etc). Defaults to 'None'.            

        Returns:
            --
        """

        # public attributes
        self.df = pd.DataFrame(columns=(_DF_TIME,_DF_VALUE)) # joint container for arrays
        self.name = name        # identifier for the time-series
        self.num_batches = -1   # number of batches (if progressive construction)
        self.meta = {}          # dict for additional "meta" data tags
        if (tags is not None):
            for key in tags:
                self.meta[key] = tags[key]
        self.time = None        # time specification object (incl. type/format)
        self.parent = None      # reference to parent object (in case of non-inplace operations)
        self.history = []       # keep track of important modifications to the object

        return

    def __repr__ (self): # -> used for direct statement in console
        return f"TimeSeries '{self.name}' w/ {len(self)} samples (and {len(self.meta.keys())} tags)"

    def __str__(self): # -> used for 'print()'
        name = f"TimeSeries '{self.name}':"
        if (_PRINT_ONELINE):
            if (len(self) < 5):
                return name+"  [ not enough samples (yet) ]  "+"\n"
            else:
                if (self.time.type == 'stamp'):
                    str_t = f"  t: [ {self[0].t:8.3f}, {self[1].t:8.3f}, ...  {self[-2].t:8.3f}, {self[-1].t:8.3f}]"
                elif ((self.time.type == 'stamp_ns') or (self.time.type == 'iso')):
                    str_t = f"  t: [ {self[0].t}, {self[1].t}, ...  {self[-2].t}, {self[-1].t}]"
                else: # 'obj' ?
                    str_t = "  t: [ unknown ]"
                if (self.get_type_x() == 'str'):
                    str_x = f"  x: [ {self[0].x}, {self[1].x}, ...  {self[-2].x}, {self[-1].x}]"
                else:
                    str_x = f"  x: [ {self[0].x:8.3f}, {self[1].x:8.3f}, ...  {self[-2].x:8.3f}, {self[-1].x:8.3f}]"               
                return name+"\n"+str_t+"\n"+str_x
        else:
            if (len(self) < 5):
                return name+"\n"+self.df.to_string()+"\n"
            else:
                head = self.df.head(2).to_string()
                tail = self.df.tail(2).to_string(header=False)
                return name+"\n"+head+"\n"+"..."+"\n"+tail+"\n"

    def __len__(self):
        return len(self.df)

    def __bool__(self):
        return len(self.df) > 0

    def __getitem__(self, n):
        # return self.df.loc[n]
        return self.df.iloc[n]    

    def __setitem__(self, n, item):
        self.df.iloc[n] = item
        return

    def __add__(self, other):
        """ Operation + """
        from zynamon.utils import relate
        return relate(self, other, '+', res=None, mode='avg')

    def __sub__(self, other):
        """ Operation - """
        from zynamon.utils import relate
        return relate(self, other, '-', res=None, mode='avg')

    def __mul__(self, other):
        """ Operation * """
        from zynamon.utils import relate
        return relate(self, other, '*', res=None, mode='avg')

    def __truediv__(self, other):
        """ Operation / """
        from zynamon.utils import relate
        return relate(self, other, '/', res=None, mode='avg')


    def clear(self, keep_history=False):
        """ Clears DataFrame arrays (name & tag attributes are kept).

        Args:
            keep_history (bool, optional): Switch to keep information on operations on the
                time-series. Defaults to 'False'.

        Returns:
            --
        """
        self.df = pd.DataFrame(columns=(_DF_TIME,_DF_VALUE))
        self.num_batches = 0
        self.time = None
        if (not keep_history):
            self.history = []
        return


    def clone(self, new_name=None, keep_history=True):
        """ Creates an exact copy of the object w/ potentially 'new_name'.

        Args:
            new_name (str, optional): New name for TimeSeries object, otherwise this will be
                set to 'self.name'+'_'. Defaults to 'None'.
            keep_history (bool, optional): Switch to keep information on operations on the
                time-series. Defaults to 'False'.

        Returns:
            ts_out (:obj:): Cloned 'TimeSeries' object (w/ batch counter reset).
        """

        # copy basic structure
        ts_out = TimeSeries('')
        for key in ts_out.__dict__:
            if (key == 'name'):
                # set new name?
                if (new_name is None):
                    ts_out.name = self.name+'_'
                else:
                    ts_out.name = new_name
            elif (key == 'df'):
                exec(f"ts_out.{key} = self.{key}.copy()")
            else: # all other members
                try:
                    exec(f"ts_out.{key} = self.{key}.copy()")
                except:
                    exec(f"ts_out.{key} = self.{key}") # no true copy! (will have *same* 'id')

        # update
        ts_out.num_batches = 1
        ts_out.parent = id(self)
        if (not keep_history):
            ts_out.history = []

        return ts_out


    def print(self, num_samples=None, end='tail'):
        """ Prints 'num_samples' items of time-series from 'end'.

        Args:
            num_samples (int, optional): Number of lines to print. Defaults to 'None' (= all).
            mode (str, optional): Indicate if data should be printed from 'head' or 'tail'.
                Defaults to 'tail' (i.e. most recent samples from the end).

        Returns:
            --
        """
        name = f"TimeSeries '{self.name}':"
        if (num_samples is None):
            body = eval(f"self.df.{end}(len(self)).to_string()")
        else:
            body = eval(f"self.df.{end}({num_samples}).to_string()")
        print("\n"+name+"\n"+body+"\n")
        return


    def stats(self, content='all'):
        """ Prints some statistics of time-series.

        Args:
            content (str, optional): Select which content to be shown w/ available options
                'all'|'size'|'time'. Defaults to 'all'.
        Returns:
            --
        """
        print("- "*8)
        print(f"Statistics on TimeSeries '{self.name}':")
        if (not len(self)):
            print("[ still empty ]")
            return print("- "*8)            
        
        if (content in ('all','size')):            
            print(f"[ size ]")
            print(f"  - # samples: {len(self)}")
            print(f"  - interval: [{self[0].t}, {self[-1].t}]")

        if (content in ('all','time')):
            print(f"[ time ]")
            self.time_analyse()
            print(f"  - Ts avg:     {self.time.Ts}")
            print(f"  - Ts range:   [{self.time.stat['Ts_min']}, {self.time.stat['Ts_max']}]")            
            print(f"  - Ts std dev: ~ {self.time.stat['Ts_sigma']:.3f}")
            print(f"  - Ts quality: {self.time.stat['quality']}")
        else:
            pass

        return print("- "*8)


    def samples_add(self, new_samples, time_key=None, value_key=None, analyse=True, 
                    incognito=False):
                    # hysteresis=False, hyst_rel=0.01,
                    # hyst_params={'mode': 'suppress', 'min_dev': 0.001, 'max_silence': '60sec'})
                    # #### TODO!
        """ Adds new samples to TimeSeries object.

        New samples may be presented in many formats and will be consumed accordingly. In
        addition, some internal analyses may be carried out as well. However, it should be
        noted that for calling loops w/ "one-sample-at-a-time" behaviour, the overall import
        procedure will perform significantly faster if 'analyse=False'. In this way, no updating
        is carried out in each step, but could be triggered on demand later on...

        Note: In contrast to other methods 'samples_add()' is INHERENTLY INPLACE only!

        Args:
            new_samples (dict or list): Object containing new samples for the object. These may
                be given in one of the following formats/structures:
                + existing 'TimeSeries' object
                + existing 'DataFrame' object
                + dict w/ {time_key: [...], value_key: [...]}
                + zip of 2-tuples where each item represents [time, value]
                + list/tuple/np.ndarray of 2-tuples as [time, value]
                + list/tuple/np.ndarray of dicts w/ scalar items as {time_key: ..., value_key: ...}
                + flat list/np.ndarray (time is created as "natural" 0-based index then)
            time_key (str, optional): If required, this defines the key by which time instants
                are recognised. Defaults to 'None' (i.e. use internal _DF_TIME).
            value_key (str, optional): If required, this defines the key by which sample values
                are recognised. Defaults to 'None' (i.e. use internal _DF_VALUE).
            analyse (bool, optional): Switch to update internal indicators (at the cost of
                slower imports if done sample-wise). Defaults to 'True'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.

        ### TODO!
        # hysteresis stuff?
        ### TODO!

        Returns:
            --
        """

        # init
        kt = _DF_TIME if (time_key is None) else time_key
        kv = _DF_VALUE if (value_key is None) else value_key

        # auto-detect format of input samples
        if (istimeseries(new_samples)):
            mode = 'ts'
        elif ((type(new_samples) is pd.DataFrame) and
              (set([kt,kv]).issubset(new_samples.columns))):
            mode = 'df'
        elif (type(new_samples) is dict):
            mode = 'dict'
        elif (type(new_samples) is zip):
            mode = 'zip'
        elif (type(new_samples) in (list, tuple, np.ndarray)):
            if (type(new_samples[0]) in (list, tuple, np.ndarray)):
                mode = 'list-of-tuples'
            elif (type(new_samples[0]) is dict):
                mode = 'list-of-dicts'
            else:
                mode = 'list-values'
        else:
            raise ValueError('Unknown format of new samples')
        
        # ingest new samples by preparing a dataframe (acc. to mode)
        if (mode == 'ts'):
            df_new = new_samples.df

        elif (mode == 'df'):
            df_new = new_samples[[kt,kv]]

        elif (mode == 'dict'):
            if (not set([kt,kv]).issubset(new_samples.keys())):
                raise KeyError(f"Missing time/value keys '{kt}'/'{kv}' in dict")
            if (len(new_samples[kt]) != len(new_samples[kv])):
                raise ValueError('Inconsistent number of time/value items')
            df_new = pd.DataFrame( data={_DF_TIME: new_samples[kt], _DF_VALUE: new_samples[kv]} )

        elif (mode in ('zip', 'list-of-tuples')):
            unzipped = list(zip(*new_samples))
            df_new = pd.DataFrame(data={_DF_TIME: unzipped[0], _DF_VALUE: unzipped[1]})

        elif (mode == 'list-of-dicts'):
            new_unwrapped = { key: [item[key] for item in new_samples] for key in (kt,kv) }
            df_new = pd.DataFrame( data={_DF_TIME: new_unwrapped[kt], _DF_VALUE: new_unwrapped[kv]} )

        else: # mode == 'list-values'
            time_unknown = -1 * np.ones_like(new_samples)
            df_new = pd.DataFrame(data={_DF_TIME: time_unknown, _DF_VALUE: new_samples})
            # Note: Setting 'time_unknown' to NaN values yields trouble when serializing! :(

        #
        # TODO: include hysteresis here...
        #

        # ensure same time format & extend object by current batch
        if (self.df.empty): # initial batch (get spec from data)
            self.time = TimeSpec(df_new.t)
            self.df = df_new
        else: # auto-convert (if required)
            df_new.t = convert_time(df_new.t, self.time.get())
            self.df = pd.concat([self.df, df_new], ignore_index=True)
        self.num_batches += 1

        # perform internal analyses?
        if (analyse or (self.time.Ts == -1)):
            self.time_analyse()

        if (not incognito):
            self.history.append(('@samples_add', len(df_new)))

        return


    def samples_crop(self, selected, incognito=False, inplace=True, addon='_cropped'):
        """ Crops matching time frame of 'selected' data & creates new 'TimeSeries'.

        If the time instants referred to by 'selected' are not directly found in the object's
        time array (e.g. due to limits exceeding array range), the effective selection is
        shrinked accordingly such that only parts inside the interval are returned. If no valid
        range is found at all, 'selected' is either in the "future" or in the "past".

        For simplicity and intuitive use, a direct indexing is provided as well. That is,
        if 'selected' contains integers less than 'TS_INDEX_LIMIT', these are interpreted as
        normal indices of the time array (rather than 'stamp_ns').

        Note: Unexpected behaviour may occur if the time-series is *not* sorted as "causal"!

        Args:
            selected (2-tuple or scalar): Frame definition by interval or scalars in *any form*
                supported by 'zynamon.zeit.TimeSpec'. Note that interval boundaries [A,B] are 
                both *inclusive* (i.e. 'df.iloc[A]' as well as 'df.iloc[B]' are present in the 
                resulting frame) whereas scalars represent a "cropping from the end", i.e. 
                are resolved into a range '[len(df)-selected:]'. In particular, also "mixed" 
                intervals w/ start/end points of different 'TimeSpec' types are supported!
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series. Defaults to '_cropped'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' as frame of original w/ only 'selected' samples
                (unless 'inplace' operation).
        """

        # ensure "usable" format
        orig_spec = self.time.get()
        arr_t = convert_time(self.df.t, 'stamp')        

        # determine mode of selection
        direct_indexing = False
        try:
            len(selected)
            if (type(selected) is str):
                raise # Note: dummy to jump to "except" branch ;)
            else:
                mode = 'interval'
                if (((type(selected[0]) is int) and (type(selected[1]) is int)) and
                    (selected[0] <= selected[1] < TS_INDEX_LIMIT)):
                    direct_indexing = True
        except:
            mode = 'scalar'
            if ((type(selected) is int) and (selected < TS_INDEX_LIMIT)):
                direct_indexing = True

        # evaluate condition
        if (direct_indexing):
            if (mode == 'scalar'):
                cond_tmp = (self.df.index > len(self)-(selected+1))
            else: # == 'interval'
                cond_tmp = ((self.df.index >= selected[0]) & (self.df.index <= selected[1]))
            condition = pd.Series(cond_tmp)
        else:
            if (mode == 'scalar'): # i.e. interval "from the end"
                t_sel = convert_time(selected, 'stamp')
                condition = (arr_t >= arr_t.iloc[-1]-t_sel)
            else: # == 'interval'
                tmp = TimeSpec(selected[0])
                selected[1] = convert_time(selected[1], target=tmp.get())
                t_sel = convert_time(selected, 'stamp')
                condition = ((arr_t >= t_sel[0]) & (arr_t <= t_sel[1]))
                # Note: The above "TimeSpec forcing" is done to support "mixed intervals"!

        # actual frame cropping
        if (inplace):
            self.df.where(condition, inplace=True)
            self.df.dropna(inplace=True)
            self.num_batches = 1
            if (not incognito):
                self.history.append(('@samples_crop', selected))
            return
        else:           
            df_cond = self.df.where(condition)
            df_crop = df_cond.dropna()         
            ts_out = self.clone(self.name+addon)
            ts_out.clear(keep_history=True)
            if (len(df_crop)):
                ts_out.samples_add(df_crop, incognito=True)
                ts_out.time_convert(orig_spec, incognito=True)            
            if (not incognito):
                ts_out.history.append(('@samples_crop', selected))
            return ts_out


    def samples_pack(self, agg_time=(5*60), agg_mode='avg',
                     incognito=False, inplace=True, addon='_packed'):
        """ Compresses the time-series samples acc. to the chosen aggregation mode.

        This method essentially performs a call to 'values_filter()' w/ a time-boxed filter
        mode and a subsequent call to 'time_align()' w/ the same time window. By this, the
        number of samples can be considerably reduced and the whole time-series is replaced by
        a downsampled version representing the desired compression.

        Args:
            agg_time (float, optional): Time interval [s] used for aggregation, i.e. resolution
                after downsampling. Defaults to 5 minutes, i.e. '300' sec.
            agg_mode (str, optional): Mapping mode for aggregation. Defaults to 'avg'.
                Available options comply with the 'box_' modes of the 'values_filter()' method,
                i.e. options are 'avg'|'max'|'min'|'median'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_packed'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).
        """

        if (inplace):
            self.values_filter('box_'+agg_mode, {'box_time': agg_time}, incognito=True)
            self.time_align(agg_time, shift='center', recon='nearest', incognito=True)
            if (not incognito):
                self.history.append(('@samples_pack', f"agg_time={agg_time}, agg_mode={agg_mode}"))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.values_filter('box_'+agg_mode, {'box_time': agg_time}, incognito=True)
            ts_out.time_align(agg_time, shift='center', recon='nearest', incognito=True)
            if (not incognito):
                ts_out.history.append(('@samples_pack', f"agg_time={agg_time}, agg_mode={agg_mode}"))
            return ts_out

     #------------------------------------------------------------------------------------------
     # TODO: How to implement a "filter/compress" mode for string values?
     #       --> e.g. do NOT repeat same string until next 'box_time' ????
     #      --> i.e. check on 'has_string_values' or get type??
     #------------------------------------------------------------------------------------------

    # def samples_crucialize(self, hyst_level_rel=0.01, hyst_time_max=5*60, incognito=False):
    #                 # hysteresis=False, hyst_rel=0.01,
    #                 # hyst_params={'mode': 'suppress', 'min_dev': 0.001, 'max_silence': '60sec'})
    #                 # #### TODO!
    #     """ Re-interprets samples of TimeSeries object by keeping only relevant ones.

    #     # TODO;: This is an 'hysteresis' function on the existing object.
    #     #       --> TO BE ADDED also to "samples_add"

    #         --
    #     """
    #     # mylocals = hist_locals(locals())
    #     pass
    #     return


    def samples_unique(self, array=None, keep='first', causalise=False,
                       incognito=False, inplace=True, addon='_unique'):
        """ "Streamlines" time-series by removing duplicates and retaining only unique data.

        Args:
            array (str, optional): Switch to select either _DF_TIME or _DF_VALUE to check for
                duplicates. Otherwise, only samples where both time & value are identical are 
                counted. Defaults to 'None' (i.e. check both).
            keep (str, optional): Which occurrences to keep w/ options 'first'|'last'. Defaults
                to 'first'.
            causalise (bool, optional): Switch to sort time array in ascending order (after
                removing duplicates). Defaults to 'False'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_unique'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).
        """
        if (inplace):
            self.df.drop_duplicates(array, keep=keep, inplace=True, ignore_index=True)
            if (causalise):
                self.time_causalise(inplace=True, incognito=True)
            if (not incognito):
                self.history.append(('@samples_unique', f"array={array}, keep='{keep}', causalise={causalise}"))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.df.drop_duplicates(array, keep=keep, inplace=True, ignore_index=True)
            if (causalise):
                ts_out.time_causalise(inplace=True, incognito=True)
            if (not incognito):
                ts_out.history.append(('@samples_unique', f"array={array}, keep='{keep}', causalise={causalise}"))
            return ts_out


    def time_align(self, res=1.0, shift='bwd', recon='avg', allow_expand=True,
                   interpol='linear', incognito=False, inplace=True, addon='_aligned'):
        """ Aligns time-series samples by temporally quantising to 'res' intervals.

        This method essentially applies an "anti-jitter" mechanism to the time-series samples.
        That is, all samples are strictly aligned to multiples of the given temporal resolution
        such that a perfect equi-distant sampling rate is generated while the associated values
        have to be mapped. For this reconstruction / interpolation scheme, two fundamental
        effects should be kept in mind:

        Notes:
        (1) The resulting NUMBER OF SAMPLES will generally be different from the original!
            For 'res > Ts', an aggregation is performed where the arrays are COMPRESSED due to
            the inherent "many-to-one" mapping, whereas for 'res < Ts' the amount of samples may
            be kept the same, but will increase if 'expand' is enabled!
        (2) The resulting time-series may represent a NON-CAUSAL VERSION of the original!
            For the default 'bwd' shift, this is the case as the samples are "pulled back"
            compared to the original time axis whereas the "fwd" will shift these to the future
            of the data stream. For reasonably small resolutions (< 1s) and typical applications
            (e.g. IoT sensors w/ larger 'Ts'), implications may still be considered negligible.
            However, the output of the "bwd" mode *could* be interpreted as a "faster response"
            e.g. for generating alarms etc. ;)

        Args:
            res (float, optional): Desired resolution [s] to which mapping should occur.
                Defaults to 1.0 (one sample each sec).
            shift (str, optional): Direction of mapping. Defaults to 'bwd'. Available options:
                 + 'bwd'    -> backwards, i.e. towards the most recent time instant
                 + 'fwd'    -> forwards, i.e. to the future time instant.
                 + 'center' -> centered, only useful when "packing" data where 'res > Ts'
                               (Note: Expansion will be disabled in this case!)
            recon (str, optional): Reconstruction / assignment method for time-series values.
                Defaults to 'avg'. Available options:
                + 'nearest'  -> use only first/last value in mapping (dep. on 'shift')
                + 'avg       -> use arithmetic average of values in mapping
                + 'weighted' -> use weighted averaging w/ contributions proportional to the
                                distance between original and mapped time instants
            allow_expand (bool, optional): Switch to allow expansion of the time-series if
                required (i.e. if 'res' < 'Ts') along with a suitable interpolation method to
                fill the missing values. Defaults to 'True'.
            interpol (str, optional): Interpolation mode to be used in case of time-series
                expansion. All methods supported by 'pd.DataFrame.interpolate' could be chosen,
                however, currently only 'pad'|'linear' are supported. If set to 'None', values
                will not be filled but remain marked as 'np.NaN'. Defaults to 'linear'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_aligned'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).

        Example: Illustration of alignment for 'res=1.0', shift='bwd' and recon='avg':

            ORIGINAL:
            t:  0.0   0.5    1.0 1.3    2.1    2.8    3.4   4.0               5.7   6.2      7.1
                  |     |      |   |      |      |      |     |                 |     |        |
            x:    1     2      3   4      5      6      7     8                 9    10       11

            ALIGNED w/ "coarser" resolution: 'res=1.0' --> aggregation
            t:  0.0        1.0         2.0       3.0        4.0        5.0        6.0        7.0
                  |          |           |         |          |          |          |          |
            x:  1.5        3.5         5.5       7.5         8          9         10        11.0

            ALIGNED w/ "finer" resolution: 'res=0.2' --> and only "padding" of values
            t:  0.0 .2 .4 .6 .8 1.0 .2 .4 .6 .8 2.0 .2 .4 .6 .8 3.0 .2 .4 .6 .8 4.0    (...)
                  |               |               |               |               |    (...)
            x:    1  1  2  2  2   3  4  4  4  4   5  5  5  5  6   6  6  7  7  7   8    (...)
        """

        # TODO: Apply "causalise" as well?
        # --> introduce this? flag set, until "breaking" operation is triggered! ;)

        # init processing arrays
        orig_spec = self.time.get()
        arr_t, arr_x, _ = self.to_numpy(float)

        # init
        Nd = get_num_digits(res)
        map_idx, map_dist = {}, {}
        if (shift == 'bwd'):
            bit_more = 0
        elif (shift == 'fwd'):
            bit_more = 1
        elif (shift == 'center'):
            bit_more = 0.5
            allow_expand, interpol = False, False # disabled (see above for explanation)

        # track mapping of sample values onto new time instants (which indices & distance?)
        for n in range(len(self)):
            tmp = float( res * (int(arr_t[n]/res) + bit_more) )
            tn = valid_prec(tmp, Nd)
            if (tn not in map_idx.keys()):
                map_idx[tn] = [n,]
                map_dist[tn] = [arr_t[n]-tn,]
            else:
                map_idx[tn].append(n)
                map_dist[tn].append(arr_t[n]-tn)
        t_new = list(map_idx.keys())

        # generate values for new samples (using desired reconstruction mode)
        x_new = np.zeros_like(t_new, dtype=float)
        for n, tn in enumerate(t_new):
            if (tn not in map_idx.keys()):
                continue
            else:
                tmp = 0.0

                if (recon == 'nearest'): # use only first/last value of mapping
                    if (shift == 'bwd'):
                        x_new[n] = arr_x[map_idx[tn][0]]
                    else: # shift == 'fwd'
                        x_new[n] = arr_x[map_idx[tn][-1]]

                elif (recon == 'avg'): # use simple arithmetic average
                    N = len(map_idx[tn])
                    for t_map in map_idx[tn]:
                        tmp += arr_x[t_map]
                    x_new[n] = tmp/N

                elif (recon == 'weighted'): # use weighted average (acc. to time distance)
                    W = 0.0
                    for n_map, t_map in enumerate(map_idx[tn]):
                        weight = 1.0 - (abs(map_dist[tn][n_map])/res)
                        tmp += arr_x[t_map] * weight
                        W += weight
                    x_new[n] = tmp/(W + 1e-9) # Note: 1e-9 for regulation!

                # elif (recon == 'sinc'): # TODO? other?
                #     pass

                else:
                    raise NotImplementedError(f"Unknown reconstruction '{recon}' specified")

        # expansion of time-series? (in case of finer resolution)
        if (allow_expand):

            # init "full ranged" temporal resolution
            tA = float( res * (int(arr_t[0]/res) + bit_more) )
            tB = float( res * (int(arr_t[-1]/res) + 1) )
            t_res = np.arange(tA, tB, res, dtype=float)
            x_res = np.empty(len(t_res))
            x_res[:] = np.nan

            # (a) find support values
            for nr, tr in enumerate(t_res):
                try:
                    nn = t_new.index( valid_prec(tr, Nd) )
                    x_res[nr] = x_new[nn]
                except:
                   continue

            # (b) create DataFrame w/ final time (incl. offset)
            df_aligned = pd.DataFrame({_DF_TIME: np.array(t_res), _DF_VALUE: x_res})

            # (c) interpolate remaining missing values (acc. to mode)
            if (interpol is not None):
                if (interpol == 'pad'):
                    exec(f"df_aligned.ffill(axis=0, inplace=True)")
                elif (interpol in ('linear',)):
                    exec(f"df_aligned.interpolate('{interpol}', axis=0, inplace=True)")
                else:
                    raise NotImplementedError(f"Unknown interpolation '{interpol}' specified")

        else:
            df_aligned = pd.DataFrame({_DF_TIME: np.array(t_new), _DF_VALUE: x_new})

        # update or create new (time-aligned) object
        if (inplace):
            self.clear(keep_history=True)
            self.samples_add(df_aligned, incognito=True)
            self.time_convert(orig_spec, incognito=True)
            if (not incognito):
                self.history.append(('@time_align', f"res={res}, shift='{shift}', recon='{recon}', allow_expand={allow_expand}, interpol='{interpol}'"))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.clear(keep_history=True)
            ts_out.samples_add(df_aligned, incognito=True)
            ts_out.time_convert(orig_spec, incognito=True)
            if (not incognito):
                ts_out.history.append(('@time_align', f"res={res}, shift='{shift}', recon='{recon}', allow_expand={allow_expand}, interpol='{interpol}'"))
            return ts_out


    def time_analyse(self):
        """ Analyse time array-specific parameters of time-series data. 
        
        Note that this will cover the (average) sampling rate and statistics of the array 
        whereas 'scale' and 'shift' modifiers are only to be set by the 'set_mods()' method!
        """

        # init container for advanced statistics (if not yet existing)
        if (not self.time.stat):
            self.time.stat = {
                'quality': 'too-few-samples',   # general quality of time array
                'Ts_max': -1,         # maxiumum time difference between consecutive samples
                'Ts_min': -1,         # minimum time difference between consecutive samples
                'Ts_sigma': -1,       # standard deviation (of time differences)
                'Ts_sigma_norm': -1,  # normalized standard deviation (of time differences)
                'dev_fac_Ts_max': -1, # maximum sampling rate deviation factor
                'dev_fac_Ts_min': -1, # minimum sampling rate deviation factor
                }        

        # ensure "usable" format for analysis & check basic suitability
        arr_t = convert_time(self.df.t, float)        
        if (len(arr_t) == 1): # single sample (yet)?
            self.time.Ts = -1
            return
        elif (arr_t.iloc[0] == arr_t.iloc[-1]): # samples w/o time? (i.e. mode 'list-values')
            self.time.Ts = -1
            return
        
        # determine (average) sampling rate
        delta_t = arr_t.diff()
        idx = (delta_t != 0.0) # exclude all "0.0" entries (i.e. duplicate time instants!)
        self.time.Ts = round(delta_t[idx].mean(), 9)
        
        # compute additional statistics
        self.time.stat['Ts_max'] = round(delta_t[idx].max(), 9)
        self.time.stat['Ts_min'] = round(delta_t[idx].min(), 9) # Note: Robustify due to division below!
        self.time.stat['Ts_sigma'] = round(delta_t[idx].std(), 9)
        self.time.stat['Ts_sigma_norm'] = round(self.time.stat['Ts_sigma']/self.time.Ts, 9)
        self.time.stat['dev_fac_Ts_max'] = round(self.time.stat['Ts_max']/self.time.Ts, 9)
        self.time.stat['dev_fac_Ts_min'] = round(self.time.Ts/self.time.stat['Ts_min'], 9)

        # assess quality of time array
        if (self.time.stat['Ts_sigma_norm'] <= 0.001): # i.e. < 0.1%
            self.time.stat['quality'] = 'equidistant'
        elif (self.time.stat['Ts_sigma_norm'] <= 0.1): # i.e. < 10%
            self.time.stat['quality'] = 'jittered'
        else: # i.e. > 10%
            self.time.stat['quality'] = 'dispersed'

        return


    def time_causalise(self, incognito=False, inplace=True, addon='_causal'):
        """ Ensures all samples are stored in ascending temporal order.

        Args:
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_causal'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).
        """
        if (inplace):
            self.df.sort_values(_DF_TIME, ascending=True, inplace=True)
            self.time_analyse()
            if (not incognito):
                self.history.append(('@time_causalise', None))
            return
        else:
            tmp = self.df.sort_values(_DF_TIME, ascending=True)
            ts_out = self.clone(self.name+addon)
            ts_out.clear(keep_history=True)
            ts_out.samples_add(tmp, analyse=True, incognito=True)
            if (not incognito):
                ts_out.history.append(('@time_causalise', None))
            return ts_out


    def time_convert(self, target, factor=None, offset=None, incognito=False):
        """ Converts time array to 'target' w/ optional scaling 'factor' and/or 'offset'.

        Notes:
        (1) Modifications (scaling / offset) are only available for 'stamp'-type inputs!
        (2) Both operations work "in-place" and in the order of arguments.
        (3) For more infos on 'TimeSeries' time formats, refer to 'TimeSpec()'.

        Args:
            target (scalar): Desired time specification.
            factor (float, optional): Scaling factor for all times. Defaults to 'None'.
            offset (scalar, optional): Additional offset (in *any* supported timespec) to be
                applied for all times.  Defaults to 'None'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.

        Returns:
            --
        """

        # anticipate change in sampling rate (if any)
        if ((self.time.Ts != -1) and (factor is not None)):
            new_Ts = self.time.Ts * factor
        else:
            new_Ts = None

        # array conversion
        self.df.t = convert_time(self.df.t, target, factor, offset)

        # update parameters
        self.time = TimeSpec(target)
        self.time.set(scale=factor, shift=offset, Ts=new_Ts)
        if (not incognito):
            self.history.append(('@time_convert', f"'{target}', factor={factor}, offset={offset}"))
        
        return


    def time_reset(self, incognito=False):
        """ Resets time array to original values (i.e. re-format w/o offset).

        Args:
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.

        Returns:
            --
        """
        if ((self.time.scale != 1.0) or (self.time.shift != 0.0)):
            # ensure timespec is determined & "usable" format
            orig_spec = self.time.get()
            self.time_convert('stamp')
            # reverse modifications
            rev_scaling = 1./self.time.scale
            rev_offset = -self.time.shift
            self.time_convert(orig_spec, scaling=rev_scaling, offset=rev_offset,
                              incognito=incognito)
        else:
            pass # nothing to do ;)
        return


    def values_filter(self, mode='FIR_LP_MA',
                      params={'N': 10, 'pole': [0.9,0.3], 'smooth': 0.15, 'box_time': (5*60)},
                      init=True, incognito=False, inplace=True, addon='_filtered'):
        """ Filters the values array 'df.x' acc. to a desired 'mode'.

        The default mode provides a moving-average over N=10 samples, realising a "lazy" FIR
        low-pass filter. For a better preservation of peaks while still smoothing less dynamic
        segments, use the sophisticated IIR-type filter w/ "flexible pole".

        Args:
            mode (str, optional): Type of filter implementation. Defaults to 'FIR_LP_MA'.
                Available options & sub-options areas follows:
                + 'FIR': Transversal finite impulse response filtering w/ fixed length 'N'.
                    - '_LP_MA'    -> rectangular shape (i.e. "moving average")
                + 'IIR': Recursive filtering acc. to given poles.
                    - '_1pole'    -> single pole (e.g. "forgetting factor")
                    - '_flexpole' -> flexible-pole approach (e.g. for preserving peaks during
                                    dynamic phases while smoothing otherwise)
                + 'NL': Sample-wise nonlinear filtering based on length 'N' sliding window.
                    - '_max'      -> select maximum within window
                    - '_min'      -> select minimum within window
                    - '_median'   -> select median value within window
                + 'box': Time-boxed filtering operation, based on the actual durations
                    found in the time array 'df.t'. All values within the box are replaced
                    by this filtered value.
                    - '_avg'      -> block-wise averaging (= arithmetic mean)
                    - '_max'      -> use maximum within t-box
                    - '_min'      -> use minimum within time-box
                    - '_median'   -> use median value within time-box
            params (dict, optional): Dictionary of filter parameters. Note that this depends on
                the chosen 'mode', i.e. not all parameters are required for every filter mode.
                Defaults to {'N': 10, 'pole': [0.9,0.3], 'smooth': 0.15, 'box_time': (5*60) },
                where the individual entries refer to:
                + 'N' (int): Filter length in case of 'FIR' or 'NL' modes.
                + 'pole' (float(s)): Pole(s) in case of 'IIR' modes.
                + 'smooth' (float): Relative distance between successive sample values to
                                    distinguish between "dynamic" and "smoothing" phases.
                + 'box_time' (float): Fixed time window in [s] in case of 'box_' modes.
            init (bool, optional): Switch to keep original values as long as filter is being
                filled in order to avoid ramp-up effects. Defaults to 'True'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_filtered'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).

        Example:
            Using a "flexible pole" (i.e. toggeling between two significantly different
            forgetting factors) in order to preserve peaks while also apply smoothing in less
            dynamic phases. That is:
                y[n] = pole * y[n-1] + (1-pole) * x[n]
            where
                pole = val_smooth   if  (1-smooth)*y[n] <= x[n] <= (1+smooth)*y[n]
                pole = val_dynamic  else
            and
                0.0 < val_dynamic << val_smooth < 1.0
        """

        # check availability (Note: Done here in order to prevent checking in loops!)
        if (mode not in _FILTER_MODES):
            raise NotImplementedError(f"Unknown filtering '{mode}' specified")

        # init processing arrays
        arr_t, arr_x, _ = self.to_numpy(float)
        xf = np.zeros_like(self.df.x)

        # FIR types
        if (mode.startswith('FIR')):
            # init
            N = params['N']
            buffer = 0.0
            for k in range(N):
                buffer += arr_x[k]
                if (init):
                    xf[k] = arr_x[k]
                else:
                    xf[k] = buffer/(1+k)
            # main phase
            if (mode == 'FIR_LP_MA'):
                tmp = lfilter(np.ones(N), [1], arr_x)
                xf[N:] = (1./N) * tmp[N:]
            else:
                pass #TODO: implement more variants?

        # IIR types
        elif (mode.startswith('IIR')):

            if (mode == 'IIR_1pole'):
                pole = params['pole'][0]
                if (init):
                    xf, _ = lfilter([(1-pole)], [1,-pole], arr_x, zi=[pole*arr_x[0]])
                else:
                    xf = lfilter([(1-pole)], [1,-pole], arr_x)

            elif (mode == 'IIR_flexpole'):
                pole_smooth = params['pole'][0]
                pole_dynamic = params['pole'][1]
                smoothing_range = params['smooth']
                if (init):
                    xf[0] = arr_x[0]
                else:
                    xf[0] = pole_smooth*0.0 + (1-pole_smooth)*arr_x[0]
                for n in range(1, len(self)):
                    if (abs((arr_x[n]/xf[n-1])-1.0) <= smoothing_range):
                        xf[n] = pole_smooth*xf[n-1] + (1-pole_smooth)*arr_x[n]
                    else:
                        xf[n] = pole_dynamic*xf[n-1] + (1-pole_dynamic)*arr_x[n]
            else:
                pass #TODO: implement more variants?

        # NL types
        elif (mode.startswith('NL')):
            # init
            N = params['N']
            if (init):
                buffer = arr_x[0] * np.ones(N)
            else:
                buffer = np.zeros(N)
            # main phase
            for k in range(len(self)):
                for n in range(N-1):
                    buffer[n] = buffer[n+1]
                buffer[N-1] = arr_x[k]
                if (mode == 'NL_max'):
                    xf[k] = np.max(buffer)
                elif (mode == 'NL_min'):
                    xf[k] = np.min(buffer)
                elif (mode == 'NL_median'):
                    xf[k] = np.median(buffer)

        # box types
        elif (mode.startswith('box')):

            # init
            Tb = params['box_time']
            v = int(arr_t[0]/Tb) # boundaries w.r.t. *absolute* time -> large frame numbers!
            t_start = v * Tb
            t_end = t_start + Tb
            timebox = []
            k = 0

            # block processing w/ strict time checking
            for n, tn in enumerate(arr_t):

                # buffer samples in "timebox"
                if (tn < t_end):
                    timebox.append( arr_x[n] )
                    continue # with next sample

                # compute respective value...
                if (mode == 'box_avg'):
                    val = np.mean(timebox)
                elif (mode == 'box_max'):
                    val = np.max(timebox)
                elif (mode == 'box_min'):
                    val = np.min(timebox)
                elif (mode == 'box_median'):
                    val = np.median(timebox)
                else:
                    val = 0.0 #TODO: implement more variants? (e.g. weighted?)

                # ...and assign to whole timebox
                N_box = len(timebox)
                xf[k:k+N_box] = val * np.ones(N_box)

                # determine next frame (i.e. timebox of sample that has already been "touched")
                v = int(tn/Tb)

                # reset buffer & update counters
                timebox = [ arr_x[n] ]
                t_start = v * Tb
                t_end = t_start + Tb
                k += N_box

        # update or create new (filtered) object
        if (inplace):
            self.df.x = list(xf)
            if (not incognito):
                self.history.append(('@values_filter', f"mode='{mode}', params={params}"))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.values_set(xf, incognito=True)
            if (not incognito):
                ts_out.history.append(('@values_filter', f"mode='{mode}', params={params}"))
            return ts_out


    def values_purge(self, mode='patch_local', params={'N': 3}, outliers=None,
                     incognito=False, inplace=True, addon='_purged'):
        """ Purges values of "outlier" samples (if any) acc. to 'mode' and 'params'.

        Args:
            mode (str, optional): Correction mode for outliers (if any). Defaults to
                'patch_local'. Available options:
                + 'remove'       -> delete outlier samples
                + 'patch_local'  -> patch outlier values by local average around position
                + 'patch_global' -> patch outliers by global mean value
            params (dict, optional): Parameters for correction (if required at all). Defaults
                to {'N': 3} where the individual entries refer to:
                + 'N' (int): (One-sided) width of local window to perform averaging
            outliers (list, optional): List of outlier samples w/ items (n, ts.t[n], ts.x[n]).
                Defaults to 'None' (i.e. automatic detection w/ default settings).
                Note: This allows to use a specific configuration of 'ts_find_outliers()'!
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_purged'.

        Returns:
            ts_out (:obj:): New 'TimeSeries' object (unless 'inplace' operation).
        """
        from zynamon.utils import find_outliers
        
        # init
        df_new = self.to_pandas()

        # perform outlier detection? (w/ default settings)
        if (outliers is None):
            outliers, _ = find_outliers(self)

        # handle all outlier values (if any)
        if (len(outliers)):

            if (mode == 'remove'):
                for item in outliers:
                    df_new.iloc[item[0]] = {_DF_TIME: np.nan, _DF_VALUE: np.nan}
                df_new.dropna(inplace=True)

            elif (mode == 'patch_local'):
                for item in outliers:
                    df_new.loc[item[0],_DF_VALUE] = local_val(self.df.x, item[0], params['N'], mode='avg')
                
            elif (mode == 'patch_global'):
                global_patch = self.df.x.mean()
                for item in outliers:
                    df_new.loc[item[0],_DF_VALUE] = global_patch                  

            else:
                raise NotImplementedError(f"Unknown outlier purge '{mode}' specified")

        # update or create new (filtered) object
        if (inplace):
            self.df = df_new
            if (not incognito):
                self.history.append(('@values_purge', f"mode='{mode}', params={params}"))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.clear(keep_history=True)
            ts_out.samples_add(df_new, incognito=True)
            if (not incognito):
                ts_out.history.append(('@values_purge', f"mode='{mode}', params={params}"))
            return ts_out


    def values_set(self, new_values, incognito=False, inplace=True, addon='_'):
        """ Directly sets 'new_values' for all samples while keeping the time array.

        Note: Although this method may seem useless at first glance, it is in fact a convenience
        function that may come in handy when comparing modified value arrays of the same
        (original) time-series next to other modified versions (e.g. in the same plot).

        Args:
            new_values (list or np.ndarray): Array of values that should be used instead. Note
                that 'len(new_values)' has to match the current 'len(self.df.x)'!
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.
            inplace (bool, optional): Switch for in-place operation. Defaults to 'True'.
            addon (str, optional): String that will be appended to the original name of the
                time-series (*only* in case a new object is returned). Defaults to '_'.

        Returns:
            ts_out (:obj:): 'TimeSeries' object w/ new values (unless 'inplace' operation).
        """

        # check consistency
        if (len(new_values) != len(self)):
            raise ValueError(f"New values do not match size of existing array! {len(new_values)}")

        # directly replace sample values
        if (inplace):
            self.df.x = list(new_values)
            self.num_batches = 1
            if (not incognito):
                self.history.append(('@values_set', None))
            return
        else:
            ts_out = self.clone(self.name+addon)
            ts_out.values_set(list(new_values), incognito=True, inplace=True)
            # Note: No more settings required due to recursion (see above)) ;)
            return ts_out


    def tags_register(self, tags, overwrite=False, incognito=False):
        """ Adds one or more tags to internal meta data.

        Args:
            tags (dict): Dict of tags to be added as key-value pairs.
            overwrite (bool, optional): Switch to force updating of tag values if key already
                exists. Defaults to 'False'.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.

        Returns:
            --
        """
        existing = list(self.meta.keys())
        for key in list(tags.keys()):
            if (key in existing):
                if (overwrite):
                    self.meta[key] = tags[key]
                else:
                    print(f"Warning: Tag '{key}' already exists in meta data! (skipping)")
                    continue
            else:
                self.meta[key] = tags[key]
        if (not incognito):
            self.history.append(('@tags_register', list(tags.keys())))
        return


    def tags_delete(self, tags, incognito=False):
        """ Remove tag(s) under 'keys' from internal meta data (if present).

        Args:
            tags (list): List of tag keys that should be removed from time-series meta data.
            incognito (bool, optional): Switch to avoid history tracking. Defaults to 'False'.

        Returns:
            --
        """
        for key in list(tags):
            if (key in self.meta.keys()):
                del self.meta[key]
        if (not incognito):
            self.history.append(('@tags_delete', tags))
        return


    def to_numpy(self, type_t=None, type_x=None):
        """ Converts both _DF_TIME & _DF_VALUE columns to NumPy arrays (for heavy-lifting ;).

        Args:
            type_t (type or str, optional): Convert time array to any desired type supported by
                'zynamon.zeit.TimeSpec'. Defaults to 'None' (i.e. no conversion).
            type_x (type or str, optional): Convert value array.

        Returns:
            arr_t (np.array): NumPy array representation of 'self.df.t' (pandas Series).
            arr_x (np.array): NumPy array representation of 'self.df.x' (pandas Series).
            types (2-tuple): Original types of contents in time/value arrays (which may be
                required in order to enforce these after processing).
        """
        types = (self.get_type_t(), self.get_type_x())
        arr_t = self.df.t.to_numpy()
        arr_x = self.df.x.to_numpy()
        if (type_t is not None):
            arr_t = convert_time(arr_t, type_t)
        #todo: add conversion for values???
        return arr_t, arr_x, types


    def to_pandas(self):
        """ Converts time-series to plain pandas 'DataFrame' type (e.g. for new objects).

        Returns:
            df_out (:obj:): Plain pandas 'DataFrame' object containing only columns _DF_TIME
                and _DF_VALUE (w/o any meta information).
        """
        df_out = self.df.copy()
        return df_out


    def export_to_file(self, fname=None, overwrite=False, combine=False, keep_history=False,
                       fmt='json'):
        """ Exports the 'TimeSeries' object to a text-based or binary-file.

        This method exports the 'TimeSeries' object to one of the file formats supported by
        'TS_SAVE_FORMATS'. This may be either:
            + JSON:     human readable / dictionary-like (text-based)
            + HDF5:     hierarchical data format (binary)
            + PK:       serialized, "pickled" Python object (binary)
        While the "core" data of the time-series is always stored, information on recent
        operations to the object are only kept if the respective switch is set 'True' as well.
        Note that such information is inherently stored if objects are "pickled" (PK).

        If desired, several 'TimeSeries' objects can be merged into a single file by using the
        'combine' option. This may be useful for the first import of data from CSV-files which
        contain more than one time-series data at once, since this will reflect the hierarchical
        assignment. However, for these scenarios, the following aspects have to be considered:
            (i) The calling application must ensure that 'fname' remains the same for all
                consecutive calls / objects to be stored
            (ii) Switch 'overwrite' has no effect, as file existence is managed internally
            (iii) Consequently, any existing files need to be deleted by the caller before!

        Moreover it needs to be emphasized that the function 'zynamon.imex.write_file()'
        PROVIDES A MUCH HIGHER SPEED FOR LARGE TIME-SERIES COLLECTIONS, since it avoids repeated
        open/write cycles on the files!

        Args:
            fname (str, optional): Desired name to be used for the export file. If none is
                given, this is created from the time-series' name. Defaults to 'None'.
            overwrite (bool, optional): Switch to overwrite existing files. Defaults to 'False'.
            combine (bool, optional): Switch to combine several time-series into one file.
                See above description for notes on usage. Defaults to 'False'.
            keep_history (bool, optional): Switch to keep information on operations on the
                time-series. Defaults to 'False'.
            fmt (str, optional): File format to be stored to w/ available options as in
                'TS_SAVE_FORMATS'. This will also be applied as extension. Defaults to 'json'.

        Returns:
            --
        """

        # core time-series information
        ts_item = _ts_to_dict(self, keep_history)

        # configure filename
        if (fname is None):
            ts_name = valid_str_name(self.name) # Note: This will remove special chars
            the_file = os.path.join(os.getcwd(), ts_name+'.'+fmt)
        else:
            the_file = fname

        # check consistency
        if (fmt not in TS_SAVE_FORMATS):
            raise NotImplementedError(f"Unknown file export type '{fmt}' specified")

        # write time-series to own/single file?
        if (not combine):
            if (os.path.isfile(the_file)):
                if (not overwrite):
                    raise FileExistsError(f"'TimeSeries' file '{the_file}' exists")
            if (fmt == 'json'):
                with open(the_file, mode='w') as jf:
                    json.dump(ts_item, jf, sort_keys=True, indent=_JSON_INDENT)
            elif (fmt in 'h5'):
                with h5py.File(the_file, mode='w') as hf:
                    _ts_to_h5grp(hf, ts_item)
            elif (fmt == 'pk'):
                with open(the_file, mode='wb') as pf:
                     itsme = self # HACK: Required to prevent "It's not the same object" error!
                     pk.dump(itsme, pf)
            elif (fmt == 'parquet'):
                ts_table = pa.Table.from_pandas(self.df)
                pq.write_table(ts_table, the_file)
                # storing 'TimeSeries' meta information             
                with open(the_file+'_meta', mode='wt') as pm:
                    pm.write(f"name: {ts_item['name']}\n")
                    pm.write(f"meta: {ts_item['meta']}\n")
                    pm.write(f"time: \n")
                    for key in ('type','fmt','Ts','shift','scale'):
                        pm.write(f"    {key}: {ts_item['time'][key]}\n")

        # write combination of time-series?
        else:

            if (not os.path.isfile(the_file)): # -> start in 1st call
                if (fmt == 'json'):
                    with open(the_file, mode='w') as jf:
                        json.dump({ts_item['name']: ts_item}, jf, indent=_JSON_INDENT)
                elif (fmt in 'h5'):
                    with h5py.File(the_file, mode='w') as hf:
                        _ts_to_h5grp(hf, ts_item)
                elif (fmt == 'pk'):
                    with open(the_file, mode='wb') as pf:
                        pk.dump({self.name: self}, pf)

            else: # -> actual "combine" for any other times
                if (fmt == 'json'):
                    with open(the_file, mode='r+') as jf:
                        all_data = json.load(jf)
                        all_data[ts_item['name']] = ts_item
                        jf.seek(0)
                        json.dump(all_data, jf, sort_keys=True, indent=_JSON_INDENT)
                elif (fmt in 'h5'):
                    with h5py.File(the_file, mode='a') as hf:
                        _ts_to_h5grp(hf, ts_item)
                elif (fmt == 'pk'):
                    with open(the_file, mode='rb+') as pf:
                        all_data = pk.load(pf)
                        all_data[self.name] = self
                        pf.seek(0)
                        pk.dump(all_data, pf)
                elif (fmt == 'parquet'):
                    pass #todo: is this possible???

        return
    
    
    def export_pk(self, fname=None, overwrite=False, combine=False, keep_history=False):
        """ Exports the 'TimeSeries' object to a HDF5-file.
        This is an alias 'export_to_file(fmt="pk")', see this method for full call signature.
        """
        self.export_to_file(fname, overwrite, combine, keep_history, fmt='pk')
        return
    

    def export_hdf5(self, fname=None, overwrite=False, combine=False, keep_history=False):
        """ Exports the 'TimeSeries' object to a HDF5-file.
        This is an alias 'export_to_file(fmt="h5")', see this method for full call signature.
        """
        self.export_to_file(fname, overwrite, combine, keep_history, fmt='h5')
        return


    def export_json(self, fname=None, overwrite=False, combine=False, keep_history=False):
        """ Exports the 'TimeSeries' object to a JSON-file.
        This is an alias 'export_to_file(fmt="json")', see this method for full call signature.
        """
        self.export_to_file(fname, overwrite, combine, keep_history, fmt='json')
        return   
    

    def export_parquet(self, fname=None, overwrite=False, combine=False, keep_history=False):
        """ Exports the 'TimeSeries' object to a PARQUET-file.
        This is an alias 'export_to_file(fmt="parquet")', see this method for full call signature.
        """
        self.export_to_file(fname, overwrite, combine, keep_history, fmt='parquet')
        return
        

    def get_time_range(self):
        """ Returns numeric time range/span covered by whole array.

        Note: The result will only be meaningful if the time-series *is causal*. However, this
        is only assumed, but *not checked* by this method!
        """
        if (self.time.type == 'stamp'):
            return (self[-1].t - self[0].t)
        else:
            tmp = convert_time([self[0].t, self[-1].t], 'stamp')
            return (tmp[1] - tmp[0])


    def get_type_t(self, check_array=False):
        """ Returns type of DataFrame column _DF_TIME.

        Args:
            check_array (bool, optional): Switch to check whole array, otherwise only the first
                item is checked and this result is assumed for all. Defaults to 'False'.
        Returns:
            type_t (str): Time type found as an element of 'set(MAP_TIME.values())', i.e.
                'stamp_ns'|'stamp'|'iso'|'obj_dt'|'obj_pd'.
        """
        return self.time.type

        #fixme: old stuff, what was the purpose? -> delete?
        # # # get type of 1st time instant
        # # dummy = TimeSpec(self.df.t.iloc[0])

        # # check all other elements?
        # if (not check_array):
        #     return self.time.type
        # else:
        #     for item in self.df.t.iloc[1:]:
        #         dummy = TimeSpec(item)
        #         if (dummy.type != self.time.type):
        #             return None # i.e. array data not consistent
        #     return self.time.type


    def get_type_x(self, check_array=False):
        """ Returns type of DataFrame column _DF_VALUE.

        Args:
            check_array (bool, optional): Switch to check whole array, otherwise only the first
                item is checked and this result is assumed for all. Defaults to 'False'.

        Returns:
            type_x (str): Value type found as an element of 'set(MAP_VALUE.values())', i.e.
                'float'|'int'|'bool'|'str'.
        """

        # get type of 1st sample value
        type_x = MAP_VALUE[type(self.df.x.iloc[0])]

        # check all other elements?
        if (not check_array):
            return type_x
        else:
            for item in self.df.x.iloc[1:]:
                chk_type = type(item)
                if (chk_type != type_x):
                    return None # i.e. array data not consistent #fixme: what to do?
            return type_x


    def is_type_t(self, chk_type, check_array=False):
        """ Validates that DataFrame column _DF_TIME contains (only) values matching 'chk_type'.

        Args:
            chk_type (str): Type of values to be checked for in 'self.df.t' w/ options acc. to
                'set(MAP_TIME.values())' (can be provided by type or as string).
            check_array (bool, optional): Switch to check whole array, otherwise only the first
                item is checked and this result is assumed for all. Defaults to 'False'.
        Returns:
            res (bool): Result of type checking acc. to above settings.
        """

        # convert type to 'timespec' string (if required)
        if (type(chk_type) is type):
            chk_type = MAP_TIME[chk_type]

        # get existing type & compare w/ check
        the_type = self.get_type_t(check_array)
        if (the_type == chk_type):
            return True
        else:
            return False


    def is_type_x(self, chk_type, check_array=False):
        """ Validates that DataFrame column _DF_VALUE contains values matching 'chk_type'.

        Args:
            chk_type (str): Type of values to be checked for in 'self.df.x' w/ available
                options 'float'|'int'|'bool'|'str' (*must be* indicated as string).
            check_array (bool, optional): Switch to check whole array, otherwise only the first
                item is checked and this result is assumed for all. Defaults to 'False'.

        Returns:
            res (bool): Result of type checking acc. to above settings.
        """

        # get existing type & compare w/ check
        the_type = self.get_type_x(check_array)
        if (the_type == chk_type):
            return True
        else:
            return False


    def close(self):
        """ Deletes memory of objects. """
        del self.df
        return



#-----------------------------------------------------------------------------------------------
# PRIVATE FUNCTIONS (only to be used from internal methods, but not to be exposed!)
#-----------------------------------------------------------------------------------------------

def _ts_to_dict(ts, keep_history=False):
    """ Creates a dict item out of a 'TimeSeries' object (e.g. for storing to JSON-files).

    Args:
        ts (:obj:): 'TimeSeries' object from which to create a dict item w/ core information.
            Note that this excludes information that can be recreated once again.
        keep_history (bool, optional): Switch to keep information on operations on the
            time-series. Defaults to 'False'.

    Returns
        ts_item (dict): Corresponding dict (item).
    """

    ts_item = {
        'name': ts.name,
        'arr_t': list(ts.df.t),
        'arr_x': list(ts.df.x),
        'meta': ts.meta,
        # 'time': vars(ts.time), #fixme: this may fail due to types (e.g. in 'python_type'!)
        'time': {
            'type': ts.time.type,
            'fmt': ts.time.fmt,
            'Ts': ts.time.Ts,
            'shift': ts.time.shift,
            'scale': ts.time.scale,
            #'stat': None, # fixme: or don't use?
            } 
    }  

    if (keep_history):
        ts_item['num_batches'] = ts.num_batches
        ts_item['history'] = ts.history

    return ts_item


def _ts_to_h5grp(hf, ts_item):
    """ Creates a group inside an HDF5-file for representing a 'TimeSeries' object.

    This convenience function just "bundles" the necessary writing operations for the HDF5-file.
    Special care needs to be taken for 'str' types in the 'df' arrays, since they have to be
    converted to 'bytes'. All operations are based on a previous conversion to the 'ts_item'
    acc. to the details of '_ts_to_dict()'.

    Args:
        hf (:obj:): Opened HDF5-file.
        ts_item (dict): A dictionary item representing the 'TimeSeries' object.

    Returns
        --
    """

    ts_grp = hf.create_group(name=ts_item['name'])
    for key in ts_item.keys():
        if (key in ('arr_t','arr_x')):
            if (type(ts_item[key][0]) is str):
                data_arr = [ s.encode(_HDF5_STR_ENC, errors='ignore') for s in ts_item[key] ]
            else:
                data_arr = ts_item[key]
            ts_grp.create_dataset(name=key, data=data_arr, chunks=True, compression='gzip',
                                  compression_opts=_HDF5_ZIP_LEVEL, shuffle=_HDF5_SHUFFLE)
        elif (key in ('name','num_batches')):
            ts_grp.attrs[key] = ts_item[key]
        elif (key in ('meta','time')):
            sub_dict = ts_grp.create_group(name=key)
            for k,v in ts_item[key].items():
                sub_dict.attrs[k] = str(v)
        elif (key in ('history')):
            sub_list = ts_grp.create_group(name=key)
            for n, item in enumerate(ts_item[key]):
                sub_list.attrs[str(n)] = str(item)

    return


def _ts_from_dict(ts_item):
    """ Recreates a 'TimeSeries' object from dict item.

    Args:
        ts_item (dict): A dictionary representing the former (core) 'TimeSeries' object as
            typically read from JSON-files. If information on previous operations has been saved
            previously, this data will be enforced as well (see "_ts_to_dict()" for details).

    Returns:
        ts (:obj:): Recreated 'TimeSeries' object.
    """

    # recreate core data (arrays & additional time parameters)
    ts = TimeSeries(ts_item['name'], tags=ts_item['meta'])
    ts.samples_add(zip(ts_item['arr_t'], ts_item['arr_x']), analyse=True)
    # Note: Above call has implicitly created the proper 'TimeSpec'!
    if ('time' in ts_item.keys()):
        for k,v in ts_item['time'].items():
            if (k in ('Ts','shift','scale')): 
                eval(f"ts.time.set({k}={v})")                
    # else: #fixme?
    #     # raise ValueError("No proper time information found in dict item")
    
    # enforce additional, historic information (if present)
    if ('num_batches' in ts_item.keys()):
        ts.num_batches = ts_item['num_batches']
    if ('history' in ts_item.keys()):
        ts.history = []
        for n, item in enumerate(ts_item['history']):
            ts.history.append(tuple(item))

    return ts


def _ts_from_h5grp(ts_item):
    """ Recreates a 'TimeSeries' object from a corresponding group in a HDF5 file.

    Args:
       ts_item (:obj:): A group of an opened HDF5-file, representing 'TimeSeries' data (e.g.
           from a previous saving operation).

    Returns:
        ts (:obj:): Recreated 'TimeSeries' object.
    """

    # decode HDF5 datasets to useable arrays
    if (type(ts_item['arr_t'][0]) is bytes):
        time_arr = [ b.decode(_HDF5_STR_ENC, errors='ignore') for b in ts_item['arr_t'] ]
    else:
        time_arr = np.array( ts_item['arr_t'] )
    if (type(ts_item['arr_x'][0]) is bytes):
        data_arr = [ b.decode(_HDF5_STR_ENC, errors='ignore') for b in ts_item['arr_x'] ]
    else:
        data_arr = np.array( ts_item['arr_x'] )

    # Note: The 'h5py._hl.dataset.Dataset' should either refer to a NumPy-like array (default)
    # or to a 'bytes' from which the original string (as "char-array") needs to be recreated!

    # recreate core data (dict structures)
    meta_dict = {}
    for k,v in ts_item['meta'].attrs.items():
        meta_dict[k] = v
    time_dict = {}
    for k,v in ts_item['time'].attrs.items():
        if (k in ('Ts','scale','shift')):
            time_dict[k] = float(v)

    # recreate core data (arrays & additional time parameters)
    ts = TimeSeries(ts_item.attrs['name'], tags=meta_dict)
    ts.samples_add(zip(time_arr, data_arr), analyse=True)
    for k,v in time_dict.items():
        eval(f"ts.time.set({k}={float(v)})")

    # enforce additional, historic information (if present)
    if ('num_batches' in ts_item.attrs.keys()):
        ts.num_batches = ts_item.attrs['num_batches']
    if ('history' in ts_item.keys()):
        ts.history = []
        for n, (k,v) in enumerate(ts_item['history'].attrs.items()):
            ts.history.append(eval(v))

    return ts


#-----------------------------------------------------------------------------------------------
# MODULE FUNCTIONS
#-----------------------------------------------------------------------------------------------

def istimeseries(obj, accept_type=True):
    """ Checks whether 'obj' is a 'TimeSeries' object and/or the respective type itself.

    Args:
        obj (:obj:): Object (or type) of class 'TimeSeries'.
        accept_type (bool, optional): Switch to indicate that 'obj' may also refer to the *type*
            'class TimeSeries' rather than directly being an object. Defaults to 'True'.

    Returns:
        res (bool): Result of check.
    """
    if (isinstance(obj, TimeSeries)):
        return True
    elif (accept_type and (str(obj).find('zynamon.zeit.TimeSeries') >= 0)):   
        return True
    else:
        return False



################################################################################################
# EXPLANATIONS
################################################################################################
#
# General difference between 'pandas' vs. 'zynamon' methods:
#           pandas.core.frame.DataFrame     -> creates NEW object (per default)
#           zynamon.zeit.TimeSeries         -> works IN-PLACE (per default)
#
# Overview for 'zynamon.zeit.TimeSeries':
#
# .clear            = (fixed) inplace
# .copy             = (fixed) create NEW object
#
# .samples_add      = (fixed) inplace
# .samples_crop     = inplace
# .samples_pack     = inplace
# .samples_unique   = inplace
#
# .time_align       = inplace
# .time_analyse     = (fixed) inplace
# .time_causalise   = inplace
# .time_convert     = (fixed) inplace
# .time_reset       = (fixed) inplace
#
# .values_filter    = inplace
# .values_purge     = inplace
# .values_set       = inplace
#
################################################################################################