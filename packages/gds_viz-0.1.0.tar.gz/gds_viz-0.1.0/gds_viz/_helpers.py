"""Shared helpers for gds-viz renderers."""

from __future__ import annotations


def sanitize_id(name: str) -> str:
    """Convert a name to a valid Mermaid identifier.

    Replaces spaces and special chars with underscores.
    """
    return (
        name.replace(" ", "_")
        .replace("-", "_")
        .replace(".", "_")
        .replace("(", "")
        .replace(")", "")
    )
