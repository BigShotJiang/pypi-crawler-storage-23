# aippy

AI-powered Python CLI tool.

## Installation

```bash
pip install aippy
```

Or with pipx (recommended for CLI tools):

```bash
pipx install aippy
```

## Development

Install in editable mode:

```bash
pip install -e .
```

## Usage

```bash
# Greet someone
aippy hello --name Roman

# Show APP_ENV value
aippy env
```

## Build & Publish

```bash
# Build distribution packages
pip install build
python -m build

# Upload to PyPI
pip install twine
twine check dist/*
twine upload dist/*
```
