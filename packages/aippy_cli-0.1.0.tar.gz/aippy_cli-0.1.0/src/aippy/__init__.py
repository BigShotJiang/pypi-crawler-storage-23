"""aippy - AI-powered Python CLI tool."""

__version__ = "0.1.0"
