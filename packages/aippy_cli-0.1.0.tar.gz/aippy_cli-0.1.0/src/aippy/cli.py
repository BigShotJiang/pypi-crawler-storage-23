import os

import click
from dotenv import load_dotenv

load_dotenv()


@click.group()
def main():
    """aippy - AI-powered Python CLI tool."""
    pass


@main.command()
@click.option("--name", default="World", help="Name to greet")
def hello(name):
    """Greet someone."""
    click.secho(f"Hello {name}", fg="green")


@main.command()
def env():
    """Show current APP_ENV value."""
    value = os.getenv("APP_ENV", "not set")
    click.secho(f"APP_ENV={value}", fg="cyan")


if __name__ == "__main__":
    main()
