"""VecGrep: Cursor-style vector search MCP plugin for Claude Code."""

__version__ = "0.1.0"
