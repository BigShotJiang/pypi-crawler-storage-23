# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2024-2026 SYMFLUENCE Team <dev@symfluence.org>

"""
Single source of truth for the SYMFLUENCE version.
Update this when cutting a release.
"""
# Semantic version (PEP 440-friendly)
__version__ = "0.7.6"
