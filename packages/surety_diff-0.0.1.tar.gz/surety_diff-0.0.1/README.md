# Surety Diff

Contract-aware diff and comparison engine for the Surety ecosystem.

`surety-diff` provides structured, human-readable comparison
for contract-driven service testing.

It is designed to explain *why* data does not match a contract,
not just that it failed.


---

## Installation

```bash
pip install surety-diff
