from .compare import compare
from .rule_decorator import compare_rule
from .diff import Diff
from .rules import *
