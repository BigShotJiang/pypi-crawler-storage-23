# Tasks: AUR Build Fix + CI Validation

- [x] Add `python-setuptools-scm` to `aur/PKGBUILD` makedepends
- [x] Add `python-setuptools-scm` to `aur/stable/PKGBUILD` makedepends
- [ ] Add `validate-aur` job to `.github/workflows/ci.yml`
- [ ] Create PR, verify CI passes
