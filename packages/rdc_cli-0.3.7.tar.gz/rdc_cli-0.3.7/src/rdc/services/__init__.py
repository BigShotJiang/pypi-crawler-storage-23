"""Service layer for rdc-cli."""
