"""
Django Helpers Module
Django-specific pagination and optimization helpers
"""

from typing import Any, Dict, List, Optional
from django.core.paginator import Paginator, Page
from django.http import JsonResponse
from django.db.models import QuerySet

class DjangoPagination:
    """
    Django ORM pagination helper
    Uses offset-based pagination
    """
    
    @staticmethod
    def paginate_queryset(
        queryset: QuerySet,
        page: int = 1,
        per_page: int = 50,
        order_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Paginate Django queryset
        
        Args:
            queryset: Django QuerySet
            page: Page number
            per_page: Items per page
            order_by: Field to order by
            
        Returns:
            Dictionary with paginated data and metadata
        """
        # Apply ordering
        if order_by:
            queryset = queryset.order_by(order_by)
        
        # Create paginator
        paginator = Paginator(queryset, per_page)
        
        # Get page
        page_obj = paginator.get_page(page)
        
        # Build response
        return {
            'data': list(page_obj.object_list.values()),
            'page': page_obj.number,
            'per_page': per_page,
            'total': paginator.count,
            'total_pages': paginator.num_pages,
            'has_more': page_obj.has_next(),
            'has_prev': page_obj.has_previous(),
            'next_page': page_obj.next_page_number() if page_obj.has_next() else None,
            'prev_page': page_obj.previous_page_number() if page_obj.has_previous() else None
        }
    
    @staticmethod
    def paginate_list(
        items: List[Any],
        page: int = 1,
        per_page: int = 50
    ) -> Dict[str, Any]:
        """
        Paginate Python list
        
        Args:
            items: List of items
            page: Page number
            per_page: Items per page
            
        Returns:
            Dictionary with paginated data and metadata
        """
        total = len(items)
        total_pages = (total + per_page - 1) // per_page
        
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        
        return {
            'data': items[start_idx:end_idx],
            'page': page,
            'per_page': per_page,
            'total': total,
            'total_pages': total_pages,
            'has_more': page < total_pages,
            'has_prev': page > 1,
            'next_page': page + 1 if page < total_pages else None,
            'prev_page': page - 1 if page > 1 else None
        }


class DjangoCursorPagination:
    """
    Django ORM cursor pagination helper
    High-performance pagination for large datasets
    """
    
    @staticmethod
    def paginate_queryset(
        queryset: QuerySet,
        cursor: Optional[str] = None,
        limit: int = 50,
        order_by: str = 'id',
        reverse: bool = False
    ) -> Dict[str, Any]:
        """
        Paginate Django queryset using cursor
        
        Args:
            queryset: Django QuerySet
            cursor: Cursor string (last ID)
            limit: Items per page
            order_by: Field to order by
            reverse: Reverse order
            
        Returns:
            Dictionary with paginated data and cursors
        """
        # Apply cursor
        if cursor:
            operator = '__lt' if reverse else '__gt'
            filter_kwargs = {f'{order_by}{operator}': cursor}
            queryset = queryset.filter(**filter_kwargs)
        
        # Apply ordering
        order_field = f'-{order_by}' if reverse else order_by
        queryset = queryset.order_by(order_field)
        
        # Get items (limit + 1 to check has_more)
        items = list(queryset.values()[:limit + 1])
        
        # Check has_more
        has_more = len(items) > limit
        if has_more:
            items = items[:limit]
        
        # Get cursors
        next_cursor = None
        prev_cursor = None
        
        if items:
            next_cursor = str(items[-1][order_by]) if has_more else None
            
            # For prev cursor, we need to query backwards
            if cursor:
                prev_cursor = cursor
        
        return {
            'data': items,
            'limit': limit,
            'has_more': has_more,
            'next_cursor': next_cursor,
            'prev_cursor': prev_cursor,
            'order_by': order_by,
            'reverse': reverse
        }
    
    @staticmethod
    def get_cursor_from_item(item: Any, field: str = 'id') -> str:
        """
        Extract cursor value from item
        
        Args:
            item: Django model instance or dict
            field: Field to use as cursor
            
        Returns:
            Cursor string
        """
        if hasattr(item, field):
            return str(getattr(item, field))
        elif isinstance(item, dict) and field in item:
            return str(item[field])
        return str(item)