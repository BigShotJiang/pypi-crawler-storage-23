"""
Response Compression Module
Gzip compression for large responses
"""

import gzip
import json
from typing import Any, Optional

class ResponseCompressor:
    """
    Compress large responses using gzip
    Reduces bandwidth for large datasets
    """
    
    def __init__(self, min_size_bytes: int = 1024):
        """
        Initialize compressor
        
        Args:
            min_size_bytes: Minimum size to compress (default 1KB)
        """
        self.min_size = min_size_bytes
    
    def compress(self, data: Any) -> bytes:
        """
        Compress data
        
        Args:
            data: Data to compress (will be JSON serialized)
            
        Returns:
            Compressed bytes
        """
        # Serialize to JSON
        if isinstance(data, (dict, list)):
            json_str = json.dumps(data)
        else:
            json_str = str(data)
        
        # Compress
        compressed = gzip.compress(json_str.encode('utf-8'))
        
        return compressed
    
    def decompress(self, compressed_data: bytes) -> Any:
        """
        Decompress data
        
        Args:
            compressed_data: Compressed bytes
            
        Returns:
            Decompressed data
        """
        decompressed = gzip.decompress(compressed_data)
        return json.loads(decompressed.decode('utf-8'))
    
    def should_compress(self, data_size: int) -> bool:
        """
        Check if data should be compressed
        
        Args:
            data_size: Size of data in bytes
            
        Returns:
            True if should compress
        """
        return data_size >= self.min_size
    
    def compress_if_large(self, data: Any) -> tuple:
        """
        Compress data if it's large enough
        
        Args:
            data: Data to potentially compress
            
        Returns:
            Tuple of (data, is_compressed)
        """
        # Estimate size
        if isinstance(data, (dict, list)):
            json_str = json.dumps(data)
            estimated_size = len(json_str.encode('utf-8'))
        else:
            estimated_size = len(str(data).encode('utf-8'))
        
        # Compress if large
        if self.should_compress(estimated_size):
            return self.compress(data), True
        
        return data, False


def gzip_response(data: Any, min_size: int = 1024) -> tuple:
    """
    Helper function to gzip response
    
    Args:
        data: Response data
        min_size: Minimum size to compress
        
    Returns:
        Tuple of (data, headers)
    """
    compressor = ResponseCompressor(min_size)
    compressed, is_compressed = compressor.compress_if_large(data)
    
    headers = {}
    if is_compressed:
        headers['Content-Encoding'] = 'gzip'
        headers['X-Compressed'] = 'true'
    
    return compressed, headers