"""
Query Logger Module
Log and track database query performance
"""

from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from functools import wraps
import time
import threading

class QueryLogger:
    """
    Log database queries with timing
    Helps identify slow queries and bottlenecks
    """
    
    def __init__(self, slow_query_threshold_ms: float = 100.0):
        """
        Initialize query logger
        
        Args:
            slow_query_threshold_ms: Threshold for slow queries in milliseconds
        """
        self.slow_threshold = slow_query_threshold_ms
        self._queries: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._slow_queries: List[Dict[str, Any]] = []
    
    def log_query(
        self,
        query: str,
        params: Optional[tuple] = None,
        duration_ms: Optional[float] = None
    ) -> None:
        """
        Log a database query
        
        Args:
            query: SQL query string
            params: Query parameters
            duration_ms: Query duration in milliseconds
        """
        with self._lock:
            log_entry = {
                'query': query,
                'params': params,
                'duration_ms': duration_ms,
                'timestamp': datetime.now().isoformat(),
                'is_slow': duration_ms and duration_ms > self.slow_threshold
            }
            
            self._queries.append(log_entry)
            
            if log_entry['is_slow']:
                self._slow_queries.append(log_entry)
    
    def get_queries(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get recent queries
        
        Args:
            limit: Maximum number of queries to return
            
        Returns:
            List of query logs
        """
        with self._lock:
            return self._queries[-limit:]
    
    def get_slow_queries(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get slow queries
        
        Args:
            limit: Maximum number of queries to return
            
        Returns:
            List of slow query logs
        """
        with self._lock:
            return self._slow_queries[-limit:]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get query statistics
        
        Returns:
            Dictionary with statistics
        """
        with self._lock:
            if not self._queries:
                return {
                    'total_queries': 0,
                    'avg_duration_ms': 0,
                    'max_duration_ms': 0,
                    'slow_queries': 0
                }
            
            durations = [q['duration_ms'] for q in self._queries if q['duration_ms']]
            
            return {
                'total_queries': len(self._queries),
                'avg_duration_ms': sum(durations) / len(durations) if durations else 0,
                'max_duration_ms': max(durations) if durations else 0,
                'slow_queries': len(self._slow_queries)
            }
    
    def clear(self) -> None:
        """Clear all query logs"""
        with self._lock:
            self._queries.clear()
            self._slow_queries.clear()


class QueryTimingMiddleware:
    """
    Middleware to automatically time database queries
    Integrates with popular ORMs
    """
    
    def __init__(self, logger: Optional[QueryLogger] = None):
        """
        Initialize middleware
        
        Args:
            logger: QueryLogger instance
        """
        self.logger = logger or QueryLogger()
    
    def time_query(self, query_func: Callable) -> Callable:
        """
        Decorator to time query execution
        
        Args:
            query_func: Query function to wrap
            
        Returns:
            Wrapped function
        """
        @wraps(query_func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = query_func(*args, **kwargs)
                duration_ms = (time.time() - start_time) * 1000
                
                # Log query
                query_str = str(args[0]) if args else 'Unknown'
                self.logger.log_query(query_str, duration_ms=duration_ms)
                
                return result
            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                self.logger.log_query(
                    f'ERROR: {str(e)}',
                    duration_ms=duration_ms
                )
                raise
        
        return wrapper
    
    def get_performance_report(self) -> str:
        """
        Generate performance report
        
        Returns:
            Formatted report string
        """
        stats = self.logger.get_stats()
        slow_queries = self.logger.get_slow_queries(5)
        
        report = "=== QUERY PERFORMANCE REPORT ===\n\n"
        report += f"Total Queries: {stats['total_queries']}\n"
        report += f"Average Duration: {stats['avg_duration_ms']:.2f}ms\n"
        report += f"Max Duration: {stats['max_duration_ms']:.2f}ms\n"
        report += f"Slow Queries: {stats['slow_queries']}\n\n"
        
        if slow_queries:
            report += "SLOWEST QUERIES:\n"
            for i, query in enumerate(slow_queries, 1):
                report += f"{i}. {query['duration_ms']:.2f}ms - {query['query'][:100]}\n"
        
        return report


def setup_query_logging(logger: Optional[QueryLogger] = None):
    """
    Setup query logging for Django
    
    Args:
        logger: QueryLogger instance
    """
    from django.conf import settings
    from django.db import connection
    
    query_logger = logger or QueryLogger()
    
    # Override Django's default query logging
    old_execute = connection.cursor().execute
    
    def new_execute(query, params=None):
        start = time.time()
        result = old_execute(query, params)
        duration = (time.time() - start) * 1000
        
        query_logger.log_query(query, params, duration)
        return result
    
    connection.cursor().execute = new_execute
    
    return query_logger