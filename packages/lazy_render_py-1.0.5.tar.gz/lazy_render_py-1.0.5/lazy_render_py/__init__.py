"""
lazy-render-py
Backend helpers for lazy-render Python integration

Provides:
- Cursor-based pagination
- Batch optimization
- API performance helpers
- Caching utilities
- FastAPI middleware
- Django helpers
"""

__version__ = '1.0.5'
__author__ = 'Sannu Kumar'

from .pagination import PaginationHelper, PaginatedResponse
from .cursor import CursorPagination, CursorEncoder, CursorDecoder
from .cache import CacheHelper, TTLCache
from .fastapi_middleware import LazyRenderMiddleware, PerformanceTracker
from .django_helpers import DjangoPagination, DjangoCursorPagination
from .rate_limiter import RateLimiter, RateLimitMiddleware
from .compression import ResponseCompressor
from .query_logger import QueryLogger, QueryTimingMiddleware

__all__ = [
    'PaginationHelper',
    'PaginatedResponse',
    'CursorPagination',
    'CursorEncoder',
    'CursorDecoder',
    'CacheHelper',
    'TTLCache',
    'LazyRenderMiddleware',
    'PerformanceTracker',
    'DjangoPagination',
    'DjangoCursorPagination',
    'RateLimiter',
    'RateLimitMiddleware',
    'ResponseCompressor',
    'QueryLogger',
    'QueryTimingMiddleware',
    '__version__'
]