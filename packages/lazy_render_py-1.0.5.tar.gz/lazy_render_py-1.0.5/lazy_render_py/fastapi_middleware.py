"""
FastAPI Middleware Module
Performance tracking and optimization middleware
"""

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Callable, Dict, Any
import time
import json

class PerformanceTracker:
    """Track API performance metrics"""
    
    def __init__(self):
        self._metrics: Dict[str, Any] = {
            'total_requests': 0,
            'total_time_ms': 0,
            'slow_requests': 0,
            'avg_time_ms': 0
        }
    
    def record_request(self, duration_ms: float, endpoint: str) -> None:
        """
        Record request metrics
        
        Args:
            duration_ms: Request duration in milliseconds
            endpoint: API endpoint
        """
        self._metrics['total_requests'] += 1
        self._metrics['total_time_ms'] += duration_ms
        
        if duration_ms > 1000:  # Slow if > 1s
            self._metrics['slow_requests'] += 1
        
        self._metrics['avg_time_ms'] = (
            self._metrics['total_time_ms'] / self._metrics['total_requests']
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics"""
        return self._metrics.copy()


class LazyRenderMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware for lazy-render optimization
    Adds performance tracking and response optimization
    """
    
    def __init__(self, app, track_performance: bool = True):
        """
        Initialize middleware
        
        Args:
            app: FastAPI application
            track_performance: Enable performance tracking
        """
        super().__init__(app)
        self.tracker = PerformanceTracker() if track_performance else None
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Process request and track performance
        
        Args:
            request: Incoming request
            call_next: Next middleware handler
            
        Returns:
            Response
        """
        start_time = time.time()
        
        # Process request
        response = await call_next(request)
        
        # Track performance
        if self.tracker:
            duration_ms = (time.time() - start_time) * 1000
            self.tracker.record_request(duration_ms, request.url.path)
            
            # Add performance headers
            response.headers['X-Response-Time-Ms'] = f"{duration_ms:.2f}"
            response.headers['X-Performance-Avg-Ms'] = f"{self.tracker.get_metrics()['avg_time_ms']:.2f}"
        
        return response
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        return self.tracker.get_metrics() if self.tracker else {}


def setup_lazy_render_middleware(app, track_performance: bool = True):
    """
    Setup lazy-render middleware for FastAPI app
    
    Args:
        app: FastAPI application
        track_performance: Enable performance tracking
    """
    app.add_middleware(LazyRenderMiddleware, track_performance=track_performance)