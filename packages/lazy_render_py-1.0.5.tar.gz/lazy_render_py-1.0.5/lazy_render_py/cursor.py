"""
Cursor-based Pagination Module
High-performance cursor pagination for large datasets
"""

from typing import Any, Optional, Dict, List, Generic, TypeVar
from dataclasses import dataclass
import base64
import json
from datetime import datetime

T = TypeVar('T')

@dataclass
class CursorPaginationResult(Generic[T]):
    """Cursor pagination result structure"""
    data: List[T]
    limit: int
    has_more: bool
    next_cursor: Optional[str]
    prev_cursor: Optional[str]
    sort_by: str
    sort_order: str


class CursorEncoder:
    """Encode cursor data"""
    
    @staticmethod
    def encode(item: Any, sort_by: str = 'id') -> str:
        """
        Encode cursor from item data
        
        Args:
            item: Item to encode
            sort_by: Field to use for cursor
            
        Returns:
            Base64 encoded cursor string
        """
        cursor_data = {
            'value': getattr(item, sort_by, None) if hasattr(item, sort_by) else item.get(sort_by),
            'timestamp': datetime.now().isoformat()
        }
        return base64.b64encode(
            json.dumps(cursor_data).encode('utf-8')
        ).decode('utf-8')


class CursorDecoder:
    """Decode cursor data"""
    
    @staticmethod
    def decode(cursor: str) -> Optional[Dict[str, Any]]:
        """
        Decode cursor string
        
        Args:
            cursor: Base64 encoded cursor string
            
        Returns:
            Decoded dictionary or None
        """
        try:
            decoded = base64.b64decode(cursor.encode('utf-8')).decode('utf-8')
            return json.loads(decoded)
        except Exception:
            return None


class CursorPagination:
    """
    High-performance cursor pagination
    Better than offset pagination for large datasets
    """
    
    @staticmethod
    def generate_sql_clause(
        cursor: Optional[str] = None,
        sort_by: str = 'id',
        sort_order: str = 'asc'
    ) -> tuple:
        """
        Generate SQL WHERE clause for cursor pagination
        Example: WHERE id > last_id
        
        Args:
            cursor: Cursor string
            sort_by: Field to sort by
            sort_order: Sort order
            
        Returns:
            Tuple of (where_clause, parameters)
        """
        if not cursor:
            return ('', [])
        
        decoded = CursorDecoder.decode(cursor)
        if not decoded:
            return ('', [])
        
        operator = '>' if sort_order == 'asc' else '<'
        value = decoded.get('value')
        
        return (f'WHERE {sort_by} {operator} %s', [value])
    
    @staticmethod
    def generate_mongo_query(
        cursor: Optional[str] = None,
        sort_by: str = '_id',
        sort_order: str = 'asc'
    ) -> Dict[str, Any]:
        """
        Generate MongoDB query for cursor pagination
        
        Args:
            cursor: Cursor string
            sort_by: Field to sort by
            sort_order: Sort order
            
        Returns:
            MongoDB query dictionary
        """
        if not cursor:
            return {}
        
        decoded = CursorDecoder.decode(cursor)
        if not decoded:
            return {}
        
        operator = '$gt' if sort_order == 'asc' else '$lt'
        value = decoded.get('value')
        
        return {sort_by: {operator: value}}
    
    @staticmethod
    def create_result(
        data: List[T],
        limit: int,
        sort_by: str,
        sort_order: str,
        get_cursor_value: callable = None
    ) -> CursorPaginationResult[T]:
        """
        Create pagination result with cursors
        
        Args:
            data: List of items
            limit: Items per page
            sort_by: Field to sort by
            sort_order: Sort order
            get_cursor_value: Function to extract cursor value from item
            
        Returns:
            CursorPaginationResult
        """
        has_more = len(data) > limit
        limited_data = data[:limit] if has_more else data
        
        next_cursor = None
        if has_more and limited_data:
            last_item = limited_data[-1]
            cursor_value = get_cursor_value(last_item) if get_cursor_value else (
                getattr(last_item, sort_by, None) if hasattr(last_item, sort_by) 
                else last_item.get(sort_by) if isinstance(last_item, dict) else last_item
            )
            next_cursor = CursorEncoder.encode(
                type('obj', (object,), {sort_by: cursor_value})()
            )
        
        prev_cursor = None
        if limited_data:
            first_item = limited_data[0]
            cursor_value = get_cursor_value(first_item) if get_cursor_value else (
                getattr(first_item, sort_by, None) if hasattr(first_item, sort_by)
                else first_item.get(sort_by) if isinstance(first_item, dict) else first_item
            )
            prev_cursor = CursorEncoder.encode(
                type('obj', (object,), {sort_by: cursor_value})()
            )
        
        return CursorPaginationResult(
            data=limited_data,
            limit=limit,
            has_more=has_more,
            next_cursor=next_cursor,
            prev_cursor=prev_cursor,
            sort_by=sort_by,
            sort_order=sort_order
        )