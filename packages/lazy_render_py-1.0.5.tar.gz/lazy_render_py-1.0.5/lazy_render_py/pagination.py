"""
Pagination Helper Module
High-performance pagination for large datasets
"""

from typing import List, Dict, Any, Optional, Generic, TypeVar
from dataclasses import dataclass
from datetime import datetime
import base64
import json

T = TypeVar('T')

@dataclass
class PaginatedResponse(Generic[T]):
    """Paginated response structure"""
    data: List[T]
    page: int
    limit: int
    total: int
    total_pages: int
    has_more: bool
    next_cursor: Optional[str] = None
    prev_cursor: Optional[str] = None
    sort_by: Optional[str] = None
    sort_order: Optional[str] = None


class PaginationHelper:
    """Helper class for pagination operations"""
    
    @staticmethod
    def calculate_pagination(
        items: List[T],
        page: int,
        limit: int,
        total: int,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None
    ) -> PaginatedResponse[T]:
        """
        Calculate pagination metadata
        
        Args:
            items: List of items for current page
            page: Current page number
            limit: Items per page
            total: Total number of items
            sort_by: Field to sort by
            sort_order: Sort order (asc/desc)
            
        Returns:
            PaginatedResponse with metadata
        """
        total_pages = (total + limit - 1) // limit
        has_more = page < total_pages
        
        return PaginatedResponse(
            data=items,
            page=page,
            limit=limit,
            total=total,
            total_pages=total_pages,
            has_more=has_more,
            next_cursor=str(page + 1) if has_more else None,
            prev_cursor=str(page - 1) if page > 1 else None,
            sort_by=sort_by,
            sort_order=sort_order
        )
    
    @staticmethod
    def validate_pagination_params(
        page: Optional[int] = None,
        limit: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Validate pagination parameters
        
        Returns:
            Dictionary with validated params and errors
        """
        errors = []
        
        # Validate page
        if page is None or page < 1:
            page = 1
            errors.append('Page must be greater than 0')
        
        # Validate limit
        if limit is None or limit < 1:
            limit = 50
            errors.append('Limit must be greater than 0')
        elif limit > 1000:
            limit = 1000
            errors.append('Limit cannot exceed 1000 items per page')
        
        # Validate sort order
        if sort_order not in ['asc', 'desc']:
            sort_order = 'asc'
        
        return {
            'page': page,
            'limit': limit,
            'sort_by': sort_by,
            'sort_order': sort_order,
            'errors': errors
        }
    
    @staticmethod
    def batch_data(data: List[T], batch_size: int) -> List[List[T]]:
        """
        Split data into batches
        
        Args:
            data: List of items to batch
            batch_size: Size of each batch
            
        Returns:
            List of batches
        """
        return [data[i:i + batch_size] for i in range(0, len(data), batch_size)]
    
    @staticmethod
    def encode_cursor(data: Dict[str, Any]) -> str:
        """
        Encode cursor data to base64 string
        
        Args:
            data: Dictionary to encode
            
        Returns:
            Base64 encoded string
        """
        cursor_data = {
            **data,
            'timestamp': datetime.now().isoformat()
        }
        return base64.b64encode(
            json.dumps(cursor_data).encode('utf-8')
        ).decode('utf-8')
    
    @staticmethod
    def decode_cursor(cursor: str) -> Optional[Dict[str, Any]]:
        """
        Decode cursor from base64 string
        
        Args:
            cursor: Base64 encoded string
            
        Returns:
            Decoded dictionary or None if invalid
        """
        try:
            decoded = base64.b64decode(cursor.encode('utf-8')).decode('utf-8')
            return json.loads(decoded)
        except Exception:
            return None
    
    @staticmethod
    def generate_sql_where_clause(
        cursor: Optional[str] = None,
        sort_by: str = 'id',
        sort_order: str = 'asc'
    ) -> tuple:
        """
        Generate SQL WHERE clause for cursor pagination
        
        Args:
            cursor: Cursor string
            sort_by: Field to sort by
            sort_order: Sort order
            
        Returns:
            Tuple of (where_clause, parameters)
        """
        if not cursor:
            return ('', [])
        
        decoded = PaginationHelper.decode_cursor(cursor)
        if not decoded:
            return ('', [])
        
        operator = '>' if sort_order == 'asc' else '<'
        value = decoded.get(sort_by)
        
        return (f'WHERE {sort_by} {operator} %s', [value])
    
    @staticmethod
    def generate_mongo_query(
        cursor: Optional[str] = None,
        sort_by: str = '_id',
        sort_order: str = 'asc'
    ) -> Dict[str, Any]:
        """
        Generate MongoDB query for cursor pagination
        
        Args:
            cursor: Cursor string
            sort_by: Field to sort by
            sort_order: Sort order
            
        Returns:
            MongoDB query dictionary
        """
        if not cursor:
            return {}
        
        decoded = PaginationHelper.decode_cursor(cursor)
        if not decoded:
            return {}
        
        operator = '$gt' if sort_order == 'asc' else '$lt'
        value = decoded.get(sort_by)
        
        return {sort_by: {operator: value}}