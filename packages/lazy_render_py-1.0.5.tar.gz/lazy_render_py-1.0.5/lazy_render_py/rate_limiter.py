"""
Rate Limiter Module
API rate limiting helpers
"""

from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from functools import wraps
import threading

class RateLimiter:
    """
    In-memory rate limiter
    Track request rates per client
    """
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        """
        Initialize rate limiter
        
        Args:
            max_requests: Maximum requests per window
            window_seconds: Time window in seconds
        """
        self._max_requests = max_requests
        self._window = timedelta(seconds=window_seconds)
        self._requests: Dict[str, list] = {}
        self._lock = threading.Lock()
    
    def is_allowed(self, client_id: str) -> bool:
        """
        Check if request is allowed
        
        Args:
            client_id: Client identifier (IP, user ID, etc.)
            
        Returns:
            True if allowed, False if rate limited
        """
        with self._lock:
            now = datetime.now()
            window_start = now - self._window
            
            # Initialize or clean old requests
            if client_id not in self._requests:
                self._requests[client_id] = []
            
            # Remove old requests
            self._requests[client_id] = [
                req_time for req_time in self._requests[client_id]
                if req_time > window_start
            ]
            
            # Check if allowed
            if len(self._requests[client_id]) >= self._max_requests:
                return False
            
            # Record request
            self._requests[client_id].append(now)
            return True
    
    def get_remaining(self, client_id: str) -> int:
        """
        Get remaining requests for client
        
        Args:
            client_id: Client identifier
            
        Returns:
            Number of remaining requests
        """
        with self._lock:
            if client_id not in self._requests:
                return self._max_requests
            
            now = datetime.now()
            window_start = now - self._window
            
            # Count recent requests
            recent = [
                req_time for req_time in self._requests[client_id]
                if req_time > window_start
            ]
            
            return max(0, self._max_requests - len(recent))
    
    def reset(self, client_id: Optional[str] = None) -> None:
        """
        Reset rate limiter
        
        Args:
            client_id: Client to reset (None for all)
        """
        with self._lock:
            if client_id:
                if client_id in self._requests:
                    del self._requests[client_id]
            else:
                self._requests.clear()


def rate_limit(max_requests: int = 100, window_seconds: int = 60):
    """
    Decorator for rate limiting functions
    
    Args:
        max_requests: Maximum requests per window
        window_seconds: Time window in seconds
    """
    limiter = RateLimiter(max_requests, window_seconds)
    
    def decorator(func):
        @wraps(func)
        def wrapper(client_id: str, *args, **kwargs):
            if not limiter.is_allowed(client_id):
                raise Exception(f'Rate limit exceeded. Max {max_requests} requests per {window_seconds}s')
            return func(client_id, *args, **kwargs)
        return wrapper
    return decorator


class RateLimitMiddleware:
    """
    Rate limiting middleware for web frameworks
    """
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        """
        Initialize middleware
        
        Args:
            max_requests: Maximum requests per window
            window_seconds: Time window in seconds
        """
        self.limiter = RateLimiter(max_requests, window_seconds)
    
    def get_client_id(self, request: Any) -> str:
        """
        Extract client ID from request
        
        Args:
            request: Web framework request object
            
        Returns:
            Client identifier
        """
        # Default implementation - override for specific frameworks
        return request.remote_addr or 'unknown'
    
    def process_request(self, request: Any) -> Optional[Any]:
        """
        Process incoming request
        
        Args:
            request: Web framework request object
            
        Returns:
            None if allowed, error response if rate limited
        """
        client_id = self.get_client_id(request)
        
        if not self.limiter.is_allowed(client_id):
            return self.create_rate_limit_response(client_id)
        
        return None
    
    def create_rate_limit_response(self, client_id: str) -> Any:
        """
        Create rate limit exceeded response
        
        Args:
            client_id: Client identifier
            
        Returns:
            Error response
        """
        # Default implementation - override for specific frameworks
        return {
            'error': 'Rate limit exceeded',
            'message': f'Too many requests. Please try again later.',
            'remaining': 0
        }