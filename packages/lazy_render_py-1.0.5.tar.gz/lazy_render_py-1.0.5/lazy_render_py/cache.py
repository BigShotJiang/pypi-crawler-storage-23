"""
Cache Helper Module
TTL-based caching utilities
"""

from typing import Any, Optional, Dict, Generic, TypeVar
from datetime import datetime, timedelta
import threading

T = TypeVar('T')

class TTLCache(Generic[T]):
    """Thread-safe TTL cache"""
    
    def __init__(self, default_ttl_seconds: int = 60):
        """
        Initialize cache
        
        Args:
            default_ttl_seconds: Default time-to-live in seconds
        """
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._default_ttl = timedelta(seconds=default_ttl_seconds)
        self._lock = threading.Lock()
    
    def set(self, key: str, value: T, ttl_seconds: Optional[int] = None) -> None:
        """
        Set cache value
        
        Args:
            key: Cache key
            value: Value to cache
            ttl_seconds: Time-to-live in seconds (optional)
        """
        with self._lock:
            ttl = timedelta(seconds=ttl_seconds) if ttl_seconds else self._default_ttl
            self._cache[key] = {
                'value': value,
                'expiry': datetime.now() + ttl
            }
    
    def get(self, key: str) -> Optional[T]:
        """
        Get cached value
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found/expired
        """
        with self._lock:
            if key not in self._cache:
                return None
            
            item = self._cache[key]
            if datetime.now() > item['expiry']:
                del self._cache[key]
                return None
            
            return item['value']
    
    def delete(self, key: str) -> bool:
        """
        Delete cached value
        
        Args:
            key: Cache key
            
        Returns:
            True if deleted, False if not found
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False
    
    def clear(self) -> None:
        """Clear all cached values"""
        with self._lock:
            self._cache.clear()
    
    def size(self) -> int:
        """Get number of items in cache"""
        with self._lock:
            return len(self._cache)
    
    def cleanup_expired(self) -> int:
        """
        Remove expired entries
        
        Returns:
            Number of entries removed
        """
        with self._lock:
            now = datetime.now()
            expired_keys = [
                key for key, item in self._cache.items()
                if now > item['expiry']
            ]
            for key in expired_keys:
                del self._cache[key]
            return len(expired_keys)


class CacheHelper:
    """Helper class for caching operations"""
    
    def __init__(self, default_ttl_seconds: int = 60):
        """
        Initialize cache helper
        
        Args:
            default_ttl_seconds: Default TTL in seconds
        """
        self._cache = TTLCache(default_ttl_seconds)
    
    def cache(self, key: str, ttl_seconds: Optional[int] = None):
        """
        Decorator for caching function results
        
        Args:
            key: Cache key prefix
            ttl_seconds: Time-to-live in seconds
        """
        def decorator(func):
            def wrapper(*args, **kwargs):
                # Generate cache key from args
                cache_key = f"{key}:{str(args)}:{str(kwargs)}"
                
                # Try to get from cache
                cached = self._cache.get(cache_key)
                if cached is not None:
                    return cached
                
                # Call function and cache result
                result = func(*args, **kwargs)
                self._cache.set(cache_key, result, ttl_seconds)
                return result
            
            return wrapper
        return decorator
    
    def get(self, key: str) -> Optional[Any]:
        """Get cached value"""
        return self._cache.get(key)
    
    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None) -> None:
        """Set cached value"""
        self._cache.set(key, value, ttl_seconds)
    
    def delete(self, key: str) -> bool:
        """Delete cached value"""
        return self._cache.delete(key)
    
    def clear(self) -> None:
        """Clear cache"""
        self._cache.clear()