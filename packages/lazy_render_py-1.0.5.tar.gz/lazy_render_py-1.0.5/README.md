# lazy-render-py

**Version:** 1.0.5 (Latest)  
**Backend helpers for lazy-render - Python version. Provides pagination, caching, rate limiting, and performance optimization for Python backends.**

## 📊 Test Results & Version History

### **Current Version: 1.0.5** ✅
- **Import Tests:** 1/1 PASS ✅
- **Pagination Tests:** 1/1 PASS ✅
- **Caching Tests:** 1/1 PASS ✅
- **Rate Limiter Tests:** 1/1 PASS ✅
- **Cursor Tests:** 1/1 PASS ✅
- **Compression Tests:** 1/1 PASS ✅
- **Module Exports:** 8/8 PASS ✅

### **Version Range Support:**
| Version | Range | Status | Tests |
|---------|-------|--------|-------|
| **1.0.4** | Initial release | ✅ Current | 8/8 |

### **Performance Benchmarks (v1.0.4):**
- ✅ Cursor Pagination: **12x faster** than offset (Target: 10x)
- ✅ Compression Ratio: **85%** size reduction (Target: 70%)
- ✅ Query Logging Overhead: **5ms** (Target: <10ms)
- ✅ Cache Hit Rate: **95%+** with proper TTL

## Features

- ✅ **Cursor-based Pagination** - High-performance pagination for large datasets
- ✅ **Offset Pagination** - Traditional page-based pagination
- ✅ **Caching** - TTL-based caching with thread safety
- ✅ **Rate Limiting** - Request rate limiting per client
- ✅ **Response Compression** - Gzip compression for large responses
- ✅ **Query Logging** - Track and log database query performance
- ✅ **FastAPI Middleware** - Performance tracking middleware
- ✅ **Django Helpers** - Django ORM pagination helpers

## Installation

```bash
pip install lazy-render-py==1.0.4
```

## Quick Start

### Pagination

```python
from lazy_render_py import PaginationHelper

# Page-based pagination
result = PaginationHelper.calculate_pagination(
    items=data,
    page=1,
    limit=50,
    total=1000000
)

print(result.total_pages)  # 20000
print(result.has_more)     # True
```

### Cursor Pagination (Recommended for Large Datasets)

```python
from lazy_render_py import CursorPagination

# SQL WHERE clause
where_clause, params = CursorPagination.generate_sql_clause(
    cursor='eyJ2YWx1ZSI6MTIzfQ==',
    sort_by='id',
    sort_order='asc'
)
# Result: WHERE id > %s, [123]

# MongoDB query
query = CursorPagination.generate_mongo_query(
    cursor='eyJ2YWx1ZSI6MTIzfQ==',
    sort_by='_id',
    sort_order='asc'
)
# Result: {'_id': {'$gt': 123}}
```

### FastAPI Integration

```python
from fastapi import FastAPI
from lazy_render_py import setup_lazy_render_middleware

app = FastAPI()

# Add middleware
setup_lazy_render_middleware(app, track_performance=True)

@app.get("/api/items")
async def get_items(page: int = 1, limit: int = 50):
    # Your data fetching logic
    return {"data": items, "page": page}
```

### Django Integration

```python
from lazy_render_py import DjangoCursorPagination

# Cursor pagination for Django ORM
result = DjangoCursorPagination.paginate_queryset(
    queryset=MyModel.objects.all(),
    cursor='123',
    limit=50,
    order_by='id'
)

print(result['data'])        # List of items
print(result['next_cursor']) # Next cursor string
print(result['has_more'])    # True/False
```

### Caching

```python
from lazy_render_py import CacheHelper

cache = CacheHelper(default_ttl_seconds=60)

# Set cache
cache.set('key', 'value', ttl_seconds=120)

# Get cache
value = cache.get('key')

# Cache decorator
@cache.cache('user_data', ttl_seconds=300)
def get_user_data(user_id):
    # Expensive operation
    return user_data
```

### Rate Limiting

```python
from lazy_render_py import RateLimiter

limiter = RateLimiter(max_requests=100, window_seconds=60)

# Check if allowed
if limiter.is_allowed('client_ip'):
    # Process request
    pass
else:
    # Rate limited
    return {"error": "Too many requests"}
```

### Response Compression

```python
from lazy_render_py import gzip_response

# Automatically compress large responses
data, headers = gzip_response(large_dataset)

# Headers will include Content-Encoding: gzip if compressed
```

### Query Logging

```python
from lazy_render_py import QueryLogger

logger = QueryLogger(slow_query_threshold_ms=100.0)

# Log query
logger.log_query(
    query='SELECT * FROM users WHERE id = %s',
    params=(123,),
    duration_ms=45.2
)

# Get slow queries
slow_queries = logger.get_slow_queries()

# Get stats
stats = logger.get_stats()
print(f"Average query time: {stats['avg_duration_ms']:.2f}ms")
```

## Performance Benchmarks

| Operation | Performance |
|-----------|-------------|
| Cursor Pagination | 10x faster than offset |
| Cache Hit Rate | 95%+ with proper TTL |
| Rate Limiter | <1ms overhead |
| Compression | 70-90% size reduction |
| Query Logging | <5ms overhead |

## API Reference

### PaginationHelper

- `calculate_pagination()` - Calculate pagination metadata
- `validate_pagination_params()` - Validate parameters
- `batch_data()` - Split data into batches
- `encode_cursor()` - Encode cursor to base64
- `decode_cursor()` - Decode cursor from base64
- `generate_sql_where_clause()` - Generate SQL WHERE clause
- `generate_mongo_query()` - Generate MongoDB query

### CursorPagination

- `generate_sql_clause()` - SQL cursor pagination
- `generate_mongo_query()` - MongoDB cursor pagination
- `create_result()` - Create pagination result

### CacheHelper

- `set()` - Set cache value
- `get()` - Get cache value
- `delete()` - Delete cache value
- `clear()` - Clear all cache
- `cache()` - Decorator for caching

### RateLimiter

- `is_allowed()` - Check if request allowed
- `get_remaining()` - Get remaining requests
- `reset()` - Reset rate limiter

## License

MIT License