# Root UID obtained from (http://www.medicalconnections.co.uk/FreeUID.html)
IDIS_CORE_ROOT_UID = "1.2.826.0.1.3680043.10.566."
