"""Top-level package for IDIS Core."""

__author__ = """Sjoerd Kerkstra"""
__email__ = "sjoerd.kerkstra@radboudumcn.nl"
__version__ = "1.2.0"
