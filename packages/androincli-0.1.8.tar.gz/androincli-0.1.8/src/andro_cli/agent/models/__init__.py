"""Pydantic models for the agent"""
