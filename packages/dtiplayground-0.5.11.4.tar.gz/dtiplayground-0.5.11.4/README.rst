DTI Playground
==============

DTI Playground is an integrated DWI processing software. 


DMRIPrep
~~~~~~~~~~

DMRIPrep is a pipelined quality control processing tool to make clean and reliable tensor images. 


DMRIAtlasBuilder
~~~~~~~~~~~~~~~~~

DMRIAtlasBuilder makes DTI atlas from multiple level of image hierarchy. 



