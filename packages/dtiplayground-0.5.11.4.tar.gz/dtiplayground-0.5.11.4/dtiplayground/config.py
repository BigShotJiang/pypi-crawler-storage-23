
INFO = {
  "dtiplayground": { 
    "version" : "0.5.11.4"
  },
  "dmriplayground": {
    "version" : "0.5.11.4"
  },
  "dmriprep": {
    "version" : "0.5.11.4"
  },
  "dmriatlas": {
    "version" : "0.2.0b1"
  },
  "dmriautotract" : {
    "version" : "0.0.2b1"
  },
  "dmrifiberprofile" : {
    "version" : "0.5.10"
  }
}
