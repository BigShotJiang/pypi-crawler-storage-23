### IDENTITY_Process

##### Introduction

Identity_Process.py will assure a identity process of the input image

##### Protocol Parameters

- options is a string with a default value of null

##### Examples


##### Author(s)

