### MULTI_SHELL_Estimate

##### Introduction

MULTI_SHELL_Estimate will run DTI by several methods like : 
- runDIPY
- runMRTRIX3
- runAMICCO

##### Protocol Parameters

- method is a list with a default value of dipy, it will choose beetween different candidates the method to estimate

- the different optimizationMethod is a list with a default value of , it will choose beetween different candidates the optimization method


##### Examples


##### Author(s)
Joshua Barnett