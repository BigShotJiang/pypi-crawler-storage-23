"""
LogosAI Configuration Module

This module provides LogosAI configuration-related functionality.
"""

from .agent_config import AgentConfig

__all__ = ['AgentConfig']
