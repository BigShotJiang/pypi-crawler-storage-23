.. role:: raw-html(raw)
    :format: html

*********************
Copyright and License
*********************

| :raw-html:`&copy;` 2012-2026 M. Andersen and L. Vandenberghe.
| :raw-html:`&copy;` 2010-2011 L. Vandenberghe. 
| :raw-html:`&copy;` 2004-2009 J. Dahl and L. Vandenberghe. 
|

kvxopt is free software; you can redistribute it and/or modify it under 
the terms of the 
`GNU General Public License <http://www.gnu.org/licenses/gpl-3.0.html>`_
as published by the Free Software Foundation; either version 3 of the 
License, or (at your option) any later version.

kvxopt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the
`GNU General Public License <http://www.gnu.org/licenses/gpl-3.0.html>`_
for more details. 

