"""auto-yes: automatically respond 'yes' to interactive CLI prompts."""

__version__ = "0.6.0"
