"""entry point for ``python -m auto_yes``."""

from auto_yes.cli import main

main()
