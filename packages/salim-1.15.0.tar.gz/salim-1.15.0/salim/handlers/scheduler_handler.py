"""
salim.handlers.scheduler_handler — Telegram-controlled Task Scheduler
/at <HH:MM> <command>   — Run a shell command at a specific time today
/every <N> <unit> <cmd> — Run a command every N minutes/hours
/jobs                   — List scheduled jobs
/jobcancel <id>         — Cancel a job
"""
from __future__ import annotations
import asyncio
import logging
import threading
import time
import re
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)

JOBS_FILE = Path.home() / ".salim" / "scheduler_jobs.json"

# In-memory job registry
_jobs: dict[str, dict] = {}
_jobs_lock = threading.Lock()
_job_counter = 0


class SchedulerHandlers:

    async def cmd_at(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Schedule a command at a specific time. Usage: /at 14:30 echo hello"""
        if not ctx.args or len(ctx.args) < 2:
            await update.message.reply_text(
                "Usage: /at <HH:MM> <shell command>\n"
                "Example: /at 14:30 shutdown -h now"
            )
            return

        time_str = ctx.args[0]
        cmd = " ".join(ctx.args[1:])

        try:
            h, m = map(int, time_str.split(":"))
            assert 0 <= h < 24 and 0 <= m < 60
        except Exception:
            await update.message.reply_text("❌ Invalid time. Use HH:MM format (e.g. 14:30)")
            return

        now = datetime.now()
        run_at = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if run_at <= now:
            run_at += timedelta(days=1)  # Schedule for tomorrow if already passed

        jid = _create_job(cmd, run_at, "once", update.effective_chat.id, ctx.bot, asyncio.get_event_loop())
        delay = (run_at - now).total_seconds()

        await update.message.reply_text(
            f"⏰ Job #{jid} scheduled\n"
            f"<b>Time:</b> {run_at.strftime('%H:%M')} ({delay/60:.0f} min from now)\n"
            f"<b>Command:</b> <code>{cmd}</code>",
            parse_mode="HTML"
        )

    async def cmd_every(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Run a command repeatedly. Usage: /every 30 min echo hello"""
        if not ctx.args or len(ctx.args) < 3:
            await update.message.reply_text(
                "Usage: /every <N> <min|hour|sec> <command>\n"
                "Example: /every 30 min df -h"
            )
            return

        try:
            n = int(ctx.args[0])
            unit = ctx.args[1].lower()
            cmd = " ".join(ctx.args[2:])
        except (ValueError, IndexError):
            await update.message.reply_text("❌ Invalid syntax.")
            return

        unit_map = {"sec": 1, "secs": 1, "second": 1, "seconds": 1,
                    "min": 60, "mins": 60, "minute": 60, "minutes": 60,
                    "hour": 3600, "hours": 3600, "hr": 3600}
        if unit not in unit_map:
            await update.message.reply_text(f"❌ Unknown unit: {unit}. Use sec, min, or hour.")
            return

        interval = n * unit_map[unit]
        jid = _create_repeating_job(cmd, interval, update.effective_chat.id, ctx.bot, asyncio.get_event_loop())

        await update.message.reply_text(
            f"🔁 Repeating job #{jid} created\n"
            f"<b>Every:</b> {n} {unit}\n"
            f"<b>Command:</b> <code>{cmd}</code>\n"
            f"Stop with: /jobcancel {jid}",
            parse_mode="HTML"
        )

    async def cmd_jobs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List all scheduled jobs."""
        with _jobs_lock:
            jobs = dict(_jobs)

        if not jobs:
            await update.message.reply_text("📭 No scheduled jobs.")
            return

        lines = [f"<b>⏰ Scheduled Jobs ({len(jobs)})</b>\n"]
        for jid, info in jobs.items():
            jtype = info.get("type", "once")
            cmd = info.get("cmd", "?")[:60]
            if jtype == "once":
                run_at = info.get("run_at_str", "?")
                lines.append(f"<b>#{jid}</b> [once] at {run_at}\n<code>{cmd}</code>")
            else:
                every = info.get("interval_sec", 0)
                lines.append(f"<b>#{jid}</b> [every {every}s]\n<code>{cmd}</code>")

        await update.message.reply_text("\n\n".join(lines), parse_mode="HTML")

    async def cmd_jobcancel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Cancel a scheduled job. Usage: /jobcancel <id>"""
        jid = " ".join(ctx.args) if ctx.args else ""
        with _jobs_lock:
            if jid not in _jobs:
                await update.message.reply_text(f"❌ Job #{jid} not found. Use /jobs to list.")
                return
            _jobs[jid]["stop"] = True
            _jobs.pop(jid)

        await update.message.reply_text(f"✅ Job #{jid} cancelled.")


# ── Internal job management ───────────────────────────────────────────────────

def _create_job(cmd: str, run_at: datetime, jtype: str, chat_id: int, bot, main_loop: asyncio.AbstractEventLoop) -> str:
    global _job_counter
    _job_counter += 1
    jid = str(_job_counter)

    with _jobs_lock:
        _jobs[jid] = {
            "cmd": cmd,
            "type": "once",
            "run_at_str": run_at.strftime("%H:%M"),
            "stop": False,
        }

    def _run():
        delay = (run_at - datetime.now()).total_seconds()
        if delay > 0:
            time.sleep(delay)
        with _jobs_lock:
            if jid not in _jobs or _jobs[jid].get("stop"):
                return
            _jobs.pop(jid, None)
        _exec_and_notify(cmd, chat_id, bot, jid, main_loop)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return jid


def _create_repeating_job(cmd: str, interval: int, chat_id: int, bot, main_loop: asyncio.AbstractEventLoop) -> str:
    global _job_counter
    _job_counter += 1
    jid = str(_job_counter)

    with _jobs_lock:
        _jobs[jid] = {
            "cmd": cmd,
            "type": "repeat",
            "interval_sec": interval,
            "stop": False,
        }

    def _run():
        while True:
            time.sleep(interval)
            with _jobs_lock:
                if jid not in _jobs or _jobs[jid].get("stop"):
                    return
            _exec_and_notify(cmd, chat_id, bot, jid, main_loop)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return jid


def _exec_and_notify(cmd: str, chat_id: int, bot, jid: str, main_loop: asyncio.AbstractEventLoop):
    import subprocess
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=60
        )
        out = (r.stdout or r.stderr or "(no output)").strip()[:3000]
        msg = f"⏰ <b>Job #{jid} completed</b>\n<code>{cmd[:80]}</code>\n\n<pre>{out}</pre>"
    except Exception as e:
        msg = f"⏰ <b>Job #{jid} failed</b>\n<code>{cmd[:80]}</code>\n\n❌ {e}"

    async def _send():
        await bot.send_message(chat_id=chat_id, text=msg, parse_mode="HTML")

    try:
        asyncio.run_coroutine_threadsafe(_send(), main_loop)
    except Exception as e:
        logger.error(f"Failed to send job result: {e}")
