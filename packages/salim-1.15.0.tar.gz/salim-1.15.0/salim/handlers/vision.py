"""
Salim Vision AI — Ask questions about images sent to the bot.

How to use:
  1. Send any photo to the bot — Salim will auto-detect it and ask what you want to know.
  2. Reply to a photo with a question in text.
  3. Use /vision to enable/disable auto-analysis.

Commands:
  /vision              — Show vision status + instructions
  /vision on           — Enable auto-describe on every incoming photo
  /vision off          — Only answer when explicitly questioned
  /vision describe     — Describe the last photo sent
  /askvision <q>       — Ask a question about the last received photo

Supported question examples:
  "what app is open?"
  "read that error message"
  "what does this code do?"
  "translate this text"
  "what's in this image?"
  "describe what you see"
  "what is the person doing?"

Vision providers (free, in order):
  1. NVIDIA NIM — LLaVA-1.5-7B / Meta-Llama multimodal (uses existing NVIDIA API key)
  2. Groq       — Llama 3.2 Vision (uses existing Groq API key)
  3. Moondream  — tiny local vision model (offline, ~2GB RAM, CPU OK)
  4. BLIP       — fast image captioning (offline, no GPU needed)

Auto-installs (for offline mode): transformers, torch (CPU), Pillow

Image pipeline:
  Telegram photo → download → base64 encode → vision model → text response
"""
from __future__ import annotations

import asyncio
import base64
import html
import io
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.config import Config

logger = logging.getLogger("salim.vision")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

# Per-chat last photo storage (file_id → bytes cache)
_last_photo: dict[int, bytes] = {}

# Vision auto-mode per chat
_vision_auto: dict[int, bool] = {}  # chat_id → True if auto-describe enabled

VISION_CONFIG_FILE = Path.home() / ".salim" / "vision_config.json"
MOONDREAM_CACHE    = Path.home() / ".salim" / "moondream"


# ── Config ────────────────────────────────────────────────────────────────────

def _load_vision_config() -> dict:
    defaults = {"auto_mode": False, "provider": "auto"}
    try:
        if VISION_CONFIG_FILE.exists():
            defaults.update(json.loads(VISION_CONFIG_FILE.read_text()))
    except Exception:
        pass
    return defaults


def _save_vision_config(cfg: dict):
    VISION_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    VISION_CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


# ── Dependency helpers ────────────────────────────────────────────────────────

def _ensure_pillow() -> bool:
    try:
        from PIL import Image  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "Pillow", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception:
        return False


def _ensure_transformers() -> bool:
    """Install transformers + torch-cpu for offline vision."""
    try:
        import transformers  # noqa
        return True
    except ImportError:
        pass
    logger.info("Installing transformers for offline vision (CPU-only)...")
    try:
        # Install CPU-only torch first (much smaller than GPU version)
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "torch", "torchvision", "--index-url",
             "https://download.pytorch.org/whl/cpu", "--quiet"],
            check=True, timeout=300
        )
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "transformers", "Pillow", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception as e:
        logger.error(f"transformers install failed: {e}")
        return False


# ── Image preprocessing ───────────────────────────────────────────────────────

def _resize_image_for_api(image_bytes: bytes, max_dimension: int = 1024) -> bytes:
    """
    Resize image if too large (APIs have size limits).
    Returns JPEG bytes at max 1024px on the longer side.
    """
    _ensure_pillow()
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(image_bytes))

        # Convert to RGB (remove alpha channel if present)
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")

        # Resize if needed
        if max(img.width, img.height) > max_dimension:
            if img.width > img.height:
                new_w = max_dimension
                new_h = int(img.height * max_dimension / img.width)
            else:
                new_h = max_dimension
                new_w = int(img.width * max_dimension / img.height)
            img = img.resize((new_w, new_h), Image.LANCZOS)

        out = io.BytesIO()
        img.save(out, format="JPEG", quality=85, optimize=True)
        return out.getvalue()
    except Exception:
        return image_bytes


def _image_to_base64(image_bytes: bytes) -> str:
    """Convert image bytes to base64 data URL string."""
    jpeg_bytes = _resize_image_for_api(image_bytes)
    return base64.b64encode(jpeg_bytes).decode()


# ── Vision providers ──────────────────────────────────────────────────────────

async def _vision_nvidia(image_bytes: bytes, question: str, config: Config) -> tuple[str, str]:
    """
    Vision via NVIDIA NIM API.
    Uses: meta/llama-3.2-11b-vision-instruct or nvidia/neva-22b
    """
    api_key = config.get("SALIM_NVIDIA_API_KEY", "")
    if not api_key:
        raise RuntimeError("NVIDIA API key not configured")

    model = config.get(
        "SALIM_NVIDIA_VISION_MODEL",
        "meta/llama-3.2-11b-vision-instruct"
    )

    img_b64 = _image_to_base64(image_bytes)

    import httpx
    payload = {
        "model": model,
        "max_tokens": 1024,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{img_b64}"
                        }
                    },
                    {
                        "type": "text",
                        "text": question
                    }
                ]
            }
        ]
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://integrate.api.nvidia.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json=payload
        )
        resp.raise_for_status()
        data = resp.json()
        text = data["choices"][0]["message"]["content"].strip()
        return text, f"NVIDIA {model.split('/')[-1]}"


async def _vision_groq(image_bytes: bytes, question: str, config: Config) -> tuple[str, str]:
    """
    Vision via Groq API.
    Uses: llama-3.2-11b-vision-preview or llama-3.2-90b-vision-preview
    """
    api_key = config.get("SALIM_GROQ_API_KEY", "")
    if not api_key:
        raise RuntimeError("Groq API key not configured")

    model = "llama-3.2-11b-vision-preview"
    img_b64 = _image_to_base64(image_bytes)

    import httpx
    payload = {
        "model": model,
        "max_tokens": 1024,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{img_b64}"
                        }
                    },
                    {
                        "type": "text",
                        "text": question
                    }
                ]
            }
        ]
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json=payload
        )
        resp.raise_for_status()
        data = resp.json()
        text = data["choices"][0]["message"]["content"].strip()
        return text, f"Groq {model}"


async def _vision_moondream(image_bytes: bytes, question: str) -> tuple[str, str]:
    """
    Vision via Moondream2 — tiny 1.86B offline model.
    Downloads ~2GB on first use, cached in ~/.salim/moondream/
    No GPU needed — runs on CPU (slow but works).
    """
    if not _ensure_transformers():
        raise RuntimeError("transformers/torch not available")

    loop = asyncio.get_event_loop()

    def _run():
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from PIL import Image

        MOONDREAM_CACHE.mkdir(parents=True, exist_ok=True)
        model_id = "vikhyatk/moondream2"
        revision = "2024-08-26"

        # Load model (downloads on first call, cached forever)
        tokenizer = AutoTokenizer.from_pretrained(
            model_id, revision=revision,
            cache_dir=str(MOONDREAM_CACHE)
        )
        model = AutoModelForCausalLM.from_pretrained(
            model_id, revision=revision,
            trust_remote_code=True,
            cache_dir=str(MOONDREAM_CACHE)
        )

        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        enc_img = model.encode_image(img)
        answer = model.answer_question(enc_img, question, tokenizer)
        return answer

    answer = await loop.run_in_executor(None, _run)
    return answer, "Moondream2 (offline)"


async def _vision_blip(image_bytes: bytes, question: str) -> tuple[str, str]:
    """
    Vision via BLIP-2 / BLIP — fast image captioning/QA.
    Uses smaller model for speed. ~900MB download.
    """
    if not _ensure_transformers():
        raise RuntimeError("transformers not available")

    loop = asyncio.get_event_loop()

    def _run():
        from transformers import pipeline
        from PIL import Image

        BLIP_CACHE = Path.home() / ".salim" / "blip"
        BLIP_CACHE.mkdir(parents=True, exist_ok=True)

        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")

        # Use VQA (Visual Question Answering) if question is not just "describe"
        is_describe = any(kw in question.lower() for kw in ["describe", "what do you see", "what is in"])

        if is_describe:
            pipe = pipeline(
                "image-to-text",
                model="Salesforce/blip-image-captioning-base",
                model_kwargs={"cache_dir": str(BLIP_CACHE)}
            )
            result = pipe(img, max_new_tokens=100)
            return result[0]["generated_text"]
        else:
            pipe = pipeline(
                "visual-question-answering",
                model="Salesforce/blip-vqa-base",
                model_kwargs={"cache_dir": str(BLIP_CACHE)}
            )
            result = pipe(img, question, top_k=1)
            return result[0]["answer"]

    answer = await loop.run_in_executor(None, _run)
    return answer, "BLIP (offline)"


async def analyze_image(
    image_bytes: bytes,
    question: str,
    config: Config,
    preferred_provider: str = "auto"
) -> tuple[str, str]:
    """
    Analyze image with question using best available vision model.
    Falls back through provider chain automatically.
    Returns (answer, provider_name).
    """
    errors = []

    # Build provider chain based on what's configured
    providers = []

    if preferred_provider != "auto":
        providers.append(preferred_provider)

    # Always try API providers first (faster, better quality)
    if config.get("SALIM_NVIDIA_API_KEY"):
        if "nvidia" not in providers:
            providers.append("nvidia")
    if config.get("SALIM_GROQ_API_KEY"):
        if "groq" not in providers:
            providers.append("groq")

    # Offline fallbacks
    providers.extend(["moondream", "blip"])

    # Remove duplicates
    seen = set()
    chain = []
    for p in providers:
        if p not in seen:
            seen.add(p)
            chain.append(p)

    for provider in chain:
        try:
            if provider == "nvidia":
                return await _vision_nvidia(image_bytes, question, config)
            elif provider == "groq":
                return await _vision_groq(image_bytes, question, config)
            elif provider == "moondream":
                return await _vision_moondream(image_bytes, question)
            elif provider == "blip":
                return await _vision_blip(image_bytes, question)
        except Exception as e:
            logger.warning(f"Vision provider {provider} failed: {e}")
            errors.append(f"{provider}: {str(e)[:100]}")
            continue

    raise RuntimeError(
        "All vision providers failed:\n" + "\n".join(errors)
    )


# ── Handler class ─────────────────────────────────────────────────────────────

class VisionHandlers:
    """Mixin for Vision AI — image understanding commands."""

    @require_auth
    async def cmd_vision(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /vision        — show status
        /vision on     — auto-describe incoming photos
        /vision off    — manual mode only
        """
        msg = update.effective_message
        chat_id = msg.chat_id
        cfg = _load_vision_config()

        if ctx.args:
            arg = ctx.args[0].lower()
            if arg == "on":
                cfg["auto_mode"] = True
                _save_vision_config(cfg)
                _vision_auto[chat_id] = True
                await msg.reply_text(
                    "👁️ <b>Vision Auto-Mode: ON</b>\n"
                    "Every photo you send will be automatically described.\n\n"
                    "<i>Turn off: /vision off</i>",
                    parse_mode=H
                )
                return
            elif arg == "off":
                cfg["auto_mode"] = False
                _save_vision_config(cfg)
                _vision_auto[chat_id] = False
                await msg.reply_text(
                    "👁️ <b>Vision Auto-Mode: OFF</b>\n"
                    "Send a photo then reply with your question,\n"
                    "or use <code>/askvision &lt;question&gt;</code>",
                    parse_mode=H
                )
                return

        # Status
        auto = _vision_auto.get(chat_id, cfg.get("auto_mode", False))
        nvidia_ok = bool(self.config.get("SALIM_NVIDIA_API_KEY"))
        groq_ok   = bool(self.config.get("SALIM_GROQ_API_KEY"))
        moondream_ok = (MOONDREAM_CACHE / "models--vikhyatk--moondream2").exists()

        providers_status = []
        if nvidia_ok:  providers_status.append("✅ NVIDIA NIM (Llama Vision)")
        if groq_ok:    providers_status.append("✅ Groq (Llama 3.2 Vision)")
        if moondream_ok: providers_status.append("✅ Moondream2 (offline, cached)")
        if not providers_status:
            providers_status.append("⚠️ No providers configured (will use BLIP offline)")

        await msg.reply_text(
            f"👁️ <b>Vision AI Status</b>\n\n"
            f"Auto-mode: {'🟢 ON' if auto else '⚫ OFF'}\n\n"
            f"Available providers:\n"
            + "\n".join(f"  {p}" for p in providers_status)
            + "\n\n"
            "📸 <b>How to use:</b>\n"
            "1. Send any photo\n"
            "2. Reply to it with your question\n"
            "   — or — type <code>/askvision &lt;question&gt;</code>\n\n"
            "Examples:\n"
            "<i>What app is open?</i>\n"
            "<i>Read the error message</i>\n"
            "<i>What does this code do?</i>\n"
            "<i>Translate this text</i>\n\n"
            "<code>/vision on</code> — auto-describe all photos\n"
            "<code>/vision off</code> — manual mode",
            parse_mode=H
        )

    @require_auth
    async def cmd_askvision(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /askvision <question>  — Ask about the last received photo.
        Must have sent a photo in this chat before using this command.
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/askvision &lt;your question&gt;</code>\n"
                "Example: <code>/askvision what error is shown?</code>\n\n"
                "<i>Send a photo first, then use this command.</i>",
                parse_mode=H
            )
            return

        if chat_id not in _last_photo:
            await msg.reply_text(
                "❌ No photo received yet.\n"
                "Send a photo first, then ask your question.",
                parse_mode=H
            )
            return

        question = " ".join(ctx.args)
        await self._do_vision_query(msg, _last_photo[chat_id], question)

    async def handle_photo_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Called for every incoming photo.
        - Always caches the photo for /askvision
        - If message has caption/text that looks like a question → answer it
        - If auto-mode ON → describe the photo
        - Otherwise → prompt user to ask
        """
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return

        msg = update.effective_message
        chat_id = msg.chat_id

        # Get the largest photo version
        photo = msg.photo[-1] if msg.photo else None
        if not photo:
            return

        # Download and cache
        try:
            file_obj = await ctx.bot.get_file(photo.file_id)
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            image_bytes = buf.getvalue()
            _last_photo[chat_id] = image_bytes
        except Exception as e:
            logger.error(f"Photo download failed: {e}")
            return

        # If caption contains a question or natural query
        caption = (msg.caption or "").strip()
        if caption and len(caption) > 3:
            # Caption looks like a question — answer it
            await self._do_vision_query(msg, image_bytes, caption)
            return

        # Check auto-mode
        cfg = _load_vision_config()
        auto = _vision_auto.get(chat_id, cfg.get("auto_mode", False))

        if auto:
            await self._do_vision_query(
                msg, image_bytes, "Describe this image in detail. What do you see?"
            )
        else:
            # Prompt the user to ask something
            await msg.reply_text(
                "📸 <b>Photo received!</b>\n\n"
                "Ask me anything about it:\n"
                "• Reply to this message with your question\n"
                "• Or type: <code>/askvision &lt;question&gt;</code>\n\n"
                "<i>Examples: 'What app is open?', 'Read this text', 'Describe the image'</i>",
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("👁️ Auto-describe", callback_data=f"vision_describe:{chat_id}"),
                    InlineKeyboardButton("❌ Dismiss", callback_data="vision_dismiss"),
                ]])
            )

    async def handle_photo_reply(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Handle text messages that are replies to photos.
        When user replies to a photo message with text, treat it as a vision query.
        """
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return

        msg = update.effective_message
        if not msg.reply_to_message:
            return
        if not msg.reply_to_message.photo:
            return

        question = (msg.text or "").strip()
        if not question:
            return

        chat_id = msg.chat_id

        # Download the replied-to photo
        photo = msg.reply_to_message.photo[-1]
        try:
            file_obj = await ctx.bot.get_file(photo.file_id)
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            image_bytes = buf.getvalue()
            _last_photo[chat_id] = image_bytes  # cache it
        except Exception as e:
            await msg.reply_text(f"❌ Could not load photo: {esc(str(e))}", parse_mode=H)
            return

        await self._do_vision_query(msg, image_bytes, question)

    async def _do_vision_query(self, msg, image_bytes: bytes, question: str):
        """Core: analyze image and send response."""
        status = await msg.reply_text(
            f"👁️ <i>Analyzing image...</i>\n<i>Question: {esc(question[:80])}</i>",
            parse_mode=H
        )

        try:
            answer, provider = await analyze_image(
                image_bytes=image_bytes,
                question=question,
                config=self.config,
            )

            # Format answer
            answer_clean = answer.strip()
            if not answer_clean:
                answer_clean = "(No response from vision model)"

            await status.edit_text(
                f"👁️ <b>Vision AI</b> <i>[{esc(provider)}]</i>\n\n"
                f"❓ <i>{esc(question[:100])}</i>\n\n"
                f"{esc(answer_clean[:3000])}",
                parse_mode=H
            )

        except Exception as e:
            logger.error(f"Vision query error: {e}", exc_info=True)
            await status.edit_text(
                f"❌ <b>Vision Analysis Failed</b>\n\n"
                f"<code>{esc(str(e)[:400])}</code>\n\n"
                f"<i>Make sure NVIDIA or Groq API keys are configured,\n"
                f"or install offline models with: <code>pip install transformers torch</code></i>",
                parse_mode=H
            )

    async def handle_vision_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle vision inline button callbacks."""
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data.startswith("vision_describe:"):
            chat_id = int(data.split(":", 1)[1])
            if chat_id in _last_photo:
                await self._do_vision_query(
                    query.message, _last_photo[chat_id],
                    "Describe this image in detail. What do you see?"
                )
            else:
                await query.edit_message_text("❌ Photo no longer available.", parse_mode=H)

        elif data == "vision_dismiss":
            await query.delete_message()
