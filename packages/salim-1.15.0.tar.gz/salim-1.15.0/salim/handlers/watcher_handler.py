"""
salim.handlers.watcher_handler — File System Watcher
/watch <path>     — Start watching a file or folder for changes
/watchlist        — List active watchers
/watchstop <id>   — Stop a watcher
"""
from __future__ import annotations
import asyncio
import logging
import threading
import time
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)

# Active watchers: {watcher_id: {"path": str, "thread": Thread, "stop": Event, "chat_id": int}}
_watchers: dict[str, dict] = {}
_watcher_counter = 0


def _ensure_watchdog():
    from salim.auto_install import ensure_one
    return ensure_one("watchdog", "watchdog>=4.0")


class WatcherHandlers:

    async def cmd_watch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Watch a file or folder for changes. Usage: /watch <path>"""
        global _watcher_counter

        path_str = " ".join(ctx.args) if ctx.args else ""
        if not path_str:
            await update.message.reply_text("Usage: /watch <path>\nExample: /watch ~/Downloads")
            return

        path = Path(path_str).expanduser().resolve()
        if not path.exists():
            await update.message.reply_text(f"❌ Path not found: {path}")
            return

        if not _ensure_watchdog():
            await update.message.reply_text("❌ watchdog library could not be installed.")
            return

        _watcher_counter += 1
        wid = str(_watcher_counter)
        stop_event = threading.Event()
        chat_id = update.effective_chat.id
        bot = ctx.bot
        main_loop = asyncio.get_event_loop()

        t = threading.Thread(
            target=_watch_thread,
            args=(wid, path, stop_event, chat_id, bot, main_loop),
            daemon=True
        )
        _watchers[wid] = {
            "path": str(path),
            "thread": t,
            "stop": stop_event,
            "chat_id": chat_id,
        }
        t.start()

        await update.message.reply_text(
            f"👁 Watching [#{wid}]: <code>{path}</code>\n"
            f"You'll be notified of any changes.\n"
            f"Stop with: /watchstop {wid}",
            parse_mode="HTML"
        )

    async def cmd_watchlist(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List active file watchers."""
        if not _watchers:
            await update.message.reply_text("No active watchers.")
            return

        lines = ["<b>👁 Active File Watchers</b>\n"]
        for wid, info in _watchers.items():
            lines.append(f"  <b>#{wid}</b> → <code>{info['path']}</code>")

        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def cmd_watchstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a file watcher. Usage: /watchstop <id>"""
        wid = " ".join(ctx.args) if ctx.args else ""
        if not wid or wid not in _watchers:
            ids = list(_watchers.keys())
            await update.message.reply_text(
                f"Usage: /watchstop <id>\nActive IDs: {ids or 'none'}"
            )
            return

        _watchers[wid]["stop"].set()
        info = _watchers.pop(wid)
        await update.message.reply_text(f"✅ Stopped watcher #{wid} for {info['path']}")


def _watch_thread(wid: str, path: Path, stop: threading.Event, chat_id: int, bot, main_loop: asyncio.AbstractEventLoop):
    """Background thread that watches a path and sends Telegram messages on change."""
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler

    class Handler(FileSystemEventHandler):
        def on_modified(self, event):
            if not event.is_directory:
                _send_alert(bot, main_loop, chat_id, f"📝 Modified: <code>{event.src_path}</code>")

        def on_created(self, event):
            kind = "📁" if event.is_directory else "📄"
            _send_alert(bot, main_loop, chat_id, f"{kind} Created: <code>{event.src_path}</code>")

        def on_deleted(self, event):
            _send_alert(bot, main_loop, chat_id, f"🗑 Deleted: <code>{event.src_path}</code>")

        def on_moved(self, event):
            _send_alert(
                bot, main_loop, chat_id,
                f"↪️ Moved: <code>{event.src_path}</code>\n→ <code>{event.dest_path}</code>"
            )

    observer = Observer()
    target = str(path)
    recursive = path.is_dir()
    observer.schedule(Handler(), target, recursive=recursive)
    observer.start()

    try:
        while not stop.is_set():
            time.sleep(0.5)
    finally:
        observer.stop()
        observer.join()


def _send_alert(bot, main_loop: asyncio.AbstractEventLoop, chat_id: int, text: str):
    """Schedule a Telegram message onto the bot's running event loop (thread-safe)."""
    async def _send():
        await bot.send_message(chat_id=chat_id, text=f"👁 Watcher alert\n\n{text}", parse_mode="HTML")
    try:
        asyncio.run_coroutine_threadsafe(_send(), main_loop)
    except Exception as e:
        logger.warning(f"Watcher alert send failed: {e}")
