"""
Salim Voice Handler — transcribe Telegram voice/audio messages and execute as commands.

Pipeline:
  Telegram voice OGG  →  convert to WAV (ffmpeg)  →  transcribe (faster-whisper, tiny model, CPU)
  →  feed into AI intent parser  →  execute exactly like typed text

faster-whisper uses CTranslate2 — runs fully offline on CPU, no API key needed.
Model is downloaded once (~75MB for "tiny", ~150MB for "base") to ~/.salim/whisper/

Auto-installs: faster-whisper, ffmpeg (system)
"""
from __future__ import annotations

import asyncio
import io
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from telegram import Update, Message
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows, run_shell_async

logger = logging.getLogger("salim.voice")

WHISPER_MODEL_DIR = Path.home() / ".salim" / "whisper"
WHISPER_MODEL_SIZE = "base"   # tiny=75MB, base=150MB, small=500MB — base gives best quality/speed ratio


def _ensure_faster_whisper() -> bool:
    """Install faster-whisper if not present. Returns True if available."""
    try:
        import faster_whisper  # noqa
        return True
    except ImportError:
        pass
    try:
        logger.info("Installing faster-whisper (first-time setup)...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "faster-whisper", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install faster-whisper: {e}")
        return False


def _ensure_ffmpeg() -> bool:
    """Check ffmpeg is available (needed for OGG→WAV conversion)."""
    import shutil
    if shutil.which("ffmpeg"):
        return True
    # Try system install
    if is_linux():
        try:
            subprocess.run(["sudo", "apt-get", "install", "-y", "ffmpeg"], check=True, timeout=60)
            return True
        except Exception:
            pass
    elif is_mac():
        try:
            subprocess.run(["brew", "install", "ffmpeg"], check=True, timeout=120)
            return True
        except Exception:
            pass
    return False


def _load_whisper_model():
    """Load faster-whisper model (downloads on first run, cached forever)."""
    from faster_whisper import WhisperModel
    WHISPER_MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model = WhisperModel(
        WHISPER_MODEL_SIZE,
        device="cpu",
        compute_type="int8",          # int8 is fastest on CPU, very good quality
        download_root=str(WHISPER_MODEL_DIR),
    )
    return model


# Module-level model cache — loaded once, reused for all voice messages
_whisper_model = None
_model_lock = asyncio.Lock()


async def _get_model():
    global _whisper_model
    async with _model_lock:
        if _whisper_model is None:
            _whisper_model = await asyncio.get_event_loop().run_in_executor(
                None, _load_whisper_model
            )
    return _whisper_model


async def transcribe_audio(ogg_bytes: bytes) -> str:
    """Convert OGG bytes → WAV → transcribe → return text."""
    with tempfile.TemporaryDirectory() as tmp:
        ogg_path = os.path.join(tmp, "voice.ogg")
        wav_path = os.path.join(tmp, "voice.wav")

        # Write OGG
        with open(ogg_path, "wb") as f:
            f.write(ogg_bytes)

        # Convert OGG → WAV 16kHz mono (Whisper requirement)
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-i", ogg_path,
            "-ar", "16000", "-ac", "1", "-f", "wav", wav_path,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()

        if not os.path.exists(wav_path):
            raise RuntimeError("ffmpeg conversion failed")

        # Transcribe
        model = await _get_model()

        def _run_transcribe():
            segments, info = model.transcribe(
                wav_path,
                beam_size=5,
                language=None,          # auto-detect language
                vad_filter=True,        # filter silence
                vad_parameters={"min_silence_duration_ms": 500},
            )
            return " ".join(seg.text.strip() for seg in segments).strip()

        text = await asyncio.get_event_loop().run_in_executor(None, _run_transcribe)
        return text


class VoiceHandlers:
    """Mixin — handles incoming Telegram voice/audio messages."""

    async def handle_voice_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Called for every voice note or audio file sent to the bot."""
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return

        msg: Message = update.effective_message
        voice = msg.voice or msg.audio
        if not voice:
            return

        # Check dependencies
        if not _ensure_ffmpeg():
            await msg.reply_text(
                "❌ <b>ffmpeg not found.</b>\n"
                "Install it: <code>sudo apt install ffmpeg</code> (Linux) "
                "or <code>brew install ffmpeg</code> (Mac)",
                parse_mode="HTML"
            )
            return

        if not _ensure_faster_whisper():
            await msg.reply_text(
                "❌ Could not install <code>faster-whisper</code>.\n"
                "Run: <code>pip install faster-whisper</code>",
                parse_mode="HTML"
            )
            return

        status = await msg.reply_text("🎙️ <i>Transcribing voice message...</i>", parse_mode="HTML")

        try:
            # Download audio from Telegram
            file_obj = await ctx.bot.get_file(voice.file_id)
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            ogg_bytes = buf.getvalue()

            # Transcribe
            text = await transcribe_audio(ogg_bytes)

            if not text:
                await status.edit_text("🎙️ <i>Could not detect speech. Please speak clearly.</i>", parse_mode="HTML")
                return

            await status.edit_text(
                f"🎙️ <b>Voice command heard:</b>\n<i>\"{text}\"</i>\n\n⚙️ Processing...",
                parse_mode="HTML"
            )

            # Feed into the AI handler exactly like typed text
            if hasattr(self, "handle_ai_message"):
                # Fake the message text so handle_ai_message works normally
                original_text = msg.text
                msg.text = text
                await self.handle_ai_message(update, ctx)
                msg.text = original_text
            else:
                await msg.reply_text(
                    f"🎙️ Transcribed: <code>{text}</code>\n\n"
                    "AI handler not found — copy the text and send it manually.",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"Voice transcription error: {e}", exc_info=True)
            await status.edit_text(f"❌ Voice processing failed: {e}", parse_mode="HTML")

    @require_auth
    async def cmd_voice_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show voice feature status."""
        has_ffmpeg = bool(__import__("shutil").which("ffmpeg"))
        try:
            import faster_whisper  # noqa
            has_whisper = True
            model_cached = (WHISPER_MODEL_DIR / WHISPER_MODEL_SIZE).exists() or \
                           any(WHISPER_MODEL_DIR.rglob("model.bin"))
        except ImportError:
            has_whisper = False
            model_cached = False

        await update.effective_message.reply_text(
            f"🎙️ <b>Voice Commands Status</b>\n\n"
            f"ffmpeg: {'✅' if has_ffmpeg else '❌ missing'}\n"
            f"faster-whisper: {'✅' if has_whisper else '❌ not installed'}\n"
            f"Model ({WHISPER_MODEL_SIZE}): {'✅ cached' if model_cached else '⏳ will download on first use'}\n\n"
            f"<i>Send any voice note to use voice commands.</i>",
            parse_mode="HTML"
        )
