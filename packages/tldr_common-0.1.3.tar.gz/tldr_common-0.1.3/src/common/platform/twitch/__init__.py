from .api import TwitchApi, TwitchApiConfig
from .conduit import ConduitManager
from . import webhook as _webhook
from . import websocket as _websocket

__all__ = [
    "TwitchApi",
    "TwitchApiConfig",
    "ConduitManager",
    *_webhook.__all__,
    *_websocket.__all__,
]

globals().update({name: getattr(_webhook, name) for name in _webhook.__all__})
globals().update({name: getattr(_websocket, name) for name in _websocket.__all__})
