from typing import List
from common.models.common import Platform

from pydantic import BaseModel


class ByPlatform(BaseModel):
    platform: Platform
    count: int


class ClipFilter(BaseModel):
    id: int
    url: str


class Users(BaseModel):
    email: str
    duration: int


class MetricResponse(BaseModel):
    active_streams_count: int
    active_streams_by_platform: List[ByPlatform]
    clips_generated: int
    minutes_since_last_clip_generated: int
    clips_generated_today: int
    ai_clips_generated: int
    voice_clips_generated: int
    ai_clips_generated_today: int
    voice_clips_generated_today: int
    user_with_both_platform_linked: int
    user_only_twitch_linked: int
    user_only_kick_linked: int
    top_10_clip_with_more_views: List[ClipFilter]
    top_10_clip_with_more_reactions: List[ClipFilter]
    edited_clips_generated: int
    edited_clips_generated_today: int
    scheduled_post_count: int
    scheduled_post_count_today: int
    new_users_last_48_hours: int
    total_users: int
    top_10_users_more_clips: List[Users]
    top_10_users_more_streams: List[Users]
    top_10_users_stream_duration: List[Users]
