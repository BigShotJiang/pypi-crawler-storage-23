---
tags:
  category: system
  context: tag-value
---
# status: `open`

Active and unfulfilled. The initial state for commitments, requests, and offers. Work is in progress or awaiting action.
