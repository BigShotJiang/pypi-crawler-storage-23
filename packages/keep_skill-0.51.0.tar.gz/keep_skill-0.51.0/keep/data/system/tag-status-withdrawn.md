---
tags:
  category: system
  context: tag-value
---
# status: `withdrawn`

Cancelled by the originator. The speaker retracts their commitment, request, or offer. Terminal state — no further action expected.
