# Merging module
from .merger import TranscriptMerger

__all__ = ["TranscriptMerger"]
