import uuid
import pytest
from expects import expect, have_keys, be_a

from documente_shared.domain.entities.in_memory_document import InMemoryDocument
from documente_shared.domain.entities.processing_case_item import ProcessingCaseItem
from documente_shared.domain.enums.common import ProcessingStatus


@pytest.fixture(scope="function")
def processing_case_item(
    in_memory_document: InMemoryDocument,
) -> ProcessingCaseItem:
    return ProcessingCaseItem(
        uuid=str(uuid.uuid4()),
        case_id=str(uuid.uuid4()),
        digest=str(uuid.uuid4()),
        status=ProcessingStatus.PENDING,
        document=in_memory_document,
        document_type=None,
        uploaded_from=None,
        processed_csv=None,
        processed_xlsx=None,
        processed_json=None,
        processing_time=None,
        processing_confidence=None,
        uploaded_at=None,
        started_at=None,
        failed_at=None,
        completed_at=None,
        feedback={},
        metadata={},
    )


def test_to_dict(
    processing_case_item: ProcessingCaseItem,
):
    result = processing_case_item.to_dict

    expect(result).to(
        have_keys(
            "uuid",
            "case_id",
            "digest",
            "status",
            "document",
            "document_type",
            "uploaded_from",
            "processed_csv",
            "processed_xlsx",
            "processed_json",
            "processing_time",
            "processing_confidence",
            "uploaded_at",
            "started_at",
            "failed_at",
            "feedback",
            "metadata",
            "completed_at",
        )
    )


def test_from_dict(
    in_memory_document: InMemoryDocument,
):
    data = {
        "uuid": str(uuid.uuid4()),
        "case_id": str(uuid.uuid4()),
        "digest": str(uuid.uuid4()),
        "status": "PENDING",
        "document": {
            "file_path": in_memory_document.file_path,
            "file_base64": in_memory_document.file_base64,
        },
        "document_type": None,
        "uploaded_from": None,
        "processed_csv": None,
        "processed_xlsx": None,
        "processed_json": None,
        "processing_time": None,
        "processing_confidence": None,
        "uploaded_at": None,
        "started_at": None,
        "failed_at": None,
        "feedback": {},
        "metadata": {},
        "completed_at": None,
    }

    result = ProcessingCaseItem.from_dict(data)

    expect(result).to(be_a(ProcessingCaseItem))
