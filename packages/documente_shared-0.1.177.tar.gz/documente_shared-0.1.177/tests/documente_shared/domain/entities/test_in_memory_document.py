from expects import expect, be_a, equal, have_keys

from documente_shared.domain.entities.in_memory_document import InMemoryDocument



def test_instance_with_base64_and_path(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
):

    result = InMemoryDocument(
        file_path=document_filename,
        file_base64=document_base64,
    )

    expect(result).to(be_a(InMemoryDocument))
    expect(result.file_path).to(equal(document_filename))
    expect(result.file_base64).to(equal(document_base64))
    expect(result.file_bytes).to(equal(document_bytes))


def test_instance_with_bytes_and_path(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
):
    result = InMemoryDocument(
        file_path=document_filename,
        file_bytes=document_bytes,
    )

    expect(result).to(be_a(InMemoryDocument))
    expect(result.file_path).to(equal(document_filename))
    expect(result.file_base64).to(equal(document_base64))
    expect(result.file_bytes).to(equal(document_bytes))


def test_from_dict_with_base64_and_path(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
):

    result = InMemoryDocument.from_dict({
        "file_path": document_filename,
        "file_base64": document_base64,
    })

    expect(result).to(be_a(InMemoryDocument))
    expect(result.file_path).to(equal(document_filename))
    expect(result.file_base64).to(equal(document_base64))
    expect(result.file_bytes).to(equal(document_bytes))


def test_from_dict_with_bytes_and_path(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
):
    result = InMemoryDocument.from_dict({
        "file_path": document_filename,
        "file_bytes": document_bytes,
    })

    expect(result).to(be_a(InMemoryDocument))
    expect(result.file_path).to(equal(document_filename))
    expect(result.file_base64).to(equal(document_base64))
    expect(result.file_bytes).to(equal(document_bytes))


def test_from_dict(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
):
    result = InMemoryDocument.from_dict({
        "file_path": document_filename,
        "file_bytes": document_bytes,
        "file_base64": document_base64,
    })

    expect(result).to(be_a(InMemoryDocument))
    expect(result.file_path).to(equal(document_filename))
    expect(result.file_base64).to(equal(document_base64))
    expect(result.file_bytes).to(equal(document_bytes))


def test_to_dict(
    in_memory_document: InMemoryDocument,
):
    result = in_memory_document.to_dict

    expect(result).to(be_a(dict))
    expect(result).to(have_keys("file_path", "file_base64"))
