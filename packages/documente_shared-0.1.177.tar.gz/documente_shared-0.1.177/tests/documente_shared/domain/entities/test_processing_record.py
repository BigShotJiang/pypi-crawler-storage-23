from expects import expect, equal, be_a

from documente_shared.domain.entities.processing_record import ProcessingRecord


def test_to_payload():
    # Arrange
    instance = ProcessingRecord(
        document_digest="0e4b13a1e...18aad2141b8",
        tenant_slug="BDP",
        document_type="PROCESSING_CASE_ITEM",
        processed_pages=20,
    )

    # Act
    result = instance.to_payload

    # Assert
    expect(result).to(
        equal(
            {
                "documentDigest": "0e4b13a1e...18aad2141b8",
                "tenantSlug": "BDP",
                "documentType": "PROCESSING_CASE_ITEM",
                "processedPages": 20,
            }
        )
    )


def test_from_dict():
    # Arrange
    data = {
        "documentDigest": "0e4b13a1e...18aad2141b8",
        "tenantSlug": "BDP",
        "documentType": "PROCESSING_CASE_ITEM",
        "processedPages": 20,
    }

    # Act
    result = ProcessingRecord.from_dict(data)

    # Assert
    expect(result).to(be_a(ProcessingRecord))
    expect(result.document_digest).to(equal("0e4b13a1e...18aad2141b8"))
    expect(result.tenant_slug).to(equal("BDP"))
    expect(result.document_type).to(equal("PROCESSING_CASE_ITEM"))
    expect(result.processed_pages).to(equal(20))
