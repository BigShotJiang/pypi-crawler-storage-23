import uuid
from os import path
from unittest.mock import ANY

import pytest
from expects import expect, have_keys, be_a, equal

from documente_shared.domain.entities.processing_case import ProcessingCase
from documente_shared.domain.enums.common import ProcessingStatus
from documente_shared.domain.enums.processing_case import ProcessingCaseType


@pytest.fixture
def processing_case() -> ProcessingCase:
    return ProcessingCase(
        uuid=str(uuid.uuid4()),
        name="Test Case",
        tenant_slug="test_tenant",
        status=ProcessingStatus.PENDING,
        case_type=ProcessingCaseType.BCP_MICROCREDITO,
        enqueued_at=None,
        started_at=None,
        failed_at=None,
        feedback=[],
        completed_at=None,
        metadata={},
        items=[],
    )


def test_to_dict(
    processing_case: ProcessingCase,
):
    result = processing_case.to_dict

    expect(result).to(
        have_keys({
            "uuid": ANY,
            "name": "Test Case",
            "tenant_slug": "test_tenant",
            "status": "PENDING",
            "case_type": "BCP_MICROCREDITO",
            "enqueued_at": None,
            "started_at": None,
            "failed_at": None,
            "feedback": [],
            "completed_at": None,
            "metadata": {},
            "items": [],
        })
    )




def test_from_dict(
    processing_case: ProcessingCase,
):
    data = {
        "uuid": str(uuid.uuid4()),
        "name": "Test Case",
        "tenant_slug": "test_tenant",
        "status": ProcessingStatus.PENDING,
        "case_type": ProcessingCaseType.BCP_MICROCREDITO,
        "enqueued_at": None,
        "started_at": None,
        "failed_at": None,
        "feedback": [],
        "completed_at": None,
        "metadata": {},
        "items": [],
    }

    result = ProcessingCase.from_dict(data)

    expect(result).to(be_a(ProcessingCase))
