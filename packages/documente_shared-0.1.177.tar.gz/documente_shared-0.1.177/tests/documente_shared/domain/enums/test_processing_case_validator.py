from documente_shared.domain.enums.processing_case import (
    ProcessingCaseType,
    ProcessingDocumentType,
)
from documente_shared.domain.enums.processing_case_validator import (
    ProcessingCaseDocumentValidator,
)
from expects import expect, be_false, be_true


def test_can_handle_document_using_enum_values():
    # Arrange
    case_type = ProcessingCaseType.UNIVIDA_SOAT
    document_type = ProcessingDocumentType.LICENCIA_DE_CONDUCIR

    # Act
    result = ProcessingCaseDocumentValidator.can_handle_document(
        case_type,
        document_type,
    )

    # Assert
    expect(result).to(be_true)


def test_can_handle_document_using_string_inputs():
    # Arrange
    case_type = "seguros_soat"
    document_type = "documento_completo"

    # Act
    result = ProcessingCaseDocumentValidator.can_handle_document(
        case_type,
        document_type,
    )

    # Assert
    expect(result).to(be_true)


def test_rejects_invalid_document_for_case():
    # Arrange
    case_type = ProcessingCaseType.AGNOSTIC
    document_type = ProcessingDocumentType.NIT

    # Act
    result = ProcessingCaseDocumentValidator.can_handle_document(
        case_type,
        document_type,
    )

    # Assert
    expect(result).to(be_false)
