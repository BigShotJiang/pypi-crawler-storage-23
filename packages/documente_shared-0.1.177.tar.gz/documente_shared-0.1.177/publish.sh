#!/bin/bash
set -e

PACKAGE_NAME="documente_shared"
PACKAGE_VERSION=$(uv run python -c "import tomllib; print(tomllib.load(open('pyproject.toml','rb'))['project']['version'])")
if curl -f -s "https://pypi.org/pypi/${PACKAGE_NAME}/${PACKAGE_VERSION}/json" > /dev/null; then
    echo "Package version ${PACKAGE_VERSION} already exists in PyPI. Publishing aborted."
    exit 0
fi

echo "Package version ${PACKAGE_VERSION} doesn't exist in PyPI. Continue publishing"

uv build
uv publish --token "$PYPI_API_KEY"
