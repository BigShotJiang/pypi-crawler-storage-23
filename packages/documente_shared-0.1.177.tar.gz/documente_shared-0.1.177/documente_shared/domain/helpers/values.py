from datetime import datetime


def optional_str(input_value: object | None = None) -> str | None:
    if input_value is None:
        return None
    return str(input_value)


def optional_datetime_str(input_datetime: datetime | None = None) -> str | None:
    if input_datetime is None:
        return None
    return input_datetime.isoformat()
