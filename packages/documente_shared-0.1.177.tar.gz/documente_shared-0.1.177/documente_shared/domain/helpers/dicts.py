"""Utilities for working with dictionaries."""

from typing import TypeVar, Dict, Any

K = TypeVar("K")
V = TypeVar("V")


def filter_none_values(data: Dict[K, V | None]) -> Dict[K, V]:
    """
    Filter out dictionary entries where the value is None.

    Args:
        data: Dictionary that may contain None values

    Returns:
        New dictionary with None values removed

    Examples:
        >>> filter_none_values({"a": 1, "b": None, "c": 3})
        {'a': 1, 'c': 3}
        >>> filter_none_values({"name": "John", "age": None})
        {'name': 'John'}
        >>> filter_none_values({})
        {}
    """
    return {k: v for k, v in data.items() if v is not None}


def filter_empty_values(data: Dict[K, V | None]) -> Dict[K, V]:
    """
    Filter out dictionary entries where the value is None or empty.

    Considers None, empty strings, empty lists, empty dicts as empty.

    Args:
        data: Dictionary that may contain empty values

    Returns:
        New dictionary with empty values removed

    Examples:
        >>> filter_empty_values({"a": 1, "b": None, "c": "", "d": []})
        {'a': 1}
        >>> filter_empty_values({"name": "John", "tags": []})
        {'name': 'John'}
    """
    return {
        k: v
        for k, v in data.items()
        if v is not None and v != "" and v != [] and v != {}
    }


def compact_dict(data: Dict[K, Any]) -> Dict[K, Any]:
    """
    Remove None, empty strings, empty lists, and empty dicts from a dictionary.

    Alias for filter_empty_values with a more concise name.

    Args:
        data: Dictionary to compact

    Returns:
        Compacted dictionary

    Examples:
        >>> compact_dict({"a": 1, "b": None, "c": ""})
        {'a': 1}
    """
    return filter_empty_values(data)
