from uuid import UUID
from abc import ABC, abstractmethod

from documente_shared.domain.entities.workspace import Workspace
from documente_shared.domain.filters.workspace import WorkspaceFilters
from documente_shared.domain.pagination.entities import Page


class WorkspaceRepository(ABC):
    @abstractmethod
    def find(self, instance_id: UUID) -> Workspace | None:
        raise NotImplementedError

    @abstractmethod
    def filter(self, filters: WorkspaceFilters) -> list[Workspace]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(self, filters: WorkspaceFilters) -> Page[Workspace]:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: Workspace) -> Workspace:
        raise NotImplementedError

    @abstractmethod
    def delete(self, instance_id: UUID) -> None:
        raise NotImplementedError
