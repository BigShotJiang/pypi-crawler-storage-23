from abc import ABC, abstractmethod

from documente_shared.domain.entities.processing_record import ProcessingRecord


class ProcessingRecordRepository(ABC):

    @abstractmethod
    def persist(self, instance: ProcessingRecord) -> ProcessingRecord:
        raise NotImplementedError
