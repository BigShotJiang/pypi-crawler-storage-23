from uuid import UUID
from datetime import datetime

from pydantic import BaseModel, Field

from documente_shared.domain.enums.processing_case import ProcessingDocumentType
from documente_shared.domain.helpers.values import optional_str


class DocumentType(BaseModel):
    uuid: UUID
    name: str
    tenant_id: UUID | None = Field(default=None)
    is_shareable: bool = False
    processing_document_type: ProcessingDocumentType | None = Field(default=None)
    description: str | None = Field(default=None)
    metadata: dict | None = Field(default=None)
    created_at: datetime | None = Field(default=None)
    updated_at: datetime | None = Field(default=None)

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "name": self.name,
            "is_shareable": self.is_shareable,
            "processing_document_type": optional_str(self.processing_document_type),
            "description": self.description,
            "metadata": self.metadata or {},
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "name": self.name,
            "tenant_id": str(self.tenant_id) if self.tenant_id else None,
            "is_shareable": self.is_shareable,
            "processing_document_type": optional_str(self.processing_document_type),
            "description": self.description,
            "metadata": self.metadata or {},
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'DocumentType':
        return cls(
            uuid=data.get('uuid'),
            name=data.get('name'),
            tenant_id=data.get('tenant_id'),
            is_shareable=data.get('is_shareable', False),
            processing_document_type=ProcessingDocumentType.from_value(data.get('processing_document_type')),
            description=data.get('description'),
            metadata=data.get('metadata', {}),
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at'),
        )