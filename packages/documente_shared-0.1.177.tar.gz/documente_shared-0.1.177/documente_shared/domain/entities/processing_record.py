from dataclasses import dataclass

from documente_shared.application.payloads import camel_to_snake, snake_to_camel


@dataclass
class ProcessingRecord(object):
    document_digest: str
    tenant_slug: str
    document_type: str
    processed_pages: int

    @property
    def to_dict(self) -> dict:
        return {
            "document_digest": self.document_digest,
            "tenant_slug": self.tenant_slug,
            "document_type": self.document_type,
            "processed_pages": self.processed_pages,
        }

    @property
    def to_payload(self) -> dict:
        return snake_to_camel(self.to_dict)

    @classmethod
    def from_dict(cls, data: dict) -> "ProcessingRecord":
        normalized = camel_to_snake(data)
        return cls(
            document_digest=normalized.get("document_digest"),
            tenant_slug=normalized.get("tenant_slug"),
            document_type=normalized.get("document_type"),
            processed_pages=normalized.get("processed_pages"),
        )
