from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, Field

from documente_shared.application.time_utils import get_datetime_from_data
from documente_shared.domain.entities.in_memory_document import InMemoryDocument
from documente_shared.domain.enums.common import ProcessingStatus
from documente_shared.domain.enums.workspace import WorkspaceSource
from documente_shared.domain.helpers.values import optional_str, optional_datetime_str


class WorkspaceDocument(BaseModel):
    uuid: UUID
    name: str
    status: ProcessingStatus
    workspace_id: UUID
    tenant_id: UUID | None = Field(default=None)
    tenant_slug: str | None = Field(default=None)
    digest: str | None = Field(default=None)
    created_by_id: UUID | None = Field(default=None)
    document_type_id: UUID | None = Field(default=None)
    source: WorkspaceSource | None = Field(default=None)
    document: InMemoryDocument | None = Field(default=None)
    document_url: str | None = Field(default=None)
    processing_time: Decimal | None = Field(default=None)
    metadata: dict | None = Field(default_factory=dict)
    extraction: dict | None = Field(default_factory=dict)
    uploaded_at: datetime | None = Field(default=None)
    created_at: datetime | None = Field(default=None)
    updated_at: datetime | None = Field(default=None)
    started_at: datetime | None = Field(default=None)
    completed_at: datetime | None = Field(default=None)
    failed_at: datetime | None = Field(default=None)

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "workspace_id": str(self.workspace_id),
            "document_type_id": optional_str(self.document_type_id),
            "created_by_id": optional_str(self.created_by_id),
            "name": self.name,
            "digest": self.digest,
            "status": str(self.status),
            "source": optional_str(self.source),
            "uploaded_at": optional_datetime_str(self.uploaded_at),
            "created_at": optional_datetime_str(self.created_at),
            "updated_at": optional_datetime_str(self.updated_at),
            "started_at": optional_datetime_str(self.started_at),
            "completed_at": optional_datetime_str(self.completed_at),
            "failed_at": optional_datetime_str(self.failed_at),
            "processing_time": self.processing_time,
            "metadata": self.metadata or {},
            "extraction": self.extraction or {},
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "name": self.name,
            "digest": self.digest,
            "status": str(self.status),
            "tenant_id": self.tenant_id,
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "created_by_id": optional_str(self.created_by_id),
            "document_type_id": optional_str(self.document_type_id),
            "source": optional_str(self.source),
            "document": (self.document.to_dict if self.document else None),
            "document_url": self.document_url,
            "processing_time": optional_str(self.processing_time),
            "metadata": self.metadata,
            "extraction": self.extraction,
            "uploaded_at": optional_datetime_str(self.uploaded_at),
            "started_at": optional_datetime_str(self.started_at),
            "completed_at": optional_datetime_str(self.completed_at),
            "failed_at": optional_datetime_str(self.failed_at),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "WorkspaceDocument":
        return cls(
            uuid=data.get("uuid"),
            name=data.get("name"),
            digest=data.get("digest"),
            status=ProcessingStatus.from_value(data.get("status")),
            tenant_slug=data.get("tenant_slug"),
            workspace_id=data.get("workspace_id"),
            document_type_id=data.get("document_type_id"),
            created_by_id=data.get("created_by_id"),
            source=WorkspaceSource.from_value(data.get("source")),
            document=(
                InMemoryDocument.from_dict(data.get("document"))
                if data.get("document")
                else None
            ),
            document_url=data.get("document_url"),
            processing_time=(
                Decimal(data.get("processing_time"))
                if data.get("processing_time")
                else None
            ),
            metadata=data.get("metadata", {}),
            extraction=data.get("extraction", {}),
            uploaded_at=get_datetime_from_data(input_datetime=data.get("uploaded_at")),
            created_at=get_datetime_from_data(input_datetime=data.get("created_at")),
            updated_at=get_datetime_from_data(input_datetime=data.get("updated_at")),
            started_at=get_datetime_from_data(input_datetime=data.get("started_at")),
            completed_at=get_datetime_from_data(
                input_datetime=data.get("completed_at")
            ),
            failed_at=get_datetime_from_data(input_datetime=data.get("failed_at")),
        )
