from datetime import datetime
from typing import Self
from uuid import UUID

from pydantic import BaseModel, Field

from documente_shared.domain.constants import DEFAULT_PAGINATION_PAGE_SIZE
from documente_shared.domain.helpers.encoding import decode_base64, encode_base64


class ListFilters(BaseModel):
    search: str | None = Field(default=None)
    cursor: str | None = Field(default=None)
    limit: int = Field(default=DEFAULT_PAGINATION_PAGE_SIZE)

    @property
    def page_cursor(self) -> "PageCursor":
        if self.cursor is None:
            return PageCursor.initial()
        try:
            return PageCursor.from_base64(self.cursor)
        except ValueError:
            return PageCursor.initial()

    @classmethod
    def from_query_params(cls, params: dict) -> "ListFilters":
        return cls(
            search=params.get("search"),
            cursor=params.get("cursor"),
            limit=params.get("limit"),
        )

    @property
    def to_dict(self) -> dict:
        return {
            "search": self.search,
            "cursor": self.cursor,
            "limit": self.limit,
        }

class PageCursor(BaseModel):
    uuid: UUID | None = Field(default=None)
    value: datetime | None = Field(default=None)

    @property
    def to_base64(self) -> str | None:
        if not self.value or not self.uuid:
            return None
        raw_value = f"{self.value.isoformat()}|{self.uuid}"
        return encode_base64(raw_value)

    @classmethod
    def from_base64(cls, base64: str) -> "PageCursor":
        decoded_value = decode_base64(base64)
        value, uuid = decoded_value.split("|")
        return cls(
            uuid=UUID(uuid),
            value=datetime.fromisoformat(value),
        )

    @classmethod
    def initial(cls) -> "PageCursor":
        return cls()


class Page[T](BaseModel):
    limit: int
    next_cursor: PageCursor
    prev_cursor: PageCursor
    items: list[T] = Field(default_factory=list)

    @property
    def to_pagination_dict(self) -> dict:
        return {
            "limit": self.limit,
            "prev_cursor": self.prev_cursor.to_base64,
            "next_cursor": self.next_cursor.to_base64,
        }

    @classmethod
    def empty(
        cls,
        limit: int | None = DEFAULT_PAGINATION_PAGE_SIZE,
        items: list[T] | None = None,
    ) -> Self:
        return cls(
            limit=limit,
            next_cursor=PageCursor.initial(),
            prev_cursor=PageCursor.initial(),
            items=items or [],
        )
