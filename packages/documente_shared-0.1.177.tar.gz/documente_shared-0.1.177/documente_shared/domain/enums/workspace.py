from documente_shared.domain.base_enum import BaseEnum


class WorkspaceSource(BaseEnum):
    WEB = "WEB"
    MOBILE = "MOBILE"
    TOOLS = "TOOLS"

    @property
    def is_web(self):
        return self == self.WEB

    @property
    def is_mobile(self):
        return self == self.MOBILE

    @property
    def is_tools(self):
        return self == self.TOOLS
