from os import environ
from zoneinfo import ZoneInfo


la_paz_tz = ZoneInfo("America/La_Paz")

DOCUMENTE_API_URL = environ.get("DOCUMENTE_API_URL")
DOCUMENTE_API_KEY = environ.get("DOCUMENTE_API_KEY")

DEFAULT_PAGINATION_PAGE_SIZE = 50