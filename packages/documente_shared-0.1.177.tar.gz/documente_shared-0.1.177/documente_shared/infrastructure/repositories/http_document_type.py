from dataclasses import dataclass
from uuid import UUID

import structlog

from documente_shared.domain.entities.document_type import DocumentType
from documente_shared.domain.filters.document_type import DocumentTypeFilters
from documente_shared.domain.pagination.entities import Page, PageCursor
from documente_shared.domain.repositories.document_type import DocumentTypeRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin

logger = structlog.get_logger()


@dataclass
class HttpDocumentTypeRepository(
    DocumenteClientMixin,
    DocumentTypeRepository,
):
    def find(self, uuid: UUID) -> DocumentType | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/document-types/{uuid}/",
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, DocumentType.from_dict)

    def find_with_tenant(self, tenant_id: UUID, instance_id: UUID) -> DocumentType | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/document-types/{instance_id}/",
            params={"tenant_id": str(tenant_id)},
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, DocumentType.from_dict)

    def find_by_tenant(self, tenant_id: UUID, shareable_only: bool = False) -> list[DocumentType]:
        response = self.session.get(
            url=f"{self.api_url}/v1/document-types/",
            params={"tenant_ids": [str(tenant_id)], "shareable_only": shareable_only},
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, DocumentType.from_dict)

    def filter(self, filters: DocumentTypeFilters) -> list[DocumentType]:
        response = self.session.get(
            url=f"{self.api_url}/v1/document-types/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, DocumentType.from_dict)

    def filter_paginated(self, filters: DocumentTypeFilters) -> Page[DocumentType]:
        response = self.session.get(
            url=f"{self.api_url}/v1/document-types/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return Page.empty()
        return Page(
            limit=filters.limit,
            next_cursor=PageCursor.initial(),
            prev_cursor=PageCursor.initial(),
            items=self._parse_list(response, DocumentType.from_dict),
        )

    def persist(self, instance: DocumentType) -> DocumentType:
        logger.info("[shared.document_type.persisting]", data=instance.to_persist_dict)
        existing = self.find(instance.uuid)
        if existing:
            response = self.session.put(
                url=f"{self.api_url}/v1/document-types/{instance.uuid}/",
                json=instance.to_persist_dict,
            )
        else:
            response = self.session.post(
                url=f"{self.api_url}/v1/document-types/",
                json=instance.to_persist_dict,
            )
        if not self._is_success(response):
            logger.error("[shared.document_type.persist_error]", response=response.text)
            return instance
        return self._parse_instance(response, DocumentType.from_dict)

    def delete(self, uuid: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/document-types/{uuid}/")
