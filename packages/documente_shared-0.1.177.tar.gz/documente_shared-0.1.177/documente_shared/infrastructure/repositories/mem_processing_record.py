from dataclasses import dataclass

from documente_shared.domain.entities.processing_record import ProcessingRecord
from documente_shared.domain.repositories.processing_record import ProcessingRecordRepository


@dataclass
class MemoryProcessingRecordRepository(ProcessingRecordRepository):
    collection: list[ProcessingRecord] = None

    def __post_init__(self):
        self.collection = self.collection or []

    def persist(self, instance: ProcessingRecord) -> ProcessingRecord:
        self.collection.append(instance)
        return instance
