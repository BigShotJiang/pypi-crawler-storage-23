from dataclasses import dataclass
from uuid import UUID

import structlog
from requests import Response

from documente_shared.domain.entities.workspace_document_page import WorkspaceDocumentPage
from documente_shared.domain.filters.workspace_document_page import WorkspaceDocumentPageFilters
from documente_shared.domain.pagination.entities import Page, PageCursor
from documente_shared.domain.repositories.workspace_document_page import WorkspaceDocumentPageRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin

logger = structlog.get_logger()


@dataclass
class HttpWorkspaceDocumentPageRepository(
    DocumenteClientMixin,
    WorkspaceDocumentPageRepository,
):
    def find(self, instance_id: UUID) -> WorkspaceDocumentPage | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-document-pages/{instance_id}/",
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, WorkspaceDocumentPage.from_dict)

    def find_by_document(
        self,
        workspace_document_id: UUID,
        include_bytes: bool = False,
    ) -> list[WorkspaceDocumentPage]:
        params = {"include_bytes": include_bytes}
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{workspace_document_id}/pages/",
            params=params,
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, WorkspaceDocumentPage.from_dict)

    def find_by_document_and_page_number(
        self,
        workspace_document_id: UUID,
        page_number: int,
    ) -> WorkspaceDocumentPage | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{workspace_document_id}/pages/{page_number}/",
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, WorkspaceDocumentPage.from_dict)

    def filter(self, filters: WorkspaceDocumentPageFilters) -> list[WorkspaceDocumentPage]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{filters.workspace_document_id}/pages/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, WorkspaceDocumentPage.from_dict)

    def filter_paginated(self, filters: WorkspaceDocumentPageFilters) -> Page[WorkspaceDocumentPage]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{filters.workspace_document_id}/pages/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return Page.empty()

        return Page(
            limit=filters.limit,
            next_cursor=PageCursor.initial(),
            prev_cursor=PageCursor.initial(),
            items=self._parse_list(response, WorkspaceDocumentPage.from_dict),
        )

    def persist(self, instance: WorkspaceDocumentPage, update: bool=False) -> WorkspaceDocumentPage:
        logger.info("[shared.workspace_document_page.persisting]", data=instance.to_persist_dict)
        if update:
            return self._update(instance)
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/workspace-documents/{instance.workspace_document_id}/pages/",
            json=instance.to_persist_dict,
        )
        if not self._is_success(response):
            logger.error("[shared.workspace_document_page.persist_error]", response=response.text)
            return instance
        return self._parse_instance(response, WorkspaceDocumentPage.from_dict)

    def _update(self, instance: WorkspaceDocumentPage):
        logger.info("[shared.workspace_document_page.updating]", data=instance.to_update_dict)
        response: Response = self.session.put(
            url=f"{self.api_url}/v1/workspace-document-pages/{instance.uuid}/",
            json=instance.to_update_dict,
        )
        if not self._is_success(response):
            logger.error("[shared.workspace_document_page.updating_error]", response=response.text)
            return instance
        return self._parse_instance(response, WorkspaceDocumentPage.from_dict)

    def delete(self, instance_id: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspace-document-pages/{instance_id}/")

    def delete_by_document(self, workspace_document_id: UUID) -> None:
        self.session.delete(
            f"{self.api_url}/v1/workspace-documents/{workspace_document_id}/pages/"
        )
