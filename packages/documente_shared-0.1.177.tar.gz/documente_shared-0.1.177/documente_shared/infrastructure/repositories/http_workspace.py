from uuid import UUID
from dataclasses import dataclass

import structlog
from requests import Response

from documente_shared.domain.entities.workspace import Workspace
from documente_shared.domain.filters.workspace import WorkspaceFilters
from documente_shared.domain.pagination.entities import Page, PageCursor
from documente_shared.domain.repositories.workspace import WorkspaceRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin

logger = structlog.get_logger()


@dataclass
class HttpWorkspaceRepository(
    DocumenteClientMixin,
    WorkspaceRepository,
):
    def find(self, instance_id: UUID) -> Workspace | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{instance_id}/",
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, Workspace.from_dict)

    def filter(self, filters: WorkspaceFilters) -> list[Workspace]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, Workspace.from_dict)

    def filter_paginated(self, filters: WorkspaceFilters) -> Page[Workspace]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return Page.empty()

        return Page(
            limit=filters.limit,
            next_cursor=PageCursor.initial(),
            prev_cursor=PageCursor.initial(),
            items=self._parse_list(response, Workspace.from_dict),
        )

    def persist(self, instance: Workspace) -> Workspace:
        logger.info("[shared.workspace.persisting]", data=instance.to_persist_dict)
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/workspaces/",
            json=instance.to_persist_dict,
        )
        if not self._is_success(response):
            logger.error("[shared.workspace.persist_error]", response=response.text)
            return instance
        return self._parse_instance(response, Workspace.from_dict)

    def delete(self, instance_id: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspaces/{instance_id}/")
