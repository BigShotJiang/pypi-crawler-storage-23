from dataclasses import dataclass

import structlog

logger = structlog.get_logger()
from requests import Response

from documente_shared.application.payloads import camel_to_snake
from documente_shared.domain.entities.processing_record import ProcessingRecord
from documente_shared.domain.repositories.processing_record import ProcessingRecordRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin


@dataclass
class HttpProcessingRecordRepository(
    DocumenteClientMixin,
    ProcessingRecordRepository,
):
    def persist(self, instance: ProcessingRecord) -> ProcessingRecord:
        logger.info("[shared.processing_record.persisting]", data=instance.to_payload)
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/processing/records/",
            json=instance.to_payload,
        )
        if response.status_code not in [200, 201]:
            logger.warning("[shared.processing_record.persist_error]", status_code=response.status_code, response=response.text)
            return instance
        return self._build_processing_record(response)

    @classmethod
    def _build_processing_record(cls, response: Response) -> ProcessingRecord:
        response_json = response.json()
        instance_data = response_json.get("data", response_json)
        return ProcessingRecord.from_dict(camel_to_snake(instance_data))
