from dataclasses import dataclass
from uuid import UUID

import structlog
from requests import Response

from documente_shared.domain.entities.workspace_document import WorkspaceDocument
from documente_shared.domain.filters.workspace_document import WorkspaceDocumentFilters
from documente_shared.domain.pagination.entities import Page, PageCursor
from documente_shared.domain.repositories.workspace_document import WorkspaceDocumentRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin

logger = structlog.get_logger()


@dataclass
class HttpWorkspaceDocumentRepository(
    DocumenteClientMixin,
    WorkspaceDocumentRepository,
):
    def find(self, instance_id: UUID) -> WorkspaceDocument | None:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{instance_id}/",
        )
        if not self._is_success(response):
            return None
        return self._parse_instance(response, WorkspaceDocument.from_dict)

    def filter(
        self,
        filters: WorkspaceDocumentFilters,
    ) -> list[WorkspaceDocument]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{filters.workspace_id}/documents/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return []
        return self._parse_list(response, WorkspaceDocument.from_dict)

    def filter_paginated(
        self,
        filters: WorkspaceDocumentFilters,
    ) -> Page[WorkspaceDocument]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{filters.workspace_id}/documents/",
            params=filters.to_params,
        )
        if not self._is_success(response):
            return Page.empty()

        return Page(
            limit=filters.limit,
            next_cursor=PageCursor.initial(),
            prev_cursor=PageCursor.initial(),
            items=self._parse_list(response, WorkspaceDocument.from_dict),
        )

    def persist(self, instance: WorkspaceDocument) -> WorkspaceDocument:
        logger.info("[shared.workspace_document.persisting]", data=instance.to_persist_dict)
        existing = self.find(instance.uuid)
        if existing:
            response: Response = self.session.put(
                url=f"{self.api_url}/v1/workspace-documents/{instance.uuid}/",
                json=instance.to_persist_dict,
            )
        else:
            response: Response = self.session.post(
                url=f"{self.api_url}/v1/workspaces/{instance.workspace_id}/documents/",
                json=instance.to_persist_dict,
            )
        if not self._is_success(response):
            logger.error("[shared.workspace_document.persist_error]", response=response.text)
            return instance
        return self._parse_instance(response, WorkspaceDocument.from_dict)

    def delete(self, instance_id: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspace-documents/{instance_id}/")
