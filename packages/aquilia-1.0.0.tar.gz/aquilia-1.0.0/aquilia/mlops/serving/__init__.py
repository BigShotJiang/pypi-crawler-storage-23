"""Model serving layer."""
