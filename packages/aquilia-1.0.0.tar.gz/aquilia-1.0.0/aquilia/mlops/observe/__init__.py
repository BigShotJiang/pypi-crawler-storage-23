"""Observability: metrics, drift detection, logging."""
