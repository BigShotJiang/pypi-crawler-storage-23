"""Explainability and privacy hooks."""
