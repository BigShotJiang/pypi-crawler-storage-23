"""Optimization pipeline: quantize, prune, export."""
