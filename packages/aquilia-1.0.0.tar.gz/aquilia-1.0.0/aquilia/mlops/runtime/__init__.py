"""Runtime adapters for model inference."""
