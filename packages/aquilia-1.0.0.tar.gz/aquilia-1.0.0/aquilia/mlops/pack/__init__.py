"""Modelpack builder and content store."""
