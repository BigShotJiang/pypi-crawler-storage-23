"""Registry service and storage adapters."""
