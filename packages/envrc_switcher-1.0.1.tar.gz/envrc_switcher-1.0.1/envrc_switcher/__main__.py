from envrc_switcher.cli import main

main()
