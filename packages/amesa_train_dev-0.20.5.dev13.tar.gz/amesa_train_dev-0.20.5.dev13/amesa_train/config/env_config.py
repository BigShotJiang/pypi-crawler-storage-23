# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Optional

from pydantic import BaseModel

from amesa_core.networking.sim.client_config import ClientConfig


# Create a BaseModel implemention that is a Union of an any dict with ClientConfigBase
class EnvConfigBase(BaseModel):
    amesa: ClientConfig = None
    render: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True


class EnvConfig(EnvConfigBase):
    def __init__(self, config={}):
        super().__init__(**config)
