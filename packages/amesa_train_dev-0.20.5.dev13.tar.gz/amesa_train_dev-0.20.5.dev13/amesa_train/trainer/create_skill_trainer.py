# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Union

from amesa_core import Agent, Skill, SkillCoordinatedSet, SkillSelector, SkillCoordinatedPopulation
from amesa_core.config.trainer_config import TrainerConfig
from ray.rllib.algorithms.algorithm import Algorithm

from .skill_trainer import SkillTrainer
from .skill_trainer_coordinated_set import SkillTrainerCoordinatedSet
from .skill_trainer_coordinated_population import SkillTrainerCoordinatedPopulation


def create_skill_trainer(agent: Agent,
                         skill: Union[Skill, SkillSelector, SkillCoordinatedSet, SkillCoordinatedPopulation],
                         config: TrainerConfig
                         ) -> Algorithm:
    if isinstance(skill, SkillCoordinatedSet):
        return SkillTrainerCoordinatedSet(agent, skill, config)
    elif isinstance(skill, SkillCoordinatedPopulation):
        return SkillTrainerCoordinatedPopulation(agent, skill, config)
    elif isinstance(skill, SkillSelector) or isinstance(skill, Skill):
        return SkillTrainer(agent, skill, config)
    else:
        raise Exception(
            f"Could not create an algorithm structure, skill type: '{type(skill)}' is not supported for training."
        )