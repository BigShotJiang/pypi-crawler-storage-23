# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import time
from abc import abstractmethod
from typing import List, Optional, Tuple, Union

import amesa_core.utils.logger as logger_util
import numpy as np
from amesa_core import (
    Agent,
    Skill,
    SkillCoordinatedPopulation,
    SkillCoordinatedSet,
    SkillSelector,
)
from amesa_core.agent.sensors.sensor import NormalizeSensor, Sensor
from amesa_core.config.skill_config import (
    SkillCoordinatedOptions,
    SkillDRLOptions,
    SkillSelectorOptions,
)
from amesa_core.config.trainer_config import (
    LearningConfig,
    ResourcesConfig,
    TrainerConfig,
)
from amesa_core.singletons.telemetry_historian import telemetry_historian
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.utils.from_config import NotProvided
from scipy.stats import ttest_1samp

logger = logger_util.get_logger(__name__)

VERY_NEGATIVE_REWARD = -1000

MAX_RETRIES = 3


def process_not_provided_values(cfg):
    """
    Process the config and replace Nones with ray's "NotProvided"
    Args:
        config (dict): the config
    Returns:
        dict: the processed config
    """
    # list_not_provfided = ["train_batch_size", "replay_buffer_size", "grad_clip", "grad_clip_by", "train_batch_size_per_learner", "learning_rate", "gamma", "num_gpus", "num_gpus_per_learner_worker", "num_gpus_per_worker", "num_cpus_per_worker", "learner_cpus", "learner_workers"]
    list_not_provided = [
        "train_batch_size",
        "replay_buffer_size",
        "grad_clip",
        "grad_clip_by",
        "train_batch_size_per_learner",
        "learning_rate",
        "gamma",
    ]

    # If key in list of not provided, and is none, then we set it to not provided in the learning_config
    for key in list_not_provided:
        if hasattr(cfg, key) and getattr(cfg, key) is None:
            setattr(cfg, key, NotProvided)

    return cfg


def average_normalization(sensors: List[Sensor]) -> NormalizeSensor:
    """
    A utility function to average the normalization parameters of sensors across workers.
    This is useful when you have multiple sensors that need to be normalized together.
    It will return a single normalizer that can be used for all sensors.

    Args:
        sensors (List[Sensor]): A list of sensors to average.

    Returns:
        NormalizeSensor: A single normalizer with averaged normalization parameters.
    """
    value_dict = {
        "mean": [],
        "var": [],
        "epsilon": []
    }

    for sensor in sensors:
        if sensor.normalizer is None:
            raise ValueError(f"Sensor '{sensor.name}' does not have a normalizer set.")
        value_dict["mean"].append(sensor.normalizer.obs_rms.mean)
        value_dict["var"].append(sensor.normalizer.obs_rms.var)
        value_dict["epsilon"].append(sensor.normalizer.obs_rms.epsilon)

    # Calculate the average mean, variance, and epsilon
    mean = np.mean(value_dict["mean"], axis=0)
    var = np.mean(value_dict["var"], axis=0)
    epsilon = np.mean(value_dict["epsilon"])

    average_sensor = sensors[0]  # Use the first sensor as a template for the new sensor
    average_sensor.normalizer.obs_rms.mean = mean
    average_sensor.normalizer.obs_rms.var = var
    average_sensor.normalizer.obs_rms.epsilon = epsilon

    return average_sensor


def average_sensor_normalization(list_workers_sensors: List[Union[Sensor, List[Sensor]]]) -> List[Sensor]:
    """
    A utility function to average the normalization of sensors.
    This is useful when you have multiple sensors that need to be normalized together.
    It will return a list of sensors with the same normalization parameters.

    Args:
        sensors (List[Union[Sensor, List[Sensor]]]): A list of sensors or lists of sensors to average.

    Returns:
        List[Sensor]: A list of sensors with averaged normalization parameters.
    """
    # create batches of sensors by index of sensors
    batch = {}
    for workers_sensors in list_workers_sensors:
        if isinstance(workers_sensors, Sensor):
            worker_sensors = [workers_sensors]

        for worker_sensors in workers_sensors:
            for sensor in worker_sensors:
                if sensor.name not in batch:
                    batch[sensor.name] = []
                batch[sensor.name].append(sensor)

    averaged_sensors = {}
    for sensor_name, sensors in batch.items():
        if not sensors[0].should_normalize():
            # If no normalizer is set, we can just return the sensors as they are
            averaged_sensors[sensor_name] = sensors[0]
            continue
        averaged_sensors[sensor_name] = average_normalization(sensors)

    return list(averaged_sensors.values())


class SkillTrainerBase:
    """
    The base skill trainer takes care of training a skill type.
    """

    agent: Agent
    skill: Skill
    config: TrainerConfig
    train_step_running: bool
    is_running: bool
    stop_signal: bool
    algo: Optional[Algorithm]

    """
    The base skill trainer takes care of training a skill type.

    Args:
        agent (Agent): the agent
        skill (Skill): the skill
        config (TrainerConfig): the trainer config
    """

    def __init__(
        self,
        agent: Agent,
        skill: Skill,
        config: TrainerConfig
    ) -> None:
        self.skill: Union[Skill, SkillCoordinatedSet, SkillSelector] = skill
        self.agent: Agent = agent
        self.config: Union[SkillCoordinatedOptions, SkillDRLOptions, SkillSelectorOptions] = self.skill.skill_config.model_copy(deep=True)
        self.train_step_running = False
        self.trainer_config = config
        self.is_running = False
        self.stop_signal = False
        self.algo: Algorithm = None
        self.episode_reward_means = []
        if self.trainer_config is None:
            self.trainer_config = TrainerConfig()
        self.trainer_config.env.init.update(
            self.skill.get_env_init()
        )

    def curriculum_fn_callback(self, train_results, task_settable_env, env_ctx):
        """
        Take the last train results, base aenv and env and return a new task to set the env to
        Here we check the current scenario, and if the scenario is successful, we move to the next scenario
        """
        logger.debug(
            f"Checking if we move to the next scenario? (success rate: {task_settable_env.get_success_rate()})"
        )

        if task_settable_env.get_success_rate() > 100:
            task_settable_env.env_config_amesa.skill.move_to_next_scenario()
            task_settable_env.reset_success_rate()

        return task_settable_env.env_config_amesa.skill.get_current_scenario()

    def policy_map_fn(self, agent_id, episode, **kwargs):
        return agent_id

    def _print_reward_skill(
        self,
        train_results,
        skill_type: str,
        skill_name: str,
        cycle_total: int,
        cycle_curr: int,
        time_taken: float,
    ) -> Tuple[float, float, float, int, float]:
        pass

    def _print_reward(
        self,
        train_results,
        skill_type: str,
        skill_name: str,
        cycle_total: int,
        cycle_curr: int,
        time_taken: float,
    ) -> None:
        """
        Print the reward

        Args:
            train_results: the training results
            skill_type (str): the skill type
            skill_name (str): the skill name
            cycle_total (int): the total number of cycles
            cycle_curr (int): the current cycle
        """
        time_taken = round(time_taken, 3)

        self._print_reward_skill(
            train_results,
            skill_type,
            skill_name,
            cycle_total,
            cycle_curr,
            time_taken,
        )

    def train_step(
        self,
        algo: Algorithm,
        skill_type: str,
        skill_name: str,
        cycle_total: int,
        cycle_curr: int,
    ) -> dict:
        """
        Perform a training step

        Args:
            algo (Algorithm): the algorithm to use
            skill_type (str): the skill type
            skill_name (str): the skill name
            cycle_total (int): the total number of cycles
            cycle_curr (int): the current cycle

        Returns:
            dict: the training results
        """
        if self.stop_signal:
            return {}

        self.train_step_running = True
        t0 = time.time()

        _result = None

        for retry_counter in range(MAX_RETRIES):
            try:
                _result = algo.train()
                break
            except Exception as e:
                logger.warning(
                    f"[{type(self.skill).__name__}][{self.skill.get_name()}] An error occured while training: {e} - retry counter {retry_counter} / {MAX_RETRIES}"
                )

                # If the sample is too slow and we are in auto mode, let the user configure it
                if "No samples returned from remote workers" in str(
                    e
                ) or "No state found in" in str(e):
                    new_sample_timeout = round(
                        self.skill.skill_config.resources.sample_timeout_s * 1.1, 3
                    )  # Increase by 10% each time
                    logger.warning(
                        f"[{type(self.skill).__name__}][{self.skill.get_name()}] Cannot get sim samples quickly enough (rollout_fragment_length={self.skill.skill_config.resources.sample_timeout_s}, sample_timeout_s={self.skill.skill_config.resources.sample_timeout_s}). Increasing the `trainer.sample_timeout_s`: {self.skill.skill_config.resources.sample_timeout_s} -> {new_sample_timeout}"
                    )
                    self.skill.skill_config.resources.sample_timeout_s = new_sample_timeout

                    # If it became too big, we raise an exception
                    if new_sample_timeout > self.skill.skill_config.resources.sample_timeout_s_max:
                        raise Exception(
                            f"[{type(self.skill).__name__}][{self.skill.get_name()}] Cannot get sim samples quickly enough (rollout_fragment_length={self.skill.skill_config.resources.sample_timeout_s}, sample_timeout_s={self.skill.skill_config.resources.sample_timeout_s}). Current sample timeout exceeds maximum specified value, either increase it through `trainer.sample_timeout_s` and `trainer.sample_timeout_s_max` or reduce the samples gathered through `trainer.rollout_fragment_length` and retry"
                        )
        else:
            logger.warning(
                f"[{type(self.skill).__name__}][{self.skill.get_name()}] Could not train after {MAX_RETRIES} retries"
            )
            return

        t1 = time.time()
        self.train_step_running = False

        if _result is None:
            raise Exception(
                f"[{type(self.skill).__name__}][{self.skill.get_name()}] Training result is None, something happened during training"
            )

        _result_to_sink = _result.copy()

        # Remove the env config from the result as it is not serializable
        _result_to_sink["config"]["env_config"] = None
        _result_to_sink["config"]["env_task_fn"] = None
        _result_to_sink["config"]["torch_compile_learner_what_to_compile"] = None
        _result_to_sink["config"]["sample_collector"] = None
        _result_to_sink["config"]["policy_mapping_fn"] = None
        _result_to_sink["config"]["callbacks"] = None

        # we need to get the env success rate and put it into the result
        # the success rate is found in the env, so we need to get the env from the algo
        success_rates = self.get_success_rate_from_algo(self.algo)
        _result_to_sink["env_success_rates"] = success_rates

        self._print_reward(
            _result_to_sink, skill_type, skill_name, cycle_total, cycle_curr, t1 - t0
        )
        return _result_to_sink

    @staticmethod
    def get_skill_from_env(env) -> Skill:
        """
        Get a skill from the environment

        Args:
            env: the environment

        Returns:
            Skill: the skill from the environment
        """
        return env.env_config_amesa.skill

    def get_env_success_rate_from_env(self, env) -> float:
        """
        Get the success rate from the environment
        """
        return env.get_success_rate()

    @staticmethod
    def get_sensors_from_env(env) -> List[Sensor]:
        """
        Get all the sensors from the environment

        Args:
            env: the environment

        Returns:
            List[Sensor]: the sensors from the environment
        """
        return env.agent.get_sensors()

    def get_success_rate_from_env(self, env) -> float:
        """
        Get the success rate from the environment
        """
        return env.get_success_rate()


    @staticmethod
    def get_success_rate_from_worker(worker):
        # Access env through the worker
        env = worker.env
        if hasattr(env, 'get_success_rate'):
            return env.get_success_rate()
        return 0.0

    def get_success_rate_from_algo(self, algo: Algorithm) -> List[float]:
        """
        Get success rates from all workers.

        Args:
            algo (Algorithm): the algorithm to get the success rates from

        Returns:
            List[float]: the success rates from all workers
        """

        success_rates = algo.workers.foreach_worker(
            self.get_success_rate_from_worker,
            local_worker=False
        )

        return success_rates

    @staticmethod
    def get_skill_from_worker(worker):
        # Access env through the worker
        env = worker.env
        if hasattr(env, 'env_config_amesa'):
            return env.env_config_amesa.skill
        return None

    def get_skill_from_workers(self, algo: Algorithm) -> Skill:
        """
        Get a skill from the workers

        Args:
            algo (Algorithm): the algorithm to get the skill from

        Returns:
            Skill: the skill from the workers
        """

        results = algo.workers.foreach_worker(
            self.get_skill_from_worker,
            local_worker=True
        )

        # results are from local and remote workers, filter out None results
        for result in results:
            if result is not None:
                return result

        return None


    @staticmethod
    def get_sensors_from_worker(worker):
        # Access env through the worker
        env = worker.env
        if hasattr(env, 'agent'):
            return env.agent.get_sensors()
        return []

    def get_sensors_from_workers(self, algo: Algorithm) -> List[Sensor]:
        """
        Get all the sensors from the workers

        Args:
            algo (Algorithm): the algorithm to get the sensors from

        Returns:
            List[Sensor]: the sensors from the workers
        """

        results = algo.workers.foreach_worker(
            self.get_sensors_from_worker,
            local_worker=True
        )

        return results[0] if results else []

    def stop(self) -> None:
        """
        Mark the trainer as stopped
        """
        self.stop_signal = True

    def update_from_algo(self) -> None:
        """
        During training, some attributes of the skill will have been updated, like the sensor space
        this method copies the skill from the workers and we update the skill in our agent definition

        This is to ensure that:
        - We can export the skill for inference
        - We can inform controllers what the sim sensor space is before it's needed for training

        We do this before training to ensure that when training is interrupted, we can still export the skill

        To perform this, we:
        1. Fetch the skill from the env runner (= worker)
        2. Update the local skill with the new sensor space (= skill attributes)

        Args:
            skill (Skill): the skill to update
        """
        """
        Update the skill from the workers

        Args:
            skill (Skill): the skill to update
        """
        # TODO: if skill is actually a coordinated skill List<skill>, then we need to update all of them
        rollout_skill = self.get_skill_from_workers(self.algo)
        self.skill.update(rollout_skill)

    def process_reward_mean(self, mean: float) -> None:
        """
        Check if the mean reward is improving. If it is not, we warn the user

        Args:
            mean (float): the mean reward
        """
        self.episode_reward_means.append(mean)

        if mean <= VERY_NEGATIVE_REWARD:
            logger.warning(
                "Mean reward is very negative, consider a different reward function"
            )

        if len(self.episode_reward_means) > 20:
            # Null hypthosis: mean reward is not improving
            # Alternative hypothesis: mean reward is improving
            # If p-value is less than 0.05, then we reject the null hypothesis
            # and conclude that the mean reward is improving
            # We use a one-tailed test because we only care if the reward is improving
            # and not if it is getting worse
            prior_mean = np.mean(self.episode_reward_means[0:-10])
            t_stat, p_value = ttest_1samp(self.episode_reward_means[-1:-10], prior_mean)

            if p_value > 0.05:
                logger.warning(
                    "Mean reward is not improving, consider a different reward function"
                )

    @abstractmethod
    def init(self):
        """
        Initialize the skill trainer
        This method should be called before training starts to set up the trainer
        Returns:
            None
        """
        pass

    def train(self, training_cycles: Optional[int] = 1000) -> None:
        """
        Train the skill for a number of cycles

        Args:
            training_cycles (int): The number of training cycles to run

        Returns:
            None
        """
        training_cycles = (
            self.skill.skill_config.learning.training_cycles
            if self.skill.skill_config.learning.training_cycles is not None
            else training_cycles
        )

        self.algo: Algorithm = self.init()
        self.is_running = True

        # During training, some attributes of the skill will have been updated, like the sensor space
        # so make sure to copy the skill from the workers
        # Do this before the first training cycle instead of after the last one
        # In case training is interrupted, which allows us to skill export the skill
        self.update_from_algo()

        # Next, we need to do this for controllers, which don't get trained
        for skill_str in self.agent.skills:
            agent_skill = self.agent.get_node_by_name(skill_str)

            if agent_skill.is_controller():
                agent_skill.set_sim_sensor_space(self.skill.get_sim_sensor_space())

        for selector_skill_str in self.agent.skill_selectors:
            selector_skill = self.agent.get_node_by_name(selector_skill_str)

            if selector_skill.is_controller():
                selector_skill.set_sim_sensor_space(self.skill.get_sim_sensor_space())

        logger.info(
            f"[{self.skill.get_name()}] Training {type(self.skill).__name__} for {training_cycles} cycles..."
        )

        for i in range(training_cycles):
            if self.stop_signal:
                break

            _result_to_sink = self.train_step(
                self.algo,
                type(self.skill).__name__,
                self.skill.get_name(),
                training_cycles,
                i,
            )

            telemetry_historian.sink(
                category="agent",
                category_sub="skill-training-cycle",
                data={
                    "name": self.skill.get_name(),
                    "is_done": self.skill.is_done_training(),
                    "cycle": i,
                    "cycle_total": training_cycles,
                    "result": _result_to_sink,
                    "scenario_idx": self.skill.get_scenarios_current_idx(),
                },
            )

            if _result_to_sink is None:
                # if results are none, that means we were unable to do a training cycle
                # inform the user and abandon training
                logger.warning("Training cycle could not be completed, aborting training...")
                break

            if self.skill.is_done_training():
                logger.info(
                    f"[{type(self.skill).__name__}][{self.skill.get_name()}] has trained for {i + 1} cycles and has mastered every scenario!"
                )
                self.is_running = False
                break

        if not self.skill.is_done_training():
            logger.warning(
                f"[{type(self.skill).__name__}][{self.skill.get_name()}][WARNING] has trained for {training_cycles} cycles but has not mastered every scenario!"
            )
            self.skill.done_training = True

        if self.stop_signal:
            self.is_running = False
            logger.warning(
                f"[{type(self.skill).__name__}][{self.skill.get_name()}] training for '{self.skill.get_name()}' was stopped"
            )
            self.export()

        self.is_running = False
        self.export()

    @abstractmethod
    def export(self) -> None:
        """
        Export the trainer
        Used for resume training, inference, and generating onnx models for deployment runtime

        Returns:
            None
        """
        pass

    def export_algo(self) -> None:
        """
        Export ray Algorithm
        This creates a checkpoint of the skill's training
        To enable resume training or local inference
        """
        if self.algo is None:
            return

        if not isinstance(self.skill, SkillCoordinatedSet) or not isinstance(self.skill, SkillCoordinatedPopulation):
            if self.skill.get_name() not in self.skill.get_checkpoint_uri():
                self.skill.set_checkpoint_uri(
                    f"{self.skill.get_checkpoint_uri()}/{self.skill.get_name()}"
                )
            else:
                # this is probably a resume training re-save. Nothing to do
                pass

        # next, update all the 's with this new sim sensor space
        ckpt_train_result = self.algo.save(
            checkpoint_dir=f"{self.skill.get_checkpoint_uri()}"
        )

        # get the policy from the skill
        ckpt_path = ckpt_train_result.checkpoint.path

        logger.info(
            f"Saving skill '{self.skill.get_name()}' checkpoint to '{ckpt_path}'"
        )

    @abstractmethod
    def export_to_onnx(self) -> None:
        """
        Export the skill's policy to onnx

        Returns:
            None
        """
        pass

    def process_not_provided_values(self, cfg: Union[LearningConfig, ResourcesConfig]) -> Union[LearningConfig, ResourcesConfig]:
        """
        Process the config and replace Nones with ray's "NotProvided"

        Args:
            config (dict): the config

        Returns:
            dict: the processed config
        """
        list_not_provided = ["train_batch_size", "replay_buffer_size", "grad_clip", "grad_clip_by", "learning_rate", "gamma"]

        # If key in list of not provided, and is none, then we set it to not provided in the learning_config
        for key in list_not_provided:
            if hasattr(cfg, key) and getattr(cfg, key) is None:
                setattr(cfg, key, NotProvided)

        return cfg
