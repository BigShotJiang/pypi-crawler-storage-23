# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Dict, List, Optional, Union

import gymnasium as gym

from ray.rllib.algorithms.callbacks import DefaultCallbacks
from ray.rllib.utils.annotations import override
from ray.rllib.utils.typing import EpisodeType
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.env.env_runner import EnvRunner
from ray.rllib.policy.sample_batch import SampleBatch
from ray.rllib.env.base_env import BaseEnv
from ray.rllib.evaluation.episode import Episode
from ray.rllib.evaluation.episode_v2 import EpisodeV2
from ray.rllib.core.rl_module.rl_module import RLModule

from amesa_core import SkillCoordinatedPopulation, SkillCoordinatedSet
from amesa_core.singletons.telemetry_historian import telemetry_historian
import amesa_core.utils.logger as logger_util

from amesa_train.actor.metrics_actor import MetricsActor

logger = logger_util.get_logger(__name__)


class AmesaCallbacks(DefaultCallbacks):
    def __init__(self):
        super().__init__()

        self.metrics_actor = MetricsActor.get_or_create()

    """
    ************************* Lessons train different scenarios and agents. *************************
     DOCS: https://docs.ray.io/en/latest/_modules/ray/rllib/algorithms/callbacks.html
    """
    @override(DefaultCallbacks)
    def on_algorithm_init(self, *, algorithm: Algorithm, **kwargs) -> None:
        skill = algorithm.config.env_config.get("composabl", {}).get("skill", None)
        if isinstance(skill, SkillCoordinatedPopulation) or isinstance(skill, SkillCoordinatedSet):
            num_models_to_train = len(skill.get_skill_names())
        else:
            num_models_to_train = 1
        self.metrics_actor.reset.remote()
        self.metrics_actor.set_steps_to_collect.remote(
            algorithm.config.total_train_batch_size * num_models_to_train
        )

    @override(DefaultCallbacks)
    def on_episode_end(
        self,
        *,
        episode: Union[EpisodeType, Episode, EpisodeV2],
        worker: Optional[EnvRunner] = None,
        env_runner: Optional[EnvRunner] = None,
        base_env: Optional[BaseEnv] = None,
        env: Optional[gym.Env] = None,
        policies=None,
        rl_module: Optional[RLModule] = None,
        env_index: int,
        **kwargs,
    ) -> None:
        """
        Each env runner steps through environments. At each episode end, we add the steps collected
        """
        self.metrics_actor.add_steps_collected.remote(episode.total_agent_steps)

    @override(DefaultCallbacks)
    def on_sample_end(
        self,
        *,
        env_runner: Optional[EnvRunner] = None,
        samples: Union[SampleBatch, List[EpisodeType]],
        # TODO (sven): Replace with `env_runner` arg.
        worker: Optional[EnvRunner] = None,
        **kwargs,
    ) -> None:
        pass

    @override(DefaultCallbacks)
    def on_evaluate_end(
        self,
        *,
        algorithm: Algorithm,
        evaluation_metrics: dict,
        **kwargs,
    ) -> None:
        telemetry_historian.sink(
            category="training_result",
            category_sub="evaluation_metrics",
            data={
                "result": evaluation_metrics,
            },
        )

    @override(DefaultCallbacks)
    def on_train_result(
        self,
        *,
        algorithm: Algorithm,
        result: dict,
        **kwargs,
    ) -> None:
        telemetry_historian.sink(
            category="training_result",
            category_sub="training_result",
            data={
                "result": result,
            },
        )
        # reset the time for steps collected after train results,
        # as we want to measure the time for the next steps collected
        # not after the sample end, as this is not the same
        self.metrics_actor.reset.remote("steps_collected")
