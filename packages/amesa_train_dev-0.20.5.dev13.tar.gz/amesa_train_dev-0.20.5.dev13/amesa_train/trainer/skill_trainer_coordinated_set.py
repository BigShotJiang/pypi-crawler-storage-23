# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import List, Tuple
from typing_extensions import override

import os

import amesa_core.utils.logger as logger_util
from amesa_core.agent import SkillCoordinatedSet, Skill
from amesa_core.agent.agent import Agent
from amesa_core.config.trainer_config import TrainerConfig
from amesa_core.settings import settings
from amesa_core.utils import async_util
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.core.rl_module.rl_module import SingleAgentRLModuleSpec
from ray.rllib.core.rl_module.marl_module import MultiAgentRLModuleSpec
from ray.rllib.policy.policy import PolicySpec

from amesa_train.model.skill_model import TorchActionMask
from amesa_train.trainer.skill_trainer_base import SkillTrainerBase
from amesa_train.trainer.training_callbacks import AmesaCallbacks
from amesa_train.utils.onnx_helper import export_policy_and_skill_to_onnx

from .algorithm_config import AmesaPPOConfig

logger = logger_util.get_logger(__name__)


class SkillTrainerCoordinatedSet(SkillTrainerBase):
    def __init__(self, agent: Agent, skill: SkillCoordinatedSet, config: TrainerConfig):
        super().__init__(agent, skill, config)

    def init(self) -> Algorithm:
        from amesa_train.trainer.skill_trainer_base import (
            process_not_provided_values,
        )

        policies_dict = {}
        policy_module_specs = {}

        self.config.resources = process_not_provided_values(
            self.skill.skill_config.resources.model_copy(deep=True)
        )
        self.config.learning = process_not_provided_values(
            self.skill.skill_config.learning.model_copy(deep=True)
        )

        for skill in self.skill.get_skills():
            policies_dict[skill.get_name()] = PolicySpec()
            policy_module_specs[skill.get_name()] = SingleAgentRLModuleSpec(
                module_class=TorchActionMask,
                model_config_dict={
                    "fcnet_hiddens": skill.skill_config.model.fc_layers,
                    "_disable_preprocessor_api": True,
                },
            )

        policies_to_train = list(policies_dict.keys())

        num_learners = self.config.resources.learner_workers
        if num_learners is None or num_learners <= 0:
            num_learners = self.config.resources.workers

        # create the algo structure
        algo = (
            AmesaPPOConfig()
            .rollouts(
                num_rollout_workers=self.config.resources.workers,
                num_envs_per_worker=self.config.resources.envs_per_worker,
                remote_worker_envs=self.config.resources.remote_worker_envs,
                sample_timeout_s=self.config.resources.sample_timeout_s * len(policies_to_train),
                rollout_fragment_length=self.config.resources.rollout_fragment_length or "auto"
            )
            .experimental(
                _disable_preprocessor_api=True,
                _enable_new_api_stack=True,
            )
            .resources(
                num_learner_workers=self.config.resources.learner_workers,
                num_gpus=self.config.resources.num_cpus_per_worker,
                num_gpus_per_learner_worker=self.config.resources.num_gpus_per_learner_worker,
                num_gpus_per_worker=self.config.resources.num_gpus_per_worker,
                num_cpus_per_worker=self.config.resources.num_cpus_per_worker,
                num_cpus_per_learner_worker=self.config.resources.num_cpus_per_learner_worker,
            )
            .training(
                train_batch_size_per_learner=int(self.config.learning.train_batch_size / num_learners),
                gamma=self.config.learning.gamma,
                grad_clip=self.config.learning.grad_clip,
                grad_clip_by=self.config.learning.grad_clip_by,
                model={
                    "_disable_preprocessor_api": True,
                    "fcnet_hiddens": self.config.model.fc_layers
                },
            )
            .multi_agent(
                policies=policies_dict,
                policies_to_train=policies_to_train,
                policy_mapping_fn=self.policy_map_fn,
            )
            .rl_module(
                rl_module_spec=MultiAgentRLModuleSpec(module_specs=SingleAgentRLModuleSpec(
                    module_class=TorchActionMask,
                    model_config_dict={
                        "fcnet_hiddens": self.config.model.fc_layers,
                        "_disable_preprocessor_api": True
                    }))
            )
            .environment(
                env="composabl",
                env_config={
                    "composabl": {
                        "skill": self.skill,
                        "id": self.trainer_config.env.name,
                        "agent": self.agent,
                        # Configure the historian on the rollout worker
                        "historian_moniker": settings.AMESA_HISTORIAN_MONIKER,
                        "historian_topic": settings.AMESA_HISTORIAN_TOPIC,
                        "trainer": self.trainer_config,  # the entire trainer config is passed down
                    },
                },
                env_task_fn=self.curriculum_fn_callback,
            )
            .framework("torch")
            .callbacks(AmesaCallbacks)
            .build()
        )

        if self.skill.get_checkpoint_uri():
            if os.path.exists(self.skill.get_checkpoint_uri()):
                logger.info(
                    f"Checkpoint exists {self.skill.get_checkpoint_uri()}"
                )
                try:
                    logger.info(
                        f"[{type(self.skill).__name__}][{self.skill.get_name()}] Found checkpoint, continuing training..."
                    )
                    algo.restore(self.skill.get_checkpoint_uri())
                except Exception:
                    logger.warning(
                        f"[{type(self.skill).__name__}][{self.skill.get_name()}] Could not restore checkpoint. Starting from scratch."
                    )
            else:
                logger.warning(
                    f"[{type(self.skill).__name__}][{self.skill.get_name()}] Skill checkpoint exists, but directory does not exist. Starting from scratch."
                )

        return algo

    def _print_reward_skill(
        self,
        train_results,
        skill_type: str,
        skill_name: str,
        cycle_total: int,
        cycle_curr: int,
        time_taken: float,
    ) -> Tuple[float, float, float, int, float]:

        default = [None] * len(self.skill.get_skill_names())
        episode_len_mean = train_results.get("episode_len_mean", default)
        episode_count = train_results.get("episodes_this_iter", default)
        policy_reward_min = train_results.get("policy_reward_min", default)
        policy_reward_max = train_results.get("policy_reward_max", default)
        policy_reward_mean = train_results.get("policy_reward_mean", default)

        for (skill_name, mean_reward, max_reward, min_reward) in zip(self.skill.get_skill_names(), policy_reward_mean.values(), policy_reward_max.values(), policy_reward_min.values()):
            # Make a json string of { mean, max, min, count }
            logger.info(
                "[%s][%s] Training (%d/%d): Δt: %ss | Reward Mean: %s | Max: %s | Min: %s | Episode Count: %s | Length Mean: %s"
                % (
                    skill_type,
                    skill_name,
                    cycle_curr + 1,
                    cycle_total,
                    time_taken,
                    mean_reward,
                    max_reward,
                    min_reward,
                    episode_count,
                    episode_len_mean,
                ),
            )

    @override
    def export(self):
        super().export_algo()

    @override
    def export_to_onnx(self) -> None:
        child_skills: List[Skill] = self.skill.get_skills()
        for child_skill in child_skills:
            policy = self.algo.get_policy(policy_id=child_skill.get_name())
            async_util.async_to_sync(export_policy_and_skill_to_onnx)(policy, child_skill, self.agent)

            # finally, move the onnx file into the sub-skill directory
            os.replace(child_skill.get_checkpoint_uri() + f"/{child_skill.get_name()}.onnx", child_skill.get_checkpoint_uri() + f"/policies/{child_skill.get_name()}/{child_skill.get_name()}.onnx")
