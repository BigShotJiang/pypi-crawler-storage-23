# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Union

import ray
from ray import ObjectRef
from ray.rllib.env.env_context import EnvContext
from ray.tune.registry import _unregister_all, register_env

from amesa_core.agent.skill.skill_coordinated import SkillCoordinatedSet, SkillCoordinatedPopulation
from amesa_core.networking.sim.client_config import ClientConfig
from amesa_core.networking.status_enum import SimStatus
import amesa_core.utils.logger as logger_util

from amesa_train.actor.sim_mgr_actor import NetworkMgrActor
from amesa_train.env.env import AmesaEnv
from amesa_train.env.env_multi_agent import AmesaEnvMultiAgent

logger = logger_util.get_logger(__name__)

"""
Ray uses an environment to communicate with the simulator.
We configure an environment that takes care of:
1. Creating a simulator
2. Creating a client interface to the simulator

We would think that the multi-agent is suboptimal as it spawns multiple
processes to interact with the simulator and we could spawn
those in the AmesaEnv directly, such that they sit next to the simulator
However, this is not the case as the AmesaEnv itself is a remote actor
"""


class EnvMgr:
    """
    The env manager manages the environment we train on. It takes care of:
    - Starting a simulator
    - Creating an environment that communicates with the simulator
    - Making sure the environment can communicate with the simulator
    """

    def __init__(self, run_id, actor_network_mgr: "ObjectRef[NetworkMgrActor]"):
        self.run_id = run_id
        self.network_mgr_actor = actor_network_mgr

        # Register AmesaEnv in the ray registry
        # we support both single and multi-agent environments
        # the sim_mgr will take care of the simulator starting
        # while the AmesaEnv will take care of the client interaction to the environment
        # _unregister_envs()  # Unregister all environments as it caches the the creator lambda else
        _unregister_all()
        register_env("composabl", self.create_env)

    def create_env(
        self, env_config: EnvContext, make_env_wrapper_func=None
    ) -> Union[AmesaEnv, AmesaEnvMultiAgent]:
        """
        Create a Sim environment that spins up its dedicated simulator
        container

        Note: we do NOT wait for the sim to be ready here as the env_mgr
              is spun up serially and awaits the create action to complete.
              The await ready is done in AmesaEnv itself

        By testing the approach, we see a startup time of:
        - 13.865s for 1 rollout worker (72 episodes/s)
        - 17.813s for 2 rollout workers (290 episodes/s)
        - 20.754s for 5 rollout workers (446 episodes/s)
        """
        env_client_config = ClientConfig.model_validate(env_config.get("composabl", {}))
        env_cls = (
            AmesaEnvMultiAgent
            if isinstance(env_client_config.skill, SkillCoordinatedSet) or isinstance(env_client_config.skill, SkillCoordinatedPopulation)
            else AmesaEnv
        )

        logger.debug(
            f"Creating Environment (type='{env_cls.__name__}', protocol='{env_client_config.trainer.target.protocol}', env_init='{env_client_config.trainer.env.init}')"
        )

        # Create a Sim ID
        self.sim_id = self.network_mgr_actor.call_sim_mgr.remote("create")

        # TODO: Figure out why this is sometimes a string and sometimes an ObjectRef
        if not isinstance(self.sim_id, str):
            self.sim_id = ray.get(self.sim_id)

        # Ensure sim_id is known and returned correctly from the SimMgr
        assert self.sim_id is not None

        # Create an environment that will communicate with the simulator
        env_client_config = ClientConfig.model_validate(env_config.get("composabl", {}))
        env = env_cls(self.run_id, self.network_mgr_actor, self.sim_id, env_client_config)
        if make_env_wrapper_func is not None:
            env = make_env_wrapper_func(env)

        # The environment is created and the client is "attached"
        self.network_mgr_actor.call_sim_mgr.remote(
            "sim_set_status", self.sim_id, SimStatus.SIM_CLIENT_CONNECTED
        )
        return env
