# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Dict, Tuple, Union

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util
from amesa_core.agent.skill.skill_teacher import SkillTeacher
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.singletons.telemetry_historian import telemetry_historian

import amesa_train.model.skill_model as skill_model
import amesa_core.utils.space_utils as space_utils
from amesa_train.utils.space_utils import make_tensor, make_np_array
from amesa_train.skill_processors.skill_processor_base import SkillProcessorBase
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class SkillProcessor(SkillProcessorBase):
    """
    The Skill Processor is responsible for:
    1. Ingesting the Sim OBS (apply the teacher methods)
    2. Getting the Action (if training, then ray queries the model, otherwise the skill processor queries the model)
    3. Transforming the action according to the teacher
    """

    teacher: SkillTeacher

    def __init__(self, context: SkillProcessorContext) -> None:
        """
        @param agent: The context of the Skill Processor.
        """
        super().__init__(context)

        self.sim_sensor_space = self.context.skill.get_sim_sensor_space()
        self.action_space: amesa_spaces.Space = (
            self.context.skill.get_action_space()
        )
        self.composabl_sensor_space: amesa_spaces.Dict = None
        if self.action_space is None:
            raise Exception(
                "Unable to make a DRL SkillProcessor without an action space. Please check to ensure the training order of the agent allows for this skill to be used at this point in time."
            )

        self.action_mask_space = self.action_space.get_action_mask_space()
        self.no_action_mask = self.action_space.get_no_action_mask()

        if not self.context.is_training and not self.context.is_validating:
            self.model: skill_model.TorchActionMask = (
                skill_model.create_model_from_skill(self.context.skill, is_coordinated_population=self.context.is_coordinated_population)
            )

        self.teacher = None
        self.perceptors = []
        # Make the teacher, which is the skill's implementation class
        self.filtered_composabl_sensor_space = None
        self.filter_keys = {}

        # Unused
        self.normalized_observation_processor = None

        # Is the ImplCls done?
        self.done = False

    async def init(self):
        """
        The initialize method is separate as it works in an async nature
        """
        await super().init()

        # Next, we need to get the composabl observation space
        # This is the space that the skill's teacher uses
        self.composabl_sensor_space = await space_utils.get_amesa_space_info(
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        self.filter_keys = await self.teacher.filtered_sensor_space()
        if self.filter_keys is None or len(self.filter_keys) == 0:
            self.filter_keys = [sensor.name for sensor in self.context.agent.sensors]

        # Filter the composabl observation space for the specific skill (we pass this to the Skill's NN)
        self.filtered_composabl_sensor_space = space_utils.filter_space(
            self.composabl_sensor_space, self.filter_keys
        )

        # Create the Gym Observation Space
        self.observation_space: Dict = {
            "observation": self.filtered_composabl_sensor_space.flatten()
        }

        self.action_mask_space = self.action_space.get_action_mask_space()
        self.observation_space["action_mask"] = self.action_mask_space

        self.observation_space = amesa_spaces.Dict(
            self.observation_space
        )  # it has to be a Dict from Gym Spaces

        # We are initialized
        self._is_initialized = True
        self.done = False

    async def process_sim_sensors(
        self, sensors, sim_action_mask=None, previous_action=None
    ) -> Union[Tuple[Dict, space_utils.TypeAmesaSpace], Dict]:
        """
        Process the incoming sim sensors data points and convert them to a dictionary based on their
        initial gymnasium space
        """
        # The incoming obs comes from the simulator, this can be in any of the Gymnasium Spaces and
        # can be different data types. We first need to convert this to a Dictionary of sensors.
        amesa_sensors = await space_utils.convert_sim_sensors_to_amesa_sensors(
            sensors,
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        # Let the teachers transform these observations as they expect certain inputs
        composabl_sensor_transformed = await self.teacher.transform_sensors(
            amesa_sensors, None
        )
        # Filter the composabl observation space for the specific skill (we pass this to the Skill's NN)
        filtered_composabl_sensor_space = space_utils.filter_sample(
            composabl_sensor_transformed, self.filter_keys
        )

        # normalized the filtered composabl sensor space
        if self.filtered_composabl_sensor_space is not None:
            for sensor in self.context.agent.sensors:
                if sensor.name in self.filter_keys:
                    filtered_composabl_sensor_space[sensor.name] = sensor.normalize_sample(
                        filtered_composabl_sensor_space[sensor.name]
                    )

        sensors_filtered = {}
        sensors_filtered["observation"] = filtered_composabl_sensor_space

        if sensors_filtered["observation"] is None:
            raise Exception(
                f"Sensor values is 'None' (original: {filtered_composabl_sensor_space}, filter space: {self.filtered_composabl_sensor_space}) for skill '{self.context.skill.get_name()}"
            )
        # the observation is a tuple of the observation and the skill group observations
        # the total observation is a dictionary of ^ and action mask
        action_mask = await self.compute_action_mask(
            composabl_sensor_transformed, sim_action_mask, previous_action
        )
        sensors_filtered["action_mask"] = action_mask

        # finally, let's flatten the obs and action mask for the model
        sensors_filtered[
            "observation"
        ] = self.filtered_composabl_sensor_space.flatten_sample(sensors_filtered["observation"])
        return sensors_filtered, composabl_sensor_transformed

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        # Todo: check if we need to unsquash the action
        if unsquash_action:
            unsquashed_action = space_utils.unsquash_action(action, self.action_space)
        else:
            unsquashed_action = action

        # Takes the filtered observation and action and returns the transformed action
        processed_action = await self.teacher.transform_action(
            amesa_obs, unsquashed_action
        )
        self.previous_action = processed_action

        if self.context.for_skill_group:
            return processed_action

        elif self.post_skill_group_skill_processor is not None:
            teacher_state = await self.post_skill_group_skill_processor._execute(
                sim_sensors,
                sim_action_mask,
                previous_action=processed_action,
                return_as_teacher_dict=True,
                skill_group_action={self.context.skill.get_name(): processed_action},
            )
            processed_action = teacher_state["action"]

        return processed_action

    async def reset(self):
        # Reset is called when an episode is done
        # So we need to reset the teacher

        if self.context.skill.is_remote():
            await self.teacher.reset()
        else:
            self.teacher = self.context.skill.get_impl_cls_instance()

        if len(self.perceptors) > 0:
            for perceptor in self.perceptors:
                try:
                    await perceptor.reset()
                except Exception as e:
                    pass

        self.done = False

    def is_done(self):
        return self.done

    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        """
        Execute the skill processor
        """
        teacher_dict = {}

        # FIRST, process the observation
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, sim_action_mask
        )

        # SECOND, compute the action
        # Never explore for discrete spaces
        if isinstance(self.action_space, amesa_spaces.Discrete) or isinstance(
            self.action_space, amesa_spaces.MultiDiscrete
        ):
            explore = False

        # or if there is a discrete and multidiscrete sub space in the action space
        if isinstance(self.action_space, amesa_spaces.Dict) or isinstance(
            self.action_space, amesa_spaces.Tuple
        ):
            if self.action_space.has_only_discrete_subspaces():
                explore = False

        (
            amesa_sensors_filtered,
            unfiltered_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        ) = await self.step(
            sim_sensors,
            0.0,
            False,
            False,
            {},
            previous_action,
        )

        obs = {
            "obs": {
                "observation": self.observation_space["observation"].expand_dims_of_batch(
                    make_tensor(sensors_filtered["observation"])
                ),
                "action_mask": self.observation_space["action_mask"].expand_dims_of_batch(
                    make_tensor(sensors_filtered["action_mask"])
                ),
            }
        }

        if self.context.is_validating:
            raw_action = self.context.skill.get_action_space().sample()

        elif isinstance(self.model, skill_model.TorchActionMask):
            if explore:
                raw_logits = self.model._forward_exploration(obs)
                distribution = self.model.get_exploration_action_dist_cls()
            else:
                raw_logits = self.model._forward_inference(obs)
                distribution = self.model.get_inference_action_dist_cls()

            if raw_logits is None:
                raise Exception(f"raw_action is None {sensors_filtered} {self.context.skill.get_name()}")

            # Distribution.from_logits requires a batch of logits
            action_dist = distribution.from_logits(
                (raw_logits["action_dist_inputs"])
            )

            # Make things deterministic
            action_dist = action_dist.to_deterministic()

            # Action dist.sample returns a batch of batches for some reason
            raw_action = action_dist.sample()

            # convert to numpy so we can use the composabl space helper methods
            raw_action = make_np_array(raw_action)

            # The action_dist is a batch of batches, we so have to remove the leading dimensions from the sample
            raw_action = self.action_space.unbatch_sample(raw_action)

            # THIRD, process the action
            # TODO: FIGURE OUT WHY THIS DOESN'T WORK FOR COORDINATED SKILLS
            if not is_coordinated:
                # batches can have weirdness with 1-d boxes
                try:
                    raw_action = self.action_space.unbatch_sample(raw_action)
                except Exception:
                    pass
        else:
            # PPOTorchRLModule
            raw_action = self.model.compute_single_action(sensors_filtered, explore=explore)[0]

            if raw_action is None:
                raise Exception(f"raw_action is None {sensors_filtered} {self.context.skill.get_name()}")

        # THIRD, process the action
        processed_action = await self.process_action(
            sim_sensors,
            unfiltered_obs,
            raw_action,
            sim_action_mask,
            unsquash_action=True,
        )

        self.done = teacher_terminated

        teacher_dict["state"] = unfiltered_obs
        teacher_dict["raw_action"] = raw_action
        teacher_dict["action"] = processed_action
        teacher_dict["reward"] = float(teacher_reward)
        teacher_dict["success"] = teacher_success
        teacher_dict["terminated"] = teacher_terminated

        if self.context.skill.has_coordinated_goal():
            reward, indivudal_rewards = await self.teacher.compute_reward(
                amesa_obs, processed_action, sim_reward=teacher_reward, return_individual=True
            )
            teacher_dict["coordinated_reward"] = indivudal_rewards
        # return the action
        if return_as_teacher_dict:
            return teacher_dict
        else:
            return processed_action

    async def step(
        self, sim_sensors, sim_reward, _sim_terminated, _truncated, info, action
    ):
        # Takes the sim observation, reward, and terminated and returns
        # The filtered obs, teacher reward, teacher success, and teacher terminated
        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step",
            data={"sim_sensors": sim_sensors},
        )

        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, info.get("action_mask", None), previous_action=action
        )

        teacher_reward = await self.teacher.compute_reward(
            amesa_obs, action, sim_reward
        )
        teacher_success = await self.teacher.compute_success_criteria(
            amesa_obs, action
        )
        teacher_terminated = await self.teacher.compute_termination(
            amesa_obs, action
        )
        truncated = teacher_success or teacher_terminated

        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step",
            data={
                "amesa_obs": amesa_obs,
                "sensors_filtered": sensors_filtered,
                "teacher_success": teacher_success,
                "teacher_reward": teacher_reward,
                "teacher_terminated": teacher_terminated,
                "truncated": truncated,
            },
        )

        return (
            sensors_filtered,
            amesa_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        )

    def get_name(self):
        return self.context.name

    def get_skill_name(self):
        return self.context.skill.get_name()

    def get_action_space(self):
        # even though the action space won't change, might as well grab from the original source
        return self.context.skill.get_action_space()

    async def compute_action_mask(
        self, amesa_obs, sim_action_mask, previous_action
    ):
        teacher_mask = await self.teacher.compute_action_mask(
            amesa_obs, previous_action
        )

        # if the skill has a custom action space, we can't use the sim action mask
        if self.context.skill.has_custom_action_space():
            # TOOD: Add a warning here
            # the sim doesn't know about the custom action space, so we can't use it
            sim_action_mask = self.no_action_mask
        if teacher_mask is None:
            teacher_mask = self.no_action_mask
        if sim_action_mask is None:
            sim_action_mask = self.no_action_mask

        total_mask = space_utils.combine_masks(teacher_mask, sim_action_mask)

        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step-mask",
            data={
                "teacher_mask": teacher_mask,
                "sim_action_mask": sim_action_mask,
                "combined_mask": total_mask,
            },
        )

        return total_mask

    def get_skill_sensor_space(self):
        return self.observation_space

    def get_composabl_sensor_space(self):
        return self.composabl_sensor_space

    def get_teacher(self):
        return self.teacher

    def get_skill(self):
        return self.context.skill
