# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
from abc import abstractmethod

from amesa_core.utils import plugin_util
import amesa_core.utils.logger as logger_util
from amesa_core import Agent

from amesa_core.networking import network_util
from amesa_core.networking.config.skill_processor_context import SkillProcessorContext

logger = logger_util.get_logger(__name__)


class SkillProcessorBase:
    agent: Agent

    def __init__(self, context: SkillProcessorContext):
        self.context = context
        self.teacher = None
        self.observation_space = None
        self.composabl_sensor_space = None
        self.perceptors = []

    @abstractmethod
    async def init(self):
        from amesa_train.skill_processors import make_skill_processor

        if self.context.skill.is_remote():
            # download the skill from the URL to check the composabl version
            # this is used to determine which remote client tag to use
            try:
                version = await plugin_util.get_amesa_version(self.context.skill.get_impl_cls())
            except Exception as _e:
                version = "latest"

            composabl_url = network_util.get_amesa_url(
                self.context.skill.get_impl_cls()
            )

            # use the network manager to create the remote client
            if self.context.skill.is_controller():
                # remote controller
                client_id, self.controller = await self.context.network_mgr.call_remote_controller_mgr.remote(
                    "create_with_client", env_init=composabl_url, version=version
                )
            else:
                # remote skill
                client_id, self.teacher = await self.context.network_mgr.call_remote_skill_mgr.remote(
                    "create_with_client", env_init=composabl_url, version=version
                )
        else:
            if self.context.skill.is_controller():
                # the controller is loaded in locally (SDK workflow)
                self.controller = self.context.skill.get_impl_cls_instance()
            else:
                # the teacher is loaded in locally (SDK workflow)
                self.teacher = self.context.skill.get_impl_cls_instance()

        if self.context.agent.perceptors is not None:
            for perceptor in self.context.agent.perceptors:
                if perceptor.is_remote():
                    composabl_url = network_util.get_amesa_url(
                        perceptor.get_impl_cls()
                    )
                    # download the perceptor from the URL
                    try:
                        version = await plugin_util.get_amesa_version(composabl_url)

                    except Exception as _e:
                        version = "latest"

                    # remote perceptor
                    client_id, remote_perceptor = await self.context.network_mgr.call_remote_perceptor_mgr.remote(
                        "create_with_client", env_init=composabl_url, version=version
                    )
                    self.perceptors.append(remote_perceptor)
                else:
                    # get the perceptor from the agent to ensure it is enabled
                    perceptor_impl = perceptor.get_impl_cls_instance()
                    self.perceptors.append(perceptor_impl)

        # You can't have nested skill groups, that would create an infinite loop between a <-> B
        if self.context.for_skill_group:
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
        else:
            # Next, see if we have any skill groups we need to add
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
            for skill_group in self.context.agent.skill_groups:
                if (
                    skill_group.get_second_skill().get_name()
                    == self.context.skill.get_name()
                ):
                    # get the skill from the agent to ensure it is enabled
                    first_skill_name = skill_group.get_first_skill().get_name()
                    first_skill = self.context.agent.get_node_by_name(first_skill_name)
                    config = SkillProcessorContext(
                        agent=self.context.agent,
                        skill=first_skill,
                        network_mgr=self.context.network_mgr,
                        is_training=False,
                        is_validating=self.context.is_validating,
                        for_skill_group=True,
                    )
                    skill_processor = await make_skill_processor(config)
                    self.skill_group_skill_processors.append(skill_processor)
                if (
                    skill_group.get_first_skill().get_name()
                    == self.context.skill.get_name()
                ):
                    second_skill = skill_group.get_second_skill()
                    config = SkillProcessorContext(
                        agent=self.context.agent,
                        skill=second_skill,
                        network_mgr=self.context.network_mgr,
                        is_training=False,
                        is_validating=self.context.is_validating,
                        for_skill_group=True,
                    )
                    skill_processor = await make_skill_processor(config)
                    self.post_skill_group_skill_processor = skill_processor

    @abstractmethod
    async def reset(self):
        raise NotImplementedError

    @abstractmethod
    async def is_compute_done(self):
        raise NotImplementedError

    def get_name(self):
        if self.context.name is not None:
            return self.context.name
        return self.context.skill.get_name()

    def get_skill_name(self):
        return self.context.skill.get_name()

    def execute(
        self,
        obs,
        sim_action_mask=None,
        explore=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        return asyncio.run(
            self._execute(
                obs,
                sim_action_mask,
                explore=explore,
                previous_action=previous_action,
                return_as_teacher_dict=return_as_teacher_dict,
            )
        )

    @abstractmethod
    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=True,
        previous_action=None,
        return_as_teacher_dict=False,
        skill_group_action=None
    ):
        raise NotImplementedError

    def set_skill_group_skill_processors(self, skill_group_skill_processors):
        self.skill_group_skill_processors = skill_group_skill_processors

    def get_skill_sensor_space(self):
        return self.observation_space

    def get_composabl_sensor_space(self):
        return self.composabl_sensor_space

    def get_teacher(self):
        return self.teacher

    def get_skill(self):
        return self.context.skill

    def get_action_space(self):
        # even though the action space won't change, might as well grab from the original source
        return self.context.skill.get_action_space()

    @abstractmethod
    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        raise NotImplementedError
