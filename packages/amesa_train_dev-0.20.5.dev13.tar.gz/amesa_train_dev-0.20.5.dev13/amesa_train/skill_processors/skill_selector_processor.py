# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
import asyncio

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util

import numpy as np
from amesa_core import SkillSelector
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.singletons.telemetry_historian import telemetry_historian

import amesa_core.utils.space_utils as space_utils
from amesa_train.model.skill_model import create_model_from_skill
from amesa_train.skill_processors.skill_processor import SkillProcessor
from amesa_core.networking.config.skill_processor_context import SkillProcessorContext

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class SkillSelectorProcessor(SkillProcessor):
    def __init__(self, context: SkillProcessorContext):
        """
        agent: Agent - the agent
        skill: Skill - the skill that is being used to process sensors and return actions
        is_training: bool - whether or not the skill processor is being used for training currently
        """
        super().__init__(context)

        if not isinstance(self.context.skill, SkillSelector):
            raise Exception(
                f"SkillSelectorProcessor must be used with a SkillSelector, {self.context.skill.get_name()}, {type(self.context.skill)}"
            )

        for child_skill_name in self.context.skill.get_children():
            self.context.agent.get_node_by_name(child_skill_name).set_sim_sensor_space(
                self.sim_sensor_space
            )

        # Make the action space for a selector skill, based on discrete with children
        self.action_space = amesa_spaces.Discrete(
            len(self.context.skill.get_children())
        )
        self.context.skill.set_action_space(self.action_space)
        self.child_skill_processors: list[SkillProcessor] = []

        if not self.context.is_training and not self.context.is_validating:
            self.model = create_model_from_skill(self.context.skill)

    async def init(self):
        await super().init()

        from amesa_train.skill_processors import make_skill_processor

        tasks = []
        for child_skill_name in self.context.skill.get_children():
            child_skill = self.context.agent.get_node_by_name(child_skill_name)
            context = SkillProcessorContext(
                agent=self.context.agent,
                skill=child_skill,
                network_mgr=self.context.network_mgr,
                is_training=False,
                is_validating=self.context.is_validating,
            )
            skill_processor = make_skill_processor(context)
            tasks.append(skill_processor)
        self.child_skill_processors = await asyncio.gather(*tasks)
        self._is_initialized = True

    async def reset(self):
        await asyncio.gather(
            *[
                child_skill_processor.reset()
                for child_skill_processor in self.child_skill_processors
            ]
        )
        await super().reset()

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        processed_selector_action = await super().process_action(
            sim_sensors,
            amesa_obs,
            action,
            sim_action_mask,
            unsquash_action=unsquash_action,
        )
        selected_child_processor: SkillProcessor = self.child_skill_processors[
            processed_selector_action
        ]
        child_action = await selected_child_processor._execute(
            sim_sensors,
            sim_action_mask,
            explore=False,
            is_coordinated=False,
            previous_action=None,
        )
        return child_action, processed_selector_action

    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        processed_selector_execute = await super()._execute(
            sim_sensors,
            sim_action_mask,
            explore=False,
            is_coordinated=False,
            previous_action=None,
            return_as_teacher_dict=return_as_teacher_dict,
        )
        teacher_action = processed_selector_execute
        if not return_as_teacher_dict:
            if isinstance(teacher_action, tuple):
                processed_selector_action = int(teacher_action[1])
            else:
                processed_selector_action = int(teacher_action)
        else:
            if isinstance(teacher_action["action"], tuple):
                processed_selector_action = int(teacher_action["action"][1])
            else:
                processed_selector_action = int(teacher_action["action"])

        if return_as_teacher_dict:
            teacher_action = processed_selector_execute["action"]

        if self.context.for_skill_group:
            return processed_selector_action

        selected_child_processor = self.child_skill_processors[
            processed_selector_action
        ]
        child_action = await selected_child_processor._execute(
            sim_sensors, sim_action_mask
        )

        # return the action
        if return_as_teacher_dict:
            processed_selector_execute["action"] = child_action
            processed_selector_execute["top_selector_action"] = processed_selector_action
            return processed_selector_execute
        else:
            return child_action

    async def process_sim_sensors(
        self, obs, sim_action_mask=None, previous_action=None
    ):
        filtered_obs, amesa_obs = await super().process_sim_sensors(
            obs, sim_action_mask, previous_action
        )

        # change the action mask according to the selector
        filtered_obs["action_mask"] = await self.compute_action_mask(
            amesa_obs, sim_action_mask, previous_action
        )

        return filtered_obs, amesa_obs

    def get_skill_name(self):
        return self.context.skill.get_name()

    def get_action_space(self):
        # even though the action space won't change, might as well grab from the original source
        return self.context.skill.get_action_space()

    async def compute_action_mask(
        self, amesa_obs, sim_action_mask, previous_action
    ):
        # first, compute the selector mask
        selector_mask = space_utils.compute_selector_action_mask(
            previous_action, self.context.skill
        )

        # next, compute the teacher mask
        teacher_mask = await self.teacher.compute_action_mask(
            amesa_obs, previous_action
        )

        if teacher_mask is None:
            teacher_mask = self.no_action_mask

        if not isinstance(teacher_mask, np.ndarray):
            teacher_mask = np.array(teacher_mask, dtype=np.int8)

        # finally, compute the total mask
        teacher_mask = space_utils.make_np_array(teacher_mask, dtype=np.int8)
        selector_mask = space_utils.make_np_array(selector_mask, dtype=np.int8)
        combined_mask = space_utils.combine_masks(selector_mask, teacher_mask)

        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step-mask",
            data={
                "teacher_mask": teacher_mask,
                "selector_mask": selector_mask,
                "combined_mask": combined_mask,
            },
        )

        return combined_mask

    def get_skill_sensor_space(self):
        return self.observation_space

    def get_teacher(self):
        return self.teacher

    def get_skill(self):
        return self.context.skill
