# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential]
import asyncio

import amesa_core.utils.logger as logger_util
from amesa_core.decorators.ensure_is_initialized import ensure_is_initialized

from amesa_train.skill_processors.skill_controller_processor import (
    SkillControllerProcessor,
)
from amesa_train.skill_processors.skill_processor_base import SkillProcessorBase
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)


# TODO: The DRL skills and controllers are weirdly overlapped in functionality
# but not enough overlap to make a base class for them. This is a problem.
# This will be resolved with the HTTP API refactor.
class SkillSelectorControllerProcessor(SkillControllerProcessor):
    def __init__(self, context: SkillProcessorContext) -> None:
        super().__init__(context)
        self.child_skill_processors: list[SkillProcessorBase] = []

    async def init(self):
        await super().init()

        from amesa_train.skill_processors import make_skill_processor

        tasks = []
        for child_skill_name in self.context.skill.get_children():
            child_skill = self.context.agent.get_node_by_name(child_skill_name)
            config = SkillProcessorContext(
                agent=self.context.agent,
                skill=child_skill,
                network_mgr=self.context.network_mgr,
                is_training=False,
                is_validating=self.context.is_validating,
            )
            skill_processor = make_skill_processor(config)
            tasks.append(skill_processor)
        self.child_skill_processors = await asyncio.gather(*tasks)
        self._is_initialized = True

    # TODO: Child processors if a selector skill
    @ensure_is_initialized
    async def reset(self):
        await super().reset()
        await asyncio.gather(
            *[
                child_skill_processor.reset()
                for child_skill_processor in self.child_skill_processors
            ]
        )

    @ensure_is_initialized
    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=True,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        # selectors skills never explore
        processed_selector_action = await super()._execute(
            sim_sensors,
            sim_action_mask,
            explore=False,
            is_coordinated=is_coordinated,
            previous_action=previous_action,
            return_as_teacher_dict=return_as_teacher_dict,
        )

        if not return_as_teacher_dict:
            if isinstance(processed_selector_action, tuple):
                processed_selector_action = int(processed_selector_action[1])
            else:
                processed_selector_action = int(processed_selector_action)
        else:
            if isinstance(processed_selector_action["action"], tuple):
                processed_selector_action["action"] = int(processed_selector_action["action"][1])
            else:
                processed_selector_action["action"] = int(processed_selector_action["action"])

        if self.context.for_skill_group:
            return processed_selector_action

        if not return_as_teacher_dict:
            selected_child_processor = self.child_skill_processors[
                processed_selector_action
            ]
        else:
            selected_child_processor = self.child_skill_processors[
                processed_selector_action["action"]
            ]

        child_action = await selected_child_processor._execute(
            sim_sensors, sim_action_mask, explore, return_as_teacher_dict=return_as_teacher_dict
        )

        # return the action
        if return_as_teacher_dict:
            processed_selector_action["action"] = child_action["action"]
            return processed_selector_action
        else:
            return child_action

    @ensure_is_initialized
    def compute_success_criteria(self, obs, action):
        pass

    @ensure_is_initialized
    def compute_termination(self, obs, action):
        pass

    @ensure_is_initialized
    async def is_compute_done(self, obs, action):
        return await self.compute_success_criteria(
            obs, action
        ) and await self.compute_termination(obs, action)
