# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential]

import amesa_core.utils.logger as logger_util
from amesa_core.decorators.ensure_is_initialized import ensure_is_initialized
from amesa_core.singletons.telemetry_historian import telemetry_historian
from amesa_core.utils import plugin_util
from amesa_core.networking import network_util
from amesa_train.skill_processors.skill_processor_base import SkillProcessorBase
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.utils.space_utils import convert_sim_sensors_to_amesa_sensors

logger = logger_util.get_logger(__name__)


# TODO: The DRL skills and controllers are weirdly overlapped in functionality
# but not enough overlap to make a base class for them. This is a problem.
# This will be resolved with the HTTP API refactor.
class SkillControllerProcessor(SkillProcessorBase):
    def __init__(self, context: SkillProcessorContext) -> None:
        super().__init__(context)

        self.controller = None
        self.sim_sensor_space = self.context.skill.get_sim_sensor_space()
        self.sim_action_space = self.context.skill.get_action_space()

        # TODO: Skill groups for controllers are valid. Need to implement
        self.skill_group_skill_processors = []

    async def init(self):
        await super().init()
            
        # We are initialized
        self._is_initialized = True

    @ensure_is_initialized
    async def reset(self):
        telemetry_historian.sink(
            category="controller",
            category_sub="reset",
            data={"controller": "reset called"},
        )

        if self.context.skill.is_remote():
            await self.controller.reset()
        else:
            self.controller = self.context.skill.get_impl_cls_instance()

        if len(self.perceptors) > 0:
            for perceptor in self.perceptors:
                try:
                    await perceptor.reset()
                except Exception as e:
                    pass

    @ensure_is_initialized
    async def compute_single_action(self, obs, action, skill_group_action={}):
        amesa_obs = await convert_sim_sensors_to_amesa_sensors(
            obs,
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        amesa_obs.update(skill_group_action)
        action = await self.controller.compute_action(amesa_obs, action)

        # Check to make sure the action conforms to the action space
        action = self.sim_action_space.coerce_sample(action)

        telemetry_historian.sink(
            category="controller",
            category_sub="compute-single-action",
            data={"action": action},
        )
        return await self.process_action(
            obs, amesa_obs, action, None, unsquash_action=False
        )

    @ensure_is_initialized
    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=True,
        previous_action=None,
        return_as_teacher_dict=False,
        skill_group_action={},
    ):
        action = await self.compute_single_action(sim_sensors, previous_action, skill_group_action)
        telemetry_historian.sink(
            category="controller",
            category_sub="execute",
            data={"action": action},
        )
        if return_as_teacher_dict:
            # dummy reward and other teacher vars
            amesa_obs = await convert_sim_sensors_to_amesa_sensors(
                sim_sensors,
                self.sim_sensor_space,
                self.context.agent.sensors,
                self.perceptors,
                self.skill_group_skill_processors,
            )
            return {
                "action": action,
                "state": amesa_obs,
                "reward": 0,
                "done": False,
                "terminated": False,
                "success": False,
            }
        else:
            return action

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        if self.context.for_skill_group:
            return action

        elif self.post_skill_group_skill_processor is not None:
            return await self.post_skill_group_skill_processor._execute(
                sim_sensors=sim_sensors,
                sim_action_mask=sim_action_mask,
                explore=False,
                is_coordinated=False,
                previous_action=action,
            )
        else:
            return action

    @ensure_is_initialized
    def compute_success_criteria(self, obs, action):
        pass

    @ensure_is_initialized
    def compute_termination(self, obs, action):
        pass

    @ensure_is_initialized
    async def is_compute_done(self, obs, action):
        return await self.compute_success_criteria(
            obs, action
        ) and await self.compute_termination(obs, action)
