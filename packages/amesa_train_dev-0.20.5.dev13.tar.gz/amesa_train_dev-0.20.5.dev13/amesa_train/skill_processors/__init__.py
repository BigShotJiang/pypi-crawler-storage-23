# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential


from amesa_core import (
    Skill,
    SkillCoordinatedPopulation,
    SkillCoordinatedSet,
    SkillSelector,
)
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

from .skill_controller_processor import SkillControllerProcessor
from .skill_coordinated_population_processor import SkillCoordinatedPopulationProcessor
from .skill_coordinated_set_processor import SkillCoordinatedSetProcessor
from .skill_processor import SkillProcessor
from .skill_processor_base import SkillProcessorBase
from .skill_selector_controller_processor import SkillSelectorControllerProcessor
from .skill_selector_processor import SkillSelectorProcessor


async def make_skill_processor(config: SkillProcessorContext) -> SkillProcessorBase:
    """
    Makes a skill processor based on the type of skill (e.g., Skill, SkillSelector, SkillCoordinated) and whether it is a controller or not.

    @param agent: The agent that the skill processor will be associated with
    @param skill: The skill that the skill processor will be associated with
    @param is_training: Whether the skill processor is for training
    @param is_validating: Whether the skill processor is for validating the skill function's correctness
    @param for_skill_group: Whether the skill processor is being made as part of a skill group for another skill processor
    """

    skill_controller_cls = None
    if config.skill.is_controller():
        if issubclass(type(config.skill), SkillSelector):
            skill_controller_cls = SkillSelectorControllerProcessor
        else:
            skill_controller_cls = SkillControllerProcessor
    elif isinstance(config.skill, SkillSelector):
        skill_controller_cls = SkillSelectorProcessor
    elif isinstance(config.skill, SkillCoordinatedSet):
        skill_controller_cls = SkillCoordinatedSetProcessor
    elif isinstance(config.skill, SkillCoordinatedPopulation):
        skill_controller_cls = SkillCoordinatedPopulationProcessor
    elif isinstance(config.skill, Skill):
        skill_controller_cls = SkillProcessor
    else:
        raise ValueError(f"Unsupported skill type: {type(config.skill)}")

    skill_controller_instance = skill_controller_cls(config)
    await skill_controller_instance.init()

    return skill_controller_instance
