# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Type, TypeVar, Union

from pydantic import BaseModel
import ray

import amesa_core.utils.logger as logger_util

T = TypeVar("T")

logger = logger_util.get_logger(__name__)


class ActorOptions(BaseModel):
    name: str

    # Do we detach the actor, maintaining it after references are removed
    # https://docs.ray.io/en/latest/ray-core/actors/named-actors.html#actor-lifetimes
    is_detached: bool = False


class Actor:
    """
    Define an Actor class that acts as a Proxy for Ray Actors

    We use this to wrap the Ray Actor and provide a more intuitive API as well as resolve cython compatibility issues
    more specifically it provides:
    1. Not having to use `.remote`
    2. Not having to use `ray.get` to get the result
    3. Supporting async methods natively, which are converted to sync methods always.
        This mainly resolves nested serialization issues causing pickle issues (ref. cannot pickle `_cython_3_2_2.coroutine`)
    """

    def __init__(
        self,
        cls: Type[T],
        name_or_options: Union[str, ActorOptions],
        *actor_args,
        **actor_kwargs
    ):
        self._cls = cls
        self._actor_args = actor_args
        self._actor_kwargs = actor_kwargs
        self._options = (
            name_or_options
            if isinstance(name_or_options, ActorOptions)
            else ActorOptions(name=name_or_options)
        )

        self._handle = (
            ray.remote(cls)
            .options(
                name=self._options.name,
                lifetime="detached" if self._options.is_detached else None,
                # By default, we create only if it doesn't exist
                get_if_exists=True,
            )
            .remote(*actor_args, **actor_kwargs)
        )

        # # Catch all exceptions
        # sys.excepthook = self._handle_excepthook

    def __getattr__(self, attr_name) -> T:
        """
        Execute this method on the Ray Actor Instance

        Note: we make an exception for the reserved attributes _cls, _name and _handle
        """
        if attr_name in ["_cls", "_name", "_handle"]:
            return getattr(self, attr_name)

        method = getattr(self._handle, attr_name)
        return self._make_sync_proxy(method)

    def _make_sync_proxy(self, method):
        def proxy(*args, **kwargs):
            result_id = method.remote(*args, **kwargs)

            try:
                # Check if we need to use ray.get
                if isinstance(result_id, ray.ObjectRef):
                    return ray.get(result_id)
                else:
                    return result_id
            except Exception as e:
                logger.error(e)
                # traceback.print_stack()
                # Handle the exception here, e.g., by re-raising it or returning an error value
                raise e

        return proxy

    def terminate(self):
        """
        Terminate the actor

        This uses a undocumented featured named `__ray_terminate__`
        https://github.com/ray-project/ray/blob/0e77916b0415ce95550610f8b61764eeadf7aa6c/python/ray/actor.py#L1340
        """
        self._handle.__ray_terminate__.remote()
        ray.kill(self._handle)

    def get_id(self):
        """
        Get the Ray Actor ID
        https://github.com/ray-project/ray/blob/master/python/ray/actor.py#L1038
        """
        return self._handle._ray_actor_id

    def get_language(self):
        """
        Get the Ray Actor Language
        https://github.com/ray-project/ray/blob/master/python/ray/actor.py#L1037C9-L1037C28
        """
        return self._handle._ray_actor_language

    def __getstate__(self):
        state = {
            "_cls": self._cls,
            "_options": self._options,
            "actor_args": self._actor_args,
            "actor_kwargs": self._actor_kwargs,
        }

        # not every cls will have a __getstate__ method implemented
        try:
            additional_state = self._handle.__getstate__()
            state["additional_state"] = additional_state
        except:
            pass

        return state

    def __setstate__(self, state):
        self._cls = state["_cls"]
        self._options = state["_options"]
        self._actor_args = state["actor_args"]
        self._actor_kwargs = state["actor_kwargs"]

        # Set the handle through Named Actors
        # https://docs.ray.io/en/latest/ray-core/actors/named-actors.html#named-actors

        try:
            self._handle = ray.get_actor(self._options.name)
        except:
            # if we can't find the ray actor by name,
            # then this is a new ray instance, and we must create it
            self._handle = (
                ray.remote(self._cls)
                .options(
                    name=self._options.name,
                    lifetime="detached" if self._options.is_detached else None,
                    # By default, we create only if it doesn't exist
                    get_if_exists=True,
                )
                .remote(*self._actor_args, **self._actor_kwargs)
            )

        if "additional_state" in state:
            self._handle.__setstate__(state["additional_state"])
