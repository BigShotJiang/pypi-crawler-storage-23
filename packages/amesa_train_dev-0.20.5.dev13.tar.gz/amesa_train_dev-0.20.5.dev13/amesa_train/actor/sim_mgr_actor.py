# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
import ray

from amesa_core.config.trainer_config import TrainerConfig
from amesa_core.networking.network_mgr import NetworkMgr
import amesa_core.utils.logger as logger_util

logger = logger_util.get_logger(__name__)


class NetworkMgrActor(NetworkMgr):
    """
    Note: we do not use the `@ray.remote` decorator here because
    ray does not support the decorator with Cython
    see: https://github.com/ray-project/ray/issues/39736
    """

    def __init__(self, config: TrainerConfig):
        super().__init__(config)

    @staticmethod
    def create_actor(config: TrainerConfig) -> "ray.ObjectRef[NetworkMgrActor]":
        """
        Create an actor
        Note: we do not check if the actor exists already as we want the error. Causing the actor
        to exist already causes unwanted behavior in tests
        """
        actor_name = "NetworkMgrActor"
        cls = ray.remote(NetworkMgrActor)
        return cls.options(name=actor_name).remote(config)

    def terminate(self):
        """
        Terminate the actor
        """
        logger.debug("Terminating sim watchdog on actor")
        self.stop_watchdogs()

        logger.debug("Terminating actor")
        ray.actor.exit_actor()
