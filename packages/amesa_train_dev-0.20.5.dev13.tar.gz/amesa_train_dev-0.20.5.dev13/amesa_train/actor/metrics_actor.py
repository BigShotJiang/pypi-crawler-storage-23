# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import time
from typing import Dict, Optional, Union

import amesa_core.utils.logger as logger_util
import ray
from amesa_core.metrics.metrics import Metrics
from amesa_core.metrics.metrics_config import MetricsConfig

import amesa_core.utils.logger as logger_util
logger = logger_util.get_logger(__name__)

IDX_ALL = -1


class MetricsActor:
    def __init__(self, config: Union[Dict, MetricsConfig, None] = None):
        self.logger = logger_util.get_logger(__name__)
        self.config = MetricsConfig.create(config)
        self.metrics = Metrics(config)
        self.log_previous_steps = 0

    @staticmethod
    def get_or_create(
        config: Optional[MetricsConfig] = None,
    ) -> "ray.ObjectRef[MetricsActor]":
        """
        Get the named actor or create it if it doesn't exist

        Returns:
            The actor
        """
        if config is None:
            config = MetricsConfig()

        actor_name = "MetricsActor"

        return (
            ray.remote(MetricsActor)
            .options(
                name=actor_name,
                # namespace="management",
                # lifetime="detached",
                get_if_exists=True,
            )
            .remote(config)
        )

    def divide_log_frequency(self, value: int) -> int:
        """
        Divide the log frequency by the value

        Args:
            value: The value

        Returns:
            The divided value
        """
        self.config.log_every_x_steps = int(self.config.log_every_x_steps / value)

    def add_steps_collected(self, value: Union[float, int]):
        """
        Set the samples collected

        Args:
            value: The value

        Returns:
            None
        """
        steps_collected = int(self.metrics.add_value("steps_collected", int(value)))
        steps_to_collect = int(self.metrics.get_metric("steps_to_collect", 0))

        # Reset when done
        if steps_to_collect > 0 and steps_collected >= steps_to_collect:
            self.metrics.set_value("steps_collected", 0)
            self.log_previous_steps = 0

        # Calculate the Δt and Σt for the timestamp
        ts = time.time()
        t_delta = round(self.metrics.diff_value("steps_collected_t", ts, 0), 3)
        self.metrics.set_value("steps_collected_Δt", t_delta)
        t_sigma = round(self.metrics.add_value("steps_collected_Σt", t_delta), 3)

        # Print
        if steps_collected - self.log_previous_steps >= self.config.log_every_x_steps:
            self.print(steps_to_collect, steps_collected, t_delta, t_sigma)
            self.log_previous_steps = steps_collected

    def print(
        self,
        steps_to_collect: int,
        steps_collected: int,
        t_delta: float,
        t_sigma: float,
    ):
        """
        Print the metrics
        """
        length_of_steps_to_collect = len(str(steps_to_collect))
        steps_collected_str = str(steps_collected).rjust(length_of_steps_to_collect)
        t_delta_str = (str(t_delta) + "s").rjust(8)
        t_sigma_str = (str(t_sigma) + "s").rjust(8)
        steps_per_second = round(
            steps_collected / t_sigma if t_sigma > 0 else 0.0001, 3
        )
        steps_per_second_str = str(steps_per_second).rjust(8)
        res = f"Gathering Experience: {steps_collected_str} / {steps_to_collect} | Δt: {t_delta_str} | Σt: {t_sigma_str} | steps/s: {steps_per_second_str}"
        self.logger.info(res)

    def set_steps_to_collect(self, value: int):
        """
        Set the samples to collect

        Args:
            value: The value

        Returns:
            None
        """
        self.metrics.set_value("steps_to_collect", value)

    def reset(self, metric: Optional[str] = None):
        """
        Reset the metric given or everything if nothing
        """
        self.log_previous_steps = 0
        self.metrics.reset(metric)

        # Also reset the other values that belong with the steps collected
        if metric == "steps_collected":
            self.metrics.set_value("steps_collected_t", time.time())
            self.metrics.set_value("steps_collected_Δt", 0)
            self.metrics.set_value("steps_collected_Σt", 0)
