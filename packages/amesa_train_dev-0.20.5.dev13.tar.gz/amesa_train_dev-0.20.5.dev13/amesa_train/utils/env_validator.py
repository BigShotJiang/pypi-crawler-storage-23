# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Dict

import amesa_core.utils.logger as logger_util
import numpy as np

from amesa_train.env.env import AmesaEnv

logger = logger_util.get_logger(__name__)


def validate_dataset(dataset: Dict):
    # for each key in the dataset, check that the values are consistent
    # this means that the values are the same data type, or None
    # if the values are not the same data type, raise an error
    # if the values are None, then we can't check them, so we skip them
    errors = []

    # first, get the keys
    # then, iterate through the keys and check the values
    for key, values in dataset.items():
        added_error = False

        if len(values) == 0:
            continue

        first_value = values[0]
        if isinstance(first_value, dict):
            # if the first value is a dict, then we need to check the keys
            # and then check the values for each key
            for sub_key in first_value.keys():
                sub_values = [value[sub_key] for value in values]
                valid, sub_errors = validate_dataset({sub_key: sub_values})

                if not valid:
                    errors.extend(sub_errors)
                    added_error = True
                    break

            if added_error:
                continue
        else:
            for value in values:
                if value is None:
                    continue

                if first_value is None:
                    first_value = value
                    continue

                if type(value) is not type(first_value):
                    errors.append(
                        ValueError(
                            f"Type Mismatch, Expected '{key}'='{value}' (type: '{type(value)}'), got: '{key}'='{first_value}' (type: '{type(first_value)}')"
                        )
                    )
                    added_error = True
                elif isinstance(value, np.ndarray):
                    if value.shape != first_value.shape:
                        errors.append(
                            ValueError(
                                f"Shape Mismatch, Expected '{key}'='{value}' (shape: '{value.shape}'), got: '{key}'='{first_value}' (shape: '{first_value.shape}')"
                            )
                        )
                        added_error = True

                if added_error:
                    break

    return len(errors) == 0, errors


async def validate_env(env: AmesaEnv):
    """
    Validate the environment
    We do this by running 3 episodes and checking various teacher values and sim values
    """

    objects = {}

    # Run 3 episodes, but stop if more than 200 steps are taken in an episode
    for _ in range(3):
        episode_objects = {
            "obs": [],
            "reward": [],
            "truncated": [],
            "done": [],
            "sim_action_mask": [],
            "teacher_reward": [],
            "teacher_action_mask": [],
            "teacher_success_criteria": [],
            "teacher_termination": [],
            "teacher_transformed_sensors": [],
            "teacher_action": [],
            "teacher_done": [],
        }

        try:
            obs, info = await env.composabl_reset()
        except Exception as e:
            # reset errors are possible from both user side and sdk side
            episode_objects["reset_error"] = e
            break  # we can't continue if we can't reset

        episode_objects["obs"].append(obs)
        done = False
        counter = 0

        while not done and counter < 200:  # in case the sim episodes are very long
            action = env.action_space.sample()
            try:
                obs, reward, done, truncated, info = await env._step_async(action)
            except Exception as e:
                # step errors are possible from both user side and sdk side
                episode_objects["step_error"] = str(e)
                break  # we can't continue if we can't step

            episode_objects["obs"].append(obs)
            episode_objects["reward"].append(reward)
            episode_objects["truncated"].append(truncated)

            if "done" not in objects.keys():
                objects["done"] = []

            episode_objects["done"].append(done)

            if isinstance(info, dict):
                if "action_mask" in info.keys():
                    episode_objects["sim_action_mask"] = info["action_mask"]
                # otherwise we don't care what sort of stuff the sim is telling us
                # it is there for logging purposes for the historian

            # Check the teacher values
            teacher = env.get_teacher()
            amesa_obs = env.prev_amesa_obs

            episode_objects["teacher_reward"].append(
                await teacher.compute_reward(amesa_obs, action, reward)
            )
            episode_objects["teacher_action_mask"].append(
                await teacher.compute_action_mask(amesa_obs, action)
            )
            episode_objects["teacher_success_criteria"].append(
                await teacher.compute_success_criteria(amesa_obs, action)
            )
            episode_objects["teacher_termination"].append(
                await teacher.compute_termination(amesa_obs, action)
            )
            episode_objects["teacher_transformed_sensors"].append(
                await teacher.transform_sensors(amesa_obs, action)
            )
            episode_objects["teacher_action"].append(
                await teacher.transform_action(amesa_obs, action)
            )
            episode_objects["teacher_done"].append(
                await teacher.is_compute_done(amesa_obs, action)
            )

            counter += 1

        # append the episode objects to the objects
        for key, value in episode_objects.items():
            if key not in objects.keys():
                objects[key] = []
            objects[key].extend(value)

        # if there is a step error or reset error, we can't continue

    valid, errors = validate_dataset(objects)
    return valid, errors
