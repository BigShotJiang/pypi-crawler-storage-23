# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Skill Processor Component for EventSkillProcessor.
This component provides skill processing functionality that can be used by EventSkillProcessor.
"""

from typing import Any, Dict, Optional, Tuple

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util
from amesa_core.agent.skill.skill_teacher import SkillTeacher
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)


class SkillProcessorComponent:
    """
    Skill Processor Component that provides skill processing functionality.

    This component encapsulates the skill processing logic and can be used
    by EventSkillProcessor or other event-driven systems.
    """

    def __init__(self, context: SkillProcessorContext):
        """
        Initialize the skill processor component.

        Args:
            context: Skill processor context containing agent and skill information
        """
        self.context = context
        self.teacher: Optional[SkillTeacher] = None
        self.sim_sensor_space = None
        self.action_space: Optional[amesa_spaces.Space] = None
        self.composabl_sensor_space: Optional[amesa_spaces.Dict] = None
        self.filtered_composabl_sensor_space = None
        self.filter_keys = {}
        self.observation_space = None
        self.action_mask_space = None
        self.no_action_mask = None
        self.done = False
        self.perceptors = []
        self.skill_group_skill_processors = []
        self.post_skill_group_skill_processor = None
        self._is_initialized = False

        # Model attributes
        self.model_path: Optional[str] = None
        self.policy = None  # Ray RLlib Policy instance

    async def init(self):
        """
        Initialize the skill processor component.

        Architecture:
        - Component needs observation space to properly flatten observations
        - It needs the teacher/controller for sensor transformation and reward computation
        - The Ray Policy (loaded from checkpoint) handles action computation
        - When a new skill processor starts up, the model torch file is sent as a message
        - Observation dict structure: {"obs": sensors, "action_mask": mask (optional)}
        - When action_mask is not present, the torch model doesn't try to apply it
        """
        # Initialize teacher/controller and spaces
        await self._init_skill_processor_base()

        # Initialize observation spaces for proper flattening
        # Note: For v2 inference-only components, we'll get the actual spaces
        # from the model checkpoint when it's loaded via update_model()
        # For now, just set up minimal state

        # Get filter keys from teacher (which sensors to use for this skill)
        self.filter_keys = await self.teacher.filtered_sensor_space()
        if self.filter_keys is None or len(self.filter_keys) == 0:
            self.filter_keys = [sensor.name for sensor in self.context.agent.sensors]

        # Spaces will be initialized from the model checkpoint
        # These are set to None until update_model() is called
        self.sim_sensor_space = None
        self.composabl_sensor_space = None
        self.filtered_composabl_sensor_space = None
        self.action_space = None
        self.action_mask_space = None
        self.no_action_mask = None

        self._is_initialized = True
        self.done = False

        logger.info(f"SkillProcessorComponent initialized for skill: {self.context.skill.get_name()}")
        logger.info("Component ready to receive model checkpoint")

    async def _init_skill_processor_base(self):
        """Initialize the skill processor base components."""
        from amesa_core.networking import network_util
        from amesa_core.utils import plugin_util

        from amesa_train.skill_processors import make_skill_processor

        if self.context.skill.is_remote():
            # download the skill from the URL to check the composabl version
            try:
                version = await plugin_util.get_amesa_version(self.context.skill.get_impl_cls())
            except Exception:
                version = "latest"

            composabl_url = network_util.get_amesa_url(
                self.context.skill.get_impl_cls()
            )

            # use the network manager to create the remote client
            if self.context.skill.is_controller():
                # remote controller
                client_id, self.controller = await self.context.network_mgr.call_remote_controller_mgr.remote(
                    "create_with_client", env_init=composabl_url, version=version
                )
            else:
                # remote skill
                client_id, self.teacher = await self.context.network_mgr.call_remote_skill_mgr.remote(
                    "create_with_client", env_init=composabl_url, version=version
                )
        else:
            if self.context.skill.is_controller():
                # the controller is loaded in locally (SDK workflow)
                self.controller = self.context.skill.get_impl_cls_instance()
            else:
                # the teacher is loaded in locally (SDK workflow)
                self.teacher = self.context.skill.get_impl_cls_instance()

        if self.context.agent.perceptors is not None:
            for perceptor in self.context.agent.perceptors:
                if perceptor.is_remote():
                    composabl_url = network_util.get_amesa_url(
                        perceptor.get_impl_cls()
                    )
                    # download the perceptor from the URL
                    try:
                        version = await plugin_util.get_amesa_version(composabl_url)
                    except Exception:
                        version = "latest"

                    # remote perceptor
                    client_id, remote_perceptor = await self.context.network_mgr.call_remote_perceptor_mgr.remote(
                        "create_with_client", env_init=composabl_url, version=version
                    )
                    self.perceptors.append(remote_perceptor)
                else:
                    # get the perceptor from the agent to ensure it is enabled
                    perceptor_impl = perceptor.get_impl_cls_instance()
                    self.perceptors.append(perceptor_impl)

        # Handle skill groups
        if self.context.for_skill_group:
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
        else:
            # Next, see if we have any skill groups we need to add
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
            for skill_group in self.context.agent.skill_groups:
                if (
                    skill_group.get_second_skill().get_name()
                    == self.context.skill.get_name()
                ):
                    # get the skill from the agent to ensure it is enabled
                    first_skill_name = skill_group.get_first_skill().get_name()
                    first_skill = self.context.agent.get_node_by_name(first_skill_name)
                    config = SkillProcessorContext(
                        agent=self.context.agent,
                        skill=first_skill,
                        network_mgr=self.context.network_mgr,
                        is_training=False,
                        is_validating=self.context.is_validating,
                        for_skill_group=True,
                    )
                    skill_processor = await make_skill_processor(config)
                    self.skill_group_skill_processors.append(skill_processor)
                if (
                    skill_group.get_first_skill().get_name()
                    == self.context.skill.get_name()
                ):
                    second_skill = skill_group.get_second_skill()
                    config = SkillProcessorContext(
                        agent=self.context.agent,
                        skill=second_skill,
                        network_mgr=self.context.network_mgr,
                        is_training=False,
                        is_validating=self.context.is_validating,
                        for_skill_group=True,
                    )
                    skill_processor = await make_skill_processor(config)
                    self.post_skill_group_skill_processor = skill_processor

    async def compute_step(
        self,
        sim_sensors,
        sim_reward=0.0,
        sim_terminated=False,
        truncated=False,
        info=None,
        previous_action=None
    ) -> Dict[str, Any]:
        """
        Compute a complete step: transform observations, compute action, compute reward.

        This is the main method for inference. It:
        1. Transforms observations → composabl observation (via teacher)
        2. Computes action using policy
        3. Transforms action
        4. Computes reward and termination criteria

        Args:
            sim_sensors: Simulation sensor data
            sim_reward: Simulation reward
            sim_terminated: Whether simulation is terminated
            truncated: Whether episode is truncated
            info: Additional info dictionary (may contain action_mask)
            previous_action: Previous action (may be None on first step)

        Returns:
            Dictionary with: action, sensors_filtered, amesa_obs, teacher_reward,
            teacher_success, teacher_terminated, truncated
        """
        if info is None:
            info = {}

        if self.policy is None:
            raise RuntimeError("No policy loaded. Call update_model() first.")

        # 1. Transform observations → composabl observation
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, info.get("action_mask", None), previous_action=previous_action
        )

        # 2. Compute action using policy
        # The policy expects observations in the format {"obs": ..., "action_mask": ... (optional)}
        action_output = self.policy.compute_single_action(sensors_filtered)

        # Extract the action from the output tuple (action, state, info_dict)
        computed_action = action_output[0]

        # 3. Transform action
        processed_action = await self.process_action(
            sim_sensors, amesa_obs, computed_action
        )

        # 4. Compute reward and termination criteria via teacher
        teacher_reward = await self.teacher.compute_reward(
            amesa_obs, processed_action, sim_reward
        )
        teacher_success = await self.teacher.compute_success_criteria(
            amesa_obs, processed_action
        )
        teacher_terminated = await self.teacher.compute_termination(
            amesa_obs, processed_action
        )
        truncated = teacher_success or teacher_terminated

        return {
            "action": processed_action,
            "sensors_filtered": sensors_filtered,
            "amesa_obs": amesa_obs,
            "teacher_reward": teacher_reward,
            "teacher_success": teacher_success,
            "teacher_terminated": teacher_terminated,
            "truncated": truncated,
        }

    async def step(
        self,
        sim_sensors,
        sim_reward,
        sim_terminated,
        truncated,
        info,
        action
    ) -> Tuple[Dict, Any, float, bool, bool, bool]:
        """
        Process a single step of the skill.

        The observation passed to the policy will be a dictionary with:
        - "obs": The actual sensor observations (required)
        - "action_mask": The action mask array (optional)

        When action_mask is not present in the observation dict, the torch model
        doesn't try to apply it. This structure is handled internally by the Ray Policy.

        Args:
            sim_sensors: Simulation sensor data
            sim_reward: Simulation reward
            sim_terminated: Whether simulation is terminated
            truncated: Whether episode is truncated
            info: Additional info dictionary (may contain action_mask)
            action: Action taken

        Returns:
            Tuple of (sensors_filtered, amesa_obs, teacher_reward, teacher_success, teacher_terminated, truncated)
        """
        # Process sensors
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, info.get("action_mask", None), previous_action=action
        )

        # Compute teacher metrics
        teacher_reward = await self.teacher.compute_reward(
            amesa_obs, action, sim_reward
        )
        teacher_success = await self.teacher.compute_success_criteria(
            amesa_obs, action
        )
        teacher_terminated = await self.teacher.compute_termination(
            amesa_obs, action
        )
        truncated = teacher_success or teacher_terminated

        return (
            sensors_filtered,
            amesa_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        )

    async def process_sim_sensors(
        self, sensors, sim_action_mask=None, previous_action=None
    ) -> Tuple[Dict, Dict]:
        """Process simulation sensors and convert to composabl format."""
        from amesa_core.utils import space_utils

        # Check if spaces are initialized (need model to be loaded first)
        if self.filtered_composabl_sensor_space is None:
            raise RuntimeError(
                "Observation spaces not initialized. Model must be loaded via update_model() first."
            )

        # Convert sim sensors to composabl sensors
        amesa_sensors = await space_utils.convert_sim_sensors_to_amesa_sensors(
            sensors,
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        # Transform sensors through teacher
        composabl_sensor_transformed = await self.teacher.transform_sensors(
            amesa_sensors, None
        )

        # Filter the composabl observation space
        filtered_composabl_sensor_space = space_utils.filter_sample(
            composabl_sensor_transformed, self.filter_keys
        )

        # Normalize the filtered composabl sensor space
        for sensor in self.context.agent.sensors:
            if sensor.name in self.filter_keys:
                filtered_composabl_sensor_space[sensor.name] = sensor.normalize_sample(
                    filtered_composabl_sensor_space[sensor.name]
                )

        if filtered_composabl_sensor_space is None:
            raise Exception(
                f"Sensor values is 'None' for skill '{self.context.skill.get_name()}'"
            )

        # Build the observation dict for the Ray Policy
        # The custom ActionMaskRLMBase model expects: {"observation": data, "action_mask": mask (optional)}
        sensors_filtered = {}
        sensors_filtered["observation"] = filtered_composabl_sensor_space

        # Compute action mask (optional - only include if needed)
        # When action_mask is not present, the torch model doesn't try to apply it
        action_mask = await self.compute_action_mask(
            composabl_sensor_transformed, sim_action_mask, previous_action
        )
        if action_mask is not None:
            sensors_filtered["action_mask"] = action_mask

        # Flatten the observation using the proper space method (like old code)
        # This ensures proper structure and dtype handling
        sensors_filtered["observation"] = self.filtered_composabl_sensor_space.flatten_sample(
            sensors_filtered["observation"]
        )

        return sensors_filtered, composabl_sensor_transformed

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        """Process the action through the teacher."""
        from amesa_core.utils import space_utils

        # Unsquash action if needed
        if unsquash_action:
            unsquashed_action = space_utils.unsquash_action(action, self.action_space)
        else:
            unsquashed_action = action

        # Transform action through teacher
        processed_action = await self.teacher.transform_action(
            amesa_obs, unsquashed_action
        )

        return processed_action

    async def compute_action_mask(self, amesa_obs, sim_action_mask, previous_action):
        """Compute the action mask for the skill."""
        from amesa_core.utils import space_utils

        teacher_mask = await self.teacher.compute_action_mask(
            amesa_obs, previous_action
        )

        # Handle custom action space
        if self.context.skill.has_custom_action_space():
            sim_action_mask = None  # Ignore sim mask for custom action spaces

        # If both masks are None, return None (no masking)
        if teacher_mask is None and sim_action_mask is None:
            return None

        # If only one is None, use the other
        if teacher_mask is None:
            return sim_action_mask
        if sim_action_mask is None:
            return teacher_mask

        # Combine both masks
        total_mask = space_utils.combine_masks(teacher_mask, sim_action_mask)
        return total_mask

    async def reset(self):
        """Reset the skill processor component for a new episode."""
        # Reset the teacher
        if self.context.skill.is_remote():
            await self.teacher.reset()
        else:
            self.teacher = self.context.skill.get_impl_cls_instance()

        # Reset perceptors
        if len(self.perceptors) > 0:
            for perceptor in self.perceptors:
                try:
                    await perceptor.reset()
                except Exception as e:
                    logger.warning(f"Error resetting perceptor: {e}")

        self.done = False

    def is_done(self):
        """Check if the skill is done."""
        return self.done

    def get_name(self):
        """Get the component name."""
        if self.context.name is not None:
            return self.context.name
        return self.context.skill.get_name()

    def get_skill_name(self):
        """Get the skill name."""
        return self.context.skill.get_name()

    def get_action_space(self):
        """Get the action space."""
        return self.context.skill.get_action_space()

    def get_skill_sensor_space(self):
        """Get the skill sensor space."""
        return self.observation_space

    def get_composabl_sensor_space(self):
        """Get the composabl sensor space."""
        return self.composabl_sensor_space

    def get_teacher(self):
        """Get the teacher."""
        return self.teacher

    def get_skill(self):
        """Get the skill."""
        return self.context.skill

    async def update_model(self, model_uri: str):
        """
        Download and load a new Ray Policy checkpoint from the given URI.

        This method handles:
        1. Downloading the checkpoint from the URI (if it's a URL)
        2. Loading the Ray Policy from the checkpoint
        3. Updating the component's internal model state

        Args:
            model_uri: URI to the checkpoint (local path or URL)

        Raises:
            Exception: If checkpoint download or loading fails
        """
        import os
        import tempfile

        from amesa_core.networking import network_util
        from ray.rllib.policy.policy import Policy

        logger.info(f"Updating model from URI: {model_uri}")

        # Download the checkpoint if it's a URL
        model_path = model_uri
        if not os.path.exists(model_uri):
            # It's a URL - download it
            logger.info(f"Downloading checkpoint from URL: {model_uri}")

            # Create temporary directory for checkpoint
            temp_dir = tempfile.mkdtemp(prefix="composabl_checkpoint_")
            model_filename = os.path.basename(model_uri)
            if not model_filename:
                model_filename = "checkpoint"

            model_path = os.path.join(temp_dir, model_filename)

            # Get license key for authentication
            license_key = os.environ.get("AMESA_LICENSE", "")
            headers = {}
            if license_key:
                headers["Authorization"] = f"Bearer {license_key}"

            # Download the checkpoint
            try:
                await network_util.download_file(model_uri, model_path, headers=headers)
                logger.info(f"Checkpoint downloaded successfully to {model_path}")
            except Exception as e:
                logger.error(f"Failed to download checkpoint from {model_uri}: {e}")
                raise

        # Load the Ray Policy from checkpoint
        try:
            logger.info(f"Loading Ray Policy from checkpoint: {model_path}")

            # Load policies from checkpoint
            policies = Policy.from_checkpoint(model_path)

            # Try to find the policy matching the skill name
            skill_name = self.context.skill.get_name()
            if skill_name in policies:
                policy = policies[skill_name]
            else:
                # Fall back to default_policy
                policy = policies["default_policy"]

            # Update component state
            self.policy = policy
            self.model_path = model_path

            # Extract observation and action spaces from the loaded policy
            import amesa_core.spaces as amesa_spaces

            # Get action space from policy
            # Ray Policy uses gym spaces, which are compatible with amesa_spaces
            if hasattr(policy, 'action_space'):
                # Use the gym space directly (amesa_spaces is gym.spaces)
                self.action_space = policy.action_space

                # Action masks are not used in this v2 inference-only setup
                # They would need to be configured separately if needed
                self.action_mask_space = None
                self.no_action_mask = None

                logger.info(f"  Action space extracted from policy: {self.action_space}")

            # Get observation space from policy
            if hasattr(policy, 'observation_space'):
                # The policy's observation space should match what we're feeding it
                # {"obs": array, "action_mask": array (optional)}
                # The policy observation space tells us what shape to expect

                # This is our flattened observation space
                # Build a Dict space for filtered_composabl_sensor_space that matches filter_keys
                amesa_space = {}
                for sensor_name in self.filter_keys:
                    # Each sensor contributes to the flattened observation
                    # For simplicity, assume each sensor is a single float value
                    amesa_space[sensor_name] = amesa_spaces.Box(
                        low=-float('inf'), high=float('inf'), shape=(1,), dtype='float32'
                    )
                self.composabl_sensor_space = amesa_spaces.Dict(amesa_space)
                self.filtered_composabl_sensor_space = self.composabl_sensor_space

                logger.info("Observation space extracted from policy")
                logger.info(f"  Filter keys: {self.filter_keys}")

            logger.info(f"✓ Ray Policy loaded successfully from {model_path}")
            logger.info(f"  Policy: {skill_name if skill_name in policies else 'default_policy'}")

        except Exception as e:
            logger.error(f"Failed to load Ray Policy from {model_path}: {e}")
            raise
