# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Union

import amesa_core.utils.logger as logger_util
import torch
from amesa_core.agent.skill import SkillSelector
from amesa_core.agent.skill.skill import Skill
import amesa_core.spaces as amesa_spaces
from ray.rllib.algorithms.ppo.torch.ppo_torch_rl_module import PPOTorchRLModule
from ray.rllib.core.rl_module.rl_module import RLModule, RLModuleConfig
from ray.rllib.policy.policy import Policy
from ray.rllib.policy.sample_batch import SampleBatch
from ray.rllib.utils.nested_dict import NestedDict
from ray.rllib.utils.torch_utils import FLOAT_MIN

from amesa_train.utils.space_utils import mask_all_zero, flatten_object_batch

logger = logger_util.get_logger(__name__)


def create_model_from_skill(skill: Union[Skill, SkillSelector], is_coordinated_population: bool = False):
    ckpt_path = skill.get_checkpoint_uri()
    if is_coordinated_population:
        policies = Policy.from_checkpoint(skill.get_checkpoint_uri())
        for policy_name, policy in policies.items():
            if policy_name in skill.get_name():
                return policy
        else:
            raise Exception(f"Policy {skill.get_name()} not found in checkpoint {ckpt_path}.")

    else:
        try:
            policy = Policy.from_checkpoint(ckpt_path)[skill.get_name()]
        except Exception:
            policy = Policy.from_checkpoint(ckpt_path)["default_policy"]
        return policy


class ActionMaskRLMBase(RLModule):
    def __init__(self, config: RLModuleConfig):
        if isinstance(config.observation_space, dict):
            config.observation_space = amesa_spaces.Dict(config.observation_space)
        if not isinstance(config.observation_space, amesa_spaces.Dict):
            config.observation_space = amesa_spaces.Dict(
                {
                    "observation": config.observation_space
                }
            )
        # We need to adjust the observation space for this RL Module so that, when
        # building the default models, the RLModule does not "see" the action mask but
        # only the original observation space without the action mask. This tricks it
        # into building models that are compatible with the original observation space.
        config.observation_space = config.observation_space["observation"]
        # The PPORLModule, in its constructor, will build models for the modified
        # observation space.
        super().__init__(config)


class TorchActionMask(ActionMaskRLMBase, PPOTorchRLModule):
    def _forward_inference(self, batch, **kwargs):
        return mask_forward_fn_torch(super()._forward_inference, batch, **kwargs)

    def _forward_train(self, batch, *args, **kwargs):
        return mask_forward_fn_torch(super()._forward_train, batch, **kwargs)

    def _forward_exploration(self, batch, *args, **kwargs):
        return mask_forward_fn_torch(super()._forward_exploration, batch, **kwargs)


def mask_forward_fn_torch(forward_fn, batch, **kwargs):
    # _check_batch(batch)
    if "action_mask" not in batch[SampleBatch.OBS]:
        # Can't action mask without an action mask.

        # Modify the incoming batch so that the default models can compute logits and
        # values as usual.
        batch[SampleBatch.OBS] = batch[SampleBatch.OBS]["observation"]
        return forward_fn(batch, **kwargs)

    # Extract the available actions tensor from the observation.
    action_mask = batch[SampleBatch.OBS]["action_mask"]

    # Modify the incoming batch so that the default models can compute logits and
    # values as usual.
    batch[SampleBatch.OBS] = batch[SampleBatch.OBS]["observation"]
    outputs = forward_fn(batch, **kwargs)

    # Mask logits
    logits = outputs[SampleBatch.ACTION_DIST_INPUTS]

    if isinstance(action_mask, (tuple, dict, NestedDict)):
        flat_mask = flatten_object_batch(action_mask)
        action_mask = torch.reshape(flat_mask, shape=logits.shape)

    if mask_all_zero(action_mask):
        # If the action mask is all zero, then we should not mask the logits.
        # Ray passes in all zeros for env validator
        return outputs

    # Convert action_mask into a [0.0 || -inf]-type mask.
    inf_mask = torch.clamp(torch.log(action_mask), min=FLOAT_MIN)

    masked_logits = logits + inf_mask

    # Replace original values with masked values.
    outputs[SampleBatch.ACTION_DIST_INPUTS] = masked_logits
    return outputs


def _check_batch(batch):
    """Check whether the batch contains the required keys."""
    if "action_mask" not in batch[SampleBatch.OBS]:
        raise ValueError(
            "Action mask not found in observation. This model requires "
            "the environment to provide observations that include an "
            "action mask (i.e. an observation space of the Dict space "
            "type that looks as follows: \n"
            "{'action_mask': Box(0.0, 1.0, shape=(self.action_space.n,)),"
            "'observation': <observation_space>}"
        )
    if "observation" not in batch[SampleBatch.OBS]:
        raise ValueError(
            "Observations not found in observation. This model requires "
            "the environment to provide observations that include a "
            " (i.e. an observation space of the Dict space "
            "type that looks as follows: \n"
            "{'action_mask': Box(0.0, 1.0, shape=(self.action_space.n,)),"
            "'observation': <observation_space>}"
        )
