# Amesa

Amesa helps you build Autonomous Agents! Through an easy SDK you get access to outscaled simulator training tools.

## Licenses / Seats

Amesa is an enterprise platform and requires an API key to use.

We offer 3 types of licenses:

- **Enterprise:** for enterprise projects and agent creations
- **Personal:** for personal usage and testing (typically offered to System Integrators)
- **Trial:** validate the Amesa platform (requires sales contact person)

One key is needed per user (seat-based licensing)

You can request an API Key through the following methods:

- [Discord](https://discord.gg/EQ3BgJt9NC)
- [Mail](mailto:sales@amesa.com?subject=REQUEST%20API%20KEY%20-%20COMPANY_NAME%20-%20NAME&body=Hi%2C%0D%0A%0D%0AI%20would%20like%20to%20request%20an%20API%20key%20for%20my%20company%20to%20get%20started%20with%20Amesa.%0D%0A%0D%0A*%20Company%20Name%3A%20COMPANY_NAME%0D%0A*%20Seats%3A%20NO_OF_SEATS%0D%0A*%20License%20Type%3A%20Enterprise%20%7C%20Personal%20%7C%20Trial%20%28keep%20what%20is%20required%29%0D%0A%0D%0AKind%20Regards%2C%0D%0ANAME%0D%0AFUNCTION)

## Getting Started

1. Download the Amesa SDK: `pip install amesa`
2. Request an API Key
3. Get a simulator or use one of the [prebuilt ones](https://hub.docker.com/u/composabl)
4. Create an Agent or see our [examples](https://github.com/Amesa/examples.amesa.com)
