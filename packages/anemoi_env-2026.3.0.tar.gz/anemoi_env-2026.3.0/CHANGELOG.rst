=========
Changelog
=========

Version 2026.3.0 (2026-03-01)
=============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.34``
* **anemoi-graphs**: ``0.8.5``
* **anemoi-inference**: ``0.9.1``
* **anemoi-models**: ``0.12.1``
* **anemoi-registry**: ``0.2.4``
* **anemoi-training**: ``0.9.1``
* **anemoi-transform**: ``0.1.27``
* **anemoi-utils**: ``0.5.0``

Version 2026.2.0 (2026-02-01)
=============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.29``
* **anemoi-graphs**: ``0.8.4``
* **anemoi-inference**: ``0.9.0``
* **anemoi-models**: ``0.12.0``
* **anemoi-registry**: ``0.2.4``
* **anemoi-training**: ``0.9.0``
* **anemoi-transform**: ``0.1.19``
* **anemoi-utils**: ``0.4.43``

Version 2026.1.0 (2026-01-01)
=============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.28``
* **anemoi-graphs**: ``0.8.1``
* **anemoi-inference**: ``0.8.3``
* **anemoi-models**: ``0.11.2``
* **anemoi-registry**: ``0.2.3``
* **anemoi-training**: ``0.8.1``
* **anemoi-transform**: ``0.1.19``
* **anemoi-utils**: ``0.4.40``

Version 2025.12.0 (2025-12-01)
==============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.28``
* **anemoi-graphs**: ``0.7.2``
* **anemoi-inference**: ``0.8.2``
* **anemoi-models**: ``0.10.0``
* **anemoi-registry**: ``0.2.3``
* **anemoi-training**: ``0.7.0``
* **anemoi-transform**: ``0.1.19``
* **anemoi-utils**: ``0.4.39``

Version 2025.11.1 (2025-11-12)
==============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.28``
* **anemoi-graphs**: ``0.7.1``
* **anemoi-inference**: ``0.8.1``
* **anemoi-models**: ``0.9.7``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.7``
* **anemoi-transform**: ``0.1.19``
* **anemoi-utils**: ``0.4.38``

Version 2025.11.0 (2025-11-01)
==============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.28``
* **anemoi-graphs**: ``0.7.1``
* **anemoi-inference**: ``0.8.0``
* **anemoi-models**: ``0.9.7``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.7``
* **anemoi-transform**: ``0.1.17``
* **anemoi-utils**: ``0.4.38``

Version 2025.10.1 (2025-10-17)
==============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.27``
* **anemoi-graphs**: ``0.7.0``
* **anemoi-inference**: ``0.8.0``
* **anemoi-models**: ``0.9.6``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.6``
* **anemoi-transform**: ``0.1.17``
* **anemoi-utils**: ``0.4.37``

Version 2025.10 (2025-10-13)
============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.27``
* **anemoi-graphs**: ``0.7.0``
* **anemoi-inference**: ``0.7.3``
* **anemoi-models**: ``0.9.6``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.6``
* **anemoi-transform**: ``0.1.17``
* **anemoi-utils**: ``0.4.37``
