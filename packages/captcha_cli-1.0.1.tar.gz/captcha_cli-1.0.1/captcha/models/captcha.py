from pydantic import BaseModel


class TextNoise(BaseModel):
    angle: tuple[int, int]
    lines: tuple[int, int]
    dots: tuple[int, int]
    amplitude: int | None
    wavelength: int | None

class AudioNoise(BaseModel):
    white_noise_loudness: tuple[int, int] | None # negative
    pitch_shift: tuple[float, float] | None

