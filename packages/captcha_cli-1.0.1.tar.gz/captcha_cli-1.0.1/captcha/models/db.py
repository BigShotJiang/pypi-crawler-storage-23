from datetime import datetime
from typing import Literal
from uuid import uuid4

from sqlmodel import Column, Field, SQLModel, String, func


class Captcha(SQLModel, table=True):
    __tablename__ = "captcha"  # type: ignore

    id: str = Field(default_factory=lambda: uuid4().__str__(), primary_key=True)
    type: Literal["text", "audio"] = Field(sa_column=Column(String))
    answer: str

    created_at: datetime = Field(default=..., sa_column_kwargs={"server_default": func.now()})
