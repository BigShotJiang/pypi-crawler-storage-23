import functools
from typing import Awaitable, Callable, Literal, TypeVar, Union

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlmodel import SQLModel, col, delete, select

from captcha.lib.env import DB_URL
from captcha.models.db import Captcha

engine = create_async_engine(str(DB_URL))
session_maker = async_sessionmaker(engine, expire_on_commit=False)


async def init():
    async with engine.connect() as connection:
        await connection.run_sync(SQLModel.metadata.create_all)

T = TypeVar("T")


def with_session(func: Callable[..., Awaitable[T]]):
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        session_key: str = next(
            key
            for key, val in func.__annotations__.items()
            if val is AsyncSession
            or (
                hasattr(val, "__origin__")
                and val.__origin__ is Union
                and hasattr(val, "__args__")
                and AsyncSession in val.__args__
            )
        )
        session: AsyncSession | None
        try:
            session = kwargs.get(session_key) or next(
                val for val in args if isinstance(val, AsyncSession)
            )
        except StopIteration:
            session = None

        if session:
            return await func(*args, **kwargs)
        else:
            async with session_maker() as session:
                return await func(*args, **{**kwargs, session_key: session})

    return wrapper

@with_session
async def insert_captcha(type: Literal["text", "audio"], answer: str, session: AsyncSession):
    captcha = Captcha(type=type, answer=answer)
    session.add(captcha)
    await session.commit()
    return captcha

@with_session
async def get_captcha(id: str, session: AsyncSession):
    statement = select(Captcha).where(Captcha.id == id)
    return (await session.execute(statement)).scalar()


@with_session
async def get_captchas(session: AsyncSession):
    statement = select(Captcha)
    return list((await session.execute(statement)).scalars().all())


@with_session
async def delete_captcha(id: str, session: AsyncSession):
    statement = delete(Captcha).where(col(Captcha.id) == id)
    await session.execute(statement)
    await session.commit()
    return
