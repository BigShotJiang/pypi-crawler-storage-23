from os import getenv
from sys import exit

from captcha.lib.logger import error, warn

default_APP_LEVEL = "simple"
try:
    import sqlalchemy  # noqa: F401
    import sqlmodel  # noqa: F401
    default_APP_LEVEL = "manage"
except ImportError:
    ...

try:
    import fastapi  # noqa: F401
    import uvicorn  # noqa: F401
    default_APP_LEVEL = "api"
except ImportError:
    ...

APP_LEVEL = getenv("APP_LEVEL", default_APP_LEVEL).lower()
if APP_LEVEL not in ["simple", "manage", "api"]:
    error("APP_LEVEL must be either simple, manage or api")
    exit(1)

USE_STORAGE = APP_LEVEL in ["manage", "api"]
if USE_STORAGE:
    try:
        import sqlmodel  # noqa: F401

    except ImportError:
        error("APP_LEVEL is manage or api, but can't find sqlmodel")
        exit(1)

if APP_LEVEL == "api":
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401

    except ImportError:
        error("APP_LEVEL is api, but can't find fastapi or uvicorn")
        exit(1)


DB_URL = getenv("DB_URL")
if USE_STORAGE and DB_URL is None:
    warn("APP_LEVEL is manage or api but can't find db url, using default db")
    DB_URL = "sqlite+aiosqlite:///file/db.sqlite"

ALLOW_GET_ANSWER = getenv("ALLOW_GET_ANSWER", "false").lower() in [
    "true",
    "yes",
    "on",
    "1",
]

HOST = getenv("HOST", "127.0.0.1")
PORT = int(getenv("PORT", "8000"))