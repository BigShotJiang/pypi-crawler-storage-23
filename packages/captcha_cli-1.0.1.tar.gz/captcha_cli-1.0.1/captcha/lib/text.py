import json
from importlib.resources import as_file, files
from typing import Any

from PIL import ImageFont
from PIL.ImageDraw import ImageDraw

from captcha.models.captcha import TextNoise

WIDTH = 550
HEIGHT = 150

W_NOISE_BOUNDING = int(WIDTH * 0.01)
H_NOISE_BOUNDING = int(HEIGHT * 0.05)

assets_dir = files("captcha") / "assets"
font_path = (assets_dir / "fonts" / "GoogleSans.ttf")

with as_file(font_path) as path:
    FONT = ImageFont.truetype(path, 100)
ImageDraw.font = FONT

text_json = assets_dir / "settings" / "text.json"
json_obj: dict[str, Any] = json.loads(text_json.read_text())
TEXT_NOISES: dict[str, TextNoise] = {
    ind: TextNoise.model_validate(val) for ind, val in json_obj.items()
}
