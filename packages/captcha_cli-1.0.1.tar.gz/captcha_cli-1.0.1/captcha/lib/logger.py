import click


def warn(log: str):
    return print(click.style("WARN   ", fg="yellow"), log)


def error(log: str):
    return print(click.style("ERROR  ", fg="red"), log)


def note(log: str):
    return print(click.style("Note   ", fg="blue"), log)


def success(log: str):
    return print(click.style("SUCCESS", fg="green"), log)
