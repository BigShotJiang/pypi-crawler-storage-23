import os
from importlib.resources import as_file
from importlib.resources.abc import Traversable


def create_if_not_exist(file: Traversable):
    with as_file(file) as path:
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
    return file
