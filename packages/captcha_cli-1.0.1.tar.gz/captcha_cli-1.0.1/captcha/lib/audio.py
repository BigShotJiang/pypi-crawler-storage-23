import json
from importlib.resources import files
from string import ascii_lowercase, digits
from typing import Any

from pydub import AudioSegment

from captcha.models.captcha import AudioNoise

assets_dir = files("captcha") / "assets"
audios: dict[str, AudioSegment] = {
    letter: AudioSegment((assets_dir / "voices" / f"{letter}.wav").read_bytes())
    for letter in ascii_lowercase + digits
}

audio_json = assets_dir / "settings" / "audio.json"
json_obj: dict[str, Any] = json.loads(audio_json.read_text())
AUDIO_NOISES: dict[str, AudioNoise] = {
    ind: AudioNoise.model_validate(val) for ind, val in json_obj.items()
}
