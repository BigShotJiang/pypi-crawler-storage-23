try:
    from fastapi import FastAPI, HTTPException, status
except ImportError:
    print("FastAPI is not installed")
    import sys

    sys.exit(1)

from base64 import b64encode
from importlib.metadata import version
from importlib.resources import as_file
from random import choices
from string import ascii_lowercase, digits
from typing import Literal

from fastapi.responses import FileResponse
from pydantic import BaseModel

from captcha.generator import audio_dir, generate_audio, generate_text, text_dir
from captcha.lib.db import get_captcha as get_captcha_
from captcha.lib.env import ALLOW_GET_ANSWER, APP_LEVEL
from captcha.models.db import Captcha

if APP_LEVEL != "api":
    print("APP_LEVEL is not api, thus, api is not enable")
    sys.exit(1)

app = FastAPI(
    title="Simple Captcha Generator",
    description="A simple Captcha generator",
    license_info={"name": "MIT", "identifier": "MIT"},
    version=version("captcha"),
)


async def get_captcha(id: str):
    captcha = await get_captcha_(id)
    if captcha is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="captcha not found"
        )
    return captcha


class CaptchaOmitAnswer(BaseModel):
    id: str
    type: Literal["text", "audio"]


class CaptchaWithData(CaptchaOmitAnswer):
    data: str | None


class CaptchaAnswer(BaseModel):
    status: Literal["wrong", "accepted"]


@app.post(
    "/captcha",
    description="generate new captcha",
    operation_id="generate",
    response_model=CaptchaWithData,
)
async def generate(
    type: Literal["text", "audio"],
    noise_level: str,
    text: str | None = None,
    include_data: bool = True,
):
    generate_func = None
    if type == "audio":
        generate_func = generate_audio
    else:
        generate_func = generate_text

    text = text or "".join(choices(ascii_lowercase + digits, k=6))
    _, captcha = await generate_func(text, noise_level)
    if captcha is None:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="APP_LEVEL is not api"
        )

    if not include_data:
        return CaptchaWithData(id=captcha.id, type=captcha.type, data=None)

    if type == "text":
        file = text_dir / f"{captcha.id}.jpg"
        data_uri = "data:image/jpeg;base64,"
    elif type == "audio":
        file = audio_dir / f"{captcha.id}.wav"
        data_uri = "data:audio/wav;base64,"

    with as_file(file) as path:
        with open(path, "rb") as file:
            data = b64encode(file.read()).decode("utf-8")

    return CaptchaWithData(id=captcha.id, type=captcha.type, data=data_uri + data)


@app.post(
    "/solve",
    description="solve the captcha",
    operation_id="solve",
    response_model=CaptchaAnswer,
)
async def solve(id: str, answer: str):
    captcha = await get_captcha(id)

    if captcha != answer:
        return CaptchaAnswer(status="wrong")
    else:
        return CaptchaAnswer(status="accepted")


@app.get(
    "/captcha",
    description="Get Captcha information",
    operation_id="get_captcha",
    response_model=CaptchaOmitAnswer | Captcha,
)
async def get_captcha_api(id: str, with_answer: bool = False):
    captcha = await get_captcha(id)
    if with_answer:
        if not ALLOW_GET_ANSWER:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="you are not allow to get answer",
            )
        else:
            return captcha
    else:
        return CaptchaOmitAnswer(id=captcha.id, type=captcha.type)


@app.get(
    "/captcha/file",
    description="Get Captcha image or audio file",
    operation_id="get_captcha_file",
)
async def get_captcha_file(id: str):
    captcha = await get_captcha(id)

    if captcha.type == "text":
        file = text_dir / f"{captcha.id}.jpg"
    elif captcha.type == "audio":
        file = audio_dir / f"{captcha.id}.wav"
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"invalid type {captcha.type}",
        )

    with as_file(file) as path:
        return FileResponse(path)
