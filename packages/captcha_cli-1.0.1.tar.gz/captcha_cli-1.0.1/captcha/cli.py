# Check env first
from captcha.lib.env import APP_LEVEL, HOST, PORT, USE_STORAGE  # noqa: F401, I001

import asyncio
from importlib.resources import as_file, files
from importlib.resources.abc import Traversable
from json import dump as json_dump
from random import choices
from string import ascii_lowercase, digits
from typing import Any, List, Mapping

import click
from prettytable import PrettyTable
from pydantic import BaseModel
from pydub.playback import play

from captcha.lib.audio import AUDIO_NOISES
from captcha.lib.text import TEXT_NOISES
from captcha.lib.logger import error, note, success
from captcha.generator import generate_audio, generate_text
from captcha.models.captcha import AudioNoise, TextNoise


def dumps(file_path: Traversable, models: Mapping[str, BaseModel]):
    with as_file(file_path) as path:
        with open(path, "w") as file:
            obj = {key: val.model_dump() for key, val in models.items()}
            json_dump(obj, file, indent=4)


@click.group(
    help="a simple captcha generator",
    context_settings={"help_option_names": ["-h", "--help"]},
)
def cli():
    pass


@cli.group(help="add new setting")
def add():
    pass


@add.command(help="add a new setting for text captcha generation")
@click.option("-L", "--level", type=str, required=True, help="level")
@click.option(
    "-a",
    "--angle",
    type=(int, int),
    required=True,
    help="text rotation angle, must include 2 int",
)
@click.option(
    "-l",
    "--lines",
    type=(int, int),
    required=True,
    help="upper bound and lower bound of how many lines will be on the image, must include 2 int",
)
@click.option(
    "-d",
    "--dots",
    type=(int, int),
    required=True,
    help="upper bound and lower bound of how many dots will be on the image, must include 2 int",
)
@click.option(
    "-A",
    "--amplitude",
    type=int,
    default=None,
    help="the amplitude of distortion",
)
@click.option(
    "-w",
    "--wavelength",
    type=int,
    default=None,
    help="the wavelength of distortion",
)
def text(
    level: str,
    angle: tuple[int, int],
    lines: tuple[int, int],
    dots: tuple[int, int],
    amplitude: int | None,
    wavelength: int | None,
):
    if level in TEXT_NOISES.keys():
        error(f"Level '{level}' is already existed")
        note(f"Use command 'captcha delete -t text -l {level}' to delete this level")
        return

    TEXT_NOISES[level] = TextNoise(
        angle=angle, lines=lines, dots=dots, amplitude=amplitude, wavelength=wavelength
    )

    dumps(files("captcha") / "assets" / "settings" / "text.json", TEXT_NOISES)

    success(f"Created level {level}")


@add.command(help="add a new setting for audio captcha generation")
@click.option("-l", "-L", "--level", type=str, required=True, help="level")
@click.option(
    "-w",
    "--white-noise",
    type=(int, int),
    default=None,
    help="the upper bound and lower bound of the loudness of the white noise, should be negative (-35 is very quiet, 0 is super dupper loud), must include 2 int, can be none",
)
@click.option(
    "-p",
    "--pitch-shift",
    type=(int, int),
    required=True,
    help="upper bound and lower bound of the pitch shift of individual character, must include 2 int, can be none",
)
def audio(
    level: str, white_noise: tuple[int, int] | None, pitch_shift: tuple[int, int] | None
):

    if level in AUDIO_NOISES.keys():
        error(f"Level '{level}' is already existed")
        note(f"Use command 'captcha delete -t audio -l {level}' to delete this level")
        return

    AUDIO_NOISES[level] = AudioNoise(
        white_noise_loudness=white_noise, pitch_shift=pitch_shift
    )

    dumps(files("captcha") / "assets" / "settings" / "audio.json", AUDIO_NOISES)

    success(f"Created level {level}")


@cli.command(help="delete a setting")
@click.option(
    "-t",
    "--type",
    type=click.Choice(["text", "audio"]),
    required=True,
    help="captcha type",
)
@click.option("-l", "--level", type=str, required=True, help="setting level")
def delete(type: str, level: str):
    obj = {}
    path = "assets/settings/"
    match type:
        case "text":
            obj = TEXT_NOISES
            path += "text.json"
        case "audio":
            obj = AUDIO_NOISES
            path += "audio.json"
        case _:
            error("type is invalid")
            return

    if level not in obj.keys():
        error(f"Level '{level}' doesn't exist")
        return

    del obj[level]
    dumps(files("captcha") / path, obj)

    success(f"Deleted level {level}")


@cli.command(name="list", help="list all captcha settings")
@click.option(
    "-t",
    "--type",
    type=click.Choice(["text", "audio"]),
    required=True,
    help="captcha type",
)
def list_settings(type: str):
    table = PrettyTable()
    match type:
        case "text":
            obj = TEXT_NOISES
        case "audio":
            obj = AUDIO_NOISES
        case _:
            error("type is invalid")
            return

    columns: dict[str, List[Any]] = {"level": []}
    for key, item in obj.items():
        columns["level"].append(key)
        for field in item.__class__.model_fields.keys():
            if field not in columns:
                columns[field] = []
            columns[field].append(getattr(item, field))

    for key, val in columns.items():
        table.add_column(key, val)

    print(table)
    pass


@cli.command(help="generate a captcha")
@click.option(
    "-t",
    "--type",
    type=click.Choice(["text", "audio"]),
    required=True,
    help="captcha type",
)
@click.option("-l", "-L", "--level", type=str, required=True, help="level")
@click.option("--text", type=str, required=False, help="text to be generated")
@click.option(
    "-k",
    "--length",
    type=int,
    required=False,
    help="the length of the text to be generated",
)
@click.option(
    "-p", "--preview", type=bool, default=False, help="preview the captcha", is_flag=True
)
def generate(type: str, level: str, text: str | None, length: int | None, preview: bool):
    if preview is False and not USE_STORAGE:
        error("preview must be true or APP_LEVEL must be manage or api")
        return

    if text is None and length is None:
        error("text or length must be specified")
        return

    obj = None
    preview_func = None
    generate_func = None

    match type:
        case "text":
            obj = TEXT_NOISES
            generate_func = generate_text

            def preview_func_text(x):
                return x.show()

            preview_func = preview_func_text

        case "audio":
            obj = AUDIO_NOISES
            generate_func = generate_audio

            def preview_func_audio(x):
                return play(x)

            preview_func = preview_func_audio

        case _:
            error("type is invalid")
            return

    if level not in obj.keys():
        error("level not found")
        return

    if USE_STORAGE:
        from captcha.lib.db import init

        asyncio.run(init())

    text = text or "".join(choices(list(ascii_lowercase + digits), k=length or 0))
    captcha, _ = asyncio.run(generate_func(text, level))
    success("Done :D")

    if preview:
        preview_func(captcha)


@cli.command(help="get all captchas, only in manage or api app")
@click.option(
    "-t",
    "--type",
    type=click.Choice(["text", "audio", "both"]),
    default="both",
    help="captcha type",
)
def all(type: str):
    if not USE_STORAGE:
        error("this is not a manage or api app")
        note("set APP_LEVEL to 'manage' or 'api' to use this function")
        return

    from captcha.lib.db import get_captchas, init

    asyncio.run(init())

    captchas = asyncio.run(get_captchas())
    type_ = type
    captchas = (
        captchas if type == "both" else list(filter(lambda x: x.type == type_, captchas))
    )

    if not len(captchas):
        error("no captcha :(")
        return

    table = PrettyTable()
    table.field_names = ["id", "type", "answer", "created_at"]
    table.add_rows(
        [
            [captcha.id, captcha.type, captcha.answer, captcha.created_at]
            for captcha in captchas
        ]
    )

    print(table)


@cli.command(help="start api server")
@click.option("-p", "--port", type=int, default=HOST)
@click.option("-h", "--host", type=str, default=PORT)
def api(port: int, host: str):
    if APP_LEVEL != "api":
        error("APP_LEVEL has to be 'api' to use api")
        return

    try:
        import fastapi  # noqa: F401
        import uvicorn

    except ImportError:
        error("uvicorn and fastapi is not installed")
        return

    from captcha.api import app

    return uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    cli()
