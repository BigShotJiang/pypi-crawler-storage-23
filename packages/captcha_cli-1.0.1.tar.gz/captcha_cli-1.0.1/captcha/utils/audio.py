from pydub import AudioSegment


def pitch_shift(audio: AudioSegment, semitones: float) -> AudioSegment:
    factor = 2 ** (semitones / 12.0)
    shifted = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * factor)})
    return shifted.set_frame_rate(audio.frame_rate)