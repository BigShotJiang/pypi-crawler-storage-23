import numpy as np
from numpy.random import randint, uniform
from PIL import Image, ImageDraw

from captcha.lib.text import (
    FONT,
    H_NOISE_BOUNDING,
    HEIGHT,
    TEXT_NOISES,
    W_NOISE_BOUNDING,
    WIDTH,
)


def generate(
    text: str,
    noise_level: str,
):
    if noise_level not in TEXT_NOISES.keys():
        raise ValueError("noise is invalid")

    noise = TEXT_NOISES[noise_level]
    character_distance = WIDTH // (text.__len__() + 1)

    image = Image.new("RGB", (WIDTH, HEIGHT), "white")
    img_draw = ImageDraw.Draw(image)

    new_character_x = character_distance * (0.2 + uniform(-0.1, 0.1))
    for char in text:
        bbox = FONT.getbbox(char)
        text_width, text_height = bbox[2] - bbox[0], bbox[3] - bbox[1]
        text_image = Image.new(
            "RGBA", (int(text_width), int(text_height)), (255, 255, 255, 0)
        )
        text_draw = ImageDraw.Draw(text_image, "RGBA")
        text_draw.text((0, 0), char, "black", anchor="lt")

        text_image = text_image.rotate(
            randint(*noise.angle),
            expand=True,
            fillcolor=(255, 255, 255, 0),
        )
        bb = text_image.getbbox()  # bounding box of non-zero alpha
        if bb is not None:
            text_image = text_image.crop(bb)

        image.paste(
            text_image,
            (int(new_character_x), int(HEIGHT * (uniform(0, 0.4) + 0.1))),
        )

        new_character_x = (
            new_character_x
            + text_image.size[0]
            + character_distance * (0.3 + uniform(-0.05, 0.05))
        )

    for _ in range(randint(*noise.dots)):
        x = randint(W_NOISE_BOUNDING, WIDTH - W_NOISE_BOUNDING)
        y = randint(H_NOISE_BOUNDING, HEIGHT - H_NOISE_BOUNDING)

        r = randint(10, 255)
        g = randint(10, 255)
        b = randint(10, 255)
        a = randint(100, 255)

        radius = randint(1, 2)

        img_draw.circle((x, y), radius, (r, g, b, a))

    for _ in range(randint(*noise.lines)):
        x_0 = randint(W_NOISE_BOUNDING, WIDTH - W_NOISE_BOUNDING)
        y_0 = randint(H_NOISE_BOUNDING, HEIGHT - H_NOISE_BOUNDING)

        x_1 = randint(W_NOISE_BOUNDING, WIDTH - W_NOISE_BOUNDING)
        y_1 = randint(H_NOISE_BOUNDING, HEIGHT - H_NOISE_BOUNDING)

        r = randint(10, 255)
        g = randint(10, 255)
        b = randint(10, 255)
        a = randint(100, 255)

        img_draw.line(((x_0, y_0), (x_1, y_1)), (r, g, b, a), 3)

    if noise.amplitude and noise.wavelength:
        arr = np.array(image)

        for i in range(arr.shape[0]):
            offset = int(noise.amplitude * np.sin(2 * np.pi * i / noise.wavelength))
            arr[i] = np.roll(arr[i], offset, axis=0)

        image = Image.fromarray(arr)

    return image
