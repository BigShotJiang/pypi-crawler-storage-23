from importlib.resources import as_file
from pathlib import Path

from captcha.lib.env import USE_STORAGE
from captcha.lib.file import create_if_not_exist

from .audio import generate as generate_audio_
from .text import generate as generate_text_

file = Path("file")

text_dir = create_if_not_exist(file / "text")
audio_dir = create_if_not_exist(file / "audio")

async def generate_audio(text: str, noise_level: str):
    audio = generate_audio_(text, noise_level)
    captcha = None
    if USE_STORAGE:
        from captcha.lib.db import insert_captcha

        captcha = await insert_captcha(type="audio", answer=text)

        with as_file(audio_dir / f"{captcha.id}.wav") as path:
            audio.export(path, "wav")

    return audio, captcha


async def generate_text(text: str, noise_level: str):
    text_ = generate_text_(text, noise_level)
    captcha = None
    if USE_STORAGE:
        from captcha.lib.db import insert_captcha

        captcha = await insert_captcha(type="text", answer=text)

        with as_file(text_dir / f"{captcha.id}.jpg") as path:
            text_.save(path)

    return text_, captcha


__all__ = ["generate_audio", "generate_text"]
