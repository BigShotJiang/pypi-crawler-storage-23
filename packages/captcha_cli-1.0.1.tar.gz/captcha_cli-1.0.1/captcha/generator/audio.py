import re

from numpy.random import uniform
from pydub import AudioSegment
from pydub.generators import WhiteNoise

from captcha.lib.audio import AUDIO_NOISES, audios
from captcha.utils.audio import pitch_shift

text_re = re.compile(r"^([\w\d]+)$")


def generate(
    text: str,
    noise_level: str,
) -> AudioSegment:
    text = text.lower()

    if not text_re.match(text):
        raise ValueError("input should only contain a-z and 0-9")

    if noise_level not in AUDIO_NOISES.keys():
        raise ValueError("noise is invalid")

    audio_noise = AUDIO_NOISES[noise_level]
    speech = audios[text[0]]

    shifts = [uniform(*audio_noise.pitch_shift) for _ in text] if audio_noise.pitch_shift else None

    if shifts:  # apply speed for first character
        speech = pitch_shift(speech, shifts[0])

    for ind, character in enumerate(text[1:]):
        char_audio = audios[character]
        if shifts:
            char_audio = pitch_shift(char_audio, shifts[ind])
        speech = speech + char_audio

    speech = speech.apply_gain(-20 - speech.dBFS)

    if audio_noise.white_noise_loudness:
        volume = uniform(*audio_noise.white_noise_loudness)

        noise = WhiteNoise().to_audio_segment(
            duration=len(speech)
        )  # default is 44.1kHz mono

        # Set noise loudness to chosen level
        noise = noise.apply_gain(volume - noise.dBFS)

        # Ensure same format
        noise = noise.set_frame_rate(speech.frame_rate).set_channels(speech.channels)

        return speech.overlay(noise)

    return speech
