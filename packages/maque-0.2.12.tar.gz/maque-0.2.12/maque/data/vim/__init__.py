# vim configuration data
