"""GhostPC proactive notifications — system monitoring and scheduled alerts."""

from ghost_pc.notifications.engine import NotificationEngine

__all__ = ["NotificationEngine"]
