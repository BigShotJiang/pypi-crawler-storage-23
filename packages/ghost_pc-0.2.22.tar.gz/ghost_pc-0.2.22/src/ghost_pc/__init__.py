"""GhostPC — Control your Windows PC from WhatsApp with AI vision."""

__version__ = "0.2.22"

__all__ = ["__version__"]
