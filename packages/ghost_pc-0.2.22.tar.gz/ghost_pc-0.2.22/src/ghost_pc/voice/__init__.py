"""Voice control module for GhostPC.

Provides wake word detection, microphone capture, and integration
with Gemini Live API for hands-free desktop control.
"""
