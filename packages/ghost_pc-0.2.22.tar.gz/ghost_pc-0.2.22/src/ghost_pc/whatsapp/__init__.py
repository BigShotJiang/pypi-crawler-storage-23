"""GhostPC WhatsApp bridge — Baileys integration over JSON-RPC."""

from ghost_pc.whatsapp.bridge import BaileysBridge

__all__ = ["BaileysBridge"]
