"""GhostPC configuration."""

from ghost_pc.config.schema import CONFIG_PATH, GHOST_HOME, GhostConfig
from ghost_pc.config.settings import Settings

__all__ = ["CONFIG_PATH", "GHOST_HOME", "GhostConfig", "Settings"]
