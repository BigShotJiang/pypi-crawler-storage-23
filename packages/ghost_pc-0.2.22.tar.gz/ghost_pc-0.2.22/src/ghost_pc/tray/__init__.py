"""GhostPC system tray icon."""

from ghost_pc.tray.tray import GhostTray

__all__ = ["GhostTray"]
