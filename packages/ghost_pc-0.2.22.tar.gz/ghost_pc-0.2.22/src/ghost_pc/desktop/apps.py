"""Launch applications and manage windows on Windows.

Includes Electron accessibility detection — automatically enables
--force-renderer-accessibility for Electron apps when UIA inspection
returns insufficient controls.
"""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import TypedDict

logger = logging.getLogger(__name__)


class WindowInfo(TypedDict):
    hwnd: int
    title: str
    visible: bool


def is_electron_app(pid: int) -> bool:
    """Check if a process is an Electron app by looking for chrome_elf.dll.

    Electron apps bundle Chromium and can be detected by the presence of
    chrome_elf.dll in their loaded modules.

    Args:
        pid: Process ID to check.
    """
    if sys.platform != "win32":
        return False

    try:
        import psutil

        proc = psutil.Process(pid)
        exe_dir = proc.exe()
        if not exe_dir:
            return False

        import os

        exe_dir = os.path.dirname(exe_dir)
        # Check for chrome_elf.dll alongside the executable
        return os.path.exists(os.path.join(exe_dir, "chrome_elf.dll"))
    except Exception:
        return False


async def ensure_electron_accessibility(pid: int) -> bool:
    """Check if an Electron app has accessibility enabled and suggest restart if not.

    When UIA inspection returns few controls for an Electron app,
    it likely needs --force-renderer-accessibility to expose its UI.

    Args:
        pid: Process ID of the Electron app.

    Returns:
        True if accessibility appears to be enabled or if this isn't an Electron app.
    """
    if not is_electron_app(pid):
        return True

    try:
        import psutil

        proc = psutil.Process(pid)
        cmdline = proc.cmdline()

        # Check if accessibility flag is already present
        if any("--force-renderer-accessibility" in arg for arg in cmdline):
            return True

        # Accessibility not enabled — log a warning
        logger.info(
            "Electron app (PID %d) detected without accessibility. "
            "Restart with --force-renderer-accessibility for better UIA support.",
            pid,
        )
        return False
    except Exception:
        return True


async def open_app(name: str) -> dict[str, str]:
    """Launch an application by name.

    Tries common app names and falls back to shell start.
    """
    app_map: dict[str, str] = {
        "chrome": "chrome",
        "google chrome": "chrome",
        "firefox": "firefox",
        "edge": "msedge",
        "microsoft edge": "msedge",
        "notepad": "notepad",
        "calculator": "calc",
        "explorer": "explorer",
        "file explorer": "explorer",
        "cmd": "cmd",
        "command prompt": "cmd",
        "powershell": "powershell",
        "terminal": "wt",
        "windows terminal": "wt",
        "task manager": "taskmgr",
        "paint": "mspaint",
        "word": "winword",
        "excel": "excel",
        "outlook": "outlook",
        "vscode": "code",
        "visual studio code": "code",
        "spotify": "spotify",
        "slack": "slack",
        "discord": "discord",
        "teams": "teams",
    }

    exe = app_map.get(name.lower().strip(), name)

    if sys.platform == "win32":
        cmd = f'Start-Process "{exe}"'
        proc = await asyncio.create_subprocess_exec(
            "powershell",
            "-NoProfile",
            "-Command",
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            return {"status": "error", "message": stderr.decode("utf-8", errors="replace")}
        return {"status": "ok", "app": exe}
    else:
        return {"status": "error", "message": "App launching requires Windows"}


# --- Window management (Win32) ---


def list_windows() -> list[WindowInfo]:
    """List all visible windows with their titles and handles."""
    if sys.platform != "win32":
        return []

    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    results: list[WindowInfo] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _enum_callback(hwnd: int, _lparam: int) -> bool:
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        if title:
            results.append(WindowInfo(hwnd=hwnd, title=title, visible=True))
        return True

    user32.EnumWindows(_enum_callback, 0)
    return results


def focus_window(title: str) -> bool:
    """Bring a window to the foreground by partial title match.

    Returns True if a matching window was found and focused.
    """
    if sys.platform != "win32":
        return False

    import ctypes

    user32 = ctypes.windll.user32
    title_lower = title.lower()

    for win in list_windows():
        if title_lower in win["title"].lower():
            hwnd = win["hwnd"]
            # Restore if minimized (SW_RESTORE = 9)
            user32.ShowWindow(hwnd, 9)
            user32.SetForegroundWindow(hwnd)
            return True
    return False


def minimize_window(title: str | None = None) -> bool:
    """Minimize a window by title, or the foreground window if no title given."""
    if sys.platform != "win32":
        return False

    import ctypes

    user32 = ctypes.windll.user32

    if title:
        for win in list_windows():
            if title.lower() in win["title"].lower():
                user32.ShowWindow(win["hwnd"], 6)  # SW_MINIMIZE
                return True
        return False
    else:
        hwnd = user32.GetForegroundWindow()
        user32.ShowWindow(hwnd, 6)
        return True


def maximize_window(title: str | None = None) -> bool:
    """Maximize a window by title, or the foreground window if no title given."""
    if sys.platform != "win32":
        return False

    import ctypes

    user32 = ctypes.windll.user32

    if title:
        for win in list_windows():
            if title.lower() in win["title"].lower():
                user32.ShowWindow(win["hwnd"], 3)  # SW_MAXIMIZE
                return True
        return False
    else:
        hwnd = user32.GetForegroundWindow()
        user32.ShowWindow(hwnd, 3)
        return True


def close_window(title: str | None = None) -> bool:
    """Close a window by title, or the foreground window if no title given."""
    if sys.platform != "win32":
        return False

    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    wm_close = 0x0010

    if title:
        for win in list_windows():
            if title.lower() in win["title"].lower():
                user32.PostMessageW(wintypes.HWND(win["hwnd"]), wm_close, 0, 0)
                return True
        return False
    else:
        hwnd = user32.GetForegroundWindow()
        user32.PostMessageW(wintypes.HWND(hwnd), wm_close, 0, 0)
        return True
