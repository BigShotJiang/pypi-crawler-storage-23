"""GhostPC desktop control — screen capture, input injection, terminal, clipboard."""

__all__: list[str] = []
