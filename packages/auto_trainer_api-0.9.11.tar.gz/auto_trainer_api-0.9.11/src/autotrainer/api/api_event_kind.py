from dataclasses import dataclass
from enum import IntEnum
from typing import List

from typing_extensions import deprecated


class ApiEventKind(IntEnum):
    """
    0000-0999   Core/System
    1000-1999   Behavior
    2000-2999   Device
    3000-3999   Inference
    4000-4999   Analysis
    5000-5999   Training
    6000-6999   Detectors & Alarms
    9000-9999   Application
    """

    # Core/System
    emergencyStop = 101
    """Payload {"reason": <string>}"""
    emergencyResume = 102
    """Payload {"reason": <string>}"""

    applicationLaunched = 201
    applicationTerminating = 202

    acquisitionStarted = 301
    acquisitionEnded = 305
    calibrationDcsStarted = 310
    calibrationDcsEnded = 315
    calibration3dStarted = 320
    calibration3dEnded = 325

    propertyChanged = 501

    systemStatus = 601

    # Behavior
    algorithmPause = 1001
    algorithmResume = 1002

    tunnelEnter = 1101
    tunnelExit = 1102

    pelletLoadCan = 1201
    pelletLoadBegin = 1202
    pelletLoadEnd = 1203
    pelletSendCan = 1204
    pelletSendBegin = 1205
    pelletSendEnd = 1206
    pelletCoverCan = 1207
    pelletCoverBegin = 1208
    pelletCoverEnd = 1209
    pelletReleaseCan = 1210
    pelletReleaseBegin = 1211
    pelletReleaseEnd = 1212
    pelletHomeCan = 1213
    pelletHomeBegin = 1214
    pelletHomeEnd = 1215
    pelletPrereleaseCan = 1216
    pelletPrereleaseBegin = 1217
    pelletPrereleaseEnd = 1218
    pelletRetractCan = 1219
    pelletRetractBegin = 1220
    pelletRetractEnd = 1221
    pelletHomeResetBegin = 1222
    """Home reset that is performed every N cycles to handle small accumulations of drift"""
    pelletHomeResetEnd = 1223
    pelletDriftResetBegin = 1222
    """Home reset that is due to drift compensation being exceeded"""
    pelletDriftResetEnd = 1223
    pelletAcknowledgeToken = 1298
    pelletExternalToken = 1299

    sessionStarting = 1301
    sessionStarted = 1302
    sessionEnding = 1303
    sessionEnded = 1304
    sessionPelletIncrease = 1311
    sessionPelletDecrease = 1312
    sessionMouseSeen = 1321

    dayStarted = 1401
    dayIncreasePellet = 1411
    dayDecreasePellet = 1412

    pelletSeen = 1501
    pelletPresented = 1502
    pelletSuccessfulReach = 1503

    triangleSeen = 1550

    headfixBaselineChanged = 1601
    headfixLoadCellChanged = 1602
    headfixLoadCellChangedInIntersession = 1603
    headfixLoadCellChangedWrongState = 1604
    headfixAutoTare = 1611

    autoClampIntensityChanged = 1621
    autoClampReleaseToneFreqChanged = 1622
    autoClampReleaseDelayChanged = 1623

    intersessionSegmentationCan = 1701
    intersessionSegmentationBegin = 1702
    intersessionSegmentationEnd = 1703
    intersessionSegmentationNonceMismatch = 1704
    intersessionSegmentationError = 1705
    intersessionSegmentationSave = 1706
    intersessionSegmentationSaveError = 1707
    intersessionSegmentationInputError = 1708
    intersessionDetectionCan = 1711
    intersessionDetectionBegin = 1712
    intersessionDetectionEnd = 1713
    intersessionDetectionNonceMismatch = 1714
    intersessionDetectionError = 1715
    intersessionDetectionSave = 1716
    intersessionDetectionSaveError = 1717
    intersessionShiftX = 1731
    intersessionShiftY = 1732
    intersessionShiftZ = 1733

    headFixationForceDetectorChanged = 1801
    headFixationEnabled = 1802

    # Device
    deviceCommandSend = 2001
    deviceCommandAcknowledge = 2002

    # Analysis
    loadCellEngagedChanged = 4001
    headbarPressureEngagedChanged = 4011

    # Training
    trainingModeChanged = 5001
    """Payload {"training_mode": ApiTrainingMode}"""

    trainingPlanLoad = 5101
    """Payload {training_plan_id: <uuid of plan>}"""

    trainingPhaseEnter = 5201
    """Payload {"training_phase_id": <uuid of plan>}"""
    trainingPhaseExit = 5202
    """Payload {"training_phase_id": <uuid of plan>}"""

    trainingProgressUpdate = 5501

    # Detector/alarm
    detectorChanged = 6001
    """
    Payload {"detector_id": ApiDetectorKind, is_active: <boolean>, is_enabled: <boolean>}
    
    Sent when either of is_active or is_enabled changes.
    """

    alarmChanged = 6501
    """
    Payload {"detector_id": ApiAlarmKind, is_active: <boolean>, is_enabled: <boolean>}
    
    Sent when either of is_active or is_enabled changes.
    """


class ApiDetectorKind(IntEnum):
    frontDoor = 101
    slidingDoor = 102

    loadCellThrash = 201
    audioThrash = 202

    pelletMisplaced = 301

    deviceAckTimeOut = 401

    animalImmobile = 99999 # deprecated


class ApiAlarmKind(IntEnum):
    externalDoors = 101

    animalMissing = 201

    animalImmobile = 210

    thrashing = 301

@dataclass(frozen=True)
class ApiDetectorStatus:
    detector_id: ApiDetectorKind
    is_active: bool
    is_enabled: bool

@dataclass(frozen=True)
class ApiAlarmStatus:
    alarm_id: ApiAlarmKind
    is_active: bool
    is_enabled: bool

@dataclass(frozen=True)
class HeadFixStatus:
    currentMagnetIntensity: float
    baselineMagnetIntensity: float

@dataclass(frozen=True)
class PelletStatus:
    send_x: float
    send_y: float
    send_z: float

@dataclass(frozen=True)
class ApiSystemStatus:
    alarms: List[ApiAlarmStatus]
    detectors: List[ApiDetectorStatus]

    pellet: PelletStatus
    headfix: HeadFixStatus
