# jax-mlx: JAX PJRT plugin for Apple Silicon using MLX
#
# This package provides MLX acceleration for JAX via the PJRT plugin interface.
# Registration is handled automatically by plugin.py via JAX's plugin mechanism.

__version__ = "0.0.2"
