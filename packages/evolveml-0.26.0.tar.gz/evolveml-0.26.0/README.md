# evolveml 🚀

> A Python ML library that **evolves with your data.**  
> Batch + Real-time Learning + Latest 2026 AI Trends — no sklearn needed!

**Author: SAPPA VAMSI**

---

## Install

```bash
pip install evolveml
```

---

## What's Inside (v0.2.0)

### 🧠 Core Models
| Module | Description |
|---|---|
| `DecisionTreeClassifier` | Decision Tree from scratch |
| `LinearRegressionModel` | Linear Regression |
| `LogisticRegressionModel` | Logistic Regression + online updates |
| `NeuralNetwork` | Neural Network from scratch |

### 🔄 Real-time / Online Learning
| Module | Description |
|---|---|
| `StreamLearner` | Learns one sample at a time in real-time |

### 🎯 Ready-to-use Tasks
| Module | Description |
|---|---|
| `FraudDetector` | Real-time bank fraud detection |
| `ImageClassifier` | Image classification |
| `SpamDetector` | Email spam detection |
| `StockPredictor` | Stock price prediction |

### 🔥 Latest 2026 Trending Modules
| Module | Trend | Description |
|---|---|---|
| `AutoFeatureSelector` | **AutoML** | Auto-selects best features |
| `AnomalyDetector` | **Edge AI / IoT** | Detects anomalies in streams |
| `ConceptDriftDetector` | **Adaptive ML** | Detects data distribution changes |
| `ExplainableModel` | **XAI** | Explains WHY model predicted |
| `ReinforcementAgent` | **Agentic AI** | Q-Learning agent |
| `SentimentAnalyzer` | **NLP** | Real-time text sentiment |
| `TransferLearner` | **Transfer Learning** | Reuse knowledge across tasks |

---

## Quick Examples

### 🤖 AutoML - Auto Feature Selection
```python
from evolveml import AutoFeatureSelector
selector = AutoFeatureSelector(top_k=5)
X_best = selector.fit_transform(X_train, y_train)
selector.report()
```

### 🚨 Anomaly Detection (IoT/Edge)
```python
from evolveml import AnomalyDetector
detector = AnomalyDetector(threshold=2.5)
detector.fit(normal_data)
result = detector.detect(new_sensor_reading)
print(result)  # {'is_anomaly': True, 'status': '🚨 ANOMALY'}
```

### 📉 Concept Drift Detection
```python
from evolveml import ConceptDriftDetector
drift = ConceptDriftDetector()
for pred, actual in prediction_stream:
    status = drift.update(pred, actual)
    if status['drift_detected']:
        print("⚠️ Retrain your model!")
```

### 🔍 Explainable AI
```python
from evolveml import ExplainableModel, DecisionTreeClassifier
model = DecisionTreeClassifier()
model.fit(X_train, y_train)
xai = ExplainableModel(model, feature_names=['age', 'amount', 'hour'])
xai.fit(X_train, y_train)
xai.explain(X_test[0])
```

### 🎮 Reinforcement Learning Agent
```python
from evolveml import ReinforcementAgent
agent = ReinforcementAgent(n_states=100, n_actions=4)
action = agent.act(state)
agent.learn(state, action, reward=+1, next_state=next_state)
```

### 💬 Sentiment Analysis
```python
from evolveml import SentimentAnalyzer
analyzer = SentimentAnalyzer()
result = analyzer.analyze("This product is absolutely amazing!")
print(result)  # {'sentiment': 'POSITIVE 😊', 'confidence': 0.87}
analyzer.learn("brilliant", label='positive')  # teach new words
```

### 🔁 Transfer Learning
```python
from evolveml import TransferLearner, DecisionTreeClassifier
source = DecisionTreeClassifier()
source.fit(X_source, y_source)
transfer = TransferLearner(source)
transfer.fit(X_target, y_target)  # learns faster with less data!
```

---

## License
MIT — Free to use!