import numpy as np
from ..models.linear import LogisticRegressionModel

class StreamLearner:
    """
    Real-time / Online Stream Learner
    Learns from data one sample at a time.

    Usage:
        from evolveml import StreamLearner
        model = StreamLearner()
        # Feed data one by one
        for X, y in data_stream:
            prediction = model.predict_one(X)
            model.learn_one(X, y)
    """
    def __init__(self, lr=0.01):
        self.lr = lr
        self.weights = None
        self.bias = 0
        self.n_seen = 0

    def _sigmoid(self, z):
        return 1 / (1 + np.exp(-np.clip(z, -250, 250)))

    def learn_one(self, x, y):
        """Learn from a single sample"""
        x = np.array(x).flatten()
        if self.weights is None:
            self.weights = np.zeros(len(x))
        pred = self._sigmoid(x.dot(self.weights) + self.bias)
        error = pred - y
        self.weights -= self.lr * error * x
        self.bias -= self.lr * error
        self.n_seen += 1

    def predict_one(self, x):
        """Predict a single sample"""
        x = np.array(x).flatten()
        if self.weights is None:
            return 0
        return int(self._sigmoid(x.dot(self.weights) + self.bias) >= 0.5)

    def partial_fit(self, X, y):
        """Batch online update"""
        for xi, yi in zip(X, y):
            self.learn_one(xi, yi)
        return self

    def predict(self, X):
        return np.array([self.predict_one(x) for x in X])

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))