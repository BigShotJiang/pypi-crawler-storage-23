import numpy as np

class AnomalyDetector:
    """
    Real-time Anomaly Detection for IoT / Edge AI.
    Detects unusual patterns in streaming sensor data.

    Usage:
        from evolveml.anomaly import AnomalyDetector
        detector = AnomalyDetector(threshold=2.5)
        detector.fit(normal_data)
        result = detector.detect(new_sample)
    """
    def __init__(self, threshold=2.5):
        self.threshold = threshold
        self.mean_ = None
        self.std_ = None
        self.history = []

    def fit(self, X):
        X = np.array(X)
        self.mean_ = X.mean(axis=0)
        self.std_ = X.std(axis=0)
        self.std_[self.std_ == 0] = 1e-10
        print(f"✅ AnomalyDetector trained on {len(X)} samples")
        return self

    def _z_score(self, x):
        return np.abs((np.array(x) - self.mean_) / self.std_).mean()

    def detect(self, x):
        """Detect if a single sample is anomalous"""
        score = self._z_score(x)
        is_anomaly = score > self.threshold
        self.history.append({'score': score, 'anomaly': is_anomaly})
        return {
            'is_anomaly': bool(is_anomaly),
            'score': float(score),
            'threshold': self.threshold,
            'status': '🚨 ANOMALY' if is_anomaly else '✅ NORMAL'
        }

    def detect_batch(self, X):
        """Detect anomalies in batch"""
        return [self.detect(x) for x in np.array(X)]

    def update(self, x):
        """Online update - adapt to new normal patterns"""
        x = np.array(x)
        alpha = 0.05  # learning rate for mean/std update
        self.mean_ = (1 - alpha) * self.mean_ + alpha * x
        self.std_ = (1 - alpha) * self.std_ + alpha * np.abs(x - self.mean_)
        self.std_[self.std_ == 0] = 1e-10