import numpy as np

class AutoFeatureSelector:
    """
    AutoML - Automatically selects the best features from your dataset.
    No manual feature engineering needed!

    Usage:
        from evolveml.automl import AutoFeatureSelector
        selector = AutoFeatureSelector(top_k=10)
        selector.fit(X_train, y_train)
        X_selected = selector.transform(X_train)
    """
    def __init__(self, top_k=10):
        self.top_k = top_k
        self.selected_indices_ = None
        self.scores_ = None

    def _correlation_score(self, X, y):
        scores = []
        for i in range(X.shape[1]):
            col = X[:, i]
            if col.std() == 0:
                scores.append(0.0)
            else:
                corr = np.corrcoef(col, y)[0, 1]
                scores.append(abs(corr) if not np.isnan(corr) else 0.0)
        return np.array(scores)

    def fit(self, X, y):
        X, y = np.array(X), np.array(y)
        self.scores_ = self._correlation_score(X, y)
        k = min(self.top_k, X.shape[1])
        self.selected_indices_ = np.argsort(self.scores_)[::-1][:k]
        print(f"✅ AutoFeatureSelector: Selected top {k} features out of {X.shape[1]}")
        return self

    def transform(self, X):
        return np.array(X)[:, self.selected_indices_]

    def fit_transform(self, X, y):
        return self.fit(X, y).transform(X)

    def report(self):
        print("\n📊 Feature Importance Scores:")
        for rank, idx in enumerate(self.selected_indices_):
            print(f"  Rank {rank+1}: Feature[{idx}] → Score: {self.scores_[idx]:.4f}")