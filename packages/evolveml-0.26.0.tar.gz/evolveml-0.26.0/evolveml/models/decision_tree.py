import numpy as np

class DecisionNode:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value

class DecisionTreeClassifier:
    """
    Decision Tree Classifier - Batch Learning
    
    Usage:
        from evolveml import DecisionTreeClassifier
        model = DecisionTreeClassifier(max_depth=10)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        print(model.score(X_test, y_test))
    """
    def __init__(self, max_depth=10, min_samples_split=2):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root = None

    def fit(self, X, y):
        X, y = np.array(X), np.array(y)
        self.classes_ = np.unique(y)
        self.root = self._build_tree(X, y, depth=0)
        return self

    def _build_tree(self, X, y, depth):
        n_samples, n_features = X.shape
        if (depth >= self.max_depth or n_samples < self.min_samples_split or len(np.unique(y)) == 1):
            return DecisionNode(value=self._most_common(y))
        best_feature, best_threshold = self._best_split(X, y, n_features)
        if best_feature is None:
            return DecisionNode(value=self._most_common(y))
        left_idx = X[:, best_feature] <= best_threshold
        left = self._build_tree(X[left_idx], y[left_idx], depth + 1)
        right = self._build_tree(X[~left_idx], y[~left_idx], depth + 1)
        return DecisionNode(feature=best_feature, threshold=best_threshold, left=left, right=right)

    def _best_split(self, X, y, n_features):
        best_gain, best_feature, best_threshold = -1, None, None
        features = np.random.choice(n_features, min(n_features, 20), replace=False)
        for feature in features:
            for threshold in np.unique(X[:, feature])[:10]:
                gain = self._info_gain(y, X[:, feature], threshold)
                if gain > best_gain:
                    best_gain, best_feature, best_threshold = gain, feature, threshold
        return best_feature, best_threshold

    def _info_gain(self, y, col, threshold):
        parent = self._entropy(y)
        left, right = y[col <= threshold], y[col > threshold]
        if len(left) == 0 or len(right) == 0:
            return 0
        n = len(y)
        return parent - (len(left)/n * self._entropy(left) + len(right)/n * self._entropy(right))

    def _entropy(self, y):
        counts = np.bincount(y.astype(int))
        probs = counts[counts > 0] / len(y)
        return -np.sum(probs * np.log2(probs))

    def _most_common(self, y):
        return np.bincount(y.astype(int)).argmax()

    def predict(self, X):
        return np.array([self._traverse(x, self.root) for x in np.array(X)])

    def _traverse(self, x, node):
        if node.value is not None:
            return node.value
        if x[node.feature] <= node.threshold:
            return self._traverse(x, node.left)
        return self._traverse(x, node.right)

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))