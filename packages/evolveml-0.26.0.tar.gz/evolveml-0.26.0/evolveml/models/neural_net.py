import numpy as np

class NeuralNetwork:
    """
    Simple Neural Network - Batch + Online Learning

    Usage:
        from evolveml import NeuralNetwork
        model = NeuralNetwork(layers=[64, 32, 16], output=3)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
    """
    def __init__(self, layers=[64, 32], output=2, lr=0.01, epochs=100):
        self.layers = layers
        self.output = output
        self.lr = lr
        self.epochs = epochs
        self.weights = []
        self.biases = []

    def _relu(self, z): return np.maximum(0, z)
    def _relu_deriv(self, z): return (z > 0).astype(float)
    def _softmax(self, z):
        e = np.exp(z - np.max(z, axis=1, keepdims=True))
        return e / e.sum(axis=1, keepdims=True)

    def _init_weights(self, input_size):
        sizes = [input_size] + self.layers + [self.output]
        self.weights = [np.random.randn(sizes[i], sizes[i+1]) * 0.1
                        for i in range(len(sizes)-1)]
        self.biases = [np.zeros((1, sizes[i+1]))
                       for i in range(len(sizes)-1)]

    def _forward(self, X):
        self.activations = [X]
        for i, (w, b) in enumerate(zip(self.weights, self.biases)):
            z = self.activations[-1].dot(w) + b
            a = self._relu(z) if i < len(self.weights)-1 else self._softmax(z)
            self.activations.append(a)
        return self.activations[-1]

    def fit(self, X, y):
        X, y = np.array(X), np.array(y).astype(int)
        if not self.weights:
            self._init_weights(X.shape[1])
        n_classes = max(self.output, y.max()+1)
        for _ in range(self.epochs):
            out = self._forward(X)
            y_oh = np.eye(n_classes)[y]
            delta = (out - y_oh) / len(X)
            for i in reversed(range(len(self.weights))):
                dw = self.activations[i].T.dot(delta)
                db = delta.sum(axis=0, keepdims=True)
                if i > 0:
                    delta = delta.dot(self.weights[i].T) * self._relu_deriv(self.activations[i])
                self.weights[i] -= self.lr * dw
                self.biases[i] -= self.lr * db
        return self

    def predict(self, X):
        return np.argmax(self._forward(np.array(X)), axis=1)

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))