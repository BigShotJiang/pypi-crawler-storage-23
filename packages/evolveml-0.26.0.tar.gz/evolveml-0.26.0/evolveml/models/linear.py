import numpy as np

class LinearRegressionModel:
    """
    Linear Regression - Batch Learning

    Usage:
        from evolveml import LinearRegressionModel
        model = LinearRegressionModel()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
    """
    def __init__(self, lr=0.01, epochs=1000):
        self.lr = lr
        self.epochs = epochs
        self.weights = None
        self.bias = 0

    def fit(self, X, y):
        X, y = np.array(X), np.array(y)
        n, f = X.shape
        self.weights = np.zeros(f)
        for _ in range(self.epochs):
            y_pred = X.dot(self.weights) + self.bias
            self.weights -= self.lr * (2/n) * X.T.dot(y_pred - y)
            self.bias -= self.lr * (2/n) * np.sum(y_pred - y)
        return self

    def predict(self, X):
        return np.array(X).dot(self.weights) + self.bias


class LogisticRegressionModel:
    """
    Logistic Regression - Batch + Online Learning

    Usage:
        from evolveml import LogisticRegressionModel
        model = LogisticRegressionModel()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        # Online update:
        model.partial_fit(X_new, y_new)
    """
    def __init__(self, lr=0.01, epochs=1000):
        self.lr = lr
        self.epochs = epochs
        self.weights = None
        self.bias = 0

    def _sigmoid(self, z):
        return 1 / (1 + np.exp(-np.clip(z, -250, 250)))

    def fit(self, X, y):
        X, y = np.array(X), np.array(y)
        n, f = X.shape
        self.weights = np.zeros(f)
        for _ in range(self.epochs):
            y_pred = self._sigmoid(X.dot(self.weights) + self.bias)
            self.weights -= self.lr * X.T.dot(y_pred - y) / n
            self.bias -= self.lr * np.sum(y_pred - y) / n
        return self

    def partial_fit(self, X, y):
        """Online learning - update with new data"""
        X, y = np.array(X), np.array(y)
        if self.weights is None:
            self.weights = np.zeros(X.shape[1])
        y_pred = self._sigmoid(X.dot(self.weights) + self.bias)
        self.weights -= self.lr * X.T.dot(y_pred - y)
        self.bias -= self.lr * np.sum(y_pred - y)
        return self

    def predict_proba(self, X):
        return self._sigmoid(np.array(X).dot(self.weights) + self.bias)

    def predict(self, X):
        return (self.predict_proba(X) >= 0.5).astype(int)

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))