import numpy as np

class ReinforcementAgent:
    """
    Simple Reinforcement Learning Agent (Q-Learning).
    Agent learns from rewards and penalties — Agentic AI trend.

    Usage:
        from evolveml.rl import ReinforcementAgent
        agent = ReinforcementAgent(n_states=10, n_actions=4)
        action = agent.act(state)
        agent.learn(state, action, reward, next_state)
    """
    def __init__(self, n_states=100, n_actions=4, lr=0.1,
                 gamma=0.95, epsilon=1.0, epsilon_decay=0.995):
        self.n_states = n_states
        self.n_actions = n_actions
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = 0.01
        self.q_table = np.zeros((n_states, n_actions))
        self.total_reward = 0
        self.episodes = 0

    def act(self, state):
        """Choose action using epsilon-greedy policy"""
        if np.random.random() < self.epsilon:
            return np.random.randint(self.n_actions)  # explore
        return np.argmax(self.q_table[state])          # exploit

    def learn(self, state, action, reward, next_state, done=False):
        """Update Q-table from experience"""
        self.total_reward += reward
        current_q = self.q_table[state, action]
        if done:
            target_q = reward
        else:
            target_q = reward + self.gamma * np.max(self.q_table[next_state])
        self.q_table[state, action] += self.lr * (target_q - current_q)

        # Decay exploration
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def end_episode(self):
        self.episodes += 1

    def best_action(self, state):
        """Get best action for a state (no exploration)"""
        return int(np.argmax(self.q_table[state]))

    def save_policy(self):
        return self.q_table.copy()

    def load_policy(self, q_table):
        self.q_table = np.array(q_table)
        self.epsilon = self.epsilon_min  # no exploration when loading

    @property
    def stats(self):
        return {
            'episodes': self.episodes,
            'total_reward': self.total_reward,
            'epsilon': round(self.epsilon, 4)
        }