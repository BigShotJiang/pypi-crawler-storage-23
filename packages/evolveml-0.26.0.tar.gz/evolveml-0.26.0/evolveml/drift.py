import numpy as np

class ConceptDriftDetector:
    """
    Detects when data distribution changes over time (Concept Drift).
    Essential for adaptive/continual learning systems.

    Usage:
        from evolveml.drift import ConceptDriftDetector
        detector = ConceptDriftDetector()
        for prediction, actual in stream:
            status = detector.update(prediction, actual)
            if status['drift_detected']:
                print("⚠️ Drift detected! Retrain model.")
    """
    def __init__(self, window_size=30, warning_threshold=0.1, drift_threshold=0.2):
        self.window_size = window_size
        self.warning_threshold = warning_threshold
        self.drift_threshold = drift_threshold
        self.errors = []
        self.drift_points = []
        self.n_samples = 0

    def update(self, predicted, actual):
        """Feed one prediction and check for drift"""
        error = int(predicted != actual)
        self.errors.append(error)
        self.n_samples += 1

        if len(self.errors) < self.window_size:
            return {'drift_detected': False, 'warning': False, 'error_rate': None}

        # Sliding window error rate
        recent = self.errors[-self.window_size:]
        error_rate = np.mean(recent)

        # Baseline from first window
        baseline = np.mean(self.errors[:self.window_size])
        change = abs(error_rate - baseline)

        drift = change > self.drift_threshold
        warning = change > self.warning_threshold

        if drift:
            self.drift_points.append(self.n_samples)

        return {
            'drift_detected': bool(drift),
            'warning': bool(warning),
            'error_rate': float(error_rate),
            'baseline_error': float(baseline),
            'change': float(change),
            'status': '🚨 DRIFT!' if drift else ('⚠️ WARNING' if warning else '✅ STABLE')
        }

    def reset(self):
        """Reset after model retraining"""
        self.errors = []
        print("🔄 Drift detector reset after retraining")

    @property
    def n_drifts(self):
        return len(self.drift_points)