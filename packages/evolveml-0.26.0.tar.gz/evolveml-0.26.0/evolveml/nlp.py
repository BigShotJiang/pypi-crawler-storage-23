import numpy as np

class SentimentAnalyzer:
    """
    Real-time Sentiment Analysis for text.
    No external NLP libraries needed — built from scratch!

    Usage:
        from evolveml.nlp import SentimentAnalyzer
        analyzer = SentimentAnalyzer()
        result = analyzer.analyze("This product is absolutely amazing!")
        print(result)  # {'sentiment': 'POSITIVE', 'score': 0.87}

        # Online learning - teach it new words
        analyzer.learn("terrible experience", label='negative')
    """
    POSITIVE_WORDS = [
        'good','great','excellent','amazing','awesome','fantastic',
        'love','best','wonderful','perfect','happy','brilliant',
        'outstanding','superb','positive','nice','beautiful','helpful',
        'fast','easy','recommend','impressive','incredible','enjoy'
    ]
    NEGATIVE_WORDS = [
        'bad','terrible','awful','horrible','worst','hate','poor',
        'disappointing','useless','broken','slow','difficult','annoying',
        'negative','ugly','unhelpful','waste','failure','boring','wrong',
        'never','problem','issue','error','crash','bug','fail'
    ]

    def __init__(self):
        self.pos_words = set(self.POSITIVE_WORDS)
        self.neg_words = set(self.NEGATIVE_WORDS)
        self.custom_pos = set()
        self.custom_neg = set()

    def _tokenize(self, text):
        return text.lower().replace('.','').replace(',','').replace('!','').replace('?','').split()

    def analyze(self, text):
        """Analyze sentiment of a text"""
        words = self._tokenize(text)
        pos_count = sum(1 for w in words if w in self.pos_words or w in self.custom_pos)
        neg_count = sum(1 for w in words if w in self.neg_words or w in self.custom_neg)

        total = pos_count + neg_count + 1e-10
        pos_score = pos_count / total
        neg_score = neg_count / total

        if pos_score > neg_score:
            sentiment = 'POSITIVE 😊'
            confidence = pos_score
        elif neg_score > pos_score:
            sentiment = 'NEGATIVE 😞'
            confidence = neg_score
        else:
            sentiment = 'NEUTRAL 😐'
            confidence = 0.5

        return {
            'text': text,
            'sentiment': sentiment,
            'confidence': round(float(confidence), 3),
            'positive_words': [w for w in words if w in self.pos_words or w in self.custom_pos],
            'negative_words': [w for w in words if w in self.neg_words or w in self.custom_neg]
        }

    def analyze_batch(self, texts):
        """Analyze multiple texts"""
        return [self.analyze(t) for t in texts]

    def learn(self, word, label):
        """Teach new words online"""
        word = word.lower().strip()
        if label == 'positive':
            self.custom_pos.add(word)
        elif label == 'negative':
            self.custom_neg.add(word)
        print(f"✅ Learned: '{word}' → {label}")

    def stream_analyze(self, texts):
        """Real-time streaming sentiment analysis"""
        for text in texts:
            result = self.analyze(text)
            print(f"  [{result['sentiment']}] ({result['confidence']:.0%}) → {text[:50]}")
            yield result