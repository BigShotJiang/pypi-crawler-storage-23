import numpy as np

def accuracy(y_true, y_pred):
    """Accuracy score"""
    return float(np.mean(np.array(y_true) == np.array(y_pred)))

def mse(y_true, y_pred):
    """Mean Squared Error"""
    return float(np.mean((np.array(y_true) - np.array(y_pred)) ** 2))

def rmse(y_true, y_pred):
    """Root Mean Squared Error"""
    return float(np.sqrt(mse(y_true, y_pred)))

def f1_score(y_true, y_pred):
    """F1 Score for binary classification"""
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    tp = np.sum((y_pred == 1) & (y_true == 1))
    fp = np.sum((y_pred == 1) & (y_true == 0))
    fn = np.sum((y_pred == 0) & (y_true == 1))
    precision = tp / (tp + fp + 1e-10)
    recall = tp / (tp + fn + 1e-10)
    return float(2 * precision * recall / (precision + recall + 1e-10))