import numpy as np

def normalize(X):
    """Normalize features to 0-1 range"""
    X = np.array(X, dtype=float)
    mn, mx = X.min(axis=0), X.max(axis=0)
    denom = mx - mn
    denom[denom == 0] = 1
    return (X - mn) / denom

def train_test_split(X, y, test_size=0.2, random_state=None):
    """Split data into train and test sets"""
    if random_state is not None:
        np.random.seed(random_state)
    X, y = np.array(X), np.array(y)
    n = len(X)
    idx = np.random.permutation(n)
    split = int(n * (1 - test_size))
    train_idx, test_idx = idx[:split], idx[split:]
    return X[train_idx], X[test_idx], y[train_idx], y[test_idx]