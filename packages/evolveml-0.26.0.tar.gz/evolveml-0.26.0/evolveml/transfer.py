import numpy as np

class TransferLearner:
    """
    Transfer Learning - Reuse knowledge from a pretrained model
    to solve a new but related problem faster.

    Usage:
        from evolveml.transfer import TransferLearner
        from evolveml import DecisionTreeClassifier

        # Train source model on original task
        source_model = DecisionTreeClassifier()
        source_model.fit(X_source, y_source)

        # Transfer to new task with few samples
        transfer = TransferLearner(source_model)
        transfer.fit(X_target, y_target)  # needs less data!
        predictions = transfer.predict(X_new)
    """
    def __init__(self, source_model, freeze_features=True):
        self.source_model = source_model
        self.freeze_features = freeze_features
        self.adapter = None
        self.fitted = False

    def _extract_features(self, X):
        """Use source model internals as feature extractor"""
        X = np.array(X)
        try:
            # Use source model predictions as soft features
            if hasattr(self.source_model, 'predict'):
                base_pred = self.source_model.predict(X).reshape(-1, 1)
                return np.hstack([X, base_pred])
        except Exception:
            pass
        return X

    def fit(self, X, y, epochs=200, lr=0.01):
        """Fine-tune on target task"""
        X_feat = self._extract_features(X)
        y = np.array(y)
        n, f = X_feat.shape

        # Simple linear adapter layer on top
        self.weights = np.random.randn(f) * 0.01
        self.bias = 0.0
        self.classes_ = np.unique(y)

        def sigmoid(z):
            return 1 / (1 + np.exp(-np.clip(z, -250, 250)))

        for _ in range(epochs):
            out = sigmoid(X_feat.dot(self.weights) + self.bias)
            error = out - y
            self.weights -= lr * X_feat.T.dot(error) / n
            self.bias -= lr * error.mean()

        self.fitted = True
        print(f"✅ TransferLearner fine-tuned on {n} target samples")
        return self

    def predict(self, X):
        X_feat = self._extract_features(X)
        z = X_feat.dot(self.weights) + self.bias
        prob = 1 / (1 + np.exp(-np.clip(z, -250, 250)))
        return (prob >= 0.5).astype(int)

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))