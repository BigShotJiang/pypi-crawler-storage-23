"""
evolveml - A Python library that evolves with your data.
Supports Batch + Real-time Online Learning + Latest 2026 ML Trends.
Author: SAPPA VAMSI
"""

from .models.decision_tree import DecisionTreeClassifier
from .models.linear import LinearRegressionModel, LogisticRegressionModel
from .models.neural_net import NeuralNetwork
from .stream_learner import StreamLearner
from .tasks.fraud_detection import FraudDetector
from .tasks.image_classifier import ImageClassifier
from .tasks.spam_detector import SpamDetector
from .tasks.stock_predictor import StockPredictor
from .automl import AutoFeatureSelector
from .anomaly import AnomalyDetector
from .drift import ConceptDriftDetector
from .explain import ExplainableModel
from .rl import ReinforcementAgent
from .nlp import SentimentAnalyzer
from .transfer import TransferLearner
from .metrics import accuracy, mse, rmse, f1_score
from .utils import normalize, train_test_split

__version__ = "0.26.0"
__author__ = "SAPPA VAMSI"