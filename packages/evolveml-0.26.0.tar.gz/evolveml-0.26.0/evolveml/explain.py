import numpy as np

class ExplainableModel:
    """
    Explainable AI (XAI) - Shows WHY your model made a prediction.
    Wraps any evolveml model and adds explanations.

    Usage:
        from evolveml.explain import ExplainableModel
        from evolveml import DecisionTreeClassifier

        base_model = DecisionTreeClassifier()
        base_model.fit(X_train, y_train)

        xai = ExplainableModel(base_model, feature_names=['age', 'amount', 'hour'])
        xai.fit(X_train, y_train)
        explanation = xai.explain(X_test[0])
        print(explanation)
    """
    def __init__(self, model, feature_names=None):
        self.model = model
        self.feature_names = feature_names
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        self.X_train = np.array(X)
        self.y_train = np.array(y)
        if not hasattr(self.model, 'weights') and not hasattr(self.model, 'root'):
            self.model.fit(X, y)
        return self

    def _feature_importance(self, x):
        """Estimate feature importance using perturbation"""
        x = np.array(x).flatten()
        base_pred = self.model.predict(x.reshape(1, -1))[0]
        importances = []
        for i in range(len(x)):
            x_perturbed = x.copy()
            x_perturbed[i] = self.X_train[:, i].mean() if self.X_train is not None else 0
            perturbed_pred = self.model.predict(x_perturbed.reshape(1, -1))[0]
            importances.append(abs(float(base_pred) - float(perturbed_pred)))
        return np.array(importances)

    def explain(self, x):
        """Explain a single prediction"""
        x = np.array(x).flatten()
        prediction = self.model.predict(x.reshape(1, -1))[0]
        importances = self._feature_importance(x)
        total = importances.sum() + 1e-10
        names = self.feature_names or [f'Feature[{i}]' for i in range(len(x))]

        ranked = sorted(zip(names, importances, x),
                        key=lambda t: t[1], reverse=True)

        explanation = {
            'prediction': int(prediction),
            'top_reasons': [
                {
                    'feature': name,
                    'value': float(val),
                    'importance': float(imp),
                    'contribution': f"{imp/total*100:.1f}%"
                }
                for name, imp, val in ranked[:5]
            ]
        }

        print(f"\n🔍 EXPLANATION")
        print(f"  Prediction : {prediction}")
        print(f"  Top Reasons:")
        for r in explanation['top_reasons']:
            print(f"    → {r['feature']} = {r['value']:.3f}  |  Impact: {r['contribution']}")

        return explanation