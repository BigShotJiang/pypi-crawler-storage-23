import numpy as np
from ..models.linear import LinearRegressionModel
from ..stream_learner import StreamLearner

class StockPredictor:
    """
    Stock Price Prediction - Batch + Real-time Learning

    Usage:
        from evolveml import StockPredictor
        predictor = StockPredictor()
        predictor.fit(X_train, y_train)
        price = predictor.predict(X_test)
    """
    def __init__(self):
        self.model = LinearRegressionModel(lr=0.001, epochs=500)
        self.stream = StreamLearner(lr=0.001)
        self.fitted = False

    def fit(self, X, y):
        self.model.fit(np.array(X), np.array(y))
        self.fitted = True
        return self

    def predict(self, X):
        return self.model.predict(np.array(X))

    def update(self, x, actual_price):
        self.stream.learn_one(x, actual_price)