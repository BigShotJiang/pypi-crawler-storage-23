import numpy as np
from ..stream_learner import StreamLearner

class FraudDetector:
    """
    Real-time Fraud Detection using Online Learning

    Usage:
        from evolveml import FraudDetector
        detector = FraudDetector()
        result = detector.check(transaction)
        detector.update(transaction, is_fraud=True)
    """
    def __init__(self):
        self.model = StreamLearner(lr=0.01)

    def _extract_features(self, transaction):
        return np.array([
            transaction.get('amount', 0) / 20000,
            transaction.get('hour', 12) / 24,
            transaction.get('location_mismatch', 0),
            transaction.get('failed_attempts', 0) / 5
        ])

    def check(self, transaction):
        features = self._extract_features(transaction)
        pred = self.model.predict_one(features)
        return {'is_fraud': bool(pred), 'transaction': transaction}

    def update(self, transaction, is_fraud):
        features = self._extract_features(transaction)
        self.model.learn_one(features, int(is_fraud))

    def fit(self, transactions, labels):
        X = np.array([self._extract_features(t) for t in transactions])
        self.model.partial_fit(X, labels)
        return self