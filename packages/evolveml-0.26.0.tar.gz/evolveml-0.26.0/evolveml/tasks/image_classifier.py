import numpy as np
from ..models.decision_tree import DecisionTreeClassifier
from ..models.neural_net import NeuralNetwork

class ImageClassifier:
    """
    Image Classification using Decision Tree or Neural Network

    Usage:
        from evolveml import ImageClassifier
        clf = ImageClassifier(model='tree')  # or 'neural'
        clf.fit(X_train, y_train)
        predictions = clf.predict(X_test)
        print(clf.score(X_test, y_test))
    """
    def __init__(self, model='tree', max_depth=10):
        self.model_type = model
        if model == 'neural':
            self.model = NeuralNetwork(layers=[64, 32], output=10, epochs=50)
        else:
            self.model = DecisionTreeClassifier(max_depth=max_depth)

    def fit(self, X, y):
        """Train on image data (flattened pixel arrays)"""
        X = np.array(X) / 255.0  # normalize
        self.model.fit(X, y)
        return self

    def predict(self, X):
        X = np.array(X) / 255.0
        return self.model.predict(X)

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))