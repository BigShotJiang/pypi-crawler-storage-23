import numpy as np
from ..models.linear import LogisticRegressionModel
from ..stream_learner import StreamLearner

class SpamDetector:
    """
    Spam Email Detection - Batch + Online Learning

    Usage:
        from evolveml import SpamDetector
        detector = SpamDetector()
        detector.fit(X_train, y_train)
        result = detector.predict(X_test)
    """
    def __init__(self, online=False):
        self.online = online
        self.model = StreamLearner() if online else LogisticRegressionModel()

    def fit(self, X, y):
        self.model.fit(np.array(X), np.array(y))
        return self

    def predict(self, X):
        return self.model.predict(np.array(X))

    def update(self, x, is_spam):
        if self.online:
            self.model.learn_one(x, int(is_spam))
        else:
            self.model.partial_fit(np.array([x]), [int(is_spam)])

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.array(y)))