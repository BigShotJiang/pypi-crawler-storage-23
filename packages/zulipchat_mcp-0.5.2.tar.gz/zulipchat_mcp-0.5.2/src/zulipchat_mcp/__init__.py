"""ZulipChat MCP Server package."""

__version__ = "0.5.2"

__all__: list[str] = []
