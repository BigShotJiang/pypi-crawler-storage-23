from rich import print

class Contoh:
    def contoh():
        print("[bold]Halo!, ini adalah contoh :)[/bold]")

def contoh():
    print("[bold][blue]Ini adalah contoh library python :)[/blue][/bold]")
