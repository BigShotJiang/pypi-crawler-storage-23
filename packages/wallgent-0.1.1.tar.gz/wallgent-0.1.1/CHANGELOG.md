# Changelog

## 0.1.1 (2026-03-02)

- Fix repository and issues URLs in package metadata

## 0.1.0 (2026-03-02)

Initial release.

- `Wallgent` client with sync and async support
- Resources: wallets, payments, policies, webhooks, transfers, cards, payment_links, customers, invoices, network
- LangChain integration (`wallgent[langchain]`)
- CrewAI integration (`wallgent[crewai]`)
