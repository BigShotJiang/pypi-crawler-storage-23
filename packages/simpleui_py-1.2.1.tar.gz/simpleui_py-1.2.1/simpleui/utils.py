"""
SimpleUI 工具模块
"""

import os
import tempfile
import webbrowser
import platform
from typing import Optional

from .core import Component, Theme, render_html


def preview(
    *components: Component,
    title: str = "SimpleUI Preview",
    theme: Optional[Theme] = None,
    open_browser: bool = True,
) -> str:
    """
    在浏览器中预览组件
    
    参数:
        *components: 要预览的组件
        title: 页面标题
        theme: 主题配置
        open_browser: 是否自动打开浏览器
    
    返回:
        临时HTML文件路径
    """
    html = render_html(*components, title=title, theme=theme)
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".html",
        delete=False,
        encoding="utf-8"
    ) as f:
        f.write(html)
        filepath = f.name
    
    if open_browser:
        # 修复 Windows 路径问题
        if platform.system() == "Windows":
            # Windows 使用绝对路径
            file_url = f"file:///{filepath.replace(os.sep, '/')}"
        else:
            # macOS/Linux
            file_url = f"file://{filepath}"
        
        # 尝试打开浏览器
        try:
            webbrowser.open(file_url)
        except Exception:
            # 如果失败，打印路径让用户手动打开
            print(f"请手动打开: {filepath}")
    
    return filepath


def serve(
    *components: Component,
    title: str = "SimpleUI App",
    theme: Optional[Theme] = None,
    host: str = "localhost",
    port: int = 8080,
    open_browser: bool = True,
) -> None:
    """
    启动本地服务器预览组件
    """
    try:
        from http.server import HTTPServer, SimpleHTTPRequestHandler
        import threading
        import time
    except ImportError:
        print("无法启动服务器，请使用 preview() 函数")
        return
    
    html = render_html(*components, title=title, theme=theme)
    
    # 创建临时目录
    temp_dir = tempfile.mkdtemp()
    filepath = os.path.join(temp_dir, "index.html")
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)
    
    # 切换到临时目录
    original_dir = os.getcwd()
    os.chdir(temp_dir)
    
    # 创建服务器
    server = HTTPServer((host, port), SimpleHTTPRequestHandler)
    
    # 在线程中启动服务器
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    
    # 打开浏览器
    if open_browser:
        time.sleep(0.5)
        url = f"http://{host}:{port}"
        try:
            webbrowser.open(url)
        except Exception:
            print(f"请手动打开: {url}")
    
    print(f"服务器已启动: http://{host}:{port}")
    print("按 Ctrl+C 停止服务器")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n服务器已停止")
        server.shutdown()
        os.chdir(original_dir)


def demo() -> str:
    """运行演示"""
    from .components import (
        Button, Input, Card, Switch, Tag, Progress, Alert,
        Container, Row
    )
    
    container = Container()
    container.add_child("<h1 style='text-align:center;margin-bottom:2rem;color:var(--text-primary)'>SimpleUI 组件演示</h1>")
    
    btn_row = Row()
    btn_row.add_child(Button("主要按钮", variant="primary"))
    btn_row.add_child(Button("次要按钮", variant="secondary"))
    btn_row.add_child(Button("危险按钮", variant="danger"))
    container.add_child(btn_row)
    
    container.add_child(Input(label="用户名", placeholder="请输入用户名"))
    container.add_child(Card(title="示例卡片", text="这是一个示例卡片", image="var(--gradient-1)"))
    container.add_child(Switch("启用功能", checked=True))
    
    tag_row = Row()
    tag_row.add_child(Tag("Python", variant="primary"))
    tag_row.add_child(Tag("UI", variant="success"))
    container.add_child(tag_row)
    
    container.add_child(Progress(value=75, label="下载进度"))
    container.add_child(Alert.success("成功", "欢迎使用 SimpleUI！"))
    
    return preview(container, title="SimpleUI 组件演示")


def playground() -> str:
    """打开交互式组件游乐场"""
    return demo()
