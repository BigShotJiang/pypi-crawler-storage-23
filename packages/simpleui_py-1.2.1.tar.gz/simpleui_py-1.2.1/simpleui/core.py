"""
SimpleUI 核心模块
包含组件基类、主题系统、渲染功能
"""

from typing import Optional, List, Dict, Union
from dataclasses import dataclass
from enum import Enum
import uuid
import os


# ============================================================
# 主题系统
# ============================================================

class ThemeType(Enum):
    """主题类型枚举"""
    LIGHT = "light"
    DARK = "dark"


@dataclass
class Theme:
    """
    主题配置类
    
    属性:
        type: 主题类型（LIGHT/DARK）
        primary: 主色调
        secondary: 次要颜色
        success: 成功颜色
        warning: 警告颜色
        danger: 危险颜色
        radius: 圆角大小
    """
    type: ThemeType = ThemeType.LIGHT
    primary: str = "#667eea"
    secondary: str = "#764ba2"
    success: str = "#43e97b"
    warning: str = "#fbbf24"
    danger: str = "#ef4444"
    info: str = "#4facfe"
    radius: str = "10px"
    
    # 背景色
    bg_primary: str = ""
    bg_secondary: str = ""
    bg_card: str = ""
    
    # 文字色
    text_primary: str = ""
    text_secondary: str = ""
    text_muted: str = ""
    
    # 边框色
    border_color: str = ""
    border_hover: str = ""
    
    def __post_init__(self):
        """根据主题类型自动设置默认颜色"""
        if self.type == ThemeType.LIGHT:
            # 浅色主题
            self.bg_primary = self.bg_primary or "#f8fafc"
            self.bg_secondary = self.bg_secondary or "#ffffff"
            self.bg_card = self.bg_card or "rgba(255, 255, 255, 0.9)"
            self.text_primary = self.text_primary or "#1e293b"
            self.text_secondary = self.text_secondary or "#475569"
            self.text_muted = self.text_muted or "#64748b"
            self.border_color = self.border_color or "rgba(0, 0, 0, 0.08)"
            self.border_hover = self.border_hover or "rgba(0, 0, 0, 0.15)"
        else:
            # 深色主题
            self.bg_primary = self.bg_primary or "#0a0a1a"
            self.bg_secondary = self.bg_secondary or "#12122a"
            self.bg_card = self.bg_card or "rgba(255, 255, 255, 0.03)"
            self.text_primary = self.text_primary or "#ffffff"
            self.text_secondary = self.text_secondary or "rgba(255, 255, 255, 0.7)"
            self.text_muted = self.text_muted or "rgba(255, 255, 255, 0.5)"
            self.border_color = self.border_color or "rgba(255, 255, 255, 0.1)"
            self.border_hover = self.border_hover or "rgba(255, 255, 255, 0.2)"
    
    def to_css_variables(self) -> str:
        """将主题转换为 CSS 变量"""
        return f"""
:root {{
    /* 主色调 */
    --primary: {self.primary};
    --primary-hover: {self._lighten(self.primary, 10)};
    --secondary: {self.secondary};
    --success: {self.success};
    --warning: {self.warning};
    --danger: {self.danger};
    --info: {self.info};
    
    /* 渐变 */
    --gradient-1: linear-gradient(135deg, {self.primary} 0%, {self.secondary} 100%);
    --gradient-2: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    --gradient-3: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    --gradient-4: linear-gradient(135deg, {self.success} 0%, #38f9d7 100%);
    --gradient-5: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
    
    /* 背景 */
    --bg-primary: {self.bg_primary};
    --bg-secondary: {self.bg_secondary};
    --bg-card: {self.bg_card};
    --bg-card-hover: {self._hover_color(self.bg_card)};
    
    /* 文字 */
    --text-primary: {self.text_primary};
    --text-secondary: {self.text_secondary};
    --text-muted: {self.text_muted};
    
    /* 边框 */
    --border-color: {self.border_color};
    --border-hover: {self.border_hover};
    
    /* 圆角 */
    --radius-sm: 6px;
    --radius-md: {self.radius};
    --radius-lg: 16px;
    --radius-xl: 24px;
    
    /* 阴影 */
    --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.1);
    --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.15);
    --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.2);
    --shadow-glow: 0 0 20px rgba(102, 126, 234, 0.4);
}}

[data-theme="{self.type.value}"] {{
    --bg-primary: {self.bg_primary};
    --bg-secondary: {self.bg_secondary};
    --bg-card: {self.bg_card};
    --text-primary: {self.text_primary};
    --text-secondary: {self.text_secondary};
    --text-muted: {self.text_muted};
    --border-color: {self.border_color};
    --border-hover: {self.border_hover};
}}
"""
    
    def _lighten(self, color: str, percent: int) -> str:
        """使颜色变亮（简化版）"""
        # 简化实现，实际可以用 colorsys
        return color
    
    def _hover_color(self, color: str) -> str:
        """获取悬停颜色"""
        return color.replace("0.03", "0.06").replace("0.9", "1")


# 全局主题实例
_current_theme: Theme = Theme()


def set_theme(theme: Union[Theme, ThemeType, str]) -> None:
    """
    设置全局主题
    
    参数:
        theme: Theme对象、ThemeType枚举或字符串("light"/"dark")
    
    示例:
        set_theme(ThemeType.DARK)
        set_theme("dark")
        set_theme(Theme(type=ThemeType.DARK, primary="#ff0000"))
    """
    global _current_theme
    
    if isinstance(theme, Theme):
        _current_theme = theme
    elif isinstance(theme, ThemeType):
        _current_theme = Theme(type=theme)
    elif isinstance(theme, str):
        theme_type = ThemeType.DARK if theme.lower() == "dark" else ThemeType.LIGHT
        _current_theme = Theme(type=theme_type)


def get_theme() -> Theme:
    """获取当前主题"""
    return _current_theme


# ============================================================
# 组件基类
# ============================================================

class Component:
    """
    组件基类
    
    所有 UI 组件都继承自此类。
    
    属性:
        id: 组件唯一标识
        class_name: 额外的 CSS 类名
        style: 内联样式字典
        attributes: 额外的 HTML 属性
    """
    
    def __init__(
        self,
        id: Optional[str] = None,
        class_name: str = "",
        style: Optional[Dict[str, str]] = None,
        attributes: Optional[Dict[str, str]] = None,
    ):
        """
        初始化组件
        
        参数:
            id: 组件ID，不指定则自动生成
            class_name: CSS类名
            style: 内联样式字典
            attributes: 其他HTML属性
        """
        self.id = id or f"component-{uuid.uuid4().hex[:8]}"
        self.class_name = class_name
        self.style = style or {}
        self.attributes = attributes or {}
        self._children: List[Union['Component', str]] = []
        self._events: Dict[str, str] = {}
    
    def add_child(self, child: Union['Component', str]) -> 'Component':
        """
        添加子组件
        
        参数:
            child: 子组件或HTML字符串
        
        返回:
            self，支持链式调用
        """
        self._children.append(child)
        return self
    
    def add_event(self, event: str, handler: str) -> 'Component':
        """
        添加事件处理
        
        参数:
            event: 事件名（如 onclick）
            handler: 处理函数
        
        返回:
            self
        """
        self._events[event] = handler
        return self
    
    def _get_base_classes(self) -> str:
        """获取基础CSS类名，子类可重写"""
        return self.class_name
    
    def _get_style_str(self) -> str:
        """获取内联样式字符串"""
        if not self.style:
            return ""
        return "; ".join(f"{k}: {v}" for k, v in self.style.items())
    
    def _get_attributes_str(self) -> str:
        """获取属性字符串"""
        attrs = []
        
        # ID
        if self.id:
            attrs.append(f'id="{self.id}"')
        
        # 类名
        classes = self._get_base_classes()
        if classes:
            attrs.append(f'class="{classes}"')
        
        # 内联样式
        style_str = self._get_style_str()
        if style_str:
            attrs.append(f'style="{style_str}"')
        
        # 其他属性
        for key, value in self.attributes.items():
            attrs.append(f'{key}="{value}"')
        
        # 事件
        for event, handler in self._events.items():
            attrs.append(f'{event}="{handler}"')
        
        return " ".join(attrs)
    
    def _render_children(self) -> str:
        """渲染所有子组件"""
        return "".join(
            child.render() if isinstance(child, Component) else str(child)
            for child in self._children
        )
    
    def render(self) -> str:
        """
        渲染组件为HTML字符串
        
        子类必须实现此方法
        """
        raise NotImplementedError(f"{self.__class__.__name__} 必须实现 render() 方法")
    
    def __str__(self) -> str:
        """字符串表示，返回渲染后的HTML"""
        return self.render()
    
    def __repr__(self) -> str:
        """调试表示"""
        return f"<{self.__class__.__name__} id='{self.id}'>"
    
    def __enter__(self) -> 'Component':
        """支持 with 语句"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        pass


# ============================================================
# 渲染函数
# ============================================================

def render_html(
    *components: Component,
    title: str = "SimpleUI App",
    theme: Optional[Theme] = None,
    include_styles: bool = True,
    include_scripts: bool = True,
) -> str:
    """
    渲染组件为完整HTML页面
    
    参数:
        *components: 要渲染的组件
        title: 页面标题
        theme: 主题配置，None则使用全局主题
        include_styles: 是否包含CSS样式
        include_scripts: 是否包含JavaScript脚本
    
    返回:
        完整的HTML字符串
    """
    theme = theme or get_theme()
    
    styles = _get_default_styles() if include_styles else ""
    theme_css = theme.to_css_variables() if include_styles else ""
    scripts = _get_default_scripts() if include_scripts else ""
    
    content = "".join(comp.render() for comp in components)
    
    return f"""<!DOCTYPE html>
<html lang="zh-CN" data-theme="{theme.type.value}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
{theme_css}
{styles}
    </style>
</head>
<body>
{content}
{scripts}
</body>
</html>"""


def export_html(
    *components: Component,
    filename: str = "output.html",
    title: str = "SimpleUI App",
    theme: Optional[Theme] = None,
) -> str:
    """
    导出组件为HTML文件
    
    参数:
        *components: 要导出的组件
        filename: 输出文件名
        title: 页面标题
        theme: 主题配置
    
    返回:
        文件的绝对路径
    """
    html = render_html(*components, title=title, theme=theme)
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
    
    return os.path.abspath(filename)


# ============================================================
# 默认样式
# ============================================================

def _get_default_styles() -> str:
    """获取默认CSS样式"""
    return """
    /* ========== 基础样式 ========== */
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    
    html {
        scroll-behavior: smooth;
    }
    
    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft YaHei', sans-serif;
        line-height: 1.6;
        color: var(--text-primary);
        background: var(--bg-primary);
        min-height: 100vh;
        padding: 2rem;
    }
    
    /* ========== 动画 ========== */
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    @keyframes ripple {
        to { transform: scale(4); opacity: 0; }
    }
    
    @keyframes alertSlideIn {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }
    
    @keyframes alertSlideOut {
        from { opacity: 1; transform: translateX(0); max-height: 100px; }
        to { opacity: 0; transform: translateX(20px); max-height: 0; padding: 0; margin: 0; }
    }
    
    /* ========== 布局组件 ========== */
    .sui-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 1rem;
    }
    
    .sui-row {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .sui-column {
        flex: 1;
        min-width: 200px;
    }
    
    /* ========== 按钮组件 ========== */
    .sui-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.625rem 1.25rem;
        font-size: 0.9rem;
        font-weight: 600;
        border: none;
        border-radius: var(--radius-md);
        cursor: pointer;
        transition: all 0.2s ease;
        position: relative;
        overflow: hidden;
        text-decoration: none;
        outline: none;
    }
    
    .sui-btn:focus-visible {
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.4);
    }
    
    .sui-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .sui-btn svg {
        width: 16px;
        height: 16px;
        fill: currentColor;
    }
    
    /* 按钮变体 */
    .sui-btn-primary {
        background: var(--gradient-1);
        color: white;
        box-shadow: var(--shadow-md);
    }
    
    .sui-btn-primary:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg), var(--shadow-glow);
    }
    
    .sui-btn-secondary {
        background: var(--bg-card);
        color: var(--text-primary);
        border: 1px solid var(--border-color);
    }
    
    .sui-btn-secondary:hover:not(:disabled) {
        background: var(--bg-card-hover);
        border-color: var(--border-hover);
        transform: translateY(-2px);
    }
    
    .sui-btn-outline {
        background: transparent;
        color: var(--primary);
        border: 2px solid var(--primary);
    }
    
    .sui-btn-outline:hover:not(:disabled) {
        background: var(--primary);
        color: white;
    }
    
    .sui-btn-ghost {
        background: transparent;
        color: var(--text-secondary);
    }
    
    .sui-btn-ghost:hover:not(:disabled) {
        background: var(--bg-card);
        color: var(--text-primary);
    }
    
    .sui-btn-danger {
        background: var(--danger);
        color: white;
    }
    
    .sui-btn-danger:hover:not(:disabled) {
        filter: brightness(1.1);
        transform: translateY(-2px);
    }
    
    .sui-btn-success {
        background: var(--success);
        color: white;
    }
    
    .sui-btn-success:hover:not(:disabled) {
        filter: brightness(1.1);
        transform: translateY(-2px);
    }
    
    /* 按钮尺寸 */
    .sui-btn-sm {
        padding: 0.4rem 0.8rem;
        font-size: 0.8rem;
    }
    
    .sui-btn-lg {
        padding: 0.875rem 1.75rem;
        font-size: 1rem;
    }
    
    .sui-btn-icon {
        width: 40px;
        height: 40px;
        padding: 0;
        border-radius: 50%;
    }
    
    .sui-btn-loading {
        pointer-events: none;
    }
    
    .sui-btn-loading::before {
        content: '';
        width: 16px;
        height: 16px;
        border: 2px solid currentColor;
        border-right-color: transparent;
        border-radius: 50%;
        animation: spin 0.6s linear infinite;
    }
    
    /* 按钮组 */
    .sui-btn-group {
        display: inline-flex;
    }
    
    .sui-btn-group .sui-btn {
        border-radius: 0;
    }
    
    .sui-btn-group .sui-btn:first-child {
        border-radius: var(--radius-md) 0 0 var(--radius-md);
    }
    
    .sui-btn-group .sui-btn:last-child {
        border-radius: 0 var(--radius-md) var(--radius-md) 0;
    }
    
    .sui-btn-group .sui-btn:not(:last-child) {
        border-right: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    /* ========== 输入框组件 ========== */
    .sui-input-wrapper {
        margin-bottom: 1rem;
    }
    
    .sui-input-label {
        display: block;
        font-size: 0.85rem;
        font-weight: 500;
        color: var(--text-secondary);
        margin-bottom: 0.4rem;
    }
    
    .sui-input {
        width: 100%;
        padding: 0.75rem 1rem;
        font-size: 0.95rem;
        background: var(--bg-card);
        border: 2px solid var(--border-color);
        border-radius: var(--radius-md);
        color: var(--text-primary);
        transition: all 0.2s ease;
        outline: none;
    }
    
    .sui-input:hover {
        border-color: var(--border-hover);
    }
    
    .sui-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.15);
    }
    
    .sui-input::placeholder {
        color: var(--text-muted);
    }
    
    .sui-input:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .sui-input-error {
        border-color: var(--danger);
    }
    
    .sui-input-success {
        border-color: var(--success);
    }
    
    .sui-input-helper {
        font-size: 0.8rem;
        color: var(--text-muted);
        margin-top: 0.35rem;
    }
    
    .sui-input-error-text {
        color: var(--danger);
    }
    
    .sui-textarea {
        min-height: 100px;
        resize: vertical;
    }
    
    .sui-input-icon-wrapper {
        position: relative;
    }
    
    .sui-input-icon-wrapper .sui-input {
        padding-left: 2.75rem;
    }
    
    .sui-input-icon {
        position: absolute;
        left: 0.875rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-muted);
        pointer-events: none;
    }
    
    .sui-input-icon svg {
        width: 18px;
        height: 18px;
        fill: currentColor;
    }
    
    /* ========== 卡片组件 ========== */
    .sui-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .sui-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-lg);
        border-color: var(--border-hover);
    }
    
    .sui-card-img {
        width: 100%;
        height: 120px;
        object-fit: cover;
    }
    
    .sui-card-body {
        padding: 1.25rem;
    }
    
    .sui-card-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 0.4rem;
    }
    
    .sui-card-text {
        font-size: 0.85rem;
        color: var(--text-secondary);
        margin-bottom: 1rem;
    }
    
    .sui-card-footer {
        padding: 1rem 1.25rem;
        border-top: 1px solid var(--border-color);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .sui-card-elevated {
        box-shadow: var(--shadow-md);
        border: none;
    }
    
    .sui-card-outlined {
        background: transparent;
    }
    
    .sui-card-interactive {
        cursor: pointer;
    }
    
    /* ========== 开关组件 ========== */
    .sui-switch-wrapper {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
    }
    
    .sui-switch {
        position: relative;
        width: 48px;
        height: 26px;
        appearance: none;
        background: var(--border-color);
        border-radius: 50px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .sui-switch::before {
        content: '';
        position: absolute;
        top: 3px;
        left: 3px;
        width: 20px;
        height: 20px;
        background: white;
        border-radius: 50%;
        transition: all 0.3s ease;
        box-shadow: var(--shadow-sm);
    }
    
    .sui-switch:checked {
        background: var(--gradient-1);
    }
    
    .sui-switch:checked::before {
        transform: translateX(22px);
    }
    
    .sui-switch:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .sui-switch-label {
        font-size: 0.9rem;
        color: var(--text-secondary);
    }
    
    /* 开关尺寸 */
    .sui-switch-sm {
        width: 36px;
        height: 20px;
    }
    
    .sui-switch-sm::before {
        width: 14px;
        height: 14px;
    }
    
    .sui-switch-sm:checked::before {
        transform: translateX(16px);
    }
    
    .sui-switch-lg {
        width: 60px;
        height: 32px;
    }
    
    .sui-switch-lg::before {
        width: 26px;
        height: 26px;
    }
    
    .sui-switch-lg:checked::before {
        transform: translateX(28px);
    }
    
    /* ========== 标签组件 ========== */
    .sui-tag {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.3rem 0.7rem;
        font-size: 0.8rem;
        font-weight: 500;
        border-radius: 50px;
        transition: all 0.2s ease;
        margin: 0.25rem;
    }
    
    .sui-tag svg {
        width: 12px;
        height: 12px;
        fill: currentColor;
    }
    
    .sui-tag-default {
        background: var(--bg-card);
        color: var(--text-secondary);
        border: 1px solid var(--border-color);
    }
    
    .sui-tag-primary {
        background: rgba(102, 126, 234, 0.15);
        color: var(--primary);
    }
    
    .sui-tag-success {
        background: rgba(67, 233, 123, 0.15);
        color: var(--success);
    }
    
    .sui-tag-warning {
        background: rgba(251, 191, 36, 0.15);
        color: var(--warning);
    }
    
    .sui-tag-danger {
        background: rgba(239, 68, 68, 0.15);
        color: var(--danger);
    }
    
    .sui-tag-removable {
        cursor: pointer;
    }
    
    .sui-tag-removable:hover {
        opacity: 0.8;
    }
    
    /* ========== 进度条组件 ========== */
    .sui-progress-wrapper {
        margin-bottom: 1.25rem;
    }
    
    .sui-progress-label {
        display: flex;
        justify-content: space-between;
        font-size: 0.85rem;
        color: var(--text-secondary);
        margin-bottom: 0.4rem;
    }
    
    .sui-progress {
        height: 8px;
        background: var(--bg-card);
        border-radius: 50px;
        overflow: hidden;
    }
    
    .sui-progress-bar {
        height: 100%;
        background: var(--gradient-1);
        border-radius: 50px;
        transition: width 0.5s ease;
    }
    
    .sui-progress-success .sui-progress-bar {
        background: var(--success);
    }
    
    .sui-progress-warning .sui-progress-bar {
        background: var(--warning);
    }
    
    .sui-progress-danger .sui-progress-bar {
        background: var(--danger);
    }
    
    /* ========== 提示组件 ========== */
    .sui-alert {
        padding: 1rem 1.25rem;
        border-radius: var(--radius-md);
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
        animation: alertSlideIn 0.4s ease forwards;
    }
    
    .sui-alert.hiding {
        animation: alertSlideOut 0.3s ease forwards;
    }
    
    .sui-alert svg {
        width: 20px;
        height: 20px;
        fill: currentColor;
        flex-shrink: 0;
        margin-top: 2px;
    }
    
    .sui-alert-content {
        flex: 1;
    }
    
    .sui-alert-title {
        font-weight: 600;
        margin-bottom: 0.25rem;
    }
    
    .sui-alert-text {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    
    .sui-alert-info {
        background: rgba(79, 172, 254, 0.1);
        color: var(--info);
        border: 1px solid rgba(79, 172, 254, 0.3);
    }
    
    .sui-alert-success {
        background: rgba(67, 233, 123, 0.1);
        color: var(--success);
        border: 1px solid rgba(67, 233, 123, 0.3);
    }
    
    .sui-alert-warning {
        background: rgba(251, 191, 36, 0.1);
        color: var(--warning);
        border: 1px solid rgba(251, 191, 36, 0.3);
    }
    
    .sui-alert-danger {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }
    
    .sui-alert-close {
        background: none;
        border: none;
        color: currentColor;
        opacity: 0.6;
        cursor: pointer;
        padding: 0;
        font-size: 1.2rem;
        line-height: 1;
        transition: opacity 0.2s, transform 0.2s;
    }
    
    .sui-alert-close:hover {
        opacity: 1;
        transform: scale(1.2);
    }
    # 在 _STYLES 字符串末尾添加以下内容

    /* ========== 窗口组件 ========== */
    .sui-window {
        position: absolute;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        display: flex;
        flex-direction: column;
        min-width: 200px;
        min-height: 150px;
        z-index: 100;
    }
    
    .sui-window:hover {
        border-color: var(--border-hover);
    }
    
    /* 窗口标题栏 */
    .sui-window-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.75rem 1rem;
        background: var(--bg-secondary);
        border-bottom: 1px solid var(--border-color);
        cursor: move;
        user-select: none;
    }
    
    .sui-window-title {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text-primary);
    }
    
    /* 窗口控制按钮 */
    .sui-window-controls {
        display: flex;
        gap: 0.5rem;
    }
    
    .sui-window-btn {
        width: 24px;
        height: 24px;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        font-size: 0.7rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s;
    }
    
    .sui-window-minimize {
        background: #fbbf24;
        color: white;
    }
    
    .sui-window-minimize:hover {
        background: #f59e0b;
    }
    
    .sui-window-close {
        background: #ef4444;
        color: white;
    }
    
    .sui-window-close:hover {
        background: #dc2626;
    }
    
    /* 窗口内容 */
    .sui-window-content {
        flex: 1;
        padding: 1rem;
        overflow: auto;
        position: relative;
    }
    
    .sui-window-content-absolute {
        flex: 1;
        overflow: visible;
        position: relative;
    }
    
    /* 调整大小手柄 */
    .sui-window-resize {
        position: absolute;
        right: 0;
        bottom: 0;
        width: 16px;
        height: 16px;
        cursor: se-resize;
        background: linear-gradient(135deg, transparent 50%, var(--border-color) 50%);
    }
    
    /* 最小化状态 */
    .sui-window-minimized .sui-window-content {
        display: none;
    }
    
    .sui-window-minimized .sui-window-resize {
        display: none;
    }
    
    /* 拖动时的样式 */
    .sui-window.dragging {
        opacity: 0.9;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    }
    
    /* 活动窗口 */
    .sui-window.active {
        z-index: 1000;
        box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
    }

"""


def _get_default_scripts() -> str:
    """获取默认JavaScript脚本"""
    return """
    <script>
    // 涟漪效果
    document.querySelectorAll('.sui-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            var rect = this.getBoundingClientRect();
            var ripple = document.createElement('span');
            ripple.style.cssText = 'position:absolute;border-radius:50%;background:rgba(255,255,255,0.4);transform:scale(0);animation:ripple 0.5s ease-out;left:' + (e.clientX - rect.left) + 'px;top:' + (e.clientY - rect.top) + 'px;width:10px;height:10px;';
            this.appendChild(ripple);
            setTimeout(function() { ripple.remove(); }, 500);
        });
    });
    
    // 提示框关闭
    function closeAlert(btn) {
        var alert = btn.closest('.sui-alert');
        alert.classList.add('hiding');
        setTimeout(function() { alert.remove(); }, 300);
    }
    
    // 标签移除
    document.querySelectorAll('.sui-tag-removable').forEach(function(tag) {
        tag.addEventListener('click', function() {
            this.style.transform = 'scale(0)';
            this.style.opacity = '0';
            var self = this;
            setTimeout(function() { self.remove(); }, 200);
        });
    });
    </script>
"""
