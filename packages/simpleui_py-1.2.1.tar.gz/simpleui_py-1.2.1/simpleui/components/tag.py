"""
标签组件
Fluent 风格标签，支持多种颜色和可移除
"""

from typing import Optional, Literal, Union
from ..core import Component


class Tag(Component):
    """
    Fluent 风格标签组件
    
    支持5种颜色变体，支持可移除功能。
    
    参数:
        text: 标签文本
        variant: 颜色变体
        removable: 是否可移除
        icon: 图标SVG路径
        onclick: 点击事件
    
    示例:
        Tag("Python", variant="primary")
        Tag("可移除", removable=True)
    """
    
    # 变体对应的CSS类
    VARIANT_CLASSES = {
        "default": "sui-tag-default",
        "primary": "sui-tag-primary",
        "success": "sui-tag-success",
        "warning": "sui-tag-warning",
        "danger": "sui-tag-danger",
    }
    
    def __init__(
        self,
        text: Optional[str] = None,
        variant: Literal["default", "primary", "success", "warning", "danger"] = "default",
        removable: bool = False,
        icon: Optional[str] = None,
        onclick: Optional[str] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.text = text
        self.variant = variant
        self.removable = removable
        self.icon = icon
        self.onclick = onclick
    
    def _get_base_classes(self) -> str:
        """获取CSS类名"""
        classes = ["sui-tag"]
        
        if self.variant in self.VARIANT_CLASSES:
            classes.append(self.VARIANT_CLASSES[self.variant])
        
        if self.removable:
            classes.append("sui-tag-removable")
        
        if self.class_name:
            classes.append(self.class_name)
        
        return " ".join(classes)
    
    def _get_attributes_str(self) -> str:
        """获取属性字符串"""
        attrs = super()._get_attributes_str()
        
        if self.onclick:
            attrs += f' onclick="{self.onclick}"'
        
        return attrs
    
    def render(self) -> str:
        """渲染标签"""
        html_parts = [f'<span {self._get_attributes_str()}>']
        
        # 图标
        if self.icon:
            html_parts.append(f'<svg viewBox="0 0 24 24" fill="currentColor" width="12" height="12">{self.icon}</svg>')
        
        # 文本
        if self.text:
            html_parts.append(self.text)
        
        # 子组件
        html_parts.append(self._render_children())
        
        # 移除按钮
        if self.removable:
            html_parts.append('<svg viewBox="0 0 24 24" fill="currentColor" width="12" height="12"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>')
        
        html_parts.append('</span>')
        
        return "".join(html_parts)
    
    @staticmethod
    def group(*tags: Union["Tag", str]) -> str:
        """
        创建标签组
        
        参数:
            *tags: 标签列表
        
        返回:
            HTML字符串
        """
        html_parts = ['<div class="sui-tag-group">']
        
        for tag in tags:
            if isinstance(tag, Tag):
                html_parts.append(tag.render())
            else:
                html_parts.append(Tag(text=str(tag)).render())
        
        html_parts.append('</div>')
        
        return "".join(html_parts)
