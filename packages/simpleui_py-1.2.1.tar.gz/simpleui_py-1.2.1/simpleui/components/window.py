"""
窗口组件
可拖动的窗口，支持子组件随窗口移动
"""

from typing import Optional, List, Union
from ..core import Component


class Window(Component):
    """
    可拖动窗口组件
    
    参数:
        title: 窗口标题
        width: 窗口宽度
        height: 窗口高度
        x: 初始X坐标
        y: 初始Y坐标
        draggable: 是否可拖动
        resizable: 是否可调整大小
        closable: 是否可关闭
        minimize: 是否可最小化
        header: 是否显示标题栏
        fixed_child: 子组件是否随窗口移动
    
    示例:
        win = Window(title="我的窗口", x=100, y=100)
        win.add_child(Button("按钮", variant="primary"))
        preview(win)
    """
    
    def __init__(
        self,
        title: str = "窗口",
        width: str = "400px",
        height: str = "300px",
        x: int = 100,
        y: int = 100,
        draggable: bool = True,
        resizable: bool = True,
        closable: bool = True,
        minimize: bool = True,
        header: bool = True,
        fixed_child: bool = True,  # 改这里
        **kwargs
    ):
        super().__init__(**kwargs)
        self.title = title
        self.width = width
        self.height = height
        self.x = x
        self.y = y
        self.draggable = draggable
        self.resizable = resizable
        self.closable = closable
        self.minimize = minimize
        self.header = header
        self.fixed_child = fixed_child  # 改这里
        self._children: List[Union[Component, str]] = []
        self._minimized = False
    
    def add_child(self, child: Union[Component, str]) -> 'Window':
        """添加子组件"""
        self._children.append(child)
        return self
    
    def _render_children(self) -> str:
        """渲染子组件"""
        return "".join(
            child.render() if isinstance(child, Component) else str(child)
            for child in self._children
        )
    
    def _get_base_classes(self) -> str:
        classes = ["sui-window"]
        if self._minimized:
            classes.append("sui-window-minimized")
        return " ".join(classes)
    
    def render(self) -> str:
        """渲染窗口"""
        # 窗口样式
        window_style = f"""
            width: {self.width};
            height: {self.height};
            left: {self.x}px;
            top: {self.y}px;
        """
        
        # 标题栏按钮
        header_buttons = ""
        if self.minimize:
            header_buttons += '<button class="sui-window-btn sui-window-minimize" onclick="suiWindowMinimize(this)">─</button>'
        if self.closable:
            header_buttons += '<button class="sui-window-btn sui-window-close" onclick="suiWindowClose(this)">✕</button>'
        
        # 拖动属性
        drag_attr = 'data-draggable="true"' if self.draggable else ''
        
        # 调整大小
        resize_handle = '<div class="sui-window-resize"></div>' if self.resizable else ''
        
        # 子组件容器 - 改这里
        children_class = "sui-window-content" if self.fixed_child else "sui-window-content-absolute"
        
        html = f'''
<div class="{self._get_base_classes()}" style="{window_style}" {drag_attr}>
    <!-- 标题栏 -->
    {'<div class="sui-window-header">' if self.header else '<div class="sui-window-header" style="display:none">'}
        <span class="sui-window-title">{self.title}</span>
        <div class="sui-window-controls">
            {header_buttons}
        </div>
    </div>
    
    <!-- 内容区域 -->
    <div class="{children_class}">
        {self._render_children()}
    </div>
    
    <!-- 调整大小手柄 -->
    {resize_handle}
</div>
'''
        return html


class WindowManager:
    """
    窗口管理器
    用于管理多个窗口
    
    示例:
        wm = WindowManager()
        wm.add_window(Window(title="窗口1"))
        wm.add_window(Window(title="窗口2"))
        preview(wm)
    """
    
    def __init__(self):
        self.windows: List[Window] = []
    
    def add_window(self, window: Window) -> 'WindowManager':
        """添加窗口"""
        self.windows.append(window)
        return self
    
    def create_window(self, title: str = "窗口", **kwargs) -> Window:
        """创建并添加窗口"""
        win = Window(title=title, **kwargs)
        self.windows.append(win)
        return win
    
    def render(self) -> str:
        """渲染所有窗口"""
        return "".join(win.render() for win in self.windows)
