"""
进度条组件
Fluent 风格进度条，支持多种状态
"""

from typing import Optional, Literal
from ..core import Component


class Progress(Component):
    """
    Fluent 风格进度条组件
    
    支持线性进度条和圆形进度条，支持多种状态颜色。
    
    参数:
        value: 当前进度值 (0-100)
        max_value: 最大值
        label: 标签文本
        show_value: 是否显示数值
        status: 状态颜色
        striped: 是否显示条纹
        height: 高度
    
    示例:
        Progress(value=75, label="下载进度")
        Progress(value=100, status="success")
        Progress.circle(value=70)
    """
    
    # 状态对应的CSS类
    STATUS_CLASSES = {
        "default": "",
        "success": "sui-progress-success",
        "warning": "sui-progress-warning",
        "danger": "sui-progress-danger",
    }
    
    def __init__(
        self,
        value: float = 0,
        max_value: float = 100,
        label: Optional[str] = None,
        show_value: bool = True,
        status: Literal["default", "success", "warning", "danger"] = "default",
        striped: bool = False,
        animated: bool = False,
        height: str = "8px",
        **kwargs
    ):
        super().__init__(**kwargs)
        self._max_value = max_value
        self.value = max(0, min(value, self._max_value))
        self.label = label
        self.show_value = show_value
        self.status = status
        self.striped = striped
        self.animated = animated
        self.height = height
    
    def _get_progress_classes(self) -> str:
        """获取进度条CSS类"""
        classes = ["sui-progress"]
        
        if self.status in self.STATUS_CLASSES:
            classes.append(self.STATUS_CLASSES[self.status])
        
        return " ".join(classes)
    
    def _get_percentage(self) -> float:
        """计算百分比"""
        if self._max_value == 0:
            return 0
        return (self.value / self._max_value) * 100
    
    def render(self) -> str:
        """渲染进度条"""
        html_parts = ['<div class="sui-progress-wrapper">']
        
        # 标签和数值
        if self.label or self.show_value:
            html_parts.append('<div class="sui-progress-label">')
            
            if self.label:
                html_parts.append(f'<span>{self.label}</span>')
            else:
                html_parts.append('<span></span>')
            
            if self.show_value:
                html_parts.append(f'<span>{round(self._get_percentage())}%</span>')
            
            html_parts.append('</div>')
        
        # 进度条
        percentage = self._get_percentage()
        html_parts.append(f'<div class="{self._get_progress_classes()}" style="height:{self.height}">')
        
        bar_style = f"width:{percentage}%"
        if self.striped:
            bar_style += ";background-image: linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-size: 1rem 1rem"
        
        html_parts.append(f'<div class="sui-progress-bar" style="{bar_style}"></div>')
        html_parts.append('</div>')
        
        html_parts.append('</div>')
        
        return "".join(html_parts)
    
    def set_value(self, value: float) -> "Progress":
        """设置当前值"""
        self.value = max(0, min(value, self._max_value))
        return self
    
    def set_status(self, status: Literal["default", "success", "warning", "danger"]) -> "Progress":
        """设置状态"""
        self.status = status
        return self
    
    @staticmethod
    def circle(
        value: float = 0,
        max_value: float = 100,
        size: int = 80,
        stroke_width: int = 6,
        status: Literal["default", "success", "warning", "danger"] = "default",
    ) -> str:
        """
        创建圆形进度条
        
        参数:
            value: 当前进度值
            max_value: 最大值
            size: 尺寸
            stroke_width: 线条宽度
            status: 状态
        
        返回:
            HTML字符串
        """
        percentage = (value / max_value) * 100 if max_value > 0 else 0
        radius = (size - stroke_width) / 2
        circumference = 2 * 3.14159 * radius
        stroke_dashoffset = circumference * (1 - percentage / 100)
        
        colors = {
            "default": "url(#progress-gradient)",
            "success": "#43e97b",
            "warning": "#fbbf24",
            "danger": "#ef4444",
        }
        
        color = colors.get(status, colors["default"])
        
        return f'''
<div class="sui-progress-circle" style="width:{size}px;height:{size}px;position:relative">
    <svg width="{size}" height="{size}" style="transform:rotate(-90deg)">
        <defs>
            <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#667eea"/>
                <stop offset="100%" stop-color="#764ba2"/>
            </linearGradient>
        </defs>
        <circle cx="{size/2}" cy="{size/2}" r="{radius}" fill="none" stroke="var(--bg-card)" stroke-width="{stroke_width}"/>
        <circle cx="{size/2}" cy="{size/2}" r="{radius}" fill="none" stroke="{color}" stroke-width="{stroke_width}" stroke-linecap="round" stroke-dasharray="{circumference}" stroke-dashoffset="{stroke_dashoffset}" style="transition:stroke-dashoffset 0.5s ease"/>
    </svg>
    <span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700;color:var(--text-primary)">{round(percentage)}%</span>
</div>
'''
