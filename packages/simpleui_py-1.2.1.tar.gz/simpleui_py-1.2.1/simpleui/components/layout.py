"""
布局组件
容器、行、列布局
"""

from typing import Optional, Union
from ..core import Component


class Container(Component):
    """
    容器组件
    
    用于包裹内容，提供最大宽度限制和居中。
    
    参数:
        max_width: 最大宽度
        padding: 内边距
        centered: 是否居中
    
    示例:
        container = Container()
        container.add_child(Button("按钮"))
    """
    
    def __init__(
        self,
        max_width: str = "1200px",
        padding: str = "2rem",
        centered: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.max_width = max_width
        self.padding = padding
        self.centered = centered
    
    def _get_base_classes(self) -> str:
        return f"sui-container {self.class_name}".strip()
    
    def _get_style_str(self) -> str:
        styles = super()._get_style_str()
        custom_styles = f"max-width:{self.max_width};padding:{self.padding}"
        if self.centered:
            custom_styles += ";margin:0 auto"
        if styles:
            return f"{styles};{custom_styles}"
        return custom_styles
    
    def render(self) -> str:
        return f'<div {self._get_attributes_str()}>{self._render_children()}</div>'


class Row(Component):
    """
    行组件（Flex布局）
    
    用于水平排列子组件。
    
    参数:
        gap: 间距
        align: 垂直对齐
        justify: 水平对齐
        wrap: 是否换行
    
    示例:
        row = Row(gap="1rem")
        row.add_child(Button("按钮1"))
        row.add_child(Button("按钮2"))
    """
    
    ALIGN_MAP = {
        "start": "flex-start",
        "center": "center",
        "end": "flex-end",
        "stretch": "stretch",
    }
    
    JUSTIFY_MAP = {
        "start": "flex-start",
        "center": "center",
        "end": "flex-end",
        "between": "space-between",
        "around": "space-around",
    }
    
    def __init__(
        self,
        gap: str = "1rem",
        align: str = "center",
        justify: str = "start",
        wrap: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.gap = gap
        self.align = align
        self.justify = justify
        self.wrap = wrap
    
    def _get_base_classes(self) -> str:
        return f"sui-row {self.class_name}".strip()
    
    def _get_style_str(self) -> str:
        styles = super()._get_style_str()
        
        flex_styles = [
            "display:flex",
            f"gap:{self.gap}",
            f"align-items:{self.ALIGN_MAP.get(self.align, self.align)}",
            f"justify-content:{self.JUSTIFY_MAP.get(self.justify, self.justify)}",
        ]
        
        if self.wrap:
            flex_styles.append("flex-wrap:wrap")
        
        custom_styles = ";".join(flex_styles)
        
        if styles:
            return f"{styles};{custom_styles}"
        return custom_styles
    
    def render(self) -> str:
        return f'<div {self._get_attributes_str()}>{self._render_children()}</div>'
    
    def add_column(self, child: Union[Component, str], flex: int = 1) -> "Row":
        """添加列"""
        col = Column(child, flex=flex)
        self.add_child(col)
        return self


class Column(Component):
    """
    列组件
    
    用于在行中占据一定比例的空间。
    
    参数:
        content: 内容
        flex: 弹性比例
        min_width: 最小宽度
    
    示例:
        col = Column(flex=2)
        col.add_child(Button("按钮"))
    """
    
    def __init__(
        self,
        content: Optional[Union[Component, str]] = None,
        flex: int = 1,
        min_width: str = "200px",
        **kwargs
    ):
        super().__init__(**kwargs)
        self.flex = flex
        self.min_width = min_width
        
        if content:
            self.add_child(content)
    
    def _get_base_classes(self) -> str:
        return f"sui-column {self.class_name}".strip()
    
    def _get_style_str(self) -> str:
        styles = super()._get_style_str()
        custom_styles = f"flex:{self.flex};min-width:{self.min_width}"
        if styles:
            return f"{styles};{custom_styles}"
        return custom_styles
    
    def render(self) -> str:
        return f'<div {self._get_attributes_str()}>{self._render_children()}</div>'
