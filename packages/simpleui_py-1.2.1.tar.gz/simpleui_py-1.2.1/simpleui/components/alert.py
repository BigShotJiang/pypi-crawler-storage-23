"""提示组件"""
from ..core import Component


class Alert(Component):
    """Fluent 风格提示组件"""
    
    VARIANTS = {
        "info": "sui-alert-info",
        "success": "sui-alert-success",
        "warning": "sui-alert-warning",
        "danger": "sui-alert-danger",
    }
    
    ICONS = {
        "info": '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>',
        "success": '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
        "warning": '<path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>',
        "danger": '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>',
    }
    
    def __init__(
        self,
        title: str = "",
        text: str = "",
        variant: str = "info",
        closable: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.title = title
        self.text = text
        self.variant = variant
        self.closable = closable
    
    def _get_base_classes(self) -> str:
        return f"sui-alert {self.VARIANTS.get(self.variant, 'sui-alert-info')} {self.class_name}".strip()
    
    def render(self) -> str:
        icon = self.ICONS.get(self.variant, self.ICONS["info"])
        close_btn = '<button class="sui-alert-close" onclick="this.parentElement.remove()">✕</button>' if self.closable else ""
        
        return f'''<div class="{self._get_base_classes()}">
    <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">{icon}</svg>
    <div class="sui-alert-content">
        <div class="sui-alert-title">{self.title}</div>
        <div class="sui-alert-text">{self.text}</div>
    </div>
    {close_btn}
</div>'''
    
    @staticmethod
    def info(title="", text="", **kw): 
        return Alert(title, text, "info", **kw)
    
    @staticmethod
    def success(title="", text="", **kw): 
        return Alert(title, text, "success", **kw)
    
    @staticmethod
    def warning(title="", text="", **kw): 
        return Alert(title, text, "warning", **kw)
    
    @staticmethod
    def danger(title="", text="", **kw): 
        return Alert(title, text, "danger", **kw)
    
    @staticmethod
    def error(title="", text="", **kw): 
        return Alert(title, text, "danger", **kw)
