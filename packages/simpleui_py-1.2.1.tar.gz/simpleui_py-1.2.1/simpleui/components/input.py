"""
输入框组件
Fluent 风格输入框，支持验证状态和图标
"""

from typing import Optional, Literal
from ..core import Component


class Input(Component):
    """
    Fluent 风格输入框组件
    
    支持多种输入类型、验证状态、图标等。
    
    参数:
        label: 标签文本
        placeholder: 占位符
        value: 默认值
        type: 输入类型
        status: 验证状态
        helper_text: 帮助文本
        icon: 图标SVG路径
        disabled: 是否禁用
        required: 是否必填
        readonly: 是否只读
        maxlength: 最大长度
        onchange: 值改变事件
        oninput: 输入事件
    
    示例:
        Input(label="用户名", placeholder="请输入")
        Input(label="密码", type="password")
        Input(label="搜索", icon=Input.ICONS["search"])
    """
    
    # 状态对应的CSS类
    STATUS_CLASSES = {
        "default": "",
        "success": "sui-input-success",
        "error": "sui-input-error",
    }
    
    # 预设图标
    ICONS = {
        "search": '<path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>',
        "user": '<path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>',
        "mail": '<path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>',
        "lock": '<path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>',
        "phone": '<path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>',
        "calendar": '<path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM9 10H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm-8 4H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2z"/>',
        "link": '<path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/>',
        "dollar": '<path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>',
    }
    
    def __init__(
        self,
        label: Optional[str] = None,
        placeholder: Optional[str] = None,
        value: Optional[str] = None,
        type: str = "text",
        status: Literal["default", "success", "error"] = "default",
        helper_text: Optional[str] = None,
        icon: Optional[str] = None,
        disabled: bool = False,
        required: bool = False,
        readonly: bool = False,
        maxlength: Optional[int] = None,
        minlength: Optional[int] = None,
        onchange: Optional[str] = None,
        oninput: Optional[str] = None,
        onfocus: Optional[str] = None,
        onblur: Optional[str] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.label = label
        self.placeholder = placeholder
        self.value = value
        self.type = type
        self.status = status
        self.helper_text = helper_text
        self.icon = icon
        self.disabled = disabled
        self.required = required
        self.readonly = readonly
        self.maxlength = maxlength
        self.minlength = minlength
        self.onchange = onchange
        self.oninput = oninput
        self.onfocus = onfocus
        self.onblur = onblur
    
    def _get_input_classes(self) -> str:
        """获取输入框CSS类"""
        classes = ["sui-input"]
        
        if self.status in self.STATUS_CLASSES:
            classes.append(self.STATUS_CLASSES[self.status])
        
        return " ".join(classes)
    
    def _get_input_attributes(self) -> str:
        """获取输入框属性"""
        attrs = [
            f'type="{self.type}"',
            f'class="{self._get_input_classes()}"',
        ]
        
        if self.placeholder:
            attrs.append(f'placeholder="{self.placeholder}"')
        
        if self.value:
            attrs.append(f'value="{self.value}"')
        
        if self.disabled:
            attrs.append("disabled")
        
        if self.required:
            attrs.append("required")
        
        if self.readonly:
            attrs.append("readonly")
        
        if self.maxlength:
            attrs.append(f'maxlength="{self.maxlength}"')
        
        if self.minlength:
            attrs.append(f'minlength="{self.minlength}"')
        
        if self.onchange:
            attrs.append(f'onchange="{self.onchange}"')
        
        if self.oninput:
            attrs.append(f'oninput="{self.oninput}"')
        
        if self.onfocus:
            attrs.append(f'onfocus="{self.onfocus}"')
        
        if self.onblur:
            attrs.append(f'onblur="{self.onblur}"')
        
        return " ".join(attrs)
    
    def render(self) -> str:
        """渲染输入框"""
        html_parts = ['<div class="sui-input-wrapper">']
        
        # 标签
        if self.label:
            required_mark = " *" if self.required else ""
            html_parts.append(f'<label class="sui-input-label">{self.label}{required_mark}</label>')
        
        # 输入框（带图标或不带图标）
        if self.icon:
            html_parts.append('<div class="sui-input-icon-wrapper">')
            html_parts.append(f'<span class="sui-input-icon"><svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18">{self.icon}</svg></span>')
            html_parts.append(f'<input {self._get_input_attributes()}>')
            html_parts.append('</div>')
        else:
            html_parts.append(f'<input {self._get_input_attributes()}>')
        
        # 帮助文本
        if self.helper_text:
            helper_class = "sui-input-helper"
            if self.status == "error":
                helper_class += " sui-input-error-text"
            html_parts.append(f'<span class="{helper_class}">{self.helper_text}</span>')
        
        html_parts.append('</div>')
        
        return "".join(html_parts)


class TextArea(Component):
    """
    多行文本输入框
    
    参数:
        label: 标签文本
        placeholder: 占位符
        value: 默认值
        rows: 行数
        status: 验证状态
        helper_text: 帮助文本
        disabled: 是否禁用
        required: 是否必填
        readonly: 是否只读
        maxlength: 最大长度
    
    示例:
        TextArea(label="描述", placeholder="请输入详细描述...", rows=4)
    """
    
    def __init__(
        self,
        label: Optional[str] = None,
        placeholder: Optional[str] = None,
        value: Optional[str] = None,
        rows: int = 4,
        status: Literal["default", "success", "error"] = "default",
        helper_text: Optional[str] = None,
        disabled: bool = False,
        required: bool = False,
        readonly: bool = False,
        maxlength: Optional[int] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.label = label
        self.placeholder = placeholder
        self.value = value
        self.rows = rows
        self.status = status
        self.helper_text = helper_text
        self.disabled = disabled
        self.required = required
        self.readonly = readonly
        self.maxlength = maxlength
    
    def render(self) -> str:
        """渲染多行文本框"""
        html_parts = ['<div class="sui-input-wrapper">']
        
        # 标签
        if self.label:
            required_mark = " *" if self.required else ""
            html_parts.append(f'<label class="sui-input-label">{self.label}{required_mark}</label>')
        
        # 状态类
        status_class = Input.STATUS_CLASSES.get(self.status, "")
        classes = f"sui-input sui-textarea {status_class}".strip()
        
        # 属性
        attrs = [f'class="{classes}"', f'rows="{self.rows}"']
        
        if self.placeholder:
            attrs.append(f'placeholder="{self.placeholder}"')
        
        if self.disabled:
            attrs.append("disabled")
        
        if self.required:
            attrs.append("required")
        
        if self.readonly:
            attrs.append("readonly")
        
        if self.maxlength:
            attrs.append(f'maxlength="{self.maxlength}"')
        
        # 文本框
        html_parts.append(f'<textarea {" ".join(attrs)}>{self.value or ""}</textarea>')
        
        # 帮助文本
        if self.helper_text:
            helper_class = "sui-input-helper"
            if self.status == "error":
                helper_class += " sui-input-error-text"
            html_parts.append(f'<span class="{helper_class}">{self.helper_text}</span>')
        
        html_parts.append('</div>')
        
        return "".join(html_parts)
