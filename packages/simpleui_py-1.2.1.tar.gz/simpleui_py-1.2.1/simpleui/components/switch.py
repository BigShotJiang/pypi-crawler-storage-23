"""
开关组件
Fluent 风格开关，支持多种尺寸
"""

from typing import Optional, Literal
from ..core import Component


class Switch(Component):
    """
    Fluent 风格开关组件
    
    支持三种尺寸：sm, md, lg
    
    参数:
        label: 标签文本
        checked: 是否选中
        disabled: 是否禁用
        size: 尺寸
        onchange: 改变事件
    
    示例:
        Switch("启用功能", checked=True)
        Switch("小尺寸", size="sm")
        Switch("大尺寸", size="lg")
    """
    
    # 尺寸对应的CSS类
    SIZE_CLASSES = {
        "sm": "sui-switch-sm",
        "md": "",
        "lg": "sui-switch-lg",
    }
    
    def __init__(
        self,
        label: Optional[str] = None,
        checked: bool = False,
        disabled: bool = False,
        size: Literal["sm", "md", "lg"] = "md",
        onchange: Optional[str] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.label = label
        self.checked = checked
        self.disabled = disabled
        self.size = size
        self.onchange = onchange
    
    def _get_switch_classes(self) -> str:
        """获取开关CSS类"""
        classes = ["sui-switch"]
        
        if self.size in self.SIZE_CLASSES:
            classes.append(self.SIZE_CLASSES[self.size])
        
        return " ".join(classes)
    
    def _get_switch_attributes(self) -> str:
        """获取开关属性"""
        attrs = [
            'type="checkbox"',
            f'class="{self._get_switch_classes()}"',
            f'id="{self.id}"',
        ]
        
        if self.checked:
            attrs.append("checked")
        
        if self.disabled:
            attrs.append("disabled")
        
        if self.onchange:
            attrs.append(f'onchange="{self.onchange}"')
        
        return " ".join(attrs)
    
    def render(self) -> str:
        """渲染开关"""
        html_parts = ['<div class="sui-switch-wrapper">']
        
        html_parts.append(f'<input {self._get_switch_attributes()}>')
        
        if self.label:
            html_parts.append(f'<label class="sui-switch-label" for="{self.id}">{self.label}</label>')
        
        html_parts.append('</div>')
        
        return "".join(html_parts)
