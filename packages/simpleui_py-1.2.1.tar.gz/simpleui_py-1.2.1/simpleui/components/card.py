"""
卡片组件
Fluent 风格卡片，支持图片和多种变体
"""

from typing import Optional, Literal, Union
from ..core import Component


class Card(Component):
    """
    Fluent 风格卡片组件
    
    支持图片、多种变体、交互效果。
    
    参数:
        title: 标题
        text: 描述文本
        image: 图片URL或背景色
        image_height: 图片高度
        variant: 变体
        footer: 底部内容
        onclick: 点击事件
    
    示例:
        Card(title="标题", text="描述")
        Card(title="标题", image="var(--gradient-1)")
        Card(title="标题", variant="elevated")
    """
    
    # 变体对应的CSS类
    VARIANT_CLASSES = {
        "default": "",
        "elevated": "sui-card-elevated",
        "outlined": "sui-card-outlined",
    }
    
    def __init__(
        self,
        title: Optional[str] = None,
        text: Optional[str] = None,
        image: Optional[str] = None,
        image_height: str = "120px",
        variant: Literal["default", "elevated", "outlined"] = "default",
        footer: Optional[Union[str, Component]] = None,
        onclick: Optional[str] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.title = title
        self.text = text
        self.image = image
        self.image_height = image_height
        self.variant = variant
        self.footer = footer
        self.onclick = onclick
    
    def _get_base_classes(self) -> str:
        """获取CSS类名"""
        classes = ["sui-card"]
        
        if self.variant in self.VARIANT_CLASSES:
            classes.append(self.VARIANT_CLASSES[self.variant])
        
        if self.onclick:
            classes.append("sui-card-interactive")
        
        if self.class_name:
            classes.append(self.class_name)
        
        return " ".join(classes)
    
    def _get_attributes_str(self) -> str:
        """获取属性字符串"""
        attrs = super()._get_attributes_str()
        
        if self.onclick:
            attrs += f' onclick="{self.onclick}"'
        
        return attrs
    
    def render(self) -> str:
        """渲染卡片"""
        html_parts = [f'<div {self._get_attributes_str()}>']
        
        # 图片
        if self.image:
            if self.image.startswith("http") or self.image.startswith("/"):
                html_parts.append(f'<img class="sui-card-img" src="{self.image}" alt="{self.title or ""}">')
            else:
                html_parts.append(f'<div class="sui-card-img" style="background:{self.image};height:{self.image_height}"></div>')
        
        # 内容
        html_parts.append('<div class="sui-card-body">')
        
        if self.title:
            html_parts.append(f'<h4 class="sui-card-title">{self.title}</h4>')
        
        if self.text:
            html_parts.append(f'<p class="sui-card-text">{self.text}</p>')
        
        # 子组件
        html_parts.append(self._render_children())
        
        html_parts.append('</div>')
        
        # 底部
        if self.footer:
            html_parts.append('<div class="sui-card-footer">')
            if isinstance(self.footer, Component):
                html_parts.append(self.footer.render())
            else:
                html_parts.append(str(self.footer))
            html_parts.append('</div>')
        
        html_parts.append('</div>')
        
        return "".join(html_parts)
    
    def set_image(self, image: str, height: Optional[str] = None) -> "Card":
        """设置图片"""
        self.image = image
        if height:
            self.image_height = height
        return self
    
    def set_footer(self, footer: Union[str, Component]) -> "Card":
        """设置底部"""
        self.footer = footer
        return self
