"""
SimpleUI - Fluent 风格 Python UI 组件库
简约设计，无限可能
"""

__version__ = "1.2.1"
__author__ = "SimpleUI Team"

# 从 core 导入核心功能
from .core import (
    Component,
    Theme,
    ThemeType,
    render_html,
    export_html,
    set_theme,
    get_theme,
)

# 从 components 导入所有组件
from .components import (
    Button,
    ButtonGroup,
    Input,
    TextArea,
    Card,
    Switch,
    Tag,
    Progress,
    Alert,
    Container,
    Row,
    Column,
)

# 从 utils 导入工具函数
from .utils import preview, serve, demo, playground

# 导出列表
__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    
    # 核心类
    "Component",
    "Theme",
    "ThemeType",
    "render_html",
    "export_html",
    "set_theme",
    "get_theme",
    
    # 组件
    "Button",
    "ButtonGroup",
    "Input",
    "TextArea",
    "Card",
    "Switch",
    "Tag",
    "Progress",
    "Alert",
    "Container",
    "Row",
    "Column",
    
    # 工具函数
    "preview",
    "serve",
    "demo",
    "playground",
]
