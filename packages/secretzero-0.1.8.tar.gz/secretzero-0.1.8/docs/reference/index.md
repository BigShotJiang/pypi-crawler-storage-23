# Reference

Authoritative reference material for SecretZero.

## Contents

- [Architecture](architecture.md)
- [Data Models](models.md)
- [CLI Reference](cli.md)
- [Security](security.md)
- [FAQ](faq.md)
- [Troubleshooting](troubleshooting.md)
- [Changelog](changelog.md)
