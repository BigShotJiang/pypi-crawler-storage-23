# Documentation

Documentation is written in Markdown and built with MkDocs.

## Build Docs

```bash
task docs:build
```

## Notes

- Keep pages concise
- Link to related pages where appropriate
