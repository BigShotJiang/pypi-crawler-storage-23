from .network import (
    Route as Route,
    SourceAddress as SourceAddress,
    NetworkInterface as NetworkInterface,
    NetworkInterfaceGroup as NetworkInterfaceGroup,
    InterfaceState as InterfaceState,
    InterfaceShapingPolicy as InterfaceShapingPolicy,
    FluxShapingPolicy as FluxShapingPolicy,
)
from .dns import (
    ResolvedDnsServer as ResolvedDnsServer,
    ResolvedHostname as ResolvedHostname,
)
