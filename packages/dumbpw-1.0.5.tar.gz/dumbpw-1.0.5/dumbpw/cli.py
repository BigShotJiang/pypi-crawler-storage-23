"""Create a command-line interface entrypoint."""

import fileinput
import sys
from typing import NoReturn

import click
import deal

from dumbpw.constants import (
    DEFAULT_BLOCKS,
    PASSWORD_LENGTH_MAX,
    PASSWORD_LENGTH_MIN,
)
from dumbpw.engine import search
from dumbpw.errors import DumbConstraintError, DumbExitCode, DumbValueError
from dumbpw.settings import Settings


@click.command(
    no_args_is_help=True,
    name="dumbpw",
)
@click.version_option()
@click.option(
    "--min-uppercase",
    type=int,
    default=1,
    show_default=True,
    help="The minimum number of uppercase characters.",
)
@click.option(
    "--min-lowercase",
    type=int,
    default=1,
    show_default=True,
    help="The minimum number of lowercase characters.",
)
@click.option(
    "--min-digits",
    type=int,
    default=1,
    show_default=True,
    help="The minimum number of digit characters.",
)
@click.option(
    "--min-specials",
    type=int,
    default=0,
    show_default=True,
    help="The minimum number of special characters.",
)
@click.option(
    "--blocklist",
    type=str,
    default=DEFAULT_BLOCKS,
    show_default=True,
    help="Characters that may not be in the password.",
)
@click.option(
    "--allow-repeating/--reject-repeating",
    help="Allow or reject repeating characters in the password.",
    default=False,
    show_default=True,
)
@click.argument(
    "length",
    type=click.IntRange(
        min=PASSWORD_LENGTH_MIN,
        max=PASSWORD_LENGTH_MAX,
    ),
)
@click.option(
    "--specials",
    envvar="DUMBPW_SPECIALS",
    help=(
        "Non-alphanumeric characters that may be in the password. "
        "Pass '-' to read from standard input."
    ),
)
@deal.has("io", "global", "stderr", "stdout")
@deal.raises(SystemExit, RuntimeError)
def cli(  # noqa: PLR0913
    *,
    length: int,
    min_uppercase: int,
    min_lowercase: int,
    min_digits: int,
    min_specials: int,
    specials: str,
    blocklist: str,
    allow_repeating: bool,
) -> NoReturn:
    """Generate a secure password conforming to dumb rules."""
    if specials == "-":
        with fileinput.input(files="-") as data:
            specials = "".join(char for char in data).strip()

    settings = Settings(
        length=length,
        min_uppercase=min_uppercase,
        min_lowercase=min_lowercase,
        min_digits=min_digits,
        min_specials=min_specials,
        specials=specials,
        blocklist=blocklist,
        allow_repeating=allow_repeating,
    )
    try:
        try_password = search(settings)
    except DumbValueError as dve:
        print(dve, file=sys.stderr)
        sys.exit(1)
    except DumbConstraintError as dce:
        print(dce, file=sys.stderr)
        sys.exit(1)
    else:
        print(try_password)
        sys.exit(DumbExitCode.OK)
