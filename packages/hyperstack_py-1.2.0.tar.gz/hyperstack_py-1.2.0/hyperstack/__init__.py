"""
HyperStack Python SDK
Cloud memory for AI agents. 3 lines to integrate.

Usage:
    from hyperstack import HyperStack

    hs = HyperStack("hs_your_key")
    hs.store("project-api", "API", "FastAPI on AWS", stack="projects", keywords=["fastapi", "python"])
    results = hs.search("python")
    cards = hs.list()
    hs.delete("project-api")
    stats = hs.stats()

    # Graph features (Pro)
    graph = hs.graph("project-api", depth=2)
    impact = hs.impact("project-api")
    recs = hs.recommend("project-api")
    result = hs.smart_search("what depends on the API?")

Install:
    pip install hyperstack-py

Docs: https://cascadeai.dev
"""

import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, List, Dict, Any

__version__ = "1.1.0"

DEFAULT_API_URL = "https://hyperstack-cloud.vercel.app"


class HyperStackError(Exception):
    """Base exception for HyperStack errors."""
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


class HyperStack:
    """
    HyperStack client — cloud memory for AI agents.

    Args:
        api_key: Your HyperStack API key (starts with hs_)
        workspace: Workspace name (default: "default")
        api_url: API base URL (default: production)
    """

    def __init__(
        self,
        api_key: str,
        workspace: str = "default",
        api_url: str = DEFAULT_API_URL,
    ):
        if not api_key:
            raise HyperStackError("API key required. Get one free at https://cascadeai.dev")
        self.api_key = api_key
        self.workspace = workspace
        self.api_url = api_url.rstrip("/")

    def _request(self, endpoint: str, method: str = "GET", body: Optional[dict] = None, params: Optional[dict] = None) -> dict:
        """Make an API request."""
        url = f"{self.api_url}/api/{endpoint}?workspace={urllib.parse.quote(self.workspace)}"
        if params:
            for k, v in params.items():
                url += f"&{urllib.parse.quote(k)}={urllib.parse.quote(str(v))}"

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body_text = e.read().decode("utf-8", errors="replace")
            try:
                err_data = json.loads(body_text)
                msg = err_data.get("error", body_text)
            except Exception:
                msg = body_text
            raise HyperStackError(msg, status=e.code)
        except urllib.error.URLError as e:
            raise HyperStackError(f"Connection failed: {e.reason}")

    def store(
        self,
        slug: str,
        title: str,
        body: str,
        stack: str = "general",
        keywords: Optional[List[str]] = None,
        card_type: str = "general",
        links: Optional[List[Dict[str, str]]] = None,
        source_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
    ) -> dict:
        """
        Store or update a memory card.

        Args:
            slug: Unique ID (kebab-case, e.g. "project-webapp")
            title: Short title
            body: The knowledge to remember
            stack: Category (projects|people|decisions|preferences|workflows|general)
            keywords: Tags for search
            card_type: Type (person|project|decision|preference|workflow|event|general|signal)
            links: List of dicts with 'target' and 'relation' keys
            source_agent: Agent storing this card
            target_agent: Agent this card is directed at (for inter-agent signals)

        Returns:
            Card data dict
        """
        payload = {
            "slug": slug,
            "title": title,
            "body": body,
            "stack": stack,
            "cardType": card_type,
            "keywords": keywords or [],
        }
        if links:
            payload["links"] = links
        if source_agent:
            payload["sourceAgent"] = source_agent
        if target_agent:
            payload["targetAgent"] = target_agent

        return self._request("cards", method="POST", body=payload)

    def search(self, query: str) -> List[dict]:
        """
        Search memory cards using vector + graph (GraphRAG).

        Args:
            query: Search term

        Returns:
            List of matching cards
        """
        result = self._request("search", params={"q": query})
        return result.get("results", result.get("cards", []))

    def smart_search(self, query: str, slug: Optional[str] = None) -> dict:
        """
        Agentic RAG — automatically routes to the best retrieval mode
        (search, graph traversal, or impact analysis) based on the query.

        Args:
            query: Natural language query
            slug: Optional hint for a specific starting card slug

        Returns:
            Dict with results, mode, autoRoutedTo, and chain
        """
        params = {"q": query, "mode": "auto"}
        if slug:
            params["slug"] = slug
        return self._request("search", params=params)

    def list(self, stack: Optional[str] = None) -> List[dict]:
        """
        List all memory cards.

        Args:
            stack: Filter by stack (optional)

        Returns:
            List of all cards
        """
        result = self._request("cards")
        cards = result.get("cards", [])
        if stack:
            cards = [c for c in cards if c.get("stack") == stack]
        return cards

    def get(self, slug: str) -> Optional[dict]:
        """
        Get a specific card by slug.

        Args:
            slug: Card slug

        Returns:
            Card dict or None
        """
        cards = self.list()
        for card in cards:
            if card.get("slug") == slug:
                return card
        return None

    def delete(self, slug: str) -> dict:
        """
        Delete a memory card.

        Args:
            slug: Card slug to delete

        Returns:
            Response dict
        """
        return self._request("cards", method="DELETE", params={"id": slug})

    def graph(
        self,
        from_slug: str,
        depth: int = 1,
        relation: Optional[str] = None,
        at: Optional[str] = None,
    ) -> dict:
        """
        Traverse the knowledge graph forward from a starting card.
        Shows connected cards and relationships. Requires Pro plan.

        Args:
            from_slug: Card slug to start traversal from
            depth: How many hops to traverse (1-3)
            relation: Filter by relation type (e.g. 'owns', 'triggers', 'blocks')
            at: ISO timestamp for time-travel (e.g. '2026-02-01T00:00:00Z')

        Returns:
            Dict with nodes, edges, and chain
        """
        params = {"from": from_slug, "depth": str(depth)}
        if relation:
            params["relation"] = relation
        if at:
            params["at"] = at
        return self._request("graph", params=params)

    def impact(
        self,
        slug: str,
        depth: int = 2,
        relation: Optional[str] = None,
    ) -> dict:
        """
        Reverse traversal — finds all cards that point TO a given card.
        Answers: 'what depends on X?' or 'what would break if X changed?'
        Requires Pro plan.

        Args:
            slug: Card slug to analyse
            depth: How many hops to traverse upstream (1-3)
            relation: Filter by relation type (e.g. 'blocks', 'depends-on')

        Returns:
            Dict with nodes, edges, and chain
        """
        params = {"from": slug, "depth": str(depth), "mode": "impact"}
        if relation:
            params["relation"] = relation
        return self._request("graph", params=params)

    def recommend(self, slug: str, limit: int = 5) -> List[dict]:
        """
        Find related cards using co-citation scoring.
        Discovers non-obvious connections via shared graph neighbours.
        Requires Pro plan.

        Args:
            slug: Card slug to find recommendations for
            limit: Maximum number of recommendations (1-20)

        Returns:
            List of recommended cards with scores
        """
        params = {"from": slug, "mode": "recommend", "limit": str(limit)}
        result = self._request("graph", params=params)
        return result.get("recommendations", result.get("nodes", []))

    def stats(self) -> dict:
        """
        Get memory usage stats.

        Returns:
            Dict with card count, plan, limit, token stats
        """
        result = self._request("cards")
        cards = result.get("cards", [])
        total_tokens = sum(c.get("tokens", 0) for c in cards)
        without_hs = len(cards) * 6000

        stacks: Dict[str, int] = {}
        for c in cards:
            s = c.get("stack", "general")
            stacks[s] = stacks.get(s, 0) + 1

        return {
            "cards": len(cards),
            "plan": result.get("plan", "FREE"),
            "limit": result.get("limit", 50),
            "tokens_stored": total_tokens,
            "tokens_without_hs": without_hs,
            "savings_pct": round((1 - total_tokens / without_hs) * 100) if without_hs > 0 else 0,
            "stacks": stacks,
        }

    def ingest(self, text: str, source: str = "conversation") -> dict:
        """
        Auto-extract memory cards from raw text.

        Args:
            text: Raw conversation or document text
            source: Source identifier

        Returns:
            Dict with extracted count and created cards
        """
        return self._request("ingest", method="POST", body={
            "text": text,
            "workspace": self.workspace,
            "source": source,
        })

    def __repr__(self) -> str:
        return f"HyperStack(workspace='{self.workspace}', key='...{self.api_key[-6:]}')"
