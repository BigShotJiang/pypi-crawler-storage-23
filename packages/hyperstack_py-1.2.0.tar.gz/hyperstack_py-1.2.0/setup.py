from setuptools import setup, find_packages

setup(
    name="hyperstack-py",
    version="1.2.0",
    description="Cloud memory for AI agents. 3 lines to integrate. No SDK dependencies.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="CascadeAI",
    author_email="deeq.yaqub1@gmail.com",
    url="https://cascadeai.dev",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],  # Zero dependencies!
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai memory agent llm hyperstack mcp claude cursor",
    license="MIT",
    project_urls={
        "Documentation": "https://cascadeai.dev",
        "Source": "https://github.com/deeqyaqub1-cmd/hyperstack-py",
        "Discord": "https://discord.gg/tdnXaV6e",
    },
)
