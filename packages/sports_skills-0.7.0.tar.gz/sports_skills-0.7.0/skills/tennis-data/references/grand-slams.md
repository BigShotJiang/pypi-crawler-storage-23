# Grand Slam Tournaments

| Tournament | Months | Surface | Location |
|-----------|--------|---------|----------|
| Australian Open | January | Hard | Melbourne, Australia |
| Roland Garros (French Open) | May-June | Clay | Paris, France |
| Wimbledon | June-July | Grass | London, England |
| US Open | August-September | Hard | New York, USA |

Grand Slams are marked with `"major": true` in the calendar.
