from .test_harness import (
    check_result,
    pause
)