# Image Utils

A small Python package to rotate images from Python or the command line.
## Command-Line Usage

After installing, you can use the CLI command `rotate-image` instead of py main.py:

## Installation

### Development (editable install)
For testing or contributing:

```bash
git clone https://github.com/rick-rocks123/image_utils.git
cd <repo-folder> 
pip install -e .