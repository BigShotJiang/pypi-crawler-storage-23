"""
GCP Pipeline Core Library
"""
__version__ = "1.0.3"
