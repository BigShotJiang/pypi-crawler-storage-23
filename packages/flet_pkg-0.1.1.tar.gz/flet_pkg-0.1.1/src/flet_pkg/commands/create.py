"""Create command for flet-pkg.

Orchestrates the full extension creation flow: type detection, name
derivation, registry checking, scaffolding, pipeline analysis, and
optional AI refinement.
"""

from pathlib import Path
from typing import Optional

import typer

from flet_pkg.core.prompts import ask, ask_choice, ask_confirm
from flet_pkg.core.registry_checker import (
    RegistryMatch,
    check_flet_packages,
    check_github,
    check_pypi,
)
from flet_pkg.core.scaffolder import Scaffolder
from flet_pkg.core.validators import (
    derive_names,
    validate_control_name,
    validate_flutter_package,
    validate_package_name,
    validate_project_name,
)
from flet_pkg.ui.console import console
from flet_pkg.ui.panels import error_panel, header_panel, info_panel
from flet_pkg.ui.tree import print_tree

EXTENSION_TYPES = {
    1: ("auto", "Auto-detect (recommended)"),
    2: ("service", "Service (no visual interface)"),
    3: ("ui_control", "UI Control (visual widget)"),
}


def create(
    # -- Package options --
    extension_type: Optional[str] = typer.Option(
        None,
        "--type",
        "-t",
        help="Extension type: [cyan]auto[/cyan], [cyan]service[/cyan] or [cyan]ui_control[/cyan].",
        rich_help_panel="Package Options",
    ),
    flutter_package: Optional[str] = typer.Option(
        None,
        "--flutter-package",
        "-f",
        help="Flutter package name from [link=https://pub.dev]pub.dev[/link].",
        rich_help_panel="Package Options",
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory for the generated project.",
        rich_help_panel="Package Options",
    ),
    local_package: Optional[Path] = typer.Option(
        None,
        "--local-package",
        "-l",
        help="Path to a local Flutter package (skips pub.dev download).",
        rich_help_panel="Package Options",
    ),
    # -- Code generation options --
    analyze: bool = typer.Option(
        True,
        "--analyze/--no-analyze",
        help=(
            "Analyze the Flutter package and auto-generate Python controls, "
            "type mappings, and Dart bridge code."
        ),
        rich_help_panel="Code Generation",
    ),
    console_module: Optional[bool] = typer.Option(
        None,
        "--console/--no-console",
        help="Include a debug console module for development logging.",
        rich_help_panel="Code Generation",
    ),
    # -- AI refinement options --
    ai_refine: Optional[bool] = typer.Option(
        None,
        "--ai-refine/--no-ai-refine",
        help=(
            "Run AI-powered refinement on generated code. "
            "An LLM analyzes coverage gaps and applies structured edits "
            "using the Architect/Editor pattern. "
            "Install: [cyan]uv add flet-pkg\\[ai][/cyan]. "
            "Set the API key for your provider (e.g. ANTHROPIC_API_KEY). "
            "In interactive mode, you will be prompted if pydantic-ai is installed."
        ),
        rich_help_panel="AI Refinement",
    ),
    ai_provider: Optional[str] = typer.Option(
        None,
        "--ai-provider",
        help=(
            "AI provider: "
            "[cyan]ollama[/cyan] (local, free — no API key), "
            "[cyan]anthropic[/cyan] (Claude), "
            "[cyan]openai[/cyan] (GPT), or "
            "[cyan]google[/cyan] (Gemini). "
            "Cloud providers need an API key via env var: "
            "ANTHROPIC_API_KEY, OPENAI_API_KEY, or GOOGLE_API_KEY. "
            "[dim]\\[default: ollama][/dim]"
        ),
        rich_help_panel="AI Refinement",
    ),
    ai_model: Optional[str] = typer.Option(
        None,
        "--ai-model",
        help=(
            "Override the default model for the selected provider. "
            "Defaults: anthropic=[dim]claude-sonnet-4-6[/dim], "
            "openai=[dim]gpt-4.1-mini[/dim], "
            "google=[dim]gemini-2.5-flash[/dim], "
            "ollama=[dim]qwen2.5-coder:14b[/dim]."
        ),
        rich_help_panel="AI Refinement",
    ),
    # -- Output options --
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed analysis output and coverage breakdown table.",
        rich_help_panel="Output",
    ),
) -> None:
    """[bold]Create a new Flet extension package.[/bold]

    Scaffolds a complete project structure and optionally analyzes the Flutter
    package to auto-generate Python controls, Dart bridge code, type mappings,
    event handlers, and enum definitions.

    [dim]AI refinement (--ai-refine) uses an LLM to detect and fill coverage
    gaps that the deterministic pipeline missed. Requires the \\[ai] extra:[/dim]

    [green]$[/green] uv add flet-pkg\\[ai]
    [green]$[/green] ollama pull qwen2.5-coder:14b              [dim]# free, local[/dim]
    [green]$[/green] flet-pkg create -f shimmer --ai-refine  [dim]# uses Ollama[/dim]

    [dim]Or use a cloud provider (requires API key):[/dim]

    [green]$[/green] export ANTHROPIC_API_KEY=sk-...
    [green]$[/green] flet-pkg create -f shimmer --ai-refine --ai-provider anthropic

    [dim]Run without flags for interactive mode, or pass flags for CI/scripting.[/dim]
    """
    header_panel("Flet Extension Generator", "Create a new Flet extension")

    # Extension type
    if extension_type:
        template_name = extension_type
        if template_name not in ("auto", "service", "ui_control"):
            error_panel(
                "Error",
                f"Invalid type: {template_name}. Use 'auto', 'service' or 'ui_control'.",
            )
            raise typer.Exit(1)
    else:
        choice = ask_choice("Extension type:", [(k, v[1]) for k, v in EXTENSION_TYPES.items()])
        template_name = EXTENSION_TYPES[choice][0]

    # When auto-detect is selected we need the Flutter package name first
    # so we can download and inspect it.
    if template_name == "auto" and not flutter_package:
        flutter_package = ask(
            "Flutter package name (from pub.dev)",
            validator=validate_flutter_package,
        )

    if template_name == "auto":
        assert flutter_package is not None
        template_name = _auto_detect_type(flutter_package, local_package)

    # Flutter package (ask if not yet provided)
    if not flutter_package:
        flutter_package = ask(
            "Flutter package name (from pub.dev)",
            validator=validate_flutter_package,
        )

    derived = derive_names(flutter_package)

    # Project name
    project_name = ask(
        "Extension name",
        default=derived.project_name,
        validator=validate_project_name,
    )

    # Check PyPI / GitHub for existing packages
    _check_existing_packages(project_name)

    # Package name
    package_name = ask(
        "Python package name",
        default=derived.package_name,
        validator=validate_package_name,
    )

    # Control class name
    control_name = ask(
        "Control class name",
        default=derived.control_name,
        validator=validate_control_name,
    )

    # Description
    description = ask("Description", default="A Flet extension package.")

    # Author
    author = ask("Author", default="")

    # Debug console module
    if console_module is None:
        console_module = ask_confirm("Include debug console module?", default=True)

    # AI refinement
    if ai_refine is None and analyze:
        ai_refine = _ask_ai_refine()
        if ai_refine and ai_provider is None:
            ai_provider, detected_model = _ask_ai_provider()
            if detected_model and ai_model is None:
                ai_model = detected_model
    if ai_refine is None:
        ai_refine = False

    # Fetch Flutter package version for pubspec.yaml
    flutter_package_version = "any"
    if flutter_package and not local_package:
        try:
            from flet_pkg.core.downloader import PubDevDownloader

            metadata = PubDevDownloader().fetch_metadata(flutter_package)
            if metadata.version:
                major, minor, *_ = metadata.version.split(".")
                flutter_package_version = f"^{major}.{minor}.0"
        except Exception:
            pass

    context = {
        "project_name": project_name,
        "package_name": package_name,
        "control_name": control_name,
        "control_name_snake": derived.control_name_snake,
        "flutter_package": flutter_package,
        "flutter_package_version": flutter_package_version,
        "description": description,
        "author": author,
        "include_console": console_module,
    }

    output_dir = output or Path.cwd()

    try:
        scaffolder = Scaffolder(template_name, context, output_dir)
        project_dir = scaffolder.generate()
    except FileExistsError as e:
        error_panel("Error", str(e))
        raise typer.Exit(1)
    except Exception as e:
        error_panel("Error", f"Failed to generate project: {e}")
        raise typer.Exit(1)

    # Remove console.py if --no-console
    if not console_module:
        console_file = project_dir / "src" / package_name / "console.py"
        if console_file.exists():
            console_file.unlink()

    # Run analysis pipeline if --analyze
    if analyze:
        console.print()
        console.print("[info]Analyzing Flutter package...[/info]")

        try:
            from flet_pkg.core.pipeline import GenerationPipeline

            pipeline = GenerationPipeline()
            result = pipeline.run(
                flutter_package=flutter_package,
                control_name=control_name,
                extension_type=template_name,
                project_dir=project_dir,
                package_name=package_name,
                description=description,
                local_package=local_package,
                control_name_snake=context["control_name_snake"],
                include_console=console_module,
                ai_refine=ai_refine,
                ai_provider=ai_provider,
                ai_model=ai_model,
                verbose=verbose,
            )

            if result.warnings:
                for warning in result.warnings:
                    console.print(f"  [warning]{warning}[/warning]")

            if result.files_generated:
                console.print(
                    f"\n[success]Auto-generated {len(result.files_generated)} files "
                    f"from {flutter_package} analysis.[/success]"
                )

            # Coverage score (always shown when available)
            if result.gap_report is not None:
                from flet_pkg.ui.coverage import print_coverage_score, print_coverage_table

                print_coverage_score(
                    result.coverage_pct,
                    result.gap_report.total_generated,
                    result.gap_report.total_dart_api,
                    ai_pct=result.ai_coverage_pct,
                )
                if verbose:
                    print_coverage_table(result.gap_report)
        except Exception as e:
            console.print(f"  [warning]Analysis skipped: {e}[/warning]")

    print_tree(project_dir)

    console.print()
    info_panel(
        "Next Steps",
        f"cd {project_name}\nuv sync",
    )


def _auto_detect_type(
    flutter_package: str,
    local_package: Path | None = None,
) -> str:
    """Download (or locate) the Flutter package and detect extension type.

    Falls back to a manual choice prompt if the download or detection fails.

    Args:
        flutter_package: Name of the Flutter package on pub.dev.
        local_package: Optional local path to the Flutter package.

    Returns:
        Extension type string: ``"ui_control"`` or ``"service"``.
    """
    from flet_pkg.core.downloader import PubDevDownloader
    from flet_pkg.core.parser import detect_extension_type

    try:
        if local_package:
            package_path = local_package
        else:
            downloader = PubDevDownloader()
            package_path = downloader.download(flutter_package)

        detected = detect_extension_type(package_path)
        label = (
            "UI Control (visual widget)"
            if detected == "ui_control"
            else "Service (no visual interface)"
        )
        console.print(f"\n  [success]Detected: {label}[/success]\n")
        return detected
    except Exception as e:
        console.print(f"\n  [warning]Auto-detect failed ({e}). Please choose manually:[/warning]")
        manual_choices = [
            (1, "Service (no visual interface)"),
            (2, "UI Control (visual widget)"),
        ]
        choice = ask_choice("Extension type:", manual_choices)
        return "service" if choice == 1 else "ui_control"


def _check_existing_packages(project_name: str) -> None:
    """Check PyPI and GitHub for existing packages with the same name.

    Shows warnings and asks for confirmation when matches are found.
    Silently continues on network errors.
    """
    matches: list[RegistryMatch] = []

    with console.status("[info]Checking PyPI, GitHub and Flet SDK...[/info]"):
        pypi_match = check_pypi(project_name)
        if pypi_match:
            matches.append(pypi_match)

        flet_match = check_flet_packages(project_name)
        if flet_match:
            matches.append(flet_match)

        gh_matches = check_github(project_name)
        matches.extend(gh_matches)

    if not matches:
        return

    console.print(f"\n  [warning]Found existing packages matching '{project_name}':[/warning]")
    for m in matches:
        desc = f" — {m.description}" if m.description else ""
        console.print(f"    [highlight]{m.source}[/highlight]: {m.name}{desc}")
        console.print(f"           {m.url}")

    console.print()
    if not ask_confirm("Continue anyway?"):
        raise typer.Exit(0)


AI_PROVIDERS = {
    1: ("ollama", "Ollama (local, free — no API key)"),
    2: ("anthropic", "Anthropic (Claude — requires API key)"),
    3: ("openai", "OpenAI (GPT — requires API key)"),
    4: ("google", "Google (Gemini — requires API key)"),
}


def _ask_ai_refine() -> bool:
    """Ask the user whether to enable AI refinement.

    Returns:
        ``True`` if the user opts in and ``pydantic_ai`` is installed.
    """
    try:
        import pydantic_ai  # noqa: F401

        return ask_confirm("Run AI refinement on generated code?", default=False)
    except ImportError:
        return False


def _ask_ai_provider() -> tuple[str, str | None]:
    """Ask the user to choose an AI provider.

    Returns:
        Tuple of (provider, model).  *model* is ``None`` unless the user
        picked a specific Ollama model interactively.
    """
    choice = ask_choice("AI provider:", [(k, v[1]) for k, v in AI_PROVIDERS.items()])
    provider = AI_PROVIDERS[choice][0]
    model: str | None = None

    if provider == "ollama":
        model = _detect_ollama_model()
    else:
        from flet_pkg.core.ai.config import AIConfig

        config = AIConfig.load(provider=provider)
        if not config.is_available():
            import os

            env_var = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY"}.get(
                provider, "GOOGLE_API_KEY"
            )
            current = os.environ.get(env_var, "")
            if not current:
                console.print(
                    f"\n  [warning]No {env_var} found. "
                    f"Set it before running or AI will be skipped.[/warning]"
                )

    return provider, model


def _detect_ollama_model() -> str | None:
    """Detect installed Ollama models and let the user pick one.

    Returns:
        Selected model name, or ``None`` to use the default.
    """
    from flet_pkg.core.ai.config import AIConfig, list_ollama_models

    config = AIConfig.load(provider="ollama")

    with console.status("[info]Detecting Ollama models...[/info]", spinner="dots"):
        models = list_ollama_models()

    if not models:
        console.print(
            f"\n  [warning]Could not connect to Ollama or no models installed.[/warning]\n"
            f"  [dim]Make sure Ollama is running: ollama serve[/dim]\n"
            f"  [dim]Pull a model first: ollama pull {config.model}[/dim]"
        )
        return None

    if len(models) == 1:
        selected = models[0]
        console.print(f"\n  [success]Ollama model detected: {selected}[/success]")
        return selected

    # Multiple models — let the user choose
    console.print(f"\n  [info]Found {len(models)} Ollama models:[/info]")
    model_choices = [(i + 1, m) for i, m in enumerate(models)]
    idx = ask_choice("Select model:", model_choices)
    selected = models[idx - 1]
    return selected
