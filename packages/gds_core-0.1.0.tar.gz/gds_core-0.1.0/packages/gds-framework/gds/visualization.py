"""Visualization has moved to the gds-viz package.

Install with: uv add gds-viz
Import with: from gds_viz import system_to_mermaid, block_to_mermaid
"""

raise ImportError(
    "gds.visualization has moved to the gds-viz package. "
    "Install with `uv add gds-viz` and import from `gds_viz` instead."
)
