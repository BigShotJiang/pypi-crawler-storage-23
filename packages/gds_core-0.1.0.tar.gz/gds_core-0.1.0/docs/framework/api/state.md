# gds.state

::: gds.state.Entity

::: gds.state.StateVariable
