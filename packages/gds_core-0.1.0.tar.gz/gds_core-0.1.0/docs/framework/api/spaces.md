# gds.spaces

::: gds.spaces.Space

::: gds.spaces.EMPTY

::: gds.spaces.TERMINAL
