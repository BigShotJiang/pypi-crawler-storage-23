# gds.spec

::: gds.spec.GDSSpec

::: gds.spec.SpecWiring

::: gds.spec.Wire
