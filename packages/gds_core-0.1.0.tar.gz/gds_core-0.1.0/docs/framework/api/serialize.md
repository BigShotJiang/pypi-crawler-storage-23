# gds.serialize

::: gds.serialize.spec_to_dict

::: gds.serialize.spec_to_json
