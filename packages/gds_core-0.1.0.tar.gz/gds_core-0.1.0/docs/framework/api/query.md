# gds.query

::: gds.query.SpecQuery
