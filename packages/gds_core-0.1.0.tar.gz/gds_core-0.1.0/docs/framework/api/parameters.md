# gds.parameters

::: gds.parameters.ParameterDef

::: gds.parameters.ParameterSchema
