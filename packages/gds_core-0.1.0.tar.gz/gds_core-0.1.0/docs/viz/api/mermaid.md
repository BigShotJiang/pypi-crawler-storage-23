# gds_viz.mermaid

Core Mermaid syntax generation — flowchart and subgraph building utilities.

::: gds_viz.mermaid
