# gds_viz.architecture

::: gds_viz.architecture.spec_to_mermaid
