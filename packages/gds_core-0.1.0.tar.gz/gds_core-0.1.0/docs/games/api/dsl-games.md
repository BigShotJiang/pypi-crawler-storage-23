# ogs.dsl.games

::: ogs.dsl.games.DecisionGame

::: ogs.dsl.games.CovariantFunction

::: ogs.dsl.games.ContravariantFunction

::: ogs.dsl.games.DeletionGame

::: ogs.dsl.games.DuplicationGame

::: ogs.dsl.games.CounitGame
