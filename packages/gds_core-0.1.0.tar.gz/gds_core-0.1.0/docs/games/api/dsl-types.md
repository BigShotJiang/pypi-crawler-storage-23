# ogs.dsl.types

::: ogs.dsl.types.Signature

::: ogs.dsl.types.GameType

::: ogs.dsl.types.FlowType

::: ogs.dsl.types.CompositionType

::: ogs.dsl.types.InputType
