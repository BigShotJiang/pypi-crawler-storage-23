# ogs.dsl.pattern

::: ogs.dsl.pattern.Pattern

::: ogs.dsl.pattern.PatternInput

::: ogs.dsl.pattern.TerminalCondition

::: ogs.dsl.pattern.ActionSpace

::: ogs.dsl.pattern.StateInitialization
