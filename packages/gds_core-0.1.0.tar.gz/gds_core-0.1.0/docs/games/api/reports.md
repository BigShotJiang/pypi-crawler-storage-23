# ogs.reports

## Generator

::: ogs.reports.generator.generate_reports

## Domain Analysis

::: ogs.reports.domain_analysis
