# ogs.dsl.compile

::: ogs.dsl.compile.compile_to_ir
