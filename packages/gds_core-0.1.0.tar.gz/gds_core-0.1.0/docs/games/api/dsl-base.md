# ogs.dsl.base

::: ogs.dsl.base.OpenGame
