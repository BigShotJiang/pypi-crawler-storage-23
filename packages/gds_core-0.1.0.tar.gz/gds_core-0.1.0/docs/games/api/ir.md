# ogs.ir

## Models

::: ogs.ir.models.OpenGameIR

::: ogs.ir.models.FlowIR

::: ogs.ir.models.PatternIR

::: ogs.ir.models.HierarchyNodeIR

## Serialization

::: ogs.ir.serialization.IRDocument

::: ogs.ir.serialization.save_ir

::: ogs.ir.serialization.load_ir
