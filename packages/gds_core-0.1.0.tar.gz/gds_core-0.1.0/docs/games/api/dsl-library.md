# ogs.dsl.library

Reusable game factories for common patterns.

::: ogs.dsl.library
