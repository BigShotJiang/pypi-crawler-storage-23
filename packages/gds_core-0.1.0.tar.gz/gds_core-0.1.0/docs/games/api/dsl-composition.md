# ogs.dsl.composition

::: ogs.dsl.composition.Flow

::: ogs.dsl.composition.SequentialComposition

::: ogs.dsl.composition.ParallelComposition

::: ogs.dsl.composition.FeedbackLoop

::: ogs.dsl.composition.CorecursiveLoop
