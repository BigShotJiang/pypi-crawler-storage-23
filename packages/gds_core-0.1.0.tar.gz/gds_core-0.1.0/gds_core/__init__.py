"""GDS ecosystem meta-package — installs all GDS packages."""

__version__ = "0.1.0"
