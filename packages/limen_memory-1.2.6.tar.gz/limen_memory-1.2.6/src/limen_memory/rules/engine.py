"""Priority-based rule engine for context injection.

Rules execute in phase order (POST_RETRIEVAL → PRE_RESPONSE), sorted by
priority within each phase. Lower priority numbers fire first.
"""

from __future__ import annotations

import json
import logging
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Any

from limen_memory.models import RuleResult, UserFact

if TYPE_CHECKING:
    from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


class RulePhase(IntEnum):
    """Execution phases for rules, ordered by pipeline position."""

    PRE_RETRIEVAL = 0
    POST_RETRIEVAL = 1
    PRE_RESPONSE = 2
    POST_RESPONSE = 3


@dataclass
class ConversationContext:
    """Mutable context passed through the rule pipeline.

    Rules may modify system_prompt_parts, loaded_reflection_ids, and metadata.

    Args:
        current_message: The user's current message text.
        conversation_id: Active conversation identifier.
        loaded_reflection_ids: IDs of reflections already loaded by the context loader.
        user_facts: Pre-loaded user facts for preference matching.
        conversation_history: Recent conversation messages (for future use).
        system_prompt_parts: Accumulator for injected context strings.
        metadata: Arbitrary metadata shared across rules (inter-rule communication).
    """

    current_message: str = ""
    conversation_id: str = ""
    loaded_reflection_ids: set[str] = field(default_factory=set)
    user_facts: list[UserFact] = field(default_factory=list)
    conversation_history: list[str] = field(default_factory=list)
    system_prompt_parts: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class Rule(ABC):
    """Abstract base class for all rules.

    Subclasses must implement name, priority, phase, evaluate, and apply.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable rule name."""

    @property
    @abstractmethod
    def priority(self) -> int:
        """Execution priority (lower = earlier within the same phase)."""

    @property
    @abstractmethod
    def phase(self) -> RulePhase:
        """Pipeline phase this rule executes in."""

    @abstractmethod
    def evaluate(self, context: ConversationContext) -> bool:
        """Check whether this rule should fire.

        Args:
            context: Current conversation context.

        Returns:
            True if the rule should fire.
        """

    @abstractmethod
    def apply(self, context: ConversationContext) -> RuleResult:
        """Execute the rule and return results.

        May mutate context.system_prompt_parts and context.loaded_reflection_ids.

        Args:
            context: Current conversation context (mutable).

        Returns:
            RuleResult describing what was injected.
        """


class RuleEngine:
    """Registers and executes rules in priority order within phases.

    Args:
        db: Database instance for audit logging (optional).
    """

    def __init__(self, db: Database | None = None) -> None:
        self._rules: list[Rule] = []
        self._db = db

    def register(self, rule: Rule) -> None:
        """Register a rule and maintain sorted order.

        Args:
            rule: The rule instance to register.
        """
        self._rules.append(rule)
        self._rules.sort(key=lambda r: (r.phase, r.priority))

    @property
    def rule_count(self) -> int:
        """Number of registered rules."""
        return len(self._rules)

    @property
    def registered_rule_names(self) -> list[str]:
        """Names of all registered rules in execution order."""
        return [r.name for r in self._rules]

    def execute(
        self,
        context: ConversationContext,
        phase: RulePhase,
    ) -> list[RuleResult]:
        """Execute all rules registered for a specific phase.

        Args:
            context: Mutable conversation context.
            phase: The phase to execute.

        Returns:
            List of RuleResults from rules that fired.
        """
        results: list[RuleResult] = []
        for rule in self._rules:
            if rule.phase != phase:
                continue
            try:
                if rule.evaluate(context):
                    result = rule.apply(context)
                    results.append(result)
                    if result.fired and self._db is not None:
                        self._log_rule_execution(result, context.conversation_id)
            except Exception:
                logger.exception("Error executing rule %s", rule.name)
        return results

    def execute_all(self, context: ConversationContext) -> list[RuleResult]:
        """Execute all rules across all phases in order.

        Args:
            context: Mutable conversation context.

        Returns:
            List of all RuleResults.
        """
        results: list[RuleResult] = []
        for phase in RulePhase:
            results.extend(self.execute(context, phase))
        return results

    def _log_rule_execution(self, result: RuleResult, conversation_id: str) -> None:
        """Write audit row to rule_executions table.

        Args:
            result: The rule result to log.
            conversation_id: The conversation this rule ran in.
        """
        if self._db is None:
            return
        try:
            self._db.execute_write(
                """INSERT INTO rule_executions
                   (id, conversation_id, rule_name, fired_at,
                    reflections_affected, outcome)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    uuid.uuid4().hex,
                    conversation_id,
                    result.rule_name,
                    datetime.utcnow().isoformat(),
                    json.dumps(result.reflections_affected),
                    result.injected_text[:500] if result.injected_text else "",
                ),
            )
        except Exception:
            logger.exception("Failed to log rule execution for %s", result.rule_name)
