"""ContradictionDetectionRule: surface conflicting reflections in context."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from limen_memory.models import RuleResult
from limen_memory.rules.engine import ConversationContext, Rule, RulePhase

if TYPE_CHECKING:
    from limen_memory.store.graph_store import GraphStore
    from limen_memory.store.memory_store import MemoryStore

logger = logging.getLogger(__name__)


class ContradictionDetectionRule(Rule):
    """Detect contradictions among loaded reflections.

    Queries contradiction edges (confidence >= 0.4) between reflections
    already in context, and injects a note so the assistant can handle
    ambiguity.

    Args:
        graph_store: Graph store for edge queries.
        memory_store: Memory store for reflection content lookups.
    """

    def __init__(self, graph_store: GraphStore, memory_store: MemoryStore) -> None:
        self._graph = graph_store
        self._memory = memory_store

    @property
    def name(self) -> str:
        return "ContradictionDetection"

    @property
    def priority(self) -> int:
        return 10

    @property
    def phase(self) -> RulePhase:
        return RulePhase.POST_RETRIEVAL

    def evaluate(self, context: ConversationContext) -> bool:
        """Fire if there are loaded reflections to check."""
        return len(context.loaded_reflection_ids) > 0

    def apply(self, context: ConversationContext) -> RuleResult:
        """Find and inject contradiction notes.

        Args:
            context: Conversation context with loaded reflection IDs.

        Returns:
            RuleResult with contradiction notes injected.
        """
        reflection_ids = list(context.loaded_reflection_ids)
        contradictions = self._graph.get_contradiction_edges(reflection_ids, min_confidence=0.4)

        if not contradictions:
            return RuleResult(rule_name=self.name, fired=False)

        # Build content cache for descriptions
        content_cache: dict[str, str] = {}
        for edge in contradictions:
            for node_id in (edge.source_id, edge.target_id):
                if node_id not in content_cache:
                    ref = self._memory.get_reflection(node_id)
                    content_cache[node_id] = ref.content[:80] if ref else "[unknown]"

        # Format up to 3 contradiction notes
        notes: list[str] = []
        affected: list[str] = []
        for edge in contradictions[:3]:
            source_desc = content_cache.get(edge.source_id, "[unknown]")
            target_desc = content_cache.get(edge.target_id, "[unknown]")
            notes.append(
                f'- "{source_desc}" conflicts with '
                f'"{target_desc}" (confidence: {edge.confidence:.1f})'
            )
            affected.extend([edge.source_id, edge.target_id])

        injection = "Note: The following observations in context may conflict:\n" + "\n".join(notes)
        context.system_prompt_parts.append(injection)

        return RuleResult(
            rule_name=self.name,
            fired=True,
            injected_text=injection,
            reflections_affected=list(set(affected)),
        )
