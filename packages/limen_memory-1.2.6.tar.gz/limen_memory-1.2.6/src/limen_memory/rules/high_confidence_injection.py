"""HighConfidenceInjectionRule: inject well-connected reflections not yet in context."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from limen_memory.models import RuleResult
from limen_memory.rules.engine import ConversationContext, Rule, RulePhase
from limen_memory.services.keyword_extractor import extract_keywords

if TYPE_CHECKING:
    from limen_memory.store.graph_store import GraphStore
    from limen_memory.store.memory_store import MemoryStore

logger = logging.getLogger(__name__)


class HighConfidenceInjectionRule(Rule):
    """Inject high-confidence reflections relevant to the current message.

    Extracts keywords from the message, queries topic-matching reflections,
    filters to those with high-confidence edges (>= 0.8), and injects up
    to 3 not-already-loaded reflections.

    Args:
        memory_store: Memory store for reflection queries.
        graph_store: Graph store for edge confidence checks.
    """

    def __init__(self, memory_store: MemoryStore, graph_store: GraphStore) -> None:
        self._memory = memory_store
        self._graph = graph_store

    @property
    def name(self) -> str:
        return "HighConfidenceInjection"

    @property
    def priority(self) -> int:
        return 20

    @property
    def phase(self) -> RulePhase:
        return RulePhase.POST_RETRIEVAL

    def evaluate(self, context: ConversationContext) -> bool:
        """Fire when there is a current message."""
        return bool(context.current_message)

    def apply(self, context: ConversationContext) -> RuleResult:
        """Find and inject high-confidence reflections.

        Args:
            context: Conversation context (loaded_reflection_ids will be mutated).

        Returns:
            RuleResult with injected reflections.
        """
        keywords = extract_keywords(context.current_message)
        if not keywords:
            return RuleResult(rule_name=self.name, fired=False)

        # Query reflections by topic keywords
        topic = " ".join(keywords)
        candidates = self._memory.query_reflections(topic=topic, limit=10, min_confidence="medium")

        # Filter out already-loaded reflections
        new_candidates = [r for r in candidates if r.id not in context.loaded_reflection_ids]
        if not new_candidates:
            return RuleResult(rule_name=self.name, fired=False)

        # Check which have high-confidence edges (>= 0.8)
        candidate_ids = [r.id for r in new_candidates]
        edges = self._graph.get_relationships_for_reflections(candidate_ids)
        high_conf_edges = [e for e in edges if e.confidence >= 0.8]
        well_connected_ids = set()
        for edge in high_conf_edges:
            well_connected_ids.add(edge.source_id)
            well_connected_ids.add(edge.target_id)

        # Select up to 3 well-connected reflections
        to_inject = [r for r in new_candidates if r.id in well_connected_ids][:3]

        if not to_inject:
            return RuleResult(rule_name=self.name, fired=False)

        # Build injection text
        lines = ["Additional high-confidence context relevant to this message:"]
        affected: list[str] = []
        for ref in to_inject:
            lines.append(f"- [{ref.type}] {ref.content}")
            affected.append(ref.id)
            context.loaded_reflection_ids.add(ref.id)

        injection = "\n".join(lines)
        context.system_prompt_parts.append(injection)

        return RuleResult(
            rule_name=self.name,
            fired=True,
            injected_text=injection,
            reflections_affected=affected,
        )
