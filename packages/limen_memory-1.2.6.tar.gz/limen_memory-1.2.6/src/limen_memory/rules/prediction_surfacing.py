"""PredictionSurfacingRule: surface active predictions for real-time validation."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from limen_memory.constants import (
    PREDICTION_HIGH_CONFIDENCE_OVERRIDE,
    PREDICTION_RELEVANCE_MIN,
    PREDICTION_SURFACING_CAP,
    PREDICTION_SURFACING_MIN_CONFIDENCE,
)
from limen_memory.models import GraphEdge, RuleResult
from limen_memory.rules.engine import ConversationContext, Rule, RulePhase

if TYPE_CHECKING:
    from limen_memory.store.graph_store import GraphStore

_WORD_PATTERN: re.Pattern[str] = re.compile(r"[a-z]+")


class PredictionSurfacingRule(Rule):
    """Surface active prediction edges for monitoring during conversation.

    Queries prediction edges, computes keyword overlap relevance against
    the current message, and injects up to 3 predictions with hit-rate
    statistics.

    Args:
        graph_store: Graph store for prediction edge queries.
    """

    def __init__(self, graph_store: GraphStore) -> None:
        self._graph = graph_store

    @property
    def name(self) -> str:
        return "PredictionSurfacing"

    @property
    def priority(self) -> int:
        return 35

    @property
    def phase(self) -> RulePhase:
        return RulePhase.PRE_RESPONSE

    def evaluate(self, context: ConversationContext) -> bool:
        """Fire on every non-empty message."""
        return bool(context.current_message)

    def apply(self, context: ConversationContext) -> RuleResult:
        """Find and inject relevant predictions.

        Args:
            context: Conversation context.

        Returns:
            RuleResult with prediction IDs in metadata["activePredictionIds"].
        """
        predictions = self._graph.get_prediction_edges(
            limit=10,
            min_confidence=PREDICTION_SURFACING_MIN_CONFIDENCE,
        )
        if not predictions:
            return RuleResult(rule_name=self.name, fired=False)

        # Tokenize message for relevance matching
        message_words = set(
            w for w in _WORD_PATTERN.findall(context.current_message.lower()) if len(w) > 3
        )

        # Score predictions by keyword overlap relevance
        scored: list[tuple[GraphEdge, float]] = []
        for edge in predictions:
            evidence_words = set(
                w for w in _WORD_PATTERN.findall((edge.evidence or "").lower()) if len(w) > 3
            )

            overlap = len(message_words & evidence_words)
            relevance = overlap / max(len(evidence_words), 1) if overlap > 0 else 0.0

            # Include if keyword overlap or high-confidence override
            if (
                relevance > PREDICTION_RELEVANCE_MIN
                or edge.confidence >= PREDICTION_HIGH_CONFIDENCE_OVERRIDE
            ):
                scored.append((edge, relevance))

        if not scored:
            return RuleResult(rule_name=self.name, fired=False)

        # Sort by relevance, then confidence; cap at limit
        scored.sort(key=lambda x: (x[1], x[0].confidence), reverse=True)
        top = scored[:PREDICTION_SURFACING_CAP]

        # Build injection text
        lines = ["Active predictions to monitor (validate against the current interaction):"]
        affected: list[str] = []
        for pred_edge, _ in top:
            hit_rate = (
                f"{pred_edge.hit_rate * 100:.0f}%" if pred_edge.prediction_count > 0 else "untested"
            )
            description = pred_edge.evidence or "prediction"
            lines.append(
                f"- {description} "
                f"(confidence: {pred_edge.confidence:.2f}, "
                f"tested: {pred_edge.prediction_count}x, "
                f"hit rate: {hit_rate})"
            )
            affected.append(pred_edge.id)

        injection = "\n".join(lines)
        context.system_prompt_parts.append(injection)

        return RuleResult(
            rule_name=self.name,
            fired=True,
            injected_text=injection,
            reflections_affected=affected,
            metadata={"activePredictionIds": affected},
        )
