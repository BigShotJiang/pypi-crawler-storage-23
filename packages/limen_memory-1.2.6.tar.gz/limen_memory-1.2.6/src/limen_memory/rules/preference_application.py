"""PreferenceApplicationRule: inject relevant user preferences."""

from __future__ import annotations

import re

from limen_memory.models import RuleResult
from limen_memory.rules.engine import ConversationContext, Rule, RulePhase

_WORD_PATTERN: re.Pattern[str] = re.compile(r"[a-z]+")
_PREFERENCE_CATEGORIES: frozenset[str] = frozenset(
    {"preferences", "communication", "communication_style", "values"}
)


class PreferenceApplicationRule(Rule):
    """Inject user preferences matching the current message.

    Tokenizes the message and user facts, finds keyword overlap for
    preference-category facts, and injects up to 5 matching preferences.
    """

    @property
    def name(self) -> str:
        return "PreferenceApplication"

    @property
    def priority(self) -> int:
        return 30

    @property
    def phase(self) -> RulePhase:
        return RulePhase.PRE_RESPONSE

    def evaluate(self, context: ConversationContext) -> bool:
        """Fire if there are user facts and a current message."""
        return bool(context.current_message) and len(context.user_facts) > 0

    def apply(self, context: ConversationContext) -> RuleResult:
        """Find and inject matching user preferences.

        Args:
            context: Conversation context with user_facts populated.

        Returns:
            RuleResult with injected preferences.
        """
        message_words = set(
            w for w in _WORD_PATTERN.findall(context.current_message.lower()) if len(w) > 2
        )
        if not message_words:
            return RuleResult(rule_name=self.name, fired=False)

        # Find preference-category facts that match message keywords
        matching_facts = []
        for fact in context.user_facts:
            if fact.category.lower() not in _PREFERENCE_CATEGORIES:
                continue

            fact_words = set(
                w for w in _WORD_PATTERN.findall(f"{fact.key} {fact.value}".lower()) if len(w) > 2
            )
            if not message_words.isdisjoint(fact_words):
                matching_facts.append(fact)

        if not matching_facts:
            return RuleResult(rule_name=self.name, fired=False)

        # Inject up to 5 relevant preferences
        to_inject = matching_facts[:5]
        lines = ["Relevant user preferences for this message:"]
        for fact in to_inject:
            lines.append(f"- {fact.key}: {fact.value}")

        injection = "\n".join(lines)
        context.system_prompt_parts.append(injection)

        return RuleResult(
            rule_name=self.name,
            fired=True,
            injected_text=injection,
        )
