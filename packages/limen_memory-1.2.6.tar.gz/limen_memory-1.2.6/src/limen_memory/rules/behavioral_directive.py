"""BehavioralDirectiveRule: inject imperative behavioral instructions."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from limen_memory.models import RuleResult
from limen_memory.rules.engine import ConversationContext, Rule, RulePhase

if TYPE_CHECKING:
    from limen_memory.store.memory_store import MemoryStore

logger = logging.getLogger(__name__)


class BehavioralDirectiveRule(Rule):
    """Inject active behavioral directives as imperative instructions.

    Queries reflections with non-null behavioral_directive columns,
    injects them as instructions for shaping the response, and tracks
    activations for effectiveness measurement.

    Args:
        memory_store: Memory store for directive queries.
    """

    def __init__(self, memory_store: MemoryStore) -> None:
        self._memory = memory_store

    @property
    def name(self) -> str:
        return "BehavioralDirective"

    @property
    def priority(self) -> int:
        return 25

    @property
    def phase(self) -> RulePhase:
        return RulePhase.PRE_RESPONSE

    def evaluate(self, context: ConversationContext) -> bool:
        """Fire on every non-empty message."""
        return bool(context.current_message)

    def apply(self, context: ConversationContext) -> RuleResult:
        """Find and inject behavioral directives.

        Args:
            context: Conversation context.

        Returns:
            RuleResult with directive IDs in metadata["activeDirectiveIds"].
        """
        directives = self._memory.get_active_behavioral_directives(limit=5)

        # Filter out directives already tracked in loaded_reflection_ids
        new_directives = [d for d in directives if d.id not in context.loaded_reflection_ids]

        if not new_directives:
            return RuleResult(rule_name=self.name, fired=False)

        # Build imperative instruction block
        lines = ["Active behavioral directives (apply these to your response):"]
        affected: list[str] = []
        for directive in new_directives:
            if not directive.behavioral_directive:
                continue
            lines.append(f"- {directive.behavioral_directive}")
            affected.append(directive.id)
            context.loaded_reflection_ids.add(directive.id)

        if not affected:
            return RuleResult(rule_name=self.name, fired=False)

        injection = "\n".join(lines)
        context.system_prompt_parts.append(injection)

        # Track activations for effectiveness measurement
        self._memory.increment_directive_activation(affected)

        return RuleResult(
            rule_name=self.name,
            fired=True,
            injected_text=injection,
            reflections_affected=affected,
            metadata={"activeDirectiveIds": affected},
        )
