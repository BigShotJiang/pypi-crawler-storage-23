"""Click CLI dispatcher for limen-memory.

Phase 1: init, status, query, reflections, user-profile,
         graph-inspect, session-history, backup, learn, deprecate.
Phase 2: add-reflection, create-edge, reflect, save-session.
Phase 3: context, run-rules, search.
Phase 4: consolidate, review-strategies, age, prune, scheduler-tick, scheduler-status.
Phase 5: cross-analyze, validate-predictions, synthesize-profile, interaction-profile.
Phase 6: SKILL.md, init improvements, integration polish.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess  # nosec B404
import uuid
from datetime import datetime
from pathlib import Path

import click

from limen_memory.config import LimenConfig, ensure_data_dir, load_config, write_default_config
from limen_memory.models import GraphEdge, SessionContext, UserFact
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.database import Database
from limen_memory.store.embedding_store import EmbeddingStore
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore
from limen_memory.store.profile_store import ProfileStore
from limen_memory.store.strategy_store import StrategyStore


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _get_config() -> LimenConfig:
    return load_config()


def _get_db(config: LimenConfig) -> Database:
    db = Database(config.db_path)
    db.ensure_tables()
    return db


def _hook_has_limen_command(group: dict[str, object]) -> bool:
    """Check if a hook group contains a limen-memory hook command."""
    hook_list = group.get("hooks")
    if not isinstance(hook_list, list):
        return False
    for h in hook_list:
        if isinstance(h, dict):
            cmd = h.get("command", "")
            if isinstance(cmd, str) and "limen-memory-" in cmd:
                return True
    return False


def _merge_hooks_into_settings(hooks_dir: Path) -> None:
    """Merge limen-memory hook entries into ~/.claude/settings.json.

    Reads existing settings, adds limen-memory hook entries if not already
    present, and writes back. Idempotent — safe to run multiple times.

    Args:
        hooks_dir: Directory containing installed hook scripts.
    """
    settings_path = Path.home() / ".claude" / "settings.json"

    settings: dict[str, object] = {}
    if settings_path.exists():
        try:
            raw = json.loads(settings_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                settings = raw
        except (json.JSONDecodeError, OSError):
            settings = {}

    raw_hooks = settings.get("hooks")
    hooks: dict[str, list[dict[str, object]]] = raw_hooks if isinstance(raw_hooks, dict) else {}

    limen_entries: dict[str, dict[str, object]] = {
        "SessionStart": {
            "hooks": [
                {
                    "type": "command",
                    "command": str(hooks_dir / "limen-memory-session-start.py"),
                }
            ],
        },
        "Stop": {
            "hooks": [
                {
                    "type": "command",
                    "command": str(hooks_dir / "limen-memory-stop.py"),
                }
            ],
        },
    }

    for hook_type, entry in limen_entries.items():
        existing_list = hooks.get(hook_type)
        if not isinstance(existing_list, list):
            existing_list = []
            hooks[hook_type] = existing_list

        already_present = any(
            _hook_has_limen_command(g) for g in existing_list if isinstance(g, dict)
        )

        if not already_present:
            existing_list.append(entry)

    settings["hooks"] = hooks
    settings_path.write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )


def _remove_hooks_from_settings() -> None:
    """Remove limen-memory hook entries from ~/.claude/settings.json."""
    settings_path = Path.home() / ".claude" / "settings.json"

    if not settings_path.exists():
        return

    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return

    if not isinstance(settings, dict):
        return

    raw_hooks = settings.get("hooks")
    if not isinstance(raw_hooks, dict):
        return
    hooks: dict[str, list[dict[str, object]]] = raw_hooks

    for hook_type in ("SessionStart", "Stop"):
        existing = hooks.get(hook_type)
        if not isinstance(existing, list):
            continue
        filtered = [
            group
            for group in existing
            if not (isinstance(group, dict) and _hook_has_limen_command(group))
        ]
        if filtered:
            hooks[hook_type] = filtered
        else:
            del hooks[hook_type]

    settings["hooks"] = hooks
    settings_path.write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )


def _merge_mcp_into_settings() -> None:
    """Register the limen-memory MCP server in ~/.claude.json.

    Claude Code reads MCP server configuration from ``~/.claude.json``
    (not ``~/.claude/settings.json``).  Reads existing config, adds or
    updates the ``mcpServers.limen-memory`` entry if not already present (or if
    the command path changed), and writes back.  Idempotent — safe to run
    multiple times.  Does not clobber user-added env overrides if the
    entry already exists.
    """
    claude_json_path = Path.home() / ".claude.json"

    settings: dict[str, object] = {}
    if claude_json_path.exists():
        try:
            raw = json.loads(claude_json_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                settings = raw
        except (json.JSONDecodeError, OSError):
            settings = {}

    raw_mcp = settings.get("mcpServers")
    mcp_servers: dict[str, object] = raw_mcp if isinstance(raw_mcp, dict) else {}

    limen_cmd = shutil.which("limen-memory") or "limen-memory"
    limen_entry: dict[str, object] = {
        "command": limen_cmd,
        "args": ["mcp"],
    }

    existing = mcp_servers.get("limen-memory")
    if isinstance(existing, dict):
        # Update command/args only if changed
        existing["command"] = limen_entry["command"]
        existing["args"] = limen_entry["args"]
        # Remove legacy env block — API keys are read from ~/.limen-memory/config.yaml
        existing.pop("env", None)
    else:
        mcp_servers["limen-memory"] = limen_entry

    settings["mcpServers"] = mcp_servers
    claude_json_path.write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )


def _remove_mcp_from_settings() -> None:
    """Remove the limen-memory MCP server entry from ~/.claude.json."""
    claude_json_path = Path.home() / ".claude.json"

    if not claude_json_path.exists():
        return

    try:
        settings = json.loads(claude_json_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return

    if not isinstance(settings, dict):
        return

    raw_mcp = settings.get("mcpServers")
    if not isinstance(raw_mcp, dict):
        return

    if "limen-memory" in raw_mcp:
        del raw_mcp["limen-memory"]

    settings["mcpServers"] = raw_mcp
    claude_json_path.write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )


def _output(data: object, as_json: bool) -> None:
    """Print output as JSON or plain text."""
    if as_json:
        if isinstance(data, str):
            click.echo(json.dumps({"result": data}))
        elif isinstance(data, list):
            click.echo(json.dumps(data, default=str))
        elif isinstance(data, dict):
            click.echo(json.dumps(data, default=str))
        else:
            click.echo(json.dumps({"result": str(data)}))
    else:
        click.echo(data)


def _cleanup_old_limen_artifacts() -> None:
    """Remove legacy limen (pre-rename) artifacts before installing limen-memory ones.

    Cleans up old hook scripts, settings entries, MCP server entry, and skill
    directory left behind by the original ``limen`` package name. Safe to call
    when those artifacts are absent — all operations are no-ops in that case.
    """
    hooks_dir = Path.home() / ".claude" / "hooks"

    # 1. Remove old hook scripts
    for old_name in ("limen-session-start.py", "limen-stop.py"):
        old_path = hooks_dir / old_name
        if old_path.exists():
            try:
                old_path.unlink()
            except OSError:
                pass

    # 2. Remove old hook entries from ~/.claude/settings.json
    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            if isinstance(settings, dict):
                raw_hooks = settings.get("hooks")
                if isinstance(raw_hooks, dict):
                    changed = False
                    for hook_type in ("SessionStart", "Stop"):
                        existing = raw_hooks.get(hook_type)
                        if not isinstance(existing, list):
                            continue
                        filtered = [
                            g
                            for g in existing
                            if not (
                                isinstance(g, dict)
                                and any(
                                    isinstance(h, dict)
                                    and isinstance(h.get("command", ""), str)
                                    and (
                                        "limen-session-start.py" in h.get("command", "")
                                        or "limen-stop.py" in h.get("command", "")
                                    )
                                    for h in (g.get("hooks") or [])
                                    if isinstance(g.get("hooks"), list)
                                )
                            )
                        ]
                        if len(filtered) != len(existing):
                            changed = True
                            if filtered:
                                raw_hooks[hook_type] = filtered
                            else:
                                del raw_hooks[hook_type]
                    if changed:
                        settings["hooks"] = raw_hooks
                        settings_path.write_text(
                            json.dumps(settings, indent=2) + "\n",
                            encoding="utf-8",
                        )
        except (json.JSONDecodeError, OSError):
            pass

    # 3. Remove old MCP entry mcpServers["limen"] from ~/.claude.json
    claude_json_path = Path.home() / ".claude.json"
    if claude_json_path.exists():
        try:
            raw = json.loads(claude_json_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                raw_mcp = raw.get("mcpServers")
                if isinstance(raw_mcp, dict) and "limen" in raw_mcp:
                    del raw_mcp["limen"]
                    raw["mcpServers"] = raw_mcp
                    claude_json_path.write_text(
                        json.dumps(raw, indent=2) + "\n",
                        encoding="utf-8",
                    )
        except (json.JSONDecodeError, OSError):
            pass

    # 4. Remove old skill directory ~/.claude/skills/limen/
    old_skill_dir = Path.home() / ".claude" / "skills" / "limen"
    if old_skill_dir.exists() and old_skill_dir.is_dir():
        try:
            shutil.rmtree(old_skill_dir)
        except OSError:
            pass


@click.group()
@click.option("--json", "as_json", is_flag=True, default=False, help="Output as JSON.")
@click.pass_context
def main(ctx: click.Context, as_json: bool) -> None:
    """Limen-Memory: Personal memory system for Claude CLI."""
    ctx.ensure_object(dict)
    ctx.obj["json"] = as_json


@main.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialize limen-memory: create data directory, database, config, skill, and hooks."""
    config = _get_config()
    ensure_data_dir(config)
    db = _get_db(config)
    db.close()

    # Clean up old limen (pre-rename) artifacts before installing new ones
    _cleanup_old_limen_artifacts()

    # Write default config.yaml if it doesn't exist
    config_path = write_default_config(config)

    # Install SKILL.md from the package
    skill_src = Path(__file__).parent / "skill" / "SKILL.md"

    skill_dest = Path.home() / ".claude" / "skills" / "limen-memory" / "SKILL.md"
    parts = [f"Initialized limen-memory at {config.data_dir}"]
    parts.append(f"Config: {config_path}")

    if skill_src.exists():
        skill_dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(skill_src, skill_dest)
        parts.append(f"Skill installed to {skill_dest}")
    else:
        parts.append("Skill file not found; reinstall package")

    # Install Claude Code hooks
    hooks_src_dir = Path(__file__).parent / "hooks"
    hooks_dest_dir = Path.home() / ".claude" / "hooks"
    hooks_dest_dir.mkdir(parents=True, exist_ok=True)

    hook_files = {
        "session_start.py": "limen-memory-session-start.py",
        "stop.py": "limen-memory-stop.py",
    }

    hooks_installed = False
    for src_name, dest_name in hook_files.items():
        src_path = hooks_src_dir / src_name
        if src_path.exists():
            dest_path = hooks_dest_dir / dest_name
            shutil.copy2(src_path, dest_path)
            dest_path.chmod(0o755)
            parts.append(f"Hook installed: {dest_path}")
            hooks_installed = True

    if hooks_installed:
        _merge_hooks_into_settings(hooks_dest_dir)
        parts.append("Hooks registered in ~/.claude/settings.json")
    else:
        parts.append("Hook scripts not found in package; hooks not installed")

    # Register MCP server in Claude Code settings
    _merge_mcp_into_settings()
    parts.append("MCP server registered in ~/.claude.json")

    _output("\n".join(parts), ctx.obj["json"])


@main.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show database stats and system status."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    memory = MemoryStore(db)
    graph = GraphStore(db)

    reflection_count = memory.get_reflection_count()
    fact_count = memory.get_user_fact_count()
    diagnostics = graph.get_graph_diagnostics()

    # Scheduler state
    scheduler_rows = db.execute_read("SELECT * FROM scheduler_state")
    scheduler_state = {r["key"]: r["value"] for r in scheduler_rows}

    if as_json:
        _output(
            {
                "reflections": reflection_count,
                "user_facts": fact_count,
                "graph_nodes": diagnostics.active_nodes,
                "graph_edges": diagnostics.active_edges,
                "orphan_nodes": diagnostics.orphan_nodes,
                "avg_edge_confidence": round(diagnostics.avg_edge_confidence, 3),
                "scheduler_state": scheduler_state,
                "db_path": str(config.db_path),
            },
            True,
        )
    else:
        lines = [
            "Limen Status",
            f"  Database: {config.db_path}",
            f"  Reflections: {reflection_count}",
            f"  User Facts: {fact_count}",
            f"  Graph Nodes: {diagnostics.active_nodes} ({diagnostics.total_nodes} total)",
            f"  Graph Edges: {diagnostics.active_edges} ({diagnostics.total_edges} total)",
            f"  Orphan Nodes: {diagnostics.orphan_nodes}",
            f"  Avg Edge Confidence: {diagnostics.avg_edge_confidence:.3f}",
        ]
        if scheduler_state:
            lines.append("  Scheduler:")
            for k, v in scheduler_state.items():
                lines.append(f"    {k}: {v}")
        _output("\n".join(lines), False)

    db.close()


@main.command()
@click.argument("topic")
@click.option("--type", "reflection_type", default="", help="Filter by reflection type.")
@click.option("--limit", default=20, help="Maximum results.")
@click.option("--since", default="", help="ISO date lower bound.")
@click.option("--min-confidence", default="", help="Minimum confidence level.")
@click.pass_context
def query(
    ctx: click.Context,
    topic: str,
    reflection_type: str,
    limit: int,
    since: str,
    min_confidence: str,
) -> None:
    """Search reflections by topic with relevance scoring.

    Uses hybrid scoring (semantic + keyword + semantic) when an embedding provider is configured.
    """
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    # Try hybrid scoring if an embedding provider is configured
    from limen_memory.services.embedding.factory import create_embedding_client

    embedding_client = create_embedding_client(config)
    if embedding_client is not None:
        try:
            embedding_store = EmbeddingStore(db)
            if embedding_store.has_embeddings():
                results = memory.query_reflections_hybrid(
                    topic=topic,
                    embedding_store=embedding_store,
                    embedding_client=embedding_client,
                    reflection_type=reflection_type,
                    limit=limit,
                    since_date=since,
                    min_confidence=min_confidence,
                )
            else:
                results = memory.query_reflections(
                    topic=topic,
                    reflection_type=reflection_type,
                    limit=limit,
                    since_date=since,
                    min_confidence=min_confidence,
                )
        except Exception:
            results = memory.query_reflections(
                topic=topic,
                reflection_type=reflection_type,
                limit=limit,
                since_date=since,
                min_confidence=min_confidence,
            )
    else:
        results = memory.query_reflections(
            topic=topic,
            reflection_type=reflection_type,
            limit=limit,
            since_date=since,
            min_confidence=min_confidence,
        )

    if as_json:
        _output(
            [
                {
                    "id": r.id,
                    "type": r.type,
                    "content": r.content,
                    "confidence": r.confidence,
                    "timestamp": r.timestamp,
                    "epistemic_status": r.epistemic_status,
                }
                for r in results
            ],
            True,
        )
    else:
        if not results:
            _output(f'No reflections found for "{topic}"', False)
        else:
            lines = [f'Results for "{topic}" ({len(results)} found):']
            for r in results:
                lines.append(f"  [{r.confidence}] {r.content[:100]}")
                lines.append(f"    id={r.id} type={r.type} ts={r.timestamp}")
            _output("\n".join(lines), False)

    db.close()


@main.command()
@click.option("--type", "reflection_type", default="", help="Filter by type.")
@click.option("--limit", default=20, help="Maximum results.")
@click.pass_context
def reflections(ctx: click.Context, reflection_type: str, limit: int) -> None:
    """List active reflections."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    results = memory.query_reflections(reflection_type=reflection_type, limit=limit)

    if as_json:
        _output(
            [
                {
                    "id": r.id,
                    "type": r.type,
                    "category": r.category,
                    "content": r.content,
                    "confidence": r.confidence,
                    "epistemic_status": r.epistemic_status,
                    "timestamp": r.timestamp,
                }
                for r in results
            ],
            True,
        )
    else:
        if not results:
            _output("No active reflections.", False)
        else:
            lines = [f"Active Reflections ({len(results)}):"]
            for r in results:
                lines.append(f"  [{r.type}/{r.confidence}] {r.content[:100]}")
                lines.append(f"    id={r.id}")
            _output("\n".join(lines), False)

    db.close()


@main.command("user-profile")
@click.pass_context
def user_profile(ctx: click.Context) -> None:
    """Show formatted user facts."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    if as_json:
        facts = memory.query_user_facts()
        _output(
            [
                {
                    "id": f.id,
                    "category": f.category,
                    "key": f.key,
                    "value": f.value,
                    "confidence": f.confidence,
                }
                for f in facts
            ],
            True,
        )
    else:
        _output(memory.get_all_user_facts_formatted(), False)

    db.close()


@main.command("graph-inspect")
@click.pass_context
def graph_inspect(ctx: click.Context) -> None:
    """Show knowledge graph diagnostics."""
    config = _get_config()
    db = _get_db(config)
    graph = GraphStore(db)
    as_json = ctx.obj["json"]

    diag = graph.get_graph_diagnostics()

    if as_json:
        _output(
            {
                "total_nodes": diag.total_nodes,
                "active_nodes": diag.active_nodes,
                "total_edges": diag.total_edges,
                "active_edges": diag.active_edges,
                "orphan_nodes": diag.orphan_nodes,
                "avg_edge_confidence": round(diag.avg_edge_confidence, 3),
                "most_connected": diag.most_connected_nodes,
            },
            True,
        )
    else:
        lines = [
            "Knowledge Graph Diagnostics",
            f"  Nodes: {diag.active_nodes} active / {diag.total_nodes} total",
            f"  Edges: {diag.active_edges} active / {diag.total_edges} total",
            f"  Orphan Nodes: {diag.orphan_nodes}",
            f"  Avg Edge Confidence: {diag.avg_edge_confidence:.3f}",
        ]
        if diag.most_connected_nodes:
            lines.append("  Most Connected:")
            for n in diag.most_connected_nodes:
                lines.append(f"    {n['label'][:60]} ({n['edge_count']} edges)")
        _output("\n".join(lines), False)

    db.close()


@main.command("session-history")
@click.option("--limit", default=10, help="Maximum sessions to show.")
@click.pass_context
def session_history(ctx: click.Context, limit: int) -> None:
    """Show recent session contexts."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    sessions = memory.get_session_history(limit=limit)

    if as_json:
        _output(
            [
                {
                    "session_id": s.session_id,
                    "primary_topic": s.primary_topic,
                    "started_at": s.started_at,
                    "ended_at": s.ended_at,
                    "active_threads": s.active_threads,
                    "pending_decisions": s.pending_decisions,
                }
                for s in sessions
            ],
            True,
        )
    else:
        if not sessions:
            _output("No session history.", False)
        else:
            lines = [f"Session History ({len(sessions)}):"]
            for s in sessions:
                lines.append(f"  [{s.started_at}] {s.primary_topic or '(no topic)'}")
                if s.active_threads:
                    lines.append(f"    Threads: {', '.join(s.active_threads)}")
            _output("\n".join(lines), False)

    db.close()


@main.command()
@click.pass_context
def backup(ctx: click.Context) -> None:
    """Backup the database (keep last 5)."""
    config = _get_config()
    as_json = ctx.obj["json"]

    if not config.db_path.exists():
        _output("No database to backup.", as_json)
        return

    ensure_data_dir(config)
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup_path = config.backup_dir / f"memory_{timestamp}.db"
    shutil.copy2(config.db_path, backup_path)

    # Prune old backups (keep last max_backups)
    backups = sorted(config.backup_dir.glob("memory_*.db"), reverse=True)
    for old in backups[config.max_backups :]:
        old.unlink()

    remaining = len(list(config.backup_dir.glob("memory_*.db")))
    msg = f"Backup created: {backup_path} ({remaining} backups retained)"
    _output(msg, as_json)


@main.command()
@click.option("--category", "-c", required=True, help="Fact category.")
@click.option("--key", "-k", required=True, help="Fact key.")
@click.option("--value", "-v", required=True, help="Fact value.")
@click.option("--confidence", default="medium", help="Confidence level.")
@click.pass_context
def learn(ctx: click.Context, category: str, key: str, value: str, confidence: str) -> None:
    """Add or update a user fact."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    now = _now_iso()
    fact = UserFact(
        id=uuid.uuid4().hex,
        category=category,
        key=key,
        value=value,
        confidence=confidence,
        first_observed=now,
        last_verified=now,
    )
    fact_id = memory.save_user_fact(fact)
    msg = f"Learned: {category}/{key} = {value} (id={fact_id})"
    _output(msg, as_json)
    db.close()


@main.command()
@click.argument("reflection_id")
@click.option("--reason", "-r", default="", help="Reason for deprecation.")
@click.option("--superseded-by", default="", help="ID of superseding reflection.")
@click.pass_context
def deprecate(ctx: click.Context, reflection_id: str, reason: str, superseded_by: str) -> None:
    """Deprecate (soft-delete) a reflection."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    success = memory.deprecate_reflection(reflection_id, reason=reason, superseded_by=superseded_by)
    if success:
        msg = f"Deprecated reflection {reflection_id}"
    else:
        msg = f"Reflection {reflection_id} not found or already deprecated"

    _output(msg, as_json)
    db.close()


@main.command()
@click.argument("reflection_id")
@click.pass_context
def pin(ctx: click.Context, reflection_id: str) -> None:
    """Pin a reflection to prevent it from being aged out."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    success = memory.pin_reflection(reflection_id)
    if success:
        msg = f"Pinned reflection {reflection_id}"
    else:
        msg = f"Reflection {reflection_id} not found or already deprecated"

    _output(msg, as_json)
    db.close()


@main.command()
@click.argument("reflection_id")
@click.pass_context
def unpin(ctx: click.Context, reflection_id: str) -> None:
    """Unpin a reflection, allowing it to be aged normally."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    success = memory.unpin_reflection(reflection_id)
    if success:
        msg = f"Unpinned reflection {reflection_id}"
    else:
        msg = f"Reflection {reflection_id} not found or already deprecated"

    _output(msg, as_json)
    db.close()


# --- Phase 2 Commands ---


def _init_services(config: LimenConfig, db: Database) -> dict[str, object]:
    """Initialize service instances with dependency injection.

    Delegates to :func:`limen_memory.service_factory.create_services`.

    Args:
        config: Limen configuration.
        db: Database instance.

    Returns:
        Dict of service instances keyed by name.
    """
    from limen_memory.service_factory import create_services

    return create_services(config, db)


@main.command("add-reflection")
@click.option("--section", "-s", required=True, help="Reflection type (insight, pattern, etc.).")
@click.option("--content", "-c", required=True, help="Reflection content.")
@click.option("--confidence", default="medium", help="Confidence level.")
@click.pass_context
def add_reflection(ctx: click.Context, section: str, content: str, confidence: str) -> None:
    """Add a single reflection with novelty filtering and embedding storage."""
    config = _get_config()
    if not config.embedding_provider:
        click.echo("Error: Embedding provider is required for add-reflection.", err=True)
        ctx.exit(1)
        return

    db = _get_db(config)
    as_json = ctx.obj["json"]

    services = _init_services(config, db)
    if services["reflection"] is None:
        click.echo("Error: Embedding provider failed to initialize.", err=True)
        ctx.exit(1)
        return
    from limen_memory.services.reflection import ReflectionService

    reflection_svc: ReflectionService = services["reflection"]  # type: ignore[assignment]

    reflection_id = reflection_svc.apply_single_reflection(
        content=content,
        reflection_type=section,
        session_id=f"cli-{uuid.uuid4().hex[:8]}",
        confidence=confidence,
    )

    if reflection_id:
        _output(f"Reflection added: {reflection_id}", as_json)
    else:
        _output("Reflection rejected by novelty filter (too similar to existing).", as_json)

    db.close()


@main.command("create-edge")
@click.option("--source", required=True, help="Source node ID.")
@click.option("--target", required=True, help="Target node ID.")
@click.option("--type", "rel_type", required=True, help="Relationship type.")
@click.option("--evidence", default="", help="Evidence text.")
@click.option("--confidence", default=0.7, type=float, help="Edge confidence (0.0-1.0).")
@click.pass_context
def create_edge(
    ctx: click.Context,
    source: str,
    target: str,
    rel_type: str,
    evidence: str,
    confidence: float,
) -> None:
    """Create a graph edge between two nodes."""
    config = _get_config()
    db = _get_db(config)
    graph = GraphStore(db)
    as_json = ctx.obj["json"]

    # Determine edge category
    edge_category = "causal" if rel_type in ("predicts", "requires") else "evaluative"

    edge = GraphEdge(
        id=uuid.uuid4().hex,
        source_id=source,
        target_id=target,
        source_type="reflection",
        target_type="reflection",
        relationship_type=rel_type,
        edge_category=edge_category,
        confidence=confidence,
        evidence=evidence or f"Manual edge: {rel_type}",
    )
    edge_id = graph.save_relationship(edge)
    _output(f"Edge created: {edge_id} ({source} --{rel_type}--> {target})", as_json)
    db.close()


@main.command()
@click.argument("session_file", type=click.Path(exists=True))
@click.option("--session-id", default="", help="Session ID (auto-generated if empty).")
@click.pass_context
def reflect(ctx: click.Context, session_file: str, session_id: str) -> None:
    """Run the full reflection pipeline on a session transcript file."""
    config = _get_config()
    if not config.embedding_provider:
        click.echo("Error: Embedding provider is required for reflect.", err=True)
        ctx.exit(1)
        return

    db = _get_db(config)
    as_json = ctx.obj["json"]

    session_text = Path(session_file).read_text(encoding="utf-8")
    if not session_id:
        session_id = f"session-{uuid.uuid4().hex[:8]}"

    conversation_id = f"conv-{uuid.uuid4().hex[:8]}"

    services = _init_services(config, db)
    from limen_memory.services.reflection import ReflectionService

    reflection_svc: ReflectionService = services["reflection"]  # type: ignore[assignment]

    result = reflection_svc.reflect_on_session(
        session_text=session_text,
        session_id=session_id,
        conversation_id=conversation_id,
    )

    if as_json:
        _output(
            {
                "reflections_accepted": result.reflections_accepted,
                "reflections_rejected": result.reflections_rejected,
                "user_facts_saved": result.user_facts_saved,
                "strategy_observations": result.strategy_observations_logged,
                "edges_created": result.edges_created,
                "session_context_saved": result.session_context_saved,
                "conversation_summary_saved": result.conversation_summary_saved,
            },
            True,
        )
    else:
        lines = [
            "Reflection Pipeline Complete",
            f"  Reflections accepted: {result.reflections_accepted}",
            f"  Reflections rejected: {result.reflections_rejected}",
            f"  User facts saved: {result.user_facts_saved}",
            f"  Strategy observations: {result.strategy_observations_logged}",
            f"  Edges created: {result.edges_created}",
            f"  Session context saved: {result.session_context_saved}",
            f"  Conversation summary saved: {result.conversation_summary_saved}",
        ]
        _output("\n".join(lines), False)

    db.close()


def _parse_transcript_to_text(transcript_path: str) -> str:
    """Convert Claude Code JSONL transcript to readable text.

    Parses the JSONL format, deduplicates entries by UUID, extracts user
    and assistant messages, and returns clean conversation text suitable
    for the reflection LLM prompt.

    Args:
        transcript_path: Path to the JSONL transcript file.

    Returns:
        Conversation text in 'User: ... / Assistant: ...' format.
    """
    messages: list[str] = []
    seen_uuids: set[str] = set()

    with open(transcript_path, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Skip non-message entries
            if entry.get("type") == "summary":
                continue

            # Deduplicate by UUID (transcript has multiple entries per message)
            entry_uuid = entry.get("uuid", "")
            if entry_uuid:
                if entry_uuid in seen_uuids:
                    continue
                seen_uuids.add(entry_uuid)

            # Claude Code nests messages in a "message" field
            msg = entry.get("message", entry)
            role = msg.get("role")
            if role not in ("user", "assistant"):
                continue

            content = msg.get("content", "")
            if isinstance(content, list):
                text_parts: list[str] = []
                for block in content:
                    if isinstance(block, dict):
                        block_type = block.get("type", "")
                        if block_type == "text":
                            text_parts.append(block.get("text", ""))
                        elif block_type == "tool_use":
                            tool_name = block.get("name", "tool")
                            text_parts.append(f"[Used tool: {tool_name}]")
                        # Skip tool_result and thinking blocks to keep text concise
                content = "\n".join(text_parts)

            if content and isinstance(content, str):
                role_label = "User" if role == "user" else "Assistant"
                messages.append(f"{role_label}: {content}")

    return "\n\n".join(messages)


@main.command("reflect-transcript")
@click.argument("transcript_path", type=click.Path(exists=True), required=False, default=None)
@click.option("--session-id", default="", help="Session ID (auto-generated if empty).")
@click.option(
    "--stdin",
    "read_stdin",
    is_flag=True,
    default=False,
    help="Read transcript text from stdin instead of a JSONL file.",
)
@click.pass_context
def reflect_transcript(
    ctx: click.Context,
    transcript_path: str | None,
    session_id: str,
    read_stdin: bool,
) -> None:
    """Parse a Claude Code JSONL transcript and run reflection pipeline.

    Designed for use by the Stop hook. Handles JSONL-to-text conversion,
    advisory lock management, and delegates to the reflection pipeline.
    Requires a configured embedding provider.

    When --stdin is used, reads pre-parsed transcript text from stdin
    instead of parsing a JSONL file.
    """
    import sys

    if not transcript_path and not read_stdin:
        click.echo("Error: provide TRANSCRIPT_PATH or --stdin.", err=True)
        raise SystemExit(1)

    config = _get_config()
    as_json = ctx.obj["json"]

    if not config.embedding_provider:
        _output("No embedding provider configured, skipping reflection.", as_json)
        return

    # Open database for advisory lock and service work.
    db = _get_db(config)
    lock_holder = f"pid-{os.getpid()}"

    if not db.acquire_advisory_lock("reflection", lock_holder):
        _output("Another reflection is already running.", as_json)
        db.close()
        return

    try:
        if read_stdin:
            session_text = sys.stdin.read()
        else:
            session_text = _parse_transcript_to_text(transcript_path)  # type: ignore[arg-type]
        if len(session_text) < 100:
            _output("Transcript too short for reflection.", as_json)
            return

        if not session_id:
            session_id = f"session-{uuid.uuid4().hex[:8]}"
        conversation_id = f"conv-{uuid.uuid4().hex[:8]}"

        services = _init_services(config, db)
        from limen_memory.services.reflection import ReflectionService

        reflection_svc: ReflectionService = services["reflection"]  # type: ignore[assignment]

        result = reflection_svc.reflect_on_session(
            session_text=session_text,
            session_id=session_id,
            conversation_id=conversation_id,
        )

        if as_json:
            _output(
                {
                    "reflections_accepted": result.reflections_accepted,
                    "reflections_rejected": result.reflections_rejected,
                    "user_facts_saved": result.user_facts_saved,
                    "strategy_observations": result.strategy_observations_logged,
                    "edges_created": result.edges_created,
                    "session_context_saved": result.session_context_saved,
                    "conversation_summary_saved": result.conversation_summary_saved,
                },
                True,
            )
        else:
            lines = [
                "Reflection Pipeline Complete",
                f"  Reflections accepted: {result.reflections_accepted}",
                f"  Reflections rejected: {result.reflections_rejected}",
                f"  User facts saved: {result.user_facts_saved}",
                f"  Strategy observations: {result.strategy_observations_logged}",
                f"  Edges created: {result.edges_created}",
                f"  Session context saved: {result.session_context_saved}",
                f"  Conversation summary saved: {result.conversation_summary_saved}",
            ]
            _output("\n".join(lines), False)
    finally:
        db.release_advisory_lock("reflection", lock_holder)
        db.close()


@main.command("save-session")
@click.option("--id", "session_id", required=True, help="Session ID.")
@click.option("--topic", "-t", required=True, help="Primary topic.")
@click.option("--notes", "-n", default="", help="Context notes.")
@click.pass_context
def save_session(ctx: click.Context, session_id: str, topic: str, notes: str) -> None:
    """Save a session context."""
    config = _get_config()
    db = _get_db(config)
    memory = MemoryStore(db)
    as_json = ctx.obj["json"]

    now = _now_iso()
    session = SessionContext(
        id=uuid.uuid4().hex,
        session_id=session_id,
        started_at=now,
        primary_topic=topic,
        context_notes=notes,
    )
    ctx_id = memory.save_session_context(session)
    _output(f"Session context saved: {ctx_id} (topic: {topic})", as_json)
    db.close()


# --- Phase 3 Commands ---


@main.command("context")
@click.argument("message")
@click.pass_context
def context_cmd(ctx: click.Context, message: str) -> None:
    """Load tiered context for a user message.

    Assembles session bridge, relevance bridge, summaries, and pending
    items within the 6000-char budget.
    """
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    services = _init_services(config, db)
    from limen_memory.services.context_loader import ContextLoader

    loader: ContextLoader = services["context_loader"]  # type: ignore[assignment]

    context_text = loader.load_context(message)
    mode = loader.detect_mode(message)
    loaded_ids = loader.last_loaded_reflection_ids

    if as_json:
        _output(
            {
                "mode": mode.value,
                "context": context_text,
                "loaded_reflection_ids": sorted(loaded_ids),
                "chars_used": len(context_text),
            },
            True,
        )
    else:
        lines = [
            f"Context Mode: {mode.value}",
            f"Chars: {len(context_text)} / 6000",
            f"Reflections loaded: {len(loaded_ids)}",
            "",
            context_text,
        ]
        _output("\n".join(lines), False)

    db.close()


@main.command("run-rules")
@click.argument("message")
@click.pass_context
def run_rules(ctx: click.Context, message: str) -> None:
    """Run the rule engine against a message with loaded context.

    Loads context first, then executes all rule phases.
    """
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    services = _init_services(config, db)
    from limen_memory.rules.engine import ConversationContext as ConvCtx
    from limen_memory.rules.engine import RuleEngine
    from limen_memory.services.context_loader import ContextLoader

    loader: ContextLoader = services["context_loader"]  # type: ignore[assignment]
    engine: RuleEngine = services["rule_engine"]  # type: ignore[assignment]
    memory: MemoryStore = services["memory"]  # type: ignore[assignment]

    # Load context first
    loader.load_context(message)
    loaded_ids = loader.last_loaded_reflection_ids

    # Build conversation context
    conv_ctx = ConvCtx(
        current_message=message,
        loaded_reflection_ids=loaded_ids,
        user_facts=memory.query_user_facts(),
    )

    results = engine.execute_all(conv_ctx)

    if as_json:
        _output(
            [
                {
                    "rule": r.rule_name,
                    "fired": r.fired,
                    "injected_text": r.injected_text[:200] if r.injected_text else "",
                    "reflections_affected": r.reflections_affected,
                }
                for r in results
            ],
            True,
        )
    else:
        fired_count = sum(1 for r in results if r.fired)
        if not results:
            _output("No rules executed.", False)
        else:
            lines = [f"Rule Results ({fired_count} fired):"]
            for r in results:
                status = "FIRED" if r.fired else "skipped"
                lines.append(f"  [{status}] {r.rule_name}")
                if r.fired and r.injected_text:
                    preview = r.injected_text[:100].replace("\n", " ")
                    lines.append(f"    Injected: {preview}...")
            _output("\n".join(lines), False)

    db.close()


@main.command()
@click.argument("query")
@click.option("--limit", default=10, help="Maximum results.")
@click.pass_context
def search(ctx: click.Context, query: str, limit: int) -> None:
    """Search conversation summaries using full-text search."""
    config = _get_config()
    db = _get_db(config)
    conversation_store = ConversationStore(db)
    as_json = ctx.obj["json"]

    results = conversation_store.search_fts(query, limit=limit)

    if as_json:
        _output(
            [
                {
                    "id": s.id,
                    "conversation_id": s.conversation_id,
                    "summary": s.summary,
                    "keywords": s.keywords,
                    "created_at": s.created_at,
                }
                for s in results
            ],
            True,
        )
    else:
        if not results:
            _output(f'No results for "{query}"', False)
        else:
            lines = [f'Search results for "{query}" ({len(results)} found):']
            for s in results:
                lines.append(f"  [{s.created_at[:10]}] {s.summary[:100]}")
                lines.append(f"    conversation_id={s.conversation_id}")
            _output("\n".join(lines), False)

    db.close()


# --- Phase 4 Commands ---


@main.command()
@click.pass_context
def consolidate(ctx: click.Context) -> None:
    """Run memory consolidation (LLM-driven dedup, merge, validate, backfill)."""
    config = _get_config()

    from limen_memory.services.embedding.factory import create_embedding_client as _create_emb

    emb_client = _create_emb(config)
    if emb_client is None:
        click.echo("Error: embedding provider is required for consolidate.", err=True)
        ctx.exit(1)
        return

    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.constants import CONSOLIDATION_TIMEOUT_SECONDS
    from limen_memory.services.consolidation import ConsolidationService
    from limen_memory.services.llm_client import LLMClient

    llm = LLMClient(model=config.claude_model, timeout=CONSOLIDATION_TIMEOUT_SECONDS)

    svc = ConsolidationService(
        memory_store=MemoryStore(db),
        graph_store=GraphStore(db),
        embedding_store=EmbeddingStore(db),
        embedding_client=emb_client,
        conversation_store=ConversationStore(db),
        llm_client=llm,
    )

    summary = svc.consolidate()

    if as_json:
        _output(summary, True)
    else:
        lines = [
            "Consolidation Complete",
            f"  Reflections: {summary['reflections_before']} -> {summary['reflections_after']}",
            f"  Deprecated: {summary['deprecated']}",
            f"  Created: {summary['created']}",
            f"  Edges created: {summary['edges_created']}",
            f"  Edges validated: {summary['edges_validated']}",
            f"  Edges deprecated: {summary['edges_deprecated']}",
            f"  Directives backfilled: {summary['directives_backfilled']}",
            f"  Duration: {summary['duration_ms']}ms",
        ]
        _output("\n".join(lines), False)

    db.close()


@main.command("review-strategies")
@click.pass_context
def review_strategies(ctx: click.Context) -> None:
    """Run LLM-driven strategy review (promote, decay, remove, merge)."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.services.llm_client import LLMClient
    from limen_memory.services.strategy_service import StrategyService

    llm = LLMClient(model=config.claude_model, timeout=config.claude_timeout)

    svc = StrategyService(
        strategy_store=StrategyStore(db),
        conversation_store=ConversationStore(db),
        llm_client=llm,
    )

    summary = svc.review_strategies()

    if as_json:
        _output(summary, True)
    else:
        lines = [
            "Strategy Review Complete",
            f"  Promoted: {summary['promoted']}",
            f"  Decayed: {summary['decayed']}",
            f"  Removed: {summary['removed']}",
            f"  Merged: {summary['merged']}",
            f"  Created: {summary['created']}",
        ]
        _output("\n".join(lines), False)

    db.close()


@main.command()
@click.argument("feedback_type", type=click.Choice(["positive", "negative", "redirect"]))
@click.option("--message", "-m", required=True, help="User message that prompted the response.")
@click.option("--response", "-r", default="", help="Assistant response being evaluated.")
@click.pass_context
def feedback(ctx: click.Context, feedback_type: str, message: str, response: str) -> None:
    """Record a feedback signal to refine behavioral strategies.

    Accepts positive, negative, or redirect feedback to help limen-memory learn
    which approaches are effective.
    """
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    services = _init_services(config, db)
    from limen_memory.services.strategy_service import StrategyService

    strategy_svc: StrategyService | None = services.get("strategy_service")  # type: ignore[assignment]
    if strategy_svc is None:
        click.echo("Error: Strategy service is not available.", err=True)
        db.close()
        ctx.exit(1)
        return

    strategy_svc.process_feedback_signal(
        feedback_type=feedback_type,
        message=message,
        response=response,
    )

    msg = f"Feedback recorded: {feedback_type}"
    _output(msg, as_json)
    db.close()


@main.command()
@click.pass_context
def age(ctx: click.Context) -> None:
    """Age reflections and graph edges based on staleness thresholds."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    memory = MemoryStore(db)
    graph = GraphStore(db)

    reflections_aged = memory.age_reflections()
    edges_aged = graph.age_relationships()

    summary = {
        "reflections_aged": reflections_aged,
        "edges_aged": edges_aged,
    }

    if as_json:
        _output(summary, True)
    else:
        _output(
            f"Aging complete: {reflections_aged} reflections, {edges_aged} edges affected",
            False,
        )

    db.close()


@main.command()
@click.pass_context
def prune(ctx: click.Context) -> None:
    """Deprecate orphaned graph relationships."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    graph = GraphStore(db)
    count = graph.deprecate_orphaned_relationships()

    if as_json:
        _output({"orphaned_edges_deprecated": count}, True)
    else:
        _output(f"Pruning complete: {count} orphaned edges deprecated", False)

    db.close()


@main.command("scheduler-tick")
@click.pass_context
def scheduler_tick(ctx: click.Context) -> None:
    """Run one scheduler tick (executes highest-priority overdue task)."""
    import fcntl
    import signal
    import tempfile

    config = _get_config()
    as_json = ctx.obj["json"]

    # Acquire exclusive lock — only one scheduler-tick process at a time
    lock_path = os.path.join(tempfile.gettempdir(), "limen-memory-scheduler-tick.lock")
    try:
        lock_fd = open(lock_path, "w")  # noqa: SIM115
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        # Another scheduler-tick is already running
        if as_json:
            _output({"task": "none", "result": "Another scheduler-tick is running"}, True)
        else:
            _output("Another scheduler-tick is already running.", False)
        return

    # Hard timeout: kill ourselves after 120 seconds to prevent zombie accumulation
    def _timeout_handler(signum: int, frame: object) -> None:
        raise SystemExit("scheduler-tick timed out after 120s")

    signal.signal(signal.SIGALRM, _timeout_handler)
    signal.alarm(120)

    try:
        db = _get_db(config)

        from limen_memory.services.embedding.factory import create_embedding_client as _create_emb2
        from limen_memory.services.llm_client import LLMClient
        from limen_memory.services.scheduler import Scheduler

        llm = LLMClient(model=config.claude_model, timeout=config.claude_timeout)
        embedding_client = _create_emb2(config)

        scheduler = Scheduler(
            db=db,
            memory_store=MemoryStore(db),
            graph_store=GraphStore(db),
            embedding_store=EmbeddingStore(db),
            embedding_client=embedding_client,
            conversation_store=ConversationStore(db),
            strategy_store=StrategyStore(db),
            llm_client=llm,
            config=config,
            profile_store=ProfileStore(db),
        )

        result = scheduler.tick()

        if as_json:
            _output(result, True)
        else:
            task_name = result.get("task", "none")
            if task_name == "none":
                _output("No tasks due.", False)
            else:
                _output(f"Ran task: {task_name}", False)

        db.close()
    finally:
        signal.alarm(0)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()
        except Exception:  # nosec B110
            pass


@main.command("scheduler-status")
@click.pass_context
def scheduler_status(ctx: click.Context) -> None:
    """Show scheduler state and next-due tasks."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.services.scheduler import Scheduler

    # Scheduler only needs db + stores for status; LLM/embeddings not required.
    scheduler = Scheduler(
        db=db,
        memory_store=MemoryStore(db),
        graph_store=GraphStore(db),
        embedding_store=EmbeddingStore(db),
        embedding_client=None,
        conversation_store=ConversationStore(db),
        strategy_store=StrategyStore(db),
        llm_client=None,  # type: ignore[arg-type]
        config=config,
        profile_store=ProfileStore(db),
    )

    status_info = scheduler.get_status()

    if as_json:
        _output(status_info, True)
    else:
        lines = ["Scheduler Status"]
        for task_info in status_info.get("tasks", []):
            name = task_info.get("name", "")
            last_run = task_info.get("last_run", "never")
            next_due = task_info.get("next_due", "unknown")
            lines.append(f"  {name}: last={last_run}, next={next_due}")
        _output("\n".join(lines), False)

    db.close()


# --- Phase 5 Commands ---


@main.command("cross-analyze")
@click.pass_context
def cross_analyze(ctx: click.Context) -> None:
    """Run cross-conversation analysis (LLM pattern detection across conversations)."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.services.cross_analyzer import CrossAnalyzer
    from limen_memory.services.embedding.factory import create_embedding_client
    from limen_memory.services.llm_client import LLMClient

    llm = LLMClient(model=config.claude_model, timeout=config.claude_timeout)
    embedding_client = create_embedding_client(config)
    embedding_store = EmbeddingStore(db)

    svc = CrossAnalyzer(
        memory_store=MemoryStore(db),
        conversation_store=ConversationStore(db),
        llm_client=llm,
        embedding_client=embedding_client,
        embedding_store=embedding_store,
    )

    try:
        summary = svc.analyze()
    except ValueError as e:
        _output(str(e), as_json)
        db.close()
        return

    if as_json:
        _output(summary, True)
    else:
        lines = [
            "Cross-Analysis Complete",
            f"  Summaries analyzed: {summary['summaries_analyzed']}",
            f"  Reflections created: {summary['reflections_created']}",
            f"  Facts updated: {summary['facts_updated']}",
            f"  Facts deprecated: {summary['facts_deprecated']}",
        ]
        patterns = summary.get("patterns_detected", [])
        if patterns:
            lines.append("  Patterns detected:")
            for p in patterns:
                lines.append(f"    - {p}")
        _output("\n".join(lines), False)

    db.close()


@main.command("validate-predictions")
@click.pass_context
def validate_predictions(ctx: click.Context) -> None:
    """Validate prediction edges against recent conversation evidence (LLM)."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.services.llm_client import LLMClient
    from limen_memory.services.scheduler import Scheduler

    llm = LLMClient(model=config.claude_model, timeout=config.claude_timeout)

    scheduler = Scheduler(
        db=db,
        memory_store=MemoryStore(db),
        graph_store=GraphStore(db),
        embedding_store=EmbeddingStore(db),
        embedding_client=None,
        conversation_store=ConversationStore(db),
        strategy_store=StrategyStore(db),
        llm_client=llm,
        config=config,
    )

    summary = scheduler._run_prediction_validation()

    if as_json:
        _output(summary, True)
    else:
        lines = [
            "Prediction Validation Complete",
            f"  Predictions validated: {summary['predictions_validated']}",
            f"  Confirmed: {summary['confirmed']}",
            f"  Refuted: {summary['refuted']}",
        ]
        _output("\n".join(lines), False)

    db.close()


@main.command("synthesize-profile")
@click.pass_context
def synthesize_profile(ctx: click.Context) -> None:
    """Synthesize interaction profile dimensions from evidence (LLM)."""
    config = _get_config()
    db = _get_db(config)
    as_json = ctx.obj["json"]

    from limen_memory.services.llm_client import LLMClient
    from limen_memory.services.profile_service import ProfileService

    llm = LLMClient(model=config.claude_model, timeout=config.claude_timeout)

    svc = ProfileService(
        memory_store=MemoryStore(db),
        graph_store=GraphStore(db),
        profile_store=ProfileStore(db),
        llm_client=llm,
    )

    summary = svc.synthesize_profile()

    if as_json:
        _output(summary, True)
    else:
        lines = [
            "Profile Synthesis Complete",
            f"  Dimensions updated: {summary['dimensions_updated']}",
            f"  Evidence items: {summary['evidence_count']}",
        ]
        for dim in summary.get("dimensions", []):
            lines.append(
                f"  {dim['dimension']}: {dim['score']:+.2f} (confidence: {dim['confidence']:.3f})"
            )
        _output("\n".join(lines), False)

    db.close()


@main.command("interaction-profile")
@click.pass_context
def interaction_profile(ctx: click.Context) -> None:
    """Read the current interaction profile scores."""
    config = _get_config()
    db = _get_db(config)
    profile_store = ProfileStore(db)
    as_json = ctx.obj["json"]

    if as_json:
        dims = profile_store.get_interaction_profile()
        _output(
            [
                {
                    "dimension": d.dimension,
                    "score": d.score,
                    "confidence": d.confidence,
                    "evidence_count": d.evidence_count,
                    "last_synthesized": d.last_synthesized,
                }
                for d in dims
            ],
            True,
        )
    else:
        formatted = profile_store.get_interaction_profile_formatted()
        _output(formatted or "No interaction profile data yet.", False)

    db.close()


@main.command("uninstall-hooks")
@click.pass_context
def uninstall_hooks(ctx: click.Context) -> None:
    """Remove limen-memory hooks and MCP server from Claude Code settings."""
    as_json = ctx.obj["json"]
    parts: list[str] = []

    # Remove hook entries from settings.json
    _remove_hooks_from_settings()
    parts.append("Removed limen-memory hook entries from ~/.claude/settings.json")

    # Remove hook scripts
    hooks_dir = Path.home() / ".claude" / "hooks"
    for name in ("limen-memory-session-start.py", "limen-memory-stop.py"):
        hook_path = hooks_dir / name
        if hook_path.exists():
            hook_path.unlink()
            parts.append(f"Removed {hook_path}")

    # Remove MCP server entry from settings.json
    _remove_mcp_from_settings()
    parts.append("Removed limen-memory MCP server from ~/.claude.json")

    _output("\n".join(parts), as_json)


@main.command("uninstall")
@click.pass_context
def uninstall(ctx: click.Context) -> None:
    """Remove limen-memory hooks and MCP server (alias for uninstall-hooks)."""
    ctx.invoke(uninstall_hooks)


# --- launchd Service Management ---

_LAUNCHD_LABEL = "com.limen-memory.mcp"
_PLIST_FILENAME = f"{_LAUNCHD_LABEL}.plist"
_LAUNCH_AGENTS_DIR = Path.home() / "Library" / "LaunchAgents"

# Common install locations (same as mcp/server.py).
_EXTRA_BIN_PATHS = [
    "/opt/homebrew/bin",
    "/usr/local/bin",
    os.path.expanduser("~/.local/bin"),
]


def _resolve_limen_binary() -> str:
    """Find the ``limen-memory`` CLI binary on PATH or common locations.

    Returns:
        Absolute path to the binary, or ``"limen-memory"`` as last resort.
    """
    found = shutil.which("limen-memory")
    if found:
        return found
    for directory in _EXTRA_BIN_PATHS:
        candidate = os.path.join(directory, "limen-memory")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return "limen-memory"


def _render_plist(
    bin_path: str,
    port: int,
    log_dir: Path,
    ssl_certfile: str = "",
    ssl_keyfile: str = "",
    public: bool = False,
) -> str:
    """Read the plist template and substitute placeholders.

    Args:
        bin_path: Absolute path to the limen-memory binary.
        port: MCP HTTP server port.
        log_dir: Directory for stdout/stderr log files.
        ssl_certfile: Path to SSL certificate (PEM). Empty to disable HTTPS.
        ssl_keyfile: Path to SSL private key (PEM). Required with ssl_certfile.
        public: Disable DNS rebinding protection for external access.

    Returns:
        Rendered plist XML string.
    """
    template_path = Path(__file__).parent / "launchd" / _PLIST_FILENAME
    template = template_path.read_text(encoding="utf-8")

    # Build a PATH that includes the binary's directory.
    env_path = os.environ.get("PATH", "/usr/bin:/bin")
    bin_dir = os.path.dirname(bin_path)
    if bin_dir and bin_dir not in env_path:
        env_path = f"{bin_dir}:{env_path}"

    # Build optional SSL program arguments.
    ssl_args = ""
    if ssl_certfile and ssl_keyfile:
        ssl_args = (
            f"        <string>--ssl-certfile</string>\n"
            f"        <string>{ssl_certfile}</string>\n"
            f"        <string>--ssl-keyfile</string>\n"
            f"        <string>{ssl_keyfile}</string>\n"
        )

    public_arg = "        <string>--public</string>\n" if public else ""

    return (
        template.replace("{LIMEN_MEMORY_BIN}", bin_path)
        .replace("{PORT}", str(port))
        .replace("{LOG_DIR}", str(log_dir))
        .replace("{PATH}", env_path)
        .replace("{HOME}", str(Path.home()))
        .replace("{SSL_ARGS}", ssl_args)
        .replace("{PUBLIC_ARG}", public_arg)
    )


def _install_launchd_service(
    port: int,
    ssl_certfile: str = "",
    ssl_keyfile: str = "",
    public: bool = False,
) -> str:
    """Render plist, write to LaunchAgents, and bootstrap via launchctl.

    Args:
        port: MCP HTTP server port.
        ssl_certfile: Path to SSL certificate (PEM). Empty to disable HTTPS.
        ssl_keyfile: Path to SSL private key (PEM). Required with ssl_certfile.
        public: Disable DNS rebinding protection for external access.

    Returns:
        Human-readable summary of actions taken.
    """
    parts: list[str] = []

    bin_path = _resolve_limen_binary()
    parts.append(f"Binary: {bin_path}")

    config = _get_config()
    log_dir = config.data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    plist_content = _render_plist(
        bin_path,
        port,
        log_dir,
        ssl_certfile=ssl_certfile,
        ssl_keyfile=ssl_keyfile,
        public=public,
    )

    _LAUNCH_AGENTS_DIR.mkdir(parents=True, exist_ok=True)
    plist_path = _LAUNCH_AGENTS_DIR / _PLIST_FILENAME
    plist_path.write_text(plist_content, encoding="utf-8")
    parts.append(f"Plist: {plist_path}")

    uid = os.getuid()
    domain_target = f"gui/{uid}"

    # Bootout any existing service (try both target forms for robustness).
    subprocess.run(  # nosec B603, B607
        ["launchctl", "bootout", f"{domain_target}/{_LAUNCHD_LABEL}"],
        capture_output=True,
    )
    subprocess.run(  # nosec B603, B607
        ["launchctl", "bootout", domain_target, str(plist_path)],
        capture_output=True,
    )

    result = subprocess.run(  # nosec B603, B607
        ["launchctl", "bootstrap", domain_target, str(plist_path)],
        capture_output=True,
        text=True,
    )

    # Error 5 (I/O) can occur if bootout hasn't fully completed; retry once.
    if result.returncode != 0:
        import time

        time.sleep(1)
        result = subprocess.run(  # nosec B603, B607
            ["launchctl", "bootstrap", domain_target, str(plist_path)],
            capture_output=True,
            text=True,
        )

    if result.returncode == 0:
        parts.append("Service bootstrapped successfully")
    else:
        stderr = result.stderr.strip()
        parts.append(f"Bootstrap warning: {stderr or 'exit code ' + str(result.returncode)}")

    scheme = "https" if ssl_certfile else "http"
    parts.append(f"URL: {scheme}://localhost:{port}/mcp")
    parts.append(f"Logs: {log_dir}/mcp-stdout.log, {log_dir}/mcp-stderr.log")

    return "\n".join(parts)


def _uninstall_launchd_service() -> str:
    """Bootout the service and remove the plist file.

    Returns:
        Human-readable summary of actions taken.
    """
    parts: list[str] = []

    uid = os.getuid()
    domain_target = f"gui/{uid}"

    plist_path = _LAUNCH_AGENTS_DIR / _PLIST_FILENAME

    # Try service-target form first, then domain-target + plist path.
    result = subprocess.run(  # nosec B603, B607
        ["launchctl", "bootout", f"{domain_target}/{_LAUNCHD_LABEL}"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0 and plist_path.exists():
        result = subprocess.run(  # nosec B603, B607
            ["launchctl", "bootout", domain_target, str(plist_path)],
            capture_output=True,
            text=True,
        )
    if result.returncode == 0:
        parts.append("Service stopped and unloaded")
    else:
        stderr = result.stderr.strip()
        parts.append(f"Bootout: {stderr or 'service was not loaded'}")
    if plist_path.exists():
        plist_path.unlink()
        parts.append(f"Removed {plist_path}")
    else:
        parts.append("Plist not found (already removed)")

    return "\n".join(parts)


def _get_service_status(port: int) -> dict[str, object]:
    """Query launchctl for service status.

    Args:
        port: Expected MCP port (for health check).

    Returns:
        Dict with keys: installed, running, pid, exit_status, port, log_dir.
    """
    plist_path = _LAUNCH_AGENTS_DIR / _PLIST_FILENAME
    installed = plist_path.exists()

    status: dict[str, object] = {
        "installed": installed,
        "running": False,
        "pid": None,
        "exit_status": None,
        "port": port,
        "plist_path": str(plist_path),
    }

    if not installed:
        return status

    result = subprocess.run(  # nosec B603, B607
        ["launchctl", "list", _LAUNCHD_LABEL],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        return status

    # Parse launchctl list output.
    # Format: "PID\tStatus\tLabel" or multi-line key-value pairs.
    stdout = result.stdout.strip()
    for line in stdout.splitlines():
        line = line.strip()
        if line.startswith('"PID"') or '"PID"' in line:
            # Key-value format: "PID" = 12345;
            parts = line.split("=")
            if len(parts) >= 2:
                pid_str = parts[1].strip().rstrip(";").strip()
                if pid_str.isdigit():
                    status["pid"] = int(pid_str)
                    status["running"] = True
        elif line.startswith('"LastExitStatus"') or '"LastExitStatus"' in line:
            parts = line.split("=")
            if len(parts) >= 2:
                val = parts[1].strip().rstrip(";").strip()
                if val.isdigit():
                    status["exit_status"] = int(val)

    # Fallback: single-line format "PID\tStatus\tLabel".
    if status["pid"] is None and "\t" in stdout:
        fields = stdout.split("\t")
        if len(fields) >= 2:
            pid_str = fields[0].strip()
            if pid_str.isdigit() and int(pid_str) > 0:
                status["pid"] = int(pid_str)
                status["running"] = True
            exit_str = fields[1].strip()
            if exit_str.isdigit():
                status["exit_status"] = int(exit_str)

    return status


@main.group()
def service() -> None:
    """Manage the limen-memory MCP background service (macOS launchd)."""


@service.command("install")
@click.option("--port", default=None, type=int, help="MCP server port (default: from config).")
@click.option(
    "--ssl-certfile",
    default=None,
    help="Path to SSL certificate (PEM). Enables HTTPS. Default: from config.",
)
@click.option(
    "--ssl-keyfile",
    default=None,
    help="Path to SSL private key (PEM). Default: from config.",
)
@click.option(
    "--public",
    is_flag=True,
    default=False,
    help="Disable DNS rebinding protection for external access.",
)
@click.pass_context
def service_install(
    ctx: click.Context,
    port: int | None,
    ssl_certfile: str | None,
    ssl_keyfile: str | None,
    public: bool,
) -> None:
    """Install and start the MCP server as a launchd service."""
    as_json = ctx.obj["json"]
    config = _get_config()
    resolved_port = port if port is not None else config.mcp_port
    resolved_cert = ssl_certfile if ssl_certfile is not None else config.mcp_ssl_certfile
    resolved_key = ssl_keyfile if ssl_keyfile is not None else config.mcp_ssl_keyfile
    summary = _install_launchd_service(
        resolved_port,
        ssl_certfile=resolved_cert,
        ssl_keyfile=resolved_key,
        public=public,
    )
    _output(summary, as_json)


@service.command("uninstall")
@click.pass_context
def service_uninstall(ctx: click.Context) -> None:
    """Stop and remove the launchd service."""
    as_json = ctx.obj["json"]
    summary = _uninstall_launchd_service()
    _output(summary, as_json)


@service.command("start")
@click.pass_context
def service_start(ctx: click.Context) -> None:
    """Start the service if installed but stopped."""
    as_json = ctx.obj["json"]
    uid = os.getuid()
    domain_target = f"gui/{uid}"

    result = subprocess.run(  # nosec B603, B607
        ["launchctl", "kickstart", f"{domain_target}/{_LAUNCHD_LABEL}"],
        capture_output=True,
        text=True,
    )

    if result.returncode == 0:
        _output("Service started", as_json)
    else:
        stderr = result.stderr.strip()
        _output(f"Start failed: {stderr or 'exit code ' + str(result.returncode)}", as_json)


@service.command("stop")
@click.pass_context
def service_stop(ctx: click.Context) -> None:
    """Stop the running service (it will restart if KeepAlive is true)."""
    as_json = ctx.obj["json"]
    uid = os.getuid()
    domain_target = f"gui/{uid}"

    result = subprocess.run(  # nosec B603, B607
        ["launchctl", "kill", "SIGTERM", f"{domain_target}/{_LAUNCHD_LABEL}"],
        capture_output=True,
        text=True,
    )

    if result.returncode == 0:
        _output("Service stopped (will restart due to KeepAlive)", as_json)
    else:
        stderr = result.stderr.strip()
        _output(f"Stop failed: {stderr or 'exit code ' + str(result.returncode)}", as_json)


@service.command("status")
@click.pass_context
def service_status_cmd(ctx: click.Context) -> None:
    """Show service status (installed, running, PID, port)."""
    as_json = ctx.obj["json"]
    config = _get_config()
    info = _get_service_status(config.mcp_port)

    if as_json:
        _output(info, True)
    else:
        installed = info["installed"]
        running = info["running"]
        pid = info["pid"]
        exit_status = info["exit_status"]
        port = info["port"]

        lines = ["MCP Service Status"]
        lines.append(f"  Installed: {installed}")
        lines.append(f"  Running: {running}")
        if pid:
            lines.append(f"  PID: {pid}")
        if exit_status is not None:
            lines.append(f"  Last Exit Status: {exit_status}")
        scheme = "https" if config.mcp_ssl_certfile else "http"
        lines.append(f"  Port: {port}")
        lines.append(f"  URL: {scheme}://localhost:{port}/mcp")
        log_dir = config.data_dir / "logs"
        lines.append(f"  Logs: {log_dir}")
        _output("\n".join(lines), False)


@service.command("logs")
@click.option("--follow", "-f", is_flag=True, default=False, help="Follow log output (tail -f).")
@click.option(
    "--lines",
    "-n",
    default=50,
    help="Number of lines to show (default: 50).",
)
@click.pass_context
def service_logs(ctx: click.Context, follow: bool, lines: int) -> None:
    """Tail the MCP service log files."""
    config = _get_config()
    log_dir = config.data_dir / "logs"
    stdout_log = log_dir / "mcp-stdout.log"
    stderr_log = log_dir / "mcp-stderr.log"

    log_files = [str(f) for f in (stdout_log, stderr_log) if f.exists()]
    if not log_files:
        click.echo(f"No log files found in {log_dir}")
        return

    cmd = ["tail"]
    if follow:
        cmd.append("-f")
    cmd.extend(["-n", str(lines)])
    cmd.extend(log_files)

    try:
        subprocess.run(cmd)  # nosec B603, B607
    except KeyboardInterrupt:
        pass


@main.command()
@click.option(
    "--transport",
    type=click.Choice(["stdio", "streamable-http"]),
    default="stdio",
    help="MCP transport (default: stdio).",
)
@click.option(
    "--host",
    default="127.0.0.1",
    help="Bind address for HTTP transport (default: 127.0.0.1)."
    " Use 0.0.0.0 or :: for all interfaces.",
)
@click.option("--port", default=8000, help="Port for HTTP transport (default: 8000).")
@click.option(
    "--ssl-certfile",
    default="",
    help="Path to SSL certificate (PEM). Enables HTTPS for streamable-http.",
)
@click.option(
    "--ssl-keyfile",
    default="",
    help="Path to SSL private key (PEM). Required with --ssl-certfile.",
)
@click.option(
    "--public",
    is_flag=True,
    default=False,
    help="Disable DNS rebinding protection for external access.",
)
def mcp(
    transport: str, host: str, port: int, ssl_certfile: str, ssl_keyfile: str, public: bool
) -> None:
    """Start the MCP server for Claude Code / Claude.ai integration."""
    try:
        from limen_memory.mcp.server import run as mcp_run
    except ImportError:
        raise click.ClickException(
            "MCP support requires the mcp extra: pip install limen-memory[mcp]"
        )
    mcp_run(
        transport=transport,
        host=host,
        port=port,
        ssl_certfile=ssl_certfile,
        ssl_keyfile=ssl_keyfile,
        public=public,
    )
