"""Allow running limen-memory as a module: python -m limen_memory."""

from limen_memory.cli import main

main()
