"""Dataclasses for all limen entities."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.utcnow().isoformat()


@dataclass
class MemoryReflection:
    """A memory reflection (insight, pattern, preference, etc.)."""

    id: str
    timestamp: str
    type: str  # insight|pattern|preference|domain_knowledge|working_style|challenge
    content: str
    category: str = ""
    confidence: str = "medium"  # high|medium|low|speculation
    tags: list[str] = field(default_factory=list)
    source_session: str = ""
    deprecated: bool = False
    superseded_by: str = ""
    last_verified: str = ""
    novelty_score: float | None = None
    epistemic_status: str = "hypothesis"  # pondering|hypothesis|working_theory|settled
    behavioral_directive: str = ""
    directive_activation_count: int = 0
    directive_positive_count: int = 0
    pinned: bool = False

    @property
    def tags_json(self) -> str:
        """Serialize tags list to JSON string for DB storage."""
        return json.dumps(self.tags)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> MemoryReflection:
        """Create from a database row dict."""
        tags_raw = row.get("tags", "[]")
        try:
            tags = json.loads(tags_raw) if isinstance(tags_raw, str) else (tags_raw or [])
        except json.JSONDecodeError:
            logger.warning("Corrupt JSON in reflection %s tags field", row.get("id", "?"))
            tags = []
        return cls(
            id=row["id"],
            timestamp=row["timestamp"],
            type=row["type"],
            content=row["content"],
            category=row.get("category", ""),
            confidence=row.get("confidence", "medium"),
            tags=tags,
            source_session=row.get("source_session", ""),
            deprecated=bool(row.get("deprecated", 0)),
            superseded_by=row.get("superseded_by", ""),
            last_verified=row.get("last_verified", ""),
            novelty_score=row.get("novelty_score"),
            epistemic_status=row.get("epistemic_status", "hypothesis"),
            behavioral_directive=row.get("behavioral_directive", ""),
            directive_activation_count=row.get("directive_activation_count", 0),
            directive_positive_count=row.get("directive_positive_count", 0),
            pinned=bool(row.get("pinned", 0)),
        )


@dataclass
class UserFact:
    """A user fact (preference, interest, expertise, etc.)."""

    id: str
    category: str
    key: str
    value: str
    confidence: str = "medium"
    first_observed: str = field(default_factory=_now_iso)
    last_verified: str = field(default_factory=_now_iso)
    deprecated: bool = False

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> UserFact:
        """Create from a database row dict."""
        return cls(
            id=row["id"],
            category=row["category"],
            key=row["key"],
            value=row["value"],
            confidence=row.get("confidence", "medium"),
            first_observed=row.get("first_observed", ""),
            last_verified=row.get("last_verified", ""),
            deprecated=bool(row.get("deprecated", 0)),
        )


@dataclass
class SessionContext:
    """Session context for conversation continuity."""

    id: str
    session_id: str
    started_at: str
    ended_at: str = ""
    primary_topic: str = ""
    active_threads: list[str] = field(default_factory=list)
    pending_decisions: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)
    completed_items: list[str] = field(default_factory=list)
    context_notes: str = ""
    next_session_prep: str = ""

    def _serialize_list(self, items: list[str]) -> str:
        return json.dumps(items)

    @property
    def active_threads_json(self) -> str:
        return self._serialize_list(self.active_threads)

    @property
    def pending_decisions_json(self) -> str:
        return self._serialize_list(self.pending_decisions)

    @property
    def blockers_json(self) -> str:
        return self._serialize_list(self.blockers)

    @property
    def completed_items_json(self) -> str:
        return self._serialize_list(self.completed_items)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> SessionContext:
        """Create from a database row dict."""

        def _parse_json_list(val: Any, field_name: str = "") -> list[str]:
            if isinstance(val, str):
                try:
                    parsed = json.loads(val)
                except json.JSONDecodeError:
                    logger.warning(
                        "Corrupt JSON in session %s %s field",
                        row.get("id", "?"),
                        field_name,
                    )
                    return []
                return parsed if isinstance(parsed, list) else []
            return val if isinstance(val, list) else []

        return cls(
            id=row["id"],
            session_id=row["session_id"],
            started_at=row["started_at"],
            ended_at=row.get("ended_at", ""),
            primary_topic=row.get("primary_topic", ""),
            active_threads=_parse_json_list(row.get("active_threads", "[]"), "active_threads"),
            pending_decisions=_parse_json_list(
                row.get("pending_decisions", "[]"), "pending_decisions"
            ),
            blockers=_parse_json_list(row.get("blockers", "[]"), "blockers"),
            completed_items=_parse_json_list(row.get("completed_items", "[]"), "completed_items"),
            context_notes=row.get("context_notes", ""),
            next_session_prep=row.get("next_session_prep", ""),
        )


@dataclass
class GraphNode:
    """A node in the knowledge graph."""

    id: str
    node_type: str  # reflection|strategy|session|fact|conversation|topic|profile_dimension
    label: str
    source_table: str
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)
    deprecated: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def metadata_json(self) -> str:
        return json.dumps(self.metadata)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> GraphNode:
        """Create from a database row dict."""
        meta_raw = row.get("metadata", "{}")
        try:
            metadata = json.loads(meta_raw) if isinstance(meta_raw, str) else (meta_raw or {})
        except json.JSONDecodeError:
            logger.warning("Corrupt JSON in graph node %s metadata field", row.get("id", "?"))
            metadata = {}
        return cls(
            id=row["id"],
            node_type=row["node_type"],
            label=row["label"],
            source_table=row["source_table"],
            created_at=row.get("created_at", ""),
            updated_at=row.get("updated_at", ""),
            deprecated=bool(row.get("deprecated", 0)),
            metadata=metadata,
        )


@dataclass
class GraphEdge:
    """An edge (relationship) in the knowledge graph."""

    id: str
    source_id: str
    target_id: str
    source_type: str
    target_type: str
    relationship_type: str  # contradicts|reinforces|refines|predicts|requires
    edge_category: str  # evaluative|causal
    confidence: float = 0.5
    evidence: str = ""
    created_at: str = field(default_factory=_now_iso)
    last_validated_at: str = field(default_factory=_now_iso)
    deprecated: bool = False
    prediction_count: int = 0
    prediction_hits: int = 0
    momentum: float = 0.0

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> GraphEdge:
        """Create from a database row dict."""
        return cls(
            id=row["id"],
            source_id=row["source_id"],
            target_id=row["target_id"],
            source_type=row["source_type"],
            target_type=row["target_type"],
            relationship_type=row["relationship_type"],
            edge_category=row["edge_category"],
            confidence=float(row.get("confidence", 0.5)),
            evidence=row.get("evidence", ""),
            created_at=row.get("created_at", ""),
            last_validated_at=row.get("last_validated_at", ""),
            deprecated=bool(row.get("deprecated", 0)),
            prediction_count=row.get("prediction_count", 0),
            prediction_hits=row.get("prediction_hits", 0),
            momentum=float(row.get("momentum", 0.0) or 0.0),
        )

    @property
    def hit_rate(self) -> float:
        """Prediction hit rate (0.0 if no predictions recorded)."""
        if self.prediction_count == 0:
            return 0.0
        return self.prediction_hits / self.prediction_count


@dataclass
class Strategy:
    """A learned strategy for interaction."""

    id: str
    type: str  # communication|task|tooling|domain_knowledge|anti_pattern
    content: str
    confidence: float = 0.5
    observation_count: int = 0
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)
    deprecated: bool = False
    superseded_by: str = ""

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> Strategy:
        """Create from a database row dict."""
        return cls(
            id=row["id"],
            type=row["type"],
            content=row["content"],
            confidence=float(row.get("confidence", 0.5)),
            observation_count=row.get("observation_count", 0),
            created_at=row.get("created_at", ""),
            updated_at=row.get("updated_at", ""),
            deprecated=bool(row.get("deprecated", 0)),
            superseded_by=row.get("superseded_by", ""),
        )


@dataclass
class InteractionDimension:
    """A dimension of the interaction profile."""

    id: str
    dimension: str
    score: float = 0.0  # -1.0 to 1.0
    confidence: float = 0.0
    evidence_count: int = 0
    evidence_ids: list[str] = field(default_factory=list)
    last_synthesized: str = field(default_factory=_now_iso)
    created_at: str = field(default_factory=_now_iso)

    @property
    def evidence_ids_json(self) -> str:
        return json.dumps(self.evidence_ids)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> InteractionDimension:
        """Create from a database row dict."""
        ids_raw = row.get("evidence_ids", "[]")
        try:
            evidence_ids = json.loads(ids_raw) if isinstance(ids_raw, str) else (ids_raw or [])
        except json.JSONDecodeError:
            logger.warning("Corrupt JSON in dimension %s evidence_ids field", row.get("id", "?"))
            evidence_ids = []
        return cls(
            id=row["id"],
            dimension=row["dimension"],
            score=float(row.get("score", 0.0)),
            confidence=float(row.get("confidence", 0.0)),
            evidence_count=row.get("evidence_count", 0),
            evidence_ids=evidence_ids,
            last_synthesized=row.get("last_synthesized", ""),
            created_at=row.get("created_at", ""),
        )


@dataclass
class GraphDiagnostics:
    """Diagnostics summary for the knowledge graph."""

    total_nodes: int = 0
    active_nodes: int = 0
    total_edges: int = 0
    active_edges: int = 0
    orphan_nodes: int = 0
    avg_edge_confidence: float = 0.0
    most_connected_nodes: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ScoredCandidate:
    """A candidate reflection with its novelty/relevance score."""

    content: str
    type: str
    category: str = ""
    confidence: str = "medium"
    score: float = 0.0
    reasoning: str = ""
    contradicts: list[str] = field(default_factory=list)
    accepted: bool = False
    tags: list[str] = field(default_factory=list)
    behavioral_directive: str = ""


@dataclass
class EmbeddingMatch:
    """Result from an embedding similarity search."""

    reflection_id: str
    similarity: float


@dataclass
class NoveltyResult:
    """Result of novelty filtering for a single candidate."""

    content: str
    score: float  # 0.0 = redundant, 1.0 = completely novel
    accepted: bool
    method: str  # "embedding_accept" | "embedding_reject" | "llm" | "llm_fallback"
    reasoning: str
    contradicts: list[str] = field(default_factory=list)


@dataclass
class ReflectionPipelineResult:
    """Summary of a reflection pipeline run."""

    reflections_accepted: int = 0
    reflections_rejected: int = 0
    user_facts_saved: int = 0
    strategy_observations_logged: int = 0
    strategies_promoted: int = 0
    edges_created: int = 0
    session_context_saved: bool = False
    conversation_summary_saved: bool = False


@dataclass
class RuleResult:
    """Result from a rule engine evaluation."""

    rule_name: str
    fired: bool = False
    injected_text: str = ""
    reflections_affected: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Conversation:
    """A tracked conversation."""

    id: str
    title: str = ""
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)
    status: str = "active"
    summary: str = ""
    keywords: list[str] = field(default_factory=list)

    @property
    def keywords_json(self) -> str:
        return json.dumps(self.keywords)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> Conversation:
        """Create from a database row dict."""
        kw_raw = row.get("keywords", "[]")
        try:
            keywords = json.loads(kw_raw) if isinstance(kw_raw, str) else (kw_raw or [])
        except json.JSONDecodeError:
            logger.warning("Corrupt JSON in conversation %s keywords field", row.get("id", "?"))
            keywords = []
        return cls(
            id=row["id"],
            title=row.get("title", ""),
            created_at=row.get("created_at", ""),
            updated_at=row.get("updated_at", ""),
            status=row.get("status", "active"),
            summary=row.get("summary", ""),
            keywords=keywords,
        )


@dataclass
class ConversationSummary:
    """A summary of a conversation."""

    id: str
    conversation_id: str
    summary: str
    keywords: str = ""
    key_topics: str = ""
    status_markers: str = ""
    pending_items: str = ""
    created_at: str = field(default_factory=_now_iso)

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> ConversationSummary:
        """Create from a database row dict."""
        return cls(
            id=row["id"],
            conversation_id=row["conversation_id"],
            summary=row["summary"],
            keywords=row.get("keywords", ""),
            key_topics=row.get("key_topics", ""),
            status_markers=row.get("status_markers", ""),
            pending_items=row.get("pending_items", ""),
            created_at=row.get("created_at", ""),
        )
