"""Configuration management for limen-memory.

Loads settings from ~/.limen-memory/config.yaml with environment variable overrides.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

_DEFAULT_DATA_DIR = Path.home() / ".limen-memory"
_CONFIG_FILENAME = "config.yaml"
_DB_FILENAME = "memory.db"
_BACKUP_DIR = "backups"
_MAX_BACKUPS = 5

_VALID_EMBEDDING_PROVIDERS: frozenset[str] = frozenset({"openai", "ollama"})

_VALID_YAML_KEYS: frozenset[str] = frozenset(
    {
        "db_path",
        "backup_dir",
        "max_backups",
        "claude_model",
        "claude_novelty_model",
        "claude_timeout",
        "log_level",
        "embedding_provider",
        "embedding_api_key",
        "embedding_model",
        "embedding_dimensions",
        "embedding_base_url",
        "mcp_port",
        "mcp_ssl_certfile",
        "mcp_ssl_keyfile",
    }
)


@dataclass
class LimenConfig:
    """Runtime configuration for limen."""

    data_dir: Path = field(default_factory=lambda: _DEFAULT_DATA_DIR)
    db_path: Path = field(default=Path(""))
    backup_dir: Path = field(default=Path(""))
    max_backups: int = _MAX_BACKUPS
    claude_model: str = "sonnet"
    claude_novelty_model: str = "haiku"
    claude_timeout: int = 150
    log_level: str = "INFO"

    # Embedding provider fields.
    embedding_provider: str = ""
    embedding_api_key: str = ""
    embedding_model: str = ""
    embedding_dimensions: int = 0
    embedding_base_url: str = ""

    # MCP HTTP server settings (used by launchd service).
    mcp_port: int = 8000
    mcp_ssl_certfile: str = ""
    mcp_ssl_keyfile: str = ""

    def __post_init__(self) -> None:
        """Derive paths from data_dir if not explicitly set, then validate."""
        if not self.db_path or self.db_path == Path(""):
            self.db_path = self.data_dir / _DB_FILENAME
        if not self.backup_dir or self.backup_dir == Path(""):
            self.backup_dir = self.data_dir / _BACKUP_DIR
        self.validate()

    def validate(self) -> list[str]:
        """Validate configuration values.

        Checks that integer fields are positive, the embedding provider
        is a recognized value, and logs warnings for any issues found.

        Returns:
            List of warning messages (empty if all valid).
        """
        warnings: list[str] = []

        # Integer fields must be positive.
        for field_name in ("max_backups", "claude_timeout", "mcp_port"):
            value = getattr(self, field_name)
            if value <= 0:
                msg = f"{field_name} must be positive, got {value}"
                warnings.append(msg)

        # embedding_dimensions may be 0 (meaning "use provider default").
        if self.embedding_dimensions < 0:
            msg = f"embedding_dimensions must be non-negative, got {self.embedding_dimensions}"
            warnings.append(msg)

        # Embedding provider must be recognized.
        if self.embedding_provider and self.embedding_provider not in _VALID_EMBEDDING_PROVIDERS:
            msg = (
                f"Unrecognized embedding_provider {self.embedding_provider!r}. "
                f"Supported: {', '.join(sorted(_VALID_EMBEDDING_PROVIDERS))}"
            )
            warnings.append(msg)

        for msg in warnings:
            logger.warning("Config validation: %s", msg)

        return warnings


def _migrate_data_dir_if_needed() -> None:
    """Migrate ~/.limen/ to ~/.limen-memory/ if needed."""
    old_dir = Path.home() / ".limen"
    new_dir = Path.home() / ".limen-memory"
    if old_dir.exists() and not old_dir.is_symlink() and not new_dir.exists():
        old_dir.rename(new_dir)
        old_dir.symlink_to(new_dir)


def load_config(
    config_path: Path | None = None,
    data_dir: Path | None = None,
) -> LimenConfig:
    """Load configuration from YAML file with environment variable overrides.

    Priority (highest to lowest):
        1. Environment variables (LIMEN_*)
        2. Explicit function arguments
        3. Config file values
        4. Defaults

    Args:
        config_path: Explicit path to config YAML. If None, uses data_dir/config.yaml.
        data_dir: Override the data directory. If None, uses LIMEN_DATA_DIR or ~/.limen-memory/.

    Returns:
        Populated LimenConfig instance.
    """
    _migrate_data_dir_if_needed()
    env_data_dir = os.environ.get("LIMEN_DATA_DIR")
    resolved_data_dir = (
        data_dir or (Path(env_data_dir) if env_data_dir else None) or _DEFAULT_DATA_DIR
    )

    resolved_config_path = config_path or (resolved_data_dir / _CONFIG_FILENAME)

    file_values: dict[str, str | int] = {}
    if resolved_config_path.exists():
        with open(resolved_config_path) as f:
            raw = yaml.safe_load(f)
            if isinstance(raw, dict):
                file_values = raw

    # Warn about unrecognized YAML keys (typo detection).
    unrecognized = set(file_values.keys()) - _VALID_YAML_KEYS
    for key in sorted(unrecognized):
        logger.warning(
            "Unrecognized config key %r in %s (possible typo?)",
            key,
            resolved_config_path,
        )

    config = LimenConfig(data_dir=resolved_data_dir)

    if "db_path" in file_values:
        config.db_path = Path(str(file_values["db_path"]))
    if "backup_dir" in file_values:
        config.backup_dir = Path(str(file_values["backup_dir"]))
    if "max_backups" in file_values:
        config.max_backups = int(file_values["max_backups"])
    if "claude_model" in file_values:
        config.claude_model = str(file_values["claude_model"])
    if "claude_novelty_model" in file_values:
        config.claude_novelty_model = str(file_values["claude_novelty_model"])
    if "claude_timeout" in file_values:
        config.claude_timeout = int(file_values["claude_timeout"])
    if "log_level" in file_values:
        config.log_level = str(file_values["log_level"])
    if "embedding_provider" in file_values:
        config.embedding_provider = str(file_values["embedding_provider"])
    if "embedding_api_key" in file_values:
        config.embedding_api_key = str(file_values["embedding_api_key"])
    if "embedding_model" in file_values:
        config.embedding_model = str(file_values["embedding_model"])
    if "embedding_dimensions" in file_values:
        config.embedding_dimensions = int(file_values["embedding_dimensions"])
    if "embedding_base_url" in file_values:
        config.embedding_base_url = str(file_values["embedding_base_url"])
    if "mcp_port" in file_values:
        config.mcp_port = int(file_values["mcp_port"])
    if "mcp_ssl_certfile" in file_values:
        config.mcp_ssl_certfile = str(file_values["mcp_ssl_certfile"])
    if "mcp_ssl_keyfile" in file_values:
        config.mcp_ssl_keyfile = str(file_values["mcp_ssl_keyfile"])

    env_overrides: dict[str, tuple[str, type]] = {
        "LIMEN_DB_PATH": ("db_path", str),
        "LIMEN_BACKUP_DIR": ("backup_dir", str),
        "LIMEN_MAX_BACKUPS": ("max_backups", int),
        "LIMEN_CLAUDE_MODEL": ("claude_model", str),
        "LIMEN_CLAUDE_NOVELTY_MODEL": ("claude_novelty_model", str),
        "LIMEN_CLAUDE_TIMEOUT": ("claude_timeout", int),
        "LIMEN_LOG_LEVEL": ("log_level", str),
        "LIMEN_EMBEDDING_PROVIDER": ("embedding_provider", str),
        "LIMEN_EMBEDDING_API_KEY": ("embedding_api_key", str),
        "LIMEN_EMBEDDING_MODEL": ("embedding_model", str),
        "LIMEN_EMBEDDING_DIMENSIONS": ("embedding_dimensions", int),
        "LIMEN_EMBEDDING_BASE_URL": ("embedding_base_url", str),
        "LIMEN_MCP_PORT": ("mcp_port", int),
        "LIMEN_MCP_SSL_CERTFILE": ("mcp_ssl_certfile", str),
        "LIMEN_MCP_SSL_KEYFILE": ("mcp_ssl_keyfile", str),
    }
    for env_key, (attr, attr_type) in env_overrides.items():
        env_val = os.environ.get(env_key)
        if env_val is not None:
            if attr in ("db_path", "backup_dir"):
                setattr(config, attr, Path(env_val))
            else:
                setattr(config, attr, attr_type(env_val))

    return config


def ensure_data_dir(config: LimenConfig) -> None:
    """Create the data directory and subdirectories if they don't exist.

    Args:
        config: The limen configuration.
    """
    config.data_dir.mkdir(parents=True, exist_ok=True)
    config.backup_dir.mkdir(parents=True, exist_ok=True)
    (config.data_dir / "logs").mkdir(parents=True, exist_ok=True)


_DEFAULT_CONFIG_TEMPLATE = """\
# Limen configuration
# See: limen-memory --help

# --- Embedding provider ---
# Supported providers: openai, ollama
embedding_provider: ollama

# API key (required for openai; ignored for ollama).
# embedding_api_key: ""

# Provider-specific model name (empty = provider default):
#   openai  → text-embedding-3-small
#   ollama  → embeddinggemma
embedding_model: "embeddinggemma"

# Embedding dimensions (0 = provider default):
#   openai  → 1536
#   ollama  → 768
embedding_dimensions: 768

# Ollama server URL (only used when embedding_provider is ollama)
embedding_base_url: http://localhost:11434

# Claude model for LLM operations (reflection analysis, consolidation)
claude_model: sonnet
# Claude model for novelty scoring — haiku is sufficient for yes/no filtering
claude_novelty_model: haiku
claude_timeout: 150

# Maximum database backups to retain
max_backups: 5

# Logging level
log_level: INFO
"""


def write_default_config(config: LimenConfig) -> Path:
    """Write a default config.yaml if one does not already exist.

    Args:
        config: The limen configuration (uses data_dir to locate config path).

    Returns:
        Path to the config file.
    """
    config_path = config.data_dir / _CONFIG_FILENAME
    if not config_path.exists():
        config_path.write_text(_DEFAULT_CONFIG_TEMPLATE, encoding="utf-8")
    return config_path
