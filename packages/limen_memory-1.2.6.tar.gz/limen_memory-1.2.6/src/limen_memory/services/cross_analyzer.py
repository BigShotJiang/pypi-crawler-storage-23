"""Cross-conversation analysis service.

Analyzes recent conversation summaries to detect recurring topics,
shifting interests, and unresolved threads. Saves new reflections and
user fact updates directly to the database. New reflections are checked
against existing embeddings for novelty before saving.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from limen_memory.constants import (
    CROSS_ANALYSIS_MIN_CONVERSATIONS,
    CROSS_ANALYSIS_SUMMARIES_LIMIT,
    EMBEDDING_REJECT_SIMILARITY,
)
from limen_memory.models import MemoryReflection, UserFact
from limen_memory.services.llm_client import LLMClient
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.memory_store import MemoryStore

if TYPE_CHECKING:
    from limen_memory.services.embedding._base import BaseEmbeddingClient
    from limen_memory.store.embedding_store import EmbeddingStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


_SYSTEM_PROMPT = (
    "You are a cross-conversation analysis engine. You analyze patterns across "
    "multiple conversations to identify recurring topics, shifting interests, "
    "unresolved threads, and emerging user behaviors that only become visible "
    "when looking at the long view (3+ conversations).\n\n"
    "You MUST respond with ONLY a single valid JSON object. No explanation, "
    "no markdown fences, just the JSON.\n\n"
    "Focus on:\n"
    "- Recurring topics that appear in multiple conversations\n"
    "- Shifting interests or focus areas over time\n"
    "- Unresolved threads that keep appearing\n"
    "- Emerging patterns in how the user works or communicates\n"
    "- New user facts or updates to existing facts\n\n"
    "Do NOT produce insights that are obvious from a single conversation — "
    "only report patterns that require the cross-conversation perspective.\n\n"
    "Confidence levels:\n"
    "- high: pattern appears in 5+ conversations or is very strong\n"
    "- medium: pattern appears in 3-4 conversations\n"
    "- low: pattern appears in 2 conversations (tentative)\n\n"
    "For new reflections, use type 'pattern' for recurring behaviors, "
    "'insight' for analytical observations, and 'preference' for discovered "
    "preferences."
)


class CrossAnalyzer:
    """Analyzes patterns across recent conversations.

    Args:
        memory_store: Reflection and fact storage.
        conversation_store: Conversation summaries.
        llm_client: Claude CLI client.
        embedding_client: Optional embedding client for novelty checks.
        embedding_store: Optional embedding store for novelty checks.
    """

    def __init__(
        self,
        memory_store: MemoryStore,
        conversation_store: ConversationStore,
        llm_client: LLMClient,
        embedding_client: BaseEmbeddingClient | None = None,
        embedding_store: EmbeddingStore | None = None,
    ) -> None:
        self._memory = memory_store
        self._conversations = conversation_store
        self._llm = llm_client
        self._embedding_client = embedding_client
        self._embedding_store = embedding_store

    def analyze(self) -> dict[str, Any]:
        """Run cross-conversation analysis.

        Loads recent summaries, existing reflections and user facts,
        then uses the LLM to detect cross-conversation patterns.
        New reflections are saved directly (no novelty filter).

        Returns:
            Dict with counts of summaries_analyzed, reflections_created,
            facts_updated, facts_deprecated, and patterns_detected.

        Raises:
            ValueError: If fewer than CROSS_ANALYSIS_MIN_CONVERSATIONS
                summaries are available.
        """
        summaries = self._conversations.get_recent_summaries(limit=CROSS_ANALYSIS_SUMMARIES_LIMIT)
        if len(summaries) < CROSS_ANALYSIS_MIN_CONVERSATIONS:
            raise ValueError(
                f"Insufficient conversations for cross-analysis: "
                f"{len(summaries)} < {CROSS_ANALYSIS_MIN_CONVERSATIONS}"
            )

        # Gather context
        reflections = self._memory.get_active_reflections(limit=100)
        facts = self._memory.query_user_facts()

        # Build prompt
        prompt = self._build_prompt(summaries, reflections, facts)

        # Call LLM
        try:
            result = self._llm.prompt_json(prompt, system_prompt=_SYSTEM_PROMPT)
        except Exception:
            logger.exception("Cross-analysis LLM call failed")
            return {
                "summaries_analyzed": len(summaries),
                "reflections_created": 0,
                "facts_updated": 0,
                "facts_deprecated": 0,
                "patterns_detected": [],
                "error": "LLM call failed",
            }

        # Apply results
        return self._apply_results(result, len(summaries))

    def _build_prompt(
        self,
        summaries: list[Any],
        reflections: list[MemoryReflection],
        facts: list[UserFact],
    ) -> str:
        """Build the analysis prompt with all context.

        Args:
            summaries: Recent conversation summaries.
            reflections: Existing active reflections.
            facts: Existing user facts.

        Returns:
            Formatted prompt string.
        """
        parts: list[str] = []

        # Summaries section
        parts.append(f"## Recent Conversations ({len(summaries)} summaries)\n")
        for i, s in enumerate(summaries, 1):
            parts.append(f"### Conversation {i} [{s.created_at[:10]}]")
            parts.append(f"Summary: {s.summary}")
            if s.keywords:
                parts.append(f"Keywords: {s.keywords}")
            if s.key_topics:
                parts.append(f"Topics: {s.key_topics}")
            if s.pending_items:
                parts.append(f"Pending: {s.pending_items}")
            parts.append("")

        # Existing reflections (truncated for context)
        if reflections:
            parts.append(f"\n## Existing Reflections ({len(reflections)} active)\n")
            for r in reflections[:30]:
                parts.append(f"- [{r.type}/{r.confidence}] {r.content[:120]}")
            if len(reflections) > 30:
                parts.append(f"  ... and {len(reflections) - 30} more")
            parts.append("")

        # Existing facts
        if facts:
            parts.append(f"\n## Known User Facts ({len(facts)})\n")
            for f in facts:
                parts.append(f"- {f.category}/{f.key}: {f.value}")
            parts.append("")

        parts.append(
            "\nAnalyze the conversations above for cross-conversation patterns. "
            "Avoid duplicating existing reflections. Return JSON with:\n"
            "{\n"
            '  "new_reflections": [{"type": "", "category": "", "content": "", '
            '"confidence": "", "tags": []}],\n'
            '  "user_fact_updates": [{"category": "", "key": "", "value": "", '
            '"confidence": ""}],\n'
            '  "deprecated_fact_ids": [],\n'
            '  "patterns_detected": ["description of each pattern"]\n'
            "}"
        )

        return "\n".join(parts)

    def _apply_results(self, result: dict[str, Any], summaries_count: int) -> dict[str, Any]:
        """Apply LLM analysis results to the database.

        Args:
            result: Parsed LLM JSON response.
            summaries_count: Number of summaries analyzed.

        Returns:
            Summary dict with counts.
        """
        now = _now_iso()
        reflections_created = 0
        facts_updated = 0
        facts_deprecated = 0

        # Save new reflections (with embedding novelty check if available)
        skipped_duplicate = 0
        for r_data in result.get("new_reflections", []):
            try:
                tags = r_data.get("tags", [])
                if not isinstance(tags, list):
                    tags = []
                reflection = MemoryReflection(
                    id=_uid(),
                    timestamp=now,
                    type=r_data.get("type", "pattern"),
                    content=r_data.get("content", ""),
                    category=r_data.get("category", "cross_analysis"),
                    confidence=r_data.get("confidence", "medium"),
                    tags=tags,
                    source_session="cross-analysis",
                    epistemic_status="hypothesis",
                )
                if not reflection.content:
                    continue

                # Novelty check: skip if too similar to existing embeddings
                if self._embedding_client and self._embedding_store:
                    try:
                        emb = self._embedding_client.embed_single(reflection.content)
                        sim = self._embedding_store.get_max_similarity(emb)
                        if sim > EMBEDDING_REJECT_SIMILARITY:
                            logger.debug(
                                "Cross-analysis reflection too similar (%.2f), skipping",
                                sim,
                            )
                            skipped_duplicate += 1
                            continue
                    except Exception:
                        logger.debug("Novelty check failed, saving reflection anyway")

                self._memory.save_reflection(reflection)
                reflections_created += 1
            except Exception:
                logger.warning("Failed to save cross-analysis reflection", exc_info=True)

        # Update user facts
        for f_data in result.get("user_fact_updates", []):
            try:
                fact = UserFact(
                    id=_uid(),
                    category=f_data.get("category", ""),
                    key=f_data.get("key", ""),
                    value=f_data.get("value", ""),
                    confidence=f_data.get("confidence", "medium"),
                    first_observed=now,
                    last_verified=now,
                )
                if fact.category and fact.key and fact.value:
                    self._memory.save_user_fact(fact)
                    facts_updated += 1
            except Exception:
                logger.warning("Failed to save cross-analysis user fact", exc_info=True)

        # Deprecate outdated facts
        for fact_id in result.get("deprecated_fact_ids", []):
            try:
                if self._memory.deprecate_user_fact(str(fact_id)):
                    facts_deprecated += 1
            except Exception:
                logger.warning("Failed to deprecate fact %s", fact_id, exc_info=True)

        patterns = result.get("patterns_detected", [])
        if not isinstance(patterns, list):
            patterns = []

        if skipped_duplicate > 0:
            logger.info("Cross-analysis skipped %d duplicate reflections", skipped_duplicate)

        logger.info(
            "Cross-analysis complete: %d reflections, %d facts updated, "
            "%d facts deprecated, %d patterns",
            reflections_created,
            facts_updated,
            facts_deprecated,
            len(patterns),
        )

        return {
            "summaries_analyzed": summaries_count,
            "reflections_created": reflections_created,
            "reflections_skipped_duplicate": skipped_duplicate,
            "facts_updated": facts_updated,
            "facts_deprecated": facts_deprecated,
            "patterns_detected": patterns,
        }
