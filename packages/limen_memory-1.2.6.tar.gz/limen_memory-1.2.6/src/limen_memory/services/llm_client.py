"""Claude CLI subprocess wrapper with JSON parse fallback chain."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess  # nosec B404
from typing import Any

logger = logging.getLogger(__name__)

# Common install locations for the claude CLI on macOS/Linux.
# Checked as a fallback when ``claude`` is not on the inherited PATH
# (e.g. when running inside Claude Desktop's MCP subprocess).
_EXTRA_SEARCH_PATHS = [
    "/opt/homebrew/bin",
    "/usr/local/bin",
    os.path.expanduser("~/.local/bin"),
    os.path.expanduser("~/.npm-global/bin"),
]


def _resolve_claude_cli() -> str:
    """Find the ``claude`` CLI binary.

    Checks the current PATH first, then falls back to common install
    locations. This avoids hard-coding a version-specific path while
    still working in restricted PATH environments like MCP subprocesses.

    Returns:
        Absolute path to the ``claude`` binary, or ``"claude"`` as a
        last resort (will raise FileNotFoundError at call time).
    """
    # Try the normal PATH first
    found = shutil.which("claude")
    if found:
        return found

    # Search common locations
    for directory in _EXTRA_SEARCH_PATHS:
        candidate = os.path.join(directory, "claude")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            logger.info("Resolved claude CLI at %s (not on PATH)", candidate)
            return candidate

    logger.warning("claude CLI not found on PATH or common locations")
    return "claude"  # Let subprocess raise FileNotFoundError with a clear message


class LLMParseError(Exception):
    """Raised when LLM output cannot be parsed as JSON."""


class LLMClient:
    """Wrapper around the ``claude`` CLI for structured JSON responses.

    Resolves the ``claude`` binary path at init time, searching common
    install locations if the CLI is not on the inherited PATH.

    Args:
        model: Claude model to use (default "sonnet").
        timeout: Subprocess timeout in seconds (default 120).
    """

    def __init__(self, model: str = "sonnet", timeout: int = 120) -> None:
        self._model = model
        self._timeout = timeout
        self._claude_path = _resolve_claude_cli()

    def prompt_json(self, prompt: str, system_prompt: str | None = None) -> dict[str, Any]:
        """Run ``claude --print`` and parse the JSON response.

        Fallback chain:
            1. ``json.loads(raw.strip())``
            2. Strip markdown fences then ``json.loads``
            3. Brace-depth extraction then ``json.loads``
            4. Raise ``LLMParseError``

        Args:
            prompt: The prompt text.
            system_prompt: Optional system prompt to append.

        Returns:
            Parsed JSON dict.

        Raises:
            LLMParseError: If all parse strategies fail.
            subprocess.TimeoutExpired: If claude times out.
            FileNotFoundError: If claude CLI is not installed.
        """
        cmd = [self._claude_path, "--print", "-p", prompt, "--model", self._model]
        if system_prompt:
            cmd.extend(["--append-system-prompt", system_prompt])

        # Ensure the subprocess inherits critical env vars.
        # Claude Desktop's MCP subprocess strips most of the user's
        # environment.  The ``claude`` CLI requires at minimum ``USER``
        # (for auth-config lookup) and ``HOME``.
        env = os.environ.copy()
        if "USER" not in env:
            import getpass

            env["USER"] = getpass.getuser()

        # Remove CLAUDECODE to avoid nested-session detection.
        # The MCP server runs inside a Claude Code process, but ``claude --print``
        # is a standalone invocation — not a nested session.
        env.pop("CLAUDECODE", None)

        result = subprocess.run(  # nosec B603
            cmd,
            capture_output=True,
            text=True,
            timeout=self._timeout,
            env=env,
        )

        raw = result.stdout
        if result.returncode != 0:
            logger.error(
                "claude CLI failed (rc=%d): %s",
                result.returncode,
                result.stderr[:200],
            )
            raise LLMParseError(
                f"claude CLI exited with code {result.returncode}: {result.stderr[:200]}"
            )

        return self._extract_json(raw)

    def prompt_json_validated(
        self,
        prompt: str,
        system_prompt: str | None = None,
        required_keys: list[str] | None = None,
    ) -> dict[str, Any]:
        """Run ``prompt_json`` and validate the response contains required keys.

        Args:
            prompt: The prompt text.
            system_prompt: Optional system prompt to append.
            required_keys: Keys that must be present in the response dict.

        Returns:
            Parsed and validated JSON dict.

        Raises:
            LLMParseError: If parsing fails or required keys are missing.
        """
        result = self.prompt_json(prompt, system_prompt)
        if required_keys:
            missing = [k for k in required_keys if k not in result]
            if missing:
                raise LLMParseError(f"LLM response missing required keys: {missing}")
        return result

    def _extract_json(self, raw: str) -> dict[str, Any]:
        """Extract JSON from raw LLM output using fallback chain.

        Args:
            raw: Raw string output from claude CLI.

        Returns:
            Parsed JSON dict.

        Raises:
            LLMParseError: If all strategies fail.
        """
        stripped = raw.strip()

        # Strategy 1: Direct parse
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass

        # Strategy 2: Strip markdown fences
        defenced = _strip_markdown_fences(stripped)
        if defenced != stripped:
            try:
                parsed = json.loads(defenced)
                if isinstance(parsed, dict):
                    return parsed
            except (json.JSONDecodeError, ValueError):
                pass

        # Strategy 3: Brace-depth extraction
        extracted = _extract_json_by_depth(stripped)
        if extracted:
            try:
                parsed = json.loads(extracted)
                if isinstance(parsed, dict):
                    return parsed
            except (json.JSONDecodeError, ValueError):
                pass

        # All strategies failed
        preview = raw[:300] if len(raw) > 300 else raw
        logger.error("Failed to parse JSON from LLM response: %s", preview)
        raise LLMParseError(f"Could not extract JSON from response: {preview}")


def _strip_markdown_fences(text: str) -> str:
    """Strip markdown code fences from text.

    Handles ``json ... `` and plain `` ... `` patterns.

    Args:
        text: Input text possibly wrapped in code fences.

    Returns:
        Text with fences stripped, or original text if no fences found.
    """
    lines = text.split("\n")
    start_idx = -1
    end_idx = -1

    for i, line in enumerate(lines):
        stripped_line = line.strip()
        if stripped_line.startswith("```") and start_idx == -1:
            start_idx = i
        elif stripped_line == "```" and start_idx != -1 and i > start_idx:
            end_idx = i
            break

    if start_idx != -1 and end_idx != -1:
        content_lines = lines[start_idx + 1 : end_idx]
        return "\n".join(content_lines).strip()

    return text


def _extract_json_by_depth(text: str) -> str | None:
    """Extract JSON object by tracking brace depth.

    Finds the first ``{`` and tracks depth to find the matching ``}``.
    Handles nested braces and quoted strings with escapes.

    Args:
        text: Input text containing a JSON object somewhere.

    Returns:
        Extracted JSON string, or None if no valid object found.
    """
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    in_string = False
    escape_next = False

    for i in range(start, len(text)):
        ch = text[i]

        if escape_next:
            escape_next = False
            continue

        if ch == "\\" and in_string:
            escape_next = True
            continue

        if ch == '"':
            in_string = not in_string
            continue

        if in_string:
            continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]

    return None
