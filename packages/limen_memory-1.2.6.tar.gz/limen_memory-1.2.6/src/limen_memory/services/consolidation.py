"""Memory consolidation: LLM-driven deduplication, merging, edge validation, directives."""

from __future__ import annotations

import logging
import time
import uuid
from collections import defaultdict
from datetime import datetime
from typing import Any

from limen_memory.constants import (
    CONSOLIDATION_BATCH_SIZE,
    CONSOLIDATION_SUMMARY_CONTEXT_LIMIT,
)
from limen_memory.models import GraphEdge, MemoryReflection, UserFact
from limen_memory.services.embedding._base import BaseEmbeddingClient
from limen_memory.services.llm_client import LLMClient, LLMParseError
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.embedding_store import EmbeddingStore
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


class ConsolidationService:
    """LLM-driven memory consolidation.

    Deduplicates reflections, merges related entries, validates working memory
    edges, and backfills behavioral directives.

    Args:
        memory_store: Reflection/fact CRUD.
        graph_store: Graph edge operations.
        embedding_store: Embedding storage.
        embedding_client: Embedding client for vector operations.
        conversation_store: For recent summaries context.
        llm_client: Claude CLI client (should use 300s timeout).
    """

    def __init__(
        self,
        memory_store: MemoryStore,
        graph_store: GraphStore,
        embedding_store: EmbeddingStore,
        embedding_client: BaseEmbeddingClient,
        conversation_store: ConversationStore,
        llm_client: LLMClient,
    ) -> None:
        self._memory = memory_store
        self._graph = graph_store
        self._embedding_store = embedding_store
        self._embeddings = embedding_client
        self._conversations = conversation_store
        self._llm = llm_client

    def consolidate(self) -> dict[str, Any]:
        """Run full consolidation pass.

        Loads active reflections and user facts, batches by category,
        runs LLM consolidation per batch, then chains edge validation
        and directive backfill.

        Returns:
            Summary dict with counts of actions taken.
        """
        start = time.monotonic()

        reflections = self._memory.get_active_reflections(limit=500)
        user_facts = self._memory.query_user_facts()
        recent_summaries = self._conversations.get_recent_summaries(
            limit=CONSOLIDATION_SUMMARY_CONTEXT_LIMIT
        )

        logger.info(
            "Starting consolidation: %d reflections, %d facts",
            len(reflections),
            len(user_facts),
        )

        batches = self._build_batches(reflections)
        total_deprecated = 0
        total_created = 0
        total_edges = 0
        all_changelog: list[str] = []

        for i, batch in enumerate(batches):
            logger.debug("Processing batch %d/%d (%d items)", i + 1, len(batches), len(batch))
            try:
                result = self._process_batch(batch, user_facts, recent_summaries)
                total_deprecated += result["deprecated_reflections"] + result["deprecated_facts"]
                total_created += result["new_reflections"] + result["new_facts"]
                total_edges += result["edges_created"]
                all_changelog.extend(result["changelog"])
            except (LLMParseError, Exception) as exc:
                logger.error("Batch %d failed, skipping: %s", i + 1, exc)
                continue

        # Chain sub-tasks
        validation_result = self.validate_working_memory_edges()
        backfilled_count = self.backfill_directives()

        duration_ms = int((time.monotonic() - start) * 1000)

        # Log consolidation run
        self._conversations.save_consolidation_log(
            log_id=_uid(),
            timestamp=_now_iso(),
            entries_before=len(reflections),
            entries_after=len(reflections) - total_deprecated + total_created,
            changelog="; ".join(all_changelog[:50]),
            duration_ms=duration_ms,
            model_used="sonnet",
            tokens_used=0,
        )

        summary: dict[str, Any] = {
            "reflections_before": len(reflections),
            "reflections_after": len(reflections) - total_deprecated + total_created,
            "deprecated": total_deprecated,
            "created": total_created,
            "edges_created": total_edges,
            "edges_validated": validation_result["validated"],
            "edges_deprecated": validation_result["deprecated"],
            "directives_backfilled": backfilled_count,
            "duration_ms": duration_ms,
            "batches_processed": len(batches),
        }

        logger.info(
            "Consolidation complete: %d reflections -> %d, %d edges validated, "
            "%d directives backfilled in %dms",
            len(reflections),
            summary["reflections_after"],
            summary["edges_validated"],
            backfilled_count,
            duration_ms,
        )

        return summary

    def validate_working_memory_edges(self) -> dict[str, int]:
        """Validate provisional working memory edges via LLM batch review.

        Queries unvalidated edges, loads source/target reflections, asks LLM
        to validate each edge, then updates confidence or deprecates.

        Returns:
            Dict with 'validated' and 'deprecated' counts.
        """
        edges = self._graph.get_unvalidated_working_memory_edges(limit=50)

        if len(edges) < 5:
            logger.info("Only %d unvalidated edges, skipping validation", len(edges))
            return {"validated": 0, "deprecated": 0}

        logger.info("Validating %d working memory edges", len(edges))

        edge_data: list[dict[str, Any]] = []
        for edge in edges:
            source = self._memory.get_reflection(edge.source_id)
            target = self._memory.get_reflection(edge.target_id)
            if not source or not target:
                logger.warning("Missing reflection for edge %s, skipping", edge.id)
                continue
            edge_data.append(
                {
                    "edge_id": edge.id,
                    "source_id": edge.source_id,
                    "source_content": source.content,
                    "target_id": edge.target_id,
                    "target_content": target.content,
                    "relationship_type": edge.relationship_type,
                    "current_confidence": edge.confidence,
                }
            )

        if not edge_data:
            logger.warning("No valid edge pairs to validate")
            return {"validated": 0, "deprecated": 0}

        prompt = self._build_edge_validation_prompt(edge_data)
        system_prompt = (
            "You are a memory validation engine. Respond with ONLY a single "
            "valid JSON object. Do not include any text before or after the JSON."
        )

        try:
            response = self._llm.prompt_json(prompt, system_prompt)
        except (LLMParseError, Exception) as exc:
            logger.error("Edge validation LLM call failed: %s", exc)
            return {"validated": 0, "deprecated": 0}

        validations = response.get("validations", [])
        validated_count = 0
        deprecated_count = 0

        for validation in validations:
            edge_id = validation.get("edge_id")
            is_valid = validation.get("valid", False)
            new_confidence = float(validation.get("new_confidence", 0.5))
            reasoning = validation.get("reasoning", "")

            if not edge_id:
                continue

            if is_valid:
                self._graph.update_edge_confidence(edge_id, new_confidence)
                new_evidence = f"Validated: {reasoning[:200]}"
                self._graph.update_edge_evidence(edge_id, new_evidence)
                validated_count += 1
            else:
                self._graph.deprecate_edge(edge_id)
                deprecated_count += 1

        logger.info(
            "Edge validation complete: %d validated, %d deprecated",
            validated_count,
            deprecated_count,
        )
        return {"validated": validated_count, "deprecated": deprecated_count}

    def backfill_directives(self) -> int:
        """Generate behavioral directives for reflections that lack them.

        Processes in batches of 20, asks LLM to generate directives for
        high/medium confidence reflections that warrant behavioral guidance.

        Returns:
            Number of directives backfilled.
        """
        reflections = self._memory.get_reflections_without_directive(limit=100)

        if not reflections:
            logger.info("No reflections need directive backfill")
            return 0

        logger.info("Backfilling directives for %d reflections", len(reflections))

        total_backfilled = 0
        batch_size = 20

        for i in range(0, len(reflections), batch_size):
            batch = reflections[i : i + batch_size]
            logger.debug(
                "Processing directive batch %d-%d of %d",
                i,
                i + len(batch),
                len(reflections),
            )

            try:
                result = self._process_directive_batch(batch)
                total_backfilled += result
            except (LLMParseError, Exception) as exc:
                logger.error("Directive batch failed: %s", exc)
                continue

        logger.info("Backfilled %d directives", total_backfilled)
        return total_backfilled

    # --- Private methods ---

    def _build_batches(self, reflections: list[MemoryReflection]) -> list[list[MemoryReflection]]:
        """Group reflections by category and split into batches.

        Args:
            reflections: All reflections to batch.

        Returns:
            List of batches, each with up to CONSOLIDATION_BATCH_SIZE reflections.
        """
        by_category: dict[str, list[MemoryReflection]] = defaultdict(list)
        for r in reflections:
            by_category[r.category].append(r)

        batches: list[list[MemoryReflection]] = []
        for _category, category_reflections in by_category.items():
            for i in range(0, len(category_reflections), CONSOLIDATION_BATCH_SIZE):
                batch = category_reflections[i : i + CONSOLIDATION_BATCH_SIZE]
                batches.append(batch)

        return batches

    def _process_batch(
        self,
        batch: list[MemoryReflection],
        user_facts: list[UserFact],
        recent_summaries: list[Any],
    ) -> dict[str, Any]:
        """Process a single batch of reflections via LLM consolidation.

        Args:
            batch: Reflections to consolidate.
            user_facts: Current user facts for context.
            recent_summaries: Recent conversation summaries for context.

        Returns:
            Dict with counts and changelog entries.
        """
        prompt = self._build_batch_prompt(batch, user_facts, recent_summaries)
        system_prompt = (
            "You are a memory consolidation engine. Respond with ONLY a "
            "single valid JSON object. Do not include any text before or after the JSON."
        )

        response = self._llm.prompt_json_validated(
            prompt, system_prompt, required_keys=["deprecate_reflection_ids"]
        )

        result: dict[str, Any] = {
            "deprecated_reflections": 0,
            "new_reflections": 0,
            "deprecated_facts": 0,
            "new_facts": 0,
            "edges_created": 0,
            "changelog": [],
        }

        deprecated_ids: list[str] = []
        for reflection_id in response.get("deprecate_reflection_ids", []):
            if self._memory.deprecate_reflection(reflection_id, reason="Consolidated"):
                self._embedding_store.delete_embedding(reflection_id)
                deprecated_ids.append(reflection_id)
                result["deprecated_reflections"] += 1
                result["changelog"].append(f"Deprecated reflection {reflection_id[:8]}")

        new_reflection_ids: list[str] = []
        for new_r in response.get("new_reflections", []):
            reflection = self._create_reflection(new_r)
            if reflection:
                new_reflection_ids.append(reflection.id)
                result["new_reflections"] += 1
                result["changelog"].append(
                    f"Created {reflection.type} reflection: {reflection.content[:60]}"
                )

        # Remap edges from deprecated reflections to their merged replacement
        if deprecated_ids and new_reflection_ids:
            target_id = new_reflection_ids[0]
            for deprecated_id in deprecated_ids:
                self._graph.remap_edges(deprecated_id, target_id)

        for fact_id in response.get("deprecate_user_fact_ids", []):
            if self._memory.deprecate_user_fact(fact_id):
                result["deprecated_facts"] += 1
                result["changelog"].append(f"Deprecated fact {fact_id[:8]}")

        for new_f in response.get("new_user_facts", []):
            fact = self._create_user_fact(new_f)
            if fact:
                result["new_facts"] += 1
                result["changelog"].append(f"Created fact {fact.category}: {fact.key[:40]}")

        for rel in response.get("relationships", []):
            edge = self._create_relationship(rel)
            if edge:
                result["edges_created"] += 1

        for entry in response.get("changelog", []):
            action = entry.get("action", "")
            detail = entry.get("detail", "")
            if action and detail:
                result["changelog"].append(f"{action}: {detail[:80]}")

        return result

    def _build_batch_prompt(
        self,
        batch: list[MemoryReflection],
        user_facts: list[UserFact],
        recent_summaries: list[Any],
    ) -> str:
        """Build consolidation prompt for a batch.

        Args:
            batch: Reflections to consolidate.
            user_facts: User facts for context.
            recent_summaries: Recent conversation summaries.

        Returns:
            Complete prompt string.
        """
        lines = [
            "You are consolidating memory reflections. Your task is to:",
            "1. Identify redundant or outdated reflections to deprecate",
            "2. Merge similar reflections into higher-confidence versions",
            "3. Create new relationships between related reflections",
            "4. Update or deprecate user facts that have changed",
            "",
            "## Reflections to Review",
            "",
        ]

        for r in batch:
            lines.append(
                f"- ID: {r.id} | Type: {r.type} | Category: {r.category} | "
                f"Confidence: {r.confidence}"
            )
            lines.append(f"  Content: {r.content}")
            lines.append("")

        lines.append("## Current User Facts")
        lines.append("")
        for f in user_facts[:20]:
            lines.append(f"- ID: {f.id} | {f.category}: {f.key} = {f.value}")
        lines.append("")

        if recent_summaries:
            lines.append("## Recent Conversation Context")
            lines.append("")
            for s in recent_summaries:
                lines.append(f"- {s.summary[:100]}")
            lines.append("")

        lines.extend(
            [
                "## Response Format",
                "",
                "Respond with ONLY a JSON object:",
                "{",
                '  "deprecate_reflection_ids": ["id1", "id2"],',
                '  "new_reflections": [',
                "    {",
                '      "type": "insight|pattern|preference|domain_knowledge|'
                'working_style|challenge",',
                '      "category": "string",',
                '      "content": "string",',
                '      "confidence": "high|medium|low|speculation"',
                "    }",
                "  ],",
                '  "deprecate_user_fact_ids": ["id1"],',
                '  "new_user_facts": [',
                "    {",
                '      "category": "preferences|interests|expertise|'
                'work_context|communication_style",',
                '      "key": "short key",',
                '      "value": "full value"',
                "    }",
                "  ],",
                '  "relationships": [',
                "    {",
                '      "source_id": "reflection_id",',
                '      "target_id": "reflection_id",',
                '      "type": "reinforces|contradicts|refines|predicts|requires",',
                '      "confidence": 0.0,',
                '      "evidence": "explanation"',
                "    }",
                "  ],",
                '  "changelog": [',
                "    {",
                '      "action": "deprecated|merged|created|updated",',
                '      "detail": "brief description"',
                "    }",
                "  ]",
                "}",
                "",
                "Be conservative: only deprecate when truly redundant, only create new "
                "reflections when merging adds value.",
            ]
        )

        return "\n".join(lines)

    def _create_reflection(self, data: dict[str, Any]) -> MemoryReflection | None:
        """Create and save a new reflection with embedding.

        Args:
            data: Dict with type, category, content, confidence.

        Returns:
            The created reflection or None on failure.
        """
        try:
            content = data.get("content", "")
            if not content:
                return None

            embedding = self._embeddings.embed_single(content)

            now = _now_iso()
            reflection = MemoryReflection(
                id=_uid(),
                timestamp=now,
                type=data.get("type", "insight"),
                content=content,
                category=data.get("category", "Insights"),
                confidence=data.get("confidence", "medium"),
                source_session="consolidation",
            )

            self._memory.save_reflection(reflection)
            self._embedding_store.save_embedding(reflection.id, embedding)

            return reflection
        except Exception as exc:
            logger.error("Failed to create reflection: %s", exc)
            return None

    def _create_user_fact(self, data: dict[str, Any]) -> UserFact | None:
        """Create and save a new user fact.

        Args:
            data: Dict with category, key, value.

        Returns:
            UserFact or None on failure.
        """
        try:
            category = data.get("category", "")
            key = data.get("key", "")
            value = data.get("value", "")

            if not category or not key or not value:
                return None

            now = _now_iso()
            fact = UserFact(
                id=_uid(),
                category=category,
                key=key,
                value=value,
                confidence="medium",
                first_observed=now,
                last_verified=now,
            )

            self._memory.save_user_fact(fact)
            return fact
        except Exception as exc:
            logger.error("Failed to create user fact: %s", exc)
            return None

    def _create_relationship(self, data: dict[str, Any]) -> GraphEdge | None:
        """Create and save a relationship edge.

        Args:
            data: Dict with source_id, target_id, type, confidence, evidence.

        Returns:
            GraphEdge or None on failure.
        """
        try:
            source_id = data.get("source_id", "")
            target_id = data.get("target_id", "")
            rel_type = data.get("type", "")
            confidence = float(data.get("confidence", 0.5))
            evidence = data.get("evidence", "")

            if not source_id or not target_id or not rel_type:
                return None

            edge_category = "causal" if rel_type in ("predicts", "requires") else "evaluative"

            now = _now_iso()
            edge = GraphEdge(
                id=_uid(),
                source_id=source_id,
                target_id=target_id,
                source_type="reflection",
                target_type="reflection",
                relationship_type=rel_type,
                edge_category=edge_category,
                confidence=confidence,
                evidence=evidence,
                created_at=now,
                last_validated_at=now,
            )

            self._graph.save_relationship(edge)
            return edge
        except Exception as exc:
            logger.error("Failed to create relationship: %s", exc)
            return None

    def _build_edge_validation_prompt(self, edge_data: list[dict[str, Any]]) -> str:
        """Build LLM prompt for edge validation.

        Args:
            edge_data: List of dicts with edge_id, source/target content, etc.

        Returns:
            Complete prompt string.
        """
        lines = [
            "You are validating provisional memory relationships. For each edge, "
            "determine if the relationship is valid and assign a confidence score.",
            "",
            "## Edges to Validate",
            "",
        ]

        for edge in edge_data:
            lines.append(f"Edge ID: {edge['edge_id']}")
            lines.append(f"Relationship: {edge['relationship_type']}")
            lines.append(f"Source: {edge['source_content'][:150]}")
            lines.append(f"Target: {edge['target_content'][:150]}")
            lines.append(f"Current confidence: {edge['current_confidence']}")
            lines.append("")

        lines.extend(
            [
                "## Response Format",
                "",
                "Respond with ONLY a JSON object:",
                "{",
                '  "validations": [',
                "    {",
                '      "edge_id": "string",',
                '      "valid": true,',
                '      "new_confidence": 0.0,',
                '      "reasoning": "brief explanation"',
                "    }",
                "  ]",
                "}",
                "",
                "Set valid=true if the relationship makes sense, false if spurious.",
            ]
        )

        return "\n".join(lines)

    def _process_directive_batch(self, batch: list[MemoryReflection]) -> int:
        """Generate directives for a batch of reflections.

        Args:
            batch: Reflections needing directives.

        Returns:
            Number of directives generated.
        """
        prompt = self._build_directive_prompt(batch)
        system_prompt = (
            "You are generating behavioral directives. Respond with ONLY a "
            "single valid JSON object. Do not include any text before or after the JSON."
        )

        response = self._llm.prompt_json(prompt, system_prompt)

        directives = response.get("directives", [])
        count = 0

        for directive_data in directives:
            reflection_id = directive_data.get("reflection_id")
            directive = directive_data.get("directive", "")

            if reflection_id and directive:
                self._memory.update_reflection_directive(reflection_id, directive)
                count += 1

        return count

    def _build_directive_prompt(self, batch: list[MemoryReflection]) -> str:
        """Build LLM prompt for directive generation.

        Args:
            batch: Reflections needing directives.

        Returns:
            Complete prompt string.
        """
        lines = [
            "You are generating behavioral directives for memory reflections. "
            "A directive is an imperative instruction (e.g., 'Ask for examples', "
            "'Avoid jargon') that should guide future interactions.",
            "",
            "Only generate directives for reflections that clearly imply a behavioral "
            "change. Not all reflections need directives.",
            "",
            "## Reflections",
            "",
        ]

        for r in batch:
            lines.append(f"ID: {r.id}")
            lines.append(f"Type: {r.type} | Confidence: {r.confidence}")
            lines.append(f"Content: {r.content}")
            lines.append("")

        lines.extend(
            [
                "## Response Format",
                "",
                "Respond with ONLY a JSON object:",
                "{",
                '  "directives": [',
                "    {",
                '      "reflection_id": "string",',
                '      "directive": "imperative instruction under 100 characters"',
                "    }",
                "  ]",
                "}",
                "",
                "Only include reflections that warrant a directive. Omit others.",
            ]
        )

        return "\n".join(lines)
