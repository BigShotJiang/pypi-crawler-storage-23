"""Full reflection pipeline: LLM analysis, novelty filtering, relationship markers.

Orchestrates conversation analysis → novelty gating → embedding storage →
relationship marker parsing → working memory edge creation → user fact
extraction → session context saving → strategy observation logging.
"""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime
from typing import Any

import numpy as np

from limen_memory.constants import (
    MARKER_EDGE_CONFIDENCE,
    WORKING_MEMORY_EDGE_CONFIDENCE,
    WORKING_MEMORY_EVIDENCE_PREFIX,
    WORKING_MEMORY_SIMILARITY_THRESHOLD,
)
from limen_memory.models import (
    Conversation,
    ConversationSummary,
    GraphEdge,
    MemoryReflection,
    ReflectionPipelineResult,
    ScoredCandidate,
    SessionContext,
    UserFact,
)
from limen_memory.services.embedding._base import BaseEmbeddingClient
from limen_memory.services.llm_client import LLMClient, LLMParseError
from limen_memory.services.novelty_filter import NoveltyFilter
from limen_memory.services.strategy_service import StrategyService
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.embedding_store import EmbeddingStore
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore
from limen_memory.store.profile_store import ProfileStore
from limen_memory.store.strategy_store import StrategyStore

logger = logging.getLogger(__name__)

_MARKER_PATTERN: re.Pattern[str] = re.compile(
    r"(REINFORCES|CONTRADICTS|REFINES|PREDICTS|REQUIRES)\s*\[([^\]]+)\]"
)
_DIRECTIVE_PATTERN: re.Pattern[str] = re.compile(r"DIRECTIVE:\s*\[([^\]]+)\]")
_NEGATION_KEYWORDS: frozenset[str] = frozenset(
    {
        "not",
        "never",
        "no longer",
        "wrong",
        "incorrect",
        "opposite",
        "however",
        "contrary",
        "instead",
        "unlike",
        "disagree",
    }
)

# Mapping from reflection type string to (type, category, confidence) defaults
_INSIGHT_TYPE_MAP: dict[str, tuple[str, str, str]] = {
    "insight": ("insight", "Insights", "medium"),
    "context": ("domain_knowledge", "Context", "medium"),
    "follow_up": ("pattern", "Follow-ups", "low"),
}

REFLECTION_PROMPT = """\
You are performing active reflection on a conversation. Your goal is not passive recording—it is \
active observation. You should identify patterns in how the user works, what engages them, what \
communication approaches are effective, and where gaps in understanding exist.

Focus on genuine insights across these dimensions:
- **Working style**: How does the user approach problems? (systematic testing, evidence-following, \
iterative refinement)
- **Engagement patterns**: What types of responses generated follow-up questions vs. closure?
- **Communication effectiveness**: What delivery style created rapport? (structured data, \
acknowledgment of gaps, directness)
- **Domain expertise**: What does the user know deeply about? (revealed through questions, \
corrections, inferences)
- **Values**: What matters most? (truthfulness, efficiency, intellectual rigor, practical \
application)
- **Gaps and errors**: Where did the assistant misunderstand? What assumptions were wrong?

Not everything warrants recording—avoid noise. Focus on patterns, preferences, effective \
approaches, and mistakes to avoid. Include evidence for claims (e.g., "demonstrated through X \
behavior"). Distinguish between observations (what happened) and inferences (what it means).

**Relationship markers:** When a new insight relates to something you already know, declare it \
using:
- REINFORCES [brief description of the existing insight it supports]
- CONTRADICTS [brief description of the existing insight it conflicts with]
- REFINES [brief description of the existing insight it refines or narrows]
- PREDICTS [brief description of what this insight predicts about future behavior]
- REQUIRES [brief description of what must be true for this insight to hold]
Only use these markers when the relationship is clear and meaningful. The bracketed text should \
be a short description (5-15 words) of the existing insight, not a quote.

**Predictive observations:** When you observe a behavioral pattern that implies future behavior, \
generate a prediction using the PREDICTS marker. Good predictions are:
- Specific and falsifiable ("will ask for X when Y happens"), not vague ("might do something")
- Based on observed patterns with evidence, not speculation
- About interaction behavior, not domain knowledge
Aim for 0-2 predictions per reflection—only when the evidence genuinely supports a forward-looking \
inference.

**Behavioral directives:** For patterns that imply a specific behavioral change in future \
interactions, generate a behavioral directive using:
DIRECTIVE: [imperative instruction]
Only use this when a pattern is clear and actionable. Keep directives concise (under 100 \
characters) and in imperative voice. At most one DIRECTIVE per insight.

Provide a structured response in the following JSON format:

{
    "user_insights": {
        "name": "string or null if not mentioned",
        "preferences": ["list of preferences mentioned or implied"],
        "interests": ["topics they showed interest in"],
        "expertise": ["areas they demonstrated knowledge in"],
        "work_context": ["information about their work, projects, or goals"],
        "communication_style": ["observations about how they prefer to communicate"]
    },
    "session_reflections": {
        "key_topics": ["main topics discussed"],
        "important_context": ["context that would be useful to remember"],
        "unresolved_items": ["things left unfinished or to follow up on"],
        "insights": ["genuine pattern observations worth remembering"]
    },
    "strategy_observations": [
        {
            "observation": "What worked or didn't work in this interaction",
            "type": "communication or task or anti_pattern",
            "confidence": 0.6
        }
    ],
    "session_context": {
        "primary_topic": "main thing discussed in this session",
        "active_threads": ["ongoing threads of work or discussion"],
        "pending_decisions": ["decisions that still need to be made"],
        "blockers": ["issues blocking progress"],
        "completed_items": ["what was accomplished this session"],
        "context_notes": "any additional context the next session should know",
        "next_session_prep": "what the next conversation should pick up on"
    },
    "should_update": true
}

Only set "should_update" to true if there is genuinely new and useful information to retain.
Be selective—only include information that would improve future interactions.

Respond ONLY with valid JSON, no other text.
"""


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


class ReflectionService:
    """Orchestrates the full reflection pipeline.

    Args:
        llm_client: Claude CLI client for reflection generation.
        embedding_client: Embedding client for vector operations.
        novelty_filter: Two-stage novelty filter.
        memory_store: Reflection and fact storage.
        graph_store: Knowledge graph operations.
        embedding_store: Embedding storage.
        conversation_store: Conversation and audit logging.
        strategy_store: Strategy operations.
        profile_store: Interaction profile storage (optional for backwards compat).
        strategy_service: Strategy service for promoting observations to strategies.
    """

    def __init__(
        self,
        llm_client: LLMClient,
        embedding_client: BaseEmbeddingClient,
        novelty_filter: NoveltyFilter,
        memory_store: MemoryStore,
        graph_store: GraphStore,
        embedding_store: EmbeddingStore,
        conversation_store: ConversationStore,
        strategy_store: StrategyStore,
        profile_store: ProfileStore | None = None,
        strategy_service: StrategyService | None = None,
    ) -> None:
        self._llm = llm_client
        self._embeddings = embedding_client
        self._novelty = novelty_filter
        self._memory = memory_store
        self._graph = graph_store
        self._embedding_store = embedding_store
        self._conversations = conversation_store
        self._strategies = strategy_store
        self._profile_store = profile_store
        self._strategy_service = strategy_service

    def reflect_on_session(
        self,
        session_text: str,
        session_id: str,
        conversation_id: str,
    ) -> ReflectionPipelineResult:
        """Run the full reflection pipeline on a session transcript.

        Args:
            session_text: The session transcript text.
            session_id: The session identifier.
            conversation_id: The conversation identifier.

        Returns:
            Summary of what was created/rejected.
        """
        result = ReflectionPipelineResult()

        # Build prompt with context
        existing_text = self._get_existing_reflections_text()
        deprecated_text = self._get_recently_deprecated_text()
        profile_text = self._get_interaction_profile_text()
        prompt = self._build_reflection_prompt(
            session_text, existing_text, profile_text, deprecated_text
        )

        # Call LLM
        try:
            response = self._llm.prompt_json_validated(
                prompt, required_keys=["session_reflections", "should_update"]
            )
        except (LLMParseError, Exception) as exc:
            logger.error("Reflection LLM call failed: %s", exc)
            return result

        # Check should_update
        should_update = response.get("should_update", False)

        # Always save session context
        session_ctx_data = response.get("session_context")
        if session_ctx_data and session_id:
            self._save_session_context(session_ctx_data, session_id)
            result.session_context_saved = True

        # Always save conversation + summary (hoist reflections_data for reuse below)
        reflections_data = response.get("session_reflections", {})
        if session_ctx_data:
            self._save_conversation_summary(session_ctx_data, reflections_data, conversation_id)
            result.conversation_summary_saved = True

        if not should_update:
            logger.info("LLM indicated no update needed")
            return result

        # Build candidates from session_reflections
        candidates = self._build_candidates(reflections_data)

        # Run novelty filter
        if candidates:
            novelty_results = self._novelty.filter_candidates(candidates, conversation_id)

            # Process accepted candidates
            for (novelty_result, embedding), candidate in zip(novelty_results, candidates):
                if novelty_result.accepted:
                    edges = self._process_accepted_reflection(
                        candidate,
                        embedding,
                        novelty_result,
                        conversation_id,
                        reflections_data,
                    )
                    result.reflections_accepted += 1
                    result.edges_created += edges
                else:
                    result.reflections_rejected += 1

        # Save user facts
        user_data = response.get("user_insights", {})
        result.user_facts_saved = self._save_user_facts(user_data, conversation_id)

        # Log strategy observations
        strategy_obs = response.get("strategy_observations", [])
        result.strategy_observations_logged = self._log_strategy_observations(
            strategy_obs, conversation_id
        )

        # Promote observations to strategies when service is available
        if self._strategy_service is not None and strategy_obs:
            result.strategies_promoted = self._strategy_service.process_observations(strategy_obs)

        logger.info(
            "Reflection complete: %d accepted, %d rejected, %d facts, %d edges",
            result.reflections_accepted,
            result.reflections_rejected,
            result.user_facts_saved,
            result.edges_created,
        )
        return result

    def apply_single_reflection(
        self,
        content: str,
        reflection_type: str,
        session_id: str,
        confidence: str = "medium",
    ) -> str | None:
        """Add a single reflection with novelty filtering and embedding storage.

        For the ``limen add-reflection`` CLI command. Skips LLM generation.

        Args:
            content: Reflection content text.
            reflection_type: Reflection type (insight, pattern, etc.).
            session_id: Source session identifier.
            confidence: Confidence level.

        Returns:
            Reflection ID if accepted, None if rejected by novelty filter.
        """
        candidate = ScoredCandidate(
            content=content,
            type=reflection_type,
            category=reflection_type.capitalize(),
            confidence=confidence,
        )

        novelty_results = self._novelty.filter_candidates([candidate], session_id)
        if not novelty_results:
            return None

        novelty_result, embedding = novelty_results[0]
        if not novelty_result.accepted:
            logger.info(
                "Reflection rejected by novelty filter: %s",
                novelty_result.reasoning,
            )
            return None

        # Save reflection
        now = _now_iso()
        directive = _parse_directive(content)
        reflection = MemoryReflection(
            id=_uid(),
            timestamp=now,
            type=reflection_type,
            content=content,
            category=reflection_type.capitalize(),
            confidence=confidence,
            source_session=session_id,
            novelty_score=novelty_result.score,
            behavioral_directive=directive,
        )
        self._memory.save_reflection(reflection)

        # Store embedding
        self._embedding_store.save_embedding(reflection.id, embedding)

        # Surface working memory
        self._surface_working_memory(reflection.id, content, embedding)

        return reflection.id

    # --- Private pipeline methods ---

    def _build_reflection_prompt(
        self,
        session_text: str,
        existing_reflections: str,
        profile_text: str,
        deprecated_reflections: str = "",
    ) -> str:
        """Build the full reflection prompt with context.

        Args:
            session_text: The session transcript.
            existing_reflections: Formatted existing reflections for context.
            profile_text: Formatted interaction profile.
            deprecated_reflections: Formatted recently deprecated reflections.

        Returns:
            Complete prompt string.
        """
        # Truncate session text to avoid exceeding context window
        truncated_session = session_text[:50000]
        if len(session_text) > 50000:
            truncated_session += f"\n[...truncated — {len(session_text) - 50000} more characters]"

        parts = [truncated_session, "\n\n", REFLECTION_PROMPT]

        if existing_reflections:
            truncated = existing_reflections[:2000]
            parts.append(
                "\n\nHere are your current observations for reference when noting relationships:\n"
            )
            parts.append(truncated)
            if len(existing_reflections) > 2000:
                parts.append(
                    f"\n[...truncated — {len(existing_reflections) - 2000} more characters]"
                )

        if profile_text:
            parts.append(
                "\n\nThe following is the user's current interaction profile — "
                "continuous trait scores derived from accumulated observations. "
                "Use these dimensions to inform predictions (PREDICTS markers). "
                "Only reference dimensions with sufficient confidence (>= 50%).\n\n"
            )
            parts.append(profile_text)

        if deprecated_reflections:
            truncated_deprecated = deprecated_reflections[:1000]
            parts.append(
                "\n\nThe following observations were recently deprecated or retracted. "
                "Do NOT reference these in session_context, next_session_prep, "
                "or active_threads:\n"
            )
            parts.append(truncated_deprecated)

        return "".join(parts)

    def _get_existing_reflections_text(self) -> str:
        """Load existing reflections formatted as text for context injection.

        Returns:
            Formatted text of active reflections, or empty string.
        """
        reflections = self._memory.query_reflections(limit=50)
        if not reflections:
            return ""
        lines = [f"- [{r.type}] {r.content}" for r in reflections]
        return "\n".join(lines)

    def _get_interaction_profile_text(self) -> str:
        """Load interaction profile formatted as text.

        Returns:
            Formatted profile text, or empty string.
        """
        if self._profile_store is None:
            return ""
        return self._profile_store.get_interaction_profile_formatted()

    def _get_recently_deprecated_text(self) -> str:
        """Load recently deprecated reflections formatted as text.

        Returns:
            Formatted text of deprecated reflections, or empty string.
        """
        deprecated = self._memory.query_recently_deprecated(limit=5)
        if not deprecated:
            return ""
        lines = [f"- [DEPRECATED/{r.type}] {r.content}" for r in deprecated]
        return "\n".join(lines)

    def _build_candidates(self, reflections_data: dict[str, Any]) -> list[ScoredCandidate]:
        """Build ScoredCandidate list from LLM reflection response.

        Args:
            reflections_data: The session_reflections dict from LLM response.

        Returns:
            List of candidates with appropriate types.
        """
        candidates: list[ScoredCandidate] = []
        key_topics = reflections_data.get("key_topics", [])

        for insight in reflections_data.get("insights", []):
            candidates.append(
                ScoredCandidate(
                    content=insight,
                    type="insight",
                    category="Insights",
                    tags=key_topics,
                )
            )

        for context in reflections_data.get("important_context", []):
            candidates.append(
                ScoredCandidate(
                    content=context,
                    type="domain_knowledge",
                    category="Context",
                    tags=key_topics,
                )
            )

        for item in reflections_data.get("unresolved_items", []):
            candidates.append(
                ScoredCandidate(
                    content=f"Follow up: {item}",
                    type="pattern",
                    category="Follow-ups",
                    confidence="low",
                    tags=key_topics,
                )
            )

        return candidates

    def _process_accepted_reflection(
        self,
        candidate: ScoredCandidate,
        embedding: np.ndarray,
        novelty_result: Any,
        conversation_id: str,
        reflections_data: dict[str, Any],
    ) -> int:
        """Save an accepted reflection and create all related edges.

        Args:
            candidate: The accepted candidate.
            embedding: Pre-computed embedding.
            novelty_result: The novelty evaluation result.
            conversation_id: Conversation id.
            reflections_data: Full reflections data for key_topics.

        Returns:
            Number of edges created.
        """
        edges_created = 0
        now = _now_iso()

        # Parse directive
        directive = _parse_directive(candidate.content)

        # Build and save reflection
        reflection = MemoryReflection(
            id=_uid(),
            timestamp=now,
            type=candidate.type,
            content=candidate.content,
            category=candidate.category,
            confidence=candidate.confidence,
            tags=candidate.tags,
            source_session=conversation_id,
            novelty_score=novelty_result.score,
            behavioral_directive=directive,
        )
        self._memory.save_reflection(reflection)

        # Store embedding (invalidates the store's internal cache)
        self._embedding_store.save_embedding(reflection.id, embedding)

        # Create contradiction edges from novelty filter
        if novelty_result.contradicts:
            edges_created += self._create_contradiction_edges(
                reflection.id, novelty_result.contradicts
            )

        # Parse and create relationship marker edges
        edges_created += self._process_relationship_markers(reflection.id, candidate.content)

        # Surface working memory candidates
        edges_created += self._surface_working_memory(reflection.id, candidate.content, embedding)

        return edges_created

    def _process_relationship_markers(self, reflection_id: str, content: str) -> int:
        """Parse relationship markers and create graph edges.

        Args:
            reflection_id: The source reflection id.
            content: Reflection content containing markers.

        Returns:
            Number of edges created.
        """
        markers = _MARKER_PATTERN.findall(content)
        edges_created = 0

        for marker_type, description in markers:
            marker_type_lower = marker_type.lower()
            description = description.strip()

            # Find matching reflection
            matches = self._memory.query_reflections(topic=description, limit=3)
            best_match = None
            for m in matches:
                if m.id != reflection_id:
                    best_match = m
                    break

            if not best_match:
                logger.debug("No match for %s marker: %s", marker_type_lower, description)
                continue

            # Determine edge category
            edge_category = (
                "causal" if marker_type_lower in ("predicts", "requires") else "evaluative"
            )

            edge = GraphEdge(
                id=_uid(),
                source_id=reflection_id,
                target_id=best_match.id,
                source_type="reflection",
                target_type="reflection",
                relationship_type=marker_type_lower,
                edge_category=edge_category,
                confidence=MARKER_EDGE_CONFIDENCE,
                evidence=(f"Declared in reflection: {marker_type} [{description}]"),
            )
            self._graph.save_relationship(edge)
            edges_created += 1

        return edges_created

    def _create_contradiction_edges(self, reflection_id: str, contradicted_texts: list[str]) -> int:
        """Create contradiction edges from novelty filter flags.

        Args:
            reflection_id: The new reflection id.
            contradicted_texts: Texts identified as contradicted.

        Returns:
            Number of edges created.
        """
        edges_created = 0
        for text in contradicted_texts:
            matches = self._memory.query_reflections(topic=text, limit=3)
            best_match = None
            for m in matches:
                if m.id != reflection_id:
                    best_match = m
                    break
            if not best_match:
                continue

            edge = GraphEdge(
                id=_uid(),
                source_id=reflection_id,
                target_id=best_match.id,
                source_type="reflection",
                target_type="reflection",
                relationship_type="contradicts",
                edge_category="evaluative",
                confidence=MARKER_EDGE_CONFIDENCE,
                evidence="Flagged by NoveltyFilter during reflection write",
            )
            self._graph.save_relationship(edge)
            edges_created += 1

        return edges_created

    def _surface_working_memory(
        self,
        reflection_id: str,
        content: str,
        embedding: np.ndarray,
    ) -> int:
        """Find similar reflections and create working memory edges.

        Args:
            reflection_id: The new reflection id.
            content: Reflection content for negation keyword detection.
            embedding: Pre-computed embedding vector.

        Returns:
            Number of edges created.
        """
        matches = self._embedding_store.find_similar(
            embedding,
            limit=5,
            min_similarity=WORKING_MEMORY_SIMILARITY_THRESHOLD,
            exclude_ids={reflection_id},
        )

        edges_created = 0
        for match in matches[:3]:
            relationship = _classify_working_memory_relationship(match.similarity, content)
            evidence = f"{WORKING_MEMORY_EVIDENCE_PREFIX}: {match.similarity:.3f}"

            edge = GraphEdge(
                id=_uid(),
                source_id=reflection_id,
                target_id=match.reflection_id,
                source_type="reflection",
                target_type="reflection",
                relationship_type=relationship,
                edge_category="evaluative",
                confidence=WORKING_MEMORY_EDGE_CONFIDENCE,
                evidence=evidence,
            )
            self._graph.save_relationship(edge)
            edges_created += 1

        return edges_created

    def _save_user_facts(self, user_data: dict[str, Any], conversation_id: str) -> int:
        """Save user facts from reflection response.

        Args:
            user_data: The user_insights dict from LLM response.
            conversation_id: Source conversation id.

        Returns:
            Number of facts saved.
        """
        saved = 0
        now = _now_iso()

        fact_sources: list[tuple[str, list[str]]] = [
            ("preferences", user_data.get("preferences", [])),
            ("interests", user_data.get("interests", [])),
            ("expertise", user_data.get("expertise", [])),
            ("work_context", user_data.get("work_context", [])),
            ("communication_style", user_data.get("communication_style", [])),
        ]

        for category, items in fact_sources:
            for item in items:
                if not item or not isinstance(item, str):
                    continue
                fact = UserFact(
                    id=_uid(),
                    category=category,
                    key=item[:100],
                    value=item,
                    confidence="medium",
                    first_observed=now,
                    last_verified=now,
                )
                self._memory.save_user_fact(fact)
                saved += 1

        return saved

    def _save_session_context(self, ctx_data: dict[str, Any], session_id: str) -> None:
        """Save session context from reflection response.

        Args:
            ctx_data: The session_context dict from LLM response.
            session_id: The session identifier.
        """
        now = _now_iso()
        ctx = SessionContext(
            id=_uid(),
            session_id=session_id,
            started_at=now,
            ended_at=now,
            primary_topic=str(ctx_data.get("primary_topic", "")),
            active_threads=ctx_data.get("active_threads", []),
            pending_decisions=ctx_data.get("pending_decisions", []),
            blockers=ctx_data.get("blockers", []),
            completed_items=ctx_data.get("completed_items", []),
            context_notes=str(ctx_data.get("context_notes", "")),
            next_session_prep=str(ctx_data.get("next_session_prep", "")),
        )
        self._memory.save_session_context(ctx)

    def _save_conversation_summary(
        self,
        ctx_data: dict[str, Any],
        reflections_data: dict[str, Any],
        conversation_id: str,
    ) -> None:
        """Save a Conversation and ConversationSummary from reflection response.

        Args:
            ctx_data: The session_context dict from LLM response.
            reflections_data: The session_reflections dict from LLM response.
            conversation_id: The conversation identifier.
        """
        now = _now_iso()
        primary_topic = str(ctx_data.get("primary_topic", ""))
        key_topics: list[str] = reflections_data.get("key_topics", [])

        # Build Conversation parent record
        conv = Conversation(
            id=conversation_id,
            title=primary_topic[:200] if primary_topic else conversation_id,
            created_at=now,
            updated_at=now,
            status="active",
            summary=primary_topic,
            keywords=key_topics,
        )
        self._conversations.save_conversation(conv)

        # Assemble summary text from session_context fields
        summary_parts: list[str] = []
        if primary_topic:
            summary_parts.append(primary_topic)
        for thread in ctx_data.get("active_threads", []):
            summary_parts.append(f"Active: {thread}")
        for item in ctx_data.get("completed_items", []):
            summary_parts.append(f"Done: {item}")
        context_notes = str(ctx_data.get("context_notes", ""))
        if context_notes:
            summary_parts.append(context_notes)

        # Build status_markers with prefixes that _build_pending_tier() checks for
        status_parts: list[str] = []
        for blocker in ctx_data.get("blockers", []):
            status_parts.append(f"blocked: {blocker}")
        for decision in ctx_data.get("pending_decisions", []):
            status_parts.append(f"pending: {decision}")

        # Build pending_items from unresolved_items
        unresolved: list[str] = reflections_data.get("unresolved_items", [])

        summary = ConversationSummary(
            id=_uid(),
            conversation_id=conversation_id,
            summary="; ".join(summary_parts) if summary_parts else conversation_id,
            keywords=", ".join(key_topics),
            key_topics=", ".join(key_topics),
            status_markers="; ".join(status_parts),
            pending_items="; ".join(unresolved),
            created_at=now,
        )
        self._conversations.save_summary(summary)

    def _log_strategy_observations(
        self, observations: list[dict[str, Any]], conversation_id: str
    ) -> int:
        """Log strategy observations from reflection response.

        Args:
            observations: List of observation dicts from LLM response.
            conversation_id: The conversation id.

        Returns:
            Number of observations logged.
        """
        logged = 0
        now = _now_iso()
        for obs in observations:
            observation = obs.get("observation", "")
            obs_type = obs.get("type", "communication")
            confidence = float(obs.get("confidence", 0.5))
            if not observation:
                continue

            self._conversations.save_strategy_observation(
                obs_id=_uid(),
                timestamp=now,
                conversation_id=conversation_id,
                observation=observation,
                obs_type=obs_type,
                source="reflection",
                confidence=confidence,
                raw_evidence="",
            )
            logged += 1

        return logged


# --- Module-level helpers ---


def _parse_directive(content: str) -> str:
    """Extract DIRECTIVE marker text from reflection content.

    Args:
        content: Reflection content possibly containing a DIRECTIVE marker.

    Returns:
        Directive instruction text, or empty string if none found.
    """
    match = _DIRECTIVE_PATTERN.search(content)
    if match:
        return match.group(1).strip()
    return ""


def _classify_working_memory_relationship(similarity: float, content: str) -> str:
    """Classify a working memory relationship type.

    Args:
        similarity: Cosine similarity score.
        content: Source reflection content for negation detection.

    Returns:
        Relationship type: 'reinforces', 'contradicts', or 'refines'.
    """
    if similarity > 0.85:
        return "reinforces"

    content_lower = content.lower()
    for keyword in _NEGATION_KEYWORDS:
        if keyword in content_lower:
            return "contradicts"

    return "refines"
