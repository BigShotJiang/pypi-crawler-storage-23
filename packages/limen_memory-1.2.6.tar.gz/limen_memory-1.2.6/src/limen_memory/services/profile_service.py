"""Interaction profile synthesis service.

Synthesizes user interaction profile dimensions from evidence
(facts, high-confidence reflections, prediction edge outcomes).
Each dimension is scored on a -1.0 to +1.0 scale with computed
confidence.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any

from limen_memory.constants import (
    PROFILE_DIMENSION_CONFIDENCE_FLOOR,
    PROFILE_DIMENSIONS,
    PROFILE_EVIDENCE_CONFIDENCE_FACTOR,
)
from limen_memory.models import InteractionDimension
from limen_memory.services.llm_client import LLMClient
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore
from limen_memory.store.profile_store import ProfileStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


_SYSTEM_PROMPT = (
    "You are an interaction profile synthesis engine. You analyze evidence "
    "about a user's working style and preferences to score personality "
    "dimensions on a -1.0 to +1.0 scale.\n\n"
    "You MUST respond with ONLY a single valid JSON object. No explanation, "
    "no markdown fences, just the JSON.\n\n"
    "Dimensions to score:\n"
    "- processing_style: -1.0 = sequential/methodical, +1.0 = intuitive/exploratory\n"
    "- detail_preference: -1.0 = high-level/big picture, +1.0 = detailed/thorough\n"
    "- challenge_tolerance: -1.0 = prefers safe/proven approaches, "
    "+1.0 = welcomes ambitious challenges\n"
    "- structure_preference: -1.0 = flexible/adaptive, +1.0 = structured/organized\n"
    "- autonomy_preference: -1.0 = prefers guided/collaborative, "
    "+1.0 = prefers autonomous/independent\n\n"
    "For each dimension, provide:\n"
    "- score: float between -1.0 and 1.0\n"
    "- confidence: float between 0.0 and 1.0 (how confident you are in this score)\n"
    "- reasoning: brief explanation of why you scored this way\n\n"
    "If insufficient evidence for a dimension, use score 0.0 and low confidence."
)


class ProfileService:
    """Synthesizes interaction profile dimensions from evidence.

    Args:
        memory_store: Reflection and fact storage.
        graph_store: Knowledge graph for prediction edges.
        profile_store: Interaction profile storage.
        llm_client: Claude CLI client.
    """

    def __init__(
        self,
        memory_store: MemoryStore,
        graph_store: GraphStore,
        profile_store: ProfileStore,
        llm_client: LLMClient,
    ) -> None:
        self._memory = memory_store
        self._graph = graph_store
        self._profile = profile_store
        self._llm = llm_client

    def synthesize_profile(self) -> dict[str, Any]:
        """Synthesize the interaction profile from all available evidence.

        Gathers user facts, high-confidence reflections, and prediction
        edge outcomes, then uses the LLM to score each dimension.

        Returns:
            Dict with dimensions_updated count and dimension details.
        """
        # Gather evidence
        facts = self._memory.query_user_facts()
        reflections = [
            r
            for r in self._memory.get_active_reflections(limit=200)
            if r.confidence in ("high", "medium")
        ]
        prediction_edges = self._graph.get_prediction_edges(limit=50, min_confidence=0.3)

        evidence_ids: list[str] = []
        evidence_ids.extend(f.id for f in facts)
        evidence_ids.extend(r.id for r in reflections)

        evidence_count = len(facts) + len(reflections) + len(prediction_edges)

        # Build prompt
        prompt = self._build_prompt(facts, reflections, prediction_edges)

        # Call LLM
        try:
            result = self._llm.prompt_json(prompt, system_prompt=_SYSTEM_PROMPT)
        except Exception:
            logger.exception("Profile synthesis LLM call failed")
            return {
                "dimensions_updated": 0,
                "evidence_count": evidence_count,
                "error": "LLM call failed",
            }

        # Apply results
        return self._apply_results(result, evidence_count, evidence_ids)

    def _build_prompt(
        self,
        facts: list[Any],
        reflections: list[Any],
        prediction_edges: list[Any],
    ) -> str:
        """Build the synthesis prompt with evidence.

        Args:
            facts: User facts.
            reflections: High-confidence reflections.
            prediction_edges: Prediction edges with outcomes.

        Returns:
            Formatted prompt string.
        """
        parts: list[str] = []

        # User facts
        if facts:
            parts.append(f"## User Facts ({len(facts)})\n")
            for f in facts:
                parts.append(f"- [{f.category}] {f.key}: {f.value} ({f.confidence})")
            parts.append("")

        # Reflections
        if reflections:
            parts.append(f"\n## High-Confidence Reflections ({len(reflections)})\n")
            for r in reflections[:50]:
                parts.append(f"- [{r.type}/{r.confidence}] {r.content[:150]}")
            if len(reflections) > 50:
                parts.append(f"  ... and {len(reflections) - 50} more")
            parts.append("")

        # Prediction outcomes
        tested_predictions = [e for e in prediction_edges if e.prediction_count > 0]
        if tested_predictions:
            parts.append(f"\n## Prediction Outcomes ({len(tested_predictions)})\n")
            for e in tested_predictions[:20]:
                hit_pct = e.hit_rate * 100
                parts.append(
                    f"- {e.evidence[:100]} "
                    f"(tested: {e.prediction_count}x, hit rate: {hit_pct:.0f}%)"
                )
            parts.append("")

        parts.append(
            "\nBased on the evidence above, score each interaction profile dimension. "
            "Return JSON:\n"
            "{\n"
            '  "dimensions": [\n'
            "    {\n"
            '      "dimension": "processing_style",\n'
            '      "score": 0.0,\n'
            '      "confidence": 0.0,\n'
            '      "reasoning": ""\n'
            "    },\n"
            "    ... (all 5 dimensions)\n"
            "  ]\n"
            "}"
        )

        return "\n".join(parts)

    def _apply_results(
        self,
        result: dict[str, Any],
        evidence_count: int,
        evidence_ids: list[str],
    ) -> dict[str, Any]:
        """Apply LLM synthesis results to the profile store.

        Confidence = min(1.0, evidence_count * FACTOR) * llm_confidence,
        but not below the floor.

        Args:
            result: Parsed LLM JSON response.
            evidence_count: Total evidence items used.
            evidence_ids: IDs of evidence items.

        Returns:
            Summary dict with dimension details.
        """
        now = _now_iso()
        dimensions_updated = 0
        dimension_details: list[dict[str, Any]] = []

        # Evidence-based confidence scaling
        evidence_factor = min(1.0, evidence_count * PROFILE_EVIDENCE_CONFIDENCE_FACTOR)

        for dim_data in result.get("dimensions", []):
            dim_name = dim_data.get("dimension", "")
            if dim_name not in PROFILE_DIMENSIONS:
                logger.warning("Unknown profile dimension: %s", dim_name)
                continue

            score = max(-1.0, min(1.0, float(dim_data.get("score", 0.0))))
            llm_confidence = max(0.0, min(1.0, float(dim_data.get("confidence", 0.0))))

            # Final confidence: evidence scaling * LLM confidence, with floor
            final_confidence = max(
                PROFILE_DIMENSION_CONFIDENCE_FLOOR,
                evidence_factor * llm_confidence,
            )

            dim = InteractionDimension(
                id=_uid(),
                dimension=dim_name,
                score=score,
                confidence=final_confidence,
                evidence_count=evidence_count,
                evidence_ids=evidence_ids[:50],  # Cap stored evidence IDs
                last_synthesized=now,
                created_at=now,
            )

            try:
                self._profile.save_interaction_dimension(dim)
                dimensions_updated += 1
                dimension_details.append(
                    {
                        "dimension": dim_name,
                        "score": score,
                        "confidence": round(final_confidence, 3),
                        "reasoning": dim_data.get("reasoning", ""),
                    }
                )
            except Exception:
                logger.warning("Failed to save dimension %s", dim_name, exc_info=True)

        logger.info(
            "Profile synthesis complete: %d dimensions updated from %d evidence items",
            dimensions_updated,
            evidence_count,
        )

        return {
            "dimensions_updated": dimensions_updated,
            "evidence_count": evidence_count,
            "dimensions": dimension_details,
        }
