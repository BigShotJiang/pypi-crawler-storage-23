"""Two-stage novelty filtering: embedding pre-filter + LLM scoring.

Prevents redundant or obvious observations from accumulating in memory.
Matches Wren's NoveltyFilter.swift thresholds and behavior.
"""

from __future__ import annotations

import logging
import math
import uuid
from datetime import datetime
from typing import Any

import numpy as np

from limen_memory.constants import (
    EMBEDDING_ACCEPT_SIMILARITY,
    EMBEDDING_REJECT_SIMILARITY,
    LLM_NOVELTY_ACCEPTANCE,
    NOVELTY_TEMPORAL_HALF_LIFE,
)
from limen_memory.models import NoveltyResult, ScoredCandidate
from limen_memory.services.embedding._base import BaseEmbeddingClient
from limen_memory.services.llm_client import LLMClient, LLMParseError
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.embedding_store import EmbeddingStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class NoveltyFilter:
    """Two-stage novelty filter using embeddings and LLM scoring.

    Stage 1: Embedding cosine similarity pre-filter (fast, deterministic).
    Stage 2: LLM scoring for borderline cases (slower, nuanced).

    Args:
        embedding_client: Client for computing embeddings.
        embedding_store: Store for similarity search.
        llm_client: Client for LLM scoring of borderlines.
        conversation_store: Store for logging novelty evaluations.
    """

    def __init__(
        self,
        embedding_client: BaseEmbeddingClient,
        embedding_store: EmbeddingStore,
        llm_client: LLMClient,
        conversation_store: ConversationStore,
    ) -> None:
        self._embedding_client = embedding_client
        self._embedding_store = embedding_store
        self._llm_client = llm_client
        self._conversation_store = conversation_store

    def filter_candidates(
        self,
        candidates: list[ScoredCandidate],
        conversation_id: str,
    ) -> list[tuple[NoveltyResult, np.ndarray]]:
        """Run two-stage novelty filter on a batch of candidates.

        Returns results paired with their embeddings so the caller can
        store embeddings without recomputation.

        Args:
            candidates: Candidate reflections to evaluate.
            conversation_id: Conversation id for logging.

        Returns:
            List of (NoveltyResult, embedding) tuples, same order as input.
        """
        if not candidates:
            return []

        # Batch embed all candidates in one API call
        texts = [c.content for c in candidates]
        try:
            all_embeddings = self._embedding_client.embed_texts(texts)
        except Exception as exc:
            logger.warning("Batch embedding failed: %s", exc)
            zero = np.zeros(self._embedding_client._dimensions, dtype=np.float32)
            return [
                (
                    NoveltyResult(
                        content=c.content,
                        score=0.0,
                        accepted=False,
                        method="embedding_error",
                        reasoning=f"Batch embedding failed: {exc}",
                    ),
                    zero,
                )
                for c in candidates
            ]

        # Stage 1: Embedding pre-filter
        results: list[tuple[NoveltyResult, np.ndarray]] = []
        borderlines: list[tuple[int, ScoredCandidate, np.ndarray]] = []

        for idx, (candidate, embedding) in enumerate(zip(candidates, all_embeddings)):
            try:
                decision, similarity = self._embedding_prefilter(candidate, embedding)
            except Exception as exc:
                logger.warning("Embedding prefilter failed for candidate %d: %s", idx, exc)
                # Fall through to Stage 2 (LLM-only)
                results.append(
                    (
                        NoveltyResult(
                            content=candidate.content,
                            score=0.0,
                            accepted=False,
                            method="llm",
                            reasoning="",
                        ),
                        embedding,
                    )
                )
                borderlines.append((idx, candidate, embedding))
                continue

            if decision == "reject":
                result = NoveltyResult(
                    content=candidate.content,
                    score=1.0 - similarity,
                    accepted=False,
                    method="embedding_reject",
                    reasoning=(f"Too similar to existing entry (similarity: {similarity:.2f})"),
                )
                results.append((result, embedding))
            elif decision == "accept":
                result = NoveltyResult(
                    content=candidate.content,
                    score=1.0 - similarity,
                    accepted=True,
                    method="embedding_accept",
                    reasoning=(f"Clearly novel (similarity: {similarity:.2f})"),
                )
                results.append((result, embedding))
            else:
                # Borderline — defer to Stage 2
                results.append(
                    (
                        NoveltyResult(
                            content=candidate.content,
                            score=0.0,
                            accepted=False,
                            method="llm",
                            reasoning="",
                        ),
                        embedding,
                    )
                )
                borderlines.append((idx, candidate, embedding))

        # Stage 2: LLM scoring for borderlines
        if borderlines:
            llm_results = self._llm_score_borderlines(borderlines)
            for idx, llm_result in llm_results:
                embedding = results[idx][1]
                results[idx] = (llm_result, embedding)

        # Log all results
        for result, _ in results:
            self._log_result(result, conversation_id)

        return results

    def _embedding_prefilter(
        self,
        candidate: ScoredCandidate,
        embedding: np.ndarray,
    ) -> tuple[str, float]:
        """Run embedding pre-filter on a single candidate.

        Applies continuous temporal decay: the effective similarity is
        reduced by exp(-age / NOVELTY_TEMPORAL_HALF_LIFE), so older
        entries progressively fade as blockers to new observations.

        Args:
            candidate: The candidate to evaluate.
            embedding: Pre-computed embedding vector for the candidate.

        Returns:
            Tuple of (decision, max_similarity) where decision
            is 'accept', 'reject', or 'borderline'.
        """
        similarity, most_similar_age = self._embedding_store.get_best_match(embedding)

        # Continuous temporal discount: older similar entries fade as blockers
        if most_similar_age is not None and most_similar_age > 0:
            similarity *= math.exp(-most_similar_age / NOVELTY_TEMPORAL_HALF_LIFE)

        if similarity > EMBEDDING_REJECT_SIMILARITY:
            return ("reject", similarity)
        elif similarity < EMBEDDING_ACCEPT_SIMILARITY:
            return ("accept", similarity)
        else:
            return ("borderline", similarity)

    def _llm_score_borderlines(
        self,
        borderlines: list[tuple[int, ScoredCandidate, np.ndarray]],
    ) -> list[tuple[int, NoveltyResult]]:
        """Score borderline candidates using the LLM.

        Args:
            borderlines: List of (original_index, candidate, embedding) tuples.

        Returns:
            List of (original_index, NoveltyResult) tuples.
        """
        candidates_for_prompt = [candidate for _, candidate, _ in borderlines]
        prompt = self._build_llm_novelty_prompt(candidates_for_prompt)

        try:
            response = self._llm_client.prompt_json(
                prompt,
                system_prompt=(
                    "You are a JSON-only novelty scoring engine. "
                    "Output raw JSON with no other text."
                ),
            )
            return self._parse_llm_response(response, borderlines)
        except (LLMParseError, Exception) as exc:
            logger.warning("LLM novelty scoring failed: %s", exc, exc_info=True)
            error_detail = f"{type(exc).__name__}: {str(exc)[:200]}"
            return [
                (
                    idx,
                    NoveltyResult(
                        content=candidate.content,
                        score=0.5,
                        accepted=False,
                        method="llm_fallback",
                        reasoning=f"LLM scoring failed — {error_detail}",
                    ),
                )
                for idx, candidate, _ in borderlines
            ]

    def _build_llm_novelty_prompt(
        self,
        candidates: list[ScoredCandidate],
    ) -> str:
        """Build the LLM novelty scoring prompt.

        Args:
            candidates: Candidates to score.

        Returns:
            Prompt string requesting JSON response.
        """
        existing_count = self._embedding_store.count_embeddings()

        candidate_text = "\n".join(f"{i + 1}. {c.content}" for i, c in enumerate(candidates))

        return (
            "You are evaluating candidate memory entries for novelty. "
            "Score each candidate based on how much NEW information it adds "
            "compared to what is already known.\n\n"
            f"There are {existing_count} existing memory entries.\n\n"
            "## Candidates to Score\n"
            f"{candidate_text}\n\n"
            "For each candidate, score novelty from 0.0 to 1.0:\n"
            "- 0.0 = already known, redundant, or obvious from existing memory\n"
            "- 0.5 = partially new, adds nuance to something already known\n"
            "- 1.0 = completely new information not predictable from existing memory\n\n"
            "Also flag any candidates that CONTRADICT existing memory "
            "(contradictions are high-value updates).\n\n"
            "Respond ONLY with valid JSON:\n"
            "{\n"
            '    "scored_candidates": [\n'
            "        {\n"
            '            "index": 1,\n'
            '            "novelty_score": 0.7,\n'
            '            "reasoning": "Brief explanation",\n'
            '            "contradicts": null\n'
            "        }\n"
            "    ]\n"
            "}"
        )

    def _parse_llm_response(
        self,
        response: dict[str, Any],
        borderlines: list[tuple[int, ScoredCandidate, np.ndarray]],
    ) -> list[tuple[int, NoveltyResult]]:
        """Parse LLM novelty scoring response.

        Args:
            response: Parsed JSON from LLM.
            borderlines: Original borderline candidates with indices.

        Returns:
            List of (original_index, NoveltyResult) tuples.
        """
        scored_items = response.get("scored_candidates", [])
        results: list[tuple[int, NoveltyResult]] = []

        # Build index mapping: LLM 1-indexed → borderlines list position
        for scored in scored_items:
            llm_idx = int(scored.get("index", 0)) - 1  # Convert to 0-indexed
            if llm_idx < 0 or llm_idx >= len(borderlines):
                continue

            orig_idx, candidate, _ = borderlines[llm_idx]
            score = float(scored.get("novelty_score", 0.0))
            reasoning = str(scored.get("reasoning", ""))
            contradicts_raw = scored.get("contradicts")

            # Contradictions are always accepted regardless of score
            is_contradiction = contradicts_raw is not None
            accepted = score >= LLM_NOVELTY_ACCEPTANCE or is_contradiction

            contradicts: list[str] = []
            if isinstance(contradicts_raw, str):
                contradicts = [contradicts_raw]
            elif isinstance(contradicts_raw, list):
                contradicts = [str(c) for c in contradicts_raw]

            results.append(
                (
                    orig_idx,
                    NoveltyResult(
                        content=candidate.content,
                        score=score,
                        accepted=accepted,
                        method="llm",
                        reasoning=reasoning,
                        contradicts=contradicts,
                    ),
                )
            )

        # Handle any candidates the LLM didn't score (conservative reject)
        scored_indices = {llm_idx for llm_idx, _ in enumerate(results)}
        for i, (orig_idx, candidate, _) in enumerate(borderlines):
            if i not in scored_indices and not any(r[0] == orig_idx for r in results):
                results.append(
                    (
                        orig_idx,
                        NoveltyResult(
                            content=candidate.content,
                            score=0.5,
                            accepted=False,
                            method="llm_fallback",
                            reasoning="Not scored by LLM — conservative reject",
                        ),
                    )
                )

        return results

    def _log_result(self, result: NoveltyResult, conversation_id: str) -> None:
        """Log a novelty evaluation result.

        Args:
            result: The novelty result to log.
            conversation_id: The conversation id.
        """
        self._conversation_store.save_novelty_log(
            log_id=uuid.uuid4().hex,
            timestamp=_now_iso(),
            conversation_id=conversation_id,
            candidate_text=result.content[:500],
            novelty_score=result.score,
            reasoning=result.reasoning,
            contradicts=",".join(result.contradicts),
            accepted=result.accepted,
            method=result.method,
        )
