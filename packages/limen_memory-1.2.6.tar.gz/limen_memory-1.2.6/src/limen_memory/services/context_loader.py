"""Tiered context retrieval for assembling memory context.

Implements fresh/continuing/recall modes with budget-based tier assembly.
The context loader transforms stored memories into formatted context
strings suitable for injection into conversation system prompts.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import datetime, timedelta
from enum import Enum
from typing import TYPE_CHECKING

from limen_memory.constants import (
    CONTEXT_BUDGET_CHARS,
    CONTINUING_MODE_KEYWORD_OVERLAP,
    CONTINUING_MODE_TIME_PROXIMITY_HOURS,
    GRAPH_DISCOVERED_CAP,
    GRAPH_TRAVERSAL_MAX_HOPS,
    GRAPH_TRAVERSAL_MIN_CONFIDENCE,
    PROFILE_DIMENSION_CONFIDENCE_FLOOR,
    PROFILE_DIMENSION_METADATA,
    RELEVANCE_FALLBACK_LIMIT,
    RELEVANCE_FALLBACK_MIN_RESULTS,
    RELEVANCE_FALLBACK_POOL_SIZE,
    RELEVANCE_REFLECTION_THRESHOLD,
    RELEVANCE_SUMMARY_THRESHOLD,
    SESSION_BRIDGE_MAX_AGE_DAYS,
    USER_FACTS_PER_CATEGORY_CAP,
)
from limen_memory.services.keyword_extractor import extract_keywords as _default_extract

if TYPE_CHECKING:
    from limen_memory.models import ConversationSummary, MemoryReflection, RuleResult, UserFact
    from limen_memory.rules.engine import RuleEngine
    from limen_memory.services.embedding._protocol import EmbeddingClientProtocol
    from limen_memory.services.strategy_service import StrategyService
    from limen_memory.store.conversation_store import ConversationStore
    from limen_memory.store.embedding_store import EmbeddingStore
    from limen_memory.store.graph_store import GraphStore
    from limen_memory.store.memory_store import MemoryStore
    from limen_memory.store.profile_store import ProfileStore


logger = logging.getLogger(__name__)


# --- Recall pattern phrases ---

_RECALL_PATTERNS: list[str] = [
    "remember when",
    "last time we",
    "we discussed",
    "we talked about",
    "previously",
    "earlier we",
    "you mentioned",
    "you said",
    "you told me",
    "recall",
    "before we",
    "in our last",
    "back when",
    "you noted",
    "as we discussed",
]

# --- Fresh-mode sentinel messages (skip keyword extraction) ---

_FRESH_SENTINEL_MESSAGES: frozenset[str] = frozenset(
    {"new conversation starting", "general context"}
)


# --- Context mode enum ---


class ContextMode(Enum):
    """Context retrieval modes determining tier budgets."""

    FRESH = "fresh"
    CONTINUING = "continuing"
    RECALL = "recall"


# --- Per-mode tier budgets ---

_TIER_BUDGETS: dict[ContextMode, dict[str, int]] = {
    ContextMode.FRESH: {
        "rules": 400,
        "session_bridge": 300,
        "user_facts": 800,
        "relevance": 1400,
        "strategy": 500,
        "profile": 400,
        "summaries": 1100,
        "pending": 1100,
    },
    ContextMode.CONTINUING: {
        "rules": 400,
        "session_bridge": 1200,
        "user_facts": 800,
        "relevance": 600,
        "strategy": 500,
        "profile": 400,
        "summaries": 900,
        "pending": 1200,
    },
    ContextMode.RECALL: {
        "rules": 400,
        "session_bridge": 400,
        "user_facts": 800,
        "relevance": 1300,
        "strategy": 500,
        "profile": 400,
        "summaries": 1200,
        "pending": 600,
    },
}


class ContextLoader:
    """Tiered context retrieval for assembling memory context.

    Implements fresh/continuing/recall modes with budget-based tier assembly.

    Args:
        memory_store: For reflections, sessions, user facts, directives.
        graph_store: For graph traversal and edge annotations.
        embedding_store: For embedding similarity search (optional).
        embedding_client: For computing query embeddings (optional).
        conversation_store: For conversation summaries and search.
        strategy_service: For loading learned strategies (optional).
        profile_store: For interaction profile dimensions (optional).
        rule_engine: For executing context-injection rules (optional).
        keyword_extractor_fn: Keyword extraction callable (defaults to built-in).
    """

    def __init__(
        self,
        memory_store: MemoryStore,
        graph_store: GraphStore,
        embedding_store: EmbeddingStore | None = None,
        embedding_client: EmbeddingClientProtocol | None = None,
        conversation_store: ConversationStore | None = None,
        strategy_service: StrategyService | None = None,
        profile_store: ProfileStore | None = None,
        rule_engine: RuleEngine | None = None,
        keyword_extractor_fn: Callable[[str, int], list[str]] | None = None,
    ) -> None:
        self._memory = memory_store
        self._graph = graph_store
        self._embedding_store = embedding_store
        self._embedding_client = embedding_client
        self._conversation_store = conversation_store
        self._strategy_service = strategy_service
        self._profile_store = profile_store
        self._rule_engine = rule_engine
        self._extract_keywords = keyword_extractor_fn or _default_extract
        self._last_loaded_reflection_ids: set[str] = set()
        self._retrieval_degraded: bool = False
        self._last_rule_results: list[RuleResult] = []
        self._last_tier_diagnostics: dict[str, str] = {}

    @property
    def last_loaded_reflection_ids(self) -> set[str]:
        """IDs of reflections loaded in the most recent context assembly."""
        return self._last_loaded_reflection_ids.copy()

    @property
    def retrieval_degraded(self) -> bool:
        """Whether the last context load fell back to keyword-only retrieval."""
        return self._retrieval_degraded

    @property
    def last_rule_results(self) -> list[RuleResult]:
        """Rule results from the most recent load_context() call."""
        return list(self._last_rule_results)

    @property
    def last_tier_diagnostics(self) -> dict[str, str]:
        """Diagnostic reasons for empty tiers in the last load_context() call."""
        return dict(self._last_tier_diagnostics)

    def detect_mode(self, user_message: str) -> ContextMode:
        """Detect context mode from message content and session state.

        Priority: recall patterns first, then time-proximity with prep notes,
        then keyword overlap >= 3 with last session, default fresh.

        Args:
            user_message: The current user message.

        Returns:
            Detected ContextMode.
        """
        msg_lower = user_message.lower()

        # Check recall patterns first
        for pattern in _RECALL_PATTERNS:
            if pattern in msg_lower:
                return ContextMode.RECALL

        # Fetch last session once for both proximity and keyword checks
        last_session = self._memory.get_last_session_context()
        if last_session:
            try:
                session_ts = datetime.fromisoformat(last_session.started_at)
                age = datetime.utcnow() - session_ts

                # Time-proximity: recent session with prep notes → continuing
                if (
                    age <= timedelta(hours=CONTINUING_MODE_TIME_PROXIMITY_HOURS)
                    and last_session.next_session_prep
                ):
                    return ContextMode.CONTINUING

                # Keyword overlap within the broader age limit
                if age <= timedelta(days=SESSION_BRIDGE_MAX_AGE_DAYS):
                    session_text = " ".join(
                        [last_session.primary_topic or ""] + last_session.active_threads
                    )
                    session_keywords = set(self._extract_keywords(session_text, 20))
                    message_keywords = set(self._extract_keywords(user_message, 20))
                    overlap = len(session_keywords & message_keywords)
                    if overlap >= CONTINUING_MODE_KEYWORD_OVERLAP:
                        return ContextMode.CONTINUING
            except (ValueError, TypeError):
                pass

        return ContextMode.FRESH

    def load_context(self, user_message: str) -> str:
        """Assemble full context string for a user message.

        Detects context mode, assembles tiers within budgets, returns
        combined context string capped at CONTEXT_BUDGET_CHARS.

        Args:
            user_message: The current user message.

        Returns:
            Assembled context string.
        """
        self._last_loaded_reflection_ids = set()
        self._retrieval_degraded = False
        self._last_rule_results = []
        self._last_tier_diagnostics = {}

        mode = self.detect_mode(user_message)
        budgets = _TIER_BUDGETS[mode]

        parts: list[str] = []

        # Tier 1: Active guidance from rule engine
        rules_text = self._build_rules_tier(user_message, budgets["rules"])
        if rules_text:
            parts.append(rules_text)

        # Tier 2: Session bridge
        session_text = self._build_session_bridge(budgets["session_bridge"], mode)
        if session_text:
            parts.append(session_text)

        # Tier 2.3: User facts
        user_facts_text = self._build_user_facts_tier(budgets["user_facts"])
        if user_facts_text:
            parts.append(user_facts_text)

        # Tier 2.5: Relevance bridge
        relevance_text, relevance_ids = self._build_relevance_bridge(
            user_message, budgets["relevance"]
        )
        if relevance_text:
            parts.append(relevance_text)
        self._last_loaded_reflection_ids.update(relevance_ids)

        # Tier 2.7: Learned strategies
        strategy_text = self._build_strategy_tier(budgets["strategy"])
        if strategy_text:
            parts.append(strategy_text)

        # Tier 2.8: Interaction profile
        profile_text = self._build_profile_tier(budgets["profile"])
        if profile_text:
            parts.append(profile_text)

        # Tier 3: Recent summaries
        summaries_text = self._build_summaries_tier(budgets["summaries"])
        if summaries_text:
            parts.append(summaries_text)

        # Tier 4: Pending items
        pending_text = self._build_pending_tier(budgets["pending"])
        if pending_text:
            parts.append(pending_text)

        # Touch retrieved reflections to reset their aging clock
        if self._last_loaded_reflection_ids:
            self._memory.touch_reflections(self._last_loaded_reflection_ids)

        if self._retrieval_degraded:
            parts.insert(0, "Note: Semantic search unavailable; using keyword fallback.")

        parts = self._dedup_across_tiers(parts)
        combined = "\n\n".join(parts)
        return self._truncate_to_budget(combined, CONTEXT_BUDGET_CHARS)

    # --- Tier builders ---

    def _build_session_bridge(self, budget: int, mode: ContextMode) -> str:
        """Tier 2: Session bridge from last session (< 7 days).

        Args:
            budget: Character budget for this tier.
            mode: Current context mode (affects content selection).

        Returns:
            Formatted session bridge text, or empty string.
        """
        last_session = self._memory.get_last_session_context()
        if not last_session:
            return ""

        # Check session age
        try:
            session_ts = datetime.fromisoformat(last_session.started_at)
            age = datetime.utcnow() - session_ts
            if age > timedelta(days=SESSION_BRIDGE_MAX_AGE_DAYS):
                return ""
        except (ValueError, TypeError):
            return ""

        lines = ["## Last Session"]
        if last_session.primary_topic:
            lines.append(f"Topic: {last_session.primary_topic}")

        if last_session.active_threads:
            lines.append(f"Active threads: {', '.join(last_session.active_threads)}")

        # Include more detail in continuing mode
        if mode == ContextMode.CONTINUING:
            if last_session.pending_decisions:
                lines.append(f"Pending decisions: {', '.join(last_session.pending_decisions)}")
            if last_session.blockers:
                lines.append(f"Blockers: {', '.join(last_session.blockers)}")
            if last_session.completed_items:
                lines.append(f"Completed: {', '.join(last_session.completed_items)}")

        if last_session.next_session_prep:
            lines.append(f"Next session prep: {last_session.next_session_prep}")

        if last_session.context_notes:
            lines.append(f"Notes: {last_session.context_notes}")

        return self._truncate_to_budget("\n".join(lines), budget)

    def _build_user_facts_tier(self, budget: int) -> str:
        """Tier 2.3: User facts grouped by category with round-robin diversity.

        Formats stored user facts as a concise profile section.
        High-confidence facts are listed first within each category.
        A per-category cap ensures every category gets representation
        before any single category monopolises the budget.

        When a fact's key equals or is a prefix of its value, only the
        value is rendered to avoid duplication (e.g. the reflection
        pipeline sometimes stores the same string as both key and value).

        Args:
            budget: Character budget for this tier.

        Returns:
            Formatted user facts text, or empty string.
        """
        facts: list[UserFact] = self._memory.query_user_facts()
        if not facts:
            return ""

        # Group by category
        by_category: dict[str, list[UserFact]] = {}
        for fact in facts:
            by_category.setdefault(fact.category, []).append(fact)

        # Sort facts within each category: high confidence first
        confidence_order = {"high": 0, "medium": 1, "low": 2}
        for cat_facts in by_category.values():
            cat_facts.sort(key=lambda f: confidence_order.get(f.confidence, 3))

        # Cap per category and interleave via round-robin
        capped: dict[str, list[UserFact]] = {
            cat: cat_facts[:USER_FACTS_PER_CATEGORY_CAP] for cat, cat_facts in by_category.items()
        }

        interleaved: list[UserFact] = []
        for slot in range(USER_FACTS_PER_CATEGORY_CAP):
            for category in sorted(capped):
                if slot < len(capped[category]):
                    interleaved.append(capped[category][slot])

        lines = ["## User Profile"]
        for fact in interleaved:
            lines.append(self._format_user_fact(fact))

        return self._truncate_to_budget("\n".join(lines), budget)

    @staticmethod
    def _format_user_fact(fact: UserFact) -> str:
        """Format a single user fact line, deduplicating key ≈ value.

        Args:
            fact: The user fact to format.

        Returns:
            Formatted line like ``- [category] value`` or ``- [category] key: value``.
        """
        if fact.key == fact.value or fact.value.startswith(fact.key):
            return f"- [{fact.category}] {fact.value}"
        return f"- [{fact.category}] {fact.key}: {fact.value}"

    def _build_relevance_bridge(
        self,
        user_message: str,
        budget: int,
    ) -> tuple[str, set[str]]:
        """Tier 2.5: Relevance bridge with optional embedding re-ranking.

        When the user message is a known sentinel (e.g. "new conversation starting"),
        keyword extraction is skipped entirely. If keyword/embedding matching yields
        fewer than RELEVANCE_FALLBACK_MIN_RESULTS reflections, recent reflections
        are fetched as a fallback.

        Args:
            user_message: The current user message.
            budget: Character budget for this tier.

        Returns:
            Tuple of (formatted context string, set of loaded reflection IDs).
        """
        loaded_ids: set[str] = set()
        is_sentinel = user_message.lower().strip() in _FRESH_SENTINEL_MESSAGES

        # Step 1: Keyword pipeline (skip for sentinel messages)
        ranked_reflections: list[MemoryReflection] = []
        summary_candidates: list[ConversationSummary] = []
        used_keyword_match = False

        if not is_sentinel:
            keywords = self._extract_keywords(user_message, 10)
            if keywords:
                topic = " ".join(keywords)
                candidates = self._memory.query_reflections(topic=topic, limit=20)

                if self._conversation_store:
                    summary_candidates = self._conversation_store.search_summaries_by_keywords(
                        keywords
                    )

                ranked_reflections = self._rerank_reflections(candidates, user_message)
                used_keyword_match = True

        # Step 2: Fallback to recent reflections if keyword results are insufficient
        fallback_reflections: list[MemoryReflection] = []
        if len(ranked_reflections) < RELEVANCE_FALLBACK_MIN_RESULTS:
            fallback_reflections = self._get_diverse_fallback(
                exclude_ids={r.id for r in ranked_reflections},
            )

        # Step 3: Embedding re-ranking for summaries (if keyword pipeline ran)
        ranked_summaries: list[ConversationSummary] = []
        if used_keyword_match and summary_candidates:
            ranked_summaries = self._rerank_summaries(summary_candidates, user_message)

        # Build reflection lines
        lines: list[str] = []
        if ranked_reflections:
            lines.append("## Relevant Context")
            for ref in ranked_reflections:
                prefix = self._apply_epistemic_prefix(ref)
                lines.append(f"- {prefix} {ref.content}")
                loaded_ids.add(ref.id)

        if fallback_reflections:
            lines.append("## Recent Insights")
            for ref in fallback_reflections:
                prefix = self._apply_epistemic_prefix(ref)
                lines.append(f"- {prefix} {ref.content}")
                loaded_ids.add(ref.id)

        # Step 4: Edge annotations for loaded reflections
        if loaded_ids:
            annotations = self._graph.get_edge_annotations_for_reflections(
                list(loaded_ids), max_per=2
            )
            for ref_id, edges in annotations.items():
                for edge in edges:
                    if edge.relationship_type == "contradicts":
                        lines.append(
                            f"  ^ contradicts another observation "
                            f"(confidence: {edge.confidence:.1f})"
                        )
                    elif edge.relationship_type == "reinforces":
                        lines.append(
                            f"  ^ reinforced by related observation "
                            f"(confidence: {edge.confidence:.1f})"
                        )

        # Step 5: Multi-hop graph traversal from relevant reflections
        if loaded_ids:
            discovered = self._graph.get_connected_reflections(
                seed_ids=list(loaded_ids),
                max_hops=GRAPH_TRAVERSAL_MAX_HOPS,
                min_confidence=GRAPH_TRAVERSAL_MIN_CONFIDENCE,
            )
            # Cap graph-discovered and exclude already loaded
            graph_count = 0
            for node_id, score in discovered:
                if node_id in loaded_ids:
                    continue
                if graph_count >= GRAPH_DISCOVERED_CAP:
                    break
                maybe_ref = self._memory.get_reflection(node_id)
                if maybe_ref is not None and not maybe_ref.deprecated:
                    prefix = self._apply_epistemic_prefix(maybe_ref)
                    lines.append(f"- [Graph-discovered] {prefix} {maybe_ref.content}")
                    loaded_ids.add(maybe_ref.id)
                    graph_count += 1

        # Add summary matches
        if ranked_summaries:
            lines.append("")
            lines.append("## Related Conversations")
            for summary in ranked_summaries[:3]:
                lines.append(f"- {summary.summary[:150]}")

        text = "\n".join(lines) if lines else ""
        return self._truncate_to_budget(text, budget), loaded_ids

    def _rerank_reflections(
        self,
        candidates: list[MemoryReflection],
        user_message: str,
    ) -> list[MemoryReflection]:
        """Re-rank reflection candidates using embeddings or keyword fallback.

        Args:
            candidates: Pre-filtered reflection candidates.
            user_message: The user message for computing query embedding.

        Returns:
            Ranked list of reflections above the relevance threshold.
        """
        if not candidates:
            return []

        # Try embedding re-ranking
        emb_client = self._embedding_client
        emb_store = self._embedding_store
        if emb_store is not None and emb_client is not None:
            try:
                query_embedding = emb_client.embed_single(user_message)
                similar = emb_store.find_similar(
                    query_embedding, limit=20, min_similarity=RELEVANCE_REFLECTION_THRESHOLD
                )
                sim_map = {m.reflection_id: m.similarity for m in similar}

                # Reorder candidates by embedding similarity
                ranked = []
                for ref in candidates:
                    if ref.id in sim_map:
                        ranked.append((ref, sim_map[ref.id]))
                ranked.sort(key=lambda x: x[1], reverse=True)
                return [ref for ref, _ in ranked]
            except Exception:
                logger.warning("Embedding re-ranking failed, using keyword order")
                self._retrieval_degraded = True

        # Keyword fallback: candidates are already keyword-sorted from query_reflections
        return candidates[:10]

    def _rerank_summaries(
        self,
        candidates: list[ConversationSummary],
        user_message: str,
    ) -> list[ConversationSummary]:
        """Re-rank summary candidates using embeddings or keyword fallback.

        Args:
            candidates: Pre-filtered summary candidates.
            user_message: The user message for context.

        Returns:
            Ranked list of summaries above the relevance threshold.
        """
        if not candidates:
            return []

        # Try embedding-based re-ranking
        emb_client = self._embedding_client
        if self._embedding_store is not None and emb_client is not None:
            try:
                import numpy as np

                query_embedding = emb_client.embed_single(user_message)
                # Score summaries by embedding similarity
                scored: list[tuple[ConversationSummary, float]] = []
                for summary in candidates:
                    summary_embedding = emb_client.embed_single(summary.summary)
                    norm_q = np.linalg.norm(query_embedding)
                    norm_s = np.linalg.norm(summary_embedding)
                    if norm_q > 0 and norm_s > 0:
                        similarity = float(
                            np.dot(query_embedding, summary_embedding) / (norm_q * norm_s)
                        )
                        if similarity >= RELEVANCE_SUMMARY_THRESHOLD:
                            scored.append((summary, similarity))

                scored.sort(key=lambda x: x[1], reverse=True)
                return [s for s, _ in scored]
            except Exception:
                logger.warning("Summary embedding re-ranking failed, using keyword order")
                self._retrieval_degraded = True

        # Keyword fallback: return as-is (already keyword-filtered)
        return candidates[:5]

    def _get_diverse_fallback(
        self,
        exclude_ids: set[str],
    ) -> list[MemoryReflection]:
        """Fetch fallback reflections with type diversity via round-robin.

        Uses the last session's primary_topic for scoring when available,
        then interleaves by reflection type to avoid homogeneous results.

        Args:
            exclude_ids: Reflection IDs already selected (to avoid duplicates).

        Returns:
            Up to RELEVANCE_FALLBACK_LIMIT reflections with type diversity.
        """
        # Use last session's topic for better scoring when available
        last_session = self._memory.get_last_session_context()
        fallback_topic = (last_session.primary_topic or "") if last_session else ""

        pool = self._memory.query_reflections(
            topic=fallback_topic, limit=RELEVANCE_FALLBACK_POOL_SIZE
        )
        filtered = [r for r in pool if r.id not in exclude_ids]

        if not filtered:
            return []

        # Group by type and round-robin interleave
        by_type: dict[str, list[MemoryReflection]] = {}
        for r in filtered:
            by_type.setdefault(r.type, []).append(r)

        interleaved: list[MemoryReflection] = []
        max_per_type = max(len(v) for v in by_type.values())
        for slot in range(max_per_type):
            for rtype in sorted(by_type):
                if slot < len(by_type[rtype]):
                    interleaved.append(by_type[rtype][slot])

        return interleaved[:RELEVANCE_FALLBACK_LIMIT]

    def _build_strategy_tier(self, budget: int) -> str:
        """Build strategy tier from high-confidence learned strategies.

        Calls strategy_service.load_strategies_for_prompt() and formats
        strategies grouped by type for context injection.

        Args:
            budget: Character budget for this tier.

        Returns:
            Formatted strategy text, or empty string.
        """
        if not self._strategy_service:
            return ""

        try:
            grouped = self._strategy_service.load_strategies_for_prompt()
        except Exception:
            logger.warning("Failed to load strategies for context")
            return ""

        if not grouped:
            self._last_tier_diagnostics["strategy"] = "no_strategies"
            return ""

        lines = ["## Learned Strategies"]
        for strategy_type, strategies in grouped.items():
            for strategy in strategies:
                lines.append(f"- [{strategy_type}] {strategy.content}")

        return self._truncate_to_budget("\n".join(lines), budget)

    def _build_profile_tier(self, budget: int) -> str:
        """Build interaction profile tier from stored dimensions.

        Calls profile_store.get_interaction_profile(), filters to dimensions
        above the confidence floor, and formats with score interpretation
        and actionable advice.

        Args:
            budget: Character budget for this tier.

        Returns:
            Formatted profile text, or empty string.
        """
        if not self._profile_store:
            return ""

        try:
            dims = self._profile_store.get_interaction_profile()
        except Exception:
            logger.warning("Failed to load interaction profile for context")
            return ""

        if not dims:
            self._last_tier_diagnostics["profile"] = "no_dimensions"
            return ""

        qualifying = [d for d in dims if d.confidence >= PROFILE_DIMENSION_CONFIDENCE_FLOOR]
        if not qualifying:
            self._last_tier_diagnostics["profile"] = "no_qualifying_dimensions"
            return ""

        lines = ["## Interaction Profile"]
        for d in qualifying:
            meta = PROFILE_DIMENSION_METADATA.get(d.dimension, {})
            if d.score > 0.3 and meta:
                label = meta["high_label"]
                advice = meta["high_advice"]
            elif d.score < -0.3 and meta:
                label = meta["low_label"]
                advice = meta["low_advice"]
            else:
                continue  # Skip balanced/neutral dimensions
            lines.append(f"- {d.dimension}: {d.score:+.1f} ({label}) \u2192 {advice}")

        if len(lines) <= 1:
            return ""

        return self._truncate_to_budget("\n".join(lines), budget)

    def _build_rules_tier(self, user_message: str, budget: int) -> str:
        """Build active guidance tier from the rule engine.

        Creates a ConversationContext, runs all rules, and collects
        injected text from fired rules.

        Args:
            user_message: The current user message.
            budget: Character budget for this tier.

        Returns:
            Formatted guidance text, or empty string.
        """
        if not self._rule_engine:
            return ""

        try:
            from limen_memory.rules.engine import ConversationContext as ConvCtx

            # Use a copy so rules don't mutate the loader's set via shared reference
            working_ids = set(self._last_loaded_reflection_ids)
            conv_ctx = ConvCtx(
                current_message=user_message,
                loaded_reflection_ids=working_ids,
                user_facts=self._memory.query_user_facts(),
            )
            results = self._rule_engine.execute_all(conv_ctx)
            self._last_rule_results = results
            # Propagate rule-consumed IDs back explicitly
            self._last_loaded_reflection_ids.update(working_ids)
        except Exception:
            logger.warning("Failed to execute rules for context")
            return ""

        injected_parts: list[str] = []
        for result in results:
            if result.fired and result.injected_text:
                injected_parts.append(result.injected_text)

        if not injected_parts:
            return ""

        lines = ["## Active Guidance"] + injected_parts
        return self._truncate_to_budget("\n".join(lines), budget)

    def _build_summaries_tier(self, budget: int) -> str:
        """Tier 3: Recent conversation summaries.

        Args:
            budget: Character budget for this tier.

        Returns:
            Formatted summaries text, or empty string.
        """
        if not self._conversation_store:
            return ""

        summaries = self._conversation_store.get_recent_summaries(limit=5)
        if not summaries:
            self._last_tier_diagnostics["summaries"] = "no_summaries"
            return ""

        lines = ["## Recent Conversations"]
        for summary in summaries:
            title_line = f"- [{summary.created_at[:10]}]"
            if summary.key_topics:
                title_line += f" ({summary.key_topics})"
            title_line += f" {summary.summary[:120]}"
            lines.append(title_line)

            if summary.status_markers:
                lines.append(f"  Status: {summary.status_markers}")

        return self._truncate_to_budget("\n".join(lines), budget)

    def _build_pending_tier(self, budget: int) -> str:
        """Tier 4: Pending items from active/blocked conversations.

        Args:
            budget: Character budget for this tier.

        Returns:
            Formatted pending items text, or empty string.
        """
        if not self._conversation_store:
            return ""

        # Search for conversations with pending status markers
        summaries = self._conversation_store.get_recent_summaries(limit=10)
        pending_items: list[str] = []
        for summary in summaries:
            if summary.pending_items:
                for item in summary.pending_items.split(";"):
                    item = item.strip()
                    if item:
                        pending_items.append(f"- {item}")
            if summary.status_markers and any(
                marker in summary.status_markers.lower()
                for marker in ("in_progress", "blocked", "pending")
            ):
                topic = summary.key_topics or summary.conversation_id
                for marker in summary.status_markers.split(";"):
                    marker = marker.strip()
                    if marker:
                        pending_items.append(f"- [{topic}] {marker}")

        if not pending_items:
            self._last_tier_diagnostics["pending"] = "no_pending_items"
            return ""

        lines = ["## Pending Items"] + pending_items[:10]
        return self._truncate_to_budget("\n".join(lines), budget)

    # --- Helpers ---

    @staticmethod
    def _apply_epistemic_prefix(reflection: MemoryReflection) -> str:
        """Apply epistemic status prefix to reflection content.

        Args:
            reflection: The reflection to format.

        Returns:
            Prefix string like "[Exploring/insight]" or "[insight]".
        """
        status = reflection.epistemic_status
        ref_type = reflection.type

        if status == "pondering":
            return f"[Exploring/{ref_type}]"
        elif status == "hypothesis":
            return f"[Hypothesis/{ref_type}]"
        else:
            return f"[{ref_type}]"

    @staticmethod
    def _dedup_across_tiers(parts: list[str]) -> list[str]:
        """Remove duplicate content lines across tiers using bigram matching.

        Earlier tiers take precedence — later-tier lines sharing >= 2 bigrams
        (word pairs with words >= 4 chars) with any earlier tier are dropped.
        Headers (##) and empty lines are preserved. Tiers reduced to only a
        header are removed entirely.

        Only catches near-identical text; paraphrased duplicates are not detected.

        Args:
            parts: List of tier strings (one per tier).

        Returns:
            Deduplicated list of tier strings.
        """
        if len(parts) <= 1:
            return parts

        def _extract_bigrams(line: str) -> set[tuple[str, str]]:
            words = [w.lower() for w in line.split() if len(w) >= 4]
            return {(words[i], words[i + 1]) for i in range(len(words) - 1)}

        seen_bigrams: set[tuple[str, str]] = set()
        result: list[str] = []

        for part in parts:
            lines = part.split("\n")
            kept_lines: list[str] = []

            for line in lines:
                stripped = line.strip()
                # Always preserve headers and empty lines
                if not stripped or stripped.startswith("##"):
                    kept_lines.append(line)
                    continue

                bigrams = _extract_bigrams(stripped)
                overlap = bigrams & seen_bigrams
                if len(overlap) >= 2:
                    continue  # Duplicate — skip

                kept_lines.append(line)
                seen_bigrams.update(bigrams)

            # Drop tiers that became empty (header only)
            content_lines = [
                ln for ln in kept_lines if ln.strip() and not ln.strip().startswith("##")
            ]
            if content_lines:
                result.append("\n".join(kept_lines))

        return result

    @staticmethod
    def _truncate_to_budget(text: str, budget: int) -> str:
        """Truncate text to budget, avoiding mid-line cuts.

        Args:
            text: Text to truncate.
            budget: Maximum character count.

        Returns:
            Truncated text.
        """
        if len(text) <= budget:
            return text

        # Find the last newline before the budget
        truncated = text[:budget]
        last_newline = truncated.rfind("\n")
        if last_newline > 0:
            return truncated[:last_newline]
        return truncated
