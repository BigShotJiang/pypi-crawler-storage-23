"""Regex-based keyword extraction for text analysis."""

from __future__ import annotations

import re
from collections import Counter

_STOP_WORDS: frozenset[str] = frozenset(
    {
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "been",
        "but",
        "by",
        "can",
        "could",
        "did",
        "do",
        "does",
        "for",
        "from",
        "had",
        "has",
        "have",
        "he",
        "her",
        "him",
        "his",
        "how",
        "if",
        "in",
        "into",
        "is",
        "it",
        "its",
        "just",
        "may",
        "me",
        "might",
        "more",
        "most",
        "my",
        "no",
        "not",
        "now",
        "of",
        "on",
        "one",
        "or",
        "our",
        "out",
        "own",
        "said",
        "say",
        "she",
        "should",
        "so",
        "some",
        "such",
        "than",
        "that",
        "the",
        "their",
        "them",
        "then",
        "there",
        "these",
        "they",
        "this",
        "those",
        "through",
        "to",
        "too",
        "up",
        "us",
        "very",
        "was",
        "we",
        "were",
        "what",
        "when",
        "where",
        "which",
        "while",
        "who",
        "whom",
        "why",
        "will",
        "with",
        "would",
        "you",
        "your",
        "about",
        "after",
        "all",
        "also",
        "any",
        "back",
        "because",
        "being",
        "between",
        "both",
        "come",
        "each",
        "even",
        "every",
        "get",
        "got",
        "here",
        "like",
        "make",
        "many",
        "much",
        "new",
        "only",
        "other",
        "over",
        "same",
        "see",
        "still",
        "take",
        "tell",
        "thing",
        "think",
        "two",
        "use",
        "want",
        "way",
        "well",
        "work",
    }
)

_WORD_PATTERN: re.Pattern[str] = re.compile(r"[a-z]+")


def extract_keywords(text: str, max_keywords: int = 10) -> list[str]:
    """Extract significant keywords from text using regex.

    Lowercases text, extracts alphabetic words, removes stopwords and
    short words (< 3 chars), returns unique words sorted by frequency.

    Args:
        text: Input text to extract keywords from.
        max_keywords: Maximum number of keywords to return.

    Returns:
        List of keyword strings, sorted by frequency (most frequent first).
    """
    words = _WORD_PATTERN.findall(text.lower())
    filtered = [w for w in words if len(w) >= 3 and w not in _STOP_WORDS]

    if not filtered:
        return []

    counts = Counter(filtered)
    return [word for word, _ in counts.most_common(max_keywords)]
