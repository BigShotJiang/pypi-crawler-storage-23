"""Background task scheduler for memory maintenance.

Manages priority-ordered maintenance tasks: backup, consolidation,
strategy review, pruning, aging, and backfill operations. State is
tracked in the ``scheduler_state`` table. One task runs per tick.
"""

from __future__ import annotations

import logging
import shutil
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from limen_memory.config import LimenConfig
from limen_memory.constants import (
    AGING_INTERVAL_DAYS,
    CONSOLIDATION_INTERVAL_HOURS,
    CONSOLIDATION_MIN_REFLECTIONS,
    CROSS_ANALYSIS_INTERVAL_HOURS,
    CROSS_ANALYSIS_MIN_CONVERSATIONS,
    DATABASE_BACKUP_INTERVAL_HOURS,
    EDGE_BACKFILL_MIN_DENSITY_RATIO,
    PREDICTION_VALIDATION_INTERVAL_HOURS,
    PREDICTION_VALIDATION_MIN_EDGES,
    PROFILE_SYNTHESIS_INTERVAL_HOURS,
    PROFILE_SYNTHESIS_MIN_EVIDENCE,
    PRUNING_INTERVAL_DAYS,
    STRATEGY_REVIEW_INTERVAL_HOURS,
    WORKING_MEMORY_EDGE_CONFIDENCE,
    WORKING_MEMORY_EVIDENCE_PREFIX,
    WORKING_MEMORY_SIMILARITY_THRESHOLD,
)
from limen_memory.models import GraphEdge
from limen_memory.services.embedding._base import BaseEmbeddingClient
from limen_memory.services.llm_client import LLMClient
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.database import Database
from limen_memory.store.embedding_store import EmbeddingStore
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore
from limen_memory.store.profile_store import ProfileStore
from limen_memory.store.strategy_store import StrategyStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


@dataclass
class SchedulerTask:
    """A schedulable maintenance task.

    Args:
        priority: Lower number = higher priority.
        name: Human-readable task name.
        state_key: Key in scheduler_state table for last-run tracking.
        check_fn: Returns True if the task is eligible to run.
        run_fn: Executes the task and returns a result dict.
    """

    priority: float
    name: str
    state_key: str
    check_fn: Callable[[], bool]
    run_fn: Callable[[], dict[str, Any]]


class Scheduler:
    """Background task scheduler with priority-ordered execution.

    Maintains state in the ``scheduler_state`` table. Each call to
    ``tick()`` runs at most one eligible task (the highest-priority one).

    Args:
        db: Database instance for scheduler_state access.
        memory_store: Reflection and fact storage.
        graph_store: Knowledge graph operations.
        embedding_store: Embedding storage.
        embedding_client: Embedding client for vector operations.
        conversation_store: Conversation and logging.
        strategy_store: Strategy operations.
        llm_client: Claude CLI client.
        config: Limen configuration (for backup paths).
        profile_store: Interaction profile storage (optional).
    """

    def __init__(
        self,
        db: Database,
        memory_store: MemoryStore,
        graph_store: GraphStore,
        embedding_store: EmbeddingStore,
        embedding_client: BaseEmbeddingClient | None,
        conversation_store: ConversationStore,
        strategy_store: StrategyStore,
        llm_client: LLMClient,
        config: LimenConfig,
        profile_store: ProfileStore | None = None,
    ) -> None:
        self._db = db
        self._memory = memory_store
        self._graph = graph_store
        self._embedding_store = embedding_store
        self._embedding_client = embedding_client
        self._conversations = conversation_store
        self._strategies = strategy_store
        self._llm = llm_client
        self._config = config
        self._profile_store = profile_store

        self._tasks = self._build_task_list()

    def _build_task_list(self) -> list[SchedulerTask]:
        """Build the priority-ordered list of scheduler tasks.

        Returns:
            List of SchedulerTask sorted by priority.
        """
        tasks = [
            SchedulerTask(
                0,
                "db_backup",
                "last_backup",
                self._check_backup,
                self._run_backup,
            ),
            SchedulerTask(
                1,
                "consolidation",
                "last_consolidation",
                self._check_consolidation,
                self._run_consolidation,
            ),
            SchedulerTask(
                2,
                "cross_analysis",
                "last_cross_analysis",
                self._check_cross_analysis,
                self._run_cross_analysis,
            ),
            SchedulerTask(
                3,
                "strategy_review",
                "last_strategy_review",
                self._check_strategy_review,
                self._run_strategy_review,
            ),
            SchedulerTask(
                4,
                "pruning",
                "last_pruning",
                self._check_pruning,
                self._run_pruning,
            ),
            SchedulerTask(
                5,
                "aging",
                "last_aging",
                self._check_aging,
                self._run_aging,
            ),
            SchedulerTask(
                6,
                "prediction_validation",
                "last_prediction_validation",
                self._check_prediction_validation,
                self._run_prediction_validation,
            ),
            SchedulerTask(
                6.2,
                "profile_synthesis",
                "last_profile_synthesis",
                self._check_profile_synthesis,
                self._run_profile_synthesis,
            ),
            SchedulerTask(
                6.5,
                "embedding_backfill",
                "embedding_backfill_done",
                self._check_embedding_backfill,
                self._run_embedding_backfill,
            ),
            SchedulerTask(
                6.6,
                "edge_backfill",
                "edge_backfill_done",
                self._check_edge_backfill,
                self._run_edge_backfill,
            ),
        ]
        tasks.sort(key=lambda t: t.priority)
        return tasks

    # --- Public API ---

    def tick(self) -> dict[str, Any]:
        """Run one scheduler tick: execute the first eligible task.

        Returns:
            Dict with ``task`` name and ``result`` of execution,
            or ``task: "none"`` if nothing was due.
        """
        for task in self._tasks:
            if not task.check_fn():
                continue

            # Check retry backoff before running
            if self._is_backed_off(task.name):
                logger.info("Scheduler skipping %s (backed off)", task.name)
                continue

            logger.info("Scheduler running task: %s", task.name)
            try:
                result = task.run_fn()
            except Exception:
                logger.exception("Scheduler task %s failed", task.name)
                self._record_failure(task.name)
                return {
                    "task": task.name,
                    "result": {"error": f"Task {task.name} failed"},
                }

            # Detect error dicts returned by services that swallow exceptions
            if isinstance(result, dict) and "error" in result:
                logger.warning(
                    "Scheduler task %s returned error: %s", task.name, result.get("error")
                )
                self._record_failure(task.name)
                return {"task": task.name, "result": result}

            # Only update state on success
            if not task.state_key.endswith("_done"):
                self._set_state(task.state_key, _now_iso())
            self._clear_failures(task.name)

            return {"task": task.name, "result": result}

        return {"task": "none", "result": "No tasks due"}

    def startup_check(self) -> dict[str, Any]:
        """Run on first tick or after a long gap.

        Checks all tasks and runs the highest-priority overdue one.
        Same logic as ``tick()`` since check functions already handle
        overdue detection (never-run returns infinite elapsed time).

        Returns:
            Same as ``tick()``.
        """
        return self.tick()

    def get_status(self) -> dict[str, Any]:
        """Get scheduler status with all task states and timing.

        Returns:
            Dict with task states, next-due info, and timestamps.
        """
        rows = self._db.execute_read("SELECT * FROM scheduler_state")
        state = {r["key"]: r["value"] for r in rows}

        tasks_status: list[dict[str, Any]] = []
        for task in self._tasks:
            eligible = task.check_fn()
            last_run = self._get_state(task.state_key)

            task_info: dict[str, Any] = {
                "name": task.name,
                "priority": task.priority,
                "eligible": eligible,
                "last_run": last_run,
            }

            if task.state_key.endswith("_done"):
                task_info["completed"] = last_run == "true"
            else:
                hours = self._hours_since(task.state_key)
                task_info["hours_since_last"] = round(hours, 1) if hours != float("inf") else None

            tasks_status.append(task_info)

        return {"state": state, "tasks": tasks_status}

    # --- State helpers ---

    def _get_state(self, key: str) -> str | None:
        """Read a scheduler_state value.

        Args:
            key: State key.

        Returns:
            Value string or None if not set.
        """
        row = self._db.execute_read_one("SELECT value FROM scheduler_state WHERE key = ?", (key,))
        return str(row["value"]) if row else None

    def _set_state(self, key: str, value: str) -> None:
        """Write a scheduler_state value (upsert).

        Args:
            key: State key.
            value: Value to store.
        """
        self._db.execute_write(
            "INSERT OR REPLACE INTO scheduler_state (key, value, updated_at) VALUES (?, ?, ?)",
            (key, value, _now_iso()),
        )

    def _hours_since(self, key: str) -> float:
        """Hours elapsed since last run of a task.

        Args:
            key: State key for the task.

        Returns:
            Hours elapsed, or ``float('inf')`` if never run.
        """
        ts = self._get_state(key)
        if not ts:
            return float("inf")
        try:
            last = datetime.fromisoformat(ts)
            return (datetime.utcnow() - last).total_seconds() / 3600
        except (ValueError, TypeError):
            return float("inf")

    def _days_since(self, key: str) -> float:
        """Days elapsed since last run of a task.

        Args:
            key: State key for the task.

        Returns:
            Days elapsed, or ``float('inf')`` if never run.
        """
        return self._hours_since(key) / 24

    # --- Failure tracking ---

    def _failure_key(self, task_name: str) -> str:
        """Return the scheduler_state key for a task's failure count."""
        return f"{task_name}_failures"

    def _get_failure_count(self, task_name: str) -> int:
        """Return the consecutive failure count for a task.

        Args:
            task_name: The task name.

        Returns:
            Number of consecutive failures (0 if none recorded).
        """
        val = self._get_state(self._failure_key(task_name))
        if val is None:
            return 0
        try:
            return int(val)
        except (ValueError, TypeError):
            return 0

    def _record_failure(self, task_name: str) -> None:
        """Increment the consecutive failure counter for a task.

        Args:
            task_name: The task name.
        """
        count = self._get_failure_count(task_name) + 1
        self._set_state(self._failure_key(task_name), str(count))
        logger.warning("Task %s failed (%d consecutive)", task_name, count)

    def _clear_failures(self, task_name: str) -> None:
        """Reset the failure counter on success.

        Args:
            task_name: The task name.
        """
        if self._get_failure_count(task_name) > 0:
            self._set_state(self._failure_key(task_name), "0")

    def _is_backed_off(self, task_name: str) -> bool:
        """Check if a task is in backoff due to repeated failures.

        Uses exponential backoff: after N failures, require
        ``interval * 2^N`` time elapsed before retrying. If failures
        reach ``SCHEDULER_MAX_FAILURES``, the task is skipped entirely
        until failures are cleared.

        Args:
            task_name: The task name.

        Returns:
            True if the task should be skipped this tick.
        """
        from limen_memory.constants import SCHEDULER_BACKOFF_MULTIPLIER, SCHEDULER_MAX_FAILURES

        failures = self._get_failure_count(task_name)
        if failures == 0:
            return False

        if failures >= SCHEDULER_MAX_FAILURES:
            logger.error(
                "Task %s has %d consecutive failures (max %d), skipping",
                task_name,
                failures,
                SCHEDULER_MAX_FAILURES,
            )
            return True

        # Find the task to get its interval-based state key
        task = next((t for t in self._tasks if t.name == task_name), None)
        if task is None or task.state_key.endswith("_done"):
            return False

        hours = self._hours_since(task.state_key)
        # Look up the configured interval for backoff calculation
        backoff_factor = SCHEDULER_BACKOFF_MULTIPLIER**failures
        interval = self._get_task_interval_hours(task_name)
        required = interval * backoff_factor

        if hours < required:
            logger.info(
                "Task %s backed off (%.1fh < %.1fh required after %d failures)",
                task_name,
                hours,
                required,
                failures,
            )
            return True

        return False

    def _get_task_interval_hours(self, task_name: str) -> float:
        """Return the configured interval in hours for a given task.

        Args:
            task_name: The task name.

        Returns:
            Interval in hours.
        """
        from limen_memory.constants import (
            AGING_INTERVAL_DAYS,
            CONSOLIDATION_INTERVAL_HOURS,
            CROSS_ANALYSIS_INTERVAL_HOURS,
            DATABASE_BACKUP_INTERVAL_HOURS,
            PREDICTION_VALIDATION_INTERVAL_HOURS,
            PROFILE_SYNTHESIS_INTERVAL_HOURS,
            PRUNING_INTERVAL_DAYS,
            STRATEGY_REVIEW_INTERVAL_HOURS,
        )

        intervals: dict[str, float] = {
            "db_backup": DATABASE_BACKUP_INTERVAL_HOURS,
            "consolidation": CONSOLIDATION_INTERVAL_HOURS,
            "cross_analysis": CROSS_ANALYSIS_INTERVAL_HOURS,
            "strategy_review": STRATEGY_REVIEW_INTERVAL_HOURS,
            "pruning": PRUNING_INTERVAL_DAYS * 24,
            "aging": AGING_INTERVAL_DAYS * 24,
            "prediction_validation": PREDICTION_VALIDATION_INTERVAL_HOURS,
            "profile_synthesis": PROFILE_SYNTHESIS_INTERVAL_HOURS,
        }
        return intervals.get(task_name, 24.0)

    # --- Check functions ---

    def _check_backup(self) -> bool:
        return self._hours_since("last_backup") >= DATABASE_BACKUP_INTERVAL_HOURS

    def _check_consolidation(self) -> bool:
        if self._hours_since("last_consolidation") < CONSOLIDATION_INTERVAL_HOURS:
            return False
        last_ts = self._get_state("last_consolidation") or "1970-01-01T00:00:00"
        return self._memory.count_reflections_since(last_ts) >= CONSOLIDATION_MIN_REFLECTIONS

    def _check_cross_analysis(self) -> bool:
        if self._hours_since("last_cross_analysis") < CROSS_ANALYSIS_INTERVAL_HOURS:
            return False
        last_ts = self._get_state("last_cross_analysis") or "1970-01-01T00:00:00"
        return (
            self._conversations.count_conversations_since(last_ts)
            >= CROSS_ANALYSIS_MIN_CONVERSATIONS
        )

    def _check_strategy_review(self) -> bool:
        if self._hours_since("last_strategy_review") < STRATEGY_REVIEW_INTERVAL_HOURS:
            return False
        last_ts = self._get_state("last_strategy_review") or "1970-01-01T00:00:00"
        return self._conversations.count_observations_since(last_ts) >= 5

    def _check_pruning(self) -> bool:
        return self._days_since("last_pruning") >= PRUNING_INTERVAL_DAYS

    def _check_aging(self) -> bool:
        return self._days_since("last_aging") >= AGING_INTERVAL_DAYS

    def _check_prediction_validation(self) -> bool:
        if self._hours_since("last_prediction_validation") < PREDICTION_VALIDATION_INTERVAL_HOURS:
            return False
        prediction_edges = self._graph.get_prediction_edges(limit=PREDICTION_VALIDATION_MIN_EDGES)
        return len(prediction_edges) >= PREDICTION_VALIDATION_MIN_EDGES

    def _check_profile_synthesis(self) -> bool:
        if self._hours_since("last_profile_synthesis") < PROFILE_SYNTHESIS_INTERVAL_HOURS:
            return False
        if self._profile_store is None:
            return False
        last_ts = self._get_state("last_profile_synthesis") or "1970-01-01T00:00:00"
        new_evidence = self._memory.count_reflections_since(last_ts)
        return new_evidence >= PROFILE_SYNTHESIS_MIN_EVIDENCE

    def _check_embedding_backfill(self) -> bool:
        if self._get_state("embedding_backfill_done") == "true":
            return False
        return self._embedding_client is not None

    def _check_edge_backfill(self) -> bool:
        if self._get_state("edge_backfill_done") == "true":
            return False
        # Only after embedding backfill is complete
        if self._get_state("embedding_backfill_done") != "true":
            return False
        # Verify embeddings actually exist (not just marked done)
        return self._embedding_store.count_embeddings() > 0

    # --- Run functions ---

    def _run_backup(self) -> dict[str, Any]:
        """Run database backup (same logic as CLI backup command).

        Returns:
            Dict with backup path and count retained.
        """
        db_path = self._config.db_path
        if not db_path.exists():
            return {"status": "no_database"}

        backup_dir = self._config.backup_dir
        backup_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f"memory_{timestamp}.db"
        shutil.copy2(db_path, backup_path)

        # Prune old backups
        backups = sorted(backup_dir.glob("memory_*.db"), reverse=True)
        for old in backups[self._config.max_backups :]:
            old.unlink()

        retained = len(list(backup_dir.glob("memory_*.db")))
        logger.info("Backup created: %s (%d retained)", backup_path, retained)
        return {"backup_path": str(backup_path), "backups_retained": retained}

    def _run_consolidation(self) -> dict[str, Any]:
        """Run memory consolidation + chained sub-tasks.

        Returns:
            Consolidation result dict.
        """
        from limen_memory.services.consolidation import ConsolidationService

        if self._embedding_client is None:
            return {"status": "no_embedding_client", "skipped": True}

        svc = ConsolidationService(
            memory_store=self._memory,
            graph_store=self._graph,
            embedding_store=self._embedding_store,
            embedding_client=self._embedding_client,
            conversation_store=self._conversations,
            llm_client=self._llm,
        )
        return svc.consolidate()

    def _run_strategy_review(self) -> dict[str, Any]:
        """Run strategy review cycle.

        Returns:
            Strategy review result dict.
        """
        from limen_memory.services.strategy_service import StrategyService

        svc = StrategyService(
            strategy_store=self._strategies,
            conversation_store=self._conversations,
            llm_client=self._llm,
        )
        return svc.review_strategies()

    def _run_pruning(self) -> dict[str, Any]:
        """Prune orphaned edges referencing deprecated nodes.

        Returns:
            Dict with count of orphaned edges deprecated.
        """
        orphaned = self._graph.deprecate_orphaned_relationships()
        logger.info("Pruning complete: %d orphaned edges deprecated", orphaned)
        return {"orphaned_edges_deprecated": orphaned}

    def _run_aging(self) -> dict[str, Any]:
        """Run aging on reflections and graph edges.

        Returns:
            Dict with counts of aged reflections and edges.
        """
        reflections_aged = self._memory.age_reflections()
        edges_aged = self._graph.age_relationships()
        logger.info(
            "Aging complete: %d reflections, %d edges",
            reflections_aged,
            edges_aged,
        )
        return {
            "reflections_aged": reflections_aged,
            "edges_aged": edges_aged,
        }

    def _run_embedding_backfill(self) -> dict[str, Any]:
        """Compute embeddings for reflections that lack them.

        Returns:
            Dict with count of embeddings backfilled.
        """
        if self._embedding_client is None:
            self._set_state("embedding_backfill_done", "true")
            return {"embeddings_backfilled": 0, "status": "no_embedding_client"}

        reflections = self._memory.get_active_reflections(limit=500)
        backfilled = 0
        for r in reflections:
            if self._embedding_store.get_embedding(r.id) is not None:
                continue
            try:
                embedding = self._embedding_client.embed_single(r.content)
                self._embedding_store.save_embedding(r.id, embedding)
                backfilled += 1
            except Exception:
                logger.warning("Failed to backfill embedding for %s", r.id)

        self._set_state("embedding_backfill_done", "true")
        logger.info("Embedding backfill complete: %d computed", backfilled)
        return {"embeddings_backfilled": backfilled}

    def _run_edge_backfill(self) -> dict[str, Any]:
        """Create working memory edges for under-connected reflections.

        Finds reflections with fewer edges than the density threshold
        and creates provisional working memory edges via embedding
        similarity.

        Returns:
            Dict with count of edges created.
        """
        from limen_memory.services.reflection import (
            _classify_working_memory_relationship,
        )

        embedding_count = self._embedding_store.count_embeddings()
        if embedding_count == 0:
            self._set_state("edge_backfill_done", "true")
            return {"edges_created": 0}

        min_edges = max(1, int(embedding_count * EDGE_BACKFILL_MIN_DENSITY_RATIO))
        reflections = self._memory.get_active_reflections(limit=500)
        edges_created = 0

        for r in reflections:
            edge_count = self._memory._get_edge_count(r.id)
            if edge_count >= min_edges:
                continue

            embedding = self._embedding_store.get_embedding(r.id)
            if embedding is None:
                continue

            matches = self._embedding_store.find_similar(
                embedding,
                limit=5,
                min_similarity=WORKING_MEMORY_SIMILARITY_THRESHOLD,
                exclude_ids={r.id},
            )

            for match in matches[:3]:
                relationship = _classify_working_memory_relationship(match.similarity, r.content)
                evidence = f"{WORKING_MEMORY_EVIDENCE_PREFIX}: {match.similarity:.3f}"
                edge = GraphEdge(
                    id=_uid(),
                    source_id=r.id,
                    target_id=match.reflection_id,
                    source_type="reflection",
                    target_type="reflection",
                    relationship_type=relationship,
                    edge_category="evaluative",
                    confidence=WORKING_MEMORY_EDGE_CONFIDENCE,
                    evidence=evidence,
                )
                self._graph.save_relationship(edge)
                edges_created += 1

        self._set_state("edge_backfill_done", "true")
        logger.info("Edge backfill complete: %d edges created", edges_created)
        return {"edges_created": edges_created}

    # --- Phase 5 run functions ---

    def _run_cross_analysis(self) -> dict[str, Any]:
        """Run cross-conversation analysis.

        Returns:
            Cross-analysis result dict.
        """
        from limen_memory.services.cross_analyzer import CrossAnalyzer

        svc = CrossAnalyzer(
            memory_store=self._memory,
            conversation_store=self._conversations,
            llm_client=self._llm,
            embedding_client=self._embedding_client,
            embedding_store=self._embedding_store,
        )
        return svc.analyze()

    def _run_prediction_validation(self) -> dict[str, Any]:
        """Validate prediction edges against recent conversation evidence.

        Queries prediction edges, loads recent conversation summaries as
        evidence, then uses the LLM to evaluate each prediction as
        confirmed, refuted, or insufficient evidence. Applies confidence
        adjustments via ``record_prediction_outcome()``.

        Returns:
            Dict with counts of predictions validated, confirmed, refuted.
        """
        prediction_edges = self._graph.get_prediction_edges(limit=20, min_confidence=0.3)
        if not prediction_edges:
            return {"predictions_validated": 0, "confirmed": 0, "refuted": 0}

        summaries = self._conversations.get_recent_summaries(limit=10)
        if not summaries:
            return {"predictions_validated": 0, "confirmed": 0, "refuted": 0}

        # Build validation prompt
        prompt_parts: list[str] = []
        prompt_parts.append("## Predictions to Validate\n")
        for i, edge in enumerate(prediction_edges, 1):
            source_label = self._get_node_label(edge.source_id)
            target_label = self._get_node_label(edge.target_id)
            prompt_parts.append(
                f'{i}. [{edge.id}] "{source_label}" PREDICTS "{target_label}"'
                f" (confidence: {edge.confidence:.2f}, evidence: {edge.evidence[:100]})"
            )
        prompt_parts.append("")

        prompt_parts.append("\n## Recent Conversation Evidence\n")
        for s in summaries:
            prompt_parts.append(f"- [{s.created_at[:10]}] {s.summary[:200]}")
        prompt_parts.append("")

        prompt_parts.append(
            "\nFor each prediction, determine if recent conversations provide "
            "evidence to confirm or refute it, or if evidence is insufficient. "
            "Return JSON:\n"
            "{\n"
            '  "validations": [\n'
            '    {"edge_id": "", "outcome": "confirmed|refuted|insufficient", '
            '"reasoning": ""}\n'
            "  ]\n"
            "}"
        )

        system_prompt = (
            "You are a prediction validation engine. You evaluate whether "
            "predictions about a user's behavior have been confirmed or refuted "
            "by recent conversation evidence. Be conservative — only mark as "
            "confirmed or refuted when evidence is clear. You MUST respond with "
            "ONLY a single valid JSON object."
        )

        try:
            result = self._llm.prompt_json("\n".join(prompt_parts), system_prompt=system_prompt)
        except Exception:
            logger.exception("Prediction validation LLM call failed")
            return {
                "predictions_validated": 0,
                "confirmed": 0,
                "refuted": 0,
                "error": "LLM call failed",
            }

        # Apply outcomes
        confirmed = 0
        refuted = 0
        validated = 0
        edge_ids = {e.id for e in prediction_edges}

        for v in result.get("validations", []):
            edge_id = v.get("edge_id", "")
            outcome = v.get("outcome", "insufficient")
            if edge_id not in edge_ids:
                continue

            if outcome == "confirmed":
                self._graph.record_prediction_outcome(edge_id, success=True)
                confirmed += 1
                validated += 1
            elif outcome == "refuted":
                self._graph.record_prediction_outcome(edge_id, success=False)
                refuted += 1
                validated += 1

        logger.info(
            "Prediction validation complete: %d validated (%d confirmed, %d refuted)",
            validated,
            confirmed,
            refuted,
        )
        return {
            "predictions_validated": validated,
            "confirmed": confirmed,
            "refuted": refuted,
        }

    def _run_profile_synthesis(self) -> dict[str, Any]:
        """Run interaction profile synthesis.

        Returns:
            Profile synthesis result dict.
        """
        from limen_memory.services.profile_service import ProfileService

        if self._profile_store is None:
            return {"dimensions_updated": 0, "error": "no_profile_store"}

        svc = ProfileService(
            memory_store=self._memory,
            graph_store=self._graph,
            profile_store=self._profile_store,
            llm_client=self._llm,
        )
        return svc.synthesize_profile()

    def _get_node_label(self, node_id: str) -> str:
        """Get the label of a graph node, falling back to the id.

        Args:
            node_id: The graph node id.

        Returns:
            Node label string.
        """
        node = self._graph.get_graph_node(node_id)
        if node:
            return node.label[:80]
        return node_id[:16]
