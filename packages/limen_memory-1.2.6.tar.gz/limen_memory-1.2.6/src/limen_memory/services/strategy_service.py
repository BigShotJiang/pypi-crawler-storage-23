"""Strategy lifecycle management: loading, observations, feedback, LLM review."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any

from limen_memory.constants import (
    FEEDBACK_NEGATIVE_CONFIDENCE,
    FEEDBACK_POSITIVE_CONFIDENCE,
    FEEDBACK_REDIRECT_CONFIDENCE,
    FEEDBACK_SUMMARY_MAX_CHARS,
    STRATEGY_CONFIDENCE_DECAY,
    STRATEGY_DEPRECATION_THRESHOLD,
    STRATEGY_INJECTION_THRESHOLD,
)
from limen_memory.models import Strategy
from limen_memory.services.llm_client import LLMClient, LLMParseError
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.strategy_store import StrategyStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


_STRATEGY_REVIEW_SYSTEM_PROMPT = """\
You are reviewing learned interaction strategies. Evaluate each and decide on an action.

Actions:
- "promote": Increase confidence by 0.1 (strategy has proven effective)
- "decay": Decrease confidence by the decay constant (strategy is weakening)
- "remove": Mark for deprecation (only if confidence < threshold)
- "merge": Combine with another strategy (provide merge_target_id and merged_content)
- "keep": No change needed

You may also propose new strategies if you observe patterns across existing ones.

Respond with ONLY valid JSON:
{
    "actions": [
        {
            "strategy_id": "abc123",
            "action": "promote",
            "merge_target_id": null,
            "merged_content": null
        }
    ],
    "new_strategies": [
        {
            "type": "communication",
            "content": "Strategy description",
            "confidence": 0.6
        }
    ]
}
"""


class StrategyService:
    """Manages strategy lifecycle operations.

    Args:
        strategy_store: Strategy CRUD operations.
        conversation_store: Conversation and observation logging.
        llm_client: Claude CLI client for strategy review.
    """

    def __init__(
        self,
        strategy_store: StrategyStore,
        conversation_store: ConversationStore,
        llm_client: LLMClient,
    ) -> None:
        self._strategies = strategy_store
        self._conversations = conversation_store
        self._llm = llm_client

    def load_strategies_for_prompt(self) -> dict[str, list[Strategy]]:
        """Load high-confidence strategies grouped by type for prompt injection.

        Returns:
            Dictionary mapping strategy type to list of strategies.
        """
        strategies = self._strategies.get_high_confidence_strategies(
            min_confidence=STRATEGY_INJECTION_THRESHOLD
        )

        grouped: dict[str, list[Strategy]] = {}
        for strategy in strategies:
            if strategy.type not in grouped:
                grouped[strategy.type] = []
            grouped[strategy.type].append(strategy)

        logger.debug("Loaded %d strategies for prompt injection", len(strategies))
        return grouped

    def process_observations(self, observations: list[dict[str, Any]]) -> int:
        """Process strategy observations: match existing or create new strategies.

        Args:
            observations: List of observation dicts with keys:
                - "observation": str (observation text)
                - "type": str (strategy type)
                - "confidence": float

        Returns:
            Number of observations processed.
        """
        processed = 0
        now = _now_iso()

        for obs in observations:
            observation_text = obs.get("observation", "")
            obs_type = obs.get("type", "communication")
            confidence = float(obs.get("confidence", 0.5))

            if not observation_text:
                continue

            match = self._strategies.find_matching_strategy(observation_text, obs_type)

            if match:
                self._strategies.increment_strategy_observations(match.id)
                new_confidence = min(1.0, match.confidence + 0.05)
                self._strategies.update_strategy_confidence(match.id, new_confidence)
                logger.debug(
                    "Matched observation to strategy %s, boosted to %.2f",
                    match.id,
                    new_confidence,
                )
            else:
                new_strategy = Strategy(
                    id=_uid(),
                    type=obs_type,
                    content=observation_text,
                    confidence=confidence,
                    observation_count=1,
                    created_at=now,
                    updated_at=now,
                )
                self._strategies.save_strategy(new_strategy)
                logger.debug("Created new strategy %s from observation", new_strategy.id)

            processed += 1

        return processed

    def process_feedback_signal(self, feedback_type: str, message: str, response: str) -> None:
        """Process user feedback signal and create strategy observation.

        Args:
            feedback_type: Type of feedback ("positive", "negative", "redirect").
            message: User message text.
            response: Assistant response text.
        """
        feedback_mapping: dict[str, tuple[str, float, str]] = {
            "positive": (
                "communication",
                FEEDBACK_POSITIVE_CONFIDENCE,
                "Approach was effective",
            ),
            "negative": (
                "anti_pattern",
                FEEDBACK_NEGATIVE_CONFIDENCE,
                "Approach was not effective",
            ),
            "redirect": (
                "task",
                FEEDBACK_REDIRECT_CONFIDENCE,
                "User preferred different approach",
            ),
        }

        if feedback_type not in feedback_mapping:
            logger.warning("Unknown feedback type: %s", feedback_type)
            return

        strategy_type, confidence, prefix = feedback_mapping[feedback_type]

        truncated_message = message[:FEEDBACK_SUMMARY_MAX_CHARS]
        observation_text = f"{prefix}: {truncated_message}"

        observation: dict[str, Any] = {
            "observation": observation_text,
            "type": strategy_type,
            "confidence": confidence,
        }
        self.process_observations([observation])

        logger.info("Processed %s feedback signal", feedback_type)

    def review_strategies(self) -> dict[str, int]:
        """Run LLM-driven strategy review for promotion, decay, removal, and merging.

        Returns:
            Summary dict with counts: promoted, decayed, removed, merged, created.
        """
        summary: dict[str, int] = {
            "promoted": 0,
            "decayed": 0,
            "removed": 0,
            "merged": 0,
            "created": 0,
        }

        strategies = self._strategies.get_all_strategies(include_deprecated=False)
        if not strategies:
            logger.info("No active strategies to review")
            return summary

        prompt = self._build_review_prompt(strategies)

        try:
            response = self._llm.prompt_json(prompt, _STRATEGY_REVIEW_SYSTEM_PROMPT)
        except LLMParseError as exc:
            logger.error("Strategy review LLM call failed: %s", exc)
            return summary
        except Exception as exc:
            logger.error("Unexpected error during strategy review: %s", exc)
            return summary

        self._apply_review_actions(response.get("actions", []), summary)
        self._create_review_strategies(response.get("new_strategies", []), summary)

        logger.info(
            "Strategy review complete: %d promoted, %d decayed, %d removed, %d merged, %d created",
            summary["promoted"],
            summary["decayed"],
            summary["removed"],
            summary["merged"],
            summary["created"],
        )
        return summary

    def _apply_review_actions(self, actions: list[dict[str, Any]], summary: dict[str, int]) -> None:
        """Apply LLM review actions to strategies.

        Args:
            actions: List of action dicts from LLM.
            summary: Running summary dict to update in place.
        """
        for action_item in actions:
            strategy_id = action_item.get("strategy_id")
            action = action_item.get("action")

            if not strategy_id or not action:
                continue

            strategy = self._strategies.get_strategy(strategy_id)
            if not strategy:
                logger.warning("Strategy %s not found for action %s", strategy_id, action)
                continue

            if action == "promote":
                new_confidence = min(1.0, strategy.confidence + 0.1)
                self._strategies.update_strategy_confidence(strategy_id, new_confidence)
                summary["promoted"] += 1

            elif action == "decay":
                new_confidence = max(0.0, strategy.confidence - STRATEGY_CONFIDENCE_DECAY)
                self._strategies.update_strategy_confidence(strategy_id, new_confidence)
                summary["decayed"] += 1

            elif action == "remove":
                if strategy.confidence < STRATEGY_DEPRECATION_THRESHOLD:
                    self._strategies.deprecate_strategy(strategy_id)
                    summary["removed"] += 1
                else:
                    logger.debug(
                        "Skipped removal of %s (confidence %.2f above threshold)",
                        strategy_id,
                        strategy.confidence,
                    )

            elif action == "merge":
                merge_target_id = action_item.get("merge_target_id")
                merged_content = action_item.get("merged_content")

                if not merge_target_id or not merged_content:
                    logger.warning(
                        "Merge action for %s missing target_id or merged_content",
                        strategy_id,
                    )
                    continue

                target = self._strategies.get_strategy(merge_target_id)
                if not target:
                    logger.warning("Merge target %s not found", merge_target_id)
                    continue

                self._strategies.merge_strategies(strategy_id, merge_target_id, merged_content)
                summary["merged"] += 1

            elif action == "keep":
                pass
            else:
                logger.warning("Unknown action: %s", action)

    def _create_review_strategies(
        self, new_strategies: list[dict[str, Any]], summary: dict[str, int]
    ) -> None:
        """Create new strategies proposed during review.

        Args:
            new_strategies: List of new strategy dicts from LLM.
            summary: Running summary dict to update in place.
        """
        now = _now_iso()
        for new_strat_data in new_strategies:
            strategy_type = new_strat_data.get("type", "communication")
            content = new_strat_data.get("content", "")
            confidence = float(new_strat_data.get("confidence", 0.5))

            if not content:
                continue

            new_strategy = Strategy(
                id=_uid(),
                type=strategy_type,
                content=content,
                confidence=confidence,
                observation_count=0,
                created_at=now,
                updated_at=now,
            )
            self._strategies.save_strategy(new_strategy)
            summary["created"] += 1
            logger.debug("Created new strategy %s from review", new_strategy.id)

    def _build_review_prompt(self, strategies: list[Strategy]) -> str:
        """Build the LLM prompt for strategy review.

        Args:
            strategies: List of active strategies to review.

        Returns:
            Complete prompt string.
        """
        lines = ["Review the following strategies and decide on actions:\n"]

        for strategy in strategies:
            lines.append(
                f"\n- ID: {strategy.id}\n"
                f"  Type: {strategy.type}\n"
                f"  Content: {strategy.content}\n"
                f"  Confidence: {strategy.confidence:.2f}\n"
                f"  Observations: {strategy.observation_count}"
            )

        lines.append(
            f"\n\nDeprecation threshold: {STRATEGY_DEPRECATION_THRESHOLD}\n"
            f"Confidence decay: {STRATEGY_CONFIDENCE_DECAY}\n"
        )

        return "".join(lines)
