"""Ollama local embedding provider."""

from __future__ import annotations

from typing import Any

from limen_memory.constants import EMBEDDING_TIMEOUT_SECONDS
from limen_memory.services.embedding._base import BaseEmbeddingClient


class OllamaEmbeddingClient(BaseEmbeddingClient):
    """Embedding provider using a local Ollama instance.

    No API key required — connects to Ollama's HTTP API.

    Args:
        model: Ollama model name (e.g. ``nomic-embed-text``).
        dimensions: Expected embedding dimensions.
        base_url: Ollama server URL (default ``http://localhost:11434``).
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        model: str,
        dimensions: int,
        base_url: str = "http://localhost:11434",
        timeout: int = EMBEDDING_TIMEOUT_SECONDS,
    ) -> None:
        super().__init__(model=model, dimensions=dimensions, timeout=timeout)
        try:
            import ollama  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "ollama package required for Ollama embeddings. "
                "Install with: pip install limen[ollama]"
            ) from exc
        self._client: Any = ollama.Client(host=base_url, timeout=float(timeout))

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Call Ollama embed endpoint.

        Args:
            texts: Batch of texts to embed.

        Returns:
            List of float lists from the Ollama response.
        """
        response = self._client.embed(model=self._model, input=texts)
        return response["embeddings"]  # type: ignore[no-any-return]
