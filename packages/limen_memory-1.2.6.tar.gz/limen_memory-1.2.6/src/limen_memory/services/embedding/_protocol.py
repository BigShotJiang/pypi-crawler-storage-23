"""Structural protocol for embedding providers.

Consumer code should type-hint against ``EmbeddingClientProtocol`` so it
remains provider-agnostic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import numpy as np


@runtime_checkable
class EmbeddingClientProtocol(Protocol):
    """Structural interface that all embedding providers satisfy."""

    def embed_texts(self, texts: list[str]) -> list[np.ndarray]:
        """Embed a batch of texts.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of numpy float32 arrays, one per input text.
        """
        ...

    def embed_single(self, text: str) -> np.ndarray:
        """Embed a single text string.

        Args:
            text: Text to embed.

        Returns:
            Numpy float32 array.
        """
        ...
