"""Configurable embedding providers for limen."""

from limen_memory.services.embedding._base import BaseEmbeddingClient
from limen_memory.services.embedding._protocol import EmbeddingClientProtocol
from limen_memory.services.embedding.factory import create_embedding_client

__all__ = [
    "BaseEmbeddingClient",
    "EmbeddingClientProtocol",
    "create_embedding_client",
]
