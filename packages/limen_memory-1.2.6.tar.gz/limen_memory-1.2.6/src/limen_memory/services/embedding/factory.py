"""Factory for creating embedding clients from configuration."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from limen_memory.constants import EMBEDDING_PROVIDER_DEFAULTS
from limen_memory.services.embedding._base import BaseEmbeddingClient

if TYPE_CHECKING:
    from limen_memory.config import LimenConfig

logger = logging.getLogger(__name__)


def create_embedding_client(config: LimenConfig) -> BaseEmbeddingClient | None:
    """Create an embedding client based on configuration.

    Returns ``None`` when no provider is configured (no API key for
    cloud providers, or no provider specified).

    Args:
        config: Limen configuration with embedding fields.

    Returns:
        Configured embedding client, or ``None``.

    Raises:
        ValueError: If ``embedding_provider`` is not a recognized value.
    """
    provider = config.embedding_provider
    if not provider:
        return None

    api_key = config.embedding_api_key
    defaults = EMBEDDING_PROVIDER_DEFAULTS.get(provider, {})
    model = config.embedding_model or str(defaults.get("model", ""))
    dimensions = config.embedding_dimensions or int(defaults.get("dimensions", 1024))

    if provider == "openai":
        if not api_key:
            logger.warning("OpenAI provider selected but no API key configured")
            return None
        from limen_memory.services.embedding.openai import OpenAIEmbeddingClient

        return OpenAIEmbeddingClient(api_key=api_key, model=model, dimensions=dimensions)

    if provider == "ollama":
        from limen_memory.services.embedding.ollama import OllamaEmbeddingClient

        base_url = config.embedding_base_url or "http://localhost:11434"
        return OllamaEmbeddingClient(model=model, dimensions=dimensions, base_url=base_url)

    raise ValueError(f"Unknown embedding provider: {provider!r}. Supported: openai, ollama")
