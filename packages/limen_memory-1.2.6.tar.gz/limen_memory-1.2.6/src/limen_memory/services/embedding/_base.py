"""Abstract base class for embedding providers with shared batching logic."""

from __future__ import annotations

import abc
import logging

import numpy as np

from limen_memory.constants import EMBEDDING_BATCH_SIZE, EMBEDDING_TIMEOUT_SECONDS

logger = logging.getLogger(__name__)


class BaseEmbeddingClient(abc.ABC):
    """Base class for embedding providers.

    Subclasses implement ``_embed_batch`` only. Batching, numpy conversion,
    and the ``embed_single`` convenience method are handled here.

    Args:
        model: Provider-specific model name.
        dimensions: Expected embedding dimensions.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        model: str,
        dimensions: int,
        timeout: int = EMBEDDING_TIMEOUT_SECONDS,
    ) -> None:
        self._model = model
        self._dimensions = dimensions
        self._timeout = timeout

    @abc.abstractmethod
    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Provider-specific batch embedding.

        Args:
            texts: Batch of texts (length <= EMBEDDING_BATCH_SIZE).

        Returns:
            List of raw float lists, one per input text.
        """

    def embed_texts(self, texts: list[str]) -> list[np.ndarray]:
        """Embed one or more texts with automatic batching.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of numpy arrays (float32), one per input text.
        """
        if not texts:
            return []

        all_embeddings: list[np.ndarray] = []
        for i in range(0, len(texts), EMBEDDING_BATCH_SIZE):
            batch = texts[i : i + EMBEDDING_BATCH_SIZE]
            logger.debug("Embedding batch %d-%d of %d", i, i + len(batch), len(texts))
            raw = self._embed_batch(batch)
            for vec in raw:
                all_embeddings.append(np.array(vec, dtype=np.float32))

        return all_embeddings

    def embed_single(self, text: str) -> np.ndarray:
        """Embed a single text string.

        Args:
            text: Text to embed.

        Returns:
            Numpy array (float32) of shape (dimensions,).
        """
        return self.embed_texts([text])[0]

    def validate_connection(self, timeout: int = 5) -> bool:
        """Test embedding connectivity with a short probe.

        Calls ``embed_single("test")`` to verify the provider is reachable.
        Uses the instance timeout or *timeout* (whichever is smaller) so the
        probe doesn't block startup for long.

        Args:
            timeout: Maximum seconds for the probe (default 5).

        Returns:
            ``True`` if the provider responded successfully, ``False`` otherwise.
        """
        original_timeout = self._timeout
        self._timeout = min(original_timeout, timeout)
        try:
            result = self.embed_single("test")
            return len(result) > 0
        except Exception as exc:
            logger.warning("Embedding connectivity check failed: %s", exc)
            return False
        finally:
            self._timeout = original_timeout
