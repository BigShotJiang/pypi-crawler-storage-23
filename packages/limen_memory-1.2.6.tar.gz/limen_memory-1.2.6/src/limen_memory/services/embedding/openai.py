"""OpenAI embedding provider."""

from __future__ import annotations

from typing import Any

from limen_memory.constants import EMBEDDING_TIMEOUT_SECONDS
from limen_memory.services.embedding._base import BaseEmbeddingClient


class OpenAIEmbeddingClient(BaseEmbeddingClient):
    """Embedding provider using the OpenAI API.

    Supports ``text-embedding-3-small`` and ``text-embedding-3-large``.

    Args:
        api_key: OpenAI API key.
        model: OpenAI model name (e.g. ``text-embedding-3-small``).
        dimensions: Embedding dimensions (OpenAI supports per-request override).
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        dimensions: int,
        timeout: int = EMBEDDING_TIMEOUT_SECONDS,
    ) -> None:
        super().__init__(model=model, dimensions=dimensions, timeout=timeout)
        try:
            import openai  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "openai package required for OpenAI embeddings. "
                "Install with: pip install limen[openai]"
            ) from exc
        self._client: Any = openai.OpenAI(api_key=api_key, timeout=float(timeout))

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Call OpenAI embeddings endpoint.

        Args:
            texts: Batch of texts to embed.

        Returns:
            List of float lists from the OpenAI API response.
        """
        response = self._client.embeddings.create(
            input=texts,
            model=self._model,
            dimensions=self._dimensions,
        )
        return [item.embedding for item in response.data]
