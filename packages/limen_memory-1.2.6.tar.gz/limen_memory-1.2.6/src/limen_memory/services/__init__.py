"""Service layer for limen."""

from limen_memory.services.consolidation import ConsolidationService
from limen_memory.services.context_loader import ContextLoader
from limen_memory.services.embedding import (
    BaseEmbeddingClient,
    EmbeddingClientProtocol,
    create_embedding_client,
)
from limen_memory.services.keyword_extractor import extract_keywords
from limen_memory.services.llm_client import LLMClient, LLMParseError
from limen_memory.services.novelty_filter import NoveltyFilter
from limen_memory.services.reflection import ReflectionService
from limen_memory.services.scheduler import Scheduler
from limen_memory.services.strategy_service import StrategyService

__all__ = [
    "BaseEmbeddingClient",
    "ConsolidationService",
    "ContextLoader",
    "EmbeddingClientProtocol",
    "LLMClient",
    "LLMParseError",
    "NoveltyFilter",
    "ReflectionService",
    "Scheduler",
    "StrategyService",
    "create_embedding_client",
    "extract_keywords",
]
