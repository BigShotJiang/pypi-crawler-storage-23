"""Knowledge graph operations: nodes, edges, BFS traversal, aging, diagnostics."""

from __future__ import annotations

import logging
import math
from collections import deque
from datetime import datetime, timedelta

from limen_memory.constants import (
    BASE_CONFIDENCE_STEP,
    CONFIDENCE_MOMENTUM,
    EDGE_DECAY_HALF_LIFE,
    EDGE_DEPRECATION_THRESHOLD,
    EVALUATIVE_STALENESS_DAYS,
    GRAPH_DISCOVERED_CAP,
    GRAPH_WEIGHTS,
    PREDICTION_DECAY_HIT_RATE_THRESHOLD,
    PREDICTION_EDGE_DECAY_HALF_LIFE,
    PREDICTION_STALENESS_DAYS,
)
from limen_memory.models import GraphDiagnostics, GraphEdge, GraphNode
from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class GraphStore:
    """Knowledge graph node and edge operations.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    # --- Nodes ---

    def register_graph_node(self, node: GraphNode) -> None:
        """Register a graph node (INSERT OR IGNORE).

        Args:
            node: The graph node to register.
        """
        self._db.execute_write(
            """INSERT OR IGNORE INTO graph_nodes
               (id, node_type, label, source_table, created_at, updated_at, deprecated, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                node.id,
                node.node_type,
                node.label,
                node.source_table,
                node.created_at,
                node.updated_at,
                int(node.deprecated),
                node.metadata_json,
            ),
        )

    def deprecate_graph_node(self, node_id: str) -> bool:
        """Deprecate a graph node.

        Args:
            node_id: The node id.

        Returns:
            True if a row was updated.
        """
        cursor = self._db.execute_write(
            "UPDATE graph_nodes SET deprecated = 1, updated_at = ? WHERE id = ? AND deprecated = 0",
            (_now_iso(), node_id),
        )
        return cursor.rowcount > 0

    def get_graph_node(self, node_id: str) -> GraphNode | None:
        """Get a graph node by id.

        Args:
            node_id: The node id.

        Returns:
            The graph node or None.
        """
        row = self._db.execute_read_one("SELECT * FROM graph_nodes WHERE id = ?", (node_id,))
        return GraphNode.from_row(row) if row else None

    # --- Edges ---

    def save_relationship(self, edge: GraphEdge) -> str:
        """Save or update an edge (upsert, keep higher confidence on conflict).

        Args:
            edge: The graph edge to save.

        Returns:
            The edge id.
        """
        self._db.execute_write(
            """INSERT INTO graph_edges
               (id, source_id, target_id, source_type, target_type, relationship_type,
                edge_category, confidence, evidence, created_at, last_validated_at,
                deprecated, prediction_count, prediction_hits, momentum)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(source_id, target_id, relationship_type)
                   WHERE deprecated = 0
               DO UPDATE SET
                   confidence = MAX(excluded.confidence, graph_edges.confidence),
                   evidence = excluded.evidence,
                   last_validated_at = excluded.last_validated_at""",
            (
                edge.id,
                edge.source_id,
                edge.target_id,
                edge.source_type,
                edge.target_type,
                edge.relationship_type,
                edge.edge_category,
                edge.confidence,
                edge.evidence,
                edge.created_at,
                edge.last_validated_at,
                int(edge.deprecated),
                edge.prediction_count,
                edge.prediction_hits,
                edge.momentum,
            ),
        )
        return edge.id

    def get_relationships_for_reflections(self, reflection_ids: list[str]) -> list[GraphEdge]:
        """Get all active edges involving any of the given reflection ids.

        Args:
            reflection_ids: List of reflection ids.

        Returns:
            List of graph edges.
        """
        if not reflection_ids:
            return []
        placeholders = ", ".join("?" for _ in reflection_ids)
        rows = self._db.execute_read(
            f"""SELECT * FROM graph_edges
                WHERE deprecated = 0
                  AND (source_id IN ({placeholders})
                       OR target_id IN ({placeholders}))""",  # nosec B608
            tuple(reflection_ids) + tuple(reflection_ids),
        )
        return [GraphEdge.from_row(r) for r in rows]

    def get_edge_annotations_for_reflections(
        self, reflection_ids: list[str], max_per: int = 2
    ) -> dict[str, list[GraphEdge]]:
        """Get top edges per reflection, grouped by reflection id.

        Args:
            reflection_ids: List of reflection ids.
            max_per: Maximum edges per reflection.

        Returns:
            Dict mapping reflection_id to list of edges.
        """
        if not reflection_ids:
            return {}

        all_edges = self.get_relationships_for_reflections(reflection_ids)

        result: dict[str, list[GraphEdge]] = {rid: [] for rid in reflection_ids}
        for edge in sorted(all_edges, key=lambda e: e.confidence, reverse=True):
            if edge.source_id in result and len(result[edge.source_id]) < max_per:
                result[edge.source_id].append(edge)
            if edge.target_id in result and len(result[edge.target_id]) < max_per:
                if edge not in result[edge.target_id]:
                    result[edge.target_id].append(edge)

        return result

    def get_connected_reflections(
        self,
        seed_ids: list[str],
        max_hops: int = 1,
        min_confidence: float = 0.4,
    ) -> list[tuple[str, float]]:
        """BFS traversal from seed nodes, scoring discovered nodes.

        Score = weight(relationship_type) * edge_confidence * (1 / hop_distance)

        Args:
            seed_ids: Starting node ids.
            max_hops: Maximum traversal depth.
            min_confidence: Minimum edge confidence for traversal.

        Returns:
            List of (node_id, score) sorted by score descending, capped at GRAPH_DISCOVERED_CAP.
        """
        if not seed_ids:
            return []

        visited: set[str] = set(seed_ids)
        scores: dict[str, float] = {}
        queue: deque[tuple[str, int]] = deque((sid, 0) for sid in seed_ids)

        while queue:
            current_id, current_hop = queue.popleft()
            if current_hop >= max_hops:
                continue

            next_hop = current_hop + 1
            edges = self._get_active_edges_for_node(current_id, min_confidence)

            for edge in edges:
                neighbor = edge.target_id if edge.source_id == current_id else edge.source_id
                if neighbor in visited:
                    continue

                weight = GRAPH_WEIGHTS.get(edge.relationship_type, 0.5)
                score = weight * edge.confidence * (1.0 / next_hop)

                if neighbor in scores:
                    scores[neighbor] = max(scores[neighbor], score)
                else:
                    scores[neighbor] = score

                visited.add(neighbor)
                queue.append((neighbor, next_hop))

        sorted_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return sorted_results[:GRAPH_DISCOVERED_CAP]

    def _get_active_edges_for_node(self, node_id: str, min_confidence: float) -> list[GraphEdge]:
        """Get active edges for a specific node above confidence threshold.

        Args:
            node_id: The node id.
            min_confidence: Minimum edge confidence.

        Returns:
            List of graph edges.
        """
        rows = self._db.execute_read(
            """SELECT * FROM graph_edges
               WHERE deprecated = 0
                 AND confidence >= ?
                 AND (source_id = ? OR target_id = ?)""",
            (min_confidence, node_id, node_id),
        )
        return [GraphEdge.from_row(r) for r in rows]

    def get_contradiction_edges(
        self, reflection_ids: list[str], min_confidence: float = 0.4
    ) -> list[GraphEdge]:
        """Get contradiction edges between loaded reflections.

        Args:
            reflection_ids: List of reflection ids (both source and target must be in this list).
            min_confidence: Minimum edge confidence.

        Returns:
            List of contradiction edges.
        """
        if not reflection_ids:
            return []
        placeholders = ", ".join("?" for _ in reflection_ids)
        rows = self._db.execute_read(
            f"""SELECT * FROM graph_edges
                WHERE relationship_type = 'contradicts'
                  AND deprecated = 0
                  AND confidence >= ?
                  AND source_id IN ({placeholders})
                  AND target_id IN ({placeholders})""",  # nosec B608
            (min_confidence,) + tuple(reflection_ids) + tuple(reflection_ids),
        )
        return [GraphEdge.from_row(r) for r in rows]

    def get_prediction_edges(self, limit: int = 10, min_confidence: float = 0.4) -> list[GraphEdge]:
        """Get active prediction edges above a confidence threshold.

        Args:
            limit: Maximum edges to return.
            min_confidence: Minimum edge confidence.

        Returns:
            List of prediction edges sorted by confidence descending.
        """
        rows = self._db.execute_read(
            """SELECT * FROM graph_edges
               WHERE relationship_type = 'predicts'
                 AND deprecated = 0
                 AND confidence >= ?
               ORDER BY confidence DESC
               LIMIT ?""",
            (min_confidence, limit),
        )
        return [GraphEdge.from_row(r) for r in rows]

    def get_unvalidated_working_memory_edges(self, limit: int = 50) -> list[GraphEdge]:
        """Get active edges with Working memory similarity evidence prefix.

        These are provisional edges created during reflection that have not
        yet been validated by the consolidation service.

        Args:
            limit: Maximum edges.

        Returns:
            List of unvalidated working memory edges.
        """
        from limen_memory.constants import WORKING_MEMORY_EVIDENCE_PREFIX

        rows = self._db.execute_read(
            "SELECT * FROM graph_edges WHERE deprecated = 0 "
            "AND evidence LIKE ? ORDER BY created_at ASC LIMIT ?",
            (f"{WORKING_MEMORY_EVIDENCE_PREFIX}%", limit),
        )
        return [GraphEdge.from_row(r) for r in rows]

    def update_edge_confidence(self, edge_id: str, confidence: float) -> None:
        """Update an edge's confidence and validation timestamp.

        Args:
            edge_id: The edge id.
            confidence: New confidence value (clamped 0.0-1.0).
        """
        clamped = max(0.0, min(1.0, confidence))
        self._db.execute_write(
            "UPDATE graph_edges SET confidence = ?, last_validated_at = ? WHERE id = ?",
            (clamped, _now_iso(), edge_id),
        )

    def update_edge_evidence(self, edge_id: str, evidence: str) -> None:
        """Update an edge's evidence string and validation timestamp.

        Used to mark working memory edges as validated by replacing the
        provisional evidence prefix.

        Args:
            edge_id: The edge id.
            evidence: New evidence text.
        """
        self._db.execute_write(
            "UPDATE graph_edges SET evidence = ?, last_validated_at = ? WHERE id = ?",
            (evidence, _now_iso(), edge_id),
        )

    def deprecate_edge(self, edge_id: str) -> bool:
        """Soft-delete a single edge.

        Args:
            edge_id: The edge id.

        Returns:
            True if deprecated.
        """
        cursor = self._db.execute_write(
            "UPDATE graph_edges SET deprecated = 1 WHERE id = ? AND deprecated = 0",
            (edge_id,),
        )
        return cursor.rowcount > 0

    # --- Aging ---

    def age_relationships(self) -> int:
        """Age edges using time-continuous exponential confidence decay.

        Decay is computed as a function of elapsed time since validation,
        not per-tick multiplication. This decouples behavior from scheduler
        frequency: confidence = original * exp(-days_stale / half_life).

        Returns:
            Total number of edges affected.
        """
        now = datetime.utcnow()
        total = 0

        # Evaluative edges: continuous decay after EVALUATIVE_STALENESS_DAYS
        cutoff = (now - timedelta(days=EVALUATIVE_STALENESS_DAYS)).isoformat()
        stale_rows = self._db.execute_read(
            """SELECT id, confidence, last_validated_at FROM graph_edges
               WHERE deprecated = 0
                 AND edge_category = 'evaluative'
                 AND last_validated_at < ?""",
            (cutoff,),
        )
        for row in stale_rows:
            try:
                validated_at = datetime.fromisoformat(row["last_validated_at"])
                days_stale = (now - validated_at).days - EVALUATIVE_STALENESS_DAYS
            except (ValueError, TypeError):
                days_stale = EVALUATIVE_STALENESS_DAYS
            if days_stale > 0:
                new_conf = float(row["confidence"]) * math.exp(-days_stale / EDGE_DECAY_HALF_LIFE)
                self._db.execute_write(
                    "UPDATE graph_edges SET confidence = ?, last_validated_at = ? WHERE id = ?",
                    (new_conf, cutoff, row["id"]),
                )
                total += 1

        # Prediction edges: continuous decay if stale AND low hit rate
        cutoff = (now - timedelta(days=PREDICTION_STALENESS_DAYS)).isoformat()
        pred_rows = self._db.execute_read(
            """SELECT id, confidence, last_validated_at, prediction_count, prediction_hits
               FROM graph_edges
               WHERE deprecated = 0
                 AND edge_category = 'causal'
                 AND relationship_type = 'predicts'
                 AND last_validated_at < ?
                 AND prediction_count > 0""",
            (cutoff,),
        )
        for row in pred_rows:
            hit_rate = float(row["prediction_hits"]) / float(row["prediction_count"])
            if hit_rate < PREDICTION_DECAY_HIT_RATE_THRESHOLD:
                try:
                    validated_at = datetime.fromisoformat(row["last_validated_at"])
                    days_stale = (now - validated_at).days - PREDICTION_STALENESS_DAYS
                except (ValueError, TypeError):
                    days_stale = PREDICTION_STALENESS_DAYS
                if days_stale > 0:
                    new_conf = float(row["confidence"]) * math.exp(
                        -days_stale / PREDICTION_EDGE_DECAY_HALF_LIFE
                    )
                    self._db.execute_write(
                        "UPDATE graph_edges SET confidence = ?, last_validated_at = ? WHERE id = ?",
                        (new_conf, cutoff, row["id"]),
                    )
                    total += 1

        # Deprecate edges below threshold
        cursor = self._db.execute_write(
            """UPDATE graph_edges SET deprecated = 1
               WHERE deprecated = 0 AND confidence < ?""",
            (EDGE_DEPRECATION_THRESHOLD,),
        )
        total += cursor.rowcount

        if total > 0:
            logger.info("Aged %d graph edges", total)
        return total

    def record_prediction_outcome(self, edge_id: str, success: bool) -> None:
        """Record a prediction outcome with momentum-based confidence update.

        Uses exponential moving average momentum so consistent evidence
        accelerates confidence while oscillating evidence stalls it:
        momentum = eta * prev_momentum + (1-eta) * direction
        delta = |momentum| * BASE_CONFIDENCE_STEP * sign(momentum)

        Args:
            edge_id: The edge id.
            success: Whether the prediction was correct.
        """
        now = _now_iso()
        direction = 1.0 if success else -1.0

        # Read current momentum
        row = self._db.execute_read_one(
            "SELECT confidence, momentum FROM graph_edges WHERE id = ?", (edge_id,)
        )
        if row is None:
            return

        prev_momentum = float(row.get("momentum", 0.0) or 0.0)
        current_confidence = float(row["confidence"])

        # Compute new momentum (exponential moving average of direction)
        new_momentum = CONFIDENCE_MOMENTUM * prev_momentum + (1.0 - CONFIDENCE_MOMENTUM) * direction

        # Confidence delta scales with momentum magnitude
        confidence_delta = abs(new_momentum) * BASE_CONFIDENCE_STEP
        if new_momentum < 0:
            confidence_delta = -confidence_delta

        new_confidence = max(0.0, min(1.0, current_confidence + confidence_delta))

        hits_increment = 1 if success else 0
        self._db.execute_write(
            """UPDATE graph_edges
                SET prediction_count = prediction_count + 1,
                    prediction_hits = prediction_hits + ?,
                    confidence = ?,
                    momentum = ?,
                    last_validated_at = ?
                WHERE id = ?""",
            (hits_increment, new_confidence, new_momentum, now, edge_id),
        )

    def deprecate_orphaned_relationships(self) -> int:
        """Deprecate edges referencing deprecated nodes.

        Returns:
            Number of edges deprecated.
        """
        cursor = self._db.execute_write(
            """UPDATE graph_edges SET deprecated = 1
               WHERE deprecated = 0
                 AND (source_id IN (SELECT id FROM graph_nodes WHERE deprecated = 1)
                      OR target_id IN (SELECT id FROM graph_nodes WHERE deprecated = 1))"""
        )
        count = cursor.rowcount
        if count > 0:
            logger.info("Deprecated %d orphaned edges", count)
        return count

    def remap_edges(self, old_id: str, new_id: str) -> int:
        """Re-point active edges from *old_id* to *new_id*.

        Used during consolidation to migrate edges from deprecated
        reflections to their merged replacement.

        Args:
            old_id: The deprecated node id to remap away from.
            new_id: The replacement node id to remap to.

        Returns:
            Total number of edge rows updated.
        """
        now = _now_iso()
        cursor_src = self._db.execute_write(
            "UPDATE graph_edges SET source_id = ?, last_validated_at = ? "
            "WHERE source_id = ? AND deprecated = 0",
            (new_id, now, old_id),
        )
        cursor_tgt = self._db.execute_write(
            "UPDATE graph_edges SET target_id = ?, last_validated_at = ? "
            "WHERE target_id = ? AND deprecated = 0",
            (new_id, now, old_id),
        )
        total = cursor_src.rowcount + cursor_tgt.rowcount
        if total > 0:
            logger.info("Remapped %d edges from %s to %s", total, old_id[:8], new_id[:8])
        return total

    def count_quality_edges(self, node_id: str, min_confidence: float = 0.4) -> int:
        """Count active edges for a node above a confidence threshold.

        Only counts non-deprecated edges where confidence exceeds
        *min_confidence*. Used by hybrid search to compute a
        quality-weighted graph score.

        Args:
            node_id: The graph node id.
            min_confidence: Minimum edge confidence to count.

        Returns:
            Number of qualifying edges.
        """
        row = self._db.execute_read_one(
            """SELECT COUNT(*) as cnt FROM graph_edges
               WHERE (source_id = ? OR target_id = ?) AND deprecated = 0
                 AND confidence >= ?""",
            (node_id, node_id, min_confidence),
        )
        return int(row["cnt"]) if row else 0

    # --- Diagnostics ---

    def get_graph_diagnostics(self) -> GraphDiagnostics:
        """Get comprehensive graph diagnostics.

        Returns:
            GraphDiagnostics with counts, orphans, avg confidence, most connected.
        """
        total_nodes = self._db.table_count("graph_nodes")
        active_nodes = self._db.table_count("graph_nodes", "deprecated = 0")
        total_edges = self._db.table_count("graph_edges")
        active_edges = self._db.table_count("graph_edges", "deprecated = 0")

        # Orphan nodes: active nodes with no active edges
        orphan_row = self._db.execute_read_one(
            """SELECT COUNT(*) as cnt FROM graph_nodes
               WHERE deprecated = 0
                 AND id NOT IN (
                     SELECT source_id FROM graph_edges WHERE deprecated = 0
                     UNION
                     SELECT target_id FROM graph_edges WHERE deprecated = 0
                 )"""
        )
        orphan_nodes = int(orphan_row["cnt"]) if orphan_row else 0

        # Average edge confidence
        avg_row = self._db.execute_read_one(
            "SELECT AVG(confidence) as avg_conf FROM graph_edges WHERE deprecated = 0"
        )
        avg_confidence = float(avg_row["avg_conf"]) if avg_row and avg_row["avg_conf"] else 0.0

        # Most connected nodes (top 5)
        connected_rows = self._db.execute_read(
            """SELECT n.id, n.label, COUNT(*) as edge_count
               FROM graph_nodes n
               JOIN (
                   SELECT source_id as nid FROM graph_edges WHERE deprecated = 0
                   UNION ALL
                   SELECT target_id as nid FROM graph_edges WHERE deprecated = 0
               ) e ON n.id = e.nid
               WHERE n.deprecated = 0
               GROUP BY n.id, n.label
               ORDER BY edge_count DESC
               LIMIT 5"""
        )
        most_connected = [
            {"id": r["id"], "label": r["label"], "edge_count": r["edge_count"]}
            for r in connected_rows
        ]

        return GraphDiagnostics(
            total_nodes=total_nodes,
            active_nodes=active_nodes,
            total_edges=total_edges,
            active_edges=active_edges,
            orphan_nodes=orphan_nodes,
            avg_edge_confidence=avg_confidence,
            most_connected_nodes=most_connected,
        )
