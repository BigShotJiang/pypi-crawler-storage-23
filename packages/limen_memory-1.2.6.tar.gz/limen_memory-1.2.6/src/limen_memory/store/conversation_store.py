"""Conversation tracking, FTS5 search, and audit logging."""

from __future__ import annotations

import logging
from datetime import datetime

from limen_memory.models import Conversation, ConversationSummary
from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class ConversationStore:
    """CRUD operations for conversations, summaries, and audit logs.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    # --- Conversations ---

    def save_conversation(self, conv: Conversation) -> str:
        """Save or update a conversation.

        Args:
            conv: The conversation to save.

        Returns:
            The conversation id.
        """
        self._db.execute_write(
            """INSERT OR REPLACE INTO conversations
               (id, title, created_at, updated_at, status, summary, keywords)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                conv.id,
                conv.title,
                conv.created_at,
                conv.updated_at,
                conv.status,
                conv.summary,
                conv.keywords_json,
            ),
        )
        self._register_graph_node(
            node_id=conv.id,
            node_type="conversation",
            label=conv.title or conv.id,
            source_table="conversations",
        )
        return conv.id

    # --- Summaries ---

    def save_summary(self, summary: ConversationSummary) -> str:
        """Save a conversation summary and index it for FTS.

        Args:
            summary: The summary to save.

        Returns:
            The summary id.
        """
        self._db.execute_write(
            """INSERT INTO conversation_summaries
               (id, conversation_id, summary, keywords, key_topics,
                status_markers, pending_items, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                summary.id,
                summary.conversation_id,
                summary.summary,
                summary.keywords,
                summary.key_topics,
                summary.status_markers,
                summary.pending_items,
                summary.created_at,
            ),
        )
        # Index in FTS
        self._db.execute_write(
            """INSERT INTO conversations_fts (conversation_id, summary, keywords)
               VALUES (?, ?, ?)""",
            (summary.conversation_id, summary.summary, summary.keywords),
        )
        return summary.id

    def search_fts(self, query: str, limit: int = 10) -> list[ConversationSummary]:
        """Search conversation summaries using FTS5.

        Args:
            query: The search query.
            limit: Maximum results.

        Returns:
            List of matching summaries.
        """
        rows = self._db.execute_read(
            """SELECT cs.* FROM conversations_fts fts
               JOIN conversation_summaries cs
                 ON fts.conversation_id = cs.conversation_id
               WHERE conversations_fts MATCH ?
               LIMIT ?""",
            (query, limit),
        )
        return [ConversationSummary.from_row(r) for r in rows]

    def get_recent_summaries(self, limit: int = 5) -> list[ConversationSummary]:
        """Get the most recent conversation summaries.

        Args:
            limit: Maximum results.

        Returns:
            List of summaries, most recent first.
        """
        rows = self._db.execute_read(
            "SELECT * FROM conversation_summaries ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [ConversationSummary.from_row(r) for r in rows]

    def search_summaries_by_keywords(self, keywords: list[str]) -> list[ConversationSummary]:
        """Search summaries by keyword matching in keywords and summary fields.

        Args:
            keywords: Keywords to search for.

        Returns:
            List of matching summaries.
        """
        if not keywords:
            return []

        conditions: list[str] = []
        params: list[str] = []
        for kw in keywords:
            conditions.append("(LOWER(keywords) LIKE ? OR LOWER(summary) LIKE ?)")
            params.extend([f"%{kw.lower()}%", f"%{kw.lower()}%"])

        where = " OR ".join(conditions)
        rows = self._db.execute_read(
            f"""SELECT * FROM conversation_summaries
                WHERE {where}
                ORDER BY created_at DESC""",  # nosec B608
            tuple(params),
        )
        return [ConversationSummary.from_row(r) for r in rows]

    def count_observations_since(self, since: str) -> int:
        """Count strategy observations recorded after a timestamp.

        Args:
            since: ISO timestamp lower bound.

        Returns:
            Number of observations since the given time.
        """
        row = self._db.execute_read_one(
            "SELECT COUNT(*) as cnt FROM strategy_observations WHERE timestamp > ?",
            (since,),
        )
        return int(row["cnt"]) if row else 0

    def count_conversations_since(self, since: str) -> int:
        """Count conversations created after a timestamp.

        Args:
            since: ISO timestamp lower bound.

        Returns:
            Number of conversations since the given time.
        """
        row = self._db.execute_read_one(
            "SELECT COUNT(*) as cnt FROM conversations WHERE created_at > ?",
            (since,),
        )
        return int(row["cnt"]) if row else 0

    # --- Logging ---

    def save_novelty_log(
        self,
        log_id: str,
        timestamp: str,
        conversation_id: str,
        candidate_text: str,
        novelty_score: float,
        reasoning: str,
        contradicts: str,
        accepted: bool,
        method: str,
    ) -> None:
        """Log a novelty evaluation result.

        Args:
            log_id: Unique log entry id.
            timestamp: ISO timestamp.
            conversation_id: The conversation id.
            candidate_text: The candidate text evaluated.
            novelty_score: The novelty score.
            reasoning: Reasoning for the score.
            contradicts: Comma-separated IDs of contradicted reflections.
            accepted: Whether the candidate was accepted.
            method: The evaluation method used.
        """
        self._db.execute_write(
            """INSERT INTO novelty_log
               (id, timestamp, conversation_id, candidate_text, novelty_score,
                reasoning, contradicts, accepted, method)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                log_id,
                timestamp,
                conversation_id,
                candidate_text,
                novelty_score,
                reasoning,
                contradicts,
                int(accepted),
                method,
            ),
        )

    def save_consolidation_log(
        self,
        log_id: str,
        timestamp: str,
        entries_before: int,
        entries_after: int,
        changelog: str,
        duration_ms: int,
        model_used: str,
        tokens_used: int,
    ) -> None:
        """Log a consolidation run.

        Args:
            log_id: Unique log entry id.
            timestamp: ISO timestamp.
            entries_before: Entry count before consolidation.
            entries_after: Entry count after consolidation.
            changelog: Description of changes.
            duration_ms: Duration in milliseconds.
            model_used: Model used for consolidation.
            tokens_used: Tokens consumed.
        """
        self._db.execute_write(
            """INSERT INTO consolidation_log
               (id, timestamp, entries_before, entries_after, changelog,
                duration_ms, model_used, tokens_used)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                log_id,
                timestamp,
                entries_before,
                entries_after,
                changelog,
                duration_ms,
                model_used,
                tokens_used,
            ),
        )

    def save_strategy_observation(
        self,
        obs_id: str,
        timestamp: str,
        conversation_id: str,
        observation: str,
        obs_type: str,
        source: str,
        confidence: float,
        raw_evidence: str,
    ) -> None:
        """Log a strategy observation.

        Args:
            obs_id: Unique observation id.
            timestamp: ISO timestamp.
            conversation_id: The conversation id.
            observation: The observation text.
            obs_type: Observation type.
            source: Source of the observation.
            confidence: Confidence score.
            raw_evidence: Raw evidence text.
        """
        self._db.execute_write(
            """INSERT INTO strategy_observations
               (id, timestamp, conversation_id, observation, type, source,
                confidence, raw_evidence)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                obs_id,
                timestamp,
                conversation_id,
                observation,
                obs_type,
                source,
                confidence,
                raw_evidence,
            ),
        )

    # --- Helpers ---

    def _register_graph_node(
        self, node_id: str, node_type: str, label: str, source_table: str
    ) -> None:
        """Register a graph node for dual-write consistency.

        Args:
            node_id: Entity id.
            node_type: Graph node type.
            label: Human-readable label.
            source_table: Source table name.
        """
        now = _now_iso()
        self._db.execute_write(
            """INSERT OR IGNORE INTO graph_nodes
               (id, node_type, label, source_table, created_at, updated_at, deprecated, metadata)
               VALUES (?, ?, ?, ?, ?, ?, 0, '{}')""",
            (node_id, node_type, label, source_table, now, now),
        )
