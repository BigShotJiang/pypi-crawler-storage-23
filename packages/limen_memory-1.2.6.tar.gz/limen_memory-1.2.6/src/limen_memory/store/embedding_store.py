"""Embedding storage and vectorized cosine similarity search."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np

from limen_memory.constants import EMBEDDING_MODEL
from limen_memory.models import EmbeddingMatch
from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


@dataclass
class EmbeddingMatrixCache:
    """Pre-loaded embedding matrix for reuse across multiple similarity queries.

    Avoids repeated ``get_all_embeddings()`` calls within a single pipeline run.
    Build once with ``EmbeddingMatrixCache.build(store)``, then pass to cached
    methods on ``EmbeddingStore``.
    """

    ids: list[str] = field(default_factory=list)
    matrix: np.ndarray = field(default_factory=lambda: np.empty((0, 0), dtype=np.float32))
    norms: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.float32))

    @classmethod
    def build(cls, store: EmbeddingStore) -> EmbeddingMatrixCache:
        """Load all embeddings from the store into a cached matrix.

        Args:
            store: The embedding store to load from.

        Returns:
            Populated cache instance.
        """
        all_data = store.get_all_embeddings()
        if not all_data:
            return cls()
        ids = [rid for rid, _ in all_data]
        matrix = np.array([emb for _, emb in all_data], dtype=np.float32)
        norms = np.linalg.norm(matrix, axis=1)
        return cls(ids=ids, matrix=matrix, norms=norms)

    def append(self, reflection_id: str, embedding: np.ndarray) -> None:
        """Add a new embedding to the cache in-memory.

        Used after saving a new reflection mid-pipeline to keep the cache
        current without reloading from the database.

        Args:
            reflection_id: The reflection this embedding belongs to.
            embedding: Numpy array of shape (dimensions,).
        """
        emb = embedding.astype(np.float32).reshape(1, -1)
        norm = float(np.linalg.norm(emb))
        self.ids.append(reflection_id)
        if self.matrix.size == 0:
            self.matrix = emb
            self.norms = np.array([norm], dtype=np.float32)
        else:
            self.matrix = np.vstack([self.matrix, emb])
            self.norms = np.append(self.norms, norm)

    @property
    def empty(self) -> bool:
        """Whether the cache contains any embeddings."""
        return len(self.ids) == 0


class EmbeddingStore:
    """CRUD operations for reflection embeddings with cosine similarity search.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db
        self._cache: EmbeddingMatrixCache | None = None

    def _ensure_cache(self) -> EmbeddingMatrixCache:
        """Return the internal cache, building it from DB on first access."""
        if self._cache is None:
            self._cache = EmbeddingMatrixCache.build(self)
        return self._cache

    def invalidate_cache(self) -> None:
        """Invalidate the internal embedding matrix cache.

        Call this after external mutations that bypass ``save_embedding``
        or ``delete_embedding``.
        """
        self._cache = None

    def save_embedding(
        self,
        reflection_id: str,
        embedding: np.ndarray,
        model_version: str = EMBEDDING_MODEL,
    ) -> None:
        """Store an embedding as a BLOB.

        Serializes the numpy array via ``.astype(np.float32).tobytes()``.

        Args:
            reflection_id: The reflection this embedding belongs to.
            embedding: Numpy array of shape (dimensions,).
            model_version: The model that produced this embedding.
        """
        blob = embedding.astype(np.float32).tobytes()
        self._db.execute_write(
            """INSERT OR REPLACE INTO reflection_embeddings
               (id, reflection_id, embedding, embedding_dimension, model_version, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                uuid.uuid4().hex,
                reflection_id,
                blob,
                len(embedding),
                model_version,
                _now_iso(),
            ),
        )
        self._cache = None

    def get_embedding(self, reflection_id: str) -> np.ndarray | None:
        """Retrieve a single embedding by reflection id.

        Args:
            reflection_id: The reflection id.

        Returns:
            Numpy array (float32), or None if not found.
        """
        row = self._db.execute_read_one(
            "SELECT embedding FROM reflection_embeddings WHERE reflection_id = ?",
            (reflection_id,),
        )
        if not row:
            return None
        return np.frombuffer(row["embedding"], dtype=np.float32).copy()

    def get_all_embeddings(self) -> list[tuple[str, np.ndarray]]:
        """Load all embeddings as (reflection_id, ndarray) pairs.

        Returns:
            List of (reflection_id, embedding) tuples.
        """
        rows = self._db.execute_read("SELECT reflection_id, embedding FROM reflection_embeddings")
        return [
            (row["reflection_id"], np.frombuffer(row["embedding"], dtype=np.float32).copy())
            for row in rows
        ]

    def find_similar(
        self,
        query_embedding: np.ndarray,
        limit: int = 10,
        min_similarity: float = 0.0,
        exclude_ids: set[str] | None = None,
    ) -> list[EmbeddingMatch]:
        """Cosine similarity search against all stored embeddings.

        Uses the internal cache to avoid repeated ``get_all_embeddings()``
        calls across multiple invocations.

        Args:
            query_embedding: Query vector of shape (dimensions,).
            limit: Maximum results to return.
            min_similarity: Minimum cosine similarity threshold.
            exclude_ids: Reflection IDs to exclude from results.

        Returns:
            List of EmbeddingMatch, sorted by similarity descending.
        """
        return self.find_similar_cached(
            query_embedding, self._ensure_cache(), limit, min_similarity, exclude_ids
        )

    def get_max_similarity(
        self,
        query_embedding: np.ndarray,
        exclude_ids: set[str] | None = None,
    ) -> float:
        """Return the maximum cosine similarity of query vs all stored embeddings.

        Used by the novelty filter's embedding pre-filter stage.

        Args:
            query_embedding: Query vector.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Maximum similarity (0.0 if no embeddings exist).
        """
        return self.get_max_similarity_cached(query_embedding, self._ensure_cache(), exclude_ids)

    def get_most_similar_age(
        self,
        query_embedding: np.ndarray,
        exclude_ids: set[str] | None = None,
    ) -> float | None:
        """Return the age in days of the most similar stored embedding.

        Used by the novelty filter to apply temporal decay: old similar
        entries should not block new observations as aggressively.

        Args:
            query_embedding: Query vector.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Age in days, or None if no embeddings exist.
        """
        return self.get_most_similar_age_cached(query_embedding, self._ensure_cache(), exclude_ids)

    def find_similar_cached(
        self,
        query_embedding: np.ndarray,
        cache: EmbeddingMatrixCache,
        limit: int = 10,
        min_similarity: float = 0.0,
        exclude_ids: set[str] | None = None,
    ) -> list[EmbeddingMatch]:
        """Cosine similarity search using a pre-loaded cache.

        Same behavior as ``find_similar`` but skips the ``get_all_embeddings()``
        database call by using the provided cache.

        Args:
            query_embedding: Query vector of shape (dimensions,).
            cache: Pre-loaded embedding matrix cache.
            limit: Maximum results to return.
            min_similarity: Minimum cosine similarity threshold.
            exclude_ids: Reflection IDs to exclude from results.

        Returns:
            List of EmbeddingMatch, sorted by similarity descending.
        """
        if cache.empty:
            return []

        exclude = exclude_ids or set()
        mask = np.array([rid not in exclude for rid in cache.ids], dtype=bool)
        if not mask.any():
            return []

        filtered_ids = [rid for rid, m in zip(cache.ids, mask) if m]
        filtered_matrix = cache.matrix[mask]
        filtered_norms = cache.norms[mask]

        query = query_embedding.astype(np.float32)
        query_norm = np.linalg.norm(query)
        if query_norm == 0.0:
            return []

        safe_norms = np.where(filtered_norms > 0, filtered_norms, 1.0)
        similarities = (filtered_matrix @ query) / (safe_norms * query_norm)

        results: list[EmbeddingMatch] = []
        for i, sim in enumerate(similarities):
            sim_float = float(sim)
            if sim_float >= min_similarity:
                results.append(EmbeddingMatch(reflection_id=filtered_ids[i], similarity=sim_float))

        results.sort(key=lambda m: m.similarity, reverse=True)
        return results[:limit]

    def get_max_similarity_cached(
        self,
        query_embedding: np.ndarray,
        cache: EmbeddingMatrixCache,
        exclude_ids: set[str] | None = None,
    ) -> float:
        """Return the maximum cosine similarity using a pre-loaded cache.

        Args:
            query_embedding: Query vector.
            cache: Pre-loaded embedding matrix cache.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Maximum similarity (0.0 if cache is empty).
        """
        matches = self.find_similar_cached(
            query_embedding, cache, limit=1, min_similarity=0.0, exclude_ids=exclude_ids
        )
        return matches[0].similarity if matches else 0.0

    def get_most_similar_age_cached(
        self,
        query_embedding: np.ndarray,
        cache: EmbeddingMatrixCache,
        exclude_ids: set[str] | None = None,
    ) -> float | None:
        """Return the age in days of the most similar embedding using a cache.

        Args:
            query_embedding: Query vector.
            cache: Pre-loaded embedding matrix cache.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Age in days, or None if cache is empty.
        """
        matches = self.find_similar_cached(
            query_embedding, cache, limit=1, min_similarity=0.0, exclude_ids=exclude_ids
        )
        if not matches:
            return None
        return self._get_reflection_age(matches[0].reflection_id)

    def get_best_match_cached(
        self,
        query_embedding: np.ndarray,
        cache: EmbeddingMatrixCache,
        exclude_ids: set[str] | None = None,
    ) -> tuple[float, float | None]:
        """Return (max_similarity, age_in_days) from a single similarity search.

        Combines ``get_max_similarity_cached`` and ``get_most_similar_age_cached``
        into one call, avoiding a redundant ``find_similar_cached`` computation.

        Args:
            query_embedding: Query vector.
            cache: Pre-loaded embedding matrix cache.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Tuple of (max_similarity, age_in_days). Returns ``(0.0, None)``
            if the cache is empty or all entries are excluded.
        """
        matches = self.find_similar_cached(
            query_embedding, cache, limit=1, min_similarity=0.0, exclude_ids=exclude_ids
        )
        if not matches:
            return 0.0, None
        return matches[0].similarity, self._get_reflection_age(matches[0].reflection_id)

    def get_best_match(
        self,
        query_embedding: np.ndarray,
        exclude_ids: set[str] | None = None,
    ) -> tuple[float, float | None]:
        """Return (max_similarity, age_in_days) from a single similarity search.

        Non-cached public API — delegates to ``get_best_match_cached``
        using the store's internal cache.

        Args:
            query_embedding: Query vector.
            exclude_ids: Reflection IDs to exclude.

        Returns:
            Tuple of (max_similarity, age_in_days). Returns ``(0.0, None)``
            if no embeddings exist or all entries are excluded.
        """
        return self.get_best_match_cached(
            query_embedding, self._ensure_cache(), exclude_ids=exclude_ids
        )

    def _get_reflection_age(self, reflection_id: str) -> float | None:
        """Return the age of a reflection in days.

        Args:
            reflection_id: The reflection to look up.

        Returns:
            Age in days, or None if not found or unparseable.
        """
        row = self._db.execute_read_one(
            "SELECT timestamp FROM memory_reflections WHERE id = ?",
            (reflection_id,),
        )
        if not row or not row["timestamp"]:
            return None
        try:
            ts = datetime.fromisoformat(row["timestamp"])
            return (datetime.utcnow() - ts).total_seconds() / 86400.0
        except (ValueError, TypeError):
            return None

    def delete_embedding(self, reflection_id: str) -> bool:
        """Delete the embedding for a given reflection.

        Args:
            reflection_id: The reflection whose embedding should be removed.

        Returns:
            True if a row was deleted, False if no embedding existed.
        """
        cursor = self._db.execute_write(
            "DELETE FROM reflection_embeddings WHERE reflection_id = ?",
            (reflection_id,),
        )
        deleted = cursor.rowcount > 0
        if deleted:
            self._cache = None
        return deleted

    def get_stored_dimension(self) -> int | None:
        """Return the dimension of an existing stored embedding, or None if empty.

        Queries a single row to avoid loading all embeddings into memory.

        Returns:
            The embedding dimension as an int, or ``None`` if no embeddings exist.
        """
        row = self._db.execute_read_one(
            "SELECT embedding_dimension FROM reflection_embeddings LIMIT 1"
        )
        if not row:
            return None
        return int(row["embedding_dimension"])

    def has_embeddings(self) -> bool:
        """Check if any embeddings exist in the store.

        Returns:
            True if at least one embedding is stored.
        """
        return self.count_embeddings() > 0

    def count_embeddings(self) -> int:
        """Count stored embeddings.

        Returns:
            Number of embeddings in the store.
        """
        return self._db.table_count("reflection_embeddings")
