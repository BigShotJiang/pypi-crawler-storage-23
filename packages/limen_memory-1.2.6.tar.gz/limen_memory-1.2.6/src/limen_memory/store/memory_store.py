"""Reflections, user facts, and session context CRUD.

Implements dual-write to graph_nodes for every entity save.
Supports both keyword-only (Phase 1) and hybrid (Phase 2) relevance scoring.
"""

from __future__ import annotations

import logging
import math
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from limen_memory.constants import (
    ACTIVITY_PRESSURE_FACTOR,
    ACTIVITY_PRESSURE_WINDOW_DAYS,
    CONFIDENCE_MAP,
    HIGH_CONFIDENCE_ACTIVITY_THRESHOLD,
    HYBRID_MIN_SIMILARITY,
    HYBRID_WEIGHT_CONFIDENCE,
    HYBRID_WEIGHT_GRAPH,
    HYBRID_WEIGHT_KEYWORD,
    HYBRID_WEIGHT_RECENCY,
    HYBRID_WEIGHT_SEMANTIC,
    RECENCY_HALF_LIFE,
    REFLECTION_AGE_LOW_TO_SPECULATION_DAYS,
    REFLECTION_AGE_MEDIUM_TO_LOW_DAYS,
    REFLECTION_AGE_SPECULATION_TO_DEPRECATED_DAYS,
    RELEVANCE_WEIGHT_CONFIDENCE,
    RELEVANCE_WEIGHT_EDGES,
    RELEVANCE_WEIGHT_RECENCY,
    RELEVANCE_WEIGHT_TOPIC,
)
from limen_memory.models import MemoryReflection, SessionContext, UserFact
from limen_memory.store.database import Database

if TYPE_CHECKING:
    from limen_memory.services.embedding._base import BaseEmbeddingClient
    from limen_memory.store.embedding_store import EmbeddingStore

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class MemoryStore:
    """CRUD operations for reflections, user facts, and session contexts.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    # --- Reflections ---

    def save_reflection(self, reflection: MemoryReflection) -> str:
        """Save a reflection and register it as a graph node.

        Args:
            reflection: The reflection to save.

        Returns:
            The reflection id.
        """
        self._db.execute_write(
            """INSERT INTO memory_reflections
               (id, timestamp, type, category, content, confidence, tags, source_session,
                deprecated, superseded_by, last_verified, novelty_score, epistemic_status,
                behavioral_directive, directive_activation_count, directive_positive_count,
                pinned)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                reflection.id,
                reflection.timestamp,
                reflection.type,
                reflection.category,
                reflection.content,
                reflection.confidence,
                reflection.tags_json,
                reflection.source_session,
                int(reflection.deprecated),
                reflection.superseded_by,
                reflection.last_verified or _now_iso(),
                reflection.novelty_score,
                reflection.epistemic_status,
                reflection.behavioral_directive,
                reflection.directive_activation_count,
                reflection.directive_positive_count,
                int(reflection.pinned),
            ),
        )
        self._register_graph_node(
            node_id=reflection.id,
            node_type="reflection",
            label=reflection.content[:80],
            source_table="memory_reflections",
        )
        logger.debug("Saved reflection %s", reflection.id)
        return reflection.id

    def get_reflection(self, reflection_id: str) -> MemoryReflection | None:
        """Get a reflection by id.

        Args:
            reflection_id: The reflection id.

        Returns:
            The reflection or None if not found.
        """
        row = self._db.execute_read_one(
            "SELECT * FROM memory_reflections WHERE id = ?", (reflection_id,)
        )
        return MemoryReflection.from_row(row) if row else None

    def query_reflections(
        self,
        topic: str = "",
        reflection_type: str = "",
        limit: int = 20,
        since_date: str = "",
        min_confidence: str = "",
    ) -> list[MemoryReflection]:
        """Query reflections with optional filtering and relevance scoring.

        Args:
            topic: Topic string for keyword relevance scoring.
            reflection_type: Filter by reflection type.
            limit: Maximum results.
            since_date: ISO date string lower bound on timestamp.
            min_confidence: Minimum confidence level (includes this level and above).

        Returns:
            List of reflections, scored and sorted if topic is provided.
        """
        conditions = ["deprecated = 0"]
        params: list[Any] = []

        if reflection_type:
            conditions.append("type = ?")
            params.append(reflection_type)

        if since_date:
            conditions.append("timestamp >= ?")
            params.append(since_date)

        if min_confidence:
            confidence_order = ["speculation", "low", "medium", "high"]
            try:
                idx = confidence_order.index(min_confidence)
                allowed = confidence_order[idx:]
                placeholders = ", ".join("?" for _ in allowed)
                conditions.append(f"confidence IN ({placeholders})")
                params.extend(allowed)
            except ValueError:
                pass

        where = " AND ".join(conditions)
        sql = f"SELECT * FROM memory_reflections WHERE {where} ORDER BY timestamp DESC"  # nosec B608
        rows = self._db.execute_read(sql, tuple(params))
        reflections = [MemoryReflection.from_row(r) for r in rows]

        if topic:
            scored = self._score_reflections(reflections, topic)
            scored.sort(key=lambda x: x[1], reverse=True)
            return [r for r, _ in scored[:limit]]

        return reflections[:limit]

    def _score_reflections(
        self, reflections: list[MemoryReflection], topic: str
    ) -> list[tuple[MemoryReflection, float]]:
        """Score reflections by keyword relevance.

        Args:
            reflections: Reflections to score.
            topic: Topic string for scoring.

        Returns:
            List of (reflection, score) tuples.
        """
        topic_words = set(topic.lower().split())
        if not topic_words:
            return [(r, 0.0) for r in reflections]

        now = datetime.utcnow()
        scored: list[tuple[MemoryReflection, float]] = []

        for r in reflections:
            content_lower = r.content.lower()
            matches = sum(1 for w in topic_words if w in content_lower)
            topic_score = matches / len(topic_words)

            try:
                ts = datetime.fromisoformat(r.timestamp)
                days_old = (now - ts).days
            except (ValueError, TypeError):
                days_old = 365
            recency_score = math.exp(-days_old / RECENCY_HALF_LIFE)

            confidence_score = CONFIDENCE_MAP.get(r.confidence, 0.5)

            edge_count = self._get_edge_count(r.id)
            edge_score = min(1.0, edge_count / 10.0)

            total = (
                topic_score * RELEVANCE_WEIGHT_TOPIC
                + recency_score * RELEVANCE_WEIGHT_RECENCY
                + confidence_score * RELEVANCE_WEIGHT_CONFIDENCE
                + edge_score * RELEVANCE_WEIGHT_EDGES
            )
            scored.append((r, total))

        return scored

    def _get_edge_count(self, node_id: str) -> int:
        """Count active edges for a node.

        Args:
            node_id: The graph node id.

        Returns:
            Number of active edges.
        """
        row = self._db.execute_read_one(
            """SELECT COUNT(*) as cnt FROM graph_edges
               WHERE (source_id = ? OR target_id = ?) AND deprecated = 0""",
            (node_id, node_id),
        )
        return int(row["cnt"]) if row else 0

    def _get_quality_edge_count(self, node_id: str, min_confidence: float = 0.4) -> int:
        """Count active edges for a node above a confidence threshold.

        Used by hybrid search to compute quality-weighted graph scores.

        Args:
            node_id: The graph node id.
            min_confidence: Minimum edge confidence.

        Returns:
            Number of qualifying edges.
        """
        row = self._db.execute_read_one(
            """SELECT COUNT(*) as cnt FROM graph_edges
               WHERE (source_id = ? OR target_id = ?) AND deprecated = 0
                 AND confidence >= ?""",
            (node_id, node_id, min_confidence),
        )
        return int(row["cnt"]) if row else 0

    def query_reflections_hybrid(
        self,
        topic: str,
        embedding_store: EmbeddingStore,
        embedding_client: BaseEmbeddingClient,
        reflection_type: str = "",
        limit: int = 20,
        since_date: str = "",
        min_confidence: str = "",
    ) -> list[MemoryReflection]:
        """Query reflections with hybrid scoring.

        Blends semantic + keyword + recency + confidence + graph.

        Uses embedding similarity for the semantic component. Falls back to
        keyword-only scoring if embedding computation fails.

        Score = semantic(0.35) + keyword(0.20) + recency(0.20) + confidence(0.15) + graph(0.10)

        Args:
            topic: Topic string for scoring.
            embedding_store: Embedding store for similarity search.
            embedding_client: Embedding client for computing topic embedding.
            reflection_type: Optional filter by reflection type.
            limit: Maximum results.
            since_date: ISO date string lower bound.
            min_confidence: Minimum confidence level.

        Returns:
            List of reflections sorted by hybrid score.
        """
        # Get base reflections (unscored)
        conditions = ["deprecated = 0"]
        params: list[Any] = []

        if reflection_type:
            conditions.append("type = ?")
            params.append(reflection_type)
        if since_date:
            conditions.append("timestamp >= ?")
            params.append(since_date)
        if min_confidence:
            confidence_order = ["speculation", "low", "medium", "high"]
            try:
                idx = confidence_order.index(min_confidence)
                allowed = confidence_order[idx:]
                placeholders = ", ".join("?" for _ in allowed)
                conditions.append(f"confidence IN ({placeholders})")
                params.extend(allowed)
            except ValueError:
                pass

        where = " AND ".join(conditions)
        sql = f"SELECT * FROM memory_reflections WHERE {where} ORDER BY timestamp DESC"  # nosec B608
        rows = self._db.execute_read(sql, tuple(params))
        reflections = [MemoryReflection.from_row(r) for r in rows]

        if not reflections or not topic:
            return reflections[:limit]

        # Compute topic embedding
        try:
            topic_embedding = embedding_client.embed_single(topic)
        except Exception:
            logger.warning("Failed to compute topic embedding, falling back to keyword scoring")
            fallback_scored = self._score_reflections(reflections, topic)
            fallback_scored.sort(key=lambda x: x[1], reverse=True)
            return [r for r, _ in fallback_scored[:limit]]

        # Get similarity scores for all reflections (filter noise below threshold)
        similar = embedding_store.find_similar(
            topic_embedding, limit=500, min_similarity=HYBRID_MIN_SIMILARITY
        )
        sim_map: dict[str, float] = {m.reflection_id: m.similarity for m in similar}

        # Compute hybrid scores
        topic_words = set(topic.lower().split())
        now = datetime.utcnow()
        scored: list[tuple[MemoryReflection, float]] = []

        for r in reflections:
            # Semantic score (from embeddings)
            semantic_score = sim_map.get(r.id, 0.0)

            # Keyword score
            if topic_words:
                content_lower = r.content.lower()
                matches = sum(1 for w in topic_words if w in content_lower)
                keyword_score = matches / len(topic_words)
            else:
                keyword_score = 0.0

            # Recency score
            try:
                ts = datetime.fromisoformat(r.timestamp)
                days_old = (now - ts).days
            except (ValueError, TypeError):
                days_old = 365
            recency_score = math.exp(-days_old / RECENCY_HALF_LIFE)

            # Confidence score
            confidence_score = CONFIDENCE_MAP.get(r.confidence, 0.5)

            # Graph score (quality-weighted: only count edges with confidence > 0.4)
            quality_edges = self._get_quality_edge_count(r.id, min_confidence=0.4)
            graph_score = min(1.0, quality_edges / 5.0)

            total = (
                semantic_score * HYBRID_WEIGHT_SEMANTIC
                + keyword_score * HYBRID_WEIGHT_KEYWORD
                + recency_score * HYBRID_WEIGHT_RECENCY
                + confidence_score * HYBRID_WEIGHT_CONFIDENCE
                + graph_score * HYBRID_WEIGHT_GRAPH
            )
            scored.append((r, total))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [r for r, _ in scored[:limit]]

    def deprecate_reflection(
        self, reflection_id: str, reason: str = "", superseded_by: str = ""
    ) -> bool:
        """Soft-delete a reflection and its graph node.

        Args:
            reflection_id: The reflection id.
            reason: Deprecation reason (logged but not stored).
            superseded_by: ID of the superseding reflection.

        Returns:
            True if a row was updated.
        """
        now = _now_iso()
        cursor = self._db.execute_write(
            """UPDATE memory_reflections
               SET deprecated = 1, superseded_by = ?
               WHERE id = ? AND deprecated = 0""",
            (superseded_by, reflection_id),
        )
        if cursor.rowcount > 0:
            self._db.execute_write(
                "UPDATE graph_nodes SET deprecated = 1, updated_at = ? WHERE id = ?",
                (now, reflection_id),
            )
            logger.info("Deprecated reflection %s (reason: %s)", reflection_id, reason)
            return True
        return False

    def query_recently_deprecated(self, limit: int = 10) -> list[MemoryReflection]:
        """Get recently deprecated reflections, ordered by deprecation time.

        Uses the graph_nodes.updated_at column (set during deprecation) for
        accurate ordering rather than the reflection's creation timestamp.

        Args:
            limit: Maximum results.

        Returns:
            List of deprecated reflections, most recently deprecated first.
        """
        rows = self._db.execute_read(
            """SELECT mr.* FROM memory_reflections mr
               JOIN graph_nodes gn ON mr.id = gn.id
               WHERE mr.deprecated = 1
               ORDER BY gn.updated_at DESC LIMIT ?""",
            (limit,),
        )
        return [MemoryReflection.from_row(r) for r in rows]

    def get_active_behavioral_directives(self, limit: int = 5) -> list[MemoryReflection]:
        """Get active reflections that have behavioral directives.

        Args:
            limit: Maximum results.

        Returns:
            List of reflections with directives.
        """
        rows = self._db.execute_read(
            """SELECT * FROM memory_reflections
               WHERE deprecated = 0
                 AND behavioral_directive IS NOT NULL
                 AND behavioral_directive != ''
               ORDER BY directive_activation_count DESC
               LIMIT ?""",
            (limit,),
        )
        return [MemoryReflection.from_row(r) for r in rows]

    def increment_directive_activation(self, reflection_ids: list[str]) -> None:
        """Increment directive activation count for given reflections.

        Args:
            reflection_ids: List of reflection ids.
        """
        if not reflection_ids:
            return
        placeholders = ", ".join("?" for _ in reflection_ids)
        self._db.execute_write(
            f"""UPDATE memory_reflections
                SET directive_activation_count = directive_activation_count + 1
                WHERE id IN ({placeholders})""",  # nosec B608
            tuple(reflection_ids),
        )

    def boost_reflection_confidence(self, reflection_id: str) -> None:
        """Upgrade a reflection's confidence by one level.

        Args:
            reflection_id: The reflection id.
        """
        upgrade_map = {
            "speculation": "low",
            "low": "medium",
            "medium": "high",
        }
        row = self._db.execute_read_one(
            "SELECT confidence FROM memory_reflections WHERE id = ?", (reflection_id,)
        )
        if not row:
            return
        current = row["confidence"]
        new_conf = upgrade_map.get(current)
        if new_conf:
            self._db.execute_write(
                """UPDATE memory_reflections
                   SET confidence = ?, last_verified = ?
                   WHERE id = ?""",
                (new_conf, _now_iso(), reflection_id),
            )

    def touch_reflections(self, reflection_ids: set[str]) -> int:
        """Update last_verified for retrieved reflections, resetting the aging clock.

        This ensures actively-used reflections never age out. Called by
        ContextLoader after assembling context.

        Args:
            reflection_ids: Set of reflection IDs to touch.

        Returns:
            Number of reflections updated.
        """
        if not reflection_ids:
            return 0
        now = _now_iso()
        placeholders = ", ".join("?" for _ in reflection_ids)
        cursor = self._db.execute_write(
            f"""UPDATE memory_reflections SET last_verified = ?
                WHERE id IN ({placeholders}) AND deprecated = 0""",  # nosec B608
            (now, *reflection_ids),
        )
        if cursor.rowcount > 0:
            logger.debug("Touched last_verified for %d reflections", cursor.rowcount)
        return cursor.rowcount

    def pin_reflection(self, reflection_id: str) -> bool:
        """Pin a reflection to prevent it from being aged out.

        Args:
            reflection_id: The reflection id.

        Returns:
            True if the reflection was pinned.
        """
        cursor = self._db.execute_write(
            "UPDATE memory_reflections SET pinned = 1 WHERE id = ? AND deprecated = 0",
            (reflection_id,),
        )
        if cursor.rowcount > 0:
            logger.info("Pinned reflection %s", reflection_id)
            return True
        return False

    def unpin_reflection(self, reflection_id: str) -> bool:
        """Unpin a reflection, allowing it to be aged normally.

        Args:
            reflection_id: The reflection id.

        Returns:
            True if the reflection was unpinned.
        """
        cursor = self._db.execute_write(
            "UPDATE memory_reflections SET pinned = 0 WHERE id = ? AND deprecated = 0",
            (reflection_id,),
        )
        if cursor.rowcount > 0:
            logger.info("Unpinned reflection %s", reflection_id)
            return True
        return False

    def age_reflections(self) -> int:
        """Age reflections by downgrading confidence based on staleness.

        Decay chain: medium -> low -> speculation -> deprecated.
        Immune to aging: pinned reflections are never downgraded automatically.
        High-confidence reflections begin aging only when their topic area
        has significant recent activity (>= HIGH_CONFIDENCE_ACTIVITY_THRESHOLD
        new reflections in the graph neighborhood within ACTIVITY_PRESSURE_WINDOW_DAYS).

        Activity pressure modulates effective age:
        effective_age = calendar_age * (1 + topic_activity * ACTIVITY_PRESSURE_FACTOR)

        Returns:
            Total number of reflections affected.
        """
        now = datetime.utcnow()
        now_iso = now.isoformat()
        total = 0

        # Load activity counts per graph neighborhood for pressure calculation
        activity_window = (now - timedelta(days=ACTIVITY_PRESSURE_WINDOW_DAYS)).isoformat()

        # medium -> low (with activity pressure)
        base_cutoff_days = REFLECTION_AGE_MEDIUM_TO_LOW_DAYS
        rows = self._db.execute_read(
            """SELECT id, last_verified FROM memory_reflections
               WHERE deprecated = 0 AND pinned = 0 AND confidence = 'medium'""",
        )
        for row in rows:
            last_v = row["last_verified"]
            try:
                ts = datetime.fromisoformat(last_v)
                calendar_age = (now - ts).days
            except (ValueError, TypeError):
                calendar_age = base_cutoff_days + 1

            activity = self._get_neighborhood_activity(row["id"], activity_window)
            effective_age = calendar_age * (1.0 + activity * ACTIVITY_PRESSURE_FACTOR)

            if effective_age >= base_cutoff_days:
                self._db.execute_write(
                    """UPDATE memory_reflections SET confidence = 'low', last_verified = ?
                       WHERE id = ?""",
                    (now_iso, row["id"]),
                )
                total += 1

        # low -> speculation (with activity pressure)
        base_cutoff_days = REFLECTION_AGE_LOW_TO_SPECULATION_DAYS
        rows = self._db.execute_read(
            """SELECT id, last_verified FROM memory_reflections
               WHERE deprecated = 0 AND pinned = 0 AND confidence = 'low'""",
        )
        for row in rows:
            last_v = row["last_verified"]
            try:
                ts = datetime.fromisoformat(last_v)
                calendar_age = (now - ts).days
            except (ValueError, TypeError):
                calendar_age = base_cutoff_days + 1

            activity = self._get_neighborhood_activity(row["id"], activity_window)
            effective_age = calendar_age * (1.0 + activity * ACTIVITY_PRESSURE_FACTOR)

            if effective_age >= base_cutoff_days:
                self._db.execute_write(
                    """UPDATE memory_reflections SET confidence = 'speculation', last_verified = ?
                       WHERE id = ?""",
                    (now_iso, row["id"]),
                )
                total += 1

        # speculation -> deprecated (with activity pressure)
        base_cutoff_days = REFLECTION_AGE_SPECULATION_TO_DEPRECATED_DAYS
        rows = self._db.execute_read(
            """SELECT id, last_verified FROM memory_reflections
               WHERE deprecated = 0 AND pinned = 0 AND confidence = 'speculation'""",
        )
        for row in rows:
            last_v = row["last_verified"]
            try:
                ts = datetime.fromisoformat(last_v)
                calendar_age = (now - ts).days
            except (ValueError, TypeError):
                calendar_age = base_cutoff_days + 1

            activity = self._get_neighborhood_activity(row["id"], activity_window)
            effective_age = calendar_age * (1.0 + activity * ACTIVITY_PRESSURE_FACTOR)

            if effective_age >= base_cutoff_days:
                self._db.execute_write(
                    """UPDATE memory_reflections SET deprecated = 1 WHERE id = ?""",
                    (row["id"],),
                )
                total += 1

        # high -> medium (only with significant activity pressure)
        rows = self._db.execute_read(
            """SELECT id, last_verified FROM memory_reflections
               WHERE deprecated = 0 AND pinned = 0 AND confidence = 'high'""",
        )
        for row in rows:
            last_v = row["last_verified"]
            try:
                ts = datetime.fromisoformat(last_v)
                calendar_age = (now - ts).days
            except (ValueError, TypeError):
                calendar_age = 0

            activity = self._get_neighborhood_activity(row["id"], activity_window)
            if activity >= HIGH_CONFIDENCE_ACTIVITY_THRESHOLD:
                effective_age = calendar_age * (1.0 + activity * ACTIVITY_PRESSURE_FACTOR)
                if effective_age >= REFLECTION_AGE_MEDIUM_TO_LOW_DAYS:
                    self._db.execute_write(
                        """UPDATE memory_reflections
                           SET confidence = 'medium', last_verified = ?
                           WHERE id = ?""",
                        (now_iso, row["id"]),
                    )
                    total += 1

        if total > 0:
            logger.info("Aged %d reflections", total)
        return total

    def _get_neighborhood_activity(self, reflection_id: str, since: str) -> int:
        """Count recent reflections in the same graph neighborhood.

        Looks at reflections connected via graph edges to the given reflection
        that were created after the `since` timestamp.

        Args:
            reflection_id: The reflection to find neighbors for.
            since: ISO timestamp lower bound for "recent" activity.

        Returns:
            Count of recent neighboring reflections.
        """
        row = self._db.execute_read_one(
            """SELECT COUNT(DISTINCT mr.id) as cnt
               FROM graph_edges ge
               JOIN memory_reflections mr ON (
                   (ge.source_id = ? AND mr.id = ge.target_id)
                   OR (ge.target_id = ? AND mr.id = ge.source_id)
               )
               WHERE ge.deprecated = 0
                 AND mr.deprecated = 0
                 AND mr.timestamp > ?""",
            (reflection_id, reflection_id, since),
        )
        return int(row["cnt"]) if row else 0

    def count_reflections_since(self, since: str) -> int:
        """Count non-deprecated reflections created after a timestamp.

        Args:
            since: ISO timestamp lower bound.

        Returns:
            Number of reflections since the given time.
        """
        row = self._db.execute_read_one(
            "SELECT COUNT(*) as cnt FROM memory_reflections WHERE deprecated = 0 AND timestamp > ?",
            (since,),
        )
        return int(row["cnt"]) if row else 0

    def get_active_reflections(self, limit: int = 500) -> list[MemoryReflection]:
        """Get all active (non-deprecated) reflections, most recent first.

        Args:
            limit: Maximum results.

        Returns:
            List of active reflections.
        """
        rows = self._db.execute_read(
            "SELECT * FROM memory_reflections WHERE deprecated = 0 ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        return [MemoryReflection.from_row(r) for r in rows]

    def update_reflection_directive(self, reflection_id: str, directive: str) -> None:
        """Set the behavioral_directive field on a reflection.

        Args:
            reflection_id: The reflection id.
            directive: The directive text.
        """
        self._db.execute_write(
            "UPDATE memory_reflections SET behavioral_directive = ? WHERE id = ?",
            (directive, reflection_id),
        )

    def get_reflections_without_directive(self, limit: int = 100) -> list[MemoryReflection]:
        """Get high/medium confidence reflections missing a behavioral directive.

        Args:
            limit: Maximum results.

        Returns:
            List of reflections without directives.
        """
        rows = self._db.execute_read(
            "SELECT * FROM memory_reflections "
            "WHERE deprecated = 0 AND confidence IN ('high', 'medium') "
            "AND (behavioral_directive IS NULL OR behavioral_directive = '') "
            "ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        return [MemoryReflection.from_row(r) for r in rows]

    # --- User Facts ---

    def save_user_fact(self, fact: UserFact) -> str:
        """Save or update a user fact (upsert by category+key).

        Args:
            fact: The user fact to save.

        Returns:
            The fact id.
        """
        existing = self._db.execute_read_one(
            "SELECT id FROM user_facts WHERE category = ? AND key = ? AND deprecated = 0",
            (fact.category, fact.key),
        )
        if existing:
            self._db.execute_write(
                """UPDATE user_facts
                   SET value = ?, confidence = ?, last_verified = ?
                   WHERE id = ?""",
                (fact.value, fact.confidence, _now_iso(), existing["id"]),
            )
            return str(existing["id"])

        self._db.execute_write(
            """INSERT INTO user_facts
               (id, category, key, value, confidence, first_observed, last_verified, deprecated)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                fact.id,
                fact.category,
                fact.key,
                fact.value,
                fact.confidence,
                fact.first_observed,
                fact.last_verified,
                int(fact.deprecated),
            ),
        )
        self._register_graph_node(
            node_id=fact.id,
            node_type="fact",
            label=f"{fact.category}: {fact.key}",
            source_table="user_facts",
        )
        return fact.id

    def query_user_facts(self, category: str = "") -> list[UserFact]:
        """Query user facts, optionally filtered by category.

        Args:
            category: Optional category filter.

        Returns:
            List of user facts.
        """
        if category:
            rows = self._db.execute_read(
                "SELECT * FROM user_facts WHERE deprecated = 0 AND category = ? ORDER BY key",
                (category,),
            )
        else:
            rows = self._db.execute_read(
                "SELECT * FROM user_facts WHERE deprecated = 0 ORDER BY category, key"
            )
        return [UserFact.from_row(r) for r in rows]

    def get_all_user_facts_formatted(self) -> str:
        """Get all user facts formatted as readable text.

        Returns:
            Formatted string grouped by category.
        """
        facts = self.query_user_facts()
        if not facts:
            return "No user facts recorded."

        grouped: dict[str, list[UserFact]] = {}
        for f in facts:
            grouped.setdefault(f.category, []).append(f)

        parts: list[str] = []
        for category in sorted(grouped.keys()):
            parts.append(f"## {category}")
            for f in grouped[category]:
                parts.append(f"- {f.key}: {f.value}")
            parts.append("")
        return "\n".join(parts).strip()

    def deprecate_user_fact(self, fact_id: str) -> bool:
        """Soft-delete a user fact and its graph node.

        Args:
            fact_id: The fact id.

        Returns:
            True if a row was updated.
        """
        cursor = self._db.execute_write(
            "UPDATE user_facts SET deprecated = 1 WHERE id = ? AND deprecated = 0",
            (fact_id,),
        )
        if cursor.rowcount > 0:
            self._db.execute_write(
                "UPDATE graph_nodes SET deprecated = 1, updated_at = ? WHERE id = ?",
                (_now_iso(), fact_id),
            )
            return True
        return False

    # --- Session Context ---

    def save_session_context(self, ctx: SessionContext) -> str:
        """Save or update a session context.

        Args:
            ctx: The session context to save.

        Returns:
            The context id.
        """
        self._db.execute_write(
            """INSERT OR REPLACE INTO session_context
               (id, session_id, started_at, ended_at, primary_topic, active_threads,
                pending_decisions, blockers, completed_items, context_notes, next_session_prep)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                ctx.id,
                ctx.session_id,
                ctx.started_at,
                ctx.ended_at,
                ctx.primary_topic,
                ctx.active_threads_json,
                ctx.pending_decisions_json,
                ctx.blockers_json,
                ctx.completed_items_json,
                ctx.context_notes,
                ctx.next_session_prep,
            ),
        )
        self._register_graph_node(
            node_id=ctx.id,
            node_type="session",
            label=ctx.primary_topic or ctx.session_id,
            source_table="session_context",
        )
        return ctx.id

    def get_last_session_context(self) -> SessionContext | None:
        """Get the most recent session context.

        Returns:
            The most recent session context or None.
        """
        row = self._db.execute_read_one(
            "SELECT * FROM session_context ORDER BY started_at DESC LIMIT 1"
        )
        return SessionContext.from_row(row) if row else None

    def get_session_history(self, limit: int = 10) -> list[SessionContext]:
        """Get recent session contexts.

        Args:
            limit: Maximum results.

        Returns:
            List of session contexts, most recent first.
        """
        rows = self._db.execute_read(
            "SELECT * FROM session_context ORDER BY started_at DESC LIMIT ?", (limit,)
        )
        return [SessionContext.from_row(r) for r in rows]

    # --- Helpers ---

    def _register_graph_node(
        self, node_id: str, node_type: str, label: str, source_table: str
    ) -> None:
        """Register a graph node for an entity (dual-write).

        Args:
            node_id: The entity id (used as node id).
            node_type: The graph node type.
            label: Human-readable label.
            source_table: The source table name.
        """
        now = _now_iso()
        self._db.execute_write(
            """INSERT OR IGNORE INTO graph_nodes
               (id, node_type, label, source_table, created_at, updated_at, deprecated, metadata)
               VALUES (?, ?, ?, ?, ?, ?, 0, '{}')""",
            (node_id, node_type, label, source_table, now, now),
        )

    def get_reflection_count(self, active_only: bool = True) -> int:
        """Count reflections.

        Args:
            active_only: If True, count only non-deprecated reflections.

        Returns:
            Reflection count.
        """
        where = "deprecated = 0" if active_only else ""
        return self._db.table_count("memory_reflections", where)

    def get_user_fact_count(self, active_only: bool = True) -> int:
        """Count user facts.

        Args:
            active_only: If True, count only non-deprecated facts.

        Returns:
            Fact count.
        """
        where = "deprecated = 0" if active_only else ""
        return self._db.table_count("user_facts", where)
