"""Interaction profile CRUD with dual-write to graph_nodes."""

from __future__ import annotations

import logging
from datetime import datetime

from limen_memory.constants import PROFILE_DIMENSION_CONFIDENCE_FLOOR, PROFILE_DIMENSION_METADATA
from limen_memory.models import InteractionDimension
from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


def _interpret_score(score: float, meta: dict[str, str]) -> str:
    """Interpret a dimension score into a human-readable implication.

    Args:
        score: Dimension score (-1.0 to 1.0).
        meta: Dimension metadata with low/high labels and advice.

    Returns:
        Implication string describing the score's meaning.
    """
    if not meta:
        if score < -0.3:
            return "Leans low"
        if score > 0.3:
            return "Leans high"
        return "Balanced — no strong lean"

    if score < -0.3:
        return f"{meta['low_label']} — {meta['low_advice']}"
    if score > 0.3:
        return f"{meta['high_label']} — {meta['high_advice']}"
    return "Balanced — adapt to conversational context"


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class ProfileStore:
    """CRUD operations for interaction profile dimensions.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    def save_interaction_dimension(self, dim: InteractionDimension) -> str:
        """Save or update an interaction dimension (upsert by dimension name).

        Args:
            dim: The interaction dimension to save.

        Returns:
            The dimension id.
        """
        self._db.execute_write(
            """INSERT OR REPLACE INTO interaction_profile
               (id, dimension, score, confidence, evidence_count,
                evidence_ids, last_synthesized, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                dim.id,
                dim.dimension,
                dim.score,
                dim.confidence,
                dim.evidence_count,
                dim.evidence_ids_json,
                dim.last_synthesized,
                dim.created_at,
            ),
        )
        self._register_graph_node(
            node_id=dim.id,
            node_type="profile_dimension",
            label=dim.dimension,
            source_table="interaction_profile",
        )
        return dim.id

    def get_interaction_profile(self) -> list[InteractionDimension]:
        """Get all interaction dimensions.

        Returns:
            List of interaction dimensions ordered by name.
        """
        rows = self._db.execute_read("SELECT * FROM interaction_profile ORDER BY dimension")
        return [InteractionDimension.from_row(r) for r in rows]

    def get_interaction_profile_formatted(self) -> str:
        """Get the interaction profile as a rich markdown table.

        Filters out dimensions below the confidence floor, interprets scores
        into human-readable implications using dimension metadata, and flags
        low-confidence dimensions as tentative.

        Returns:
            Formatted markdown string, or empty string if no qualifying data.
        """
        dims = self.get_interaction_profile()
        qualifying = [d for d in dims if d.confidence >= PROFILE_DIMENSION_CONFIDENCE_FLOOR]
        if not qualifying:
            return ""

        lines = [
            "## Interaction Profile",
            "",
            "These are default interaction preferences derived from accumulated observations.",
            "Current conversational context may override any of these defaults.",
            "",
            "| Dimension | Score | Confidence | Implication |",
            "|-----------|-------|------------|-------------|",
        ]

        low_confidence_dims: list[str] = []

        for d in qualifying:
            meta = PROFILE_DIMENSION_METADATA.get(d.dimension, {})
            implication = _interpret_score(d.score, meta)
            lines.append(f"| {d.dimension} | {d.score:+.2f} | {d.confidence:.0%} | {implication} |")
            if d.confidence < 0.5:
                low_confidence_dims.append(d.dimension)

        if low_confidence_dims:
            lines.append("")
            lines.append(
                f"*Note: {', '.join(low_confidence_dims)} "
                f"{'has' if len(low_confidence_dims) == 1 else 'have'} "
                f"low confidence (<50%) and should be considered tentative.*"
            )

        return "\n".join(lines)

    def _register_graph_node(
        self, node_id: str, node_type: str, label: str, source_table: str
    ) -> None:
        """Register a graph node for dual-write consistency.

        Args:
            node_id: Entity id.
            node_type: Graph node type.
            label: Human-readable label.
            source_table: Source table name.
        """
        now = _now_iso()
        self._db.execute_write(
            """INSERT OR IGNORE INTO graph_nodes
               (id, node_type, label, source_table, created_at, updated_at, deprecated, metadata)
               VALUES (?, ?, ?, ?, ?, ?, 0, '{}')""",
            (node_id, node_type, label, source_table, now, now),
        )
