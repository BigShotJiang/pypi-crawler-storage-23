"""Strategy CRUD with dual-write to graph_nodes."""

from __future__ import annotations

import logging
from datetime import datetime

from limen_memory.models import Strategy
from limen_memory.store.database import Database

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class StrategyStore:
    """CRUD operations for strategies.

    Args:
        db: Database instance.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    def save_strategy(self, strategy: Strategy) -> str:
        """Save a strategy and register it as a graph node.

        Args:
            strategy: The strategy to save.

        Returns:
            The strategy id.
        """
        self._db.execute_write(
            """INSERT INTO strategies
               (id, type, content, confidence, observation_count,
                created_at, updated_at, deprecated, superseded_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                strategy.id,
                strategy.type,
                strategy.content,
                strategy.confidence,
                strategy.observation_count,
                strategy.created_at,
                strategy.updated_at,
                int(strategy.deprecated),
                strategy.superseded_by,
            ),
        )
        self._register_graph_node(
            node_id=strategy.id,
            node_type="strategy",
            label=strategy.content[:80],
            source_table="strategies",
        )
        logger.debug("Saved strategy %s", strategy.id)
        return strategy.id

    def get_strategy(self, strategy_id: str) -> Strategy | None:
        """Get a strategy by id.

        Args:
            strategy_id: The strategy id.

        Returns:
            The strategy or None.
        """
        row = self._db.execute_read_one("SELECT * FROM strategies WHERE id = ?", (strategy_id,))
        return Strategy.from_row(row) if row else None

    def find_matching_strategy(self, content: str, strategy_type: str = "") -> Strategy | None:
        """Find a strategy matching keywords from the given content.

        Args:
            content: Text to extract keywords from.
            strategy_type: Optional type filter.

        Returns:
            Best matching strategy or None.
        """
        words = [w for w in content.lower().split() if len(w) >= 4][:3]
        if not words:
            return None

        conditions = ["deprecated = 0"]
        params: list[str] = []

        for word in words:
            conditions.append("LOWER(content) LIKE ?")
            params.append(f"%{word}%")

        if strategy_type:
            conditions.append("type = ?")
            params.append(strategy_type)

        where = " AND ".join(conditions)
        row = self._db.execute_read_one(
            f"SELECT * FROM strategies WHERE {where} ORDER BY confidence DESC LIMIT 1",  # nosec B608
            tuple(params),
        )
        return Strategy.from_row(row) if row else None

    def get_high_confidence_strategies(self, min_confidence: float = 0.7) -> list[Strategy]:
        """Get strategies above a confidence threshold.

        Args:
            min_confidence: Minimum confidence.

        Returns:
            List of strategies sorted by confidence descending.
        """
        rows = self._db.execute_read(
            """SELECT * FROM strategies
               WHERE deprecated = 0 AND confidence >= ?
               ORDER BY confidence DESC""",
            (min_confidence,),
        )
        return [Strategy.from_row(r) for r in rows]

    def increment_strategy_observations(self, strategy_id: str) -> None:
        """Increment the observation count for a strategy.

        Args:
            strategy_id: The strategy id.
        """
        self._db.execute_write(
            """UPDATE strategies
               SET observation_count = observation_count + 1, updated_at = ?
               WHERE id = ?""",
            (_now_iso(), strategy_id),
        )

    def deprecate_strategy(self, strategy_id: str, superseded_by: str = "") -> bool:
        """Soft-delete a strategy and its graph node.

        Args:
            strategy_id: The strategy id.
            superseded_by: ID of the superseding strategy.

        Returns:
            True if a row was updated.
        """
        now = _now_iso()
        cursor = self._db.execute_write(
            """UPDATE strategies
               SET deprecated = 1, superseded_by = ?, updated_at = ?
               WHERE id = ? AND deprecated = 0""",
            (superseded_by, now, strategy_id),
        )
        if cursor.rowcount > 0:
            self._db.execute_write(
                "UPDATE graph_nodes SET deprecated = 1, updated_at = ? WHERE id = ?",
                (now, strategy_id),
            )
            return True
        return False

    def update_strategy_confidence(self, strategy_id: str, new_confidence: float) -> None:
        """Set a strategy's confidence to a specific value.

        Args:
            strategy_id: The strategy id.
            new_confidence: New confidence value (clamped 0.0-1.0).
        """
        clamped = max(0.0, min(1.0, new_confidence))
        self._db.execute_write(
            "UPDATE strategies SET confidence = ?, updated_at = ? WHERE id = ?",
            (clamped, _now_iso(), strategy_id),
        )

    def merge_strategies(self, source_id: str, target_id: str, merged_content: str) -> str:
        """Merge source strategy into target, deprecating source.

        Args:
            source_id: Strategy to deprecate.
            target_id: Strategy to keep (content updated).
            merged_content: New merged content for target.

        Returns:
            The target strategy id.
        """
        now = _now_iso()
        self._db.execute_write(
            "UPDATE strategies SET content = ?, updated_at = ? WHERE id = ?",
            (merged_content, now, target_id),
        )
        self.deprecate_strategy(source_id, superseded_by=target_id)
        return target_id

    def get_all_strategies(self, include_deprecated: bool = False) -> list[Strategy]:
        """Get all strategies.

        Args:
            include_deprecated: Include deprecated strategies.

        Returns:
            List of strategies.
        """
        if include_deprecated:
            rows = self._db.execute_read("SELECT * FROM strategies ORDER BY type, confidence DESC")
        else:
            rows = self._db.execute_read(
                "SELECT * FROM strategies WHERE deprecated = 0 ORDER BY type, confidence DESC"
            )
        return [Strategy.from_row(r) for r in rows]

    def _register_graph_node(
        self, node_id: str, node_type: str, label: str, source_table: str
    ) -> None:
        """Register a graph node for dual-write consistency.

        Args:
            node_id: Entity id.
            node_type: Graph node type.
            label: Human-readable label.
            source_table: Source table name.
        """
        now = _now_iso()
        self._db.execute_write(
            """INSERT OR IGNORE INTO graph_nodes
               (id, node_type, label, source_table, created_at, updated_at, deprecated, metadata)
               VALUES (?, ?, ?, ?, ?, ?, 0, '{}')""",
            (node_id, node_type, label, source_table, now, now),
        )
