"""SQLite database connection, schema initialization, and migration support.

Uses WAL mode for concurrent read access. All writes go through execute_write()
which holds an exclusive lock for the duration of the transaction.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SCHEMA_VERSION = 1

_SCHEMA_SQL = """
-- Core Memory
CREATE TABLE IF NOT EXISTS memory_reflections (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    type TEXT NOT NULL,
    category TEXT,
    content TEXT NOT NULL,
    confidence TEXT DEFAULT 'medium',
    tags TEXT,
    source_session TEXT,
    deprecated INTEGER DEFAULT 0,
    superseded_by TEXT,
    last_verified TEXT,
    novelty_score REAL,
    epistemic_status TEXT DEFAULT 'hypothesis',
    behavioral_directive TEXT,
    directive_activation_count INTEGER DEFAULT 0,
    directive_positive_count INTEGER DEFAULT 0,
    pinned INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS user_facts (
    id TEXT PRIMARY KEY,
    category TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    confidence TEXT DEFAULT 'medium',
    first_observed TEXT NOT NULL,
    last_verified TEXT NOT NULL,
    deprecated INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS session_context (
    id TEXT PRIMARY KEY,
    session_id TEXT UNIQUE NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    primary_topic TEXT,
    active_threads TEXT,
    pending_decisions TEXT,
    blockers TEXT,
    completed_items TEXT,
    context_notes TEXT,
    next_session_prep TEXT
);

-- Knowledge Graph
CREATE TABLE IF NOT EXISTS graph_nodes (
    id TEXT PRIMARY KEY,
    node_type TEXT NOT NULL,
    label TEXT NOT NULL,
    source_table TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    deprecated INTEGER DEFAULT 0,
    metadata TEXT
);

CREATE TABLE IF NOT EXISTS graph_edges (
    id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    source_type TEXT NOT NULL,
    target_type TEXT NOT NULL,
    relationship_type TEXT NOT NULL,
    edge_category TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.5,
    evidence TEXT,
    created_at TEXT NOT NULL,
    last_validated_at TEXT NOT NULL,
    deprecated INTEGER DEFAULT 0,
    prediction_count INTEGER DEFAULT 0,
    prediction_hits INTEGER DEFAULT 0,
    momentum REAL DEFAULT 0.0,
    FOREIGN KEY (source_id) REFERENCES graph_nodes(id),
    FOREIGN KEY (target_id) REFERENCES graph_nodes(id)
);

-- Strategies
CREATE TABLE IF NOT EXISTS strategies (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.5,
    observation_count INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    deprecated INTEGER DEFAULT 0,
    superseded_by TEXT
);

-- Embeddings
CREATE TABLE IF NOT EXISTS reflection_embeddings (
    id TEXT PRIMARY KEY,
    reflection_id TEXT NOT NULL UNIQUE,
    embedding BLOB NOT NULL,
    embedding_dimension INTEGER NOT NULL,
    model_version TEXT NOT NULL DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reflection_id) REFERENCES memory_reflections(id)
);

-- Interaction Profile
CREATE TABLE IF NOT EXISTS interaction_profile (
    id TEXT PRIMARY KEY,
    dimension TEXT NOT NULL UNIQUE,
    score REAL NOT NULL DEFAULT 0.0,
    confidence REAL NOT NULL DEFAULT 0.0,
    evidence_count INTEGER DEFAULT 0,
    evidence_ids TEXT,
    last_synthesized TEXT NOT NULL,
    created_at TEXT NOT NULL
);

-- Conversations
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    summary TEXT,
    keywords TEXT
);

CREATE TABLE IF NOT EXISTS conversation_summaries (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    summary TEXT NOT NULL,
    keywords TEXT,
    key_topics TEXT,
    status_markers TEXT,
    pending_items TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
);

-- Audit & Logging
CREATE TABLE IF NOT EXISTS rule_executions (
    id TEXT PRIMARY KEY,
    conversation_id TEXT,
    rule_name TEXT NOT NULL,
    fired_at TEXT NOT NULL,
    reflections_affected TEXT,
    outcome TEXT
);

CREATE TABLE IF NOT EXISTS consolidation_log (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    entries_before INTEGER,
    entries_after INTEGER,
    changelog TEXT,
    duration_ms INTEGER,
    model_used TEXT,
    tokens_used INTEGER
);

CREATE TABLE IF NOT EXISTS novelty_log (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    conversation_id TEXT,
    candidate_text TEXT,
    novelty_score REAL,
    reasoning TEXT,
    contradicts TEXT,
    accepted INTEGER,
    method TEXT
);

CREATE TABLE IF NOT EXISTS strategy_observations (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    conversation_id TEXT,
    observation TEXT NOT NULL,
    type TEXT NOT NULL,
    source TEXT NOT NULL,
    confidence REAL,
    raw_evidence TEXT
);

CREATE TABLE IF NOT EXISTS scheduler_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS context_quality (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    context_loaded_tokens INTEGER,
    context_sufficient INTEGER,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);
"""

_INDEX_SQL = """
-- Memory reflections indexes
CREATE INDEX IF NOT EXISTS idx_reflections_type ON memory_reflections(type) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_reflections_confidence
    ON memory_reflections(confidence) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_reflections_timestamp
    ON memory_reflections(timestamp) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_reflections_source_session
    ON memory_reflections(source_session) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_reflections_epistemic
    ON memory_reflections(epistemic_status) WHERE deprecated = 0;

-- User facts indexes
CREATE INDEX IF NOT EXISTS idx_facts_category ON user_facts(category) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_facts_key ON user_facts(category, key) WHERE deprecated = 0;

-- Session context indexes
CREATE INDEX IF NOT EXISTS idx_session_started ON session_context(started_at);

-- Graph indexes
CREATE INDEX IF NOT EXISTS idx_nodes_type ON graph_nodes(node_type) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_nodes_source_table ON graph_nodes(source_table) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_edges_source ON graph_edges(source_id) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_edges_target ON graph_edges(target_id) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_edges_type
    ON graph_edges(relationship_type) WHERE deprecated = 0;
CREATE UNIQUE INDEX IF NOT EXISTS idx_edges_active_pair
    ON graph_edges(source_id, target_id, relationship_type) WHERE deprecated = 0;

-- Strategies indexes
CREATE INDEX IF NOT EXISTS idx_strategies_type ON strategies(type) WHERE deprecated = 0;
CREATE INDEX IF NOT EXISTS idx_strategies_confidence
    ON strategies(confidence) WHERE deprecated = 0;

-- Embeddings indexes
CREATE INDEX IF NOT EXISTS idx_embeddings_reflection
    ON reflection_embeddings(reflection_id);

-- Conversation indexes
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status);
CREATE INDEX IF NOT EXISTS idx_summaries_conversation
    ON conversation_summaries(conversation_id);

-- Logging indexes
CREATE INDEX IF NOT EXISTS idx_novelty_log_conversation
    ON novelty_log(conversation_id);
CREATE INDEX IF NOT EXISTS idx_strategy_obs_type
    ON strategy_observations(type);
"""

_FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS conversations_fts USING fts5(
    conversation_id, summary, keywords, content='conversation_summaries'
);
"""


class Database:
    """SQLite database wrapper with WAL mode and schema management.

    Args:
        db_path: Path to the SQLite database file. Use ":memory:" for in-memory DB.
    """

    def __init__(self, db_path: Path | str = ":memory:") -> None:
        self._db_path = str(db_path)
        self._conn: sqlite3.Connection | None = None

    @property
    def connection(self) -> sqlite3.Connection:
        """Get or create the database connection."""
        if self._conn is None:
            self._conn = self._create_connection()
        return self._conn

    def _create_connection(self) -> sqlite3.Connection:
        """Create a new SQLite connection with WAL mode and optimized settings."""
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA cache_size=-8000")  # 8MB cache
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def ensure_tables(self) -> None:
        """Create all tables, indexes, and FTS tables if they don't exist."""
        conn = self.connection
        conn.executescript(_SCHEMA_SQL)
        conn.executescript(_INDEX_SQL)

        # FTS tables need special handling — check if already exists
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
        )
        if cursor.fetchone() is None:
            conn.executescript(_FTS_SQL)

        # Set schema version if not already set
        cursor = conn.execute("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1")
        row = cursor.fetchone()
        if row is None:
            conn.execute("INSERT INTO schema_version (version) VALUES (?)", (_SCHEMA_VERSION,))
            conn.commit()

        # Migration: add pinned column if missing (added in Phase 2.3)
        try:
            conn.execute("SELECT pinned FROM memory_reflections LIMIT 0")
        except sqlite3.OperationalError:
            conn.execute("ALTER TABLE memory_reflections ADD COLUMN pinned INTEGER DEFAULT 0")
            conn.commit()
            logger.info("Migration: added pinned column to memory_reflections")

        # Migration: add momentum column for Titans-inspired confidence accumulation
        try:
            conn.execute("SELECT momentum FROM graph_edges LIMIT 0")
        except sqlite3.OperationalError:
            conn.execute("ALTER TABLE graph_edges ADD COLUMN momentum REAL DEFAULT 0.0")
            conn.commit()
            logger.info("Migration: added momentum column to graph_edges")

        logger.info("Database schema ensured (version %d)", _SCHEMA_VERSION)

    def get_schema_version(self) -> int:
        """Return the current schema version."""
        try:
            cursor = self.connection.execute(
                "SELECT version FROM schema_version ORDER BY version DESC LIMIT 1"
            )
            row = cursor.fetchone()
            return int(row["version"]) if row else 0
        except sqlite3.OperationalError:
            return 0

    def execute_read(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        """Execute a read query and return results as list of dicts.

        Args:
            sql: SQL query string.
            params: Query parameters.

        Returns:
            List of row dicts.
        """
        cursor = self.connection.execute(sql, params)
        return [dict(row) for row in cursor.fetchall()]

    def execute_read_one(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        """Execute a read query and return a single result or None.

        Args:
            sql: SQL query string.
            params: Query parameters.

        Returns:
            Row dict or None.
        """
        cursor = self.connection.execute(sql, params)
        row = cursor.fetchone()
        return dict(row) if row else None

    def execute_write(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Cursor:
        """Execute a write query within a transaction.

        Args:
            sql: SQL statement.
            params: Statement parameters.

        Returns:
            The cursor after execution.
        """
        cursor = self.connection.execute(sql, params)
        self.connection.commit()
        return cursor

    def execute_write_many(self, sql: str, params_list: list[tuple[Any, ...]]) -> None:
        """Execute a write query for multiple parameter sets in a single transaction.

        Args:
            sql: SQL statement.
            params_list: List of parameter tuples.
        """
        conn = self.connection
        conn.executemany(sql, params_list)
        conn.commit()

    def execute_script(self, sql: str) -> None:
        """Execute a multi-statement SQL script.

        Args:
            sql: SQL script text.
        """
        self.connection.executescript(sql)

    def acquire_advisory_lock(
        self,
        lock_name: str,
        holder: str,
        timeout_seconds: int = 600,
    ) -> bool:
        """Acquire a named advisory lock using the ``limen_locks`` table.

        The lock is granted when no lock exists for *lock_name* or the
        existing lock is stale (older than *timeout_seconds*).  Uses an
        atomic INSERT-or-UPDATE pattern so concurrent callers cannot both
        succeed.

        Args:
            lock_name: Logical lock name (e.g., ``"reflection"``).
            holder: Unique identifier for the caller (e.g., PID or session ID).
            timeout_seconds: Seconds after which an existing lock is
                considered stale and may be stolen.

        Returns:
            ``True`` if the lock was acquired, ``False`` otherwise.
        """
        now = datetime.utcnow().isoformat()
        conn = self.connection

        # Ensure the locks table exists (idempotent).
        conn.execute(
            "CREATE TABLE IF NOT EXISTS limen_locks "
            "(lock_name TEXT PRIMARY KEY, acquired_at TEXT NOT NULL, holder TEXT NOT NULL)"
        )

        # Try to insert a fresh lock row.
        try:
            conn.execute(
                "INSERT INTO limen_locks (lock_name, acquired_at, holder) VALUES (?, ?, ?)",
                (lock_name, now, holder),
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            pass  # Row exists — check staleness below

        row = self.execute_read_one(
            "SELECT acquired_at, holder FROM limen_locks WHERE lock_name = ?",
            (lock_name,),
        )
        if row is None:
            # Deleted between INSERT and SELECT — retry once.
            try:
                conn.execute(
                    "INSERT INTO limen_locks (lock_name, acquired_at, holder) VALUES (?, ?, ?)",
                    (lock_name, now, holder),
                )
                conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False

        acquired_at = datetime.fromisoformat(row["acquired_at"])
        age = (datetime.utcnow() - acquired_at).total_seconds()
        if age <= timeout_seconds:
            return False  # Lock still fresh — held by another process

        # Stale lock — attempt atomic steal.
        cursor = conn.execute(
            "UPDATE limen_locks SET acquired_at = ?, holder = ? "
            "WHERE lock_name = ? AND acquired_at = ?",
            (now, holder, lock_name, row["acquired_at"]),
        )
        conn.commit()
        return cursor.rowcount > 0

    def release_advisory_lock(self, lock_name: str, holder: str) -> bool:
        """Release a previously acquired advisory lock.

        Only the holder that acquired the lock can release it.

        Args:
            lock_name: Logical lock name.
            holder: Identifier used when the lock was acquired.

        Returns:
            ``True`` if the lock was released, ``False`` if not held
            by *holder* or does not exist.
        """
        try:
            cursor = self.connection.execute(
                "DELETE FROM limen_locks WHERE lock_name = ? AND holder = ?",
                (lock_name, holder),
            )
            self.connection.commit()
            return cursor.rowcount > 0
        except sqlite3.OperationalError:
            # Table doesn't exist — lock was never acquired.
            return False

    def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> Database:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def table_count(self, table: str, where: str = "", params: tuple[Any, ...] = ()) -> int:
        """Return the count of rows in a table with optional WHERE clause.

        Args:
            table: Table name.
            where: Optional WHERE clause (without the WHERE keyword).
            params: Query parameters for the WHERE clause.

        Returns:
            Row count.
        """
        sql = f"SELECT COUNT(*) as cnt FROM {table}"  # noqa: S608  # nosec B608
        if where:
            sql += f" WHERE {where}"
        row = self.execute_read_one(sql, params)
        return int(row["cnt"]) if row else 0
