"""All thresholds and constants for limen.

Titans-inspired improvements (arXiv:2501.00663): continuous exponential decay
replaces binary step functions for novelty, recency, and edge aging. Momentum-
based confidence accumulation replaces fixed +/- deltas. Activity-pressure
aging modulates forgetting rate by topic area activity.
"""

# --- Novelty ---
EMBEDDING_REJECT_SIMILARITY: float = 0.92
EMBEDDING_ACCEPT_SIMILARITY: float = 0.70
LLM_NOVELTY_ACCEPTANCE: float = 0.45
# Continuous temporal decay: similarity *= exp(-age / half_life)
# At half_life days, discount factor = exp(-1) ≈ 0.37.
# 30d → 0.85, 90d → 0.61, 180d → 0.37, 365d → 0.13
NOVELTY_TEMPORAL_HALF_LIFE: float = 180.0

assert (  # nosec B101
    EMBEDDING_REJECT_SIMILARITY > EMBEDDING_ACCEPT_SIMILARITY
), "Reject threshold must be higher than accept threshold"

# --- Working Memory ---
WORKING_MEMORY_SIMILARITY_THRESHOLD: float = 0.55
WORKING_MEMORY_EDGE_CONFIDENCE: float = 0.5
WORKING_MEMORY_EVIDENCE_PREFIX: str = "Working memory similarity"

# --- Markers ---
MARKER_EDGE_CONFIDENCE: float = 0.7

# --- Graph ---
GRAPH_TRAVERSAL_MIN_CONFIDENCE: float = 0.4
GRAPH_TRAVERSAL_MAX_HOPS: int = 2
GRAPH_DISCOVERED_CAP: int = 5

# --- Relevance ---
RELEVANCE_REFLECTION_THRESHOLD: float = 0.45
RELEVANCE_SUMMARY_THRESHOLD: float = 0.40

# --- Strategies ---
STRATEGY_INJECTION_THRESHOLD: float = 0.7
STRATEGY_DEPRECATION_THRESHOLD: float = 0.3
STRATEGY_CONFIDENCE_DECAY: float = 0.05

# --- Aging ---
EVALUATIVE_STALENESS_DAYS: int = 60
# Time-continuous edge decay: confidence *= exp(-days_stale / half_life)
# Decoupled from scheduler frequency — identical behavior regardless of tick rate.
EDGE_DECAY_HALF_LIFE: float = 50.0
PREDICTION_STALENESS_DAYS: int = 30
PREDICTION_EDGE_DECAY_HALF_LIFE: float = 30.0
PREDICTION_DECAY_HIT_RATE_THRESHOLD: float = 0.3
EDGE_DEPRECATION_THRESHOLD: float = 0.2

# --- Predictions ---
# Momentum-based confidence: direction accumulates over observations.
# Consistent evidence accelerates; oscillating evidence stalls.
CONFIDENCE_MOMENTUM: float = 0.7
BASE_CONFIDENCE_STEP: float = 0.05
PREDICTION_SURFACING_MIN_CONFIDENCE: float = 0.4
PREDICTION_SURFACING_CAP: int = 3

# --- Context ---
CONTEXT_BUDGET_CHARS: int = 6000
SESSION_BRIDGE_MAX_AGE_DAYS: int = 7
CONTINUING_MODE_KEYWORD_OVERLAP: int = 3
CONTINUING_MODE_TIME_PROXIMITY_HOURS: int = 4
STRATEGY_BUDGET_CHARS: int = 500
PROFILE_BUDGET_CHARS: int = 400
RULES_BUDGET_CHARS: int = 400
RELEVANCE_FALLBACK_MIN_RESULTS: int = 3
RELEVANCE_FALLBACK_LIMIT: int = 7
RELEVANCE_FALLBACK_POOL_SIZE: int = 20
USER_FACTS_PER_CATEGORY_CAP: int = 3

# --- Scheduler ---
CONSOLIDATION_INTERVAL_HOURS: int = 24
CONSOLIDATION_MIN_REFLECTIONS: int = 5
CROSS_ANALYSIS_INTERVAL_HOURS: int = 12
CROSS_ANALYSIS_MIN_CONVERSATIONS: int = 3
STRATEGY_REVIEW_INTERVAL_HOURS: int = 48
PRUNING_INTERVAL_DAYS: int = 7
AGING_INTERVAL_DAYS: int = 7
DATABASE_BACKUP_INTERVAL_HOURS: int = 24
PREDICTION_VALIDATION_INTERVAL_HOURS: int = 24
PREDICTION_VALIDATION_MIN_EDGES: int = 3
PROFILE_SYNTHESIS_INTERVAL_HOURS: int = 48
PROFILE_SYNTHESIS_MIN_EVIDENCE: int = 3

# --- Embeddings ---
EMBEDDING_MODEL: str = ""
EMBEDDING_DIMENSIONS: int = 0
EMBEDDING_BATCH_SIZE: int = 128
EMBEDDING_TIMEOUT_SECONDS: int = 30

# Provider-specific defaults (model, dimensions) applied when the user
# configures a provider but does not override model/dimensions.
EMBEDDING_PROVIDER_DEFAULTS: dict[str, dict[str, str | int]] = {
    "openai": {"model": "text-embedding-3-small", "dimensions": 1536},
    "ollama": {"model": "embeddinggemma", "dimensions": 768},
}

# --- Profile ---
PROFILE_EVIDENCE_CONFIDENCE_FACTOR: float = 0.15
PROFILE_DIMENSION_CONFIDENCE_FLOOR: float = 0.3

# --- Graph Weights (relationship type → traversal weight) ---
GRAPH_WEIGHT_REINFORCES: float = 1.0
GRAPH_WEIGHT_REQUIRES: float = 0.9
GRAPH_WEIGHT_REFINES: float = 0.8
GRAPH_WEIGHT_PREDICTS: float = 0.7
GRAPH_WEIGHT_CONTRADICTS: float = 0.6

GRAPH_WEIGHTS: dict[str, float] = {
    "reinforces": GRAPH_WEIGHT_REINFORCES,
    "requires": GRAPH_WEIGHT_REQUIRES,
    "refines": GRAPH_WEIGHT_REFINES,
    "predicts": GRAPH_WEIGHT_PREDICTS,
    "contradicts": GRAPH_WEIGHT_CONTRADICTS,
}

# --- Confidence ---
CONFIDENCE_HIGH: float = 1.0
CONFIDENCE_MEDIUM: float = 0.7
CONFIDENCE_LOW: float = 0.4
CONFIDENCE_SPECULATION: float = 0.1

CONFIDENCE_MAP: dict[str, float] = {
    "high": CONFIDENCE_HIGH,
    "medium": CONFIDENCE_MEDIUM,
    "low": CONFIDENCE_LOW,
    "speculation": CONFIDENCE_SPECULATION,
}

assert (  # nosec B101
    CONFIDENCE_HIGH > CONFIDENCE_MEDIUM > CONFIDENCE_LOW > CONFIDENCE_SPECULATION
), "Confidence levels must be strictly descending"

# --- Hybrid Search ---
HYBRID_WEIGHT_SEMANTIC: float = 0.35
HYBRID_WEIGHT_KEYWORD: float = 0.20
HYBRID_WEIGHT_RECENCY: float = 0.20
HYBRID_WEIGHT_CONFIDENCE: float = 0.15
HYBRID_WEIGHT_GRAPH: float = 0.10
HYBRID_MIN_SIMILARITY: float = 0.3

# Exponential recency: exp(-days / half_life).
# 1d → 0.99, 30d → 0.72, 90d → 0.37, 365d → 0.02
RECENCY_HALF_LIFE: float = 90.0

assert (  # nosec B101
    abs(
        sum(
            [
                HYBRID_WEIGHT_SEMANTIC,
                HYBRID_WEIGHT_KEYWORD,
                HYBRID_WEIGHT_RECENCY,
                HYBRID_WEIGHT_CONFIDENCE,
                HYBRID_WEIGHT_GRAPH,
            ]
        )
        - 1.0
    )
    < 0.001
), "Hybrid search weights must sum to 1.0"

# --- Predictions ---
PREDICTION_RELEVANCE_MIN: float = 0.1
PREDICTION_HIGH_CONFIDENCE_OVERRIDE: float = 0.7

# --- Strategy Feedback ---
FEEDBACK_POSITIVE_CONFIDENCE: float = 0.5
FEEDBACK_NEGATIVE_CONFIDENCE: float = 0.5
FEEDBACK_REDIRECT_CONFIDENCE: float = 0.4
FEEDBACK_SUMMARY_MAX_CHARS: int = 100

# --- Consolidation ---
CONSOLIDATION_BATCH_SIZE: int = 50
CONSOLIDATION_SUMMARY_CONTEXT_LIMIT: int = 10
CONSOLIDATION_MAX_TOKENS: int = 8192
CONSOLIDATION_TIMEOUT_SECONDS: int = 300

# --- Scheduler Retry ---
SCHEDULER_MAX_FAILURES: int = 3
SCHEDULER_BACKOFF_MULTIPLIER: int = 2

# --- Backfill ---
EDGE_BACKFILL_MIN_DENSITY_RATIO: float = 0.1

# --- Cross-Analysis ---
CROSS_ANALYSIS_SUMMARIES_LIMIT: int = 15

# --- Profile Dimensions ---
PROFILE_DIMENSIONS: list[str] = [
    "processing_style",
    "detail_preference",
    "challenge_tolerance",
    "structure_preference",
    "autonomy_preference",
]

# Dimension metadata for rich profile formatting (ported from Wren)
PROFILE_DIMENSION_METADATA: dict[str, dict[str, str]] = {
    "processing_style": {
        "low_label": "Internal processor",
        "high_label": "External processor",
        "low_advice": "Give space for their conclusions before elaborating. Ask before expanding.",
        "high_advice": ("Engage collaboratively, think alongside them, welcome thinking aloud."),
    },
    "detail_preference": {
        "low_label": "Concise/bottom-line",
        "high_label": "Thorough/comprehensive",
        "low_advice": "Lead with the answer, expand only if asked.",
        "high_advice": ("Provide reasoning, context, and alternatives alongside answers."),
    },
    "challenge_tolerance": {
        "low_label": "Prefers validation",
        "high_label": "Wants pushback",
        "low_advice": ("Affirm before suggesting alternatives, be diplomatic."),
        "high_advice": (
            "Proactively question assumptions, flag weaknesses, play devil's advocate."
        ),
    },
    "structure_preference": {
        "low_label": "Flexible/exploratory",
        "high_label": "Systematic/sequential",
        "low_advice": ("Follow the conversation's natural flow, avoid rigid frameworks."),
        "high_advice": ("Outline steps, use numbered lists, provide clear structure."),
    },
    "autonomy_preference": {
        "low_label": "Wants guidance",
        "high_label": "Wants independence",
        "low_advice": ("Make recommendations, explain trade-offs, suggest next steps."),
        "high_advice": ("Present information and options rather than prescribing solutions."),
    },
}

# --- Relevance Scoring (Phase 1: keyword-only mode) ---
RELEVANCE_WEIGHT_TOPIC: float = 0.4
RELEVANCE_WEIGHT_RECENCY: float = 0.3
RELEVANCE_WEIGHT_CONFIDENCE: float = 0.2
RELEVANCE_WEIGHT_EDGES: float = 0.1

# --- Reflection Aging Thresholds ---
REFLECTION_AGE_MEDIUM_TO_LOW_DAYS: int = 30
REFLECTION_AGE_LOW_TO_SPECULATION_DAYS: int = 30
REFLECTION_AGE_SPECULATION_TO_DEPRECATED_DAYS: int = 14

# --- Activity-Pressure Aging ---
# Data-dependent forgetting: reflections in active topic areas age faster.
# effective_age = calendar_age * (1 + topic_activity * ACTIVITY_PRESSURE_FACTOR)
ACTIVITY_PRESSURE_FACTOR: float = 0.15
# Minimum recent reflections in graph neighborhood before high-confidence begins aging
HIGH_CONFIDENCE_ACTIVITY_THRESHOLD: int = 8
# Window for counting "recent" activity in a topic area
ACTIVITY_PRESSURE_WINDOW_DAYS: int = 30
