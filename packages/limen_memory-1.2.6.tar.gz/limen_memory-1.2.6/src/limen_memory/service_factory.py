"""Shared service instantiation for CLI and MCP server.

Extracts the service graph creation from cli.py so both CLI commands
and the MCP server can instantiate the full dependency tree without
duplication.
"""

from __future__ import annotations

import logging
from typing import Any

from limen_memory.config import LimenConfig
from limen_memory.store.conversation_store import ConversationStore
from limen_memory.store.database import Database
from limen_memory.store.embedding_store import EmbeddingStore
from limen_memory.store.graph_store import GraphStore
from limen_memory.store.memory_store import MemoryStore
from limen_memory.store.profile_store import ProfileStore
from limen_memory.store.strategy_store import StrategyStore

logger = logging.getLogger(__name__)


def create_services(config: LimenConfig, db: Database) -> dict[str, Any]:
    """Create all service instances with dependency injection.

    Builds the full service graph: stores, clients, and services.
    When no embedding provider is configured, embedding-dependent services
    (``embedding_client``, ``novelty``, ``reflection``) are set to ``None``
    so the rest of the system degrades gracefully.

    Args:
        config: Limen configuration.
        db: Database instance (must have tables ensured).

    Returns:
        Dict of service instances keyed by name.  Embedding-dependent
        values may be ``None`` when no embedding provider is configured.
    """
    from limen_memory.services.embedding.factory import create_embedding_client
    from limen_memory.services.llm_client import LLMClient

    memory_store = MemoryStore(db)
    graph_store = GraphStore(db)
    embedding_store = EmbeddingStore(db)
    conversation_store = ConversationStore(db)
    strategy_store = StrategyStore(db)
    profile_store = ProfileStore(db)

    llm_client = LLMClient(model=config.claude_model, timeout=config.claude_timeout)
    novelty_llm_client = LLMClient(model=config.claude_novelty_model, timeout=config.claude_timeout)

    # Embedding-dependent services require a configured embedding provider.
    embedding_client = create_embedding_client(config)

    # Validate embedding connectivity at startup.
    if embedding_client is not None:
        if not embedding_client.validate_connection():
            logger.warning(
                "Embedding provider (%s) is not reachable — "
                "disabling embedding-dependent services for this session.",
                config.embedding_provider,
            )
            embedding_client = None

    # Warn if stored embeddings have different dimensions than the current provider.
    if embedding_client is not None:
        stored_dim = embedding_store.get_stored_dimension()
        configured_dim = embedding_client._dimensions
        if stored_dim is not None and stored_dim != configured_dim:
            logger.warning(
                "Stored embeddings have dimension %d but the configured provider "
                "(%s) produces dimension %d. Semantic search will not work correctly. "
                "Either switch back to the original provider or re-embed all reflections.",
                stored_dim,
                config.embedding_provider,
                configured_dim,
            )

    from limen_memory.services.strategy_service import StrategyService

    strategy_service = StrategyService(
        strategy_store=strategy_store,
        conversation_store=conversation_store,
        llm_client=llm_client,
    )

    novelty_filter: Any = None
    reflection_service: Any = None

    if embedding_client is not None:
        from limen_memory.services.novelty_filter import NoveltyFilter
        from limen_memory.services.reflection import ReflectionService

        novelty_filter = NoveltyFilter(
            embedding_client=embedding_client,
            embedding_store=embedding_store,
            llm_client=novelty_llm_client,
            conversation_store=conversation_store,
        )

        reflection_service = ReflectionService(
            llm_client=llm_client,
            embedding_client=embedding_client,
            novelty_filter=novelty_filter,
            memory_store=memory_store,
            graph_store=graph_store,
            embedding_store=embedding_store,
            conversation_store=conversation_store,
            strategy_store=strategy_store,
            profile_store=profile_store,
            strategy_service=strategy_service,
        )

    from limen_memory.rules.behavioral_directive import BehavioralDirectiveRule
    from limen_memory.rules.contradiction_detection import ContradictionDetectionRule
    from limen_memory.rules.engine import RuleEngine
    from limen_memory.rules.high_confidence_injection import HighConfidenceInjectionRule
    from limen_memory.rules.prediction_surfacing import PredictionSurfacingRule
    from limen_memory.rules.preference_application import PreferenceApplicationRule
    from limen_memory.services.context_loader import ContextLoader

    rule_engine = RuleEngine(db=db)
    rule_engine.register(ContradictionDetectionRule(graph_store, memory_store))
    rule_engine.register(HighConfidenceInjectionRule(memory_store, graph_store))
    rule_engine.register(BehavioralDirectiveRule(memory_store))
    rule_engine.register(PreferenceApplicationRule())
    rule_engine.register(PredictionSurfacingRule(graph_store))

    context_loader = ContextLoader(
        memory_store=memory_store,
        graph_store=graph_store,
        embedding_store=embedding_store,
        embedding_client=embedding_client,
        conversation_store=conversation_store,
        strategy_service=strategy_service,
        profile_store=profile_store,
        rule_engine=rule_engine,
    )

    return {
        "memory": memory_store,
        "graph": graph_store,
        "embedding": embedding_store,
        "conversation": conversation_store,
        "strategy": strategy_store,
        "profile": profile_store,
        "llm": llm_client,
        "embedding_client": embedding_client,
        "novelty": novelty_filter,
        "reflection": reflection_service,
        "context_loader": context_loader,
        "rule_engine": rule_engine,
        "strategy_service": strategy_service,
    }
