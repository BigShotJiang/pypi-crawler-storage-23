"""MCP server for limen-memory — tool registration and lifespan management.

Provides 5 core tools (Phase 1):
    limen_context  — Load tiered session context
    limen_learn    — Record a user fact
    limen_reflect  — Add a single reflection with novelty gating
    limen_query    — Hybrid search over reflections
    limen_status   — Health check and database statistics

Extended tools (Phase 2):
    limen_user_profile          — View user facts
    limen_interaction_profile   — View interaction profile dimensions
    limen_search_conversations  — Full-text search over conversations
    limen_graph_inspect         — Inspect knowledge graph nodes and edges
    limen_deprecate             — Soft-delete a reflection
    limen_pin                   — Pin/unpin a reflection (immune to aging)
    limen_consolidate           — Run LLM-driven memory consolidation
    limen_scheduler_tick        — Execute one scheduler maintenance task
    limen_reflect_transcript    — Reflect on a full conversation transcript
    limen_feedback              — Record feedback signal to refine strategies

Resources (Phase 3):
    limen://profile      — Current user profile (all facts, formatted)
    limen://strategies   — Active behavioral strategies
    limen://predictions  — Pending prediction edges
    limen://status       — System status snapshot

The server shares the same service layer as the CLI.  Services are
created once at startup and stored in the lifespan context so every
tool handler can access them without re-initialisation.
"""

from __future__ import annotations

import json as _json
import logging
import os
import shutil
import subprocess  # nosec B404
import tempfile
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

from mcp.server.fastmcp import Context, FastMCP
from mcp.server.fastmcp.resources import FunctionResource

from limen_memory.config import LimenConfig, ensure_data_dir, load_config
from limen_memory.store.database import Database

_MCP_VERSION = "0.1.4"


# ---------------------------------------------------------------------------
# Lifespan — open DB, build services, yield them, close DB on shutdown
# ---------------------------------------------------------------------------


class _LifespanState:
    """Container for objects created during server lifespan."""

    def __init__(
        self,
        config: LimenConfig,
        db: Database,
        services: dict[str, Any],
    ) -> None:
        self.config = config
        self.db = db
        self.services = services


def _register_resources(
    server: FastMCP,
    state: _LifespanState,
) -> None:
    """Register MCP resources as closures that capture lifespan state.

    Resources are read-only snapshots refreshed on each access.
    Registered during lifespan so closures can reference services.
    """
    from limen_memory.store.graph_store import GraphStore
    from limen_memory.store.memory_store import MemoryStore
    from limen_memory.store.strategy_store import StrategyStore

    services = state.services
    memory: MemoryStore = services["memory"]
    strategy: StrategyStore = services["strategy"]
    graph: GraphStore = services["graph"]

    # limen://profile — formatted user facts grouped by category
    def _profile_resource() -> str:
        return memory.get_all_user_facts_formatted()

    server.add_resource(
        FunctionResource.from_function(
            fn=_profile_resource,
            uri="limen://profile",
            name="limen_profile",
            description="Current user profile: all known facts grouped by category.",
            mime_type="text/plain",
        )
    )

    # limen://strategies — active behavioral strategies as JSON
    def _strategies_resource() -> str:
        strategies = strategy.get_all_strategies(include_deprecated=False)
        return _json.dumps(
            [
                {
                    "id": s.id,
                    "type": s.type,
                    "content": s.content,
                    "confidence": round(s.confidence, 3),
                    "observation_count": s.observation_count,
                    "created_at": s.created_at,
                    "updated_at": s.updated_at,
                }
                for s in strategies
            ],
            indent=2,
        )

    server.add_resource(
        FunctionResource.from_function(
            fn=_strategies_resource,
            uri="limen://strategies",
            name="limen_strategies",
            description="Active behavioral strategies with confidence scores.",
            mime_type="application/json",
        )
    )

    # limen://predictions — pending prediction edges as JSON
    def _predictions_resource() -> str:
        edges = graph.get_prediction_edges(limit=20)
        return _json.dumps(
            [
                {
                    "id": e.id,
                    "source_id": e.source_id,
                    "target_id": e.target_id,
                    "confidence": round(e.confidence, 3),
                    "evidence": e.evidence[:200] if e.evidence else "",
                    "created_at": e.created_at,
                }
                for e in edges
            ],
            indent=2,
        )

    server.add_resource(
        FunctionResource.from_function(
            fn=_predictions_resource,
            uri="limen://predictions",
            name="limen_predictions",
            description="Pending prediction edges that have not been validated yet.",
            mime_type="application/json",
        )
    )

    # limen://status — system status snapshot as JSON
    def _status_resource() -> str:
        reflection_count = memory.get_reflection_count()
        fact_count = memory.get_user_fact_count()
        diagnostics = graph.get_graph_diagnostics()
        scheduler_rows = state.db.execute_read("SELECT * FROM scheduler_state")
        scheduler_state = {r["key"]: r["value"] for r in scheduler_rows}
        return _json.dumps(
            {
                "reflections": reflection_count,
                "user_facts": fact_count,
                "graph_nodes": diagnostics.active_nodes,
                "graph_edges": diagnostics.active_edges,
                "orphan_nodes": diagnostics.orphan_nodes,
                "avg_edge_confidence": round(diagnostics.avg_edge_confidence, 3),
                "scheduler_state": scheduler_state,
                "db_path": str(state.config.db_path),
                "embedding_configured": services.get("embedding_client") is not None,
                "mcp_version": _MCP_VERSION,
            },
            indent=2,
        )

    server.add_resource(
        FunctionResource.from_function(
            fn=_status_resource,
            uri="limen://status",
            name="limen_status_resource",
            description="System health: reflection/fact counts, graph stats, scheduler state.",
            mime_type="application/json",
        )
    )


@asynccontextmanager
async def _lifespan(server: FastMCP) -> AsyncIterator[_LifespanState]:
    """Server lifespan: create config, DB, and services on startup."""
    config = load_config()
    ensure_data_dir(config)
    db = Database(config.db_path)
    db.ensure_tables()

    from limen_memory.service_factory import create_services

    services = create_services(config, db)
    state = _LifespanState(config=config, db=db, services=services)
    _register_resources(server, state)
    try:
        yield state
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

_MCP_INSTRUCTIONS = """\
Limen-memory is a personal memory system with persistent reflections, user facts, \
strategies, and a knowledge graph.

You are operating WITHOUT automatic hooks (no session-start or session-end \
automation). You must be proactive about all memory operations:

AT CONVERSATION START:
- Call limen_context with a relevant query when past context would help \
(references to previous work, "continue", "as we discussed", project names).
- Mode is auto-detected: fresh (new topic), continuing (keyword overlap with \
last session), recall (explicit past references).

DURING CONVERSATION:
- Call limen_learn when the user reveals facts: preferences, tools, expertise, \
work context, communication style, projects, goals. Categories: preferences, \
tools, expertise, work_context, communication_style, interests, personal.
- Call limen_reflect for genuine insights worth persisting: behavioral patterns, \
effective approaches, domain connections, hypotheses. Source types: insight, \
observation, pattern, hypothesis.
- Call limen_query before answering questions where accumulated memory would \
improve the response.

WRITING GOOD REFLECTIONS:
Reflections pass through a novelty filter that rejects content too similar to \
existing entries. To maximize acceptance:
- BEFORE reflecting, call limen_query on the topic to see what is already stored. \
If the insight is already captured, skip it. If it adds a new angle, phrase the \
reflection to emphasize only the delta — what is new.
- Write specific, concrete claims rather than broad thematic summaries. \
Bad: "Dennis works on local AI systems." \
Good: "Limen config bug revealed that env-var-first priority in layered config \
systems silently fails when a layer injects truthy garbage like literal \
${VAR_NAME} strings."
- Focus each reflection on ONE distinct insight. Do not combine multiple ideas \
into a single reflection — split them.
- Avoid restating shared context. The reflection should be meaningful on its own \
without needing the surrounding conversation to interpret it.

AT CONVERSATION END (substantive conversations only):
- Call limen_reflect_transcript with a summary of key exchanges. It returns \
immediately — the full reflection pipeline (LLM analysis, novelty filtering, \
fact extraction, strategy observations, graph edges) runs in the background.
- Skip for trivial interactions (quick lookups, brief Q&A).

MAINTENANCE:
- Call limen_scheduler_tick once per conversation. It returns immediately — the \
highest-priority maintenance task runs in the background.

PRINCIPLES:
- Learn facts as you observe them — don't batch.
- Quality over quantity — genuine insights beat shallow observations.
- Soft delete only — use limen_deprecate, never hard delete.
- Evidence accumulates — confidence grows with repeated observations.
"""

mcp_server = FastMCP(
    name="limen-memory",
    instructions=_MCP_INSTRUCTIONS,
    lifespan=_lifespan,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


def _uid() -> str:
    return uuid.uuid4().hex


def _get_state(ctx: Context) -> _LifespanState:
    """Extract lifespan state from the MCP request context."""
    return ctx.request_context.lifespan_context  # type: ignore[no-any-return]


logger = logging.getLogger(__name__)

# Common install locations checked when ``limen-memory`` is not on the inherited PATH.
_EXTRA_LIMEN_MEMORY_PATHS = [
    "/opt/homebrew/bin",
    "/usr/local/bin",
    os.path.expanduser("~/.local/bin"),
]


def _resolve_limen_memory_cli() -> str:
    """Find the ``limen-memory`` CLI binary on PATH or common locations.

    Returns:
        Absolute path to the ``limen-memory`` binary, or ``"limen-memory"`` as a
        last resort (will raise FileNotFoundError at call time).
    """
    found = shutil.which("limen-memory")
    if found:
        return found
    for directory in _EXTRA_LIMEN_MEMORY_PATHS:
        candidate = os.path.join(directory, "limen-memory")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return "limen-memory"


def _spawn_background(
    args: list[str],
    stdin_text: str | None = None,
    log_name: str = "limen-memory-mcp-bg",
) -> dict[str, Any]:
    """Spawn a limen-memory CLI command as a fire-and-forget background process.

    Args:
        args: CLI arguments after ``limen-memory`` (e.g., ``["consolidate"]``).
        stdin_text: Optional text to pipe to the subprocess's stdin.
        log_name: Base name for the stderr log file.

    Returns:
        Dict with ``status`` and ``message`` for immediate MCP response.
    """
    limen_path = _resolve_limen_memory_cli()
    cmd = [limen_path, "--json"] + args

    try:
        bg_log_path = os.path.join(tempfile.gettempdir(), f"{log_name}.log")
        bg_log = open(bg_log_path, "a")  # noqa: SIM115

        stdin_pipe = subprocess.PIPE if stdin_text else subprocess.DEVNULL
        proc = subprocess.Popen(  # nosec B603
            cmd,
            stdin=stdin_pipe,
            stdout=subprocess.DEVNULL,
            stderr=bg_log,
        )
        bg_log.close()  # Subprocess inherits the fd; parent can close its copy

        if stdin_text and proc.stdin:
            proc.stdin.write(stdin_text.encode("utf-8"))
            proc.stdin.close()

        logger.info("Spawned background: %s (pid=%d)", " ".join(args), proc.pid)
        return {
            "status": "spawned",
            "message": f"Task '{args[0]}' started in background (pid {proc.pid}).",
            "pid": proc.pid,
        }
    except FileNotFoundError:
        return {
            "status": "error",
            "message": "limen-memory CLI not found on PATH.",
        }
    except Exception as exc:
        logger.exception("Failed to spawn background task: %s", args)
        return {
            "status": "error",
            "message": f"Failed to spawn: {type(exc).__name__}: {exc}",
        }


# ---------------------------------------------------------------------------
# Tool: limen_context
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_context(
    ctx: Context,
    query: str = "",
    mode: str = "",
    include_rules: bool = True,
) -> dict[str, Any]:
    """Load tiered session context, optionally focused on a topic.

    Args:
        query: Topic to focus context on. Defaults to general context.
        mode: One of 'fresh', 'continuing', 'recall'. Auto-detected if omitted.
        include_rules: Whether to run the rule engine. Default true.
    """
    state = _get_state(ctx)
    services = state.services

    from limen_memory.services.context_loader import ContextLoader

    loader: ContextLoader = services["context_loader"]

    user_message = query or "general context"
    context_text = loader.load_context(user_message)
    detected_mode = loader.detect_mode(user_message)
    loaded_ids = loader.last_loaded_reflection_ids

    result: dict[str, Any] = {
        "mode": mode if mode else detected_mode.value,
        "context": context_text,
        "chars_used": len(context_text),
        "loaded_reflection_ids": sorted(loaded_ids),
        "degraded": loader.retrieval_degraded,
    }

    if include_rules:
        rule_results = loader.last_rule_results
        result["rules"] = [
            {
                "rule": r.rule_name,
                "fired": r.fired,
                "injected_text": r.injected_text[:200] if r.injected_text else "",
            }
            for r in rule_results
        ]

    tier_diags = loader.last_tier_diagnostics
    if tier_diags:
        result["tier_diagnostics"] = tier_diags

    return result


# ---------------------------------------------------------------------------
# Tool: limen_learn
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_learn(
    ctx: Context,
    category: str,
    key: str,
    value: str,
    confidence: str = "medium",
) -> dict[str, Any]:
    """Record a user fact. Idempotent — updates existing fact if category+key match.

    Args:
        category: Fact category (e.g., preferences, work, tools).
        key: Fact key (e.g., testing_framework).
        value: Fact value (e.g., pytest).
        confidence: low, medium, or high. Default medium.
    """
    state = _get_state(ctx)
    services = state.services

    from limen_memory.models import UserFact
    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = services["memory"]

    now = _now_iso()
    fact = UserFact(
        id=_uid(),
        category=category,
        key=key,
        value=value,
        confidence=confidence,
        first_observed=now,
        last_verified=now,
    )
    fact_id = memory.save_user_fact(fact)

    return {
        "id": fact_id,
        "category": category,
        "key": key,
        "value": value,
        "confidence": confidence,
    }


# ---------------------------------------------------------------------------
# Tool: limen_reflect
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_reflect(
    ctx: Context,
    content: str,
    source: str = "insight",
    confidence: str = "medium",
) -> dict[str, Any]:
    """Add a single reflection, passing through novelty gating.

    Requires a configured embedding provider for embedding and novelty filter.

    Args:
        content: The reflection text.
        source: Type: insight, observation, pattern, hypothesis. Default insight.
        confidence: low, medium, or high. Default medium.
    """
    state = _get_state(ctx)

    if not state.config.embedding_provider:
        return {
            "error": "Embedding provider is required for limen_reflect.",
            "rejected": True,
            "reason": "No embedding provider configured",
        }

    from limen_memory.services.reflection import ReflectionService

    reflection_svc: ReflectionService = state.services["reflection"]

    session_id = f"mcp-{_uid()[:8]}"
    reflection_id = reflection_svc.apply_single_reflection(
        content=content,
        reflection_type=source,
        session_id=session_id,
        confidence=confidence,
    )

    if reflection_id:
        return {"id": reflection_id, "accepted": True}
    else:
        return {
            "rejected": True,
            "reason": "Rejected by novelty filter (too similar to existing reflection)",
        }


# ---------------------------------------------------------------------------
# Tool: limen_query
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_query(
    ctx: Context,
    query: str,
    limit: int = 10,
    type: str = "",
    min_confidence: str = "",
) -> list[dict[str, Any]]:
    """Hybrid search over reflections (semantic + keyword + recency + confidence + graph).

    Args:
        query: Search topic.
        limit: Max results. Default 10.
        type: Filter by reflection type.
        min_confidence: Minimum confidence level.
    """
    state = _get_state(ctx)
    services = state.services

    from limen_memory.store.embedding_store import EmbeddingStore
    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = services["memory"]

    if services.get("embedding_client") is not None:
        try:
            embedding_client = services["embedding_client"]
            embedding_store: EmbeddingStore = services["embedding"]

            if embedding_store.has_embeddings():
                results = memory.query_reflections_hybrid(
                    topic=query,
                    embedding_store=embedding_store,
                    embedding_client=embedding_client,
                    reflection_type=type,
                    limit=limit,
                    min_confidence=min_confidence,
                )
            else:
                results = memory.query_reflections(
                    topic=query,
                    reflection_type=type,
                    limit=limit,
                    min_confidence=min_confidence,
                )
        except Exception:
            results = memory.query_reflections(
                topic=query,
                reflection_type=type,
                limit=limit,
                min_confidence=min_confidence,
            )
    else:
        results = memory.query_reflections(
            topic=query,
            reflection_type=type,
            limit=limit,
            min_confidence=min_confidence,
        )

    return [
        {
            "id": r.id,
            "type": r.type,
            "content": r.content,
            "confidence": r.confidence,
            "timestamp": r.timestamp,
            "epistemic_status": r.epistemic_status,
        }
        for r in results
    ]


# ---------------------------------------------------------------------------
# Tool: limen_status
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_status(ctx: Context) -> dict[str, Any]:
    """Health check and database statistics."""
    state = _get_state(ctx)
    services = state.services

    from limen_memory.store.graph_store import GraphStore
    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = services["memory"]
    graph: GraphStore = services["graph"]

    reflection_count = memory.get_reflection_count()
    fact_count = memory.get_user_fact_count()
    diagnostics = graph.get_graph_diagnostics()

    scheduler_rows = state.db.execute_read("SELECT * FROM scheduler_state")
    scheduler_state = {r["key"]: r["value"] for r in scheduler_rows}

    return {
        "reflections": reflection_count,
        "user_facts": fact_count,
        "graph_nodes": diagnostics.active_nodes,
        "graph_edges": diagnostics.active_edges,
        "orphan_nodes": diagnostics.orphan_nodes,
        "avg_edge_confidence": round(diagnostics.avg_edge_confidence, 3),
        "scheduler_state": scheduler_state,
        "db_path": str(state.config.db_path),
        "embedding_configured": services.get("embedding_client") is not None,
        "mcp_version": _MCP_VERSION,
    }


# ===========================================================================
# Phase 2 — Extended Tools
# ===========================================================================


# ---------------------------------------------------------------------------
# Tool: limen_user_profile
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_user_profile(
    ctx: Context,
    category: str = "",
) -> dict[str, Any]:
    """View stored user facts, optionally filtered by category.

    Args:
        category: Filter to specific category (e.g., preferences, work, tools).
    """
    state = _get_state(ctx)

    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = state.services["memory"]
    facts = memory.query_user_facts(category=category)

    return {
        "facts": [
            {
                "id": f.id,
                "category": f.category,
                "key": f.key,
                "value": f.value,
                "confidence": f.confidence,
                "first_observed": f.first_observed,
                "last_verified": f.last_verified,
            }
            for f in facts
        ],
        "count": len(facts),
    }


# ---------------------------------------------------------------------------
# Tool: limen_interaction_profile
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_interaction_profile(
    ctx: Context,
) -> dict[str, Any]:
    """View interaction profile dimensions (behavioral model of the user)."""
    state = _get_state(ctx)

    from limen_memory.store.profile_store import ProfileStore

    profile: ProfileStore = state.services["profile"]
    dims = profile.get_interaction_profile()

    return {
        "dimensions": [
            {
                "dimension": d.dimension,
                "score": round(d.score, 3),
                "confidence": round(d.confidence, 3),
                "evidence_count": d.evidence_count,
                "last_synthesized": d.last_synthesized,
            }
            for d in dims
        ],
        "count": len(dims),
    }


# ---------------------------------------------------------------------------
# Tool: limen_search_conversations
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_search_conversations(
    ctx: Context,
    query: str,
    limit: int = 10,
) -> dict[str, Any]:
    """Full-text search over conversation summaries.

    Args:
        query: Full-text search query.
        limit: Max results. Default 10.
    """
    state = _get_state(ctx)

    from limen_memory.store.conversation_store import ConversationStore

    conversations: ConversationStore = state.services["conversation"]

    try:
        results = conversations.search_fts(query=query, limit=limit)
    except Exception:
        # FTS match can fail on malformed queries
        return {"results": [], "count": 0}

    return {
        "results": [
            {
                "id": s.id,
                "conversation_id": s.conversation_id,
                "summary": s.summary,
                "keywords": s.keywords,
                "created_at": s.created_at,
            }
            for s in results
        ],
        "count": len(results),
    }


# ---------------------------------------------------------------------------
# Tool: limen_graph_inspect
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_graph_inspect(
    ctx: Context,
    node_id: str = "",
) -> dict[str, Any]:
    """Inspect the knowledge graph. Returns global diagnostics or edges for a specific node.

    Args:
        node_id: Specific node to inspect. If omitted, returns global diagnostics.
    """
    state = _get_state(ctx)

    from limen_memory.store.graph_store import GraphStore

    graph: GraphStore = state.services["graph"]

    if not node_id:
        diag = graph.get_graph_diagnostics()
        return {
            "type": "diagnostics",
            "total_nodes": diag.total_nodes,
            "active_nodes": diag.active_nodes,
            "total_edges": diag.total_edges,
            "active_edges": diag.active_edges,
            "orphan_nodes": diag.orphan_nodes,
            "avg_edge_confidence": round(diag.avg_edge_confidence, 3),
            "most_connected_nodes": diag.most_connected_nodes,
        }

    edges = graph.get_relationships_for_reflections([node_id])
    return {
        "type": "node_edges",
        "node_id": node_id,
        "edge_count": len(edges),
        "edges": [
            {
                "id": e.id,
                "source_id": e.source_id,
                "target_id": e.target_id,
                "relationship_type": e.relationship_type,
                "edge_category": e.edge_category,
                "confidence": round(e.confidence, 3),
                "evidence": e.evidence[:200] if e.evidence else "",
                "created_at": e.created_at,
            }
            for e in edges
        ],
    }


# ---------------------------------------------------------------------------
# Tool: limen_deprecate
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_deprecate(
    ctx: Context,
    id: str,
    reason: str = "",
) -> dict[str, Any]:
    """Soft-delete a reflection (marks as deprecated, never hard-deletes).

    Args:
        id: Reflection ID to deprecate.
        reason: Reason for deprecation.
    """
    state = _get_state(ctx)

    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = state.services["memory"]
    success = memory.deprecate_reflection(reflection_id=id, reason=reason)

    return {"success": success, "id": id}


# ---------------------------------------------------------------------------
# Tool: limen_pin
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_pin(
    ctx: Context,
    reflection_id: str,
    pinned: bool = True,
) -> dict[str, Any]:
    """Pin or unpin a reflection. Pinned reflections are immune to aging.

    Args:
        reflection_id: Reflection ID to pin or unpin.
        pinned: True to pin, False to unpin.
    """
    state = _get_state(ctx)

    from limen_memory.store.memory_store import MemoryStore

    memory: MemoryStore = state.services["memory"]
    if pinned:
        success = memory.pin_reflection(reflection_id)
    else:
        success = memory.unpin_reflection(reflection_id)

    return {"success": success, "reflection_id": reflection_id, "pinned": pinned}


# ---------------------------------------------------------------------------
# Tool: limen_consolidate
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_consolidate(
    ctx: Context,
) -> dict[str, Any]:
    """Run LLM-driven memory consolidation (dedup, merge, validate edges).

    Requires a configured embedding provider.
    """
    state = _get_state(ctx)

    from limen_memory.services.embedding.factory import create_embedding_client

    emb_client = create_embedding_client(state.config)
    if emb_client is None:
        return {"error": "Embedding provider is required for consolidation."}

    return _spawn_background(["consolidate"], log_name="limen-memory-consolidate-bg")


# ---------------------------------------------------------------------------
# Tool: limen_scheduler_tick
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_scheduler_tick(
    ctx: Context,
) -> dict[str, Any]:
    """Execute one scheduler maintenance task (consolidation, aging, pruning, backup).

    Runs the highest-priority eligible task, or returns 'none' if nothing is due.
    """
    return _spawn_background(["scheduler-tick"], log_name="limen-memory-scheduler-tick-bg")


# ---------------------------------------------------------------------------
# Tool: limen_reflect_transcript
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_reflect_transcript(
    ctx: Context,
    transcript: str,
    session_id: str = "",
) -> dict[str, Any]:
    """Reflect on a full conversation transcript (the MCP equivalent of the stop hook).

    Runs the full reflection pipeline: LLM analysis, novelty filtering,
    embedding, graph edges, fact extraction, and strategy observations.

    Requires a configured embedding provider.

    Args:
        transcript: Full conversation transcript text.
        session_id: Session ID. Auto-generated if omitted.
    """
    state = _get_state(ctx)

    if not state.config.embedding_provider:
        return {"error": "Embedding provider is required for transcript reflection."}

    args: list[str] = ["reflect-transcript", "--stdin"]
    if session_id:
        args.extend(["--session-id", session_id])

    return _spawn_background(
        args,
        stdin_text=transcript,
        log_name="limen-memory-reflect-transcript-bg",
    )


# ---------------------------------------------------------------------------
# Tool: limen_feedback
# ---------------------------------------------------------------------------


@mcp_server.tool()
def limen_feedback(
    ctx: Context,
    feedback_type: str,
    message: str,
    response: str,
) -> dict[str, Any]:
    """Record a feedback signal (positive, negative, redirect) to refine strategies.

    Call this when the user signals approval or disapproval of a response,
    or redirects the conversation to a different approach.

    Args:
        feedback_type: One of "positive", "negative", "redirect".
        message: The user message that prompted the response.
        response: The assistant response being evaluated.
    """
    state = _get_state(ctx)
    services = state.services

    from limen_memory.services.strategy_service import StrategyService

    strategy_svc: StrategyService | None = services.get("strategy_service")
    if strategy_svc is None:
        return {
            "error": "Strategy service is not available.",
        }

    if feedback_type not in ("positive", "negative", "redirect"):
        return {
            "error": f"Invalid feedback_type: {feedback_type!r}. "
            "Must be 'positive', 'negative', or 'redirect'.",
        }

    strategy_svc.process_feedback_signal(
        feedback_type=feedback_type,
        message=message,
        response=response,
    )

    return {
        "status": "recorded",
        "feedback_type": feedback_type,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run(
    transport: str = "stdio",
    host: str = "127.0.0.1",
    port: int = 8000,
    ssl_certfile: str = "",
    ssl_keyfile: str = "",
    public: bool = False,
) -> None:
    """Start the MCP server.

    Args:
        transport: Transport mode — 'stdio' or 'streamable-http'.
        host: Bind address for HTTP transport. Ignored for stdio.
        port: Port for HTTP transport. Ignored for stdio.
        ssl_certfile: Path to SSL certificate file (PEM). Enables HTTPS.
        ssl_keyfile: Path to SSL private key file (PEM). Required with ssl_certfile.
        public: Disable DNS rebinding protection for external access.
    """
    if transport == "streamable-http":
        mcp_server.settings.host = host
        mcp_server.settings.port = port

    if public and transport == "streamable-http":
        from mcp.server.transport_security import TransportSecuritySettings

        mcp_server.settings.transport_security = TransportSecuritySettings(
            enable_dns_rebinding_protection=False,
        )

    if transport == "streamable-http" and ssl_certfile and ssl_keyfile:
        import asyncio

        import uvicorn

        starlette_app = mcp_server.streamable_http_app()
        config = uvicorn.Config(
            starlette_app,
            host=host,
            port=port,
            log_level=mcp_server.settings.log_level.lower(),
            ssl_certfile=ssl_certfile,
            ssl_keyfile=ssl_keyfile,
        )
        server = uvicorn.Server(config)
        asyncio.run(server.serve())
    else:
        mcp_server.run(transport=transport)
