---
name: limen-memory
description: >
  Personal memory system with persistent reflections, user facts, strategies, and a knowledge graph.
  In Claude Code, context loads at session start and reflection runs at session end via hooks.
  In claude.ai or other MCP clients without hooks, you MUST be proactive:
  (1) Call limen_context at conversation start when past context would help.
  (2) Call limen_learn whenever the user reveals facts about themselves (preferences, work, tools, expertise).
  (3) Call limen_reflect for genuine insights, patterns, or observations worth persisting.
  (4) At the end of substantive conversations, call limen_reflect_transcript with a summary of the conversation.
  (5) Periodically call limen_scheduler_tick for maintenance.
  (6) Call limen_feedback when the user signals approval, disapproval, or redirects the approach.
  Always use limen_query to check for relevant context before answering questions where memory would help.
allowed-tools: Read, Bash, Glob, Grep, Write
---

# Limen-memory — Personal Memory System

You have access to **limen-memory**, a persistent memory system with reflections, user facts, strategies, and interaction patterns. MCP tools are the primary interface.

## Environment Detection

Limen works in two modes depending on the client:

### Claude Code (hooks available)

Context is loaded at session start and reflection runs at session end via hooks automatically. MCP tools are for on-demand queries and learning during conversation. Maintenance (consolidation, aging, pruning, backup) runs automatically via scheduler ticks at session boundaries.

### claude.ai / MCP clients (no hooks)

There are **no automatic hooks** — you must be proactive about memory operations. Follow these behavioral rules:

**At conversation start:**
- If the user's message suggests past context would help (references to previous work, "continue", "as we discussed", project names, etc.), call `limen_context` with a relevant query.
- If unsure, call `limen_context` with a general query — it's cheap and the tiered loader handles relevance.

**During conversation:**
- Call `limen_learn` whenever the user reveals a fact about themselves: preferences, tools, expertise, work context, communication style, projects, goals. Be proactive — don't wait to be asked.
- Call `limen_reflect` for genuine insights worth persisting: patterns in how the user works, effective communication approaches, domain knowledge connections, hypotheses about preferences. Use the `source` parameter to classify: `insight`, `observation`, `pattern`, `hypothesis`.
- Call `limen_query` before answering questions where accumulated memory would improve the response.

**Writing good reflections (important — affects acceptance rate):**

Reflections pass through a novelty filter that rejects content too similar to existing entries. Embeddings cluster thematically related content tightly, so two genuinely different insights about the same domain can be rejected if phrased broadly. To maximize acceptance:

1. **Pre-flight check**: Before reflecting, call `limen_query` on the topic. If the insight is already captured, skip it. If it adds a new angle, phrase the reflection to emphasize *only the delta*.
2. **Specific claims, not themes**: Write concrete, specific insights rather than broad summaries.
   - Bad: `Dennis works on local AI systems and values autonomy.`
   - Good: `Limen config bug revealed that env-var-first priority in layered config systems silently fails when a layer injects truthy garbage like literal ${VAR_NAME} strings.`
3. **One insight per reflection**: Don't combine multiple ideas. Split them into separate `limen_reflect` calls.
4. **Avoid restating context**: The reflection should stand alone without the surrounding conversation. Focus on the novel claim, not the setup.

**At conversation end (substantive conversations only):**
- If the conversation was substantive (not just a quick question), call `limen_reflect_transcript` with a summary of the key exchanges. This runs the full reflection pipeline: LLM analysis, novelty filtering, fact extraction, strategy observations, session context, and graph edges.
- Skip this for trivial interactions (simple lookups, brief Q&A).

**Maintenance:**
- Call `limen_scheduler_tick` opportunistically — once per conversation is sufficient. It runs the highest-priority maintenance task (consolidation, aging, pruning, or backup) if one is due.

## MCP Tools

### Core

| Tool | When to use |
|------|-------------|
| `limen_context` | Load topic-specific context. Params: `query`, `mode` (fresh/continuing/recall), `include_rules`. Mode is auto-detected if omitted: **fresh** = new topic, **continuing** = overlapping keywords with last session, **recall** = explicit references to past conversations. |
| `limen_learn` | Record a user fact (idempotent on category+key). Params: `category`, `key`, `value`, `confidence`. Categories: preferences, tools, expertise, work_context, communication_style, interests, personal. |
| `limen_reflect` | Store an insight with novelty gating. Params: `content`, `source` (insight/observation/pattern/hypothesis), `confidence` (low/medium/high). Rejected if too similar to existing reflections. |
| `limen_query` | Search reflections (hybrid semantic + keyword + recency + confidence + graph). Params: `query`, `limit`, `type`, `min_confidence`. |
| `limen_status` | System health check — reflection/fact counts, graph stats, scheduler state. |

### Extended

| Tool | When to use |
|------|-------------|
| `limen_user_profile` | View stored user facts. Params: `category` (optional filter). |
| `limen_interaction_profile` | View behavioral model dimensions (-1.0 to 1.0 scale). |
| `limen_search_conversations` | Full-text search over conversation summaries. Params: `query`, `limit`. |
| `limen_graph_inspect` | Inspect knowledge graph — global diagnostics or specific node edges. Params: `node_id`. |
| `limen_deprecate` | Soft-delete a reflection. Params: `id`, `reason`. Never hard-delete. |
| `limen_consolidate` | Run LLM-driven memory consolidation (dedup, merge, validate). Use sparingly — resource intensive. |
| `limen_scheduler_tick` | Execute one maintenance task. Returns what ran or 'none' if nothing due. |
| `limen_reflect_transcript` | Reflect on a full conversation transcript. Runs the complete pipeline: LLM analysis → novelty filtering → embeddings → graph edges → fact extraction → strategy observations → session context. Params: `transcript`, `session_id`. |
| `limen_feedback` | Record a feedback signal to refine strategies. Call when the user signals approval, disapproval, or redirects to a different approach. Params: `feedback_type` (positive/negative/redirect), `message`, `response`. |

### Feedback Signals

Call `limen_feedback` when you detect explicit or implicit user feedback:

- **positive** — User expresses approval: "that's exactly what I needed", "perfect", "great explanation", thumbs up, etc.
- **negative** — User expresses disapproval: "that's not what I asked", "too verbose", "wrong approach", etc.
- **redirect** — User steers toward a different approach: "actually, let's try X instead", "can you do it this way", etc.

Pass the original user `message` and your `response` so the strategy system can learn which approaches work and which don't. You don't need to capture every interaction — focus on clear signals.

## Principles

1. **Learn facts as you observe them** — call `limen_learn` during conversations, don't batch them
2. **In Claude Code, trust the hooks** — context and reflection happen automatically at session boundaries
3. **In claude.ai, be proactive** — you are responsible for all memory operations
4. **Use `limen_context` for topic-specific context** mid-conversation when needed
5. **Soft delete only** — use `limen_deprecate`, never hard delete
6. **Evidence accumulates** — confidence grows with repeated observations
7. **Novelty matters** — `limen_reflect` rejects redundant insights, so don't worry about over-calling it
8. **Quality over quantity** — a few genuine insights beat many shallow observations
