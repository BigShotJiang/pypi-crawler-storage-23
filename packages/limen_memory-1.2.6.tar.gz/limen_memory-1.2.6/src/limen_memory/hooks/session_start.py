#!/usr/bin/env python3
"""SessionStart hook for limen-memory personal memory system.

Loads limen context automatically at conversation start.
Outputs plain text to stdout which Claude Code injects as context.

Fires on source="startup" and source="resume" only.
Skips "clear" (handled by cwms) and "compact" (mid-session).
"""

from __future__ import annotations

import json
import os
import subprocess  # nosec B404
import sys
import tempfile
from datetime import datetime


def debug_log(msg: str) -> None:
    """Write debug message to log file."""
    try:
        debug_file = os.path.join(tempfile.gettempdir(), "limen-memory-hook-debug.log")
        log_size = os.path.getsize(debug_file) if os.path.exists(debug_file) else 0
        if log_size > 10_000_000:
            rotated = debug_file + ".old"
            os.replace(debug_file, rotated)
        with open(debug_file, "a") as f:
            f.write(f"[{datetime.now().isoformat()}] [session-start] {msg}\n")
    except Exception:  # nosec B110
        pass


def main() -> None:
    """Main hook entry point."""
    debug_log("=== Limen-memory SessionStart hook started ===")

    try:
        hook_data = json.load(sys.stdin)
    except Exception as e:
        debug_log(f"Failed to read stdin: {e}")
        sys.exit(0)

    session_id = hook_data.get("session_id", "")
    source = hook_data.get("source", "")
    debug_log(f"session_id={session_id}, source={source}")

    # Only inject context on fresh session starts
    # Skip "clear" (cwms handles that) and "compact" (mid-session)
    if source not in ("startup", "resume"):
        debug_log(f"Skipping: source={source}")
        sys.exit(0)

    # Load limen context via CLI
    timeout = int(os.environ.get("LIMEN_CONTEXT_TIMEOUT", "30"))
    try:
        result = subprocess.run(  # nosec B603, B607
            ["limen-memory", "context", "new conversation starting"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0 and result.stdout.strip():
            # Plain text stdout is injected as context by Claude Code
            print(result.stdout.strip())
            debug_log(f"Context injected: {len(result.stdout)} chars")
        else:
            debug_log(
                f"limen context returned rc={result.returncode}, "
                f"stderr={result.stderr[:200] if result.stderr else '(none)'}"
            )
    except FileNotFoundError:
        debug_log("limen-memory CLI not found on PATH")
    except subprocess.TimeoutExpired:
        debug_log(f"limen-memory context timed out ({timeout}s)")
    except Exception as e:
        debug_log(f"Error running limen-memory context: {type(e).__name__}: {e}")

    # Spawn scheduler-tick in background (opportunistic maintenance)
    # The CLI command itself holds an exclusive lock, so even if we spawn one
    # while another is running, the new one will exit immediately.
    try:
        subprocess.Popen(  # nosec B603, B607
            ["limen-memory", "scheduler-tick"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        debug_log("scheduler-tick spawned in background")
    except Exception as e:
        debug_log(f"scheduler-tick spawn failed: {e}")

    debug_log("=== Limen-memory SessionStart hook finished ===")
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        debug_log(f"EXCEPTION: {type(e).__name__}: {e}")
        # Fail gracefully — hooks must not crash the session
        sys.exit(0)
