# Hook scripts for Claude Code integration.
# Installed to ~/.claude/hooks/ by `limen-memory init`.
