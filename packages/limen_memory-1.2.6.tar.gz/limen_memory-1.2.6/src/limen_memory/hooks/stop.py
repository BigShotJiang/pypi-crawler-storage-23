#!/usr/bin/env python3
"""Stop hook for limen-memory personal memory system.

Runs the reflection pipeline automatically after conversations.
Spawns reflection as a background process to avoid blocking Claude Code.

Skips trivial conversations (transcript smaller than 500 bytes).
Concurrency is handled by the database advisory lock in reflect-transcript.
"""

from __future__ import annotations

import json
import os
import subprocess  # nosec B404
import sys
import tempfile
from datetime import datetime

MIN_TRANSCRIPT_BYTES = 500


def debug_log(msg: str) -> None:
    """Write debug message to log file."""
    try:
        debug_file = os.path.join(tempfile.gettempdir(), "limen-memory-hook-debug.log")
        log_size = os.path.getsize(debug_file) if os.path.exists(debug_file) else 0
        if log_size > 10_000_000:
            rotated = debug_file + ".old"
            os.replace(debug_file, rotated)
        with open(debug_file, "a") as f:
            f.write(f"[{datetime.now().isoformat()}] [stop] {msg}\n")
    except Exception:  # nosec B110
        pass


def main() -> None:
    """Main hook entry point."""
    debug_log("=== Limen-memory Stop hook started ===")

    try:
        hook_data = json.load(sys.stdin)
    except Exception as e:
        debug_log(f"Failed to read stdin: {e}")
        sys.exit(0)

    session_id = hook_data.get("session_id", "")
    transcript_path = hook_data.get("transcript_path", "")
    debug_log(f"session_id={session_id}, transcript_path={transcript_path}")

    if not transcript_path or not os.path.exists(transcript_path):
        debug_log("No transcript path or file doesn't exist")
        sys.exit(0)

    # Skip trivial conversations (byte-size check matches CLI's 100-char threshold
    # after accounting for JSONL overhead)
    try:
        file_size = os.path.getsize(transcript_path)
    except OSError:
        file_size = 0
    if file_size < MIN_TRANSCRIPT_BYTES:
        debug_log(f"Transcript too small ({file_size} bytes), skipping reflection")
        sys.exit(0)

    # Spawn background reflection process (DB advisory lock handles concurrency)
    debug_log(f"Spawning background reflection for {transcript_path}")
    try:
        bg_log_path = os.path.join(tempfile.gettempdir(), "limen-memory-reflect-bg.log")
        bg_log = open(bg_log_path, "a")  # noqa: SIM115
        cmd = ["limen-memory", "reflect-transcript", transcript_path]
        if session_id:
            cmd.extend(["--session-id", session_id])
        subprocess.Popen(  # nosec B603, B607
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=bg_log,
        )
        bg_log.close()  # Subprocess inherits the fd; parent can close its copy
        debug_log("Background reflection spawned")
    except FileNotFoundError:
        debug_log("limen-memory CLI not found on PATH")
    except Exception as e:
        debug_log(f"Failed to spawn reflection: {type(e).__name__}: {e}")

    # Spawn scheduler-tick in background (opportunistic maintenance)
    # The CLI command itself holds an exclusive lock, so even if we spawn one
    # while another is running, the new one will exit immediately.
    try:
        subprocess.Popen(  # nosec B603, B607
            ["limen-memory", "scheduler-tick"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        debug_log("scheduler-tick spawned in background")
    except Exception:  # nosec B110
        pass

    debug_log("=== Limen-memory Stop hook finished ===")
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        debug_log(f"EXCEPTION: {type(e).__name__}: {e}")
        # Fail gracefully — hooks must not crash the session
        sys.exit(0)
