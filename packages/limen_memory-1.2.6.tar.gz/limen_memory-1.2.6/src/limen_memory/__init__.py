"""Limen-memory: Personal memory system for Claude CLI."""

__version__ = "1.2.3"
