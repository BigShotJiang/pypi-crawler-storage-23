from tkinter import *
from tkinter import ttk

styles= ttk.Style()
