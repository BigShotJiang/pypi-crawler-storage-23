from tkinter import *
from tkinter import ttk
import os
import sys
from VIStk.Structures._Project import *

class MenuItem(Button):
    """Each item in the menu is created from the corresponding .json file. Each path should be given relative to xyz/WOM/
    """
    def __init__(self,parent:Frame|Toplevel|LabelFrame|Tk,path,nav,*args,**kwargs):
        """Create an item in a row on the menu
        Args:
            root (Tk): Master root for destruction on redirect
            _root (Toplevel): Toplevel object to create menu items in
            path (str): Name of .exe or absolute path to python script
            nav (str): Navigation character to click button
        """
        super().__init__(master=parent, *args, **kwargs)
        self.root = parent.winfo_toplevel()
        self.path = path
        self.nav = nav
        self.config(command = self.itemPath)
        enter = lambda event: event.widget.configure(background="dodger blue")
        leave = lambda event: event.widget.configure(background="gray94")
        self.bind("<Enter>", enter)
        self.bind("<Leave>", leave)
        #self.button.pack()

        for i in Project().screenlist:
            i:Screen
            if self.path == i.name:
                self.screen = i
                """The `Screen` to load upon clicking"""
                break
        else:
            self.screen = None
            """The `Screen` to load upon clicking"""

    def itemPath(self):
        """Opens the given path or exe for the button
        """
        #Should have a more VIStk way to switch screens
        
        if not self.screen is None:
            self.screen.load()
        if ".exe" in self.path:
            #os.execl(self.path,*(self.path))
            os.startfile(self.path)
        else:
            os.execl(sys.executable, *(sys.executable,self.path))
            #subprocess.call("pythonw.exe "+self.path)
        self.root.destroy()