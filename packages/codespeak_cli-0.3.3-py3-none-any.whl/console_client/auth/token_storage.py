"""Token storage module for managing user authentication tokens."""

import json
import os
import time
from pathlib import Path

from pydantic import BaseModel

# Buffer time in seconds before actual expiry to trigger re-login
_TOKEN_EXPIRY_BUFFER_SECONDS = 30

_MIGRATION_DEFAULT_DOMAIN = "auth.codespeak.dev"


class StoredToken(BaseModel):
    """Token data stored in the token file."""

    domain: str
    access_token: str
    expires_at: int | None = None


class TokenFile(BaseModel):
    """Versioned token file containing per-domain tokens."""

    version: int = 1
    tokens: list[StoredToken] = []


def get_codespeak_home() -> Path:
    """Get the CodeSpeak home directory path (~/.codespeak)."""
    return Path.home() / ".codespeak"


def ensure_codespeak_home() -> Path:
    """
    Ensure the CodeSpeak home directory exists.

    Creates the directory with secure permissions (0700) if it doesn't exist.

    Returns:
        Path to the CodeSpeak home directory.
    """
    codespeak_home = get_codespeak_home()
    if not codespeak_home.exists():
        codespeak_home.mkdir(parents=True, mode=0o700, exist_ok=True)
    return codespeak_home


def get_token_path() -> Path:
    """Get the path to the token file (~/.codespeak/token.json)."""
    return get_codespeak_home() / "token.json"


def _load_token_file() -> TokenFile:
    """Load and parse the token file, migrating from old format if needed."""
    token_path = get_token_path()
    if not token_path.exists():
        return TokenFile()

    try:
        data = json.loads(token_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, ValueError):
        return TokenFile()

    if "version" in data:
        return TokenFile.model_validate(data)

    # Migrate old format: {access_token, expires_at} -> versioned per-domain format
    access_token = data.get("access_token")
    if not access_token:
        return TokenFile()

    migrated_token = StoredToken(
        domain=_MIGRATION_DEFAULT_DOMAIN,
        access_token=access_token,
        expires_at=data.get("expires_at"),
    )
    token_file = TokenFile(tokens=[migrated_token])

    # Write back the migrated format
    _save_token_file(token_file)
    return token_file


def _save_token_file(token_file: TokenFile) -> None:
    """Write the token file to disk with secure permissions."""
    ensure_codespeak_home()
    token_path = get_token_path()
    token_path.write_text(token_file.model_dump_json(indent=2), encoding="utf-8")
    os.chmod(token_path, 0o600)


def save_token(token: str, expires_in: int = 0, *, domain: str) -> None:
    """
    Save the authentication token and its expiration time for a given domain.

    Creates the CodeSpeak home directory if it doesn't exist.
    Sets file permissions to 0600 (owner read/write only) for security.

    Args:
        token: The authentication token to save.
        expires_in: Token lifetime in seconds from now. If 0, no expiry is saved.
        domain: The auth domain this token belongs to.

    Raises:
        OSError: If the token cannot be saved due to filesystem errors.
    """
    expires_at = int(time.time()) + expires_in if expires_in > 0 else None
    new_token = StoredToken(domain=domain, access_token=token, expires_at=expires_at)

    token_file = _load_token_file()
    token_file.tokens = [t for t in token_file.tokens if t.domain != domain]
    token_file.tokens.append(new_token)

    _save_token_file(token_file)


def _find_token_for_domain(domain: str) -> StoredToken | None:
    """Find the stored token for a specific domain."""
    token_file = _load_token_file()
    for t in token_file.tokens:
        if t.domain == domain:
            return t
    return None


def load_user_token(*, domain: str) -> StoredToken | None:
    """
    Load the stored token for a given domain from the token file.

    Returns:
        The stored token if it exists, None otherwise.
    """
    return _find_token_for_domain(domain)


def delete_token(*, domain: str) -> None:
    """
    Delete the authentication token for a given domain.

    Removes only the token for the specified domain. If no tokens remain,
    the file is deleted.

    Raises:
        OSError: If the file exists but cannot be deleted.
    """
    token_path = get_token_path()
    if not token_path.exists():
        return

    token_file = _load_token_file()
    token_file.tokens = [t for t in token_file.tokens if t.domain != domain]

    if not token_file.tokens:
        token_path.unlink()
    else:
        _save_token_file(token_file)


def is_token_expired(token: StoredToken) -> bool:
    """
    Check if a token is expired or about to expire.

    Returns True if the token is expired or will expire within the buffer period,
    giving time for re-login before actual expiry.
    """
    if token.expires_at is None:
        return False

    return time.time() >= token.expires_at - _TOKEN_EXPIRY_BUFFER_SECONDS
