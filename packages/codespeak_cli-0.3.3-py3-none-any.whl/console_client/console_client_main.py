"""Console client CLI for CodeSpeak - remote builds and authentication."""

import logging
import os
import sys
from importlib.metadata import version
from pathlib import Path

import dotenv
from api_stubs.setup_grpc import setup_grpc
from codespeak_shared import BuildResult, LoggingUtil
from codespeak_shared.change_request_utils import implement_code_change_request
from codespeak_shared.client_constants import ClientConstants
from codespeak_shared.cmdline_parsing import (
    add_common_params,
    create_codespeak_parser,
    parse_codespeak_args,
    validate_coverage_args,
)
from codespeak_shared.codespeak_project import FileBasedCodeSpeakProject
from codespeak_shared.environment_enhancer import enhance_environment_with_api_key
from codespeak_shared.exceptions import (
    BuildWithExistingChangeRequest,
    CodespeakInternalError,
    CodespeakUserError,
    ProjectNotFoundUserError,
)
from codespeak_shared.project_initializer import initialize_project
from codespeak_shared.shared_feature_flags import SharedFeatureFlags
from codespeak_shared.utils.colors import Colors, ThemeType
from codespeak_shared.utils.error_reporting import print_stack_trace_if_enabled
from codespeak_shared.utils.process_util import register_signal_handlers
from rich.console import Console

from console_client.auth.auth_manager import login
from console_client.auth.token_storage import is_token_expired, load_user_token
from console_client.client_feature_flags import ConsoleClientFeatureFlags
from console_client.console_client_logging import ConsoleClientLoggingUtil
from console_client.version_check import check_for_updates


def _ensure_authenticated(console: Console, client_feature_flags: ConsoleClientFeatureFlags) -> BuildResult:
    """
    Ensure user is authenticated. If no token is found, trigger login flow.

    Args:
        console: Rich console for user output.
        client_feature_flags: Feature flags instance to check if authentication is enabled.

    Returns:
        Result indicating authentication success or failure.
    """
    # Skip authentication check if feature flag is disabled
    if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_SEND_USER_TOKEN):
        return BuildResult.succeeded("authentication-check")

    auth0_domain = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_AUTH0_DOMAIN)

    try:
        stored = load_user_token(domain=auth0_domain)
        if stored:
            if not is_token_expired(stored):
                # Token exists and is valid
                return BuildResult.succeeded("authentication-check")

            # Token is expired - trigger login
            console.print("[yellow]Your authentication token has expired.[/yellow]")
            console.print("[yellow]Please log in again to continue...[/yellow]\n")
            return _login_user(console, client_feature_flags)

        # Token is missing or empty - trigger login
        console.print("[yellow]Authentication required.[/yellow]")
        console.print("[yellow]Please log in to continue...[/yellow]\n")
        return _login_user(console, client_feature_flags)

    except BaseException as e:  # noqa: BLE001
        return BuildResult.failed("authentication-check", e)


def _login_user(console: Console, client_feature_flags: ConsoleClientFeatureFlags) -> BuildResult:
    """Execute login flow."""
    if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_SEND_USER_TOKEN):
        console.print("Login disabled")
        return BuildResult.succeeded("login")

    try:
        login(console, client_feature_flags)
        return BuildResult.succeeded("login")

    except KeyboardInterrupt as e:
        console.print("\n[yellow]Login cancelled by user.[/yellow]")
        return BuildResult.failed("login", e)

    except CodespeakUserError as e:
        return BuildResult.failed("login", e)

    except BaseException as e:  # noqa: BLE001 (login catch-all block)
        return BuildResult.failed("login", e)


def main() -> None:
    register_signal_handlers()

    dotenv.load_dotenv(dotenv.find_dotenv(usecwd=True))
    dotenv.load_dotenv(".env.local", override=True)

    logger = logging.getLogger("console-client")
    logger.info(f"Invocation: {' '.join([os.path.basename(sys.argv[0])] + sys.argv[1:])}")

    parser, subparsers = create_codespeak_parser(
        version=f"CodeSpeak CLI {version(ClientConstants.CONSOLE_CLIENT_PACKAGE_NAME)}"
    )

    login_parser = subparsers.add_parser(
        "login",
        help="authenticate with CodeSpeak",
        description="Authenticate with CodeSpeak to enable builds. Opens a browser for authentication.",
    )
    add_common_params(login_parser)

    args = parse_codespeak_args(parser)
    env_vars = dict(os.environ)
    client_feature_flags = ConsoleClientFeatureFlags(env_vars, args.enable_flag, args.disable_flag)

    # Setup console with theme
    theme = Colors.get_theme(
        ThemeType.DARK
        if client_feature_flags.get_flag_value(SharedFeatureFlags.CONSOLE_USES_DARK_THEME)
        else ThemeType.LIGHT
    )
    console = Console(theme=theme)
    stderr_console = Console(stderr=True, theme=theme)

    # Print any feature flag warnings
    for warning in client_feature_flags.warnings:
        stderr_console.print(warning)

    if client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_VERSION_CHECK_ENABLED):
        check_for_updates(
            stderr_console,
            client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_VERSION_CHECK_INTERVAL_HOURS),
        )

    # Handle commands
    try:
        # Validate command-specific args early (before sending to server)
        if args.command == "coverage":
            validate_coverage_args(args)

        if args.command == "init":

            def init_logging(local_project: FileBasedCodeSpeakProject, feature_flags: SharedFeatureFlags) -> None:
                ConsoleClientLoggingUtil.initialize_logger(
                    local_project.ignored_data_path("codespeak.log").get_underlying_path(), enable_console_logging=False
                )

            result = initialize_project(
                current_path=Path(os.curdir),
                console=console,
                feature_flags=client_feature_flags,
                args=args,
                initialize_logging=init_logging,
            )

        elif args.command == "login":
            result = _login_user(console, client_feature_flags)

        else:
            # All non-local commands are forwarded to the server
            local_project = FileBasedCodeSpeakProject.find_upwards(Path(os.curdir))
            if not local_project:
                result = BuildResult.failed(args.command, ProjectNotFoundUserError(Path(os.curdir).resolve()))
            else:
                ConsoleClientLoggingUtil.initialize_logger(
                    local_project.ignored_data_path("codespeak.log").get_underlying_path(), enable_console_logging=False
                )

                # Enhance environment with API key on client side (before sending to server)
                env_vars = enhance_environment_with_api_key(
                    console=console,
                    env_vars=env_vars,
                    project_root=local_project.project_root.get_underlying_path(),
                    no_interactive=args.no_interactive,
                )

                def call_server() -> BuildResult:
                    # Ensure user is authenticated before running build
                    auth_result = _ensure_authenticated(console, client_feature_flags)
                    if auth_result.enum_type != BuildResult.SUCCEEDED:
                        return auth_result
                    else:
                        with LoggingUtil.Span(f"Running command: {args.command}"):
                            # setup GRPC logging before importing build_client (which imports grpc)
                            setup_grpc(client_feature_flags.get_flag_value(SharedFeatureFlags.DEBUG_GRPC))

                            from console_client.build_client import run_build_client  # noqa: PLC0415

                            return run_build_client(args, local_project, client_feature_flags, console, env_vars)

                if args.command in ("build", "run"):
                    ccr_path = local_project.code_change_request_path()
                    if local_project.os_env().exists(ccr_path):
                        result = BuildResult.failed(
                            "build", BuildWithExistingChangeRequest(ccr_path.get_underlying_path())
                        )
                    else:
                        result = call_server()
                elif args.command == "change":
                    result = implement_code_change_request(local_project, args, console, call_server)
                else:
                    result = call_server()

    except BaseException as e:  # noqa: BLE001 (global catch-all block)
        result = BuildResult.failed(args.command, e)

    # Handle result and exit
    if client_feature_flags.get_flag_value(SharedFeatureFlags.SHOW_BUILD_COST):
        console.print(f"[dim]Build cost: ${result.build_stats.cost_usd:.1f}[/dim]")

    if result.enum_type == BuildResult.SUCCEEDED:
        sys.exit(0)
    elif result.enum_type == BuildResult.SKIPPED:
        sys.exit(0)
    elif result.enum_type == BuildResult.FAILED:
        assert result.exception
        if isinstance(result.exception, KeyboardInterrupt):
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} interrupted by user.[/error.emphasized]"
            )
            sys.exit(130)
        elif isinstance(result.exception, (CodespeakUserError, CodespeakUserError)):
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} failed:[/error.emphasized]\n{result.exception}"
            )
            sys.exit(CodespeakUserError.EXIT_CODE)
        else:
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} failed: [/error.emphasized]{result.exception}"
            )
            server_trace = getattr(result.exception, "server_stack_trace", None)
            if server_trace or result.exception.__traceback__:
                if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.PRINT_STACKTRACE_ON_FAILURE):
                    stderr_console.print(
                        "[dim]To see full error details, run with --enable-flag PRINT_STACKTRACE_ON_FAILURE[/dim]"
                    )
                print_stack_trace_if_enabled(result.exception, stderr_console, client_feature_flags)
            sys.exit(CodespeakInternalError.EXIT_CODE)


if __name__ == "__main__":
    main()
