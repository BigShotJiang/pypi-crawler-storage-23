from .octorules_wirefilter import *

__doc__ = octorules_wirefilter.__doc__
if hasattr(octorules_wirefilter, "__all__"):
    __all__ = octorules_wirefilter.__all__