"""Allow running with `python -m uploadwhen`."""

from uploadwhen.cli import main

if __name__ == "__main__":
    main()
