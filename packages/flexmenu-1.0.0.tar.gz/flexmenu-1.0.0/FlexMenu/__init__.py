import platform
import sys

__version__ = "1.0.0"


class FlexMenu:
    def __init__(self, title, options):
        self.title = title
        self.options = options
        self.selected = 0

    @property
    def get_choice(self):
        return self.options[self.selected]

    def run(self):
        self.selected = 0
        while True:
            self._display()
            key = self._get_key()

            if key == "up" and self.selected > 0:
                self.selected -= 1
            elif key == "down" and self.selected < len(self.options) - 1:
                self.selected += 1
            elif key == "enter" or key == "space":
                self._clear_screen()
                return self.selected
            elif key == "esc":
                self.selected = -1
                self._clear_screen()
                return self.selected

            self._clear_screen()  # 清屏

    def _clear_screen(self):
        menu_height = len(self.options) + 3  # 动态计算菜单高度
        # 光标上移菜单高度行
        print(f"\033[{menu_height}A", end="")
        # 清除从光标到屏幕末尾
        print("\033[0J", end="")
        sys.stdout.flush()

    def _display(self):
        print(f"\033[1;34m=== {self.title} ===\033[0m")
        for i, option in enumerate(self.options):
            if i == self.selected:
                print(f"\033[1;34m > {i+1}. {option}\033[0m")
            else:
                print(f"\033[90m  {i+1}. {option}\033[0m")
        print(
            "\033[90mUse ↑ and ↓ to choose. Enter/Space to select, ESC to cancel.\033[0m"
        )
        print("=" * (len(self.title) + 8))

    def _get_key(self):
        # 根据操作系统选择不同的输入方法
        if platform.system() == "Windows":
            return self._get_key_windows()
        else:
            return self._get_key_unix()

    def _get_key_windows(self):
        """Windows 版本的键盘输入"""
        try:
            import msvcrt

            key = msvcrt.getch()

            # 处理方向键和功能键（以 \xe0 开头）
            if key == b"\xe0":
                key = msvcrt.getch()
                if key == b"H":  # 上箭头
                    return "up"
                elif key == b"P":  # 下箭头
                    return "down"
            elif key == b"\r":  # 回车键
                return "enter"
            elif key == b" ":  # 空格键
                return "space"
            elif key == b"\x1b":  # ESC 键
                return "esc"

        except ImportError:
            # 如果 msvcrt 不可用，回退到简单的 input
            return input("Press Enter to select: ") or "enter"

        return ""

    def _get_key_unix(self):
        """Unix/Linux/macOS 版本的键盘输入"""
        try:
            import termios
            import tty

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                ch = sys.stdin.read(1)
                if ch == "\x1b":
                    ch = sys.stdin.read(2)
                    if ch == "[A":
                        return "up"
                    elif ch == "[B":
                        return "down"
                elif ch == "\r":
                    return "enter"
                elif ch == " ":
                    return "space"
                elif ch == "\x1b":
                    return "esc"
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        except ImportError:
            # 如果 termios 不可用，回退到简单的 input
            return input("Press Enter to select: ") or "enter"

        return ""
