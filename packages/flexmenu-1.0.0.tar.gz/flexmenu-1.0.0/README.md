# FlexMenu

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/pypi/v/FlexMenu.svg)]()
[![Download](https://img.shields.io/pypi/dm/FlexMenu.svg)]()

A lightweight, cross-platform terminal menu library for Python that enables keyboard-controlled menu selection with a clean visual interface.

## Features

- **Keyboard Navigation**: Use ↑/↓ arrows to navigate, Enter/Space to select, ESC to cancel
- **Cross-Platform**: Works on Windows (msvcrt) and Unix/Linux/macOS (termios)
- **Visual Feedback**: Color-coded selection highlighting and clear operation prompts
- **No Dependencies**: Pure Python implementation using ANSI escape codes
- **Lightweight**: Simple and easy to integrate into any CLI application

## Installation

Simply copy the `FlexMenu` class into your project. No additional dependencies required.

## Quick Start

```python
from FlexMenu import FlexMenu

# Create a menu
menu = FlexMenu("Main Menu", ["Start Game", "Settings", "Exit"])

# Run the menu
choice_index = menu.run()

# Get the selected option
if choice_index != -1:  # -1 means user pressed ESC
    print(f"You selected: {menu.get_choice}")
else:
    print("Menu cancelled")
```

## API Reference

### `FlexMenu(title, options)`

Create a new menu instance.

- `title` (str): The menu title displayed at the top
- `options` (list): List of option strings to display

### Methods

- `run()`: Display the menu and handle user input. Returns the index of selected option (0-based) or -1 if cancelled.
- `get_choice` (property): Returns the text of the currently selected option

## Keyboard Controls

- **↑ / ↓**: Navigate through options
- **Enter / Space**: Confirm selection
- **ESC**: Cancel and exit menu

## Platform Support

- **Windows**: Uses `msvcrt` for keyboard input
- **Linux/macOS**: Uses `termios` and `tty` for keyboard input
- Falls back to simple input mode if terminal control libraries are unavailable

## Example

```python
menu = FlexMenu(
    "Configuration", 
    ["Network Settings", "Display Options", "Audio", "Save & Exit"]
)

choice = menu.run()

if choice == 0:
    configure_network()
elif choice == 1:
    configure_display()
# ... etc
```
