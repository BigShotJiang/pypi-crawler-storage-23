__version__ = "1.0.0"

# Core auth & init
from sodas_sdk.core.auth import Config
from sodas_sdk.core.init import (
    configure_api_url,
    configure_datahub_api_url,
    configure_governance_api_url,
    set_bearer_token,
    set_governance_bearer_token,
    set_legacy_datahub_bearer_token,
)
from sodas_sdk.core.type import (
    ArtifactType,
    IRIType,
    IDType,
    SortOrder,
    as_id,
    as_iri,
)
from sodas_sdk.core.values import (
    BASIC_TYPE_VALUES,
    CONVERSION_VALUES,
    MEASURE_VALUES,
    ORIGIN_VALUES,
)

# DCAT
from sodas_sdk.sodas_sdk_class.DCAT.data_service import DataService
from sodas_sdk.sodas_sdk_class.DCAT.dataset import Dataset
from sodas_sdk.sodas_sdk_class.DCAT.dataset_series import DatasetSeries
from sodas_sdk.sodas_sdk_class.DCAT.distribution import Distribution
from sodas_sdk.sodas_sdk_class.DCAT.version_info import VersionInfo

# Dictionary
from sodas_sdk.sodas_sdk_class.dictionary.term import Term
from sodas_sdk.sodas_sdk_class.dictionary.vocabulary import Vocabulary

# Validation – types and rule classes
from sodas_sdk.sodas_sdk_class.validation.type import (
    COMPARISION_OPERATOR,
    CUSTOM_CONDITION,
    CUSTOM_CONDITION_TYPE,
    DATETIME_FORMAT_TYPE,
    EXPECTED_TYPE,
    OUTLIER_METHOD,
    VALIDATION_TYPE,
    ValidationRuleDTO,
    AllowedValuesValidationRule,
    CompletenessValidationRule,
    create_rule,
    CustomValidationRule,
    DataTypeValidationRule,
    LengthValidationRule,
    OutlierValidationRule,
    PatternValidationRule,
    RangeValidationRule,
    StatisticalValidationRule,
    UniquenessValidationRule,
    ValidationRule,
)
from sodas_sdk.sodas_sdk_class.validation.template import ValidationTemplate
from sodas_sdk.sodas_sdk_class.validation.quality import (
    QualityMetadataByDistributionIRI,
    QualityMetadataClient,
)

# Named exports (align with TS SDK)
__all__ = [
    "__version__",
    "AllowedValuesValidationRule",
    "ArtifactType",
    "BASIC_TYPE_VALUES",
    "COMPARISION_OPERATOR",
    "CONVERSION_VALUES",
    "CompletenessValidationRule",
    "Config",
    "CUSTOM_CONDITION",
    "CUSTOM_CONDITION_TYPE",
    "create_rule",
    "CustomValidationRule",
    "DATETIME_FORMAT_TYPE",
    "DataService",
    "DataTypeValidationRule",
    "Dataset",
    "DatasetSeries",
    "Distribution",
    "EXPECTED_TYPE",
    "IDType",
    "IRIType",
    "LengthValidationRule",
    "MEASURE_VALUES",
    "ORIGIN_VALUES",
    "OutlierValidationRule",
    "OUTLIER_METHOD",
    "PatternValidationRule",
    "QualityMetadataByDistributionIRI",
    "QualityMetadataClient",
    "RangeValidationRule",
    "SortOrder",
    "StatisticalValidationRule",
    "Term",
    "UniquenessValidationRule",
    "VALIDATION_TYPE",
    "ValidationRule",
    "ValidationRuleDTO",
    "ValidationTemplate",
    "VersionInfo",
    "Vocabulary",
    "as_id",
    "as_iri",
    "configure_api_url",
    "configure_datahub_api_url",
    "configure_governance_api_url",
    "set_bearer_token",
    "set_governance_bearer_token",
    "set_legacy_datahub_bearer_token",
]
