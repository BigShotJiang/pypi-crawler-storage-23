from __future__ import annotations

import os
from typing import Optional

import requests

from sodas_sdk.core.error import NoAccessTokenFoundError, UnexpectedResponseFormatError
from sodas_sdk.core.init import (
    configure_datahub_api_url,
    configure_governance_api_url,
    set_governance_bearer_token,
    set_legacy_datahub_bearer_token,
)


class Config:
    """
    SDK runtime configuration singleton.

    Mirrors `sodas_sdk/lib/core/auth.ts`'s Config:
    - stores base URLs
    - initializes class API URLs
    - performs login/logout and stores tokens (governance / legacy-datahub)
    """

    _instance: Optional["Config"] = None

    def __init__(
        self,
        sodas_profile_base_url: str,
        legacy_datahub_base_url: str,
        governance_base_url: str,
    ) -> None:
        self._governance_token: Optional[str] = None
        self._legacy_datahub_token: Optional[str] = None

        self._governance_base_url = governance_base_url.rstrip("/")
        self._sodas_profile_base_url = sodas_profile_base_url.rstrip("/")
        self._legacy_datahub_base_url = legacy_datahub_base_url.rstrip("/")

        self._initialize_api_urls()

    @classmethod
    def configure(
        cls,
        datahub_api_url: str,
        legacy_datahub_api_url: str,
        governance_api_url: str,
    ) -> "Config":
        """
        Explicitly configure the SDK with the given API URLs.
        Preferred over relying on environment variables.
        """
        if cls._instance is None:
            cls._instance = Config(
                sodas_profile_base_url=datahub_api_url,
                legacy_datahub_base_url=legacy_datahub_api_url,
                governance_base_url=governance_api_url,
            )
        else:
            cls._instance._governance_base_url = governance_api_url.rstrip("/")
            cls._instance._sodas_profile_base_url = datahub_api_url.rstrip("/")
            cls._instance._legacy_datahub_base_url = legacy_datahub_api_url.rstrip("/")
            cls._instance._initialize_api_urls()

        return cls._instance

    @classmethod
    def get_instance(cls) -> "Config":
        """
        Get singleton instance, using environment variables (production/test).
        """
        if cls._instance is None:
            governance_base_url = (
                os.getenv("PRODUCTION_GOVERNANCE_API_URL")
                or os.getenv("PRODUCTION_GOVERNANCE_PORTAL_API_URL")
                or os.getenv("TEST_GOVERNANCE_API_URL")
                or os.getenv("TEST_GOVERNANCE_PORTAL_API_URL")
                or ""
            )
            sodas_profile_base_url = (
                os.getenv("PRODUCTION_SODAS_PROFILE_API_URL")
                or os.getenv("PRODUCTION_DATAHUB_API_URL")
                or os.getenv("TEST_SODAS_PROFILE_API_URL")
                or os.getenv("TEST_DATAHUB_API_URL")
                or ""
            )
            legacy_datahub_base_url = (
                os.getenv("PRODUCTION_LEGACY_DATAHUB_API_URL")
                or os.getenv("TEST_LEGACY_DATAHUB_API_URL")
                or ""
            )
            if not legacy_datahub_base_url:
                # Backward-compatible fallback for environments that only had one URL.
                legacy_datahub_base_url = sodas_profile_base_url

            if not governance_base_url or not sodas_profile_base_url:
                raise ValueError(
                    "Governance or Datahub base URL is not configured in environment variables."
                )

            cls._instance = Config(
                sodas_profile_base_url=sodas_profile_base_url,
                legacy_datahub_base_url=legacy_datahub_base_url,
                governance_base_url=governance_base_url,
            )

        return cls._instance

    def _initialize_api_urls(self) -> None:
        # NOTE: In TS, "sodasProfileBaseUrl" is used to configure Dataset/Distribution/etc.
        # The python SDK historically calls it "datahub_api_url", so we keep using
        # configure_datahub_api_url() for now.
        if self._sodas_profile_base_url:
            configure_datahub_api_url(self._sodas_profile_base_url)
        else:
            print("DATAHUB_API_URL not found in config")

        if self._governance_base_url:
            configure_governance_api_url(self._governance_base_url)
        else:
            print("GOVERNANCE_API_URL not found in config")

    async def login_governance(self, id: str, password: str) -> None:
        url = f"{self._governance_base_url}/api/v1/authnz/authentication/user/login"
        parameters = {"id": id, "password": password, "offline": False}

        response = requests.post(url, json=parameters)
        response_data = response.json()

        access_token = (
            response_data.get("accessToken")
            if isinstance(response_data, dict)
            else None
        )
        if access_token:
            self._governance_token = access_token
            set_governance_bearer_token(access_token)
            return

        raise NoAccessTokenFoundError()

    async def login_legacy_datahub(self, id: str, password: str) -> None:
        url = f"{self._legacy_datahub_base_url}/api/v1/authnz/authentication/user/login"
        parameters = {"id": id, "password": password, "offline": False}

        response = requests.post(url, json=parameters)
        response_data = response.json()

        access_token = (
            response_data.get("accessToken")
            if isinstance(response_data, dict)
            else None
        )
        if access_token:
            self._legacy_datahub_token = access_token
            set_legacy_datahub_bearer_token(access_token)
            return

        raise NoAccessTokenFoundError()

    async def logout_governance(self) -> None:
        url = f"{self._governance_base_url}/api/v1/authnz/authentication/user/logout"
        headers = (
            {"Authorization": f"Bearer {self._governance_token}"}
            if self._governance_token
            else None
        )

        response = requests.post(url, json={}, headers=headers)
        response_data = response.json()

        if isinstance(response_data, dict) and response_data.get("result") == "success":
            self._governance_token = None
            return

        raise UnexpectedResponseFormatError(response_data)

    async def logout_legacy_datahub(self) -> None:
        url = (
            f"{self._legacy_datahub_base_url}/api/v1/authnz/authentication/user/logout"
        )
        headers = (
            {"Authorization": f"Bearer {self._legacy_datahub_token}"}
            if self._legacy_datahub_token
            else None
        )

        response = requests.post(url, json={}, headers=headers)
        response_data = response.json()

        if isinstance(response_data, dict) and response_data.get("result") == "success":
            self._legacy_datahub_token = None
            return

        raise UnexpectedResponseFormatError(response_data)

    def get_governance_token(self) -> Optional[str]:
        return self._governance_token

    def get_legacy_datahub_token(self) -> Optional[str]:
        return self._legacy_datahub_token
