import re
from datetime import datetime
from enum import Enum
from typing import Dict, Generic, List, Optional, TypeVar, cast

from dateutil.parser import parse
from pydantic import BaseModel

from sodas_sdk.core.error import InvalidDateObjectError, InvalidDateStringError

# === ID and IRI ===

IDType = str
IRIType = str

uuid_regex = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", re.I
)


def as_id(value: str) -> IDType:
    if not uuid_regex.match(value):
        raise ValueError(f"Invalid UUID format: '{value}'")
    return value


def as_ids(values: List[str]) -> List[IDType]:
    return [as_id(v) for v in values]


def as_iri(value: str) -> IRIType:
    return value


# === Date Handling ===

DateString = str  # alias for clarity

iso_8601_pattern = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)


def to_date_string(date: Optional[datetime]) -> DateString:
    if not isinstance(date, datetime):
        raise InvalidDateObjectError(date)
    value = date.isoformat().replace("+00:00", "Z")
    if not iso_8601_pattern.match(value):
        raise InvalidDateStringError(value)
    return value


def to_date(date_string: DateString) -> datetime:
    try:
        return cast(datetime, parse(date_string))
    except Exception:
        raise InvalidDateStringError(date_string)


# === Multilingual fields ===

MultiLanguageField = Dict[str, str]
MultiLanguageKeywords = Dict[str, List[str]]
ExtraMetadataType = Dict[str, str]
# QualityMetadataType removed: use sodas_sdk_class.validation.quality.QualityMetadataByDistributionIRI


# === Enums ===


class SortOrder(str, Enum):
    ASC = "ASC"
    DESC = "DESC"


class ArtifactType(str, Enum):
    TEMPLATE = "template"
    FILE = "file"


# === Paginated Response ===

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    total: int
    list: List[T]
