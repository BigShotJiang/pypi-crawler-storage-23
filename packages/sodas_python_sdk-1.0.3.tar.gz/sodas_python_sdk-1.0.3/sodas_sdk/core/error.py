from typing import Any


class AlreadyRecordedError(Exception):
    def __init__(self, instance: Any):
        super().__init__(f"This instance is already recorded in Database: {instance}")


class APIURLNotSetError(Exception):
    def __init__(self, cls: type):
        super().__init__(f"API_URL is not set in class: {cls.__name__}")


class DeleteRecordFailError(Exception):
    def __init__(self):
        super().__init__("Delete DBRecord Failed")


class IndexOutOfBoundsError(Exception):
    def __init__(self, index: int):
        super().__init__(f"Index : {index} out of bounds")


class InvalidDateObjectError(Exception):
    def __init__(self, value: Any):
        super().__init__(f"Invalid Date object : {value}")


class InvalidDateStringError(Exception):
    def __init__(self, s: str):
        super().__init__(f"Invalid Date string : {s}")


class InvalidTypeError(Exception):
    def __init__(self, value: Any, expected_type: str):
        super().__init__(
            f"Invalid type '{type(value).__name__}' instead of '{expected_type}'"
        )


class InvalidValueError(Exception):
    def __init__(self, value: Any):
        super().__init__(f"Invalid value : {value} is put")


class NamedTermNotExistError(Exception):
    def __init__(self, name: str):
        super().__init__(f"Named term {name} not exist.")


class NeedToImplementError(NotImplementedError):
    def __init__(self):
        super().__init__("It needs to be implemented.")


class NeedToSetFieldError(Exception):
    def __init__(self, value: Any, field: str):
        super().__init__(f"This instance : {value} needs to set field : {field}")


class NoAccessTokenFoundError(Exception):
    def __init__(self):
        super().__init__("No accessToken found in the response")


class NotInitializedError(Exception):
    def __init__(self, field: str):
        super().__init__(f"Field : {field} is not initialized yet")


class NotRecordedArgumentError(Exception):
    def __init__(self, instance: Any):
        super().__init__(f"Not recorded argument is put : {instance}")


class NotRecordedYetError(Exception):
    def __init__(self, instance: Any):
        super().__init__(f"This instance is not recorded in Database yet : {instance}")


class RecordNotFoundError(Exception):
    def __init__(self):
        super().__init__("Record is not found")


class RequirementsNotSetError(Exception):
    def __init__(self):
        super().__init__("Requirements are not set")


class RetryLimitReachedError(Exception):
    def __init__(self, max_attempts: int):
        super().__init__(f"Max retries[{max_attempts}] reached")


class SwitchSameIndexError(Exception):
    def __init__(self, index: int):
        super().__init__(f"Switch same index : {index}")


class UnexpectedResponseFormatError(Exception):
    def __init__(self, response: Any):
        super().__init__(f"Unexpected response format: {response}")
        super().__init__(f"Unexpected response format: {response}")
