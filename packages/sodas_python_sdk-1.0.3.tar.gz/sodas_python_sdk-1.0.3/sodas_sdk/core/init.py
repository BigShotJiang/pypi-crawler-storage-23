from sodas_sdk.sodas_sdk_class.DCAT.data_service import DataService
from sodas_sdk.sodas_sdk_class.DCAT.dataset import Dataset
from sodas_sdk.sodas_sdk_class.DCAT.dataset_series import DatasetSeries
from sodas_sdk.sodas_sdk_class.DCAT.distribution import Distribution
from sodas_sdk.sodas_sdk_class.dictionary.term import Term
from sodas_sdk.sodas_sdk_class.dictionary.vocabulary import Vocabulary
from sodas_sdk.sodas_sdk_class.validation.quality import QualityMetadataClient
from sodas_sdk.sodas_sdk_class.validation.template import ValidationTemplate
from sodas_sdk.sodas_sdk_file.data_file import DataFile
from sodas_sdk.sodas_sdk_file.thumbnail_file import ThumbnailFile


def configure_governance_api_url(governance_portal_api_url: str) -> None:
    governance_portal_api_url = governance_portal_api_url.rstrip("/")

    if governance_portal_api_url:
        Vocabulary.configure_api_url(governance_portal_api_url)
        Term.configure_api_url(governance_portal_api_url)
        ValidationTemplate.configure_api_url(governance_portal_api_url)
    else:
        print("GOVERNANCE_API_URL not found in .env")


def configure_datahub_api_url(datahub_api_url: str) -> None:
    datahub_api_url = datahub_api_url.rstrip("/")

    if datahub_api_url:
        Distribution.configure_api_url(datahub_api_url)
        Dataset.configure_api_url(datahub_api_url)
        DatasetSeries.configure_api_url(datahub_api_url)
        DataService.configure_api_url(datahub_api_url)
        ThumbnailFile.configure_api_url(datahub_api_url)
        DataFile.configure_api_url(datahub_api_url)
        QualityMetadataClient.configure_api_url(datahub_api_url)
    else:
        print("DATAHUB_API_URL not found in .env")


def configure_api_url(datahub_api_url: str, governance_portal_api_url: str) -> None:
    configure_datahub_api_url(datahub_api_url)
    configure_governance_api_url(governance_portal_api_url)


def set_governance_bearer_token(token: str) -> None:
    """
    Governance portal token (dictionary, ValidationTemplate APIs).
    Mirrors `setGovernanceBearerToken` in TS SDK.
    """
    Vocabulary.BEARER_TOKEN = token
    Term.BEARER_TOKEN = token
    ValidationTemplate.BEARER_TOKEN = token


def set_legacy_datahub_bearer_token(token: str) -> None:
    """
    Legacy datahub / sodas_profile token (profile, QualityMetadata APIs).
    Mirrors `setLegacyDatahubBearerToken` in TS SDK.
    """
    Dataset.BEARER_TOKEN = token
    DataService.BEARER_TOKEN = token
    DatasetSeries.BEARER_TOKEN = token
    Distribution.BEARER_TOKEN = token
    QualityMetadataClient.BEARER_TOKEN = token


def set_bearer_token(token: str) -> None:
    """
    Backward-compatible helper.

    Historically the python SDK used a single token for everything; the TS SDK now
    uses separate tokens. Keep this for older callers, but prefer using
    `set_governance_bearer_token` / `set_legacy_datahub_bearer_token`.
    """
    set_governance_bearer_token(token)
    set_legacy_datahub_bearer_token(token)
