from typing import Any, TypedDict

from sodas_sdk.core.type import (
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


class DefaultExampleTemplateRowType(TypedDict):
    FIELD: str
    VALUE: Any
    DESCRIPTION: str


async def create_default_dcat_example_template() -> Template:
    default_dcat_example_template = Template()
    default_dcat_example_template.default_template = True
    default_dcat_example_template.role = ResourceDescriptorRole.EXAMPLE
    default_dcat_example_template.type = ProfileType.DCAT
    default_dcat_example_template.name = "DCAT_DEFAULT_EXAMPLE_TEMPLATE"
    default_dcat_example_template.description = (
        "DCAT_DEFAULT_EXAMPLE_TEMPLATE\n"
        "This template is used to describe the values of fields."
    )

    # Create Template Details
    field_detail = default_dcat_example_template.create_detail(
        TemplateDetailFunctionality.FIELD
    )
    field_detail.column_name = "FIELD"
    value_detail = default_dcat_example_template.create_detail(
        TemplateDetailFunctionality.VALUE
    )
    value_detail.column_name = "VALUE"
    description_detail = default_dcat_example_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"

    # Save to DB
    await default_dcat_example_template.create_db_record()

    return default_dcat_example_template


async def create_default_data_example_template() -> Template:
    default_data_example_template = Template()
    default_data_example_template.default_template = True
    default_data_example_template.role = ResourceDescriptorRole.EXAMPLE
    default_data_example_template.type = ProfileType.DATA
    default_data_example_template.name = "DATA_DEFAULT_EXAMPLE_TEMPLATE"
    default_data_example_template.description = (
        "DATA_DEFAULT_EXAMPLE_TEMPLATE\n"
        "This template is used to describe the values of fields."
    )

    # Create Template Details
    field_detail = default_data_example_template.create_detail(
        TemplateDetailFunctionality.FIELD
    )
    field_detail.column_name = "FIELD"
    value_detail = default_data_example_template.create_detail(
        TemplateDetailFunctionality.VALUE
    )
    value_detail.column_name = "VALUE"
    description_detail = default_data_example_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"

    # Save to DB
    await default_data_example_template.create_db_record()

    return default_data_example_template
