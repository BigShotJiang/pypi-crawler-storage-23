from typing import TypedDict

from sodas_sdk.core.type import (
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.core.values import CONVERSION_VALUES
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultSpecificationTemplateRowType(TypedDict):
    CONVERSION: CONVERSION_VALUES


async def create_default_dcat_specification_template() -> Template:
    default_dcat_specification_template = Template()
    default_dcat_specification_template.default_template = True
    default_dcat_specification_template.role = ResourceDescriptorRole.SPECIFICATION
    default_dcat_specification_template.type = ProfileType.DCAT
    default_dcat_specification_template.name = "DCAT_DEFAULT_SPECIFICATION_TEMPLATE"
    default_dcat_specification_template.description = (
        "DCAT_DEFAULT_SPECIFICATION_TEMPLATE\n"
        "This template is used to produce specification resource descriptor.\n"
        "Currently, just the html page of the profile could be provided.\n"
        "After some update, pdf serialization would be provided."
    )

    # Create Template Details
    conversion_detail = default_dcat_specification_template.create_detail(
        TemplateDetailFunctionality.CONVERSION
    )
    conversion_detail.column_name = "CONVERSION"

    # Save to DB
    await default_dcat_specification_template.create_db_record()

    return default_dcat_specification_template


async def create_default_data_specification_template() -> Template:
    default_data_specification_template = Template()
    default_data_specification_template.default_template = True
    default_data_specification_template.role = ResourceDescriptorRole.SPECIFICATION
    default_data_specification_template.type = ProfileType.DATA
    default_data_specification_template.name = "DATA_DEFAULT_SPECIFICATION_TEMPLATE"
    default_data_specification_template.description = (
        "DATA_DEFAULT_SPECIFICATION_TEMPLATE\n"
        "This template is used to produce specification resource descriptor.\n"
        "Currently, just the html page of the profile could be provided.\n"
        "After some update, pdf serialization would be provided."
    )

    # Create Template Details
    conversion_detail = default_data_specification_template.create_detail(
        TemplateDetailFunctionality.CONVERSION
    )
    conversion_detail.column_name = "CONVERSION"

    # Save to DB
    await default_data_specification_template.create_db_record()

    return default_data_specification_template
