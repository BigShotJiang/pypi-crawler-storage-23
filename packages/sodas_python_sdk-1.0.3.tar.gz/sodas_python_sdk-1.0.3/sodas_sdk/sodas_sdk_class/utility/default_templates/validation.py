from typing import TypedDict

from sodas_sdk.core.type import (
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.core.values import MEASURE_VALUES
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultValidationTemplateRowType(TypedDict):
    MEASURE: MEASURE_VALUES


async def create_default_dcat_validation_template() -> Template:
    default_dcat_validation_template = Template()
    default_dcat_validation_template.default_template = True
    default_dcat_validation_template.role = ResourceDescriptorRole.VALIDATION
    default_dcat_validation_template.type = ProfileType.DCAT
    default_dcat_validation_template.name = "DCAT_DEFAULT_VALIDATION_TEMPLATE"
    default_dcat_validation_template.description = (
        "DCAT_DEFAULT_VALIDATION_TEMPLATE\n"
        "This template is used to produce quality metadata of resource.\n"
        "Currently, Y-Data and Constraint are available.\n"
        "If you don't add the values here, quality would not be calculated for this resource."
    )

    # Create Template Detail
    measure_detail = default_dcat_validation_template.create_detail(
        TemplateDetailFunctionality.MEASURE
    )
    measure_detail.column_name = "MEASURE"

    # Save to DB
    await default_dcat_validation_template.create_db_record()

    return default_dcat_validation_template


async def create_default_data_validation_template() -> Template:
    default_data_validation_template = Template()
    default_data_validation_template.default_template = True
    default_data_validation_template.role = ResourceDescriptorRole.VALIDATION
    default_data_validation_template.type = ProfileType.DATA
    default_data_validation_template.name = "DATA_DEFAULT_VALIDATION_TEMPLATE"
    default_data_validation_template.description = (
        "DATA_DEFAULT_VALIDATION_TEMPLATE\n"
        "This template is used to produce quality metadata of data.\n"
        "Currently, Y-Data and Constraint are available.\n"
        "If you don't add the values here, quality would not be calculated for this resource."
    )

    # Create Template Detail
    measure_detail = default_data_validation_template.create_detail(
        TemplateDetailFunctionality.MEASURE
    )
    measure_detail.column_name = "MEASURE"

    # Save to DB
    await default_data_validation_template.create_db_record()

    return default_data_validation_template
