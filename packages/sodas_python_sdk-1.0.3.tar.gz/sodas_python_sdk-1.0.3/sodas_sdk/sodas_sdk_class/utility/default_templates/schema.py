from typing import TypedDict, Union

from sodas_sdk.core.type import (
    IRIType,
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.core.values import BASIC_TYPE_VALUES
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultDCATSchemaTemplateRowType(TypedDict):
    NAME: str
    TYPE: Union[BASIC_TYPE_VALUES, str]
    DESCRIPTION: str
    REQUIRED: bool
    NAMESPACE: IRIType
    FIELD_TERM: str


async def create_default_dcat_schema_template() -> Template:
    default_dcat_schema_template = Template()
    default_dcat_schema_template.default_template = True
    default_dcat_schema_template.role = ResourceDescriptorRole.SCHEMA
    default_dcat_schema_template.type = ProfileType.DCAT
    default_dcat_schema_template.name = "DCAT_DEFAULT_SCHEMA_TEMPLATE"
    default_dcat_schema_template.description = (
        "DCAT_DEFAULT_SCHEMA_TEMPLATE\n"
        "This template is used to register the SCHEMA which is needed to represent extended DCAT fields.\n"
        "If you register some types in type resource descriptor, "
        "you could use them in this type field.\n"
        "The type you register here would help users put right value in datahub portal.\n"
        "And value of 'REQUIRED' field would help users to put value correctly.\n"
        "The vocabulary field could be selected using the vocabulary already registered, "
        "and the vocabulary you registered in vocabulary resource descriptor.\n"
        "The vocabulary would be used to represent the field and parse resource to RDF."
    )

    # Create Template Details
    name_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.NAME
    )
    name_detail.column_name = "NAME"
    type_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.TYPE
    )
    type_detail.column_name = "TYPE"
    description_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"
    required_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.REQUIRED
    )
    required_detail.column_name = "REQUIRED"
    namespace_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.NAMESPACE
    )
    namespace_detail.column_name = "VOCABULARY"
    term_detail = default_dcat_schema_template.create_detail(
        TemplateDetailFunctionality.FIELD_TERM
    )
    term_detail.column_name = "TERM"

    # Save to DB
    await default_dcat_schema_template.create_db_record()

    return default_dcat_schema_template


async def create_default_data_schema_template() -> Template:
    default_data_schema_template = Template()
    default_data_schema_template.default_template = True
    default_data_schema_template.role = ResourceDescriptorRole.SCHEMA
    default_data_schema_template.type = ProfileType.DATA
    default_data_schema_template.name = "DATA_DEFAULT_SCHEMA_TEMPLATE"
    default_data_schema_template.description = (
        "DATA_DEFAULT_SCHEMA_TEMPLATE\n"
        "This template is used to register the SCHEMA which is needed to represent extended DCAT fields.\n"
        "If you register some types in type resource descriptor, "
        "you could use them in this type field.\n"
        "The type you register here would help users put right value in datahub portal.\n"
        "And value of 'REQUIRED' field would help users to put value correctly."
    )

    # Create Template Details
    name_detail = default_data_schema_template.create_detail(
        TemplateDetailFunctionality.NAME
    )
    name_detail.column_name = "NAME"
    type_detail = default_data_schema_template.create_detail(
        TemplateDetailFunctionality.TYPE
    )
    type_detail.column_name = "TYPE"
    description_detail = default_data_schema_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"
    required_detail = default_data_schema_template.create_detail(
        TemplateDetailFunctionality.REQUIRED
    )
    required_detail.column_name = "REQUIRED"

    # Save to DB
    await default_data_schema_template.create_db_record()

    return default_data_schema_template
