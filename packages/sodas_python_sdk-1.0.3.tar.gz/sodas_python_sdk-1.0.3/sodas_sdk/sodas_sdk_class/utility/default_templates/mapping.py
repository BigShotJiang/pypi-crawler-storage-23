from typing import TypedDict

from sodas_sdk.core.type import (
    IRIType,
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultMappingTemplateRowType(TypedDict):
    FIELD: str
    TARGET_PROFILE: IRIType
    TARGET_FIELD: str


async def create_default_dcat_mapping_template() -> Template:
    default_dcat_mapping_template = Template()
    default_dcat_mapping_template.default_template = True
    default_dcat_mapping_template.role = ResourceDescriptorRole.MAPPING
    default_dcat_mapping_template.type = ProfileType.DCAT
    default_dcat_mapping_template.name = "DCAT_DEFAULT_MAPPING_TEMPLATE"
    default_dcat_mapping_template.description = (
        "DCAT_DEFAULT_MAPPING_TEMPLATE\n"
        "This template is used to map fields between profiles.\n"
        "After you select Target Profile, field would be automatically created, "
        "and you have to choose field of Target Profile.\n"
        "The mapping functionality is provided in datahub portal."
    )

    # Create Template Details
    field_detail = default_dcat_mapping_template.create_detail(
        TemplateDetailFunctionality.FIELD
    )
    field_detail.column_name = "FIELD"
    target_profile_detail = default_dcat_mapping_template.create_detail(
        TemplateDetailFunctionality.TARGET_PROFILE
    )
    target_profile_detail.column_name = "TARGET PROFILE"
    target_field_detail = default_dcat_mapping_template.create_detail(
        TemplateDetailFunctionality.TARGET_FIELD
    )
    target_field_detail.column_name = "TARGET FIELD"

    # Save to DB
    await default_dcat_mapping_template.create_db_record()

    return default_dcat_mapping_template


async def create_default_data_mapping_template() -> Template:
    default_data_mapping_template = Template()
    default_data_mapping_template.default_template = True
    default_data_mapping_template.role = ResourceDescriptorRole.MAPPING
    default_data_mapping_template.type = ProfileType.DATA
    default_data_mapping_template.name = "DATA_DEFAULT_MAPPING_TEMPLATE"
    default_data_mapping_template.description = (
        "DATA_DEFAULT_MAPPING_TEMPLATE\n"
        "This template is used to map fields between profiles.\n"
        "After you select Target Profile, field would be automatically created, "
        "and you have to choose field of Target Profile.\n"
        "The mapping functionality is provided in datahub portal."
    )

    # Create Template Details
    field_detail = default_data_mapping_template.create_detail(
        TemplateDetailFunctionality.FIELD
    )
    field_detail.column_name = "FIELD"
    target_profile_detail = default_data_mapping_template.create_detail(
        TemplateDetailFunctionality.TARGET_PROFILE
    )
    target_profile_detail.column_name = "TARGET PROFILE"
    target_field_detail = default_data_mapping_template.create_detail(
        TemplateDetailFunctionality.TARGET_FIELD
    )
    target_field_detail.column_name = "TARGET FIELD"

    # Save to DB
    await default_data_mapping_template.create_db_record()

    return default_data_mapping_template
