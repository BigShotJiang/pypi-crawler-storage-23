from typing import TypedDict

from sodas_sdk.core.type import (
    IRIType,
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.core.values import ORIGIN_VALUES
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultVocabularyTemplateRowType(TypedDict):
    ORIGIN: ORIGIN_VALUES
    NAMESPACE: IRIType
    TERM: str
    DESCRIPTION: str


async def create_default_dcat_vocabulary_template() -> Template:
    default_dcat_vocabulary_template = Template()
    default_dcat_vocabulary_template.default_template = True
    default_dcat_vocabulary_template.role = ResourceDescriptorRole.VOCABULARY
    default_dcat_vocabulary_template.type = ProfileType.DCAT
    default_dcat_vocabulary_template.name = "DCAT_DEFAULT_VOCABULARY_TEMPLATE"
    default_dcat_vocabulary_template.description = (
        "DCAT_DEFAULT_VOCABULARY_TEMPLATE\n"
        "If you wanna register your original vocabulary, use 'ORIGINAL'.\n"
        "If you wanna register external vocabulary like dcat, use 'EXTERNAL'.\n"
        "If you know vocabulary is already registered but show the vocabulary "
        "because of its importance, use 'REGISTERED'"
    )

    # Create Template Details
    origin_detail = default_dcat_vocabulary_template.create_detail(
        TemplateDetailFunctionality.ORIGIN
    )
    origin_detail.column_name = "ORIGIN"

    namespace_prefix_detail = default_dcat_vocabulary_template.create_detail(
        TemplateDetailFunctionality.NAMESPACE
    )
    namespace_prefix_detail.column_name = "PREFIX"

    term_detail = default_dcat_vocabulary_template.create_detail(
        TemplateDetailFunctionality.TERM
    )
    term_detail.column_name = "TERM"

    description_detail = default_dcat_vocabulary_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"

    # Save to DB
    await default_dcat_vocabulary_template.create_db_record()

    return default_dcat_vocabulary_template


async def create_default_data_vocabulary_template() -> Template:
    default_data_vocabulary_template = Template()
    default_data_vocabulary_template.default_template = True
    default_data_vocabulary_template.role = ResourceDescriptorRole.VOCABULARY
    default_data_vocabulary_template.type = ProfileType.DATA
    default_data_vocabulary_template.name = "DATA_DEFAULT_VOCABULARY_TEMPLATE"
    default_data_vocabulary_template.description = (
        "DATA_DEFAULT_VOCABULARY_TEMPLATE\n"
        "If you wanna register your original vocabulary, use 'ORIGINAL'.\n"
        "If you wanna register external vocabulary like dcat, use 'EXTERNAL'.\n"
        "If you know vocabulary is already registered but show the vocabulary "
        "because of its importance, use 'REGISTERED'"
    )

    # Create Template Details
    origin_detail = default_data_vocabulary_template.create_detail(
        TemplateDetailFunctionality.ORIGIN
    )
    origin_detail.column_name = "ORIGIN"

    namespace_prefix_detail = default_data_vocabulary_template.create_detail(
        TemplateDetailFunctionality.NAMESPACE
    )
    namespace_prefix_detail.column_name = "PREFIX"

    term_detail = default_data_vocabulary_template.create_detail(
        TemplateDetailFunctionality.TERM
    )
    term_detail.column_name = "TERM"

    description_detail = default_data_vocabulary_template.create_detail(
        TemplateDetailFunctionality.DESCRIPTION
    )
    description_detail.column_name = "DESCRIPTION"

    # Save to DB
    await default_data_vocabulary_template.create_db_record()

    return default_data_vocabulary_template
