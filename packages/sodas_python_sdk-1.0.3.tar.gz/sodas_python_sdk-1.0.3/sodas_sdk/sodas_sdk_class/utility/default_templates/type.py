from typing import TypedDict

from sodas_sdk.core.type import (
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


# Define the row type using TypedDict
class DefaultTypeTemplateRowType(TypedDict):
    NAME: str
    LABEL: str
    VALUE: str


async def create_default_dcat_type_template() -> Template:
    default_dcat_type_template = Template()
    default_dcat_type_template.default_template = True
    default_dcat_type_template.role = ResourceDescriptorRole.TYPE
    default_dcat_type_template.type = ProfileType.DCAT
    default_dcat_type_template.name = "DCAT_DEFAULT_TYPE_TEMPLATE"
    default_dcat_type_template.description = (
        "DCAT_DEFAULT_TYPE_TEMPLATE\n"
        "This template is used to register the type which is needed to represent specific custom type.\n"
        "The registered type could be used in schema resource descriptor.\n"
        "After you use the type you registered in schema resource descriptor, "
        "the registered type could be used in the datahub portal and displayed as select box.\n"
        "The rows with same name would make one named type.\n"
        "So if you write different names, different types would be made.\n"
        "The value you put in LABEL field would be displayed name.\n"
        "And the value you put in VALUE field would be the actual value field."
    )

    # Create Template Details
    name_detail = default_dcat_type_template.create_detail(
        TemplateDetailFunctionality.NAME
    )
    name_detail.column_name = "NAME"
    label_detail = default_dcat_type_template.create_detail(
        TemplateDetailFunctionality.LABEL
    )
    label_detail.column_name = "LABEL"
    value_detail = default_dcat_type_template.create_detail(
        TemplateDetailFunctionality.VALUE
    )
    value_detail.column_name = "VALUE"

    # Save to DB
    await default_dcat_type_template.create_db_record()

    return default_dcat_type_template


async def create_default_data_type_template() -> Template:
    default_data_type_template = Template()
    default_data_type_template.default_template = True
    default_data_type_template.role = ResourceDescriptorRole.TYPE
    default_data_type_template.type = ProfileType.DATA
    default_data_type_template.name = "DATA_DEFAULT_TYPE_TEMPLATE"
    default_data_type_template.description = (
        "DATA_DEFAULT_TYPE_TEMPLATE\n"
        "This template is used to register the type which is needed to represent specific custom type.\n"
        "The registered type could be used in schema resource descriptor.\n"
        "After you use the type you registered in schema resource descriptor, "
        "the registered type could be used in the datahub portal and displayed as select box.\n"
        "The rows with same name would make one named type.\n"
        "So if you write different names, different types would be made.\n"
        "The value you put in LABEL field would be displayed name.\n"
        "And the value you put in VALUE field would be the actual value field."
    )

    # Create Template Details
    name_detail = default_data_type_template.create_detail(
        TemplateDetailFunctionality.NAME
    )
    name_detail.column_name = "NAME"
    label_detail = default_data_type_template.create_detail(
        TemplateDetailFunctionality.LABEL
    )
    label_detail.column_name = "LABEL"
    value_detail = default_data_type_template.create_detail(
        TemplateDetailFunctionality.VALUE
    )
    value_detail.column_name = "VALUE"

    # Save to DB
    await default_data_type_template.create_db_record()

    return default_data_type_template
