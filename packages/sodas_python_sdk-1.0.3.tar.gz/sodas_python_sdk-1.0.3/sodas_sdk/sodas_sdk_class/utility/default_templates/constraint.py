from typing import TypedDict

from sodas_sdk.core.type import (
    ProfileType,
    ResourceDescriptorRole,
    TemplateDetailFunctionality,
)
from sodas_sdk.sodas_sdk_class.SODAS.template import Template


class DefaultDCATConstraintTemplateRowType(TypedDict):
    FIELD: str
    REQUIRED: bool


async def create_default_dcat_constraint_template() -> Template:
    template = Template()
    template.default_template = True
    template.role = ResourceDescriptorRole.CONSTRAINT
    template.type = ProfileType.DCAT
    template.name = "DCAT_DEFAULT_CONSTRAINT_TEMPLATE"
    template.description = (
        "DCAT_DEFAULT_CONSTRAINT_TEMPLATE\n"
        "This template is used to produce quality metadata of resource.\n"
        "The Field would be automatically gotten from schema resource descriptor.\n"
        "The 'required' value you put in would be used to check the quality "
        "when you put the 'CONSTRAINT' to validation resource descriptor."
    )

    field_detail = template.create_detail(TemplateDetailFunctionality.FIELD)
    field_detail.column_name = "FIELD"
    required_detail = template.create_detail(TemplateDetailFunctionality.REQUIRED)
    required_detail.column_name = "REQUIRED"

    await template.create_db_record()
    return template


class DefaultDataConstraintTemplateRowType(TypedDict):
    FIELD: str
    REQUIRED: bool
    TYPE: str
    REGEX: str


async def create_default_data_constraint_template() -> Template:
    template = Template()
    template.default_template = True
    template.role = ResourceDescriptorRole.CONSTRAINT
    template.type = ProfileType.DATA
    template.name = "DATA_DEFAULT_CONSTRAINT_TEMPLATE"
    template.description = (
        "DATA_DEFAULT_CONSTRAINT_TEMPLATE\n"
        "This template is used to produce quality metadata of data.\n"
        "The Field would be automatically gotten from schema resource descriptor.\n"
        "The 'type', 'required', and 'regex' value you put in would be used to check the quality "
        "when you put the 'CONSTRAINT' to validation resource descriptor."
    )

    field_detail = template.create_detail(TemplateDetailFunctionality.FIELD)
    field_detail.column_name = "FIELD"

    type_detail = template.create_detail(TemplateDetailFunctionality.TYPE)
    type_detail.column_name = "TYPE"

    required_detail = template.create_detail(TemplateDetailFunctionality.REQUIRED)
    required_detail.column_name = "REQUIRED"

    regex_detail = template.create_detail(TemplateDetailFunctionality.REGEX)
    regex_detail.column_name = "REGEX"

    await template.create_db_record()
    return template
