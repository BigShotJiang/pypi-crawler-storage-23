from sodas_sdk.sodas_sdk_class.utility.default_templates.constraint import (
    create_default_data_constraint_template,
    create_default_dcat_constraint_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.mapping import (
    create_default_data_mapping_template,
    create_default_dcat_mapping_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.schema import (
    create_default_data_schema_template,
    create_default_dcat_schema_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.specification import (
    create_default_data_specification_template,
    create_default_dcat_specification_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.type import (
    create_default_data_type_template,
    create_default_dcat_type_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.validation import (
    create_default_data_validation_template,
    create_default_dcat_validation_template,
)
from sodas_sdk.sodas_sdk_class.utility.default_templates.vocabulary import (
    create_default_data_vocabulary_template,
    create_default_dcat_vocabulary_template,
)


async def create_all_default_templates_if_not_exist():
    try:
        await create_default_dcat_vocabulary_template()
    except Exception as error:
        print(f"Error in creating DCAT Vocabulary Template: {error}")

    try:
        await create_default_data_vocabulary_template()
    except Exception as error:
        print(f"Error in creating Data Vocabulary Template: {error}")

    try:
        await create_default_dcat_type_template()
    except Exception as error:
        print(f"Error in creating DCAT Type Template: {error}")

    try:
        await create_default_data_type_template()
    except Exception as error:
        print(f"Error in creating Data Type Template: {error}")

    try:
        await create_default_dcat_schema_template()
    except Exception as error:
        print(f"Error in creating DCAT Schema Template: {error}")

    try:
        await create_default_data_schema_template()
    except Exception as error:
        print(f"Error in creating Data Schema Template: {error}")

    try:
        await create_default_dcat_constraint_template()
    except Exception as error:
        print(f"Error in creating DCAT Constraint Template: {error}")

    try:
        await create_default_data_constraint_template()
    except Exception as error:
        print(f"Error in creating Data Constraint Template: {error}")

    try:
        await create_default_dcat_validation_template()
    except Exception as error:
        print(f"Error in creating DCAT Validation Template: {error}")

    try:
        await create_default_data_validation_template()
    except Exception as error:
        print(f"Error in creating Data Validation Template: {error}")

    try:
        await create_default_dcat_mapping_template()
    except Exception as error:
        print(f"Error in creating DCAT Mapping Template: {error}")

    try:
        await create_default_data_mapping_template()
    except Exception as error:
        print(f"Error in creating Data Mapping Template: {error}")

    try:
        await create_default_dcat_specification_template()
    except Exception as error:
        print(f"Error in creating DCAT Specification Template: {error}")

    try:
        await create_default_data_specification_template()
    except Exception as error:
        print(f"Error in creating Data Specification Template: {error}")
