"""
Validation rule types and rule classes. Mirrors sodas_sdk/lib/SODAS_SDK_CLASS/template/validationType.ts.
"""

from abc import ABC
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class VALIDATION_TYPE(str, Enum):
    DATA_TYPE = "data_type"
    RANGE = "range"
    PATTERN = "pattern"
    UNIQUENESS = "uniqueness"
    CUSTOM = "custom"
    COMPLETENESS = "completeness"
    LENGTH = "length"
    ALLOWED_VALUES = "allowed_values"
    OUTLIER = "outlier"
    STATISTICAL = "statistical"


class EXPECTED_TYPE(str, Enum):
    NUMERIC = "numeric"
    STRING = "string"
    DATETIME = "datetime"


class COMPARISION_OPERATOR(str, Enum):
    EQUAL = "=="
    NOT_EQUAL = "!="
    GREATER_THAN = ">"
    LESS_THAN = "<"
    GREATER_THAN_OR_EQUAL = ">="
    LESS_THAN_OR_EQUAL = "<="


class CUSTOM_CONDITION_TYPE(str, Enum):
    ALL = "all"
    ANY = "any"
    MIN = "min"
    MAX = "max"
    MEAN = "mean"
    RATIO = "ratio"


class OUTLIER_METHOD(str, Enum):
    Z_SCORE = "zscore"
    IQR = "iqr"
    ISOLATION = "isolation"


class DATETIME_FORMAT_TYPE(str, Enum):
    YYYY_MM_DD_HH_MM_SS = "%Y-%m-%d %H:%M:%S"
    YYYY_MM_DD = "%Y-%m-%d"
    YYYY_MM_DD_SLASH = "%Y/%m/%d"
    DD_MM_YYYY = "%d-%m-%Y"
    YYYY_MM_DD_T_HH_MM_SS = "%Y-%m-%dT%H:%M:%S"


class ValidationRuleDTO(BaseModel):
    column: str = ""
    name: str = ""
    type: str = ""
    weight: float = 0.0


class QualityMetadata(BaseModel):
    """Result of a single validation rule: rule identity + pass/fail + score (metric)."""

    rule_type: str = ""
    column: Optional[str] = None
    name: str = ""
    passed: bool = False
    score: float = 0.0
    details: Dict[str, Any] = Field(default_factory=dict)


class CUSTOM_CONDITION(BaseModel):
    type: CUSTOM_CONDITION_TYPE = CUSTOM_CONDITION_TYPE.ALL
    threholder: float = 0.0
    comparision: COMPARISION_OPERATOR = COMPARISION_OPERATOR.EQUAL


class ValidationRule(ABC):
    def __init__(self, rule_type: VALIDATION_TYPE) -> None:
        self._column: str = ""
        self._name: str = ""
        self._type: VALIDATION_TYPE = rule_type
        self._weight: float = 0.0

    def to_dto(self) -> Dict[str, Any]:
        return {
            "column": self._column,
            "name": self._name,
            "type": self._type.value,
            "weight": self._weight,
        }

    def populate_from_dto(self, dto: Any) -> None:
        if isinstance(dto, dict):
            self._column = dto.get("column") or ""
            self._name = dto.get("name") or ""
            w = dto.get("weight")
            self._weight = w if w is not None else 0.0
        else:
            self._column = getattr(dto, "column", "") or ""
            self._name = getattr(dto, "name", "") or ""
            w = getattr(dto, "weight", None)
            self._weight = w if w is not None else 0.0

    def set_column(self, column: str) -> "ValidationRule":
        self._column = column
        return self

    def set_name(self, name: str) -> "ValidationRule":
        self._name = name
        return self

    def set_weight(self, weight: float) -> "ValidationRule":
        self._weight = weight
        return self

    @property
    def column(self) -> str:
        return self._column

    @property
    def name(self) -> str:
        return self._name

    @property
    def type(self) -> VALIDATION_TYPE:
        return self._type

    @property
    def weight(self) -> float:
        return self._weight


class UniquenessValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.UNIQUENESS)
        self._unique: bool = False

    def to_dto(self) -> Dict[str, Any]:
        return {**super().to_dto(), "unique": self._unique}

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        raw = (
            getattr(dto, "unique", None)
            if hasattr(dto, "unique")
            else (dto.get("unique", False) if isinstance(dto, dict) else False)
        )
        self._unique = bool(raw) if raw is not None else False

    def set_unique(self, unique: bool) -> "UniquenessValidationRule":
        self._unique = unique
        return self

    @property
    def unique(self) -> bool:
        return self._unique


class PatternValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.PATTERN)
        self._pattern: str = ""

    def to_dto(self) -> Dict[str, Any]:
        return {**super().to_dto(), "pattern": self._pattern}

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        self._pattern = (
            getattr(dto, "pattern", None)
            or (dto.get("pattern", "") if isinstance(dto, dict) else "")
            or ""
        )

    def set_pattern(self, pattern: str) -> "PatternValidationRule":
        self._pattern = pattern
        return self

    @property
    def pattern(self) -> str:
        return self._pattern


class RangeValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.RANGE)
        self._min_value: float = 0.0
        self._max_value: float = 0.0

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "min_value": self._min_value,
            "max_value": self._max_value,
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        mv = (
            getattr(dto, "min_value", None)
            if hasattr(dto, "min_value")
            else (dto.get("min_value", 0) if isinstance(dto, dict) else 0)
        )
        xv = (
            getattr(dto, "max_value", None)
            if hasattr(dto, "max_value")
            else (dto.get("max_value", 0) if isinstance(dto, dict) else 0)
        )
        self._min_value = float(mv) if mv is not None else 0.0
        self._max_value = float(xv) if xv is not None else 0.0

    def set_min_value(self, v: float) -> "RangeValidationRule":
        self._min_value = v
        return self

    def set_max_value(self, v: float) -> "RangeValidationRule":
        self._max_value = v
        return self

    @property
    def min_value(self) -> float:
        return self._min_value

    @property
    def max_value(self) -> float:
        return self._max_value


class CustomValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.CUSTOM)
        self._condition: CUSTOM_CONDITION = CUSTOM_CONDITION()

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "condition": {
                "type": self._condition.type.value,
                "threholder": self._condition.threholder,
                "comparision": self._condition.comparision.value,
            },
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        raw = getattr(dto, "condition", None) or (
            dto.get("condition") if isinstance(dto, dict) else None
        )
        if raw:
            thr_val = (
                getattr(raw, "threholder", raw.get("threholder", 0))
                if isinstance(raw, dict)
                else getattr(raw, "threholder", 0)
            )
            self._condition = CUSTOM_CONDITION(
                type=CUSTOM_CONDITION_TYPE(
                    getattr(raw, "type", raw.get("type", "all"))
                    if isinstance(raw, dict)
                    else getattr(raw, "type", CUSTOM_CONDITION_TYPE.ALL)
                ),
                threholder=float(thr_val) if thr_val is not None else 0.0,
                comparision=COMPARISION_OPERATOR(
                    getattr(raw, "comparision", raw.get("comparision", "=="))
                    if isinstance(raw, dict)
                    else getattr(raw, "comparision", COMPARISION_OPERATOR.EQUAL)
                ),
            )

    def set_condition(self, condition: CUSTOM_CONDITION) -> "CustomValidationRule":
        self._condition = condition
        return self

    @property
    def condition(self) -> CUSTOM_CONDITION:
        return self._condition


class LengthValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.LENGTH)
        self._min_length: float = 0.0
        self._max_length: float = 0.0

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "min_length": self._min_length,
            "max_length": self._max_length,
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        ml = (
            getattr(dto, "min_length", None)
            if hasattr(dto, "min_length")
            else (dto.get("min_length", 0) if isinstance(dto, dict) else 0) or 0
        )
        xl = (
            getattr(dto, "max_length", None)
            if hasattr(dto, "max_length")
            else (dto.get("max_length", 0) if isinstance(dto, dict) else 0) or 0
        )
        self._min_length = float(ml) if ml is not None else 0.0
        self._max_length = float(xl) if xl is not None else 0.0

    def set_min_length(self, v: float) -> "LengthValidationRule":
        self._min_length = v
        return self

    def set_max_length(self, v: float) -> "LengthValidationRule":
        self._max_length = v
        return self

    @property
    def min_length(self) -> float:
        return self._min_length

    @property
    def max_length(self) -> float:
        return self._max_length


class AllowedValuesValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.ALLOWED_VALUES)
        self._allowed_values: List[str] = []

    def to_dto(self) -> Dict[str, Any]:
        return {**super().to_dto(), "allowed_values": self._allowed_values}

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        self._allowed_values = (
            getattr(dto, "allowed_values", None)
            or (dto.get("allowed_values", []) if isinstance(dto, dict) else [])
            or []
        )

    def set_allowed_values(self, v: List[str]) -> "AllowedValuesValidationRule":
        self._allowed_values = v
        return self

    @property
    def allowed_values(self) -> List[str]:
        return self._allowed_values


class OutlierValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.OUTLIER)
        self._method: OUTLIER_METHOD = OUTLIER_METHOD.Z_SCORE
        self._threshold: float = 0.0

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "method": self._method.value,
            "threshold": self._threshold,
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        self._method = OUTLIER_METHOD(
            getattr(dto, "method", None)
            or (dto.get("method", "zscore") if isinstance(dto, dict) else "zscore")
            or "zscore"
        )
        th = (
            getattr(dto, "threshold", None)
            if hasattr(dto, "threshold")
            else (dto.get("threshold", 0) if isinstance(dto, dict) else 0) or 0
        )
        self._threshold = float(th) if th is not None else 0.0

    def set_method(self, m: OUTLIER_METHOD) -> "OutlierValidationRule":
        self._method = m
        return self

    def set_threshold(self, t: float) -> "OutlierValidationRule":
        self._threshold = t
        return self

    @property
    def method(self) -> OUTLIER_METHOD:
        return self._method

    @property
    def threshold(self) -> float:
        return self._threshold


class StatisticalValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.STATISTICAL)
        self._check: str = ""
        self._threshold: float = 0.0
        self._comparision: COMPARISION_OPERATOR = COMPARISION_OPERATOR.EQUAL

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "check": self._check,
            "threshold": self._threshold,
            "comparision": self._comparision.value,
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        self._check = (
            getattr(dto, "check", None)
            or (dto.get("check", "") if isinstance(dto, dict) else "")
            or ""
        )
        th = (
            getattr(dto, "threshold", None)
            if hasattr(dto, "threshold")
            else (dto.get("threshold", 0) if isinstance(dto, dict) else 0) or 0
        )
        self._threshold = float(th) if th is not None else 0.0
        self._comparision = COMPARISION_OPERATOR(
            getattr(dto, "comparision", None)
            or (dto.get("comparision", "==") if isinstance(dto, dict) else "==")
            or "=="
        )

    def set_check(self, c: str) -> "StatisticalValidationRule":
        self._check = c
        return self

    def set_threshold(self, t: float) -> "StatisticalValidationRule":
        self._threshold = t
        return self

    def set_comparision(self, c: COMPARISION_OPERATOR) -> "StatisticalValidationRule":
        self._comparision = c
        return self

    @property
    def check(self) -> str:
        return self._check

    @property
    def threshold(self) -> float:
        return self._threshold

    @property
    def comparision(self) -> COMPARISION_OPERATOR:
        return self._comparision


class CompletenessValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.COMPLETENESS)
        self._min_completeness: float = 0.0

    def to_dto(self) -> Dict[str, Any]:
        return {**super().to_dto(), "min_completeness": self._min_completeness}

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        mc = (
            getattr(dto, "min_completeness", None)
            if hasattr(dto, "min_completeness")
            else (dto.get("min_completeness", 0) if isinstance(dto, dict) else 0)
        )
        self._min_completeness = float(mc) if mc is not None else 0.0

    def set_min_completeness(self, v: float) -> "CompletenessValidationRule":
        self._min_completeness = v
        return self

    @property
    def min_completeness(self) -> float:
        return self._min_completeness


class DataTypeValidationRule(ValidationRule):
    def __init__(self) -> None:
        super().__init__(VALIDATION_TYPE.DATA_TYPE)
        self._expected_type: EXPECTED_TYPE = EXPECTED_TYPE.STRING
        self._datetime_format: DATETIME_FORMAT_TYPE = (
            DATETIME_FORMAT_TYPE.YYYY_MM_DD_HH_MM_SS
        )

    def to_dto(self) -> Dict[str, Any]:
        return {
            **super().to_dto(),
            "expected_type": self._expected_type.value,
            "datetime_format": self._datetime_format.value,
        }

    def populate_from_dto(self, dto: Any) -> None:
        super().populate_from_dto(dto)
        et = (
            getattr(dto, "expected_type", None)
            or (
                dto.get("expected_type", "string")
                if isinstance(dto, dict)
                else "string"
            )
            or "string"
        )
        df = (
            getattr(dto, "datetime_format", None)
            or (
                dto.get("datetime_format", "%Y-%m-%d %H:%M:%S")
                if isinstance(dto, dict)
                else "%Y-%m-%d %H:%M:%S"
            )
            or "%Y-%m-%d %H:%M:%S"
        )
        self._expected_type = EXPECTED_TYPE(et)
        self._datetime_format = DATETIME_FORMAT_TYPE(df)

    def set_expected_type(self, v: EXPECTED_TYPE) -> "DataTypeValidationRule":
        self._expected_type = v
        return self

    def set_datetime_format(self, v: DATETIME_FORMAT_TYPE) -> "DataTypeValidationRule":
        self._datetime_format = v
        return self

    @property
    def expected_type(self) -> EXPECTED_TYPE:
        return self._expected_type

    @property
    def datetime_format(self) -> DATETIME_FORMAT_TYPE:
        return self._datetime_format


def create_rule(rule_type: VALIDATION_TYPE) -> ValidationRule:
    """
    Factory for validation rules by type. Mirrors TS SDK createRule().
    """
    if rule_type == VALIDATION_TYPE.ALLOWED_VALUES:
        return AllowedValuesValidationRule()
    if rule_type == VALIDATION_TYPE.COMPLETENESS:
        return CompletenessValidationRule()
    if rule_type == VALIDATION_TYPE.CUSTOM:
        return CustomValidationRule()
    if rule_type == VALIDATION_TYPE.DATA_TYPE:
        return DataTypeValidationRule()
    if rule_type == VALIDATION_TYPE.LENGTH:
        return LengthValidationRule()
    if rule_type == VALIDATION_TYPE.OUTLIER:
        return OutlierValidationRule()
    if rule_type == VALIDATION_TYPE.PATTERN:
        return PatternValidationRule()
    if rule_type == VALIDATION_TYPE.RANGE:
        return RangeValidationRule()
    if rule_type == VALIDATION_TYPE.STATISTICAL:
        return StatisticalValidationRule()
    if rule_type == VALIDATION_TYPE.UNIQUENESS:
        return UniquenessValidationRule()
    raise ValueError(f"Unknown validation rule type: {rule_type}")
