"""
Quality metadata types and API client. Mirrors sodas_sdk/lib/SODAS_SDK_CLASS/validation/quality.ts.

QualityMetadata is the result of a validation rule run (read-only, populated from API).
QualityMetadataByDistributionIRI maps distribution IRI -> array of quality metadata.

QualityMetadataClient wraps GET/POST/DELETE /validation/quality APIs and
POST /validation/measure-distribution-quality, POST /validation/append-dropped-distribution.
"""

from typing import Any, ClassVar, Dict, List, Optional, cast

import requests

from sodas_sdk.core.error import APIURLNotSetError
from sodas_sdk.core.util import handle_error
from sodas_sdk.sodas_sdk_class.DCAT.distribution import Distribution, DistributionDTO
from sodas_sdk.sodas_sdk_class.validation.type import ValidationRule

# QualityMetadataByDistributionIRI = Record<distributionIRI, QualityMetadata[]>
# TS: QualityMetadataByDistributionIRI = Record<string, QualityMetadata[]>
QualityMetadataByDistributionIRI = Dict[str, List[Dict[str, Any]]]

# Quality API lives under SODAS_PROFILE_BASE_URL (datahub), not governance
QUALITY_API_PATH = "validation/quality"
MEASURE_DISTRIBUTION_QUALITY_PATH = "validation/measure-distribution-quality"
APPEND_DROPPED_DISTRIBUTION_PATH = "validation/append-dropped-distribution"


class QualityMetadataClient:
    """
    API client for quality metadata endpoints.
    GET /validation/quality - Get quality metadata for a distribution
    POST /validation/quality - Create or replace (UPSERT)
    DELETE /validation/quality - Delete quality metadata
    """

    API_URL: ClassVar[Optional[str]] = None
    BEARER_TOKEN: ClassVar[Optional[str]] = None

    @classmethod
    def configure_api_url(cls, url: str) -> None:
        """Configure with SODAS_PROFILE_BASE_URL (datahub API base)."""
        cls.API_URL = f"{url.rstrip('/')}/{QUALITY_API_PATH}"

    @classmethod
    def _auth_headers(cls) -> Dict[str, str]:
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        token = getattr(cls, "BEARER_TOKEN", None)
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    @classmethod
    def _ensure_url(cls) -> None:
        if not cls.API_URL:
            raise APIURLNotSetError(cls)

    @classmethod
    def _validation_base_url(cls) -> str:
        """Base URL (no path) for validation APIs; derived from API_URL."""
        url = cast(str, cls.API_URL)
        suffix = f"/{QUALITY_API_PATH}"
        if not url.endswith(suffix):
            raise ValueError(
                "QualityMetadataClient API URL is not configured or has unexpected format"
            )
        return url[: -len(suffix)]

    @classmethod
    def get(cls, distribution_iri: str) -> List[Dict[str, Any]]:
        """
        Get quality metadata for a distribution.
        Returns: quality_metadata list (QualityMetadata[]).
        """
        cls._ensure_url()
        url: str = cast(str, cls.API_URL)
        try:
            response = requests.get(
                url,
                params={"distribution_iri": distribution_iri},
                headers=cls._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
            return data.get("quality_metadata") or []
        except Exception as e:
            handle_error(e)

    @classmethod
    def upsert(
        cls,
        distribution_iri: str,
        quality_metadata: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Create or replace quality metadata for a distribution (UPSERT).
        Returns: quality_metadata list (QualityMetadata[]).
        """
        cls._ensure_url()
        url: str = cast(str, cls.API_URL)
        try:
            response = requests.post(
                url,
                json={
                    "distribution_iri": distribution_iri,
                    "quality_metadata": quality_metadata,
                },
                headers=cls._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
            return data.get("quality_metadata") or []
        except Exception as e:
            handle_error(e)

    @classmethod
    def delete(cls, distribution_iri: str) -> str:
        """
        Delete quality metadata for a distribution.
        Returns: message string.
        """
        cls._ensure_url()
        url: str = cast(str, cls.API_URL)
        try:
            response = requests.delete(
                url,
                params={"distribution_iri": distribution_iri},
                headers=cls._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
            return data.get("message") or ""
        except Exception as e:
            handle_error(e)

    @classmethod
    def measure_distribution_quality(
        cls,
        distribution: Distribution,
        validation_rules: List[ValidationRule],
        *,
        assessment_name: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Measure quality of an existing distribution using SDK Distribution and ValidationRule instances.
        POST /validation/measure-distribution-quality
        Fetches the distribution's CSV, applies the given validation rules, and saves
        the quality metadata. No new distribution is created.
        Returns: quality_metadata list (QualityMetadata[]).
        """
        if not distribution.iri:
            raise ValueError("Distribution must have an IRI set")
        cls._ensure_url()
        base = cls._validation_base_url()
        url = f"{base}/{MEASURE_DISTRIBUTION_QUALITY_PATH}"
        try:
            body: Dict[str, Any] = {
                "distribution_iri": distribution.iri,
                "validation_rules": [r.to_dto() for r in validation_rules],
            }
            if assessment_name is not None:
                body["assessment_name"] = assessment_name
            response = requests.post(
                url,
                json=body,
                headers=cls._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
            return data.get("quality_metadata") or []
        except Exception as e:
            handle_error(e)

    @classmethod
    async def append_dropped_distribution(
        cls,
        distribution: Distribution,
        name: str,
        validation_rules: List[ValidationRule],
        assessment_name: Optional[str] = None,
    ) -> Distribution:
        """
        Append a distribution with dropped failing rows using SDK Distribution and ValidationRule instances.
        POST /validation/append-dropped-distribution
        Applies validation rules, drops rows that fail, uploads the result, and adds
        a new distribution. QualityMetadata is set for both source and new distribution.
        Returns: Distribution instance populated from the created distribution (populate_from_dto).
        """
        if not distribution.iri:
            raise ValueError("Distribution must have an IRI set")
        cls._ensure_url()
        base = cls._validation_base_url()
        url = f"{base}/{APPEND_DROPPED_DISTRIBUTION_PATH}"
        try:
            body: Dict[str, Any] = {
                "distribution_iri": distribution.iri,
                "name": name,
                "validation_rules": [r.to_dto() for r in validation_rules],
            }
            if assessment_name is not None:
                body["assessment_name"] = assessment_name
            response = requests.post(
                url,
                json=body,
                headers=cls._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
            created = Distribution()
            dto = (
                DistributionDTO.model_validate(data) if isinstance(data, dict) else data
            )
            await created.populate_from_dto(dto)
            return created
        except Exception as e:
            handle_error(e)
