"""
ValidationTemplate SDK class. Mirrors sodas_sdk/lib/SODAS_SDK_CLASS/validation/template.ts.
"""

import json
from typing import Any, ClassVar, Dict, List, Optional, Type, TypeVar, cast

import requests

from sodas_sdk.core.type import PaginatedResponse, SortOrder
from sodas_sdk.core.util import LARGE_ENOUGH_NUMBER, handle_error
from sodas_sdk.sodas_sdk_class.governance_class import (
    GOVERNANCE_MODEL,
    GOVERNANCE_MODEL_DTO,
)
from sodas_sdk.sodas_sdk_class.validation.type import (
    VALIDATION_TYPE,
    AllowedValuesValidationRule,
    CompletenessValidationRule,
    CustomValidationRule,
    DataTypeValidationRule,
    LengthValidationRule,
    OutlierValidationRule,
    PatternValidationRule,
    RangeValidationRule,
    StatisticalValidationRule,
    UniquenessValidationRule,
    ValidationRule,
)

T = TypeVar("T", bound="ValidationTemplate")

PREFIX = "api/v1/governance/template"


class ValidationTemplateDTO(GOVERNANCE_MODEL_DTO):
    name: Optional[str] = None
    description: Optional[str] = None
    validationRules: Optional[List[Dict[str, Any]]] = None


class ValidationTemplate(GOVERNANCE_MODEL):
    _Name: str = ""
    _Description: str = ""
    _ValidationRules: List[ValidationRule] = []

    DTO_CLASS: ClassVar[Type[ValidationTemplateDTO]] = ValidationTemplateDTO

    @classmethod
    def configure_api_url(cls, url: str) -> None:
        base_url = f"{url}/{PREFIX}/validation"
        cls.API_URL = base_url
        cls.LIST_URL = f"{base_url}/list"
        cls.GET_URL = f"{base_url}/get"
        cls.CREATE_URL = f"{base_url}/create"
        cls.UPDATE_URL = f"{base_url}/update"
        cls.DELETE_URL = f"{base_url}/remove"

    def to_dto(self) -> ValidationTemplateDTO:
        base = super().to_dto().model_dump(exclude_none=True)
        rules_dto = [r.to_dto() for r in (self._ValidationRules or [])]
        dto_dict: Dict[str, Any] = {**base}
        if self._Name:
            dto_dict["name"] = self._Name
        if self._Description:
            dto_dict["description"] = self._Description
        # API requires validationRules to be present (even if empty)
        dto_dict["validationRules"] = rules_dto
        return ValidationTemplateDTO(**dto_dict)

    async def populate_from_dto(self, dto: GOVERNANCE_MODEL_DTO) -> None:
        await super().populate_from_dto(dto)
        dto = (
            dto
            if isinstance(dto, ValidationTemplateDTO)
            else ValidationTemplateDTO(**dto.model_dump(exclude_none=True))
        )
        if dto.name is not None:
            self._Name = dto.name
        if dto.description is not None:
            self._Description = dto.description
        if dto.validationRules is not None:
            self._ValidationRules = ValidationTemplate.parse_validation_rules(
                dto.validationRules
            )

    @classmethod
    async def list_db_records(
        cls: Type["ValidationTemplate"],
        page_number: int = 1,
        page_size: int = 10,
        sort_order: SortOrder = SortOrder.DESC,
        *additional_args: Any,
    ) -> PaginatedResponse["ValidationTemplate"]:
        cls.throw_error_if_api_url_not_set()
        name: Optional[str] = additional_args[0] if len(additional_args) > 0 else None
        params: Dict[str, Any] = {
            "offset": (page_number - 1) * page_size,
            "limit": page_size,
            "ordered": sort_order.value,
        }
        if name is not None:
            params["name"] = name
        list_url: str = cast(str, cls.LIST_URL)
        try:
            response = requests.get(
                list_url,
                params=params,
                headers={"Content-Type": "application/json"},
            )
        except Exception as e:
            handle_error(e)
        return await cls.list_response_to_paginated_response(response)

    @classmethod
    async def get_all_db_records(cls) -> List["ValidationTemplate"]:
        cls.throw_error_if_api_url_not_set()
        result = await cls.list_db_records(1, LARGE_ENOUGH_NUMBER)
        return cast(List["ValidationTemplate"], result.list)

    @property
    def name(self) -> str:
        return self._Name

    @name.setter
    def name(self, value: str) -> None:
        self._Name = value

    @property
    def description(self) -> str:
        return self._Description

    @description.setter
    def description(self, value: str) -> None:
        self._Description = value

    @property
    def validation_rules(self) -> List[ValidationRule]:
        return self._ValidationRules or []

    @validation_rules.setter
    def validation_rules(self, value: List[ValidationRule]) -> None:
        self._ValidationRules = value

    @staticmethod
    def parse_validation_rules(raw_rules: Optional[List[Any]]) -> List[ValidationRule]:
        if raw_rules is None:
            return []
        result: List[ValidationRule] = []
        r: ValidationRule
        for rule in raw_rules:
            rtype = (
                getattr(rule, "type", None)
                or (rule.get("type") if isinstance(rule, dict) else None)
            ) or ""
            if rtype == VALIDATION_TYPE.COMPLETENESS.value:
                r = CompletenessValidationRule()
            elif rtype == VALIDATION_TYPE.DATA_TYPE.value:
                r = DataTypeValidationRule()
            elif rtype == VALIDATION_TYPE.PATTERN.value:
                r = PatternValidationRule()
            elif rtype == VALIDATION_TYPE.UNIQUENESS.value:
                r = UniquenessValidationRule()
            elif rtype == VALIDATION_TYPE.RANGE.value:
                r = RangeValidationRule()
            elif rtype == VALIDATION_TYPE.CUSTOM.value:
                r = CustomValidationRule()
            elif rtype == VALIDATION_TYPE.LENGTH.value:
                r = LengthValidationRule()
            elif rtype == VALIDATION_TYPE.ALLOWED_VALUES.value:
                r = AllowedValuesValidationRule()
            elif rtype == VALIDATION_TYPE.OUTLIER.value:
                r = OutlierValidationRule()
            elif rtype == VALIDATION_TYPE.STATISTICAL.value:
                r = StatisticalValidationRule()
            else:
                raise ValueError(f"Invalid validation rule type: {rtype}")
            r.populate_from_dto(rule)
            result.append(r)
        return result

    def _ensure_validation_rules_initialized(self) -> None:
        if self._ValidationRules is None:
            self._ValidationRules = []

    def create_range_rule(self) -> RangeValidationRule:
        self._ensure_validation_rules_initialized()
        r = RangeValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_pattern_rule(self) -> PatternValidationRule:
        self._ensure_validation_rules_initialized()
        r = PatternValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_completeness_rule(self) -> CompletenessValidationRule:
        self._ensure_validation_rules_initialized()
        r = CompletenessValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_data_type_rule(self) -> DataTypeValidationRule:
        self._ensure_validation_rules_initialized()
        r = DataTypeValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_uniqueness_rule(self) -> UniquenessValidationRule:
        self._ensure_validation_rules_initialized()
        r = UniquenessValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_custom_rule(self) -> CustomValidationRule:
        self._ensure_validation_rules_initialized()
        r = CustomValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_length_rule(self) -> LengthValidationRule:
        self._ensure_validation_rules_initialized()
        r = LengthValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_allowed_values_rule(self) -> AllowedValuesValidationRule:
        self._ensure_validation_rules_initialized()
        r = AllowedValuesValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_outlier_rule(self) -> OutlierValidationRule:
        self._ensure_validation_rules_initialized()
        r = OutlierValidationRule()
        self._ValidationRules.append(r)
        return r

    def create_statistical_rule(self) -> StatisticalValidationRule:
        self._ensure_validation_rules_initialized()
        r = StatisticalValidationRule()
        self._ValidationRules.append(r)
        return r

    def get_range_rules(self) -> List[RangeValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[RangeValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.RANGE],
        )

    def get_pattern_rules(self) -> List[PatternValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[PatternValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.PATTERN],
        )

    def get_completeness_rules(self) -> List[CompletenessValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[CompletenessValidationRule],
            [
                r
                for r in self._ValidationRules
                if r.type == VALIDATION_TYPE.COMPLETENESS
            ],
        )

    def get_data_type_rules(self) -> List[DataTypeValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[DataTypeValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.DATA_TYPE],
        )

    def get_uniqueness_rules(self) -> List[UniquenessValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[UniquenessValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.UNIQUENESS],
        )

    def get_custom_rules(self) -> List[CustomValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[CustomValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.CUSTOM],
        )

    def get_length_rules(self) -> List[LengthValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[LengthValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.LENGTH],
        )

    def get_allowed_values_rules(self) -> List[AllowedValuesValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[AllowedValuesValidationRule],
            [
                r
                for r in self._ValidationRules
                if r.type == VALIDATION_TYPE.ALLOWED_VALUES
            ],
        )

    def get_outlier_rules(self) -> List[OutlierValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[OutlierValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.OUTLIER],
        )

    def get_statistical_rules(self) -> List[StatisticalValidationRule]:
        if not self._ValidationRules:
            return []
        return cast(
            List[StatisticalValidationRule],
            [r for r in self._ValidationRules if r.type == VALIDATION_TYPE.STATISTICAL],
        )

    def delete_rule(self, rule: ValidationRule) -> None:
        if not self._ValidationRules:
            return
        if rule in self._ValidationRules:
            self._ValidationRules.remove(rule)

    @staticmethod
    def group_validation_rules_by_type(
        rules: List[ValidationRule],
    ) -> Dict[VALIDATION_TYPE, List[ValidationRule]]:
        acc: Dict[VALIDATION_TYPE, List[ValidationRule]] = {}
        for rule in rules:
            t = rule.type
            if t not in acc:
                acc[t] = []
            acc[t].append(rule)
        return acc

    @staticmethod
    def parse_validation_rules_from_escaped_string(
        escaped_string: str,
    ) -> List[ValidationRule]:
        s = escaped_string.strip()
        if (
            s.startswith('"')
            and s.endswith('"')
            or s.startswith("'")
            and s.endswith("'")
        ) and len(s) > 1:
            s = s[1:-1].strip()
        s = s.replace('\\"', '"')
        try:
            parsed = json.loads(s)
        except json.JSONDecodeError:
            s_trim = s.strip()
            if '"validation_rules"' in s_trim or s_trim.startswith("validation_rules"):
                wrapped = (
                    "{" + s_trim + "}"
                    if not s_trim.startswith('"')
                    else "{" + s_trim + "}"
                )
                try:
                    parsed = json.loads(wrapped)
                except json.JSONDecodeError:
                    parsed = json.loads('{"' + s_trim.replace('"', "", 1) + "}")
            elif s_trim.startswith("{") and s_trim.endswith("}"):
                parsed = json.loads(s_trim)
            else:
                raise ValueError("Invalid format: could not parse JSON")
        if isinstance(parsed, list):
            validation_rules: Any = parsed
        elif isinstance(parsed, dict) and "validation_rules" in parsed:
            validation_rules = parsed["validation_rules"]
        elif isinstance(parsed, dict):
            validation_rules = parsed  # Will fail isinstance(..., list) below
        else:
            raise ValueError("Invalid format: validation_rules not found")
        if not isinstance(validation_rules, list):
            raise ValueError("Invalid format: validation_rules must be an array")
        return ValidationTemplate.parse_validation_rules(validation_rules)

    @staticmethod
    def stringify_validation_rules_to_escaped_string(
        rules: List[ValidationRule],
    ) -> str:
        plain = [r.to_dto() for r in rules]
        obj = {"validation_rules": plain}
        json_str = json.dumps(obj)
        escaped = json_str.replace('"', '\\"')
        return '"' + escaped + '"'

    _COMPARISON_TO_CUSTOM: ClassVar[Dict[str, str]] = {
        "==": "eq",
        "!=": "ne",
        ">": "gt",
        "<": "lt",
        ">=": "gte",
        "<=": "lte",
    }
