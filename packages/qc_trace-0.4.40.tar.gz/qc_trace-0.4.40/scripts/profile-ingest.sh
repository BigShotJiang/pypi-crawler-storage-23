#!/usr/bin/env bash
# profile-ingest.sh — Real-time profiling of data flowing into qc-trace
#
# Polls the server API + Postgres every 2 seconds and shows:
# - Sessions, messages, tokens counts
# - Messages per source
# - Ingestion rate (messages/sec)
# - Daemon state file stats
#
# Usage: ./scripts/profile-ingest.sh

set -euo pipefail

DSN="postgresql://qc_trace:qc_trace_dev@localhost:5432/qc_trace"
SERVER_URL="${QC_TRACE_SERVER:-http://localhost:19777}"
POLL_INTERVAL=2
DAEMON_STATE="$HOME/.quickcall-trace/state.json"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

prev_messages=0
prev_time=$(date +%s)

clear_line() {
    printf '\033[2K'
}

while true; do
    clear

    now=$(date +%s)
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    echo -e "${BOLD}╔══════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BOLD}║  qc-trace Ingest Profiler          ${DIM}${timestamp}${RESET}${BOLD}  ║${RESET}"
    echo -e "${BOLD}╚══════════════════════════════════════════════════════════════╝${RESET}"
    echo ""

    # ── Server health ──
    health=$(curl -s --connect-timeout 2 "${SERVER_URL}/health" 2>/dev/null || echo '{"status":"unreachable"}')
    server_status=$(echo "$health" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','?'))" 2>/dev/null || echo "unreachable")
    db_status=$(echo "$health" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('db','?'))" 2>/dev/null || echo "?")

    if [ "$server_status" = "ok" ]; then
        echo -e "  ${GREEN}●${RESET} Server: ${GREEN}${server_status}${RESET}  |  DB: ${GREEN}${db_status}${RESET}"
    else
        echo -e "  ${RED}●${RESET} Server: ${RED}${server_status}${RESET}  |  DB: ${RED}${db_status}${RESET}"
    fi
    echo ""

    # ── Database counts (direct Postgres query) ──
    db_stats=$(docker exec qc_trace_postgres psql -U qc_trace -d qc_trace -t -A -F'|' -c "
        SELECT
            (SELECT count(*) FROM sessions) AS sessions,
            (SELECT count(*) FROM messages) AS messages,
            (SELECT count(*) FROM token_usage) AS token_rows,
            (SELECT count(*) FROM tool_calls) AS tool_calls,
            (SELECT count(*) FROM tool_results) AS tool_results
    " 2>/dev/null || echo "0|0|0|0|0")

    IFS='|' read -r sessions messages token_rows tool_calls tool_results <<< "$db_stats"

    echo -e "  ${BOLD}DATABASE COUNTS${RESET}"
    echo -e "  ┌────────────────┬──────────┐"
    printf "  │ %-14s │ %8s │\n" "Sessions" "$sessions"
    printf "  │ %-14s │ %8s │\n" "Messages" "$messages"
    printf "  │ %-14s │ %8s │\n" "Token rows" "$token_rows"
    printf "  │ %-14s │ %8s │\n" "Tool calls" "$tool_calls"
    printf "  │ %-14s │ %8s │\n" "Tool results" "$tool_results"
    echo -e "  └────────────────┴──────────┘"
    echo ""

    # ── Messages by source ──
    by_source=$(docker exec qc_trace_postgres psql -U qc_trace -d qc_trace -t -A -F'|' -c "
        SELECT source, count(*) FROM messages GROUP BY source ORDER BY count(*) DESC
    " 2>/dev/null || echo "")

    echo -e "  ${BOLD}BY SOURCE${RESET}"
    if [ -n "$by_source" ]; then
        echo -e "  ┌──────────────────┬──────────┐"
        while IFS='|' read -r src cnt; do
            case "$src" in
                claude_code) color="${CYAN}" ;;
                codex_cli)   color="${YELLOW}" ;;
                gemini_cli)  color="${GREEN}" ;;
                cursor)      color="${RED}" ;;
                *)           color="${RESET}" ;;
            esac
            printf "  │ ${color}%-16s${RESET} │ %8s │\n" "$src" "$cnt"
        done <<< "$by_source"
        echo -e "  └──────────────────┴──────────┘"
    else
        echo -e "  ${DIM}(no data yet)${RESET}"
    fi
    echo ""

    # ── Messages by type ──
    by_type=$(docker exec qc_trace_postgres psql -U qc_trace -d qc_trace -t -A -F'|' -c "
        SELECT msg_type, count(*) FROM messages GROUP BY msg_type ORDER BY count(*) DESC
    " 2>/dev/null || echo "")

    echo -e "  ${BOLD}BY MESSAGE TYPE${RESET}"
    if [ -n "$by_type" ]; then
        echo -e "  ┌──────────────────┬──────────┐"
        while IFS='|' read -r mtype cnt; do
            printf "  │ %-16s │ %8s │\n" "$mtype" "$cnt"
        done <<< "$by_type"
        echo -e "  └──────────────────┴──────────┘"
    else
        echo -e "  ${DIM}(no data yet)${RESET}"
    fi
    echo ""

    # ── Token totals ──
    token_totals=$(docker exec qc_trace_postgres psql -U qc_trace -d qc_trace -t -A -F'|' -c "
        SELECT
            coalesce(sum(input_tokens),0),
            coalesce(sum(output_tokens),0),
            coalesce(sum(cached_tokens),0),
            coalesce(sum(thinking_tokens),0)
        FROM token_usage
    " 2>/dev/null || echo "0|0|0|0")

    IFS='|' read -r t_input t_output t_cached t_thinking <<< "$token_totals"

    echo -e "  ${BOLD}TOKEN TOTALS${RESET}"
    echo -e "  ┌────────────────┬──────────────┐"
    printf "  │ %-14s │ %12s │\n" "Input" "$t_input"
    printf "  │ %-14s │ %12s │\n" "Output" "$t_output"
    printf "  │ %-14s │ %12s │\n" "Cached" "$t_cached"
    printf "  │ %-14s │ %12s │\n" "Thinking" "$t_thinking"
    echo -e "  └────────────────┴──────────────┘"
    echo ""

    # ── Ingestion rate ──
    elapsed=$((now - prev_time))
    if [ "$elapsed" -gt 0 ] && [ "$prev_messages" -gt 0 ]; then
        delta=$((messages - prev_messages))
        rate=$(python3 -c "print(f'{${delta}/${elapsed}:.1f}')" 2>/dev/null || echo "?")
        echo -e "  ${BOLD}RATE${RESET}: ${GREEN}+${delta}${RESET} messages in ${elapsed}s (${CYAN}${rate} msg/s${RESET})"
    elif [ "$messages" -gt 0 ]; then
        echo -e "  ${BOLD}RATE${RESET}: measuring..."
    else
        echo -e "  ${BOLD}RATE${RESET}: ${DIM}waiting for data...${RESET}"
    fi
    echo ""

    # ── Daemon state ──
    echo -e "  ${BOLD}DAEMON STATE${RESET}"
    if [ -f "$DAEMON_STATE" ]; then
        file_count=$(python3 -c "import json; d=json.load(open('$DAEMON_STATE')); print(len(d.get('files',{})))" 2>/dev/null || echo "?")
        total_lines=$(python3 -c "
import json
d=json.load(open('$DAEMON_STATE'))
total=sum(f.get('last_line_processed',0) for f in d.get('files',{}).values())
print(total)
" 2>/dev/null || echo "?")
        echo -e "  Files tracked: ${file_count}  |  Total lines processed: ${total_lines}"
    else
        echo -e "  ${DIM}(no state file yet)${RESET}"
    fi

    # ── Recent activity (last 5 ingested messages) ──
    echo ""
    echo -e "  ${BOLD}LATEST INGESTED${RESET}"
    recent=$(docker exec qc_trace_postgres psql -U qc_trace -d qc_trace -t -A -F'|' -c "
        SELECT source, msg_type, left(coalesce(content,'(no content)'), 50), ingested_at
        FROM messages ORDER BY ingested_at DESC LIMIT 5
    " 2>/dev/null || echo "")

    if [ -n "$recent" ]; then
        echo -e "  ┌──────────────┬────────────┬──────────────────────────────────────────────────────┐"
        while IFS='|' read -r src mtype preview ts; do
            short_ts=$(echo "$ts" | cut -c12-19)
            printf "  │ %-12s │ %-10s │ %-52s │\n" "$src" "$mtype" "${preview:0:52}"
        done <<< "$recent"
        echo -e "  └──────────────┴────────────┴──────────────────────────────────────────────────────┘"
    else
        echo -e "  ${DIM}(no messages yet)${RESET}"
    fi

    prev_messages=$messages
    prev_time=$now

    sleep "$POLL_INTERVAL"
done
