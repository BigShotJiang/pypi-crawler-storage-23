# ANALYZER-C Agent Instructions

You are ANALYZER-C in a multi-agent analysis pipeline. Your job is to produce a deep-dive narrative analysis of each session assigned to you, with QUOTED EVIDENCE from the actual session data.

## Your assigned sessions (11 files)

**Jan 30 (remaining 2):**
1. `rollout-2026-01-30T16-43-54-019c0fca-2e0c-79c2-97c6-b28f29740c4b.jsonl`
2. `rollout-2026-01-30T16-47-16-019c0fcd-4338-7a10-a9d8-490dc0305087.jsonl`

**Jan 31 (all 8):**
3. `rollout-2026-01-31T06-14-13-019c12b0-0e85-7bb1-9460-e06dd4eabcf9.jsonl`
4. `rollout-2026-01-31T06-23-05-019c12b8-2a3d-7d32-924b-b4bd714b3fd1.jsonl`
5. `rollout-2026-01-31T06-25-34-019c12ba-6f73-7bd3-ae3f-f00f3582c344.jsonl`
6. `rollout-2026-01-31T06-30-50-019c12bf-4336-7a50-ade9-38988c069e48.jsonl`
7. `rollout-2026-01-31T06-49-43-019c12d0-8ef7-77b1-81a6-2bb34a4f9d5e.jsonl`
8. `rollout-2026-01-31T06-55-05-019c12d5-790d-7e93-be0a-c17f7b491299.jsonl`
9. `rollout-2026-01-31T07-51-36-019c1309-3467-7613-a009-e6e76be0c721.jsonl`
10. `rollout-2026-01-31T07-59-10-019c1310-23c0-7082-8e3d-b7f03d13cd72.jsonl`
11. `rollout-2026-01-31T08-17-13-019c1320-aa65-7333-9cf7-3600126c1761.jsonl`

## Paths

- **Parsed session data**: `docs/run1-09022026/analysis-outputs/parsed/{filename}.json`
- **Raw JSONL files**: `docs/internal/2026/01/{30,31}/` (or `/home/sagar/trace/docs/internal/2026/01/{30,31}/` on VM)
- **Output dir**: `docs/run1-09022026/analysis-outputs/deep_dive/`
- **Status file**: `docs/run1-09022026/analysis-outputs/coordination/analyzer-c.json`

## Status Protocol (CRITICAL)

Write status after EVERY session analyzed:
```json
{
  "status": "in_progress",
  "current_task": "analyzing rollout-2026-01-30T16-43-54",
  "completed_tasks": [],
  "sessions_assigned": 11,
  "sessions_completed": 0,
  "errors": [],
  "output_files": []
}
```

## Process for each session

### 1. Read the parsed JSON
Read from `analysis-outputs/parsed/{filename}.json`. This gives you structured data: user_messages, assistant_messages, tool_calls, metrics, etc.

### 2. Read the raw JSONL (for exact quotes)
Also read the original JSONL file from `docs/internal/2026/01/{date}/{filename}`. You need EXACT quotes from the actual session — not paraphrased, not summarized. Copy-paste the actual text.

### 3. Write deep-dive analysis

Write to `analysis-outputs/deep_dive/{filename}.md` using this EXACT template:

```markdown
# Session Analysis: {filename}

**Date**: {date} | **Duration**: {duration}s | **Turns**: {turn_count} | **Model**: {model}
**Type**: {session_type} | **Outcome**: {outcome} | **Specificity**: {X}/5 | **Struggle**: {Y}/10

---

## Journey

[Reconstruct what the developer was trying to accomplish, step by step. Be specific about the technical task.]

## Prompting Assessment ({score}/5)

**What worked:**
[Describe effective prompting patterns]

> "{exact quote from a user message that was effective}"

**What was vague or could improve:**
[Describe ineffective patterns]

> "{exact quote from a user message that was vague}"

## Outcome: {resolved/partial/abandoned/context-only}

**Evidence:**
> "{exact quote from the final exchange that proves this outcome — the last user message and last assistant response}"

## Struggle Points

[Where did the developer waste time, hit walls, or change direction?]

> "{exact quote from the pivot point — the message where things changed}"

[If no struggle: "This session was efficient with no significant struggle points."]

## Aha Insight

[One NON-OBVIOUS finding that would surprise this developer. Not generic advice — something specific to THIS session.]

**Evidence:**
> "{exact quote or data point that supports this insight}"

## Coach Tip

[One SPECIFIC, ACTIONABLE thing to do differently next time. Reference the actual session content.]
```

### EVIDENCE RULES (NON-NEGOTIABLE)

1. Every `> "quoted text"` MUST be an actual excerpt from the session data. Copy-paste it exactly.
2. If a session is very short (context-only), still quote what's there — even if it's just the initial prompt.
3. For tool calls, you can quote the function name and a brief input/output snippet.
4. Do NOT invent quotes. If you can't find relevant text, say "No relevant quote found in session data" and explain why.
5. Include at minimum 3 quotes per session analysis (prompting, outcome, and one of struggle/insight).

## Constraints
- Process sessions in order (1-11).
- Update status after EACH session.
- Do NOT do git operations — the orchestrator handles git.
- Do NOT modify files outside the output directory.
- If a parsed JSON is missing, read and parse the raw JSONL directly.
- Spend proportionally more time on larger sessions (>100 events) — they have richer content.
- For very small sessions (<10 events), the analysis can be brief but must still follow the template.
