# Agent Observations: Session Context Run (07-02-2026)

## Issue: Agents Did Not Use QuickCall MCP for GitHub Issue Comments

### What Happened

All 3 agents were instructed (via CLAUDE.md) to comment on their GitHub issues at milestones. The CLAUDE.md files originally used `gh` CLI examples. After discovering `gh` was not authenticated, we sent a message to all agents telling them to use QuickCall MCP tools instead. Despite this, none of the agents used the MCP tools for GitHub operations.

### Agent-by-Agent Behavior

#### Track A (#46) — Schema + DB Pipeline
- **Attempted:** `gh` CLI first → failed (not authenticated)
- **Fallback:** Read `.quickcall.env`, extracted `GITHUB_TOKEN`, used `curl` + raw GitHub REST API to post comments
- **Issues:** `jq` not installed, multiple JSON parsing errors before getting it to work
- **Result:** Comments posted via raw API, NOT via QuickCall MCP

#### Track B (#47) — Repo Resolver
- **Attempted:** `gh` CLI first → failed (not authenticated)
- **Fallback:** `source .quickcall.env` → failed (token escaping issues), then `export $(cat .quickcall.env | xargs)` + Python `urllib.request` directly against GitHub API
- **Result:** Comments posted via raw `urllib`, NOT via QuickCall MCP
- **Note:** Posted duplicate "In Progress" and "Completed" comments (4 total, 2 were dupes)

#### Track C (#48) — Collector Wiring
- **Attempted:** Looked for MCP tools, couldn't figure out how to use them
- **Result:** Did NOT post any comments. Noted "I could not post GitHub issue comments because gh CLI is not authenticated and I don't have access to QuickCall MCP tools in this session."

### Root Cause Analysis

1. **CLAUDE.md examples used `gh` CLI syntax** — The mandatory reporting section showed `gh issue comment` examples. Agents treated these as the primary method and only looked for alternatives after `gh` failed.

2. **MCP tools not surfaced in agent context** — Worktree-launched Claude Code agents may not inherit MCP server configuration from the parent directory. The QuickCall MCP tools (`manage_issues`, `manage_prs`, etc.) were available to the orchestrator but not necessarily to the sub-agents.

3. **No explicit MCP tool names in CLAUDE.md** — The correction message said "use QuickCall MCP tools" but didn't name the specific tool (`manage_issues`) or show the exact invocation syntax. Agents didn't know the tool API.

4. **Fallback to raw API hacking** — Track A and B improvised with `curl`/`urllib` + `GITHUB_TOKEN` from `.quickcall.env`. This worked but is fragile and not the intended workflow.

### Recommendations for Future Runs

1. **Don't use `gh` examples in CLAUDE.md** — Replace all `gh issue comment` examples with explicit MCP tool invocations or Python scripts that use the GitHub API properly.

2. **Verify MCP availability in worktrees** — Before launching agents, confirm that MCP servers are accessible from worktree directories. The MCP config may need to be copied or symlinked.

3. **Provide exact tool signatures** — Instead of "use QuickCall MCP tools", provide the exact function call:
   ```
   Use the manage_issues MCP tool:
   - action: "comment"
   - owner: "quickcall-dev"
   - repo: "trace"
   - issue_numbers: [YOUR_ISSUE_NUMBER]
   - body: "your comment text"
   ```

4. **Copy `.quickcall.env` to worktrees preemptively** — Don't wait for agents to discover the auth problem. Copy the env file during setup.

5. **Test one agent's reporting flow before launching all** — Do a dry run: launch one agent, have it post a single comment, verify it works, then launch the rest.

### Duplicate Comment Issue (Track B)

Track B posted 4 comments (2 pairs of duplicates):
- 2x "Status: In Progress" (posted 5 seconds apart)
- 2x "Status: Completed" (posted 18 seconds apart)

Likely cause: the agent retried after uncertain success on the first attempt (no proper response parsing from raw API calls).

### Summary

| Agent | Method Used | MCP Used? | Comments Posted? |
|-------|-----------|-----------|-----------------|
| Track A | curl + GitHub REST API | No | Yes (via raw API) |
| Track B | Python urllib + GitHub REST API | No | Yes (with duplicates) |
| Track C | None (gave up) | No | No |
