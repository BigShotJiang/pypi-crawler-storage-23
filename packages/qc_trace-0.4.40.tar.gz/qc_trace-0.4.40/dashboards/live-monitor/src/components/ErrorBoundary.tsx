import { Component, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
          <h1 className="text-2xl font-bold text-danger">Something went wrong</h1>
          <p className="text-text-secondary text-sm max-w-md text-center">
            {this.state.error.message}
          </p>
          <button
            onClick={() => this.setState({ error: null })}
            className="text-accent hover:text-accent-hover text-sm"
          >
            Try again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
