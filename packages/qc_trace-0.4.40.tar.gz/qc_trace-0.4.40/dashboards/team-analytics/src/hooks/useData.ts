import { useEffect, useState } from "react";
import type { AllData } from "../types/data";

export function useData() {
  const [data, setData] = useState<AllData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/data/all.json")
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(setData)
      .catch((e) => setError(e.message));
  }, []);

  return { data, error, loading: !data && !error };
}
