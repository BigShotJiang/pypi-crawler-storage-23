# Release to production

Automate the full release pipeline for qc-trace. Follows `docs/deployment-guide.md`.

## Input

The user may provide a version like `/release 0.4.18` or a bump type like `/release patch`.
If no argument: read current version from `qc_trace/__init__.py`, bump the patch number, and confirm with the user before proceeding.

## Steps

### 1. Determine version

- Read current version from `qc_trace/__init__.py` (`__version__`)
- If user provided an explicit version (e.g., `0.4.18`), use that
- If user said `patch`/`minor`/`major`, bump accordingly
- If no argument, bump patch and ask user to confirm

### 2. Run tests

```bash
uv run pytest tests/ -q
```

**STOP if tests fail.** Do not proceed with a broken release.

### 3. Bump version in BOTH places

These MUST match. If they don't, the daemon auto-update will loop.

- `qc_trace/__init__.py`: `__version__ = "X.Y.Z"`
- `pyproject.toml`: `version = "X.Y.Z"`

Use the Edit tool to update both files.

### 4. Commit and tag

```bash
git add qc_trace/__init__.py pyproject.toml
git commit -m "chore: bump version to X.Y.Z"
git tag vX.Y.Z
```

### 5. Push (triggers CI)

```bash
git push && git push --tags
```

This triggers:
- `release.yml`: test -> GitHub Release -> PyPI publish
- `deploy.yml`: Docker build -> ACR -> Azure Container Apps

### 6. Remind about DB update

After pushing, print this reminder:

```
Release vX.Y.Z pushed. CI is running:
  https://github.com/quickcall-dev/trace/actions

After CI completes, update the database to trigger daemon auto-updates:

  INSERT INTO version_config (key, value)
  VALUES ('latest_version', 'X.Y.Z')
  ON CONFLICT (key) DO UPDATE SET value = 'X.Y.Z';

Verify:
  curl -s https://trace.quickcall.dev/api/latest-version
  curl -s https://trace.quickcall.dev/health
```

## Important

- NEVER skip the test step
- NEVER push if tests fail
- ALWAYS bump BOTH version files
- Ask user for confirmation before `git push`
