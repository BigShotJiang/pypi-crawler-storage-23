"""quickcall: Silent daemon that watches coding agent sessions and pushes to ingest server."""

from qc_trace.daemon.config import DaemonConfig

__all__ = ["DaemonConfig"]
