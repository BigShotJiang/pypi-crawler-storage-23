let DATA = null;
const msgCache = {};

export function getData() { return DATA; }
export function getMsgCache() { return msgCache; }

export async function loadIndex() {
  const res = await fetch('/data/index.json');
  DATA = await res.json();
  return DATA;
}

export async function loadSessionMessages(sessionId) {
  if (msgCache[sessionId]) return msgCache[sessionId];
  const res = await fetch(`/data/sessions/${sessionId}.json`);
  if (!res.ok) return [];
  const msgs = await res.json();
  msgCache[sessionId] = msgs;
  return msgs;
}
