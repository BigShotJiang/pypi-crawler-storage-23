# Ridds Calculator

A simple, lightweight calculator library for Python with basic mathematical operations.

## Features

- Addition
- Subtraction
- Multiplication
- Division (with zero-division protection)
- Power/Exponentiation

## Installation

```bash
pip install riddscal
```

## Usage

```python
from riddscal.calculator import add, subtract, multiply, divide, power

# Addition
result = add(5, 3)  # Returns 8

# Subtraction
result = subtract(10, 4)  # Returns 6

# Multiplication
result = multiply(6, 7)  # Returns 42

# Division
result = divide(20, 4)  # Returns 5.0

# Power
result = power(2, 3)  # Returns 8
```

## Error Handling

The `divide()` function raises a `ValueError` if you attempt to divide by zero:

```python
from riddscal.calculator import divide

try:
    result = divide(10, 0)
except ValueError as e:
    print(f"Error: {e}")  # Error: Division by zero
```

## Requirements

- Python 3.7 or higher

## License

MIT License

## Author

Your Name (your.email@example.com)

## Contributing

Contributions are welcome! Please feel free to submit a pull request.

## Changelog

### Version 0.1.0
- Initial release with basic calculator functions
