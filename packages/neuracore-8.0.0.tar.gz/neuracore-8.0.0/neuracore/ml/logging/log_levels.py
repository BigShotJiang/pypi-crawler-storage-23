"""Shared logging severity constants."""

LOG_SEVERITY_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
