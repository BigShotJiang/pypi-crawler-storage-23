"""CLI utilities for neuracore ML functionality."""
