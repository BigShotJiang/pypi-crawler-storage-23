"""Neuracore Data Damon to manage data recording and uploading locally."""

from neuracore.data_daemon.main import main

if __name__ == "__main__":
    main()
