"""Init."""

__version__ = "0.1.0"  # Source of truth for versioning
