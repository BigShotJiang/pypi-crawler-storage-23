"""git-diff -- Beautiful git viewer in your browser. Like GitHub, but local."""

__version__ = "0.1.0"
__author__ = "Ankit Chaubey"
__email__ = "ankitchaubey.dev@gmail.com"
__url__ = "https://github.com/ankit-chaubey/git-diff"
