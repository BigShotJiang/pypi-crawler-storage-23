##################
ctrl_platform_s3df
##################

This package contains S3DF (SLAC) platform configuration and template files for `lsst.ctrl.execute`.
