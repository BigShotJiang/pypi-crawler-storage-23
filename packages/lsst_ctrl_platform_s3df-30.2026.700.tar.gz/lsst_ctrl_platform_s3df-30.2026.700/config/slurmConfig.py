# flake8: noqa
config.platform.queue = "$QUEUE"
config.platform.scratchDirectory = "$USER_SCRATCH/condor_scratch"
config.platform.loginHostName = "sdfiana012.sdf.slac.stanford.edu"
config.platform.utilityPath = "/usr/sbin/"
