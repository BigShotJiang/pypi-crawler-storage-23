from ._base import OptimizationStrategy
