from ._problem import MaxDivProblem
