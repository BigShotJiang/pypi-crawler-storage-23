from ._fast_exp import fast_exp2_f32, fast_exp2_f64, fast_exp_f32, fast_exp_f64
from ._fast_log import fast_log2_f32, fast_log2_f64, fast_log_f32, fast_log_f64
