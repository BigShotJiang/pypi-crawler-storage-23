"""Version information for theow."""

__version__ = "0.0.12"  # x-release-please-version
