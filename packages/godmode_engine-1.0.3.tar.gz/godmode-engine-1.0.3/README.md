# 神级引擎 (GodMode Engine)

GodMode 是一个专为 AI 一句话生成游戏（单提示词编程）所打造的极致 2D 游戏开发底座框架。
它被设计为拥有 3A 级别的商业级表现力，提供绝度纯粹的果汁感（Juicy）和完美的 UX 操作体验。

## 核心特性 (Features)
- 📱 **黄金比例自适应**: 锁定 422x750 (9:16) 竖屏显示，附带 Letterbox 等比黑边自适应缩放机制，支持自由拉伸窗口不糊不崩。
- ⚡ **电竞级操作手感**: 告别常规轮询死板延迟，底层级引入 DAS (延时自动重按) 和 ARR (自动连发率) 以及覆盖插断逻辑，移动丝滑如冰面。
- 🗼 **无尽通天塔系统**: 告别单局，自带 RPG 级无境关卡跃迁与长宽自动膨胀（难度根据层数无缝扩展）。
- 🖨️ **护眼系统交互**: 游玩中按 `Ctrl+P` 即可极速后台剥离光效，生成并直接唤起系统看图器弹射出 **白底黑线** 护眼打印级图纸。
- 🇨🇳 **原生中文护航**: 彻底拒绝机翻与方块乱码，全局系统提示与 Toast 弹窗全面采用本地微软雅黑/黑体字库，中文体验拉满。

## 安装指南 (Installation)

```bash
pip install godmode-engine
```

## 极速起飞 (Quick Start)

只需要短短的十几行代码（甚至可以让 AI 来替你生成），你就可以直接拉起一款具有光污染和粒子特效的完全体游戏：

```python
import godmode

# 1. 唤醒神级引擎内置框架：随心所欲注入赛博朋克深红滤镜（bg_color, wall_color 等任意修改即换肤！）
app = godmode.GodEngine(
    title="AI Generated Power - Neon Labyrinth", 
    width=422, height=750,
    bg_color=(15, 0, 0),         # 深渊红背景
    wall_color=(60, 10, 20),     # 鲜血墙壁
    ground_color=(20, 0, 5),     # 暗泥地
    exit_color=(255, 200, 0)     # 黄金终点
)

# 2. 注入自适应完美迷宫算法：抛弃单调路线，生成绝对唯一路径且带海量分支欺骗网格
app.set_world(godmode.algorithms.ProceduralMaze(complexity="adaptive"))

# 3. 部署主角：开启极致平滑插值(Juicy Movement)、碰撞震屏、拖尾果汁感特效
app.bind_player(godmode.entities.NeonPlayer(glow_color=(0, 255, 200), juice_level="MAX"))

# 4. 点燃宇宙引擎
if __name__ == "__main__":
    app.ignite()
```
