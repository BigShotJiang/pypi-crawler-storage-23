import pygame
import random

class Camera:
    def __init__(self):
        self.offset_x, self.offset_y = 0, 0
        self.shake_intensity = 0

    def add_shake(self, val):
        self.shake_intensity = min(self.shake_intensity + val, 30)

    def update(self, dt, target_x, target_y):
        # Lerp 摄像机跟随
        self.offset_x += (target_x - self.offset_x) * 10 * dt
        self.offset_y += (target_y - self.offset_y) * 10 * dt
        # 震屏计算
        if self.shake_intensity > 0:
            rx = random.uniform(-self.shake_intensity, self.shake_intensity)
            ry = random.uniform(-self.shake_intensity, self.shake_intensity)
            # 在返回画面偏移时做叠加，但不影响基准点
            self.shake_intensity = max(0, self.shake_intensity - dt * 60)
            return self.offset_x + rx, self.offset_y + ry
        return self.offset_x, self.offset_y

class Particle:
    def __init__(self, x, y, color, size, life):
        self.x, self.y = x, y
        self.vx = random.uniform(-100, 100)
        self.vy = random.uniform(-100, 100)
        self.max_life = life
        self.life = life
        self.color = color
        self.size = size

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt

    def draw(self, surface, cx, cy):
        if self.life > 0:
            alpha = int((self.life / self.max_life) * 255)
            s = max(1, int(self.size * (self.life / self.max_life)))
            temp = pygame.Surface((s * 2, s * 2), pygame.SRCALPHA)
            pygame.draw.circle(temp, (*self.color, alpha), (s, s), s)
            surface.blit(temp, (int(self.x - cx - s), int(self.y - cy - s)), special_flags=pygame.BLEND_RGB_ADD)

class ParticleSystem:
    def __init__(self):
        self.particles = []

    def emit(self, x, y, color, count=5, size=6, life=0.4):
        for _ in range(count):
            self.particles.append(Particle(x, y, color, random.uniform(2, size), random.uniform(0.1, life)))

    def update(self, dt):
        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.life > 0]

    def draw(self, surface, cx, cy):
        for p in self.particles:
            p.draw(surface, cx, cy)
