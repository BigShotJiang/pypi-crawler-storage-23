use std::collections::BTreeMap;
use std::path::PathBuf;

use halimede::{FieldType, Network};
use serde::Serialize;

#[derive(Serialize)]
struct Manifest {
    header: ManifestHeader,
    node_schema: Vec<ManifestField>,
    link_schema: Vec<ManifestField>,
    nodes: ManifestNodes,
    links: ManifestLinks,
    speed_table: ManifestLookup,
    capacity_table: ManifestLookup,
}

#[derive(Serialize)]
struct ManifestHeader {
    banner: String,
    run_id: String,
    zones: u32,
    max_node_id: u32,
    link_count: u32,
    node_rec_count: u32,
    left_drive: bool,
}

#[derive(Serialize)]
struct ManifestField {
    name: String,
    #[serde(rename = "type")]
    field_type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    max_size: Option<u16>,
}

#[derive(Serialize)]
struct ManifestNodes {
    ids: Vec<i32>,
    columns: BTreeMap<String, serde_json::Value>,
}

#[derive(Serialize)]
struct ManifestLinks {
    a: Vec<i32>,
    b: Vec<i32>,
    columns: BTreeMap<String, serde_json::Value>,
}

#[derive(Serialize)]
struct ManifestLookup {
    is_default: bool,
}

fn golden_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("fixtures/golden")
}

fn field_to_manifest(field: &halimede::FieldDef) -> ManifestField {
    match field.field_type() {
        FieldType::Numeric => ManifestField {
            name: field.name().to_string(),
            field_type: "numeric".to_string(),
            max_size: None,
        },
        FieldType::String { max_size } => ManifestField {
            name: field.name().to_string(),
            field_type: "string".to_string(),
            max_size: Some(*max_size),
        },
    }
}

fn main() {
    let dir = golden_dir();
    let mut entries: Vec<_> = std::fs::read_dir(&dir)
        .unwrap_or_else(|e| panic!("cannot read {}: {}", dir.display(), e))
        .filter_map(|e| e.ok())
        .filter(|e| e.path().extension().is_some_and(|ext| ext == "net"))
        .collect();
    entries.sort_by_key(|e| e.file_name());

    for entry in &entries {
        let net_path = entry.path();
        let stem = net_path.file_stem().unwrap().to_str().unwrap();
        let bytes = std::fs::read(&net_path).unwrap();
        let net = Network::from_bytes(&bytes).unwrap_or_else(|e| panic!("{}: {}", stem, e));

        let node_schema: Vec<ManifestField> = net
            .nodes()
            .schema()
            .fields()
            .iter()
            .map(field_to_manifest)
            .collect();

        let link_schema: Vec<ManifestField> = net
            .links()
            .schema()
            .fields()
            .iter()
            .map(field_to_manifest)
            .collect();

        let mut node_columns = BTreeMap::new();
        for field in net.nodes().schema().fields() {
            match field.field_type() {
                FieldType::Numeric => {
                    let values = net.nodes().column_f64(field.name()).unwrap();
                    let json_values: Vec<serde_json::Value> =
                        values.iter().map(|&v| serde_json::Value::from(v)).collect();
                    node_columns.insert(
                        field.name().to_string(),
                        serde_json::Value::Array(json_values),
                    );
                }
                FieldType::String { .. } => {
                    let values = net.nodes().column_str(field.name()).unwrap();
                    let json_values: Vec<serde_json::Value> = values
                        .iter()
                        .map(|v| serde_json::Value::String(v.clone()))
                        .collect();
                    node_columns.insert(
                        field.name().to_string(),
                        serde_json::Value::Array(json_values),
                    );
                }
            }
        }

        let mut link_columns = BTreeMap::new();
        for field in net.links().schema().fields() {
            match field.field_type() {
                FieldType::Numeric => {
                    let values = net.links().column_f64(field.name()).unwrap();
                    let json_values: Vec<serde_json::Value> =
                        values.iter().map(|&v| serde_json::Value::from(v)).collect();
                    link_columns.insert(
                        field.name().to_string(),
                        serde_json::Value::Array(json_values),
                    );
                }
                FieldType::String { .. } => {
                    let values = net.links().column_str(field.name()).unwrap();
                    let json_values: Vec<serde_json::Value> = values
                        .iter()
                        .map(|v| serde_json::Value::String(v.clone()))
                        .collect();
                    link_columns.insert(
                        field.name().to_string(),
                        serde_json::Value::Array(json_values),
                    );
                }
            }
        }

        let manifest = Manifest {
            header: ManifestHeader {
                banner: net.header().banner().to_string(),
                run_id: net.header().run_id().to_string(),
                zones: net.header().zones(),
                max_node_id: net.header().max_node_id(),
                link_count: net.header().link_count(),
                node_rec_count: net.header().node_rec_count(),
                left_drive: net.header().left_drive(),
            },
            node_schema,
            link_schema,
            nodes: ManifestNodes {
                ids: net.nodes().ids().to_vec(),
                columns: node_columns,
            },
            links: ManifestLinks {
                a: net.links().a().to_vec(),
                b: net.links().b().to_vec(),
                columns: link_columns,
            },
            speed_table: ManifestLookup {
                is_default: net.speed_table().is_default_speed(),
            },
            capacity_table: ManifestLookup {
                is_default: net.capacity_table().is_default_capacity(),
            },
        };

        let json_path = dir.join(format!("{}.expected.json", stem));
        let json = serde_json::to_string_pretty(&manifest).unwrap();
        std::fs::write(&json_path, format!("{}\n", json)).unwrap();
        println!("wrote {}", json_path.display());
    }

    println!("generated {} manifests", entries.len());
}
