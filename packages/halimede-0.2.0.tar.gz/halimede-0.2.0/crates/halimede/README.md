# halimede

Read and write `.net` binary network files.

`.net` files store directed graphs used in transport modelling. Each file
contains intersections as nodes and road segments as directed links, with
arbitrary numeric and string attributes per record plus embedded speed and
capacity lookup tables.

## Overview

- Parses and writes the binary `.net` network format.
- In-memory columnar API centred on `Network`, `NodeTable`, and `LinkTable`.
- Schema-only inspection with `NetworkInfo`, plus field-selective loading.
- All numeric values presented as `f64` regardless of on-disk encoding.
- Prefer `write_to` or `write_to_writer` for large outputs; use `to_bytes` for
  in-memory workflows.
- No runtime dependencies. No proc-macro crates.
- Edition 2024, MSRV 1.85.

## Installation

```sh
cargo add halimede
```

## Usage

### Load a network

```rust
let net = halimede::Network::open("network.net")?;

println!("nodes: {}", net.nodes().row_count());
println!("links: {}", net.links().row_count());

let speed: &[f64] = net.links().column_f64("SPEED")?;
let a: &[i32] = net.links().a();
let b: &[i32] = net.links().b();
```

### Inspect schema and load selected fields

```rust
let info = halimede::NetworkInfo::open("network.net")?;

println!("zones: {}", info.header().zones());
let node_fields: Vec<&str> = info.node_schema().field_names().collect();
println!("node fields: {node_fields:?}");

let net = halimede::Network::open_fields(
    "network.net",
    ["X", "Y"],
    ["SPEED", "DIST"],
)?;
assert!(net.links().column_f64("SPEED").is_ok());
```

### Edit a network and write it back

```rust
let mut net = halimede::Network::open_fields(
    "network.net",
    ["X", "Y"],
    std::iter::empty::<&str>(),
)?;

let nodes = net.nodes_mut();
nodes.remove_fields(["Y"])?;

// Resolve handles after the last schema mutation.
let x = nodes.resolve_field("X")?;
nodes.derive_column_f64("X_KM", |table, row_index| {
    Ok(table.column_f64_field(&x)?[row_index] / 1000.0)
})?;

net.write_to("output.net")?;
```

### Build and write a network

```rust
use halimede::{LinkTable, NetworkBuilder, NodeTable};

let nodes = NodeTable::builder()
    .ids(vec![1, 2])
    .build()?;
let links = LinkTable::builder()
    .endpoints(vec![1], vec![2])
    .column_f64("SPEED", vec![60.0])
    .build()?;
let net = NetworkBuilder::new()
    .nodes(nodes)
    .links(links)
    .build()?;

net.write_to("output.net")?;
// Or write to bytes for in-memory workflows.
let bytes = net.to_bytes()?;
```

## Key types

| Type | Role |
|------|------|
| `Network` | In-memory network with columnar node and link data |
| `NetworkInfo` | Metadata and schemas without loading row data |
| `NetworkBuilder` | Programmatic construction of a `Network` for writing |
| `NodeTable` | Columnar storage for node IDs and user-defined fields |
| `LinkTable` | Columnar storage for link endpoints and user-defined fields |
| `NodeField` / `LinkField` | Resolved field handles for repeated typed access |
| `NodeTableBuilder` | Builds a `NodeTable` with validation |
| `LinkTableBuilder` | Builds a `LinkTable` with validation |
| `Header` | Parsed file header with zone count, banner, and run ID |
| `Schema` | Ordered set of field definitions for a table |
| `FieldDef` | Name, type, and index for one field in a schema |
| `LookupTable` | Speed or capacity lookup grid (9 lanes by 99 classes) |

## Part of the halimede workspace

This crate is the core library. The workspace also includes:

- [`halimede-cli`](https://crates.io/crates/halimede-cli) — command-line tool
- [`halimede-duckdb`](https://github.com/MichaelByrneAU/halimede/tree/main/crates/halimede-duckdb) — DuckDB extension for reading `.net` files
- [Python package](https://pypi.org/project/halimede/) — `uv add halimede`
- [GitHub repository](https://github.com/MichaelByrneAU/halimede)

## Licence

MIT OR Apache-2.0
