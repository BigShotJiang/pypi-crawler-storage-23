//! Top-level network type and builder.
//!
//! [`Network`] is the primary entry point for reading and writing `.net` files.
//! It owns the [`Header`], speed and capacity [`LookupTable`]s, and columnar
//! [`NodeTable`] and [`LinkTable`] data. Use [`NetworkInfo`] for schema-first
//! workflows, [`Network::open_fields`] when you only need selected user
//! columns, or construct a network programmatically via [`NetworkBuilder`].

use std::io::{Read, Write};
use std::path::Path;

use crate::error::{Error, ErrorKind, Result};
use crate::header::{self, Header};
use crate::reader::Reader;
use crate::schema::Schema;
use crate::spdcap::LookupTable;
use crate::table::{LinkTable, NodeTable};
use crate::writer::Writer;

/// Logical network metadata independent of derived PAR counts.
///
/// Use this for validation-only workflows or when constructing a [`Network`]
/// from already-built tables with [`Network::from_parts`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NetworkMetadata {
    banner: String,
    run_id: String,
    zones: u32,
    left_drive: bool,
}

impl NetworkMetadata {
    /// Create network metadata, applying the crate defaults when values are not
    /// supplied.
    ///
    /// `banner` defaults to `NET PGM=HALIMEDE VER=<crate version>` and must
    /// begin with `NET`. `run_id` defaults to `HALIMEDE`, and a leading `ID=`
    /// prefix is stripped when present.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::InvalidBanner`] when the supplied banner does not
    /// begin with `NET`.
    pub fn new<Banner, RunId>(
        banner: Option<Banner>,
        run_id: Option<RunId>,
        zones: u32,
        left_drive: bool,
    ) -> Result<Self>
    where
        Banner: AsRef<str>,
        RunId: AsRef<str>,
    {
        let banner = banner
            .map(|value| value.as_ref().to_string())
            .unwrap_or_else(|| header::DEFAULT_BANNER.to_string());
        let run_id = run_id
            .map(header::normalise_run_id)
            .unwrap_or_else(|| header::DEFAULT_RUN_ID.to_string());

        Ok(Self {
            banner: header::normalise_banner(banner)?,
            run_id,
            zones,
            left_drive,
        })
    }

    /// The validated banner string.
    #[must_use]
    pub fn banner(&self) -> &str {
        &self.banner
    }

    /// The validated run ID with the on-disk `ID=` prefix stripped.
    #[must_use]
    pub fn run_id(&self) -> &str {
        &self.run_id
    }

    /// The zone count.
    #[must_use]
    pub fn zones(&self) -> u32 {
        self.zones
    }

    /// Whether the network uses left-hand drive.
    #[must_use]
    pub fn left_drive(&self) -> bool {
        self.left_drive
    }
}

impl Default for NetworkMetadata {
    fn default() -> Self {
        Self {
            banner: header::DEFAULT_BANNER.to_string(),
            run_id: header::DEFAULT_RUN_ID.to_string(),
            zones: 0,
            left_drive: false,
        }
    }
}

/// An in-memory representation of a `.net` binary network file.
///
/// A `Network` owns the header metadata, speed and capacity lookup tables, and
/// columnar node and link data. It is the primary entry point for working with
/// `.net` files. Edit user-defined fields through [`nodes_mut`](Self::nodes_mut)
/// and [`links_mut`](Self::links_mut), then serialise with
/// [`write_to`](Self::write_to), [`write_to_writer`](Self::write_to_writer), or
/// [`to_bytes`](Self::to_bytes).
///
/// Core method families:
///
/// - Reading: [`open`](Self::open), [`from_bytes`](Self::from_bytes),
///   [`from_reader`](Self::from_reader).
/// - Selective reading:
///   [`open_fields`](Self::open_fields),
///   [`from_bytes_fields`](Self::from_bytes_fields),
///   [`from_reader_fields`](Self::from_reader_fields).
/// - Writing: [`write_to`](Self::write_to),
///   [`to_bytes`](Self::to_bytes),
///   [`write_to_writer`](Self::write_to_writer).
/// - Data access: [`nodes`](Self::nodes),
///   [`links`](Self::links), [`header`](Self::header).
///
/// # Example
///
/// ```
/// # use halimede::{NetworkBuilder, NodeTable, LinkTable};
/// # let nodes = NodeTable::builder().ids(vec![1, 2]).build()?;
/// # let links = LinkTable::builder()
/// #     .endpoints(vec![1], vec![2])
/// #     .column_f64("SPEED", vec![60.0])
/// #     .build()?;
/// # let net = NetworkBuilder::new().nodes(nodes).links(links).build()?;
/// let ids = net.nodes().ids();
/// let speed = net.links().column_f64("SPEED")?;
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct Network {
    header: Header,
    speed_table: LookupTable,
    capacity_table: LookupTable,
    nodes: NodeTable,
    links: LinkTable,
}

impl Network {
    /// Construct a `Network` directly from pre-validated parts.
    pub(crate) fn from_parts_unchecked(
        header: Header,
        speed_table: LookupTable,
        capacity_table: LookupTable,
        nodes: NodeTable,
        links: LinkTable,
    ) -> Self {
        Self {
            header,
            speed_table,
            capacity_table,
            nodes,
            links,
        }
    }

    /// Construct a `Network` from validated metadata, lookup tables, and
    /// already-built node and link tables.
    ///
    /// Derived PAR values such as maximum node ID and record counts are
    /// recomputed from `nodes` and `links`.
    ///
    /// # Errors
    ///
    /// Returns an error if the supplied metadata is invalid.
    pub fn from_parts(
        metadata: NetworkMetadata,
        speed_table: LookupTable,
        capacity_table: LookupTable,
        nodes: NodeTable,
        links: LinkTable,
    ) -> Result<Self> {
        let header = build_header(&metadata, &nodes, &links)?;
        Ok(Self {
            header,
            speed_table,
            capacity_table,
            nodes,
            links,
        })
    }

    /// Open a `.net` file from disk and materialise all data into memory.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be opened, or if the contents are
    /// not a valid `.net` file (malformed records, invalid schema, etc.).
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let file = std::fs::File::open(path.as_ref()).map_err(Error::from)?;
        Reader::new(file).parse()
    }

    /// Parse a `.net` file from a byte slice.
    ///
    /// For loading only selected columns, use
    /// [`from_bytes_fields`](Network::from_bytes_fields) instead.
    ///
    /// # Errors
    ///
    /// Returns an error if the bytes are not a valid `.net` file.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable, Network};
    ///
    /// let nodes = NodeTable::builder().ids(vec![1, 2]).build()?;
    /// let links = LinkTable::builder()
    ///     .endpoints(vec![1], vec![2])
    ///     .build()?;
    /// let net = NetworkBuilder::new()
    ///     .nodes(nodes)
    ///     .links(links)
    ///     .build()?;
    ///
    /// let bytes = net.to_bytes()?;
    /// let parsed = Network::from_bytes(&bytes)?;
    /// assert_eq!(parsed.nodes().ids(), &[1, 2]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        Reader::new(std::io::Cursor::new(bytes)).parse()
    }

    /// Parse a `.net` file from any reader.
    ///
    /// For loading only selected columns, use
    /// [`from_reader_fields`](Network::from_reader_fields) instead.
    ///
    /// # Errors
    ///
    /// Returns an error if reading fails or the contents are not a valid `.net`
    /// file.
    pub fn from_reader(reader: impl Read) -> Result<Self> {
        Reader::new(reader).parse()
    }

    /// Open a `.net` file, loading only the named fields.
    ///
    /// Fields not listed in `node_fields` or `link_fields` are skipped during
    /// decoding. Structural columns (N, A, B) are always loaded. For loading
    /// all fields, use [`open`](Network::open) instead. The field arguments
    /// accept any iterator of items implementing [`AsRef<str>`].
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be opened, if a requested field name
    /// does not exist in the schema, or if the contents are not a valid `.net`
    /// file.
    pub fn open_fields<NodeFields, LinkFields, NodeField, LinkField>(
        path: impl AsRef<Path>,
        node_fields: NodeFields,
        link_fields: LinkFields,
    ) -> Result<Self>
    where
        NodeFields: IntoIterator<Item = NodeField>,
        LinkFields: IntoIterator<Item = LinkField>,
        NodeField: AsRef<str>,
        LinkField: AsRef<str>,
    {
        let file = std::fs::File::open(path.as_ref()).map_err(Error::from)?;
        parse_reader_with_fields(file, node_fields, link_fields)
    }

    /// Parse a `.net` file from a byte slice, loading only the named fields.
    ///
    /// Fields not listed in `node_fields` or `link_fields` are skipped during
    /// decoding. Structural columns (N, A, B) are always loaded. For loading
    /// all fields, use [`from_bytes`](Network::from_bytes) instead. The field
    /// arguments accept any iterator of items implementing [`AsRef<str>`].
    ///
    /// # Errors
    ///
    /// Returns an error if a requested field name does not exist in the schema,
    /// or if the bytes are not a valid `.net` file.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable, Network};
    ///
    /// let nodes = NodeTable::builder()
    ///     .ids(vec![1, 2])
    ///     .column_f64("X", vec![1.0, 2.0])
    ///     .column_f64("Y", vec![3.0, 4.0])
    ///     .build()?;
    /// let links = LinkTable::builder()
    ///     .endpoints(vec![1], vec![2])
    ///     .build()?;
    /// let bytes = NetworkBuilder::new()
    ///     .nodes(nodes)
    ///     .links(links)
    ///     .build()?
    ///     .to_bytes()?;
    ///
    /// // Load only the "X" node column and no link fields.
    /// let no_link_fields = std::iter::empty::<&str>();
    /// let net = Network::from_bytes_fields(
    ///     &bytes, ["X"], no_link_fields,
    /// )?;
    /// assert_eq!(net.nodes().column_f64("X")?, &[1.0, 2.0]);
    /// assert!(net.nodes().column_f64("Y").is_err());
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn from_bytes_fields<NodeFields, LinkFields, NodeField, LinkField>(
        bytes: &[u8],
        node_fields: NodeFields,
        link_fields: LinkFields,
    ) -> Result<Self>
    where
        NodeFields: IntoIterator<Item = NodeField>,
        LinkFields: IntoIterator<Item = LinkField>,
        NodeField: AsRef<str>,
        LinkField: AsRef<str>,
    {
        parse_reader_with_fields(std::io::Cursor::new(bytes), node_fields, link_fields)
    }

    /// Parse a `.net` file from any reader, loading only the named fields.
    ///
    /// Fields not listed in `node_fields` or `link_fields` are skipped during
    /// decoding. Structural columns (N, A, B) are always loaded. For loading
    /// all fields, use [`from_reader`](Network::from_reader) instead. The
    /// field arguments accept any iterator of items implementing [`AsRef<str>`].
    ///
    /// # Errors
    ///
    /// Returns an error if a requested field name does not exist in the schema,
    /// or if reading fails or the contents are not a valid `.net` file.
    pub fn from_reader_fields<NodeFields, LinkFields, NodeField, LinkField>(
        reader: impl Read,
        node_fields: NodeFields,
        link_fields: LinkFields,
    ) -> Result<Self>
    where
        NodeFields: IntoIterator<Item = NodeField>,
        LinkFields: IntoIterator<Item = LinkField>,
        NodeField: AsRef<str>,
        LinkField: AsRef<str>,
    {
        parse_reader_with_fields(reader, node_fields, link_fields)
    }

    /// Write this network to a file on disk.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be created or written to, or if any
    /// value cannot be encoded in the `.net` binary format.
    pub fn write_to(&self, path: impl AsRef<Path>) -> Result<()> {
        let file = std::fs::File::create(path.as_ref()).map_err(Error::from)?;
        Writer::new(file).write_network(self)
    }

    /// Write this network to any writer.
    ///
    /// This is the preferred write path when you already have a sink and want
    /// to avoid allocating a full output buffer in memory.
    ///
    /// # Errors
    ///
    /// Returns an error if writing fails or if any value cannot be encoded.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable, Network};
    ///
    /// let net = NetworkBuilder::new()
    ///     .nodes(NodeTable::builder().ids(vec![1]).build()?)
    ///     .links(
    ///         LinkTable::builder()
    ///             .endpoints(vec![1], vec![1])
    ///             .build()?,
    ///     )
    ///     .build()?;
    ///
    /// let mut buf = Vec::new();
    /// net.write_to_writer(&mut buf)?;
    /// let parsed = Network::from_bytes(&buf)?;
    /// assert_eq!(parsed.nodes().ids(), &[1]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn write_to_writer(&self, writer: impl Write) -> Result<()> {
        Writer::new(writer).write_network(self)
    }

    /// Serialise this network to a byte vector.
    ///
    /// This is a convenience method for in-memory workflows. For large outputs
    /// or streaming writes, prefer [`write_to`](Self::write_to) or
    /// [`write_to_writer`](Self::write_to_writer).
    ///
    /// # Errors
    ///
    /// Returns an error if any value cannot be encoded in the `.net` binary
    /// format.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable, Network};
    ///
    /// let net = NetworkBuilder::new()
    ///     .nodes(NodeTable::builder().ids(vec![1, 2]).build()?)
    ///     .links(
    ///         LinkTable::builder()
    ///             .endpoints(vec![1], vec![2])
    ///             .build()?,
    ///     )
    ///     .build()?;
    ///
    /// let bytes = net.to_bytes()?;
    /// let roundtripped = Network::from_bytes(&bytes)?;
    /// assert_eq!(roundtripped.nodes().ids(), &[1, 2]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let field_count_estimate =
            self.nodes.schema().field_count() + self.links.schema().field_count();
        let row_count_estimate = self.nodes.row_count() + self.links.row_count();
        let estimated_size = 512 + row_count_estimate * (8 + field_count_estimate * 3);
        let mut buf = Vec::with_capacity(estimated_size);
        Writer::new(&mut buf).write_network(self)?;
        Ok(buf)
    }

    /// The header metadata.
    #[inline]
    #[must_use]
    pub fn header(&self) -> &Header {
        &self.header
    }

    /// The node table containing structural IDs and user-defined columns.
    #[inline]
    #[must_use]
    pub fn nodes(&self) -> &NodeTable {
        &self.nodes
    }

    /// The link table containing structural endpoints and user-defined columns.
    #[inline]
    #[must_use]
    pub fn links(&self) -> &LinkTable {
        &self.links
    }

    /// Mutable access to the node table.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable};
    ///
    /// let mut net = NetworkBuilder::new()
    ///     .nodes(
    ///         NodeTable::builder()
    ///             .ids(vec![1, 2])
    ///             .column_f64("X", vec![1.0, 2.0])
    ///             .build()?,
    ///     )
    ///     .links(
    ///         LinkTable::builder()
    ///             .endpoints(vec![1], vec![2])
    ///             .build()?,
    ///     )
    ///     .build()?;
    ///
    /// net.nodes_mut().column_f64_mut("X")?[0] = 99.0;
    /// assert_eq!(net.nodes().column_f64("X")?, &[99.0, 2.0]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    #[inline]
    #[must_use]
    pub fn nodes_mut(&mut self) -> &mut NodeTable {
        &mut self.nodes
    }

    /// Mutable access to the link table.
    #[inline]
    #[must_use]
    pub fn links_mut(&mut self) -> &mut LinkTable {
        &mut self.links
    }

    /// The speed lookup table.
    #[inline]
    #[must_use]
    pub fn speed_table(&self) -> &LookupTable {
        &self.speed_table
    }

    /// The capacity lookup table.
    #[inline]
    #[must_use]
    pub fn capacity_table(&self) -> &LookupTable {
        &self.capacity_table
    }

    /// Set the zone count.
    ///
    /// Nodes 1 through `zones` are treated as zone centroids by convention.
    pub fn set_zones(&mut self, zones: u32) {
        self.header.zones = zones;
    }

    /// Set the banner string.
    ///
    /// The value must begin with `NET`.
    pub fn set_banner(&mut self, banner: impl AsRef<str>) -> Result<()> {
        self.header.banner = header::normalise_banner(banner)?;
        Ok(())
    }

    /// Set the run ID.
    ///
    /// A leading `ID=` prefix is stripped when present.
    pub fn set_run_id(&mut self, run_id: impl AsRef<str>) {
        self.header.run_id = header::normalise_run_id(run_id);
    }

    /// Set the left-hand drive flag.
    pub fn set_left_drive(&mut self, left_drive: bool) {
        self.header.left_drive = left_drive;
    }

    /// Consume this network and return its constituent parts.
    ///
    /// Returns `(header, speed_table, capacity_table, nodes, links)`.
    #[must_use]
    pub fn into_parts(self) -> (Header, LookupTable, LookupTable, NodeTable, LinkTable) {
        (
            self.header,
            self.speed_table,
            self.capacity_table,
            self.nodes,
            self.links,
        )
    }
}

/// Builder for constructing a [`Network`] programmatically.
///
/// The builder validates that all required components are present and uses
/// default speed and capacity tables if none are provided.
///
/// # Example
///
/// ```
/// use halimede::{NetworkBuilder, NodeTable, LinkTable};
///
/// let nodes = NodeTable::builder()
///     .ids(vec![1, 2, 3])
///     .column_f64("X", vec![320000.0, 320100.0, 320200.0])
///     .build()?;
///
/// let links = LinkTable::builder()
///     .endpoints(vec![1, 2], vec![2, 3])
///     .column_f64("DIST", vec![1.2, 0.8])
///     .build()?;
///
/// let net = NetworkBuilder::new()
///     .nodes(nodes)
///     .links(links)
///     .zones(1)
///     .build()?;
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug)]
pub struct NetworkBuilder {
    header_zones: Option<u32>,
    header_banner: Option<String>,
    header_run_id: Option<String>,
    header_left_drive: bool,
    speed_table: Option<LookupTable>,
    capacity_table: Option<LookupTable>,
    nodes: Option<NodeTable>,
    links: Option<LinkTable>,
}

impl NetworkBuilder {
    /// Create a new builder with default settings.
    #[must_use]
    pub fn new() -> Self {
        Self {
            header_zones: None,
            header_banner: None,
            header_run_id: None,
            header_left_drive: false,
            speed_table: None,
            capacity_table: None,
            nodes: None,
            links: None,
        }
    }

    /// Set the zone count.
    ///
    /// Nodes 1 through `zones` are treated as zone centroids by convention.
    /// Defaults to 0 if not set.
    #[must_use]
    pub fn zones(mut self, zones: u32) -> Self {
        self.header_zones = Some(zones);
        self
    }

    /// Override the banner string.
    ///
    /// Defaults to `NET PGM=HALIMEDE VER=<crate version>`. The supplied value
    /// must begin with `NET`; this is validated during [`build`](Self::build).
    #[must_use]
    pub fn banner(mut self, banner: impl Into<String>) -> Self {
        self.header_banner = Some(banner.into());
        self
    }

    /// Override the run ID (default: `"HALIMEDE"`).
    ///
    /// A leading `ID=` prefix is stripped when present.
    #[must_use]
    pub fn run_id(mut self, run_id: impl AsRef<str>) -> Self {
        self.header_run_id = Some(header::normalise_run_id(run_id));
        self
    }

    /// Set the left-hand drive flag (default: `false`).
    #[must_use]
    pub fn left_drive(mut self, left_drive: bool) -> Self {
        self.header_left_drive = left_drive;
        self
    }

    /// Provide a custom speed lookup table (default: standard speed table).
    #[must_use]
    pub fn speed_table(mut self, table: LookupTable) -> Self {
        self.speed_table = Some(table);
        self
    }

    /// Provide a custom capacity lookup table (default: standard capacity
    /// table).
    #[must_use]
    pub fn capacity_table(mut self, table: LookupTable) -> Self {
        self.capacity_table = Some(table);
        self
    }

    /// Set the node table.
    #[must_use]
    pub fn nodes(mut self, nodes: NodeTable) -> Self {
        self.nodes = Some(nodes);
        self
    }

    /// Set the link table.
    #[must_use]
    pub fn links(mut self, links: LinkTable) -> Self {
        self.links = Some(links);
        self
    }

    /// Validate the builder configuration and return the effective header.
    ///
    /// This performs the same metadata and table-presence validation as
    /// [`build`](Self::build), and derives the PAR counts from the provided
    /// tables, but does not allocate a final [`Network`] value.
    ///
    /// # Errors
    ///
    /// Returns an error under the same conditions as [`build`](Self::build).
    pub fn validate(&self) -> Result<Header> {
        let nodes = self
            .nodes
            .as_ref()
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "N" }))?;
        let links = self
            .links
            .as_ref()
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "A" }))?;
        let metadata = build_metadata(
            self.header_banner.as_deref(),
            self.header_run_id.as_deref(),
            self.header_zones.unwrap_or(0),
            self.header_left_drive,
        )?;
        build_header(&metadata, nodes, links)
    }

    /// Build the [`Network`], validating all required components.
    ///
    /// # Errors
    ///
    /// Returns an error if the node table or link table has not been set.
    pub fn build(self) -> Result<Network> {
        let nodes = self
            .nodes
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "N" }))?;
        let links = self
            .links
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "A" }))?;
        let metadata = build_metadata(
            self.header_banner.as_deref(),
            self.header_run_id.as_deref(),
            self.header_zones.unwrap_or(0),
            self.header_left_drive,
        )?;
        let header = build_header(&metadata, &nodes, &links)?;

        let speed_table = self.speed_table.unwrap_or_else(LookupTable::default_speed);
        let capacity_table = self
            .capacity_table
            .unwrap_or_else(LookupTable::default_capacity);

        Ok(Network {
            header,
            speed_table,
            capacity_table,
            nodes,
            links,
        })
    }
}

impl Default for NetworkBuilder {
    fn default() -> Self {
        Self::new()
    }
}

fn build_metadata(
    banner: Option<&str>,
    run_id: Option<&str>,
    zones: u32,
    left_drive: bool,
) -> Result<NetworkMetadata> {
    NetworkMetadata::new(banner, run_id, zones, left_drive)
}

fn build_header(
    metadata: &NetworkMetadata,
    nodes: &NodeTable,
    links: &LinkTable,
) -> Result<Header> {
    let max_node_id = derive_max_node_id(nodes, links);
    Header::new(
        metadata.banner.clone(),
        metadata.run_id.clone(),
        metadata.zones,
        max_node_id,
        links.row_count() as u32,
        nodes.row_count() as u32,
        metadata.left_drive,
    )
}

fn collect_field_names<Fields, Field>(field_names: Fields) -> Vec<String>
where
    Fields: IntoIterator<Item = Field>,
    Field: AsRef<str>,
{
    field_names
        .into_iter()
        .map(|field_name| field_name.as_ref().to_string())
        .collect()
}

fn parse_reader_with_fields<R, NodeFields, LinkFields, NodeField, LinkField>(
    reader: R,
    node_fields: NodeFields,
    link_fields: LinkFields,
) -> Result<Network>
where
    R: Read,
    NodeFields: IntoIterator<Item = NodeField>,
    LinkFields: IntoIterator<Item = LinkField>,
    NodeField: AsRef<str>,
    LinkField: AsRef<str>,
{
    let node_field_names = collect_field_names(node_fields);
    let link_field_names = collect_field_names(link_fields);
    let node_field_refs: Vec<&str> = node_field_names.iter().map(String::as_str).collect();
    let link_field_refs: Vec<&str> = link_field_names.iter().map(String::as_str).collect();
    Reader::new(reader).parse_with_fields(&node_field_refs, &link_field_refs)
}

fn derive_max_node_id(nodes: &NodeTable, links: &LinkTable) -> u32 {
    nodes
        .ids()
        .iter()
        .chain(links.a().iter())
        .chain(links.b().iter())
        .copied()
        .max()
        .map(|value| value as u32)
        .unwrap_or(0)
}

/// Schema-only view of a `.net` file.
///
/// `NetworkInfo` captures the header, speed and capacity lookup tables, and
/// node and link schemas without reading any data records. This allows callers
/// to discover available fields before deciding which columns to load via
/// [`Network::from_bytes_fields`] or similar methods.
///
/// # Example
///
/// ```
/// use halimede::{
///     NetworkBuilder, NetworkInfo, NodeTable, LinkTable, Network,
/// };
///
/// let nodes = NodeTable::builder()
///     .ids(vec![1, 2])
///     .column_f64("X", vec![1.0, 2.0])
///     .column_f64("Y", vec![3.0, 4.0])
///     .build()?;
/// let links = LinkTable::builder()
///     .endpoints(vec![1], vec![2])
///     .column_f64("SPEED", vec![60.0])
///     .build()?;
/// let bytes = NetworkBuilder::new()
///     .nodes(nodes)
///     .links(links)
///     .build()?
///     .to_bytes()?;
///
/// // Inspect the schema without loading data.
/// let info = NetworkInfo::from_bytes(&bytes)?;
/// let node_fields: Vec<&str> =
///     info.node_schema().field_names().collect();
/// assert_eq!(node_fields, vec!["X", "Y"]);
///
/// // Now load only the columns we need.
/// let net = Network::from_bytes_fields(
///     &bytes, ["X"], ["SPEED"],
/// )?;
/// assert_eq!(net.nodes().column_f64("X")?, &[1.0, 2.0]);
/// assert!(net.nodes().column_f64("Y").is_err());
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone)]
pub struct NetworkInfo {
    header: Header,
    speed_table: LookupTable,
    capacity_table: LookupTable,
    node_schema: Schema,
    link_schema: Schema,
}

impl NetworkInfo {
    /// Construct a `NetworkInfo` from pre-parsed parts.
    pub(crate) fn from_parts(
        header: Header,
        speed_table: LookupTable,
        capacity_table: LookupTable,
        node_schema: Schema,
        link_schema: Schema,
    ) -> Self {
        Self {
            header,
            speed_table,
            capacity_table,
            node_schema,
            link_schema,
        }
    }

    /// Open a `.net` file and parse only the metadata records.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be opened or its contents are
    /// malformed.
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let file = std::fs::File::open(path.as_ref()).map_err(Error::from)?;
        Reader::new(file).parse_info()
    }

    /// Parse metadata from a byte slice without reading data records.
    ///
    /// # Errors
    ///
    /// Returns an error if the contents are malformed.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        Reader::new(std::io::Cursor::new(bytes)).parse_info()
    }

    /// Parse metadata from any reader without reading data records.
    ///
    /// # Errors
    ///
    /// Returns an error if reading fails or the contents are malformed.
    pub fn from_reader(reader: impl Read) -> Result<Self> {
        Reader::new(reader).parse_info()
    }

    /// The header metadata.
    #[inline]
    #[must_use]
    pub fn header(&self) -> &Header {
        &self.header
    }

    /// The speed lookup table.
    #[inline]
    #[must_use]
    pub fn speed_table(&self) -> &LookupTable {
        &self.speed_table
    }

    /// The capacity lookup table.
    #[inline]
    #[must_use]
    pub fn capacity_table(&self) -> &LookupTable {
        &self.capacity_table
    }

    /// The node schema describing available node fields.
    #[inline]
    #[must_use]
    pub fn node_schema(&self) -> &Schema {
        &self.node_schema
    }

    /// The link schema describing available link fields.
    #[inline]
    #[must_use]
    pub fn link_schema(&self) -> &Schema {
        &self.link_schema
    }

    /// Consume this info and return its constituent parts.
    ///
    /// Returns `(header, speed_table, capacity_table, node_schema,
    /// link_schema)`.
    #[must_use]
    pub fn into_parts(self) -> (Header, LookupTable, LookupTable, Schema, Schema) {
        (
            self.header,
            self.speed_table,
            self.capacity_table,
            self.node_schema,
            self.link_schema,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn network_metadata_new_applies_defaults_and_normalises_run_id() {
        let metadata = NetworkMetadata::new(None::<&str>, Some("ID=TEST"), 3, true).unwrap();

        assert!(metadata.banner().starts_with("NET "));
        assert_eq!(metadata.run_id(), "TEST");
        assert_eq!(metadata.zones(), 3);
        assert!(metadata.left_drive());
    }

    #[test]
    fn builder_validate_returns_effective_header() {
        let nodes = NodeTable::builder().ids(vec![1, 5]).build().unwrap();
        let links = LinkTable::builder()
            .endpoints(vec![1], vec![5])
            .build()
            .unwrap();

        let header = NetworkBuilder::new()
            .nodes(nodes)
            .links(links)
            .zones(2)
            .run_id("ID=CHECK")
            .validate()
            .unwrap();

        assert_eq!(header.run_id(), "CHECK");
        assert_eq!(header.zones(), 2);
        assert_eq!(header.max_node_id(), 5);
        assert_eq!(header.link_count(), 1);
        assert_eq!(header.node_rec_count(), 2);
    }

    #[test]
    fn network_from_parts_derives_header_counts() {
        let metadata =
            NetworkMetadata::new(Some("NET PGM=TEST"), Some("ID=RUN"), 1, false).unwrap();
        let nodes = NodeTable::builder().ids(vec![1, 4]).build().unwrap();
        let links = LinkTable::builder()
            .endpoints(vec![1, 4], vec![4, 1])
            .build()
            .unwrap();

        let network = Network::from_parts(
            metadata,
            LookupTable::default_speed(),
            LookupTable::default_capacity(),
            nodes,
            links,
        )
        .unwrap();

        assert_eq!(network.header().run_id(), "RUN");
        assert_eq!(network.header().zones(), 1);
        assert_eq!(network.header().max_node_id(), 4);
        assert_eq!(network.header().link_count(), 2);
        assert_eq!(network.header().node_rec_count(), 2);
    }
}
