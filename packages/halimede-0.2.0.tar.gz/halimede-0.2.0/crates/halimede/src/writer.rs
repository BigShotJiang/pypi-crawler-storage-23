//! Internal writer for producing `.net` binary network files.
//!
//! The writer accepts a [`Network`](crate::Network) and emits the complete
//! record sequence.

use std::io::{BufWriter, Write};

use crate::encode::{encode_numeric, encode_string, encode_sub_record_length};
use crate::error::Result;
use crate::network::Network;
use crate::schema::FieldType;
use crate::spdcap::encode_spdcap_record;
use crate::table::Column;

/// Writer that serialises a [`Network`] to the `.net` binary format.
pub(crate) struct Writer<W: Write> {
    sink: BufWriter<W>,
}

impl<W: Write> Writer<W> {
    /// Wrap a writer and prepare to emit a `.net` file.
    pub(crate) fn new(sink: W) -> Self {
        Self {
            sink: BufWriter::new(sink),
        }
    }

    /// Write the complete `.net` file for the given network.
    pub(crate) fn write_network(mut self, net: &Network) -> Result<()> {
        // 1. NET banner.
        self.write_text_record(&format!("{}\n\0", net.header().banner()))?;

        // 2. ID.
        self.write_text_record(&format!("ID={}\0", net.header().run_id()))?;

        // 3. PAR. Recompute derived fields from the actual table data so
        // that mutations to node/link tables are reflected correctly.
        let max_node_id = net
            .nodes()
            .ids()
            .iter()
            .chain(net.links().a().iter())
            .chain(net.links().b().iter())
            .copied()
            .max()
            .unwrap_or(0) as u32;
        let link_count = net.links().row_count() as u32;
        let node_rec_count = net.nodes().row_count() as u32;
        let mut par = format!(
            "PAR Zones={} Nodes={} Links={} NodeRecs={}",
            net.header().zones(),
            max_node_id,
            link_count,
            node_rec_count,
        );
        if net.header().left_drive() {
            par.push_str(" LeftDrive=1");
        }
        par.push('\0');
        self.write_text_record(&par)?;

        // 4. SPD.
        let spd_payload = encode_spdcap_record(net.speed_table(), true);
        self.write_record(&spd_payload)?;

        // 5. CAP.
        let cap_payload = encode_spdcap_record(net.capacity_table(), false);
        self.write_record(&cap_payload)?;

        // 6. NVR (node schema).
        let nvr_payload = self.build_schema_payload(b"NVR ", &["N"], net.nodes().schema());
        self.write_record(&nvr_payload)?;

        // 7. LVR (link schema).
        let lvr_payload = self.build_schema_payload(b"LVR ", &["A", "B"], net.links().schema());
        self.write_record(&lvr_payload)?;

        // 8. NOD (node data).
        self.write_data_record(b"NOD\0", &[net.nodes().ids()], net.nodes().raw_columns())?;

        // 9. LNK (link data).
        self.write_data_record(
            b"LNK\0",
            &[net.links().a(), net.links().b()],
            net.links().raw_columns(),
        )?;

        // 10. END.
        self.write_record(b"END\0")?;

        self.sink.flush()?;
        Ok(())
    }

    /// Write a record envelope: 4-byte LE total_size then payload.
    fn write_record(&mut self, payload: &[u8]) -> Result<()> {
        let total_size = (payload.len() + 4) as u32;
        self.sink.write_all(&total_size.to_le_bytes())?;
        self.sink.write_all(payload)?;
        Ok(())
    }

    /// Write a text record (string payload).
    fn write_text_record(&mut self, text: &str) -> Result<()> {
        self.write_record(text.as_bytes())
    }

    /// Build a schema record payload (NVR or LVR).
    fn build_schema_payload(
        &self,
        tag: &[u8; 4],
        structural_names: &[&str],
        schema: &crate::schema::Schema,
    ) -> Vec<u8> {
        let total_field_count = structural_names.len() + schema.field_count();
        let count_str = total_field_count.to_string();

        let mut payload = Vec::new();
        payload.extend_from_slice(tag);
        payload.extend_from_slice(count_str.as_bytes());
        payload.push(0);

        for &name in structural_names {
            payload.extend_from_slice(name.as_bytes());
            payload.push(0);
        }

        for field in schema.fields() {
            payload.extend_from_slice(field.name().as_bytes());
            if let FieldType::String { max_size } = field.field_type() {
                payload.push(b'=');
                payload.extend_from_slice(max_size.to_string().as_bytes());
            }
            payload.push(0);
        }

        payload
    }

    /// Write a NOD or LNK data record as a single buffered pass.
    ///
    /// Each row is encoded into `row_buf` first so the sub-record length can be
    /// written before the row bytes themselves. Trailing default-valued user
    /// fields are elided by scanning back to the last non-default column, which
    /// mirrors the reader's default expansion logic.
    fn write_data_record(
        &mut self,
        tag: &[u8; 4],
        structural_ids: &[&[i32]],
        columns: &[Column],
    ) -> Result<()> {
        let row_count = structural_ids[0].len();

        let mut payload =
            Vec::with_capacity(4 + row_count * (2 + structural_ids.len() * 4 + columns.len() * 3));
        payload.extend_from_slice(tag);

        let mut row_buf = Vec::with_capacity((2 + columns.len()) * 9);
        for row_index in 0..row_count {
            row_buf.clear();
            for ids in structural_ids {
                encode_numeric(ids[row_index] as f64, &mut row_buf);
            }
            if let Some(last) = find_last_non_default(columns, row_index) {
                for column in &columns[..=last] {
                    encode_field_value(column, row_index, &mut row_buf)?;
                }
            }
            encode_sub_record_length(row_buf.len(), &mut payload);
            payload.extend_from_slice(&row_buf);
        }

        self.write_record(&payload)?;
        Ok(())
    }
}

/// Find the index of the last non-default user field for the given row.
///
/// Returns `None` when all fields are default. A numeric default is 0.0, a
/// string default is empty.
fn find_last_non_default(columns: &[Column], row_index: usize) -> Option<usize> {
    for field_index in (0..columns.len()).rev() {
        let is_default = match &columns[field_index] {
            Column::Numeric(values) => values[row_index] == 0.0,
            Column::String(values) => values[row_index].is_empty(),
        };
        if !is_default {
            return Some(field_index);
        }
    }
    None
}

/// Encode a single field value into the buffer.
fn encode_field_value(column: &Column, row_index: usize, buf: &mut Vec<u8>) -> Result<()> {
    match column {
        Column::Numeric(values) => {
            encode_numeric(values[row_index], buf);
            Ok(())
        }
        Column::String(values) => encode_string(&values[row_index], buf),
    }
}
