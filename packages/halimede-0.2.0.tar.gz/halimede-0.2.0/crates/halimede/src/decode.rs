//! Variable-width tag decoder for `.net` sub-record payloads.
//!
//! This module decodes the binary tag-value encoding used in node and link
//! sub-records.

use crate::error::{Error, ErrorKind, Result};

/// A value decoded from the variable-width tag encoding used inside sub-record
/// payloads.
///
/// The reader converts numeric values to `f64` column entries and string values
/// to `String` column entries.
#[derive(Debug, Clone, PartialEq)]
#[cfg(test)]
pub(crate) enum DecodedValue {
    /// A numeric value decoded as `f64`.
    Numeric(f64),
    /// A string value decoded from ASCII bytes.
    String(String),
}

/// Decode a single variable-width value starting at `offset` in `data`.
///
/// Returns `(value, next_offset)` where `next_offset` is the first byte after
/// the consumed value.
///
/// Returns `UnexpectedEof` if `data` is too short for the tag or its payload,
/// and `InvalidTag` if the tag byte does not belong to any recognised encoding
/// family.
#[cfg(test)]
pub(crate) fn decode_value(data: &[u8], offset: usize) -> Result<(DecodedValue, usize)> {
    let tag = read_u8(data, offset)?;
    let past_tag = offset + 1;

    match tag {
        // Inline string (0 to 62 characters).
        0xC0..=0xFF => decode_string_tag(tag, data, past_tag)
            .map(|(value, next_offset)| (DecodedValue::String(value), next_offset)),

        // All other tags are numeric.
        _ => {
            let (value, next) = decode_numeric_tag(tag, data, past_tag)?;
            Ok((DecodedValue::Numeric(value), next))
        }
    }
}

/// Decode a single numeric value starting at `offset` in `data`.
///
/// Handles all numeric tag families (integers, compact doubles, scaled
/// decimals, and single-precision floats) and returns the decoded `f64` with
/// the next offset. Unlike `decode_value`, this function does not accept string
/// tags. An `InvalidTag` error is returned for inline string tags
/// (`0xC0..=0xFE`), extended string tags (`0xFF`), and any unrecognised tag
/// byte.
///
/// Returns `UnexpectedEof` if `data` is too short for the tag or its payload.
pub(crate) fn decode_numeric_value(data: &[u8], offset: usize) -> Result<(f64, usize)> {
    let tag = read_u8(data, offset)?;
    decode_numeric_tag(tag, data, offset + 1)
}

/// Decode a single string value starting at `offset` in `data`.
///
/// Accepts only inline and extended string tags and returns the decoded string
/// plus the next offset. Numeric tags and invalid tags return `InvalidTag`.
pub(crate) fn decode_string_value(data: &[u8], offset: usize) -> Result<(String, usize)> {
    let tag = read_u8(data, offset)?;
    decode_string_tag(tag, data, offset + 1)
}

/// Decode the payload of a numeric tag byte.
///
/// Handles all numeric tag families: positive and negative integers (with 0 to
/// 3 extra bytes), compact doubles (0 to 8 stored bytes), scaled decimals (1 to
/// 4 payload bytes with a power-of-ten divisor), and single-precision IEEE 754
/// floats. Returns `InvalidTag` for string tags and any tag byte that falls
/// outside a recognised numeric range.
///
/// `past_tag` is the offset of the first byte after the tag.
fn decode_numeric_tag(tag: u8, data: &[u8], past_tag: usize) -> Result<(f64, usize)> {
    match tag {
        // Positive integer: literal (0 extra bytes).
        0x00..=0x47 => Ok((tag as f64, past_tag)),

        // Positive integer: 1 extra byte.
        0x48..=0x4F => {
            let b1 = read_u8(data, past_tag)?;
            let value = ((tag as u32 - 0x48) << 8) | b1 as u32;
            Ok((value as f64, past_tag + 1))
        }

        // Positive integer: 2 extra bytes.
        0x50..=0x57 => {
            let lo = read_u16_le(data, past_tag)?;
            let value = ((tag as u32 - 0x50) << 16) | lo as u32;
            Ok((value as f64, past_tag + 2))
        }

        // Positive integer: 3 extra bytes.
        0x58..=0x5F => {
            let lo = read_u24_le(data, past_tag)?;
            let value = ((tag as u32 - 0x58) << 24) | lo;
            Ok((value as f64, past_tag + 3))
        }

        // Negative integer: literal (0 extra bytes).
        0x60..=0x67 => {
            let value = -((tag - 0x60) as f64);
            Ok((value, past_tag))
        }

        // Negative integer: 1 extra byte.
        0x68..=0x6F => {
            let b1 = read_u8(data, past_tag)?;
            let magnitude = ((tag as u32 - 0x68) << 8) | b1 as u32;
            Ok((-(magnitude as f64), past_tag + 1))
        }

        // Negative integer: 2 extra bytes.
        0x70..=0x77 => {
            let lo = read_u16_le(data, past_tag)?;
            let magnitude = ((tag as u32 - 0x70) << 16) | lo as u32;
            Ok((-(magnitude as f64), past_tag + 2))
        }

        // Negative integer: 3 extra bytes.
        0x78..=0x7F => {
            let lo = read_u24_le(data, past_tag)?;
            let magnitude = ((tag as u32 - 0x78) << 24) | lo;
            Ok((-(magnitude as f64), past_tag + 3))
        }

        // Compact double: zero.
        0x80 => Ok((0.0, past_tag)),

        // Compact double: 1 to 7 stored bytes.
        0x81..=0x87 => {
            let byte_count = (tag - 0x80) as usize;
            bounds_check(data, past_tag, byte_count)?;
            let mut buf = [0u8; 8];
            // Stored bytes are the most-significant (rightmost in
            // LE). Place them at the high end of the 8-byte buffer.
            let dest_start = 8 - byte_count;
            buf[dest_start..8].copy_from_slice(&data[past_tag..past_tag + byte_count]);
            let value = f64::from_le_bytes(buf);
            Ok((value, past_tag + byte_count))
        }

        // Full double: 8 bytes.
        0x88 => {
            bounds_check(data, past_tag, 8)?;
            let mut buf = [0u8; 8];
            buf.copy_from_slice(&data[past_tag..past_tag + 8]);
            let value = f64::from_le_bytes(buf);
            Ok((value, past_tag + 8))
        }

        // Scaled decimal: tag = 0x90 | (scale_index << 2) | (extra_bytes - 1).
        0x90..=0x9F => {
            let scale_index = ((tag - 0x90) >> 2) as usize;
            let extra_bytes = ((tag - 0x90) & 0x03) as usize + 1;

            let divisors: [f64; 4] = [10.0, 100.0, 1000.0, 10000.0];
            let divisor = divisors[scale_index];

            let payload = match extra_bytes {
                1 => {
                    let b = read_u8(data, past_tag)?;
                    b as u32
                }
                2 => {
                    let v = read_u16_le(data, past_tag)?;
                    v as u32
                }
                3 => read_u24_le(data, past_tag)?,
                4 => read_u32_le(data, past_tag)?,
                _ => unreachable!(),
            };

            let value = payload as f64 / divisor;
            Ok((value, past_tag + extra_bytes))
        }

        // Single-precision float (IEEE 754).
        0xA4 => {
            bounds_check(data, past_tag, 4)?;
            let mut buf = [0u8; 4];
            buf.copy_from_slice(&data[past_tag..past_tag + 4]);
            let value = f32::from_le_bytes(buf) as f64;
            Ok((value, past_tag + 4))
        }

        // String or invalid tag in numeric context.
        _ => Err(Error::new(ErrorKind::InvalidTag { tag })),
    }
}

fn decode_string_tag(tag: u8, data: &[u8], past_tag: usize) -> Result<(String, usize)> {
    match tag {
        // Inline string (0 to 62 characters).
        0xC0..=0xFE => {
            let string_length = (tag & 0x3F) as usize;
            bounds_check(data, past_tag, string_length)?;
            let s = ascii_string(&data[past_tag..past_tag + string_length]);
            Ok((s, past_tag + string_length))
        }

        // Extended string.
        0xFF => {
            let string_length = read_u8(data, past_tag)? as usize;
            let content_offset = past_tag + 1;
            bounds_check(data, content_offset, string_length)?;
            let s = ascii_string(&data[content_offset..content_offset + string_length]);
            Ok((s, content_offset + string_length))
        }

        _ => Err(Error::new(ErrorKind::InvalidTag { tag })),
    }
}

/// Read a sub-record length from the variable-width length prefix.
///
/// Returns `(length, prefix_size)` where `length` is the payload byte count and
/// `prefix_size` is 1 or 2. Lengths below 128 are stored as a single byte.
/// Lengths of 128 or more use a two-byte big-endian encoding with the high bit
/// of the first byte set.
pub(crate) fn read_sub_record_length(data: &[u8], offset: usize) -> Result<(usize, usize)> {
    let b = read_u8(data, offset)?;
    if b < 0x80 {
        Ok((b as usize, 1))
    } else {
        let b2 = read_u8(data, offset + 1)?;
        let length = ((b as usize & 0x7F) << 8) | b2 as usize;
        Ok((length, 2))
    }
}

#[inline]
fn bounds_check(data: &[u8], offset: usize, needed: usize) -> Result<()> {
    if offset + needed > data.len() {
        Err(Error::new(ErrorKind::UnexpectedEof))
    } else {
        Ok(())
    }
}

#[inline]
fn read_u8(data: &[u8], offset: usize) -> Result<u8> {
    bounds_check(data, offset, 1)?;
    Ok(data[offset])
}

#[inline]
fn read_u16_le(data: &[u8], offset: usize) -> Result<u16> {
    bounds_check(data, offset, 2)?;
    Ok(u16::from_le_bytes([data[offset], data[offset + 1]]))
}

#[inline]
fn read_u24_le(data: &[u8], offset: usize) -> Result<u32> {
    bounds_check(data, offset, 3)?;
    Ok(data[offset] as u32 | (data[offset + 1] as u32) << 8 | (data[offset + 2] as u32) << 16)
}

#[inline]
fn read_u32_le(data: &[u8], offset: usize) -> Result<u32> {
    bounds_check(data, offset, 4)?;
    Ok(u32::from_le_bytes([
        data[offset],
        data[offset + 1],
        data[offset + 2],
        data[offset + 3],
    ]))
}

/// Skip a single variable-width value starting at `offset` in `data`.
///
/// Reads the tag byte, computes the payload width from the tag alone, and
/// returns the next offset without constructing a `DecodedValue`.
pub(crate) fn skip_value(data: &[u8], offset: usize) -> Result<usize> {
    let tag = read_u8(data, offset)?;
    let offset = offset + 1;

    match tag {
        // Positive integer: literal (0 extra bytes).
        0x00..=0x47 => Ok(offset),

        // Positive integer: 1 extra byte.
        0x48..=0x4F => {
            bounds_check(data, offset, 1)?;
            Ok(offset + 1)
        }

        // Positive integer: 2 extra bytes.
        0x50..=0x57 => {
            bounds_check(data, offset, 2)?;
            Ok(offset + 2)
        }

        // Positive integer: 3 extra bytes.
        0x58..=0x5F => {
            bounds_check(data, offset, 3)?;
            Ok(offset + 3)
        }

        // Negative integer: literal (0 extra bytes).
        0x60..=0x67 => Ok(offset),

        // Negative integer: 1 extra byte.
        0x68..=0x6F => {
            bounds_check(data, offset, 1)?;
            Ok(offset + 1)
        }

        // Negative integer: 2 extra bytes.
        0x70..=0x77 => {
            bounds_check(data, offset, 2)?;
            Ok(offset + 2)
        }

        // Negative integer: 3 extra bytes.
        0x78..=0x7F => {
            bounds_check(data, offset, 3)?;
            Ok(offset + 3)
        }

        // Compact double: zero.
        0x80 => Ok(offset),

        // Compact double: 1 to 7 stored bytes.
        0x81..=0x87 => {
            let byte_count = (tag - 0x80) as usize;
            bounds_check(data, offset, byte_count)?;
            Ok(offset + byte_count)
        }

        // Full double: 8 bytes.
        0x88 => {
            bounds_check(data, offset, 8)?;
            Ok(offset + 8)
        }

        // Scaled decimal.
        0x90..=0x9F => {
            let extra_bytes = ((tag - 0x90) & 0x03) as usize + 1;
            bounds_check(data, offset, extra_bytes)?;
            Ok(offset + extra_bytes)
        }

        // Single-precision float (IEEE 754).
        0xA4 => {
            bounds_check(data, offset, 4)?;
            Ok(offset + 4)
        }

        // Inline string (0 to 62 characters).
        0xC0..=0xFE => {
            let string_length = (tag & 0x3F) as usize;
            bounds_check(data, offset, string_length)?;
            Ok(offset + string_length)
        }

        // Extended string.
        0xFF => {
            let string_length = read_u8(data, offset)? as usize;
            let offset = offset + 1;
            bounds_check(data, offset, string_length)?;
            Ok(offset + string_length)
        }

        // Invalid/unrecognised tags.
        _ => Err(Error::new(ErrorKind::InvalidTag { tag })),
    }
}

/// Trim trailing null bytes and ASCII spaces from a padded text field and
/// convert the remainder to a `String`.
///
/// Text values in sub-records are stored as byte payloads, not validated text
/// records. This helper strips only trailing `0x00` and `0x20` padding bytes,
/// then converts the remainder with `String::from_utf8_lossy` to mirror the
/// codec's permissive payload handling.
fn ascii_string(bytes: &[u8]) -> String {
    let trimmed = bytes
        .iter()
        .rposition(|&b| b != 0 && b != b' ')
        .map_or(&[][..], |last| &bytes[..=last]);
    String::from_utf8_lossy(trimmed).into_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn positive_int_literal_zero() {
        let (val, next) = decode_value(&[0x00], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(0.0));
        assert_eq!(next, 1);
    }

    #[test]
    fn positive_int_literal_max() {
        let (val, next) = decode_value(&[0x47], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(71.0));
        assert_eq!(next, 1);
    }

    #[test]
    fn positive_int_1_extra_byte() {
        // tag=0x48, b1=0x00 → (0 << 8) | 0 = 0.
        let (val, _) = decode_value(&[0x48, 0x00], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(0.0));

        // tag=0x4F, b1=0xFF → (7 << 8) | 255 = 2047.
        let (val, next) = decode_value(&[0x4F, 0xFF], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(2047.0));
        assert_eq!(next, 2);
    }

    #[test]
    fn positive_int_2_extra_bytes() {
        // tag=0x50, u16=100 → 100.
        let (val, next) = decode_value(&[0x50, 0x64, 0x00], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(100.0));
        assert_eq!(next, 3);
    }

    #[test]
    fn positive_int_3_extra_bytes() {
        // tag=0x58, u24=0x010000 → 65536.
        let (val, next) = decode_value(&[0x58, 0x00, 0x00, 0x01], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(65536.0));
        assert_eq!(next, 4);
    }

    #[test]
    fn negative_int_literal_zero() {
        let (val, next) = decode_value(&[0x60], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(-0.0));
        assert_eq!(next, 1);
    }

    #[test]
    fn negative_int_literal_max() {
        let (val, _) = decode_value(&[0x67], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(-7.0));
    }

    #[test]
    fn negative_int_1_extra_byte() {
        // tag=0x68, b1=0x0A → -((0 << 8) | 10) = -10.
        let (val, next) = decode_value(&[0x68, 0x0A], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(-10.0));
        assert_eq!(next, 2);
    }

    #[test]
    fn negative_int_2_extra_bytes() {
        // tag=0x70, u16=1000 → -1000.
        let (val, _) = decode_value(&[0x70, 0xE8, 0x03], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(-1000.0));
    }

    #[test]
    fn negative_int_3_extra_bytes() {
        let (val, _) = decode_value(&[0x78, 0x00, 0x00, 0x01], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(-65536.0));
    }

    #[test]
    fn compact_double_zero() {
        let (val, next) = decode_value(&[0x80], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(0.0));
        assert_eq!(next, 1);
    }

    #[test]
    fn compact_double_100() {
        // 100.0 as f64 LE = [00 00 00 00 00 00 59 40]
        // Compact: tag=0x82, stored=[0x59, 0x40] (2 significant high bytes).
        let (val, next) = decode_value(&[0x82, 0x59, 0x40], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(100.0));
        assert_eq!(next, 3);
    }

    #[test]
    fn compact_double_1_byte() {
        // f64::from_le_bytes([0,0,0,0,0,0,0, 0x40]) = 2.0.
        let (val, _) = decode_value(&[0x81, 0x40], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(2.0));
    }

    #[test]
    fn full_double() {
        let value: f64 = std::f64::consts::PI;
        let bytes = value.to_le_bytes();
        let mut data = vec![0x88];
        data.extend_from_slice(&bytes);
        let (val, next) = decode_value(&data, 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(value));
        assert_eq!(next, 9);
    }

    #[test]
    fn scaled_decimal_div10_1byte() {
        // 0x90, payload=15 → 15/10 = 1.5.
        let (val, next) = decode_value(&[0x90, 0x0F], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(1.5));
        assert_eq!(next, 2);
    }

    #[test]
    fn scaled_decimal_div10_2bytes() {
        // 0x91, u16LE=9999 → 9999/10 = 999.9.
        let (val, next) = decode_value(&[0x91, 0x0F, 0x27], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(999.9));
        assert_eq!(next, 3);
    }

    #[test]
    fn scaled_decimal_div100_1byte() {
        // 0x94, payload=150 → 150/100 = 1.50.
        let (val, _) = decode_value(&[0x94, 0x96], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(1.5));
    }

    #[test]
    fn scaled_decimal_div1000_1byte() {
        // 0x98, payload=1 → 1/1000 = 0.001.
        let (val, _) = decode_value(&[0x98, 0x01], 0).unwrap();
        assert_eq!(val, DecodedValue::Numeric(0.001));
    }

    #[test]
    fn scaled_decimal_div10000_4bytes() {
        // 0x9F, u32LE payload
        // tag=0x9F → scale_index=3 (÷10000), extra_bytes=4.
        let payload: u32 = 123456;
        let bytes = payload.to_le_bytes();
        let data = [0x9F, bytes[0], bytes[1], bytes[2], bytes[3]];
        let (val, next) = decode_value(&data, 0).unwrap();
        assert!((val == DecodedValue::Numeric(12.3456)));
        assert_eq!(next, 5);
    }

    #[test]
    fn single_float() {
        let value: f32 = -3.7;
        let bytes = value.to_le_bytes();
        let data = [0xA4, bytes[0], bytes[1], bytes[2], bytes[3]];
        let (val, next) = decode_value(&data, 0).unwrap();
        if let DecodedValue::Numeric(v) = val {
            assert!((v - (-3.7f32 as f64)).abs() < 1e-6);
        } else {
            panic!("expected numeric");
        }
        assert_eq!(next, 5);
    }

    #[test]
    fn inline_string_empty() {
        let (val, next) = decode_value(&[0xC0], 0).unwrap();
        assert_eq!(val, DecodedValue::String(String::new()));
        assert_eq!(next, 1);
    }

    #[test]
    fn inline_string_5_chars() {
        // "LOCAL".
        let data = [0xC5, b'L', b'O', b'C', b'A', b'L'];
        let (val, next) = decode_value(&data, 0).unwrap();
        assert_eq!(val, DecodedValue::String("LOCAL".to_string()));
        assert_eq!(next, 6);
    }

    #[test]
    fn inline_string_62_chars() {
        // tag=0xFE → 62 chars.
        let mut data = vec![0xFE];
        data.extend(std::iter::repeat_n(b'A', 62));
        let (val, next) = decode_value(&data, 0).unwrap();
        assert_eq!(val, DecodedValue::String("A".repeat(62)));
        assert_eq!(next, 63);
    }

    #[test]
    fn extended_string() {
        // tag=0xFF, length=63.
        let mut data = vec![0xFF, 63];
        data.extend(std::iter::repeat_n(b'B', 63));
        let (val, next) = decode_value(&data, 0).unwrap();
        assert_eq!(val, DecodedValue::String("B".repeat(63)));
        assert_eq!(next, 65);
    }

    #[test]
    fn invalid_tag_0x89() {
        let err = decode_value(&[0x89], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0x89 }));
    }

    #[test]
    fn invalid_tag_0xa0() {
        let err = decode_value(&[0xA0], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0xA0 }));
    }

    #[test]
    fn invalid_tag_0xbf() {
        let err = decode_value(&[0xBF], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0xBF }));
    }

    #[test]
    fn truncated_positive_int_1_extra() {
        let err = decode_value(&[0x48], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn truncated_compact_double() {
        // tag=0x83 needs 3 extra bytes, only 2 provided.
        let err = decode_value(&[0x83, 0x00, 0x00], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn truncated_inline_string() {
        // tag=0xC5 needs 5 chars, only 3 provided.
        let err = decode_value(&[0xC5, b'A', b'B', b'C'], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn empty_data() {
        let err = decode_value(&[], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn sub_record_length_1_byte() {
        let (length, consumed) = read_sub_record_length(&[0x7F], 0).unwrap();
        assert_eq!(length, 127);
        assert_eq!(consumed, 1);
    }

    #[test]
    fn sub_record_length_1_byte_zero() {
        let (length, consumed) = read_sub_record_length(&[0x00], 0).unwrap();
        assert_eq!(length, 0);
        assert_eq!(consumed, 1);
    }

    #[test]
    fn sub_record_length_2_bytes() {
        // b=0x80, b2=0x00 → ((0x80 & 0x7F) << 8) | 0x00 = 0.
        let (length, consumed) = read_sub_record_length(&[0x80, 0x00], 0).unwrap();
        assert_eq!(length, 0);
        assert_eq!(consumed, 2);

        // b=0x81, b2=0x00 → ((0x81 & 0x7F) << 8) | 0x00 = 256.
        let (length, consumed) = read_sub_record_length(&[0x81, 0x00], 0).unwrap();
        assert_eq!(length, 256);
        assert_eq!(consumed, 2);

        // b=0x82, b2=0x58 → ((0x82 & 0x7F) << 8) | 0x58 = 600.
        let (length, consumed) = read_sub_record_length(&[0x82, 0x58], 0).unwrap();
        assert_eq!(length, 600);
        assert_eq!(consumed, 2);
    }

    #[test]
    fn sub_record_length_truncated() {
        let err = read_sub_record_length(&[0x80], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn decode_at_nonzero_offset() {
        let data = [0xFF, 0xFF, 0x05]; // value 5 is at offset 2
        let (val, next) = decode_value(&data, 2).unwrap();
        assert_eq!(val, DecodedValue::Numeric(5.0));
        assert_eq!(next, 3);
    }

    fn numeric_test_cases() -> Vec<Vec<u8>> {
        vec![
            // Positive integer: literal.
            vec![0x00],
            vec![0x47],
            // Positive integer: 1 extra byte.
            vec![0x48, 0x00],
            vec![0x4F, 0xFF],
            // Positive integer: 2 extra bytes.
            vec![0x50, 0x64, 0x00],
            // Positive integer: 3 extra bytes.
            vec![0x58, 0x00, 0x00, 0x01],
            // Negative integer: literal.
            vec![0x60],
            vec![0x67],
            // Negative integer: 1 extra byte.
            vec![0x68, 0x0A],
            // Negative integer: 2 extra bytes.
            vec![0x70, 0xE8, 0x03],
            // Negative integer: 3 extra bytes.
            vec![0x78, 0x00, 0x00, 0x01],
            // Compact double: zero.
            vec![0x80],
            // Compact double: 1 byte.
            vec![0x81, 0x40],
            // Compact double: 2 bytes.
            vec![0x82, 0x59, 0x40],
            // Full double.
            {
                let mut v = vec![0x88];
                v.extend_from_slice(&std::f64::consts::PI.to_le_bytes());
                v
            },
            // Scaled decimal: div10 1 byte.
            vec![0x90, 0x0F],
            // Scaled decimal: div10 2 bytes.
            vec![0x91, 0x0F, 0x27],
            // Scaled decimal: div100 1 byte.
            vec![0x94, 0x96],
            // Scaled decimal: div10000 4 bytes.
            vec![0x9F, 0x40, 0xE2, 0x01, 0x00],
            // Single-precision float.
            {
                let mut v = vec![0xA4];
                v.extend_from_slice(&(-3.7f32).to_le_bytes());
                v
            },
        ]
    }

    fn string_test_cases() -> Vec<Vec<u8>> {
        vec![
            // Inline string: empty.
            vec![0xC0],
            // Inline string: 5 chars.
            vec![0xC5, b'L', b'O', b'C', b'A', b'L'],
            // Extended string: 63 chars.
            {
                let mut v = vec![0xFF, 63];
                v.extend(std::iter::repeat_n(b'B', 63));
                v
            },
        ]
    }

    #[test]
    fn skip_value_matches_decode_value() {
        let mut all_cases = numeric_test_cases();
        all_cases.extend(string_test_cases());

        for (index, data) in all_cases.iter().enumerate() {
            let (_, decode_next) = decode_value(data, 0).unwrap();
            let skip_next = skip_value(data, 0).unwrap();
            assert_eq!(
                decode_next, skip_next,
                "skip_value mismatch at test case {}",
                index,
            );
        }
    }

    #[test]
    fn skip_value_invalid_tag() {
        let err = skip_value(&[0x89], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0x89 }));
    }

    #[test]
    fn skip_value_truncated() {
        let err = skip_value(&[0x48], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::UnexpectedEof));
    }

    #[test]
    fn decode_numeric_value_matches_decode_value() {
        for (index, data) in numeric_test_cases().iter().enumerate() {
            let (decoded, decode_next) = decode_value(data, 0).unwrap();
            let (numeric, numeric_next) = decode_numeric_value(data, 0).unwrap();

            let expected = match decoded {
                DecodedValue::Numeric(v) => v,
                DecodedValue::String(_) => {
                    panic!("expected numeric at test case {}", index)
                }
            };

            assert_eq!(
                numeric.to_bits(),
                expected.to_bits(),
                "value mismatch at test case {}",
                index,
            );
            assert_eq!(
                numeric_next, decode_next,
                "offset mismatch at test case {}",
                index,
            );
        }
    }

    #[test]
    fn decode_string_value_matches_decode_value() {
        for (index, data) in string_test_cases().iter().enumerate() {
            let (decoded, decode_next) = decode_value(data, 0).unwrap();
            let (decoded_string, string_next) = decode_string_value(data, 0).unwrap();

            let expected = match decoded {
                DecodedValue::String(value) => value,
                DecodedValue::Numeric(_) => {
                    panic!("expected string at test case {}", index)
                }
            };

            assert_eq!(
                decoded_string, expected,
                "value mismatch at test case {}",
                index
            );
            assert_eq!(
                string_next, decode_next,
                "offset mismatch at test case {}",
                index,
            );
        }
    }

    #[test]
    fn decode_numeric_value_rejects_inline_string() {
        let data = [0xC5, b'L', b'O', b'C', b'A', b'L'];
        let err = decode_numeric_value(&data, 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0xC5 }));
    }

    #[test]
    fn decode_numeric_value_rejects_extended_string() {
        let data = vec![0xFF, 3, b'A', b'B', b'C'];
        let err = decode_numeric_value(&data, 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0xFF }));
    }

    #[test]
    fn decode_string_value_rejects_numeric_tag() {
        let err = decode_string_value(&[0x00], 0).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidTag { tag: 0x00 }));
    }
}
