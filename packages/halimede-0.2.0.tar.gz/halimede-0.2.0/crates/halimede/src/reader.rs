//! Internal reader for parsing `.net` binary network files.
//!
//! The reader handles record-envelope sequencing, delegates text parsing to
//! [`header`](crate::header) and [`schema`](crate::schema), and decodes binary
//! data records directly into columnar tables.

use std::io::{BufReader, Read};

use crate::decode::{
    decode_numeric_value, decode_string_value, read_sub_record_length, skip_value,
};
use crate::error::{Error, ErrorKind, Result};
use crate::header;
use crate::header::Header;
use crate::network::{Network, NetworkInfo};
use crate::schema::{self, FieldDef, FieldType, Schema};
use crate::spdcap;
use crate::spdcap::LookupTable;
use crate::table::{Column, LinkTable, NodeTable};

/// Reader that parses a `.net` file and materialises it into a [`Network`].
pub(crate) struct Reader<R> {
    source: BufReader<R>,
    source_offset: u64,
}

impl<R: Read> Reader<R> {
    /// Wrap a reader and prepare to parse a `.net` file.
    pub(crate) fn new(source: R) -> Self {
        Self {
            source: BufReader::new(source),
            source_offset: 0,
        }
    }

    /// Parse the complete `.net` file and return a materialised [`Network`].
    pub(crate) fn parse(self) -> Result<Network> {
        self.parse_inner(None, None)
    }

    /// Parse the `.net` file, loading only the named fields.
    ///
    /// Structural columns (N, A, B) are always loaded. Fields not listed in the
    /// corresponding slice are skipped during decoding.
    pub(crate) fn parse_with_fields(
        self,
        node_fields: &[&str],
        link_fields: &[&str],
    ) -> Result<Network> {
        self.parse_inner(Some(node_fields), Some(link_fields))
    }

    /// Parse only the metadata records (banner through LVR) and return a
    /// [`NetworkInfo`] without reading any data records.
    pub(crate) fn parse_info(mut self) -> Result<NetworkInfo> {
        let meta = self.parse_metadata()?;
        Ok(NetworkInfo::from_parts(
            meta.header,
            meta.speed_table,
            meta.capacity_table,
            meta.node_schema,
            meta.link_schema,
        ))
    }

    /// Read records 1-7 (banner, ID, PAR, SPD, CAP, NVR, LVR) and return the
    /// parsed metadata needed for both info-only and full data parsing.
    fn parse_metadata(&mut self) -> Result<Metadata> {
        // 1. Banner.
        let banner_payload = self.read_record("NET")?;
        let banner = header::parse_banner(&banner_payload)?;

        // 2. Run ID.
        let id_payload = self.read_record("ID")?;
        let run_id = header::parse_run_id(&id_payload)?;

        // 3. PAR -> Header.
        let par_payload = self.read_record("PAR")?;
        let header = header::parse_par(&par_payload, banner, run_id)?;

        // 4. SPD.
        let spd_payload = self.read_record("SPD")?;
        self.validate_tag(&spd_payload, b"SPD\0", "SPD")?;
        let speed_table = spdcap::decode_spdcap_record(&spd_payload, true)
            .map_err(|e| Error::at(e.into_kind(), self.source_offset))?;

        // 5. CAP.
        let cap_payload = self.read_record("CAP")?;
        self.validate_tag(&cap_payload, b"CAP\0", "CAP")?;
        let capacity_table = spdcap::decode_spdcap_record(&cap_payload, false)
            .map_err(|e| Error::at(e.into_kind(), self.source_offset))?;

        // 6. NVR (node schema).
        let nvr_payload = self.read_record("NVR")?;
        self.validate_tag(&nvr_payload, b"NVR ", "NVR")?;
        let (node_schema, _) = schema::parse_schema(&nvr_payload, "NVR", 1)?;

        // 7. LVR (link schema).
        let lvr_payload = self.read_record("LVR")?;
        self.validate_tag(&lvr_payload, b"LVR ", "LVR")?;
        let (link_schema, _) = schema::parse_schema(&lvr_payload, "LVR", 2)?;

        Ok(Metadata {
            header,
            speed_table,
            capacity_table,
            node_schema,
            link_schema,
        })
    }

    /// Shared implementation for both full and selective parsing.
    fn parse_inner(
        mut self,
        node_fields: Option<&[&str]>,
        link_fields: Option<&[&str]>,
    ) -> Result<Network> {
        let meta = self.parse_metadata()?;

        // Build field selection bitmasks.
        let node_selection = build_field_selection(&meta.node_schema, node_fields)?;
        let link_selection = build_field_selection(&meta.link_schema, link_fields)?;

        // 8. NOD, decode directly into typed columns.
        let nod_payload = self.read_record("NOD")?;
        self.validate_tag(&nod_payload, b"NOD\0", "NOD")?;
        let (mut node_structural_ids, node_columns, filtered_node_schema) = self
            .decode_data_record(
                &nod_payload[4..],
                DataRecordSpec::new(
                    "NOD",
                    1,
                    &meta.node_schema,
                    meta.header.node_rec_count() as usize,
                    node_selection.as_deref(),
                ),
            )?;
        let node_n = node_structural_ids.swap_remove(0);
        let nodes = NodeTable::from_parts_unchecked(node_n, filtered_node_schema, node_columns);

        // 9. LNK, decode directly into typed columns.
        let lnk_payload = self.read_record("LNK")?;
        self.validate_tag(&lnk_payload, b"LNK\0", "LNK")?;
        let (mut link_structural_ids, link_columns, filtered_link_schema) = self
            .decode_data_record(
                &lnk_payload[4..],
                DataRecordSpec::new(
                    "LNK",
                    2,
                    &meta.link_schema,
                    meta.header.link_count() as usize,
                    link_selection.as_deref(),
                ),
            )?;
        let link_b = link_structural_ids.swap_remove(1);
        let link_a = link_structural_ids.swap_remove(0);
        let links =
            LinkTable::from_parts_unchecked(link_a, link_b, filtered_link_schema, link_columns);

        // 10. END.
        let end_payload = self.read_record("END")?;
        self.validate_tag(&end_payload, b"END\0", "END")?;

        Ok(Network::from_parts_unchecked(
            meta.header,
            meta.speed_table,
            meta.capacity_table,
            nodes,
            links,
        ))
    }

    /// Read one record envelope (4-byte size + payload) and return the payload.
    fn read_record(&mut self, record_name: &'static str) -> Result<Vec<u8>> {
        let mut size_buf = [0u8; 4];
        self.read_exact(&mut size_buf)?;
        let total_size = u32::from_le_bytes(size_buf);

        if total_size < 4 {
            return Err(Error::at(
                ErrorKind::InvalidRecordLength {
                    record: record_name,
                    total_size,
                },
                self.source_offset - 4,
            ));
        }

        let payload_size = (total_size - 4) as usize;
        let mut payload = vec![0u8; payload_size];
        self.read_exact(&mut payload)?;
        Ok(payload)
    }

    /// Read exactly `buf.len()` bytes, tracking the source offset.
    fn read_exact(&mut self, buf: &mut [u8]) -> Result<()> {
        self.source.read_exact(buf).map_err(|e| {
            let kind = if e.kind() == std::io::ErrorKind::UnexpectedEof {
                ErrorKind::UnexpectedEof
            } else {
                ErrorKind::Io(e)
            };
            Error::at(kind, self.source_offset)
        })?;
        self.source_offset += buf.len() as u64;
        Ok(())
    }

    /// Decode a NOD or LNK data record directly into typed column vectors.
    ///
    /// The decoder walks each sub-record row-by-row:
    /// - read the variable-width sub-record length
    /// - decode the structural IDs first
    /// - for each user field, either decode into the selected typed column,
    ///   skip the value entirely, or synthesise the default when the row omits
    ///   trailing default-valued fields
    ///
    /// After the row pass, the helper checks the decoded row count against the
    /// PAR declaration and rebuilds a filtered schema/column set containing
    /// only the selected user fields.
    ///
    /// Returns a vector of structural ID columns, the user-defined [`Column`]
    /// vector, and the rebuilt [`Schema`].
    fn decode_data_record(
        &self,
        data: &[u8],
        spec: DataRecordSpec<'_>,
    ) -> Result<(Vec<Vec<i32>>, Vec<Column>, Schema)> {
        let structural_names = spec.structural_names;

        // Pre-allocate structural ID columns.
        let mut structural_ids: Vec<Vec<i32>> = (0..structural_names.len())
            .map(|_| Vec::with_capacity(spec.expected_row_count))
            .collect();

        let mut user_columns = spec.new_user_columns();

        let mut offset = 0;
        while offset < data.len() {
            let (sub_record_length, length_size) = read_sub_record_length(data, offset)?;
            offset += length_size;

            let sub_record_end = offset + sub_record_length;
            if sub_record_end > data.len() {
                return Err(Error::at(ErrorKind::UnexpectedEof, self.source_offset));
            }

            // Decode structural IDs.
            let mut pos = offset;
            for (index, id_column) in structural_ids.iter_mut().enumerate() {
                let (id_value, next_pos) =
                    decode_structural_id(data, pos, structural_names[index])?;
                pos = next_pos;
                id_column.push(id_value);
            }

            // Decode user fields directly into typed columns.
            for (field_index, column) in user_columns.iter_mut().enumerate() {
                if pos >= sub_record_end {
                    // Trailing-zero elision: fill with the default value for
                    // selected fields only.
                    column.push_default();
                } else if !is_field_selected(spec.selection, field_index) {
                    pos = skip_value(data, pos)?;
                } else {
                    pos = column.decode_selected(data, pos)?;
                }
            }

            offset = sub_record_end;
        }

        let actual_row_count = structural_ids.first().map_or(0, Vec::len);
        if actual_row_count != spec.expected_row_count {
            return Err(Error::new(ErrorKind::RowCountMismatch {
                record: spec.record_name,
                expected_count: spec.expected_row_count,
                actual_count: actual_row_count,
            }));
        }

        let (columns, filtered_schema) = spec.build_output(user_columns);
        Ok((structural_ids, columns, filtered_schema))
    }

    /// Validate that a record payload begins with the expected tag bytes.
    fn validate_tag(&self, payload: &[u8], expected: &[u8], name: &'static str) -> Result<()> {
        if !payload.starts_with(expected) {
            let mut got = [0u8; 4];
            let copy_count = payload.len().min(4);
            got[..copy_count].copy_from_slice(&payload[..copy_count]);
            return Err(Error::at(
                ErrorKind::UnexpectedRecordTag {
                    expected: name,
                    got,
                },
                self.source_offset,
            ));
        }
        Ok(())
    }
}

/// Intermediate state from parsing the first 7 records (banner through LVR).
/// Bundles everything needed to either return a [`NetworkInfo`] or continue
/// decoding data records.
struct Metadata {
    header: Header,
    speed_table: LookupTable,
    capacity_table: LookupTable,
    node_schema: Schema,
    link_schema: Schema,
}

/// Immutable decode plan for one NOD or LNK payload.
///
/// This keeps the hot decode loop small by precomputing which structural names
/// apply, the expected row count from PAR, and the optional field-selection
/// bitset used for selective loading.
struct DataRecordSpec<'a> {
    record_name: &'static str,
    structural_names: &'static [&'static str],
    schema: &'a Schema,
    expected_row_count: usize,
    selection: Option<&'a [bool]>,
}

impl<'a> DataRecordSpec<'a> {
    fn new(
        record_name: &'static str,
        structural_count: usize,
        schema: &'a Schema,
        expected_row_count: usize,
        selection: Option<&'a [bool]>,
    ) -> Self {
        let structural_names = match structural_count {
            1 => &["N"][..],
            2 => &["A", "B"][..],
            _ => unreachable!("unexpected structural field count"),
        };

        Self {
            record_name,
            structural_names,
            schema,
            expected_row_count,
            selection,
        }
    }

    fn new_user_columns(&self) -> Vec<DecodedUserColumn> {
        self.schema
            .fields()
            .iter()
            .enumerate()
            .map(|(field_index, field)| {
                DecodedUserColumn::new(
                    field,
                    is_field_selected(self.selection, field_index),
                    self.expected_row_count,
                )
            })
            .collect()
    }

    fn build_output(self, user_columns: Vec<DecodedUserColumn>) -> (Vec<Column>, Schema) {
        let mut columns = Vec::new();
        let mut filtered_fields = Vec::new();

        for (field, column) in self.schema.fields().iter().zip(user_columns.into_iter()) {
            let Some(column) = column.into_column() else {
                continue;
            };

            let field_index = filtered_fields.len();
            filtered_fields.push(FieldDef::new(
                field.name().to_string(),
                field.field_type().clone(),
                field_index,
            ));
            columns.push(column);
        }

        (columns, Schema::new(filtered_fields))
    }
}

/// Typed accumulator for one user field during NOD/LNK decode.
///
/// `Skipped` preserves schema position without allocating storage for
/// unselected fields. Selected fields accumulate directly into their final
/// typed column vectors.
enum DecodedUserColumn {
    Skipped,
    Numeric {
        name: String,
        values: Vec<f64>,
    },
    String {
        name: String,
        max_size: u16,
        values: Vec<String>,
    },
}

impl DecodedUserColumn {
    fn new(field: &FieldDef, selected: bool, expected_row_count: usize) -> Self {
        if !selected {
            return Self::Skipped;
        }

        match field.field_type() {
            FieldType::Numeric => Self::Numeric {
                name: field.name().to_string(),
                values: Vec::with_capacity(expected_row_count),
            },
            FieldType::String { max_size } => Self::String {
                name: field.name().to_string(),
                max_size: *max_size,
                values: Vec::with_capacity(expected_row_count),
            },
        }
    }

    fn push_default(&mut self) {
        match self {
            Self::Skipped => {}
            Self::Numeric { values, .. } => values.push(0.0),
            Self::String { values, .. } => values.push(String::new()),
        }
    }

    fn decode_selected(&mut self, data: &[u8], offset: usize) -> Result<usize> {
        match self {
            Self::Skipped => Ok(offset),
            Self::Numeric { name, values } => {
                let (value, next_offset) = decode_numeric_value(data, offset)
                    .map_err(|error| map_numeric_field_decode_error(name, error))?;
                values.push(value);
                Ok(next_offset)
            }
            Self::String {
                name,
                max_size,
                values,
            } => {
                let (value, next_offset) = decode_string_value(data, offset)
                    .map_err(|error| map_string_field_decode_error(name, error))?;
                if value.len() > usize::from(*max_size) {
                    return Err(Error::new(ErrorKind::ValueOutOfRange {
                        detail: format!(
                            "field \"{}\" contains {} bytes, which exceeds max_size {}",
                            name,
                            value.len(),
                            max_size
                        ),
                    }));
                }
                values.push(value);
                Ok(next_offset)
            }
        }
    }

    fn into_column(self) -> Option<Column> {
        match self {
            Self::Skipped => None,
            Self::Numeric { values, .. } => Some(Column::Numeric(values)),
            Self::String { values, .. } => Some(Column::String(values)),
        }
    }
}

fn map_numeric_field_decode_error(name: &str, error: Error) -> Error {
    match error.kind() {
        ErrorKind::InvalidTag { tag } if is_string_tag(*tag) => {
            Error::new(ErrorKind::FieldTypeMismatch {
                name: name.to_string(),
                expected: "numeric",
                actual: "string",
            })
        }
        _ => error,
    }
}

fn map_string_field_decode_error(name: &str, error: Error) -> Error {
    match error.kind() {
        ErrorKind::InvalidTag { tag } if is_numeric_tag(*tag) => {
            Error::new(ErrorKind::FieldTypeMismatch {
                name: name.to_string(),
                expected: "string",
                actual: "numeric",
            })
        }
        _ => error,
    }
}

/// Build a field selection bitmask from a list of requested field names.
///
/// Returns `None` if all fields should be loaded (the `field_names` argument is
/// `None`). Returns `Some(bitmask)` when selective loading is requested. Each
/// bit position corresponds to the field's index in the schema.
fn build_field_selection(
    schema: &Schema,
    field_names: Option<&[&str]>,
) -> Result<Option<Box<[bool]>>> {
    let names = match field_names {
        None => return Ok(None),
        Some(names) => names,
    };

    let mut selected = vec![false; schema.field_count()];

    for &name in names {
        let field = schema.find(name).ok_or_else(|| {
            Error::new(ErrorKind::FieldNotFound {
                name: name.to_string(),
            })
        })?;
        selected[field.field_index()] = true;
    }

    Ok(Some(selected.into_boxed_slice()))
}

/// Check whether a field at the given index is selected.
///
/// Returns `true` when `selection` is `None` (all fields selected) or when the
/// bit for `field_index` is set.
#[inline]
fn is_field_selected(selection: Option<&[bool]>, field_index: usize) -> bool {
    match selection {
        None => true,
        Some(selected) => selected.get(field_index).copied().unwrap_or(false),
    }
}

#[inline]
fn is_numeric_tag(tag: u8) -> bool {
    matches!(tag, 0x00..=0x88 | 0x90..=0x9F | 0xA4)
}

#[inline]
fn is_string_tag(tag: u8) -> bool {
    matches!(tag, 0xC0..=0xFF)
}

/// Decode a structural ID (N, A, or B) from the variable-width encoding.
///
/// Returns the ID as `i32` and the offset past the consumed bytes. Uses the
/// specialised numeric decoder since structural IDs are always numeric.
fn decode_structural_id(
    data: &[u8],
    offset: usize,
    field_name: &'static str,
) -> Result<(i32, usize)> {
    let (value, next_offset) = decode_numeric_value(data, offset).map_err(|_| {
        Error::new(ErrorKind::InvalidStructuralId {
            field: field_name,
            detail: "value is not numeric".to_string(),
        })
    })?;

    if !value.is_finite() {
        return Err(Error::new(ErrorKind::InvalidStructuralId {
            field: field_name,
            detail: "value is not finite".to_string(),
        }));
    }
    if value.fract() != 0.0 {
        return Err(Error::new(ErrorKind::InvalidStructuralId {
            field: field_name,
            detail: format!("value {} is not an integer", value),
        }));
    }
    if value <= 0.0 {
        return Err(Error::new(ErrorKind::InvalidStructuralId {
            field: field_name,
            detail: format!("value {} must be greater than 0", value),
        }));
    }
    if value > f64::from(i32::MAX) {
        return Err(Error::new(ErrorKind::InvalidStructuralId {
            field: field_name,
            detail: format!("value {} exceeds i32::MAX", value),
        }));
    }

    Ok((value as i32, next_offset))
}
