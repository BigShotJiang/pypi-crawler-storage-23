//! Variable-width tag encoder for `.net` sub-record payloads.
//!
//! This module encodes `f64` and `String` values into the compact binary
//! tag-value format used in node and link sub-records.

use crate::error::{Error, ErrorKind, Result};

/// Intermediate representation between classification and serialisation.
///
/// Each variant carries its tag byte plus any payload needed for encoding.
/// `classify_numeric` produces one of these, and `encode_numeric` writes it to
/// a buffer.
enum NumericEncoding {
    /// Tag byte is the value itself (0x00..=0x47).
    PositiveIntLiteral(u8),
    /// 1 extra byte (0x48..=0x4F).
    PositiveInt1(u8, u8),
    /// 2 extra bytes (0x50..=0x57).
    PositiveInt2(u8, u16),
    /// 3 extra bytes (0x58..=0x5F).
    PositiveInt3(u8, u32),
    /// Tag byte encodes negated small value (0x60..=0x67).
    NegativeIntLiteral(u8),
    /// 1 extra byte (0x68..=0x6F).
    NegativeInt1(u8, u8),
    /// 2 extra bytes (0x70..=0x77).
    NegativeInt2(u8, u16),
    /// 3 extra bytes (0x78..=0x7F).
    NegativeInt3(u8, u32),
    /// Scaled decimal. Fields are `(tag, payload, extra_bytes)`
    /// where `tag` encodes the divisor and byte count, `payload`
    /// is the scaled integer, and `extra_bytes` is the number of
    /// payload bytes to write (1 to 4).
    ScaledDecimal(u8, u32, usize),
    /// IEEE 754 single-precision float (tag 0xA4).
    Float32(f32),
    /// Compact double: tag 0x80..=0x88 with trailing zero stripping.
    CompactDouble(u8, [u8; 8]),
}

/// Classify a numeric value into its most compact encoding.
///
/// The classification cascade tries each family in order: exact non-negative
/// integers (literal, 1-, 2-, 3-byte), exact negative integers (literal, 1-,
/// 2-, 3-byte), positive scaled decimals (divisors 10, 100, 1000, 10000),
/// lossless float32, and finally compact double as a fallback that handles
/// every remaining value including NaN and infinity.
fn classify_numeric(value: f64) -> NumericEncoding {
    if value.is_finite() && value == value.trunc() {
        if value >= 0.0 {
            let int_value = value as u64;
            if int_value <= 0x47 {
                return NumericEncoding::PositiveIntLiteral(int_value as u8);
            }
            if int_value <= 0x07FF {
                let tag = 0x48 + (int_value >> 8) as u8;
                let b1 = (int_value & 0xFF) as u8;
                return NumericEncoding::PositiveInt1(tag, b1);
            }
            if int_value <= 0x0007_FFFF {
                let tag = 0x50 + (int_value >> 16) as u8;
                let lo = (int_value & 0xFFFF) as u16;
                return NumericEncoding::PositiveInt2(tag, lo);
            }
            if int_value <= 0x07FF_FFFF {
                let tag = 0x58 + (int_value >> 24) as u8;
                let lo = (int_value & 0x00FF_FFFF) as u32;
                return NumericEncoding::PositiveInt3(tag, lo);
            }
        } else {
            let magnitude = (-value) as u64;
            if magnitude <= 7 {
                return NumericEncoding::NegativeIntLiteral(0x60 + magnitude as u8);
            }
            if magnitude <= 0x07FF {
                let tag = 0x68 + (magnitude >> 8) as u8;
                let b1 = (magnitude & 0xFF) as u8;
                return NumericEncoding::NegativeInt1(tag, b1);
            }
            if magnitude <= 0x0007_FFFF {
                let tag = 0x70 + (magnitude >> 16) as u8;
                let lo = (magnitude & 0xFFFF) as u16;
                return NumericEncoding::NegativeInt2(tag, lo);
            }
            if magnitude <= 0x07FF_FFFF {
                let tag = 0x78 + (magnitude >> 24) as u8;
                let lo = (magnitude & 0x00FF_FFFF) as u32;
                return NumericEncoding::NegativeInt3(tag, lo);
            }
        }
    }

    // Scaled decimal: positive fractional values only.
    if value.is_finite() && value > 0.0 {
        let divisors: [(f64, usize); 4] = [(10.0, 0), (100.0, 1), (1000.0, 2), (10000.0, 3)];
        for &(divisor, scale_index) in &divisors {
            let scaled = value * divisor;
            let rounded = scaled.round();
            if (scaled - rounded).abs() < 1e-9 {
                let int_value = rounded as u64;
                let extra_bytes = if int_value <= 0xFF {
                    1
                } else if int_value <= 0xFFFF {
                    2
                } else if int_value <= 0xFF_FFFF {
                    3
                } else if int_value <= 0xFFFF_FFFF {
                    4
                } else {
                    continue;
                };
                let tag = 0x90 | ((scale_index as u8) << 2) | (extra_bytes as u8 - 1);
                return NumericEncoding::ScaledDecimal(tag, int_value as u32, extra_bytes);
            }
        }
    }

    // Float32: check if value round-trips without loss.
    if value.is_finite() {
        let as_f32 = value as f32;
        if as_f32 as f64 == value {
            return NumericEncoding::Float32(as_f32);
        }
    }

    // Compact double: strip trailing LE zero bytes.
    let bytes = value.to_le_bytes();
    let mut sig_count = 8;
    while sig_count > 0 && bytes[8 - sig_count] == 0 {
        sig_count -= 1;
    }
    let tag = 0x80 + sig_count as u8;
    NumericEncoding::CompactDouble(tag, bytes)
}

/// Encode a numeric value using the most compact representation.
///
/// Classifies `value` via `classify_numeric` then writes the tag byte and
/// payload to `buf`. This function is infallible because every `f64` (including
/// NaN, infinity, and negative zero) has a valid compact-double encoding as a
/// fallback. The output round-trips through `decode_value` /
/// `decode_numeric_value`.
pub(crate) fn encode_numeric(value: f64, buf: &mut Vec<u8>) {
    match classify_numeric(value) {
        NumericEncoding::PositiveIntLiteral(tag) => {
            buf.push(tag);
        }
        NumericEncoding::PositiveInt1(tag, b1) => {
            buf.push(tag);
            buf.push(b1);
        }
        NumericEncoding::PositiveInt2(tag, lo) => {
            buf.push(tag);
            buf.extend_from_slice(&lo.to_le_bytes());
        }
        NumericEncoding::PositiveInt3(tag, lo) => {
            buf.push(tag);
            buf.extend_from_slice(&lo.to_le_bytes()[..3]);
        }
        NumericEncoding::NegativeIntLiteral(tag) => {
            buf.push(tag);
        }
        NumericEncoding::NegativeInt1(tag, b1) => {
            buf.push(tag);
            buf.push(b1);
        }
        NumericEncoding::NegativeInt2(tag, lo) => {
            buf.push(tag);
            buf.extend_from_slice(&lo.to_le_bytes());
        }
        NumericEncoding::NegativeInt3(tag, lo) => {
            buf.push(tag);
            buf.extend_from_slice(&lo.to_le_bytes()[..3]);
        }
        NumericEncoding::ScaledDecimal(tag, payload, extra_bytes) => {
            buf.push(tag);
            buf.extend_from_slice(&payload.to_le_bytes()[..extra_bytes]);
        }
        NumericEncoding::Float32(v) => {
            buf.push(0xA4);
            buf.extend_from_slice(&v.to_le_bytes());
        }
        NumericEncoding::CompactDouble(tag, bytes) => {
            buf.push(tag);
            let sig_count = (tag - 0x80) as usize;
            if sig_count > 0 {
                // Stored bytes are the most-significant (rightmost in
                // LE), starting at index 8 - sig_count.
                buf.extend_from_slice(&bytes[8 - sig_count..8]);
            }
        }
    }
}

/// Encode a string value.
///
/// Inline encoding (tag 0xC0..0xFE) for 0 to 62 bytes. Extended encoding (tag
/// 0xFF + length byte) for 63 to 255 bytes. Returns `ValueOutOfRange` for
/// strings exceeding 255 bytes.
pub(crate) fn encode_string(value: &str, buf: &mut Vec<u8>) -> Result<()> {
    let length = value.len();
    if length <= 62 {
        buf.push(0xC0 | length as u8);
        buf.extend_from_slice(value.as_bytes());
    } else if length <= 255 {
        buf.push(0xFF);
        buf.push(length as u8);
        buf.extend_from_slice(value.as_bytes());
    } else {
        return Err(Error::new(ErrorKind::ValueOutOfRange {
            detail: format!("string length {} exceeds maximum of 255 bytes", length),
        }));
    }
    Ok(())
}

/// Encode a sub-record length prefix (1 or 2 bytes).
///
/// Lengths below 128 are stored as a single byte. Lengths of 128 or more are
/// stored as two bytes in big-endian order with the high bit of the first byte
/// set.
pub(crate) fn encode_sub_record_length(length: usize, buf: &mut Vec<u8>) {
    if length < 0x80 {
        buf.push(length as u8);
    } else {
        let hi = ((length >> 8) & 0x7F) as u8 | 0x80;
        let lo = (length & 0xFF) as u8;
        buf.push(hi);
        buf.push(lo);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::decode::{DecodedValue, decode_value, read_sub_record_length};

    fn roundtrip_numeric(value: f64) -> f64 {
        let mut buf = Vec::new();
        encode_numeric(value, &mut buf);
        let (decoded, next) = decode_value(&buf, 0).unwrap();
        assert_eq!(next, buf.len(), "consumed all bytes for {}", value);
        match decoded {
            DecodedValue::Numeric(v) => v,
            DecodedValue::String(_) => {
                panic!("expected numeric for {}", value)
            }
        }
    }

    fn roundtrip_string(value: &str) -> String {
        let mut buf = Vec::new();
        encode_string(value, &mut buf).unwrap();
        let (decoded, next) = decode_value(&buf, 0).unwrap();
        assert_eq!(next, buf.len(), "consumed all bytes for {:?}", value);
        match decoded {
            DecodedValue::String(s) => s,
            DecodedValue::Numeric(_) => {
                panic!("expected string for {:?}", value)
            }
        }
    }

    /// Byte count of the encoded numeric form without writing.
    fn encoded_numeric_size(value: f64) -> usize {
        match classify_numeric(value) {
            NumericEncoding::PositiveIntLiteral(_) => 1,
            NumericEncoding::PositiveInt1(_, _) => 2,
            NumericEncoding::PositiveInt2(_, _) => 3,
            NumericEncoding::PositiveInt3(_, _) => 4,
            NumericEncoding::NegativeIntLiteral(_) => 1,
            NumericEncoding::NegativeInt1(_, _) => 2,
            NumericEncoding::NegativeInt2(_, _) => 3,
            NumericEncoding::NegativeInt3(_, _) => 4,
            NumericEncoding::ScaledDecimal(_, _, extra) => 1 + extra,
            NumericEncoding::Float32(_) => 5,
            NumericEncoding::CompactDouble(tag, _) => 1 + (tag - 0x80) as usize,
        }
    }

    /// Byte count of the encoded string form.
    fn encoded_string_size(value: &str) -> usize {
        let length = value.len();
        if length <= 62 { 1 + length } else { 2 + length }
    }

    /// Byte count of the sub-record length prefix.
    fn sub_record_length_size(length: usize) -> usize {
        if length < 0x80 { 1 } else { 2 }
    }

    #[test]
    fn positive_int_literal_roundtrips() {
        for v in 0..=71 {
            assert_eq!(roundtrip_numeric(v as f64), v as f64);
        }
    }

    #[test]
    fn positive_int_1byte_roundtrips() {
        for v in [72, 100, 255, 1000, 2047] {
            assert_eq!(roundtrip_numeric(v as f64), v as f64);
        }
    }

    #[test]
    fn positive_int_2byte_roundtrips() {
        for v in [2048, 10000, 65535, 524287] {
            assert_eq!(roundtrip_numeric(v as f64), v as f64);
        }
    }

    #[test]
    fn positive_int_3byte_roundtrips() {
        for v in [524288, 1000000, 134217727] {
            assert_eq!(roundtrip_numeric(v as f64), v as f64);
        }
    }

    #[test]
    fn negative_int_literal_roundtrips() {
        for v in 0..=7 {
            let result = roundtrip_numeric(-(v as f64));
            assert_eq!(result, -(v as f64));
        }
    }

    #[test]
    fn negative_int_1byte_roundtrips() {
        for v in [8, 100, 2047] {
            assert_eq!(roundtrip_numeric(-(v as f64)), -(v as f64));
        }
    }

    #[test]
    fn negative_int_2byte_roundtrips() {
        for v in [2048, 65535, 524287] {
            assert_eq!(roundtrip_numeric(-(v as f64)), -(v as f64));
        }
    }

    #[test]
    fn negative_int_3byte_roundtrips() {
        for v in [524288, 1000000] {
            assert_eq!(roundtrip_numeric(-(v as f64)), -(v as f64));
        }
    }

    #[test]
    fn scaled_decimal_div10() {
        assert_eq!(roundtrip_numeric(1.5), 1.5);
        assert_eq!(roundtrip_numeric(999.9), 999.9);
        assert_eq!(roundtrip_numeric(0.1), 0.1);
    }

    #[test]
    fn scaled_decimal_div100() {
        assert_eq!(roundtrip_numeric(1.25), 1.25);
        assert_eq!(roundtrip_numeric(0.01), 0.01);
    }

    #[test]
    fn scaled_decimal_div1000() {
        assert_eq!(roundtrip_numeric(0.001), 0.001);
    }

    #[test]
    fn scaled_decimal_div10000() {
        assert_eq!(roundtrip_numeric(0.0001), 0.0001);
        assert_eq!(roundtrip_numeric(12.3456), 12.3456);
    }

    #[test]
    fn float32_roundtrip() {
        let value = -3.7f32 as f64;
        assert_eq!(roundtrip_numeric(value), value);
    }

    #[test]
    fn compact_double_roundtrip() {
        assert_eq!(roundtrip_numeric(0.0), 0.0);
        assert_eq!(roundtrip_numeric(2.0), 2.0);
        assert_eq!(roundtrip_numeric(100.0), 100.0);
        let pi = std::f64::consts::PI;
        assert_eq!(roundtrip_numeric(pi), pi);
    }

    #[test]
    fn compact_double_nan_and_infinity() {
        let v = roundtrip_numeric(f64::NAN);
        assert!(v.is_nan());
        assert_eq!(roundtrip_numeric(f64::INFINITY), f64::INFINITY);
        assert_eq!(roundtrip_numeric(f64::NEG_INFINITY), f64::NEG_INFINITY);
    }

    #[test]
    fn encoded_numeric_size_matches_actual() {
        let test_values = [
            0.0,
            1.0,
            71.0,
            72.0,
            2047.0,
            2048.0,
            524287.0,
            524288.0,
            -1.0,
            -7.0,
            -8.0,
            -2047.0,
            -2048.0,
            1.5,
            0.001,
            12.3456,
            -3.7f32 as f64,
            std::f64::consts::PI,
            f64::NAN,
            f64::INFINITY,
        ];
        for &v in &test_values {
            let mut buf = Vec::new();
            encode_numeric(v, &mut buf);
            assert_eq!(
                encoded_numeric_size(v),
                buf.len(),
                "size mismatch for {}",
                v
            );
        }
    }

    #[test]
    fn string_empty() {
        assert_eq!(roundtrip_string(""), "");
    }

    #[test]
    fn string_short() {
        assert_eq!(roundtrip_string("LOCAL"), "LOCAL");
    }

    #[test]
    fn string_62_chars() {
        let s = "A".repeat(62);
        assert_eq!(roundtrip_string(&s), s);
    }

    #[test]
    fn string_63_chars() {
        let s = "B".repeat(63);
        assert_eq!(roundtrip_string(&s), s);
    }

    #[test]
    fn string_255_chars() {
        let s = "C".repeat(255);
        assert_eq!(roundtrip_string(&s), s);
    }

    #[test]
    fn string_256_chars_errors() {
        let s = "D".repeat(256);
        let mut buf = Vec::new();
        let err = encode_string(&s, &mut buf).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::ValueOutOfRange { .. }));
    }

    #[test]
    fn encoded_string_size_matches_actual() {
        for length in [0, 1, 62, 63, 128, 255] {
            let s = "X".repeat(length);
            let mut buf = Vec::new();
            encode_string(&s, &mut buf).unwrap();
            assert_eq!(
                encoded_string_size(&s),
                buf.len(),
                "size mismatch for length {}",
                length
            );
        }
    }

    #[test]
    fn sub_record_length_roundtrips() {
        for length in [0, 1, 127, 128, 256, 600, 32767] {
            let mut buf = Vec::new();
            encode_sub_record_length(length, &mut buf);
            let (decoded, consumed) = read_sub_record_length(&buf, 0).unwrap();
            assert_eq!(decoded, length, "length mismatch for {}", length);
            assert_eq!(consumed, buf.len(), "consumed mismatch for {}", length);
        }
    }

    #[test]
    fn sub_record_length_size_matches() {
        for length in [0, 127, 128, 32767] {
            let mut buf = Vec::new();
            encode_sub_record_length(length, &mut buf);
            assert_eq!(
                sub_record_length_size(length),
                buf.len(),
                "size mismatch for {}",
                length
            );
        }
    }

    #[test]
    fn integer_boundary_values() {
        // Boundaries between positive integer tiers.
        assert_eq!(roundtrip_numeric(71.0), 71.0);
        assert_eq!(roundtrip_numeric(72.0), 72.0);
        assert_eq!(roundtrip_numeric(2047.0), 2047.0);
        assert_eq!(roundtrip_numeric(2048.0), 2048.0);
        assert_eq!(roundtrip_numeric(524287.0), 524287.0);
        assert_eq!(roundtrip_numeric(524288.0), 524288.0);
        assert_eq!(roundtrip_numeric(134217727.0), 134217727.0);
    }

    #[test]
    fn large_integer_uses_compact_double() {
        // Value that cannot be encoded as integer, scaled decimal, or
        // float32 falls through to compact double.
        let v = std::f64::consts::E;
        assert_eq!(roundtrip_numeric(v), v);
        let mut buf = Vec::new();
        encode_numeric(v, &mut buf);
        assert!(buf[0] >= 0x80 && buf[0] <= 0x88);
    }

    #[test]
    fn negative_fractional_uses_float32_or_double() {
        // Negative fractional values skip scaled decimal.
        let v = -1.5f32 as f64;
        assert_eq!(roundtrip_numeric(v), v);
    }

    #[test]
    fn zero_encodes_as_positive_int_literal() {
        let mut buf = Vec::new();
        encode_numeric(0.0, &mut buf);
        assert_eq!(buf, [0x00]);
    }

    #[test]
    fn negative_zero_encodes_as_compact_double() {
        let mut buf = Vec::new();
        encode_numeric(-0.0, &mut buf);
        // -0.0 has the sign bit set so it is not equal to its trunc
        // in the positive path. The encoder should handle this.
        let v = roundtrip_numeric(-0.0);
        // Both -0.0 and 0.0 are acceptable since they compare equal.
        assert_eq!(v, 0.0);
    }
}
