//! Header metadata for `.net` binary network files.
//!
//! A [`Header`] is parsed from the opening records of a `.net` file. It
//! captures the banner, run ID, network dimensions (zone count, maximum node
//! ID, link count, node record count), and the left-hand drive flag.

use crate::error::{Error, ErrorKind, Result};

pub(crate) const DEFAULT_BANNER: &str = concat!("NET PGM=HALIMEDE VER=", env!("CARGO_PKG_VERSION"));
pub(crate) const DEFAULT_RUN_ID: &str = "HALIMEDE";

/// Metadata parsed from the opening records of a `.net` file.
///
/// The header captures the banner, run ID, network dimensions, and
/// configuration. Banner values begin with `NET`. Run IDs are exposed without
/// the on-disk `ID=` prefix.
///
/// # Example
///
/// ```
/// use halimede::{NetworkBuilder, NodeTable, LinkTable};
///
/// let nodes = NodeTable::builder().ids(vec![1, 2]).build()?;
/// let links = LinkTable::builder()
///     .endpoints(vec![1], vec![2])
///     .build()?;
/// let net = NetworkBuilder::new()
///     .nodes(nodes)
///     .links(links)
///     .zones(5)
///     .banner("NET PGM=CUSTOM".to_string())
///     .build()?;
///
/// let header = net.header();
/// assert_eq!(header.banner(), "NET PGM=CUSTOM");
/// assert_eq!(header.run_id(), "HALIMEDE");
/// assert_eq!(header.zones(), 5);
/// assert_eq!(header.max_node_id(), 2);
/// assert_eq!(header.link_count(), 1);
/// assert_eq!(header.node_rec_count(), 2);
/// assert!(!header.left_drive());
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct Header {
    pub(crate) banner: String,
    pub(crate) run_id: String,
    pub(crate) zones: u32,
    pub(crate) max_node_id: u32,
    pub(crate) link_count: u32,
    pub(crate) node_rec_count: u32,
    pub(crate) left_drive: bool,
}

impl Header {
    /// Create a new header with the given values.
    pub(crate) fn new(
        banner: String,
        run_id: String,
        zones: u32,
        max_node_id: u32,
        link_count: u32,
        node_rec_count: u32,
        left_drive: bool,
    ) -> Result<Self> {
        Ok(Self {
            banner: normalise_banner(banner)?,
            run_id: normalise_run_id(run_id),
            zones,
            max_node_id,
            link_count,
            node_rec_count,
            left_drive,
        })
    }

    /// The banner string from the first record (e.g. "NET PGM=...").
    #[inline]
    #[must_use]
    pub fn banner(&self) -> &str {
        &self.banner
    }

    /// The run identifier with the `ID=` prefix stripped.
    #[inline]
    #[must_use]
    pub fn run_id(&self) -> &str {
        &self.run_id
    }

    /// The zone count.
    ///
    /// Nodes 1 through `zones` are treated as zone centroids by convention.
    #[inline]
    #[must_use]
    pub fn zones(&self) -> u32 {
        self.zones
    }

    /// The maximum node ID the file can reference.
    ///
    /// This is the maximum node ID, not a count of stored node records. Use
    /// [`crate::NodeTable::row_count`] for the actual number of node records.
    #[inline]
    #[must_use]
    pub fn max_node_id(&self) -> u32 {
        self.max_node_id
    }

    /// The number of link records.
    #[inline]
    #[must_use]
    pub fn link_count(&self) -> u32 {
        self.link_count
    }

    /// The number of node records.
    #[inline]
    #[must_use]
    pub fn node_rec_count(&self) -> u32 {
        self.node_rec_count
    }

    /// Whether the network uses left-hand drive.
    #[inline]
    #[must_use]
    pub fn left_drive(&self) -> bool {
        self.left_drive
    }
}

/// Parse the banner (NET) record payload.
///
/// The payload is a null-terminated ASCII string beginning with "NET". Returns
/// the trimmed banner string.
pub(crate) fn parse_banner(payload: &[u8]) -> Result<String> {
    normalise_banner(null_terminated_str(payload, "NET")?)
}

/// Parse the run ID record payload.
///
/// The payload is a null-terminated string. A leading `ID=` prefix is stripped
/// when present.
pub(crate) fn parse_run_id(payload: &[u8]) -> Result<String> {
    Ok(normalise_run_id(null_terminated_str(payload, "ID")?))
}

/// Parse the PAR record payload and construct a [`Header`].
///
/// `banner` and `run_id` are the previously parsed values from the NET and ID
/// records. The PAR payload provides the network dimensions and the left-hand
/// drive flag.
pub(crate) fn parse_par(payload: &[u8], banner: String, run_id: String) -> Result<Header> {
    let s = null_terminated_str(payload, "PAR")?;
    let s = s.strip_prefix("PAR ").ok_or_else(|| {
        Error::new(ErrorKind::InvalidPar {
            detail: "missing PAR prefix".to_string(),
        })
    })?;

    let mut zones: Option<u32> = None;
    let mut nodes: Option<u32> = None;
    let mut links: Option<u32> = None;
    let mut node_recs: Option<u32> = None;
    let mut left_drive = false;

    for pair in s.split_whitespace() {
        if let Some((key, value)) = pair.split_once('=') {
            match key {
                "Zones" => {
                    zones = Some(value.parse::<u32>().map_err(|_| {
                        Error::new(ErrorKind::InvalidPar {
                            detail: format!("invalid Zones value: {}", value),
                        })
                    })?);
                }
                "Nodes" => {
                    nodes = Some(value.parse::<u32>().map_err(|_| {
                        Error::new(ErrorKind::InvalidPar {
                            detail: format!("invalid Nodes value: {}", value),
                        })
                    })?);
                }
                "Links" => {
                    links = Some(value.parse::<u32>().map_err(|_| {
                        Error::new(ErrorKind::InvalidPar {
                            detail: format!("invalid Links value: {}", value),
                        })
                    })?);
                }
                "NodeRecs" => {
                    node_recs = Some(value.parse::<u32>().map_err(|_| {
                        Error::new(ErrorKind::InvalidPar {
                            detail: format!("invalid NodeRecs value: {}", value),
                        })
                    })?);
                }
                "LeftDrive" => {
                    left_drive = value == "1";
                }
                _ => {}
            }
        }
    }

    let zones = zones.ok_or_else(|| {
        Error::new(ErrorKind::InvalidPar {
            detail: "missing Zones".to_string(),
        })
    })?;
    let max_node_id = nodes.ok_or_else(|| {
        Error::new(ErrorKind::InvalidPar {
            detail: "missing Nodes".to_string(),
        })
    })?;
    let link_count = links.ok_or_else(|| {
        Error::new(ErrorKind::InvalidPar {
            detail: "missing Links".to_string(),
        })
    })?;
    let node_rec_count = node_recs.ok_or_else(|| {
        Error::new(ErrorKind::InvalidPar {
            detail: "missing NodeRecs".to_string(),
        })
    })?;

    Header::new(
        banner,
        run_id,
        zones,
        max_node_id,
        link_count,
        node_rec_count,
        left_drive,
    )
}

pub(crate) fn normalise_banner(banner: impl AsRef<str>) -> Result<String> {
    let banner = banner.as_ref().trim_end().trim_end_matches('\0');
    if !banner.starts_with("NET") {
        return Err(Error::new(ErrorKind::InvalidBanner));
    }
    Ok(banner.to_string())
}

pub(crate) fn normalise_run_id(run_id: impl AsRef<str>) -> String {
    let run_id = run_id.as_ref().trim_end_matches('\0');
    run_id.strip_prefix("ID=").unwrap_or(run_id).to_string()
}

/// Extract a null-terminated UTF-8 string from a byte slice.
///
/// Returns everything before the first null byte. If no null byte is found, the
/// entire slice is used. Invalid UTF-8 is rejected as
/// [`ErrorKind::InvalidTextRecord`] so callers keep the record name in the
/// error.
fn null_terminated_str<'a>(data: &'a [u8], record_name: &'static str) -> Result<&'a str> {
    let end = data.iter().position(|&b| b == 0).unwrap_or(data.len());
    std::str::from_utf8(&data[..end]).map_err(|_| {
        Error::new(ErrorKind::InvalidTextRecord {
            record: record_name,
            detail: "payload is not valid UTF-8".to_string(),
        })
    })
}
