//! Error types for reading and writing `.net` binary network files.
//!
//! An [`std::io::Error`] is automatically converted into an [`Error`] via the
//! [`From`] implementation. As a special case, an I/O error with kind
//! [`std::io::ErrorKind::UnexpectedEof`] is promoted to
//! [`ErrorKind::UnexpectedEof`] rather than being wrapped in [`ErrorKind::Io`],
//! so that premature end-of-file in truncated `.net` files is reported as
//! [`ErrorKind::UnexpectedEof`] rather than a generic I/O error.

use std::fmt;
use std::io;

/// A type alias for `std::result::Result<T, Error>`.
pub type Result<T> = std::result::Result<T, Error>;

/// The error type for all operations in this crate.
///
/// Every error carries an [`ErrorKind`] describing what went wrong. Errors
/// produced while reading a `.net` file also carry a byte offset indicating
/// where in the input the problem was detected. Use [`Error::offset`] to
/// retrieve it.
///
/// The error payload is heap-allocated so that `Result<T, Error>` is
/// pointer-sized.
#[derive(Debug)]
pub struct Error(Box<ErrorInner>);

#[derive(Debug)]
struct ErrorInner {
    kind: ErrorKind,
    offset: Option<u64>,
}

impl Error {
    /// Create an error without a byte offset.
    ///
    /// Used by builders and the `From<io::Error>` conversion.
    pub(crate) fn new(kind: ErrorKind) -> Self {
        Self(Box::new(ErrorInner { kind, offset: None }))
    }

    /// Create an error pinned to a byte offset in the input.
    ///
    /// Used by the reader to record where parsing failed.
    pub(crate) fn at(kind: ErrorKind, offset: u64) -> Self {
        Self(Box::new(ErrorInner {
            kind,
            offset: Some(offset),
        }))
    }

    /// Return the specific kind of this error.
    #[must_use]
    pub fn kind(&self) -> &ErrorKind {
        &self.0.kind
    }

    /// Consume the error and return the underlying [`ErrorKind`].
    #[must_use]
    pub fn into_kind(self) -> ErrorKind {
        self.0.kind
    }

    /// Byte offset in the input where the error was detected, if known.
    ///
    /// Populated by the reader from its current stream position. Not set for
    /// errors produced by the builder.
    #[must_use]
    pub fn offset(&self) -> Option<u64> {
        self.0.offset
    }
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(offset) = self.0.offset {
            write!(f, "at byte offset {}: ", offset)?;
        }
        write!(f, "{}", self.0.kind)
    }
}

impl fmt::Display for ErrorKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ErrorKind::Io(err) => write!(f, "I/O error: {}", err),
            ErrorKind::UnexpectedEof => write!(f, "unexpected end of file"),

            ErrorKind::InvalidRecordLength { record, total_size } => write!(
                f,
                "invalid {} record length: {} bytes (minimum 4)",
                record, total_size
            ),
            ErrorKind::InvalidBanner => {
                write!(f, "invalid or missing banner record")
            }
            ErrorKind::InvalidTextRecord { record, detail } => {
                write!(f, "invalid {} record: {}", record, detail)
            }
            ErrorKind::InvalidPar { detail } => {
                write!(f, "invalid parameter record (PAR): {}", detail)
            }
            ErrorKind::UnexpectedRecordTag { expected, got } => {
                write!(
                    f,
                    "unexpected record tag: expected {}, got \
                     [{:#04X}, {:#04X}, {:#04X}, {:#04X}]",
                    expected, got[0], got[1], got[2], got[3]
                )
            }

            ErrorKind::InvalidSchema { record, detail } => {
                write!(f, "invalid {} schema record: {}", record, detail)
            }

            ErrorKind::InvalidSpdCap { detail } => {
                write!(f, "invalid SPD/CAP table: {}", detail)
            }
            ErrorKind::InvalidRle { detail } => {
                write!(f, "invalid RLE stream: {}", detail)
            }

            ErrorKind::InvalidTag { tag } => {
                write!(f, "invalid tag byte: {:#04X}", tag)
            }
            ErrorKind::SubRecordOverflow {
                declared_size,
                consumed_size,
            } => write!(
                f,
                "sub-record overflow: declared {} bytes, consumed {}",
                declared_size, consumed_size
            ),

            ErrorKind::FieldNotFound { name } => {
                write!(f, "field \"{}\" not found in schema", name)
            }
            ErrorKind::FieldTypeMismatch {
                name,
                expected,
                actual,
            } => write!(
                f,
                "field \"{}\" type mismatch: expected {}, got {}",
                name, expected, actual
            ),
            ErrorKind::InvalidStructuralId { field, detail } => {
                write!(f, "invalid structural ID in \"{}\": {}", field, detail)
            }

            ErrorKind::ColumnLengthMismatch {
                name,
                expected_count,
                actual_count,
            } => write!(
                f,
                "column \"{}\" length mismatch: expected {} rows, got {}",
                name, expected_count, actual_count
            ),
            ErrorKind::MissingStructuralColumn { name } => {
                write!(f, "missing required structural column: \"{}\"", name)
            }
            ErrorKind::RowCountMismatch {
                record,
                expected_count,
                actual_count,
            } => {
                write!(
                    f,
                    "{} row count mismatch: expected {}, got {}",
                    record, expected_count, actual_count
                )
            }

            ErrorKind::DuplicateFieldName { name } => {
                write!(f, "duplicate field name: \"{}\"", name)
            }

            ErrorKind::ReservedFieldName { name } => {
                write!(f, "\"{}\" is a reserved structural field name", name)
            }

            ErrorKind::ValueOutOfRange { detail } => {
                write!(f, "value out of range: {}", detail)
            }
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match &self.0.kind {
            ErrorKind::Io(err) => Some(err),
            _ => None,
        }
    }
}

impl From<io::Error> for Error {
    fn from(err: io::Error) -> Self {
        if err.kind() == io::ErrorKind::UnexpectedEof {
            Error::new(ErrorKind::UnexpectedEof)
        } else {
            Error::new(ErrorKind::Io(err))
        }
    }
}

/// The specific kind of error that occurred.
///
/// This enum is marked `#[non_exhaustive]` so that new variants can be added in
/// future releases without breaking existing code. Match expressions should
/// include a wildcard arm.
#[non_exhaustive]
#[derive(Debug)]
pub enum ErrorKind {
    /// An I/O error from the underlying reader or writer.
    ///
    /// The original [`std::io::Error`] is preserved. Note that I/O errors with
    /// kind [`std::io::ErrorKind::UnexpectedEof`] are promoted to
    /// [`ErrorKind::UnexpectedEof`] instead of appearing here.
    Io(io::Error),

    /// The file ended before a complete record could be read.
    ///
    /// This typically means the file has been truncated. It is also produced
    /// when an [`std::io::Error`] with kind
    /// [`std::io::ErrorKind::UnexpectedEof`] is converted into an [`Error`].
    UnexpectedEof,

    /// A record envelope has an invalid length prefix.
    ///
    /// Every record begins with a four-byte little-endian size that includes
    /// the size field itself, so the minimum valid value is 4.
    InvalidRecordLength {
        /// Which record failed (e.g. "NET", "PAR", "SPD").
        record: &'static str,
        /// The invalid size value that was read.
        total_size: u32,
    },

    /// The banner record is missing or does not begin with `NET`.
    ///
    /// Every `.net` file starts with a banner record whose payload is a
    /// null-terminated ASCII string beginning with `NET`. This error is
    /// returned when parsing malformed file data, or when a builder or setter
    /// is given a banner that does not satisfy the same contract. The banner
    /// typically looks like `"NET PGM=... VER=..."`.
    InvalidBanner,

    /// A text record payload is malformed.
    ///
    /// Text records such as NET, ID, and PAR are null-terminated UTF-8
    /// strings. This error is returned when the payload cannot be decoded or
    /// otherwise violates that contract.
    InvalidTextRecord {
        /// Which record failed (for example "NET" or "ID").
        record: &'static str,
        /// Description of the specific failure.
        detail: String,
    },

    /// The parameter record (PAR) could not be parsed.
    ///
    /// The PAR record declares network dimensions (`Zones`, `Nodes`, `Links`,
    /// `NodeRecs`). This error is returned when the record is missing required
    /// fields or contains unparseable values.
    InvalidPar {
        /// Description of the specific parsing failure.
        detail: String,
    },

    /// A record tag does not match the expected record type.
    ///
    /// Records in a `.net` file must appear in a fixed order. This error is
    /// returned when a record's identifying bytes do not match what was
    /// expected at that position in the file.
    UnexpectedRecordTag {
        /// The record type that was expected (e.g. "NVR", "LVR").
        expected: &'static str,
        /// The first four bytes of the record that was found.
        got: [u8; 4],
    },

    /// A schema record (NVR or LVR) is malformed.
    ///
    /// This is returned when the node variable record or link variable record
    /// cannot be parsed into a valid schema.
    InvalidSchema {
        /// Which schema record failed ("NVR" or "LVR").
        record: &'static str,
        /// Description of the specific parsing failure.
        detail: String,
    },

    /// A SPD or CAP lookup table record is malformed.
    ///
    /// The SPD (speed) and CAP (capacity) records each contain a 9-lane by
    /// 99-class lookup table encoded as RLE-compressed `f64` values. This error
    /// is returned when the record payload cannot be decoded into exactly 891
    /// cells, or when the values are otherwise inconsistent.
    InvalidSpdCap {
        /// Description of the specific failure.
        detail: String,
    },

    /// An RLE-compressed stream is corrupt.
    ///
    /// Several record types (notably SPD/CAP tables and data records) use
    /// run-length encoding to compress sequences of repeated values. This error
    /// is returned when the RLE stream is truncated, contains an invalid run
    /// count, or produces more or fewer values than expected.
    InvalidRle {
        /// Description of the specific failure.
        detail: String,
    },

    /// A tag byte in the variable-width codec is unrecognised.
    ///
    /// This typically indicates file corruption or an unsupported format
    /// version.
    InvalidTag {
        /// The invalid tag byte.
        tag: u8,
    },

    /// A sub-record consumed more bytes than its declared length.
    ///
    /// This indicates a corrupt sub-record length or a decoding error in the
    /// field codec.
    SubRecordOverflow {
        /// The declared sub-record payload size in bytes.
        declared_size: usize,
        /// The number of bytes actually consumed.
        consumed_size: usize,
    },

    /// The requested field name was not found in the schema.
    ///
    /// Field lookup is case-sensitive. This error is produced when a requested
    /// name does not match any field in the schema, and also when a resolved
    /// field handle is reused after a schema mutation.
    FieldNotFound {
        /// The field name that was requested.
        name: String,
    },

    /// A field was accessed with the wrong column type.
    ///
    /// For example, calling `column_f64` on a string field, or `column_str` on
    /// a numeric field.
    FieldTypeMismatch {
        /// The field name.
        name: String,
        /// The type that was requested (e.g. "numeric").
        expected: &'static str,
        /// The actual type of the field (e.g. "string").
        actual: &'static str,
    },

    /// A structural ID is missing, out of range, or not an integer.
    ///
    /// Structural IDs must be positive whole numbers that fit within `i32`.
    /// This error is returned when parsing malformed file data or validating
    /// caller-provided node IDs and link endpoints.
    InvalidStructuralId {
        /// The structural field name ("N", "A", or "B").
        field: &'static str,
        /// Description of the specific failure.
        detail: String,
    },

    /// A column length does not match the table's row count.
    ///
    /// All columns in a table must have the same number of rows, equal to the
    /// length of the structural ID column(s). This error is returned by table
    /// builders and by mutation helpers such as add, replace, and derive when
    /// a supplied column does not match the existing row count.
    ColumnLengthMismatch {
        /// The column name.
        name: String,
        /// The expected number of rows (from the structural ID column).
        expected_count: usize,
        /// The actual number of rows in the mismatched column.
        actual_count: usize,
    },

    /// A required structural column is missing from the builder.
    ///
    /// [`crate::NodeTableBuilder`] requires the `"N"` column (node IDs).
    /// [`crate::LinkTableBuilder`] requires both `"A"` (from-node) and `"B"`
    /// (to-node) columns. This error is returned when
    /// [`build`](crate::NodeTableBuilder::build) is called without first
    /// providing the required structural column(s).
    MissingStructuralColumn {
        /// The name of the missing column (`"N"`, `"A"`, or `"B"`).
        name: &'static str,
    },

    /// A decoded row count does not match the count declared in PAR.
    ///
    /// This error is returned when a NOD or LNK record contains fewer or more
    /// rows than the header declared.
    RowCountMismatch {
        /// Which record failed ("NOD" or "LNK").
        record: &'static str,
        /// The count declared by PAR.
        expected_count: usize,
        /// The number of rows actually decoded.
        actual_count: usize,
    },

    /// A column with the given name already exists in the table.
    ///
    /// Returned by builders and add-column helpers when the caller introduces
    /// the same user-defined field name more than once.
    DuplicateFieldName {
        /// The duplicate field name.
        name: String,
    },

    /// A user-defined column name collides with a reserved structural field
    /// name (`N`, `A`, or `B`).
    ///
    /// Structural fields are managed automatically by the table builders and
    /// table mutation helpers and cannot be used as user-defined column names.
    ReservedFieldName {
        /// The reserved name that was used.
        name: &'static str,
    },

    /// A value is outside the supported `.net` contract.
    ///
    /// String values in the `.net` format are limited to 255 bytes, and
    /// explicit string widths must also fit the supplied data. This error is
    /// returned by builders, mutation helpers, parsing, and encoding when a
    /// value violates those limits or another range-bound contract.
    ValueOutOfRange {
        /// Description of the specific failure.
        detail: String,
    },
}

const _: () = {
    assert!(size_of::<Error>() == size_of::<usize>());
};
