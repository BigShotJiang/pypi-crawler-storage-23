//! Schema types for node and link field definitions.
//!
//! A [`Schema`] is an ordered list of [`FieldDef`] entries describing the
//! user-defined columns in a node or link table. Each field has a [`FieldType`]
//! (numeric or string) and a positional index. Use [`Schema::find`] to look up
//! a field by name, then use [`FieldDef::field_index`] to index into the column
//! vector.

use crate::error::{Error, ErrorKind, Result};

/// What kind of data a field carries.
///
/// # Example
///
/// ```
/// use halimede::FieldType;
///
/// let num = FieldType::Numeric;
/// assert_eq!(format!("{}", num), "numeric");
///
/// let s = FieldType::String { max_size: 20 };
/// assert_eq!(format!("{}", s), "string(max_size=20)");
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FieldType {
    /// A numeric field, exposed as `f64`.
    Numeric,
    /// A string field with a maximum size in bytes.
    String {
        /// Maximum size in bytes.
        max_size: u16,
    },
}

impl std::fmt::Display for FieldType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FieldType::Numeric => write!(f, "numeric"),
            FieldType::String { max_size } => write!(f, "string(max_size={})", max_size),
        }
    }
}

/// A named field in a schema.
///
/// # Example
///
/// ```
/// use halimede::{NodeTable, FieldType};
///
/// let table = NodeTable::builder()
///     .ids(vec![1])
///     .column_f64("SPEED", vec![60.0])
///     .build()?;
///
/// let field = table.schema().find("SPEED").unwrap();
/// assert_eq!(field.name(), "SPEED");
/// assert_eq!(field.field_type(), &FieldType::Numeric);
/// assert_eq!(field.field_index(), 0);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FieldDef {
    name: String,
    field_type: FieldType,
    field_index: usize,
}

impl FieldDef {
    /// Create a new field definition.
    pub(crate) fn new(name: String, field_type: FieldType, field_index: usize) -> Self {
        Self {
            name,
            field_type,
            field_index,
        }
    }

    /// The field's name.
    #[inline]
    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    /// The type of data this field carries.
    #[inline]
    #[must_use]
    pub fn field_type(&self) -> &FieldType {
        &self.field_type
    }

    /// The 0-based position of this field in the schema.
    #[inline]
    #[must_use]
    pub fn field_index(&self) -> usize {
        self.field_index
    }
}

/// An ordered list of field definitions describing the columns in a node or
/// link table.
///
/// The field list is immutable after construction. Use [`Schema::find`] to look
/// up a field by name, then use the returned [`FieldDef::field_index`] to index
/// into the corresponding column vector.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Schema {
    fields: Vec<FieldDef>,
}

impl Schema {
    /// Create a new schema from `(name, field_type)` pairs.
    ///
    /// Field indices are assigned in declaration order. String field widths are
    /// validated to ensure they are within `1..=255` bytes.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::DuplicateFieldName`] if the same name appears more
    /// than once, or [`ErrorKind::ValueOutOfRange`] if a string field declares
    /// an invalid `max_size`.
    pub fn from_fields<Fields, Name>(fields: Fields) -> Result<Self>
    where
        Fields: IntoIterator<Item = (Name, FieldType)>,
        Name: Into<String>,
    {
        let mut schema_fields = Vec::new();
        for (field_index, (name, field_type)) in fields.into_iter().enumerate() {
            let name = name.into();
            if schema_fields
                .iter()
                .any(|field: &FieldDef| field.name == name)
            {
                return Err(Error::new(ErrorKind::DuplicateFieldName { name }));
            }

            if let FieldType::String { max_size } = &field_type {
                if *max_size == 0 || *max_size > 255 {
                    return Err(Error::new(ErrorKind::ValueOutOfRange {
                        detail: format!(
                            "string field {:?} declares max_size {}, but valid values are 1..=255",
                            name, max_size
                        ),
                    }));
                }
            }

            schema_fields.push(FieldDef::new(name, field_type, field_index));
        }

        Ok(Self {
            fields: schema_fields,
        })
    }

    /// Create a new schema from the given field definitions.
    pub(crate) fn new(fields: Vec<FieldDef>) -> Self {
        Self { fields }
    }

    /// Append a field definition.
    pub(crate) fn push_field(&mut self, field: FieldDef) {
        self.fields.push(field);
    }

    /// Remove the field at the given index and re-number subsequent fields.
    pub(crate) fn remove_field(&mut self, field_index: usize) {
        self.fields.remove(field_index);
        for (position, field) in self.fields[field_index..].iter_mut().enumerate() {
            field.field_index = field_index + position;
        }
    }

    /// Replace the type metadata for the field at the given index.
    pub(crate) fn update_field_type(&mut self, field_index: usize, field_type: FieldType) {
        self.fields[field_index].field_type = field_type;
    }

    /// The field definitions in declaration order.
    #[inline]
    #[must_use]
    pub fn fields(&self) -> &[FieldDef] {
        &self.fields
    }

    /// The number of fields in this schema.
    #[inline]
    #[must_use]
    pub fn field_count(&self) -> usize {
        self.fields.len()
    }

    /// The field names in declaration order.
    pub fn field_names(&self) -> impl Iterator<Item = &str> {
        self.fields.iter().map(|f| f.name.as_str())
    }

    /// Look up a field by name (case-sensitive).
    ///
    /// Returns `None` if no field with the given name exists.
    #[must_use]
    pub fn find(&self, name: &str) -> Option<&FieldDef> {
        self.fields.iter().find(|f| f.name == name)
    }
}

/// Parse a NVR or LVR schema record payload.
///
/// `structural_count` is the number of leading structural fields to skip (1 for
/// NVR, 2 for LVR).
///
/// Returns `(schema, total_field_count_including_structural)`.
pub(crate) fn parse_schema(
    payload: &[u8],
    record_name: &'static str,
    structural_count: usize,
) -> Result<(Schema, usize)> {
    // Tag: "NVR " or "LVR " (4 bytes with trailing space).
    if payload.len() < 4 {
        return Err(Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: "payload too short".to_string(),
        }));
    }

    let text = &payload[4..];

    // Payload is null-separated: field_count then field names.
    let parts: Vec<&[u8]> = text.split(|&b| b == 0).collect();

    // First part is the field count as ASCII decimal.
    if parts.is_empty() {
        return Err(Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: "empty schema payload".to_string(),
        }));
    }

    let count_str = std::str::from_utf8(parts[0]).map_err(|_| {
        Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: "invalid field count encoding".to_string(),
        })
    })?;

    let declared_count: usize = count_str.trim().parse().map_err(|_| {
        Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: format!("invalid field count: \"{}\"", count_str),
        })
    })?;

    // Collect non-empty field names from the remaining parts.
    let mut field_names = Vec::new();
    for part in &parts[1..] {
        if part.is_empty() {
            continue;
        }
        let field_name = std::str::from_utf8(part).map_err(|_| {
            Error::new(ErrorKind::InvalidSchema {
                record: record_name,
                detail: "invalid field name encoding".to_string(),
            })
        })?;
        if field_name.is_empty() {
            continue;
        }
        field_names.push(field_name);
    }

    if field_names.len() != declared_count {
        return Err(Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: format!(
                "declared {} fields but found {}",
                declared_count,
                field_names.len()
            ),
        }));
    }

    if declared_count < structural_count {
        return Err(Error::new(ErrorKind::InvalidSchema {
            record: record_name,
            detail: format!(
                "declared {} fields but expected at least {} structural fields",
                declared_count, structural_count
            ),
        }));
    }

    // Skip structural fields, build schema from the rest.
    let user_field_names = &field_names[structural_count..];
    let mut fields = Vec::with_capacity(user_field_names.len());

    for (index, &name) in user_field_names.iter().enumerate() {
        let (field_name, field_type) = if let Some((base, size_str)) = name.split_once('=') {
            let max_size: u16 = size_str.parse().map_err(|_| {
                Error::new(ErrorKind::InvalidSchema {
                    record: record_name,
                    detail: format!(
                        "invalid string size for field \"{}\": \"{}\"",
                        base, size_str
                    ),
                })
            })?;
            if base.is_empty() {
                return Err(Error::new(ErrorKind::InvalidSchema {
                    record: record_name,
                    detail: "string field name is empty".to_string(),
                }));
            }
            if max_size == 0 || max_size > 255 {
                return Err(Error::new(ErrorKind::InvalidSchema {
                    record: record_name,
                    detail: format!("invalid string size for field \"{}\": {}", base, max_size),
                }));
            }
            (base.to_string(), FieldType::String { max_size })
        } else {
            (name.to_string(), FieldType::Numeric)
        };

        fields.push(FieldDef::new(field_name, field_type, index));
    }

    Ok((Schema::new(fields), declared_count))
}
