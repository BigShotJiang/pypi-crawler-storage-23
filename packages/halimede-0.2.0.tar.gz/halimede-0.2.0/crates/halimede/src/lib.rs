//! Read and write `.net` binary network files.
//!
//! `halimede` provides an in-memory, columnar API for directed graph networks
//! stored in the `.net` binary format. [`Network`] is the main entry point for
//! full-file reads, table edits, and writes. [`NetworkInfo`] exposes header
//! metadata and schemas without materialising row data.
//!
//! The crate is intentionally columnar-first:
//! - structural IDs (`N`, `A`, `B`) are exposed as `i32`
//! - all decoded numeric field values are exposed as [`f64`]
//! - user-defined data lives in [`NodeTable`] and [`LinkTable`]
//! - edits happen by working with whole columns or typed field handles, not
//!   per-row public objects
//!
//! Primary workflows:
//! - inspect schemas up front with [`NetworkInfo`]
//! - load the whole network with [`Network::open`] or [`Network::from_bytes`]
//! - load only selected user fields with [`Network::open_fields`] or
//!   [`Network::from_bytes_fields`]
//! - edit node and link tables in memory, then write with
//!   [`Network::write_to`] or [`Network::write_to_writer`]
//!
//! # Reading
//!
//! ```
//! # use halimede::{NetworkBuilder, NodeTable, LinkTable};
//! # let nodes = NodeTable::builder()
//! #     .ids(vec![1, 2, 3])
//! #     .column_f64("X", vec![320000.0, 320100.0, 320200.0])
//! #     .build()?;
//! # let links = LinkTable::builder()
//! #     .endpoints(vec![1, 2], vec![2, 3])
//! #     .column_f64("SPEED", vec![60.0, 80.0])
//! #     .build()?;
//! # let net = NetworkBuilder::new()
//! #     .nodes(nodes)
//! #     .links(links)
//! #     .zones(1)
//! #     .build()?;
//! // Structural IDs.
//! let ids: &[i32] = net.nodes().ids();
//! let a: &[i32] = net.links().a();
//! let b: &[i32] = net.links().b();
//!
//! // Numeric field access.
//! let speed: &[f64] = net.links().column_f64("SPEED")?;
//!
//! // Schema introspection.
//! for field in net.links().schema().fields() {
//!     println!("{}: {:?}", field.name(), field.field_type());
//! }
//! # Ok::<(), halimede::Error>(())
//! ```
//!
//! # Inspecting Schemas And Selective Loading
//!
//! ```
//! # use halimede::{LinkTable, Network, NetworkBuilder, NetworkInfo, NodeTable};
//! # let source = NetworkBuilder::new()
//! #     .nodes(
//! #         NodeTable::builder()
//! #             .ids(vec![1, 2])
//! #             .column_f64("X", vec![10.0, 20.0])
//! #             .column_f64("Y", vec![1.0, 2.0])
//! #             .build()?,
//! #     )
//! #     .links(
//! #         LinkTable::builder()
//! #             .endpoints(vec![1], vec![2])
//! #             .column_f64("SPEED", vec![60.0])
//! #             .build()?,
//! #     )
//! #     .build()?;
//! # let bytes = source.to_bytes()?;
//! let info = NetworkInfo::from_bytes(&bytes)?;
//! let node_fields: Vec<&str> = info.node_schema().field_names().collect();
//! assert_eq!(node_fields, vec!["X", "Y"]);
//!
//! let net = Network::from_bytes_fields(&bytes, ["X"], ["SPEED"])?;
//! assert_eq!(net.nodes().column_f64("X")?, &[10.0, 20.0]);
//! assert!(net.nodes().column_f64("Y").is_err());
//! # Ok::<(), halimede::Error>(())
//! ```
//!
//! # Editing
//!
//! ```
//! # use halimede::{LinkTable, Network, NetworkBuilder, NodeTable};
//! # let source = NetworkBuilder::new()
//! #     .nodes(
//! #         NodeTable::builder()
//! #             .ids(vec![1, 2])
//! #             .column_f64("X", vec![10.0, 20.0])
//! #             .column_f64("Y", vec![1.0, 2.0])
//! #             .build()?,
//! #     )
//! #     .links(LinkTable::builder().endpoints(vec![1], vec![2]).build()?)
//! #     .build()?;
//! # let bytes = source.to_bytes()?;
//! let mut net = Network::from_bytes_fields(&bytes, ["X", "Y"], std::iter::empty::<&str>())?;
//!
//! let nodes = net.nodes_mut();
//! nodes.remove_fields(["Y"])?;
//!
//! // Resolve handles after the last schema mutation.
//! let x = nodes.resolve_field("X")?;
//! nodes.derive_column_f64("X2", |table, row_index| {
//!     Ok(table.column_f64_field(&x)?[row_index] * 2.0)
//! })?;
//!
//! let mut out = Vec::new();
//! net.write_to_writer(&mut out)?;
//! # assert!(!out.is_empty());
//! # Ok::<(), halimede::Error>(())
//! ```
//!
//! # Writing
//!
//! ```
//! # use halimede::{NetworkBuilder, NodeTable, LinkTable};
//! let nodes = NodeTable::builder()
//!     .ids(vec![1, 2])
//!     .build()?;
//! let links = LinkTable::builder()
//!     .endpoints(vec![1], vec![2])
//!     .column_f64("SPEED", vec![60.0])
//!     .build()?;
//! let net = NetworkBuilder::new()
//!     .nodes(nodes)
//!     .links(links)
//!     .build()?;
//!
//! let mut bytes = Vec::new();
//! net.write_to_writer(&mut bytes)?;
//! # Ok::<(), halimede::Error>(())
//! ```
//!
//! # Errors
//!
//! Fallible operations return [`Result`]. Inspect failures via [`Error::kind`]
//! and match on [`ErrorKind`]. [`ErrorKind`] is non-exhaustive, so include a
//! wildcard arm for forward compatibility.
//!
//! String field widths are validated against encoded byte length, banner values
//! must begin with `NET`, and run IDs are exposed without the on-disk `ID=`
//! prefix.

mod error;
mod header;
mod network;
mod schema;
mod spdcap;
mod table;

mod decode;
mod encode;
mod reader;
mod writer;

pub use crate::error::{Error, ErrorKind, Result};
pub use crate::header::Header;
pub use crate::network::{Network, NetworkBuilder, NetworkInfo, NetworkMetadata};
pub use crate::schema::{FieldDef, FieldType, Schema};
pub use crate::spdcap::{LookupTable, SPDCAP_CELLS, SPDCAP_CLASSES, SPDCAP_LANES};
pub use crate::table::{
    Column, LinkField, LinkTable, LinkTableBuilder, NodeField, NodeTable, NodeTableBuilder,
};
