//! SPD/CAP lookup tables for speed and capacity class mappings.
//!
//! Each `.net` file contains a speed (SPD) and capacity (CAP) lookup table,
//! each a 9-lane by 99-class grid of `f64` values. Most files contain only the
//! defaults (speed class `k` maps to `k`, capacity class `k` maps to `20 * k`).

use std::sync::LazyLock;

use crate::error::{Error, ErrorKind, Result};

static DEFAULT_SPEED_VALUES: LazyLock<[f64; SPDCAP_CELLS]> = LazyLock::new(|| {
    let mut values = [0.0; SPDCAP_CELLS];
    for lane in 0..SPDCAP_LANES {
        for class in 0..SPDCAP_CLASSES {
            values[lane * SPDCAP_CLASSES + class] = (class + 1) as f64;
        }
    }
    values
});

static DEFAULT_CAPACITY_VALUES: LazyLock<[f64; SPDCAP_CELLS]> = LazyLock::new(|| {
    let mut values = [0.0; SPDCAP_CELLS];
    for lane in 0..SPDCAP_LANES {
        for class in 0..SPDCAP_CLASSES {
            values[lane * SPDCAP_CLASSES + class] = ((class + 1) * 20) as f64;
        }
    }
    values
});

/// Number of lane groups in the lookup table (lanes 1 through 9).
pub const SPDCAP_LANES: usize = 9;

/// Number of classes in the lookup table (classes 1 through 99).
pub const SPDCAP_CLASSES: usize = 99;

/// Total number of cells in the lookup table (9 lanes x 99 classes).
pub const SPDCAP_CELLS: usize = SPDCAP_LANES * SPDCAP_CLASSES;

/// A 9-lane by 99-class lookup table for speed or capacity class mappings.
///
/// Use [`get`](LookupTable::get) to look up values by 1-based lane and class
/// indices. The flat representation from [`as_slice`](LookupTable::as_slice) is
/// in lane-major order.
///
/// # Example
///
/// ```
/// use halimede::{NetworkBuilder, NodeTable, LinkTable};
///
/// let net = NetworkBuilder::new()
///     .nodes(NodeTable::builder().ids(vec![1, 2]).build()?)
///     .links(
///         LinkTable::builder()
///             .endpoints(vec![1], vec![2])
///             .build()?,
///     )
///     .build()?;
///
/// let spd = net.speed_table();
/// assert!(spd.is_default_speed());
/// assert_eq!(spd.get(1, 45), 45.0);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct LookupTable {
    values: [f64; SPDCAP_CELLS],
}

impl LookupTable {
    /// Create a lookup table from a flat array of values in lane-major
    /// order.
    ///
    /// The array is laid out lane-major: indices `0..99` are classes 1-99
    /// for lane 1, indices `99..198` are classes 1-99 for lane 2, and so
    /// on through lane 9. The total length is
    /// [`SPDCAP_CELLS`] (9 x 99 = 891).
    pub fn from_values(values: [f64; SPDCAP_CELLS]) -> Self {
        Self { values }
    }

    /// Create the default speed lookup table.
    ///
    /// Default speed: for every lane group, class `k` maps to value `k` (i.e.
    /// speed class 1 = 1, speed class 45 = 45, etc.). All 9 lane rows are
    /// identical.
    #[must_use]
    pub fn default_speed() -> Self {
        Self {
            values: *DEFAULT_SPEED_VALUES,
        }
    }

    /// Create the default capacity lookup table.
    ///
    /// Default capacity: for every lane group, class `k` maps to value `20 * k`
    /// (i.e. capacity class 1 = 20, capacity class 45 = 900, etc.). All 9 lane
    /// rows are identical.
    #[must_use]
    pub fn default_capacity() -> Self {
        Self {
            values: *DEFAULT_CAPACITY_VALUES,
        }
    }

    /// Look up a value by lane count (1-9) and class (1-99).
    ///
    /// Returns `0.0` for out-of-range inputs.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{NetworkBuilder, NodeTable, LinkTable};
    ///
    /// let net = NetworkBuilder::new()
    ///     .nodes(NodeTable::builder().ids(vec![1, 2]).build()?)
    ///     .links(
    ///         LinkTable::builder()
    ///             .endpoints(vec![1], vec![2])
    ///             .build()?,
    ///     )
    ///     .build()?;
    ///
    /// // Default speed: class k maps to k.
    /// assert_eq!(net.speed_table().get(1, 10), 10.0);
    /// // Out-of-range returns 0.0.
    /// assert_eq!(net.speed_table().get(0, 1), 0.0);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    #[inline]
    #[must_use]
    pub fn get(&self, lanes: u8, class: u8) -> f64 {
        if lanes == 0 || lanes > SPDCAP_LANES as u8 || class == 0 || class > SPDCAP_CLASSES as u8 {
            return 0.0;
        }
        self.values[(lanes as usize - 1) * SPDCAP_CLASSES + (class as usize - 1)]
    }

    /// Access the full 9x99 grid as a flat slice in lane-major order.
    #[inline]
    #[must_use]
    pub fn as_slice(&self) -> &[f64; SPDCAP_CELLS] {
        &self.values
    }

    /// Consume the lookup table and return the flat lane-major values.
    #[inline]
    #[must_use]
    pub fn into_values(self) -> [f64; SPDCAP_CELLS] {
        self.values
    }

    /// Iterate rows (one per lane group, each containing 99 class values).
    pub fn rows(&self) -> impl Iterator<Item = &[f64]> {
        self.values.chunks(SPDCAP_CLASSES)
    }

    /// Mutable access to the full 9x99 grid as a flat slice in
    /// lane-major order.
    #[inline]
    pub fn as_slice_mut(&mut self) -> &mut [f64; SPDCAP_CELLS] {
        &mut self.values
    }

    /// Set a single cell by lane count (1-9) and class (1-99).
    ///
    /// Out-of-range inputs are silently ignored.
    #[inline]
    pub fn set(&mut self, lanes: u8, class: u8, value: f64) {
        if lanes == 0 || lanes > SPDCAP_LANES as u8 || class == 0 || class > SPDCAP_CLASSES as u8 {
            return;
        }
        self.values[(lanes as usize - 1) * SPDCAP_CLASSES + (class as usize - 1)] = value;
    }

    /// Returns `true` if this table matches the default speed table
    /// (class `k` maps to `k` for all lane groups).
    #[inline]
    #[must_use]
    pub fn is_default_speed(&self) -> bool {
        self.values == *DEFAULT_SPEED_VALUES
    }

    /// Returns `true` if this table matches the default capacity table
    /// (class `k` maps to `20 * k` for all lane groups).
    #[inline]
    #[must_use]
    pub fn is_default_capacity(&self) -> bool {
        self.values == *DEFAULT_CAPACITY_VALUES
    }
}

/// Decode an RLE-compressed byte stream, producing exactly `expected_count`
/// values.
///
/// Returns `(values, bytes_consumed)` starting from `offset` in `data`.
pub(crate) fn decode_rle(
    data: &[u8],
    mut offset: usize,
    expected_count: usize,
) -> Result<(Vec<u8>, usize)> {
    let start = offset;
    let mut output = Vec::with_capacity(expected_count);

    while output.len() < expected_count {
        if offset + 2 > data.len() {
            return Err(Error::new(ErrorKind::InvalidRle {
                detail: format!(
                    "truncated RLE header at offset {}: need 2 bytes, have {}",
                    offset,
                    data.len().saturating_sub(offset)
                ),
            }));
        }

        let count_lo = data[offset] as usize;
        let byte2 = data[offset + 1] as usize;
        offset += 2;

        if byte2 & 0x80 != 0 {
            // Constant run.
            let count = count_lo | ((byte2 & 0x7F) << 8);
            if offset >= data.len() {
                return Err(Error::new(ErrorKind::InvalidRle {
                    detail: "truncated constant run: missing value byte".to_string(),
                }));
            }
            let value = data[offset];
            offset += 1;
            for _ in 0..count {
                output.push(value);
            }
        } else {
            // Literal run.
            let count = count_lo | (byte2 << 8);
            if offset + count > data.len() {
                return Err(Error::new(ErrorKind::InvalidRle {
                    detail: format!(
                        "truncated literal run at offset {}: need {} bytes, have {}",
                        offset,
                        count,
                        data.len().saturating_sub(offset)
                    ),
                }));
            }
            output.extend_from_slice(&data[offset..offset + count]);
            offset += count;
        }
    }

    if output.len() != expected_count {
        return Err(Error::new(ErrorKind::InvalidRle {
            detail: format!(
                "RLE produced {} values, expected {}",
                output.len(),
                expected_count
            ),
        }));
    }

    Ok((output, offset - start))
}

/// Decode a SPD or CAP record payload into a [`LookupTable`].
///
/// `payload` is the full record payload (after the 4-byte envelope size),
/// including the `SPD\0` or `CAP\0` tag bytes. The decoder skips the outer tag,
/// reads the embedded little-endian sub-record length for framing only,
/// validates the fixed `[0x20, 0x80, 0xC0]` header, then decodes the low-byte
/// and high-byte RLE streams into 891 internal `u16` cells. `is_speed`
/// selects the final scaling: SPD values are divided by 10.0, CAP values are
/// used directly.
pub(crate) fn decode_spdcap_record(payload: &[u8], is_speed: bool) -> Result<LookupTable> {
    // Skip 4-byte tag (SPD\0 or CAP\0).
    if payload.len() < 4 {
        return Err(Error::new(ErrorKind::InvalidSpdCap {
            detail: "payload too short for tag".to_string(),
        }));
    }
    let data = &payload[4..];

    // Read u16 LE sub-record length.
    if data.len() < 2 {
        return Err(Error::new(ErrorKind::InvalidSpdCap {
            detail: "payload too short for sub-record length".to_string(),
        }));
    }
    let _sub_length = u16::from_le_bytes([data[0], data[1]]) as usize;
    let data = &data[2..];

    // Validate 3-byte header: [0x20, 0x80, 0xC0].
    if data.len() < 3 {
        return Err(Error::new(ErrorKind::InvalidSpdCap {
            detail: "payload too short for header".to_string(),
        }));
    }
    if data[0] != 0x20 || data[1] != 0x80 || data[2] != 0xC0 {
        return Err(Error::new(ErrorKind::InvalidSpdCap {
            detail: format!(
                "invalid header bytes: [{:#04X}, {:#04X}, {:#04X}], expected [0x20, 0x80, 0xC0]",
                data[0], data[1], data[2]
            ),
        }));
    }

    let mut offset = 3;

    // Decode low-byte RLE stream (891 values).
    let (low_bytes, consumed) = decode_rle(data, offset, SPDCAP_CELLS)?;
    offset += consumed;

    // Decode high-byte RLE stream (891 values).
    let (high_bytes, _consumed) = decode_rle(data, offset, SPDCAP_CELLS)?;

    // Reconstruct values.
    let mut values = [0.0f64; SPDCAP_CELLS];
    for index in 0..SPDCAP_CELLS {
        let internal = high_bytes[index] as u16 * 256 + low_bytes[index] as u16;
        values[index] = if is_speed {
            internal as f64 / 10.0
        } else {
            internal as f64
        };
    }

    Ok(LookupTable::from_values(values))
}

/// RLE-encode a byte slice using a greedy strategy.
///
/// Constant runs of 3 or more identical bytes are stored as constant runs. All
/// other sequences are stored as literal runs.
pub(crate) fn encode_rle(data: &[u8]) -> Vec<u8> {
    let mut output = Vec::with_capacity(data.len());
    let mut pos = 0;

    while pos < data.len() {
        // Count consecutive identical bytes.
        let run_value = data[pos];
        let mut run_count = 1;
        while pos + run_count < data.len()
            && data[pos + run_count] == run_value
            && run_count < 0x7FFF
        {
            run_count += 1;
        }

        if run_count >= 3 {
            // Constant run.
            let count_lo = (run_count & 0xFF) as u8;
            let byte2 = ((run_count >> 8) as u8) | 0x80;
            output.push(count_lo);
            output.push(byte2);
            output.push(run_value);
            pos += run_count;
        } else {
            // Literal run: gather bytes until we hit a constant run of 3+
            // or reach the end.
            let lit_start = pos;
            while pos < data.len() {
                let remaining = data.len() - pos;
                if remaining >= 3 && data[pos] == data[pos + 1] && data[pos] == data[pos + 2] {
                    break;
                }
                pos += 1;
                if pos - lit_start >= 0x7FFF {
                    break;
                }
            }
            let lit_count = pos - lit_start;
            let count_lo = (lit_count & 0xFF) as u8;
            let byte2 = (lit_count >> 8) as u8;
            output.push(count_lo);
            output.push(byte2);
            output.extend_from_slice(&data[lit_start..pos]);
        }
    }

    output
}

/// Encode a complete SPD or CAP record payload.
///
/// Returns the full record payload including the tag bytes. `is_speed` selects
/// the value conversion: SPD values are multiplied by 10 to get the internal
/// u16, CAP values are used directly.
pub(crate) fn encode_spdcap_record(table: &LookupTable, is_speed: bool) -> Vec<u8> {
    // Convert f64 values to u16 internal representation.
    let mut low_bytes = [0u8; SPDCAP_CELLS];
    let mut high_bytes = [0u8; SPDCAP_CELLS];

    for index in 0..SPDCAP_CELLS {
        let internal = if is_speed {
            (table.values[index] * 10.0).round() as u16
        } else {
            table.values[index].round() as u16
        };
        low_bytes[index] = (internal & 0xFF) as u8;
        high_bytes[index] = (internal >> 8) as u8;
    }

    let low_rle = encode_rle(&low_bytes);
    let high_rle = encode_rle(&high_bytes);

    // sub_length includes itself (2 bytes) + header (3 bytes) + both RLE
    // streams.
    let sub_length = 2 + 3 + low_rle.len() + high_rle.len();

    let tag = if is_speed { b"SPD\0" } else { b"CAP\0" };
    let mut payload = Vec::with_capacity(4 + sub_length);
    payload.extend_from_slice(tag);
    payload.extend_from_slice(&(sub_length as u16).to_le_bytes());
    payload.extend_from_slice(&[0x20, 0x80, 0xC0]);
    payload.extend_from_slice(&low_rle);
    payload.extend_from_slice(&high_rle);
    payload
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_speed_class_values() {
        let table = LookupTable::default_speed();
        for lane in 1..=9u8 {
            for class in 1..=99u8 {
                assert_eq!(
                    table.get(lane, class),
                    class as f64,
                    "speed({}, {})",
                    lane,
                    class
                );
            }
        }
    }

    #[test]
    fn default_capacity_class_values() {
        let table = LookupTable::default_capacity();
        for lane in 1..=9u8 {
            for class in 1..=99u8 {
                assert_eq!(
                    table.get(lane, class),
                    (class as f64) * 20.0,
                    "capacity({}, {})",
                    lane,
                    class
                );
            }
        }
    }

    #[test]
    fn out_of_range_returns_zero() {
        let table = LookupTable::default_speed();
        assert_eq!(table.get(0, 1), 0.0);
        assert_eq!(table.get(10, 1), 0.0);
        assert_eq!(table.get(1, 0), 0.0);
        assert_eq!(table.get(1, 100), 0.0);
    }

    #[test]
    fn is_default_speed_detects_default() {
        let table = LookupTable::default_speed();
        assert!(table.is_default_speed());
        assert!(!table.is_default_capacity());
    }

    #[test]
    fn is_default_capacity_detects_default() {
        let table = LookupTable::default_capacity();
        assert!(table.is_default_capacity());
        assert!(!table.is_default_speed());
    }

    #[test]
    fn rows_iterator_yields_nine_rows() {
        let table = LookupTable::default_speed();
        let rows: Vec<&[f64]> = table.rows().collect();
        assert_eq!(rows.len(), SPDCAP_LANES);
        for row in &rows {
            assert_eq!(row.len(), SPDCAP_CLASSES);
        }
    }

    #[test]
    fn all_lane_rows_identical_in_defaults() {
        let speed = LookupTable::default_speed();
        let rows: Vec<&[f64]> = speed.rows().collect();
        for row in &rows[1..] {
            assert_eq!(rows[0], *row);
        }

        let capacity = LookupTable::default_capacity();
        let rows: Vec<&[f64]> = capacity.rows().collect();
        for row in &rows[1..] {
            assert_eq!(rows[0], *row);
        }
    }

    #[test]
    fn from_values_roundtrips() {
        let speed = LookupTable::default_speed();
        let values = *speed.as_slice();
        let rebuilt = LookupTable::from_values(values);
        assert_eq!(speed.as_slice(), rebuilt.as_slice());
    }

    #[test]
    fn rle_constant_run() {
        // 5 copies of 0x42: count_lo=5, byte2=0x80 (bit7 set), value=0x42.
        let data = [0x05, 0x80, 0x42];
        let (values, consumed) = decode_rle(&data, 0, 5).unwrap();
        assert_eq!(values, vec![0x42; 5]);
        assert_eq!(consumed, 3);
    }

    #[test]
    fn rle_literal_run() {
        // 3 literal bytes: count_lo=3, byte2=0x00.
        let data = [0x03, 0x00, 0x0A, 0x0B, 0x0C];
        let (values, consumed) = decode_rle(&data, 0, 3).unwrap();
        assert_eq!(values, vec![0x0A, 0x0B, 0x0C]);
        assert_eq!(consumed, 5);
    }

    #[test]
    fn rle_extended_count_constant() {
        // 891 copies: count_lo=0x7B (123), byte2=0x83 (bit7 set, hi=3)
        // count = 123 | (3 << 8) = 123 + 768 = 891.
        let data = [0x7B, 0x83, 0x00];
        let (values, consumed) = decode_rle(&data, 0, 891).unwrap();
        assert_eq!(values.len(), 891);
        assert!(values.iter().all(|&v| v == 0x00));
        assert_eq!(consumed, 3);
    }

    #[test]
    fn rle_extended_count_literal() {
        // 891 literal bytes: count_lo=0x7B (123), byte2=0x03 (bit7 clear)
        // count = 123 | (3 << 8) = 891.
        let mut data = vec![0x7B, 0x03];
        for i in 0..891u16 {
            data.push((i % 256) as u8);
        }
        assert_eq!(data.len(), 2 + 891);
        let (values, consumed) = decode_rle(&data, 0, 891).unwrap();
        assert_eq!(values.len(), 891);
        assert_eq!(consumed, 2 + 891);
    }

    #[test]
    fn rle_truncated_header() {
        let err = decode_rle(&[0x05], 0, 5).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidRle { .. }));
    }

    #[test]
    fn rle_truncated_literal() {
        let data = [0x05, 0x00, 0x01, 0x02]; // needs 5 literal bytes, has 2.
        let err = decode_rle(&data, 0, 5).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::InvalidRle { .. }));
    }

    #[test]
    fn rle_encode_decode_constant_run() {
        let input = vec![0x42; 100];
        let encoded = encode_rle(&input);
        let (decoded, _) = decode_rle(&encoded, 0, 100).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn rle_encode_decode_literal_run() {
        let input: Vec<u8> = (0..100).map(|i| (i % 256) as u8).collect();
        let encoded = encode_rle(&input);
        let (decoded, _) = decode_rle(&encoded, 0, 100).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn rle_encode_decode_mixed() {
        let mut input = Vec::new();
        input.extend_from_slice(&[1, 2, 3]); // literal
        input.extend(std::iter::repeat_n(0x42, 10)); // constant
        input.extend_from_slice(&[7, 8]); // literal
        input.extend(std::iter::repeat_n(0xFF, 5)); // constant
        let encoded = encode_rle(&input);
        let (decoded, _) = decode_rle(&encoded, 0, input.len()).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn rle_encode_decode_empty() {
        let input: Vec<u8> = vec![];
        let encoded = encode_rle(&input);
        assert!(encoded.is_empty());
    }

    #[test]
    fn rle_encode_decode_single_byte() {
        let input = vec![0xAB];
        let encoded = encode_rle(&input);
        let (decoded, _) = decode_rle(&encoded, 0, 1).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn spdcap_encode_decode_default_speed() {
        let table = LookupTable::default_speed();
        let payload = encode_spdcap_record(&table, true);
        let decoded = decode_spdcap_record(&payload, true).unwrap();
        assert_eq!(table.as_slice(), decoded.as_slice());
    }

    #[test]
    fn spdcap_encode_decode_default_capacity() {
        let table = LookupTable::default_capacity();
        let payload = encode_spdcap_record(&table, false);
        let decoded = decode_spdcap_record(&payload, false).unwrap();
        assert_eq!(table.as_slice(), decoded.as_slice());
    }

    #[test]
    fn spdcap_encode_decode_custom_speed() {
        // Use values that round-trip exactly through the u16 encoding
        // (value * 10 must be an exact integer).
        let mut values = [0.0; SPDCAP_CELLS];
        for (index, slot) in values.iter_mut().enumerate() {
            *slot = (index as u16) as f64 / 10.0;
        }
        let table = LookupTable::from_values(values);
        let payload = encode_spdcap_record(&table, true);
        let decoded = decode_spdcap_record(&payload, true).unwrap();
        for (original, roundtripped) in table.as_slice().iter().zip(decoded.as_slice().iter()) {
            assert!(
                (original - roundtripped).abs() < 1e-10,
                "mismatch: {} != {}",
                original,
                roundtripped,
            );
        }
    }

    #[test]
    fn spdcap_encode_decode_custom_capacity() {
        let mut values = [0.0; SPDCAP_CELLS];
        for (index, slot) in values.iter_mut().enumerate() {
            *slot = (index * 3) as f64;
        }
        let table = LookupTable::from_values(values);
        let payload = encode_spdcap_record(&table, false);
        let decoded = decode_spdcap_record(&payload, false).unwrap();
        assert_eq!(table.as_slice(), decoded.as_slice());
    }
}
