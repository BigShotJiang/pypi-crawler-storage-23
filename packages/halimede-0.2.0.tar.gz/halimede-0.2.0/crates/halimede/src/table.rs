//! Columnar tables for node and link data.
//!
//! [`NodeTable`] and [`LinkTable`] store network data in a columnar layout:
//! structural columns (node IDs, link endpoints) contain `i32` values, while
//! user-defined columns are stored as [`Column::Numeric`] (`Vec<f64>`) or
//! [`Column::String`] (`Vec<String>`). Columns are parallel to a [`Schema`]
//! that maps field names to column indices.
//!
//! Tables are constructed via the builder types [`NodeTableBuilder`] and
//! [`LinkTableBuilder`], which validate that all columns have equal length and
//! that required structural columns are present.
//!
//! For hot paths, resolve a field once with [`NodeTable::resolve_field`] or
//! [`LinkTable::resolve_field`] and reuse the handle with
//! [`NodeTable::column_f64_field`] or [`LinkTable::column_f64_field`]. Schema
//! mutations such as retain, remove, add, or derive invalidate previously
//! resolved handles.

use crate::error::{Error, ErrorKind, Result};
use crate::schema::{FieldDef, FieldType, Schema};

const NODE_RESERVED: &[&str] = &["N"];
const LINK_RESERVED: &[&str] = &["A", "B"];
const MAX_STRING_FIELD_SIZE: u16 = 255;
const INITIAL_SCHEMA_VERSION: u64 = 0;

#[derive(Debug, Clone, Copy)]
enum BuilderFieldType {
    Numeric,
    String { max_size: Option<u16> },
}

fn check_reserved(name: &str, reserved: &[&'static str]) -> Result<()> {
    for &r in reserved {
        if name == r {
            return Err(Error::new(ErrorKind::ReservedFieldName { name: r }));
        }
    }
    Ok(())
}

fn validate_structural_ids(values: &[i32], field: &'static str) -> Result<()> {
    for &value in values {
        if value <= 0 {
            return Err(Error::new(ErrorKind::InvalidStructuralId {
                field,
                detail: format!("value {} must be greater than 0", value),
            }));
        }
    }
    Ok(())
}

fn resolve_string_max_size(
    name: &str,
    values: &[String],
    explicit_max_size: Option<u16>,
) -> Result<u16> {
    let actual_max_size = values.iter().map(String::len).max().unwrap_or(0).max(1);
    if actual_max_size > usize::from(MAX_STRING_FIELD_SIZE) {
        return Err(Error::new(ErrorKind::ValueOutOfRange {
            detail: format!(
                "string column \"{}\" contains {} bytes, which exceeds the maximum of {}",
                name, actual_max_size, MAX_STRING_FIELD_SIZE
            ),
        }));
    }

    match explicit_max_size {
        Some(max_size) => {
            if max_size == 0 || max_size > MAX_STRING_FIELD_SIZE {
                return Err(Error::new(ErrorKind::ValueOutOfRange {
                    detail: format!(
                        "string column \"{}\" declares max_size {}, but valid values are 1..={}",
                        name, max_size, MAX_STRING_FIELD_SIZE
                    ),
                }));
            }
            if actual_max_size > usize::from(max_size) {
                return Err(Error::new(ErrorKind::ValueOutOfRange {
                    detail: format!(
                        "string column \"{}\" contains {} bytes, which exceeds max_size {}",
                        name, actual_max_size, max_size
                    ),
                }));
            }
            Ok(max_size)
        }
        None => Ok(actual_max_size as u16),
    }
}

fn column_row_count(column: &Column) -> usize {
    match column {
        Column::Numeric(values) => values.len(),
        Column::String(values) => values.len(),
    }
}

fn add_string_column(
    schema: &mut Schema,
    columns: &mut Vec<Column>,
    row_count: usize,
    reserved: &[&'static str],
    name: &str,
    values: Vec<String>,
    explicit_max_size: Option<u16>,
) -> Result<()> {
    check_reserved(name, reserved)?;
    if schema.find(name).is_some() {
        return Err(Error::new(ErrorKind::DuplicateFieldName {
            name: name.to_string(),
        }));
    }
    if values.len() != row_count {
        return Err(Error::new(ErrorKind::ColumnLengthMismatch {
            name: name.to_string(),
            expected_count: row_count,
            actual_count: values.len(),
        }));
    }

    let max_size = resolve_string_max_size(name, &values, explicit_max_size)?;
    let field_index = schema.field_count();
    schema.push_field(FieldDef::new(
        name.to_string(),
        FieldType::String { max_size },
        field_index,
    ));
    columns.push(Column::String(values));
    Ok(())
}

fn add_numeric_column(
    schema: &mut Schema,
    columns: &mut Vec<Column>,
    row_count: usize,
    reserved: &[&'static str],
    name: &str,
    values: Vec<f64>,
) -> Result<()> {
    check_reserved(name, reserved)?;
    if schema.find(name).is_some() {
        return Err(Error::new(ErrorKind::DuplicateFieldName {
            name: name.to_string(),
        }));
    }
    if values.len() != row_count {
        return Err(Error::new(ErrorKind::ColumnLengthMismatch {
            name: name.to_string(),
            expected_count: row_count,
            actual_count: values.len(),
        }));
    }

    let field_index = schema.field_count();
    schema.push_field(FieldDef::new(
        name.to_string(),
        FieldType::Numeric,
        field_index,
    ));
    columns.push(Column::Numeric(values));
    Ok(())
}

fn replace_string_column(
    schema: &mut Schema,
    columns: &mut [Column],
    row_count: usize,
    name: &str,
    values: Vec<String>,
    explicit_max_size: Option<u16>,
) -> Result<()> {
    if values.len() != row_count {
        return Err(Error::new(ErrorKind::ColumnLengthMismatch {
            name: name.to_string(),
            expected_count: row_count,
            actual_count: values.len(),
        }));
    }

    let field = schema.find(name).ok_or_else(|| {
        Error::new(ErrorKind::FieldNotFound {
            name: name.to_string(),
        })
    })?;
    let field_index = field.field_index();
    let max_size = resolve_string_max_size(name, &values, explicit_max_size)?;

    match &mut columns[field_index] {
        Column::String(column_values) => {
            *column_values = values;
            schema.update_field_type(field_index, FieldType::String { max_size });
            Ok(())
        }
        Column::Numeric(_) => Err(Error::new(ErrorKind::FieldTypeMismatch {
            name: name.to_string(),
            expected: "string",
            actual: "numeric",
        })),
    }
}

fn upsert_numeric_column(
    schema: &mut Schema,
    columns: &mut Vec<Column>,
    row_count: usize,
    reserved: &[&'static str],
    name: &str,
    values: Vec<f64>,
) -> Result<()> {
    if values.len() != row_count {
        return Err(Error::new(ErrorKind::ColumnLengthMismatch {
            name: name.to_string(),
            expected_count: row_count,
            actual_count: values.len(),
        }));
    }

    if let Some(field) = schema.find(name) {
        let field_index = field.field_index();
        columns[field_index] = Column::Numeric(values);
        schema.update_field_type(field_index, FieldType::Numeric);
        return Ok(());
    }

    check_reserved(name, reserved)?;
    let field_index = schema.field_count();
    schema.push_field(FieldDef::new(
        name.to_string(),
        FieldType::Numeric,
        field_index,
    ));
    columns.push(Column::Numeric(values));
    Ok(())
}

fn upsert_string_column(
    schema: &mut Schema,
    columns: &mut Vec<Column>,
    row_count: usize,
    reserved: &[&'static str],
    name: &str,
    values: Vec<String>,
    explicit_max_size: Option<u16>,
) -> Result<()> {
    if let Some(field) = schema.find(name) {
        let field_index = field.field_index();
        if values.len() != row_count {
            return Err(Error::new(ErrorKind::ColumnLengthMismatch {
                name: name.to_string(),
                expected_count: row_count,
                actual_count: values.len(),
            }));
        }
        let max_size = resolve_string_max_size(name, &values, explicit_max_size)?;
        columns[field_index] = Column::String(values);
        schema.update_field_type(field_index, FieldType::String { max_size });
        return Ok(());
    }

    add_string_column(
        schema,
        columns,
        row_count,
        reserved,
        name,
        values,
        explicit_max_size,
    )
}

fn build_requested_field_mask<Fields, Field>(
    schema: &Schema,
    field_names: Fields,
) -> Result<Vec<bool>>
where
    Fields: IntoIterator<Item = Field>,
    Field: AsRef<str>,
{
    let mut selected = vec![false; schema.field_count()];

    for field_name in field_names {
        let name = field_name.as_ref();
        let field = schema.find(name).ok_or_else(|| {
            Error::new(ErrorKind::FieldNotFound {
                name: name.to_string(),
            })
        })?;
        selected[field.field_index()] = true;
    }

    Ok(selected)
}

fn invert_field_mask(remove_field: Vec<bool>) -> Vec<bool> {
    remove_field
        .into_iter()
        .map(|remove_field| !remove_field)
        .collect()
}

fn apply_field_mask(schema: &mut Schema, columns: &mut Vec<Column>, keep_field: &[bool]) {
    let old_fields: Vec<FieldDef> = schema.fields().to_vec();
    let old_columns = std::mem::take(columns);
    let mut new_fields = Vec::with_capacity(old_fields.len());
    let mut new_columns = Vec::with_capacity(old_columns.len());

    for ((keep, field), column) in keep_field
        .iter()
        .copied()
        .zip(old_fields.into_iter())
        .zip(old_columns.into_iter())
    {
        if !keep {
            continue;
        }

        let field_index = new_fields.len();
        new_fields.push(FieldDef::new(
            field.name().to_string(),
            field.field_type().clone(),
            field_index,
        ));
        new_columns.push(column);
    }

    *schema = Schema::new(new_fields);
    *columns = new_columns;
}

fn resolve_field_index(
    schema: &Schema,
    schema_version: u64,
    name: &str,
    hint_index: usize,
    field_schema_version: u64,
) -> Result<usize> {
    if field_schema_version != schema_version || hint_index >= schema.field_count() {
        return Err(Error::new(ErrorKind::FieldNotFound {
            name: name.to_string(),
        }));
    }

    debug_assert_eq!(schema.fields()[hint_index].name(), name);
    Ok(hint_index)
}

fn remove_column_by_name(
    schema: &mut Schema,
    columns: &mut Vec<Column>,
    name: &str,
) -> Result<Column> {
    let field_index = schema
        .find(name)
        .map(FieldDef::field_index)
        .ok_or_else(|| {
            Error::new(ErrorKind::FieldNotFound {
                name: name.to_string(),
            })
        })?;
    schema.remove_field(field_index);
    Ok(columns.remove(field_index))
}

fn derive_column_values<Table, Value, F>(
    table: &Table,
    row_count: usize,
    mut derive: F,
) -> Result<Vec<Value>>
where
    F: FnMut(&Table, usize) -> Result<Value>,
{
    let mut values = Vec::with_capacity(row_count);
    for row_index in 0..row_count {
        values.push(derive(table, row_index)?);
    }
    Ok(values)
}

fn validate_builder_fields(
    fields: &[(String, BuilderFieldType)],
    reserved: &[&'static str],
) -> Result<()> {
    for (name, _) in fields {
        check_reserved(name, reserved)?;
    }

    for first_index in 0..fields.len() {
        for second_index in (first_index + 1)..fields.len() {
            if fields[first_index].0 == fields[second_index].0 {
                return Err(Error::new(ErrorKind::DuplicateFieldName {
                    name: fields[first_index].0.clone(),
                }));
            }
        }
    }

    Ok(())
}

fn build_schema_fields(
    fields: &[(String, BuilderFieldType)],
    columns: &[Column],
) -> Result<Vec<FieldDef>> {
    fields
        .iter()
        .zip(columns.iter())
        .enumerate()
        .map(|(field_index, ((name, field_type), column))| {
            let field_type = match field_type {
                BuilderFieldType::Numeric => FieldType::Numeric,
                BuilderFieldType::String { max_size } => {
                    let values = column
                        .as_str()
                        .expect("string builder field must match string column");
                    FieldType::String {
                        max_size: resolve_string_max_size(name, values, *max_size)?,
                    }
                }
            };
            Ok(FieldDef::new(name.clone(), field_type, field_index))
        })
        .collect()
}

/// A column of homogeneous data, either all numeric or all string.
///
/// Most callers should prefer the typed accessors on [`NodeTable`] and
/// [`LinkTable`] rather than matching on `Column` directly.
#[derive(Debug, Clone, PartialEq)]
pub enum Column {
    /// A column of numeric values, stored as `f64`.
    Numeric(Vec<f64>),
    /// A column of string values.
    String(Vec<String>),
}

impl Column {
    /// The number of rows in this column.
    #[inline]
    #[must_use]
    pub fn row_count(&self) -> usize {
        match self {
            Column::Numeric(v) => v.len(),
            Column::String(v) => v.len(),
        }
    }

    /// Returns `true` if this column holds numeric (`f64`) data.
    #[inline]
    #[must_use]
    pub fn is_numeric(&self) -> bool {
        matches!(self, Column::Numeric(_))
    }

    /// Returns `true` if this column holds string data.
    #[inline]
    #[must_use]
    pub fn is_string(&self) -> bool {
        matches!(self, Column::String(_))
    }

    /// Access the underlying numeric data, if this is a numeric column.
    #[inline]
    #[must_use]
    pub fn as_f64(&self) -> Option<&[f64]> {
        match self {
            Column::Numeric(v) => Some(v),
            Column::String(_) => None,
        }
    }

    /// Access the underlying string data, if this is a string column.
    #[inline]
    #[must_use]
    pub fn as_str(&self) -> Option<&[String]> {
        match self {
            Column::String(v) => Some(v),
            Column::Numeric(_) => None,
        }
    }

    /// Consume the column, returning the numeric vector if present.
    #[inline]
    #[must_use]
    pub fn into_f64(self) -> Option<Vec<f64>> {
        match self {
            Column::Numeric(v) => Some(v),
            Column::String(_) => None,
        }
    }

    /// Consume the column, returning the string vector if present.
    #[inline]
    #[must_use]
    pub fn into_str(self) -> Option<Vec<String>> {
        match self {
            Column::String(v) => Some(v),
            Column::Numeric(_) => None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ResolvedField {
    name: String,
    field_type: FieldType,
    field_index: usize,
    schema_version: u64,
}

#[derive(Debug, Clone, PartialEq)]
struct UserColumns {
    schema: Schema,
    columns: Vec<Column>,
    row_count: usize,
    schema_version: u64,
}

impl UserColumns {
    /// Owns the shared user-field state for both table types.
    ///
    /// `NodeTable` and `LinkTable` keep their structural columns separate and
    /// delegate all schema-versioned user-column behaviour through this core.
    fn new(schema: Schema, columns: Vec<Column>, row_count: usize) -> Self {
        Self {
            schema,
            columns,
            row_count,
            schema_version: INITIAL_SCHEMA_VERSION,
        }
    }

    fn bump_schema_version(&mut self) {
        self.schema_version = self.schema_version.wrapping_add(1);
    }

    fn row_count(&self) -> usize {
        self.row_count
    }

    fn schema(&self) -> &Schema {
        &self.schema
    }

    fn has_field(&self, name: &str) -> bool {
        self.schema.find(name).is_some()
    }

    fn resolve_field(&self, name: &str) -> Result<ResolvedField> {
        let field = self.schema.find(name).ok_or_else(|| {
            Error::new(ErrorKind::FieldNotFound {
                name: name.to_string(),
            })
        })?;

        Ok(ResolvedField {
            name: field.name().to_string(),
            field_type: field.field_type().clone(),
            field_index: field.field_index(),
            schema_version: self.schema_version,
        })
    }

    fn column_f64(&self, name: &str) -> Result<&[f64]> {
        as_f64(find_column(&self.schema, &self.columns, name)?, name)
    }

    fn column_str(&self, name: &str) -> Result<&[String]> {
        as_str(find_column(&self.schema, &self.columns, name)?, name)
    }

    fn column_f64_field(&self, field: &ResolvedField) -> Result<&[f64]> {
        let field_index = resolve_field_index(
            &self.schema,
            self.schema_version,
            &field.name,
            field.field_index,
            field.schema_version,
        )?;
        as_f64(&self.columns[field_index], &field.name)
    }

    fn column_str_field(&self, field: &ResolvedField) -> Result<&[String]> {
        let field_index = resolve_field_index(
            &self.schema,
            self.schema_version,
            &field.name,
            field.field_index,
            field.schema_version,
        )?;
        as_str(&self.columns[field_index], &field.name)
    }

    fn column_f64_mut(&mut self, name: &str) -> Result<&mut [f64]> {
        as_f64_mut(
            find_column_mut(&self.schema, &mut self.columns, name)?,
            name,
        )
    }

    fn set_column_str(
        &mut self,
        name: &str,
        values: Vec<String>,
        explicit_max_size: Option<u16>,
    ) -> Result<()> {
        replace_string_column(
            &mut self.schema,
            &mut self.columns,
            self.row_count,
            name,
            values,
            explicit_max_size,
        )?;
        self.bump_schema_version();
        Ok(())
    }

    fn column(&self, name: &str) -> Result<&Column> {
        find_column(&self.schema, &self.columns, name)
    }

    fn add_numeric_column(
        &mut self,
        reserved: &[&'static str],
        name: &str,
        values: Vec<f64>,
    ) -> Result<()> {
        add_numeric_column(
            &mut self.schema,
            &mut self.columns,
            self.row_count,
            reserved,
            name,
            values,
        )?;
        self.bump_schema_version();
        Ok(())
    }

    fn add_string_column(
        &mut self,
        reserved: &[&'static str],
        name: &str,
        values: Vec<String>,
        explicit_max_size: Option<u16>,
    ) -> Result<()> {
        add_string_column(
            &mut self.schema,
            &mut self.columns,
            self.row_count,
            reserved,
            name,
            values,
            explicit_max_size,
        )?;
        self.bump_schema_version();
        Ok(())
    }

    fn retain_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        let keep_field = build_requested_field_mask(&self.schema, field_names)?;
        apply_field_mask(&mut self.schema, &mut self.columns, &keep_field);
        self.bump_schema_version();
        Ok(())
    }

    fn remove_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        let remove_field = build_requested_field_mask(&self.schema, field_names)?;
        let keep_field = invert_field_mask(remove_field);
        apply_field_mask(&mut self.schema, &mut self.columns, &keep_field);
        self.bump_schema_version();
        Ok(())
    }

    fn upsert_numeric_column(
        &mut self,
        reserved: &[&'static str],
        name: &str,
        values: Vec<f64>,
    ) -> Result<()> {
        upsert_numeric_column(
            &mut self.schema,
            &mut self.columns,
            self.row_count,
            reserved,
            name,
            values,
        )?;
        self.bump_schema_version();
        Ok(())
    }

    fn upsert_string_column(
        &mut self,
        reserved: &[&'static str],
        name: &str,
        values: Vec<String>,
        explicit_max_size: Option<u16>,
    ) -> Result<()> {
        upsert_string_column(
            &mut self.schema,
            &mut self.columns,
            self.row_count,
            reserved,
            name,
            values,
            explicit_max_size,
        )?;
        self.bump_schema_version();
        Ok(())
    }

    fn columns(&self) -> impl Iterator<Item = (&FieldDef, &Column)> {
        self.schema.fields().iter().zip(self.columns.iter())
    }

    fn remove_column(&mut self, name: &str) -> Result<Column> {
        let column = remove_column_by_name(&mut self.schema, &mut self.columns, name)?;
        self.bump_schema_version();
        Ok(column)
    }

    fn raw_columns(&self) -> &[Column] {
        &self.columns
    }
}

/// A resolved node field for repeated typed access.
///
/// Resolve handles from [`NodeTable::resolve_field`] and reuse them inside
/// transform loops. Resolve a new handle after any schema mutation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NodeField {
    inner: ResolvedField,
}

impl NodeField {
    /// The field name.
    #[must_use]
    pub fn name(&self) -> &str {
        &self.inner.name
    }

    /// The field type.
    #[must_use]
    pub fn field_type(&self) -> &FieldType {
        &self.inner.field_type
    }

    /// The field index from the schema at resolution time.
    #[must_use]
    pub fn field_index(&self) -> usize {
        self.inner.field_index
    }
}

/// A resolved link field for repeated typed access.
///
/// Resolve handles from [`LinkTable::resolve_field`] and reuse them inside
/// transform loops. Resolve a new handle after any schema mutation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LinkField {
    inner: ResolvedField,
}

impl LinkField {
    /// The field name.
    #[must_use]
    pub fn name(&self) -> &str {
        &self.inner.name
    }

    /// The field type.
    #[must_use]
    pub fn field_type(&self) -> &FieldType {
        &self.inner.field_type
    }

    /// The field index from the schema at resolution time.
    #[must_use]
    pub fn field_index(&self) -> usize {
        self.inner.field_index
    }
}

fn find_column<'a>(schema: &Schema, columns: &'a [Column], name: &str) -> Result<&'a Column> {
    let field = schema.find(name).ok_or_else(|| {
        Error::new(ErrorKind::FieldNotFound {
            name: name.to_string(),
        })
    })?;
    Ok(&columns[field.field_index()])
}

fn find_column_mut<'a>(
    schema: &Schema,
    columns: &'a mut [Column],
    name: &str,
) -> Result<&'a mut Column> {
    let field = schema.find(name).ok_or_else(|| {
        Error::new(ErrorKind::FieldNotFound {
            name: name.to_string(),
        })
    })?;
    let field_index = field.field_index();
    Ok(&mut columns[field_index])
}

fn as_f64<'a>(column: &'a Column, name: &str) -> Result<&'a [f64]> {
    match column {
        Column::Numeric(values) => Ok(values),
        Column::String(_) => Err(Error::new(ErrorKind::FieldTypeMismatch {
            name: name.to_string(),
            expected: "numeric",
            actual: "string",
        })),
    }
}

fn as_f64_mut<'a>(column: &'a mut Column, name: &str) -> Result<&'a mut [f64]> {
    match column {
        Column::Numeric(values) => Ok(values),
        Column::String(_) => Err(Error::new(ErrorKind::FieldTypeMismatch {
            name: name.to_string(),
            expected: "numeric",
            actual: "string",
        })),
    }
}

fn as_str<'a>(column: &'a Column, name: &str) -> Result<&'a [String]> {
    match column {
        Column::String(values) => Ok(values),
        Column::Numeric(_) => Err(Error::new(ErrorKind::FieldTypeMismatch {
            name: name.to_string(),
            expected: "string",
            actual: "numeric",
        })),
    }
}

/// Columnar table of node data.
///
/// Each row represents a node in the network. The structural column `ids`
/// contains the node IDs (the `N` field). User-defined columns are accessed by
/// name via [`column_f64`](NodeTable::column_f64) and
/// [`column_str`](NodeTable::column_str). For edit-heavy workflows, combine
/// [`retain_fields`](NodeTable::retain_fields),
/// [`remove_fields`](NodeTable::remove_fields),
/// [`derive_column_f64`](NodeTable::derive_column_f64), and resolved field
/// handles from [`resolve_field`](NodeTable::resolve_field).
///
/// # Example
///
/// ```
/// use halimede::NodeTable;
///
/// let table = NodeTable::builder()
///     .ids(vec![1, 2, 3])
///     .column_f64("X", vec![100.0, 200.0, 300.0])
///     .build()?;
///
/// assert_eq!(table.ids(), &[1, 2, 3]);
/// assert_eq!(table.row_count(), 3);
/// assert_eq!(table.column_f64("X")?, &[100.0, 200.0, 300.0]);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct NodeTable {
    ids: Vec<i32>,
    user: UserColumns,
}

impl NodeTable {
    /// Construct a `NodeTable` from structural IDs, schema, and columns.
    ///
    /// The schema and columns are validated together. Every field must have a
    /// matching column with the same row count as `ids`, and string values must
    /// fit their declared `max_size`.
    ///
    /// # Errors
    ///
    /// Returns an error if the structural IDs are invalid, the schema and
    /// columns disagree, or any column violates the declared field type.
    pub fn from_parts(ids: Vec<i32>, schema: Schema, columns: Vec<Column>) -> Result<Self> {
        validate_structural_ids(&ids, "N")?;
        let row_count = ids.len();
        let user = build_user_columns_from_parts(schema, columns, row_count, NODE_RESERVED)?;
        Ok(Self { ids, user })
    }

    /// Construct a `NodeTable` directly from pre-validated parts.
    pub(crate) fn from_parts_unchecked(
        ids: Vec<i32>,
        schema: Schema,
        columns: Vec<Column>,
    ) -> Self {
        let row_count = ids.len();
        Self {
            ids,
            user: UserColumns::new(schema, columns, row_count),
        }
    }

    /// Create a new builder for constructing a `NodeTable`.
    #[must_use]
    pub fn builder() -> NodeTableBuilder {
        NodeTableBuilder::new()
    }

    /// The node IDs (N field) as a slice.
    #[inline]
    #[must_use]
    pub fn ids(&self) -> &[i32] {
        &self.ids
    }

    /// The number of node records.
    #[inline]
    #[must_use]
    pub fn row_count(&self) -> usize {
        self.user.row_count()
    }

    /// The schema describing user-defined columns.
    #[inline]
    #[must_use]
    pub fn schema(&self) -> &Schema {
        self.user.schema()
    }

    /// Returns `true` if a column with the given name exists.
    #[inline]
    #[must_use]
    pub fn has_field(&self, name: &str) -> bool {
        self.user.has_field(name)
    }

    /// Resolve a field for repeated access.
    ///
    /// The returned handle can be reused across row iterations without
    /// repeating name lookups. Resolve a new handle after any schema mutation
    /// such as retain, remove, add, or derive.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the field does not exist.
    pub fn resolve_field(&self, name: &str) -> Result<NodeField> {
        Ok(NodeField {
            inner: self.user.resolve_field(name)?,
        })
    }

    /// Access a numeric column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a string column.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::NodeTable;
    ///
    /// let table = NodeTable::builder()
    ///     .ids(vec![1, 2])
    ///     .column_f64("X", vec![1.0, 2.0])
    ///     .build()?;
    ///
    /// assert_eq!(table.column_f64("X")?, &[1.0, 2.0]);
    /// assert!(table.column_f64("NOSUCH").is_err());
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn column_f64(&self, name: &str) -> Result<&[f64]> {
        self.user.column_f64(name)
    }

    /// Access a string column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a numeric column.
    pub fn column_str(&self, name: &str) -> Result<&[String]> {
        self.user.column_str(name)
    }

    /// Access a numeric column by resolved field.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the handle was resolved before
    /// a schema mutation, or [`ErrorKind::FieldTypeMismatch`] if the field is
    /// not numeric.
    pub fn column_f64_field(&self, field: &NodeField) -> Result<&[f64]> {
        self.user.column_f64_field(&field.inner)
    }

    /// Access a string column by resolved field.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the handle was resolved before
    /// a schema mutation, or [`ErrorKind::FieldTypeMismatch`] if the field is
    /// not a string column.
    pub fn column_str_field(&self, field: &NodeField) -> Result<&[String]> {
        self.user.column_str_field(&field.inner)
    }

    /// Mutable access to a numeric column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a string column.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::NodeTable;
    ///
    /// let mut table = NodeTable::builder()
    ///     .ids(vec![1, 2])
    ///     .column_f64("X", vec![1.0, 2.0])
    ///     .build()?;
    ///
    /// table.column_f64_mut("X")?[0] = 99.0;
    /// assert_eq!(table.column_f64("X")?, &[99.0, 2.0]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn column_f64_mut(&mut self, name: &str) -> Result<&mut [f64]> {
        self.user.column_f64_mut(name)
    }

    /// Replace a string column by field name.
    ///
    /// The encoded width is inferred from the longest value in bytes.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, [`ErrorKind::FieldTypeMismatch`] if the field is
    /// numeric, or [`ErrorKind::ColumnLengthMismatch`] if `values` does not
    /// match [`row_count`](Self::row_count).
    pub fn set_column_str(&mut self, name: &str, values: Vec<String>) -> Result<()> {
        self.user.set_column_str(name, values, None)
    }

    /// Replace a string column by field name using an explicit maximum size.
    ///
    /// # Errors
    ///
    /// Returns the same errors as [`set_column_str`](Self::set_column_str),
    /// plus [`ErrorKind::ValueOutOfRange`] if `max_size` is not within
    /// `1..=255` or the values exceed it.
    pub fn set_column_str_with_max_size(
        &mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Result<()> {
        self.user.set_column_str(name, values, Some(max_size))
    }

    /// Access a column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given
    /// name exists in the schema.
    pub fn column(&self, name: &str) -> Result<&Column> {
        self.user.column(name)
    }

    /// Add a numeric column to this table.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::DuplicateFieldName`] if a column with the
    /// given name already exists, or [`ErrorKind::ColumnLengthMismatch`]
    /// if `values` has a different length than [`row_count`](Self::row_count).
    pub fn add_column_f64(&mut self, name: &str, values: Vec<f64>) -> Result<()> {
        self.user.add_numeric_column(NODE_RESERVED, name, values)
    }

    /// Add a string column to this table.
    ///
    /// The encoded width is inferred from the longest value in bytes.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::DuplicateFieldName`] if a column with the
    /// given name already exists, or [`ErrorKind::ColumnLengthMismatch`]
    /// if `values` has a different length than [`row_count`](Self::row_count).
    pub fn add_column_str(&mut self, name: &str, values: Vec<String>) -> Result<()> {
        self.user
            .add_string_column(NODE_RESERVED, name, values, None)
    }

    /// Add a string column to this table with an explicit maximum size.
    ///
    /// # Errors
    ///
    /// Returns the same errors as [`add_column_str`](Self::add_column_str),
    /// plus [`ErrorKind::ValueOutOfRange`] if `max_size` is not within
    /// `1..=255` or the values exceed it.
    pub fn add_column_str_with_max_size(
        &mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Result<()> {
        self.user
            .add_string_column(NODE_RESERVED, name, values, Some(max_size))
    }

    /// Retain only the named fields, preserving their current order.
    ///
    /// Structural IDs are always retained. Any previously resolved
    /// [`NodeField`] handles become invalid.
    pub fn retain_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        self.user.retain_fields(field_names)
    }

    /// Remove the named fields in one pass.
    ///
    /// Any previously resolved [`NodeField`] handles become invalid.
    pub fn remove_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        self.user.remove_fields(field_names)
    }

    /// Derive a numeric column from the current node rows.
    ///
    /// Replaces an existing field in place when `name` already exists, or
    /// appends a new field otherwise.
    ///
    /// Resolve any input [`NodeField`] handles after the last schema mutation
    /// before calling this method.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::NodeTable;
    ///
    /// let mut table = NodeTable::builder()
    ///     .ids(vec![1, 2])
    ///     .column_f64("X", vec![1.0, 2.0])
    ///     .build()?;
    ///
    /// let x = table.resolve_field("X")?;
    /// table.derive_column_f64("X2", |table, row_index| {
    ///     Ok(table.column_f64_field(&x)?[row_index] * 2.0)
    /// })?;
    ///
    /// assert_eq!(table.column_f64("X2")?, &[2.0, 4.0]);
    /// # Ok::<(), halimede::Error>(())
    /// ```
    pub fn derive_column_f64<F>(&mut self, name: &str, mut derive: F) -> Result<()>
    where
        F: FnMut(&NodeTable, usize) -> Result<f64>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user.upsert_numeric_column(NODE_RESERVED, name, values)
    }

    /// Derive a string column from the current node rows.
    ///
    /// Replaces an existing field in place when `name` already exists, or
    /// appends a new field otherwise. The encoded width is inferred from the
    /// longest returned value in bytes.
    pub fn derive_column_str<F>(&mut self, name: &str, mut derive: F) -> Result<()>
    where
        F: FnMut(&NodeTable, usize) -> Result<String>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user
            .upsert_string_column(NODE_RESERVED, name, values, None)
    }

    /// Derive a string column using an explicit maximum size in bytes.
    pub fn derive_column_str_with_max_size<F>(
        &mut self,
        name: &str,
        max_size: u16,
        mut derive: F,
    ) -> Result<()>
    where
        F: FnMut(&NodeTable, usize) -> Result<String>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user
            .upsert_string_column(NODE_RESERVED, name, values, Some(max_size))
    }

    /// Iterate over all columns as `(field, column)` pairs in schema order.
    pub fn columns(&self) -> impl Iterator<Item = (&FieldDef, &Column)> {
        self.user.columns()
    }

    /// Remove a column by field name.
    ///
    /// Returns the removed column, or an error if no field with the given
    /// name exists.
    pub fn remove_column(&mut self, name: &str) -> Result<Column> {
        self.user.remove_column(name)
    }

    /// Access the raw column vector in schema order.
    pub(crate) fn raw_columns(&self) -> &[Column] {
        self.user.raw_columns()
    }

    /// Consume this table and return its constituent parts.
    ///
    /// Returns `(ids, schema, columns)`.
    #[must_use]
    pub fn into_parts(self) -> (Vec<i32>, Schema, Vec<Column>) {
        (self.ids, self.user.schema, self.user.columns)
    }
}

/// Columnar table of link data.
///
/// Each row represents a directed link in the network. The structural columns
/// `a` and `b` contain the from-node and to-node IDs. User-defined columns are
/// accessed by name via [`column_f64`](LinkTable::column_f64) and
/// [`column_str`](LinkTable::column_str). For edit-heavy workflows, combine
/// [`retain_fields`](LinkTable::retain_fields),
/// [`remove_fields`](LinkTable::remove_fields),
/// [`derive_column_f64`](LinkTable::derive_column_f64), and resolved field
/// handles from [`resolve_field`](LinkTable::resolve_field).
///
/// # Example
///
/// ```
/// use halimede::LinkTable;
///
/// let table = LinkTable::builder()
///     .endpoints(vec![1, 2], vec![2, 3])
///     .column_f64("SPEED", vec![60.0, 80.0])
///     .build()?;
///
/// assert_eq!(table.a(), &[1, 2]);
/// assert_eq!(table.b(), &[2, 3]);
/// assert_eq!(table.row_count(), 2);
/// assert_eq!(table.column_f64("SPEED")?, &[60.0, 80.0]);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct LinkTable {
    a: Vec<i32>,
    b: Vec<i32>,
    user: UserColumns,
}

impl LinkTable {
    /// Construct a `LinkTable` from structural endpoints, schema, and columns.
    ///
    /// The schema and columns are validated together. Every field must have a
    /// matching column with the same row count as `a` and `b`, and string
    /// values must fit their declared `max_size`.
    ///
    /// # Errors
    ///
    /// Returns an error if the structural IDs are invalid, `a` and `b` differ
    /// in length, the schema and columns disagree, or any column violates the
    /// declared field type.
    pub fn from_parts(
        a: Vec<i32>,
        b: Vec<i32>,
        schema: Schema,
        columns: Vec<Column>,
    ) -> Result<Self> {
        validate_structural_ids(&a, "A")?;
        validate_structural_ids(&b, "B")?;
        if a.len() != b.len() {
            return Err(Error::new(ErrorKind::ColumnLengthMismatch {
                name: "B".to_string(),
                expected_count: a.len(),
                actual_count: b.len(),
            }));
        }

        let row_count = a.len();
        let user = build_user_columns_from_parts(schema, columns, row_count, LINK_RESERVED)?;
        Ok(Self { a, b, user })
    }

    /// Construct a `LinkTable` directly from pre-validated parts.
    pub(crate) fn from_parts_unchecked(
        a: Vec<i32>,
        b: Vec<i32>,
        schema: Schema,
        columns: Vec<Column>,
    ) -> Self {
        let row_count = a.len();
        Self {
            a,
            b,
            user: UserColumns::new(schema, columns, row_count),
        }
    }

    /// Create a new builder for constructing a `LinkTable`.
    #[must_use]
    pub fn builder() -> LinkTableBuilder {
        LinkTableBuilder::new()
    }

    /// The from-node IDs (A field) as a slice.
    #[inline]
    #[must_use]
    pub fn a(&self) -> &[i32] {
        &self.a
    }

    /// The to-node IDs (B field) as a slice.
    #[inline]
    #[must_use]
    pub fn b(&self) -> &[i32] {
        &self.b
    }

    /// The number of link records.
    #[inline]
    #[must_use]
    pub fn row_count(&self) -> usize {
        self.user.row_count()
    }

    /// The schema describing user-defined columns.
    #[inline]
    #[must_use]
    pub fn schema(&self) -> &Schema {
        self.user.schema()
    }

    /// Returns `true` if a column with the given name exists.
    #[inline]
    #[must_use]
    pub fn has_field(&self, name: &str) -> bool {
        self.user.has_field(name)
    }

    /// Resolve a field for repeated access.
    ///
    /// The returned handle can be reused across row iterations without
    /// repeating name lookups. Resolve a new handle after any schema mutation
    /// such as retain, remove, add, or derive.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the field does not exist.
    pub fn resolve_field(&self, name: &str) -> Result<LinkField> {
        Ok(LinkField {
            inner: self.user.resolve_field(name)?,
        })
    }

    /// Access a numeric column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a string column.
    pub fn column_f64(&self, name: &str) -> Result<&[f64]> {
        self.user.column_f64(name)
    }

    /// Access a string column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a numeric column.
    pub fn column_str(&self, name: &str) -> Result<&[String]> {
        self.user.column_str(name)
    }

    /// Access a numeric column by resolved field.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the handle was resolved before
    /// a schema mutation, or [`ErrorKind::FieldTypeMismatch`] if the field is
    /// not numeric.
    pub fn column_f64_field(&self, field: &LinkField) -> Result<&[f64]> {
        self.user.column_f64_field(&field.inner)
    }

    /// Access a string column by resolved field.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if the handle was resolved before
    /// a schema mutation, or [`ErrorKind::FieldTypeMismatch`] if the field is
    /// not a string column.
    pub fn column_str_field(&self, field: &LinkField) -> Result<&[String]> {
        self.user.column_str_field(&field.inner)
    }

    /// Mutable access to a numeric column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, or [`ErrorKind::FieldTypeMismatch`] if the field
    /// is a string column.
    pub fn column_f64_mut(&mut self, name: &str) -> Result<&mut [f64]> {
        self.user.column_f64_mut(name)
    }

    /// Replace a string column by field name.
    ///
    /// The encoded width is inferred from the longest value in bytes.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given name
    /// exists in the schema, [`ErrorKind::FieldTypeMismatch`] if the field is
    /// numeric, or [`ErrorKind::ColumnLengthMismatch`] if `values` does not
    /// match [`row_count`](Self::row_count).
    pub fn set_column_str(&mut self, name: &str, values: Vec<String>) -> Result<()> {
        self.user.set_column_str(name, values, None)
    }

    /// Replace a string column by field name using an explicit maximum size.
    ///
    /// # Errors
    ///
    /// Returns the same errors as [`set_column_str`](Self::set_column_str),
    /// plus [`ErrorKind::ValueOutOfRange`] if `max_size` is not within
    /// `1..=255` or the values exceed it.
    pub fn set_column_str_with_max_size(
        &mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Result<()> {
        self.user.set_column_str(name, values, Some(max_size))
    }

    /// Access a column by field name.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::FieldNotFound`] if no field with the given
    /// name exists in the schema.
    pub fn column(&self, name: &str) -> Result<&Column> {
        self.user.column(name)
    }

    /// Add a numeric column to this table.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::DuplicateFieldName`] if a column with the
    /// given name already exists, or [`ErrorKind::ColumnLengthMismatch`]
    /// if `values` has a different length than [`row_count`](Self::row_count).
    pub fn add_column_f64(&mut self, name: &str, values: Vec<f64>) -> Result<()> {
        self.user.add_numeric_column(LINK_RESERVED, name, values)
    }

    /// Add a string column to this table.
    ///
    /// The encoded width is inferred from the longest value in bytes.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::DuplicateFieldName`] if a column with the
    /// given name already exists, or [`ErrorKind::ColumnLengthMismatch`]
    /// if `values` has a different length than [`row_count`](Self::row_count).
    pub fn add_column_str(&mut self, name: &str, values: Vec<String>) -> Result<()> {
        self.user
            .add_string_column(LINK_RESERVED, name, values, None)
    }

    /// Add a string column to this table with an explicit maximum size.
    ///
    /// # Errors
    ///
    /// Returns the same errors as [`add_column_str`](Self::add_column_str),
    /// plus [`ErrorKind::ValueOutOfRange`] if `max_size` is not within
    /// `1..=255` or the values exceed it.
    pub fn add_column_str_with_max_size(
        &mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Result<()> {
        self.user
            .add_string_column(LINK_RESERVED, name, values, Some(max_size))
    }

    /// Retain only the named fields, preserving their current order.
    ///
    /// Structural endpoints are always retained. Any previously resolved
    /// [`LinkField`] handles become invalid.
    pub fn retain_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        self.user.retain_fields(field_names)
    }

    /// Remove the named fields in one pass.
    ///
    /// Any previously resolved [`LinkField`] handles become invalid.
    pub fn remove_fields<Fields, Field>(&mut self, field_names: Fields) -> Result<()>
    where
        Fields: IntoIterator<Item = Field>,
        Field: AsRef<str>,
    {
        self.user.remove_fields(field_names)
    }

    /// Derive a numeric column from the current link rows.
    ///
    /// Replaces an existing field in place when `name` already exists, or
    /// appends a new field otherwise. Resolve any input [`LinkField`] handles
    /// after the last schema mutation before calling this method.
    pub fn derive_column_f64<F>(&mut self, name: &str, mut derive: F) -> Result<()>
    where
        F: FnMut(&LinkTable, usize) -> Result<f64>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user.upsert_numeric_column(LINK_RESERVED, name, values)
    }

    /// Derive a string column from the current link rows.
    ///
    /// Replaces an existing field in place when `name` already exists, or
    /// appends a new field otherwise. The encoded width is inferred from the
    /// longest returned value in bytes.
    pub fn derive_column_str<F>(&mut self, name: &str, mut derive: F) -> Result<()>
    where
        F: FnMut(&LinkTable, usize) -> Result<String>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user
            .upsert_string_column(LINK_RESERVED, name, values, None)
    }

    /// Derive a string column using an explicit maximum size in bytes.
    pub fn derive_column_str_with_max_size<F>(
        &mut self,
        name: &str,
        max_size: u16,
        mut derive: F,
    ) -> Result<()>
    where
        F: FnMut(&LinkTable, usize) -> Result<String>,
    {
        let values = {
            let table = &*self;
            derive_column_values(table, table.row_count(), &mut derive)?
        };

        self.user
            .upsert_string_column(LINK_RESERVED, name, values, Some(max_size))
    }

    /// Iterate over all columns as `(field, column)` pairs in schema order.
    pub fn columns(&self) -> impl Iterator<Item = (&FieldDef, &Column)> {
        self.user.columns()
    }

    /// Remove a column by field name.
    ///
    /// Returns the removed column, or an error if no field with the given
    /// name exists.
    pub fn remove_column(&mut self, name: &str) -> Result<Column> {
        self.user.remove_column(name)
    }

    /// Access the raw column vector in schema order.
    pub(crate) fn raw_columns(&self) -> &[Column] {
        self.user.raw_columns()
    }

    /// Consume this table and return its constituent parts.
    ///
    /// Returns `(a, b, schema, columns)`.
    #[must_use]
    pub fn into_parts(self) -> (Vec<i32>, Vec<i32>, Schema, Vec<Column>) {
        (self.a, self.b, self.user.schema, self.user.columns)
    }
}

fn validate_builder_column_counts(
    fields: &[(String, BuilderFieldType)],
    columns: &[Column],
    row_count: usize,
) -> Result<()> {
    for (field_index, column) in columns.iter().enumerate() {
        let column_count = column_row_count(column);
        if column_count != row_count {
            return Err(Error::new(ErrorKind::ColumnLengthMismatch {
                name: fields[field_index].0.clone(),
                expected_count: row_count,
                actual_count: column_count,
            }));
        }
    }

    Ok(())
}

fn build_user_columns_from_parts(
    schema: Schema,
    columns: Vec<Column>,
    row_count: usize,
    reserved: &[&'static str],
) -> Result<UserColumns> {
    if schema.field_count() != columns.len() {
        return Err(Error::new(ErrorKind::ColumnLengthMismatch {
            name: "schema".to_string(),
            expected_count: schema.field_count(),
            actual_count: columns.len(),
        }));
    }

    for field in schema.fields() {
        check_reserved(field.name(), reserved)?;
    }

    for (field, column) in schema.fields().iter().zip(columns.iter()) {
        let actual_count = column_row_count(column);
        if actual_count != row_count {
            return Err(Error::new(ErrorKind::ColumnLengthMismatch {
                name: field.name().to_string(),
                expected_count: row_count,
                actual_count,
            }));
        }

        match (field.field_type(), column) {
            (FieldType::Numeric, Column::Numeric(_)) => {}
            (FieldType::Numeric, Column::String(_)) => {
                return Err(Error::new(ErrorKind::FieldTypeMismatch {
                    name: field.name().to_string(),
                    expected: "numeric",
                    actual: "string",
                }));
            }
            (FieldType::String { max_size }, Column::String(values)) => {
                let resolved_max_size =
                    resolve_string_max_size(field.name(), values, Some(*max_size))?;
                debug_assert_eq!(*max_size, resolved_max_size);
            }
            (FieldType::String { .. }, Column::Numeric(_)) => {
                return Err(Error::new(ErrorKind::FieldTypeMismatch {
                    name: field.name().to_string(),
                    expected: "string",
                    actual: "numeric",
                }));
            }
        }
    }

    Ok(UserColumns::new(schema, columns, row_count))
}

#[derive(Debug)]
struct TableBuilderCore {
    fields: Vec<(String, BuilderFieldType)>,
    columns: Vec<Column>,
}

impl TableBuilderCore {
    /// Accumulates user-defined builder fields before the structural wrapper
    /// validates its own required columns and constructs the final table.
    fn new() -> Self {
        Self {
            fields: Vec::new(),
            columns: Vec::new(),
        }
    }

    fn push_numeric(&mut self, name: &str, values: Vec<f64>) {
        self.fields
            .push((name.to_string(), BuilderFieldType::Numeric));
        self.columns.push(Column::Numeric(values));
    }

    fn push_string(&mut self, name: &str, values: Vec<String>) {
        self.fields.push((
            name.to_string(),
            BuilderFieldType::String { max_size: None },
        ));
        self.columns.push(Column::String(values));
    }

    fn push_string_with_max_size(&mut self, name: &str, values: Vec<String>, max_size: u16) {
        self.fields.push((
            name.to_string(),
            BuilderFieldType::String {
                max_size: Some(max_size),
            },
        ));
        self.columns.push(Column::String(values));
    }

    fn build(self, row_count: usize, reserved: &[&'static str]) -> Result<UserColumns> {
        validate_builder_column_counts(&self.fields, &self.columns, row_count)?;
        validate_builder_fields(&self.fields, reserved)?;
        let schema_fields = build_schema_fields(&self.fields, &self.columns)?;
        Ok(UserColumns::new(
            Schema::new(schema_fields),
            self.columns,
            row_count,
        ))
    }
}

/// Builder for constructing a [`NodeTable`] from pre-built vectors.
///
/// # Example
///
/// ```
/// use halimede::NodeTable;
///
/// let table = NodeTable::builder()
///     .ids(vec![1, 2, 3])
///     .column_f64("X", vec![100.0, 200.0, 300.0])
///     .column_str("NAME", vec!["a".into(), "b".into(), "c".into()])
///     .build()?;
///
/// assert_eq!(table.row_count(), 3);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug)]
pub struct NodeTableBuilder {
    ids: Option<Vec<i32>>,
    core: TableBuilderCore,
}

impl NodeTableBuilder {
    /// Create a new empty builder.
    #[must_use]
    pub fn new() -> Self {
        Self {
            ids: None,
            core: TableBuilderCore::new(),
        }
    }

    /// Set the node IDs (N field).
    #[must_use]
    pub fn ids(mut self, ids: Vec<i32>) -> Self {
        self.ids = Some(ids);
        self
    }

    /// Add a numeric column.
    #[must_use]
    pub fn column_f64(mut self, name: &str, values: Vec<f64>) -> Self {
        self.core.push_numeric(name, values);
        self
    }

    /// Add a string column.
    ///
    /// The encoded width is inferred from the longest string value.
    #[must_use]
    pub fn column_str(mut self, name: &str, values: Vec<String>) -> Self {
        self.core.push_string(name, values);
        self
    }

    /// Add a string column with an explicit maximum encoded size.
    #[must_use]
    pub fn column_str_with_max_size(
        mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Self {
        self.core.push_string_with_max_size(name, values, max_size);
        self
    }

    /// Build the [`NodeTable`], validating that all columns have the same
    /// length and that the structural ID column is present.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::MissingStructuralColumn`] if no IDs were provided,
    /// or [`ErrorKind::ColumnLengthMismatch`] if a column has a different
    /// length than the ID column.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{ErrorKind, NodeTable};
    ///
    /// // Missing IDs produces an error.
    /// let err = NodeTable::builder().build().unwrap_err();
    /// assert!(matches!(
    ///     err.kind(),
    ///     ErrorKind::MissingStructuralColumn { name: "N" },
    /// ));
    /// ```
    pub fn build(self) -> Result<NodeTable> {
        let ids = self
            .ids
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "N" }))?;
        validate_structural_ids(&ids, "N")?;

        let row_count = ids.len();
        let user = self.core.build(row_count, NODE_RESERVED)?;
        Ok(NodeTable { ids, user })
    }
}

impl Default for NodeTableBuilder {
    fn default() -> Self {
        Self::new()
    }
}

/// Builder for constructing a [`LinkTable`] from pre-built vectors.
///
/// # Example
///
/// ```
/// use halimede::LinkTable;
///
/// let table = LinkTable::builder()
///     .endpoints(vec![1, 2], vec![2, 3])
///     .column_f64("SPEED", vec![60.0, 80.0])
///     .build()?;
///
/// assert_eq!(table.row_count(), 2);
/// # Ok::<(), halimede::Error>(())
/// ```
#[derive(Debug)]
pub struct LinkTableBuilder {
    a: Option<Vec<i32>>,
    b: Option<Vec<i32>>,
    core: TableBuilderCore,
}

impl LinkTableBuilder {
    /// Create a new empty builder.
    #[must_use]
    pub fn new() -> Self {
        Self {
            a: None,
            b: None,
            core: TableBuilderCore::new(),
        }
    }

    /// Set the link endpoints (A and B fields).
    #[must_use]
    pub fn endpoints(mut self, a: Vec<i32>, b: Vec<i32>) -> Self {
        self.a = Some(a);
        self.b = Some(b);
        self
    }

    /// Add a numeric column.
    #[must_use]
    pub fn column_f64(mut self, name: &str, values: Vec<f64>) -> Self {
        self.core.push_numeric(name, values);
        self
    }

    /// Add a string column.
    ///
    /// The encoded width is inferred from the longest string value.
    #[must_use]
    pub fn column_str(mut self, name: &str, values: Vec<String>) -> Self {
        self.core.push_string(name, values);
        self
    }

    /// Add a string column with an explicit maximum encoded size.
    #[must_use]
    pub fn column_str_with_max_size(
        mut self,
        name: &str,
        values: Vec<String>,
        max_size: u16,
    ) -> Self {
        self.core.push_string_with_max_size(name, values, max_size);
        self
    }

    /// Build the [`LinkTable`], validating that all columns have the same
    /// length and that the structural endpoint columns are present.
    ///
    /// # Errors
    ///
    /// Returns [`ErrorKind::MissingStructuralColumn`] if no endpoints were
    /// provided, or [`ErrorKind::ColumnLengthMismatch`] if a column has a
    /// different length than the endpoint columns.
    ///
    /// # Example
    ///
    /// ```
    /// use halimede::{ErrorKind, LinkTable};
    ///
    /// // Mismatched column length produces an error.
    /// let err = LinkTable::builder()
    ///     .endpoints(vec![1, 2], vec![2, 3])
    ///     .column_f64("SPEED", vec![60.0])
    ///     .build()
    ///     .unwrap_err();
    /// assert!(matches!(
    ///     err.kind(),
    ///     ErrorKind::ColumnLengthMismatch { .. },
    /// ));
    /// ```
    pub fn build(self) -> Result<LinkTable> {
        let a = self
            .a
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "A" }))?;
        let b = self
            .b
            .ok_or_else(|| Error::new(ErrorKind::MissingStructuralColumn { name: "B" }))?;
        validate_structural_ids(&a, "A")?;
        validate_structural_ids(&b, "B")?;

        if a.len() != b.len() {
            return Err(Error::new(ErrorKind::ColumnLengthMismatch {
                name: "B".to_string(),
                expected_count: a.len(),
                actual_count: b.len(),
            }));
        }

        let row_count = a.len();
        let user = self.core.build(row_count, LINK_RESERVED)?;
        Ok(LinkTable { a, b, user })
    }
}

impl Default for LinkTableBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn column_row_count() {
        let num = Column::Numeric(vec![1.0, 2.0, 3.0]);
        assert_eq!(num.row_count(), 3);

        let s = Column::String(vec!["a".into(), "b".into()]);
        assert_eq!(s.row_count(), 2);
    }

    #[test]
    fn column_type_predicates() {
        let num = Column::Numeric(vec![1.0]);
        assert!(num.is_numeric());
        assert!(!num.is_string());

        let s = Column::String(vec!["a".into()]);
        assert!(s.is_string());
        assert!(!s.is_numeric());
    }

    #[test]
    fn column_as_f64_and_as_str() {
        let num = Column::Numeric(vec![1.0, 2.0]);
        assert_eq!(num.as_f64(), Some([1.0, 2.0].as_slice()));
        assert!(num.as_str().is_none());

        let s = Column::String(vec!["a".into()]);
        assert!(s.as_f64().is_none());
        assert_eq!(s.as_str().unwrap().len(), 1);
    }

    #[test]
    fn node_column_access() {
        let table = NodeTable::builder()
            .ids(vec![1, 2])
            .column_f64("X", vec![1.0, 2.0])
            .build()
            .unwrap();

        let col = table.column("X").unwrap();
        assert!(col.is_numeric());
        assert!(table.column("NOSUCH").is_err());
    }

    #[test]
    fn node_numeric_column_mut_access() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2])
            .column_f64("X", vec![1.0, 2.0])
            .build()
            .unwrap();

        table.column_f64_mut("X").unwrap()[0] = 99.0;
        assert_eq!(table.column_f64("X").unwrap(), &[99.0, 2.0]);
    }

    #[test]
    fn link_column_access() {
        let table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .column_f64("SPEED", vec![60.0])
            .build()
            .unwrap();

        let col = table.column("SPEED").unwrap();
        assert!(col.is_numeric());
        assert!(table.column("NOSUCH").is_err());
    }

    #[test]
    fn link_numeric_column_mut_access() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .column_f64("SPEED", vec![60.0])
            .build()
            .unwrap();

        table.column_f64_mut("SPEED").unwrap()[0] = 99.0;
        assert_eq!(table.column_f64("SPEED").unwrap(), &[99.0]);
    }

    #[test]
    fn structural_ids_must_be_positive() {
        let err = NodeTable::builder().ids(vec![0, 1]).build().unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::InvalidStructuralId { field: "N", .. }
        ));

        let err = LinkTable::builder()
            .endpoints(vec![1], vec![-1])
            .build()
            .unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::InvalidStructuralId { field: "B", .. }
        ));
    }

    #[test]
    fn node_add_column_f64_success() {
        let mut table = NodeTable::builder().ids(vec![1, 2]).build().unwrap();

        table.add_column_f64("X", vec![1.0, 2.0]).unwrap();
        assert_eq!(table.column_f64("X").unwrap(), &[1.0, 2.0]);
        assert_eq!(table.schema().field_count(), 1);
    }

    #[test]
    fn node_add_column_str_success() {
        let mut table = NodeTable::builder().ids(vec![1, 2]).build().unwrap();

        table
            .add_column_str("NAME", vec!["a".into(), "b".into()])
            .unwrap();
        assert_eq!(
            table.column_str("NAME").unwrap(),
            &["a".to_string(), "b".to_string()]
        );
        assert_eq!(
            table.schema().find("NAME").unwrap().field_type(),
            &FieldType::String { max_size: 1 }
        );
    }

    #[test]
    fn node_set_column_str_updates_schema_width() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2])
            .column_str("NAME", vec!["a".into(), "b".into()])
            .build()
            .unwrap();

        table
            .set_column_str("NAME", vec!["alpha".into(), "beta".into()])
            .unwrap();

        assert_eq!(
            table.schema().find("NAME").unwrap().field_type(),
            &FieldType::String { max_size: 5 }
        );
    }

    #[test]
    fn node_add_column_duplicate_name_rejected() {
        let mut table = NodeTable::builder()
            .ids(vec![1])
            .column_f64("X", vec![1.0])
            .build()
            .unwrap();

        let err = table.add_column_f64("X", vec![2.0]).unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::DuplicateFieldName { name } if name == "X"
        ));
    }

    #[test]
    fn node_add_column_length_mismatch_rejected() {
        let mut table = NodeTable::builder().ids(vec![1, 2]).build().unwrap();

        let err = table.add_column_f64("X", vec![1.0, 2.0, 3.0]).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::ColumnLengthMismatch { .. }));
    }

    #[test]
    fn link_add_column_f64_success() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .build()
            .unwrap();

        table.add_column_f64("SPEED", vec![60.0]).unwrap();
        assert_eq!(table.column_f64("SPEED").unwrap(), &[60.0]);
    }

    #[test]
    fn link_add_column_str_success() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .build()
            .unwrap();

        table.add_column_str("NAME", vec!["link1".into()]).unwrap();
        assert_eq!(table.column_str("NAME").unwrap(), &["link1".to_string()]);
        assert_eq!(
            table.schema().find("NAME").unwrap().field_type(),
            &FieldType::String { max_size: 5 }
        );
    }

    #[test]
    fn explicit_string_width_must_fit_values() {
        let err = NodeTable::builder()
            .ids(vec![1])
            .column_str_with_max_size("NAME", vec!["alpha".into()], 4)
            .build()
            .unwrap_err();

        assert!(matches!(err.kind(), ErrorKind::ValueOutOfRange { .. }));
    }

    #[test]
    fn link_add_column_duplicate_name_rejected() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .column_f64("SPEED", vec![60.0])
            .build()
            .unwrap();

        let err = table.add_column_f64("SPEED", vec![70.0]).unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::DuplicateFieldName { name } if name == "SPEED"
        ));
    }

    #[test]
    fn link_add_column_length_mismatch_rejected() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1], vec![2])
            .build()
            .unwrap();

        let err = table.add_column_f64("SPEED", vec![60.0, 70.0]).unwrap_err();
        assert!(matches!(err.kind(), ErrorKind::ColumnLengthMismatch { .. }));
    }

    #[test]
    fn retain_fields_preserves_current_order() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2, 3])
            .column_f64("X", vec![10.0, 20.0, 30.0])
            .column_f64("Y", vec![40.0, 50.0, 60.0])
            .column_str("NAME", vec!["alpha".into(), "beta".into(), "gamma".into()])
            .build()
            .unwrap();

        table.retain_fields(["NAME", "X"]).unwrap();

        let field_names: Vec<&str> = table.schema().field_names().collect();
        assert_eq!(field_names, vec!["X", "NAME"]);
    }

    #[test]
    fn resolved_fields_become_invalid_after_schema_mutation() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2, 3])
            .column_f64("X", vec![10.0, 20.0, 30.0])
            .column_f64("Y", vec![40.0, 50.0, 60.0])
            .column_str("NAME", vec!["alpha".into(), "beta".into(), "gamma".into()])
            .build()
            .unwrap();

        let name = table.resolve_field("NAME").unwrap();
        table.retain_fields(["NAME", "X"]).unwrap();

        let err = table.column_str_field(&name).unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::FieldNotFound { name } if name == "NAME"
        ));
    }

    #[test]
    fn retain_fields_rejects_unknown_field() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2])
            .column_f64("X", vec![1.0, 2.0])
            .build()
            .unwrap();

        let err = table.retain_fields(["NOSUCH"]).unwrap_err();
        assert!(matches!(
            err.kind(),
            ErrorKind::FieldNotFound { name } if name == "NOSUCH"
        ));
    }

    #[test]
    fn remove_fields_preserves_current_order() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1, 2], vec![2, 3])
            .column_f64("SPEED", vec![60.0, 80.0])
            .column_str("RDTYPE", vec!["LOCAL".into(), "ARTERIAL".into()])
            .column_f64("DIST", vec![1.5, 2.0])
            .build()
            .unwrap();

        table.remove_fields(["RDTYPE"]).unwrap();

        let field_names: Vec<&str> = table.schema().field_names().collect();
        assert_eq!(field_names, vec!["SPEED", "DIST"]);
    }

    #[test]
    fn derive_numeric_column_replaces_existing_field_in_place() {
        let mut table = NodeTable::builder()
            .ids(vec![1, 2])
            .column_f64("X", vec![1.0, 2.0])
            .column_f64("Y", vec![10.0, 20.0])
            .build()
            .unwrap();

        let x = table.resolve_field("X").unwrap();

        table
            .derive_column_f64("X", |table, row_index| {
                Ok(table.column_f64_field(&x)?[row_index] * 2.0)
            })
            .unwrap();

        let field_names: Vec<&str> = table.schema().field_names().collect();
        assert_eq!(field_names, vec!["X", "Y"]);
        assert_eq!(table.column_f64("X").unwrap(), &[2.0, 4.0]);
    }

    #[test]
    fn derive_string_column_infers_width_from_values() {
        let mut table = NodeTable::builder().ids(vec![1, 2]).build().unwrap();

        table
            .derive_column_str("LABEL", |_table, row_index| {
                Ok(match row_index {
                    0 => "a".to_string(),
                    _ => "alpha".to_string(),
                })
            })
            .unwrap();

        assert_eq!(
            table.schema().find("LABEL").unwrap().field_type(),
            &FieldType::String { max_size: 5 }
        );
        assert_eq!(
            table.column_str("LABEL").unwrap(),
            &["a".to_string(), "alpha".to_string()],
        );
    }

    #[test]
    fn derive_link_numeric_column_uses_resolved_fields() {
        let mut table = LinkTable::builder()
            .endpoints(vec![1, 2], vec![2, 3])
            .column_f64("SPEED", vec![60.0, 80.0])
            .column_f64("DIST", vec![1.5, 2.0])
            .build()
            .unwrap();

        let speed = table.resolve_field("SPEED").unwrap();
        let dist = table.resolve_field("DIST").unwrap();

        table
            .derive_column_f64("TIME", |table, row_index| {
                Ok(table.column_f64_field(&dist)?[row_index]
                    / table.column_f64_field(&speed)?[row_index])
            })
            .unwrap();

        let field_names: Vec<&str> = table.schema().field_names().collect();
        assert_eq!(field_names, vec!["SPEED", "DIST", "TIME"]);
        assert_eq!(table.column_f64("TIME").unwrap(), &[0.025, 0.025]);
    }

    #[test]
    fn node_table_from_parts_validates_schema_and_columns() {
        let schema = Schema::from_fields(vec![
            ("X".to_string(), FieldType::Numeric),
            ("NAME".to_string(), FieldType::String { max_size: 5 }),
        ])
        .unwrap();
        let table = NodeTable::from_parts(
            vec![1, 2],
            schema,
            vec![
                Column::Numeric(vec![10.0, 20.0]),
                Column::String(vec!["a".into(), "alpha".into()]),
            ],
        )
        .unwrap();

        assert_eq!(table.ids(), &[1, 2]);
        assert_eq!(table.column_f64("X").unwrap(), &[10.0, 20.0]);
        assert_eq!(
            table.column_str("NAME").unwrap(),
            &["a".to_string(), "alpha".to_string()]
        );
    }

    #[test]
    fn link_table_into_parts_roundtrips() {
        let original = LinkTable::builder()
            .endpoints(vec![1, 2], vec![2, 3])
            .column_f64("SPEED", vec![60.0, 80.0])
            .column_str("NAME", vec!["A".into(), "B".into()])
            .build()
            .unwrap();

        let (a, b, schema, columns) = original.into_parts();
        let rebuilt = LinkTable::from_parts(a, b, schema, columns).unwrap();

        assert_eq!(rebuilt.a(), &[1, 2]);
        assert_eq!(rebuilt.b(), &[2, 3]);
        assert_eq!(rebuilt.column_f64("SPEED").unwrap(), &[60.0, 80.0]);
        assert_eq!(
            rebuilt.column_str("NAME").unwrap(),
            &["A".to_string(), "B".to_string()]
        );
    }
}
