from __future__ import annotations

import numpy as np

import halimede


def test_read_golden_fixture(golden_dir):
    network = halimede.read(golden_dir / "mixed_fields.net")

    assert network.banner == "NET PGM=HALIMEDE"
    assert network.run_id == "HALIMEDE"
    assert network.zones == 1
    assert network.left_drive is False
    assert network.nodes.field_names == ("X", "NAME", "Y")
    assert network.links.field_names == ("SPEED", "RDTYPE", "DIST")
    np.testing.assert_array_equal(network.nodes.N, [1, 2, 3])
    np.testing.assert_allclose(network.nodes["X"], [100.0, 200.0, 300.0])
    assert network.nodes["NAME"].tolist() == ["alpha", "beta", "gamma"]
    np.testing.assert_array_equal(network.links.A, [1, 2])
    np.testing.assert_array_equal(network.links.B, [2, 3])
    np.testing.assert_allclose(network.links["DIST"], [1.2, 0.8])


def test_selective_read_loads_requested_fields_only(golden_dir):
    network = halimede.read(
        golden_dir / "mixed_fields.net",
        node_fields=["NAME"],
        link_fields=["DIST"],
    )

    assert network.nodes.field_names == ("NAME",)
    assert network.links.field_names == ("DIST",)
    assert network.nodes["NAME"].tolist() == ["alpha", "beta", "gamma"]
    np.testing.assert_allclose(network.links["DIST"], [1.2, 0.8])


def test_inspect_reads_metadata_and_loads_selected_fields(golden_dir):
    info = halimede.inspect(golden_dir / "mixed_fields.net")

    assert info.banner == "NET PGM=HALIMEDE"
    assert info.run_id == "HALIMEDE"
    assert info.node_row_count == 3
    assert info.link_row_count == 2
    assert info.node_field_names == ("X", "NAME", "Y")
    assert info.link_field_names == ("SPEED", "RDTYPE", "DIST")
    assert info.node_field_spec("NAME").field_type.is_string is True
    assert info.link_field_type("SPEED").is_numeric is True

    network = info.load(node_fields=["NAME"], link_fields=["DIST"])

    assert network.nodes.field_names == ("NAME",)
    assert network.links.field_names == ("DIST",)
    assert network.nodes["NAME"].tolist() == ["alpha", "beta", "gamma"]
    np.testing.assert_allclose(network.links["DIST"], [1.2, 0.8])


def test_inspect_bytes_supports_later_eager_load(small_network):
    info = halimede.inspect_bytes(small_network.to_bytes())

    assert info.run_id == "PYTEST"
    assert info.node_field_names == ("X", "NAME")
    assert info.link_field_names == ("SPEED", "RDTYPE")

    network = info.load(node_fields=["X"], link_fields=["SPEED"])

    assert network.nodes.field_names == ("X",)
    assert network.links.field_names == ("SPEED",)
    np.testing.assert_allclose(network.nodes["X"], [100.0, 200.0, 300.0])
    np.testing.assert_allclose(network.links["SPEED"], [60.0, 80.0])


def test_mutate_and_round_trip_write(tmp_path, small_network):
    network = small_network.copy()
    network.nodes.remove_fields(["NAME"])
    network.nodes["X2"] = network.nodes["X"] * 2.0
    network.links["LANE_NAME"] = np.asarray(["one", "two"], dtype=object)

    path = tmp_path / "round_trip.net"
    network.write(path)
    restored = halimede.read(path)

    assert restored.banner == "NET PGM=PYTEST"
    assert restored.run_id == "PYTEST"
    assert restored.left_drive is True
    assert restored.nodes.field_names == ("X", "X2")
    np.testing.assert_allclose(restored.nodes["X2"], [200.0, 400.0, 600.0])
    assert restored.links["LANE_NAME"].tolist() == ["one", "two"]


def test_like_preserves_structure_and_schema(small_network):
    result = halimede.like(small_network, run_id="COPY")

    assert result.run_id == "COPY"
    np.testing.assert_array_equal(result.nodes.N, small_network.nodes.N)
    np.testing.assert_array_equal(result.links.A, small_network.links.A)
    np.testing.assert_array_equal(result.links.B, small_network.links.B)
    np.testing.assert_allclose(result.nodes["X"], 0.0)
    assert result.nodes["NAME"].tolist() == ["", "", ""]
    np.testing.assert_allclose(result.links["SPEED"], 0.0)


def test_getitem_returns_live_array_view(small_network):
    speed = small_network.links["SPEED"]
    speed *= 2.0

    np.testing.assert_allclose(small_network.links["SPEED"], [120.0, 160.0])


def test_setitem_replaces_previous_array(small_network):
    previous = small_network.nodes["X"]
    small_network.nodes["X"] = np.asarray([1.0, 2.0, 3.0], dtype=np.float64)

    np.testing.assert_allclose(previous, [100.0, 200.0, 300.0])
    np.testing.assert_allclose(small_network.nodes["X"], [1.0, 2.0, 3.0])


def test_copy_detaches_python_owned_arrays(small_network):
    copied = small_network.copy()
    copied.links["SPEED"][0] = 999.0

    assert small_network.links["SPEED"][0] == 60.0


def test_table_field_lookup_and_batch_edit_helpers(small_network):
    assert small_network.nodes.field_spec("X").field_type.is_numeric is True
    assert small_network.links.field_type("RDTYPE").is_string is True

    small_network.nodes.assign({"X2": small_network.nodes["X"] * 2.0})
    small_network.links.assign(LANE_TAG=np.asarray(["one", "two"], dtype=object))
    small_network.nodes.drop("NAME")

    assert small_network.nodes.field_names == ("X", "X2")
    assert small_network.links.field_names == ("SPEED", "RDTYPE", "LANE_TAG")
    np.testing.assert_allclose(small_network.nodes["X2"], [200.0, 400.0, 600.0])
