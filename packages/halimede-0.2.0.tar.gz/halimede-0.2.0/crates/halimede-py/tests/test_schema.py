from __future__ import annotations

import pytest

import halimede
from halimede.schema import normalise_link_field_specs, normalise_node_field_specs


def test_node_field_spec_normalisation_rejects_reserved_names():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="reserved structural field name",
    ):
        normalise_node_field_specs([("N", "numeric")])


def test_link_field_spec_normalisation_rejects_duplicate_names():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="duplicate field name 'DIST'",
    ):
        normalise_link_field_specs([("DIST", "numeric"), ("DIST", "string", 4)])


def test_field_type_rejects_invalid_string_width():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="within 1..=255",
    ):
        halimede.FieldType.string(max_size=0)


def test_node_field_helper_accepts_explicit_string_width():
    spec = halimede.node_field("NAME", "string", 12)

    assert spec.name == "NAME"
    assert spec.field_type.is_string is True
    assert spec.field_type.max_size == 12


def test_network_from_pandas_infers_field_types_in_frame_order():
    import pandas as pd

    network = halimede.from_pandas(
        nodes=pd.DataFrame({"N": [1, 2], "X": [1.0, 2.0], "NAME": ["a", "b"]}),
        links=pd.DataFrame({"A": [1], "B": [2], "DIST": [3.5]}),
        banner="NET PGM=TEST",
        run_id="TEST",
    )

    assert network.nodes.field_names == ("X", "NAME")
    assert network.links.field_names == ("DIST",)
    assert network.nodes.field_specs[0].field_type.is_numeric is True
    assert network.nodes.field_specs[1].field_type.is_string is True
