from __future__ import annotations

import pandas as pd
import pytest

import halimede


def test_missing_field_lookup_suggests_close_match(small_network):
    with pytest.raises(KeyError, match=r"did you mean 'SPEED'") as error:
        _ = small_network.links["SPEE"]

    assert "available fields" in str(error.value)


def test_structural_columns_are_not_user_mapping_keys(small_network):
    assert "N" not in small_network.nodes

    with pytest.raises(KeyError, match=r"field 'N' not found"):
        _ = small_network.nodes["N"]


def test_structural_ids_reject_non_integral_values():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="must contain only integer IDs",
    ) as error:
        halimede.NodeTable([1.5], {})

    assert error.value.kind == "validation"
    assert error.value.offset is None


def test_structural_ids_reject_non_positive_values():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="must contain only positive IDs",
    ):
        halimede.LinkTable([1], [0], {})


def test_declared_string_width_is_validated_early():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="declared max_size 2",
    ):
        halimede.NodeTable(
            [1],
            {"NAME": ["toolong"]},
            field_specs=[halimede.NodeFieldSpec.string("NAME", max_size=2)],
        )


def test_banner_validation_happens_on_python_surface(small_network):
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="NET",
    ):
        small_network.banner = "BAD BANNER"


def test_node_from_pandas_requires_structural_column():
    with pytest.raises(
        halimede.HalimedeValidationError,
        match="must contain 'N'",
    ):
        halimede.NodeTable.from_pandas(pd.DataFrame({"X": [1.0]}))


def test_like_copies_lookup_tables_independently(small_network):
    copy = halimede.like(small_network)
    copy.speed_table.set(1, 1, 123.0)

    assert small_network.speed_table.get(1, 1) != 123.0


def test_root_package_keeps_low_level_core_types_internal():
    assert hasattr(halimede, "NetworkInfo")
    assert not hasattr(halimede, "FieldDef")
    assert not hasattr(halimede, "TableSchema")
    assert not hasattr(halimede, "NetworkInfoResult")
    assert not hasattr(halimede, "NetworkSchemaResult")
    assert not hasattr(halimede, "HalimedeWriterError")


def test_parse_errors_expose_kind_and_offset():
    with pytest.raises(halimede.HalimedeParseError) as error:
        halimede.from_bytes(b"")

    assert isinstance(error.value.kind, str)
    assert error.value.kind == "unexpected_eof"
    assert error.value.offset == 0
