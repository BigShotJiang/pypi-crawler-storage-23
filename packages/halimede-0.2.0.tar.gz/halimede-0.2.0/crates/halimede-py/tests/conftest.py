"""Shared fixtures for halimede test suite."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

import halimede

_PROJECT_ROOT = Path(__file__).resolve().parents[3]


def pytest_configure(config):
    storage = f"file://{_PROJECT_ROOT / 'target' / '.benchmarks'}"
    config.option.benchmark_storage = storage


@pytest.fixture
def repo_root() -> Path:
    return _PROJECT_ROOT


@pytest.fixture
def golden_dir(repo_root: Path) -> Path:
    return repo_root / "fixtures" / "golden"


@pytest.fixture
def small_network() -> halimede.Network:
    nodes = halimede.NodeTable(
        [1, 2, 3],
        {
            "X": np.asarray([100.0, 200.0, 300.0], dtype=np.float64),
            "NAME": np.asarray(["alpha", "beta", "gamma"], dtype=object),
        },
        field_specs=[
            halimede.NodeFieldSpec.float64("X"),
            halimede.NodeFieldSpec.string("NAME", max_size=15),
        ],
    )
    links = halimede.LinkTable(
        [1, 2],
        [2, 3],
        {
            "SPEED": np.asarray([60.0, 80.0], dtype=np.float64),
            "RDTYPE": np.asarray(["LOCAL", "ARTERIAL"], dtype=object),
        },
        field_specs=[
            halimede.LinkFieldSpec.float64("SPEED"),
            halimede.LinkFieldSpec.string("RDTYPE", max_size=15),
        ],
    )
    return halimede.Network.create(
        nodes,
        links,
        banner="NET PGM=PYTEST",
        run_id="PYTEST",
        zones=1,
        left_drive=True,
    )
