from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
import halimede


def test_node_table_pandas_round_trip(small_network):
    frame = small_network.nodes.to_pandas()
    restored = halimede.NodeTable.from_pandas(
        frame,
        field_specs=small_network.nodes.field_specs,
    )

    np.testing.assert_array_equal(restored.N, small_network.nodes.N)
    np.testing.assert_allclose(restored["X"], small_network.nodes["X"])
    assert restored["NAME"].tolist() == small_network.nodes["NAME"].tolist()


def test_network_from_pandas_round_trip(small_network):
    node_frame, link_frame = small_network.to_pandas_frames()

    rebuilt = halimede.from_pandas(
        nodes=node_frame,
        links=link_frame,
        node_field_specs=small_network.nodes.field_specs,
        link_field_specs=small_network.links.field_specs,
        banner="NET PGM=PANDAS",
        run_id="PANDAS",
        zones=small_network.zones,
        left_drive=small_network.left_drive,
    )
    restored = halimede.from_bytes(rebuilt.to_bytes())

    assert restored.banner == "NET PGM=PANDAS"
    assert restored.run_id == "PANDAS"
    np.testing.assert_allclose(restored.nodes["X"], [100.0, 200.0, 300.0])
    assert restored.links["RDTYPE"].tolist() == ["LOCAL", "ARTERIAL"]


def test_network_from_polars_round_trip(small_network):
    node_frame, link_frame = small_network.to_polars_frames()

    rebuilt = halimede.from_polars(
        nodes=node_frame,
        links=link_frame,
        node_field_specs=small_network.nodes.field_specs,
        link_field_specs=small_network.links.field_specs,
        banner="NET PGM=POLARS",
        run_id="POLARS",
        zones=small_network.zones,
    )
    restored = halimede.from_bytes(rebuilt.to_bytes())

    assert restored.banner == "NET PGM=POLARS"
    assert restored.run_id == "POLARS"
    np.testing.assert_array_equal(restored.nodes.N, [1, 2, 3])
    np.testing.assert_allclose(restored.links["SPEED"], [60.0, 80.0])


def test_explicit_string_width_survives_round_trip():
    node_frame = pd.DataFrame({"N": [1, 2], "NAME": ["ab", "c"]})
    link_frame = pd.DataFrame({"A": [1], "B": [2]})

    network = halimede.from_pandas(
        nodes=node_frame,
        links=link_frame,
        node_field_specs=[halimede.NodeFieldSpec.string("NAME", max_size=10)],
        banner="NET PGM=WIDTH",
        run_id="WIDTH",
    )
    restored = halimede.from_bytes(network.to_bytes())

    assert restored.nodes.field_specs[0].field_type.max_size == 10
    assert restored.nodes["NAME"].tolist() == ["ab", "c"]


def test_frame_import_reports_missing_and_unexpected_columns_together():
    frame = pd.DataFrame({"N": [1, 2], "EXTRA": [1.0, 2.0]})

    with pytest.raises(halimede.HalimedeValidationError) as error:
        halimede.NodeTable.from_pandas(
            frame,
            field_specs=[halimede.NodeFieldSpec.float64("X")],
        )

    message = str(error.value)
    assert "missing columns for fields: X" in message
    assert "unexpected columns not present in field_specs: EXTRA" in message


def test_network_frame_bundle_helpers_match_table_exports(small_network):
    node_pd, link_pd = small_network.to_pandas_frames()
    node_pl, link_pl = small_network.to_polars_frames()

    assert list(node_pd.columns) == ["N", "X", "NAME"]
    assert list(link_pd.columns) == ["A", "B", "SPEED", "RDTYPE"]
    assert node_pl.columns == ["N", "X", "NAME"]
    assert link_pl.columns == ["A", "B", "SPEED", "RDTYPE"]

    np.testing.assert_array_equal(
        node_pd["N"].to_numpy(copy=False),
        small_network.nodes.N,
    )
    np.testing.assert_array_equal(
        link_pd["A"].to_numpy(copy=False),
        small_network.links.A,
    )
