from __future__ import annotations

from pathlib import Path

import pytest
import halimede

_BENCH_DIR = Path(__file__).resolve().parents[3] / "fixtures" / "bench"

_SMALL_MIXED_PATH = _BENCH_DIR / "small_mixed_50_nodes_100_links.net"
_MEDIUM_NUMERIC_PATH = _BENCH_DIR / "medium_numeric_2000_nodes_4000_links.net"
_FIELDS_HEAVY_PATH = _BENCH_DIR / "fields_heavy_200_nodes_400_links.net"


def _load_fixture_bytes(path: Path) -> bytes:
    if not path.exists():
        pytest.skip(f"benchmark fixture not found at {path}")
    return path.read_bytes()


_small_mixed_bytes: bytes | None = None
_medium_numeric_bytes: bytes | None = None
_fields_heavy_bytes: bytes | None = None


def _get_small_mixed_bytes() -> bytes:
    global _small_mixed_bytes
    if _small_mixed_bytes is None:
        _small_mixed_bytes = _load_fixture_bytes(_SMALL_MIXED_PATH)
    return _small_mixed_bytes


def _get_medium_numeric_bytes() -> bytes:
    global _medium_numeric_bytes
    if _medium_numeric_bytes is None:
        _medium_numeric_bytes = _load_fixture_bytes(_MEDIUM_NUMERIC_PATH)
    return _medium_numeric_bytes


def _get_fields_heavy_bytes() -> bytes:
    global _fields_heavy_bytes
    if _fields_heavy_bytes is None:
        _fields_heavy_bytes = _load_fixture_bytes(_FIELDS_HEAVY_PATH)
    return _fields_heavy_bytes


def test_bench_from_bytes_small_mixed(benchmark):
    data = _get_small_mixed_bytes()
    benchmark(halimede.from_bytes, data)


def test_bench_from_bytes_medium_numeric(benchmark):
    data = _get_medium_numeric_bytes()
    benchmark(halimede.from_bytes, data)


def test_bench_from_bytes_fields_heavy_selective(benchmark):
    data = _get_fields_heavy_bytes()
    benchmark(
        halimede.from_bytes,
        data,
        node_fields=["F01", "F02", "F03", "S01"],
        link_fields=["G01", "G02", "G03", "T01"],
    )


def test_bench_to_bytes_medium_numeric(benchmark):
    network = halimede.from_bytes(_get_medium_numeric_bytes())
    benchmark(network.to_bytes)


def test_bench_nodes_to_pandas_medium_numeric(benchmark):
    network = halimede.from_bytes(_get_medium_numeric_bytes())
    benchmark(network.nodes.to_pandas)


def test_bench_load_edit_write_selective_medium_numeric(benchmark):
    data = _get_medium_numeric_bytes()

    def load_edit_write() -> bytes:
        network = halimede.from_bytes(
            data,
            node_fields=["X", "ACCESS", "POP"],
            link_fields=["DIST", "TIME", "TOLL"],
        )
        network.nodes["ACCESS_X_POP"] = network.nodes["ACCESS"] * network.nodes["POP"]
        network.links["GENCOST"] = network.links["TIME"] + network.links["TOLL"] * 2.5
        network.links.remove_fields(["TOLL"])
        return network.to_bytes()

    benchmark(load_edit_write)
