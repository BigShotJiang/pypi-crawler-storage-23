//! Thin Rust core bindings for the Python package.
//!
//! The public Python package in `python/halimede/` wraps this module. The Rust
//! side stays focused on strict parse, validation, and write paths. The Python
//! layer owns the eager NumPy-first editing surface.

use std::path::PathBuf;

use halimede::{
    Column, ErrorKind, FieldType as RustFieldType, LinkTable, LookupTable, Network, NetworkInfo,
    NetworkMetadata, NodeTable, SPDCAP_CELLS, SPDCAP_CLASSES, SPDCAP_LANES, Schema,
};
use numpy::ndarray::{Array1, Array2};
use numpy::{
    IntoPyArray, PyArray1, PyArray2, PyReadonlyArray1, PyReadonlyArray2, PyUntypedArrayMethods,
};
use pyo3::create_exception;
use pyo3::exceptions::{PyException, PyRuntimeError, PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBytes, PyList, PyModule};

create_exception!(halimede, HalimedeError, PyException);
create_exception!(halimede, HalimedeIoError, HalimedeError);
create_exception!(halimede, HalimedeParseError, HalimedeError);
create_exception!(halimede, HalimedeValidationError, HalimedeError);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ParsedFieldType {
    Numeric,
    String { max_size: Option<u16> },
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ParsedFieldDef {
    name: String,
    field_type: ParsedFieldType,
}

impl ParsedFieldDef {
    fn new(name: String, field_type: ParsedFieldType) -> PyResult<Self> {
        if name.is_empty() {
            return Err(PyValueError::new_err("field name must not be empty"));
        }
        Ok(Self { name, field_type })
    }

    fn kind_name(&self) -> &'static str {
        match self.field_type {
            ParsedFieldType::Numeric => "numeric",
            ParsedFieldType::String { .. } => "string",
        }
    }

    fn max_size(&self) -> Option<u16> {
        match self.field_type {
            ParsedFieldType::Numeric => None,
            ParsedFieldType::String { max_size } => max_size,
        }
    }
}

#[pyclass(
    name = "FieldDef",
    module = "halimede._halimede",
    frozen,
    skip_from_py_object
)]
#[derive(Debug, Clone, PartialEq, Eq)]
struct PyFieldDef {
    #[pyo3(get)]
    name: String,
    #[pyo3(get)]
    field_type: String,
    #[pyo3(get)]
    max_size: Option<u16>,
}

impl PyFieldDef {
    fn from_parsed(field: &ParsedFieldDef) -> Self {
        Self {
            name: field.name.clone(),
            field_type: field.kind_name().to_string(),
            max_size: field.max_size(),
        }
    }

    fn from_rust(field: &halimede::FieldDef) -> Self {
        match field.field_type() {
            RustFieldType::Numeric => Self {
                name: field.name().to_string(),
                field_type: "numeric".to_string(),
                max_size: None,
            },
            RustFieldType::String { max_size } => Self {
                name: field.name().to_string(),
                field_type: "string".to_string(),
                max_size: Some(*max_size),
            },
        }
    }

    fn to_parsed(&self) -> PyResult<ParsedFieldDef> {
        ParsedFieldDef::new(
            self.name.clone(),
            parse_field_type_name(&self.field_type, self.max_size)?,
        )
    }
}

#[pymethods]
impl PyFieldDef {
    #[new]
    #[pyo3(signature = (name, field_type, max_size=None), text_signature = "(name, field_type, max_size=None, /)")]
    fn new(name: String, field_type: &Bound<'_, PyAny>, max_size: Option<u16>) -> PyResult<Self> {
        let field_type_name = field_type
            .extract::<String>()
            .map_err(|_| PyTypeError::new_err("field_type must be 'numeric' or 'string'"))?;
        let parsed = ParsedFieldDef::new(name, parse_field_type_name(&field_type_name, max_size)?)?;
        Ok(Self::from_parsed(&parsed))
    }

    fn __repr__(&self) -> String {
        match self.max_size {
            Some(max_size) => format!(
                "FieldDef(name={:?}, field_type={:?}, max_size={})",
                self.name, self.field_type, max_size
            ),
            None => format!(
                "FieldDef(name={:?}, field_type={:?})",
                self.name, self.field_type
            ),
        }
    }
}

#[pyclass(
    name = "TableSchema",
    module = "halimede._halimede",
    frozen,
    skip_from_py_object
)]
#[derive(Debug, Clone, PartialEq, Eq)]
struct PyTableSchema {
    fields: Vec<PyFieldDef>,
}

impl PyTableSchema {
    fn from_rust(schema: &halimede::Schema) -> Self {
        Self {
            fields: schema.fields().iter().map(PyFieldDef::from_rust).collect(),
        }
    }
}

#[pymethods]
impl PyTableSchema {
    #[getter]
    fn field_count(&self) -> usize {
        self.fields.len()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn fields(&self) -> Vec<PyFieldDef> {
        self.fields.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn field_names(&self) -> Vec<String> {
        self.fields.iter().map(|field| field.name.clone()).collect()
    }

    #[pyo3(text_signature = "($self, name, /)")]
    fn find(&self, name: &str) -> Option<PyFieldDef> {
        self.fields.iter().find(|field| field.name == name).cloned()
    }

    fn __repr__(&self) -> String {
        format!("TableSchema(field_count={})", self.fields.len())
    }
}

#[pyclass(
    name = "NetworkSchemaResult",
    module = "halimede._halimede",
    frozen,
    skip_from_py_object
)]
#[derive(Debug, Clone)]
struct PyNetworkSchemaResult {
    #[pyo3(get)]
    banner: String,
    #[pyo3(get)]
    run_id: String,
    #[pyo3(get)]
    zones: u32,
    #[pyo3(get)]
    left_drive: bool,
    node_schema: PyTableSchema,
    link_schema: PyTableSchema,
}

impl PyNetworkSchemaResult {
    fn from_metadata(
        metadata: &NetworkMetadata,
        node_fields: &[ParsedFieldDef],
        link_fields: &[ParsedFieldDef],
    ) -> Self {
        Self {
            banner: metadata.banner().to_string(),
            run_id: metadata.run_id().to_string(),
            zones: metadata.zones(),
            left_drive: metadata.left_drive(),
            node_schema: PyTableSchema {
                fields: node_fields.iter().map(PyFieldDef::from_parsed).collect(),
            },
            link_schema: PyTableSchema {
                fields: link_fields.iter().map(PyFieldDef::from_parsed).collect(),
            },
        }
    }
}

#[pymethods]
impl PyNetworkSchemaResult {
    #[pyo3(text_signature = "($self, /)")]
    fn node_schema(&self) -> PyTableSchema {
        self.node_schema.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_schema(&self) -> PyTableSchema {
        self.link_schema.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "NetworkSchemaResult(node_fields={}, link_fields={})",
            self.node_schema.fields.len(),
            self.link_schema.fields.len()
        )
    }
}

#[pyclass(
    name = "NetworkInfoResult",
    module = "halimede._halimede",
    frozen,
    skip_from_py_object
)]
#[derive(Debug)]
struct PyNetworkInfoResult {
    #[pyo3(get)]
    banner: String,
    #[pyo3(get)]
    run_id: String,
    #[pyo3(get)]
    zones: u32,
    #[pyo3(get)]
    left_drive: bool,
    #[pyo3(get)]
    node_row_count: usize,
    #[pyo3(get)]
    link_row_count: usize,
    node_schema: PyTableSchema,
    link_schema: PyTableSchema,
    speed_table: Py<PyArray2<f64>>,
    capacity_table: Py<PyArray2<f64>>,
}

impl PyNetworkInfoResult {
    fn from_rust(py: Python<'_>, info: NetworkInfo) -> Self {
        let (header, speed_table, capacity_table, node_schema, link_schema) = info.into_parts();
        Self {
            banner: header.banner().to_string(),
            run_id: header.run_id().to_string(),
            zones: header.zones(),
            left_drive: header.left_drive(),
            node_row_count: header.node_rec_count() as usize,
            link_row_count: header.link_count() as usize,
            node_schema: PyTableSchema::from_rust(&node_schema),
            link_schema: PyTableSchema::from_rust(&link_schema),
            speed_table: lookup_to_py_array_owned(py, speed_table),
            capacity_table: lookup_to_py_array_owned(py, capacity_table),
        }
    }
}

#[pymethods]
impl PyNetworkInfoResult {
    #[staticmethod]
    #[pyo3(text_signature = "(path, /)")]
    fn open(py: Python<'_>, path: PathBuf) -> PyResult<Self> {
        let info = py.detach(|| NetworkInfo::open(path)).map_err(to_py_error)?;
        Ok(Self::from_rust(py, info))
    }

    #[staticmethod]
    #[pyo3(text_signature = "(bytes, /)")]
    fn from_bytes(py: Python<'_>, bytes: &[u8]) -> PyResult<Self> {
        let owned = bytes.to_vec();
        let info = py
            .detach(|| NetworkInfo::from_bytes(&owned))
            .map_err(to_py_error)?;
        Ok(Self::from_rust(py, info))
    }

    #[pyo3(text_signature = "($self, /)")]
    fn node_schema(&self) -> PyTableSchema {
        self.node_schema.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_schema(&self) -> PyTableSchema {
        self.link_schema.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn speed_table<'py>(&self, py: Python<'py>) -> Py<PyArray2<f64>> {
        self.speed_table.clone_ref(py)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn capacity_table<'py>(&self, py: Python<'py>) -> Py<PyArray2<f64>> {
        self.capacity_table.clone_ref(py)
    }

    fn __repr__(&self) -> String {
        format!(
            "NetworkInfoResult(node_row_count={}, link_row_count={}, node_fields={}, link_fields={})",
            self.node_row_count,
            self.link_row_count,
            self.node_schema.fields.len(),
            self.link_schema.fields.len()
        )
    }
}

#[pyclass(
    name = "_CoreSnapshot",
    module = "halimede._halimede",
    frozen,
    skip_from_py_object
)]
#[derive(Debug)]
struct PyCoreSnapshot {
    #[pyo3(get)]
    banner: String,
    #[pyo3(get)]
    run_id: String,
    #[pyo3(get)]
    zones: u32,
    #[pyo3(get)]
    left_drive: bool,
    node_ids: Py<PyArray1<i32>>,
    node_fields: Vec<PyFieldDef>,
    node_columns: Vec<Py<PyAny>>,
    link_a: Py<PyArray1<i32>>,
    link_b: Py<PyArray1<i32>>,
    link_fields: Vec<PyFieldDef>,
    link_columns: Vec<Py<PyAny>>,
    speed_table: Py<PyArray2<f64>>,
    capacity_table: Py<PyArray2<f64>>,
}

impl PyCoreSnapshot {
    fn from_network(py: Python<'_>, network: Network) -> PyResult<Self> {
        let (header, speed_table, capacity_table, nodes, links) = network.into_parts();
        let (node_ids, node_schema, node_columns) = nodes.into_parts();
        let (link_a, link_b, link_schema, link_columns) = links.into_parts();
        let (node_fields, node_columns) = table_snapshot_columns(py, node_schema, node_columns)?;
        let (link_fields, link_columns) = table_snapshot_columns(py, link_schema, link_columns)?;

        Ok(Self {
            banner: header.banner().to_string(),
            run_id: header.run_id().to_string(),
            zones: header.zones(),
            left_drive: header.left_drive(),
            node_ids: Array1::from_vec(node_ids).into_pyarray(py).unbind(),
            node_fields,
            node_columns,
            link_a: Array1::from_vec(link_a).into_pyarray(py).unbind(),
            link_b: Array1::from_vec(link_b).into_pyarray(py).unbind(),
            link_fields,
            link_columns,
            speed_table: lookup_to_py_array_owned(py, speed_table),
            capacity_table: lookup_to_py_array_owned(py, capacity_table),
        })
    }
}

#[pymethods]
impl PyCoreSnapshot {
    #[pyo3(text_signature = "($self, /)")]
    fn node_ids<'py>(&self, py: Python<'py>) -> Py<PyArray1<i32>> {
        self.node_ids.clone_ref(py)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn node_fields(&self) -> Vec<PyFieldDef> {
        self.node_fields.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn node_columns(&self, py: Python<'_>) -> Vec<Py<PyAny>> {
        self.node_columns
            .iter()
            .map(|column| column.clone_ref(py))
            .collect()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_a<'py>(&self, py: Python<'py>) -> Py<PyArray1<i32>> {
        self.link_a.clone_ref(py)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_b<'py>(&self, py: Python<'py>) -> Py<PyArray1<i32>> {
        self.link_b.clone_ref(py)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_fields(&self) -> Vec<PyFieldDef> {
        self.link_fields.clone()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_columns(&self, py: Python<'_>) -> Vec<Py<PyAny>> {
        self.link_columns
            .iter()
            .map(|column| column.clone_ref(py))
            .collect()
    }

    #[pyo3(text_signature = "($self, /)")]
    fn speed_table<'py>(&self, py: Python<'py>) -> Py<PyArray2<f64>> {
        self.speed_table.clone_ref(py)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn capacity_table<'py>(&self, py: Python<'py>) -> Py<PyArray2<f64>> {
        self.capacity_table.clone_ref(py)
    }
}

#[pyclass(
    name = "_NetworkCore",
    module = "halimede._halimede",
    skip_from_py_object
)]
#[derive(Debug)]
struct PyNetworkCore {
    inner: Option<Network>,
}

impl PyNetworkCore {
    fn inner(&self) -> PyResult<&Network> {
        self.inner
            .as_ref()
            .ok_or_else(|| PyRuntimeError::new_err("_NetworkCore has already been consumed"))
    }

    fn clone_inner(&self) -> PyResult<Network> {
        Ok(self.inner()?.clone())
    }
}

#[pymethods]
impl PyNetworkCore {
    #[staticmethod]
    #[pyo3(text_signature = "(path, /)")]
    fn open(py: Python<'_>, path: PathBuf) -> PyResult<Self> {
        let inner = py.detach(|| Network::open(path)).map_err(to_py_error)?;
        Ok(Self { inner: Some(inner) })
    }

    #[staticmethod]
    #[pyo3(text_signature = "(bytes, /)")]
    fn from_bytes(py: Python<'_>, bytes: &[u8]) -> PyResult<Self> {
        let owned = bytes.to_vec();
        let inner = py
            .detach(|| Network::from_bytes(&owned))
            .map_err(to_py_error)?;
        Ok(Self { inner: Some(inner) })
    }

    #[staticmethod]
    #[pyo3(text_signature = "(path, node_fields, link_fields, /)")]
    fn open_fields(
        py: Python<'_>,
        path: PathBuf,
        node_fields: Vec<String>,
        link_fields: Vec<String>,
    ) -> PyResult<Self> {
        let inner = py
            .detach(|| {
                let node_field_refs: Vec<&str> = node_fields.iter().map(String::as_str).collect();
                let link_field_refs: Vec<&str> = link_fields.iter().map(String::as_str).collect();
                Network::open_fields(path, node_field_refs, link_field_refs)
            })
            .map_err(to_py_error)?;
        Ok(Self { inner: Some(inner) })
    }

    #[staticmethod]
    #[pyo3(text_signature = "(bytes, node_fields, link_fields, /)")]
    fn from_bytes_fields(
        py: Python<'_>,
        bytes: &[u8],
        node_fields: Vec<String>,
        link_fields: Vec<String>,
    ) -> PyResult<Self> {
        let owned = bytes.to_vec();
        let inner = py
            .detach(|| {
                let node_field_refs: Vec<&str> = node_fields.iter().map(String::as_str).collect();
                let link_field_refs: Vec<&str> = link_fields.iter().map(String::as_str).collect();
                Network::from_bytes_fields(&owned, node_field_refs, link_field_refs)
            })
            .map_err(to_py_error)?;
        Ok(Self { inner: Some(inner) })
    }

    #[staticmethod]
    #[pyo3(
        signature = (node_fields, link_fields, banner=None, run_id=None, zones=None, left_drive=false),
        text_signature = "(node_fields, link_fields, banner=None, run_id=None, zones=None, left_drive=False)"
    )]
    fn validate_schema(
        node_fields: &Bound<'_, PyAny>,
        link_fields: &Bound<'_, PyAny>,
        banner: Option<String>,
        run_id: Option<String>,
        zones: Option<u32>,
        left_drive: bool,
    ) -> PyResult<PyNetworkSchemaResult> {
        let parsed_node_fields = parse_field_defs(node_fields)?;
        let parsed_link_fields = parse_field_defs(link_fields)?;
        let metadata = NetworkMetadata::new(
            banner.as_deref(),
            run_id.as_deref(),
            zones.unwrap_or(0),
            left_drive,
        )
        .map_err(to_py_error)?;
        Ok(PyNetworkSchemaResult::from_metadata(
            &metadata,
            &parsed_node_fields,
            &parsed_link_fields,
        ))
    }

    #[getter]
    fn banner(&self) -> PyResult<&str> {
        Ok(self.inner()?.header().banner())
    }

    #[getter]
    fn run_id(&self) -> PyResult<&str> {
        Ok(self.inner()?.header().run_id())
    }

    #[getter]
    fn zones(&self) -> PyResult<u32> {
        Ok(self.inner()?.header().zones())
    }

    #[getter]
    fn left_drive(&self) -> PyResult<bool> {
        Ok(self.inner()?.header().left_drive())
    }

    #[getter]
    fn node_row_count(&self) -> PyResult<usize> {
        Ok(self.inner()?.nodes().row_count())
    }

    #[getter]
    fn link_row_count(&self) -> PyResult<usize> {
        Ok(self.inner()?.links().row_count())
    }

    #[pyo3(text_signature = "($self, /)")]
    fn node_schema(&self) -> PyResult<PyTableSchema> {
        Ok(PyTableSchema::from_rust(self.inner()?.nodes().schema()))
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_schema(&self) -> PyResult<PyTableSchema> {
        Ok(PyTableSchema::from_rust(self.inner()?.links().schema()))
    }

    #[pyo3(text_signature = "($self, /)")]
    fn node_ids<'py>(&self, py: Python<'py>) -> PyResult<Py<PyArray1<i32>>> {
        Ok(Array1::from_vec(self.inner()?.nodes().ids().to_vec())
            .into_pyarray(py)
            .unbind())
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_a<'py>(&self, py: Python<'py>) -> PyResult<Py<PyArray1<i32>>> {
        Ok(Array1::from_vec(self.inner()?.links().a().to_vec())
            .into_pyarray(py)
            .unbind())
    }

    #[pyo3(text_signature = "($self, /)")]
    fn link_b<'py>(&self, py: Python<'py>) -> PyResult<Py<PyArray1<i32>>> {
        Ok(Array1::from_vec(self.inner()?.links().b().to_vec())
            .into_pyarray(py)
            .unbind())
    }

    #[pyo3(text_signature = "($self, name, /)")]
    fn node_numeric_column<'py>(&self, py: Python<'py>, name: &str) -> PyResult<Py<PyArray1<f64>>> {
        let values = self
            .inner()?
            .nodes()
            .column_f64(name)
            .map_err(to_py_error)?;
        Ok(Array1::from_vec(values.to_vec()).into_pyarray(py).unbind())
    }

    #[pyo3(text_signature = "($self, name, /)")]
    fn node_string_column(&self, name: &str) -> PyResult<Vec<String>> {
        Ok(self
            .inner()?
            .nodes()
            .column_str(name)
            .map_err(to_py_error)?
            .to_vec())
    }

    #[pyo3(text_signature = "($self, name, /)")]
    fn link_numeric_column<'py>(&self, py: Python<'py>, name: &str) -> PyResult<Py<PyArray1<f64>>> {
        let values = self
            .inner()?
            .links()
            .column_f64(name)
            .map_err(to_py_error)?;
        Ok(Array1::from_vec(values.to_vec()).into_pyarray(py).unbind())
    }

    #[pyo3(text_signature = "($self, name, /)")]
    fn link_string_column(&self, name: &str) -> PyResult<Vec<String>> {
        Ok(self
            .inner()?
            .links()
            .column_str(name)
            .map_err(to_py_error)?
            .to_vec())
    }

    #[pyo3(text_signature = "($self, /)")]
    fn speed_table<'py>(&self, py: Python<'py>) -> PyResult<Py<PyArray2<f64>>> {
        Ok(lookup_to_py_array(py, self.inner()?.speed_table()))
    }

    #[pyo3(text_signature = "($self, /)")]
    fn capacity_table<'py>(&self, py: Python<'py>) -> PyResult<Py<PyArray2<f64>>> {
        Ok(lookup_to_py_array(py, self.inner()?.capacity_table()))
    }

    #[pyo3(text_signature = "($self, /)")]
    fn take_snapshot<'py>(&mut self, py: Python<'py>) -> PyResult<PyCoreSnapshot> {
        let inner = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("_NetworkCore has already been consumed"))?;
        PyCoreSnapshot::from_network(py, inner)
    }

    #[pyo3(text_signature = "($self, path, /)")]
    fn write(&self, py: Python<'_>, path: PathBuf) -> PyResult<()> {
        let inner = self.clone_inner()?;
        py.detach(|| inner.write_to(path)).map_err(to_py_error)
    }

    #[pyo3(text_signature = "($self, /)")]
    fn to_bytes<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let inner = self.clone_inner()?;
        let bytes = py.detach(|| inner.to_bytes()).map_err(to_py_error)?;
        Ok(PyBytes::new(py, &bytes).into())
    }

    fn __bytes__<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        self.to_bytes(py)
    }

    #[staticmethod]
    #[pyo3(
        signature = (
            path,
            node_ids,
            node_fields,
            node_columns,
            link_a,
            link_b,
            link_fields,
            link_columns,
            speed_table,
            capacity_table,
            banner=None,
            run_id=None,
            zones=None,
            left_drive=false
        ),
        text_signature = "(path, node_ids, node_fields, node_columns, link_a, link_b, link_fields, link_columns, speed_table, capacity_table, banner=None, run_id=None, zones=None, left_drive=False)"
    )]
    #[allow(clippy::too_many_arguments)]
    fn write_from_parts(
        py: Python<'_>,
        path: PathBuf,
        node_ids: PyReadonlyArray1<'_, i32>,
        node_fields: &Bound<'_, PyAny>,
        node_columns: &Bound<'_, PyAny>,
        link_a: PyReadonlyArray1<'_, i32>,
        link_b: PyReadonlyArray1<'_, i32>,
        link_fields: &Bound<'_, PyAny>,
        link_columns: &Bound<'_, PyAny>,
        speed_table: PyReadonlyArray2<'_, f64>,
        capacity_table: PyReadonlyArray2<'_, f64>,
        banner: Option<String>,
        run_id: Option<String>,
        zones: Option<u32>,
        left_drive: bool,
    ) -> PyResult<()> {
        let network = build_network_from_parts(
            node_ids,
            node_fields,
            node_columns,
            link_a,
            link_b,
            link_fields,
            link_columns,
            speed_table,
            capacity_table,
            banner,
            run_id,
            zones,
            left_drive,
        )?;
        py.detach(|| network.write_to(path)).map_err(to_py_error)
    }

    #[staticmethod]
    #[pyo3(
        signature = (
            node_ids,
            node_fields,
            node_columns,
            link_a,
            link_b,
            link_fields,
            link_columns,
            speed_table,
            capacity_table,
            banner=None,
            run_id=None,
            zones=None,
            left_drive=false
        ),
        text_signature = "(node_ids, node_fields, node_columns, link_a, link_b, link_fields, link_columns, speed_table, capacity_table, banner=None, run_id=None, zones=None, left_drive=False)"
    )]
    #[allow(clippy::too_many_arguments)]
    fn to_bytes_from_parts<'py>(
        py: Python<'py>,
        node_ids: PyReadonlyArray1<'_, i32>,
        node_fields: &Bound<'_, PyAny>,
        node_columns: &Bound<'_, PyAny>,
        link_a: PyReadonlyArray1<'_, i32>,
        link_b: PyReadonlyArray1<'_, i32>,
        link_fields: &Bound<'_, PyAny>,
        link_columns: &Bound<'_, PyAny>,
        speed_table: PyReadonlyArray2<'_, f64>,
        capacity_table: PyReadonlyArray2<'_, f64>,
        banner: Option<String>,
        run_id: Option<String>,
        zones: Option<u32>,
        left_drive: bool,
    ) -> PyResult<Py<PyBytes>> {
        let network = build_network_from_parts(
            node_ids,
            node_fields,
            node_columns,
            link_a,
            link_b,
            link_fields,
            link_columns,
            speed_table,
            capacity_table,
            banner,
            run_id,
            zones,
            left_drive,
        )?;
        let bytes = py.detach(|| network.to_bytes()).map_err(to_py_error)?;
        Ok(PyBytes::new(py, &bytes).into())
    }

    fn __repr__(&self) -> String {
        match self.inner.as_ref() {
            Some(inner) => format!(
                "_NetworkCore(node_row_count={}, link_row_count={})",
                inner.nodes().row_count(),
                inner.links().row_count()
            ),
            None => "_NetworkCore(consumed=True)".to_string(),
        }
    }
}

fn parse_field_defs(fields: &Bound<'_, PyAny>) -> PyResult<Vec<ParsedFieldDef>> {
    let mut parsed = Vec::new();
    for (field_index, item_result) in fields.try_iter()?.enumerate() {
        let item = item_result?;
        parsed.push(parse_field_def_item(&item, field_index)?);
    }
    Ok(parsed)
}

fn parse_field_def_item(item: &Bound<'_, PyAny>, field_index: usize) -> PyResult<ParsedFieldDef> {
    if let Ok(field) = item.extract::<PyRef<'_, PyFieldDef>>() {
        return field.to_parsed();
    }

    if let Ok((name, field_type)) = item.extract::<(String, String)>() {
        return ParsedFieldDef::new(name, parse_field_type_name(&field_type, None)?);
    }

    if let Ok((name, field_type, max_size)) = item.extract::<(String, String, u16)>() {
        return ParsedFieldDef::new(name, parse_field_type_name(&field_type, Some(max_size))?);
    }

    Err(PyTypeError::new_err(format!(
        "fields[{field_index}] must be FieldDef, (name, field_type), or (name, field_type, max_size)"
    )))
}

fn parse_field_type_name(name: &str, max_size: Option<u16>) -> PyResult<ParsedFieldType> {
    match name {
        "numeric" => {
            if max_size.is_some() {
                return Err(PyValueError::new_err(
                    "numeric fields must not declare max_size",
                ));
            }
            Ok(ParsedFieldType::Numeric)
        }
        "string" => {
            if let Some(max_size) = max_size {
                if max_size == 0 || max_size > 255 {
                    return Err(PyValueError::new_err(
                        "string field max_size must be within 1..=255",
                    ));
                }
            }
            Ok(ParsedFieldType::String { max_size })
        }
        _ => Err(PyValueError::new_err(
            "field_type must be 'numeric' or 'string'",
        )),
    }
}

fn lookup_to_py_array<'py>(py: Python<'py>, table: &LookupTable) -> Py<PyArray2<f64>> {
    let values = Array2::from_shape_vec((SPDCAP_LANES, SPDCAP_CLASSES), table.as_slice().to_vec())
        .expect("lookup table shape must be valid");
    values.into_pyarray(py).unbind()
}

fn lookup_to_py_array_owned<'py>(py: Python<'py>, table: LookupTable) -> Py<PyArray2<f64>> {
    let values = Array2::from_shape_vec(
        (SPDCAP_LANES, SPDCAP_CLASSES),
        Vec::from(table.into_values()),
    )
    .expect("lookup table shape must be valid");
    values.into_pyarray(py).unbind()
}

fn column_to_py_any(py: Python<'_>, column: Column) -> PyResult<Py<PyAny>> {
    match column {
        Column::Numeric(values) => Ok(Array1::from_vec(values)
            .into_pyarray(py)
            .unbind()
            .into_any()),
        Column::String(values) => Ok(PyList::new(py, values)?.unbind().into_any()),
    }
}

fn table_snapshot_columns(
    py: Python<'_>,
    schema: Schema,
    columns: Vec<Column>,
) -> PyResult<(Vec<PyFieldDef>, Vec<Py<PyAny>>)> {
    let mut field_defs = Vec::with_capacity(schema.field_count());
    let mut py_columns = Vec::with_capacity(columns.len());
    for (field, column) in schema.fields().iter().zip(columns.into_iter()) {
        field_defs.push(PyFieldDef::from_rust(field));
        py_columns.push(column_to_py_any(py, column)?);
    }
    Ok((field_defs, py_columns))
}

fn copy_i32_array(values: PyReadonlyArray1<'_, i32>, label: &str) -> PyResult<Vec<i32>> {
    let shape = values.shape();
    if shape.len() != 1 {
        return Err(PyValueError::new_err(format!(
            "{label} must be a one-dimensional array"
        )));
    }

    let array = values.as_array();
    Ok(match array.as_slice() {
        Some(slice) => slice.to_vec(),
        None => array.iter().copied().collect(),
    })
}

fn copy_f64_array(
    values: PyReadonlyArray1<'_, f64>,
    expected_count: usize,
    label: &str,
) -> PyResult<Vec<f64>> {
    let shape = values.shape();
    if shape != [expected_count] {
        return Err(PyValueError::new_err(format!(
            "{label} must have shape ({expected_count},) (got {shape:?})"
        )));
    }

    let array = values.as_array();
    Ok(match array.as_slice() {
        Some(slice) => slice.to_vec(),
        None => array.iter().copied().collect(),
    })
}

fn copy_string_values(
    values: &Bound<'_, PyAny>,
    expected_count: usize,
    label: &str,
) -> PyResult<Vec<String>> {
    let parsed = values.extract::<Vec<String>>().map_err(|_| {
        PyTypeError::new_err(format!("{label} must be a sequence of Python strings"))
    })?;

    if parsed.len() != expected_count {
        return Err(PyValueError::new_err(format!(
            "{label} must contain {expected_count} values (got {})",
            parsed.len()
        )));
    }

    Ok(parsed)
}

fn copy_lookup_table(values: PyReadonlyArray2<'_, f64>, label: &str) -> PyResult<LookupTable> {
    let shape = values.shape();
    let expected_shape = [SPDCAP_LANES, SPDCAP_CLASSES];
    if shape != expected_shape {
        return Err(PyValueError::new_err(format!(
            "{label} must have shape ({}, {}) (got {shape:?})",
            SPDCAP_LANES, SPDCAP_CLASSES
        )));
    }

    let mut flat_values = [0.0; SPDCAP_CELLS];
    let array = values.as_array();
    if let Some(slice) = array.as_slice() {
        flat_values.copy_from_slice(slice);
    } else {
        for lane_index in 0..SPDCAP_LANES {
            for class_index in 0..SPDCAP_CLASSES {
                flat_values[lane_index * SPDCAP_CLASSES + class_index] =
                    array[[lane_index, class_index]];
            }
        }
    }

    Ok(LookupTable::from_values(flat_values))
}

fn collect_column_items(columns: &Bound<'_, PyAny>) -> PyResult<Vec<Py<PyAny>>> {
    let mut items = Vec::new();
    for item_result in columns.try_iter()? {
        items.push(item_result?.unbind());
    }
    Ok(items)
}

fn infer_string_max_size(values: &[String], label: &str) -> PyResult<u16> {
    let max_size = values.iter().map(String::len).max().unwrap_or(0).max(1);
    if max_size > 255 {
        return Err(PyValueError::new_err(format!(
            "{label} contains values wider than 255 encoded bytes"
        )));
    }

    Ok(max_size as u16)
}

fn build_node_table(
    py: Python<'_>,
    ids: Vec<i32>,
    fields: &[ParsedFieldDef],
    columns: &[Py<PyAny>],
) -> PyResult<NodeTable> {
    if fields.len() != columns.len() {
        return Err(PyValueError::new_err(format!(
            "node field count {} does not match node column count {}",
            fields.len(),
            columns.len()
        )));
    }

    let row_count = ids.len();
    let mut schema_fields = Vec::with_capacity(fields.len());
    let mut raw_columns = Vec::with_capacity(fields.len());
    for (field_index, field) in fields.iter().enumerate() {
        let column = columns[field_index].bind(py);
        match field.field_type {
            ParsedFieldType::Numeric => {
                let values = column
                    .extract::<PyReadonlyArray1<'_, f64>>()
                    .map_err(|_| {
                        PyTypeError::new_err(format!(
                            "node column {:?} must be a NumPy float64 array",
                            field.name
                        ))
                    })
                    .and_then(|array| {
                        copy_f64_array(array, row_count, &format!("node column {:?}", field.name))
                    })?;
                schema_fields.push((field.name.clone(), RustFieldType::Numeric));
                raw_columns.push(Column::Numeric(values));
            }
            ParsedFieldType::String { max_size } => {
                let values = copy_string_values(
                    column,
                    row_count,
                    &format!("node column {:?}", field.name),
                )?;
                let max_size = max_size.unwrap_or(infer_string_max_size(
                    &values,
                    &format!("node column {:?}", field.name),
                )?);
                schema_fields.push((field.name.clone(), RustFieldType::String { max_size }));
                raw_columns.push(Column::String(values));
            }
        }
    }

    let schema = Schema::from_fields(schema_fields).map_err(to_py_error)?;
    NodeTable::from_parts(ids, schema, raw_columns).map_err(to_py_error)
}

fn build_link_table(
    py: Python<'_>,
    a: Vec<i32>,
    b: Vec<i32>,
    fields: &[ParsedFieldDef],
    columns: &[Py<PyAny>],
) -> PyResult<LinkTable> {
    if fields.len() != columns.len() {
        return Err(PyValueError::new_err(format!(
            "link field count {} does not match link column count {}",
            fields.len(),
            columns.len()
        )));
    }

    let row_count = a.len();
    let mut schema_fields = Vec::with_capacity(fields.len());
    let mut raw_columns = Vec::with_capacity(fields.len());
    for (field_index, field) in fields.iter().enumerate() {
        let column = columns[field_index].bind(py);
        match field.field_type {
            ParsedFieldType::Numeric => {
                let values = column
                    .extract::<PyReadonlyArray1<'_, f64>>()
                    .map_err(|_| {
                        PyTypeError::new_err(format!(
                            "link column {:?} must be a NumPy float64 array",
                            field.name
                        ))
                    })
                    .and_then(|array| {
                        copy_f64_array(array, row_count, &format!("link column {:?}", field.name))
                    })?;
                schema_fields.push((field.name.clone(), RustFieldType::Numeric));
                raw_columns.push(Column::Numeric(values));
            }
            ParsedFieldType::String { max_size } => {
                let values = copy_string_values(
                    column,
                    row_count,
                    &format!("link column {:?}", field.name),
                )?;
                let max_size = max_size.unwrap_or(infer_string_max_size(
                    &values,
                    &format!("link column {:?}", field.name),
                )?);
                schema_fields.push((field.name.clone(), RustFieldType::String { max_size }));
                raw_columns.push(Column::String(values));
            }
        }
    }

    let schema = Schema::from_fields(schema_fields).map_err(to_py_error)?;
    LinkTable::from_parts(a, b, schema, raw_columns).map_err(to_py_error)
}

#[allow(clippy::too_many_arguments)]
fn build_network_from_parts(
    node_ids: PyReadonlyArray1<'_, i32>,
    node_fields: &Bound<'_, PyAny>,
    node_columns: &Bound<'_, PyAny>,
    link_a: PyReadonlyArray1<'_, i32>,
    link_b: PyReadonlyArray1<'_, i32>,
    link_fields: &Bound<'_, PyAny>,
    link_columns: &Bound<'_, PyAny>,
    speed_table: PyReadonlyArray2<'_, f64>,
    capacity_table: PyReadonlyArray2<'_, f64>,
    banner: Option<String>,
    run_id: Option<String>,
    zones: Option<u32>,
    left_drive: bool,
) -> PyResult<Network> {
    let py = node_fields.py();
    let parsed_node_fields = parse_field_defs(node_fields)?;
    let parsed_link_fields = parse_field_defs(link_fields)?;
    let node_column_items = collect_column_items(node_columns)?;
    let link_column_items = collect_column_items(link_columns)?;
    let ids = copy_i32_array(node_ids, "node_ids")?;
    let a = copy_i32_array(link_a, "link_a")?;
    let b = copy_i32_array(link_b, "link_b")?;
    let speed_lookup = copy_lookup_table(speed_table, "speed_table")?;
    let capacity_lookup = copy_lookup_table(capacity_table, "capacity_table")?;
    let nodes = build_node_table(py, ids, &parsed_node_fields, &node_column_items)?;
    let links = build_link_table(py, a, b, &parsed_link_fields, &link_column_items)?;
    let metadata = NetworkMetadata::new(
        banner.as_deref(),
        run_id.as_deref(),
        zones.unwrap_or(0),
        left_drive,
    )
    .map_err(to_py_error)?;

    Network::from_parts(metadata, speed_lookup, capacity_lookup, nodes, links).map_err(to_py_error)
}

fn to_py_error(error: halimede::Error) -> PyErr {
    Python::attach(|py| {
        let kind_name = py_error_kind_name(error.kind());
        let offset = error.offset();
        let message = error.to_string();
        let py_error = match py_error_category(error.kind()) {
            PyErrorCategory::Io => HalimedeIoError::new_err(message),
            PyErrorCategory::Parse => HalimedeParseError::new_err(message),
            PyErrorCategory::Validation => HalimedeValidationError::new_err(message),
        };
        let value = py_error.value(py);
        let _ = value.setattr("kind", kind_name);
        let _ = value.setattr("offset", offset);
        py_error
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PyErrorCategory {
    Io,
    Parse,
    Validation,
}

fn py_error_category(kind: &ErrorKind) -> PyErrorCategory {
    match kind {
        ErrorKind::Io(_) => PyErrorCategory::Io,
        ErrorKind::UnexpectedEof
        | ErrorKind::InvalidRecordLength { .. }
        | ErrorKind::InvalidBanner
        | ErrorKind::InvalidTextRecord { .. }
        | ErrorKind::InvalidPar { .. }
        | ErrorKind::UnexpectedRecordTag { .. }
        | ErrorKind::InvalidSchema { .. }
        | ErrorKind::InvalidSpdCap { .. }
        | ErrorKind::InvalidRle { .. }
        | ErrorKind::InvalidTag { .. }
        | ErrorKind::SubRecordOverflow { .. }
        | ErrorKind::RowCountMismatch { .. } => PyErrorCategory::Parse,
        ErrorKind::ValueOutOfRange { .. }
        | ErrorKind::FieldNotFound { .. }
        | ErrorKind::FieldTypeMismatch { .. }
        | ErrorKind::InvalidStructuralId { .. }
        | ErrorKind::ColumnLengthMismatch { .. }
        | ErrorKind::MissingStructuralColumn { .. }
        | ErrorKind::DuplicateFieldName { .. }
        | ErrorKind::ReservedFieldName { .. } => PyErrorCategory::Validation,
        _ => PyErrorCategory::Validation,
    }
}

fn py_error_kind_name(kind: &ErrorKind) -> &'static str {
    match kind {
        ErrorKind::Io(_) => "io",
        ErrorKind::UnexpectedEof => "unexpected_eof",
        ErrorKind::InvalidRecordLength { .. } => "invalid_record_length",
        ErrorKind::InvalidBanner => "invalid_banner",
        ErrorKind::InvalidTextRecord { .. } => "invalid_text_record",
        ErrorKind::InvalidPar { .. } => "invalid_par",
        ErrorKind::UnexpectedRecordTag { .. } => "unexpected_record_tag",
        ErrorKind::InvalidSchema { .. } => "invalid_schema",
        ErrorKind::InvalidSpdCap { .. } => "invalid_spdcap",
        ErrorKind::InvalidRle { .. } => "invalid_rle",
        ErrorKind::InvalidTag { .. } => "invalid_tag",
        ErrorKind::SubRecordOverflow { .. } => "sub_record_overflow",
        ErrorKind::FieldNotFound { .. } => "field_not_found",
        ErrorKind::FieldTypeMismatch { .. } => "field_type_mismatch",
        ErrorKind::InvalidStructuralId { .. } => "invalid_structural_id",
        ErrorKind::ColumnLengthMismatch { .. } => "column_length_mismatch",
        ErrorKind::MissingStructuralColumn { .. } => "missing_structural_column",
        ErrorKind::RowCountMismatch { .. } => "row_count_mismatch",
        ErrorKind::DuplicateFieldName { .. } => "duplicate_field_name",
        ErrorKind::ReservedFieldName { .. } => "reserved_field_name",
        ErrorKind::ValueOutOfRange { .. } => "value_out_of_range",
        _ => "unknown",
    }
}

#[pymodule]
#[pyo3(name = "_halimede")]
fn halimede_py(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add(
        "__doc__",
        "Low-level core bindings for halimede.\n\nImport the public `halimede` package for normal use.",
    )?;

    module.add("HalimedeError", module.py().get_type::<HalimedeError>())?;
    module.add("HalimedeIoError", module.py().get_type::<HalimedeIoError>())?;
    module.add(
        "HalimedeParseError",
        module.py().get_type::<HalimedeParseError>(),
    )?;
    module.add(
        "HalimedeValidationError",
        module.py().get_type::<HalimedeValidationError>(),
    )?;

    module.add_class::<PyFieldDef>()?;
    module.add_class::<PyTableSchema>()?;
    module.add_class::<PyNetworkSchemaResult>()?;
    module.add_class::<PyNetworkInfoResult>()?;
    module.add_class::<PyCoreSnapshot>()?;
    module.add_class::<PyNetworkCore>()?;
    Ok(())
}
