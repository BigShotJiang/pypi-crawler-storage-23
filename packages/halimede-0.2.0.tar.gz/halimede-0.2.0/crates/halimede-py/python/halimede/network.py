"""NumPy-backed network, node-table, and link-table editing surface.

The public classes in this module form the main Python-side object model.
Rust is used only when parsing, validating, or serialising ``.net`` data.
"""

from __future__ import annotations

import difflib
import numbers
from collections.abc import Iterator, Mapping, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, TypeVar

import numpy as np
import numpy.typing as npt

from ._core import (
    NetworkInfoResult,
    HalimedeParseError,
    HalimedeValidationError,
    _NetworkCore,
    _new_validation_error,
    _raise_validation,
)
from .capabilities import has_pandas_support, has_polars_support
from .schema import (
    FieldType,
    LinkFieldSpec,
    NodeFieldSpec,
    normalise_link_field_specs,
    normalise_node_field_specs,
)

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl

_LookupArray = npt.NDArray[np.float64]
_IndexArray = npt.NDArray[np.int32]
_NumericArray = npt.NDArray[np.float64]
_StringArray = npt.NDArray[np.object_]
_TableFieldSpec = TypeVar("_TableFieldSpec", NodeFieldSpec, LinkFieldSpec)
_INDEX_DTYPE_INFO = np.iinfo(np.int32)
_FLOAT_SAFE_INT_MAX = float(2**53 - 1)


def _missing_field_message(name: str, field_names: Sequence[str]) -> str:
    message = f"field {name!r} not found"
    if not field_names:
        return message

    suggestion = difflib.get_close_matches(name, field_names, n=1, cutoff=0.6)
    if suggestion:
        message += f"; did you mean {suggestion[0]!r}?"

    preview = ", ".join(repr(field_name) for field_name in field_names[:8])
    if len(field_names) > 8:
        preview += ", ..."
    return f"{message}; available fields: {preview}"


def _normalise_index_array(values: object, *, name: str) -> _IndexArray:
    """Normalise structural IDs to a validated contiguous ``int32`` array."""
    raw = np.asarray(values)
    if raw.ndim != 1:
        _raise_validation(f"{name} must be one-dimensional")
    if raw.dtype.kind == "b":
        _raise_validation(f"{name} must contain integer IDs, not booleans")

    if raw.dtype.kind in {"i", "u"}:
        if raw.size and (raw.min() < 1 or raw.max() > _INDEX_DTYPE_INFO.max):
            _raise_validation(
                f"{name} must contain only positive IDs within int32 range"
            )
        return np.ascontiguousarray(raw, dtype=np.int32)

    if raw.dtype.kind == "f":
        if raw.size:
            if not np.isfinite(raw).all():
                _raise_validation(f"{name} must contain only integer IDs")
            if not np.equal(raw, np.trunc(raw)).all():
                _raise_validation(f"{name} must contain only integer IDs")
            if raw.min() < 1 or raw.max() > _INDEX_DTYPE_INFO.max:
                _raise_validation(
                    f"{name} must contain only positive IDs within int32 range"
                )
            if np.abs(raw).max() > _FLOAT_SAFE_INT_MAX:
                _raise_validation(
                    f"{name} must contain only positive IDs within int32 range"
                )
        return np.ascontiguousarray(raw, dtype=np.int32)

    python_values = raw.tolist()
    normalised_values: list[int] = []
    for value in python_values:
        if isinstance(value, bool):
            _raise_validation(f"{name} must contain integer IDs, not booleans")

        if isinstance(value, numbers.Integral):
            integral_value = int(value)
        elif isinstance(value, numbers.Real):
            numeric_value = float(value)
            if not np.isfinite(numeric_value) or not numeric_value.is_integer():
                _raise_validation(f"{name} must contain only integer IDs")
            if abs(numeric_value) > _FLOAT_SAFE_INT_MAX:
                _raise_validation(
                    f"{name} must contain only positive IDs within int32 range"
                )
            integral_value = int(numeric_value)
        else:
            _raise_validation(f"{name} must contain only integer IDs")

        if not 1 <= integral_value <= _INDEX_DTYPE_INFO.max:
            _raise_validation(
                f"{name} must contain only positive IDs within int32 range"
            )
        normalised_values.append(integral_value)

    return np.ascontiguousarray(np.asarray(normalised_values, dtype=np.int32))


def _normalise_numeric_array(
    values: object,
    row_count: int,
    *,
    name: str,
) -> _NumericArray:
    raw = np.asarray(values)
    if raw.ndim != 1:
        _raise_validation(f"{name} must be one-dimensional")
    if raw.dtype.kind == "b":
        _raise_validation(f"{name} must contain numeric values, not booleans")
    if raw.dtype.kind == "O":
        python_values = raw.tolist()
        if any(isinstance(value, bool) for value in python_values):
            _raise_validation(f"{name} must contain numeric values, not booleans")

    array = np.ascontiguousarray(raw, dtype=np.float64)
    if array.shape != (row_count,):
        _raise_validation(
            f"{name} must contain {row_count} rows, got {array.shape[0]}"
        )
    return array


def _normalise_string_array(
    values: object,
    row_count: int,
    *,
    name: str,
    max_size: int | None = None,
) -> _StringArray:
    raw = np.asarray(values, dtype=object)
    if raw.ndim != 1:
        _raise_validation(f"{name} must be one-dimensional")

    python_values = raw.tolist()
    if len(python_values) != row_count:
        _raise_validation(f"{name} must contain {row_count} rows, got {len(python_values)}")
    if any(not isinstance(value, str) for value in python_values):
        _raise_validation(f"{name} must contain only Python strings")

    encoded_width = max((len(value.encode("utf-8")) for value in python_values), default=1)
    if encoded_width > 255:
        _raise_validation(f"{name} contains values wider than 255 encoded bytes")
    if max_size is not None and encoded_width > max_size:
        _raise_validation(
            f"{name} contains values wider than declared max_size {max_size}"
        )

    return np.ascontiguousarray(np.asarray(python_values, dtype=object))


def _infer_field_type(values: object, *, name: str) -> FieldType:
    raw = np.asarray(values)
    if raw.ndim != 1:
        _raise_validation(f"{name} must be one-dimensional")
    if raw.dtype.kind in {"i", "u", "f"}:
        return FieldType.numeric()
    if raw.dtype.kind in {"U", "S"}:
        return FieldType.string()
    if raw.dtype.kind == "b":
        _raise_validation(f"{name} must be numeric or string, not boolean")

    python_values = raw.tolist()
    if not python_values:
        return FieldType.numeric()
    if all(isinstance(value, str) for value in python_values):
        return FieldType.string()
    if all(
        isinstance(value, numbers.Real) and not isinstance(value, bool)
        for value in python_values
    ):
        return FieldType.numeric()

    _raise_validation(
        f"{name} must contain only numeric values or only Python strings"
    )


def _normalise_lookup_array(values: object) -> _LookupArray:
    array = np.ascontiguousarray(np.asarray(values, dtype=np.float64))
    if array.shape != (9, 99):
        _raise_validation(f"lookup table must have shape (9, 99), got {array.shape}")
    return array


def _normalise_lookup_table(
    value: LookupTable | object | None,
    *,
    default_factory: type[LookupTable],
) -> LookupTable:
    if value is None:
        return default_factory()
    if isinstance(value, LookupTable):
        return value
    return LookupTable(value)


def _build_field_index(field_specs: Sequence[_TableFieldSpec]) -> dict[str, int]:
    return {field.name: field_index for field_index, field in enumerate(field_specs)}


def _field_spec_for_name(
    name: str,
    field_specs: Sequence[_TableFieldSpec],
    field_index_by_name: Mapping[str, int],
) -> _TableFieldSpec:
    field_index = field_index_by_name.get(name)
    if field_index is None:
        raise KeyError(_missing_field_message(name, [field.name for field in field_specs]))
    return field_specs[field_index]


def _copy_columns(columns: Mapping[str, np.ndarray]) -> dict[str, np.ndarray]:
    return {name: values.copy() for name, values in columns.items()}


def _zero_column(field_type: FieldType, row_count: int) -> np.ndarray:
    if field_type.is_numeric:
        return np.zeros(row_count, dtype=np.float64)
    return np.asarray([""] * row_count, dtype=object)


def _field_specs_to_core(
    field_specs: Sequence[NodeFieldSpec | LinkFieldSpec],
) -> list[object]:
    return [field.to_core() for field in field_specs]


def _validate_network_schema(
    node_field_specs: Sequence[NodeFieldSpec],
    link_field_specs: Sequence[LinkFieldSpec],
    *,
    banner: str | None,
    run_id: str | None,
    zones: int | None,
    left_drive: bool,
):
    try:
        return _NetworkCore.validate_schema(
            _field_specs_to_core(node_field_specs),
            _field_specs_to_core(link_field_specs),
            banner=banner,
            run_id=run_id,
            zones=zones,
            left_drive=left_drive,
        )
    except HalimedeParseError as error:
        if banner is not None and not banner.startswith("NET"):
            raise _new_validation_error(
                "banner must start with 'NET'",
                kind="invalid_banner",
            ) from error
        raise _new_validation_error(
            str(error),
            kind=getattr(error, "kind", "validation"),
            offset=getattr(error, "offset", None),
        ) from error


class LookupTable:
    """NumPy-backed 9 by 99 speed or capacity lookup table.

    The array shape matches Voyager's SPD/CAP layout: lane counts 1..9 on the
    first axis and field classes 1..99 on the second axis.
    """

    def __init__(self, values: object) -> None:
        self._values = _normalise_lookup_array(values)

    @classmethod
    def default_speed(cls) -> LookupTable:
        """Return Voyager's default speed lookup table."""
        values = np.zeros((9, 99), dtype=np.float64)
        for lane_index in range(9):
            values[lane_index, :] = np.arange(1, 100, dtype=np.float64)
        return cls(values)

    @classmethod
    def default_capacity(cls) -> LookupTable:
        """Return Voyager's default capacity lookup table."""
        values = np.zeros((9, 99), dtype=np.float64)
        for lane_index in range(9):
            values[lane_index, :] = np.arange(20, 2000, 20, dtype=np.float64)
        return cls(values)

    @property
    def values(self) -> _LookupArray:
        """Return the backing NumPy array."""
        return self._values

    def copy(self) -> LookupTable:
        """Return an independent copy of the lookup table."""
        return LookupTable(self._values.copy())

    def to_numpy(self, *, copy: bool = False) -> _LookupArray:
        """Return the lookup array, optionally copying it first."""
        if copy:
            return self._values.copy()
        return self._values

    def get(self, lanes: int, field_class: int) -> float:
        """Return the value for a 1-based ``(lanes, field_class)`` pair."""
        if not 1 <= lanes <= 9 or not 1 <= field_class <= 99:
            return 0.0
        return float(self._values[lanes - 1, field_class - 1])

    def set(self, lanes: int, field_class: int, value: float) -> None:
        """Set the value for a 1-based ``(lanes, field_class)`` pair."""
        if not 1 <= lanes <= 9 or not 1 <= field_class <= 99:
            return
        self._values[lanes - 1, field_class - 1] = float(value)

    def is_default_speed(self) -> bool:
        """Return ``True`` when values match Voyager's default speed table."""
        return np.array_equal(self._values, LookupTable.default_speed().values)

    def is_default_capacity(self) -> bool:
        """Return ``True`` when values match Voyager's default capacity table."""
        return np.array_equal(self._values, LookupTable.default_capacity().values)

    def __repr__(self) -> str:
        return f"LookupTable(shape={self._values.shape})"


class _TableBase:
    _reserved_names: tuple[str, ...]
    _field_spec_type: type[NodeFieldSpec] | type[LinkFieldSpec]

    def __init__(
        self,
        row_count: int,
        columns: Mapping[str, object] | None,
        field_specs: Sequence[_TableFieldSpec] | None,
    ) -> None:
        self._row_count = row_count
        self._field_specs: tuple[_TableFieldSpec, ...]
        self._columns: dict[str, np.ndarray]
        self._field_index_by_name: dict[str, int]
        self._initialise_columns(columns, field_specs)

    @property
    def row_count(self) -> int:
        """Return the number of rows in the table."""
        return self._row_count

    @property
    def field_specs(self) -> tuple[_TableFieldSpec, ...]:
        """Return ordered user-field specifications."""
        return self._field_specs

    @property
    def field_names(self) -> tuple[str, ...]:
        """Return ordered user-field names."""
        return tuple(field.name for field in self._field_specs)

    def has_field(self, name: str) -> bool:
        """Return ``True`` when a user field with *name* is present."""
        return name in self._field_index_by_name

    def field_spec(self, name: str) -> _TableFieldSpec:
        """Return the schema item for the named user field."""
        return _field_spec_for_name(name, self._field_specs, self._field_index_by_name)

    def field_type(self, name: str) -> FieldType:
        """Return the validated field type for the named user field."""
        return self.field_spec(name).field_type

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._field_index_by_name

    def __len__(self) -> int:
        return len(self._field_specs)

    def __iter__(self) -> Iterator[str]:
        return iter(self.field_names)

    def keys(self) -> tuple[str, ...]:
        """Return ordered user-field names."""
        return self.field_names

    def values(self) -> tuple[np.ndarray, ...]:
        """Return user-field arrays in schema order."""
        return tuple(self._columns[field.name] for field in self._field_specs)

    def items(self) -> tuple[tuple[str, np.ndarray], ...]:
        """Return ``(name, values)`` pairs in schema order."""
        return tuple((field.name, self._columns[field.name]) for field in self._field_specs)

    def __getitem__(self, name: str) -> np.ndarray:
        try:
            return self._columns[name]
        except KeyError as error:
            raise KeyError(_missing_field_message(name, self.field_names)) from error

    def __setitem__(self, name: str, values: object) -> None:
        self.set_column(name, values, field_type=self._field_type_for_name(name))

    def __delitem__(self, name: str) -> None:
        if name not in self._field_index_by_name:
            raise KeyError(_missing_field_message(name, self.field_names))
        self.remove_fields([name])

    def copy(self) -> _TableBase:
        raise NotImplementedError

    def assign(
        self,
        columns: Mapping[str, object] | None = None,
        /,
        **named_columns: object,
    ) -> None:
        """Replace or append multiple user fields in one call.

        The mapping interface remains the primary edit surface. ``assign`` is
        the batch analogue of repeated ``table[name] = values`` operations.
        Non-identifier field names should be supplied through *columns*.
        """
        updates = dict(columns or {})
        updates.update(named_columns)
        for name, values in updates.items():
            self[name] = values

    def drop(self, field_names: str | Sequence[str]) -> None:
        """Remove one or more user fields from the table."""
        if isinstance(field_names, str):
            self.remove_fields([field_names])
            return
        self.remove_fields(field_names)

    def retain_fields(self, field_names: Sequence[str]) -> None:
        """Retain only the named user fields, preserving their existing order."""
        requested = set(field_names)
        for name in requested:
            if name not in self._field_index_by_name:
                _raise_validation(_missing_field_message(name, self.field_names))

        kept_specs: list[_TableFieldSpec] = []
        kept_columns: dict[str, np.ndarray] = {}
        for field in self._field_specs:
            if field.name not in requested:
                continue
            kept_specs.append(field)
            kept_columns[field.name] = self._columns[field.name]

        self._field_specs = tuple(kept_specs)
        self._columns = kept_columns
        self._field_index_by_name = _build_field_index(self._field_specs)

    def remove_fields(self, field_names: Sequence[str]) -> None:
        """Remove the named user fields from the table."""
        requested = set(field_names)
        for name in requested:
            if name not in self._field_index_by_name:
                _raise_validation(_missing_field_message(name, self.field_names))

        kept_specs: list[_TableFieldSpec] = []
        kept_columns: dict[str, np.ndarray] = {}
        for field in self._field_specs:
            if field.name in requested:
                continue
            kept_specs.append(field)
            kept_columns[field.name] = self._columns[field.name]

        self._field_specs = tuple(kept_specs)
        self._columns = kept_columns
        self._field_index_by_name = _build_field_index(self._field_specs)

    def set_column(
        self,
        name: str,
        values: object,
        *,
        field_type: FieldType | None = None,
    ) -> None:
        """Replace or append a user column after validation.

        Parameters
        ----------
        name:
            User-field name. Structural names such as ``N``, ``A``, and ``B``
            are rejected here and must be edited through their dedicated
            properties.
        values:
            One-dimensional values with exactly ``row_count`` items.
        field_type:
            Optional explicit field type. When omitted, new fields are inferred
            from the provided values and existing fields keep their current
            type.
        """
        if name in self._reserved_names:
            _raise_validation(f"{name!r} is a reserved structural field name")

        resolved_field_type = field_type or self._field_type_for_name(name) or _infer_field_type(
            values,
            name=name,
        )
        normalised = self._normalise_column_values(
            name,
            values,
            resolved_field_type,
            self._row_count,
        )

        if name in self._field_index_by_name:
            field_index = self._field_index_by_name[name]
            specs = list(self._field_specs)
            specs[field_index] = self._field_spec_type(name, resolved_field_type)
            self._field_specs = tuple(specs)
        else:
            self._field_specs = self._field_specs + (
                self._field_spec_type(name, resolved_field_type),
            )
            self._field_index_by_name = _build_field_index(self._field_specs)

        self._columns[name] = normalised

    def to_pandas(self) -> "pd.DataFrame":
        """Return the table as a pandas DataFrame.

        Structural columns are included as ``N`` for node tables and ``A``/``B``
        for link tables.
        """
        if not has_pandas_support():
            raise ImportError("pandas support is not installed")

        import pandas as pd

        return pd.DataFrame(dict(self._frame_columns()))

    def to_polars(self) -> "pl.DataFrame":
        """Return the table as a polars DataFrame."""
        if not has_polars_support():
            raise ImportError("polars support is not installed")

        import polars as pl

        data: dict[str, object] = {}
        for name, values in self._frame_columns():
            data[name] = values.tolist() if values.dtype == object else values
        return pl.DataFrame(data)

    def _frame_columns(self) -> list[tuple[str, np.ndarray]]:
        raise NotImplementedError

    def _core_columns(self) -> list[object]:
        columns: list[object] = []
        for field in self._field_specs:
            values = self._columns[field.name]
            columns.append(values if field.field_type.is_numeric else values.tolist())
        return columns

    def _field_type_for_name(self, name: str) -> FieldType | None:
        field_index = self._field_index_by_name.get(name)
        if field_index is None:
            return None
        return self._field_specs[field_index].field_type

    def _initialise_columns(
        self,
        columns: Mapping[str, object] | None,
        field_specs: Sequence[_TableFieldSpec] | None,
    ) -> None:
        source_columns = dict(columns or {})

        if field_specs is None:
            specs: list[_TableFieldSpec] = []
            normalised_columns: dict[str, np.ndarray] = {}
            for name, raw_values in source_columns.items():
                if name in self._reserved_names:
                    _raise_validation(f"{name!r} is a reserved structural field name")
                field_type = _infer_field_type(raw_values, name=name)
                specs.append(self._field_spec_type(name, field_type))
                normalised_columns[name] = self._normalise_column_values(
                    name,
                    raw_values,
                    field_type,
                    self._row_count,
                )
        else:
            specs = list(self._normalise_field_specs(field_specs))
            expected_names = {field.name for field in specs}
            actual_names = set(source_columns)
            missing_names = expected_names - actual_names
            extra_names = actual_names - expected_names

            issues: list[str] = []
            if missing_names:
                missing_preview = ", ".join(sorted(missing_names))
                issues.append(f"missing columns for fields: {missing_preview}")
            if extra_names:
                extra_preview = ", ".join(sorted(extra_names))
                issues.append(
                    f"unexpected columns not present in field_specs: {extra_preview}"
                )
            normalised_columns = {}
            for field in specs:
                if field.name not in source_columns:
                    continue
                try:
                    normalised_columns[field.name] = self._normalise_column_values(
                        field.name,
                        source_columns[field.name],
                        field.field_type,
                        self._row_count,
                    )
                except HalimedeValidationError as error:
                    issues.append(str(error))

            if issues:
                _raise_validation("; ".join(issues))

        self._field_specs = tuple(specs)
        self._columns = normalised_columns
        self._field_index_by_name = _build_field_index(self._field_specs)

    def _normalise_field_specs(
        self,
        field_specs: Sequence[_TableFieldSpec],
    ) -> tuple[_TableFieldSpec, ...]:
        if self._field_spec_type is NodeFieldSpec:
            return normalise_node_field_specs(field_specs)  # type: ignore[return-value]
        return normalise_link_field_specs(field_specs)  # type: ignore[return-value]

    @staticmethod
    def _normalise_column_values(
        name: str,
        values: object,
        field_type: FieldType,
        row_count: int,
    ) -> np.ndarray:
        if field_type.is_numeric:
            return _normalise_numeric_array(values, row_count, name=name)
        return _normalise_string_array(
            values,
            row_count,
            name=name,
            max_size=field_type.max_size,
        )


class NodeTable(_TableBase):
    """NumPy-backed node table with structural ``N`` plus user fields.

    The mapping interface covers user fields only. Structural node IDs are
    accessed through :attr:`N`.
    """

    _reserved_names = ("N",)
    _field_spec_type = NodeFieldSpec

    def __init__(
        self,
        ids: object,
        columns: Mapping[str, object] | None = None,
        *,
        field_specs: Sequence[NodeFieldSpec] | None = None,
    ) -> None:
        self._ids = _normalise_index_array(ids, name="N")
        super().__init__(self._ids.shape[0], columns, field_specs)

    @property
    def N(self) -> _IndexArray:
        """Return the structural node IDs as a contiguous ``int32`` array."""
        return self._ids

    @N.setter
    def N(self, values: object) -> None:
        new_ids = _normalise_index_array(values, name="N")
        if new_ids.shape != self._ids.shape:
            _raise_validation(
                f"N must contain {self._ids.shape[0]} rows, got {new_ids.shape[0]}"
            )
        self._ids = new_ids

    @classmethod
    def from_pandas(
        cls,
        frame: "pd.DataFrame",
        *,
        field_specs: Sequence[NodeFieldSpec] | None = None,
    ) -> NodeTable:
        """Build a node table from a pandas DataFrame.

        The frame must contain a structural ``N`` column. Remaining columns are
        treated as user fields in frame order.
        """
        if "N" not in frame.columns:
            _raise_validation("node pandas frame must contain 'N'")
        ids = frame["N"].to_numpy(copy=False)
        columns = {
            name: frame[name].to_numpy(copy=False)
            for name in frame.columns
            if name != "N"
        }
        return cls(ids, columns, field_specs=field_specs)

    @classmethod
    def from_polars(
        cls,
        frame: "pl.DataFrame",
        *,
        field_specs: Sequence[NodeFieldSpec] | None = None,
    ) -> NodeTable:
        """Build a node table from a polars DataFrame.

        The frame must contain a structural ``N`` column. Remaining columns are
        treated as user fields in frame order.
        """
        if "N" not in frame.columns:
            _raise_validation("node polars frame must contain 'N'")
        ids = frame.get_column("N").to_list()
        columns = {
            name: frame.get_column(name).to_list()
            for name in frame.columns
            if name != "N"
        }
        return cls(ids, columns, field_specs=field_specs)

    @classmethod
    def like(cls, other: NodeTable) -> NodeTable:
        """Create a zero-initialised node table with the same schema."""
        columns = {
            field.name: _zero_column(field.field_type, other.row_count)
            for field in other.field_specs
        }
        return cls(other.N.copy(), columns, field_specs=other.field_specs)

    @classmethod
    def _from_core(cls, core: _NetworkCore) -> NodeTable:
        field_specs = tuple(
            NodeFieldSpec.from_core(field)
            for field in core.node_schema().fields()
        )
        columns: dict[str, object] = {}
        for field in field_specs:
            if field.field_type.is_numeric:
                columns[field.name] = core.node_numeric_column(field.name)
            else:
                columns[field.name] = np.asarray(
                    core.node_string_column(field.name),
                    dtype=object,
                )
        return cls(core.node_ids(), columns, field_specs=field_specs)

    def copy(self) -> NodeTable:
        """Return a detached copy of the node table and its arrays."""
        return NodeTable(self.N.copy(), _copy_columns(self._columns), field_specs=self.field_specs)

    def _frame_columns(self) -> list[tuple[str, np.ndarray]]:
        return [("N", self._ids), *self.items()]

    def __repr__(self) -> str:
        return f"NodeTable(row_count={self.row_count}, field_names={self.field_names!r})"


class LinkTable(_TableBase):
    """NumPy-backed link table with structural ``A`` and ``B`` plus user fields.

    The mapping interface covers user fields only. Structural endpoints are
    accessed through :attr:`A` and :attr:`B`.
    """

    _reserved_names = ("A", "B")
    _field_spec_type = LinkFieldSpec

    def __init__(
        self,
        a: object,
        b: object,
        columns: Mapping[str, object] | None = None,
        *,
        field_specs: Sequence[LinkFieldSpec] | None = None,
    ) -> None:
        self._a = _normalise_index_array(a, name="A")
        self._b = _normalise_index_array(b, name="B")
        if self._a.shape != self._b.shape:
            _raise_validation(
                "A and B must contain the same number of rows, "
                f"got {self._a.shape[0]} and {self._b.shape[0]}"
            )
        super().__init__(self._a.shape[0], columns, field_specs)

    @property
    def A(self) -> _IndexArray:
        """Return the structural ``A`` endpoint IDs as a contiguous array."""
        return self._a

    @A.setter
    def A(self, values: object) -> None:
        new_a = _normalise_index_array(values, name="A")
        if new_a.shape != self._a.shape:
            _raise_validation(
                f"A must contain {self._a.shape[0]} rows, got {new_a.shape[0]}"
            )
        self._a = new_a

    @property
    def B(self) -> _IndexArray:
        """Return the structural ``B`` endpoint IDs as a contiguous array."""
        return self._b

    @B.setter
    def B(self, values: object) -> None:
        new_b = _normalise_index_array(values, name="B")
        if new_b.shape != self._b.shape:
            _raise_validation(
                f"B must contain {self._b.shape[0]} rows, got {new_b.shape[0]}"
            )
        self._b = new_b

    @classmethod
    def from_pandas(
        cls,
        frame: "pd.DataFrame",
        *,
        field_specs: Sequence[LinkFieldSpec] | None = None,
    ) -> LinkTable:
        """Build a link table from a pandas DataFrame.

        The frame must contain structural ``A`` and ``B`` columns. Remaining
        columns are treated as user fields in frame order.
        """
        if "A" not in frame.columns or "B" not in frame.columns:
            _raise_validation("link pandas frame must contain 'A' and 'B'")
        a = frame["A"].to_numpy(copy=False)
        b = frame["B"].to_numpy(copy=False)
        columns = {
            name: frame[name].to_numpy(copy=False)
            for name in frame.columns
            if name not in {"A", "B"}
        }
        return cls(a, b, columns, field_specs=field_specs)

    @classmethod
    def from_polars(
        cls,
        frame: "pl.DataFrame",
        *,
        field_specs: Sequence[LinkFieldSpec] | None = None,
    ) -> LinkTable:
        """Build a link table from a polars DataFrame.

        The frame must contain structural ``A`` and ``B`` columns. Remaining
        columns are treated as user fields in frame order.
        """
        if "A" not in frame.columns or "B" not in frame.columns:
            _raise_validation("link polars frame must contain 'A' and 'B'")
        a = frame.get_column("A").to_list()
        b = frame.get_column("B").to_list()
        columns = {
            name: frame.get_column(name).to_list()
            for name in frame.columns
            if name not in {"A", "B"}
        }
        return cls(a, b, columns, field_specs=field_specs)

    @classmethod
    def like(cls, other: LinkTable) -> LinkTable:
        """Create a zero-initialised link table with the same schema."""
        columns = {
            field.name: _zero_column(field.field_type, other.row_count)
            for field in other.field_specs
        }
        return cls(other.A.copy(), other.B.copy(), columns, field_specs=other.field_specs)

    @classmethod
    def _from_core(cls, core: _NetworkCore) -> LinkTable:
        field_specs = tuple(
            LinkFieldSpec.from_core(field)
            for field in core.link_schema().fields()
        )
        columns: dict[str, object] = {}
        for field in field_specs:
            if field.field_type.is_numeric:
                columns[field.name] = core.link_numeric_column(field.name)
            else:
                columns[field.name] = np.asarray(
                    core.link_string_column(field.name),
                    dtype=object,
                )
        return cls(core.link_a(), core.link_b(), columns, field_specs=field_specs)

    def copy(self) -> LinkTable:
        """Return a detached copy of the link table and its arrays."""
        return LinkTable(
            self.A.copy(),
            self.B.copy(),
            _copy_columns(self._columns),
            field_specs=self.field_specs,
        )

    def _frame_columns(self) -> list[tuple[str, np.ndarray]]:
        return [("A", self._a), ("B", self._b), *self.items()]

    def __repr__(self) -> str:
        return f"LinkTable(row_count={self.row_count}, field_names={self.field_names!r})"


class NetworkInfo:
    """Parsed network metadata and schemas without allocating table columns.

    ``NetworkInfo`` mirrors the Rust crate's cheap inspection surface. It is
    the preferred way to discover available fields before choosing a selective
    eager load.
    """

    def __init__(
        self,
        *,
        banner: str,
        run_id: str,
        zones: int,
        left_drive: bool,
        node_row_count: int,
        link_row_count: int,
        node_field_specs: Sequence[NodeFieldSpec],
        link_field_specs: Sequence[LinkFieldSpec],
        speed_table: LookupTable,
        capacity_table: LookupTable,
        source_path: Path | None = None,
        source_bytes: bytes | None = None,
    ) -> None:
        self._banner = banner
        self._run_id = run_id
        self._zones = zones
        self._left_drive = left_drive
        self._node_row_count = node_row_count
        self._link_row_count = link_row_count
        self._node_field_specs = tuple(node_field_specs)
        self._link_field_specs = tuple(link_field_specs)
        self._node_field_index_by_name = _build_field_index(self._node_field_specs)
        self._link_field_index_by_name = _build_field_index(self._link_field_specs)
        self._speed_table = speed_table
        self._capacity_table = capacity_table
        self._source_path = source_path
        self._source_bytes = source_bytes

    @classmethod
    def inspect(cls, path: str | Path) -> NetworkInfo:
        """Inspect a ``.net`` file without allocating node or link columns."""
        resolved = Path(path)
        return cls._from_core(NetworkInfoResult.open(resolved), source_path=resolved)

    @classmethod
    def from_bytes(
        cls, data: bytes | bytearray | memoryview
    ) -> NetworkInfo:
        """Inspect in-memory ``.net`` bytes without allocating table columns."""
        payload = bytes(data)
        return cls._from_core(NetworkInfoResult.from_bytes(payload), source_bytes=payload)

    @classmethod
    def _from_core(
        cls,
        core: NetworkInfoResult,
        *,
        source_path: Path | None = None,
        source_bytes: bytes | None = None,
    ) -> NetworkInfo:
        return cls(
            banner=core.banner,
            run_id=core.run_id,
            zones=core.zones,
            left_drive=core.left_drive,
            node_row_count=core.node_row_count,
            link_row_count=core.link_row_count,
            node_field_specs=tuple(
                NodeFieldSpec.from_core(field) for field in core.node_schema().fields()
            ),
            link_field_specs=tuple(
                LinkFieldSpec.from_core(field) for field in core.link_schema().fields()
            ),
            speed_table=LookupTable(core.speed_table()),
            capacity_table=LookupTable(core.capacity_table()),
            source_path=source_path,
            source_bytes=source_bytes,
        )

    @property
    def banner(self) -> str:
        """Return the parsed banner string."""
        return self._banner

    @property
    def run_id(self) -> str:
        """Return the logical run identifier without the ``ID=`` prefix."""
        return self._run_id

    @property
    def zones(self) -> int:
        """Return the parsed zone-count metadata."""
        return self._zones

    @property
    def left_drive(self) -> bool:
        """Return whether the network is marked as left-drive."""
        return self._left_drive

    @property
    def node_row_count(self) -> int:
        """Return the number of node records."""
        return self._node_row_count

    @property
    def link_row_count(self) -> int:
        """Return the number of link records."""
        return self._link_row_count

    @property
    def node_field_specs(self) -> tuple[NodeFieldSpec, ...]:
        """Return ordered node user-field specifications."""
        return self._node_field_specs

    @property
    def link_field_specs(self) -> tuple[LinkFieldSpec, ...]:
        """Return ordered link user-field specifications."""
        return self._link_field_specs

    @property
    def node_field_names(self) -> tuple[str, ...]:
        """Return ordered node user-field names."""
        return tuple(field.name for field in self._node_field_specs)

    @property
    def link_field_names(self) -> tuple[str, ...]:
        """Return ordered link user-field names."""
        return tuple(field.name for field in self._link_field_specs)

    @property
    def speed_table(self) -> LookupTable:
        """Return the SPD lookup table."""
        return self._speed_table

    @property
    def capacity_table(self) -> LookupTable:
        """Return the CAP lookup table."""
        return self._capacity_table

    def has_node_field(self, name: str) -> bool:
        """Return ``True`` when a node user field named *name* is present."""
        return name in self._node_field_index_by_name

    def has_link_field(self, name: str) -> bool:
        """Return ``True`` when a link user field named *name* is present."""
        return name in self._link_field_index_by_name

    def node_field_spec(self, name: str) -> NodeFieldSpec:
        """Return the node-field schema item for *name*."""
        return _field_spec_for_name(
            name, self._node_field_specs, self._node_field_index_by_name
        )

    def link_field_spec(self, name: str) -> LinkFieldSpec:
        """Return the link-field schema item for *name*."""
        return _field_spec_for_name(
            name, self._link_field_specs, self._link_field_index_by_name
        )

    def node_field_type(self, name: str) -> FieldType:
        """Return the node-field type for *name*."""
        return self.node_field_spec(name).field_type

    def link_field_type(self, name: str) -> FieldType:
        """Return the link-field type for *name*."""
        return self.link_field_spec(name).field_type

    def load(
        self,
        *,
        node_fields: Sequence[str] | None = None,
        link_fields: Sequence[str] | None = None,
    ) -> Network:
        """Load the inspected network eagerly, optionally selecting fields."""
        if self._source_path is not None:
            return Network.read(
                self._source_path,
                node_fields=node_fields,
                link_fields=link_fields,
            )
        if self._source_bytes is not None:
            return Network.from_bytes(
                self._source_bytes,
                node_fields=node_fields,
                link_fields=link_fields,
            )
        raise RuntimeError("NetworkInfo has no associated source to load")

    def __repr__(self) -> str:
        return (
            "NetworkInfo("
            f"node_row_count={self.node_row_count}, "
            f"link_row_count={self.link_row_count}, "
            f"node_fields={self.node_field_names!r}, "
            f"link_fields={self.link_field_names!r}"
            ")"
        )


class Network:
    """Eager NumPy-backed network with explicit node and link tables.

    Rust is used only for strict `.net` parsing, validation, and serialisation.
    After loading, the network owns Python-managed NumPy arrays for direct
    manipulation.

    Structural columns are exposed through ``nodes.N`` and ``links.A``/``B``.
    The mapping interfaces on ``nodes`` and ``links`` cover user fields only.
    """

    def __init__(
        self,
        *,
        nodes: NodeTable,
        links: LinkTable,
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
        speed_table: LookupTable | object | None = None,
        capacity_table: LookupTable | object | None = None,
    ) -> None:
        if not isinstance(nodes, NodeTable):
            _raise_validation("nodes must be a NodeTable")
        if not isinstance(links, LinkTable):
            _raise_validation("links must be a LinkTable")

        validated = _validate_network_schema(
            nodes.field_specs,
            links.field_specs,
            banner=banner,
            run_id=run_id,
            zones=zones,
            left_drive=left_drive,
        )
        self._assign_parts(
            nodes=nodes,
            links=links,
            banner=validated.banner,
            run_id=validated.run_id,
            zones=validated.zones,
            left_drive=validated.left_drive,
            speed_table=_normalise_lookup_table(
                speed_table,
                default_factory=LookupTable.default_speed,
            ),
            capacity_table=_normalise_lookup_table(
                capacity_table,
                default_factory=LookupTable.default_capacity,
            ),
        )

    def _assign_parts(
        self,
        *,
        nodes: NodeTable,
        links: LinkTable,
        banner: str,
        run_id: str,
        zones: int,
        left_drive: bool,
        speed_table: LookupTable,
        capacity_table: LookupTable,
    ) -> None:
        self._nodes = nodes
        self._links = links
        self._banner = banner
        self._run_id = run_id
        self._zones = zones
        self._left_drive = bool(left_drive)
        self._speed_table = speed_table
        self._capacity_table = capacity_table

    @classmethod
    def _from_core(cls, core: _NetworkCore) -> Network:
        snapshot = core.take_snapshot()
        node_field_specs = tuple(
            NodeFieldSpec.from_core(field) for field in snapshot.node_fields()
        )
        node_columns: dict[str, object] = {}
        for field, column in zip(node_field_specs, snapshot.node_columns(), strict=True):
            if field.field_type.is_numeric:
                node_columns[field.name] = column
            else:
                node_columns[field.name] = np.asarray(column, dtype=object)

        link_field_specs = tuple(
            LinkFieldSpec.from_core(field) for field in snapshot.link_fields()
        )
        link_columns: dict[str, object] = {}
        for field, column in zip(link_field_specs, snapshot.link_columns(), strict=True):
            if field.field_type.is_numeric:
                link_columns[field.name] = column
            else:
                link_columns[field.name] = np.asarray(column, dtype=object)

        self = cls.__new__(cls)
        self._assign_parts(
            nodes=NodeTable(
                snapshot.node_ids(),
                node_columns,
                field_specs=node_field_specs,
            ),
            links=LinkTable(
                snapshot.link_a(),
                snapshot.link_b(),
                link_columns,
                field_specs=link_field_specs,
            ),
            banner=snapshot.banner,
            run_id=snapshot.run_id,
            zones=snapshot.zones,
            left_drive=snapshot.left_drive,
            speed_table=LookupTable(snapshot.speed_table()),
            capacity_table=LookupTable(snapshot.capacity_table()),
        )
        return self

    @classmethod
    def read(
        cls,
        path: str | Path,
        *,
        node_fields: Sequence[str] | None = None,
        link_fields: Sequence[str] | None = None,
    ) -> Network:
        """Read a ``.net`` file into an eager NumPy-backed network.

        Parameters
        ----------
        path:
            Source network file path.
        node_fields, link_fields:
            Optional subsets of user fields to load. Structural columns and
            metadata are always loaded. When omitted, all user fields are read.

        Notes
        -----
        Use :meth:`NetworkInfo.inspect` when the workflow needs schema
        discovery before choosing these field lists.
        """
        resolved = Path(path)
        if node_fields is None and link_fields is None:
            core = _NetworkCore.open(resolved)
        else:
            core = _NetworkCore.open_fields(
                resolved,
                list(node_fields or ()),
                list(link_fields or ()),
            )
        return cls._from_core(core)

    @classmethod
    def from_bytes(
        cls,
        data: bytes | bytearray | memoryview,
        *,
        node_fields: Sequence[str] | None = None,
        link_fields: Sequence[str] | None = None,
    ) -> Network:
        """Parse a ``.net`` payload into an eager NumPy-backed network.

        Parameters
        ----------
        data:
            In-memory ``.net`` bytes.
        node_fields, link_fields:
            Optional subsets of user fields to load. Structural columns and
            metadata are always loaded.

        Notes
        -----
        Use :meth:`NetworkInfo.from_bytes` when the workflow needs metadata or
        schema inspection without eagerly allocating table columns.
        """
        payload = bytes(data)
        if node_fields is None and link_fields is None:
            core = _NetworkCore.from_bytes(payload)
        else:
            core = _NetworkCore.from_bytes_fields(
                payload,
                list(node_fields or ()),
                list(link_fields or ()),
            )
        return cls._from_core(core)

    @classmethod
    def create(
        cls,
        nodes: NodeTable,
        links: LinkTable,
        *,
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
        speed_table: LookupTable | object | None = None,
        capacity_table: LookupTable | object | None = None,
    ) -> Network:
        """Create a validated network from explicit node and link tables.

        The resulting object owns NumPy-backed arrays for all structural and
        user columns. Header metadata is validated to the same standard used by
        the Rust crate.
        """
        return cls(
            nodes=nodes,
            links=links,
            banner=banner,
            run_id=run_id,
            zones=zones,
            left_drive=left_drive,
            speed_table=speed_table,
            capacity_table=capacity_table,
        )

    @classmethod
    def like(
        cls,
        other: Network,
        *,
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool | None = None,
    ) -> Network:
        """Create a zero-initialised network with the same schema as ``other``.

        Structural node IDs, link endpoints, metadata, and lookup-table values
        are copied unless explicitly overridden. User columns are reallocated as
        new zero-filled numeric arrays or empty-string object arrays.
        """
        return cls(
            nodes=NodeTable.like(other.nodes),
            links=LinkTable.like(other.links),
            banner=other.banner if banner is None else banner,
            run_id=other.run_id if run_id is None else run_id,
            zones=other.zones if zones is None else zones,
            left_drive=other.left_drive if left_drive is None else left_drive,
            speed_table=other.speed_table.copy(),
            capacity_table=other.capacity_table.copy(),
        )

    @classmethod
    def from_pandas(
        cls,
        *,
        nodes: "pd.DataFrame",
        links: "pd.DataFrame",
        node_field_specs: Sequence[NodeFieldSpec] | None = None,
        link_field_specs: Sequence[LinkFieldSpec] | None = None,
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
        speed_table: LookupTable | object | None = None,
        capacity_table: LookupTable | object | None = None,
    ) -> Network:
        """Build a network from separate node and link pandas frames.

        Parameters
        ----------
        nodes, links:
            Canonical tabular forms with structural columns ``N`` and ``A``/``B``.
        node_field_specs, link_field_specs:
            Optional explicit schema definitions. When omitted, field types are
            inferred from the frame dtypes and values.
        """
        return cls(
            nodes=NodeTable.from_pandas(nodes, field_specs=node_field_specs),
            links=LinkTable.from_pandas(links, field_specs=link_field_specs),
            banner=banner,
            run_id=run_id,
            zones=zones,
            left_drive=left_drive,
            speed_table=speed_table,
            capacity_table=capacity_table,
        )

    @classmethod
    def from_polars(
        cls,
        *,
        nodes: "pl.DataFrame",
        links: "pl.DataFrame",
        node_field_specs: Sequence[NodeFieldSpec] | None = None,
        link_field_specs: Sequence[LinkFieldSpec] | None = None,
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
        speed_table: LookupTable | object | None = None,
        capacity_table: LookupTable | object | None = None,
    ) -> Network:
        """Build a network from separate node and link polars frames."""
        return cls(
            nodes=NodeTable.from_polars(nodes, field_specs=node_field_specs),
            links=LinkTable.from_polars(links, field_specs=link_field_specs),
            banner=banner,
            run_id=run_id,
            zones=zones,
            left_drive=left_drive,
            speed_table=speed_table,
            capacity_table=capacity_table,
        )

    @property
    def banner(self) -> str:
        """Return the validated banner string."""
        return self._banner

    @banner.setter
    def banner(self, value: str) -> None:
        validated = _validate_network_schema(
            self._nodes.field_specs,
            self._links.field_specs,
            banner=value,
            run_id=self._run_id,
            zones=self._zones,
            left_drive=self._left_drive,
        )
        self._banner = validated.banner

    @property
    def run_id(self) -> str:
        """Return the logical run identifier without the ``ID=`` prefix."""
        return self._run_id

    @run_id.setter
    def run_id(self, value: str) -> None:
        validated = _validate_network_schema(
            self._nodes.field_specs,
            self._links.field_specs,
            banner=self._banner,
            run_id=value,
            zones=self._zones,
            left_drive=self._left_drive,
        )
        self._run_id = validated.run_id

    @property
    def zones(self) -> int:
        """Return the validated zone count metadata."""
        return self._zones

    @zones.setter
    def zones(self, value: int) -> None:
        validated = _validate_network_schema(
            self._nodes.field_specs,
            self._links.field_specs,
            banner=self._banner,
            run_id=self._run_id,
            zones=value,
            left_drive=self._left_drive,
        )
        self._zones = validated.zones

    @property
    def left_drive(self) -> bool:
        """Return whether the network is marked as left-drive."""
        return self._left_drive

    @left_drive.setter
    def left_drive(self, value: bool) -> None:
        validated = _validate_network_schema(
            self._nodes.field_specs,
            self._links.field_specs,
            banner=self._banner,
            run_id=self._run_id,
            zones=self._zones,
            left_drive=bool(value),
        )
        self._left_drive = validated.left_drive

    @property
    def nodes(self) -> NodeTable:
        """Return the eager node table."""
        return self._nodes

    @property
    def links(self) -> LinkTable:
        """Return the eager link table."""
        return self._links

    @property
    def speed_table(self) -> LookupTable:
        """Return the SPD lookup table."""
        return self._speed_table

    @property
    def capacity_table(self) -> LookupTable:
        """Return the CAP lookup table."""
        return self._capacity_table

    @property
    def node_row_count(self) -> int:
        """Return the node row count."""
        return self._nodes.row_count

    @property
    def link_row_count(self) -> int:
        """Return the link row count."""
        return self._links.row_count

    def copy(self) -> Network:
        """Return a deep copy of the network and its NumPy-owned state."""
        return Network(
            nodes=self.nodes.copy(),
            links=self.links.copy(),
            banner=self.banner,
            run_id=self.run_id,
            zones=self.zones,
            left_drive=self.left_drive,
            speed_table=self.speed_table.copy(),
            capacity_table=self.capacity_table.copy(),
        )

    def write(self, path: str | Path) -> None:
        """Write the network to disk as a ``.net`` file.

        Python-owned state is validated and rebuilt into a transient Rust
        network immediately before serialisation.
        """
        _NetworkCore.write_from_parts(
            Path(path),
            self.nodes.N,
            _field_specs_to_core(self.nodes.field_specs),
            self.nodes._core_columns(),
            self.links.A,
            self.links.B,
            _field_specs_to_core(self.links.field_specs),
            self.links._core_columns(),
            self.speed_table.values,
            self.capacity_table.values,
            banner=self.banner,
            run_id=self.run_id,
            zones=self.zones,
            left_drive=self.left_drive,
        )

    def to_bytes(self) -> bytes:
        """Serialise the network to ``.net`` bytes.

        This is the in-memory analogue of :meth:`write`.
        """
        return bytes(
            _NetworkCore.to_bytes_from_parts(
                self.nodes.N,
                _field_specs_to_core(self.nodes.field_specs),
                self.nodes._core_columns(),
                self.links.A,
                self.links.B,
                _field_specs_to_core(self.links.field_specs),
                self.links._core_columns(),
                self.speed_table.values,
                self.capacity_table.values,
                banner=self.banner,
                run_id=self.run_id,
                zones=self.zones,
                left_drive=self.left_drive,
            )
        )

    def __bytes__(self) -> bytes:
        return self.to_bytes()

    def to_node_pandas(self) -> "pd.DataFrame":
        """Return the node table as a pandas DataFrame."""
        return self.nodes.to_pandas()

    def to_link_pandas(self) -> "pd.DataFrame":
        """Return the link table as a pandas DataFrame."""
        return self.links.to_pandas()

    def to_pandas_frames(self) -> tuple["pd.DataFrame", "pd.DataFrame"]:
        """Return canonical ``(node_frame, link_frame)`` pandas tables.

        This is the network-level convenience wrapper over
        :meth:`NodeTable.to_pandas` and :meth:`LinkTable.to_pandas`.
        """
        return (self.nodes.to_pandas(), self.links.to_pandas())

    def to_node_polars(self) -> "pl.DataFrame":
        """Return the node table as a polars DataFrame."""
        return self.nodes.to_polars()

    def to_link_polars(self) -> "pl.DataFrame":
        """Return the link table as a polars DataFrame."""
        return self.links.to_polars()

    def to_polars_frames(self) -> tuple["pl.DataFrame", "pl.DataFrame"]:
        """Return canonical ``(node_frame, link_frame)`` polars tables.

        This is the network-level convenience wrapper over
        :meth:`NodeTable.to_polars` and :meth:`LinkTable.to_polars`.
        """
        return (self.nodes.to_polars(), self.links.to_polars())

    def __repr__(self) -> str:
        return (
            "Network("
            f"node_row_count={self.node_row_count}, "
            f"link_row_count={self.link_row_count}, "
            f"zones={self.zones}, "
            f"left_drive={self.left_drive}"
            ")"
        )
