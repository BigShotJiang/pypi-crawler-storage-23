"""Workflow-oriented eager entry points for :mod:`halimede`.

These functions mirror the most common class methods on
:class:`halimede.network.Network`, but keep the typical load and construction
paths available directly from the root package.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Sequence

from .network import LinkTable, LookupTable, Network, NetworkInfo, NodeTable
from .schema import LinkFieldSpec, NodeFieldSpec

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl

__all__ = [
    "create",
    "from_bytes",
    "inspect",
    "inspect_bytes",
    "from_pandas",
    "from_polars",
    "like",
    "read",
]


def read(
    path: str | Path,
    *,
    node_fields: Sequence[str] | None = None,
    link_fields: Sequence[str] | None = None,
) -> Network:
    """Read a ``.net`` file from disk into an eager :class:`Network`.

    Parameters
    ----------
    path:
        Path to the source network file.
    node_fields, link_fields:
        Optional subsets of user fields to load for nodes and links. Structural
        columns and metadata are always loaded.

    Returns
    -------
    Network
        Fully loaded eager network with Python-owned NumPy arrays.
    """
    return Network.read(path, node_fields=node_fields, link_fields=link_fields)


def from_bytes(
    data: bytes | bytearray | memoryview,
    *,
    node_fields: Sequence[str] | None = None,
    link_fields: Sequence[str] | None = None,
) -> Network:
    """Parse an eager :class:`Network` from in-memory ``.net`` bytes.

    Accepts ``bytes``, ``bytearray``, or ``memoryview`` payloads where network
    content is already materialised in memory.
    """
    return Network.from_bytes(data, node_fields=node_fields, link_fields=link_fields)


def inspect(path: str | Path) -> NetworkInfo:
    """Inspect a ``.net`` file without allocating node or link columns.

    Use this to discover metadata and available fields before deciding which
    user columns to load eagerly.
    """
    return NetworkInfo.inspect(path)


def inspect_bytes(data: bytes | bytearray | memoryview) -> NetworkInfo:
    """Inspect in-memory ``.net`` bytes without allocating table columns."""
    return NetworkInfo.from_bytes(data)


def create(
    nodes: NodeTable,
    links: LinkTable,
    *,
    banner: str | None = None,
    run_id: str | None = None,
    zones: int | None = None,
    left_drive: bool = False,
    speed_table: LookupTable | object | None = None,
    capacity_table: LookupTable | object | None = None,
) -> Network:
    """Create a validated network from explicit node and link tables.

    Use this when node and link arrays already exist in Python and only the
    final ``.net`` serialisation should be delegated to Rust.
    """
    return Network.create(
        nodes,
        links,
        banner=banner,
        run_id=run_id,
        zones=zones,
        left_drive=left_drive,
        speed_table=speed_table,
        capacity_table=capacity_table,
    )


def like(
    other: Network,
    *,
    banner: str | None = None,
    run_id: str | None = None,
    zones: int | None = None,
    left_drive: bool | None = None,
) -> Network:
    """Create a zero-initialised network with the same schema as *other*.

    Structural IDs, link endpoints, metadata, and lookup-table values are
    copied from *other* unless explicitly overridden.
    """
    return Network.like(
        other,
        banner=banner,
        run_id=run_id,
        zones=zones,
        left_drive=left_drive,
    )


def from_pandas(
    *,
    nodes: "pd.DataFrame",
    links: "pd.DataFrame",
    node_field_specs: Sequence[NodeFieldSpec] | None = None,
    link_field_specs: Sequence[LinkFieldSpec] | None = None,
    banner: str | None = None,
    run_id: str | None = None,
    zones: int | None = None,
    left_drive: bool = False,
    speed_table: LookupTable | object | None = None,
    capacity_table: LookupTable | object | None = None,
) -> Network:
    """Build a network from separate node and link pandas frames.

    The canonical frame form is separate node and link tables with structural
    column names ``N`` and ``A``/``B``.
    """
    return Network.from_pandas(
        nodes=nodes,
        links=links,
        node_field_specs=node_field_specs,
        link_field_specs=link_field_specs,
        banner=banner,
        run_id=run_id,
        zones=zones,
        left_drive=left_drive,
        speed_table=speed_table,
        capacity_table=capacity_table,
    )


def from_polars(
    *,
    nodes: "pl.DataFrame",
    links: "pl.DataFrame",
    node_field_specs: Sequence[NodeFieldSpec] | None = None,
    link_field_specs: Sequence[LinkFieldSpec] | None = None,
    banner: str | None = None,
    run_id: str | None = None,
    zones: int | None = None,
    left_drive: bool = False,
    speed_table: LookupTable | object | None = None,
    capacity_table: LookupTable | object | None = None,
) -> Network:
    """Build a network from separate node and link polars frames."""
    return Network.from_polars(
        nodes=nodes,
        links=links,
        node_field_specs=node_field_specs,
        link_field_specs=link_field_specs,
        banner=banner,
        run_id=run_id,
        zones=zones,
        left_drive=left_drive,
        speed_table=speed_table,
        capacity_table=capacity_table,
    )
