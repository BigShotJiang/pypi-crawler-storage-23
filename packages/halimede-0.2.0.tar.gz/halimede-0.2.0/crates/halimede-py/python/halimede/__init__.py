"""Public Python API for eager NumPy-backed Voyager network editing."""

from importlib.metadata import PackageNotFoundError, version as _metadata_version

from ._core import (
    HalimedeError,
    HalimedeIoError,
    HalimedeParseError,
    HalimedeValidationError,
)
from .capabilities import (
    has_dataframe_support,
    has_pandas_support,
    has_polars_support,
)
from .io import (
    create,
    from_bytes,
    from_pandas,
    from_polars,
    inspect,
    inspect_bytes,
    like,
    read,
)
from .network import LinkTable, LookupTable, Network, NetworkInfo, NodeTable
from .schema import (
    FieldType,
    LinkFieldSpec,
    NodeFieldSpec,
    link_field,
    node_field,
)

try:
    __version__: str = _metadata_version("halimede")
except PackageNotFoundError:  # pragma: no cover - source tree fallback.
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "FieldType",
    "LinkFieldSpec",
    "LinkTable",
    "LookupTable",
    "Network",
    "NetworkInfo",
    "NodeFieldSpec",
    "NodeTable",
    "HalimedeError",
    "HalimedeIoError",
    "HalimedeParseError",
    "HalimedeValidationError",
    "create",
    "from_bytes",
    "from_pandas",
    "from_polars",
    "inspect",
    "inspect_bytes",
    "has_dataframe_support",
    "has_pandas_support",
    "has_polars_support",
    "like",
    "link_field",
    "node_field",
    "read",
]
