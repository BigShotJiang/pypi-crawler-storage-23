"""Type stubs for the private Rust binding module used by :mod:`halimede`."""

from __future__ import annotations

from os import PathLike
from typing import Iterable

import numpy as np
import numpy.typing as npt


class HalimedeError(Exception):
    kind: str
    offset: int | None


class HalimedeIoError(HalimedeError): ...
class HalimedeParseError(HalimedeError): ...
class HalimedeValidationError(HalimedeError): ...


class FieldDef:
    """Private binding field descriptor used for schema exchange with Rust."""
    name: str
    field_type: str
    max_size: int | None

    def __init__(
        self, name: str, field_type: str, max_size: int | None = None, /
    ) -> None: ...


class TableSchema:
    """Private binding table schema view."""
    @property
    def field_count(self) -> int: ...
    def fields(self) -> list[FieldDef]: ...
    def field_names(self) -> list[str]: ...
    def find(self, name: str, /) -> FieldDef | None: ...


class NetworkSchemaResult:
    """Validated metadata and schema result returned by Rust helpers."""
    banner: str
    run_id: str
    zones: int
    left_drive: bool

    def node_schema(self) -> TableSchema: ...
    def link_schema(self) -> TableSchema: ...


class NetworkInfoResult:
    """Parsed network metadata and schemas without allocating table columns."""
    banner: str
    run_id: str
    zones: int
    left_drive: bool
    node_row_count: int
    link_row_count: int

    @staticmethod
    def open(path: str | PathLike[str], /) -> NetworkInfoResult: ...
    @staticmethod
    def from_bytes(
        data: bytes | bytearray | memoryview, /
    ) -> NetworkInfoResult: ...
    def node_schema(self) -> TableSchema: ...
    def link_schema(self) -> TableSchema: ...
    def speed_table(self) -> npt.NDArray[np.float64]: ...
    def capacity_table(self) -> npt.NDArray[np.float64]: ...


class _CoreSnapshot:
    banner: str
    run_id: str
    zones: int
    left_drive: bool

    def node_ids(self) -> npt.NDArray[np.int32]: ...
    def node_fields(self) -> list[FieldDef]: ...
    def node_columns(self) -> list[npt.NDArray[np.float64] | list[str]]: ...
    def link_a(self) -> npt.NDArray[np.int32]: ...
    def link_b(self) -> npt.NDArray[np.int32]: ...
    def link_fields(self) -> list[FieldDef]: ...
    def link_columns(self) -> list[npt.NDArray[np.float64] | list[str]]: ...
    def speed_table(self) -> npt.NDArray[np.float64]: ...
    def capacity_table(self) -> npt.NDArray[np.float64]: ...


class _NetworkCore:
    """Transient Rust-owned network used only during IO and validation."""
    @staticmethod
    def open(path: str | PathLike[str], /) -> _NetworkCore: ...
    @staticmethod
    def from_bytes(data: bytes | bytearray | memoryview, /) -> _NetworkCore: ...
    @staticmethod
    def open_fields(
        path: str | PathLike[str],
        node_fields: list[str],
        link_fields: list[str],
        /,
    ) -> _NetworkCore: ...
    @staticmethod
    def from_bytes_fields(
        data: bytes | bytearray | memoryview,
        node_fields: list[str],
        link_fields: list[str],
        /,
    ) -> _NetworkCore: ...
    @staticmethod
    def validate_schema(
        node_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        link_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
    ) -> NetworkSchemaResult: ...
    @property
    def banner(self) -> str: ...
    @property
    def run_id(self) -> str: ...
    @property
    def zones(self) -> int: ...
    @property
    def left_drive(self) -> bool: ...
    @property
    def node_row_count(self) -> int: ...
    @property
    def link_row_count(self) -> int: ...
    def node_schema(self) -> TableSchema: ...
    def link_schema(self) -> TableSchema: ...
    def node_ids(self) -> npt.NDArray[np.int32]: ...
    def link_a(self) -> npt.NDArray[np.int32]: ...
    def link_b(self) -> npt.NDArray[np.int32]: ...
    def node_numeric_column(self, name: str, /) -> npt.NDArray[np.float64]: ...
    def node_string_column(self, name: str, /) -> list[str]: ...
    def link_numeric_column(self, name: str, /) -> npt.NDArray[np.float64]: ...
    def link_string_column(self, name: str, /) -> list[str]: ...
    def speed_table(self) -> npt.NDArray[np.float64]: ...
    def capacity_table(self) -> npt.NDArray[np.float64]: ...
    def take_snapshot(self) -> _CoreSnapshot: ...
    def write(self, path: str | PathLike[str], /) -> None: ...
    def to_bytes(self) -> bytes: ...
    @staticmethod
    def write_from_parts(
        path: str | PathLike[str],
        node_ids: npt.NDArray[np.int32],
        node_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        node_columns: Iterable[npt.NDArray[np.float64] | list[str]],
        link_a: npt.NDArray[np.int32],
        link_b: npt.NDArray[np.int32],
        link_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        link_columns: Iterable[npt.NDArray[np.float64] | list[str]],
        speed_table: npt.NDArray[np.float64],
        capacity_table: npt.NDArray[np.float64],
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
    ) -> None: ...
    @staticmethod
    def to_bytes_from_parts(
        node_ids: npt.NDArray[np.int32],
        node_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        node_columns: Iterable[npt.NDArray[np.float64] | list[str]],
        link_a: npt.NDArray[np.int32],
        link_b: npt.NDArray[np.int32],
        link_fields: Iterable[FieldDef | tuple[str, str] | tuple[str, str, int]],
        link_columns: Iterable[npt.NDArray[np.float64] | list[str]],
        speed_table: npt.NDArray[np.float64],
        capacity_table: npt.NDArray[np.float64],
        banner: str | None = None,
        run_id: str | None = None,
        zones: int | None = None,
        left_drive: bool = False,
    ) -> bytes: ...
