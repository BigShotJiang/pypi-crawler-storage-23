"""Optional dependency capability helpers."""

from __future__ import annotations

from importlib.util import find_spec

__all__ = [
    "has_dataframe_support",
    "has_pandas_support",
    "has_polars_support",
]


def has_pandas_support() -> bool:
    """Return ``True`` when pandas is importable."""
    return find_spec("pandas") is not None


def has_polars_support() -> bool:
    """Return ``True`` when polars is importable."""
    return find_spec("polars") is not None


def has_dataframe_support() -> bool:
    """Return ``True`` when either pandas or polars is importable."""
    return has_pandas_support() or has_polars_support()
