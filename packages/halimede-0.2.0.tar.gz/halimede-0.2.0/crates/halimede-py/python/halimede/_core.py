from __future__ import annotations

from typing import NoReturn

from ._halimede import (
    _CoreSnapshot,
    FieldDef,
    NetworkInfoResult,
    NetworkSchemaResult,
    TableSchema,
    HalimedeError,
    HalimedeIoError,
    HalimedeParseError,
    HalimedeValidationError,
    _NetworkCore,
)

__all__ = [
    "FieldDef",
    "NetworkInfoResult",
    "NetworkSchemaResult",
    "TableSchema",
    "HalimedeError",
    "HalimedeIoError",
    "HalimedeParseError",
    "HalimedeValidationError",
    "_CoreSnapshot",
    "_NetworkCore",
    "_new_validation_error",
    "_raise_validation",
]


def _new_validation_error(
    message: str,
    *,
    kind: str = "validation",
    offset: int | None = None,
) -> HalimedeValidationError:
    error = HalimedeValidationError(message)
    setattr(error, "kind", kind)
    setattr(error, "offset", offset)
    return error


def _raise_validation(
    message: str,
    *,
    kind: str = "validation",
    offset: int | None = None,
) -> NoReturn:
    raise _new_validation_error(message, kind=kind, offset=offset)
