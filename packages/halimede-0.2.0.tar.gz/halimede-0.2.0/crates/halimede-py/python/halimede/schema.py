"""Schema helpers for explicit node and link field definitions.

The schema layer keeps wire-format details visible only where they matter:
field names, numeric-versus-string choice, and optional explicit string widths.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ._core import FieldDef, HalimedeValidationError

__all__ = [
    "FieldType",
    "LinkFieldSpec",
    "NodeFieldSpec",
    "link_field",
    "node_field",
    "normalise_link_field_specs",
    "normalise_node_field_specs",
]


@dataclass(frozen=True)
class FieldType:
    """Validated user-field type descriptor.

    ``numeric`` fields are stored as ``float64`` arrays in Python.
    ``string`` fields are stored as object arrays of Python strings.
    Explicit ``max_size`` values are measured in encoded UTF-8 bytes.
    """

    kind: str
    max_size: int | None = None

    def __post_init__(self) -> None:
        if self.kind not in {"numeric", "string"}:
            raise HalimedeValidationError(
                "field type kind must be 'numeric' or 'string'"
            )

        if self.kind == "numeric":
            if self.max_size is not None:
                raise HalimedeValidationError(
                    "numeric fields must not declare max_size"
                )
            return

        if self.max_size is not None and not 1 <= self.max_size <= 255:
            raise HalimedeValidationError(
                "string field max_size must be within 1..=255"
            )

    @classmethod
    def numeric(cls) -> FieldType:
        """Return the canonical numeric field type."""
        return cls("numeric")

    @classmethod
    def string(cls, *, max_size: int | None = None) -> FieldType:
        """Return the canonical string field type.

        Parameters
        ----------
        max_size:
            Optional explicit on-disk width in encoded bytes. When omitted,
            width is inferred from the actual column values during writes.
        """
        return cls("string", max_size=max_size)

    @property
    def is_numeric(self) -> bool:
        """Return ``True`` when the field type is numeric."""
        return self.kind == "numeric"

    @property
    def is_string(self) -> bool:
        """Return ``True`` when the field type is string."""
        return self.kind == "string"


@dataclass(frozen=True)
class NodeFieldSpec:
    """Validated node-field schema item.

    Node field specs describe user fields only. The structural ``N`` column is
    implicit and must not appear here.
    """

    name: str
    field_type: FieldType

    def __post_init__(self) -> None:
        _validate_field_name(self.name)

    @classmethod
    def float64(cls, name: str) -> NodeFieldSpec:
        """Create a numeric node-field specification."""
        return cls(name=name, field_type=FieldType.numeric())

    @classmethod
    def string(
        cls, name: str, *, max_size: int | None = None
    ) -> NodeFieldSpec:
        """Create a string node-field specification."""
        return cls(name=name, field_type=FieldType.string(max_size=max_size))

    def to_core(self) -> FieldDef:
        """Convert to the private Rust binding field descriptor."""
        return FieldDef(self.name, self.field_type.kind, self.field_type.max_size)

    @classmethod
    def from_core(cls, field: FieldDef) -> NodeFieldSpec:
        """Convert a private Rust binding field descriptor into a spec."""
        return cls(
            name=field.name,
            field_type=FieldType(field.field_type, field.max_size),
        )


@dataclass(frozen=True)
class LinkFieldSpec:
    """Validated link-field schema item.

    Link field specs describe user fields only. Structural ``A`` and ``B``
    endpoints are implicit and must not appear here.
    """

    name: str
    field_type: FieldType

    def __post_init__(self) -> None:
        _validate_field_name(self.name)

    @classmethod
    def float64(cls, name: str) -> LinkFieldSpec:
        """Create a numeric link-field specification."""
        return cls(name=name, field_type=FieldType.numeric())

    @classmethod
    def string(
        cls, name: str, *, max_size: int | None = None
    ) -> LinkFieldSpec:
        """Create a string link-field specification."""
        return cls(name=name, field_type=FieldType.string(max_size=max_size))

    def to_core(self) -> FieldDef:
        """Convert to the private Rust binding field descriptor."""
        return FieldDef(self.name, self.field_type.kind, self.field_type.max_size)

    @classmethod
    def from_core(cls, field: FieldDef) -> LinkFieldSpec:
        """Convert a private Rust binding field descriptor into a spec."""
        return cls(
            name=field.name,
            field_type=FieldType(field.field_type, field.max_size),
        )


def node_field(
    name: str, field_type: FieldType | str, max_size: int | None = None
) -> NodeFieldSpec:
    """Create a node-field specification from explicit pieces.

    This is the concise checked constructor when a full
    :class:`NodeFieldSpec` call would be noisy.
    """
    return NodeFieldSpec(name=name, field_type=_parse_field_type(field_type, max_size))


def link_field(
    name: str, field_type: FieldType | str, max_size: int | None = None
) -> LinkFieldSpec:
    """Create a link-field specification from explicit pieces."""
    return LinkFieldSpec(name=name, field_type=_parse_field_type(field_type, max_size))


def normalise_node_field_specs(
    fields: Iterable[
        NodeFieldSpec | FieldDef | tuple[str, str] | tuple[str, str, int]
    ],
) -> tuple[NodeFieldSpec, ...]:
    """Normalise explicit node-field definitions into validated specs.

    Accepted inputs are existing specs, private binding ``FieldDef`` values, or
    ``(name, field_type[, max_size])`` tuples.
    """
    return _normalise_field_specs(fields, NodeFieldSpec, reserved={"N"})


def normalise_link_field_specs(
    fields: Iterable[
        LinkFieldSpec | FieldDef | tuple[str, str] | tuple[str, str, int]
    ],
) -> tuple[LinkFieldSpec, ...]:
    """Normalise explicit link-field definitions into validated specs."""
    return _normalise_field_specs(fields, LinkFieldSpec, reserved={"A", "B"})


def _validate_field_name(name: str) -> None:
    if not isinstance(name, str):
        raise HalimedeValidationError("field name must be a string")
    if not name:
        raise HalimedeValidationError("field name must not be empty")


def _parse_field_type(
    field_type: FieldType | str, max_size: int | None = None
) -> FieldType:
    if isinstance(field_type, FieldType):
        if max_size is not None:
            raise HalimedeValidationError(
                "max_size must not be provided when field_type is already a FieldType"
            )
        return field_type

    if not isinstance(field_type, str):
        raise HalimedeValidationError(
            "field_type must be a FieldType or string token"
        )

    if field_type == "numeric":
        return FieldType.numeric()
    if field_type == "string":
        return FieldType.string(max_size=max_size)
    raise HalimedeValidationError("field_type must be 'numeric' or 'string'")


def _normalise_field_specs(
    fields: Iterable[object],
    spec_type: type[NodeFieldSpec] | type[LinkFieldSpec],
    *,
    reserved: set[str],
) -> tuple[NodeFieldSpec | LinkFieldSpec, ...]:
    normalised: list[NodeFieldSpec | LinkFieldSpec] = []
    seen_names: set[str] = set()

    for field_index, item in enumerate(fields):
        if isinstance(item, spec_type):
            spec = item
        elif isinstance(item, FieldDef):
            spec = spec_type(
                name=item.name,
                field_type=FieldType(item.field_type, item.max_size),
            )
        else:
            try:
                name, field_type, *rest = item  # type: ignore[misc]
            except Exception as error:  # pragma: no cover - defensive
                raise HalimedeValidationError(
                    f"fields[{field_index}] must be a field spec or tuple"
                ) from error

            if len(rest) > 1:
                raise HalimedeValidationError(
                    f"fields[{field_index}] tuple must contain 2 or 3 items"
                )
            max_size = rest[0] if rest else None
            spec = spec_type(name=name, field_type=_parse_field_type(field_type, max_size))

        if spec.name in reserved:
            raise HalimedeValidationError(
                f"{spec.name!r} is a reserved structural field name"
            )
        if spec.name in seen_names:
            raise HalimedeValidationError(f"duplicate field name {spec.name!r}")

        seen_names.add(spec.name)
        normalised.append(spec)

    return tuple(normalised)
