Error Handling and Diagnostics
==============================

``halimede`` exposes distinct exception types from the root package:

* ``HalimedeIoError``
* ``HalimedeParseError``
* ``HalimedeValidationError``

Each exception carries two diagnostic fields. ``kind`` is a stable snake_case
string suitable for programmatic handling. ``offset`` reports the byte position
where malformed file input was detected, or ``None`` when the error is not
position-specific. Pure Python validation checks use ``offset=None`` and a
generic or derived validation ``kind``.

.. code-block:: python

   import halimede

   try:
       network = halimede.read("network.net")
   except halimede.HalimedeParseError as error:
       print(error.kind)
       print(error.offset)
       print(str(error))

Prefer logging ``kind`` and relevant input context rather than matching full
message text.

Validation Errors
-----------------

Most Python-surface mistakes raise ``HalimedeValidationError`` before Rust
serialisation is attempted. Common examples include:

* missing structural columns in pandas or polars imports
* duplicate or reserved field names
* non-integral or non-positive structural IDs
* string values wider than the declared or inferred encoded width

Missing Field Names
-------------------

Missing-field lookups on node and link tables raise ``KeyError`` with a close
match suggestion and a preview of available user fields.

.. code-block:: python

   network = halimede.read("network.net")
   network.links["DISTS"]
   # Raises: field 'DISTS' not found; did you mean 'DIST'?; available fields: ...

Structural and Width Errors
---------------------------

Structural IDs are validated as positive integers within the ``int32`` range.
String widths are validated in encoded UTF-8 bytes.

.. code-block:: python

   import halimede

   halimede.NodeTable([1.5], {})
   # Raises HalimedeValidationError.

   halimede.NodeTable(
       [1],
       {"NAME": ["toolong"]},
       field_specs=[halimede.NodeFieldSpec.string("NAME", max_size=2)],
   )
   # Raises HalimedeValidationError.

Optional Dependency Errors
--------------------------

Dataframe methods raise descriptive ``ImportError`` exceptions when ``pandas``
or ``polars`` is not installed. Use :func:`halimede.has_pandas_support` and
:func:`halimede.has_polars_support` to check availability before calling those
paths in optional workflows.

Quick Debug Checklist
---------------------

When tracing a data or API failure, check in this order:

1. Confirm ``banner``, ``run_id``, ``zones``, and row counts before any
   transform logic.
2. Confirm whether the failing field is structural (``N``/``A``/``B``) or a
   user field.
3. Confirm row counts and string widths immediately before every write-back
   call.
