NumPy Workflows
===============

The main editing surface is eager and NumPy-backed. Rust is not kept alive as a
live data owner after parsing.

Core Edit Pattern
-----------------

Node and link tables expose user fields as one-dimensional arrays. Subscript
access returns the stored array directly.

.. code-block:: python

   network.links["TIME"] = network.links["DIST"] / network.links["SPEED"] * 60.0
   network.nodes["X"] += 100.0

In-place edits modify the table immediately:

.. code-block:: python

   dist = network.links["DIST"]
   dist *= 1.05

When an operation creates a new array, assign it back to replace the stored
column.

.. code-block:: python

   network.nodes["X"] = network.nodes["X"] * 1.1

Add, Replace, Retain, and Remove Fields
---------------------------------------

Replacing or appending a column validates row count and field type:

.. code-block:: python

   network.links["LANE_NAME"] = ["one", "two", "three"]

Bulk schema edits stay explicit:

.. code-block:: python

   network.nodes.remove_fields(["NAME"])
   network.links.retain_fields(["DIST", "SPEED", "TIME"])

Structural columns are edited separately:

Structural IDs must stay positive integers within the ``int32`` range.

.. code-block:: python

   network.nodes.N = [1, 2, 3]
   network.links.A = [1, 2]
   network.links.B = [2, 3]

String Fields and Widths
------------------------

String fields are stored as object arrays of Python strings. Width is inferred
by default from the widest encoded value, but explicit widths can be declared
through field specs.

.. code-block:: python

   import halimede

   nodes = halimede.NodeTable(
       [1, 2],
       {"NAME": ["alpha", "beta"]},
       field_specs=[halimede.NodeFieldSpec.string("NAME", max_size=16)],
   )

Widths are measured in encoded UTF-8 bytes rather than Python character counts.

Copy Semantics
--------------

``copy()`` detaches all Python-owned arrays, including lookup tables.

.. code-block:: python

   copied = network.copy()
   copied.links["DIST"][0] = 999.0

   assert network.links["DIST"][0] != 999.0

Performance Notes
-----------------

Prefer vectorised NumPy expressions over Python loops. The Python API is
designed so that once data is loaded, most transform cost is ordinary NumPy
work rather than callback overhead.
