Network API
===========

The in-memory API is centred on :class:`halimede.network.Network`, with
explicit :class:`halimede.network.NodeTable` and
:class:`halimede.network.LinkTable` objects for structural and user-field data.

Three behavioural notes matter throughout this API:

1. ``network.nodes["FIELD"]`` and ``network.links["FIELD"]`` return the stored
   NumPy arrays. In-place edits mutate the owning table directly.
2. Structural columns are separate properties rather than mapping keys:
   ``network.nodes.N`` and ``network.links.A``/``network.links.B``.
3. ``network.copy()`` detaches all Python-owned arrays. Mutating the copy does
   not mutate the source network.

When the workflow needs cheap discovery first, use
:class:`halimede.network.NetworkInfo` instead of reading a full eager network.

Quick Example
-------------

.. code-block:: python

   import halimede

   network = halimede.read("network.net")
   node_frame, link_frame = network.to_pandas_frames()

   dist = network.links["DIST"]
   speed = network.links["SPEED"]
   network.links["TIME"] = dist / speed * 60.0
   network.nodes.remove_fields(["NAME"])

   payload = network.to_bytes()
   restored = halimede.from_bytes(payload)

Lookup Tables
-------------

.. autoclass:: halimede.network.LookupTable
   :members:
   :member-order: bysource

Inspected Network Metadata
--------------------------

.. autoclass:: halimede.network.NetworkInfo
   :members:
   :member-order: bysource

Node Tables
-----------

.. autoclass:: halimede.network.NodeTable
   :members:
   :member-order: bysource
   :inherited-members:

Link Tables
-----------

.. autoclass:: halimede.network.LinkTable
   :members:
   :member-order: bysource
   :inherited-members:

Networks
--------

.. autoclass:: halimede.network.Network
   :members:
   :member-order: bysource
