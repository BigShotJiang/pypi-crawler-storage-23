I/O Functions
=============

The root-level eager entry points either load :class:`halimede.network.Network`
instances directly or construct them from explicit node/link tables and
canonical dataframe inputs. Selective loading keeps field-selection assumptions
visible at the call site.

All import and construction functions share the same validation model:

1. Structural node and link columns are required.
2. Banners must start with ``NET`` and run IDs are stored without the ``ID=``
   prefix.
3. String widths are validated in encoded bytes.
4. Python-owned arrays and frames are fully checked before ``.net``
   serialisation.

Quick Example
-------------

.. code-block:: python

   import halimede

   info = halimede.inspect("network.net")
   network = info.load(node_fields=["X", "Y"], link_fields=["DIST", "SPEED"])
   network.links["TIME"] = network.links["DIST"] / network.links["SPEED"] * 60.0
   network.write("network_updated.net")

Capability Helpers
------------------

Optional dataframe support can be checked explicitly before calling dataframe
or frame-construction paths.

.. autofunction:: halimede.has_pandas_support

.. autofunction:: halimede.has_polars_support

.. autofunction:: halimede.has_dataframe_support

Reference
---------

.. autofunction:: halimede.io.read

.. autofunction:: halimede.io.from_bytes

.. autofunction:: halimede.io.inspect

.. autofunction:: halimede.io.inspect_bytes

.. autofunction:: halimede.io.create

.. autofunction:: halimede.io.like

.. autofunction:: halimede.io.from_pandas

.. autofunction:: halimede.io.from_polars
