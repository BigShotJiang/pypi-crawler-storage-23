Schema Helpers
==============

Schema objects validate field names, field types, and explicit string widths at
construction time. They are useful when schema originates from configuration,
metadata, or dataframe imports where width control matters.

The four core helpers are:

1. :class:`halimede.schema.FieldType` for validated numeric and string types.
2. :class:`halimede.schema.NodeFieldSpec` for validated node-field schema items.
3. :class:`halimede.schema.LinkFieldSpec` for validated link-field schema items.
4. :func:`halimede.schema.node_field` and :func:`halimede.schema.link_field`
   as concise checked constructors.

Quick Example
-------------

.. code-block:: python

   import halimede

   node_fields = [
       halimede.NodeFieldSpec.float64("X"),
       halimede.NodeFieldSpec.string("NAME", max_size=16),
   ]

   link_fields = [
       halimede.LinkFieldSpec.float64("DIST"),
       halimede.LinkFieldSpec.string("RDTYPE"),
   ]

Reference
---------

.. autoclass:: halimede.schema.FieldType
   :members:
   :member-order: bysource

.. autoclass:: halimede.schema.NodeFieldSpec
   :members:
   :member-order: bysource

.. autoclass:: halimede.schema.LinkFieldSpec
   :members:
   :member-order: bysource

.. autofunction:: halimede.schema.node_field

.. autofunction:: halimede.schema.link_field

.. autofunction:: halimede.schema.normalise_node_field_specs

.. autofunction:: halimede.schema.normalise_link_field_specs
