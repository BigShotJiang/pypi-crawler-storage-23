API Reference
=============

The reference is organised by usage layer: root-level I/O and construction
functions, the in-memory network and table objects, and schema definition
helpers. Read :doc:`../quickstart` first if you are new to the package, then
use this section for exact method signatures and behavioural details.

Four conventions apply throughout the Python API:

1. Structural columns are explicit properties: ``N`` for nodes and ``A``/``B``
   for links.
2. The mapping interface on :class:`halimede.network.NodeTable` and
   :class:`halimede.network.LinkTable` covers user fields only.
3. Field order is preserved exactly as loaded or declared, including during
   dataframe import and export.
4. String widths are measured in encoded UTF-8 bytes, not Python character
   counts.

.. toctree::
   :maxdepth: 2

   io
   schema
   network
