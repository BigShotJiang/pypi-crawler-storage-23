Quickstart
==========

These examples follow one :class:`halimede.network.Network` from loading
through editing, serialisation, and dataframe interchange. The sequence covers
four stages after installation:

1. Read a network and inspect its metadata and schema.
2. Apply direct NumPy edits to node and link fields.
3. Serialise to ``.net`` bytes or write to disk.
4. Round-trip through pandas or polars when tabular processing is needed.

Installation
------------

`uv <https://docs.astral.sh/uv/>`_ is used in the examples below. Equivalent
``pip`` workflows work when the same dependencies are installed.

Install the base package:

.. code-block:: bash

   uv add halimede

Optional dependencies are only needed for dataframe adapters:

* Install ``pandas`` for :func:`halimede.from_pandas` and
  :meth:`halimede.network.NodeTable.to_pandas`.
* Install ``polars`` for :func:`halimede.from_polars` and
  :meth:`halimede.network.NodeTable.to_polars`.

For one-off execution without creating a project:

.. code-block:: bash

   uv run --with halimede python your_script.py

Step 1: Inspect, Then Read
--------------------------

Inspecting a ``.net`` file returns lightweight metadata and schema only.
Reading returns a fully eager :class:`halimede.network.Network`.

.. code-block:: python

   import halimede

   info = halimede.inspect("network.net")

   print(info.banner)
   print(info.run_id)
   print(info.node_row_count, info.link_row_count)
   print(info.node_field_names)
   print(info.link_field_names)

   network = info.load(
       node_fields=["X", "Y"],
       link_fields=["DIST", "SPEED"],
   )

   print(network.banner)
   print(network.run_id)
   print(network.zones)
   print(network.left_drive)
   print(network.node_row_count, network.link_row_count)
   print(network.nodes.field_names)
   print(network.links.field_names)

Structural columns are explicit properties:

* ``network.nodes.N``
* ``network.links.A``
* ``network.links.B``

Step 2: Inspect and Edit Values
-------------------------------

User fields use the mapping interface and return the stored NumPy arrays.
In-place edits mutate the network directly.

.. code-block:: python

   x = network.nodes["X"]           # Stored array.
   x *= 1.1                         # In-place, modifies network directly.

   dist = network.links["DIST"]
   speed = network.links["SPEED"]
   network.links["TIME"] = dist / speed * 60.0

   network.nodes.remove_fields(["NAME"])
   network.links.retain_fields(["DIST", "SPEED", "TIME"])

When an expression creates a new array, assign it back to replace the column.

.. code-block:: python

   network.nodes["X2"] = network.nodes["X"] * 2.0

Step 3: Write or Serialise
--------------------------

``write`` serialises directly to disk. ``to_bytes`` is useful for API payloads,
object stores, or test fixtures.

.. code-block:: python

   network.write("network_updated.net")

   payload = network.to_bytes()
   restored = halimede.from_bytes(payload)
   print(restored.links.field_names)

Step 4: DataFrame Interchange
-----------------------------

Node and link tables have separate canonical dataframe forms.

.. code-block:: python

   node_frame, link_frame = network.to_pandas_frames()

   rebuilt_pandas = halimede.from_pandas(
       nodes=node_frame,
       links=link_frame,
       banner=network.banner,
       run_id=network.run_id,
       zones=network.zones,
       left_drive=network.left_drive,
   )

   node_frame_polars, link_frame_polars = network.to_polars_frames()

   rebuilt_polars = halimede.from_polars(
       nodes=node_frame_polars,
       links=link_frame_polars,
       banner=network.banner,
       run_id=network.run_id,
       zones=network.zones,
       left_drive=network.left_drive,
   )
