Performance And Benchmarks
==========================

The Python package ships with a dedicated benchmark module covering the main
workflow shapes:

* full parse from bytes
* selective parse from bytes
* serialise back to bytes
* pandas export
* selective load, derive fields, and write

The intent of the suite is not micro-optimisation of individual helper calls.
It measures the workflows that matter for this package design: eager load into
Python-owned arrays, vectorised mutation, and serialisation back to ``.net``.

The benchmark suite lives in ``crates/halimede-py/tests/bench_performance.py``.

Run it with the benchmark dependency group installed:

.. code-block:: sh

   uv sync --group bench
   .venv/bin/python -m pytest crates/halimede-py/tests/bench_performance.py --benchmark-only

The benchmarks use fixture-backed ``.net`` files under ``fixtures/bench`` so
results reflect realistic node and link schemas rather than synthetic
micro-cases.

Interpret the results with the package design in mind:

1. Full eager reads include Rust parsing plus Python/NumPy materialisation.
2. Selective reads are usually the most relevant benchmark for production
   transform jobs.
3. Write timings include rebuilding a transient Rust network from the Python
   state before serialisation.
