Inspecting Networks, Tables, and Lookup Data
============================================

The cheapest way to discover a network is :func:`halimede.inspect`. It parses
only header metadata, lookup tables, and ordered node/link schemas without
allocating node or link column arrays.

Inspect Before You Load
-----------------------

.. code-block:: python

   import halimede

   info = halimede.inspect("network.net")

   print(info.banner)
   print(info.run_id)
   print(info.node_row_count, info.link_row_count)
   print(info.node_field_names)
   print(info.link_field_names)

   network = info.load(
       node_fields=["X", "Y"],
       link_fields=["DIST", "SPEED"],
   )

Use :func:`halimede.inspect_bytes` for already-materialised ``.net`` payloads.

The eager :class:`~halimede.network.Network` object exposes the same metadata at
three levels: file-wide header fields, ordered node and link schemas, and
SPD/CAP lookup tables used by Voyager for speed and capacity defaults.

Network Metadata
----------------

Header metadata is available directly on the network object.

.. code-block:: python

   import halimede

   network = halimede.read("network.net")

   print(network.banner)
   print(network.run_id)
   print(network.zones)
   print(network.left_drive)
   print(network.node_row_count)
   print(network.link_row_count)

``banner`` is the text banner written into the ``NET`` record. ``run_id`` is
the logical identifier without the on-disk ``ID=`` prefix. ``zones`` and
``left_drive`` are metadata fields preserved during round-trip writes.

Node and Link Schema
--------------------

Node and link schemas are available both on :class:`halimede.network.NetworkInfo`
and on eager tables.

.. code-block:: python

   print(info.node_field_names)
   print(info.link_field_names)

   print(network.nodes.field_names)
   print(network.links.field_names)

   for spec in network.links.field_specs:
       print(spec.name, spec.field_type.kind, spec.field_type.max_size)

   print(info.link_field_spec("DIST").field_type.kind)
   print(network.links.field_type("DIST").kind)

Field order is preserved exactly as loaded. String widths, when explicit, are
stored in encoded bytes.

Structural Columns
------------------

Structural columns are separate from the mapping interface:

.. code-block:: python

   node_ids = network.nodes.N
   from_nodes = network.links.A
   to_nodes = network.links.B

The mapping interface covers user fields only:

.. code-block:: python

   if "DIST" in network.links:
       dist = network.links["DIST"]

   print(network.links.keys())

SPD and CAP Lookup Tables
-------------------------

``network.speed_table`` and ``network.capacity_table`` expose the Voyager
9-lane by 99-class lookup arrays.

.. code-block:: python

   speed = network.speed_table
   print(speed.get(2, 10))

   cap = network.capacity_table.copy()
   cap.set(3, 20, 1500.0)

Both tables are NumPy-backed and can be converted to arrays with
:meth:`halimede.network.LookupTable.to_numpy`.

Selective Loading
-----------------

``halimede`` can load only the user fields you need for a workflow while still
loading structural columns and metadata. In practice, inspect-first is the most
predictable way to choose those field lists.

.. code-block:: python

   info = halimede.inspect("network.net")
   network = info.load(node_fields=["X", "Y"], link_fields=["DIST", "SPEED"])

Selective loading reduces Python allocation when the workflow only needs a
subset of user fields. Structural columns remain available through ``N``,
``A``, and ``B`` even when all user fields are omitted.

Reading from Bytes
------------------

:func:`halimede.from_bytes` parses a network from an in-memory byte sequence
rather than a file path.

.. code-block:: python

   payload = Path("network.net").read_bytes()
   network = halimede.from_bytes(payload)
   print(network.links.field_names)
