halimede Python API
===================

``halimede`` reads, edits, and writes Voyager ``.net`` binary network files.
The Python API is eager and NumPy-first: Rust is used only for strict parsing,
validation, and serialisation, while node and link data are exposed as
Python-owned arrays.

What The Package Provides
-------------------------

The package covers the full round trip for Voyager network data: loading
existing networks, selectively loading node and link fields, applying direct
NumPy transforms, round-tripping through pandas or polars, and writing the
result back to ``.net``.

The canonical Python model is explicit:

* :class:`halimede.network.Network` owns metadata, node data, link data, and
  SPD/CAP lookup tables.
* :class:`halimede.network.NodeTable` exposes structural ``N`` and ordered user
  fields.
* :class:`halimede.network.LinkTable` exposes structural ``A`` and ``B`` plus
  ordered user fields.

Four package-level conventions shape the entire API:

1. Structural columns are explicit properties rather than mapping keys.
2. User fields preserve their order exactly as loaded, declared, or imported.
3. ``run_id`` is exposed without the on-disk ``ID=`` prefix.
4. String widths are tracked in encoded UTF-8 bytes and inferred by default.

Usage
-----

.. code-block:: python

   import halimede

   info = halimede.inspect("network.net")
   network = info.load(node_fields=["X", "Y"], link_fields=["DIST", "SPEED"])

   print(network.banner, network.run_id)
   print(network.nodes.field_names)
   print(network.links.field_names)

   network.links["TIME"] = network.links["DIST"] / network.links["SPEED"] * 60.0
   network.nodes.remove_fields(["NAME"])

   network.write("network_updated.net")

Documentation Map
-----------------

Start with :doc:`quickstart`, then read :doc:`numpy_workflows` and
:doc:`tabular_workflows`. :doc:`inspection`, :doc:`performance`, and
:doc:`error_handling` cover selective loads, benchmark coverage, and validation
behaviour. :doc:`api/index` contains the full public Python API reference.

.. toctree::
   :hidden:
   :maxdepth: 2

   Home <self>
   quickstart
   inspection
   numpy_workflows
   tabular_workflows
   performance
   error_handling
   api/index
