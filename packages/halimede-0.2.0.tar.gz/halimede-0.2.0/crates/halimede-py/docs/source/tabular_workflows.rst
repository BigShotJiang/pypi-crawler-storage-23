Tabular Workflows
=================

Node and link tables have separate canonical DataFrame forms. Structural column
names are the on-disk names:

* node frames: ``N`` plus ordered user fields
* link frames: ``A``, ``B`` plus ordered user fields

The same conventions apply to pandas and polars interchange. Structural
columns are required, field order is preserved, and remaining columns map to
user fields.

Canonical Frame Shape
---------------------

In canonical form each frame carries one table kind only:

.. code-block:: text

   # Nodes
   N,X,Y,NAME

   # Links
   A,B,DIST,SPEED,RDTYPE

``N`` is always the structural node identifier. ``A`` and ``B`` are always the
structural link endpoints.

Export is explicit:

Export to pandas or polars either from the individual tables or as a canonical
``(node_frame, link_frame)`` pair from the network.

.. code-block:: python

   node_frame, link_frame = network.to_pandas_frames()
   node_frame_polars, link_frame_polars = network.to_polars_frames()

Import from pandas
------------------

Import is symmetric:

.. code-block:: python

   rebuilt = halimede.from_pandas(
       nodes=node_frame,
       links=link_frame,
       banner=network.banner,
       run_id=network.run_id,
   )

Import from polars
------------------

.. code-block:: python

   node_frame, link_frame = network.to_polars_frames()

   rebuilt = halimede.from_polars(
       nodes=node_frame,
       links=link_frame,
       banner=network.banner,
       run_id=network.run_id,
   )

When field specs are omitted, numeric columns become numeric fields and string
columns become string fields. Use explicit field specs when you need exact
string widths.

Explicit Field Specs
--------------------

Explicit specs are most useful for string fields whose on-disk width matters.

.. code-block:: python

   rebuilt = halimede.from_pandas(
       nodes=node_frame,
       links=link_frame,
       node_field_specs=[
           halimede.NodeFieldSpec.float64("X"),
           halimede.NodeFieldSpec.string("NAME", max_size=24),
       ],
   )

Lookup Tables Are Separate
--------------------------

SPD and CAP lookup tables are not part of the node/link dataframe interchange.
Pass them explicitly through ``speed_table=`` and ``capacity_table=`` when
constructing a network from dataframes.
