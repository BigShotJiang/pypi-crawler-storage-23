# halimede

Read, analyse, edit, and write `.net` binary network files from Python.

`halimede` exposes Voyager node and link data as eager NumPy-backed tables.
Rust is used only for strict `.net` parsing, validation, and serialisation. The
main Python API owns the in-memory editing surface, so field transforms happen
directly on NumPy arrays and DataFrame conversions stay explicit.

## Installation

```sh
uv add halimede
```

Optional extras for tabular workflows:

```sh
uv add "halimede[dataframe]"  # Pandas support.
uv add "halimede[polars]"     # Polars support.
```

## Requirements

- Python >= 3.9
- NumPy >= 1.23

## Quick start

### Inspect, then read a network

```python
import halimede

info = halimede.inspect("network.net")

print(info.node_field_names)
print(info.link_field_names)

network = info.load(node_fields=["X", "Y"], link_fields=["DIST", "SPEED"])

print(network.node_row_count)
print(network.link_row_count)
print(network.nodes.field_names)
print(network.links.field_names)
```

### Work with NumPy-backed tables

```python
# Structural columns are explicit properties.
node_ids = network.nodes.N
from_nodes = network.links.A
to_nodes = network.links.B

# User fields are NumPy-backed and mutate in place.
network.links["TIME"] = network.links["DIST"] / network.links["SPEED"] * 60.0
network.nodes["X"] *= 1.1

# Remove or retain user fields by name.
network.nodes.remove_fields(["NAME"])
network.links.retain_fields(["DIST", "TIME"])
```

### Create a network from scratch

```python
import numpy as np
import halimede

nodes = halimede.NodeTable(
    np.array([1, 2, 3], dtype=np.int32),
    {"X": np.array([100.0, 200.0, 300.0], dtype=np.float64)},
)
links = halimede.LinkTable(
    np.array([1, 2], dtype=np.int32),
    np.array([2, 3], dtype=np.int32),
    {"DIST": np.array([1.2, 0.8], dtype=np.float64)},
)

network = halimede.create(nodes, links, zones=1)
network.write("output.net")
```

### Serialise to bytes

```python
payload = network.to_bytes()
restored = halimede.from_bytes(payload)
```

## Tabular ingestion

Node and link tables are separate canonical frames. Structural column names are
kept as `N`, `A`, and `B` for round-trip clarity.

```python
nodes_df = ...
links_df = ...

rebuilt = halimede.from_pandas(
    nodes=nodes_df,
    links=links_df,
    banner=network.banner,
    run_id=network.run_id,
)

nodes_pl = ...
links_pl = ...

rebuilt_polars = halimede.from_polars(
    nodes=nodes_pl,
    links=links_pl,
    banner=network.banner,
    run_id=network.run_id,
)
```

Use `from_pandas()` and `from_polars()` when node and link data already exist
as separate frames. Unlike matrix-style wide tabular workflows, networks keep
nodes and links as distinct canonical tables.

## Export

```python
node_frame, link_frame = network.to_pandas_frames()
node_frame_polars, link_frame_polars = network.to_polars_frames()

network.write("output.net")
payload = network.to_bytes()
```

Export methods keep structural columns explicit as `N`, `A`, and `B`, and
preserve field order as loaded or declared.

## Benchmarks

The Python package includes a dedicated benchmark module for the main hot
paths: full parse, selective parse, serialise, pandas export, and selective
load/edit/write.

Install the benchmark group and run the benchmark module directly:

```sh
uv sync --group bench
.venv/bin/python -m pytest crates/halimede-py/tests/bench_performance.py --benchmark-only
```

## Part of the halimede workspace

This is the Python package. The workspace also includes:

- [`halimede`](https://crates.io/crates/halimede) — Rust library for `.net` files
- [`halimede-cli`](https://crates.io/crates/halimede-cli) — command-line tool
- [`halimede-duckdb`](https://github.com/MichaelByrneAU/halimede/tree/main/crates/halimede-duckdb) — DuckDB extension for reading `.net` files
- [GitHub repository](https://github.com/MichaelByrneAU/halimede)

## Licence

MIT OR Apache-2.0
