"""Tests for loki-reader-core."""
