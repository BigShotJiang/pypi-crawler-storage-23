from __future__ import annotations

from typing import cast

import pyrogram
from pyrogram import raw, utils


class SetAdministratorTitle:
    async def set_administrator_title(
        self: pyrogram.Client,
        chat_id: int | str,
        user_id: int | str,
        title: str,
    ) -> bool:
        """Set a custom title (rank) to an administrator of a supergroup.

        If you are an administrator of a supergroup (i.e. not the owner), you can only set the title of other
        administrators who have been promoted by you. If you are the owner, you can change every administrator's title.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            user_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target user.
                For a contact that exists in your Telegram address book you can use his phone number (str).
                You can also use user profile link in form of *t.me/<username>* (str).

            title (``str``, *optional*):
                A custom title that will be shown to all members instead of "Owner" or "Admin".
                Pass None or "" (empty string) to remove the custom title.

        Returns:
            ``bool``: True on success.

        Example:
            .. code-block:: python

                await app.set_administrator_title(chat_id, user_id, "Admin Title")
        """
        peer_chat_id = await self.resolve_peer(chat_id)
        peer_user_id = await self.resolve_peer(user_id)

        r = (
            await self.invoke(
                raw.functions.channels.GetParticipant(
                    channel=cast(
                        "raw.base.InputChannel",
                        utils.get_input_channel(peer_chat_id),
                    ),
                    participant=cast(
                        "raw.base.InputPeer", utils.get_input_peer(peer_user_id)
                    ),
                ),
            )
        ).participant

        if isinstance(r, raw.types.ChannelParticipantCreator):
            admin_rights = raw.types.ChatAdminRights()
        elif isinstance(r, raw.types.ChannelParticipantAdmin):
            admin_rights = r.admin_rights
        else:
            raise ValueError(
                "Custom titles can only be applied to owners or administrators of supergroups",
            )

        await self.invoke(
            raw.functions.channels.EditAdmin(
                channel=cast(
                    "raw.base.InputChannel", utils.get_input_channel(peer_chat_id)
                ),
                user_id=cast(
                    "raw.base.InputUser", utils.get_input_user(peer_user_id)
                ),
                admin_rights=admin_rights,
                rank=title,
            ),
        )

        return True
