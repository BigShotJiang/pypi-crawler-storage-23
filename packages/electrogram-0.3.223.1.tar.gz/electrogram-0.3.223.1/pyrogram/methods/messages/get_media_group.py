from __future__ import annotations

import logging

import pyrogram
from pyrogram import types

log = logging.getLogger(__name__)


class GetMediaGroup:
    async def get_media_group(
        self: pyrogram.Client,
        chat_id: int | str,
        message_id: int,
    ) -> list[types.Message]:
        """Get the media group a message belongs to.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                For your personal cloud (Saved Messages) you can simply use "me" or "self".
                For a contact that exists in your Telegram address book you can use his phone number (str).
                You can also use chat public link in form of *t.me/<username>* (str).

            message_id (``int``):
                The id of one of the messages that belong to the media group.

        Returns:
            List of :obj:`~pyrogram.types.Message`: On success, a list of messages of the media group is returned.

        Raises:
            ValueError:
                In case the passed message_id is negative or equal 0.
                In case target message doesn't belong to a media group.
        """

        if message_id <= 0:
            raise ValueError("Passed message_id is negative or equal to zero.")

        # Get messages with id from `id - 9` to `id + 10` to get all possible media group messages.
        messages = await self.get_messages(
            chat_id=chat_id,
            message_ids=list(range(message_id - 9, message_id + 10)),
            replies=0,
        )

        if not isinstance(messages, list):
            messages = [messages] if messages else []

        # There can be maximum 10 items in a media group.
        # If/else condition to fix the problem of getting correct `media_group_id` when `message_id` is less than 10.
        media_group_id = (
            messages[9].media_group_id
            if len(messages) == 19
            else messages[message_id - 1].media_group_id
        )

        if media_group_id is None:
            raise ValueError("The message doesn't belong to a media group")

        return types.List(
            msg for msg in messages if msg.media_group_id == media_group_id
        )
