from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from .bytes import Bytes

if TYPE_CHECKING:
    from io import BytesIO


class String(Bytes):
    @classmethod
    def read(cls, b: BytesIO, *args: Any) -> Any:  # noqa: ARG003
        return cast("bytes", super().read(b)).decode(
            errors="replace",
        )

    def __new__(cls, value: str) -> bytes:
        return super().__new__(cls, value.encode())
