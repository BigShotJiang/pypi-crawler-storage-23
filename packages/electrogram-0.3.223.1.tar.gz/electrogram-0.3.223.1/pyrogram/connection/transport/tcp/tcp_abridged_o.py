# ruff: noqa: ARG002
from __future__ import annotations

import logging
import os

import pyrogram
from pyrogram.crypto import aes

from .tcp import TCP, Proxy

log = logging.getLogger(__name__)


class TCPAbridgedO(TCP):
    RESERVED = (b"HEAD", b"POST", b"GET ", b"OPTI", b"\xee" * 4)

    def __init__(self, ipv6: bool, proxy: Proxy) -> None:
        super().__init__(ipv6, proxy)

        self.encrypt = None
        self.decrypt = None

    async def connect(self, address: tuple[str, int]) -> None:
        await super().connect(address)

        while True:
            nonce = bytearray(os.urandom(64))

            if (
                bytes([nonce[0]]) != b"\xef"
                and nonce[:4] not in self.RESERVED
                and nonce[4:8] != b"\x00" * 4
            ):
                nonce[56] = nonce[57] = nonce[58] = nonce[59] = 0xEF
                break

        temp = bytearray(nonce[55:7:-1])

        self.encrypt = (nonce[8:40], nonce[40:56], bytearray(1))
        self.decrypt = (temp[0:32], temp[32:48], bytearray(1))

        nonce[56:64] = aes.ctr256_encrypt(nonce, *self.encrypt)[56:64]

        await super().send(bytes(nonce))

    async def send(self, data: bytes, *args) -> None:
        length = len(data) // 4
        data = (
            bytes([length])
            if length <= 126
            else b"\x7f" + length.to_bytes(3, "little")
        ) + data

        if self.encrypt is None:
            raise ValueError("Transport not connected")

        payload = await self.loop.run_in_executor(
            pyrogram.crypto_executor,
            aes.ctr256_encrypt,
            data,
            *self.encrypt,
        )

        await super().send(payload)

    async def recv(self, length: int = 0) -> bytes | None:
        length_bytes = await super().recv(1)

        if length_bytes is None:
            return None

        if self.decrypt is None:
            raise ValueError("Transport not connected")

        length_bytes = aes.ctr256_decrypt(length_bytes, *self.decrypt)

        if length_bytes == b"\x7f":
            length_bytes = await super().recv(3)

            if length_bytes is None:
                return None

            length_bytes = aes.ctr256_decrypt(length_bytes, *self.decrypt)

        data = await super().recv(int.from_bytes(length_bytes, "little") * 4)

        if data is None:
            return None

        return await self.loop.run_in_executor(
            pyrogram.crypto_executor,
            aes.ctr256_decrypt,
            data,
            *self.decrypt,
        )
