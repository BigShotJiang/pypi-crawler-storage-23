from src.qargparse.tasks import TasksKwargs

def test_task_kwargs():
    tasks = TasksKwargs(tasks=[('run_1', {}), ('run_2', {})], defaults={'g': {'': 'B'}, 'a': {'': 'x', 'run_3': 'c', 'run_1': 'a'}, 'e': {'': 'A'}, 'b': {'': 0}})
    task = tasks[0]
    assert task.name == "run_1"
    assert task.kwargs == {'a': 'a'}
    assert task.defaults == {'g': {'': 'B'}, 'e': {'': 'A'}, 'b': {'': 0}}
    task = task.set_defaults(['g', 'b'])
    assert task.kwargs == {'a': 'a', 'g': 'B', 'b': 0}
    assert task.defaults == {}
    task = tasks[1]
    assert task.name == "run_2"
    assert task.kwargs == {}
    assert task.defaults == {'g': {'': 'B'}, 'a': {'': 'x', 'run_3': 'c', 'run_1': 'a'}, 'e': {'': 'A'}, 'b': {'': 0}}
    task = task.set_defaults(['g', 'b', 'a'], alias='run_3')
    assert task.name == "run_2"
    assert task.kwargs == {'g': 'B', 'a': 'c', 'b': 0}
    assert task.defaults == {}