from src.qargparse.type import (
    type_args,
    type_kwargs
)

def test_type_args():
    assert type_args('None') is None
    assert type_args('a') == 'a'
    assert type_args('1') == 1
    assert type_args('1.1') == 1.1
    assert type_args("['a', 1, 1.1]") == ['a', 1, 1.1]
    assert type_args("{'a': [1, 2], 'b': 'c'}") == {'a': [1, 2], 'b': 'c'}

def test_type_kwargs():
    assert type_kwargs("foo=None") == {'foo': None}
    assert type_kwargs("foo=a") == {'foo': 'a'}
    assert type_kwargs("foo=1") == {'foo': 1}
    assert type_kwargs("foo=1.1") == {'foo': 1.1}
    assert type_kwargs("foo=['a', 1, 1.1]") == {'foo': ['a', 1, 1.1]}
    assert type_kwargs("foo={'a': [1, 2], 'b': 'c'}") == {'foo': {'a': [1, 2], 'b': 'c'}}
