import pytest

from src.qargparse.parser import ArgumentParser

def test_add_argument():
    parser = ArgumentParser()
    parser.add_argument("--x")                     
    parser.add_argument("--a", action='q')         
    parser.add_argument("--b", action='q_true')
    parser.add_argument("--c", action='q', default='foo')
    parser.add_argument("--run_1", action='task')  
    parser.add_argument("--run_2", action='task')  

def test_add_arguments():
    parser_add_arguments = ArgumentParser()
    parser_add_arguments.add_arguments(
        verbose=True,
        regular=[
            ("--foo", dict(default="foo", help="Regular action.")),
            ("--bar", dict(default="bar", help="Regular action."))
        ],
        q_global=[
            ("--a", dict(default='x', help="Global queue action."), dict(run_1=dict(default='a'), run_2=dict(help="Custom global queue action help for run_2"), run_3=dict(default='c', help="--a parameter of run_3"))),
            ("--b", dict(default=0, help="Global queue action.")),
            ("--c", dict(action='q_true', help="Global queue action."))
        ],
        tasks={
            'run_1': [
                ("--d", dict(help="Run 1 specific action.")),
                ("--e", dict(default='A', help="Run 1 specific action."))
            ],
            'run_2': (
                [
                    ("--f", dict(help="Run 2 specific action.")),
                    ("--g", dict(default='B', help="Run 2 specific action."))
                ],
                dict(title="Custom title for Run 2.", description="Run 2 does a lots of things!")
            ),
            'run_3': (
                [],
                dict(title="Custom title for Run 3.", description="Run 3 have a default value for --a!")
            )
        }
    )
    parser = ArgumentParser()
    parser.add_argument("--foo", default="foo", help="Regular action.")
    parser.add_argument("--bar", default="bar", help="Regular action.")
    parser.add_argument("--a", default="x", help="Global queue action.", action="q")
    parser.add_argument("--b", default=0, help="Global queue action.", action="q")
    parser.add_argument("--c", action="q_true", help="Global queue action.")
    PARSER_TASK_RUN_1 = parser.add_argument_group(title="Run 1", description="Specific parameters of: run_1()")
    PARSER_TASK_RUN_1.add_argument("--d", help="Run 1 specific action.", action="q")
    PARSER_TASK_RUN_1.add_argument("--e", default="A", help="Run 1 specific action.", action="q")
    PARSER_TASK_RUN_1.add_argument("--a", default="a", action="q", alias="run_1")
    PARSER_TASK_RUN_1.add_argument("--run_1", dest="run_1", action="task", help="Launch 'run_1' task.")
    PARSER_TASK_RUN_2 = parser.add_argument_group(title="Custom title for Run 2.", description="Run 2 does a lots of things!")
    PARSER_TASK_RUN_2.add_argument("--f", help="Run 2 specific action.", action="q")
    PARSER_TASK_RUN_2.add_argument("--g", default="B", help="Run 2 specific action.", action="q")
    PARSER_TASK_RUN_2.add_argument("--a", help="Custom global queue action help for run_2", action="q", alias="run_2")
    PARSER_TASK_RUN_2.add_argument("--run_2", dest="run_2", action="task", help="Launch 'run_2' task.")
    PARSER_TASK_RUN_3 = parser.add_argument_group(title="Custom title for Run 3.", description="Run 3 have a default value for --a!")
    PARSER_TASK_RUN_3.add_argument("--a", default="c", help="--a parameter of run_3", action="q", alias="run_3")
    PARSER_TASK_RUN_3.add_argument("--run_3", dest="run_3", action="task", help="Launch 'run_3' task.")
    assert parser_add_arguments.format_help() == parser.format_help()

def test_parse_args():
    parser = ArgumentParser()
    parser.add_argument("--x")
    parser.add_argument("--a", action='q')
    parser.add_argument("--b", action='q_true')
    parser.add_argument("--c", action='q', default='foo')
    parser.add_argument("--run_1", action='task')
    parser.add_argument("--run_2", action='task')
    with pytest.raises(ValueError):
        opts, tasks = parser.parse_args([
            "--x", "foo", 
            "--a", "1", "--b", "--run_1", 
            "--a", "2", "--c", "bar", "--run_1", 
            "--b"])
    opts, tasks = parser.parse_args([
        "--x", "foo", 
        "--a", "1", "--b", "--run_1", 
        "--a", "2", "--c", "bar", "--run_1", 
        "--b", "--run_2"])
    assert vars(opts) == {'x': 'foo'}
    assert tasks.tasks == [('run_1', {'a': '1', 'b': True}), ('run_1', {'a': '2', 'c': 'bar'}), ('run_2', {'b': True})]
    assert tasks.defaults == {'c': {'': 'foo'}}

    parser = ArgumentParser()
    parser.add_argument("--a", action='q', default=1, help="Run 1 and 2 argument")
    parser.add_argument("--run_1", action='task')
    parser.add_argument("--run_2", action='task')
    opts, tasks = parser.parse_args(["--run_1", "--run_2"])
    assert vars(opts) == {}
    assert tasks.tasks == [('run_1', {}), ('run_2', {})]
    assert tasks.defaults == {'a': {'': 1}}

    parser = ArgumentParser()
    parser.add_argument("--global", action='q', default='foo', help="Global queue parameter")
    parser.add_argument("--a", action='q', default=1, help="Run 1 help", alias="run_1")
    parser.add_argument("--run_1", action='task')
    parser.add_argument("--a", action='q', default=2, help="Run 2 help", alias="run_2")
    parser.add_argument("--run_2", action='task')
    opts, tasks = parser.parse_args(["--run_1", "--run_2"])
    assert vars(opts) == {}
    assert tasks.tasks == [('run_1', {}), ('run_2', {})]
    assert tasks.defaults == {'a': {'run_1': 1, 'run_2': 2}, 'global': {'': 'foo'}}