from src.qargparse.utils import (
    merge_nested_dict,
    api_to_cli_template
)
from src.qargparse.opts.deduplication_strategy import DeduplicationStrategy

def test_merge_nested_dict():
    d1 = {'a': {'': 0, 'b': 1}, 'c': {'': 4}}
    d2 = {'a': {'d': 2, 'e': 3}, 'c': {'': 5, 'f': 6}}
    assert merge_nested_dict(d1, d2) == {'a': {'': 0, 'e': 3, 'b': 1, 'd': 2}, 'c': {'': 5, 'f': 6}}

def test_api_to_cli_template():
    import random
    assert api_to_cli_template(random, dedup_kwargs_strategy=DeduplicationStrategy.REGROUP.value) == "".join(open('tests/io/random.regroup.py', 'r'))
    assert api_to_cli_template(random, dedup_kwargs_strategy=DeduplicationStrategy.ALIAS.value) == "".join(open('tests/io/random.alias.py', 'r'))