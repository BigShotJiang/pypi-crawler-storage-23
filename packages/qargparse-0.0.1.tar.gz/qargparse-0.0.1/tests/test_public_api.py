import random

from src.qargparse.opts.deduplication_strategy import DeduplicationStrategy
from src.qargparse.public_api import (
    PublicAPI,
    get_methods
)

def test_get_methods():
    methods = get_methods(random)
    tot = len(methods)
    methods = get_methods(random, skip_methods=['randint', 'randrange'])
    assert len(methods) == tot - 2
    methods = get_methods(random, only_methods=['randint', 'randrange'])
    assert len(methods) == 2
    methods = get_methods(random, return_type=['int'])

def test_api_public():
    p = PublicAPI(random)
    s = p.to_cli_template(dedup_kwargs_strategy=DeduplicationStrategy.REGROUP.value)
    assert s == "".join(open('tests/io/random.regroup.py', 'r').readlines())
    s = p.to_cli_template(dedup_kwargs_strategy=DeduplicationStrategy.ALIAS.value)
    assert s == "".join(open('tests/io/random.alias.py', 'r').readlines())
