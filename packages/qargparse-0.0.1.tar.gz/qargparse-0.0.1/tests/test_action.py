import pytest
import argparse

from src.qargparse.action import (
    Queue,
    QueueTrue,
    QueueFalse,
    Task
)
from src.qargparse.env import (
    Q_KWARGS,
    Q_TASKS
)

def test_queue():
    namespace = argparse.Namespace()
    setattr(namespace, Q_KWARGS, {})
    q = Queue("--foo", "foo")
    q("parser", namespace, "bar")
    assert getattr(namespace, Q_KWARGS) == {'foo': 'bar'}

def test_queue_true_false():
    namespace = argparse.Namespace()
    setattr(namespace, Q_KWARGS, {})
    with pytest.raises(ValueError):
        q = QueueTrue("--foo", "foo", nargs=1)
    q = QueueTrue("--foo", "foo")
    with pytest.raises(ValueError):
        q("parser", namespace, 'bar')
    q("parser", namespace, None)
    assert getattr(namespace, Q_KWARGS) == {'foo': True}
    q = QueueFalse("--foo", "foo")
    q("parser", namespace, None)
    assert getattr(namespace, Q_KWARGS) == {'foo': False}

def test_task():
    namespace = argparse.Namespace()
    setattr(namespace, Q_KWARGS, {})
    setattr(namespace, Q_TASKS, [])
    q = Queue("--foo", "foo")
    task = Task("--task", "task")
    q("parser", namespace, "bar")
    task("parser", namespace, None)
    assert getattr(namespace, Q_KWARGS) == {}
    assert getattr(namespace, Q_TASKS) == [('task', {'foo': 'bar'})]

