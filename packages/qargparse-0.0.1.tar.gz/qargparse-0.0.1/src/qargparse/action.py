"""Queue-based argparse extensions for ordered task execution.

This module provides custom argparse actions that accumulate parsed
arguments into a shared queue dictionary and allow defining execution
boundaries via task actions.

It enables building command-line interfaces where arguments are grouped
and processed incrementally instead of being stored statically in a
namespace.
"""

import argparse
from abc import ABC, abstractmethod

from qargparse.env import (
    Q_KWARGS, 
    Q_TASKS,
)

class Queue(argparse.Action):
    """Argparse action that stores parsed arguments into a shared queue dictionary.

    This action writes each parsed argument value into a dictionary stored
    on the argparse namespace under the attribute defined by ``Q_KWARGS``.

    The destination name (``self.dest``) is used as the key and the parsed
    value is stored as the corresponding value.

    This action does not preserve call order. It overwrites previously stored
    values for the same destination key.
    """
    def __call__(self, parser, namespace, values, option_string=None):
        q_kwargs = getattr(namespace, Q_KWARGS)
        q_kwargs[self.dest] = values
        setattr(namespace, Q_KWARGS, q_kwargs)

class _QueueDeterministic(Queue, ABC):
    """Abstract base class for deterministic queue actions.

    This action enforces that the argument takes no values (``nargs=0``)
    and stores a predefined value in the queue dictionary.

    Subclasses must implement the ``_set_value`` method to define the 
    stored ``self._value`` value.

    Args:
        *args: Positional arguments forwarded to ``argparse.Action``.
        nargs (int, optional): Must be ``0``. Defaults to ``0``.
        **kwargs: Keyword arguments forwarded to ``argparse.Action``.

    Raises:
        ValueError: If ``nargs`` is not ``0``.
    """
    def __init__(self, *args, nargs=0, **kwargs):
        if nargs != 0:
            raise ValueError("Parameter 'nargs' must be 0!")
        super().__init__(*args, nargs=nargs, **kwargs)
        self._set_value()
    
    @abstractmethod
    def _set_value(self) -> None:
        pass

    @staticmethod
    def _check_values(values):
        if values:
            raise ValueError("Deterministic arguments can not have a value!")

    def __call__(self, parser, namespace, values, option_string=None):
        self._check_values(values)
        super().__call__(parser=parser, namespace=namespace, values=self._value, option_string=option_string)

class QueueTrue(_QueueDeterministic):
    """Boolean queue action that stores ``True``.

    This action behaves similarly to ``argparse``'s ``store_true`` action,
    but stores the value inside the shared queue dictionary defined by
    ``Q_KWARGS`` instead of directly on the namespace.
    """
    def _set_value(self) -> None:
        self._value = True

class QueueFalse(_QueueDeterministic):
    """Boolean queue action that stores ``False``.

    This action behaves similarly to ``argparse``'s ``store_false`` action,
    but stores the value inside the shared queue dictionary defined by
    ``Q_KWARGS`` instead of directly on the namespace.
    """
    def _set_value(self) -> None:
        self._value = False

class Task(_QueueDeterministic):
    """Special queue action that creates and registers a task boundary.

    This action treats the current queue state as a completed task.

    When invoked, it:

    - Creates a new task entry structured as:
       ``{task_name: collected_arguments}``.
    - Appends this task entry to the task list stored under ``Q_TASKS``.
    - Resets the queue dictionary to an empty state.

    This enables CLI patterns such as:

        tool.py --a foo --b bar --run --c baz --run

    Where each ``--run`` marks a boundary and triggers collection of
    the previously accumulated arguments as a separate task.
    """

    def _set_value(self) -> None:
        self._value = None

    def __call__(self, parser, namespace, values, option_string=None):
        self._check_values(values)
        setattr(namespace, Q_TASKS, getattr(namespace, Q_TASKS)+[(self.dest, getattr(namespace, Q_KWARGS))])
        setattr(namespace, Q_KWARGS, {})