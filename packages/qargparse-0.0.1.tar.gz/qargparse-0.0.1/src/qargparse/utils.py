from typing import List, Dict, Any, Union

from qargparse.env import (
    F_ADD_ARGUMENT,
    F_ADD_ARGUMENT_GROUP,
    F_ARGUMENTPARSER
)

def merge_nested_dict(d1: Dict, d2: Dict) -> Dict:
    """Deep-merge two dictionaries and return a new dictionary.

    The merge follows these rules:
        - Keys present in only one dictionary are copied as-is.
        - If both values are dictionaries, they are merged recursively.
        - Otherwise, the value from `d2` overrides the one from `d1`.

    Args:
        d1 (dict): Base dictionary.
        d2 (dict): Dictionary whose values take precedence.

    Returns:
        dict: A new dictionary containing the merged result.

    Notes:
        - The input dictionaries are not modified.
        - Only nested dictionaries are merged recursively; other
          types are overwritten.
    """
    result = {}

    keys = set(d1) | set(d2)

    for k in keys:
        v1 = d1.get(k)
        v2 = d2.get(k)

        if isinstance(v1, dict) and isinstance(v2, dict):
            result[k] = merge_nested_dict(v1, v2)
        elif k in d2:
            result[k] = v2
        else:
            result[k] = v1

    return result

def valid_cli_value(value: Any) -> bool:
    """Determine whether a value can be safely represented as a CLI argument.

    A value is considered valid if it is one of the supported
    primitive or container types.

    Args:
        value (Any): The value to validate.

    Returns:
        bool: True if the value is one of:
              (str, int, float, bool, list, dict),
              False otherwise.
    """
    return isinstance(value, (str, int, float, bool, list, dict))

def api_to_cli_template(
        cls: type, 
        skip_methods: List[str]=[],
        only_methods: List[str]=[],
        return_type: List[str]=[],
        output: str | None = None,
        **kwargs
        ) -> Union[None, str]:
    """Generate a CLI template from a class public API.

    This utility builds a CLI representation of a class by delegating
    to `PublicAPI.to_cli_template()`. The resulting template can either
    be returned as a string or written to a file.

    Args:
        cls (type): Target class to convert.
        skip_methods (list[str], optional): Methods to exclude.
        only_methods (list[str], optional): If provided, only these methods are included.
        return_type (list[str], optional): Filter methods by return type.
        output (str, optional): If provided, path to a file where the
                                generated template will be written.
        **kwargs: Additional arguments forwarded to `to_cli_template()`.

    Returns:
        str or None:
            - Returns the generated template if `output` is None.
            - Otherwise writes to file and returns None.

    Notes:
        - The file is overwritten if it already exists.
    """
    from qargparse.public_api import PublicAPI

    template = PublicAPI(
        cls=cls, 
        skip_methods=skip_methods, 
        only_methods=only_methods,
        return_type=return_type
    ).to_cli_template(**kwargs)

    if output is None:
        return template
    
    with open(output, 'w') as f:
        f.write(output)

def value_to_str(value: Any) -> str:
    """
    Convert a value to its CLI string representation.

    Strings are wrapped in double quotes. Other values
    are converted using `str()`.

    Args:
        value (Any): The value to convert.

    Returns:
        str: CLI-compatible string representation.
    """
    return f"\"{value}\"" if isinstance(value, str) else str(value)

def args_to_str(args: tuple) -> str:
    """
    Convert a sequence of positional arguments into a
    comma-separated CLI string representation.

    Args:
        args (Iterable[Any]): Positional arguments.

    Returns:
        str: Comma-separated string of formatted values.
    """
    return ", ".join([value_to_str(e) for e in args])

def kwargs_to_str(kwargs: Dict[str, Any]) -> str:
    """
    Convert keyword arguments into a CLI-style string representation.

    Each key-value pair is formatted as:
        key=value

    Values are converted using `value_to_str()`.

    Args:
        kwargs (dict): Keyword arguments.

    Returns:
        str: Comma-separated key=value string.
    """
    return ", ".join([f"""{k}={value_to_str(v)}""" for k, v in kwargs.items()])

def generate_add_argument(param_name: str, parser_name: str, prefix: str="", **kwargs) -> str:
    """
    Generate a formatted `add_argument` call string.

    Args:
        param_name (str): Parameter name.
        parser_name (str): Target parser variable name.
        prefix (str, optional): Prefix to prepend to the parameter name.
        **kwargs: Additional keyword arguments for the argument definition.

    Returns:
        str: Formatted string representing an `add_argument` call.
    """
    return F_ADD_ARGUMENT.format(parser_name, f"{prefix}{param_name}", kwargs_to_str(kwargs))

def generate_add_argument_group(parser_name: str, **kwargs) -> str:
    """
    Generate a formatted `add_argument_group` call string.

    Args:
        parser_name (str): Target parser variable name.
        **kwargs: Arguments forwarded to the group constructor.

    Returns:
        str: Formatted string representing an `add_argument_group` call.
    """
    return F_ADD_ARGUMENT_GROUP.format(parser_name, kwargs_to_str(kwargs))

def generate_argumentparser(parser_name: str, **kwargs) -> str:
    """
    Generate a formatted `ArgumentParser` constructor call string.

    Args:
        parser_name (str): Variable name for the parser.
        **kwargs: Keyword arguments for the parser constructor.

    Returns:
        str: Formatted string representing an `ArgumentParser` instantiation.
    """
    return F_ARGUMENTPARSER.format(parser_name, kwargs_to_str(kwargs))

def get_action(param) -> str:
    """
    Determine the appropriate queue action name for a parameter.

    Boolean parameters use specialized actions depending on their
    default value:
        - "q_true"  if default is True
        - "q_false" if default is False

    All other parameter types use the generic "q" action.

    Args:
        param: Parameter object (expected to have `annotation`
               and `default` attributes).

    Returns:
        str: Name of the action to use.
    """
    if param.annotation in ['bool', bool] :
        return "q_true" if param.default is True else "q_false"
    return "q"