import argparse
from ast import literal_eval
from typing import Dict, Any

def type_kwargs(string) -> Dict[str, Any]:
    """Parse a key=value string into a dictionary.

    This function converts a command-line argument of the form
    ``"key=value"`` into a dictionary ``{key: value}``.

    The value portion is first evaluated using ``ast.literal_eval``
    to allow Python literals such as integers, floats, lists, booleans,
    or dict. If evaluation fails, the value is returned as a stripped
    string.

    Example:
        "a=1"        -> {"a": 1}
        "b=True"     -> {"b": True}
        "c=[1, 2]"   -> {"c": [1, 2]}
        "d=hello"    -> {"d": "hello"}

    Args:
        string (str): Input string in ``key=value`` format.

    Returns:
        dict: A dictionary containing a single key-value pair.

    Raises:
        argparse.ArgumentTypeError: If the input string is not in
            ``key=value`` format.
    """
    try:
        key, value = string.split("=", 1)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Expected key=value format, got '{string}'"
        )
    return {key.strip(): type_args(value)}
    
def type_args(value: str) -> Any:
    """Eval a value string.

    This function converts a command-line argument of the form
    ``"value"`` into a auto-typed ``value``.

    The value is first evaluated using ``ast.literal_eval``
    to allow Python literals such as integers, floats, lists, booleans,
    or dict. If evaluation fails, the value is returned as a stripped
    string.

    Example:
        "1"        -> 1
        "True"     -> True
        "[1, 2]"   -> [1, 2]
        "hello"    -> "hello"

    Args:
        string (str): Input string in ``value`` format.

    Returns:
        Any: the auto-typed value.
    """
    try:
        return literal_eval(value)
    except:  # noqa: E722
        return value.strip()