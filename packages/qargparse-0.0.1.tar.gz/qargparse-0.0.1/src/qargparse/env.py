"""Internal constants used across qargparse.

This module centralizes string literals and template definitions used
for:

- Internal namespace bookkeeping
- Custom argparse action names
- Argument type identifiers
- CLI template string formatting
- Deduplication strategy values

Centralizing these constants ensures consistency across modules and
avoids hardcoded string duplication throughout the codebase.
"""

# Internal namespace keys used during parsing
Q_KWARGS = '_q_kwargs'
Q_TASKS = '_q_tasks'

# Registered custom argparse action names
ACTION_Q = "q"
ACTION_Q_TRUE = "q_true"
ACTION_Q_FALSE = "q_false"
ACTION_TASK = "task"
Q_ACTIONS = [ACTION_Q, ACTION_Q_TRUE, ACTION_Q_FALSE]

# Custom logical argument type identifiers
TYPE_ARGS = "args"
TYPE_KWARGS = "kwargs"

# Reserved parameter names for signature inspection
ARGS = "args"
KWARGS = "kwargs"

# Template variable names used in generated CLI code
PARSER_DEFAULT = "parser"
F_PARSER_TASK = "PARSER_TASK_{}"

# CLI template string builders
F_ARGUMENTPARSER = """{} = qargparse.ArgumentParser({})"""
F_ADD_ARGUMENT = "{} = " + PARSER_DEFAULT + """.add_argument("{}", {})"""
F_ADD_ARGUMENT_GROUP = "{} = " + PARSER_DEFAULT + """.add_argument_group({})"""

# Deduplication strategy identifiers
DEDUP_STRAT_REGROUP = "regroup"
DEDUP_STRAT_ALIAS = "alias"

# Alias pattern
F_ALIAS_PREFIX = "-ALIAS_'{}'_OF:"

# Template
TEMPLATE = "# TEMPLATE: the following is a template, investigate/update it!"
