"""Public API reflection layer for qargparse.

This module provides utilities to transform a Python class API into a
qargparse-compatible CLI template.

It inspects public methods, extracts their signatures and docstrings,
and generates a Python template file that configures a qargparse
ArgumentParser capable of dispatching tasks to the corresponding methods.

The generated CLI supports:
- Automatic argument generation from method parameters
- Optional parameter deduplication strategies
- Docstring-based help text extraction
- Task-based execution mapping
"""

import inspect
from typing import List, Dict, Tuple
from collections import defaultdict
from griffe import Docstring
from dataclasses import asdict

from qargparse.env import (
    ARGS,
    KWARGS,
    ACTION_Q,
    ACTION_TASK,
    TYPE_ARGS,
    TYPE_KWARGS,
    F_PARSER_TASK,
    PARSER_DEFAULT,
    TEMPLATE
)

from qargparse.utils import (
    get_action,
    generate_add_argument,
    generate_add_argument_group,
    generate_argumentparser,
    valid_cli_value
)

from qargparse.opts.to_cli_template import ToCliTemplateOpts

from qargparse.opts.deduplication_strategy import DeduplicationStrategy

class PublicAPI:
    """Reflect a Python class into a qargparse CLI template.

    This class inspects the public methods of a target class and generates
    a Python template string that builds a configured qargparse-based CLI.

    It supports filtering methods, handling duplicated parameters across
    methods, and injecting docstring-derived help messages.

    Args:
        cls (type): The class to inspect and convert into a CLI template.
        skip_methods (List[str], optional): Method names to exclude from
            CLI generation. Defaults to an empty list.
        only_methods (List[str], optional): If provided, only these methods
            are included. Defaults to an empty list.
        return_type (List[str], optional): Optional list of return type
            strings used to filter methods by annotation. Defaults to empty.

    Raises:
        ValueError: If both ``skip_methods`` and ``only_methods`` are set.
    """

    def __init__(self, 
                 cls: type, 
                 skip_methods: List[str]=[],
                 only_methods: List[str]=[],
                 return_type: List[str]=[]):
        if skip_methods and only_methods:
            raise ValueError("Can not set both skip_methods and only_methods!")
        self.cls: type = cls
        self.methods = get_methods(self.cls, skip_methods, only_methods, return_type)

    def __getitem__(self, i):
        """Return a wrapped method by index.

        Args:
            i (int): Index of the method.

        Returns:
            Method: A Method wrapper instance.
        """
        return Method(self.methods[i])
    
    @property
    def is_module(self):
        return "__module__" in dir(self.cls)
    
    def to_cli_template(self, 
                        parser_kwargs: Dict | None = None,
                        **kwargs):
        """Generate a full Python CLI template string.

        This method builds a ready-to-use Python script template that:
        - Creates a qargparse.ArgumentParser
        - Adds arguments derived from class methods
        - Configures deduplication strategies
        - Generates task dispatch logic

        Args:
            parser_kwargs (Dict, optional): Keyword arguments forwarded to
                the generated ArgumentParser constructor.
            **kwargs: Additional options forwarded to ToCliTemplateOpts.

        Returns:
            str: A formatted Python script template as a single string.
        """

        self_is_module = self.is_module
        
        opts = ToCliTemplateOpts(**kwargs)

        if parser_kwargs is None:
            parser_kwargs = {}

        # Load argumentParser obj and args/kwargs arguments
        argparse = [
            TEMPLATE,
            f"{f"from {self.cls.__module__} " if self_is_module else ""}import {self.cls.__name__}",
            "import qargparse",
            "",
            generate_argumentparser(parser_name=PARSER_DEFAULT, **parser_kwargs), 
            "",
            "# Regular argparse arguments",
            "## Add regular argparse arguments here",
            "",
            "# Global queue arguments",
            generate_add_argument(
                param_name=ARGS, 
                parser_name=PARSER_DEFAULT, 
                dest=ARGS, 
                action=ACTION_Q, 
                nargs="*", 
                dtype=TYPE_ARGS
            ), 
            generate_add_argument(
                param_name=KWARGS, 
                parser_name=PARSER_DEFAULT, 
                dest=KWARGS, 
                prefix=opts.param_prefix, 
                action=ACTION_Q, 
                nargs="*", 
                dtype=TYPE_KWARGS
            )
        ]

        # Set parameters for deduplication strategy
        opts = opts.set_skipped_and_uniquize_params(self)

        # Load skipped parameters
        for param_name in opts.skip_params:
            fct = self.parameters[param_name][0]
            param = fct.parameters[param_name]
            d_param_to_doc = fct.get_doc_params()
            param_default_dict = get_param_default_dict(param) if opts.param_default else {}
            argparse.append(
                generate_add_argument(
                    param_name=param_name, 
                    parser_name=PARSER_DEFAULT, 
                    prefix=opts.param_prefix, 
                    dest=param_name, 
                    action=get_action(param), 
                    dtype=TYPE_ARGS, 
                    **param_default_dict,
                    help=generate_add_argument_help(
                        param, 
                        d_param_to_doc, 
                        from_method=fct.fct.__name__, 
                        desc=opts.param_desc
                    )
                )
            )

        # Load arguments
        argparse.append("")
        argparse.append("# Method-specific queue arguments & tasks")
        for method in self:
            argparse.append(method.to_cli_template(**asdict(opts)))
            argparse.append("")

        # Parse parser
        argparse.append("")
        argparse.append("# Parse the command-line")
        argparse.append("opts, tasks = parser.parse_args()")

        # Regular argparse argument processing
        argparse.append("")
        if self_is_module:
            argparse.append(TEMPLATE)
            argparse.append(f"obj = {self.cls.__name__}(...) # Create your instance")
            argparse.append("")
        argparse.append("# Regular argparse argument processing")
        argparse.append("## Add your regular argparse processing here")

        # Loop on tasks
        SEP = "    "
        argparse.append("")
        argparse.append("# Tasks processing")
        argparse.append("for task in tasks:")
        argparse.append(f"{SEP}")
        argparse.append(f"{SEP}match task.name:")
        for task in self:
            task_name = task.fct.__name__
            argparse.append(f"{SEP*2}")
            argparse.append(f"{SEP*2}case \"{task_name}\":")
            argparse.append(f"{SEP*3}{TEMPLATE}")
            if opts.dedup_kwargs_strategy == DeduplicationStrategy.REGROUP:
                argparse.append(f"{SEP*3}# task = task.set_defaults(params=...) # You may want to set some default parameters")
            if self_is_module:
                argparse.append(f"{SEP*3}obj = obj.{task_name}(**task.kwargs)")
            else:
                argparse.append(f"{SEP*3}result = {self.cls.__name__}.{task_name}(**task.kwargs)")

        return "\n".join(argparse)
    
    @property
    def parameters(self) -> Dict[str, List['Method']]:
        """Map parameter names to methods that use them.

        Returns:
            Dict[str, List[Method]]: A dictionary where keys are parameter
            names and values are lists of Method instances that declare
            those parameters.
        """
        d = defaultdict(list)
        for method in self:
            d.update({param.name: d[param.name] + [method] for param in method})
        return d

class Method:
    """Wrapper around a callable for CLI generation.

    This class provides utilities to inspect a method's signature,
    extract parameters (excluding ``self``), parse docstrings, and
    generate qargparse-compatible argument definitions.

    Args:
        fct (callable): The function or method to wrap.
    """
    def __init__(self, fct: callable):
        self.fct = fct
        self.parameters: Dict[str, inspect.Parameter] = {k: v for k, v in self.signature.parameters.items() if k != 'self'}

    def __str__(self):
        return str(self.fct)
    
    @property
    def signature(self) -> inspect.Signature:
        """Return the inspect.Signature of the wrapped function.

        Returns:
            inspect.Signature: The function signature. If inspection fails,
            an empty signature is returned.
        """
        try:
            return inspect.signature(self.fct)
        except ValueError:
            return inspect.Signature()
    
    def __len__(self):
        return len(self.parameters)
    
    def __getitem__(self, key) -> inspect.Parameter:
        self.parameters[key]
        
    def __iter__(self):
        return iter(self.parameters.values())

    def to_cli_template(self, **kwargs) -> str:
        """Generate CLI template lines for this method.

        Builds argument definitions corresponding to the method parameters
        and appends a task-dispatch argument.

        Args:
            **kwargs: Options forwarded to ToCliTemplateOpts controlling:
                - Group creation
                - Parameter deduplication
                - Help text formatting
                - Prefix customization

        Returns:
            str: Multiline string defining CLI arguments for this method.
        """
        
        opts = ToCliTemplateOpts(**kwargs)

        argparse = []

        uniquize_params = [] if opts.uniquize_params is None else opts.uniquize_params

        # Identify parameters to skip
        skip_params = [] if opts.skip_params is None else [param for param in opts.skip_params if param in self.parameters.keys()]

        # Make the help message for skipped params
        help_skip_params_msg = ""
        fct_name = self.fct.__name__
        if opts.help_skip_params and skip_params:
            help_skip_params_msg = "Additional parameters: {}".format(", ".join([f"--{e}" for e in skip_params]))

        # Create an argument group if requested
        if opts.make_grp:
            parser_name = F_PARSER_TASK.format(fct_name.upper())
            add_argument_group_opt = " ".join(fct_name.capitalize().split("_"))
            argparse.append(
                generate_add_argument_group(
                    parser_name, 
                    title=add_argument_group_opt, 
                    description=help_skip_params_msg if opts.help_skip_params else ""
                )
            )
        else:
            parser_name = PARSER_DEFAULT

        # Get parameters doc
        d_param_to_doc = self.get_doc_params()

        # Load parameters
        for param in self:
            if param.name not in skip_params:
                if param.kind in [inspect.Parameter.KEYWORD_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD]:
                    alias_dict = dict(alias=fct_name) if param.name in uniquize_params else {}
                    param_default_dict = get_param_default_dict(param) if opts.param_default else {}
                    argparse.append(
                        generate_add_argument(
                            param_name=param.name, 
                            parser_name=parser_name, 
                            prefix=opts.param_prefix, 
                            dest=param.name, 
                            action=get_action(param), 
                            dtype=TYPE_ARGS, 
                            **param_default_dict,
                            help=generate_add_argument_help(
                                param=param, 
                                d_param_to_doc=d_param_to_doc, 
                                desc=opts.param_desc
                            ),
                            **alias_dict
                        )
                    )
        help = f"Launch '{fct_name}' task{": " + self.get_doc_header().split("\n")[0].rstrip(".")}."
        if opts.help_skip_params and not opts.make_grp:
            help += f" {help_skip_params_msg}."
        help += f" ({str(self.signature.return_annotation)})"
        argparse.append(
            generate_add_argument(
                param_name=fct_name, 
                parser_name=parser_name, 
                prefix=opts.param_prefix, 
                dest=fct_name, 
                action=ACTION_TASK, 
                help=help
            )
        )
        return "\n".join(argparse)
    
    def get_doc(self) -> str:
        """Return the raw docstring of the wrapped function.

        Returns:
            str: The function docstring, or an empty string if none exists.
        """
        doc = inspect.getdoc(self.fct)
        return "" if doc is None else doc
    
    def get_parsed_docstring(self, parser="auto", **kwargs) -> List:
        """Parse the function docstring using griffe.

        Args:
            parser (str, optional): Parsing style ("auto", "google",
                "numpy", etc.). Defaults to "auto".
            **kwargs: Additional keyword arguments passed to Docstring.parse().

        Returns:
            List: Parsed docstring sections.
        """
        return Docstring(self.get_doc()).parse(parser=parser, **kwargs)
    
    def get_doc_header(self, **kwargs) -> str:
        """Extract the main description header from the docstring.

        Returns:
            str: The first free-text section of the docstring.
        """
        l_ds = self.get_parsed_docstring(**kwargs)
        for ds in l_ds:
            if ds.kind == 'text':
                return ds.value
        return ""


    def get_doc_params(self, **kwargs) -> Dict[str, Tuple[str, str]]:
        """Extract parameter documentation from the docstring.

        Returns:
            Dict[str, Tuple[str, str]]: Mapping of parameter names to
            (annotation, description) tuples.
        """
        d_param_to_doc = {}
        l_ds = self.get_parsed_docstring(**kwargs)
        for ds in l_ds:
            if ds.kind == 'parameters':
                params = ds.value
                for param in params:
                    d_param_to_doc[param.name] = (str(param.annotation), str(param.description))
                return d_param_to_doc
        return {}
            


def get_methods(cls: type, skip_methods=[], only_methods=[], return_type=[]) -> List[callable]:
    """Return filtered public methods from a class.

    Methods are filtered based on:
    - Exclusion list
    - Inclusion list
    - Optional return type matching

    Args:
        cls (type): Class to inspect.
        skip_methods (List[str], optional): Method names to exclude.
        only_methods (List[str], optional): If provided, only these are included.
        return_type (List[str], optional): Filter methods by return annotation.

    Returns:
        List[callable]: Sorted list of matching methods.
    """
    return_type = [str(e) for e in return_type]
    if any(e in return_type for e in ['None']):
        return_type.append("'inspect._empty'>")
    return sorted({method for name, method in inspect.getmembers(cls) if (inspect.isfunction(method) or inspect.ismethod(method)) and ((name in only_methods) or (not only_methods and not name.startswith('_') and name not in skip_methods and (not return_type or any(e in str(inspect.signature(method).return_annotation).split() for e in return_type))))}, key=lambda x: x.__name__)

def generate_add_argument_help(
        param, 
        d_param_to_doc, 
        from_method: str="", 
        desc: bool=True
    ):
    """Generate help text for a CLI argument.

    Constructs help text using:
    - Docstring parameter description
    - Type annotation
    - Required flag
    - Optional alias information
    - Method origin (for deduplicated parameters)

    Args:
        param (inspect.Parameter): The parameter object.
        d_param_to_doc (Dict): Mapping of parameter names to doc info.
        from_method (str, optional): Name of originating method.
        desc (bool, optional): Whether to include description text.

    Returns:
        str: Formatted help string.
    """
    have_param = param.name in d_param_to_doc
    return "".join([
        "Required. " if param.default is inspect.Parameter.empty else "",
        f"{d_param_to_doc[param.name][1].replace("\n", r"\n").replace("\"", r"\\\"")} " if have_param and desc else "",
        f"({d_param_to_doc[param.name][0].replace("\n", r"\n").replace("\"", r"\\\"")}) " if have_param else "",
        f"(from method: \'{from_method}\')" if from_method else ""
    ])

def get_param_default_dict(param):
    param_default = param.default
    if not valid_cli_value(param_default):
        return {}
    if isinstance(param_default, str):
        param_default = param_default.replace("\n", r"\n").replace("\"", r"\\\"")
    return dict(default=param_default)