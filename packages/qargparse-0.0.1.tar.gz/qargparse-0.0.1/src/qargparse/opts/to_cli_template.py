"""Configuration options for qargparse CLI template generation.

This module defines the immutable configuration object used when
generating CLI templates from a reflected public API.

The ToCliTemplateOpts dataclass centralizes all customization flags
that control how parameters are rendered into CLI arguments, including:

- Argument grouping behavior
- Parameter deduplication strategies
- Help message formatting
- Parameter skipping or uniquification rules

The object is frozen and uses structural replacement (dataclasses.replace)
to safely derive modified configurations.
"""

from pydantic.dataclasses import dataclass
from dataclasses import field, replace
from typing import (
    List
)

from qargparse.env import (
    ARGS,
    KWARGS,
)
from qargparse.opts.deduplication_strategy import DeduplicationStrategy

@dataclass(frozen=True, slots=True, kw_only=True)
class ToCliTemplateOpts:
    """Options controlling CLI template generation.

    This immutable configuration object defines how a PublicAPI
    instance is translated into qargparse argument definitions.

    Attributes:
        make_grp (bool):
            Whether to create argument groups per method in the
            generated CLI template.

        dedup_kwargs_strategy (DeduplicationStrategy):
            Strategy used when multiple methods share parameters.
            Determines whether parameters are aliased or regrouped.

        n_min_dedup (int)
            Minimum number of duplicated parameters ti regroup
            them if DeduplicationStrategy is REGROUP (default: 2)

        param_prefix (str):
            Prefix used for named CLI parameters (e.g., "--").

        param_desc (bool):
            Whether to include parameter descriptions in help messages.

        param_default (bool):
            Whether to include parameter default value, if any.
            WARNING: with REGROUP dedup strategy, the default value may
            not correspond to the expected on!

        skip_params (List[str]):
            Parameter names to skip during CLI generation.

        uniquize_params (List[str]):
            Parameter names that must be uniquified when shared
            across multiple methods.

        help_skip_params (bool):
            Whether skipped parameters should still appear in help output.

    Raises:
        TypeError: If any attribute has an invalid type.
    """
    make_grp: bool = field(default=True)
    dedup_kwargs_strategy: DeduplicationStrategy = field(default=DeduplicationStrategy.ALIAS)
    n_min_dedup: int = field(default=2)
    param_prefix: str = field(default="--")
    param_desc: bool = field(default=True)
    param_default: bool = field(default=True)
    skip_params: List[str] = field(default_factory=list)
    uniquize_params: List[str] = field(default_factory=list)
    help_skip_params: bool = field(default=True)
        
    def set_skipped_and_uniquize_params(self, public_api: 'PublicAPI'):  # type: ignore # noqa: F821
        """Compute deduplicated parameter handling rules.

        Determines which parameters should be skipped or uniquified
        based on the selected deduplication strategy and the
        parameters exposed by the provided PublicAPI.

        Duplicate parameters are defined as parameters shared by more
        than one method, excluding special ARGS and KWARGS entries.

        Args:
            public_api (PublicAPI):
                The reflected API containing parameter metadata.

        Returns:
            ToCliTemplateOpts:
                A new configuration instance with updated
                ``skip_params`` and ``uniquize_params`` fields,
                derived using dataclasses.replace().

        Raises:
            ValueError: If the deduplication strategy is unsupported.
        """
        d_param = public_api.parameters
        dup_params = []
        uniquize_params = []
        for k, v in d_param.items():
            if k not in [ARGS, KWARGS]:
                if len(v) > 1:
                    if len(v) >= self.n_min_dedup:
                        dup_params.append(k)
                    else:
                        uniquize_params.append(k)
        match self.dedup_kwargs_strategy:
            case DeduplicationStrategy.REGROUP:
                skip_params = self.skip_params + dup_params
                uniquize_params = self.uniquize_params + uniquize_params
            case DeduplicationStrategy.ALIAS:
                skip_params = self.skip_params
                uniquize_params = self.uniquize_params + dup_params + uniquize_params  
        return replace(self, skip_params=skip_params, uniquize_params=uniquize_params)
