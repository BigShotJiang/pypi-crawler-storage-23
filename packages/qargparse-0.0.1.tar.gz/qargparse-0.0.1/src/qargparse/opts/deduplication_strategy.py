"""Deduplication strategies for shared CLI parameters.

This module defines the available strategies used when multiple API
methods expose parameters with the same name.

These strategies control how qargparse resolves naming conflicts
during CLI template generation.
"""

from enum import Enum

from qargparse.env import (
    DEDUP_STRAT_REGROUP,
    DEDUP_STRAT_ALIAS
)

class DeduplicationStrategy(Enum):
    """Strategies for handling duplicated parameters across methods.

    When multiple methods share parameters with the same name,
    a deduplication strategy determines how those parameters
    are represented in the generated CLI.

    Attributes:
        REGROUP (str):
            Shared parameters are regrouped and defined once.
            Methods reuse the same CLI argument.

        ALIAS (str):
            Shared parameters are duplicated and uniquified
            (e.g., prefixed with the method name).
    """
    REGROUP: str = DEDUP_STRAT_REGROUP
    ALIAS: str = DEDUP_STRAT_ALIAS
