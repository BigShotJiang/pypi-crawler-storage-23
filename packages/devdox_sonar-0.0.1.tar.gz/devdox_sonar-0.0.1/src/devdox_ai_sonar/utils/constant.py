SWITCH_COMMAND_TRIGGER = "/"
BOLD_MAGENTA = "bold magenta"
BOLD_PURPLE = "fg:#673ab7 bold"
AUTHENTICATION_NOT_FOUND = "[red]❌ No authentication configuration found[/red]"
DEVDOX_SONAR_CONFIG = (
    "[yellow]💡 Run 'devdox_sonar_config' to configure authentication[/yellow]"
)
NO_BRANCH_OR_PR_SPECIFIED = "[red]❌ No branch or pull request specified[/red]"
AUTH_CONFIG_LOADED = "[green]✓[/green] Authentication config loaded"
CONFIGURATION_APPLY = "configuration.apply"
CONFIGURATION_BACKUP = "configuration.create_backup"
SKIPPED = "Skipped"
SWITCH_COMMANDS = "↩Switching commands.."
FETCHING_ISSUES = "Fetching issues..."
RETURN_TO_MAIN_MENU = "Return to main menu?"
EXCLUDE_NONE = "NONE"
EXCLUDE_RULES_EMPTY_ERROR = (
    "[red]✖ Please enter valid comma-separated rules or 'NONE'.[/red]"
)
