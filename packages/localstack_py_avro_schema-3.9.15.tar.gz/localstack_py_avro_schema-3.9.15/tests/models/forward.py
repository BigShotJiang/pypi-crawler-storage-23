from __future__ import annotations

Name = str


class PyClass:
    """For testing imports with future annotations"""

    name: Name
