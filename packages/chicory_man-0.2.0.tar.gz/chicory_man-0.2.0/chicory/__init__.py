"""Chicory: Dual-tracking memory architecture for LLMs."""

__version__ = "0.2.0"
