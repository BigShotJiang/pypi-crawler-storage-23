"""Cross-project commons layer for Chicory."""
