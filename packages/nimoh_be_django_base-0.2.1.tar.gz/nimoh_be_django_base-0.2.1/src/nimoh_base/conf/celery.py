"""
nimoh_base.conf.celery
======================
Celery app factory for nimoh-be-django-base consumers.

Usage in a consumer project's ``celery.py``::

    import os
    from nimoh_base.conf.celery import make_celery

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.development')

    app = make_celery()

    if __name__ == '__main__':
        app.start()
"""

import os


def make_celery(settings_module: str | None = None) -> "Celery":  # noqa: F821
    """
    Create and configure a Celery application instance.

    The app name is read from ``settings.NIMOH_BASE['CELERY_APP_NAME']``
    (with ``os.environ.get('CELERY_APP_NAME', 'django-app')`` as fallback
    before Django settings are available).

    Args:
        settings_module: Django settings module path. When ``None``, falls
                         back to the ``DJANGO_SETTINGS_MODULE`` env variable.

    Returns:
        A fully configured Celery ``app`` instance.
    """
    from celery import Celery

    if settings_module:
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", settings_module)

    # Name is resolved from env first (before Django loads), then from settings
    app_name = os.environ.get("CELERY_APP_NAME", "django-app")

    app = Celery(app_name)
    app.config_from_object("django.conf:settings", namespace="CELERY")
    app.autodiscover_tasks()

    @app.task(bind=True, ignore_result=True)
    def debug_task(self):
        """Built-in debug task — call with: ``celery -A app.celery debug_task.delay()``"""
        print(f"Request: {self.request!r}")

    return app
