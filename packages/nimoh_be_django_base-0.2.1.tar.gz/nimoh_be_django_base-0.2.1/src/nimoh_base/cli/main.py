"""
nimoh_base.cli.main
====================
Click entry-point for the ``nimoh-base`` command-line tool.

Commands
--------
``nimoh-base init``
    Interactive (or ``--no-input`` / ``--config config.yml``) project scaffolding.

``nimoh-base check``
    Validate a project's NIMOH_BASE settings against current package requirements.

``nimoh-base config-template``
    Print/write a documented YAML config template for use with ``--config``.

Install
-------
    pip install "nimoh-be-django-base[cli]"

Then run::

    nimoh-base --help
"""

from __future__ import annotations

import sys
from pathlib import Path


def _require_cli_deps() -> None:
    """Raise a friendly ImportError if Click/questionary are not installed."""
    try:
        import click  # noqa: F401
    except ImportError as exc:
        print(
            "\nERROR: CLI extras are not installed.\nInstall them with:  pip install 'nimoh-be-django-base[cli]'\n",
            file=sys.stderr,
        )
        raise SystemExit(1) from exc


_require_cli_deps()

import click  # noqa: E402 — only reached if click is installed


@click.group()
@click.version_option(package_name="nimoh-be-django-base", prog_name="nimoh-base")
def cli() -> None:
    """nimoh-base — scaffold and verify Django projects powered by nimoh-be-django-base."""


# ── nimoh-base init ───────────────────────────────────────────────────────────


@cli.command("init")
@click.option(
    "--config",
    "config_file",
    type=click.Path(exists=True, file_okay=True, dir_okay=False, path_type=Path),
    default=None,
    help="Path to a YAML config file. Skips interactive prompts.",
)
@click.option(
    "--no-input",
    is_flag=True,
    default=False,
    help="Use --config file only; never prompt. Requires --config.",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Directory where the project folder is created (default: current dir).",
)
def init_command(config_file: Path | None, no_input: bool, output_dir: Path | None) -> None:
    """
    Scaffold a new Django project powered by nimoh-be-django-base.

    By default, launches an interactive questionary wizard.
    Pass --config config.yml to skip prompts.
    """
    try:
        from rich.console import Console

        console = Console()
    except ImportError:
        console = None  # type: ignore[assignment]

    # ── Load config from file ──────────────────────────────────────────────
    cfg = None
    if config_file is not None:
        from nimoh_base.cli.config import load_config

        try:
            cfg = load_config(config_file)
        except (FileNotFoundError, ValueError) as exc:
            click.echo(f"ERROR: {exc}", err=True)
            raise SystemExit(1)

    if no_input and cfg is None:
        click.echo(
            "ERROR: --no-input requires --config <file.yml>. Either supply a config file or remove --no-input.",
            err=True,
        )
        raise SystemExit(1)

    # ── Interactive prompts (unless --no-input) ────────────────────────────
    if not no_input:
        from nimoh_base.cli.prompts import run_prompts

        cfg = run_prompts(defaults=cfg)

    if cfg is None:
        click.echo("ERROR: no project configuration available.", err=True)
        raise SystemExit(1)

    # Override output dir if passed on CLI
    if output_dir is not None:
        cfg.output_dir = str(output_dir)

    # ── Generate project ───────────────────────────────────────────────────
    from nimoh_base.cli.generators import render_project

    try:
        project_root = render_project(cfg)
    except Exception as exc:
        click.echo(f"ERROR generating project: {exc}", err=True)
        raise SystemExit(1)

    if console:
        from rich.panel import Panel

        console.print()
        console.print(
            Panel.fit(
                f"[bold green]✓  Project created:[/bold green] [cyan]{project_root}[/cyan]\n\n"
                f"Next steps:\n"
                f"  cd {project_root.name}\n"
                f"  python -m venv venv && source venv/bin/activate\n"
                f"  pip install -r requirements.txt\n"
                f"  cp .env.example .env   # then fill in secrets\n"
                f"  python manage.py migrate\n"
                f"  python manage.py createsuperuser\n"
                f"  python manage.py runserver",
                border_style="green",
                title="Done!",
            )
        )
    else:
        click.echo(f"\n✓  Project created: {project_root}")
        click.echo(f"  cd {project_root.name}")
        click.echo("  pip install -r requirements.txt")
        click.echo("  python manage.py migrate")


# ── nimoh-base check ──────────────────────────────────────────────────────────


@cli.command("check")
@click.option(
    "--settings",
    "settings_module",
    required=True,
    help="Dotted import path to the settings module (e.g. myapp.config.settings.base).",
)
@click.option(
    "--project-root",
    "-r",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project root to prepend to sys.path before importing settings.",
)
def check_command(settings_module: str, project_root: Path | None) -> None:
    """
    Validate NIMOH_BASE settings in an existing project.

    Exits with code 1 if required keys are missing or AUTH_USER_MODEL is wrong.

    Example::

        nimoh-base check --settings myproject.config.settings.base --project-root .
    """
    from nimoh_base.cli.checks import print_check_results, run_checks

    result = run_checks(settings_module, project_root=project_root)
    print_check_results(result)

    if not result.passed:
        raise SystemExit(1)


# ── nimoh-base config-template ────────────────────────────────────────────────


@cli.command("config-template")
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, path_type=Path),
    default=None,
    help="Write template to this file instead of printing to stdout.",
)
def config_template_command(output: Path | None) -> None:
    """
    Print (or write) a documented YAML config template.

    Use the output as the starting point for a --config file::

        nimoh-base config-template -o my_project.yml
        # edit my_project.yml …
        nimoh-base init --config my_project.yml --no-input
    """
    from nimoh_base.cli.config import dump_config_template

    content = dump_config_template(output_path=output)

    if output is None:
        click.echo(content, nl=False)
    else:
        click.echo(f"Config template written to: {output}")
