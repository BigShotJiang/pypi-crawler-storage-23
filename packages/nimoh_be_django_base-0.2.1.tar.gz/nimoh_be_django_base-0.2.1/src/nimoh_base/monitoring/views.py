"""
Monitoring views for health checks and performance metrics.

Provides endpoints for:
- System health checks for container orchestration
- Performance metrics and monitoring dashboards
- Real-time application status
"""

import logging
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.db import DatabaseError, connection, models
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from drf_spectacular.utils import OpenApiResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response

from nimoh_base.conf import nimoh_setting
from nimoh_base.core.api_tags import monitoring_schema
from nimoh_base.core.health import check_cache, check_celery, check_database

from .models import EndpointMetrics, HealthCheck, MetricType, PerformanceMetric

logger = logging.getLogger(__name__)


def _get_package_version() -> str:
    """Return the installed package version, falling back to 'unknown'."""
    try:
        from importlib.metadata import version

        return version("nimoh-be-django-base")
    except Exception:
        return "unknown"


@csrf_exempt
@never_cache
@require_http_methods(["GET"])
def health_check(request):
    """
    Enhanced health check endpoint with dependency verification.

    Checks:
    - Database connectivity
    - Redis cache availability
    - Celery worker availability

    Returns 200 OK if all checks pass, 503 if any check fails.
    """
    checks = {}
    overall_healthy = True

    # Database connectivity check
    db_result = check_database()
    checks["database"] = db_result
    if db_result["status"] != "healthy":
        overall_healthy = False

    # Redis cache check
    cache_result = check_cache()
    checks["cache"] = cache_result
    if cache_result["status"] != "healthy":
        overall_healthy = False

    # Celery worker check — skipped when NIMOH_BASE['HEALTH_CHECK_CELERY'] is False
    if nimoh_setting("HEALTH_CHECK_CELERY", True):
        celery_result = check_celery(timeout=2.0)
        checks["celery"] = celery_result
        if celery_result["status"] not in ("healthy", "degraded"):
            overall_healthy = False

    response_data = {
        "status": "healthy" if overall_healthy else "unhealthy",
        "timestamp": timezone.now().isoformat(),
        "version": getattr(settings, "APP_VERSION", None) or _get_package_version(),
        "checks": checks,
    }

    status_code = 200 if overall_healthy else 503
    return JsonResponse(response_data, status=status_code)


@csrf_exempt
@never_cache
@require_http_methods(["GET"])
def readiness_check(request):
    """
    Readiness check for container orchestration.

    Verifies that all critical services are available.
    """
    checks = {}
    overall_status = "ready"

    # Database connectivity
    db_result = check_database()
    checks["database"] = db_result
    if db_result["status"] != "healthy":
        overall_status = "not_ready"

    # Cache connectivity (Redis)
    cache_result = check_cache()
    checks["cache"] = cache_result
    if cache_result["status"] != "healthy":
        overall_status = "not_ready"

    # Record health check results
    try:
        for check_type, check_data in checks.items():
            HealthCheck.objects.create(
                check_type=check_type,
                status=check_data["status"],
                response_time=Decimal(str(check_data.get("response_time_ms", 0))),
                details=check_data,
                error_message=check_data.get("error", ""),
            )
    except DatabaseError as e:
        logger.error("Failed to record health check results", extra={"error": str(e)})

    response_data = {"status": overall_status, "timestamp": timezone.now().isoformat(), "checks": checks}

    status_code = 200 if overall_status == "ready" else 503
    return JsonResponse(response_data, status=status_code)


@monitoring_schema(
    summary="Get Performance Metrics",
    description="Retrieve aggregated performance metrics for monitoring dashboards",
    responses={
        200: OpenApiResponse(description="Performance metrics data"),
        403: OpenApiResponse(description="Admin access required"),
    },
)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsAdminUser])
def performance_metrics(request):
    """
    Get performance metrics for monitoring dashboards.

    Returns aggregated performance data for analysis.
    """
    # Get time range from query parameters
    try:
        hours = int(request.GET.get("hours", 24))
    except (ValueError, TypeError):
        hours = 24
    since = timezone.now() - timedelta(hours=hours)

    # Aggregate metrics by type
    metrics_data = {}

    # Request/Response metrics
    request_metrics = (
        PerformanceMetric.objects.filter(metric_type=MetricType.REQUEST_RESPONSE, timestamp__gte=since)
        .values("name")
        .annotate(
            count=models.Count("id"),
            avg_value=models.Avg("value"),
            min_value=models.Min("value"),
            max_value=models.Max("value"),
        )
    )

    metrics_data["request_response"] = list(request_metrics)

    # Database query metrics
    db_metrics = (
        PerformanceMetric.objects.filter(metric_type=MetricType.DATABASE_QUERY, timestamp__gte=since)
        .values("name")
        .annotate(total_queries=models.Sum("value"), avg_queries=models.Avg("value"))
    )

    metrics_data["database_queries"] = list(db_metrics)

    # Recent health checks
    health_checks = HealthCheck.objects.filter(timestamp__gte=since).order_by("-timestamp")[:50]

    metrics_data["health_checks"] = [
        {
            "check_type": check.check_type,
            "status": check.status,
            "response_time": float(check.response_time),
            "timestamp": check.timestamp.isoformat(),
            "error_message": check.error_message,
        }
        for check in health_checks
    ]

    return Response({"time_range_hours": hours, "since": since.isoformat(), "metrics": metrics_data})


@monitoring_schema(
    summary="Get Endpoint Metrics",
    description="Retrieve performance metrics grouped by API endpoint",
    responses={
        200: OpenApiResponse(description="Endpoint performance metrics"),
        403: OpenApiResponse(description="Admin access required"),
    },
)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsAdminUser])
def endpoint_metrics(request):
    """
    Get performance metrics grouped by API endpoint.

    Returns aggregated performance data per endpoint.
    """
    # Get time range from query parameters
    try:
        hours = int(request.GET.get("hours", 24))
    except (ValueError, TypeError):
        hours = 24
    since = timezone.now() - timedelta(hours=hours)

    # Get aggregated endpoint metrics
    endpoint_data = EndpointMetrics.objects.filter(time_window_start__gte=since).order_by(
        "endpoint_path", "-time_window_start"
    )

    # Group by endpoint
    endpoints = {}
    for metric in endpoint_data:
        key = f"{metric.http_method} {metric.endpoint_path}"
        if key not in endpoints:
            endpoints[key] = []

        endpoints[key].append(
            {
                "time_window_start": metric.time_window_start.isoformat(),
                "request_count": metric.request_count,
                "error_count": metric.error_count,
                "error_rate": float(metric.error_rate),
                "avg_response_time": float(metric.avg_response_time),
                "min_response_time": float(metric.min_response_time),
                "max_response_time": float(metric.max_response_time),
                "p95_response_time": float(metric.p95_response_time),
                "status_codes": metric.status_codes,
            }
        )

    return Response({"time_range_hours": hours, "since": since.isoformat(), "endpoints": endpoints})


@monitoring_schema(
    summary="Get Real-time Metrics",
    description="Retrieve real-time performance metrics from cache",
    responses={
        200: OpenApiResponse(description="Real-time performance data"),
        403: OpenApiResponse(description="Admin access required"),
    },
)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsAdminUser])
def real_time_metrics(request):
    """
    Get real-time performance metrics from cache.

    Returns current performance data for monitoring dashboards.
    """
    # Get cached metrics for last hour

    # Note: This is a simplified version. In production, you might want
    # to use Redis directly for pattern matching
    real_time_data = {
        "timestamp": timezone.now().isoformat(),
        "endpoints": {},
        "system": {
            "active_connections": getattr(connection, "queries_count", 0),
            "cache_status": "healthy",  # Simplified
        },
    }

    return Response(real_time_data)


@monitoring_schema(
    summary="Clear Old Metrics",
    description="Clear old performance metrics to manage database size",
    responses={
        200: OpenApiResponse(description="Metrics cleared successfully"),
        403: OpenApiResponse(description="Admin access required"),
    },
)
@api_view(["POST"])
@permission_classes([IsAuthenticated, IsAdminUser])
def clear_metrics(request):
    """
    Clear old performance metrics to manage database size.

    Removes metrics older than specified retention period.
    """
    # Get retention period from request or settings
    retention_days = int(request.data.get("retention_days", getattr(settings, "METRICS_RETENTION_DAYS", 30)))
    cutoff_date = timezone.now() - timedelta(days=retention_days)

    # Clear old metrics
    deleted_metrics = PerformanceMetric.objects.filter(timestamp__lt=cutoff_date).delete()

    deleted_health_checks = HealthCheck.objects.filter(timestamp__lt=cutoff_date).delete()

    deleted_endpoint_metrics = EndpointMetrics.objects.filter(time_window_start__lt=cutoff_date).delete()

    return Response(
        {
            "message": "Metrics cleared successfully",
            "retention_days": retention_days,
            "cutoff_date": cutoff_date.isoformat(),
            "deleted_counts": {
                "performance_metrics": deleted_metrics[0] if deleted_metrics else 0,
                "health_checks": deleted_health_checks[0] if deleted_health_checks else 0,
                "endpoint_metrics": deleted_endpoint_metrics[0] if deleted_endpoint_metrics else 0,
            },
        }
    )
