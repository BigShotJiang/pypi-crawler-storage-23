# Core app initialization
