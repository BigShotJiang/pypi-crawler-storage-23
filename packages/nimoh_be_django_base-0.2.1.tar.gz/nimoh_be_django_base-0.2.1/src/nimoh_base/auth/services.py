"""Authentication Services.

This module provides business logic for authentication operations including
token exchange, user sessions, and secure authentication flows.
"""

import logging
import secrets
from datetime import timedelta
from typing import Any

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import transaction
from django.db.utils import DatabaseError
from django.utils import timezone
from rest_framework_simplejwt.tokens import RefreshToken

from .models import AuditLog, EmailVerificationToken, UserSession

User = get_user_model()
logger = logging.getLogger(__name__)


class ExchangeTokenService:
    """
    Service for managing temporary exchange tokens for secure authentication flows.

    Exchange tokens are short-lived, single-use tokens that can be exchanged
    for JWT access/refresh tokens. This pattern is more secure than passing
    JWT tokens directly in URLs.
    """

    # Cache key prefix for exchange tokens
    CACHE_PREFIX = "exchange_token"

    # Exchange token expiry (short-lived for security)
    TOKEN_EXPIRY_SECONDS = 60  # 1 minute

    @classmethod
    def generate_exchange_token(cls, user: User, context: dict[str, Any] | None = None) -> str:
        """
        Generate a one-time exchange token for a user.

        Args:
            user: The user to generate the token for
            context: Optional context data to store with the token

        Returns:
            The exchange token string
        """
        # Generate cryptographically secure random token
        exchange_token = secrets.token_urlsafe(32)

        # Prepare token data
        token_data = {
            "user_id": user.id,
            "created_at": timezone.now().isoformat(),
            "context": context or {},
            "used": False,
        }

        # Store in cache with expiry
        cache_key = f"{cls.CACHE_PREFIX}:{exchange_token}"
        cache.set(cache_key, token_data, timeout=cls.TOKEN_EXPIRY_SECONDS)

        logger.info(f"Generated exchange token for user {user.id}")

        return exchange_token

    @classmethod
    def exchange_for_jwt_tokens(cls, exchange_token: str, request_meta: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Exchange a one-time token for JWT access/refresh tokens.

        Args:
            exchange_token: The exchange token to validate and consume
            request_meta: Request metadata for session creation

        Returns:
            Dict containing access_token, refresh_token, and user info

        Raises:
            ValueError: If token is invalid, expired, or already used
        """
        cache_key = f"{cls.CACHE_PREFIX}:{exchange_token}"

        # Retrieve token data from cache
        token_data = cache.get(cache_key)

        if not token_data:
            raise ValueError("Invalid or expired exchange token")

        if token_data.get("used", False):
            raise ValueError("Exchange token has already been used")

        # Mark token as used (prevents reuse)
        token_data["used"] = True
        cache.set(cache_key, token_data, timeout=cls.TOKEN_EXPIRY_SECONDS)

        # Get user
        try:
            user = User.objects.get(id=token_data["user_id"])
        except User.DoesNotExist:
            raise ValueError("User not found for exchange token")

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token

        # Create user session and audit log atomically
        with transaction.atomic():
            session = cls._create_user_session(user, refresh, request_meta)
            cls._log_token_exchange(user, request_meta, success=True)

        # Delete the exchange token from cache (single use)
        cache.delete(cache_key)

        return {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user_id": user.id,
            "email": user.email,
            "session_id": str(session.id),
            # 15 minutes default
            "expires_in": access_token.get("exp") - timezone.now().timestamp() if access_token.get("exp") else 900,
            "context": token_data.get("context", {}),
        }

    @classmethod
    def _create_user_session(
        cls, user: User, refresh_token: RefreshToken, request_meta: dict[str, Any] | None = None
    ) -> UserSession:
        """Create a user session for the token exchange login."""
        request_meta = request_meta or {}

        # Generate a shorter session key that fits in 40 characters
        # Format: {jti}_{short_timestamp}
        timestamp = str(int(timezone.now().timestamp()))
        session_key = f"{refresh_token['jti'][:24]}_{timestamp[:8]}"

        session = UserSession.objects.create(
            user=user,
            device_fingerprint=request_meta.get("device_fingerprint", ""),
            device_name=request_meta.get("device_name", "Email Verification Login"),
            user_agent=request_meta.get("user_agent", ""),
            ip_address=request_meta.get("ip_address", ""),
            refresh_token_jti=str(refresh_token["jti"]),
            session_key=session_key,
            expires_at=timezone.now() + timedelta(days=14),  # Match refresh token expiry
        )

        UserSession.enforce_session_limit(user)
        return session

    @classmethod
    def _log_token_exchange(cls, user: User, request_meta: dict[str, Any] | None = None, success: bool = True):
        """Log the token exchange attempt for audit purposes."""
        request_meta = request_meta or {}

        AuditLog.log_event(
            event_type="security_event",
            user=user,
            description=f"Exchange token {'used' if success else 'failed'} for auto-login",
            ip_address=request_meta.get("ip_address", ""),
            user_agent=request_meta.get("user_agent", ""),
            success=success,
            risk_level="low" if success else "medium",
            metadata={
                "auto_login": True,
                "method": "email_verification_exchange",
            },
        )


class AuthenticationService:
    """
    Service for core authentication operations.

    Provides high-level authentication methods that can be used
    across different views and flows.
    """

    @staticmethod
    def authenticate_user(validated_data: dict[str, Any], request) -> dict[str, Any]:
        """
        Authenticate user and create session with JWT tokens.

        Args:
            validated_data: Dictionary containing user and session data from serializer
            request: HTTP request object

        Returns:
            Dict containing access_token, refresh_token, user, session, and metadata
        """
        user = validated_data["user"]
        device_name = validated_data.get("device_name", "Unknown Device")
        device_fingerprint = validated_data.get("device_fingerprint", "")
        remember_me = validated_data.get("remember_me", False)

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token

        # Extract request metadata
        request_meta = {
            "device_fingerprint": device_fingerprint or AuthenticationService.get_device_fingerprint(request),
            "device_name": device_name,
            "user_agent": request.META.get("HTTP_USER_AGENT", "Unknown"),
            "ip_address": request.META.get("REMOTE_ADDR", ""),
        }

        # Create user session and log atomically
        from .models import UserSession

        with transaction.atomic():
            session = UserSession.objects.create(
                user=user,
                device_fingerprint=request_meta["device_fingerprint"],
                device_name=request_meta["device_name"],
                user_agent=request_meta["user_agent"],
                ip_address=request_meta["ip_address"],
                refresh_token_jti=str(refresh["jti"]),
                session_key=f"{refresh['jti'][:24]}_{str(int(timezone.now().timestamp()))[:8]}",
                expires_at=timezone.now() + timedelta(days=14 if remember_me else 7),
            )

            UserSession.enforce_session_limit(user)

            AuditLog.log_from_request(
                request,
                event_type="login_success",
                description="User logged in successfully",
                user=user,
                session_id=str(session.id),
                metadata={
                    "device_name": device_name,
                    "remember_me": remember_me,
                },
            )

        return {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user": user,
            "session": session,
            "expires_in": 900,  # 15 minutes
            "token_type": "Bearer",
        }

    @staticmethod
    def get_device_fingerprint(request) -> str:
        """
        Generate a device fingerprint from request headers.

        This is a simple implementation - in production you might want
        to use more sophisticated fingerprinting.
        """
        user_agent = request.META.get("HTTP_USER_AGENT", "Test Client")
        accept_language = request.META.get("HTTP_ACCEPT_LANGUAGE", "")
        accept_encoding = request.META.get("HTTP_ACCEPT_ENCODING", "")

        # Create a simple hash of key headers
        import hashlib

        fingerprint_data = f"{user_agent}:{accept_language}:{accept_encoding}"
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]

    @staticmethod
    def extract_request_metadata(request) -> dict[str, Any]:
        """Extract metadata from request for session creation and logging."""
        return {
            "device_fingerprint": AuthenticationService.get_device_fingerprint(request),
            "device_name": "Email Verification Login",
            "user_agent": request.META.get("HTTP_USER_AGENT", "Test Client"),
            "ip_address": request.META.get("REMOTE_ADDR", ""),
        }

    @staticmethod
    def logout_user(user, request) -> bool:
        """
        Logout user and invalidate their active sessions.

        Args:
            user: User instance to logout
            request: HTTP request object

        Returns:
            bool: Success status
        """
        try:
            from .models import UserSession

            with transaction.atomic():
                active_sessions = UserSession.objects.filter(user=user, is_active=True)

                terminated_count = active_sessions.update(is_active=False)

                AuditLog.log_from_request(
                    request,
                    event_type="logout",
                    description=f"User logged out successfully. Terminated {terminated_count} session(s)",
                    user=user,
                    metadata={"sessions_terminated": terminated_count},
                )

            logger.info("User logout successful", user_id=str(user.id), sessions_terminated=terminated_count)

            return True
        except DatabaseError as e:
            logger.error("Logout failed with exception", user_id=str(user.id), error=str(e))

            # Log the failure
            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description="User logout failed",
                user=user,
                success=False,
                risk_level="medium",
                metadata={"error_type": type(e).__name__},
            )

            return False


class PasswordService:
    """
    Service class for password-related operations.
    """

    @staticmethod
    def validate_password_change(user, old_password, new_password):
        """
        Validate password change request.

        Args:
            user: User instance
            old_password: Current password
            new_password: New password

        Returns:
            dict: Validation result
        """
        # Check if old password is correct
        if not user.check_password(old_password):
            return {"valid": False, "error": "Current password is incorrect"}

        # Validate new password strength
        from .utils.auth import validate_password_strength

        strength_result = validate_password_strength(new_password, user)

        if not strength_result.get("valid", False):
            return {
                "valid": False,
                "error": "New password does not meet security requirements",
                "details": strength_result,
            }

        return {"valid": True, "message": "Password validation successful"}

    @staticmethod
    def change_password(user, new_password):
        """
        Change user password, invalidate all sessions/tokens, and log the action.

        After the password is set the method:
        1. Blacklists the refresh token for every active session.
        2. Deactivates all ``UserSession`` rows for the user.
        3. Creates an audit log entry.

        Args:
            user: User instance
            new_password: New password

        Returns:
            bool: Success status
        """
        try:
            with transaction.atomic():
                # Set the new password
                user.set_password(new_password)
                user.save()

                # Invalidate all active sessions and blacklist their tokens
                active_sessions = UserSession.objects.filter(user=user, is_active=True)
                for session in active_sessions:
                    session.invalidate_session_tokens(reason="password_change")
                # Bulk-deactivate any remaining active rows (belt-and-suspenders)
                active_sessions.update(is_active=False)

                # Log the password change
                AuditLog.log_event(
                    event_type="password_change",
                    user=user,
                    description="User changed their password — all sessions terminated",
                    ip_address="127.0.0.1",
                    risk_level="medium",
                )

            return True
        except DatabaseError as e:
            logger.error(f"Failed to change password for user {user.id}: {e}")
            return False


class SessionService:
    """
    Service class for session management operations.
    """

    @staticmethod
    def get_user_sessions(user):
        """
        Get all active sessions for a user.

        Args:
            user: User instance

        Returns:
            QuerySet of UserSession objects
        """
        return UserSession.objects.filter(user=user, is_active=True).order_by("-last_activity")

    @staticmethod
    def terminate_session(user, session_id):
        """
        Terminate a specific user session.

        Args:
            user: User instance
            session_id: ID of session to terminate

        Returns:
            bool: Success status
        """
        try:
            with transaction.atomic():
                session = UserSession.objects.get(id=session_id, user=user, is_active=True)
                session.is_active = False
                session.save()

                AuditLog.log_event(
                    event_type="session_terminated",
                    user=user,
                    description=f"Session {session_id} terminated",
                    ip_address="127.0.0.1",
                )

            return True
        except UserSession.DoesNotExist:
            logger.warning(f"Session {session_id} not found for user {user.id}")
            return False
        except DatabaseError as e:
            logger.error(f"Failed to terminate session {session_id}: {e}")
            return False

    @staticmethod
    def terminate_all_sessions(user, exclude_current=True, current_session_id=None):
        """
        Terminate all user sessions.

        Args:
            user: User instance
            exclude_current: Whether to exclude the current session
            current_session_id: ID of current session to exclude

        Returns:
            int: Number of sessions terminated
        """
        try:
            with transaction.atomic():
                sessions = UserSession.objects.filter(user=user, is_active=True)

                if exclude_current and current_session_id:
                    sessions = sessions.exclude(id=current_session_id)

                terminated_count = sessions.update(is_active=False)

                AuditLog.log_event(
                    event_type="session_terminated",
                    user=user,
                    description=f"Terminated {terminated_count} sessions",
                    ip_address="127.0.0.1",
                    risk_level="medium",
                )

            return terminated_count
        except DatabaseError as e:
            logger.error(f"Failed to terminate all sessions for user {user.id}: {e}")
            return 0

    @staticmethod
    def create_session(user, request):
        """
        Create a new user session.

        Args:
            user: User instance
            request: Django request object

        Returns:
            UserSession instance or None
        """
        try:
            from .utils.sessions import get_device_fingerprint

            session = UserSession.objects.create(
                user=user,
                device_name=request.META.get("HTTP_USER_AGENT", "Unknown Device")[:100],
                device_fingerprint=get_device_fingerprint(request),
                ip_address=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                is_active=True,
            )

            UserSession.enforce_session_limit(user)
            return session
        except DatabaseError as e:
            logger.error("Failed to create session", extra={"user_id": str(user.id), "error": str(e)})
            return None


class EmailVerificationService:
    """
    Service for handling email verification operations.

    Provides functionality for sending verification emails,
    validating tokens, and managing email verification state.
    """

    @staticmethod
    def send_verification_email(user):
        """
        Send verification email to user.

        Args:
            user: User instance to send verification email to

        Returns:
            bool: Success status
        """
        try:
            from .utils.auth import send_verification_email

            with transaction.atomic():
                # Generate verification token
                token = EmailVerificationToken.objects.create(user=user)

                # Send email
                send_verification_email(user, str(token.token))

                AuditLog.log_event(
                    event_type="email_verification",
                    user=user,
                    description="Email verification sent",
                )

            logger.info(f"Verification email sent to user {user.id}")
            return True

        except (DatabaseError, OSError) as e:
            logger.error(f"Failed to send verification email for user {user.id}: {e}")

            # Log the failure
            AuditLog.log_event(
                event_type="email_verification",
                user=user,
                description="Failed to send verification email",
                success=False,
                risk_level="medium",
                metadata={"error_type": type(e).__name__},
            )

            return False

    @staticmethod
    def verify_email_token(token_string):
        """
        Verify email verification token and mark email as verified.

        Args:
            token_string: Verification token string

        Returns:
            dict: Verification result with user and status
        """
        try:
            from .utils.auth import verify_email_token

            # Verify token using existing utility
            result = verify_email_token(token_string)

            if result.get("valid"):
                user = result.get("user")

                with transaction.atomic():
                    # Mark email as verified
                    user.email_verified = True
                    user.email_verified_at = timezone.now()
                    user.save()

                    AuditLog.log_event(
                        event_type="email_verification",
                        user=user,
                        description="Email verified successfully",
                    )

                logger.info(f"Email verified for user {user.id}")

                return {"valid": True, "user": user, "message": "Email verified successfully"}
            else:
                return {"valid": False, "error": result.get("error", "Invalid or expired token")}

        except DatabaseError as e:
            logger.error(f"Email verification failed: {e}")
            return {"valid": False, "error": "Verification failed"}

    @staticmethod
    def resend_verification_email(user):
        """
        Resend verification email to user.

        Args:
            user: User instance

        Returns:
            bool: Success status
        """
        # Check if email is already verified
        if user.email_verified:
            logger.warning(f"Attempted to resend verification to already verified user {user.id}")
            return False

        # Invalidate any existing tokens
        EmailVerificationToken.objects.filter(user=user, used=False).update(used=True)

        # Send new verification email
        return EmailVerificationService.send_verification_email(user)


class TokenService:
    """
    Service for token management operations.

    Placeholder for future token-related functionality beyond
    what's already provided by ExchangeTokenService.
    """

    pass
