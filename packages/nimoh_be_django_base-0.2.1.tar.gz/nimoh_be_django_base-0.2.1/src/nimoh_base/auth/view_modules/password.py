"""Password management views.

This module handles:
- Password change for authenticated users
- Password reset request flow
- Password reset confirmation
- Password validation and security
"""

import logging

from django.contrib.auth import get_user_model
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.exceptions import Throttled, ValidationError
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from nimoh_base.core.api_tags import APITags
from nimoh_base.core.exceptions import ProblemDetailException
from nimoh_base.core.throttling import (
    ChangePasswordRateThrottle,
    PasswordResetConfirmRateThrottle,
    PasswordResetRateThrottle,
)
from nimoh_base.core.utils import get_client_ip

from ..serializers import (
    PasswordChangeSerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    SuccessMessageSerializer,
)
from ..services import PasswordService

logger = logging.getLogger(__name__)
User = get_user_model()


@extend_schema(
    operation_id="change_password",
    summary="Change user password",
    description="""
    Change password for authenticated user.

    Requires current password for verification. Old password is stored in
    password history to prevent reuse. All user sessions and tokens are
    invalidated after password change.

    Rate limiting: 10 password changes per hour per user.
    """,
    request=PasswordChangeSerializer,
    responses={
        200: SuccessMessageSerializer,
        400: "Validation errors or incorrect current password",
        429: "Rate limit exceeded",
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@never_cache
def change_password_view(request):
    """
    Change password for authenticated user.

    This endpoint allows authenticated users to change their password.
    Requires the current password for verification.

    **Authentication**: Required
    **Rate Limiting**: 10 changes per hour per user

    **Request Body**:
    ```json
    {
        "current_password": "OldPassword123!",
        "new_password": "NewSecurePassword456!",
        "confirm_password": "NewSecurePassword456!"
    }
    ```

    **Response**:
    - `200 OK`: Password changed successfully
    - `400 Bad Request`: Validation errors or incorrect current password
    - `429 Too Many Requests`: Rate limit exceeded
    """
    throttle = ChangePasswordRateThrottle()
    if not throttle.allow_request(request, change_password_view):
        raise Throttled(detail="Too many password change attempts. Please try again later.")

    serializer = PasswordChangeSerializer(data=request.data, context={"request": request})

    if not serializer.is_valid():
        logger.warning(
            "Password change validation failed", extra={"user_id": str(request.user.id), "errors": serializer.errors}
        )
        raise ValidationError(serializer.errors)

    try:
        # Change password using service
        PasswordService.change_password(
            user=request.user,
            new_password=serializer.validated_data["new_password"],
        )

        logger.info(
            "Password changed successfully", extra={"user_id": str(request.user.id), "email": request.user.email}
        )

        return Response(
            {
                "message": "Password changed successfully. Please log in again.",
                "detail": "All sessions have been terminated for security.",
            },
            status=status.HTTP_200_OK,
        )

    except ValueError as e:
        logger.warning("Password change failed", extra={"user_id": str(request.user.id), "error": str(e)})
        raise ProblemDetailException(
            detail="Password change failed. Please try again.",
            code="password_change_error",
            status_code=status.HTTP_400_BAD_REQUEST,
        )


@extend_schema(
    operation_id="request_password_reset",
    summary="Request password reset",
    description="""
    Request password reset for user account.

    Sends password reset email with secure token. Always returns success
    to prevent email enumeration attacks, even if email doesn't exist.

    Rate limiting: 5 reset requests per hour per IP address.
    """,
    request=PasswordResetRequestSerializer,
    responses={200: SuccessMessageSerializer, 400: "Validation errors", 429: "Rate limit exceeded"},
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([AllowAny])
@never_cache
def password_reset_request_view(request):
    """
    Request password reset email.

    This endpoint sends a password reset email to the specified address.
    For security, always returns success even if email doesn't exist.

    **Authentication**: Not required
    **Rate Limiting**: 5 requests per hour per IP

    **Request Body**:
    ```json
    {
        "email": "user@example.com"
    }
    ```

    **Response**:
    - `200 OK`: Reset email sent (or would be sent if email exists)
    - `400 Bad Request`: Validation errors
    - `429 Too Many Requests`: Rate limit exceeded
    """
    throttle = PasswordResetRateThrottle()
    if not throttle.allow_request(request, password_reset_request_view):
        raise Throttled(detail="Too many password reset requests. Please try again later.")

    serializer = PasswordResetRequestSerializer(data=request.data)

    if not serializer.is_valid():
        logger.warning(
            "Password reset request validation failed",
            extra={"ip_address": get_client_ip(request), "errors": serializer.errors},
        )
        raise ValidationError(serializer.errors)

    try:
        email = serializer.validated_data["email"]

        # Process reset request (always returns True for security)
        PasswordService.request_password_reset(email=email, request=request)

        logger.info("Password reset requested", extra={"email": email, "ip_address": get_client_ip(request)})

        return Response(
            {
                "message": "If an account with this email exists, a password reset link has been sent.",
                "detail": "Please check your email for reset instructions.",
            },
            status=status.HTTP_200_OK,
        )

    except Exception as e:
        logger.error(
            "Password reset request error",
            extra={
                "email": serializer.validated_data.get("email"),
                "ip_address": get_client_ip(request),
                "error": str(e),
            },
        )
        return Response(
            {
                "message": "If an account with this email exists, a password reset link has been sent.",
                "detail": "Please check your email for reset instructions.",
            },
            status=status.HTTP_200_OK,
        )


class PasswordResetConfirmView(APIView):
    """
    Password reset confirmation endpoint.

    Supports both GET and POST methods:
    - GET: Validate reset token and show form (for email links)
    - POST: Confirm password reset with new password
    """

    permission_classes = [AllowAny]
    throttle_classes = [PasswordResetConfirmRateThrottle]

    @extend_schema(
        operation_id="validate_password_reset_token",
        summary="Validate password reset token",
        description="Validate password reset token from email link (GET method)",
        responses={
            200: {
                "type": "object",
                "properties": {
                    "message": {"type": "string"},
                    "token_valid": {"type": "boolean"},
                    "email": {"type": "string"},
                },
            },
            400: {"description": "Invalid or expired token"},
        },
        tags=[APITags.AUTHENTICATION],
    )
    def get(self, request, uidb64=None, token=None):
        """
        Validate password reset token.

        This endpoint validates a password reset token from an email link
        and returns whether the token is valid for password reset.
        """
        # Extract token from URL parameters or query parameters
        token = token or request.GET.get("token")

        if not token:
            raise ProblemDetailException(
                detail="Reset token is required.",
                code="token_missing",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        # Get and validate reset token
        from ..models import PasswordResetToken

        try:
            reset_token = PasswordResetToken.objects.get(token=token, is_used=False)
        except PasswordResetToken.DoesNotExist:
            logger.warning(
                "Invalid password reset token accessed",
                extra={"token": token[:8] + "...", "ip_address": get_client_ip(request)},
            )
            raise ProblemDetailException(
                detail="Invalid or expired reset token.",
                code="token_invalid",
                status_code=status.HTTP_400_BAD_REQUEST,
                token_valid=False,
            )

        # Check if token is expired
        if reset_token.is_expired():
            logger.warning(
                "Expired password reset token accessed",
                extra={
                    "token_id": str(reset_token.id),
                    "user_id": str(reset_token.user.id),
                    "ip_address": get_client_ip(request),
                },
            )
            raise ProblemDetailException(
                detail="Reset token has expired. Please request a new one.",
                code="token_expired",
                status_code=status.HTTP_400_BAD_REQUEST,
                token_valid=False,
            )

        # Token is valid
        logger.info(
            "Valid password reset token accessed",
            extra={
                "token_id": str(reset_token.id),
                "user_id": str(reset_token.user.id),
                "ip_address": get_client_ip(request),
            },
        )

        return Response(
            {
                "message": "Reset token is valid. You can now set a new password.",
                "token_valid": True,
                "email": reset_token.user.email,
            },
            status=status.HTTP_200_OK,
        )

    @extend_schema(
        operation_id="confirm_password_reset",
        summary="Confirm password reset",
        description="""
        Confirm password reset with token and set new password.

        Uses secure token from reset email to verify identity. Token is
        single-use and expires after 1 hour. All user sessions and tokens
        are invalidated after password reset.

        Rate limiting: 10 reset confirmations per hour per IP address.
        """,
        request=PasswordResetConfirmSerializer,
        responses={
            200: SuccessMessageSerializer,
            400: "Invalid token, expired token, or validation errors",
            429: "Rate limit exceeded",
        },
        tags=[APITags.AUTHENTICATION],
    )
    @method_decorator(never_cache)
    def post(self, request, uidb64=None, token=None):
        """
        Confirm password reset with token.

        This endpoint confirms a password reset using the token from the reset email
        and sets a new password for the user.
        """
        # Merge URL token with request data
        data = request.data.copy()
        if token:
            data["token"] = token

        serializer = PasswordResetConfirmSerializer(data=data)

        if not serializer.is_valid():
            logger.warning(
                "Password reset confirm validation failed",
                extra={"ip_address": get_client_ip(request), "errors": serializer.errors},
            )
            raise ValidationError(serializer.errors)

        try:
            token = serializer.validated_data["token"]
            new_password = serializer.validated_data["new_password"]

            # Get and validate reset token
            from ..models import PasswordResetToken

            try:
                reset_token = PasswordResetToken.objects.get(token=token, is_used=False)
            except PasswordResetToken.DoesNotExist:
                logger.warning(
                    "Invalid password reset token used",
                    extra={"token": token[:8] + "...", "ip_address": get_client_ip(request)},
                )
                raise ProblemDetailException(
                    detail="Invalid or expired reset token.",
                    code="token_invalid",
                    status_code=status.HTTP_400_BAD_REQUEST,
                )

            # Check if token is expired
            if reset_token.is_expired():
                logger.warning(
                    "Expired password reset token used",
                    extra={
                        "token_id": str(reset_token.id),
                        "user_id": str(reset_token.user.id),
                        "ip_address": get_client_ip(request),
                    },
                )
                raise ProblemDetailException(
                    detail="Reset token has expired. Please request a new one.",
                    code="token_expired",
                    status_code=status.HTTP_400_BAD_REQUEST,
                )

            # Reset password using service
            user = PasswordService.reset_password(reset_token=reset_token, new_password=new_password, request=request)

            logger.info(
                "Password reset completed",
                extra={"user_id": str(user.id), "email": user.email, "ip_address": get_client_ip(request)},
            )

            return Response(
                {
                    "message": "Password reset successfully. You can now log in with your new password.",
                    "detail": "All previous sessions have been terminated for security.",
                },
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            logger.warning("Password reset failed", extra={"error": str(e), "ip_address": get_client_ip(request)})
            raise ProblemDetailException(
                detail="Password reset failed. Please try again.",
                code="password_reset_error",
                status_code=status.HTTP_400_BAD_REQUEST,
            )


# Backward compatibility function
@csrf_exempt
@never_cache
def password_reset_confirm_view(request, uidb64=None, token=None):
    """Backward compatibility wrapper for the class-based view."""
    view = PasswordResetConfirmView()
    if request.method == "GET":
        return view.get(request, uidb64, token)
    else:
        return view.post(request, uidb64, token)
