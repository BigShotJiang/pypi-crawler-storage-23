"""Authentication app configuration."""

from django.apps import AppConfig


class AuthenticationConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nimoh_base.auth"
    label = "nimoh_auth"
    verbose_name = "Nimoh Base: Authentication"
