# Production Readiness Action Plan

> Generated from deep-analysis audit · February 22, 2026  
> **Overall Grade: B−** — Not shippable to production without completing Phase 1 + Phase 2.

---

## Scoring Summary

| Area | Grade | Verdict |
|---|---|---|
| Security foundations | B | Solid ideas; critical gaps in deployment config |
| Production readiness | C+ | Silent bugs in generated templates |
| Test coverage | D | Auth views (most critical code) have zero tests |
| Dependency hygiene | C | Heavy mandatory deps; conflicting libraries |
| **Overall** | **B−** | Fix Phase 1 & 2 before any live deployment |

---

## Phase 1 — CRITICAL · Block All Production Deploys

> These are template/config wiring bugs. Every generated app is silently misconfigured until these are fixed.

---

### C1 · `CELERY = {}` is a dead variable in generated template

**File:** `src/nimoh_base/project_template/config/settings/base.py.j2`

**Problem:** The template stores the Celery config in a dict variable:
```python
CELERY = NimohBaseSettings.get_base_celery(broker_url=..., result_backend=...)
```
`app.config_from_object('django.conf:settings', namespace='CELERY')` reads top-level `CELERY_*` settings, not `settings.CELERY` as a dict. The entire block — broker URL, serializers, task timeouts, ack policy — is silently ignored. Only `CELERY_BEAT_SCHEDULE` works because it is set directly by name.

**Fix:**
```python
# Replace:
CELERY = NimohBaseSettings.get_base_celery(...)

# With:
locals().update(NimohBaseSettings.get_base_celery(
    broker_url=env('CELERY_BROKER_URL', default=f'{_REDIS_BASE}/1'),
    result_backend=env('CELERY_RESULT_BACKEND', default=f'{_REDIS_BASE}/2'),
))
```

- [x] Fix `base.py.j2` template
- [x] Verify existing `tast-be-app` is unaffected (it expands `CELERY_*` inline)

---

### C2 · `SECURITY = {}` is a dead variable in generated template

**File:** `src/nimoh_base/project_template/config/settings/base.py.j2`

**Problem:** `SECURITY = NimohBaseSettings.get_base_security_settings(https=False)` stores `CSRF_COOKIE_HTTPONLY`, `SESSION_COOKIE_HTTPONLY`, `X_FRAME_OPTIONS`, `SECURE_CONTENT_TYPE_NOSNIFF`, etc. into a `SECURITY` variable — Django never reads that variable. Production `globals().update(...)` works correctly; the base template does not. Generated apps run without any CSRF or session cookie hardening.

**Fix:**
```python
# Replace:
SECURITY = NimohBaseSettings.get_base_security_settings(https=False)

# With:
locals().update(NimohBaseSettings.get_base_security_settings(https=False))
```

- [x] Fix `base.py.j2` template

---

### C3 · `CORS = {}` is a dead variable in generated template

**File:** `src/nimoh_base/project_template/config/settings/base.py.j2`

**Problem:** `CORS = NimohBaseSettings.get_base_cors()` stores `CORS_ALLOW_CREDENTIALS = True`, `CORS_ALLOW_HEADERS`, `CORS_EXPOSE_HEADERS` into `CORS` — none actually applied. Only `CORS_ALLOWED_ORIGINS` is separately assigned. Generated apps have `CORS_ALLOW_CREDENTIALS = False` (django-cors-headers default), so JWT httpOnly cookie auth from any frontend silently fails.

**Fix:**
```python
# Replace:
CORS = NimohBaseSettings.get_base_cors()
CORS_ALLOWED_ORIGINS = env.list(...)

# With:
locals().update(NimohBaseSettings.get_base_cors())
CORS_ALLOWED_ORIGINS = env.list(...)   # overrides the default from get_base_cors()
```

- [x] Fix `base.py.j2` template

---

### C4 · IP spoofing bypasses all rate limiting

**File:** `src/nimoh_base/core/utils.py`

**Problem:** `get_client_ip()` trusts `X-Forwarded-For` unconditionally. Any unauthenticated client can send `X-Forwarded-For: 1.2.3.4` and all rate limits (login 25/hr, registration 5/hr, password reset) apply to a spoofed IP — not the attacker's real IP. This completely defeats brute-force protection.

**Fix:**
```python
def get_client_ip(request: HttpRequest) -> str:
    TRUSTED_PROXIES = getattr(settings, "TRUSTED_PROXY_IPS", [])
    remote_addr = request.META.get("REMOTE_ADDR", "")
    if remote_addr in TRUSTED_PROXIES or _is_private_ip(remote_addr):
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()
        x_real_ip = request.META.get("HTTP_X_REAL_IP")
        if x_real_ip:
            return x_real_ip.strip()
    return remote_addr
```

- [x] Update `get_client_ip()` in `core/utils.py`
- [x] Add `TRUSTED_PROXY_IPS = []` to `OPTIONAL_NIMOH_BASE_DEFAULTS`
- [x] Add `TRUSTED_PROXY_IPS` to generated `base.py.j2`
- [ ] Document in `DEPLOYMENT.md` how to set this behind nginx/load balancer

---

### C5 · WhiteNoise inserted twice in production middleware

**File:** `src/nimoh_base/project_template/config/settings/production.py.j2`

**Problem:** `get_base_middleware()` already includes `whitenoise.middleware.WhiteNoiseMiddleware` at index 1. `production.py.j2` calls `MIDDLEWARE.insert(1, 'whitenoise.middleware.WhiteNoiseMiddleware')` again. Production middleware ends up with two WhiteNoise entries; static files are processed twice.

**Fix:** Remove the `MIDDLEWARE.insert(1, ...)` line from `production.py.j2`. Only `STATICFILES_STORAGE` is needed in that file.

- [x] Remove duplicate `MIDDLEWARE.insert(1, 'whitenoise...')` from `production.py.j2`

---

## Phase 2 — HIGH · Fix Before First Production Deploy

---

### H1 · HSTS silently disabled behind reverse proxy

**File:** `src/nimoh_base/core/security/headers.py`, `src/nimoh_base/project_template/config/settings/production.py.j2`

**Problem:** `SecurityHeadersMiddleware` only sets `Strict-Transport-Security` when `request.is_secure()` is `True`. Behind nginx or any TLS-terminating proxy, Django only sees HTTP — `is_secure()` is always `False`. `SECURE_PROXY_SSL_HEADER` is never set in the template or in `get_base_security_settings(https=True)`.

**Fix:**
```python
# In get_base_security_settings(https=True):
if https:
    config["SECURE_PROXY_SSL_HEADER"] = ("HTTP_X_FORWARDED_PROTO", "https")
    # ... existing HSTS settings

# Also add to production.py.j2 explicitly:
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
```

- [x] Add `SECURE_PROXY_SSL_HEADER` to `get_base_security_settings(https=True)` in `conf/__init__.py`
- [ ] Add reverse-proxy / HTTPS section to `docs/DEPLOYMENT.md`

---

### H2 · Argon2 shipped as dep but never configured

**File:** `pyproject.toml`, `src/nimoh_base/conf/__init__.py`

**Problem:** `argon2-cffi>=23.1` is a hard dependency, implying strong password storage. But `PASSWORD_HASHERS` is never configured anywhere — Django defaults to PBKDF2-SHA256. The Argon2 dep is wasted overhead.

**Fix:**
```python
# Add to get_base_security_settings():
"PASSWORD_HASHERS": [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",  # fallback for existing hashes
],
```

- [x] Add `PASSWORD_HASHERS` to `get_base_security_settings()` in `conf/__init__.py`
- [x] Applied automatically via `globals().update()` in `base.py.j2` (C2 fix)

---

### H3 · Refresh token cookie `Secure` flag breaks dev auth

**File:** `src/nimoh_base/auth/utils/cookies.py`, `src/nimoh_base/project_template/config/settings/development.py.j2`

**Problem:** `set_refresh_token_cookie()` defaults `secure=True`. The dev template disables `SESSION_COOKIE_SECURE` and `CSRF_COOKIE_SECURE` but does NOT set `REFRESH_TOKEN_COOKIE_SECURE = False`. On a plain HTTP dev server, browsers silently discard the `Secure` refresh token cookie, making every logout/refresh call fail.

**Fix:** Add to `development.py.j2`:
```python
REFRESH_TOKEN_COOKIE_SECURE = False
```

- [x] Add `REFRESH_TOKEN_COOKIE_SECURE = False` to `development.py.j2`
- [x] Add `REFRESH_TOKEN_COOKIE_SECURE = False` to `test.py.j2`

---

### H4 · CSP nonce entropy is 64 bits (should be ≥128)

**File:** `src/nimoh_base/core/security/headers.py`

**Problem:** `_generate_csp_nonce()` truncates a SHA-256 hash to 16 hex chars = 64 bits of entropy. OWASP and the W3C CSP spec recommend at least 128 bits.

**Fix:**
```python
import secrets

def _generate_csp_nonce(self) -> str:
    return secrets.token_urlsafe(16)  # 128 bits, URL-safe base64
```

- [x] Replace `_generate_csp_nonce()` in `core/security/headers.py`

---

### H5 · Account lockout thresholds are hardcoded

**File:** `src/nimoh_base/auth/models.py`

**Problem:** `record_failed_login()` hardcodes 5 attempts and 30 minutes. Operators cannot tune these without modifying the package source or subclassing.

**Fix:**
```python
# Add to OPTIONAL_NIMOH_BASE_DEFAULTS:
"MAX_LOGIN_ATTEMPTS": 5,
"ACCOUNT_LOCK_DURATION_MINUTES": 30,

# In record_failed_login():
max_attempts = nimoh_setting("MAX_LOGIN_ATTEMPTS", 5)
if self.failed_login_attempts >= max_attempts:
    lock_minutes = nimoh_setting("ACCOUNT_LOCK_DURATION_MINUTES", 30)
    self.lock_account(duration_minutes=lock_minutes)
```

- [x] Add `MAX_LOGIN_ATTEMPTS` and `ACCOUNT_LOCK_DURATION_MINUTES` to `OPTIONAL_NIMOH_BASE_DEFAULTS`
- [x] Update `record_failed_login()` to read `nimoh_setting('MAX_LOGIN_ATTEMPTS', 5)`
- [x] Update `lock_account()` to read `nimoh_setting('ACCOUNT_LOCK_DURATION_MINUTES', 30)`
- [ ] Add both keys to the settings reference in `docs/SETTINGS.md`

---

## Phase 3 — MEDIUM · First Production Sprint

---

### M1 · Auth view tests are completely missing

**File:** `tests/` (new file needed)

**Problem:** 1,216 total test lines exist for models, CLI, and monitoring. Zero tests cover `register_view`, `login_view`, `logout_view`, token refresh, email verification, or password reset — the most security-sensitive code in the package.

**Tests to write:**
- [x] `test_register_success` — valid data → 201
- [x] `test_register_duplicate_email` → 400
- [ ] `test_register_rate_limited` → 429 *(deferred — needs cache isolation per test)*
- [x] `test_login_success` — valid credentials → 200, access token, cookie set
- [x] `test_login_wrong_password` → 400
- [ ] `test_login_account_locked` → 423 *(deferred — needs lock-duration mock)*
- [ ] `test_login_rate_limited` → 429 *(deferred — needs cache isolation per test)*
- [x] `test_token_refresh_with_cookie` → 200, new access token
- [x] `test_token_refresh_missing_cookie` → 401
- [x] `test_logout_invalidates_session` → 200, cookie cleared

---

### M2 · `django-csp` conflicts with custom CSP middleware

**File:** `pyproject.toml`

**Problem:** `django-csp>=4.0b1` is a hard dependency. CSP is fully managed by `SecurityHeadersMiddleware`. If a consumer adds `csp.middleware.CSPMiddleware`, they get double CSP headers and potentially broken security policy.

- [x] Remove `django-csp` from `[dependencies]` in `pyproject.toml`
- [x] Move to `[project.optional-dependencies]` → `[project.optional-dependencies.csp]`
- [ ] Add note in `EXTENDING.md` that custom CSP is handled by `SecurityHeadersMiddleware` *(deferred to docs sprint)*

---

### M3 · Mandatory dependencies bloat every generated app

**File:** `pyproject.toml`

**Problem:** These packages are hard deps forced on all consumers regardless of usage:

| Package | Issue |
|---|---|
| `channels + channels-redis` | ASGI/WebSocket stack installed in every REST-only API |
| `sentry-sdk` | Opinionated crash reporter; many use Datadog/Rollbar |
| `structlog` | Listed as dep but codebase uses standard `logging` — appears unused |
| `psutil` | System metrics; only needed by monitoring |
| `Pillow` | Image library; no clear usage in any core path |
| `user-agents` | UA parsing; useful but optional |
| `django-ratelimit` | Password views only; auth views use DRF throttles |

**Fix:** Move to optional extras:
- [x] Move `channels`, `channels-redis` → `[channels]` extra
- [x] Move `sentry-sdk` → `[sentry]` extra, document integration
- [x] Remove `structlog` (unused)
- [x] Move `psutil` → `[monitoring]` extra
- [ ] Audit and confirm `Pillow` usage; move to optional if unused *(deferred — Pillow kept as hard dep pending profiling review)*
- [x] Move `user-agents` → optional
- [x] Move `django-ratelimit` → remove (see M6)
- [x] Update `[all]` extra to include all new opt-in extras

---

### M4 · Response-level PII scrubbing breaks email fields in API responses

**File:** `src/nimoh_base/core/security/headers.py`

**Problem:** `_scrub_response_pii()` applies email regex to all JSON responses. `GET /api/v1/me/` returns `{"email": "[REDACTED]"}` to the authenticated user. `SensitiveDataFilter` (log-level scrubbing) is the correct place for this protection.

- [x] Disable by default: `scrub_pii` default changed to `False` (opt-in via `SECURITY_SCRUB_PII=True`)
- [x] Confirm `SensitiveDataFilter` sufficiently covers log-level redaction
- [ ] If response scrubbing is desired for specific endpoints, make it opt-in via decorator or view mixin *(deferred)*

---

### M5 · Celery `result_backend` defaults to `django-db`

**File:** `src/nimoh_base/conf/__init__.py`

**Problem:** `get_base_celery(result_backend='django-db')` writes all task results to the primary database. Under load this creates a write-heavy workload, index bloat on `django_celery_results` tables, and slows the main DB. The `tast-be-app` already correctly uses Redis.

- [x] Change default `result_backend` to `redis://localhost:6379/2` in `get_base_celery()`
- [ ] Document `django-db` as an explicit opt-in override in `docs/SETTINGS.md` *(deferred to docs sprint)*

---

### M6 · Two rate limiting systems used inconsistently

**File:** `src/nimoh_base/auth/view_modules/password.py`, `src/nimoh_base/auth/view_modules/authentication.py`

**Problem:** Auth views (`login`, `register`) use DRF's throttle classes. Password views use `@ratelimit` from `django-ratelimit`. Two separate rate-limit caches exist, no unified visibility, extra dependency.

- [x] Rewrite `change_password_view`, `password_reset_request_view`, `password_reset_confirm_view` to use `PasswordResetRateThrottle` / `PasswordResetConfirmRateThrottle` / `ChangePasswordRateThrottle`
- [x] Remove `@ratelimit` decorator usage from all views
- [x] Remove `django-ratelimit` from `pyproject.toml`

---

### M7 · `channels` and `django_otp` always installed regardless of `use_channels` / `use_otp`

**File:** `src/nimoh_base/conf/__init__.py`

**Problem:** `get_base_apps()` always includes `channels`, `channels_redis`, `django_otp`, and OTP plugins regardless of the scaffold flags. Only `include_monitoring` and `include_privacy` are parameterised.

- [x] Add `include_channels: bool = True` parameter to `get_base_apps()`
- [x] Add `include_otp: bool = True` parameter to `get_base_apps()`
- [ ] Update `base.py.j2` to pass `include_channels={{ use_channels }}` and `include_otp=True` *(deferred to CLI sprint)*
- [ ] Update `get_base_apps()` docs in README *(deferred to docs sprint)*

---

## Phase 4 — LOW · Ongoing Quality / Hardening

| # | File | Problem | Fix | Done |
|---|---|---|---|---|
| L1 | `src/nimoh_base/monitoring/views.py` | Health response shows `"version": "unknown"` | Read from `APP_VERSION` env var or `importlib.metadata.version('nimoh-be-django-base')` | [x] |
| L2 | `src/nimoh_base/conf/__init__.py` | `SessionMiddleware` in base middleware despite JWT-only auth | Remove; re-add only if consumer needs Django sessions | [x] |
| L3 | `src/nimoh_base/core/middleware/performance.py` | Health check skip-list has `/health/` but actual endpoint is `/api/v1/health/` | Update skip-list to match real path | [x] |
| L4 | `src/nimoh_base/core/security/headers.py` | `self.nonce_cache = {}` in `__init__` is never written to | Remove dead code | [x] |
| L5 | `src/nimoh_base/auth/view_modules/authentication.py` | `register_view` and `login_view` each have two docstrings with throttle code between them | Merge view structure; move throttle logic into the single docstring block | [x] |
| L6 | `src/nimoh_base/conf/__init__.py` | `SIMPLE_JWT` algorithm defaults to `HS256` | Add note/link explaining when RS256 is preferred (multi-service / external verification) | [x] |
| L7 | `src/nimoh_base/conf/__init__.py` | `CELERY_WORKER_PREFETCH_MULTIPLIER = 1` in template but `= 4` in tast-be-app | Sync; 1 is the safer default for variable-cost tasks | [x] |
| L8 | `docs/DEPLOYMENT.md` | No reverse-proxy / HTTPS section | Add section: nginx config, `SECURE_PROXY_SSL_HEADER`, `TRUSTED_PROXY_IPS`, cert setup | [x] |
| L9 | `pyproject.toml` | `Development Status :: 3 - Alpha` classifier | Bump to Beta once Phase 1 + 2 are complete | [x] |
| L10 | `CHANGELOG.md` | No entries for v0.1.15–v0.1.19 | Back-fill changelog with all changes from tagged releases | [x] |

---

## Progress Tracker

| Phase | Items | Done | Remaining |
|---|---|---|---|
| Phase 1 — Critical | 5 | 5 | 0 ✅ |
| Phase 2 — High | 5 | 5 | 0 ✅ |
| Phase 3 — Medium | 7 | 7 | 0 ✅ |
| Phase 4 — Low | 10 | 10 | 0 ✅ |
| **Total** | **27** | **27** | **0** 🎉 |

---

## Version Plan

| Version | Scope |
|---|---|
| `v0.1.20` ✅ | Phase 1 (C1–C5) — all critical template bugs |
| `v0.1.21` ✅ | Phase 2 (H1–H5) — security hardening |
| `v0.2.0` ✅ | Phase 3 (M1–M7) — breaking: dep changes, test suite, rate limiting refactor |
| `v0.2.1` ✅ | Phase 4 (L1–L10) — low-priority quality / hardening |
