# Deployment Guide

This guide covers production deployment of a project built on `nimoh-be-django-base`.

---

## Table of Contents

1. [Overview](#overview)
2. [Environment Variables](#environment-variables)
3. [Reverse Proxy / HTTPS with nginx](#reverse-proxy--https-with-nginx)
4. [Django Proxy SSL Settings](#django-proxy-ssl-settings)
5. [Trusted Proxy IPs](#trusted-proxy-ips)
6. [TLS Certificate Setup (Let's Encrypt)](#tls-certificate-setup-lets-encrypt)
7. [Gunicorn Process](#gunicorn-process)
8. [Health Check Endpoint](#health-check-endpoint)
9. [Checklist](#checklist)

---

## Overview

The recommended production stack:

```
Internet → nginx (TLS termination) → Gunicorn (Django) → PostgreSQL + Redis
```

Gunicorn never handles TLS directly. nginx terminates HTTPS and forwards plain
HTTP to Gunicorn over a Unix socket or `127.0.0.1`.

---

## Environment Variables

Copy `.env.example` to `.env` and set at minimum:

```bash
SECRET_KEY=<long-random-string>
DEBUG=False
ALLOWED_HOSTS=api.example.com
DATABASE_URL=postgres://user:pass@localhost:5432/mydb
REDIS_URL=redis://localhost:6379/0
```

---

## Reverse Proxy / HTTPS with nginx

### Minimal nginx site config

```nginx
server {
    listen 80;
    server_name api.example.com;
    # Redirect all HTTP to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.example.com;

    # --- TLS ---
    ssl_certificate     /etc/letsencrypt/live/api.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.example.com/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    # --- Proxy to Gunicorn ---
    location / {
        proxy_pass         http://unix:/run/gunicorn.sock;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_redirect     off;

        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout    60s;
        proxy_read_timeout    120s;
    }

    # --- Static files served directly ---
    location /static/ {
        alias /srv/myapp/staticfiles/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # --- Media files (if not on object storage) ---
    location /media/ {
        alias /srv/myapp/mediafiles/;
        expires 7d;
    }
}
```

---

## Django Proxy SSL Settings

Django must know that HTTPS is being terminated by the proxy. Add to your
production settings:

```python
# Trust the X-Forwarded-Proto header set by nginx
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

# Redirect HTTP → HTTPS via Django's SecurityMiddleware
SECURE_SSL_REDIRECT = True

# HSTS — tell browsers to always use HTTPS (1 year)
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Secure cookies
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
REFRESH_TOKEN_COOKIE_SECURE = True  # nimoh_base custom setting
```

> **Note**: `SECURE_SSL_REDIRECT` should be `False` if nginx already enforces
> the redirect (to avoid a redirect loop). Either nginx redirects or Django
> redirects — not both.

---

## Trusted Proxy IPs

`PerformanceMonitoringMiddleware` reads the real client IP from
`X-Forwarded-For`. To prevent IP spoofing, restrict which proxies are trusted.

Via Django 4.0+ `TRUSTED_PROXY_IPS` (or your custom env var):

```python
# Trust only your own nginx server (127.0.0.1 for same-host, or real IP)
USE_X_FORWARDED_HOST = True
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

# If using django-ipware or similar, configure trusted proxies:
IPWARE_META_PRECEDENCE_ORDER = ("HTTP_X_FORWARDED_FOR", "REMOTE_ADDR")
```

For load-balanced setups with multiple proxy IPs, set `ALLOWED_HOSTS` strictly
and consider using `django-xff` or `whitenoise`'s trusted proxy feature.

---

## TLS Certificate Setup (Let's Encrypt)

Using **Certbot** with nginx on Ubuntu/Debian:

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain and auto-install certificate
sudo certbot --nginx -d api.example.com

# Automatic renewal (added by certbot, verify it runs)
sudo systemctl status certbot.timer
```

Certbot modifies your nginx config to add the `ssl_certificate` lines and sets
up a systemd timer for auto-renewal every 12 hours.

---

## Gunicorn Process

`start_prod.sh` in the project root starts Gunicorn. For production, run it
under **systemd**:

```ini
# /etc/systemd/system/myapp.service
[Unit]
Description=Gunicorn daemon for myapp
Requires=myapp.socket
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/srv/myapp
EnvironmentFile=/srv/myapp/.env
ExecStart=/srv/myapp/.venv/bin/gunicorn \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind unix:/run/gunicorn.sock \
    --timeout 120 \
    config.asgi:application
ExecReload=/bin/kill -s HUP $MAINPID
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

```ini
# /etc/systemd/system/myapp.socket
[Unit]
Description=Gunicorn socket for myapp

[Socket]
ListenStream=/run/gunicorn.sock
SocketUser=www-data

[Install]
WantedBy=sockets.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now myapp.socket myapp
```

---

## Health Check Endpoint

The health check lives at `/api/v1/health/` and returns:

```json
{
  "status": "healthy",
  "timestamp": "2026-02-22T12:00:00.000000+00:00",
  "version": "0.2.0",
  "checks": {
    "database": {"status": "healthy"},
    "cache": {"status": "healthy"},
    "celery": {"status": "healthy"}
  }
}
```

HTTP `200` means all checks passed; `503` means at least one check failed.

Configure your load balancer / container orchestrator to poll this endpoint.
Set `HEALTH_CHECK_CELERY=false` in `.env` to skip the Celery worker check
(useful during startup before workers come online).

---

## Checklist

Before going live:

- [ ] `DEBUG=False`
- [ ] `SECRET_KEY` is unique and not committed to VCS
- [ ] `ALLOWED_HOSTS` contains only your domain(s)
- [ ] `SECURE_PROXY_SSL_HEADER` set correctly
- [ ] `SECURE_SSL_REDIRECT=True` (or nginx handles it)
- [ ] `SESSION_COOKIE_SECURE=True` and `CSRF_COOKIE_SECURE=True`
- [ ] `REFRESH_TOKEN_COOKIE_SECURE=True`
- [ ] `SECURE_HSTS_SECONDS` set (start with 300 and increase after testing)
- [ ] Static files collected: `python manage.py collectstatic --noinput`
- [ ] Migrations applied: `python manage.py migrate`
- [ ] Celery worker and beat processes running
- [ ] Health check endpoint reachable and returning `200`
- [ ] Log aggregation configured (the JSON formatter outputs structured logs)
