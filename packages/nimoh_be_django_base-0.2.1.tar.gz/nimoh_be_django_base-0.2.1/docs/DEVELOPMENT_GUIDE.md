# Development Guide

> **Prerequisite:** your project must already be scaffolded and running.
> If you haven't done that yet, start with [GETTING_STARTED.md](GETTING_STARTED.md).

This guide covers the day-to-day development workflow: creating models, writing API
endpoints, handling errors, running background tasks, and testing.

---

## Table of Contents

1. [Starting your development environment](#1-starting-your-development-environment)
2. [Project structure overview](#2-project-structure-overview)
3. [Creating your first feature](#3-creating-your-first-feature)
   - [3.1 Model](#31-model)
   - [3.2 Serializer](#32-serializer)
   - [3.3 View](#33-view)
   - [3.4 URLs](#34-urls)
4. [Base model reference](#4-base-model-reference)
5. [Authentication & permissions](#5-authentication--permissions)
6. [Error handling](#6-error-handling)
7. [Background tasks (Celery)](#7-background-tasks-celery)
8. [Logging](#8-logging)
9. [Writing tests](#9-writing-tests)
10. [Code quality](#10-code-quality)
11. [Adding a new Django app](#11-adding-a-new-django-app)
12. [Upgrading the base package](#12-upgrading-the-base-package)

---

## 1. Starting your development environment

From inside your project directory (with the venv activated):

```bash
# One-command start — spins up Redis + Celery via Docker, then runserver
make start

# Or manually:
docker compose up -d redis celery_worker   # background services
python manage.py runserver                 # Django dev server
```

Key URLs once running:

| URL | Description |
|-----|-------------|
| `http://localhost:8000/api/v1/health/` | Health check (database, cache, celery) |
| `http://localhost:8000/api/v1/schema/docs/` | Swagger UI — browse all endpoints |
| `http://localhost:8000/admin/` | Django admin |

---

## 2. Project structure overview

```
my_app/
├── manage.py
├── Makefile
├── requirements.txt
├── .env                       ← local secrets (never commit this)
├── .env.example               ← committed; documents all env vars
├── config/
│   ├── settings/
│   │   ├── base.py            ← shared settings; NIMOH_BASE lives here
│   │   ├── development.py     ← overrides for local dev (DEBUG=True, etc.)
│   │   └── production.py      ← production overrides (JSON logging, HTTPS)
│   ├── urls.py                ← root URL conf; mounts nimoh_base routes
│   ├── celery.py              ← Celery app factory
│   └── wsgi.py
└── my_app/                    ← generated stub app (rename/extend as needed)
    ├── apps.py
    ├── models.py
    ├── serializers.py
    ├── views.py
    └── urls.py
```

The `config/settings/base.py` file is the main settings file. It calls
`NimohBaseSettings` helpers to wire in all package settings, and defines the
`NIMOH_BASE` configuration dict.

`DJANGO_SETTINGS_MODULE` defaults to `config.settings.development`. Production
deployments set it to `config.settings.production`.

---

## 3. Creating your first feature

The typical pattern for a new API resource is:

```
Model → Migration → Serializer → View → URL
```

### 3.1 Model

Inherit from `TimeStampedModel` to get `created_at` / `updated_at` for free:

```python
# my_app/models.py
from django.conf import settings
from django.db import models
from nimoh_base.core.models import TimeStampedModel


class Article(TimeStampedModel):
    """A simple article resource."""

    title = models.CharField(max_length=255)
    body = models.TextField()
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="articles",
    )
    is_published = models.BooleanField(default=False)

    def __str__(self) -> str:
        return self.title
```

Generate and apply the migration:

```bash
python manage.py makemigrations
python manage.py migrate
```

### 3.2 Serializer

```python
# my_app/serializers.py
from rest_framework import serializers
from .models import Article


class ArticleSerializer(serializers.ModelSerializer):
    author_email = serializers.EmailField(source="author.email", read_only=True)

    class Meta:
        model = Article
        fields = ["id", "title", "body", "author_email", "is_published", "created_at", "updated_at"]
        read_only_fields = ["id", "author_email", "created_at", "updated_at"]
```

### 3.3 View

Use DRF's `ModelViewSet` for full CRUD, or `APIView` / `GenericAPIView` for
fine-grained control:

```python
# my_app/views.py
import logging

from rest_framework import permissions, viewsets

from nimoh_base.core.permissions import IsOwnerOrReadOnly

from .models import Article
from .serializers import ArticleSerializer

logger = logging.getLogger("apps")


class ArticleViewSet(viewsets.ModelViewSet):
    serializer_class = ArticleSerializer
    permission_classes = [permissions.IsAuthenticated, IsOwnerOrReadOnly]

    def get_queryset(self):
        # List only published articles to non-owners
        if self.action == "list":
            return Article.objects.filter(is_published=True)
        return Article.objects.all()

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)
        logger.info("Article created", extra={"user_id": self.request.user.pk})
```

### 3.4 URLs

Register the router in your app's `urls.py`, then include it in the root conf:

```python
# my_app/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ArticleViewSet

router = DefaultRouter()
router.register(r"articles", ArticleViewSet, basename="article")

urlpatterns = [
    path("", include(router.urls)),
]
```

```python
# config/urls.py
from django.contrib import admin
from django.urls import path, include
from nimoh_base.conf.urls import nimoh_base_urlpatterns

urlpatterns = [
    path("admin/", admin.site.urls),
    *nimoh_base_urlpatterns(api_prefix="api/v1/"),
    path("api/v1/", include("my_app.urls")),   # ← add your app here
]
```

Your endpoints are now live at `GET /api/v1/articles/`, `POST /api/v1/articles/`, etc.
Browse them at `http://localhost:8000/api/v1/schema/docs/`.

---

## 4. Base model reference

### `TimeStampedModel`

```python
from nimoh_base.core.models import TimeStampedModel
```

| Field | Type | Notes |
|-------|------|-------|
| `created_at` | `DateTimeField(auto_now_add=True)` | Set once on creation; indexed |
| `updated_at` | `DateTimeField(auto_now=True)` | Updated on every save |

Default `Meta.ordering` is `["-created_at"]` (newest first).

### `SoftDeleteModel`

```python
from nimoh_base.core.models import SoftDeleteModel
```

Records are never physically deleted — `delete()` sets `is_deleted=True` and
records a timestamp. The default manager automatically filters out soft-deleted rows.

| Field | Type | Notes |
|-------|------|-------|
| `is_deleted` | `BooleanField(default=False)` | Soft-delete flag |
| `deleted_at` | `DateTimeField(null=True)` | Set when soft-deleted |

**Manager / QuerySet methods:**

```python
Article.objects.all()                # excludes soft-deleted (default)
Article.objects.all_with_deleted()   # includes soft-deleted rows
article.delete()                     # soft-delete — sets is_deleted=True
article.hard_delete()                # permanent DELETE FROM … (use with care)

# QuerySet level
Article.objects.filter(author=user).delete()       # soft-delete all
Article.objects.filter(author=user).alive()        # only non-deleted
Article.objects.filter(author=user).dead()         # only soft-deleted
Article.objects.filter(author=user).hard_delete()  # permanent
```

### Combining both

```python
from nimoh_base.core.models import TimeStampedModel, SoftDeleteModel

class Article(TimeStampedModel, SoftDeleteModel):
    ...
```

---

## 5. Authentication & permissions

All endpoints protected by `IsAuthenticated` expect a JWT `Authorization` header:

```http
Authorization: Bearer <access_token>
```

Obtain tokens via `POST /api/v1/auth/login/` (email + password).

### Built-in permission classes

```python
from nimoh_base.core.permissions import (
    IsOwnerOrReadOnly,    # SAFE methods for anyone; write methods for obj.author/owner only
    IsAdminOrReadOnly,    # SAFE methods for anyone; write methods for staff only
    IsVerifiedUser,       # Requires user.email_verified == True
    CanManageDevices,     # Requires authenticated + verified (for device-session endpoints)
)
```

Combine with DRF's built-ins:

```python
permission_classes = [permissions.IsAuthenticated, IsVerifiedUser, IsOwnerOrReadOnly]
```

### Checking ownership manually

`IsOwnerOrReadOnly` calls `obj.author` or `obj.user` automatically. If your
model uses a different owner field, override `has_object_permission`:

```python
class ArticleViewSet(viewsets.ModelViewSet):
    def get_permissions(self):
        if self.action in ["update", "partial_update", "destroy"]:
            return [permissions.IsAuthenticated(), IsOwnerPermission()]
        return [permissions.AllowAny()]
```

---

## 6. Error handling

The package registers a custom DRF exception handler that returns
[RFC 7807 Problem+JSON](https://www.rfc-editor.org/rfc/rfc7807) responses.

Standard DRF exceptions (e.g. `ValidationError`, `PermissionDenied`) are
automatically transformed. For your own domain errors, raise `ProblemDetailException`:

```python
from rest_framework import status
from nimoh_base.core.exceptions import ProblemDetailException


def perform_create(self, serializer):
    if self.request.user.articles.count() >= 10:
        raise ProblemDetailException(
            detail="Free accounts are limited to 10 articles.",
            status_code=status.HTTP_403_FORBIDDEN,
            title="Article limit reached",
            type_uri="https://myapp.com/errors/article-limit",
        )
    serializer.save(author=self.request.user)
```

Error response shape:

```json
{
  "type": "https://myapp.com/errors/article-limit",
  "title": "Article limit reached",
  "status": 403,
  "detail": "Free accounts are limited to 10 articles."
}
```

---

## 7. Background tasks (Celery)

The project already has a Celery app configured via `nimoh_base`'s `make_celery()`
factory. Define tasks with `@shared_task` so they're decoupled from the app name:

```python
# my_app/tasks.py
import logging

from celery import shared_task
from celery.utils.log import get_task_logger

from .models import Article

logger = get_task_logger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def publish_article(self, article_id: int) -> dict:
    """Publish an article and notify subscribers."""
    try:
        article = Article.objects.get(pk=article_id)
        article.is_published = True
        article.save(update_fields=["is_published", "updated_at"])
        logger.info("Article published", extra={"article_id": article_id})
        return {"status": "published", "article_id": article_id}
    except Article.DoesNotExist:
        logger.error("Article not found", extra={"article_id": article_id})
        return {"status": "not_found"}
    except Exception as exc:
        logger.warning("publish_article failed, retrying", extra={"error": str(exc)})
        raise self.retry(exc=exc)
```

Dispatch from a view:

```python
# In your view
from .tasks import publish_article

def perform_update(self, serializer):
    instance = serializer.save()
    if instance.is_published:
        publish_article.delay(instance.pk)
```

The package also ships a pre-built `send_email_task` you can use directly:

```python
from nimoh_base.core.tasks import send_email_task

send_email_task.delay(
    subject="Welcome!",
    message="Thanks for signing up.",
    recipient_list=["user@example.com"],
)
```

---

## 8. Logging

Each app has a named logger. Use `logging.getLogger("apps")` for your app code —
it maps to the `apps` logger configured in `LOGGING`:

```python
import logging

logger = logging.getLogger("apps")        # general app code
# logger = logging.getLogger("apps.orders")  # sub-logger for a specific module

def my_view(request):
    logger.debug("Processing request", extra={"user_id": request.user.pk})
    logger.info("Order placed", extra={"order_id": 42})
    logger.warning("Low stock", extra={"product_id": 7, "quantity": 1})
    logger.error("Payment failed", extra={"error_code": "card_declined"})
```

Dev output is coloured and aligned:

```
19:35:06  INFO      apps              Order placed
19:35:06  WARNING   apps              Low stock
```

### Toggling SQL query logging

Set `LOG_SQL=true` in `.env` to see every database query in the terminal:

```dotenv
LOG_SQL=true
```

This is useful for catching N+1 queries. Disable it (`LOG_SQL=false` or remove)
for normal development to reduce noise.

### Log levels per environment

| Logger | Development | Production |
|--------|-------------|------------|
| `apps` | `DEBUG` | `INFO` |
| `django` | `INFO` | `WARNING` |
| `django.db.backends` | `DEBUG` (only if `LOG_SQL=true`) | `WARNING` |

---

## 9. Writing tests

The project uses **pytest-django**. Tests live in `tests/` at the project root or
inside each app (`my_app/tests/`).

### Setup

```python
# conftest.py  (already generated — add fixtures here)
import pytest
from rest_framework.test import APIClient
from django.contrib.auth import get_user_model

User = get_user_model()


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user(db):
    return User.objects.create_user(
        email="test@example.com",
        username="testuser",
        password="StrongPass123!",
    )


@pytest.fixture
def auth_client(api_client, user):
    api_client.force_authenticate(user=user)
    return api_client
```

### Writing a test

```python
# my_app/tests/test_articles.py
import pytest
from django.urls import reverse
from my_app.models import Article


@pytest.mark.django_db
class TestArticleAPI:
    def test_list_returns_only_published(self, api_client, user):
        Article.objects.create(title="Draft", body="...", author=user, is_published=False)
        Article.objects.create(title="Live", body="...", author=user, is_published=True)

        url = reverse("article-list")
        response = api_client.get(url)

        assert response.status_code == 200
        assert len(response.data["results"]) == 1
        assert response.data["results"][0]["title"] == "Live"

    def test_create_requires_auth(self, api_client):
        url = reverse("article-list")
        response = api_client.post(url, {"title": "New", "body": "Body"})
        assert response.status_code == 401

    def test_create_article(self, auth_client, user):
        url = reverse("article-list")
        response = auth_client.post(url, {"title": "My Article", "body": "Content"})
        assert response.status_code == 201
        assert Article.objects.filter(author=user).count() == 1
```

### Running tests

```bash
make test              # runs the full suite
pytest my_app/tests/   # run only one app's tests
pytest -k test_create  # run tests matching a keyword
pytest --reuse-db      # skip re-creating the test DB (faster on repeat runs)
```

---

## 10. Code quality

The project is configured with **ruff** for linting and formatting:

```bash
make lint      # ruff check
make format    # ruff format
```

Run both before committing (CI will fail if either has errors):

```bash
make format && make lint
```

If you've added the pre-commit hook (`make setup` / `pre-commit install`), this
runs automatically on `git commit`.

### Import order

Ruff enforces isort-compatible import ordering. The expected order is:
1. Standard library
2. Third-party (`django`, `rest_framework`, `celery`, …)
3. First-party (`nimoh_base.*`, `config.*`)
4. Local app imports (`from .models import …`)

---

## 11. Adding a new Django app

```bash
python manage.py startapp orders
```

Register it in `config/settings/base.py`:

```python
# config/settings/base.py
INSTALLED_APPS = NimohBaseSettings.get_base_apps() + [
    "my_app",
    "orders",    # ← add here
]
```

Add a `urls.py` to the new app and include it in `config/urls.py`:

```python
path("api/v1/", include("orders.urls")),
```

Create the migration:

```bash
python manage.py makemigrations orders
python manage.py migrate
```

---

## 12. Upgrading the base package

When a new version of `nimoh-be-django-base` is released:

```bash
make upgrade          # pip install --upgrade nimoh-be-django-base[all]
make migrate          # apply any new migrations from the package
```

Check the [CHANGELOG](../CHANGELOG.md) for breaking changes before upgrading
across major versions. The [MIGRATION_GUIDE](MIGRATION_GUIDE.md) covers
step-by-step instructions for significant upgrades.
