"""Bash capability - execute shell commands with security constraints."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
import time
from typing import Any, ClassVar

import psutil

from snippbot_device.capabilities import BaseCapability, CapabilityResult

logger = logging.getLogger(__name__)

MAX_TIMEOUT = 300  # 5 minutes
MAX_OUTPUT_SIZE = 1 * 1024 * 1024  # 1 MB
MAX_MEMORY_MB = 2048  # 2 GB


class BashCapability(BaseCapability):
    """Execute shell commands with timeout, env sanitization, and resource limits."""

    name: ClassVar[str] = "bash"
    description: ClassVar[str] = "Execute shell commands on the device"

    def __init__(self, blocked_env_vars: list[str] | None = None) -> None:
        self._blocked_env_vars = blocked_env_vars or []
        self._shell_path = self._find_shell()

    def _find_shell(self) -> str | None:
        """Locate a usable shell binary."""
        if sys.platform == "win32":
            return shutil.which("cmd") or shutil.which("powershell")
        return shutil.which("bash") or shutil.which("sh")

    def is_available(self) -> bool:
        """Shell is available if we can find a shell binary."""
        return self._shell_path is not None

    def get_metadata(self) -> dict[str, Any]:
        base = super().get_metadata()
        base["shell"] = self._shell_path
        base["platform"] = sys.platform
        base["max_timeout"] = MAX_TIMEOUT
        return base

    def _sanitize_env(self) -> dict[str, str]:
        """Build an environment dict with sensitive variables removed."""
        env = dict(os.environ)
        removed: list[str] = []
        for key in list(env.keys()):
            key_upper = key.upper()
            for blocked in self._blocked_env_vars:
                if blocked.upper() in key_upper or key_upper in blocked.upper():
                    del env[key]
                    removed.append(key)
                    break
        if removed:
            logger.debug("Stripped %d env vars for bash execution", len(removed))
        return env

    def _apply_resource_limits(self) -> None:
        """Apply resource limits to subprocess (Unix only)."""
        if sys.platform == "win32":
            return
        import resource

        mem_bytes = MAX_MEMORY_MB * 1024 * 1024
        try:
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        except (ValueError, resource.error):
            pass
        try:
            resource.setrlimit(resource.RLIMIT_CPU, (MAX_TIMEOUT, MAX_TIMEOUT + 10))
        except (ValueError, resource.error):
            pass
        try:
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except (ValueError, resource.error):
            pass

    async def execute(self, action: str, params: dict[str, Any]) -> CapabilityResult:
        """Execute a bash action.

        Supported actions:
          - "run": execute a shell command
        """
        if action == "run":
            return await self._run(params)
        return CapabilityResult(
            success=False,
            error=f"Unknown bash action: {action}",
            exit_code=1,
        )

    async def _run(self, params: dict[str, Any]) -> CapabilityResult:
        """Run a shell command with timeout and resource limits."""
        command = params.get("command", "")
        if not command:
            return CapabilityResult(success=False, error="No command provided", exit_code=1)

        timeout = min(params.get("timeout", 60), MAX_TIMEOUT)
        working_dir = params.get("working_directory")
        env = self._sanitize_env()
        preexec = self._apply_resource_limits if sys.platform != "win32" else None

        start = time.monotonic()

        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env=env,
                    cwd=working_dir,
                    preexec_fn=preexec,
                ),
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    asyncio.get_event_loop().run_in_executor(
                        None, lambda: proc.communicate()
                    ),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._kill_tree(proc)
                return CapabilityResult(
                    success=False,
                    error=f"Command timed out after {timeout}s",
                    exit_code=-1,
                    duration=time.monotonic() - start,
                )

            duration = time.monotonic() - start
            stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]
            stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]

            return CapabilityResult(
                success=proc.returncode == 0,
                output=stdout,
                error=stderr,
                exit_code=proc.returncode or 0,
                duration=duration,
            )

        except FileNotFoundError:
            return CapabilityResult(
                success=False,
                error="Shell not found",
                exit_code=127,
                duration=time.monotonic() - start,
            )
        except Exception as exc:
            return CapabilityResult(
                success=False,
                error=f"Execution failed: {exc}",
                exit_code=1,
                duration=time.monotonic() - start,
            )

    def _kill_tree(self, proc: subprocess.Popen[bytes]) -> None:
        """Kill a process and all its children."""
        try:
            parent = psutil.Process(proc.pid)
            children = parent.children(recursive=True)
            for child in children:
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            parent.kill()
            proc.wait(timeout=5)
        except (psutil.NoSuchProcess, subprocess.TimeoutExpired, OSError):
            try:
                proc.kill()
            except OSError:
                pass
