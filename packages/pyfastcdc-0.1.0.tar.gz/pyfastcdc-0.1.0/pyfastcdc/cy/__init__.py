from pyfastcdc.cy.fastcdc import FastCDC

__all__ = [
	'FastCDC',
]
