from pyfastcdc.py.fastcdc import FastCDC

__all__ = [
	'FastCDC',
]
