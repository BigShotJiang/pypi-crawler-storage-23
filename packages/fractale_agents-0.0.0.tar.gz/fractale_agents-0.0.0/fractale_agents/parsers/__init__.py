from .logs import ResultParserAgent
