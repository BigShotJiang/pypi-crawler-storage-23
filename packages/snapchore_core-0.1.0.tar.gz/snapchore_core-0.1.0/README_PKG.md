# snapchore-core

Cryptographic integrity for stateful events — hash, chain, verify.

SnapChore Core is the local hashing library for the SmartBlocks protocol. It provides deterministic, content-addressed block creation with zero network dependencies.

## Install

```bash
pip install snapchore-core
```

Optional extras:

```bash
pip install snapchore-core[image]   # Pillow for image metadata extraction
pip install snapchore-core[device]  # Device capture utilities
```

## Quick start

```python
from snapchore import SmartBlock, SnapChoreChain

# Seal a single event
block = SmartBlock(domain="ai.inference", payload={"tokens": 1500})
block.seal()
assert block.verify()

# Chain multiple events into a tamper-evident ledger
chain = SnapChoreChain()
chain.append(block)

block2 = SmartBlock(domain="ai.inference", payload={"tokens": 2300})
block2.seal()
chain.append(block2)
assert chain.verify()
```

### Lower-level API

```python
from snapchore import snapchore_capture, snapchore_verify

data = {"model": "gpt-4", "tokens": 1500}
h = snapchore_capture(data)
assert snapchore_verify(data, h)
```

## What it does

- **Canonical serialization** — deterministic JSON surface with float quantization and stable timestamps
- **SmartBlock** — content-addressed container with domain tagging and metadata
- **SnapChoreChain** — linked hash ledger for tamper-evident event sequences
- **Capture / Verify** — convenience functions for one-shot hashing and verification

## Relationship to sbn-sdk

`snapchore-core` handles local computation (hashing, chaining, verification) with no network calls. To submit blocks to the SmartBlocks Network, use the [sbn-sdk](https://pypi.org/project/sbn-sdk/) which includes a `SnapChoreClient` for server-side sealing, discovery, and chain management.

## License

Apache-2.0
