# core/snapchore/snapchore.py
from __future__ import annotations

import copy
import logging
from typing import Dict, Iterable, Optional

from .serialize import snapchore_hash, CANON_VERSION, VOLATILE_DEFAULT

logger = logging.getLogger(__name__)

def freeze_for_snap(data: Dict, *, volatile: Iterable[str] | None = None) -> Dict:
    """
    Return a deep-copied, sanitized dict suitable for SnapChore hashing:
      - strips known volatile keys at the top level and under 'metadata'
      - does NOT mutate the original object
    """
    cleaned = copy.deepcopy(data)
    vol = set(VOLATILE_DEFAULT)
    if volatile:
        vol.update(volatile)

    # Strip at top level
    for k in list(cleaned.keys()):
        if k in vol:
            cleaned.pop(k, None)

    # Strip under metadata if present
    if isinstance(cleaned.get("metadata"), dict):
        for k in list(cleaned["metadata"].keys()):
            if k in vol:
                cleaned["metadata"].pop(k, None)

    return cleaned


def snapchore_capture(data: Dict, *, volatile: Iterable[str] | None = None) -> Optional[str]:
    """
    Compute the SnapChore hash for a dict *without* mutating it.
    Any request flags (e.g., 'add_snapchore_hash') and other volatile keys are ignored,
    guaranteeing idempotent capture.
    """
    try:
        frozen = freeze_for_snap(data, volatile=volatile)
        h = snapchore_hash(frozen)
        logger.info("SnapChore hash generated: %s", h)
        return h
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError) as e:
        # ValueError: non-finite floats, nesting depth exceeded
        # TypeError: unhashable/unserializable payload contents
        # KeyError: unexpected missing fields during canonicalization
        # AttributeError: malformed nested structures
        # RecursionError: pathological nesting despite depth guard
        logger.error("Failed to generate snapchore hash: %s", e)
        return None


def snapchore_verify(data: Dict, expected_hash: str, *, volatile: Iterable[str] | None = None) -> bool:
    """
    Recompute the canonical hash (with the same volatile-stripping) and compare to the expected one.
    """
    try:
        frozen = freeze_for_snap(data, volatile=volatile)
        actual = snapchore_hash(frozen)
        ok = (actual == expected_hash)
        if ok:
            logger.info("SnapChore verification passed for hash: %s", expected_hash)
        else:
            logger.warning("SnapChore verification failed: expected %s, got %s", expected_hash, actual)
        return ok
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError) as e:
        logger.error("Failed to verify snapchore hash: %s", e)
        return False


def snapchore_envelope(payload: Dict, *, volatile: Iterable[str] | None = None) -> Dict:
    """
    Non-mutating convenience that returns:
      { "payload": <original>, "snapchore": { "hash": "...", "canon_version": "..." } }
    Caller can persist the envelope while keeping the hashed surface separate.
    """
    h = snapchore_capture(payload, volatile=volatile)
    return {
        "payload": payload,
        "snapchore": {"hash": h, "canon_version": CANON_VERSION},
    }
