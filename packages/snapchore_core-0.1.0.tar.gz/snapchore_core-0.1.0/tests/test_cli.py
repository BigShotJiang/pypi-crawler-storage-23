"""Tests for core.snapchore.cli — command-line interface."""

from __future__ import annotations

import json
import os
import tempfile

import pytest

from core.snapchore.cli import main


class TestCliHash:
    def test_hash_inline_json(self, capsys):
        rc = main(["hash", '{"model": "gpt-4", "tokens": 1500}'])
        assert rc == 0
        out = capsys.readouterr().out.strip()
        assert len(out) == 64

    def test_hash_json_output(self, capsys):
        rc = main(["hash", "--json", '{"x": 1}'])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert "hash" in data
        assert "canon_version" in data

    def test_hash_from_file(self, capsys, tmp_path):
        f = tmp_path / "input.json"
        f.write_text('{"file": true}')
        rc = main(["hash", str(f)])
        assert rc == 0
        out = capsys.readouterr().out.strip()
        assert len(out) == 64


class TestCliSeal:
    def test_seal_stdout(self, capsys):
        rc = main(["seal", '{"payload": "test"}'])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert "snapchore_hash" in data
        assert data["domain"] == "general"

    def test_seal_custom_domain(self, capsys):
        rc = main(["seal", "--domain", "ai.inference", '{"tokens": 1500}'])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["domain"] == "ai.inference"

    def test_seal_to_file(self, capsys, tmp_path):
        outfile = tmp_path / "block.json"
        rc = main(["seal", "-o", str(outfile), '{"x": 1}'])
        assert rc == 0
        assert outfile.exists()
        data = json.loads(outfile.read_text())
        assert "snapchore_hash" in data


class TestCliVerify:
    def test_verify_valid(self, capsys):
        # First get a hash
        rc = main(["hash", '{"data": "test"}'])
        h = capsys.readouterr().out.strip()

        rc = main(["verify", '{"data": "test"}', h])
        assert rc == 0
        assert "VALID" in capsys.readouterr().out

    def test_verify_invalid(self, capsys):
        rc = main(["verify", '{"data": "test"}', "0" * 64])
        assert rc == 1
        assert "INVALID" in capsys.readouterr().out

    def test_verify_json_output(self, capsys):
        rc = main(["hash", '{"k": "v"}'])
        h = capsys.readouterr().out.strip()

        rc = main(["verify", "--json", '{"k": "v"}', h])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["valid"] is True


class TestCliVerifyBlock:
    def test_verify_sealed_block(self, capsys, tmp_path):
        # Seal a block to file
        outfile = tmp_path / "block.json"
        main(["seal", "-o", str(outfile), '{"x": 1}'])
        capsys.readouterr()  # clear

        rc = main(["verify-block", str(outfile)])
        assert rc == 0
        assert "VALID" in capsys.readouterr().out

    def test_verify_tampered_block(self, capsys, tmp_path):
        outfile = tmp_path / "block.json"
        main(["seal", "-o", str(outfile), '{"x": 1}'])
        capsys.readouterr()

        # Tamper
        data = json.loads(outfile.read_text())
        data["payload"]["x"] = 999
        outfile.write_text(json.dumps(data))

        rc = main(["verify-block", str(outfile)])
        assert rc == 1
        assert "INVALID" in capsys.readouterr().out


class TestCliChain:
    def test_create_chain(self, capsys, tmp_path):
        outfile = tmp_path / "test.chain.json"
        rc = main(["chain", "create", "-o", str(outfile)])
        assert rc == 0
        assert outfile.exists()
        data = json.loads(outfile.read_text())
        assert data["length"] == 0

    def test_append_and_verify(self, capsys, tmp_path):
        chain_file = tmp_path / "chain.json"
        main(["chain", "create", "-o", str(chain_file)])
        capsys.readouterr()

        # Append two entries
        main(["chain", "append", str(chain_file), "hash_aaa"])
        main(["chain", "append", str(chain_file), "hash_bbb"])
        capsys.readouterr()

        # Verify
        rc = main(["chain", "verify", str(chain_file)])
        assert rc == 0
        assert "VALID" in capsys.readouterr().out

    def test_show_chain(self, capsys, tmp_path):
        chain_file = tmp_path / "chain.json"
        main(["chain", "create", "-o", str(chain_file)])
        main(["chain", "append", str(chain_file), "hash_x"])
        capsys.readouterr()

        rc = main(["chain", "show", str(chain_file)])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["length"] == 1

    def test_verify_json_output(self, capsys, tmp_path):
        chain_file = tmp_path / "chain.json"
        main(["chain", "create", "-o", str(chain_file)])
        main(["chain", "append", str(chain_file), "h1"])
        capsys.readouterr()

        rc = main(["chain", "verify", "--json", str(chain_file)])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["valid"] is True
        assert data["length"] == 1


class TestCliVersion:
    def test_version_flag(self, capsys):
        rc = main(["--version"])
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert "snapchore" in data
        assert "canon_version" in data


class TestCliNoArgs:
    def test_no_args_prints_help(self, capsys):
        rc = main([])
        assert rc == 0
