"""Tests for core.snapchore.serialize — canonical hashing primitives."""

from __future__ import annotations

import math
from datetime import datetime, timezone

import pytest

from core.snapchore.serialize import (
    CANON_VERSION,
    canonical_serialize,
    canonical_surface,
    snapchore_hash,
    quantize_float,
    stable_timestamp,
    parse_iso8601_to_canonical,
)


# ---------------------------------------------------------------------------
# stable_timestamp
# ---------------------------------------------------------------------------

class TestStableTimestamp:
    def test_utc_format(self):
        dt = datetime(2026, 1, 15, 10, 30, 45, tzinfo=timezone.utc)
        assert stable_timestamp(dt) == "20260115T103045Z"

    def test_strips_microseconds(self):
        dt = datetime(2026, 1, 15, 10, 30, 45, 123456, tzinfo=timezone.utc)
        assert stable_timestamp(dt) == "20260115T103045Z"

    def test_naive_assumed_utc(self):
        dt = datetime(2026, 6, 1, 0, 0, 0)
        result = stable_timestamp(dt)
        assert result.endswith("Z")


# ---------------------------------------------------------------------------
# quantize_float
# ---------------------------------------------------------------------------

class TestQuantizeFloat:
    def test_rounds_deterministically(self):
        assert quantize_float(3.14159265358979) == 3.14159265359

    def test_int_to_float(self):
        assert quantize_float(42) == 42.0
        assert isinstance(quantize_float(42), float)

    def test_none_passthrough(self):
        assert quantize_float(None) is None  # type: ignore[arg-type]

    def test_nan_raises(self):
        with pytest.raises(ValueError, match="Non-finite"):
            quantize_float(float("nan"))

    def test_inf_raises(self):
        with pytest.raises(ValueError, match="Non-finite"):
            quantize_float(float("inf"))

    def test_custom_places(self):
        result = quantize_float(3.14159, places=2)
        assert result == 3.14


# ---------------------------------------------------------------------------
# canonical_serialize
# ---------------------------------------------------------------------------

class TestCanonicalSerialize:
    def test_sorted_keys(self):
        result = canonical_serialize({"b": 2, "a": 1})
        assert result == '{"a":1,"b":2}'

    def test_minimal_separators(self):
        result = canonical_serialize({"key": "value"})
        assert " " not in result

    def test_deterministic(self):
        data = {"z": 1, "a": 2, "m": [3, 4]}
        assert canonical_serialize(data) == canonical_serialize(data)


# ---------------------------------------------------------------------------
# canonical_surface
# ---------------------------------------------------------------------------

class TestCanonicalSurface:
    def test_injects_canon_version(self):
        surface = canonical_surface({"x": 1})
        assert CANON_VERSION.encode() in surface

    def test_strips_default_volatile(self):
        data = {"real": "data", "snap_hash": "should_be_gone", "signature": "gone_too"}
        surface = canonical_surface(data)
        assert b"snap_hash" not in surface
        assert b"signature" not in surface
        assert b"real" in surface

    def test_custom_volatile(self):
        data = {"keep": 1, "drop_me": 2}
        surface = canonical_surface(data, volatile={"drop_me"})
        assert b"drop_me" not in surface
        assert b"keep" in surface

    def test_deep_copy_no_mutation(self):
        data = {"nested": {"key": "val", "signature": "secret"}}
        canonical_surface(data)
        # Original should be unmodified
        assert "signature" in data["nested"]

    def test_returns_bytes(self):
        result = canonical_surface({"a": 1})
        assert isinstance(result, bytes)


# ---------------------------------------------------------------------------
# snapchore_hash
# ---------------------------------------------------------------------------

class TestSnapchoreHash:
    def test_hex_sha256(self):
        h = snapchore_hash({"test": True})
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)

    def test_deterministic(self):
        data = {"model": "gpt-4", "tokens": 1500}
        assert snapchore_hash(data) == snapchore_hash(data)

    def test_different_data_different_hash(self):
        h1 = snapchore_hash({"a": 1})
        h2 = snapchore_hash({"a": 2})
        assert h1 != h2

    def test_key_order_irrelevant(self):
        h1 = snapchore_hash({"a": 1, "b": 2})
        h2 = snapchore_hash({"b": 2, "a": 1})
        assert h1 == h2

    def test_volatile_keys_ignored(self):
        h1 = snapchore_hash({"data": 1})
        h2 = snapchore_hash({"data": 1, "signature": "abc"})
        assert h1 == h2


# ---------------------------------------------------------------------------
# parse_iso8601_to_canonical
# ---------------------------------------------------------------------------

class TestParseIso8601:
    def test_zulu(self):
        result = parse_iso8601_to_canonical("2026-01-15T10:30:45Z")
        assert result == "20260115T103045Z"

    def test_offset(self):
        result = parse_iso8601_to_canonical("2026-01-15T10:30:45+00:00")
        assert result == "20260115T103045Z"
