"""Tests for core.snapchore.snapchore — capture, verify, envelope, freeze."""

from __future__ import annotations

from core.snapchore.snapchore import (
    snapchore_capture,
    snapchore_verify,
    snapchore_envelope,
    freeze_for_snap,
)
from core.snapchore.serialize import CANON_VERSION


class TestFreezeForSnap:
    def test_strips_volatile_keys(self):
        data = {"real": 1, "snap_hash": "x", "signature": "y", "nonce": "z"}
        frozen = freeze_for_snap(data)
        assert "real" in frozen
        assert "snap_hash" not in frozen
        assert "signature" not in frozen
        assert "nonce" not in frozen

    def test_strips_under_metadata(self):
        data = {"payload": 1, "metadata": {"snap_hash": "x", "tag": "keep"}}
        frozen = freeze_for_snap(data)
        assert "snap_hash" not in frozen["metadata"]
        assert frozen["metadata"]["tag"] == "keep"

    def test_deep_copy_no_mutation(self):
        data = {"nested": {"key": "val"}}
        frozen = freeze_for_snap(data)
        frozen["nested"]["key"] = "changed"
        assert data["nested"]["key"] == "val"

    def test_custom_volatile(self):
        data = {"keep": 1, "custom_vol": 2}
        frozen = freeze_for_snap(data, volatile={"custom_vol"})
        assert "custom_vol" not in frozen
        assert "keep" in frozen


class TestSnapchoreCapture:
    def test_returns_hash(self):
        h = snapchore_capture({"model": "gpt-4", "tokens": 1500})
        assert h is not None
        assert len(h) == 64

    def test_deterministic(self):
        data = {"a": 1, "b": [2, 3]}
        assert snapchore_capture(data) == snapchore_capture(data)

    def test_ignores_volatile_keys(self):
        h1 = snapchore_capture({"data": 1})
        h2 = snapchore_capture({"data": 1, "snap_hash": "noise", "nonce": "abc"})
        assert h1 == h2

    def test_empty_dict(self):
        h = snapchore_capture({})
        assert h is not None


class TestSnapchoreVerify:
    def test_valid(self):
        data = {"model": "gpt-4", "tokens": 1500}
        h = snapchore_capture(data)
        assert snapchore_verify(data, h)

    def test_invalid_wrong_hash(self):
        data = {"model": "gpt-4", "tokens": 1500}
        assert not snapchore_verify(data, "0" * 64)

    def test_invalid_modified_data(self):
        data = {"amount": 100}
        h = snapchore_capture(data)
        data["amount"] = 999
        assert not snapchore_verify(data, h)

    def test_volatile_keys_dont_affect_verify(self):
        data = {"real": "data"}
        h = snapchore_capture(data)
        # Add volatile keys — should still verify
        data["snap_hash"] = "something"
        data["signature"] = "something_else"
        assert snapchore_verify(data, h)


class TestSnapchoreEnvelope:
    def test_structure(self):
        data = {"key": "value"}
        env = snapchore_envelope(data)
        assert "payload" in env
        assert "snapchore" in env
        assert env["snapchore"]["canon_version"] == CANON_VERSION
        assert env["snapchore"]["hash"] is not None

    def test_payload_is_original(self):
        data = {"key": "value"}
        env = snapchore_envelope(data)
        assert env["payload"] is data  # Same reference (not copied)

    def test_hash_matches_capture(self):
        data = {"model": "gpt-4"}
        env = snapchore_envelope(data)
        direct_hash = snapchore_capture(data)
        assert env["snapchore"]["hash"] == direct_hash
