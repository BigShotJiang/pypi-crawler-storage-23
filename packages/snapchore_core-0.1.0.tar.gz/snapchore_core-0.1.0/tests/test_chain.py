"""Tests for core.snapchore.chain — SnapChoreChain linked hash ledger."""

from __future__ import annotations

import pytest

from core.snapchore.block import SmartBlock
from core.snapchore.chain import SnapChoreChain, ChainEntry


class TestChainCreate:
    def test_default_id(self):
        c = SnapChoreChain()
        assert c.chain_id  # UUID generated
        assert len(c) == 0

    def test_custom_id(self):
        c = SnapChoreChain(chain_id="my-chain")
        assert c.chain_id == "my-chain"

    def test_head_empty(self):
        c = SnapChoreChain()
        assert c.head is None
        assert c.head_hash is None


class TestChainAppend:
    def test_append_block(self):
        chain = SnapChoreChain()
        block = SmartBlock(payload={"x": 1})
        block.seal()

        entry = chain.append(block)
        assert entry.index == 0
        assert entry.block_hash == block.snapchore_hash
        assert entry.block_id == block.id
        assert entry.previous_chain_hash is None
        assert len(chain) == 1

    def test_append_links_to_previous(self):
        chain = SnapChoreChain()

        b1 = SmartBlock(payload={"seq": 1})
        b1.seal()
        e1 = chain.append(b1)

        b2 = SmartBlock(payload={"seq": 2})
        b2.seal()
        e2 = chain.append(b2)

        assert e2.previous_chain_hash == e1.chain_hash
        assert e2.index == 1

    def test_append_unsealed_raises(self):
        chain = SnapChoreChain()
        block = SmartBlock(payload={"x": 1})
        with pytest.raises(ValueError, match="sealed"):
            chain.append(block)

    def test_append_raw(self):
        chain = SnapChoreChain()
        entry = chain.append_raw(block_hash="abc123", event_type="test")
        assert entry.block_hash == "abc123"
        assert entry.event_type == "test"
        assert len(chain) == 1

    def test_head_after_append(self):
        chain = SnapChoreChain()
        b = SmartBlock(payload={"x": 1})
        b.seal()
        chain.append(b)
        assert chain.head is not None
        assert chain.head_hash == chain[0].chain_hash


class TestChainVerify:
    def _build_chain(self, n: int = 3) -> SnapChoreChain:
        chain = SnapChoreChain()
        for i in range(n):
            b = SmartBlock(payload={"seq": i})
            b.seal()
            chain.append(b)
        return chain

    def test_verify_valid(self):
        chain = self._build_chain(5)
        assert chain.verify()

    def test_verify_empty(self):
        chain = SnapChoreChain()
        assert chain.verify()

    def test_verify_single_entry(self):
        chain = self._build_chain(1)
        assert chain.verify()

    def test_verify_detects_tamper(self):
        chain = self._build_chain(3)
        # Tamper with middle entry's block_hash
        chain[1].block_hash = "tampered_hash"
        assert not chain.verify()

    def test_find_break_returns_index(self):
        chain = self._build_chain(5)
        # Tamper with entry 2
        chain[2].block_hash = "tampered"
        break_at = chain.find_break()
        assert break_at == 2

    def test_find_break_intact(self):
        chain = self._build_chain(3)
        assert chain.find_break() is None


class TestChainSerialization:
    def test_to_dict(self):
        chain = SnapChoreChain(chain_id="test-chain")
        b = SmartBlock(payload={"x": 1})
        b.seal()
        chain.append(b)

        d = chain.to_dict()
        assert d["chain_id"] == "test-chain"
        assert d["length"] == 1
        assert d["head_hash"] is not None
        assert len(d["entries"]) == 1

    def test_from_dict_roundtrip(self):
        chain = SnapChoreChain()
        for i in range(3):
            b = SmartBlock(payload={"i": i})
            b.seal()
            chain.append(b)

        d = chain.to_dict()
        chain2 = SnapChoreChain.from_dict(d)

        assert chain2.chain_id == chain.chain_id
        assert len(chain2) == len(chain)
        assert chain2.head_hash == chain.head_hash
        assert chain2.verify()

    def test_from_dict_invalid_hash_raises(self):
        chain = SnapChoreChain()
        b = SmartBlock(payload={"x": 1})
        b.seal()
        chain.append(b)

        d = chain.to_dict()
        # Corrupt the stored chain_hash
        d["entries"][0]["chain_hash"] = "bad_hash"
        with pytest.raises(ValueError, match="Chain hash mismatch"):
            SnapChoreChain.from_dict(d)


class TestChainEntryToDict:
    def test_entry_fields(self):
        entry = ChainEntry(
            index=0,
            event_type="block_sealed",
            block_hash="abc123",
            previous_chain_hash=None,
            block_id="block-001",
            metadata={"source": "test"},
        )
        d = entry.to_dict()
        assert d["index"] == 0
        assert d["block_hash"] == "abc123"
        assert d["previous_chain_hash"] is None
        assert d["block_id"] == "block-001"
        assert d["chain_hash"]  # computed
        assert d["timestamp"]


class TestChainRepr:
    def test_repr_empty(self):
        c = SnapChoreChain()
        r = repr(c)
        assert "empty" in r

    def test_repr_with_entries(self):
        c = SnapChoreChain()
        c.append_raw(block_hash="abc")
        r = repr(c)
        assert "len=1" in r
