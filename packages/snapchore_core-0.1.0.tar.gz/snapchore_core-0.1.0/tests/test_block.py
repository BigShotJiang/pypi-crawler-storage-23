"""Tests for core.snapchore.block — SmartBlock container."""

from __future__ import annotations

import json

import pytest

from core.snapchore.block import SmartBlock


class TestSmartBlockCreation:
    def test_default_fields(self):
        b = SmartBlock()
        assert b.domain == "general"
        assert b.block_type == "event"
        assert b.payload == {}
        assert b.metadata == {}
        assert b.metrics == {}
        assert b.snapchore_hash is None
        assert not b.sealed
        assert b.id  # UUID generated

    def test_custom_fields(self):
        b = SmartBlock(
            domain="ai.inference",
            block_type="completion",
            payload={"tokens": 1500},
            metadata={"model": "gpt-4"},
            metrics={"latency_ms": 200},
        )
        assert b.domain == "ai.inference"
        assert b.block_type == "completion"
        assert b.payload["tokens"] == 1500


class TestSmartBlockSeal:
    def test_seal_produces_hash(self):
        b = SmartBlock(payload={"x": 1})
        h = b.seal()
        assert h is not None
        assert len(h) == 64
        assert b.sealed
        assert b.snapchore_hash == h

    def test_seal_idempotent(self):
        b = SmartBlock(payload={"x": 1})
        h1 = b.seal()
        h2 = b.seal()
        assert h1 == h2

    def test_seal_deterministic_for_same_content(self):
        b1 = SmartBlock(
            domain="test",
            payload={"val": 42},
            block_id="same-id",
            created_at="2026-01-01T00:00:00+00:00",
        )
        b2 = SmartBlock(
            domain="test",
            payload={"val": 42},
            block_id="same-id",
            created_at="2026-01-01T00:00:00+00:00",
        )
        assert b1.seal() == b2.seal()


class TestSmartBlockVerify:
    def test_verify_valid(self):
        b = SmartBlock(payload={"important": "data"})
        b.seal()
        assert b.verify()

    def test_verify_fails_on_tamper(self):
        b = SmartBlock(payload={"amount": 100})
        b.seal()
        # Tamper with the payload directly
        b.payload["amount"] = 999
        assert not b.verify()

    def test_verify_unsealed_returns_false(self):
        b = SmartBlock(payload={"x": 1})
        assert not b.verify()


class TestSmartBlockSerialization:
    def test_to_dict(self):
        b = SmartBlock(domain="test", payload={"k": "v"})
        b.seal()
        d = b.to_dict()
        assert d["domain"] == "test"
        assert d["payload"] == {"k": "v"}
        assert "snapchore_hash" in d
        assert "id" in d

    def test_from_dict_roundtrip(self):
        b1 = SmartBlock(domain="test", payload={"roundtrip": True})
        b1.seal()
        d = b1.to_dict()

        b2 = SmartBlock.from_dict(d)
        assert b2.id == b1.id
        assert b2.domain == b1.domain
        assert b2.snapchore_hash == b1.snapchore_hash
        assert b2.sealed
        assert b2.verify()

    def test_to_dict_deep_copies(self):
        b = SmartBlock(payload={"nested": {"a": 1}})
        b.seal()
        d = b.to_dict()
        d["payload"]["nested"]["a"] = 999
        # Original block should be unaffected
        assert b.payload["nested"]["a"] == 1


class TestSmartBlockMutation:
    def test_update_metrics_unsealed(self):
        b = SmartBlock()
        b.update_metrics(score=0.95)
        assert b.metrics["score"] == 0.95

    def test_update_metrics_sealed_raises(self):
        b = SmartBlock(payload={"x": 1})
        b.seal()
        with pytest.raises(RuntimeError, match="Cannot modify"):
            b.update_metrics(score=0.95)

    def test_add_metadata_unsealed(self):
        b = SmartBlock()
        b.add_metadata(tag="important")
        assert b.metadata["tag"] == "important"

    def test_add_metadata_sealed_raises(self):
        b = SmartBlock(payload={"x": 1})
        b.seal()
        with pytest.raises(RuntimeError, match="Cannot modify"):
            b.add_metadata(tag="important")


class TestSmartBlockRepr:
    def test_repr_unsealed(self):
        b = SmartBlock(domain="test")
        r = repr(b)
        assert "unsealed" in r
        assert "test" in r

    def test_repr_sealed(self):
        b = SmartBlock(domain="test", payload={"x": 1})
        b.seal()
        r = repr(b)
        assert "sealed" in r
