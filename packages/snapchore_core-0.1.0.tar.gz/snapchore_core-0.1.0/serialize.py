# core/snapchore/serialize.py
from __future__ import annotations

import json
import math
import decimal
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Iterable

CANON_VERSION = "SVP-1.0"

# Fields that must NEVER participate in the hashed surface.
# This is the SINGLE source of truth for volatile keys — all modules
# that need the volatile set should import it from here.
VOLATILE_DEFAULT: frozenset[str] = frozenset({
    # Hash / integrity fields (self-referential if included)
    "snap_hash",
    "hash",
    "add_snapchore_hash",
    "post_metrics_snap_hash",
    # Signatures & attestations
    "signature",
    "signatures",
    "sig",
    "attestation",
    "attestations",
    "attestation_sig",
    # Temporal fields (raw wallclock — never hash these)
    "created_at",
    "updated_at",
    "timestamp",
    "time",
    "ts",
    # Nonces & audit tags
    "nonce",
    "audit_snapchore",
    # Raw device telemetry (moment hash is the authenticated proxy)
    "snapchore_context",
    # Audit record of moment-auth checks — not for hashing, the
    # stable proxy is metadata.snapchore_moment_hash
    "snapchore_validation",
})

def stable_timestamp(dt: datetime) -> str:
    """UTC Zulu, second precision, stable formatting."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y%m%dT%H%M%SZ")

def parse_iso8601_to_canonical(ts: str) -> str:
    """
    Accepts many ISO8601 variants and emits stable Zulu stamp.
    """
    s = ts.replace("Z", "+00:00") if isinstance(ts, str) else ts
    from datetime import datetime as _dt
    try:
        dt = _dt.fromisoformat(s)
    except Exception:
        # Fallback for strings without tz / millis
        dt = _dt.strptime(str(ts)[:19], "%Y-%m-%dT%H:%M:%S")
        dt = dt.replace(tzinfo=timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return stable_timestamp(dt)

def quantize_float(x: float, places: int = 12) -> float:
    """
    Deterministic float rounding to avoid platform drift.
    """
    if x is None:
        return None  # type: ignore[return-value]
    if isinstance(x, int):
        return float(x)
    if math.isnan(x) or math.isinf(x):
        raise ValueError("Non-finite float in canonical payload")
    q = decimal.Decimal(str(x)).quantize(
        decimal.Decimal(10) ** -places, rounding=decimal.ROUND_HALF_UP
    )
    return float(q)

MAX_NESTING_DEPTH = 50


def _scrub(o: Any, volatile: Iterable[str], *, _depth: int = 0) -> Any:
    """
    Remove volatile keys from dicts (deep).
    """
    if _depth > MAX_NESTING_DEPTH:
        raise ValueError(f"Payload nesting exceeds maximum depth of {MAX_NESTING_DEPTH}")
    if isinstance(o, dict):
        return {k: _scrub(v, volatile, _depth=_depth + 1) for k, v in o.items() if k not in volatile}
    if isinstance(o, list):
        return [_scrub(v, volatile, _depth=_depth + 1) for v in o]
    return o

def _normalize(o: Any, *, _depth: int = 0) -> Any:
    """
    Normalize floats, datetimes, and timestamps (if present as strings).

    Note: ``timestamp``, ``created_at``, and ``updated_at`` are in
    VOLATILE_DEFAULT and normally stripped by ``_scrub()`` before this
    runs.  The normalizations below are a safety net for two cases:
      1. A caller invokes ``_normalize()`` outside the ``canonical_surface``
         pipeline (standalone canonicalization).
      2. The volatile set is customized and these keys are retained — without
         normalization they would produce platform-dependent hashes.
    """
    if _depth > MAX_NESTING_DEPTH:
        raise ValueError(f"Payload nesting exceeds maximum depth of {MAX_NESTING_DEPTH}")
    if isinstance(o, datetime):
        # Convert datetime objects to stable timestamp string
        return stable_timestamp(o)
    if isinstance(o, float):
        return quantize_float(o)
    if isinstance(o, dict):
        out: Dict[str, Any] = {}
        for k, v in o.items():
            if k in {"timestamp", "created_at", "updated_at"} and isinstance(v, str):
                out[k] = parse_iso8601_to_canonical(v)
            else:
                out[k] = _normalize(v, _depth=_depth + 1)
        return out
    if isinstance(o, list):
        return [_normalize(v, _depth=_depth + 1) for v in o]
    return o

class _CanonicalEncoder(json.JSONEncoder):
    """JSON encoder that handles datetime objects that slip through normalization."""
    def default(self, o: Any) -> Any:
        if isinstance(o, datetime):
            return stable_timestamp(o)
        return super().default(o)

def canonical_serialize(obj: Any) -> str:
    """
    Stable JSON (sorted keys, minimal separators, UTF-8 safe).
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, cls=_CanonicalEncoder)

def canonical_surface(obj: Dict[str, Any], *, volatile: Iterable[str] | None = None) -> bytes:
    """
    Produce the exact bytes that are hashed by SnapChore:
    - deep copy
    - scrub volatile keys
    - normalize floats/timestamps
    - inject canon_version (if top-level dict)
    - stable JSON
    """
    vset = set(VOLATILE_DEFAULT) | set(volatile or ())
    x = deepcopy(obj)
    x = _scrub(x, vset)
    x = _normalize(x)
    if isinstance(x, dict):
        x.setdefault("canon_version", CANON_VERSION)
    return canonical_serialize(x).encode("utf-8")

def sha256_hex_bytes(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

def snapchore_hash(payload: Dict[str, Any], *, volatile: Iterable[str] | None = None) -> str:
    """
    Convenience: compute SnapChore hash over the canonical surface.
    """
    surface = canonical_surface(payload, volatile=volatile)
    return sha256_hex_bytes(surface)

__all__ = [
    "CANON_VERSION",
    "VOLATILE_DEFAULT",
    "stable_timestamp",
    "parse_iso8601_to_canonical",
    "quantize_float",
    "canonical_serialize",
    "canonical_surface",
    "snapchore_hash",
]
