# mhub_proxy

`mhub_proxy` is a local OpenAI-compatible proxy that lets CLI tools (for example, Opencode) send OpenAI-style requests to SecureGPT.

## Requirements:

`uv` is required to install and run the proxy.

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Or, using `pip`:

```bash
pip install uv
```
## Install `mhub_proxy`

Install as a `uv` tool:

```bash
uv tool install mhub_proxy
```

## Required environment variables

Before starting the proxy, define the variables used by `mhub_proxy/config.py`:

- `MHUB_API_URL` : URL of the Model Hub API
- `MHUB_CLIENT_ID` : Client ID for the Model Hub API
- `MHUB_CLIENT_SECRET` : Client Secret for the Model Hub API
- `ONEACCOUNT_LOGIN_URL` : URL of the OneAccount login API

Optional:

- `MHUB_PROXY_HOST` (default: `127.0.0.1`)
- `MHUB_PROXY_PORT` (default: `8123`)
- `MHUB_PROXY_LOG_LEVEL` (default: `info`)

## Run the proxy

Start the proxy with:

```bash
uvx mhub_proxy
```

By default, the proxy runs on `http://127.0.0.1:8123`.

## Use with Opencode

1. Add an `opencode.json` file to the root of your project.
2. Use the configuration in this repository as your example (`/opencode.json`).

**IMPORTANT: Notice how the API version is included in the model ID, e.g. `gpt-5.1-2025-11-13@2025-01-01-preview`.**
This is required for the proxy to correctly route requests to the Model Hub API.

3. Optionally: Install the OpenCode plugin (see below) in your project (`uvx mhub_proxy --install-plugin`).
4. Start Opencode from a terminal **inside your project directory**.

The included `opencode.json` points Opencode to the local proxy URL:

```json
"baseURL": "http://127.0.0.1:8123/openai"
```

When Opencode asks for an API key, you can enter any value.

Reference: [OpenCode plugin docs](https://opencode.ai/docs/plugins/#create-a-plugin)

## Install the OpenCode plugin

A plugin is included to automatically start the proxy when Opencode starts (if not started already).
Optionally, you may install the bundled plugin into your project:

```bash
uvx mhub_proxy --install-plugin
```

This copies plugin files into:

```text
<project_root>/.opencode/plugins
```

You can also install into a specific project root:

```bash
uvx mhub_proxy --install-plugin --project-root /path/to/project
```

## Notes

- The proxy expects OpenAI chat-completions style traffic from your CLI tool.
- If startup fails, first verify that all required environment variables are set.
- The installed OpenCode plugin checks proxy health at session start and will launch `uvx mhub_proxy` in the background when needed.