import time

import httpx
from fastapi import Request

from .config import oneaccount_login_url, mhub_client_id, mhub_client_secret

async def _authenticate(request: Request) -> None:
    """
    Authenticate with OneAccount and return the access token.
    """
    access_token = request.app.state.cached_auth_header
    token_expiry = request.app.state.cached_auth_expires_at
    if access_token and token_expiry > time.time():
        return access_token

    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    }
    payload = {
        "grant_type": "client_credentials",
        "client_id": mhub_client_id(),
        "client_secret": mhub_client_secret(),
        "scope": "urn:grp:chatgpt",
    }

    async with httpx.AsyncClient(verify=False) as client:
        response = await client.post(
            f"{oneaccount_login_url()}/as/token.oauth2",
            headers=headers,
            data=payload,
            timeout=15,
        )
    response.raise_for_status()
    response_json = response.json()
    access_token = response_json.get("access_token")
    request.app.state.cached_auth_header = access_token
    request.app.state.cached_auth_expires_at = time.time() + response_json.get(
        "expires_in"
    )
    return access_token
