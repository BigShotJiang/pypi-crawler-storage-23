import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI

from .proxy import router as proxy_router

@asynccontextmanager
async def lifespan(app_instance: FastAPI):

    app_instance.state.token_lock = asyncio.Lock()
    app_instance.state.cached_auth_header = ""
    app_instance.state.cached_auth_expires_at = 0.0
    try:
        yield
    finally:
        pass

app = FastAPI(title="SecureGPT MHUB Proxy", version="0.1.0", lifespan=lifespan)
app.include_router(proxy_router)
