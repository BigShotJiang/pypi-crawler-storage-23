import { spawn } from "node:child_process"

const PROXY_HOST = process.env.MHUB_PROXY_HOST || process.env.LLM_PROXY_HOST || "127.0.0.1"
const PROXY_PORT = process.env.MHUB_PROXY_PORT || process.env.LLM_PROXY_PORT || "8123"
const HEALTH_URL = `http://${PROXY_HOST}:${PROXY_PORT}/health`
const START_COMMAND = "uvx"
const START_ARGS = ["mhub_proxy"]
const STARTUP_WAIT_MS = Number(
  process.env.MHUB_PROXY_STARTUP_WAIT_MS || "800",
)
const STARTUP_CHECK_ATTEMPTS = Number(
  process.env.MHUB_PROXY_STARTUP_CHECK_ATTEMPTS || "8",
)

let launchAttempted = false

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function isProxyHealthy() {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 1200)

  try {
    const response = await fetch(HEALTH_URL, {
      method: "GET",
      signal: controller.signal,
    })
    return response.ok
  } catch {
    return false
  } finally {
    clearTimeout(timeout)
  }
}

function startProxyInBackground() {
  const child = spawn(START_COMMAND, START_ARGS, {
    detached: true,
    stdio: "ignore",
    shell: process.platform === "win32",
    windowsHide: true,
  })

  child.unref()
}

async function waitForProxyToBeHealthy() {
  await sleep(STARTUP_WAIT_MS)
  for (let attempt = 0; attempt < STARTUP_CHECK_ATTEMPTS; attempt += 1) {
    if (await isProxyHealthy()) {
      return true
    }
    await sleep(STARTUP_WAIT_MS)
  }
  return false
}

export const MhubProxyAutostartPlugin = async ({ client }) => {
  return {
    event: async ({ event }) => {
      if (event.type !== "session.created" || launchAttempted) {
        return
      }

      const healthy = await isProxyHealthy()
      if (healthy) {
        return
      }

      launchAttempted = true
      startProxyInBackground()
      const started = await waitForProxyToBeHealthy()

      await client.app.log({
        body: {
          service: "mhub-proxy-autostart",
          level: started ? "info" : "warn",
          message: started
            ? "mhub_proxy was started in the background and is now healthy."
            : "mhub_proxy was started in the background but did not become healthy in time.",
          extra: {
            healthUrl: HEALTH_URL,
            command: [START_COMMAND, ...START_ARGS].join(" "),
            startupWaitMs: STARTUP_WAIT_MS,
            startupCheckAttempts: STARTUP_CHECK_ATTEMPTS,
          },
        },
      })
    },
  }
}
