import argparse
from importlib import resources
from pathlib import Path
import uvicorn

from .config import verify_config, log_level, host, port

# def setup_logging() -> None:
#    file_handler = logging.FileHandler("mhub_proxy.log")
#    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
#    root_logger = logging.getLogger("mhub_proxy.requests")
#    root_logger.addHandler(file_handler)
#    root_logger.setLevel(log_level().upper())


def _copy_plugin_dir(project_root: Path) -> list[Path]:
    source_plugins = resources.files("mhub_proxy").joinpath(".opencode").joinpath("plugins")
    destination_plugins = project_root / ".opencode" / "plugins"
    destination_plugins.mkdir(parents=True, exist_ok=True)

    copied_files: list[Path] = []
    for entry in source_plugins.iterdir():
        if not entry.is_file():
            continue

        destination = destination_plugins / entry.name
        destination.write_bytes(entry.read_bytes())
        copied_files.append(destination)
    
    source_config = resources.files("mhub_proxy").joinpath("opencode.json")
    destination_config = project_root / "opencode.json"
    destination_config.write_bytes(source_config.read_bytes())
    copied_files.append(destination_config)

    return copied_files


def main() -> None:
    parser = argparse.ArgumentParser(prog="mhub_proxy")
    parser.add_argument(
        "--install-plugin",
        action="store_true",
        help="Install bundled OpenCode plugin(s) into <project_root>/.opencode/plugins.",
    )
    parser.add_argument(
        "--project-root",
        default=".",
        help="Project root used by --install-plugin (default: current directory).",
    )
    args = parser.parse_args()

    if args.install_plugin:
        project_root = Path(args.project_root).resolve()
        copied_files = _copy_plugin_dir(project_root=project_root)
        if not copied_files:
            print("No plugin files were found to install.")
            return

        print(f"Installed {len(copied_files)} plugin file(s) to {project_root / '.opencode' / 'plugins'}:")
        for file_path in copied_files:
            print(f"- {file_path}")
        return

    # setup_logging()
    verify_config()
    uvicorn.run(
        "mhub_proxy.app:app",
        host=host(),
        port=port(),
        log_level=log_level(),
        access_log=True,
    )
