import os

def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ValueError(f"{name} is not set")
    return value

def mhub_base_url() -> str:
    return required_env("MHUB_API_URL").rstrip("/")

def mhub_client_id() -> str:
    return required_env("MHUB_CLIENT_ID")

def mhub_client_secret() -> str:
    return required_env("MHUB_CLIENT_SECRET")

def oneaccount_login_url() -> str:
    return required_env("ONEACCOUNT_LOGIN_URL").rstrip("/")

def log_level() -> str:
    return os.getenv("MHUB_PROXY_LOG_LEVEL") or os.getenv("LLM_PROXY_LOG_LEVEL", "info")

def host() -> str:
    return os.getenv("MHUB_PROXY_HOST") or os.getenv("LLM_PROXY_HOST", "127.0.0.1")

def port() -> int:
    return int(os.getenv("MHUB_PROXY_PORT") or os.getenv("LLM_PROXY_PORT", "8123"))

def verify_config() -> None:
    mhub_base_url()
    mhub_client_id()
    mhub_client_secret()
    oneaccount_login_url()
    