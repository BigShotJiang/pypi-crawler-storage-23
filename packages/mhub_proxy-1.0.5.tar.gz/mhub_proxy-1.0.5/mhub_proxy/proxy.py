import logging
import uuid
from typing import AsyncIterator
import json

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from .config import (
    mhub_base_url,  
)

from .auth import _authenticate

router = APIRouter()
request_logger = logging.getLogger("mhub_proxy.requests")


def openai_upstream_url(deployment_id: str) -> str:
    upstream_base = mhub_base_url()
    base = upstream_base.rstrip("/")
    model_id = deployment_id.split('@')[0]
    api_version = deployment_id.split('@')[1]
    return f"{base}/providers/openai/deployments/{model_id}/chat/completions?api-version={api_version}"


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/openai/chat/completions")
async def chat_completions(request: Request) -> StreamingResponse:
    request_id = uuid.uuid4().hex
    body = await request.body()
    body = json.loads(body)

    upstream_url = openai_upstream_url(
        deployment_id=body.get("model")
    )
    request_logger.info(
        "body=%s", json.dumps(body),
    )

    request_logger.info(
        "request_id=%s method=%s path=%s upstream_url=%s query=%s",
        request_id,
        request.method,
        request.url.path,
        upstream_url,
        str(request.query_params),
    )

    auth_token = await _authenticate(request)
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }
    payload = {
        "messages": body.get("messages"),
        "tools": body.get("tools"),
        "reasoning_effort": body.get("reasoning_effort", "medium"),
        "tool_choice": "auto",
        "stream_options": {"include_usage": True},
        "stream": True,
    }

    async def stream_response() -> AsyncIterator[bytes]:
        async with httpx.AsyncClient(verify=False, timeout=300) as client:
            async with client.stream(
                "POST",
                upstream_url,
                headers=headers,
                json=payload,
            ) as response:
                response.raise_for_status()
                async for chunk in response.aiter_bytes():
                    yield chunk

    return StreamingResponse(
        content=stream_response(),
        status_code=200,
        headers={"Content-Type": "application/json"},
    )
