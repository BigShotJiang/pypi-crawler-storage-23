from demuxai.model import Model


class OllamaModel(Model):
    pass
