"""
TODO: a provider that dynamically routes requests to different providers
- configuration will allow specification of upstream providers per programming language
- should have a default upstream provider
- the provider then routes based to the specified upstream provider
"""
