"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.dtype_converter import aidge_to_onnx, onnx_to_aidge
from aidge_onnx.node_export import auto_register_export


@auto_register_export("QLinearMatMul")
def export_quantified_matmul(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:

    aidge_operator = aidge_node.get_operator()
    inner_graph_nodes = aidge_operator.get_micro_graph().get_nodes()
    # getters of matmul operator from the metaoperator
    matmul_node = None
    for node in inner_graph_nodes:
        if node.type() == "MatMul":
            matmul_node = node
            break
        elif node.type() not in ["Quantizer", "Dequantizer"]:
            raise RuntimeError(
                f"Unsupported node type: {node.type()} inside {aidge_node.name()}[{aidge_node.type()}]."
            )

    if matmul_node is None:
        raise RuntimeError(
            f"Unexpected error: could not find MatMul node inside {aidge_node.name()}[{aidge_node.type()}]."
        )

    # -- QLinearMatMul export
    # QLinearMatMul inputs in Aidge are as follows:
    # input X
    # input W
    # QLinearMatMul inputs in ONNX are as follows:
    # input X, x_scale, x_zero_point
    # input W, w_scale, w_zero_point
    # output y_scale, y_zero_point

    # The missing inputs in aidge are initializers ; these values are inside the metaoperators Quantizers and Dequantizers
    # service function to create initializers

    new_node_inputs_name = [node_inputs_name[0]]

    def create_and_add_initializer(tensor, tensor_dtype, in_name="", tensor_dims=[]):
        tensor.set_datatype(onnx_to_aidge(tensor_dtype))
        initializer_list.append(
            helper.make_tensor(
                aidge_node.name() + in_name, tensor_dtype, tensor_dims, tensor
            )
        )
        new_node_inputs_name.append(aidge_node.name() + in_name)

    # service function to get scaling factor and zero_point of a quantizer/dequantizer node
    def get_scale_and_zeropoint(quantizer_node):
        scale = None
        zero_point = None
        for q_inner_node in quantizer_node.get_operator().get_micro_graph().get_nodes():
            if q_inner_node.type() == "Mul":
                # First scaling operation will have as parent 1 the scale producer
                scale = q_inner_node.get_parent(1).get_operator().get_output(0).clone()
                if quantizer_node.type() == "Quantizer":
                    temp_tensor = aidge_core.Tensor(1)
                    temp_tensor.set_datatype(scale.dtype)
                    scale = temp_tensor / scale
            if q_inner_node.type() in ("Add", "Sub"):
                zero_point = (
                    q_inner_node.get_parent(1).get_operator().get_output(0).clone()
                )

        if scale is None:
            aidge_core.Log.warn(
                f"Could not determine the scaling factor of {quantizer_node.name()}[{quantizer_node.type()}]."
            )
            return None

        if zero_point is None:
            aidge_core.Log.warn(
                f"Could not determine the zero point of {quantizer_node.name()}[{quantizer_node.type()}]."
            )
            return None

        return scale, zero_point

    # Get scaling factors and zeropoints
    sc_zp = []

    for inpt in matmul_node.get_parents():
        if inpt.type() != "Dequantizer":
            raise RuntimeError(
                f"Expected Dequantizer as parent of {matmul_node.name()} but got {inpt.name()}[{inpt.type()}]."
            )

        sc_dtype = aidge_to_onnx(inpt.get_operator().get_output(0).dtype)
        zp_dtype = aidge_to_onnx(inpt.get_operator().get_input(0).dtype)
        sc_zp.append((get_scale_and_zeropoint(inpt), (sc_dtype, zp_dtype)))

    output_quant_node = list(matmul_node.get_children())[0]
    if output_quant_node.type() != "Quantizer":
        raise RuntimeError(
            f"Expected Quantizer as child of {matmul_node.name()} but got {output_quant_node.name()}[{output_quant_node.type()}]."
        )
    sc_dtype = aidge_to_onnx(output_quant_node.get_operator().get_input(0).dtype)
    zp_dtype = aidge_to_onnx(output_quant_node.get_operator().get_output(0).dtype)
    sc_zp.append((get_scale_and_zeropoint(output_quant_node), (sc_dtype, zp_dtype)))

    # Make input_names list and create new initializers

    create_and_add_initializer(sc_zp[0][0][0], sc_zp[0][1][0], "_x_scale")
    create_and_add_initializer(sc_zp[0][0][1], sc_zp[0][1][1], "_x_zero_point")
    new_node_inputs_name.append(node_inputs_name[1])
    create_and_add_initializer(sc_zp[1][0][0], sc_zp[1][1][0], "_w_scale")
    create_and_add_initializer(sc_zp[1][0][1], sc_zp[1][1][1], "_w_zero_point")
    create_and_add_initializer(sc_zp[2][0][0], sc_zp[2][1][0], "_y_scale")
    create_and_add_initializer(sc_zp[2][0][1], sc_zp[2][1][1], "_y_zero_point")

    # onnx qlinearmatmul node creation and attributes
    qlinearmatmul_node = helper.make_node(
        name=aidge_node.name(),
        op_type="QLinearMatMul",
        inputs=new_node_inputs_name,
        outputs=node_outputs_name,
    )

    return [qlinearmatmul_node]
