"""
Copyright (c) 2025 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx import dtype_converter
from aidge_onnx.node_export import auto_register_export


@auto_register_export("LRN")
def export_lrn(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:
    """
    Export the LRN operation from Aidge to ONNX.

    :param aidge_node: Aidge node to convert
    :type aidge_node: aidge_core.Node
    :param node_inputs_name: List of input names for the ONNX node
    :type node_inputs_name: List[str]
    :param node_outputs_name: List of output names for the ONNX node
    :type node_outputs_name: List[str]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    :return: List of ONNX nodes
    :rtype: List[helper.NodeProto]
    """

    aidge_operator = aidge_node.get_operator()

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="LRN",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
        alpha=aidge_operator.attr.alpha,
        beta=aidge_operator.attr.beta,
        bias=aidge_operator.attr.bias,
        size=aidge_operator.attr.size,
    )

    return [onnx_node]
