"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import helper

import aidge_core
from aidge_onnx.dtype_converter import aidge_to_onnx
from aidge_onnx.node_export import auto_register_export


@auto_register_export("HannWindow")
def export_hannwindow(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    opset: int | None = None,
    **kwargs
) -> list[helper.NodeProto]:

    aidge_operator = aidge_node.get_operator()
    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="HannWindow",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    micro_graph = aidge_operator.get_micro_graph()
    nb_sub = 0
    for node in micro_graph.get_nodes():
        if node.type() == "Sub":
            nb_sub += 1

    onnx_node.attribute.append(
        helper.make_attribute(
            "output_datatype", aidge_to_onnx(aidge_operator.get_output(0).dtype)
        )
    )
    # If the window is to be used as periodic function, the sub-graph will
    # contain 2 Sub operators, and only 1 otherwise.
    onnx_node.attribute.append(helper.make_attribute("periodic", nb_sub == 1))
    return [onnx_node]
