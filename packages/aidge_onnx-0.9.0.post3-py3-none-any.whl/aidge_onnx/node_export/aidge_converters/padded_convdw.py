"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("PaddedConvDepthWise2D")
def export_padded_conv(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:

    aidge_operator = aidge_node.get_operator()
    micro_graph = aidge_operator.get_micro_graph()
    conv_op, pad_op = None, None
    for node in micro_graph.get_nodes():
        if (
            node.type() == "ConvDepthWise1D"
            or node.type() == "ConvDepthWise2D"
            or node.type() == "ConvDepthWise3D"
        ):
            conv_op = node.get_operator()
        elif node.type() == "Pad":
            pad_op = node.get_operator()
        else:
            raise RuntimeError(
                f"Unsupported node type: {node.type()} inside PaddedConv."
            )
    # If bias not set, remove bias as an input
    if aidge_node.input(2)[0] is None:
        node_inputs_name.remove("")  # should have no name
    elif not aidge_node.input(2)[0].get_operator().get_output(0).impl:
        node_inputs_name.remove(aidge_node.input(2)[0].name() + "_out0")

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="Conv",
        inputs=node_inputs_name[:3],  # ignore Pad extra inputs
        outputs=node_outputs_name,
    )
    onnx_node.attribute.append(
        helper.make_attribute("dilations", conv_op.attr.get_attr("dilation_dims"))
    )
    onnx_node.attribute.append(
        helper.make_attribute(
            "group", conv_op.nb_channels()  # Group size = nb channel out for convdw
        )
    )
    onnx_node.attribute.append(
        helper.make_attribute("kernel_shape", conv_op.attr.get_attr("kernel_dims"))
    )
    onnx_node.attribute.append(
        helper.make_attribute("strides", conv_op.attr.get_attr("stride_dims"))
    )

    full_pads = pad_op.attr.get_attr("pads")
    pad_input_tensor: aidge_core.Tensor = pad_op.get_input(0)
    nb_dims = len(pad_input_tensor.dims)
    all_axes = list(range(nb_dims))

    # Conv compatible padding (without N, C)
    spatial_pads = [0] * (2 * (nb_dims - 2))

    # in theory should always be defined by Pad ctor.
    # For good measure, define all axes by default
    axes = pad_op.attr.get_attr("axes") if pad_op.attr.get_attr("axes") else all_axes
    # Convert to positive axis
    axes = [axe if axe >= 0 else nb_dims + axe for axe in axes]

    # Check if non-zero padding is applied to N or C dimensions (first two axes)
    for i, axis in enumerate(axes):
        if axis in [0, 1]:  # N or C dimension
            begin_pad = full_pads[i]
            end_pad = full_pads[i + len(axes)]
            if begin_pad != 0 or end_pad != 0:
                raise ValueError(
                    f"Cannot fuse Pad into Conv: non-zero padding on "
                    f"{'batch (N)' if axis == 0 else 'channel (C)'} dimension is not supported"
                )

    # Map padding values to spatial dimensions
    # full_pads format: [begin_0, begin_1, ..., begin_n, end_0, end_1, ..., end_n]
    # spatial_pads format: [begin_2, begin_3, ..., begin_n, end_2, end_3, ..., end_n]
    for i, axis in enumerate(axes):
        if axis >= 2:  # Spatial dimensions only (skip N and C)
            spatial_idx = axis - 2
            spatial_pads[spatial_idx] = full_pads[i]
            spatial_pads[spatial_idx + (nb_dims - 2)] = full_pads[i + len(axes)]
    onnx_node.attribute.append(helper.make_attribute("pads", spatial_pads))

    return [onnx_node]
