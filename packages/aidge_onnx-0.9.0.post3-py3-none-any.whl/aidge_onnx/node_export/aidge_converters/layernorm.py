"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import numpy as np
from onnx import TensorProto, helper

import aidge_core
from aidge_onnx import dtype_converter
from aidge_onnx.node_export import auto_register_export


def fail_export(msg):
    aidge_core.Log.warn(msg)
    return None


@auto_register_export("LayerNorm")
def export_layernorm(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:
    if opset < 17:
        fail_export(
            f"LayerNorm has been introduced with opset 17, cannot export a network with LayerNorm in opset {opset}"
        )
    epsilon = None
    axis = -1
    aidge_operator = aidge_node.get_operator()
    if not aidge_operator.attr.epsilon:
        fail_export("Missing LayerNorm mandatory attribute epsilon.")
    else:
        epsilon = aidge_operator.attr.epsilon
    if aidge_operator.attr.axis:
        axis = aidge_operator.attr.axis

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="LayerNormalization",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )
    onnx_node.attribute.append(helper.make_attribute("epsilon", epsilon))
    onnx_node.attribute.append(helper.make_attribute("axis", axis))

    return [onnx_node]
