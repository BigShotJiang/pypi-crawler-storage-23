"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.dtype_converter import aidge_to_onnx, onnx_to_aidge
from aidge_onnx.node_export import auto_register_export


@auto_register_export("QLinearConv")
def export_quantified_Conv(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:

    convs_types_list = [
        "Conv1D",
        "Conv2D",
        "Conv3D",
        "ConvDepthWise1D",
        "ConvDepthWise2D",
        "ConvDepthWise3D",
        "PaddedConv1D",
        "PaddedConv2D",
        "PaddedConv3D",
        "PaddedConvDepthWise1D",
        "PaddedConvDepthWise2D",
        "PaddedConvDepthWise3D",
    ]

    aidge_operator = aidge_node.get_operator()

    # getters of conv operator from the metaoperator
    # Get information: padded? depthwise? bias?
    conv_node = None
    # variable main_node is used to refer to the convolution node, be it a metaop(because of padding) or normal convolution
    # while conv_node refers to the inner convolution node
    main_node = None
    pad_node = None
    for node in aidge_operator.get_micro_graph().get_nodes():
        if node.type() in convs_types_list:
            main_node = node
            if hasattr(node.get_operator(), "get_micro_graph"):
                for conv_inner_node in node.get_operator().get_micro_graph():
                    if conv_inner_node.type() in convs_types_list[:6]:
                        conv_node = conv_inner_node
                    elif conv_inner_node.type() == "Pad":
                        pad_node = conv_inner_node
                    else:
                        raise RuntimeError(
                            f"Unsupported node type: {conv_inner_node.type()} inside {node.name()}[{node.type()}]."
                        )
            else:
                conv_node = node
            break
        elif node.type() not in ["Quantizer", "Dequantizer"]:
            raise RuntimeError(
                f"Unsupported node type: {node.type()} inside {aidge_node.name()}[{aidge_node.type()}]."
            )

    if conv_node is None or main_node is None:
        raise RuntimeError(
            f"Unexpected error: could not find convolution node or type inside {aidge_node.name()}[{aidge_node.type()}]."
        )

    has_bias = True
    if (
        len(aidge_node.inputs()) == 3
        and (
            aidge_node.input(2)[0] is None
            or not aidge_node.input(2)[0].get_operator().get_output(0).has_impl()
        )
        and len(node_inputs_name) == 3
    ):
        # remove bias input if no bias
        node_inputs_name.pop()
        has_bias = False

    # -- QLinearConv export
    # QLinearConv inputs in Aidge are as follows:
    # input X
    # input W
    # input B (optional)
    # QLinearConv inputs in ONNX are as follows:
    # input X, x_scale, x_zero_point
    # input W, w_scale, w_zero_point
    # output y_scale, y_zero_point
    # input B (optional)

    # The missing inputs in aidge are initializers ; these values are inside the metaoperators Quantizers and Dequantizers
    # service function to create initializers

    new_node_inputs_name = [node_inputs_name[0]]

    def create_and_add_initializer(tensor, tensor_dtype, in_name="", tensor_dims=[]):
        tensor.set_datatype(onnx_to_aidge(tensor_dtype))
        initializer_list.append(
            helper.make_tensor(
                aidge_node.name() + in_name, tensor_dtype, tensor_dims, tensor
            )
        )
        new_node_inputs_name.append(aidge_node.name() + in_name)

    # service function to get scaling factor and zero_point of a quantizer/dequantizer node
    def get_scale_and_zeropoint(quantizer_node):
        scale = None
        zero_point = None
        for q_inner_node in quantizer_node.get_operator().get_micro_graph().get_nodes():
            if q_inner_node.type() == "Mul":
                # First scaling operation will have as parent 1 the scale producer
                scale = q_inner_node.get_parent(1).get_operator().get_output(0).clone()
                if quantizer_node.type() == "Quantizer":
                    temp_tensor = aidge_core.Tensor(1)
                    temp_tensor.set_datatype(scale.dtype)
                    scale = temp_tensor / scale
            if q_inner_node.type() in ("Add", "Sub"):
                zero_point = (
                    q_inner_node.get_parent(1).get_operator().get_output(0).clone()
                )

        if scale is None:
            aidge_core.Log.warn(
                f"Could not determine the scaling factor of {quantizer_node.name()}[{quantizer_node.type()}]."
            )
            return None

        if zero_point is None:
            aidge_core.Log.warn(
                f"Could not determine the zero point of {quantizer_node.name()}[{quantizer_node.type()}]."
            )
            return None

        return scale, zero_point

    # Get scaling factors and zeropoints
    sc_zp = []

    for inpt in main_node.get_parents():
        if inpt is None:
            continue  # No bias case
        if inpt.type() != "Dequantizer":
            raise RuntimeError(
                f"Expected Dequantizer as parent of {main_node.name()} but got {inpt.name()}[{inpt.type()}]."
            )

        sc_dtype = aidge_to_onnx(inpt.get_operator().get_output(0).dtype)
        zp_dtype = aidge_to_onnx(inpt.get_operator().get_input(0).dtype)
        sc_zp.append((get_scale_and_zeropoint(inpt), (sc_dtype, zp_dtype)))

    output_quant_node = list(main_node.get_children())[0]
    if output_quant_node.type() != "Quantizer":
        raise RuntimeError(
            f"Expected Quantizer as child of {main_node.name()} but got {output_quant_node.name()}[{output_quant_node.type()}]."
        )
    sc_dtype = aidge_to_onnx(output_quant_node.get_operator().get_input(0).dtype)
    zp_dtype = aidge_to_onnx(output_quant_node.get_operator().get_output(0).dtype)
    sc_zp.append((get_scale_and_zeropoint(output_quant_node), (sc_dtype, zp_dtype)))

    # Make input_names list and create new initializers

    create_and_add_initializer(sc_zp[0][0][0], sc_zp[0][1][0], "_x_scale")
    create_and_add_initializer(sc_zp[0][0][1], sc_zp[0][1][1], "_x_zero_point")
    new_node_inputs_name.append(node_inputs_name[1])
    create_and_add_initializer(sc_zp[1][0][0], sc_zp[1][1][0], "_w_scale")
    create_and_add_initializer(sc_zp[1][0][1], sc_zp[1][1][1], "_w_zero_point")
    y_idx = (
        2 + has_bias
    )  # in sc_zp y scaling and zero point is at idx 2 without bias and index 3 with bias
    create_and_add_initializer(sc_zp[y_idx][0][0], sc_zp[y_idx][1][0], "_y_scale")
    create_and_add_initializer(sc_zp[y_idx][0][1], sc_zp[y_idx][1][1], "_y_zero_point")
    if has_bias:
        new_node_inputs_name.append(node_inputs_name[2])

    # onnx qlinearconv node creation and attributes
    qlinearconv_node = helper.make_node(
        name=aidge_node.name(),
        op_type="QLinearConv",
        inputs=new_node_inputs_name,
        outputs=node_outputs_name,
    )

    conv_op = conv_node.get_operator()
    qlinearconv_node.attribute.append(
        helper.make_attribute("dilations", conv_op.attr.get_attr("dilation_dims"))
    )
    qlinearconv_node.attribute.append(
        helper.make_attribute(
            "group",
            conv_op.nb_channels() if conv_node.type() in convs_types_list[3:6] else 1,
        )
    )
    qlinearconv_node.attribute.append(
        helper.make_attribute("kernel_shape", conv_op.attr.get_attr("kernel_dims"))
    )
    qlinearconv_node.attribute.append(
        helper.make_attribute("strides", conv_op.attr.get_attr("stride_dims"))
    )

    if pad_node is not None:
        qlinearconv_node.attribute.append(
            helper.make_attribute("pads", pad_node.get_operator().attr.get_attr("pads"))
        )

    return [qlinearconv_node]
