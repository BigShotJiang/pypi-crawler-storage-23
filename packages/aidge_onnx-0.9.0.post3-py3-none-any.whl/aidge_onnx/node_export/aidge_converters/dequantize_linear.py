"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.dtype_converter import aidge_to_onnx
from aidge_onnx.node_export import auto_register_export


@auto_register_export("Dequantizer")
def export_dequantize_linear(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:

    aidge_operator = aidge_node.get_operator()
    micro_graph = aidge_operator.get_micro_graph()
    onnx_target_type = aidge_to_onnx(aidge_node.get_operator().get_output(0).dtype)

    if aidge_operator.get_input(0) is not None:
        in_dtype = aidge_operator.get_input(0).dtype
        onnx_input_type = aidge_to_onnx(in_dtype)
    else:
        aidge_core.Log.warn(
            f"Failed to convert {aidge_node.name()}[{aidge_node.type()}], could not determine the input datatype."
        )
        return None

    current_scale = None
    current_zero_point = None
    for operator in micro_graph.get_ordered_nodes():
        if operator.type() == "Mul":
            # First scaling operation will have as parent 1 the scale producer
            current_scale = operator.get_parent(1).get_operator().get_output(0).clone()
        if operator.type() == "Sub":
            current_zero_point = (
                operator.get_parent(1).get_operator().get_output(0).clone()
            )
            current_zero_point.set_datatype(in_dtype)

    if current_scale is None:
        aidge_core.Log.warn(
            f"Failed to convert {aidge_node.name()}[{aidge_node.type()}], could not determine the scaling factor."
        )
        return None

    initializer_list.append(
        helper.make_tensor(
            aidge_node.name() + "_scale_tensor", onnx_target_type, [], current_scale
        )
    )
    node_inputs_name.append(aidge_node.name() + "_scale_tensor")

    if current_zero_point is not None:
        initializer_list.append(
            helper.make_tensor(
                aidge_node.name() + "_zero_point_tensor",
                onnx_input_type,
                [],
                current_zero_point,
            )
        )

        node_inputs_name.append(aidge_node.name() + "_zero_point_tensor")

    dequantize_linear = helper.make_node(
        name=aidge_node.name(),
        op_type="DequantizeLinear",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    return [dequantize_linear]
