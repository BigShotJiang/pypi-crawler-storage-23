"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("ComplexToInnerPair")
def export_complex_to_inner_pair(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs
) -> list[helper.NodeProto]:

    # Shape
    shape_node = helper.make_node(
        "Shape", inputs=[node_inputs_name[0]], outputs=[node_inputs_name[0] + "_shape"]
    )

    # Constant [1]
    const_one_node = helper.make_node(
        "Constant",
        inputs=[],
        outputs=["one"],
        value=helper.make_tensor(
            name="const_one",
            data_type=TensorProto.INT64,
            dims=[1],
            vals=[1],
        ),
    )

    # Concat along axis 0
    concat_node = helper.make_node(
        "Concat",
        inputs=[node_inputs_name[0] + "_shape", "one"],
        outputs=[node_inputs_name[0] + "_reshaped"],
        axis=0,
    )

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="Reshape",
        inputs=[node_inputs_name[0] + "_reshaped"],
        outputs=node_outputs_name,
    )

    return [shape_node, const_one_node, concat_node, onnx_node]
