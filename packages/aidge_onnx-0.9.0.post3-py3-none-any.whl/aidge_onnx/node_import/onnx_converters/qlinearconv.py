"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import numpy as np
import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.dtype_converter import aidge_to_onnx
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("qlinearconv")
def import_qlinearconv(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    # Qlinear Conv is the quantized convolution representation of ONNX, produced by quantizing in Qop format
    # Qlinear Conv uses quantized inputs, weights and bias, and returns a quantized output
    # The quantized inputs, weights and bias are firstly dequantized, then infereded in a dequantized convolution then quantized again
    # Note : there may be some optimizations made on runtime by onnx
    # This operator can be described as a normal convolution with DequantizeLinear operators in its inputs(data, weight and bias)
    # and QuantizeLinear operators in its output
    # When importing the scaling factors and zero points will be placed inside the metaoperator meaning that the inputs will change
    # Inputs descriptions:
    # x: quantized input data (qlinearconv expects a quantified input)
    # w: quantized convolution weights (qlinearconv expects quantified weights)
    # b (optional): quantized convolution bias (qlinearconv expects a quantified bias)

    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)
    conv_attrs: dict = {}

    ### Normal Convolution import: attributes
    if "kernel_shape" in onnx_attrs:
        kernel_dims = onnx_attrs["kernel_shape"]
        del onnx_attrs["kernel_shape"]
    else:
        # If not present, should be inferred from input W.
        if input_nodes[3] is None:
            Log.warning(
                f"Kernel dims cannot be inferred from W for qlinearconv node at import time. This node will be filled by a GenericOperator."
            )
            return None
        kernel_dims = (
            input_nodes[3][0].get_operator().get_output(input_nodes[3][1]).dims[2:]
        )
    kernel_length = len(kernel_dims)  # to prevent reutilisation of len and kerneldims

    if "strides" in onnx_attrs:
        conv_attrs["stride_dims"] = onnx_attrs["strides"]
        del onnx_attrs["strides"]
    else:
        # If not present, the stride defaults is 1 along each spatial axis.
        conv_attrs["stride_dims"] = [1] * kernel_length

    if "dilations" in onnx_attrs:
        conv_attrs["dilation_dims"] = onnx_attrs["dilations"]
        del onnx_attrs["dilations"]
    else:
        # If not present, the stride defaults is 1 along each spatial axis.
        conv_attrs["dilation_dims"] = [1] * kernel_length

    # group is 1 by default
    group = 1
    if "group" in onnx_attrs:
        group = onnx_attrs["group"]
        del onnx_attrs["group"]

    conv_attrs["padding_dims"] = [0] * 2 * kernel_length
    if "pads" in onnx_attrs:
        conv_attrs["padding_dims"] = onnx_attrs["pads"]
        del onnx_attrs["pads"]

    if "auto_pad" in onnx_attrs and onnx_attrs["auto_pad"] in (
        b"NOTSET",
        b"SAME_UPPER",
        b"SAME_LOWER",
        b"VALID",
    ):
        if (
            onnx_attrs["auto_pad"] != b"NOTSET"
            and np.count_nonzero(conv_attrs["padding_dims"]) > 0
        ):
            raise RuntimeError(
                f"Error: malformed ONNX: cannot have both non-zero 'pads' and 'auto_pad' different from 'NOTSET'."
            )

        nb_feature = len(kernel_dims)
        for i, ele in enumerate(kernel_dims):
            padding = ele - conv_attrs["stride_dims"][i]
            nb_same_padding = padding // 2
            floor_half_hadding = padding % 2

            if onnx_attrs["auto_pad"] == b"SAME_UPPER":
                conv_attrs["padding_dims"][i] = nb_same_padding + floor_half_hadding
                conv_attrs["padding_dims"][i + nb_feature] = nb_same_padding
            elif onnx_attrs["auto_pad"] == b"SAME_LOWER":
                conv_attrs["padding_dims"][i] = nb_same_padding
                conv_attrs["padding_dims"][i + nb_feature] = (
                    nb_same_padding + floor_half_hadding
                )
        del onnx_attrs["auto_pad"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'Conv' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    if group == 1:
        op_aidge_class_name = f"Conv{kernel_length}D"
        op_aidge_constr_name = f"Conv{kernel_length}DOp"
    else:
        w_dims = input_nodes[1][0].get_operator().get_output(input_nodes[1][1]).dims
        if w_dims[1] == 1:
            op_aidge_class_name = f"ConvDepthWise{kernel_length}D"
            op_aidge_constr_name = f"ConvDepthWise{kernel_length}DOp"
        else:
            Log.warn(
                f"Warning: non depth-wise grouped Conv is not supported in Aidge. This node will be filled by a GenericOperator."
            )
            return None

    if np.count_nonzero(conv_attrs["padding_dims"]) > 0:
        # if padding_dims values are different from 0 then a padded convolution will be made
        op_aidge_class_name = "Padded" + op_aidge_class_name
        op_aidge_constr_name = "Padded" + op_aidge_constr_name
    else:
        del conv_attrs["padding_dims"]

    if op_aidge_class_name in dir(aidge_core):
        aidge_op = aidge_core.__getattribute__(op_aidge_constr_name)(
            kernel_dims, **conv_attrs
        )
    else:
        Log.warn(
            f"Warning: {op_aidge_class_name} is not supported in Aidge. This node will be filled by a GenericOperator."
        )
        return None

    main_conv_node = aidge_core.Node(aidge_op, name=node_name + "_convCore")

    ### Quantization part import

    # get all the onnx initializers
    quantif_inputs = []
    for idx, inp in enumerate(input_nodes[1:]):
        prod_node = inp[0]
        if prod_node is None:
            Log.warn(
                f"Input {idx-1} is not available at import time for node QLinearConv, This node will be filled by a GenericOperator."
            )
            return None
        prod_out = None
        if prod_node.type() == "Producer":
            prod_out = prod_node.get_operator().get_output(0)
        quantif_inputs.append(prod_out)

    if len(quantif_inputs) < 7:
        Log.warning(
            f"Node {node_name} needs at least 8 inputs for QLinearConv node, got {len(quantif_inputs)} inputs. This node will be filled by a GenericOperator."
        )
        return None

    has_bias = len(quantif_inputs) == 8

    ### Input Dequantizers creation
    #### x Dequantizer

    # get zero_point value
    inpt_zero_point_value = quantif_inputs[1][0]

    # output dtype of dequantize operator is determined by the scaling factor dtype
    inpt_cast_output_dtype = quantif_inputs[0].dtype

    inpt_scale_array = quantif_inputs[0]
    inpt_scale_value = inpt_scale_array[0]
    if not all([s == inpt_scale_value for s in inpt_scale_array]):
        Log.warn(
            f"Aidge currently only supports layerwise scaling and not channelwise for QLinearConv[Input DequantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    input_dequantizer_node = aidge_core.Dequantizer(
        inpt_scale_value,
        name=node_name + "_x_dq",
        zero_point=inpt_zero_point_value,
        to_type=inpt_cast_output_dtype,
    )
    # input_dequantizer_node.get_operator().set_datatype(inpt_cast_output_dtype)

    #### W Dequantizer

    # get zero_point value
    w_zero_point_value = quantif_inputs[4][0]

    # output dtype of dequantize operator is determined by the scaling factor dtype
    w_cast_output_dtype = quantif_inputs[3].dtype

    w_scale_array = quantif_inputs[3]
    w_scale_value = w_scale_array[0]
    if not all([s == w_scale_value for s in w_scale_array]):
        Log.warn(
            f"Aidge currently only supports layerwise scaling and not channelwise for QLinearConv[Weight DequantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    weight_dequantizer_node = aidge_core.Dequantizer(
        w_scale_value,
        name=node_name + "_w_dq",
        zero_point=w_zero_point_value,
        to_type=w_cast_output_dtype,
    )
    # weight_dequantizer_node.get_operator().set_datatype(w_cast_output_dtype)

    #### B Dequantizer(optional)
    # Dequantize operator attribute's values are not indicated in QLinearConv inputs but they are calculated or equal to:
    # bias scaling = input_scaling*weight_scaling
    # bias zero point = 0
    # source: https://onnx.ai/onnx/operators/onnx__QLinearConv.html#:~:text=using%20scale%20%3D%20x_scale%20*%20w_scale%20and%20zero_point%20%3D%200

    if has_bias:
        b_scale_value = inpt_scale_value * w_scale_value

        bias_dequantizer_node = aidge_core.Dequantizer(
            b_scale_value,
            name=node_name + "_b_dq",
            to_type=w_cast_output_dtype,  # dtype cannot be inferred from the onnx model, so the weight one is used
        )
        # bias_dequantizer_node.get_operator().set_datatype(w_cast_output_dtype)

    #### Y Quantizer

    # output dtype is determined by zero_point dtype

    y_cast_output_dtype = quantif_inputs[6].dtype
    y_cast_output_dtype_onnx = aidge_to_onnx(quantif_inputs[6].dtype)

    y_zero_point = quantif_inputs[6][0]

    # nodes creation
    clip_ranges = {
        2: [0, 255],
        3: [-128, 127],
        4: [0, 65535],
        5: [-32768, 32767],
        21: [0, 15],
        22: [-8, 7],
    }
    if y_cast_output_dtype_onnx not in clip_ranges:
        Log.warn(
            f"Unknown output dtype {y_cast_output_dtype_onnx} for node {node_name}[QLinearConv[Output QuantizeLinear]]. This node will be filled by a GenericOperator."
        )
        return None
    y_scale_array = quantif_inputs[5]
    y_scale_value = y_scale_array[0]
    if not all([s == y_scale_value for s in y_scale_array]):
        Log.warn(
            f"Aidge currently only support layerwise scaling and not channelwise for QLinearConv[Output QuantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    output_quantizer_node = aidge_core.Quantizer(
        1 / y_scale_value,
        name=node_name,
        zero_point=y_zero_point,
        round=True,
        clip_min=clip_ranges[y_cast_output_dtype_onnx][0],
        clip_max=clip_ranges[y_cast_output_dtype_onnx][1],
        to_type=y_cast_output_dtype,
    )

    ### Graph and metaoperator creation

    metaop_graph = aidge_core.GraphView()

    input_dequantizer_node.add_child(main_conv_node, 0, 0)
    weight_dequantizer_node.add_child(main_conv_node, 0, 1)
    if has_bias:
        bias_dequantizer_node.add_child(main_conv_node, 0, 2)
    main_conv_node.add_child(output_quantizer_node, 0, 0)

    metaop_graph.add(input_dequantizer_node)
    metaop_graph.add(weight_dequantizer_node)
    if has_bias:
        metaop_graph.add(bias_dequantizer_node)
    metaop_graph.add(main_conv_node)
    metaop_graph.add(output_quantizer_node)

    # Internal propagation of dtype, using input zero_point datatype : https://onnx.ai/onnx/operators/onnx__QLinearConv.html#:~:text=x_zero_point%20(heterogeneous)%20%2D-,T1,-%3A
    in_dtypes = [quantif_inputs[1].dtype, quantif_inputs[4].dtype]
    if has_bias:
        in_dtypes.append(aidge_core.dtype.int32)  # bias dtype must be int32
    metaop_graph.forward_dtype(in_dtypes)

    # change input nodes to only include input, weight and optionally bias
    input_nodes[:] = (
        [input_nodes[0], input_nodes[3]]
        if not has_bias
        else [input_nodes[0], input_nodes[3], input_nodes[8]]
    )

    ### Qoperator metaoperator creation
    qoperator_node = aidge_core.meta_operator(
        "QLinearConv", metaop_graph, name=node_name
    )

    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return qoperator_node
