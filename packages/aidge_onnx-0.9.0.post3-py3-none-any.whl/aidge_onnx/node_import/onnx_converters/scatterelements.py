"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import NodeProto, ValueInfoProto

from aidge_core import Log, Node, ScatterOp
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("scatterelements")
def import_scatter_elements(
    onnx_node: NodeProto,
    input_nodes: list[tuple[Node, int]],
    opset: int,
    inputs_tensor_info: list[ValueInfoProto | None],
) -> Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)
    scatter_attrs = {"axis": 0, "reduction": "none"}  # Default values

    if "axis" in onnx_attrs:
        scatter_attrs["axis"] = onnx_attrs["axis"]
        del onnx_attrs["axis"]

    if "reduction" in onnx_attrs:
        scatter_attrs["reduction"] = onnx_attrs["reduction"].decode("ascii")
        del onnx_attrs["reduction"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'ScatterElements' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    my_node = Node(ScatterOp(**scatter_attrs), name=node_name)
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return my_node
