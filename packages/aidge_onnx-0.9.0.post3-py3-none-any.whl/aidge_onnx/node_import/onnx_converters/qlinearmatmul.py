"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.dtype_converter import aidge_to_onnx
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("qlinearmatmul")
def import_qlinearmatmul(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    # QLinearMatMul is the quantized matmul representation of ONNX, produced by quantizing in Qop format
    # QLinearMatMul uses quantized inputs, weights, and returns a quantized output
    # The quantized inputs, weights are firstly dequantized, then infereded in a dequantized matmul then quantized again
    # Note : there may be some optimizations made on runtime by onnx
    # This operator can be described as a normal matmul with DequantizeLinear operators in its inputs(data and weight)
    # and QuantizeLinear operators in its output
    # When importing the scaling factors and zero points will be placed inside the metaoperator meaning that the inputs will change
    # Inputs descriptions:
    # x: quantized input data (qlinearmatmul expects a quantified input)
    # w: quantized matmul weights (qlinearmatmul expects quantified weights)

    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)

    ### Normal matmul import: attributes
    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'MatMul' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None
    main_matmul_node = aidge_core.MatMul(name=node_name)

    ### Quantization part import

    # get all the onnx initializers
    quantif_inputs = []
    for idx, inp in enumerate(input_nodes[1:]):
        prod_node = inp[0]
        if prod_node is None:
            Log.warn(
                f"Input {idx-1} is not available at import time for node QLinearMatMul, This node will be filled by a GenericOperator."
            )
            return None
        prod_out = None
        if prod_node.type() == "Producer":
            prod_out = prod_node.get_operator().get_output(0)
        quantif_inputs.append(prod_out)

    if len(quantif_inputs) != 7:
        Log.warning(
            f"Node {node_name} needs 8 inputs for QLinearMatMul node, got {len(quantif_inputs)} inputs. This node will be filled by a GenericOperator."
        )
        return None

    ### Input Dequantizers creation
    #### x Dequantizer

    # get zero_point value
    inpt_zero_point_value = quantif_inputs[1][0]

    # output dtype of dequantize operator is determined by the scaling factor dtype
    inpt_cast_output_dtype = quantif_inputs[0].dtype

    inpt_scale_array = quantif_inputs[0]
    inpt_scale_value = inpt_scale_array[0]
    if not all([s == inpt_scale_value for s in inpt_scale_array]):
        Log.warn(
            f"Aidge currently only supports layerwise scaling and not channelwise for QLinearMatMul[Input DequantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    input_dequantizer_node = aidge_core.Dequantizer(
        inpt_scale_value,
        name=node_name + "_x_dq",
        zero_point=inpt_zero_point_value,
        to_type=inpt_cast_output_dtype,
    )

    #### W Dequantizer

    # get zero_point value
    w_zero_point_value = quantif_inputs[4][0]

    # output dtype of dequantize operator is determined by the scaling factor dtype
    w_cast_output_dtype = quantif_inputs[3].dtype

    w_scale_array = quantif_inputs[3]
    w_scale_value = w_scale_array[0]
    if not all([s == w_scale_value for s in w_scale_array]):
        Log.warn(
            f"Aidge currently only supports layerwise scaling and not channelwise for QLinearMatMul[Weight DequantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    weight_dequantizer_node = aidge_core.Dequantizer(
        w_scale_value,
        name=node_name + "_w_dq",
        zero_point=w_zero_point_value,
        to_type=w_cast_output_dtype,
    )

    #### Y Quantizer

    # output dtype is determined by zero_point dtype

    y_cast_output_dtype = quantif_inputs[6].dtype
    y_cast_output_dtype_onnx = aidge_to_onnx(quantif_inputs[6].dtype)

    y_zero_point = quantif_inputs[6][0]

    # nodes creation
    clip_ranges = {
        2: [0, 255],
        3: [-128, 127],
        4: [0, 65535],
        5: [-32768, 32767],
        21: [0, 15],
        22: [-8, 7],
    }
    if y_cast_output_dtype_onnx not in clip_ranges:
        Log.warn(
            f"Unknown output dtype {y_cast_output_dtype_onnx} for node {node_name}[QLinearMatMul[Output QuantizeLinear]]. This node will be filled by a GenericOperator."
        )
        return None
    y_scale_array = quantif_inputs[5]
    y_scale_value = y_scale_array[0]
    if not all([s == y_scale_value for s in y_scale_array]):
        Log.warn(
            f"Aidge currently only support layerwise scaling and not channelwise for QLinearMatMul[Output QuantizeLinear] node. This node will be filled by a GenericOperator."
        )
        return None

    output_quantizer_node = aidge_core.Quantizer(
        1 / y_scale_value,
        name=node_name,
        zero_point=y_zero_point,
        round=True,
        clip_min=clip_ranges[y_cast_output_dtype_onnx][0],
        clip_max=clip_ranges[y_cast_output_dtype_onnx][1],
        to_type=y_cast_output_dtype,
    )

    ### Graph and metaoperator creation

    metaop_graph = aidge_core.GraphView()

    input_dequantizer_node.add_child(main_matmul_node, 0, 0)
    weight_dequantizer_node.add_child(main_matmul_node, 0, 1)
    main_matmul_node.add_child(output_quantizer_node, 0, 0)

    metaop_graph.add(input_dequantizer_node)
    metaop_graph.add(weight_dequantizer_node)
    metaop_graph.add(main_matmul_node)
    metaop_graph.add(output_quantizer_node)

    # Internal propagation of dtype, using input zero_point datatype, it is the same datatype as the input: https://onnx.ai/onnx/operators/onnx__QLinearMatMul.html
    in_dtypes = [quantif_inputs[1].dtype, quantif_inputs[4].dtype]
    metaop_graph.forward_dtype(in_dtypes)

    # change input nodes to only include input and weight
    input_nodes[:] = [input_nodes[0], input_nodes[3]]

    ### Qoperator metaoperator creation
    qoperator_node = aidge_core.meta_operator(
        "QLinearMatMul", metaop_graph, name=node_name
    )

    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return qoperator_node
