"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import numpy as np
import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import warn_unsupported_attr


@auto_register_import("gru")
def import_gru(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = {attr.name: attr for attr in onnx_node.attribute}

    if "direction" in onnx_attrs:
        if onnx_attrs["direction"].s == b"forward":
            del onnx_attrs["direction"]
        else:
            warn_unsupported_attr("direction", "gru", opset, onnx_attrs["direction"].s)
            return None

    if "hidden_size" in onnx_attrs:
        hidden_channels = onnx_attrs["hidden_size"].i
        del onnx_attrs["hidden_size"]

    if "layout" in onnx_attrs:
        if onnx_attrs["layout"].i == 0:
            del onnx_attrs["layout"]
        else:
            warn_unsupported_attr("layout", "gru", opset, onnx_attrs["layout"].i)
            return None

    if "linear_before_reset" in onnx_attrs:
        if onnx_attrs["linear_before_reset"].i == 0:
            del onnx_attrs["linear_before_reset"]
        else:
            warn_unsupported_attr(
                "linear_before_reset", "gru", opset, onnx_attrs["linear_before_reset"].i
            )
            return None

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'gru' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    # seq_length = input_nodes[0][0].get_operator().get_output(input_nodes[0][1]).dims[0]
    in_channels = (
        input_nodes[1][0].get_operator().get_output(input_nodes[1][1]).dims[-1]
    )
    batch_size = input_nodes[0][0].get_operator().get_output(input_nodes[0][1]).dims[1]

    # Current Aidge GRU meta operator does take separate weights and bias for every FC operator
    # But ONNX GRU takes a concatenated tensor for input, output, forget and cell state gates
    # We therefore create a new meta operator wrapping Aidge GRU and Slices operations
    gru_op = aidge_core.GRUOp(seq_length=0)
    gru = aidge_core.Node(gru_op, name=node_name)
    gru_op.set_upper_node(gru)

    # Add a Pop operator at the input to make scheduling work
    pop = aidge_core.Pop()
    pop.add_child(gru, 0, 0)

    # Weights slicing
    w = aidge_core.Squeeze(axes=[0])
    wz_slice = aidge_core.Slice(starts=[0], ends=[hidden_channels], axes=[0])
    wz_slice.add_child(gru, 0, 1)
    wr_slice = aidge_core.Slice(
        starts=[hidden_channels], ends=[2 * hidden_channels], axes=[0]
    )
    wr_slice.add_child(gru, 0, 2)
    wh_slice = aidge_core.Slice(
        starts=[2 * hidden_channels], ends=[3 * hidden_channels], axes=[0]
    )
    wh_slice.add_child(gru, 0, 3)
    w.add_child(wz_slice, 0, 0)
    w.add_child(wr_slice, 0, 0)
    w.add_child(wh_slice, 0, 0)

    # Recurrent weights slicing
    r = aidge_core.Squeeze(axes=[0])
    rz_slice = aidge_core.Slice(starts=[0], ends=[hidden_channels], axes=[0])
    rz_slice.add_child(gru, 0, 4)
    rr_slice = aidge_core.Slice(
        starts=[hidden_channels], ends=[2 * hidden_channels], axes=[0]
    )
    rr_slice.add_child(gru, 0, 5)
    rh_slice = aidge_core.Slice(
        starts=[2 * hidden_channels], ends=[3 * hidden_channels], axes=[0]
    )
    rh_slice.add_child(gru, 0, 6)
    r.add_child(rz_slice, 0, 0)
    r.add_child(rr_slice, 0, 0)
    r.add_child(rh_slice, 0, 0)

    # Bias slicing
    b = aidge_core.Squeeze(axes=[0])
    bwz_slice = aidge_core.Slice(starts=[0], ends=[hidden_channels], axes=[0])
    bwz_slice.add_child(gru, 0, 7)
    bwr_slice = aidge_core.Slice(
        starts=[hidden_channels], ends=[2 * hidden_channels], axes=[0]
    )
    bwr_slice.add_child(gru, 0, 8)
    bwh_slice = aidge_core.Slice(
        starts=[2 * hidden_channels], ends=[3 * hidden_channels], axes=[0]
    )
    bwh_slice.add_child(gru, 0, 9)
    brz_slice = aidge_core.Slice(
        starts=[3 * hidden_channels], ends=[4 * hidden_channels], axes=[0]
    )
    brz_slice.add_child(gru, 0, 10)
    brr_slice = aidge_core.Slice(
        starts=[4 * hidden_channels], ends=[5 * hidden_channels], axes=[0]
    )
    brr_slice.add_child(gru, 0, 11)
    brh_slice = aidge_core.Slice(
        starts=[5 * hidden_channels], ends=[6 * hidden_channels], axes=[0]
    )
    brh_slice.add_child(gru, 0, 12)
    b.add_child(bwz_slice, 0, 0)
    b.add_child(bwr_slice, 0, 0)
    b.add_child(bwh_slice, 0, 0)
    b.add_child(brz_slice, 0, 0)
    b.add_child(brr_slice, 0, 0)
    b.add_child(brh_slice, 0, 0)

    # State squeeze
    h_squeeze = aidge_core.Squeeze(axes=[0])
    h_squeeze.add_child(gru, 0, 13)

    # Outputs unsqueeze
    out_h = aidge_core.Unsqueeze(axes=[0])
    gru.add_child(out_h, 0, 0)

    # Add a Stack operator at the output
    stack = aidge_core.Stack()
    out_h.add_child(stack, 0, 0)

    input = aidge_core.Identity()
    input_shape = aidge_core.Shape(start=0, end=1)
    input.add_child(pop, 0, 0)
    input.add_child(input_shape, 0, 0)
    input_shape.add_child(stack, 0, 1)

    # Create the graph for the ONNX GRU meta operator with correct input/output ordering
    graph = aidge_core.get_connected_graph_view(gru)
    graph.set_ordered_inputs(
        [[input, 0], [w, 0], [r, 0], [b, 0], [None, 0], [h_squeeze, 0]]
    )
    graph.set_ordered_outputs([[stack, 0], [out_h, 0]])

    inputs_category = [
        aidge_core.InputCategory.Data,
        aidge_core.InputCategory.Param,
        aidge_core.InputCategory.Param,
        aidge_core.InputCategory.Param,
        aidge_core.InputCategory.OptionalData,
        aidge_core.InputCategory.Param,
    ]

    my_node = aidge_core.meta_operator(
        "GRU_ONNX", graph, inputs_category, name=node_name
    )
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )

    # Create default producers
    h_init_def = aidge_core.Producer(
        aidge_core.Tensor(np.zeros([1, batch_size, hidden_channels], dtype=np.float32)),
        constant=True,
    )
    h_init_def.add_child(my_node, 0, 5)
    return my_node
