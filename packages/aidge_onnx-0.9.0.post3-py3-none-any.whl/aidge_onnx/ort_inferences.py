import numpy as np
import onnx

from aidge_core.benchmark.output_wise_comparison import OutputTensorMap, RunResult
from aidge_onnx.utils import onnx_to_aidge_name, set_every_out_as_graph_out

ORT_AVAILABLE = True
try:
    import onnxruntime as ort
except ImportError as e:
    ORT_AVAILABLE = False


def generate_random_inputs_from_onnx(
    model: onnx.ModelProto, input_shape: dict[str, list[int]] = None
) -> dict[str, np.ndarray]:
    """Generate random inputs for an ONNX model.

    :param model: The ONNX model to generate inputs for
    :type model: onnx.ModelProto
    :param input_shape: Optional dict mapping input names to shape lists in nested format.
                        Format: {name: [[dim1, dim2, ...]]}
                        If provided, uses these shapes instead of inferring from model.
    :type input_shape: dict[str, list[int]] | None, optional
    :returns: Dictionary mapping input names to numpy arrays
    :rtype: dict[str, np.ndarray]
    """
    inputs = {}
    initializer_names = [x.name for x in model.graph.initializer]
    for inp in model.graph.input:
        # Skip initializers
        if inp.name in initializer_names:
            continue

        # Use provided input_shape if available
        if input_shape and inp.name in input_shape:
            shape = input_shape[inp.name][
                0
            ]  # Extract shape list from nested list format
        else:
            # Fallback to model specs
            shape = []
            for dim in inp.type.tensor_type.shape.dim:
                if dim.dim_value > 0:
                    shape.append(dim.dim_value)
                else:
                    shape.append(1)  # Use 1 as a fallback for unknown dimensions

        dtype = inp.type.tensor_type.elem_type
        np_dtype = onnx.helper.tensor_dtype_to_np_dtype(dtype)
        rand_input = np.random.rand(*shape).astype(np_dtype)
        inputs[inp.name] = rand_input
    return inputs


def run_ort_outputwise_benchmark(
    model: onnx.ModelProto, inputs: dict[str, np.ndarray]
) -> OutputTensorMap:
    if not ORT_AVAILABLE:
        raise ImportError(
            "ONNX Runtime is not available please use `pip install onnxruntime`."
        )

    set_every_out_as_graph_out(model)

    session = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )

    # Gather outputs
    output_names = [o.name for o in model.graph.output]
    # Run inference
    ort_outs = session.run(output_names, inputs)
    # Generate result dictionary

    ordered_output_names = []
    for node in model.graph.node:
        if node.op_type != "Constant":
            ordered_output_names.extend(node.output)

    return RunResult(
        edge_tensor_map={
            onnx_to_aidge_name(name): val for name, val in zip(output_names, ort_outs)
        },
        topological_order=[
            onnx_to_aidge_name(out_name)
            for n in model.graph.node
            for out_name in n.output
            if n.op_type != "Constant"
        ],
    )
