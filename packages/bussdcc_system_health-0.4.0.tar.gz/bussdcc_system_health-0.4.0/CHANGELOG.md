# Changelog

## [0.4.0](https://github.com/jbussdieker/bussdcc-system-health/compare/v0.3.1...v0.4.0) (2026-02-19)


### Features

* **dependencies:** update bussdcc to version 0.22.0 ([bb7f842](https://github.com/jbussdieker/bussdcc-system-health/commit/bb7f8426ce0798a2fa215b4f09390d44c380d0c1))

## [0.3.1](https://github.com/jbussdieker/bussdcc-system-health/compare/v0.3.0...v0.3.1) (2026-02-18)


### Bug Fixes

* **dependencies:** update bussdcc to version 0.20.1 ([bcecb61](https://github.com/jbussdieker/bussdcc-system-health/commit/bcecb61a459eb553e769bc955764bf717a4d04da))

## [0.3.0](https://github.com/jbussdieker/bussdcc-system-health/compare/v0.2.0...v0.3.0) (2026-02-18)


### Features

* **cli:** enhance CLI with Click and add new options ([b55205e](https://github.com/jbussdieker/bussdcc-system-health/commit/b55205e54134d2fe58171419a608fb5a1c1032cf))
* **system-health:** enhance system health interface with new UI components ([5d8866c](https://github.com/jbussdieker/bussdcc-system-health/commit/5d8866caeea93b7fe72d416b0778690935e09c23))

## [0.2.0](https://github.com/jbussdieker/bussdcc-system-health/compare/v0.1.1...v0.2.0) (2026-02-18)


### Features

* **dependencies:** update bussdcc to version 0.19.0 ([340c719](https://github.com/jbussdieker/bussdcc-system-health/commit/340c719cfa3452631fdcde3940fce8d1279837b6))

## [0.1.1](https://github.com/jbussdieker/bussdcc-system-health/compare/v0.1.0...v0.1.1) (2026-02-17)


### Documentation

* add MIT license ([5f88729](https://github.com/jbussdieker/bussdcc-system-health/commit/5f887292a0424133b10ed0329a58278fecbe94e3))

## 0.1.0 (2026-02-17)


### Features

* initial commit ([2443ba3](https://github.com/jbussdieker/bussdcc-system-health/commit/2443ba35f44a20db882228f0b3ae57a8c453b6ca))
