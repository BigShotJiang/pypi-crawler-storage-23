from mcp.server.fastmcp import FastMCP

# Initialize the MCP server
mcp = FastMCP("Workflow Manager")

# -----------------------------------------------------------------------------
# 1. PROMPT: Injects the rules at the start of the conversation
# -----------------------------------------------------------------------------

@mcp.prompt()
def workflow_instructions() -> str:
    """
    Loads the core workflow and task instructions into the model's context.
    Use this prompt at the beginning of a session to set the behavior.
    """
    return """
# Workflow Instructions

I want you to always use ask the user if there any more tasks to complete after finishing any task. This instruction
will be recurring so that we don't end any turn without any confirmation. If the task is complete always ask the
user if there are any remaining tasks. Once the remaining task is complete, we again start from the beginning of
asking the user for remaining tasks. This will be a loop.

## Task Instructions

Always be in a planning stage where you will asking questions and then after there are no questions left and no further clarifications are needed, you will start executing the task.

## Enforcement Mechanism

To help you follow these rules, you have access to the tool `confirm_task_completion`. 
- You MUST call this tool when you believe a task is done. 
- The tool will remind you to ask the user for the next task.
- You MUST NOT end your response without asking for the next task.
"""

# -----------------------------------------------------------------------------
# 2. TOOLS: Active enforcement during the conversation
# -----------------------------------------------------------------------------

@mcp.tool()
def confirm_task_completion(task_name: str) -> str:
    """
    Call this tool when you have finished executing a specific task.
    This tool records the completion and enforces the workflow rule 
    to ask the user for the next task.
    """
    # In a real app, you might save this to a database. 
    # Here we just return the enforcement reminder.
    return (
        f"Task '{task_name}' has been marked as complete.\n\n"
        "⚠️ WORKFLOW REMINDER: Per your instructions, you must now ask the user "
        "if there are any remaining tasks before ending your turn. Do not stop yet."
    )

@mcp.tool()
def start_planning_phase(topic: str) -> str:
    """
    Call this tool when you are beginning a new task to enter the 'Planning Stage'.
    This reminds you to ask clarifying questions before executing.
    """
    return (
        f"Planning phase started for: '{topic}'.\n\n"
        "⚠️ TASK REMINDER: You are now in the planning stage. You must ask clarifying questions. "
        "Do not execute the task until all questions are answered and no further clarifications are needed."
    )

if __name__ == "__main__":
    # Run the server using stdio transport (default for most clients)
    mcp.run()
