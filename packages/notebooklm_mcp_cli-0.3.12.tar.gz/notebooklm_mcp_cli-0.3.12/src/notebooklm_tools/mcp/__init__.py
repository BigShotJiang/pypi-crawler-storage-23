"""MCP server interface for NotebookLM."""
