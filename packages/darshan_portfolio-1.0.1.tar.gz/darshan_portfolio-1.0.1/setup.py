from setuptools import setup, find_packages

setup(
    name="darshan-portfolio",
    version="1.0.1",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "portfolio=portfolio.portfolio:main",        ],
    },
)
