from redup_servicekit import *

def test_sample():
    assert 0 == 0
