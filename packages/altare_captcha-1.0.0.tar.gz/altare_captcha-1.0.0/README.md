# altare-captcha

Cap.js PoW CAPTCHA solver.

## Install

```bash
pip install altare-captcha
```

## Usage

```python
from altare_captcha import CapSolver

solver = CapSolver("https://api.altare.sh/cap/bb402c6b75/")
cap_token = solver.solve()
```
