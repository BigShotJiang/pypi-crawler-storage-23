import asyncio
import sys
from typing import TYPE_CHECKING, final
import time


@final
class AIOBufferReader:
    """
    AIOBufferReader is a wrapper for asyncio.StreamReader that provides a buffer for reading.

    This class is mainly used to fix the bug with `StreamReader.read_exactly(n)`,
    which has a very serious bug that will make CPU up to 100%.

    This class is not thread-safe, do not call `read_exactly` in multiple coroutines.
    """

    if TYPE_CHECKING:
        _reader: asyncio.StreamReader
        _buffer: bytes

    def __init__(self, reader: asyncio.StreamReader) -> None:
        self._reader = reader
        self._buffer = b""

    async def read_exactly(self, n: int, timeout: float = 2.0) -> bytes | None:
        """
        Read exactly n bytes from the stream.

        This method will block until n bytes are available or timeout.

        Args:
            n: The number of bytes to read.
            timeout: The timeout in seconds.

        Returns:
            The bytes read from the stream. The length of the bytes must be n. Otherwize, None will be returned.
        """
        ddl = time.time() + timeout

        while len(self._buffer) < n:
            try:
                now = time.time()
                timeout_rest = ddl - now

                data = await asyncio.wait_for(
                    self._reader.read(sys.maxsize), timeout_rest
                )

                if len(data) == 0:
                    asyncio.sleep(0.01)  # sleep 10ms to avoid busy loop
                    continue

                self._buffer += data
            except asyncio.TimeoutError:
                return None

        result = self._buffer[:n]
        self._buffer = self._buffer[n:]
        return result
