#############
API reference
#############

.. automodule:: scifem
    :members:

.. automodule:: scifem.petsc
    :members:
