"""Services tests for Bedrock AgentCore SDK."""
