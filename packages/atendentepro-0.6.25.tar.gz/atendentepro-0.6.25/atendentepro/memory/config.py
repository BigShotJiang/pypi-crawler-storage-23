# -*- coding: utf-8 -*-
"""
Optional configuration for the memory module.

Used when creating a GRK backend from config (e.g. future memory_config.yaml).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class MemoryConfig:
    """Configuration for long-context memory (e.g. GRKMemory)."""

    enabled: bool = True
    search_method: str = "graph"
    memory_limit: int = 5
    memory_threshold: float = 0.3
    memory_file: Optional[str] = None
    memory_header: str = "Memória relevante (conversas anteriores):"
    extra: Dict[str, Any] = field(default_factory=dict)
