# -*- coding: utf-8 -*-
"""
Applier: read client YAML, apply Suggestion changes, write back with optional backup and dry_run.
Also supports writing to a suggested folder for user review and replace_originals_with_suggested.
"""

from __future__ import annotations

import json
import shutil
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml

from atendentepro.tuning.suggestions import Suggestion

REPORT_FILENAME = "_suggestions_report.json"


def _apply_add_triage_keyword(data: Dict[str, Any], payload: Dict[str, Any]) -> None:
    """Add a keyword to triage_config keywords for target_agent."""
    target_agent = payload.get("target_agent") or ""
    keyword = (payload.get("keyword") or "").strip()
    if not target_agent or not keyword:
        return
    keywords = data.get("keywords") or {}
    if not isinstance(keywords, dict):
        data["keywords"] = {}
        keywords = data["keywords"]
    entry = keywords.get(target_agent)
    if isinstance(entry, dict):
        kws = entry.get("keywords") or []
        if keyword not in kws:
            kws.append(keyword)
        entry["keywords"] = kws
    elif isinstance(entry, list):
        if keyword not in entry:
            entry.append(keyword)
    else:
        keywords[target_agent] = [keyword]


def _apply_add_escalation_trigger(data: Dict[str, Any], payload: Dict[str, Any]) -> None:
    """Add a trigger phrase to escalation_config triggers (explicit_request or frustration)."""
    phrase = (payload.get("trigger_phrase") or "").strip()
    if not phrase:
        return
    triggers = data.get("triggers") or {}
    if not isinstance(triggers, dict):
        data["triggers"] = {}
        triggers = data["triggers"]
    explicit = triggers.get("explicit_request") or []
    if isinstance(explicit, list) and phrase not in explicit:
        explicit.append(phrase)
        triggers["explicit_request"] = explicit
    data["triggers"] = triggers


def _apply_suggestion_to_data(data: Dict[str, Any], suggestion: Suggestion) -> bool:
    """Apply one suggestion to loaded YAML data. Returns True if applied."""
    ct = suggestion.change_type
    payload = suggestion.payload or {}
    if ct == "add_triage_keyword":
        _apply_add_triage_keyword(data, payload)
        return True
    if ct == "add_escalation_trigger":
        _apply_add_escalation_trigger(data, payload)
        return True
    if ct == "feedback_ensure_reclamacao":
        # Informational; no structural change to YAML in this heuristic
        return False
    return False


def apply_suggestions(
    client: str,
    suggestions: List[Suggestion],
    templates_root: Path,
    dry_run: bool = True,
    backup: bool = True,
) -> List[Tuple[Suggestion, str]]:
    """
    Apply suggestions to client YAML files under templates_root / client.

    Args:
        client: Client key (folder name under templates_root).
        suggestions: List of Suggestion from run_analysis.
        templates_root: Root path containing client template folders.
        dry_run: If True, do not write files; return would-be applied list.
        backup: If True and not dry_run, copy each file to .bak before writing.

    Returns:
        List of (suggestion, status) where status is "applied", "skipped", "dry_run", or "error".
    """
    folder = templates_root / client
    if not folder.is_dir():
        return [(s, "error: folder not found") for s in suggestions]

    results: List[Tuple[Suggestion, str]] = []
    for s in suggestions:
        path = folder / s.yaml_file
        if not path.exists():
            results.append((s, "skipped: file not found"))
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                results.append((s, "error: invalid yaml structure"))
                continue
            applied = _apply_suggestion_to_data(data, s)
            if not applied:
                results.append((s, "skipped: no change"))
                continue
            if dry_run:
                results.append((s, "dry_run"))
                continue
            if backup:
                bak = path.with_suffix(path.suffix + ".bak")
                shutil.copy2(path, bak)
            with open(path, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
            results.append((s, "applied"))
        except Exception as e:
            results.append((s, f"error: {e}"))
    return results


def write_suggestions_to_folder(
    client: str,
    suggestions: List[Suggestion],
    templates_root: Path,
    suggested_subdir: str = "_suggested",
) -> Dict[str, Any]:
    """
    Write modified YAMLs to a suggested subfolder for user review. Originals are unchanged.

    Groups suggestions by yaml_file, applies all changes per file, and writes to
    templates_root / client / suggested_subdir. Also writes _suggestions_report.json.

    Args:
        client: Client key (folder name under templates_root).
        suggestions: List of Suggestion from run_analysis.
        templates_root: Root path containing client template folders.
        suggested_subdir: Subfolder name under client (default "_suggested").

    Returns:
        Dict with suggested_folder (Path), written_files (List[str]), report_path (Path),
        per_suggestion (List[Tuple[Suggestion, str]]).
    """
    folder = templates_root / client
    suggested_folder = folder / suggested_subdir
    per_suggestion: List[Tuple[Suggestion, str]] = []
    written_files: List[str] = []
    report_suggestions: List[Dict[str, Any]] = []

    if not folder.is_dir():
        return {
            "suggested_folder": suggested_folder,
            "written_files": [],
            "report_path": suggested_folder / REPORT_FILENAME,
            "per_suggestion": [(s, "error: folder not found") for s in suggestions],
        }

    # Group by yaml_file
    by_file: Dict[str, List[Suggestion]] = defaultdict(list)
    for s in suggestions:
        by_file[s.yaml_file].append(s)

    suggested_folder.mkdir(parents=True, exist_ok=True)

    for yaml_file, file_suggestions in by_file.items():
        path = folder / yaml_file
        if not path.exists():
            for s in file_suggestions:
                per_suggestion.append((s, "skipped: file not found"))
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                for s in file_suggestions:
                    per_suggestion.append((s, "error: invalid yaml structure"))
                continue
            applied_any = False
            for s in file_suggestions:
                applied = _apply_suggestion_to_data(data, s)
                if applied:
                    applied_any = True
                    per_suggestion.append((s, "written"))
                    report_suggestions.append({
                        "yaml_file": s.yaml_file,
                        "agent_name": s.agent_name,
                        "change_type": s.change_type,
                        "reason": s.reason,
                        "payload": s.payload,
                    })
                else:
                    per_suggestion.append((s, "skipped: no change"))
            if applied_any:
                out_path = suggested_folder / yaml_file
                with open(out_path, "w", encoding="utf-8") as f:
                    yaml.safe_dump(
                        data, f, allow_unicode=True, default_flow_style=False, sort_keys=False
                    )
                written_files.append(yaml_file)
        except Exception as e:
            for s in file_suggestions:
                per_suggestion.append((s, f"error: {e}"))

    report_path = suggested_folder / REPORT_FILENAME
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "client": client,
        "suggested_folder": str(suggested_folder),
        "written_files": written_files,
        "suggestions": report_suggestions,
    }
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    return {
        "suggested_folder": suggested_folder,
        "written_files": written_files,
        "report_path": report_path,
        "per_suggestion": per_suggestion,
    }


def replace_originals_with_suggested(
    client: str,
    templates_root: Path,
    suggested_subdir: str = "_suggested",
    remove_suggested_after: bool = False,
) -> Dict[str, Any]:
    """
    Copy YAML files from client/suggested_subdir to client/, overwriting originals.
    Does not copy the report file. Call after user has reviewed the suggested folder.

    Args:
        client: Client key (folder name under templates_root).
        templates_root: Root path containing client template folders.
        suggested_subdir: Subfolder name under client (default "_suggested").
        remove_suggested_after: If True, remove suggested_subdir after copying.

    Returns:
        Dict with replaced_files (List[str]) and errors (List[str]).
    """
    folder = templates_root / client
    suggested_folder = folder / suggested_subdir
    replaced_files: List[str] = []
    errors: List[str] = []

    if not suggested_folder.is_dir():
        return {"replaced_files": [], "errors": ["suggested folder not found"]}

    for path in suggested_folder.iterdir():
        if not path.is_file() or path.suffix not in (".yaml", ".yml"):
            continue
        if path.name == REPORT_FILENAME:
            continue
        dest = folder / path.name
        try:
            shutil.copy2(path, dest)
            replaced_files.append(path.name)
        except Exception as e:
            errors.append(f"{path.name}: {e}")

    if remove_suggested_after and replaced_files:
        try:
            shutil.rmtree(suggested_folder)
        except Exception as e:
            errors.append(f"remove_suggested_after: {e}")

    return {"replaced_files": replaced_files, "errors": errors}
