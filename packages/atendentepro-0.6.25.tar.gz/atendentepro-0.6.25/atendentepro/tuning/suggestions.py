# -*- coding: utf-8 -*-
"""
Pydantic models for tuning suggestions.

A Suggestion describes a single change to apply to a client YAML file.
"""

from typing import Any, Dict

from pydantic import BaseModel, Field


class Suggestion(BaseModel):
    """A suggested change to a client YAML config file."""

    yaml_file: str = Field(..., description="Target YAML filename (e.g. triage_config.yaml)")
    agent_name: str = Field("", description="Agent name from feedback, if applicable")
    change_type: str = Field(
        ...,
        description="Type of change, e.g. add_triage_keyword, add_escalation_trigger",
    )
    payload: Dict[str, Any] = Field(
        default_factory=dict,
        description="Structured data for the change (e.g. keyword, agent key, trigger text)",
    )
    reason: str = Field("", description="Human-readable reason, e.g. from feedback description")
