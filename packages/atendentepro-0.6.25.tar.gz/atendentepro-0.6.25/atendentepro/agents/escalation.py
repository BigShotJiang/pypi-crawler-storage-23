# -*- coding: utf-8 -*-
"""
Escalation Agent for AtendentePro.

Handles transfers to human support when:
- User explicitly requests
- Topic is not covered by the system
- Agent cannot resolve the issue
- User shows frustration or confusion
"""

from __future__ import annotations

try:
    from typing import TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

import logging
import os
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any, TYPE_CHECKING
from dataclasses import dataclass, field

from agents import Agent, function_tool

from atendentepro.config import RECOMMENDED_PROMPT_PREFIX
from atendentepro.models import ContextNote
from atendentepro.prompts.escalation import (
    get_escalation_prompt,
    EscalationPromptBuilder,
    ESCALATION_INTRO,
    DEFAULT_ESCALATION_TRIGGERS,
)

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable

logger = logging.getLogger(__name__)

# Type alias for the Escalation Agent
EscalationAgent: TypeAlias = Agent[ContextNote]


# =============================================================================
# Configurações de Escalação
# =============================================================================

# Horário de atendimento padrão (pode ser sobrescrito via config)
DEFAULT_BUSINESS_HOURS = {
    "start": 8,
    "end": 18,
    "days": [0, 1, 2, 3, 4],  # Seg-Sex
}

# Configurable business hours (None = use DEFAULT_BUSINESS_HOURS)
_configured_business_hours: Optional[Dict[str, Any]] = None

# Configurable priority keywords (None = use defaults)
_priority_keywords_urgent: Optional[List[str]] = None
_priority_keywords_high: Optional[List[str]] = None


# =============================================================================
# Storage de Escalações (em memória - substituir por DB em produção)
# =============================================================================

@dataclass
class Escalation:
    """Representa uma escalação para atendimento humano."""
    protocolo: str
    motivo: str
    categoria: str  # solicitacao, frustração, topico_nao_coberto, incerteza
    nome_usuario: str
    contato: str
    tipo_contato: str  # telefone, email, whatsapp
    resumo_conversa: str
    prioridade: str  # baixa, normal, alta, urgente
    status: str  # pendente, em_atendimento, concluido, cancelado
    data_criacao: datetime = field(default_factory=datetime.now)
    data_atualizacao: datetime = field(default_factory=datetime.now)
    atendente: Optional[str] = None
    observacoes: Optional[str] = None


# Storage em memória
_escalations_storage: Dict[str, Escalation] = {}


def _gerar_protocolo_escalacao() -> str:
    """Gera um protocolo único para escalação."""
    timestamp = datetime.now().strftime("%Y%m%d")
    unique_id = uuid.uuid4().hex[:6].upper()
    return f"ESC-{timestamp}-{unique_id}"


def _salvar_escalacao(escalation: Escalation) -> None:
    """Salva escalação no storage."""
    _escalations_storage[escalation.protocolo] = escalation


def _buscar_escalacao(protocolo: str) -> Optional[Escalation]:
    """Busca escalação pelo protocolo."""
    return _escalations_storage.get(protocolo.upper())


def _listar_escalacoes_pendentes() -> List[Escalation]:
    """Lista escalações pendentes."""
    return [
        e for e in _escalations_storage.values()
        if e.status == "pendente"
    ]


# =============================================================================
# Funções de Notificação (implementar conforme necessidade)
# =============================================================================

def _notificar_equipe(escalation: Escalation) -> bool:
    """
    Notifica a equipe sobre nova escalação via webhook com retry.

    Em produção, integrar com:
    - Email (SMTP)
    - Slack/Teams
    - Sistema de tickets
    - Webhook
    """
    webhook_url = os.getenv("ESCALATION_WEBHOOK_URL")

    if webhook_url:
        import hashlib
        import hmac as _hmac
        import json as _json

        import httpx

        payload = {
            "protocolo": escalation.protocolo,
            "motivo": escalation.motivo,
            "prioridade": escalation.prioridade,
            "usuario": escalation.nome_usuario,
            "contato": escalation.contato,
            "resumo": escalation.resumo_conversa,
        }

        headers: Dict[str, str] = {"Content-Type": "application/json"}

        webhook_secret = os.getenv("ESCALATION_WEBHOOK_SECRET")
        if webhook_secret:
            payload_bytes = _json.dumps(
                payload, separators=(",", ":"), sort_keys=True
            ).encode()
            sig = _hmac.new(
                webhook_secret.encode(), payload_bytes, hashlib.sha256
            ).hexdigest()
            headers["X-Webhook-Signature"] = f"sha256={sig}"
        else:
            logger.warning(
                "ESCALATION_WEBHOOK_SECRET nao configurado. "
                "Webhook enviado sem assinatura HMAC."
            )

        max_attempts = 2
        for attempt in range(max_attempts):
            try:
                resp = httpx.post(webhook_url, json=payload, headers=headers, timeout=5.0)
                resp.raise_for_status()
                return True
            except Exception as e:
                if attempt < max_attempts - 1:
                    logger.warning("Tentativa %d de webhook falhou: %s. Retentando...", attempt + 1, e)
                else:
                    logger.warning("Erro ao notificar webhook apos %d tentativas: %s", max_attempts, e)
                    return False

    logger.info("Nova escalação: %s", escalation.protocolo)
    return True


def _verificar_disponibilidade() -> Dict[str, Any]:
    """Verifica se atendimento humano está disponível."""
    global _configured_business_hours
    agora = datetime.now()
    hora = agora.hour
    dia = agora.weekday()
    
    # Use configured business hours or fall back to defaults
    if _configured_business_hours:
        business_hours = _configured_business_hours
        hora_inicio = business_hours.get("start", DEFAULT_BUSINESS_HOURS["start"])
        hora_fim = business_hours.get("end", DEFAULT_BUSINESS_HOURS["end"])
        days = business_hours.get("days", DEFAULT_BUSINESS_HOURS["days"])
    else:
        # Verificar variáveis de ambiente para horário customizado
        hora_inicio = int(os.getenv("ESCALATION_HOUR_START", str(DEFAULT_BUSINESS_HOURS["start"])))
        hora_fim = int(os.getenv("ESCALATION_HOUR_END", str(DEFAULT_BUSINESS_HOURS["end"])))
        days = DEFAULT_BUSINESS_HOURS["days"]

    # Ensure days is a list of integers
    if isinstance(days, list):
        days_int = [d if isinstance(d, int) else int(d) for d in days]
    else:
        raw_days = DEFAULT_BUSINESS_HOURS["days"]
        days_int = list(raw_days) if isinstance(raw_days, list) else [0, 1, 2, 3, 4]
    
    disponivel = dia in days_int and hora_inicio <= hora < hora_fim
    
    # Format days for display
    day_names = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
    if len(days_int) == 1:
        dias_atendimento = day_names[days_int[0]]
    elif len(days_int) == 5 and days_int == [0, 1, 2, 3, 4]:
        dias_atendimento = "Segunda a Sexta"
    else:
        dias_atendimento = ", ".join(day_names[d] for d in sorted(days_int))
    
    return {
        "disponivel": disponivel,
        "hora_atual": agora.strftime("%H:%M"),
        "dia_semana": day_names[dia],
        "horario_atendimento": f"{hora_inicio:02d}:00 - {hora_fim:02d}:00",
        "dias_atendimento": dias_atendimento,
    }


# =============================================================================
# Classificação Automática de Prioridade
# =============================================================================

def _classificar_prioridade(motivo: str, categoria: str) -> str:
    """
    Classifica automaticamente a prioridade baseado no motivo e categoria.
    """
    global _priority_keywords_urgent, _priority_keywords_high
    motivo_lower = motivo.lower()
    
    # Use configured keywords or defaults
    palavras_urgentes = _priority_keywords_urgent or [
        "urgente", "emergência", "emergencia", "crítico", "critico",
        "não funciona", "parou", "bloqueado", "cancelar", "prejuízo"
    ]
    
    palavras_alta = _priority_keywords_high or [
        "reclamação", "reclamacao", "insatisfeito", "problema grave",
        "já tentei", "terceira vez", "não resolve"
    ]
    
    # Verificar urgência
    for palavra in palavras_urgentes:
        if palavra in motivo_lower:
            return "urgente"
    
    # Verificar alta prioridade
    for palavra in palavras_alta:
        if palavra in motivo_lower:
            return "alta"
    
    # Frustração do usuário = alta
    if categoria == "frustracao":
        return "alta"
    
    return "normal"


# =============================================================================
# Tools do Agente de Escalação
# =============================================================================

@function_tool
def verificar_horario_atendimento() -> str:
    """
    Verifica se o atendimento humano está disponível no momento atual.
    Use esta ferramenta ANTES de registrar a escalação para informar o usuário.
    
    Returns:
        Status de disponibilidade do atendimento humano
    """
    info = _verificar_disponibilidade()
    
    if info["disponivel"]:
        return f"""✅ **Atendimento Humano DISPONÍVEL**

📅 {info['dia_semana']}, {info['hora_atual']}
⏰ Horário de atendimento: {info['horario_atendimento']}

Um atendente poderá retornar em breve após o registro."""
    else:
        return f"""⚠️ **Atendimento Humano FORA DO HORÁRIO**

📅 {info['dia_semana']}, {info['hora_atual']}
⏰ Horário de atendimento: {info['horario_atendimento']}
📆 Dias: {info['dias_atendimento']}

Você pode deixar seus dados e retornaremos no próximo horário disponível."""


@function_tool
def registrar_escalacao(
    motivo: str,
    nome_usuario: str,
    contato: str,
    tipo_contato: str = "telefone",
    resumo_conversa: str = "",
    categoria: str = "solicitacao",
) -> str:
    """
    Registra uma escalação para atendimento humano e notifica a equipe.
    
    IMPORTANTE: Use esta ferramenta quando:
    - O usuário solicitar falar com um humano
    - O tópico não for coberto pelo sistema
    - Não conseguir resolver o problema do usuário
    - O usuário demonstrar frustração
    
    Args:
        motivo: Motivo da escalação (descrição do que o usuário precisa)
        nome_usuario: Nome do usuário para contato
        contato: Telefone, email ou WhatsApp do usuário
        tipo_contato: Tipo de contato preferido ("telefone", "email", "whatsapp")
        resumo_conversa: Breve resumo do que foi discutido antes da escalação
        categoria: Categoria da escalação:
                  - "solicitacao": Usuário pediu para falar com humano
                  - "frustracao": Usuário demonstrou frustração
                  - "topico_nao_coberto": Assunto fora do escopo
                  - "incerteza": Agente não conseguiu resolver
              
    Returns:
        Confirmação com protocolo e próximos passos
    """
    # Validações
    if not nome_usuario or len(nome_usuario.strip()) < 2:
        return "❌ Por favor, informe seu nome completo para que possamos retornar."
    
    if not contato or len(contato.strip()) < 5:
        return "❌ Por favor, informe um contato válido (telefone, email ou WhatsApp)."
    
    if not motivo or len(motivo.strip()) < 5:
        return "❌ Por favor, descreva brevemente o motivo do contato."
    
    # Normalizar tipo de contato
    tipo_contato_norm = tipo_contato.lower().strip()
    if tipo_contato_norm not in ["telefone", "email", "whatsapp"]:
        tipo_contato_norm = "telefone"
    
    # Normalizar categoria
    categorias_validas = ["solicitacao", "frustracao", "topico_nao_coberto", "incerteza"]
    categoria_norm = categoria.lower().strip()
    if categoria_norm not in categorias_validas:
        categoria_norm = "solicitacao"
    
    # Classificar prioridade automaticamente
    prioridade = _classificar_prioridade(motivo, categoria_norm)
    
    # Criar escalação
    escalation = Escalation(
        protocolo=_gerar_protocolo_escalacao(),
        motivo=motivo.strip(),
        categoria=categoria_norm,
        nome_usuario=nome_usuario.strip(),
        contato=contato.strip(),
        tipo_contato=tipo_contato_norm,
        resumo_conversa=resumo_conversa.strip() if resumo_conversa else "",
        prioridade=prioridade,
        status="pendente",
    )
    
    # Salvar
    _salvar_escalacao(escalation)
    
    # Notificar equipe
    notificado = _notificar_equipe(escalation)
    
    # Verificar disponibilidade
    disp = _verificar_disponibilidade()
    
    # Ícones por prioridade
    icone_prioridade = {
        "baixa": "🟢",
        "normal": "🟡",
        "alta": "🟠",
        "urgente": "🔴",
    }.get(prioridade, "🟡")
    
    # Ícones por tipo de contato
    icone_contato = {
        "telefone": "📞",
        "email": "📧",
        "whatsapp": "💬",
    }.get(tipo_contato_norm, "📞")
    
    resposta = f"""
✅ **Escalação Registrada com Sucesso!**

═══════════════════════════════════════
📋 **Protocolo:** {escalation.protocolo}
═══════════════════════════════════════

👤 **Nome:** {escalation.nome_usuario}
{icone_contato} **Contato ({tipo_contato_norm}):** {escalation.contato}
{icone_prioridade} **Prioridade:** {prioridade.upper()}
📅 **Data:** {escalation.data_criacao.strftime('%d/%m/%Y às %H:%M')}

📝 **Motivo:**
{escalation.motivo}
"""
    
    if escalation.resumo_conversa:
        resposta += f"""
📄 **Resumo da conversa:**
{escalation.resumo_conversa[:200]}{'...' if len(escalation.resumo_conversa) > 200 else ''}
"""
    
    resposta += "\n═══════════════════════════════════════\n"
    
    if disp["disponivel"]:
        resposta += """
⏳ **Próximos Passos:**
Um atendente humano entrará em contato em breve.
"""
    else:
        resposta += f"""
⏳ **Próximos Passos:**
Estamos fora do horário de atendimento ({disp['horario_atendimento']}).
Um atendente retornará no próximo dia útil.
"""
    
    resposta += f"""
💡 **Dica:** Guarde o protocolo **{escalation.protocolo}** para acompanhamento.
"""
    
    if notificado:
        resposta += "\n✅ Nossa equipe foi notificada."
    
    return resposta


@function_tool
def consultar_escalacao(protocolo: str) -> str:
    """
    Consulta o status de uma escalação pelo protocolo.
    
    Args:
        protocolo: Número do protocolo (ex: ESC-20240105-ABC123)
        
    Returns:
        Status e detalhes da escalação
    """
    escalation = _buscar_escalacao(protocolo)
    
    if not escalation:
        return f"""❌ **Escalação não encontrada:** {protocolo}

Verifique se o número do protocolo está correto.
Formato esperado: ESC-YYYYMMDD-XXXXXX"""
    
    # Ícones de status
    icone_status = {
        "pendente": "🟡",
        "em_atendimento": "🔵",
        "concluido": "🟢",
        "cancelado": "⚫",
    }.get(escalation.status, "⚪")
    
    resposta = f"""
📋 **Consulta de Escalação**

═══════════════════════════════════════
🔖 **Protocolo:** {escalation.protocolo}
{icone_status} **Status:** {escalation.status.upper().replace('_', ' ')}
═══════════════════════════════════════

👤 **Solicitante:** {escalation.nome_usuario}
📞 **Contato:** {escalation.contato} ({escalation.tipo_contato})
⚡ **Prioridade:** {escalation.prioridade.upper()}

📅 **Criado em:** {escalation.data_criacao.strftime('%d/%m/%Y às %H:%M')}
📅 **Atualizado em:** {escalation.data_atualizacao.strftime('%d/%m/%Y às %H:%M')}

📝 **Motivo:**
{escalation.motivo}
"""
    
    if escalation.atendente:
        resposta += f"\n👨‍💼 **Atendente:** {escalation.atendente}"
    
    if escalation.observacoes:
        resposta += f"\n\n📌 **Observações:**\n{escalation.observacoes}"
    
    return resposta


# =============================================================================
# Lista de Tools
# =============================================================================

ESCALATION_TOOLS = [
    verificar_horario_atendimento,
    registrar_escalacao,
    consultar_escalacao,
]


# =============================================================================
# Triggers e Instruções movidos para atendentepro/prompts/escalation.py
# =============================================================================

# Re-exportar para compatibilidade
# DEFAULT_ESCALATION_TRIGGERS e ESCALATION_INTRO estão em prompts/escalation.py


# =============================================================================
# Criar Escalation Agent
# =============================================================================

def create_escalation_agent(
    escalation_triggers: str = "",
    escalation_channels: str = "",
    business_hours: Optional[Dict[str, Any]] = None,
    priority_keywords_urgent: Optional[List[str]] = None,
    priority_keywords_high: Optional[List[str]] = None,
    handoffs: Optional[List] = None,
    tools: Optional[List] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Escalation Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
) -> EscalationAgent:
    """
    Create an Escalation Agent instance.
    
    The escalation agent handles transfers to human support when:
    - User explicitly requests to talk to a human
    - Topic is not covered by the automated system
    - Agent cannot resolve the issue after attempts
    - User shows frustration or confusion
    
    This agent should be added as a handoff option to ALL other agents
    in the network to ensure users can always escalate when needed.
    
    Args:
        escalation_triggers: Custom triggers for escalation (keywords, situations).
        escalation_channels: Available contact channels description.
        business_hours: Optional dict with "start", "end", and "days" (list of weekday numbers 0-6 or day names).
        priority_keywords_urgent: Optional list of keywords that indicate urgent priority.
        priority_keywords_high: Optional list of keywords that indicate high priority.
        handoffs: List of agents to hand off to (usually triage to return).
        tools: Additional tools (custom notifications, integrations).
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        
    Returns:
        Configured Escalation Agent instance.
        
    Example:
        >>> escalation = create_escalation_agent(
        ...     escalation_channels="Telefone: 0800-123-4567 (Seg-Sex 8h-18h)",
        ...     handoffs=[triage],
        ... )
        >>> # Add to all agents
        >>> triage.handoffs.append(escalation)
        >>> flow.handoffs.append(escalation)
    """
    global _configured_business_hours, _priority_keywords_urgent, _priority_keywords_high
    
    # Configure business hours
    if business_hours:
        # Convert day names to weekday numbers if needed
        days = business_hours.get("days", [])
        if days and isinstance(days[0], str):
            day_map = {
                "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                "friday": 4, "saturday": 5, "sunday": 6,
            }
            days_int = [day_map.get(day.lower(), day) for day in days if day.lower() in day_map]
            business_hours = {**business_hours, "days": days_int}
        _configured_business_hours = business_hours
    else:
        _configured_business_hours = None
    
    # Configure priority keywords
    _priority_keywords_urgent = priority_keywords_urgent
    _priority_keywords_high = priority_keywords_high
    
    if custom_instructions:
        instructions = f"{RECOMMENDED_PROMPT_PREFIX} {custom_instructions}"
    else:
        # Usar o prompt builder do módulo prompts
        instructions = f"{RECOMMENDED_PROMPT_PREFIX}\n{get_escalation_prompt(escalation_triggers=escalation_triggers, escalation_channels=escalation_channels)}"
    
    # Append style instructions if provided
    if style_instructions:
        instructions += style_instructions
    
    # Single reply mode: respond once then return to triage
    if single_reply:
        instructions += "\n\nIMPORTANTE: Após fornecer sua resposta, transfira IMEDIATAMENTE para o triage_agent. Você só pode dar UMA resposta antes de transferir."
    
    # Combinar tools padrão com customizadas
    agent_tools = list(ESCALATION_TOOLS)
    if tools:
        agent_tools.extend(tools)
    
    return Agent[ContextNote](
        name=name,
        handoff_description="Transfere para atendimento humano quando o agente não consegue resolver, o tópico não é coberto, ou o usuário solicita.",
        instructions=instructions,
        tools=agent_tools,
        handoffs=handoffs or [],
        input_guardrails=guardrails or [],
    )

