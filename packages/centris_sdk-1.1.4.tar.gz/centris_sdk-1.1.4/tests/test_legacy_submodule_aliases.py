"""Compatibility tests for legacy `centris_sdk.<module>` import paths."""

import importlib

_LEGACY_MODULE_ALIASES = {
    "centris_sdk.action_api": "centris_sdk.action.api",
    "centris_sdk.action_cache": "centris_sdk.client.action_cache",
    "centris_sdk.adapter_runtime": "centris_sdk.runtime.adapter_runtime",
    "centris_sdk.capability": "centris_sdk.connector.capability",
    "centris_sdk.decorators": "centris_sdk.connector.decorators",
    "centris_sdk.execute_task": "centris_sdk.client.execute_task",
    "centris_sdk.extract": "centris_sdk.client.extract",
    "centris_sdk.kernel": "centris_sdk.action.kernel",
    "centris_sdk.plugin_api": "centris_sdk.connector.plugin_api",
    "centris_sdk.types": "centris_sdk.connector.types",
    "centris_sdk.validation": "centris_sdk.connector.validation",
}


def test_legacy_module_aliases_import_to_canonical_paths() -> None:
    # Import package first to ensure alias registration runs.
    importlib.import_module("centris_sdk")

    for legacy_name, canonical_name in _LEGACY_MODULE_ALIASES.items():
        legacy_module = importlib.import_module(legacy_name)
        canonical_module = importlib.import_module(canonical_name)
        assert legacy_module is canonical_module
