"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.agentic.action_api_cmd import *  # noqa: F401,F403
