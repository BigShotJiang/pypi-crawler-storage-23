"""Tests for web memory CLI helper behavior."""

from __future__ import annotations

import json

from centris_sdk.cli.commands.agentic.web_memory_cmd import _derive_snapshot_indexing


def test_derive_snapshot_indexing_adds_semantic_anchors_and_node_id_fallback(tmp_path) -> None:
    snapshot_path = tmp_path / "snapshot.json"
    snapshot_path.write_text(
        json.dumps(
            {
                "metadata": {"title": "Demo"},
                "interactiveNodes": [
                    {
                        "id": 42,
                        "n": "Submit",
                        "r": "button",
                        "selector": "button[type=submit]",
                        "ariaLabel": "Submit form",
                        "placeholder": "unused",
                        "testId": "submit-btn",
                        "businessId": "checkout-submit",
                    }
                ],
                "headings": ["Checkout"],
                "navLabels": ["Cart"],
            }
        ),
        encoding="utf-8",
    )

    _fingerprint, action_index = _derive_snapshot_indexing(
        snapshot_file=str(snapshot_path),
        url="https://example.com/checkout",
        intent="checkout",
        fingerprint_id="fp-checkout",
    )

    assert len(action_index) == 1
    first = action_index[0]
    assert first.node_hints[0].node_id == 42
    anchor_types = {anchor.anchor_type for anchor in first.anchors}
    assert "label" in anchor_types
    assert "selector" in anchor_types
    assert "aria_label" in anchor_types
    assert "test_id" in anchor_types
    assert "business_id" in anchor_types
