"""Agent and direct tool command registration."""

import click


def register_agentic_commands(cli: click.Group) -> None:
    """Register direct execution and tool-style command groups."""
    from centris_sdk.cli.browser import browser_group
    from centris_sdk.cli.daemon import daemon_group
    from centris_sdk.cli.sandbox import sandbox_group

    from .action_api_cmd import act_command, observe_command, route_group, verify_command
    from .agent_cmd import agent_command
    from .desktop_cmd import desktop_group
    from .do_cmd import do_command
    from .elements_cmd import elements_group
    from .file_cmd import file_group
    from .retrieval_cmd import retrieval_group
    from .web_memory_cmd import web_memory_group

    cli.add_command(agent_command, name="agent")
    cli.add_command(do_command, name="do")
    cli.add_command(browser_group, name="browser")
    cli.add_command(desktop_group, name="desktop")
    cli.add_command(file_group, name="file")
    cli.add_command(observe_command, name="observe")
    cli.add_command(act_command, name="act")
    cli.add_command(verify_command, name="verify")
    cli.add_command(route_group, name="route")
    cli.add_command(retrieval_group, name="retrieval")
    cli.add_command(web_memory_group, name="web-memory")
    cli.add_command(daemon_group, name="daemon")
    cli.add_command(sandbox_group, name="sandbox")
    cli.add_command(elements_group, name="elements")


__all__ = ["register_agentic_commands"]
