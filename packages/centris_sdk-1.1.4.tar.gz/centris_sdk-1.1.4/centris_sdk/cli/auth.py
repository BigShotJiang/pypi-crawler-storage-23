"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.catalog.auth import *  # noqa: F401,F403
