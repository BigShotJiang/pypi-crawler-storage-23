---
tags:
  category: system
  context: prompt
---
# .prompt/agent/subagent-start

Context for subagent initialization.

## Prompt

Review this context, and investigate if necessary:

{get}

Note any open commitments and recent learnings relevant to this task.
Reflect before this work is finished.
