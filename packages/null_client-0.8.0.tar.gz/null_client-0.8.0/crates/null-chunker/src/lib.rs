use fastcdc::v2020::StreamCDC;
use pyo3::exceptions::PyIOError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use pyo3_stub_gen::derive::{gen_stub_pyclass, gen_stub_pyfunction, gen_stub_pymethods};
use std::fs::File;
use std::io::{self, Read, Seek, SeekFrom};

/// Default chunk size constants (matching null-cli)
const MIN_CHUNK_SIZE: u32 = 256 * 1024; // 256 KB
const AVG_CHUNK_SIZE: u32 = 1024 * 1024; // 1 MB
const MAX_CHUNK_SIZE: u32 = 4 * 1024 * 1024; // 4 MB
const MAX_TREE_ENTRIES: usize = 2000;
const TARGET_SQLITE_CHUNK_SIZE: usize = 64 * 1024; // 64KB

/// A single chunk from content-defined chunking
#[gen_stub_pyclass]
#[pyclass(module = "null_client._chunker")]
#[derive(Clone)]
pub struct Chunk {
    #[pyo3(get)]
    pub offset: u64,
    #[pyo3(get)]
    pub length: usize,
    data: Vec<u8>,
}

#[gen_stub_pymethods]
#[pymethods]
impl Chunk {
    #[getter]
    fn data<'py>(&self, py: Python<'py>) -> Bound<'py, PyBytes> {
        PyBytes::new(py, &self.data)
    }

    fn __repr__(&self) -> String {
        format!(
            "Chunk(offset={}, length={}, data=<{} bytes>)",
            self.offset,
            self.length,
            self.data.len()
        )
    }
}

/// Chunker that splits SQLite files at page boundaries for efficient dedup
/// Groups multiple pages per chunk to reach the target chunk size
pub struct SqliteChunker<R> {
    file: R,
    page_size: usize,
    pages_per_chunk: usize,
    offset: u64,
    file_len: u64,
}

impl<R: Read + Seek> SqliteChunker<R> {
    pub fn new(mut file: R) -> io::Result<Self> {
        // Get file length by seeking to end
        let file_len = file.seek(SeekFrom::End(0))?;
        file.seek(SeekFrom::Start(0))?;

        // Read page size from SQLite header
        let mut header = [0u8; 100];
        file.read_exact(&mut header)?;
        let page_size = u16::from_be_bytes([header[16], header[17]]) as usize;
        let page_size = if page_size == 1 { 65536 } else { page_size };

        let pages_per_chunk = (TARGET_SQLITE_CHUNK_SIZE / page_size).max(1);

        file.seek(SeekFrom::Start(0))?;

        Ok(Self {
            file,
            page_size,
            pages_per_chunk,
            offset: 0,
            file_len,
        })
    }
}

impl<R: Read> Iterator for SqliteChunker<R> {
    type Item = io::Result<fastcdc::v2020::ChunkData>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.offset >= self.file_len {
            return None;
        }

        let chunk_size =
            (self.page_size * self.pages_per_chunk).min((self.file_len - self.offset) as usize);

        let mut data = vec![0u8; chunk_size];
        if let Err(e) = self.file.read_exact(&mut data) {
            return Some(Err(e));
        }

        let offset = self.offset;
        self.offset += chunk_size as u64;

        Some(Ok(fastcdc::v2020::ChunkData {
            offset,
            length: chunk_size,
            hash: 0,
            data,
        }))
    }
}

enum Chunker {
    Cdc(StreamCDC<FileOrFileLike>),
    Sqlite(SqliteChunker<FileOrFileLike>),
}

impl Iterator for Chunker {
    type Item = io::Result<fastcdc::v2020::ChunkData>;

    fn next(&mut self) -> Option<Self::Item> {
        match self {
            Chunker::Cdc(c) => c
                .next()
                .map(|r| r.map_err(|e| io::Error::other(e.to_string()))),
            Chunker::Sqlite(c) => c.next(),
        }
    }
}

fn get_chunker(mut reader: FileOrFileLike, min: u32, avg: u32, max: u32) -> io::Result<Chunker> {
    let size = reader.seek(SeekFrom::End(0))?;
    reader.seek(SeekFrom::Start(0))?;

    let mut header = [0u8; 16];
    let bytes_read = reader.read(&mut header)?;
    reader.seek(SeekFrom::Start(0))?;

    if bytes_read >= 16 && &header[0..16] == b"SQLite format 3\0" && size > 1024 * 1024 {
        Ok(Chunker::Sqlite(SqliteChunker::new(reader)?))
    } else {
        Ok(Chunker::Cdc(StreamCDC::new(reader, min, avg, max)))
    }
}

/// Wrapper for Python file-like objects that implements std::io::Read
struct PyFileReader {
    inner: Py<PyAny>,
}

impl PyFileReader {
    fn new(obj: Py<PyAny>) -> Self {
        Self { inner: obj }
    }
}

impl Seek for PyFileReader {
    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
        Python::attach(|py| {
            let obj = self.inner.bind(py);

            let (whence, offset) = match pos {
                SeekFrom::Start(n) => (0, n as i64),
                SeekFrom::Current(n) => (1, n),
                SeekFrom::End(n) => (2, n),
            };

            let result = obj
                .call_method1("seek", (offset, whence))
                .map_err(|e| io::Error::other(e.to_string()))?;

            result
                .extract::<u64>()
                .map_err(|e| io::Error::other(e.to_string()))
        })
    }
}

impl Read for PyFileReader {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        Python::attach(|py| {
            let obj = self.inner.bind(py);

            let result = obj
                .call_method1("read", (buf.len(),))
                .map_err(|e| io::Error::other(e.to_string()))?;

            let bytes: &[u8] = result
                .cast::<PyBytes>()
                .map(|b| b.as_bytes())
                .or_else(|_| result.extract::<&[u8]>())
                .map_err(|e| {
                    io::Error::new(
                        io::ErrorKind::InvalidData,
                        format!("read() must return bytes: {}", e),
                    )
                })?;

            let n = bytes.len();
            buf[..n].copy_from_slice(bytes);
            Ok(n)
        })
    }
}

enum FileOrFileLike {
    File(File),
    FileLike(PyFileReader),
}

impl Read for FileOrFileLike {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        match self {
            FileOrFileLike::File(f) => f.read(buf),
            FileOrFileLike::FileLike(f) => f.read(buf),
        }
    }
}

impl Seek for FileOrFileLike {
    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
        match self {
            FileOrFileLike::File(f) => f.seek(pos),
            FileOrFileLike::FileLike(f) => f.seek(pos),
        }
    }
}

#[gen_stub_pyclass]
#[pyclass(module = "null_client._chunker")]
pub struct ChunkIterator {
    inner: Chunker,
}

#[gen_stub_pymethods]
#[pymethods]
impl ChunkIterator {
    fn __iter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    fn __next__(mut slf: PyRefMut<'_, Self>) -> PyResult<Option<Chunk>> {
        match slf.inner.next() {
            Some(Ok(chunk)) => Ok(Some(Chunk {
                offset: chunk.offset,
                length: chunk.length,
                data: chunk.data,
            })),
            Some(Err(e)) => Err(PyIOError::new_err(e.to_string())),
            None => Ok(None),
        }
    }
}

/// Streaming chunker for a file path or file-like object
#[gen_stub_pyfunction(module = "null_client._chunker")]
#[pyfunction]
#[pyo3(signature = (source, min_size=None, avg_size=None, max_size=None))]
pub fn chunk_file(
    source: &Bound<'_, PyAny>,
    min_size: Option<u32>,
    avg_size: Option<u32>,
    max_size: Option<u32>,
) -> PyResult<ChunkIterator> {
    let min = min_size.unwrap_or(MIN_CHUNK_SIZE);
    let avg = avg_size.unwrap_or(AVG_CHUNK_SIZE);
    let max = max_size.unwrap_or(MAX_CHUNK_SIZE);

    let reader: FileOrFileLike = if let Ok(path) = source.extract::<String>() {
        let file = File::open(&path)
            .map_err(|e| PyIOError::new_err(format!("Failed to open '{}': {}", path, e)))?;
        FileOrFileLike::File(file)
    } else {
        FileOrFileLike::FileLike(PyFileReader::new(source.clone().unbind()))
    };

    let chunker =
        get_chunker(reader, min, avg, max).map_err(|e| PyIOError::new_err(e.to_string()))?;

    Ok(ChunkIterator { inner: chunker })
}

/// Python module definition
#[pymodule]
fn _chunker(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<Chunk>()?;
    m.add_class::<ChunkIterator>()?;
    m.add_function(wrap_pyfunction!(chunk_file, m)?)?;

    // Export constants
    m.add("MIN_CHUNK_SIZE", MIN_CHUNK_SIZE)?;
    m.add("AVG_CHUNK_SIZE", AVG_CHUNK_SIZE)?;
    m.add("MAX_CHUNK_SIZE", MAX_CHUNK_SIZE)?;
    m.add("MAX_TREE_ENTRIES", MAX_TREE_ENTRIES)?;
    m.add("TARGET_SQLITE_CHUNK_SIZE", TARGET_SQLITE_CHUNK_SIZE)?;

    Ok(())
}

// Stub file generation
pyo3_stub_gen::define_stub_info_gatherer!(stub_info);

// Declare module-level constants for stub generation
pyo3_stub_gen::module_variable!("null_client._chunker", "MIN_CHUNK_SIZE", u32);
pyo3_stub_gen::module_variable!("null_client._chunker", "AVG_CHUNK_SIZE", u32);
pyo3_stub_gen::module_variable!("null_client._chunker", "MAX_CHUNK_SIZE", u32);
pyo3_stub_gen::module_variable!("null_client._chunker", "MAX_TREE_ENTRIES", usize);
pyo3_stub_gen::module_variable!("null_client._chunker", "TARGET_SQLITE_CHUNK_SIZE", usize);
