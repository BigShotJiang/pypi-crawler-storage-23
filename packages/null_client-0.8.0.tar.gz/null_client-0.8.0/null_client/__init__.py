"""
null-client: Python client for the null content-addressable storage system.
"""

from null_client._chunker import (
    Chunk,
    ChunkIterator,
    chunk_file,
    MIN_CHUNK_SIZE,
    AVG_CHUNK_SIZE,
    MAX_CHUNK_SIZE,
    MAX_TREE_ENTRIES,
)

from .backup import backup_file
from .client import (
    BatchBlobResult,
    BatchBlobStatus,
    BatchBlobsResponse,
    BlobNotFoundError,
    Client,
    CreatedAtFilter,
    Hash,
    created_at,
    MetadataFilter,
    SortBy,
    SortOrder,
    ListRecordsResponse,
    RecordResponse,
    NullClientError,
    RecordConflictError,
    RecordAlreadyDeletedError,
)

__all__ = [
    # From Rust extension
    "Chunk",
    "ChunkIterator",
    "chunk_file",
    "MIN_CHUNK_SIZE",
    "AVG_CHUNK_SIZE",
    "MAX_CHUNK_SIZE",
    "MAX_TREE_ENTRIES",
    # Python API
    "backup_file",
    "BatchBlobResult",
    "BatchBlobStatus",
    "BatchBlobsResponse",
    "Client",
    "CreatedAtFilter",
    "Hash",
    "created_at",
    "MetadataFilter",
    "SortBy",
    "SortOrder",
    "ListRecordsResponse",
    "RecordResponse",
    # Exceptions
    "BlobNotFoundError",
    "NullClientError",
    "RecordConflictError",
    "RecordAlreadyDeletedError",
]
