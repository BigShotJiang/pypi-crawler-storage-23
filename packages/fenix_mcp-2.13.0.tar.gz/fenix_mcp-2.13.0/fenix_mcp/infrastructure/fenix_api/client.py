# SPDX-License-Identifier: MIT
"""HTTP client wrapper aligned with the Fênix Cloud Swagger."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

from fenix_mcp.infrastructure.http_client import HttpClient


class FenixApiError(RuntimeError):
    """Represents an error returned by the Fênix API."""


def _to_query_value(value: Any) -> Any:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (list, tuple, set)):
        return ",".join(str(item) for item in value)
    return value


def _strip_none(data: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        key: _to_query_value(value) for key, value in data.items() if value is not None
    }


@dataclass(slots=True)
class FenixApiClient:
    """Facade used by tools to communicate with the REST API."""

    base_url: str
    personal_access_token: Optional[str]
    timeout: float = 30.0
    _http: HttpClient = field(init=False, repr=False)

    def __post_init__(self) -> None:
        headers: Dict[str, str] = {
            "User-Agent": "fenix-mcp-py/0.1.0",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.personal_access_token:
            headers["Authorization"] = f"Bearer {self.personal_access_token}"

        object.__setattr__(
            self,
            "_http",
            HttpClient(
                base_url=self.base_url,
                timeout=self.timeout,
                default_headers=headers,
            ),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def update_token(self, token: Optional[str]) -> None:
        """Update bearer token used for subsequent requests."""

        self.personal_access_token = token
        headers = dict(self._http.default_headers or {})
        if token:
            headers["Authorization"] = f"Bearer {token}"
        else:
            headers.pop("Authorization", None)
        self._http.default_headers = headers

    def set_active_team(self, team_id: Optional[str]) -> None:
        """Set X-Team-Id header for all subsequent requests."""

        headers = dict(self._http.default_headers or {})
        if team_id:
            headers["X-Team-Id"] = team_id
        else:
            headers.pop("X-Team-Id", None)
        self._http.default_headers = headers

    def _build_params(
        self,
        *,
        required: Optional[Mapping[str, Any]] = None,
        optional: Optional[Mapping[str, Any]] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}

        if required:
            for key, value in required.items():
                if value is None:
                    raise ValueError(f"Missing required query parameter: {key}")
                params[key] = _to_query_value(value)

        if optional:
            for key, value in optional.items():
                if value is None:
                    continue
                params[key] = _to_query_value(value)

        return params

    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        json: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        response = self._http.request(
            method, endpoint, params=params, json=json, headers=headers
        )
        if response.status_code == 204:
            return None

        try:
            payload = response.json()
        except ValueError as exc:  # pragma: no cover - defensive
            raise FenixApiError(f"Invalid JSON response from {endpoint}") from exc

        if not response.ok:
            # The API wraps errors via GlobalExceptionsFilter:
            # {error: {statusCode, message: {code, message, ...}}}
            # Unwrap to find the actual error body.
            error_body = payload
            if isinstance(payload.get("error"), dict):
                inner = payload["error"]
                if isinstance(inner.get("message"), dict):
                    error_body = inner["message"]
                else:
                    error_body = inner

            message = error_body.get("message") or payload.get("error") or response.text

            raise FenixApiError(
                f"HTTP {response.status_code} calling {endpoint}: {message}"
            )

        return payload.get("data", payload)

    def _request_with_team(
        self,
        method: str,
        endpoint: str,
        *,
        team_id: Optional[str] = None,
        params: Optional[Mapping[str, Any]] = None,
        json: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        headers: Dict[str, str] = {}
        if team_id:
            headers["X-Team-Id"] = team_id
        return self._request(
            method, endpoint, params=params, json=json, headers=headers or None
        )

    # ------------------------------------------------------------------
    # Health / profile
    # ------------------------------------------------------------------

    def get_health(self) -> Any:
        return self._request("GET", "/health")

    def get_profile(self, *, include_documents: bool = False) -> Any:
        """Get user profile. Use include_documents=True to include core and user documents."""
        params = self._build_params(
            optional={"include": "documents" if include_documents else None}
        )
        return self._request("GET", "/api/auth/profile", params=params)

    # ------------------------------------------------------------------
    # Core documents (requires PAT authentication)
    # ------------------------------------------------------------------

    def list_core_documents(self, *, return_content: bool = False) -> Any:
        """List all core documents. Requires valid PAT."""
        params = self._build_params(optional={"returnContent": return_content})
        return self._request("GET", "/api/core-documents", params=params)

    def get_core_document(self, name: str, *, return_content: bool = False) -> Any:
        """Get a core document by name. Requires valid PAT."""
        params = self._build_params(optional={"returnContent": return_content})
        return self._request("GET", f"/api/core-documents/{name}", params=params)

    # ------------------------------------------------------------------
    # User core documents
    # ------------------------------------------------------------------

    def list_user_core_documents(
        self, *, return_content: bool = False, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(optional={"returnContent": return_content})
        return self._request_with_team(
            "GET", "/api/user-core-documents", params=params, team_id=team_id
        )

    def get_user_core_document(
        self,
        document_id: str,
        *,
        return_content: bool = False,
        team_id: Optional[str] = None,
    ) -> Any:
        params = self._build_params(optional={"returnContent": return_content})
        return self._request_with_team(
            "GET",
            f"/api/user-core-documents/{document_id}",
            params=params,
            team_id=team_id,
        )

    def create_user_core_document(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/user-core-documents", json=payload, team_id=team_id
        )

    def update_user_core_document(
        self,
        document_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/user-core-documents/{document_id}",
            json=payload,
            team_id=team_id,
        )

    def delete_user_core_document(
        self, document_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "DELETE",
            f"/api/user-core-documents/{document_id}",
            team_id=team_id,
        )

    # ------------------------------------------------------------------
    # Productivity (todo items)
    # ------------------------------------------------------------------

    def create_todo_item(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/todo-items", json=payload, team_id=team_id
        )

    def list_todo_items(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        params = _strip_none(filters)
        return self._request_with_team(
            "GET", "/api/todo-items", params=params, team_id=team_id
        )

    def get_todo_item(
        self,
        item_id: str,
        *,
        return_content: bool = False,
        team_id: Optional[str] = None,
    ) -> Any:
        params = self._build_params(optional={"returnContent": return_content})
        return self._request_with_team(
            "GET", f"/api/todo-items/{item_id}", params=params, team_id=team_id
        )

    def update_todo_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/todo-items/{item_id}",
            json=payload,
            team_id=team_id,
        )

    def delete_todo_item(self, item_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/todo-items/{item_id}", team_id=team_id
        )

    def update_todo_item_status(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/todo-items/{item_id}/status",
            json=payload,
            team_id=team_id,
        )

    def update_todo_item_priority(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/todo-items/{item_id}/priority",
            json=payload,
            team_id=team_id,
        )

    def get_todo_stats(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", "/api/todo-items/stats", team_id=team_id)

    def get_todo_categories(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/todo-items/categories", team_id=team_id
        )

    def get_todo_tags(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", "/api/todo-items/tags", team_id=team_id)

    def search_todo_items(self, *, query: str, team_id: Optional[str] = None) -> Any:
        params = self._build_params(required={"q": query})
        return self._request_with_team(
            "GET", "/api/todo-items/search", params=params, team_id=team_id
        )

    def list_todo_overdue(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/todo-items/overdue", team_id=team_id
        )

    def list_todo_upcoming(
        self, *, days: Optional[int] = None, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(optional={"days": days})
        return self._request_with_team(
            "GET", "/api/todo-items/upcoming", params=params, team_id=team_id
        )

    # ------------------------------------------------------------------
    # Memories
    # ------------------------------------------------------------------

    def list_memories(
        self,
        *,
        include_content: bool = True,
        include_metadata: bool = True,
        team_id: Optional[str] = None,
        **filters: Any,
    ) -> Any:
        params = self._build_params(
            required={"content": include_content, "metadata": include_metadata},
            optional=filters,
        )
        return self._request_with_team(
            "GET", "/api/memories", params=params, team_id=team_id
        )

    def get_memory(
        self,
        memory_id: str,
        *,
        include_content: bool = True,
        include_metadata: bool = True,
        team_id: Optional[str] = None,
    ) -> Any:
        params = self._build_params(
            required={"content": include_content, "metadata": include_metadata}
        )
        return self._request_with_team(
            "GET", f"/api/memories/{memory_id}", params=params, team_id=team_id
        )

    def update_memory(
        self,
        memory_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/memories/{memory_id}", json=payload, team_id=team_id
        )

    def record_memory_access(
        self, memory_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", f"/api/memories/{memory_id}/access", team_id=team_id
        )

    def save_memory(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        """Smart save memory - creates or updates based on semantic similarity."""
        return self._request_with_team(
            "POST", "/api/memories/save", json=payload, team_id=team_id
        )

    def search_memories(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        """Search memories using semantic similarity (embeddings)."""
        return self._request_with_team(
            "POST", "/api/memories/search", json=payload, team_id=team_id
        )

    # ------------------------------------------------------------------
    # Knowledge: documentation
    # ------------------------------------------------------------------

    def list_documentation_items(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> Any:
        return self._request_with_team(
            "GET", "/api/documentation", team_id=team_id, params=_strip_none(filters)
        )

    def get_documentation_item(
        self, item_id: str, *, team_id: Optional[str] = None, **filters: Any
    ) -> Any:
        return self._request_with_team(
            "GET",
            f"/api/documentation/{item_id}",
            team_id=team_id,
            params=_strip_none(filters),
        )

    def create_documentation_item(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/documentation", team_id=team_id, json=payload
        )

    def update_documentation_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/documentation/{item_id}", team_id=team_id, json=payload
        )

    def delete_documentation_item(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/documentation/{item_id}", team_id=team_id
        )

    def get_documentation_children(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/documentation/{item_id}/children", team_id=team_id
        )

    def get_documentation_tree(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/documentation/{item_id}/tree", team_id=team_id
        )

    def get_documentation_full_tree(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/documentation/tree", team_id=team_id
        )

    def search_documentation_items(
        self, *, query: str, limit: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"q": query, "limit": limit})
        return self._request_with_team(
            "GET", "/api/documentation/search", team_id=team_id, params=params
        )

    def list_documentation_roots(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/documentation/roots", team_id=team_id
        )

    def list_documentation_recent(
        self, *, limit: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"limit": limit})
        return self._request_with_team(
            "GET", "/api/documentation/recent", team_id=team_id, params=params
        )

    def get_documentation_analytics(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/documentation/analytics", team_id=team_id
        )

    def move_documentation_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/documentation/{item_id}/move", team_id=team_id, json=payload
        )

    def publish_documentation_item(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/documentation/{item_id}/publish", team_id=team_id
        )

    def create_documentation_version(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "POST",
            f"/api/documentation/{item_id}/version",
            team_id=team_id,
            json=payload,
        )

    def duplicate_documentation_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "POST",
            f"/api/documentation/{item_id}/duplicate",
            team_id=team_id,
            json=payload,
        )

    # ------------------------------------------------------------------
    # Knowledge: work items
    # ------------------------------------------------------------------

    def create_work_item(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/work-items", team_id=team_id, json=payload
        )

    def list_work_items(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        return self._request_with_team(
            "GET", "/api/work-items", team_id=team_id, params=_strip_none(filters)
        )

    def get_work_item(self, item_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/{item_id}", team_id=team_id
        )

    def get_work_item_by_key(self, key: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/by-key/{key}", team_id=team_id
        )

    def assign_work_item_to_me(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", f"/api/work-items/{item_id}/assign-to-me", team_id=team_id
        )

    def advance_work_item_status(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/advance", team_id=team_id
        )

    def complete_work_item_status(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/complete", team_id=team_id
        )

    def get_work_items_mine(
        self, *, limit: int = 50, offset: int = 0, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(optional={"limit": limit, "offset": offset})
        return self._request_with_team(
            "GET", "/api/work-items/mine", team_id=team_id, params=params
        )

    def update_work_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}", team_id=team_id, json=payload
        )

    def delete_work_item(self, item_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/work-items/{item_id}", team_id=team_id
        )

    def list_work_items_backlog(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/work-items/backlog", team_id=team_id
        )

    def search_work_items(
        self,
        *,
        query: str,
        limit: int,
        team_id: Optional[str] = None,
        item_type: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assignee_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> Any:
        params = self._build_params(
            required={"q": query, "limit": limit},
            optional={
                "item_type": item_type,
                "status": status,
                "priority": priority,
                "assignee_id": assignee_id,
                "tags": ",".join(tags) if tags else None,
            },
        )
        return self._request_with_team(
            "GET", "/api/work-items/search", team_id=team_id, params=params
        )

    def get_work_items_analytics(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/work-items/analytics", team_id=team_id
        )

    def get_work_items_velocity(
        self, *, sprints_count: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"sprints_count": sprints_count})
        return self._request_with_team(
            "GET", "/api/work-items/velocity", team_id=team_id, params=params
        )

    def list_work_items_by_sprint(
        self, *, sprint_id: str, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/by-sprint/{sprint_id}", team_id=team_id
        )

    def get_work_items_burndown(
        self, *, sprint_id: str, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/burndown/{sprint_id}", team_id=team_id
        )

    def list_work_items_by_epic(
        self, *, epic_id: str, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/by-epic/{epic_id}", team_id=team_id
        )

    def get_work_items_epic_progress(
        self, *, epic_id: str, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/epic-progress/{epic_id}", team_id=team_id
        )

    def list_work_items_by_board(
        self, *, board_id: str, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/by-board/{board_id}", team_id=team_id
        )

    def get_work_item_children(
        self, item_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-items/{item_id}/children", team_id=team_id
        )

    def move_work_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/move", team_id=team_id, json=payload
        )

    def update_work_item_status(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/status", team_id=team_id, json=payload
        )

    def move_work_item_to_board(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/board", team_id=team_id, json=payload
        )

    def link_work_item(
        self,
        item_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-items/{item_id}/link", team_id=team_id, json=payload
        )

    def assign_work_items_to_sprint(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/work-items/assign-to-sprint", team_id=team_id, json=payload
        )

    def bulk_update_work_items(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", "/api/work-items/bulk-update", team_id=team_id, json=payload
        )

    def bulk_create_work_items(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/work-items/bulk-create", team_id=team_id, json=payload
        )

    # ------------------------------------------------------------------
    # Knowledge: boards
    # ------------------------------------------------------------------

    def create_work_board(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/work-boards", team_id=team_id, json=payload
        )

    def list_work_boards(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        return self._request_with_team(
            "GET", "/api/work-boards", team_id=team_id, params=_strip_none(filters)
        )

    def list_favorite_work_boards(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", "/api/work-boards/favorites", team_id=team_id
        )

    def search_work_boards(
        self, *, query: str, limit: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"q": query, "limit": limit})
        return self._request_with_team(
            "GET", "/api/work-boards/search", team_id=team_id, params=params
        )

    def list_recent_work_boards(
        self, *, limit: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"limit": limit})
        return self._request_with_team(
            "GET", "/api/work-boards/recent", team_id=team_id, params=params
        )

    def get_work_board(self, board_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-boards/{board_id}", team_id=team_id
        )

    def update_work_board(
        self,
        board_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/work-boards/{board_id}", team_id=team_id, json=payload
        )

    def delete_work_board(self, board_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/work-boards/{board_id}", team_id=team_id
        )

    def get_work_board_analytics(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-boards/{board_id}/analytics", team_id=team_id
        )

    def list_work_board_columns(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-boards/{board_id}/columns", team_id=team_id
        )

    def toggle_work_board_favorite(
        self,
        board_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/work-boards/{board_id}/favorite",
            team_id=team_id,
            json=payload,
        )

    def clone_work_board(
        self,
        board_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "POST", f"/api/work-boards/{board_id}/clone", team_id=team_id, json=payload
        )

    def reorder_work_boards(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", "/api/work-boards/reorder", team_id=team_id, json=payload
        )

    def create_work_board_column(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/work-boards/columns", team_id=team_id, json=payload
        )

    def reorder_work_board_columns(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "PATCH", "/api/work-boards/columns/reorder", team_id=team_id, json=payload
        )

    def get_work_board_column(
        self, column_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/work-boards/columns/{column_id}", team_id=team_id
        )

    def update_work_board_column(
        self,
        column_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH",
            f"/api/work-boards/columns/{column_id}",
            team_id=team_id,
            json=payload,
        )

    def delete_work_board_column(
        self, column_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/work-boards/columns/{column_id}", team_id=team_id
        )

    # ------------------------------------------------------------------
    # Knowledge: sprints
    # ------------------------------------------------------------------

    def create_sprint(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/sprints", team_id=team_id, json=payload
        )

    def list_sprints(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        return self._request_with_team(
            "GET", "/api/sprints", team_id=team_id, params=_strip_none(filters)
        )

    def get_sprint(self, sprint_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "GET", f"/api/sprints/{sprint_id}", team_id=team_id
        )

    def update_sprint(
        self,
        sprint_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/sprints/{sprint_id}", team_id=team_id, json=payload
        )

    def delete_sprint(self, sprint_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/sprints/{sprint_id}", team_id=team_id
        )

    def list_recent_sprints(self, *, limit: int, team_id: Optional[str] = None) -> Any:
        params = self._build_params(required={"limit": limit})
        return self._request_with_team(
            "GET", "/api/sprints/recent", team_id=team_id, params=params
        )

    def search_sprints(
        self, *, query: str, limit: int, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"q": query, "limit": limit})
        return self._request_with_team(
            "GET", "/api/sprints/search", team_id=team_id, params=params
        )

    def get_active_sprint(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", "/api/sprints/active", team_id=team_id)

    def get_sprints_velocity(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", "/api/sprints/velocity", team_id=team_id)

    def get_sprints_burndown(self, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", "/api/sprints/burndown", team_id=team_id)

    def get_sprint_work_items(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/sprints/{sprint_id}/work-items", team_id=team_id
        )

    def add_work_items_to_sprint(
        self,
        sprint_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "POST",
            f"/api/sprints/{sprint_id}/work-items",
            team_id=team_id,
            json=payload,
        )

    def remove_work_items_from_sprint(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "DELETE", "/api/sprints/work-items", team_id=team_id, json=payload
        )

    def get_sprint_analytics(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/sprints/{sprint_id}/analytics", team_id=team_id
        )

    def get_sprint_capacity(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/sprints/{sprint_id}/capacity", team_id=team_id
        )

    def start_sprint(
        self,
        sprint_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/sprints/{sprint_id}/start", team_id=team_id, json=payload
        )

    def complete_sprint(
        self,
        sprint_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/sprints/{sprint_id}/complete", team_id=team_id, json=payload
        )

    def cancel_sprint(self, sprint_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/sprints/{sprint_id}/cancel", team_id=team_id
        )

    # ------------------------------------------------------------------
    # Rules
    # ------------------------------------------------------------------

    def create_rule(
        self, payload: Mapping[str, Any], *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST", "/api/rules", team_id=team_id, json=payload
        )

    def list_rules(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        return self._request_with_team(
            "GET", "/api/rules", team_id=team_id, params=_strip_none(filters)
        )

    def get_rule(self, rule_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team("GET", f"/api/rules/{rule_id}", team_id=team_id)

    def update_rule(
        self,
        rule_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "PATCH", f"/api/rules/{rule_id}", team_id=team_id, json=payload
        )

    def delete_rule(self, rule_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "DELETE", f"/api/rules/{rule_id}", team_id=team_id
        )

    def list_marketplace_rules(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> Any:
        return self._request_with_team(
            "GET",
            "/api/rules/marketplace/list",
            team_id=team_id,
            params=_strip_none(filters),
        )

    def search_marketplace_rules(
        self, *, query: str, limit: int = 20, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(required={"q": query}, optional={"limit": limit})
        return self._request_with_team(
            "GET", "/api/rules/marketplace/search", team_id=team_id, params=params
        )

    def get_top_marketplace_rules(
        self, *, limit: int = 10, team_id: Optional[str] = None
    ) -> Any:
        params = self._build_params(optional={"limit": limit})
        return self._request_with_team(
            "GET", "/api/rules/marketplace/top", team_id=team_id, params=params
        )

    def fork_rule(
        self,
        rule_id: str,
        payload: Mapping[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Any:
        return self._request_with_team(
            "POST", f"/api/rules/{rule_id}/fork", team_id=team_id, json=payload
        )

    def download_rule(self, rule_id: str, *, team_id: Optional[str] = None) -> Any:
        return self._request_with_team(
            "POST", f"/api/rules/{rule_id}/download", team_id=team_id
        )

    def rate_rule(
        self, rule_id: str, rating: float, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "POST",
            f"/api/rules/{rule_id}/rate",
            team_id=team_id,
            json={"rating": rating},
        )

    def export_rule(
        self, rule_id: str, format: str, *, team_id: Optional[str] = None
    ) -> Any:
        return self._request_with_team(
            "GET", f"/api/rules/{rule_id}/export/{format}", team_id=team_id
        )

    def export_merged_rules(self, format: str, *, team_id: Optional[str] = None) -> Any:
        params = self._build_params(required={"format": format})
        return self._request_with_team(
            "GET", "/api/rules/export/merged", team_id=team_id, params=params
        )

    # ------------------------------------------------------------------
    # API Catalog
    # ------------------------------------------------------------------

    def list_api_catalog(self, *, team_id: Optional[str] = None, **filters: Any) -> Any:
        """List API specifications with optional filters."""
        return self._request_with_team(
            "GET", "/api/api-catalog", team_id=team_id, params=_strip_none(filters)
        )

    def get_api_catalog(self, spec_id: str, *, team_id: Optional[str] = None) -> Any:
        """Get API specification details by ID."""
        return self._request_with_team(
            "GET", f"/api/api-catalog/{spec_id}", team_id=team_id
        )

    def search_api_catalog_text(
        self,
        *,
        query: str,
        limit: int = 20,
        offset: int = 0,
        team_id: Optional[str] = None,
        status: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> Any:
        """Full-text search in API specifications."""
        params = self._build_params(
            required={"q": query},
            optional={
                "limit": limit,
                "offset": offset,
                "status": status,
                "tags": ",".join(tags) if tags else None,
            },
        )
        return self._request_with_team(
            "GET", "/api/api-catalog/search/apis", team_id=team_id, params=params
        )

    def search_api_catalog_endpoints_text(
        self,
        *,
        query: str,
        limit: int = 20,
        offset: int = 0,
        team_id: Optional[str] = None,
        specification_id: Optional[str] = None,
        method: Optional[str] = None,
    ) -> Any:
        """Full-text search in API endpoints."""
        params = self._build_params(
            required={"q": query},
            optional={
                "limit": limit,
                "offset": offset,
                "specificationId": specification_id,
                "method": method,
            },
        )
        return self._request_with_team(
            "GET",
            "/api/api-catalog/search/endpoints",
            team_id=team_id,
            params=params,
        )

    def search_api_catalog_semantic(
        self,
        *,
        query: str,
        limit: int = 20,
        offset: int = 0,
        team_id: Optional[str] = None,
        threshold: Optional[float] = None,
        status: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> Any:
        """Semantic search in API specifications using embeddings."""
        params = self._build_params(
            required={"q": query},
            optional={
                "limit": limit,
                "offset": offset,
                "threshold": threshold,
                "status": status,
                "tags": ",".join(tags) if tags else None,
            },
        )
        return self._request_with_team(
            "GET", "/api/api-catalog/semantic/apis", team_id=team_id, params=params
        )

    def search_api_catalog_endpoints_semantic(
        self,
        *,
        query: str,
        limit: int = 20,
        offset: int = 0,
        team_id: Optional[str] = None,
        threshold: Optional[float] = None,
        specification_id: Optional[str] = None,
        method: Optional[str] = None,
    ) -> Any:
        """Semantic search in API endpoints using embeddings."""
        params = self._build_params(
            required={"q": query},
            optional={
                "limit": limit,
                "offset": offset,
                "threshold": threshold,
                "specificationId": specification_id,
                "method": method,
            },
        )
        return self._request_with_team(
            "GET",
            "/api/api-catalog/semantic/endpoints",
            team_id=team_id,
            params=params,
        )
