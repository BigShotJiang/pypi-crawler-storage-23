# SPDX-License-Identifier: MIT
"""Focused work items tool."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import _format_work
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    DateTimeStr,
    MERMAID_HINT,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
)
from fenix_mcp.domain.work_items import WorkItemService
from fenix_mcp.infrastructure.context import AppContext

WorkItemsAction = Literal[
    "work_create",
    "work_list",
    "work_get",
    "work_update",
    "work_children",
    "work_assign_to_me",
    "work_status_next",
    "work_status_done",
    "work_mine",
    "work_bulk_create",
]

_ALLOWED_WORK_ITEM_TYPES = {
    "epic",
    "feature",
    "story",
    "bug",
    "hotfix",
    "task",
    "spike",
    "subtask",
}


def _work_action_choices() -> List[str]:
    return [
        "work_create",
        "work_list",
        "work_get",
        "work_update",
        "work_children",
        "work_assign_to_me",
        "work_status_next",
        "work_status_done",
        "work_mine",
        "work_bulk_create",
    ]


class WorkItemsRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: WorkItemsAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    board_id: Optional[UUIDStr] = Field(
        default=None, description="Associated board ID (UUID)."
    )
    sprint_id: Optional[UUIDStr] = Field(
        default=None, description="Associated sprint ID (UUID)."
    )
    epic_id: Optional[UUIDStr] = Field(
        default=None, description="Associated epic ID (UUID)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")
    return_content: Optional[bool] = Field(
        default=None, description="Return full content."
    )
    return_description: Optional[bool] = Field(
        default=None, description="Return full description."
    )
    return_metadata: Optional[bool] = Field(
        default=None, description="Return full metadata."
    )

    work_key: Optional[str] = Field(
        default=None,
        description="Work item key (e.g., DVPT-0001). Use this instead of id for work_get and work_children.",
    )
    work_title: Optional[TitleStr] = Field(default=None, description="Work item title.")
    work_description: Optional[MarkdownStr] = Field(
        default=None, description=f"Work item description (Markdown).{MERMAID_HINT}"
    )
    work_type: Optional[str] = Field(
        default="task",
        description="Work item type. Values: epic, feature, story, bug, hotfix, task, spike, subtask.",
    )
    work_status: Optional[str] = Field(
        default=None,
        description="Work item status ID (UUID of TeamStatus).",
    )
    work_priority: Optional[str] = Field(
        default=None,
        description="Work item priority (critical, high, medium, low).",
    )
    work_category: Optional[str] = Field(
        default=None,
        description="Work item category/discipline. REQUIRED for work_create. Values: backend, frontend, mobile, fullstack, devops, infra, platform, sre, database, security, data, analytics, ai_ml, qa, automation, design, research, product, project, agile, support, operations, documentation, training, architecture, planning, development.",
    )
    story_points: Optional[int] = Field(
        default=None, ge=0, le=100, description="Story points (0-100)."
    )
    assignee_id: Optional[UUIDStr] = Field(
        default=None, description="Assignee ID (UUID)."
    )
    parent_id: Optional[UUIDStr] = Field(
        default=None,
        description="Parent item ID (UUID). Prefer using parent_key instead.",
    )
    parent_key: Optional[str] = Field(
        default=None,
        description="Parent item key (e.g., DVPT-0001). Use this to set the parent of a work item.",
    )
    work_due_date: Optional[DateTimeStr] = Field(
        default=None, description="Work item due date (ISO 8601)."
    )
    work_tags: Optional[List[TagStr]] = Field(
        default=None, description="Work item tags."
    )
    work_item_ids: Optional[List[UUIDStr]] = Field(
        default=None,
        description="List of work item IDs for batch operations (UUIDs).",
    )
    work_items: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description=(
            "List of work items for bulk create (max 50). Each item requires: "
            "temp_id (your temporary ID like 'epic-1', 'task-a'), title, item_type, work_category. "
            "Use parent_temp_id to set parent from same batch (e.g., parent_temp_id:'epic-1'), "
            "OR parent_key to set parent from existing work item (e.g., parent_key:'TEMA-0056'). "
            "Cannot use both parent_temp_id and parent_key on the same item. "
            "Optional: description, priority (low/medium/high/critical), story_points, tags, due_date. "
            'Example: [{"temp_id":"e1", "title":"Epic", "item_type":"epic", "work_category":"backend"}, '
            '{"temp_id":"t1", "parent_temp_id":"e1", "title":"Task", "item_type":"task", "work_category":"backend"}]'
        ),
    )


class WorkItemsTool(Tool):
    name = "work_items"
    description = """Manage Fenix work items (tasks, bugs, stories, epics) with focused actions.

Available actions:
- `work_create`, `work_list`, `work_get`, `work_update`
- `work_children`, `work_assign_to_me`
- `work_status_next`, `work_status_done`
- `work_mine`, `work_bulk_create`

Common example:
- List my current assignments:
  `{"action":"work_mine"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = WorkItemsRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = WorkItemService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(WorkItemsRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "work_create":
            if not payload.work_title:
                return text("❌ Provide work_title to create the item.")
            if not payload.work_category:
                return text(
                    "❌ Provide work_category to create the item. Values: backend, frontend, mobile, fullstack, devops, infra, platform, sre, database, security, data, analytics, ai_ml, qa, automation, design, research, product, project, agile, support, operations, documentation, training, architecture, planning, development."
                )

            if payload.work_type and payload.work_type not in _ALLOWED_WORK_ITEM_TYPES:
                allowed_types = ", ".join(sorted(_ALLOWED_WORK_ITEM_TYPES))
                return text(
                    f"❌ Invalid work_type: '{payload.work_type}'\n\n"
                    f"Valid types are: {allowed_types}"
                )

            parent_id = payload.parent_id
            if payload.parent_key and not parent_id:
                parent_work = await self._service.work_get_by_key(
                    payload.parent_key, team_id=team_id
                )
                parent_id = parent_work.get("id")

            work = await self._service.work_create(
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "item_type": payload.work_type,
                    "status_id": payload.work_status,
                    "priority": payload.work_priority,
                    "work_category": payload.work_category,
                    "story_points": payload.story_points,
                    "assignee_id": payload.assignee_id,
                    "sprint_id": payload.sprint_id,
                    "parent_id": parent_id,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                },
                team_id=team_id,
            )
            return text(_format_work(work, header="✅ Work item created"))

        if action == "work_list":
            if payload.work_type and payload.work_type not in _ALLOWED_WORK_ITEM_TYPES:
                allowed_types = ", ".join(sorted(_ALLOWED_WORK_ITEM_TYPES))
                return text(
                    f"❌ Invalid work_type: '{payload.work_type}'\n\n"
                    f"Valid types are: {allowed_types}"
                )

            items = await self._service.work_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                priority=payload.work_priority,
                type=payload.work_type,
                assignee=payload.assignee_id,
                sprint=payload.sprint_id,
            )
            if not items:
                return text("🎯 No work items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🎯 **Work items ({len(items)}):**\n\n{body}")

        if action == "work_get":
            if payload.work_key:
                work = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
            elif payload.id:
                work = await self._service.work_get(payload.id, team_id=team_id)
            else:
                return text("❌ Provide id or work_key to get the work item.")
            return text(
                _format_work(work, header="🎯 Work item details", show_description=True)
            )

        if action == "work_update":
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to update the work item.")

            work = await self._service.work_update(
                work_id,
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "priority": payload.work_priority,
                    "story_points": payload.story_points,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                },
                team_id=team_id,
            )
            return text(_format_work(work, header="✅ Work item updated"))

        if action == "work_assign_to_me":
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to assign the work item.")
            work = await self._service.work_assign_to_me(work_id, team_id=team_id)
            return text(_format_work(work, header="✅ Work item assigned to you"))

        if action == "work_status_next":
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to advance status.")
            work = await self._service.work_advance_status(work_id, team_id=team_id)
            return text(_format_work(work, header="✅ Status advanced"))

        if action == "work_status_done":
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to complete status.")
            work = await self._service.work_complete_status(work_id, team_id=team_id)
            return text(_format_work(work, header="✅ Status completed"))

        if action == "work_mine":
            items = await self._service.work_mine(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
            )
            if not items:
                return text("🎯 No work items assigned to you.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🎯 **Your work items ({len(items)}):**\n\n{body}")

        if action == "work_children":
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(
                    payload.work_key, team_id=team_id
                )
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to list children.")
            items = await self._service.work_children(work_id, team_id=team_id)
            if not items:
                return text("👶 No child items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"👶 **Child work items ({len(items)}):**\n\n{body}")

        if action == "work_bulk_create":
            if not payload.work_items:
                return text(
                    "❌ Provide work_items array. Each item requires: temp_id, title, item_type, work_category. "
                    "Optional: parent_temp_id OR parent_key (not both), description, priority, story_points, tags, due_date."
                )
            if len(payload.work_items) > 50:
                return text("❌ Maximum 50 items per bulk create.")

            for i, item in enumerate(payload.work_items):
                if not item.get("temp_id"):
                    return text(f"❌ Item {i}: missing temp_id.")
                if not item.get("title"):
                    return text(f"❌ Item {i}: missing title.")
                if not item.get("item_type"):
                    return text(f"❌ Item {i}: missing item_type.")
                if not item.get("work_category"):
                    return text(f"❌ Item {i}: missing work_category.")
                if item.get("parent_temp_id") and item.get("parent_key"):
                    return text(
                        f"❌ Item {i}: cannot have both parent_temp_id and parent_key. Use one or the other."
                    )

            items = await self._service.work_bulk_create(
                {"items": payload.work_items}, team_id=team_id
            )

            lines = [f"✅ **{len(items)} work items created**", ""]

            items_by_id: Dict[str, Dict[str, Any]] = {}
            children_map: Dict[str, List[str]] = {}
            root_ids: List[str] = []

            for item in items:
                item_id = item.get("id", "")
                items_by_id[item_id] = item
                parent_id = item.get("parent_id")
                if parent_id and parent_id in items_by_id:
                    if parent_id not in children_map:
                        children_map[parent_id] = []
                    children_map[parent_id].append(item_id)
                else:
                    root_ids.append(item_id)

            def format_tree_node(
                item_id: str, prefix: str = "", is_last: bool = True
            ) -> List[str]:
                node_lines: List[str] = []
                item = items_by_id.get(item_id, {})
                key = item.get("key", "")
                title = item.get("title", "Untitled")
                item_type = item.get("item_type", "unknown")

                if prefix == "":
                    connector = ""
                    child_prefix = ""
                else:
                    connector = "└── " if is_last else "├── "
                    child_prefix = prefix + ("    " if is_last else "│   ")

                node_lines.append(f"{prefix}{connector}{item_type}: {key} - {title}")

                child_ids = children_map.get(item_id, [])
                for i, child_id in enumerate(child_ids):
                    is_last_child = i == len(child_ids) - 1
                    node_lines.extend(
                        format_tree_node(child_id, child_prefix, is_last_child)
                    )

                return node_lines

            for i, root_id in enumerate(root_ids):
                lines.extend(format_tree_node(root_id))
                if i < len(root_ids) - 1:
                    lines.append("")

            type_counts: Dict[str, int] = {}
            for item in items:
                item_type = item.get("item_type", "unknown")
                type_counts[item_type] = type_counts.get(item_type, 0) + 1

            lines.append("")
            lines.append("**Summary by type:**")
            for item_type, count in sorted(type_counts.items()):
                lines.append(f"- {item_type}: {count}")

            return text("\n".join(lines))

        return text(
            "❌ Unsupported work item action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _work_action_choices())
        )


__all__ = ["WorkItemsTool", "WorkItemsAction", "WorkItemsRequest"]
