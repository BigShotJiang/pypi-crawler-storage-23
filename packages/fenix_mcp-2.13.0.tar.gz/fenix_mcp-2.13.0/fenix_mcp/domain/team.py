# SPDX-License-Identifier: MIT

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TypedDict


class TeamRecord(TypedDict, total=False):
    id: str
    name: str
    prefix: str


def _format_team_list(teams: Sequence[Mapping[str, str]]) -> str:
    lines: list[str] = []
    for t in teams:
        name = t.get("name") or "?"
        tid = t.get("id") or "?"
        prefix = t.get("prefix") or ""
        suffix = f" [{prefix}]" if prefix else ""
        lines.append(f"  - {name}{suffix}: {tid}")
    return "\n".join(lines)


def match_team_by_name(
    query: str,
    teams: Sequence[Mapping[str, str]],
) -> Mapping[str, str]:
    if not teams:
        raise ValueError("No teams available. Call the `initialize` tool first.")

    query_lower = query.strip().lower()

    for t in teams:
        if t.get("id") == query:
            return t

    for t in teams:
        if (t.get("name") or "").lower() == query_lower:
            return t

    for t in teams:
        if (t.get("prefix") or "").lower() == query_lower:
            return t

    partial_matches = [t for t in teams if query_lower in (t.get("name") or "").lower()]

    if len(partial_matches) == 1:
        return partial_matches[0]

    if len(partial_matches) > 1:
        team_display = _format_team_list(partial_matches)
        raise ValueError(
            f"Ambiguous: multiple teams match '{query}':\n{team_display}\n\n"
            + "Please be more specific or use the exact team name."
        )

    team_display = _format_team_list(teams)
    raise ValueError(
        f"No team found matching '{query}'. Available teams:\n{team_display}"
    )


__all__ = ["match_team_by_name", "TeamRecord"]
