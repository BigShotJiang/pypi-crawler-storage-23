import logging
from typing import cast

from langchain_core.runnables import RunnableLambda
from langgraph.checkpoint.memory import MemorySaver

import chATLAS_Chains.chains.advanced as advanced_module
import chATLAS_Chains.chains.basic as basic_module
import chATLAS_Chains.chains.conversational_graph as conversational_module
from chATLAS_Chains.llm.model_selection import sanitize_chat_model_kwargs
from chATLAS_Embed.VectorStores import VectorStore


def test_sanitize_chat_model_kwargs_warns_and_drops_unknown(caplog):
    with caplog.at_level(logging.WARNING, logger="chATLAS_Chains.llm.model_selection"):
        sanitized = sanitize_chat_model_kwargs({"temperature": 0.4, "max_tokens": 200, "unsupported_key": "x"})

    assert sanitized == {"temperature": 0.4, "max_tokens": 200}
    assert "Ignoring unknown chat_model_kwargs key 'unsupported_key'" in caplog.text


def test_basic_retrieval_chain_uses_sanitized_chat_model_kwargs(monkeypatch, caplog):
    captured: dict[str, object] = {}

    def fake_search_runnable(_vectorstore):
        return RunnableLambda(lambda question: {"question": question, "docs": []})

    def fake_get_chat_model(model_name: str, **kwargs):
        captured["model_name"] = model_name
        captured["kwargs"] = kwargs
        return RunnableLambda(lambda _prompt_value: "stubbed answer")

    monkeypatch.setattr(basic_module, "search_runnable", fake_search_runnable)
    monkeypatch.setattr(basic_module, "get_chat_model", fake_get_chat_model)

    with caplog.at_level(logging.WARNING, logger="chATLAS_Chains.llm.model_selection"):
        chain = basic_module.basic_retrieval_chain(
            prompt="Question: {question}\nContext: {context}",
            vectorstore=cast(VectorStore, object()),
            model_name="gpt-4o-mini",
            chat_model_kwargs={"temperature": 0.2, "unsupported_key": "x"},
        )

    assert captured["model_name"] == "gpt-4o-mini"
    assert captured["kwargs"] == {"temperature": 0.2}
    assert "Ignoring unknown chat_model_kwargs key 'unsupported_key'" in caplog.text
    output = chain.invoke("What is ATLAS?")
    assert output["answer"] == "stubbed answer"


def test_basic_retrieval_chain_constructs_with_only_model_name(monkeypatch):
    monkeypatch.setattr(
        basic_module,
        "search_runnable",
        lambda _vectorstore: RunnableLambda(lambda question: {"question": question, "docs": []}),
    )
    monkeypatch.setattr(
        basic_module,
        "get_chat_model",
        lambda _model_name, **_kwargs: RunnableLambda(lambda _prompt_value: "stubbed answer"),
    )

    chain = basic_module.basic_retrieval_chain(
        prompt="Question: {question}\nContext: {context}",
        vectorstore=cast(VectorStore, object()),
        model_name="gpt-4o-mini",
    )

    output = chain.invoke("What is ATLAS?")
    assert output["answer"] == "stubbed answer"


def test_advanced_rag_query_rewriting_kwargs_merge_precedence(monkeypatch):
    calls: list[tuple[str, dict[str, object]]] = []

    class DummyChatModel:
        def invoke(self, _prompt):
            return type("Resp", (), {"content": "ok"})()

    monkeypatch.setattr(
        advanced_module,
        "search_runnable",
        lambda _vectorstore: RunnableLambda(lambda question: {"question": question, "docs": []}),
    )

    def fake_get_chat_model(model_name: str, **kwargs):
        calls.append((model_name, kwargs))
        return DummyChatModel()

    monkeypatch.setattr(advanced_module, "get_chat_model", fake_get_chat_model)

    advanced_module.advanced_rag(
        vectorstore=cast(VectorStore, object()),
        model_name="primary-model",
        enable_query_rewriting=True,
        query_rewriting_model="rewrite-model",
        chat_model_kwargs={"temperature": 0.9, "max_tokens": 50, "unsupported_key": "x"},
        query_rewriting_chat_model_kwargs={"temperature": 0.2, "proxy": "socks5h://localhost:1080"},
    )

    assert calls[0] == ("primary-model", {"temperature": 0.9, "max_tokens": 50})
    assert calls[1] == (
        "rewrite-model",
        {"temperature": 0.2, "max_tokens": 50, "proxy": "socks5h://localhost:1080"},
    )


def test_conversational_contextualization_kwargs_and_forwarding(monkeypatch):
    contextualization_calls: list[tuple[str, dict[str, object]]] = []
    captured_advanced_kwargs: dict[str, object] = {}

    class DummyChatModel:
        def invoke(self, _prompt):
            return type("Resp", (), {"content": "contextualized query"})()

    class DummyAdvancedGraph:
        def invoke(self, _state):
            return {"answer": "ok", "docs": []}

    def fake_get_chat_model(model_name: str, **kwargs):
        contextualization_calls.append((model_name, kwargs))
        return DummyChatModel()

    def fake_advanced_rag(**kwargs):
        captured_advanced_kwargs.update(kwargs)
        return DummyAdvancedGraph()

    monkeypatch.setattr(conversational_module, "get_chat_model", fake_get_chat_model)
    monkeypatch.setattr(conversational_module, "advanced_rag", fake_advanced_rag)

    conversational_module.conversational_retrieval_graph(
        vectorstore=object(),
        model_name="primary-model",
        checkpointer=MemorySaver(),
        enable_query_contextualization=True,
        chat_model_kwargs={"service_provider": "litellm", "max_tokens": 999, "temperature": 0.8},
        query_rewriting_chat_model_kwargs={"temperature": 0.33},
        contextualization_chat_model_kwargs={"max_tokens": 128},
    )

    assert contextualization_calls[0] == (
        conversational_module.GROQ_PRODUCTION_MODELS[0],
        {"service_provider": "litellm", "max_tokens": 128, "temperature": 0.1},
    )

    assert captured_advanced_kwargs["chat_model_kwargs"] == {
        "service_provider": "litellm",
        "max_tokens": 999,
        "temperature": 0.8,
    }
    assert captured_advanced_kwargs["query_rewriting_chat_model_kwargs"] == {"temperature": 0.33}


def test_conversational_graph_constructs_with_only_model_name(monkeypatch):
    class DummyAdvancedGraph:
        def invoke(self, _state):
            return {"answer": "ok", "docs": []}

    monkeypatch.setattr(conversational_module, "advanced_rag", lambda **_kwargs: DummyAdvancedGraph())

    graph = conversational_module.conversational_retrieval_graph(
        vectorstore=object(),
        model_name="gpt-4o-mini",
        checkpointer=MemorySaver(),
        enable_query_contextualization=False,
    )

    assert graph is not None
