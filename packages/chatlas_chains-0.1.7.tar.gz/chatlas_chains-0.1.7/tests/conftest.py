"""
vectorstore fixtures for CI/CD
"""

import os
from typing import NoReturn

import pytest

from chATLAS_Chains.vectorstore import VectorStoreManager

DEFAULT_HF_MODEL = "chatlas/multi-qa-mpnet-base-dot-v1-ATLAS-TALK"


def _env_flag(name: str) -> bool:
    """Parse boolean environment variables in a predictable way."""
    value = os.getenv(name, "")
    return value in {"1", "true", "True"}


def _skip_db_tests(message: str) -> NoReturn:
    """Skip DB-backed tests and make control-flow explicit for type checkers."""
    pytest.skip(message)
    raise AssertionError("unreachable")


@pytest.fixture(scope="session")
def manager() -> VectorStoreManager:
    """
    Build a VectorStoreManager for integration tests.

    Skips DB-backed tests when local environment configuration is missing.
    """
    port_forwarding = _env_flag("CHATLAS_PORT_FORWARDING")

    try:
        return VectorStoreManager(model_path=DEFAULT_HF_MODEL, port_forwarding=port_forwarding)
    except ValueError as exc:
        _skip_db_tests(
            "Skipping DB-backed tests: vectorstore environment is not configured "
            f"(CHATLAS_PORT_FORWARDING={port_forwarding}, "
            f"CHATLAS_DB_PASSWORD={'set' if os.getenv('CHATLAS_DB_PASSWORD') else 'unset'}; error: {exc})"
        )


@pytest.fixture(scope="session")
def twiki_vectorstore(manager: VectorStoreManager):
    """
    Create a twiki vectorstore fixture for the CI/CD
    """

    try:
        vectorstore = manager.get_vectorstore("twiki_prod")
    except Exception as exc:
        pytest.skip(f"Skipping DB-backed tests: could not initialize twiki_prod vectorstore ({exc})")

    yield vectorstore

    vectorstore.close()


@pytest.fixture(scope="session")
def mkdocs_vectorstore(manager: VectorStoreManager):
    """
    Create a mkdocs vectorstore fixture for the CI/CD
    """

    try:
        vectorstore = manager.get_vectorstore("mkdocs_prod_v1")
    except Exception as exc:
        pytest.skip(f"Skipping DB-backed tests: could not initialize mkdocs_prod_v1 vectorstore ({exc})")

    yield vectorstore

    vectorstore.close()


@pytest.fixture(scope="session")
def cds_vectorstore(manager: VectorStoreManager):
    """
    Create a cds vectorstore fixture for the CI/CD
    """

    try:
        vectorstore = manager.get_vectorstore("cds_v1")
    except Exception as exc:
        pytest.skip(f"Skipping DB-backed tests: could not initialize cds_v1 vectorstore ({exc})")

    yield vectorstore

    vectorstore.close()


@pytest.fixture(scope="session")
def three_vectorstores(twiki_vectorstore, mkdocs_vectorstore, cds_vectorstore):
    """
    Fixture that returns the twiki, mkdocs and CDS vectorstores as a list
    """
    return [twiki_vectorstore, mkdocs_vectorstore, cds_vectorstore]
