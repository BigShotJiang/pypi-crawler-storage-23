"""
Tests for conversational RAG graph.
"""

import pytest
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver

from chATLAS_Chains.chains.conversational_graph import conversational_retrieval_graph
from chATLAS_Chains.llm.model_selection import GROQ_PRODUCTION_MODELS

GROQ_MODEL_KWARGS = {"service_provider": "groq"}


@pytest.fixture
def checkpointer():
    """In-memory checkpointer for tests"""
    return MemorySaver()


@pytest.fixture
def search_kwargs():
    """Default search kwargs for tests"""
    return {"k_text": 3, "k": 15, "date_filter": "01-01-2010"}


def test_pronoun_resolution(twiki_vectorstore, checkpointer, search_kwargs):
    """Test pronoun 'them' resolves to TWiki rules from previous turn."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_pronoun_resolution"

    graph.invoke(
        {
            "messages": [HumanMessage(content="What are the rules for creating TWiki pages?")],
            "search_kwargs": search_kwargs,
        },
        config={"configurable": {"thread_id": thread_id}},
    )

    # Rewrite: 'How do I follow the rules for creating TWiki pages?'
    result = graph.invoke(
        {"messages": [HumanMessage(content="How do I follow them?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    assert "twiki" in answer or "page" in answer or "rule" in answer


def test_incomplete_reference(twiki_vectorstore, checkpointer, search_kwargs):
    """Test ordinal reference 'the third one' resolves to specific list item."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_incomplete_reference"

    # First turn: establishes a list (Responsible, Editor signature, Reviewer name, Review date)
    graph.invoke(
        {
            "messages": [HumanMessage(content="What information should be included at the bottom of a TWiki page?")],
            "search_kwargs": search_kwargs,
        },
        config={"configurable": {"thread_id": thread_id}},
    )

    # Second turn: refers to list item by ordinal
    # Rewrite: 'What is the purpose of the Name of Reviewer and Date of last Review?'
    result = graph.invoke(
        {"messages": [HumanMessage(content="What is the purpose of the third one?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    # Third item should be "Name of Reviewer" - verify answer relates to reviewing
    assert "review" in answer or "quality" in answer or "assess" in answer


def test_clarification_refinement(twiki_vectorstore, checkpointer, search_kwargs):
    """Test clarification 'Using WikiWords' refines the previous question."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_clarification"

    graph.invoke(
        {"messages": [HumanMessage(content="How to create a new TWiki page?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    # Rewrite: 'Using WikiWords to create new TWiki pages'
    result = graph.invoke(
        {"messages": [HumanMessage(content="Using WikiWords")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    assert "wikiword" in answer or "uppercase" in answer or "lowercase" in answer


def test_topic_shift(twiki_vectorstore, checkpointer, search_kwargs):
    """Test topic shift - new topic should not include previous context."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_topic_shift"

    graph.invoke(
        {"messages": [HumanMessage(content="What is the ATLAS Protected Web?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    # No rewrite: Question is self-contained and about a different topic
    result = graph.invoke(
        {"messages": [HumanMessage(content="How to delete a TWiki page?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    assert "delete" in answer or "removal" in answer or "contact" in answer


def test_generalization(twiki_vectorstore, checkpointer, search_kwargs):
    """Test generalization - broader question should not inherit specific context."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_generalization"

    graph.invoke(
        {
            "messages": [HumanMessage(content="How to set parent topic for an existing page?")],
            "search_kwargs": search_kwargs,
        },
        config={"configurable": {"thread_id": thread_id}},
    )

    # Rewrite: 'What is a parent topic in the ATLAS TWiki?'
    result = graph.invoke(
        {"messages": [HumanMessage(content="What is a parent topic?")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    assert "parent" in answer or "breadcrumb" in answer or "metadata" in answer


def test_spelling_and_grammar_correction(twiki_vectorstore, checkpointer, search_kwargs):
    """Test spelling and grammar errors are corrected while preserving abbreviations."""
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
    )

    thread_id = "test_spelling_grammar"

    # Spelling errors: "differance" (difference), "betwenn" (between)
    # Grammar error: missing "the" before "difference"
    # Abbreviations to preserve: "xAOD", "AOD"
    # Rewrite: 'What is the difference between xAOD and AOD?'
    result = graph.invoke(
        {
            "messages": [HumanMessage(content="What differance betwenn xAOD and AOD?")],
            "search_kwargs": search_kwargs,
        },
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content.lower()
    # Should understand the question despite errors, and mention data format content
    assert "xaod" in answer or "aod" in answer or "format" in answer or "data" in answer


def test_hard_turn_limit(twiki_vectorstore, checkpointer, search_kwargs):
    """Test that conversation strictly stops after max_total_turns is reached."""
    # Set hard limit to 2 turns
    graph = conversational_retrieval_graph(
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        contextualization_chat_model_kwargs=GROQ_MODEL_KWARGS,
        max_turns=2,
    )

    thread_id = "test_hard_limit"

    # Turn 1: OK
    graph.invoke(
        {"messages": [HumanMessage(content="Hello")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    # Turn 2: OK (This reaches the limit: 2 Q + 2 A = 4 messages)
    graph.invoke(
        {"messages": [HumanMessage(content="Second question")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    # Turn 3: Should trigger the limit message
    result = graph.invoke(
        {"messages": [HumanMessage(content="Third question")], "search_kwargs": search_kwargs},
        config={"configurable": {"thread_id": thread_id}},
    )

    answer = result["messages"][-1].content
    assert "limit" in answer.lower()
    assert "2" in answer
    assert "new thread" in answer.lower()
