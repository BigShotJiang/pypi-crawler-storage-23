import pytest

import chATLAS_Chains.llm.model_selection as ms


def test_autoselect_prefers_groq(monkeypatch, capsys):
    model_name = "openai/gpt-oss-120b"

    called = {}

    def fake_groq_runnable(model_name_arg, api_key=None, temperature=None, max_tokens=None, base_url=None, proxy=None):
        called["model_name"] = model_name_arg
        called["api_key"] = api_key
        called["temperature"] = temperature
        called["max_tokens"] = max_tokens
        called["base_url"] = base_url
        called["proxy"] = proxy
        return object()

    monkeypatch.setattr(ms, "groq_runnable", fake_groq_runnable)

    llm = ms.get_chat_model(model_name, service_provider="")
    assert llm is not None
    assert called["model_name"] == model_name

    if model_name in ms.OPENAI_MODELS:
        assert "Defaulting to Groq" in capsys.readouterr().out


def test_openai_requires_api_key(monkeypatch):
    model_name = ms.OPENAI_MODELS[0]

    monkeypatch.delenv("CHATLAS_OPENAI_KEY", raising=False)

    with pytest.raises(ValueError, match="Missing OpenAI API key"):
        ms.get_chat_model(model_name, service_provider="openai", api_key=None)


def test_openai_delegates_to_openai_runnable(monkeypatch):
    model_name = ms.OPENAI_MODELS[0]

    called = {}

    def fake_openai_runnable(model_name_arg, api_key=None, temperature=None, max_tokens=None):
        called["model_name"] = model_name_arg
        called["api_key"] = api_key
        called["temperature"] = temperature
        called["max_tokens"] = max_tokens
        return object()

    monkeypatch.setattr(ms, "openai_runnable", fake_openai_runnable)

    llm = ms.get_chat_model(model_name, service_provider="openai", api_key="k", temperature=0.4, max_tokens=100)
    assert llm is not None
    assert called == {
        "model_name": model_name,
        "api_key": "k",
        "temperature": 0.4,
        "max_tokens": 100,
    }


def test_groq_max_tokens_default(monkeypatch):
    model_name = ms.GROQ_MODELS[0]

    created = {}

    def fake_groq_runnable(
        model_name_arg, base_url="https://api.groq.com/openai/v1", api_key=None, temperature=None, max_tokens=None
    ):
        created["model_name"] = model_name_arg
        created["base_url"] = base_url
        created["api_key"] = api_key
        created["temperature"] = temperature
        created["max_tokens"] = max_tokens
        return object()

    monkeypatch.setattr(ms, "groq_runnable", fake_groq_runnable)

    ms.get_chat_model(model_name, service_provider="groq")

    assert created["max_tokens"] == ms.get_max_completion_tokens(model_name)


def test_groq_rejects_excessive_max_tokens(monkeypatch):
    model_name = ms.GROQ_MODELS[0]

    monkeypatch.setattr(ms, "groq_runnable", lambda *args, **kwargs: object())

    with pytest.raises(ValueError, match="exceeds the model's maximum"):
        ms.get_chat_model(
            model_name,
            service_provider="groq",
            max_tokens=ms.get_max_completion_tokens(model_name) + 1,
        )


def test_litellm_called_with_base_url(monkeypatch):
    called = {}

    def fake_litellm_runnable(
        model_name_arg,
        base_url="https://llmgw-litellm.web.cern.ch/v1",
        api_key=None,
        temperature=None,
        max_tokens=None,
        proxy=None,
    ):
        called["model_name"] = model_name_arg
        called["base_url"] = base_url
        called["api_key"] = api_key
        called["temperature"] = temperature
        called["max_tokens"] = max_tokens
        called["proxy"] = proxy
        return object()

    monkeypatch.setattr(ms, "litellm_runnable", fake_litellm_runnable)

    llm = ms.get_chat_model(
        "gpt-oss-20b",
        service_provider="litellm",
        api_key="k",
        base_url="https://litellm.test",
        temperature=0.3,
    )

    assert llm is not None
    assert called["base_url"] == "https://litellm.test"
    assert called["temperature"] == 0.3
