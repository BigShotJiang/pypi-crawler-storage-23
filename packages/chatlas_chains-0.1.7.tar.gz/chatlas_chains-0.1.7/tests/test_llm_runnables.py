import os

import pytest

from chATLAS_Chains.llm.runnables import groq_runnable, litellm_runnable, openai_runnable


def _secret_to_str(value) -> str:
    """Handle Pydantic SecretStr / plain str seamlessly."""
    getter = getattr(value, "get_secret_value", None)
    return getter() if callable(getter) else str(value)


def test_litellm_model_uses_explicit_api_key_and_strips():
    llm = litellm_runnable(
        model_name="gpt-4",
        api_key="  sk-test-key  ",
        base_url="https://example.com/v1",
    )

    # ChatOpenAI is a Pydantic model; args are stored as attributes.
    # These are the "real" field names used internally by langchain-openai.
    assert llm.model_name == "gpt-4"

    # Depending on langchain-openai version, this may be stored under openai_api_key
    # (recommended) or exposed via model_dump; we check attribute first.
    assert _secret_to_str(llm.openai_api_key) == "sk-test-key"
    assert llm.openai_api_base == "https://example.com/v1"


def test_litellm_model_uses_env_var_when_api_key_not_provided(monkeypatch):
    monkeypatch.setenv("CHATLAS_CHAINS_LITELLM_KEY", "  sk-env-key  ")

    llm = litellm_runnable(
        model_name="hf-qwen25-32b",
        base_url="https://example.com/v1",
    )

    assert llm.model_name == "hf-qwen25-32b"
    assert _secret_to_str(llm.openai_api_key) == "sk-env-key"
    assert llm.openai_api_base == "https://example.com/v1"


def test_litellm_model_raises_if_no_key_in_arg_or_env(monkeypatch):
    monkeypatch.delenv("CHATLAS_CHAINS_LITELLM_KEY", raising=False)

    with pytest.raises(ValueError, match="Missing API key for LiteLLM"):
        litellm_runnable(model_name="gpt-4")
