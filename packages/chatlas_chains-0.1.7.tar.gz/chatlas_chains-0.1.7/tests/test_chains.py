"""
Unit tests for basic_retrieval_chain

These**NOTE** These require a running postgres database with a populated vector store.

The fixtures used for the tests are defined in conftest.py and are automatically gathered by pytest
"""

import pytest
from langchain_core.documents import Document
from langchain_core.runnables import RunnableSequence
from pydantic import ValidationError

from chATLAS_Chains.chains.advanced import advanced_rag
from chATLAS_Chains.chains.basic import basic_retrieval_chain
from chATLAS_Chains.llm.model_selection import GROQ_PRODUCTION_MODELS
from chATLAS_Chains.prompt.starters import CHAT_PROMPT_TEMPLATE

GROQ_MODEL_KWARGS = {"service_provider": "groq"}


def test_basic_retrieval_chain_returns_runnablesequence(twiki_vectorstore):
    chain = basic_retrieval_chain(prompt=CHAT_PROMPT_TEMPLATE, vectorstore=twiki_vectorstore, model_name="gpt-4o-mini")

    assert isinstance(chain, RunnableSequence)


def test_search_runnable_returns_runnablesequence_with_list_of_vectorstores(three_vectorstores):
    chain = basic_retrieval_chain(prompt=CHAT_PROMPT_TEMPLATE, vectorstore=three_vectorstores, model_name="gpt-4o-mini")

    assert isinstance(chain, RunnableSequence)


def test_search_runnable_error_on_invalid_input():
    with pytest.raises(ValidationError):
        basic_retrieval_chain(
            prompt=CHAT_PROMPT_TEMPLATE,
            vectorstore="not a vectorstore",  # type: ignore[arg-type]
            model_name="gpt-4o-mini",
        )


def test_basic_retrieval_chain_returns_docs_and_answer(twiki_vectorstore):
    chain = basic_retrieval_chain(
        prompt=CHAT_PROMPT_TEMPLATE,
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        chat_model_kwargs=GROQ_MODEL_KWARGS,
    )
    output = chain.invoke("What is the Higgs boson?")

    assert "docs" in output, "'docs' key not in output"
    assert "answer" in output, "'answer' key not in output"

    assert isinstance(output["docs"], list), "'docs' is not a list"
    assert all([isinstance(obj, Document) for obj in output["docs"]]), "'docs' should be a list of Documents"


def test_basic_retrieval_chain_multiple_vectorstores(three_vectorstores):
    chain = basic_retrieval_chain(
        prompt=CHAT_PROMPT_TEMPLATE,
        vectorstore=three_vectorstores,
        model_name=GROQ_PRODUCTION_MODELS[0],
        chat_model_kwargs=GROQ_MODEL_KWARGS,
    )
    output = chain.invoke("What is the Higgs boson?")

    assert "docs" in output, "'docs' key not in output"
    assert len(output["docs"]) > 1, "Didn't return more than one doc with k=15, k_text=3, three vectorstores"
    assert "answer" in output, "'answer' key not in output"

    assert isinstance(output["docs"], list), "'docs' is not a list"

    sources = set([doc.metadata.get("source") for doc in output["docs"]])
    expected_sources = {"twiki", "MkDocs", "CDS"}
    assert sources == expected_sources, (
        f"Unexpected sources from three vectorstore search: {sources}, expected {expected_sources}"
    )


def test_advanced_rag_chain(twiki_vectorstore):
    # TODO: this is required currently requried for search to work
    search_kwargs = {
        "k_text": 3,
        "k": 15,
        "date_filter": "01-01-2010",
        # "type": ["twiki"],
    }

    chain = advanced_rag(
        prompt=CHAT_PROMPT_TEMPLATE,
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        chat_model_kwargs=GROQ_MODEL_KWARGS,
    )
    output = chain.invoke(
        {"question": "What is the Higgs boson?", "search_kwargs": search_kwargs},
    )

    assert "docs" in output, "'docs' key not in output"
    assert len(output["docs"]) > 1, "Didn't return more than one doc with k=15, k_text=3"
    assert "answer" in output, "'answer' key not in output"
    assert isinstance(output["docs"], list), "'docs' is not a list"
    assert isinstance(output["docs"][0], Document), (
        f"'docs' should contain instances of {Document}, but instead it has {type(output['docs'][0])}"
    )

    # test with the additional options turned on (besides rerank)
    chain = advanced_rag(
        prompt=CHAT_PROMPT_TEMPLATE,
        vectorstore=twiki_vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        chat_model_kwargs=GROQ_MODEL_KWARGS,
        enable_query_rewriting=True,
        query_rewriting_chat_model_kwargs=GROQ_MODEL_KWARGS,
        enable_rrf=True,
    )

    output = chain.invoke(
        {"question": "What is the Higgs boson?", "search_kwargs": search_kwargs},
    )

    assert "docs" in output, "'docs' key not in output"
    assert len(output["docs"]) > 1, "Didn't return more than one doc with k=15, k_text=3"
    assert "answer" in output, "'answer' key not in output"
    assert isinstance(output["docs"], list), "'docs' is not a list"
    assert all(isinstance(obj, Document) for obj in output["docs"]), (
        f"'docs' should only contain instances of {Document}"
    )
    assert all("rrf_score" in doc.metadata for doc in output["docs"]), "'rrf_score' not in document metadata"


def test_advanced_rag_chain_multiple_vectorstores(three_vectorstores):
    search_kwargs = {
        "k_text": 3,
        "k": 15,
        "date_filter": "01-01-2010",
        # "type": ["twiki"],
    }

    chain = advanced_rag(
        prompt=CHAT_PROMPT_TEMPLATE,
        vectorstore=three_vectorstores,
        model_name=GROQ_PRODUCTION_MODELS[0],
        chat_model_kwargs=GROQ_MODEL_KWARGS,
    )
    output = chain.invoke(
        {"question": "What is the Higgs boson?", "search_kwargs": search_kwargs},
    )

    assert "docs" in output, "'docs' key not in output"
    assert len(output["docs"]) > 1, "Didn't return more than one doc with k=15, k_text=3, three vectorstores"
    assert "answer" in output, "'answer' key not in output"
    assert isinstance(output["docs"], list), "'docs' is not a list"
    assert isinstance(output["docs"][0], Document), (
        f"'docs' should contain instances of {Document}, but instead it has {type(output['docs'][0])}"
    )

    sources = set([doc.metadata.get("source") for doc in output["docs"]])
    expected_sources = {"twiki", "MkDocs", "CDS"}
    assert sources == expected_sources, (
        f"Unexpected sources from three vectorstore search: {sources}, expected {expected_sources}"
    )
