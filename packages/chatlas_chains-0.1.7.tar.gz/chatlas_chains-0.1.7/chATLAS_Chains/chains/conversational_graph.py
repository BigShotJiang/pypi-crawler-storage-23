"""
Conversational RAG graph with multi-turn conversation support.

TODO: Add persistent checkpointer for production deployment
TODO: Add glossary-based abbreviation expansion
"""

import logging
from typing import Annotated, TypedDict

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from sentence_transformers.util import cos_sim

from chATLAS_Chains.chains.advanced import advanced_rag
from chATLAS_Chains.llm.model_selection import (
    GROQ_PRODUCTION_MODELS,
    ChatModelKwargs,
    get_chat_model,
    sanitize_chat_model_kwargs,
)
from chATLAS_Chains.prompt.starters import (
    CHAT_PROMPT_TEMPLATE,
    CONVERSATIONAL_CHAT_PROMPT_TEMPLATE,
    QUERY_CONTEXTUALIZATION_PROMPT,
)

logger = logging.getLogger(__name__)


def get_message_type(msg: BaseMessage) -> str:
    """Identify message type from LangChain message object.

    :param msg: LangChain message object.
    :return: Message type ("human", "ai", "system", or "unknown").
    """
    if isinstance(msg, HumanMessage):
        return "human"
    elif isinstance(msg, AIMessage):
        return "ai"
    elif isinstance(msg, SystemMessage):
        return "system"
    elif hasattr(msg, "type"):
        return msg.type
    return "unknown"


def select_relevant_history(
    question: str,
    messages: list[BaseMessage],
    embedder,
    max_messages: int = 10,
    min_similarity: float = 0.3,
) -> list[BaseMessage]:
    """Select messages semantically relevant to the current query.

    :param question: Current user query.
    :param messages: Full conversation history.
    :param embedder: Embedding model with embed_query method.
    :param max_messages: Maximum messages to retain.
    :param min_similarity: Minimum similarity threshold.
    :return: Chronologically sorted list of relevant messages.
    """
    if len(messages) <= max_messages:
        return messages

    question_embedding = embedder.embed_query(question)

    scored_messages = []
    for i, msg in enumerate(messages):
        msg_embedding = embedder.embed_query(msg.content)
        similarity = cos_sim(question_embedding, msg_embedding).item()
        scored_messages.append((i, similarity, msg))

    scored_messages.sort(key=lambda x: x[1], reverse=True)
    selected = [(i, msg) for i, sim, msg in scored_messages[:max_messages] if sim >= min_similarity]

    selected.sort(key=lambda x: x[0])
    return [msg for _, msg in selected]


def format_chat_history(messages: list[BaseMessage], max_turns: int = 5) -> str:
    """
    Format conversation history as a string for LLM consumption.

    Args:
        messages: List of conversation messages (excluding the current question)
        max_turns: Maximum number of conversation turns to include (1 turn = 1 Q&A pair)

    Returns:
        Formatted conversation history string
    """
    if not messages:
        return ""

    max_messages = max_turns * 2
    recent_messages = messages[-max_messages:] if len(messages) > max_messages else messages

    history_lines = []
    for msg in recent_messages:
        if hasattr(msg, "type"):
            if msg.type == "human":
                history_lines.append(f"Human: {msg.content}")
            elif msg.type == "ai":
                history_lines.append(f"Assistant: {msg.content}")
        elif isinstance(msg, HumanMessage):
            history_lines.append(f"Human: {msg.content}")
        elif isinstance(msg, AIMessage):
            history_lines.append(f"Assistant: {msg.content}")

    return "\n".join(history_lines)


class ConversationalGraphState(TypedDict, total=False):
    """State for conversational RAG graph with message history."""

    messages: Annotated[list[BaseMessage], add_messages]
    search_kwargs: dict
    answer: str


def conversational_retrieval_graph(
    vectorstore,
    model_name: str,
    checkpointer: BaseCheckpointSaver,
    prompt: str | None = None,
    chat_model_kwargs: ChatModelKwargs | None = None,
    enable_query_rewriting: bool = False,
    enable_rrf: bool = True,
    enable_reranking: bool = False,
    enable_query_contextualization: bool = True,
    query_rewriting_model: str = GROQ_PRODUCTION_MODELS[0],
    query_rewriting_chat_model_kwargs: ChatModelKwargs | None = None,
    contextualization_model: str | None = None,
    contextualization_chat_model_kwargs: ChatModelKwargs | None = None,
    max_turns: int = 10,
    rerank_model: str = "cohere-rerank-3.5",
    pinecone_api_key: str | None = None,
    rrf_constant: float = 60.0,
    rrf_weights: dict[str, float] | None = None,
    embedder=None,  # Required for semantic history selection
) -> CompiledStateGraph:
    """
    Conversational RAG graph with multi-turn conversation support.
    Includes query contextualization to resolve coreferences (pronouns like "it", "they", "this") in multi-turn conversations.

    :param vectorstore: Vector store(s) for document retrieval.
    :param model_name: Primary LLM model name.
    :param checkpointer: LangGraph checkpointer for state persistence.
    :param prompt: Custom prompt template (defaults to CHAT_PROMPT_TEMPLATE).
    :param chat_model_kwargs: Optional kwargs passed through to ``get_chat_model`` for the main model.
    :param enable_query_rewriting: Enable LLM-powered query rewriting.
    :param enable_rrf: Enable Reciprocal Rank Fusion.
    :param enable_reranking: Enable document reranking.
    :param enable_query_contextualization: Enable query contextualization.
    :param query_rewriting_model: Model for query rewriting.
    :param query_rewriting_chat_model_kwargs: Optional kwargs for query rewriting model construction.
    :param contextualization_model: Model for query contextualization (defaults to query_rewriting_model).
    :param contextualization_chat_model_kwargs: Optional kwargs for contextualization model construction.
        Inheritance order is: ``chat_model_kwargs`` -> ``{"max_tokens": 256, "temperature": 0.1}`` defaults
        -> explicit contextualization kwargs.
    :param max_turns: Maximum conversation turns to include for context AND hard limit for session.
    :param rerank_model: Pinecone reranker model name.
    :param pinecone_api_key: Pinecone API key for reranking.
    :param rrf_constant: RRF constant (k parameter).
    :param rrf_weights: Weights for different retrievers in RRF.
    :param embedder: Embedding model for semantic history selection (required).

    :return: A compiled LangGraph instance with conversational memory.
    """
    if prompt is None:
        prompt = CONVERSATIONAL_CHAT_PROMPT_TEMPLATE

    if contextualization_model is None:
        contextualization_model = query_rewriting_model

    primary_model_kwargs = sanitize_chat_model_kwargs(chat_model_kwargs)

    contextualization_llm = None
    if enable_query_contextualization:
        contextualization_kwargs: ChatModelKwargs = {
            **primary_model_kwargs,
            "max_tokens": 256,
            "temperature": 0.1,
        }
        contextualization_kwargs.update(sanitize_chat_model_kwargs(contextualization_chat_model_kwargs))
        contextualization_llm = get_chat_model(
            model_name=contextualization_model,
            **contextualization_kwargs,
        )
        contextualization_prompt = ChatPromptTemplate.from_template(QUERY_CONTEXTUALIZATION_PROMPT)

    advanced_graph = advanced_rag(
        vectorstore=vectorstore,
        model_name=model_name,
        prompt=prompt,
        chat_model_kwargs=primary_model_kwargs,
        enable_query_rewriting=enable_query_rewriting,
        enable_rrf=enable_rrf,
        enable_reranking=enable_reranking,
        query_rewriting_model=query_rewriting_model,
        query_rewriting_chat_model_kwargs=query_rewriting_chat_model_kwargs,
        rerank_model=rerank_model,
        pinecone_api_key=pinecone_api_key,
        rrf_constant=rrf_constant,
        rrf_weights=rrf_weights,
    )

    def contextualize_question(question: str, messages: list[BaseMessage]) -> str:
        """Rewrite query to resolve coreferences and fix spelling errors.

        :param question: Current user query.
        :param messages: Conversation history.
        :return: Standalone question with resolved references and corrected spelling.
        """
        if not enable_query_contextualization or contextualization_llm is None:
            return question

        history_messages = [m for m in messages if m.content != question]

        # Always invoke LLM (even without history) for spelling correction
        if history_messages:
            if embedder is not None:
                history_messages = select_relevant_history(
                    question, history_messages, embedder, max_messages=max_turns * 2
                )
            chat_history = format_chat_history(history_messages, max_turns=max_turns)
        else:
            chat_history = "(No previous conversation)"

        try:
            formatted_prompt = contextualization_prompt.format(chat_history=chat_history, question=question)
            response = contextualization_llm.invoke(formatted_prompt)
            standalone_question = str(response.content).strip()

            if standalone_question != question:
                logger.info(f"Contextualized question: '{question}' -> '{standalone_question}'")
            else:
                logger.debug("Question unchanged after contextualization")

            return standalone_question

        except Exception as e:
            logger.warning(f"Query contextualization failed: {e}. Using original question.")
            return question

    def extract_question_and_call_advanced(state: ConversationalGraphState) -> dict:
        """Bridge conversational state to advanced RAG chain.

        :param state: Current graph state with messages.
        :return: Updated state with answer.
        """
        messages = state["messages"]

        if max_turns is not None and len(messages) >= max_turns * 2:
            limit_msg = f"Conversation turn limit ({max_turns}) reached. Please start a new thread."
            return {
                "messages": [AIMessage(content=limit_msg)],
                "answer": limit_msg,
            }

        question = ""
        for msg in reversed(messages):
            if get_message_type(msg) == "human":
                question = msg.content
                break

        if not question:
            raise ValueError("No human message found in conversation history")

        standalone_question = contextualize_question(question, messages)
        search_kwargs = state.get("search_kwargs", {})

        history_for_generation = format_chat_history(
            [m for m in messages if m.content != question], max_turns=max_turns
        )

        result = advanced_graph.invoke(
            {
                "question": standalone_question,
                "search_kwargs": search_kwargs,
                "chat_history": history_for_generation,
            }
        )

        docs = result.get("docs", [])
        if docs and logger.isEnabledFor(logging.DEBUG):
            print(f"Retrieved {len(docs)} documents for: '{standalone_question}'")
            print("-" * 80)

            for j, doc in enumerate(docs, 1):
                doc_name = doc.metadata.get("name", "Unknown")
                doc_url = doc.metadata.get("url", "Unknown")
                rrf_score = doc.metadata.get("rrf_score", None)
                similarity_score = doc.metadata.get("similarity", None)

                if rrf_score is not None:
                    print(f"  {j}. [RRF: {rrf_score:.4f}] {doc_name}")
                elif similarity_score is not None:
                    print(f"  {j}. [Sim: {similarity_score:.4f}] {doc_name}")
                else:
                    print(f"  {j}. {doc_name}")
                print(f"     URL: {doc_url}")

            print("-" * 80 + "\n")

        answer = result.get("answer", "")

        return {
            "messages": [AIMessage(content=answer)],
            "answer": answer,
        }

    graph = StateGraph(ConversationalGraphState)
    graph.add_node("rag", extract_question_and_call_advanced)
    graph.set_entry_point("rag")
    graph.add_edge("rag", END)

    return graph.compile(checkpointer=checkpointer)


if __name__ == "__main__":
    from langchain_core.messages import HumanMessage
    from langgraph.checkpoint.memory import InMemorySaver

    from chATLAS_Chains.vectorstore import get_vectorstore

    logger.setLevel(logging.DEBUG)

    vectorstore = get_vectorstore("twiki_prod")
    checkpointer = InMemorySaver()

    graph = conversational_retrieval_graph(
        vectorstore=vectorstore,
        model_name=GROQ_PRODUCTION_MODELS[0],
        checkpointer=checkpointer,
        enable_query_rewriting=False,
        enable_rrf=True,
        enable_reranking=False,
        enable_query_contextualization=True,
        max_turns=3,
    )

    session_id = "demo_session_contextualization"
    config = {"configurable": {"thread_id": session_id}}

    search_kwargs = {
        "k": 10,
        "k_text": 0,
        "date_filter": "01-01-2010",
    }

    questions = [
        # Turn 1: Specific context - Athena command with detailed parameters
        # Intent: Establish conversation context with a specific use case
        # Expected: Retrieve `AMAAthenaDriver zmumu_AOD 100 ConfigFile=Config/tutorial.conf 2>&1 | tee output.log` command from AMATutorial
        "What is the command line to run an AMA job in Athena using the 'zmumu_AOD' sample for 100 events with the tutorial configuration file?",
        # Turn 2: Generalization - Broaden scope from specific to general
        # Intent: Test if system recognizes generalization and avoids adding Q1's specific details
        # Expected: Return as-is, retrieve overview covering both Athena and Standalone modes
        "How do I run AMA?",
        # Turn 3: Clarification - Specify mode mentioned in Q2's answer
        # Intent: Test incomplete reference resolution (add context from Q2's answer)
        # Expected: Contextualize to "How do I run AMA in Standalone mode?", retrieve AMADriver.exe
        # Rewrite: 'How to run AMA in Standalone mode.'
        "I mean in Standalone mode.",
    ]

    for _, question in enumerate(questions, 1):
        result = graph.invoke(
            {
                "messages": [HumanMessage(content=question)],
                "search_kwargs": search_kwargs,
            },
            config=config,
        )

        for message in result["messages"][-2:]:
            message.pretty_print()
