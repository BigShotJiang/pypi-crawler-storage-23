DEFAULT_DOCUMENT_JOINER = """
Name of document: {name}
Date of document: {last_modification}
Content of document: {page_content}
"""
