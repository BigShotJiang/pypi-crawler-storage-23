"""
Module providing a LangChain runnable(s) for the various LLMs

All use the OpenAI protocol
"""

import os

import httpx
from langchain_openai import ChatOpenAI
from pydantic import SecretStr


def llm_runnable(
    model_name: str,
    base_url: str | None,
    api_key: str,
    temperature: float | None = None,
    max_tokens: int | None = None,
    proxy: str | None = None,
    timeout: float = 60.0,
    trust_env: bool = False,
):
    """
    Base function to return a LangChain runnable. Wrapped by the various LLM providers.

    Args:
        proxy: Optional proxy URL to use for requests. Use for LiteLLM if not on the CERN network.
    """

    # Build an httpx client with explicit proxy behavior
    client_kwargs = {
        "timeout": timeout,
        "trust_env": trust_env,
    }
    if proxy is not None:
        # httpx supports string proxies (including socks5h) when httpx[socks] is installed
        client_kwargs["proxy"] = proxy

    http_client = httpx.Client(**client_kwargs)

    kwargs = {
        "model": model_name,
        "api_key": api_key.strip(),
        "base_url": base_url,
        "http_client": http_client,
    }

    if temperature is not None:
        kwargs["temperature"] = temperature
    if max_tokens is not None:
        kwargs["max_tokens"] = max_tokens

    return ChatOpenAI(**kwargs)


def openai_runnable(
    model_name: str,
    api_key: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
):
    """
    Returns a LangChain runnable using the OpenAI API.

    Args:
        model_name: Model to use
        api_key: OpenAI API key, if None, tries to use the CHATLAS_OPENAI_KEY environment variable
        temperature: Model temperature. Defaults to None.
    """

    if api_key is None:
        api_key = os.getenv("CHATLAS_OPENAI_KEY")
        if not api_key or not api_key.strip():
            raise ValueError("Missing OpenAI API key. Set CHATLAS_OPENAI_KEY in environment or pass api_key argument.")

    return llm_runnable(model_name, None, api_key, temperature, max_tokens=max_tokens)


def groq_runnable(
    model_name: str,
    base_url: str = "https://api.groq.com/openai/v1",
    api_key: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
):
    """
    Returns a LangChain runnable using the Groq API.

    Args:
        model_name: Model to use
        base_url: The API URL to use. Uses the standard URL for the Groq API by default
        api_key: Groq API key, if None, tries to use the CHATLAS_GROQ_KEY environment variable
        temperature: Model temperature. Defaults to None.
        max_tokens: Maximum number of tokens to generate. If ``None``, uses the
            model default (or provider default behavior).
    """

    if api_key is None:
        api_key = os.getenv("CHATLAS_GROQ_KEY")
        if not api_key or not api_key.strip():
            raise ValueError("Missing Groq API key. Set CHATLAS_GROQ_KEY in environment or pass api_key argument.")

    return llm_runnable(model_name, base_url, api_key, temperature, max_tokens=max_tokens)


def litellm_runnable(
    model_name: str,
    base_url: str = "https://llmgw-litellm.web.cern.ch/v1",
    api_key: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    proxy: str | None = None,
):
    """
    Returns a LangChain runnable using the CERN-hosted LiteLLM API.

    Args:
        model_name: Model to use
        base_url: The API URL to use. Uses the standard URL for the Groq API by default
        api_key: LiteLLM API key, if None, tries to use the CHATLAS_CHAINS_LITELLM_KEY environment variable
        temperature: Model temperature. Defaults to None.
        max_tokens: Maximum number of tokens to generate. If ``None``, uses the
            model default (or provider default behavior).
        proxy: Optional proxy URL to use for requests. If provided, will be used instead of environment variables.
    """

    if api_key is None:
        api_key = os.getenv("CHATLAS_CHAINS_LITELLM_KEY")
        if not api_key or not api_key.strip():
            raise ValueError(
                "Missing API key for LiteLLM. Set the CHATLAS_CHAINS_LITELLM_KEY environment variable or provide it as an argument."
            )

    return llm_runnable(model_name, base_url, api_key, temperature, max_tokens=max_tokens, proxy=proxy)


if __name__ == "__main__":
    import time

    # Example use
    openai = openai_runnable("gpt-5-mini")
    groq = groq_runnable("openai/gpt-oss-120b")
    litellm = litellm_runnable("gpt-oss-20b", proxy="socks5h://localhost:1080")

    llms = [
        ("openai", openai),
        ("groq", groq),
        ("litellm", litellm),
    ]

    for provider, llm in llms:
        t0 = time.time()
        print("provider: ", provider)
        print(llm.invoke("Describe the LHC in one sentence."))
        print(f"Inference time: {time.time() - t0}")
