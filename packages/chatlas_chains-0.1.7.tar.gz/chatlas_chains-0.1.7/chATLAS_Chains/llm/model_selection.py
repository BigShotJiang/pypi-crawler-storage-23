import logging
from collections.abc import Mapping
from typing import Any, TypedDict, cast

from chATLAS_Chains.llm.runnables import groq_runnable, litellm_runnable, openai_runnable

logger = logging.getLogger(__name__)

# to update this list, see https://codimd.web.cern.ch/tQKiMa13Q4O-EJXWTO3N7w?view#Using-Your-Dedicated-API-Key-to-Access-LLMs
LITELLM_MODELS = [
    "llama-3.1-8b-instruct",
    "hf-qwen25-32b",
    "gpt-oss-20b",
    "gpt-4",
    "gpt-4-turbo",
    "gpt-4.1-nano",
    "gpt-5",
    "gpt-5.1",
    "gpt-5.2",
    "gpt-4.1",
    "e5-large-v2",
    "accgpt",
    "magistral-medium-latest",
    "codestral-latest",
    "devstral-medium-latest",
    "devstral-small-latest",
    "magistral-small-latest",
    "ministral-3b-latest",
    "ministral-8b-latest",
    "mistral-large-latest",
    "mistral-medium-latest",
    "mistral-small-latest",
    "mistral-tiny-latest",
    "mistral-moderation-latest",
    "mistral-ocr-latest",
    "pixtral-12b-latest",
    "pixtral-large-latest",
    "voxtral-mini-latest",
    "voxtral-small-latest",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-120b",
    "moonshotai/kimi-k2-instruct-0905",
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
]

# limit what OpenAI models we support (to control costs)
# see https://platform.openai.com/docs/pricing
OPENAI_MODELS = [
    "gpt-5.2",
    "gpt-5",
    "gpt-5-mini",
    "gpt-5-nano",
    "gpt-4o",
    "gpt-4.1",
    "gpt-4.1-mini",
    "gpt-4.1-nano",
    "gpt-4o-mini",
]

# see Groq docs: https://console.groq.com/docs/models
GROQ_PRODUCTION_MODELS = [
    "llama-3.1-8b-instant",
    "llama-3.3-70b-versatile",
    "meta-llama/llama-guard-4-12b",
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
]

GROQ_PREVIEW_MODELS = [
    "meta-llama/llama-4-maverick-17b-128e-instruct",
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "meta-llama/llama-prompt-guard-2-22m",
    "meta-llama/llama-prompt-guard-2-86m",
    "moonshotai/kimi-k2-instruct",
    "openai/gpt-oss-safeguard-20b",
    "qwen/qwen3-32b",
]

GROQ_CONTEXT_WINDOWS = {
    "default": 131_072,  # most models
    "meta-llama/llama-prompt-guard-2-22m": 512,
    "meta-llama/llama-prompt-guard-2-86m": 512,
}

GROQ_MAX_COMPLETION_TOKENS = {
    "default": 131_072,
    "llama-3.3-70b-versatile": 32_768,
    "meta-llama/llama-guard-4-12b": 1_024,
    "meta-llama/llama-4-maverick-17b-128e-instruct": 8192,
    "meta-llama/llama-4-scout-17b-16e-instruct": 8192,
    "meta-llama/llama-prompt-guard-2-22m": 512,
    "meta-llama/llama-prompt-guard-2-86m": 512,
    "moonshotai/kimi-k2-instruct": 16_384,
    "openai/gpt-oss-120b": 32_768,
    "openai/gpt-oss-20b": 32_768,
    "qwen/qwen3-32b": 40_960,
}

GROQ_MODELS = GROQ_PRODUCTION_MODELS + GROQ_PREVIEW_MODELS

SUPPORTED_CHAT_MODELS = OPENAI_MODELS + GROQ_MODELS + LITELLM_MODELS


class ChatModelKwargs(TypedDict, total=False):
    """Optional kwargs accepted by ``get_chat_model``."""

    service_provider: str
    api_key: str | None
    base_url: str | None
    max_tokens: int | None
    temperature: float | None
    proxy: str | None


_ALLOWED_CHAT_MODEL_KWARGS = set(ChatModelKwargs.__annotations__.keys())


def sanitize_chat_model_kwargs(chat_model_kwargs: Mapping[str, Any] | None) -> ChatModelKwargs:
    """Drop unknown keys from chat model kwargs and warn."""
    if chat_model_kwargs is None:
        return {}

    sanitized: dict[str, Any] = {}
    for key, value in chat_model_kwargs.items():
        if key in _ALLOWED_CHAT_MODEL_KWARGS:
            sanitized[key] = value
            continue

        logger.warning(
            "Ignoring unknown chat_model_kwargs key '%s'. Allowed keys are: %s",
            key,
            sorted(_ALLOWED_CHAT_MODEL_KWARGS),
        )

    return cast(ChatModelKwargs, sanitized)


def get_context_window(model_name: str) -> int:
    """
    Get the context window size for a given model.
    """
    if model_name not in GROQ_CONTEXT_WINDOWS:
        model_name = "default"

    return GROQ_CONTEXT_WINDOWS[model_name]


def get_max_completion_tokens(model_name: str) -> int:
    """
    Get the max completion tokens for a given model.
    """
    if model_name not in GROQ_MAX_COMPLETION_TOKENS:
        model_name = "default"

    return GROQ_MAX_COMPLETION_TOKENS[model_name]


def get_chat_model(
    model_name: str,
    service_provider: str = "",
    api_key: str | None = None,
    base_url: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    proxy: str | None = None,
):
    """
    Initialize a supported chat model.

    Args:
        model_name: Model to load

        service_provider: Which provider to use for this model.
            Used when a model is available from multiple providers (e.g. "gpt-5" is available from both OpenAI and LiteLLM).

        api_key: Optional API key for the provider. If not provided, will look for environment variables:
            - OpenAI: `CHATLAS_OPENAI_KEY`
            - Groq: `CHATLAS_GROQ_KEY`
            - LiteLLM: `CHATLAS_CHAINS_LITELLM_KEY`

        base_url: Optional base URL for the provider. Only needed for Groq and LiteLLM
                - Groq: `CHATLAS_GROQ_BASE_URL`
                - LiteLLM: defaults to "https://llmgw-litellm.web.cern.ch/v1" if not provided

        max_tokens: Maximum number of tokens to generate. If ``None``, uses the
            model default (or provider default behavior).

        temperature: Model temperature. If ``None``, uses the model default.

        proxy: Optional proxy URL to use for requests. If provided, will be used instead of environment variables.

    Returns:
        A configured chat model instance.

    Raises:
        ValueError: If ``model_name`` is unsupported, a required API environment
            variable is missing, a preview model is disallowed, or ``max_tokens``
            exceeds the model limit.
    """
    # work out which provider to use for this model if not explicitly specified
    service_provider = service_provider.lower()
    if service_provider == "":
        in_openai = model_name in OPENAI_MODELS
        in_groq = model_name in GROQ_MODELS
        in_litellm = model_name in LITELLM_MODELS

        # prefer Groq if possible
        if in_groq:
            service_provider = "groq"

            # warn if also avaiable from elsewhere
            if in_openai or in_litellm:
                print(
                    f"Model '{model_name}' is also available from either LiteLLM and OpenAI. Defaulting to Groq. To use the another provider, specify e.g. service_provider='openai' in the get_chat_model arguments."
                )

        elif in_litellm:
            service_provider = "litellm"

        elif in_openai:
            service_provider = "openai"
        else:
            raise ValueError(
                f"Model '{model_name}' is not in the list of supported models for any provider. Supported models: {SUPPORTED_CHAT_MODELS}"
            )

    print(f"Using service provider '{service_provider}' for model '{model_name}'")
    if service_provider == "openai":
        if model_name not in OPENAI_MODELS:
            raise ValueError(f"Model '{model_name}' is not an allowed OpenAI model. Allowed models: {OPENAI_MODELS}")

        llm = openai_runnable(model_name, api_key, temperature, max_tokens)

    elif service_provider == "groq":
        if max_tokens is None:
            max_tokens = get_max_completion_tokens(model_name)

        elif max_tokens > get_max_completion_tokens(model_name):
            raise ValueError(
                f"max_tokens ({max_tokens}) exceeds the model's maximum ({get_max_completion_tokens(model_name)})."
            )

        runnable_base_url = base_url if base_url is not None else "https://api.groq.com/openai/v1"
        llm = groq_runnable(
            model_name,
            base_url=runnable_base_url,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    elif service_provider == "litellm":
        runnable_base_url = base_url if base_url is not None else "https://llmgw-litellm.web.cern.ch/v1"
        llm = litellm_runnable(
            model_name,
            base_url=runnable_base_url,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            proxy=proxy,
        )

    else:
        raise ValueError(
            f"Unsupported service_provider argument '{service_provider}'. Supported providers: 'openai', 'groq', 'litellm'."
        )

    return llm


if __name__ == "__main__":
    from time import time
    # Example usage

    message = "Explain the Higgs boson in one sentence."

    service_provider_model = [
        # ("", "llama-3.1-8b-instruct"),
        # ("", "llama-3.1-8b-instant"),
        # ("", "gpt-oss-20b"),
        # ("openai", "gpt-5-mini"),
        # ("groq", "llama-3.1-8b-instant"),
        ("litellm", "gpt-oss-20b"),
    ]

    for service_provider, model_name in service_provider_model:
        if service_provider == "litellm":
            print(f"Testing LiteLLM model '{model_name}' with proxy...")
            llm = get_chat_model(model_name, service_provider, proxy="socks5h://localhost:1080")
        else:
            print(f"Testing model '{model_name}' from provider '{service_provider or 'auto-detected'}'...")
            llm = get_chat_model(model_name, service_provider, max_tokens=150)

        print(f"Successfully loaded model: {model_name}")

        t0 = time()
        result = llm.invoke(message)
        t1 = time()

        print(f"result ({model_name}): {result}")
        print(f"Time taken for {model_name}: {t1 - t0:.2f} seconds\n")
