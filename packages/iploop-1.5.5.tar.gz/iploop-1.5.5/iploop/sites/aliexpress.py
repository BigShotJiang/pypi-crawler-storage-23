"""AliExpress site preset."""
import re


class AliExpress:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
            resp = self.client.fetch(url, headers=headers, timeout=15)
            if resp.status_code != 200:
                return {"success": False, "data": {}, "source": "aliexpress-http", "error": f"HTTP {resp.status_code}"}

            html = resp.text
            data = {}

            t = re.search(r'<title>([^<]*)</title>', html)
            if t:
                raw_title = t.group(1).strip()
                # Clean "Buy X - Free Shipping..." pattern
                data["title"] = raw_title.split(" - ")[0].split("|")[0].strip()

            # Price from meta or JSON
            price = re.search(r'"price"\s*:\s*"?([0-9.]+)"?', html)
            if price:
                data["price"] = price.group(1)
            else:
                price2 = re.search(r'<meta[^>]*property="product:price:amount"[^>]*content="([^"]*)"', html)
                if price2:
                    data["price"] = price2.group(1)

            # Rating
            rv = re.search(r'"ratingValue"\s*:\s*"?([0-9.]+)"?', html)
            if rv:
                data["rating"] = float(rv.group(1))

            # Orders
            orders = re.search(r'([\d,]+)\s*(?:sold|orders)', html, re.IGNORECASE)
            if orders:
                data["orders"] = orders.group(1)

            return {"success": bool(data.get("title")), "data": data, "source": "aliexpress-http", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "aliexpress-http", "error": str(e)}
