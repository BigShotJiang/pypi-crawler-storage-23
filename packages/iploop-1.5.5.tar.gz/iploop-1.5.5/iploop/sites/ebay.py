"""eBay site preset with fixed extractors."""
import time
import random
import re
import json
import logging

logger = logging.getLogger("iploop.sites.ebay")


class eBay:
    RATE_LIMIT = 15
    _last_request = 0

    def __init__(self, client):
        self.client = client

    def _rate_limit(self):
        elapsed = time.time() - eBay._last_request
        if elapsed < self.RATE_LIMIT:
            time.sleep(self.RATE_LIMIT - elapsed + random.uniform(0, 2))
        eBay._last_request = time.time()

    def _extract_text(self, html: str) -> str:
        """Strip HTML tags and return clean text."""
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', html)
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def _validate_ebay_results(self, html: str) -> bool:
        """Check if we got real eBay search results."""
        if not html:
            return False
        
        # Check for actual search results
        result_indicators = [
            'class="s-item"',
            'data-testid="item-card"',
            'class="srp-results"',
            'id="srp-river-results"',
            'class="s-item__title"',
            'class="s-item__price"'
        ]
        
        return any(indicator in html for indicator in result_indicators)

    def _extract_ebay_products(self, html: str) -> list:
        """Extract product listings from eBay search results using improved regex."""
        products = []
        
        # Split by s-item boundaries — more reliable than matching nested divs
        item_chunks = re.split(r'<li[^>]*class="s-item\b', html)[1:]  # skip first empty chunk
        
        for item_html in item_chunks[:20]:
            
            # Extract title - look for s-item__title
            title_match = re.search(r'class="s-item__title"[^>]*>(?:<[^>]*>)*([^<]+)', item_html)
            if not title_match:
                title_match = re.search(r'<h3[^>]*>(?:<[^>]*>)*([^<]+)', item_html)
            title = self._extract_text(title_match.group(1)) if title_match else ""
            
            # Extract price - Price in <span class="s-item__price">
            price_match = re.search(r'<span class="s-item__price"[^>]*>([^<]+)', item_html)
            if not price_match:
                price_match = re.search(r'class="[^"]*price[^"]*"[^>]*>([^<]+)', item_html)
            price = self._extract_text(price_match.group(1)) if price_match else ""
            
            # Extract URL
            url_match = re.search(r'href="([^"]*)"', item_html)
            url = url_match.group(1) if url_match else ""
            
            # Extract shipping info
            shipping_match = re.search(r'class="s-item__shipping[^"]*"[^>]*>([^<]+)', item_html)
            shipping = self._extract_text(shipping_match.group(1)) if shipping_match else ""
            
            # Extract seller info
            seller_match = re.search(r'class="s-item__seller-info[^"]*"[^>]*>([^<]+)', item_html)
            seller = self._extract_text(seller_match.group(1)) if seller_match else ""
            
            # Extract condition
            condition_match = re.search(r'class="SECONDARY_INFO"[^>]*>([^<]+)', item_html)
            condition = self._extract_text(condition_match.group(1)) if condition_match else ""
            
            if title and price:
                products.append({
                    "title": title,
                    "price": price,
                    "url": url,
                    "shipping": shipping,
                    "seller": seller,
                    "condition": condition
                })
        
        # If no results with s-item__info, try the broader s-item pattern
        if not products:
            item_pattern = r'<div class="s-item[^"]*"[^>]*>(.*?)(?=<div class="s-item|</div>)'
            items = re.finditer(item_pattern, html, re.DOTALL)
            
            for item_match in items:
                item_html = item_match.group(1)
                
                title_match = re.search(r'class="s-item__title"[^>]*>(?:<[^>]*>)*([^<]+)', item_html)
                title = self._extract_text(title_match.group(1)) if title_match else ""
                
                price_match = re.search(r'<span class="s-item__price"[^>]*>([^<]+)', item_html)
                price = self._extract_text(price_match.group(1)) if price_match else ""
                
                if title and price:
                    products.append({
                        "title": title,
                        "price": price
                    })
        
        return products

    def _extract_item_data(self, html: str, item_id: str) -> dict:
        """Extract item data from eBay item page."""
        data = {"item_id": item_id}
        
        # Extract title
        title_match = re.search(r'<h1[^>]*id="x-title-label-lbl"[^>]*>([^<]+)', html)
        if not title_match:
            title_match = re.search(r'<h1[^>]*class="[^"]*it-ttl[^"]*"[^>]*>([^<]+)', html)
        if title_match:
            data['title'] = title_match.group(1).strip()
        
        # Extract price
        price_match = re.search(r'class="u-flL[^"]*"[^>]*>([^<]+)', html)
        if not price_match:
            price_match = re.search(r'id="prcIsum"[^>]*>([^<]+)', html)
        if price_match:
            data['price'] = price_match.group(1).strip()
        
        # Extract condition
        condition_match = re.search(r'Condition:[^>]*>([^<]+)', html, re.IGNORECASE)
        if condition_match:
            data['condition'] = condition_match.group(1).strip()
        
        # Extract seller
        seller_match = re.search(r'class="mbg-nw"[^>]*>([^<]+)', html)
        if seller_match:
            data['seller'] = seller_match.group(1).strip()
        
        # Extract shipping
        shipping_match = re.search(r'Shipping:[^>]*>([^<]+)', html, re.IGNORECASE)
        if shipping_match:
            data['shipping'] = shipping_match.group(1).strip()
        
        return data

    def search(self, query, country="US", extract=True):
        """Search eBay with improved extraction."""
        self._rate_limit()
        import urllib.parse
        
        domain_map = {
            "US": "ebay.com",
            "UK": "ebay.co.uk", 
            "DE": "ebay.de",
            "FR": "ebay.fr",
            "CA": "ebay.ca",
            "AU": "ebay.com.au"
        }
        
        domain = domain_map.get(country, "ebay.com")
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://www.{domain}/sch/i.html?_nkw={encoded_query}"
        
        resp = self.client.fetch(url, country=country)
        
        result = {
            "query": query,
            "url": url,
            "status": resp.status_code,
            "html": resp.text,
            "size_kb": len(resp.text) // 1024
        }
        
        if extract and resp.status_code == 200:
            if self._validate_ebay_results(resp.text):
                result["products"] = self._extract_ebay_products(resp.text)
            else:
                result["products"] = []
                logger.warning("eBay search returned no valid results")
        
        return result

    def item(self, item_id, country="US", extract=True):
        """Fetch an eBay item page with extraction."""
        self._rate_limit()
        url = f"https://www.ebay.com/itm/{item_id}"
        
        resp = self.client.fetch(url, country=country)
        
        result = {
            "item_id": item_id,
            "url": url,
            "status": resp.status_code,
            "html": resp.text,
            "size_kb": len(resp.text) // 1024
        }
        
        if extract and resp.status_code == 200:
            result["data"] = self._extract_item_data(resp.text, item_id)
        
        return result

    def category(self, category_id, country="US"):
        """Browse eBay category."""
        self._rate_limit()
        domain = {"US": "ebay.com", "UK": "ebay.co.uk", "DE": "ebay.de"}.get(country, "ebay.com")
        url = f"https://www.{domain}/sch/i.html?_sacat={category_id}"
        
        resp = self.client.fetch(url, country=country)
        
        return {
            "category_id": category_id,
            "url": url,
            "status": resp.status_code,
            "html": resp.text
        }
