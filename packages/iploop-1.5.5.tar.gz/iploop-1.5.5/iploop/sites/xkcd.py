"""XKCD site preset."""
import re


class XKCD:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            m = re.search(r'/(\d+)', url)
            api_url = f"https://xkcd.com/{m.group(1)}/info.0.json" if m else "https://xkcd.com/info.0.json"
            resp = self.client.fetch(api_url, timeout=10)
            d = resp.json()
            return {"success": True, "data": {
                "title": d.get("title"), "alt": d.get("alt"),
                "num": d.get("num"), "img": d.get("img"),
            }, "source": "xkcd-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "xkcd-api", "error": str(e)}
