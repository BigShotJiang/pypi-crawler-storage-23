"""Reddit site preset with post extraction."""
import time
import random
import re
import logging

logger = logging.getLogger("iploop.sites.reddit")


class Reddit:
    RATE_LIMIT = 5
    _last_request = 0

    def __init__(self, client):
        self.client = client

    def _rate_limit(self):
        elapsed = time.time() - Reddit._last_request
        if elapsed < self.RATE_LIMIT:
            time.sleep(self.RATE_LIMIT - elapsed + random.uniform(0, 2))
        Reddit._last_request = time.time()

    def _extract_text(self, html: str) -> str:
        """Strip HTML tags and return clean text."""
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', html)
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def _try_reddit_json_api(self, subreddit_name: str) -> dict:
        """Use Reddit JSON API - just append .json to any Reddit URL."""
        url = f"https://www.reddit.com/r/{subreddit_name}.json"
        
        try:
            # Use the client's proxy instead of direct requests
            resp = self.client.fetch(url, country="US", headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/html, */*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Cache-Control': 'no-cache',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none'
            })
            
            if resp.status_code == 200:
                import json
                data = json.loads(resp.text)
                posts = []
                
                # Parse Reddit JSON structure
                if 'data' in data and 'children' in data['data']:
                    for post_data in data['data']['children']:
                        post = post_data.get('data', {})
                        
                        posts.append({
                            'title': post.get('title', ''),
                            'author': post.get('author', ''),
                            'score': post.get('score', 0),
                            'url': f"https://www.reddit.com{post.get('permalink', '')}",
                            'subreddit': post.get('subreddit', ''),
                            'created_utc': post.get('created_utc'),
                            'num_comments': post.get('num_comments', 0),
                            'selftext': post.get('selftext', '')[:200] if post.get('selftext') else ''
                        })
                
                return {
                    'subreddit': subreddit_name,
                    'status': 200,
                    'source': 'reddit_json_api',
                    'posts': posts
                }
        
        except Exception as e:
            logger.debug(f"Reddit JSON API failed: {e}")
        
        return None

    def _validate_reddit_content(self, html: str) -> bool:
        """Check if we got real Reddit content."""
        if not html:
            return False
        
        indicators = [
            'data-testid="post"',
            'class="Post"',
            'data-click-id="subreddit"',
            'r/{subreddit}',
            'reddit-main-content',
            'Post__content'
        ]
        
        return any(indicator in html for indicator in indicators)

    def _extract_posts(self, html: str) -> list:
        """Extract posts from subreddit HTML."""
        posts = []
        
        # Pattern for post data
        post_pattern = r'data-testid="post-container"[^>]*>(.*?)(?=data-testid="post-container"|</div>)'
        post_matches = re.finditer(post_pattern, html, re.DOTALL)
        
        for match in post_matches:
            post_html = match.group(1)
            
            # Extract title
            title_match = re.search(r'data-testid="post-content"[^>]*>.*?<h3[^>]*>([^<]+)', post_html, re.DOTALL)
            title = title_match.group(1).strip() if title_match else ""
            
            # Extract URL
            url_match = re.search(r'href="(/r/[^"]+)"', post_html)
            url = f"https://www.reddit.com{url_match.group(1)}" if url_match else ""
            
            # Extract author
            author_match = re.search(r'data-testid="post_author_link"[^>]*>([^<]+)', post_html)
            author = author_match.group(1).strip() if author_match else ""
            
            # Extract score
            score_match = re.search(r'data-testid="post-vote-score"[^>]*>([^<]+)', post_html)
            score = score_match.group(1).strip() if score_match else ""
            
            if title:
                posts.append({
                    'title': title,
                    'url': url,
                    'author': author,
                    'score': score
                })
        
        return posts

    def subreddit(self, name, extract=True):
        """Fetch a subreddit page with JSON API - Reddit has a JSON API! No HTML parsing needed."""
        # First try Reddit JSON API (much simpler and more reliable)
        json_result = self._try_reddit_json_api(name)
        if json_result:
            return json_result
        
        # Fallback to HTML scraping
        self._rate_limit()
        url = f"https://www.reddit.com/r/{name}/"
        
        from ..fingerprint import chrome_fingerprint
        resp = self.client.fetch(url, country="US", headers=chrome_fingerprint("US"))
        
        result = {
            "subreddit": name,
            "url": url,
            "status": resp.status_code,
            "html": resp.text,
            "size_kb": len(resp.text) // 1024,
            "source": "html_fallback"
        }
        
        if extract and resp.status_code == 200:
            if self._validate_reddit_content(resp.text):
                result["posts"] = self._extract_posts(resp.text)
            else:
                result["posts"] = []
        
        return result

    def post(self, url, extract=True):
        """Fetch a Reddit post by URL with extraction."""
        self._rate_limit()
        resp = self.client.fetch(url, country="US")
        
        result = {
            "url": url,
            "status": resp.status_code,
            "html": resp.text,
            "size_kb": len(resp.text) // 1024
        }
        
        if extract and resp.status_code == 200:
            # Extract post details
            title_match = re.search(r'<h1[^>]*>([^<]+)</h1>', resp.text)
            result["title"] = title_match.group(1).strip() if title_match else ""
            
            author_match = re.search(r'data-testid="post_author_link"[^>]*>([^<]+)', resp.text)
            result["author"] = author_match.group(1).strip() if author_match else ""
            
            score_match = re.search(r'data-testid="post-vote-score"[^>]*>([^<]+)', resp.text)
            result["score"] = score_match.group(1).strip() if score_match else ""
        
        return result

    def search(self, query, country="US"):
        """Search Reddit."""
        self._rate_limit()
        import urllib.parse
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://www.reddit.com/search/?q={encoded_query}"
        
        resp = self.client.fetch(url, country=country)
        
        return {
            "query": query,
            "url": url,
            "status": resp.status_code,
            "html": resp.text
        }
