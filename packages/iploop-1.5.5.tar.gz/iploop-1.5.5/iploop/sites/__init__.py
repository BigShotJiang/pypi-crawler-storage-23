"""Site-specific presets for popular websites."""

from .twitter import Twitter
from .google import Google
from .amazon import Amazon
from .instagram import Instagram
from .tiktok import TikTok
from .youtube import YouTube
from .reddit import Reddit
from .ebay import eBay
from .nasdaq import Nasdaq
from .linkedin import LinkedIn
from .extractors import Extractors
from .trustpilot import Trustpilot
from .airbnb import Airbnb
from .remoteok import RemoteOK
from .cnn import CNN
from .aliexpress import AliExpress
from .shopify import Shopify

__all__ = [
    "Twitter", "Google", "Amazon", "Instagram", "TikTok",
    "YouTube", "Reddit", "eBay", "Nasdaq", "LinkedIn", "Extractors",
    "Trustpilot", "Airbnb", "RemoteOK", "CNN", "AliExpress", "Shopify",
]
