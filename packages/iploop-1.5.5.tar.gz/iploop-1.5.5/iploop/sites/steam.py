"""Steam site preset."""
import re


class Steam:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            m = re.search(r'/app/(\d+)', url)
            if not m:
                return {"success": False, "data": {}, "source": "steam-api", "error": "No app ID found in URL"}
            appid = m.group(1)
            resp = self.client.fetch(f"https://store.steampowered.com/api/appdetails?appids={appid}", timeout=10)
            info = resp.json().get(appid, {})
            if not info.get("success"):
                return {"success": False, "data": {}, "source": "steam-api", "error": "App not found"}
            d = info.get("data", {})
            price = d.get("price_overview", {})
            return {"success": True, "data": {
                "name": d.get("name"), "short_description": d.get("short_description", "")[:200],
                "price": price.get("final_formatted"), "release_date": d.get("release_date", {}).get("date"),
                "metacritic_score": (d.get("metacritic") or {}).get("score"),
            }, "source": "steam-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "steam-api", "error": str(e)}
