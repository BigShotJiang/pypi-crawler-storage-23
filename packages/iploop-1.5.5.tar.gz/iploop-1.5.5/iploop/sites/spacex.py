"""SpaceX site preset."""


class SpaceX:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            resp = self.client.fetch("https://api.spacexdata.com/v4/launches/latest", timeout=10)
            d = resp.json()
            return {"success": True, "data": {
                "name": d.get("name"), "date_utc": d.get("date_utc"),
                "success": d.get("success"), "rocket": d.get("rocket"),
                "details": d.get("details"),
            }, "source": "spacex-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "spacex-api", "error": str(e)}
