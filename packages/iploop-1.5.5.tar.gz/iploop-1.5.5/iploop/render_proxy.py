"""
Local HTTP CONNECT proxy that adds Proxy-Authorization header.
Playwright/Chromium doesn't support proxy auth on CONNECT natively.
"""

import asyncio
import socket
import base64
import logging
from typing import Optional, Tuple

logger = logging.getLogger("iploop.render_proxy")


class AuthProxy:
    """Local proxy that adds auth to CONNECT requests."""
    
    def __init__(self, api_key: str, upstream_host: str = "proxy.iploop.io", upstream_port: int = 8880):
        self.api_key = api_key
        self.upstream_host = upstream_host
        self.upstream_port = upstream_port
        self.server = None
        self.port = None
        self._request_count = 0
    
    async def start(self) -> int:
        """Start the proxy server on a random port. Returns the port number."""
        # Find a free port
        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        self.port = sock.getsockname()[1]
        sock.close()
        
        self.server = await asyncio.start_server(
            self._handle_client,
            '127.0.0.1',
            self.port
        )
        
        logger.debug(f"Auth proxy started on port {self.port}")
        return self.port
    
    async def stop(self):
        """Stop the proxy server."""
        if self.server:
            self.server.close()
            await self.server.wait_closed()
            logger.debug(f"Auth proxy stopped on port {self.port}")
    
    async def _handle_client(self, client_reader: asyncio.StreamReader, client_writer: asyncio.StreamWriter):
        """Handle a client connection."""
        self._request_count += 1
        request_id = self._request_count
        
        try:
            # Read the CONNECT request
            request_line = await client_reader.readline()
            if not request_line:
                return
                
            request_str = request_line.decode('utf-8', errors='ignore').strip()
            logger.debug(f"[{request_id}] {request_str}")
            
            if not request_str.startswith('CONNECT '):
                # Not a CONNECT request, reject
                client_writer.write(b'HTTP/1.1 400 Bad Request\r\n\r\n')
                await client_writer.drain()
                return
            
            # Extract the target from "CONNECT target HTTP/1.1"
            parts = request_str.split(' ')
            if len(parts) < 2:
                client_writer.write(b'HTTP/1.1 400 Bad Request\r\n\r\n')
                await client_writer.drain()
                return
            
            target = parts[1]
            
            # Read and discard the rest of the client headers
            while True:
                line = await client_reader.readline()
                if line == b'\r\n' or not line:
                    break
            
            # Connect to upstream proxy
            try:
                upstream_reader, upstream_writer = await asyncio.open_connection(
                    self.upstream_host, self.upstream_port
                )
            except Exception as e:
                logger.debug(f"[{request_id}] Upstream connection failed: {e}")
                client_writer.write(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
                await client_writer.drain()
                return
            
            # Send CONNECT with auth to upstream
            auth_string = base64.b64encode(f"user:{self.api_key}".encode()).decode()
            upstream_request = (
                f"CONNECT {target} HTTP/1.1\r\n"
                f"Host: {target}\r\n"
                f"Proxy-Authorization: Basic {auth_string}\r\n"
                f"\r\n"
            )
            
            upstream_writer.write(upstream_request.encode())
            await upstream_writer.drain()
            
            # Read upstream response
            response_buffer = b''
            while True:
                chunk = await upstream_reader.read(1024)
                if not chunk:
                    break
                response_buffer += chunk
                if b'\r\n\r\n' in response_buffer:
                    break
            
            response_str = response_buffer.decode('utf-8', errors='ignore')
            
            if '200' in response_str.split('\r\n')[0]:
                # Success - start tunneling
                client_writer.write(b'HTTP/1.1 200 Connection Established\r\n\r\n')
                await client_writer.drain()
                
                # Handle any extra data from upstream response
                header_end = response_buffer.find(b'\r\n\r\n') + 4
                if len(response_buffer) > header_end:
                    extra_data = response_buffer[header_end:]
                    client_writer.write(extra_data)
                    await client_writer.drain()
                
                # Start bidirectional tunneling
                await asyncio.gather(
                    self._tunnel_data(client_reader, upstream_writer, f"{request_id}-c2u"),
                    self._tunnel_data(upstream_reader, client_writer, f"{request_id}-u2c"),
                    return_exceptions=True
                )
            else:
                # Upstream rejected
                logger.debug(f"[{request_id}] Upstream rejected: {response_str.split('\\r\\n')[0]}")
                client_writer.write(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
                await client_writer.drain()
                
        except Exception as e:
            logger.debug(f"[{request_id}] Error: {e}")
        finally:
            client_writer.close()
            try:
                await client_writer.wait_closed()
            except:
                pass
    
    async def _tunnel_data(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, direction: str):
        """Tunnel data between client and upstream."""
        try:
            while True:
                data = await reader.read(8192)
                if not data:
                    break
                writer.write(data)
                await writer.drain()
        except Exception:
            pass
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except:
                pass


class ProxyManager:
    """Manages the lifecycle of auth proxies."""
    
    _instance = None
    _proxies = {}  # api_key -> AuthProxy
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    async def get_proxy_port(self, api_key: str) -> int:
        """Get or create a proxy for the given API key."""
        if api_key not in self._proxies:
            proxy = AuthProxy(api_key)
            port = await proxy.start()
            self._proxies[api_key] = proxy
            return port
        return self._proxies[api_key].port
    
    async def cleanup_proxy(self, api_key: str):
        """Stop and remove a proxy."""
        if api_key in self._proxies:
            await self._proxies[api_key].stop()
            del self._proxies[api_key]
    
    async def cleanup_all(self):
        """Stop all proxies."""
        for proxy in list(self._proxies.values()):
            await proxy.stop()
        self._proxies.clear()