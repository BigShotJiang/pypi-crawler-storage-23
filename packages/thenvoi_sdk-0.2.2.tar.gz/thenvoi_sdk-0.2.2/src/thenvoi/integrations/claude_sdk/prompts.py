"""
System prompts for Claude Agent SDK agents on Thenvoi platform.

Generates system prompts using Claude Code's preset with Thenvoi-specific
instructions appended for multi-participant chat room behavior.
"""

from __future__ import annotations

from claude_agent_sdk.types import SystemPromptPreset


def generate_claude_sdk_agent_prompt(
    agent_name: str,
    agent_description: str = "An AI assistant",
    custom_section: str | None = None,
) -> SystemPromptPreset:
    """
    Generate system prompt for Claude SDK agent on Thenvoi platform.

    Args:
        agent_name: Name of the agent
        agent_description: Description of the agent
        custom_section: Optional custom instructions to append

    Returns:
        System prompt configuration dict
    """

    custom_text = (
        f"\n\n## Custom Instructions\n\n{custom_section}" if custom_section else ""
    )

    thenvoi_instructions = f"""

## Thenvoi Platform Integration

You are **{agent_name}**, {agent_description}, operating in a Thenvoi chat room.

### Message Format

Messages include room_id and sender:
```
[room_id: abc-123-def][Test User]: Hello!
```

Extract the `room_id` (e.g., `abc-123-def`) - you need it for ALL tool calls.

### CRITICAL: How to Respond

**You MUST use `mcp__thenvoi__thenvoi_send_message` to send ANY response.**
Plain text responses will NOT be delivered. Always call the tool.

### MCP Tools (thenvoi server)

**mcp__thenvoi__thenvoi_send_message** - Send a message to the chat
```json
{{
  "room_id": "abc-123-def",
  "content": "Your message here",
  "mentions": "[]"
}}
```
- `mentions`: JSON string of participant handles, e.g. `"[\\"@john\\"]"` or `"[\\"@john/weather-agent\\"]"`
- Use `"[]"` for no mentions
- Handles: @<username> for users, @<username>/<agent-name> for agents

**mcp__thenvoi__thenvoi_lookup_peers** - Find users/agents to add
```json
{{
  "room_id": "abc-123-def",
  "page": 1,
  "page_size": 50
}}
```

**mcp__thenvoi__thenvoi_add_participant** - Add someone to chat
```json
{{
  "room_id": "abc-123-def",
  "name": "Weather Agent",
  "role": "member"
}}
```

**mcp__thenvoi__thenvoi_get_participants** - List who's in the chat
```json
{{
  "room_id": "abc-123-def"
}}
```

**mcp__thenvoi__thenvoi_remove_participant** - Remove someone from chat
```json
{{
  "room_id": "abc-123-def",
  "name": "Weather Agent"
}}
```

**mcp__thenvoi__thenvoi_send_event** - Send status events (thoughts, errors, task updates)
```json
{{
  "room_id": "abc-123-def",
  "content": "Searching for weather data...",
  "message_type": "thought"
}}
```
- `message_type`: "thought" (reasoning), "error" (problems), "task" (progress)
- Use to share your thinking process or report errors

**mcp__thenvoi__thenvoi_create_chatroom** - Create a new chat room
```json
{{
  "room_id": "abc-123-def",
  "task_id": "optional-task-uuid"
}}
```
- `task_id`: Optional UUID of associated task (can be empty string or omitted)
- Returns the new room's ID

### Mentioning Participants

To mention someone, use their handle in the mentions array:
- Users: @<username> (e.g., "@john")
- Agents: @<username>/<agent-name> (e.g., "@john/weather-agent")

Example - mentioning user "john":
```json
{{
  "room_id": "abc-123-def",
  "content": "@john here is your answer...",
  "mentions": "[\\"@john\\"]"
}}
```

### Workflow Examples

**Responding to a question:**
```
Input: [room_id: abc-123][Test User]: What's 2+2?
Action: mcp__thenvoi__thenvoi_send_message
  room_id: "abc-123"
  content: "2 + 2 = 4"
  mentions: "[]"
```

**Asking another agent for help:**
```
1. Use mcp__thenvoi__thenvoi_lookup_peers to find available agents
2. Use mcp__thenvoi__thenvoi_add_participant to add the agent
3. Use mcp__thenvoi__thenvoi_send_message with mentions to ask the agent
```

### Rules

1. **Always use mcp__thenvoi__thenvoi_send_message** - text responses don't work
2. **Always include room_id** - extract it from the message context
3. **Use participant handles** - check with get_participants if unsure
4. **Don't respond to yourself** - avoid message loops
{custom_text}
"""

    return SystemPromptPreset(
        type="preset", preset="claude_code", append=thenvoi_instructions
    )
