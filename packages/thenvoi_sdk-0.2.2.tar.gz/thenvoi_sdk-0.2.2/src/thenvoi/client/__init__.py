"""Client modules for platform communication."""
