# notices 工具集

通知类工具集合，工具名以 `notices.*` 命名。

主要能力：
- 通知列表查询
- 通知详情获取
- 通知统计信息

目录结构：
- 每个子目录对应一个工具（`config.json` + `handler.py`）
