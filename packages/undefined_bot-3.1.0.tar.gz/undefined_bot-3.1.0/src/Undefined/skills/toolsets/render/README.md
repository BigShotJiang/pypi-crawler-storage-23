# render 工具集

渲染相关工具集合，工具名以 `render.*` 命名。

主要能力：
- HTML 渲染
- Markdown 渲染
- LaTeX 渲染

目录结构：
- 每个子目录对应一个工具（`config.json` + `handler.py`）
