"""Prompt building utilities."""

from __future__ import annotations

import html
import logging
import re
from collections import deque
from datetime import datetime
from typing import Any, Callable, Awaitable, Literal

import aiofiles

from Undefined.context import RequestContext
from Undefined.end_summary_storage import (
    EndSummaryStorage,
    EndSummaryRecord,
    MAX_END_SUMMARIES,
)
from Undefined.memory import MemoryStorage
from Undefined.skills.anthropic_skills import AnthropicSkillRegistry
from Undefined.utils.logging import log_debug_json
from Undefined.utils.resources import read_text_resource
from Undefined.utils.xml import escape_xml_attr, escape_xml_text

logger = logging.getLogger(__name__)

_CURRENT_MESSAGE_RE = re.compile(
    r"<message\b(?P<attrs>[^>]*)>\s*<content>(?P<content>.*?)</content>\s*</message>",
    re.DOTALL | re.IGNORECASE,
)
_XML_ATTR_RE = re.compile(r'(?P<key>[a-zA-Z_][a-zA-Z0-9_-]*)="(?P<value>[^"]*)"')
_COGNITIVE_QUERY_SHORT_THRESHOLD = 20
_COGNITIVE_CONTEXT_VALUE_MAX_LEN = 18


class PromptBuilder:
    """Construct system/user messages with memory, history, and time."""

    def __init__(
        self,
        bot_qq: int,
        memory_storage: MemoryStorage | None,
        end_summary_storage: EndSummaryStorage,
        system_prompt_path: str = "res/prompts/undefined.xml",
        runtime_config_getter: Callable[[], Any] | None = None,
        anthropic_skill_registry: AnthropicSkillRegistry | None = None,
        cognitive_service: Any = None,
    ) -> None:
        """初始化 Prompt 构建器

        参数:
            bot_qq: 机器人 QQ 号
            memory_storage: 长期记忆存储 (可选)
            end_summary_storage: 短期回忆存储
            system_prompt_path: 系统提示词文件路径
            anthropic_skill_registry: Anthropic Skills 注册中心（可选）
        """
        self._bot_qq = bot_qq
        self._memory_storage = memory_storage
        self._end_summary_storage = end_summary_storage
        self._system_prompt_path = system_prompt_path
        self._runtime_config_getter = runtime_config_getter
        self._anthropic_skill_registry = anthropic_skill_registry
        self._cognitive_service = cognitive_service
        self._end_summaries: deque[EndSummaryRecord] = deque(maxlen=MAX_END_SUMMARIES)
        self._summaries_loaded = False

    def set_cognitive_service(self, service: Any = None) -> None:
        """更新认知记忆服务引用（支持运行时注入/替换）。"""
        self._cognitive_service = service
        logger.info(
            "[Prompt] 认知服务引用已更新: enabled=%s",
            bool(getattr(service, "enabled", False)) if service is not None else False,
        )

    @property
    def end_summaries(self) -> deque[EndSummaryRecord]:
        """暴露短期摘要缓存，供工具执行上下文共享。"""
        return self._end_summaries

    def _select_system_prompt_path(self) -> str:
        """根据运行时配置选择系统提示词路径。

        - 关闭 nagaagent_mode_enabled: 使用默认 public prompt
        - 开启 nagaagent_mode_enabled: 使用 NagaAgent prompt

        说明：路径在每次构建 messages 时动态选择，以支持配置热更新。
        """

        if self._runtime_config_getter is None:
            return self._system_prompt_path

        runtime_config = None
        try:
            runtime_config = self._runtime_config_getter()
        except Exception:
            runtime_config = None

        enabled = bool(getattr(runtime_config, "nagaagent_mode_enabled", False))
        if enabled:
            return "res/prompts/undefined_nagaagent.xml"
        return "res/prompts/undefined.xml"

    async def _ensure_summaries_loaded(self) -> None:
        if not self._summaries_loaded:
            loaded_summaries = await self._end_summary_storage.load()
            self._end_summaries.extend(loaded_summaries)
            self._summaries_loaded = True
            logger.debug(f"[AI初始化] 已加载 {len(loaded_summaries)} 条 End 摘要")

    async def _load_each_rules(self) -> str:
        path = "res/IMPORTANT/each.md"
        try:
            return read_text_resource(path)
        except Exception:
            pass
        try:
            async with aiofiles.open(path, "r", encoding="utf-8") as f:
                return await f.read()
        except Exception:
            return ""

    async def _load_system_prompt(self) -> str:
        system_prompt_path = self._select_system_prompt_path()
        try:
            return read_text_resource(system_prompt_path)
        except Exception as exc:
            logger.debug("读取系统提示词失败，尝试本地路径: %s", exc)
        async with aiofiles.open(system_prompt_path, "r", encoding="utf-8") as f:
            return await f.read()

    async def build_messages(
        self,
        question: str,
        get_recent_messages_callback: Callable[
            [str, str, int, int], Awaitable[list[dict[str, Any]]]
        ]
        | None = None,
        extra_context: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """构建发送给 AI 的消息列表

        参数:
            question: 当前用户消息
            get_recent_messages_callback: 获取历史消息的回调函数
            extra_context: 额外的上下文信息 (如 group_id, user_id)

        返回:
            构建好的消息列表 (role/content 结构)
        """
        system_prompt = await self._load_system_prompt()
        logger.debug(
            "[Prompt] system_prompt_len=%s path=%s",
            len(system_prompt),
            self._select_system_prompt_path(),
        )

        if self._bot_qq != 0:
            bot_qq_info = (
                f"<!-- 机器人QQ号: {self._bot_qq} -->\n"
                f"<!-- 你现在知道自己的QQ号是 {self._bot_qq}，请记住这个信息用于防止无限循环 -->\n\n"
            )
            system_prompt = bot_qq_info + system_prompt

        messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]

        # 注入群聊关键词自动回复机制说明，避免模型误判历史中的系统彩蛋消息。
        is_group_context = False
        ctx = RequestContext.current()
        if ctx and ctx.group_id is not None:
            is_group_context = True
        elif extra_context and extra_context.get("group_id") is not None:
            is_group_context = True

        keyword_reply_enabled = False
        if self._runtime_config_getter is not None:
            try:
                runtime_config = self._runtime_config_getter()
                keyword_reply_enabled = bool(
                    getattr(runtime_config, "keyword_reply_enabled", False)
                )
            except Exception as exc:
                logger.debug("读取关键词自动回复配置失败: %s", exc)

        if is_group_context and keyword_reply_enabled:
            messages.append(
                {
                    "role": "system",
                    "content": (
                        "【系统行为说明】\n"
                        '当前群聊已开启关键词自动回复彩蛋（例如触发词"心理委员"）。'
                        "命中时，系统可能直接发送固定回复，并在历史中写入"
                        '以"[系统关键词自动回复] "开头的消息。\n\n'
                        "这类消息属于系统预设机制，不代表你在该轮主动决策。"
                        "阅读历史时请识别该前缀，避免误判为人格漂移或上下文异常。"
                        "除非用户主动询问，否则不要主动解释此机制。"
                    ),
                }
            )

        # 注入 Anthropic Skills 元数据（Level 1: 始终加载 name + description）
        if (
            self._anthropic_skill_registry
            and self._anthropic_skill_registry.has_skills()
        ):
            skills_xml = self._anthropic_skill_registry.build_metadata_xml()
            if skills_xml:
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "【可用的 Anthropic Skills】\n"
                            f"{skills_xml}\n\n"
                            "注意：以上是可用的 Anthropic Agent Skills 列表。"
                            "当用户的请求与某个 skill 相关时，"
                            "你可以调用对应的 skill tool（tool_name 字段）"
                            "来获取该领域的详细指令和知识。"
                        ),
                    }
                )
                logger.debug(
                    "[Prompt] 已注入 %d 个 Anthropic Skills 元数据",
                    len(self._anthropic_skill_registry.get_all_skills()),
                )

        if self._memory_storage:
            memories = self._memory_storage.get_all()
            if memories:
                memory_lines = [f"- {mem.fact}" for mem in memories]
                memory_text = "\n".join(memory_lines)
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "【memory.* 手动长期记忆（可编辑）】\n"
                            f"{memory_text}\n\n"
                            "注意：以上是你通过 memory.add 等工具主动维护的长期事实清单。"
                            "它与认知记忆（cognitive.* / end.observations 产生的事件与侧写）是两套机制。"
                            "请根据任务选择合适的记忆工具，避免混用。"
                        ),
                    }
                )
                logger.info(f"[AI会话] 已注入 {len(memories)} 条长期记忆")
                if logger.isEnabledFor(logging.DEBUG):
                    log_debug_json(
                        logger, "[AI会话] 注入长期记忆", [mem.fact for mem in memories]
                    )

        await self._ensure_summaries_loaded()
        if self._cognitive_service and getattr(
            self._cognitive_service, "enabled", False
        ):
            recent_action_inject_k = 30
            if self._runtime_config_getter is not None:
                try:
                    runtime_config = self._runtime_config_getter()
                    cog_cfg = getattr(runtime_config, "cognitive", None)
                    if cog_cfg is not None and hasattr(
                        cog_cfg, "recent_end_summaries_inject_k"
                    ):
                        recent_action_inject_k = int(
                            getattr(cog_cfg, "recent_end_summaries_inject_k")
                        )
                except Exception:
                    pass
            if recent_action_inject_k < 0:
                recent_action_inject_k = 0

            ctx = RequestContext.current()
            resolved_group_id = (
                str(ctx.group_id)
                if ctx and ctx.group_id is not None
                else (str(extra_context.get("group_id", "")) if extra_context else None)
            )
            resolved_user_id = (
                str(ctx.user_id)
                if ctx and ctx.user_id is not None
                else (str(extra_context.get("user_id", "")) if extra_context else None)
            )
            resolved_sender_id = (
                str(ctx.sender_id)
                if ctx and ctx.sender_id is not None
                else (
                    str(extra_context.get("sender_id", "")) if extra_context else None
                )
            )
            cognitive_query, query_enhanced = self._build_cognitive_query(
                question, extra_context
            )
            logger.info(
                "[AI会话] 开始自动检索认知记忆: raw_query_len=%s effective_query_len=%s query_enhanced=%s group=%s user=%s sender=%s",
                len(question),
                len(cognitive_query),
                query_enhanced,
                resolved_group_id or "",
                resolved_user_id or "",
                resolved_sender_id or "",
            )
            cognitive_context = await self._cognitive_service.build_context(
                query=cognitive_query,
                group_id=resolved_group_id,
                user_id=resolved_user_id,
                sender_id=resolved_sender_id,
                sender_name=str(extra_context.get("sender_name", ""))
                if extra_context
                else None,
                group_name=str(extra_context.get("group_name", ""))
                if extra_context
                else None,
            )
            if cognitive_context:
                messages.append({"role": "system", "content": cognitive_context})
                logger.info(
                    "[AI会话] 已注入认知记忆上下文: context_len=%s",
                    len(cognitive_context),
                )
            else:
                logger.info("[AI会话] 自动检索完成：未命中可注入认知记忆")

            # 额外注入最近 end 行动记录，作为短期“工作记忆”，弥补史官异步入库延迟与向量检索的漏召回。
            if recent_action_inject_k > 0 and self._end_summaries:
                items = list(self._end_summaries)[-recent_action_inject_k:]
                recent_summary_lines: list[str] = []
                for item in items:
                    location_text = ""
                    location = item.get("location")
                    if isinstance(location, dict):
                        location_type = location.get("type")
                        location_name = location.get("name")
                        if (
                            location_type in {"private", "group"}
                            and isinstance(location_name, str)
                            and location_name.strip()
                        ):
                            location_text = (
                                f" ({location_type}: {location_name.strip()})"
                            )
                    recent_summary_lines.append(
                        f"- [{item.get('timestamp', '')}] {item.get('summary', '')}{location_text}"
                    )
                recent_summary_text = "\n".join(recent_summary_lines).strip()
                if recent_summary_text:
                    messages.append(
                        {
                            "role": "system",
                            "content": (
                                f"【短期行动记录（最近 {len(items)} 条，带时间）】\n"
                                f"{recent_summary_text}\n\n"
                                "注意：以上是你最近在 end 时记录的行动摘要，用于保持短期连续性。"
                                "它可能与认知记忆事件存在重复；优先以更具体、更近期的描述为准。"
                            ),
                        }
                    )
        elif self._end_summaries:
            summary_lines: list[str] = []
            for item in self._end_summaries:
                location_text = ""
                location = item.get("location")
                if isinstance(location, dict):
                    location_type = location.get("type")
                    location_name = location.get("name")
                    if (
                        location_type in {"private", "group"}
                        and isinstance(location_name, str)
                        and location_name.strip()
                    ):
                        location_text = f" ({location_type}: {location_name.strip()})"
                summary_lines.append(
                    f"- [{item['timestamp']}] {item['summary']}{location_text}"
                )
            summary_text = "\n".join(summary_lines)
            messages.append(
                {
                    "role": "system",
                    "content": (
                        "【这是你之前end时记录的事情】\n"
                        f"{summary_text}\n\n"
                        "注意：以上是你之前在end时记录的事情，用于帮助你记住之前做了什么或以后可能要做什么。"
                    ),
                }
            )
            logger.info(
                f"[AI会话] 已注入 {len(self._end_summaries)} 条短期回忆 (end 摘要)"
            )
            if logger.isEnabledFor(logging.DEBUG):
                log_debug_json(
                    logger, "[AI会话] 注入短期回忆", list(self._end_summaries)
                )

        if get_recent_messages_callback:
            await self._inject_recent_messages(
                messages, get_recent_messages_callback, extra_context, question
            )

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        messages.append(
            {
                "role": "system",
                "content": f"【当前时间】\n{current_time}\n\n注意：以上是当前的系统时间，供你参考。",
            }
        )

        each_rules = await self._load_each_rules()
        if each_rules:
            messages.append(
                {
                    "role": "system",
                    "content": f"【强制规则 - 必须在进行任何操作前仔细阅读并严格遵守】\n{each_rules}",
                }
            )

        messages.append({"role": "user", "content": f"【当前消息】\n{question}"})
        logger.debug(
            "[Prompt] messages_ready=%s question_len=%s",
            len(messages),
            len(question),
        )
        return messages

    def _resolve_chat_scope(
        self, extra_context: dict[str, Any] | None
    ) -> tuple[Literal["group", "private"], int] | None:
        ctx = RequestContext.current()

        def _safe_int(value: Any) -> int | None:
            if isinstance(value, bool):
                return None
            if isinstance(value, int):
                return value
            if isinstance(value, str):
                text = value.strip()
                if not text:
                    return None
                try:
                    return int(text)
                except ValueError:
                    return None
            return None

        if ctx and ctx.request_type == "group" and ctx.group_id is not None:
            group_id = _safe_int(ctx.group_id)
            if group_id is not None:
                return ("group", group_id)
            return None
        if ctx and ctx.request_type == "private" and ctx.user_id is not None:
            user_id = _safe_int(ctx.user_id)
            if user_id is not None:
                return ("private", user_id)
            return None

        if extra_context and extra_context.get("group_id") is not None:
            group_id = _safe_int(extra_context.get("group_id"))
            if group_id is not None:
                return ("group", group_id)
            return None
        if extra_context and extra_context.get("user_id") is not None:
            user_id = _safe_int(extra_context.get("user_id"))
            if user_id is not None:
                return ("private", user_id)
            return None

        return None

    async def _inject_recent_messages(
        self,
        messages: list[dict[str, Any]],
        get_recent_messages_callback: Callable[
            [str, str, int, int], Awaitable[list[dict[str, Any]]]
        ],
        extra_context: dict[str, Any] | None,
        question: str,
    ) -> None:
        try:
            ctx = RequestContext.current()
            if ctx:
                group_id_from_ctx = ctx.group_id
                user_id_from_ctx = ctx.user_id
            elif extra_context:
                group_id_from_ctx = extra_context.get("group_id")
                user_id_from_ctx = extra_context.get("user_id")
            else:
                group_id_from_ctx = None
                user_id_from_ctx = None

            if group_id_from_ctx is not None:
                chat_id = str(group_id_from_ctx)
                msg_type = "group"
            elif user_id_from_ctx is not None:
                chat_id = str(user_id_from_ctx)
                msg_type = "private"
            else:
                chat_id = ""
                msg_type = "group"

            recent_limit = 20
            if self._runtime_config_getter is not None:
                try:
                    runtime_config = self._runtime_config_getter()
                    if hasattr(runtime_config, "get_context_recent_messages_limit"):
                        recent_limit = int(
                            runtime_config.get_context_recent_messages_limit()
                        )
                except Exception as exc:
                    logger.debug("读取上下文历史条数配置失败: %s", exc)

            if recent_limit < 0:
                recent_limit = 0
            if recent_limit > 200:
                recent_limit = 200
            if recent_limit == 0:
                logger.debug("上下文历史消息注入已关闭 (limit=0)")
                return

            recent_msgs = await get_recent_messages_callback(
                chat_id,
                msg_type,
                0,
                recent_limit,
            )
            recent_msgs = self._drop_current_message_if_duplicated(
                recent_msgs, question
            )
            context_lines: list[str] = []
            for msg in recent_msgs:
                msg_type_val = msg.get("type", "group")
                sender_name = msg.get("display_name", "未知用户")
                sender_id = msg.get("user_id", "")
                chat_id = msg.get("chat_id", "")
                chat_name = msg.get("chat_name", "未知群聊")
                timestamp = msg.get("timestamp", "")
                text = msg.get("message", "")
                role = msg.get("role", "member")
                title = msg.get("title", "")

                safe_sender = escape_xml_attr(sender_name)
                safe_sender_id = escape_xml_attr(sender_id)
                safe_chat_id = escape_xml_attr(chat_id)
                safe_chat_name = escape_xml_attr(chat_name)
                safe_role = escape_xml_attr(role)
                safe_title = escape_xml_attr(title)
                safe_time = escape_xml_attr(timestamp)
                safe_text = escape_xml_text(str(text))

                if msg_type_val == "group":
                    location = (
                        chat_name if chat_name.endswith("群") else f"{chat_name}群"
                    )
                    safe_location = escape_xml_attr(location)
                    xml_msg = (
                        f'<message sender="{safe_sender}" sender_id="{safe_sender_id}" group_id="{safe_chat_id}" '
                        f'group_name="{safe_chat_name}" location="{safe_location}" role="{safe_role}" title="{safe_title}" '
                        f'time="{safe_time}">\n<content>{safe_text}</content>\n</message>'
                    )
                else:
                    location = "私聊"
                    safe_location = escape_xml_attr(location)
                    xml_msg = (
                        f'<message sender="{safe_sender}" sender_id="{safe_sender_id}" location="{safe_location}" '
                        f'time="{safe_time}">\n<content>{safe_text}</content>\n</message>'
                    )
                context_lines.append(xml_msg)

            formatted_context = "\n---\n".join(context_lines)

            if formatted_context:
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "【历史消息存档】\n"
                            f"{formatted_context}\n\n"
                            "注意：以上是之前的聊天记录，用于提供背景信息。每个消息之间使用 --- 分隔。接下来的用户消息才是当前正在发生的对话。"
                        ),
                    }
                )
            logger.debug(f"自动预获取了 {len(context_lines)} 条历史消息作为上下文")
            if logger.isEnabledFor(logging.DEBUG):
                log_debug_json(
                    logger,
                    "[Prompt] 历史消息上下文",
                    context_lines,
                )
        except Exception as exc:
            logger.warning(f"自动获取历史消息失败: {exc}")

    @staticmethod
    def _normalize_cognitive_context_value(value: Any) -> str:
        text = " ".join(str(value or "").split()).strip()
        if len(text) <= _COGNITIVE_CONTEXT_VALUE_MAX_LEN:
            return text
        return text[: _COGNITIVE_CONTEXT_VALUE_MAX_LEN - 3].rstrip() + "..."

    def _build_cognitive_query(
        self, question: str, extra_context: dict[str, Any] | None = None
    ) -> tuple[str, bool]:
        question_text = str(question or "").strip()
        signature = self._extract_current_message_signature(question_text)
        current_content = str(signature.get("content", "")).strip()
        base_query = current_content or question_text
        if not base_query:
            return "", False

        # 优先使用当前帧原始消息内容；仅在短消息时追加少量会话语境，降低“这/那个”类指代丢失。
        if (
            not current_content
            or len(current_content) > _COGNITIVE_QUERY_SHORT_THRESHOLD
        ):
            return base_query, False

        context_parts: list[str] = []
        if extra_context:
            if bool(extra_context.get("is_private_chat", False)):
                context_parts.append("会话:私聊")
            elif str(extra_context.get("group_id", "")).strip():
                context_parts.append("会话:群聊")
            if bool(extra_context.get("is_at_bot", False)):
                context_parts.append("触发:@机器人")

            sender_name = self._normalize_cognitive_context_value(
                extra_context.get("sender_name", "")
            )
            if sender_name:
                context_parts.append(f"发送者:{sender_name}")

            group_name = self._normalize_cognitive_context_value(
                extra_context.get("group_name", "")
            )
            if group_name:
                context_parts.append(f"群:{group_name}")

        if not context_parts:
            return base_query, False
        return f"{base_query}\n语境: {'; '.join(context_parts)}", True

    def _extract_current_message_signature(self, question: str) -> dict[str, str]:
        matched = _CURRENT_MESSAGE_RE.search(str(question or ""))
        if not matched:
            return {}

        attrs_text = str(matched.group("attrs") or "")
        attrs: dict[str, str] = {}
        for attr_match in _XML_ATTR_RE.finditer(attrs_text):
            key = str(attr_match.group("key") or "").strip()
            if not key:
                continue
            attrs[key] = html.unescape(str(attr_match.group("value") or "")).strip()

        content = html.unescape(str(matched.group("content") or "")).strip()
        return {
            "sender_id": attrs.get("sender_id", ""),
            "timestamp": attrs.get("time", ""),
            "content": content,
        }

    def _drop_current_message_if_duplicated(
        self, recent_msgs: list[dict[str, Any]], question: str
    ) -> list[dict[str, Any]]:
        if not recent_msgs:
            return recent_msgs

        signature = self._extract_current_message_signature(question)
        if not signature:
            return recent_msgs

        last_msg = recent_msgs[-1]
        last_sender_id = str(last_msg.get("user_id", "")).strip()
        last_timestamp = str(last_msg.get("timestamp", "")).strip()
        last_content = str(last_msg.get("message", "")).strip()

        sig_sender_id = str(signature.get("sender_id", "")).strip()
        sig_timestamp = str(signature.get("timestamp", "")).strip()
        sig_content = str(signature.get("content", "")).strip()
        if not sig_sender_id or not sig_content:
            return recent_msgs

        if last_sender_id != sig_sender_id:
            return recent_msgs
        if last_content != sig_content:
            return recent_msgs

        if sig_timestamp and last_timestamp and sig_timestamp != last_timestamp:
            # history 写入时间与事件时间可能存在秒级偏差；若分钟都不同则判定不是同一帧。
            if sig_timestamp[:16] != last_timestamp[:16]:
                return recent_msgs

        logger.info(
            "[Prompt] 历史注入剔除当前帧: sender=%s sig_time=%s history_time=%s content_preview=%s",
            sig_sender_id,
            sig_timestamp,
            last_timestamp,
            sig_content[:60],
        )
        return recent_msgs[:-1]
