"""允许 python -m Undefined 运行"""

from Undefined.main import run

if __name__ == "__main__":
    run()
