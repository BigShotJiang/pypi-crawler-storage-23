"""Version information for inkpass-sdk."""

__version__ = "0.1.2"
