"""Tests for model metadata normalization in fetcher."""

from whichllm.models.fetcher import (
    _extract_hf_eval_score,
    _extract_published_at,
    _normalize_param_count,
    _parse_model,
    dicts_to_models,
    models_to_dicts,
)
from whichllm.models.types import ModelInfo


def test_normalize_param_count_for_quantized_repo_uses_size_hint():
    corrected = _normalize_param_count(
        extracted=5_233_828_308,
        model_id="ISTA-DASLab/gemma-3-27b-it-GPTQ-4b-128g",
        base_model="google/gemma-3-27b-it",
    )
    assert corrected == 27_000_000_000


def test_normalize_param_count_keeps_reasonable_value():
    kept = _normalize_param_count(
        extracted=11_765_788_416,
        model_id="MaziyarPanahi/gemma-3-12b-it-GGUF",
        base_model="google/gemma-3-12b-it",
    )
    assert kept == 11_765_788_416


def test_normalize_param_count_with_no_hint_keeps_original():
    kept = _normalize_param_count(
        extracted=3_820_000_000,
        model_id="microsoft/Phi-3-mini-4k-instruct-gguf",
        base_model=None,
    )
    assert kept == 3_820_000_000


def test_dicts_to_models_normalizes_cached_parameter_count():
    models = dicts_to_models(
        [
            {
                "id": "ISTA-DASLab/gemma-3-27b-it-GPTQ-4b-128g",
                "family_id": "gemma-3-27b",
                "name": "gemma-3-27b-it-GPTQ-4b-128g",
                "parameter_count": 5_233_828_308,
                "downloads": 1,
                "likes": 1,
                "gguf_variants": [],
                "benchmark_scores": {},
                "base_model": "google/gemma-3-27b-it",
            }
        ]
    )
    assert len(models) == 1
    assert models[0].parameter_count == 27_000_000_000


def test_models_cache_roundtrip_keeps_published_at():
    models = [
        ModelInfo(
            id="Qwen/Qwen3-8B-AWQ",
            family_id="qwen3-8b",
            name="Qwen3-8B-AWQ",
            parameter_count=8_000_000_000,
            published_at="2025-09-17T12:34:56.000Z",
            downloads=123_456,
            likes=789,
        )
    ]
    cached = models_to_dicts(models)
    restored = dicts_to_models(cached)
    assert len(restored) == 1
    assert restored[0].published_at == "2025-09-17T12:34:56.000Z"
    assert restored[0].downloads == 123_456


def test_extract_published_at_prefers_created_at():
    value = _extract_published_at(
        {
            "createdAt": "2025-01-01T00:00:00.000Z",
            "lastModified": "2026-01-01T00:00:00.000Z",
        }
    )
    assert value == "2025-01-01T00:00:00.000Z"


def test_extract_published_at_falls_back_to_last_modified():
    value = _extract_published_at(
        {
            "lastModified": "2026-01-01T00:00:00.000Z",
        }
    )
    assert value == "2026-01-01T00:00:00.000Z"


def test_parse_model_keeps_split_gguf_as_single_variant():
    parsed = _parse_model(
        {
            "id": "org/Test-8B-GGUF",
            "config": {
                "architectures": ["LlamaForCausalLM"],
            },
            "safetensors": {"total": 8_000_000_000},
            "siblings": [
                {"rfilename": "model-Q4_K_M-00001-of-00002.gguf", "size": 2_000_000_000},
                {"rfilename": "model-Q4_K_M-00002-of-00002.gguf", "size": 2_500_000_000},
                {"rfilename": "model-Q8_0.gguf", "size": 8_000_000_000},
            ],
            "cardData": {},
        }
    )
    assert parsed is not None
    q4 = [v for v in parsed.gguf_variants if v.quant_type == "Q4_K_M"]
    q8 = [v for v in parsed.gguf_variants if v.quant_type == "Q8_0"]
    assert len(q4) == 1
    assert len(q8) == 1
    assert q4[0].file_size_bytes == 4_500_000_000


def test_extract_hf_eval_score_uses_general_datasets_and_median():
    score = _extract_hf_eval_score(
        {
            "evalResults": [
                {
                    "filename": ".eval_results/mmlu-pro.yaml",
                    "data": {"dataset": {"id": "TIGER-Lab/MMLU-Pro"}, "value": 48.3},
                },
                {
                    "filename": ".eval_results/gsm8k.yaml",
                    "data": {"dataset": {"id": "openai/gsm8k"}, "value": 84.5},
                },
                {
                    "filename": ".eval_results/hle_medium_with_tools.yaml",
                    "data": {
                        "dataset": {"id": "cais/hle"},
                        "value": 99.0,
                        "notes": "Reasoning: medium, With tools",
                    },
                },
                {
                    "filename": ".eval_results/swe_bench.yaml",
                    "data": {"dataset": {"id": "SWE-bench/SWE-bench_Verified"}, "value": 53.2},
                },
            ]
        }
    )
    # general対象(mmlu/gsm8k)のみ集計し、中央値を使う。
    assert score == 66.4


def test_parse_model_extracts_hf_eval_benchmark_score():
    parsed = _parse_model(
        {
            "id": "meta-llama/Llama-3.1-8B-Instruct",
            "config": {"architectures": ["LlamaForCausalLM"]},
            "safetensors": {"total": 8_000_000_000},
            "siblings": [],
            "cardData": {},
            "evalResults": [
                {
                    "filename": ".eval_results/mmlu-pro.yaml",
                    "data": {"dataset": {"id": "TIGER-Lab/MMLU-Pro"}, "value": 48.3},
                },
                {
                    "filename": ".eval_results/gsm8k.yaml",
                    "data": {"dataset": {"id": "openai/gsm8k"}, "value": 84.5},
                },
            ],
        }
    )
    assert parsed is not None
    assert parsed.benchmark_scores.get("hf_eval") == 66.4
