"""atlas.recon.external — External reconnaissance (OSINT, public data)."""
