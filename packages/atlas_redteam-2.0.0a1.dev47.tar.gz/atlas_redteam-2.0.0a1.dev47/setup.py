# Shim for editable installs — all config is in pyproject.toml
from setuptools import setup
setup()
