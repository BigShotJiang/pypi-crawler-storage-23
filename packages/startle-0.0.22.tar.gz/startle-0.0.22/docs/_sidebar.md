
* [Home](/ "Startle")
* [CLI from functions](function-interface "Startle • CLI from functions")
* [CLI from classes](class-interface "Startle • CLI from classes")
* [Argument specification](arg-spec "Startle • Argument specification")
* [Types and parsing rules](types "Startle • Types and parsing rules")
* [Design](design "Startle • Design")


__API__

* [Functions](/api/functions "Startle • Functions")