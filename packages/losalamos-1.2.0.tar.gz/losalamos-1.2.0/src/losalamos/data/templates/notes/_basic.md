---
note_type: basic
timestamp: <% tp.file.creation_date("YYYY-MM-DD HH:mm:ss") %>
tags:
  - basic-note
aliases:
subject:
url:
name: <% tp.file.title %>
abstract:
---
# <% tp.file.title %>

BASIC NOTE

> [!Abstract] Summary
> {a paragraph description of the note}

---

> [!example]+ Related 
> - {related links}

# Main

*Insert main content here*

---
# Resources

> [!info] Other references
> - {related references}