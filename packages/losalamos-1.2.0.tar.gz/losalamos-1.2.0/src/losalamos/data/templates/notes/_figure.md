---
note_type: figure
timestamp: <% tp.file.creation_date("YYYY-MM-DD HH:mm:ss") %>
tags:
  - figure
  - losalamos
aliases:
  - Figure Note
  - Note for Figures
subject: "[[Scientific Illustration]]"
url:
abstract:
name: <% tp.file.title %>
label:
comment:
project:
document:
collection: main
size:
category: schematics 3d
subcategory:
complexity:
order: 1
panels: 1
title:
subtitle:
caption:
alttext:
source:
tier: T1
file:
file_draft:
status: on going
status_data:
date_start:
date_end:
---
# <% tp.file.title %>

FIGURE

![[<% tp.file.title %>.jpeg|500]]

**`=this.label`**

`=this.category`  |   `=this.status`   

> [!Abstract] Summary
> {a paragraph description of the note}

---

> [!example]+ Related 
> - {related links}

---
# Draft

![[{file_draft}|500]]


---
# Team


---
# Tasks


---
# Panels


---
# Resources


---
# Credits


---
# Other resources

Write here useful links and other notes

