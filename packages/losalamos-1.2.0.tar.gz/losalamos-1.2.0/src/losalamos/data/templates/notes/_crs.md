---
note_type: crs
timestamp: <% tp.file.creation_date("YYYY-MM-DD HH:mm:ss") %>
tags:
  - crs-note
aliases:
subject:
name: <% tp.file.title %>
title:
abstract:
category:
authority:
code: 
status:
extent:
bbox: 
base_crs:
datum:
epoch:
units:
source:
url:
---
# <% tp.file.title %>

CRS

> [!Abstract] Summary
> {a paragraph description of the note}

---

> [!example]+ Related 
> - {related links}

# Description

*Insert main content here*

---

# Area of use

![[<% tp.file.title %>_bbox.jpeg|500]]

---

# WKT2
```wkt
<full WKT2 here>
```

---

# PROJJSON
```json
<projjson here>
```

---

# PROJ string
```
+proj=longlat +datum=WGS84 +no_defs
```

---
# Resources

> [!info] Other references
> - {related references}