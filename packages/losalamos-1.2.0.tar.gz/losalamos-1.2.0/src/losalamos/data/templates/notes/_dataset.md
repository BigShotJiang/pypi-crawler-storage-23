---
note_type: dataset
timestamp: <% tp.file.creation_date("YYYY-MM-DD HH:mm:ss") %>
tags:
  - dataset-note
aliases:
subject:
category:
name:  <% tp.file.title %>
source:
alias:
version:
cite_inline:
cite_bibli:
entry_type: dataset
doi:
url:
author:
title:
year:
note:
organization:
abstract:
license:
download:
access:
datetime:
frequency:
structure:
resolution_xy:
resolution_t:
extent_xy:
extent_t:
bbox:
---
# <% tp.file.title %>

DATASET

![[<% tp.file.title %>.jpeg|200]]

**`=this.title`**

By `=this.cite_inline`

- URL: `=this.url`

> [!Info] Abstract
> {a paragraph description of the note}

---

# Overview

> [!Abstract]+ Highlights
> - List highlights

> [!Example]+ Related
> - List related notes

---
# Description

*Start typing here*

---
# Specifications

*Start typing here*

---
# Downloading

*Start typing here*

---
# Loading

*Start typing here*

---
# References

*Start typing here*

---
# Resources

*Start typing here*

---
# Bibliographic information

## In-line citation
```
{cite_inline}
```

## Full citation
```
{cite_bibli}
```

## BibTeX entry
```
{bibtex}
```