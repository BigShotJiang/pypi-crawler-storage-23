.. _home:

.. include:: ./includes/warning_development.rst

Los Alamos
############################################

Welcome to ``losalamos`` documentation! A comprehensive Python toolkit for productivity and research.

Contents
********************************************

.. list all pages it must contain in the home page [CHANGE THIS]:

.. toctree::
   :maxdepth: 1

   Home <self>
   about
   usage
   api
   development
