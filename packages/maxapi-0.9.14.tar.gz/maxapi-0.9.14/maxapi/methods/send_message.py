import asyncio
from typing import TYPE_CHECKING, Any, cast

from ..connection.base import BaseConnection
from ..enums.api_path import ApiPath
from ..enums.http_method import HTTPMethod
from ..enums.parse_mode import ParseMode
from ..exceptions.max import MaxApiError
from ..loggers import logger_bot
from ..types.attachments import Attachments
from ..types.attachments.attachment import Attachment
from ..types.attachments.upload import AttachmentUpload
from ..types.input_media import InputMedia, InputMediaBuffer
from ..types.message import NewMessageLink
from ..utils.message import process_input_media
from .types.sended_message import SendedMessage

if TYPE_CHECKING:
    from ..bot import Bot


class SendMessage(BaseConnection):
    """
    Класс для отправки сообщения в чат или пользователю с поддержкой
    вложений и форматирования.

    https://dev.max.ru/docs-api/methods/POST/messages

    Attributes:
        bot (Bot): Экземпляр бота для выполнения запроса.
        chat_id (Optional[int]): Идентификатор чата, куда отправлять
            сообщение.
        user_id (Optional[int]): Идентификатор пользователя, если нужно
            отправить личное сообщение.
        text (Optional[str]): Текст сообщения.
        attachments (Optional[List[Attachment | InputMedia |
            InputMediaBuffer]]): Список вложений к сообщению.
        link (Optional[NewMessageLink]): Связь с другим сообщением
            (например, ответ или пересылка).
        notify (Optional[bool]): Отправлять ли уведомление о сообщении.
            По умолчанию True.
        parse_mode (Optional[ParseMode]): Режим разбора текста
            (например, Markdown, HTML).
        disable_link_preview (Optional[bool]): Флаг генерации превью.
    """

    def __init__(
        self,
        bot: "Bot",
        chat_id: int | None = None,
        user_id: int | None = None,
        text: str | None = None,
        attachments: list[
            Attachment | InputMedia | InputMediaBuffer | AttachmentUpload
        ]
        | list[Attachments]
        | None = None,
        link: NewMessageLink | None = None,
        parse_mode: ParseMode | None = None,
        *,
        notify: bool | None = None,
        disable_link_preview: bool | None = None,
        sleep_after_input_media: bool | None = True,
    ):
        if text is not None and not (len(text) < 4000):
            raise ValueError("text должен быть меньше 4000 символов")

        super().__init__()
        self.bot = bot
        self.chat_id = chat_id
        self.user_id = user_id
        self.text = text
        self.attachments = attachments
        self.link = link
        self.notify = notify
        self.parse_mode = parse_mode
        self.disable_link_preview = disable_link_preview
        self.sleep_after_input_media = sleep_after_input_media

    async def fetch(self) -> SendedMessage | None:
        """
        Отправляет сообщение с вложениями (если есть),
        с обработкой задержки готовности вложений.

        Возвращает результат отправки или ошибку.

        Возвращаемое значение:
            SendedMessage или Error
        """

        bot = self._ensure_bot()

        params = bot.params.copy()

        json: dict[str, Any] = {"attachments": []}

        if self.chat_id:
            params["chat_id"] = self.chat_id
        elif self.user_id:
            params["user_id"] = self.user_id

        json["text"] = self.text

        has_input_media = False

        if self.attachments:
            for att in self.attachments:
                if isinstance(att, (InputMedia, InputMediaBuffer)):
                    has_input_media = True

                    input_media = await process_input_media(
                        base_connection=self, bot=bot, att=att
                    )
                    json["attachments"].append(input_media.model_dump())
                elif isinstance(att, Attachment) and isinstance(
                    att.payload, AttachmentUpload
                ):
                    json["attachments"].append(att.payload.model_dump())
                else:
                    json["attachments"].append(att.model_dump())

        if self.link is not None:
            json["link"] = self.link.model_dump()

        if self.notify:
            json["notify"] = self.notify

        if self.disable_link_preview:
            json["disable_link_preview"] = self.disable_link_preview

        if self.parse_mode is not None:
            json["format"] = self.parse_mode.value

        if has_input_media and self.sleep_after_input_media:
            await asyncio.sleep(bot.after_input_media_delay)

        response = None
        for attempt in range(self.ATTEMPTS_COUNT):
            try:
                response = await super().request(
                    method=HTTPMethod.POST,
                    path=ApiPath.MESSAGES,
                    model=SendedMessage,
                    params=params,
                    json=json,
                )
            except MaxApiError as e:
                if (
                    isinstance(e.raw, dict)
                    and e.raw.get("code") == "attachment.not.ready"
                ):
                    logger_bot.info(
                        f"Ошибка при отправке загруженного медиа, попытка "
                        f"{attempt + 1}, жду {self.RETRY_DELAY} секунды"
                    )
                    await asyncio.sleep(self.RETRY_DELAY)
                    continue
                else:
                    raise e

            break

        if response is None:
            raise RuntimeError("Не удалось отправить сообщение")

        return cast(SendedMessage | None, response)
