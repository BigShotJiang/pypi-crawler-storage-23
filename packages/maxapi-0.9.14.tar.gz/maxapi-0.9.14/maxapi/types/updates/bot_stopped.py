from typing import TYPE_CHECKING

from ...types.users import User
from .update import Update

if TYPE_CHECKING:
    from ...bot import Bot


class BotStopped(Update):
    """
    Обновление, сигнализирующее об остановке бота.

    Attributes:
        chat_id (int): Идентификатор чата.
        user (User): Пользователь (бот).
        user_locale (Optional[str]): Локаль пользователя.
        payload (Optional[str]): Дополнительные данные.
    """

    chat_id: int
    user: User
    user_locale: str | None = None
    payload: str | None = None

    if TYPE_CHECKING:
        bot: Bot | None  # pyright: ignore[reportGeneralTypeIssues]

    def get_ids(self):
        return self.chat_id, self.user.user_id
