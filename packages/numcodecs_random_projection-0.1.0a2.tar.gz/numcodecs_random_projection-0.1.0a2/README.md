[![image](https://img.shields.io/github/actions/workflow/status/Sidorow/numcodecs-random-projection/ci.yml?branch=main)](https://github.com/Sidorow/numcodecs-random-projection/actions/workflows/ci.yml?query=branch%3Amain)
[![image](https://img.shields.io/pypi/v/numcodecs-random-projection.svg)](https://pypi.python.org/pypi/numcodecs-random-projection)
[![image](https://img.shields.io/pypi/l/numcodecs-random-projection.svg)](https://github.com/Sidorow/numcodecs-random-projection/blob/main/LICENSE)
[![image](https://img.shields.io/pypi/pyversions/numcodecs-random-projection.svg)](https://pypi.python.org/pypi/numcodecs-random-projection)
[![image](https://img.shields.io/github/actions/workflow/status/Sidorow/numcodecs-random-projection/docs.yml?branch=main&label=docs)](https://sidorow.github.io/numcodecs-random-projection/)

# numcodecs-random-projection

`RPCodec` for the [`numcodecs`] buffer compression API.

[`numcodecs`]: https://numcodecs.readthedocs.io/en/stable/

## License

Licensed under the Mozilla Public License, Version 2.0 ([LICENSE](LICENSE) or https://www.mozilla.org/en-US/MPL/2.0/).


## Funding

The `numcodecs-random-projection` package has been developed as part of [ESiWACE3](https://www.esiwace.eu), the third phase of the Centre of Excellence in Simulation of Weather and Climate in Europe.

Funded by the European Union. This work has received funding from the European High Performance Computing Joint Undertaking (JU) under grant agreement No 101093054.
