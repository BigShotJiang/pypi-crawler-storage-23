# -*- coding: utf-8 -*-
"""
Small utils package that stores a few other functions that do not generate DHW
"""
