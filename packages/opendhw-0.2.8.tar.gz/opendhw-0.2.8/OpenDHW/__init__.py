# -*- coding: utf-8 -*-
"""
This package contains the script that stores all function of the DHWcalc package
as well as a utils package.
"""

from OpenDHW.OpenDHW import *
__version__ = '0.2.8'
