# -*- coding: utf-8 -*-
"""
Data for DHW tapping probability
"""