"""Integration tests for Hybrid Search functionality.

These tests require a running Seahorse API instance.
Set the following environment variables:
- SEAHORSE_API_KEY: Your Seahorse API key
- SEAHORSE_BASE_URL: Your Seahorse API base URL
"""

import os
from typing import List

import pytest
import pytest_asyncio

from seahorse_vector_store import (
    DenseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
    SeahorseVectorStore,
    SearchMode,
    SparseSearchConfig,
)

# Skip all tests if environment variables are not set
pytestmark = pytest.mark.skipif(
    not os.environ.get("SEAHORSE_API_KEY") or not os.environ.get("SEAHORSE_BASE_URL"),
    reason="SEAHORSE_API_KEY and SEAHORSE_BASE_URL must be set",
)


@pytest.fixture(scope="class")
def vectorstore() -> SeahorseVectorStore:
    """Create a SeahorseVectorStore instance using environment variables."""
    return SeahorseVectorStore(
        api_key=os.environ["SEAHORSE_API_KEY"],
        base_url=os.environ["SEAHORSE_BASE_URL"],
        use_builtin_embedding=True,
    )


@pytest.fixture(scope="class")
def sample_texts() -> List[str]:
    """Sample texts for testing."""
    return [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with many layers.",
        "Natural language processing enables computers to understand text.",
        "Computer vision allows machines to interpret images.",
        "Reinforcement learning trains agents through rewards.",
    ]


class TestSearchModes:
    """Test different search modes."""

    @pytest.fixture(autouse=True, scope="class")
    def setup_test_data(
        self,
        vectorstore: SeahorseVectorStore,
        sample_texts: List[str],
    ) -> None:
        """Setup test data for all tests in this class."""
        TestSearchModes.vectorstore = vectorstore
        metadatas = [{"category": "ai", "source": "test"} for _ in sample_texts]
        TestSearchModes.ids = vectorstore.add_texts(
            texts=sample_texts, metadatas=metadatas
        )

        yield

        # Cleanup after all tests in this class
        vectorstore.delete(ids=TestSearchModes.ids)

    def test_hybrid_search_default(self) -> None:
        """Test hybrid search is the default mode."""
        docs = self.vectorstore.similarity_search("machine learning", k=3)
        assert 0 < len(docs) <= 3
        for doc in docs:
            assert doc.page_content is not None

    def test_dense_search(self) -> None:
        """Test dense (semantic) search mode."""
        docs = self.vectorstore.similarity_search(
            "artificial intelligence",
            k=3,
            retrieval_mode=SearchMode.DENSE,
        )
        assert 0 < len(docs) <= 3
        for doc in docs:
            assert doc.page_content is not None

    def test_sparse_search(self) -> None:
        """Test sparse (BM25) search mode."""
        docs = self.vectorstore.similarity_search(
            "neural networks",
            k=3,
            retrieval_mode=SearchMode.SPARSE,
        )
        assert 0 < len(docs) <= 3
        for doc in docs:
            assert doc.page_content is not None

    def test_search_with_scores(self) -> None:
        """Test search returns scores correctly."""
        # Dense mode returns distance
        docs_dense = self.vectorstore.similarity_search_with_score(
            "deep learning",
            k=3,
            retrieval_mode=SearchMode.DENSE,
        )
        for doc, score in docs_dense:
            assert isinstance(score, (int, float))

        # Hybrid mode returns score
        docs_hybrid = self.vectorstore.similarity_search_with_score(
            "deep learning",
            k=3,
            retrieval_mode=SearchMode.HYBRID,
        )
        for doc, score in docs_hybrid:
            assert isinstance(score, (int, float))


class TestHybridSearchConfig:
    """Test HybridSearchConfig options."""

    @pytest.fixture(autouse=True, scope="class")
    def setup_test_data(
        self,
        vectorstore: SeahorseVectorStore,
        sample_texts: List[str],
    ) -> None:
        """Setup test data for all tests in this class."""
        TestHybridSearchConfig.vectorstore = vectorstore
        metadatas = [{"category": "ai", "source": "test"} for _ in sample_texts]
        TestHybridSearchConfig.ids = vectorstore.add_texts(
            texts=sample_texts, metadatas=metadatas
        )

        yield

        # Cleanup after all tests in this class
        vectorstore.delete(ids=TestHybridSearchConfig.ids)

    def test_custom_dense_config(self) -> None:
        """Test custom dense search configuration."""
        config = HybridSearchConfig(dense=DenseSearchConfig(ef_search=200))
        docs = self.vectorstore.similarity_search(
            "machine learning",
            k=3,
            retrieval_mode=SearchMode.DENSE,
            hybrid_config=config,
        )
        assert 0 < len(docs) <= 3

    def test_custom_sparse_config(self) -> None:
        """Test custom sparse search configuration."""
        config = HybridSearchConfig(sparse=SparseSearchConfig(k=1.5, b=0.8))
        docs = self.vectorstore.similarity_search(
            "neural networks",
            k=3,
            retrieval_mode=SearchMode.SPARSE,
            hybrid_config=config,
        )
        assert 0 < len(docs) <= 3

    def test_custom_fusion_config(self) -> None:
        """Test custom fusion configuration."""
        # Dense-biased (70% dense, 30% sparse)
        config = HybridSearchConfig(fusion=FusionConfig(alpha=0.7, k=60))
        docs = self.vectorstore.similarity_search(
            "computer vision",
            k=3,
            retrieval_mode=SearchMode.HYBRID,
            hybrid_config=config,
        )
        assert 0 < len(docs) <= 3

    def test_full_custom_config(self) -> None:
        """Test fully customized hybrid search."""
        config = HybridSearchConfig(
            dense=DenseSearchConfig(ef_search=150),
            sparse=SparseSearchConfig(k=1.2, b=0.75),
            fusion=FusionConfig(type="rrf", k=80, alpha=0.6),
        )
        docs = self.vectorstore.similarity_search(
            "reinforcement learning",
            k=3,
            retrieval_mode=SearchMode.HYBRID,
            hybrid_config=config,
        )
        assert 0 < len(docs) <= 3


class TestSearchWithFilters:
    """Test search with metadata filters."""

    @pytest.fixture(autouse=True, scope="class")
    def setup_test_data(
        self,
        vectorstore: SeahorseVectorStore,
        sample_texts: List[str],
    ) -> None:
        """Setup test data for all tests in this class."""
        TestSearchWithFilters.vectorstore = vectorstore
        metadatas = [{"category": "ai", "source": "test.pdf"} for _ in sample_texts]
        TestSearchWithFilters.ids = vectorstore.add_texts(
            texts=sample_texts, metadatas=metadatas
        )

        yield

        # Cleanup after all tests in this class
        vectorstore.delete(ids=TestSearchWithFilters.ids)

    def test_hybrid_search_with_filter(self) -> None:
        """Test hybrid search with metadata filter."""
        docs = self.vectorstore.similarity_search(
            "machine learning",
            k=3,
            filter={"source": "test.pdf"},
            retrieval_mode=SearchMode.HYBRID,
        )
        # Filter may result in fewer results
        assert len(docs) > 0


@pytest.mark.asyncio(loop_scope="class")
class TestAsyncSearch:
    """Test async search methods."""

    @pytest_asyncio.fixture(autouse=True, scope="class")
    async def setup_test_data(
        self,
        vectorstore: SeahorseVectorStore,
        sample_texts: List[str],
    ) -> None:
        """Setup test data for all tests in this class."""
        TestAsyncSearch.vectorstore = vectorstore
        metadatas = [{"category": "ai", "source": "test"} for _ in sample_texts]
        TestAsyncSearch.ids = await vectorstore.aadd_texts(
            texts=sample_texts, metadatas=metadatas
        )

        yield

        # Cleanup after all tests in this class
        await vectorstore.adelete(ids=TestAsyncSearch.ids)

    async def test_async_hybrid_search(self) -> None:
        """Test async hybrid search."""
        docs = await self.vectorstore.asimilarity_search(
            "artificial intelligence",
            k=3,
            retrieval_mode=SearchMode.HYBRID,
        )
        assert 0 < len(docs) <= 3

    async def test_async_search_with_score(self) -> None:
        """Test async search with scores."""
        docs = await self.vectorstore.asimilarity_search_with_score(
            "deep learning",
            k=3,
            retrieval_mode=SearchMode.HYBRID,
        )
        for doc, score in docs:
            assert doc.page_content is not None
            assert isinstance(score, (int, float))


class TestBackwardCompatibility:
    """Test backward compatibility with existing code."""

    @pytest.fixture(autouse=True, scope="class")
    def setup_test_data(
        self,
        vectorstore: SeahorseVectorStore,
        sample_texts: List[str],
    ) -> None:
        """Setup test data for all tests in this class."""
        TestBackwardCompatibility.vectorstore = vectorstore
        metadatas = [{"category": "ai", "source": "test"} for _ in sample_texts]
        TestBackwardCompatibility.ids = vectorstore.add_texts(
            texts=sample_texts, metadatas=metadatas
        )

        yield

        # Cleanup after all tests in this class
        vectorstore.delete(ids=TestBackwardCompatibility.ids)

    def test_ef_search_kwargs(self) -> None:
        """Test ef_search can still be passed via kwargs."""
        docs = self.vectorstore.similarity_search(
            "machine learning",
            k=3,
            ef_search=100,  # Old way
        )
        assert 0 < len(docs) <= 3

    def test_index_name_deprecated(self) -> None:
        """Test index_name parameter shows deprecation warning."""
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            # This should trigger a deprecation warning
            # (only if API credentials are available)
            if os.environ.get("SEAHORSE_API_KEY"):
                _ = SeahorseVectorStore(
                    api_key=os.environ["SEAHORSE_API_KEY"],
                    base_url=os.environ["SEAHORSE_BASE_URL"],
                    index_name="dense_vector",  # Deprecated parameter
                )
                # Check if deprecation warning was raised
                deprecation_warnings = [
                    x for x in w if issubclass(x.category, DeprecationWarning)
                ]
                assert len(deprecation_warnings) >= 1
