"""Integration tests for async operations."""

import pytest
import pytest_asyncio

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
@pytest.mark.asyncio(loop_scope="class")
class TestAsyncSearchOperations:
    """Integration tests for async search operations.

    공용 테스트 데이터를 사용하는 검색 테스트들.
    클래스 시작 시 데이터 삽입, 종료 시 삭제.
    """

    @pytest_asyncio.fixture(scope="class")
    async def setup_test_data(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> tuple:
        """클래스 레벨에서 테스트 데이터를 설정합니다.

        Returns:
            (vectorstore, ids) 튜플
        """
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            use_builtin_embedding=True,
        )

        # Add texts asynchronously
        print("\n📝 Setting up test data for async operations...")
        ids = await vectorstore.aadd_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )
        print(f"✅ Added {len(ids)} documents")

        yield vectorstore, ids

        # Cleanup after all tests in this class
        print("\n🧹 Cleaning up test data...")
        await vectorstore.adelete(ids=ids)
        print(f"✅ Deleted {len(ids)} documents")

    async def test_async_add_and_search(
        self,
        setup_test_data: tuple,
        integration_texts: list,
    ) -> None:
        """Test async add texts and search."""
        vectorstore, ids = setup_test_data

        # Verify add was successful
        assert len(ids) == len(integration_texts)
        assert all(isinstance(id, str) for id in ids)

        # Search asynchronously
        docs = await vectorstore.asimilarity_search(
            query="programming language",
            k=2,
        )

        # Verify search results
        assert 0 < len(docs) <= 2
        assert all(hasattr(doc, "page_content") for doc in docs)

    async def test_async_search_with_score(
        self,
        setup_test_data: tuple,
    ) -> None:
        """Test async search with scores."""
        vectorstore, _ = setup_test_data

        # Search with scores
        docs_and_scores = await vectorstore.asimilarity_search_with_score(
            query="machine learning",
            k=3,
        )

        # Verify
        assert 0 < len(docs_and_scores) <= 3
        for doc, score in docs_and_scores:
            assert hasattr(doc, "page_content")
            assert isinstance(score, float)
            assert score >= 0  # Distance should be non-negative

    async def test_async_search_with_filter(
        self,
        setup_test_data: tuple,
    ) -> None:
        """Test async search with metadata filter."""
        vectorstore, _ = setup_test_data

        # Search with filter
        docs = await vectorstore.asimilarity_search(
            query="test",
            k=5,
            filter={"source": "integration_test"},
        )

        # Verify
        assert len(docs) > 0
        for doc in docs:
            assert doc.metadata.get("source") == "integration_test"


@pytest.mark.integration
@pytest.mark.asyncio
class TestAsyncDeleteOperation:
    """Integration tests for async delete operation.

    삭제 테스트는 별도로 실행 (자체 데이터 사용).
    """

    async def test_async_delete(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test async delete operation."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add a test document
        ids = await vectorstore.aadd_texts(
            texts=["Test document for deletion"],
            metadatas=[{"test": "delete"}],
        )

        # Delete
        result = await vectorstore.adelete(ids=ids)

        # Verify
        assert result is True
