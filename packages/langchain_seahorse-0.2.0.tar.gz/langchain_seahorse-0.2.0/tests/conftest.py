"""Pytest configuration and fixtures."""

import pytest


@pytest.fixture
def mock_api_key() -> str:
    """Mock API key for testing."""
    return "test-api-key-12345"


@pytest.fixture
def mock_base_url() -> str:
    """Mock base URL for testing."""
    return "https://test-table-uuid.api.seahorse.dnotitia.ai"


@pytest.fixture
def sample_texts() -> list:
    """Sample texts for testing."""
    return [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with multiple layers.",
        "Natural language processing enables computers to understand human language.",
    ]


@pytest.fixture
def sample_metadatas() -> list:
    """Sample metadatas for testing."""
    return [
        {"source": "doc1.pdf", "page": 1},
        {"source": "doc2.pdf", "page": 5},
        {"source": "doc3.pdf", "page": 10},
    ]


@pytest.fixture
def sample_embedding() -> list:
    """Sample embedding vector (4096 dimensions - Seahorse default)."""
    return [0.1] * 4096


@pytest.fixture
def mock_coral_response_success() -> dict:
    """Mock successful CoralResponse."""
    return {
        "success": True,
        "code": 200,
        "data": {
            "inserted_row_count": 3,
            "inserted_record_batches": 1,
            "elapsed_time": 0.5,
        },
        "exception": None,
    }


@pytest.fixture
def mock_coral_response_error() -> dict:
    """Mock error CoralResponse."""
    return {
        "success": False,
        "code": 400,
        "data": None,
        "exception": {
            "error_code": 400001,
            "error_message": "Bad Request: Invalid parameter",
        },
    }


@pytest.fixture
def mock_search_results() -> list:
    """Mock search results.

    Contains both 'distance' (for Dense search) and 'score' (for Sparse/Hybrid search).
    """
    return [
        {
            "id": "doc1_hash\x1e0",
            "text": "Machine learning is fun",
            "metadata": '{"source": "doc1.pdf", "page": 1}',
            "distance": 0.15,  # Dense search
            "score": 0.85,  # Sparse/Hybrid search
        },
        {
            "id": "doc2_hash\x1e0",
            "text": "Deep learning is powerful",
            "metadata": '{"source": "doc2.pdf", "page": 2}',
            "distance": 0.25,  # Dense search
            "score": 0.75,  # Sparse/Hybrid search
        },
    ]


@pytest.fixture
def mock_table_schema() -> dict:
    """Mock table schema response from GET /v2/data/schema."""
    return {
        "table_name": "14d0508b-c824-4550-8687-f8bdecd9aad1",
        "columns": [
            {
                "name": "id",
                "type": "STRING",
                "nullable": False,
            },
            {
                "name": "metadata",
                "type": "STRING",
                "nullable": False,
            },
            {
                "name": "text",
                "type": "STRING",
                "nullable": False,
            },
            {
                "name": "dense_vector",
                "type": {
                    "name": "DENSE_VECTOR",
                    "element": "FLOAT32",
                    "dim": 4096,
                },
                "nullable": False,
            },
            {
                "name": "sparse_vector",
                "type": {
                    "name": "SPARSE_VECTOR",
                },
                "nullable": False,
            },
        ],
        "primary_key": ["id"],
        "segmentation": {
            "strategy": "hash",
            "columns": ["id"],
            "buckets": 1,
            "composition": "single",
        },
        "indexes": [
            {
                "type": "diskbased",
                "column": "dense_vector",
                "params": {
                    "space": "ipspace",
                    "ef_construction": 128,
                    "M": 16,
                },
            },
            {
                "type": "inverted",
                "column": "sparse_vector",
                "params": {
                    "sparse_model": "bm25",
                },
            },
        ],
        "configurations": {
            "active_set_size_limit": 50000,
            "max_threads": 8,
        },
        "schema": None,
    }
