"""Unit tests for SeahorseVectorStore."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.vectorstores import SeahorseVectorStore


class TestSeahorseVectorStore:
    """Tests for SeahorseVectorStore class."""

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_builtin_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test initialization with builtin embedding."""
        # Setup mock client for schema retrieval
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        assert vectorstore._use_builtin_embedding is True
        assert vectorstore._embedding is None
        assert vectorstore._index_name == "dense_vector"
        assert vectorstore.dimension == 4096
        mock_client.get_table_schema.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_external_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test initialization with external embedding."""
        mock_embedding = Mock()

        # Setup mock client for schema retrieval
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        assert vectorstore._use_builtin_embedding is False
        assert vectorstore._embedding is mock_embedding
        assert vectorstore.dimension == 4096

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_conflict_error(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test initialization error when both builtin and external embedding specified."""
        mock_embedding = Mock()

        # Setup mock client for schema retrieval
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        with pytest.raises(ValueError, match="Cannot specify both"):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                embedding=mock_embedding,
                use_builtin_embedding=True,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_missing_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test initialization error when external embedding not provided."""
        # Setup mock client for schema retrieval
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        with pytest.raises(ValueError, match="Must provide embedding"):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                use_builtin_embedding=False,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_schema_error(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization error when schema retrieval fails."""
        from seahorse_vector_store.exceptions import SeahorseSchemaError

        # Setup mock client that raises exception on schema retrieval
        mock_client = MagicMock()
        mock_client.get_table_schema.side_effect = Exception("API Error")
        mock_client_class.return_value = mock_client

        with pytest.raises(
            SeahorseSchemaError, match="Failed to retrieve table schema"
        ):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                use_builtin_embedding=True,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_schema_missing_dimension(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization error when dense_vector dimension not found in schema."""
        from seahorse_vector_store.exceptions import SeahorseSchemaError

        # Schema without dense_vector column
        mock_schema = {
            "table_name": "test-table",
            "columns": [
                {"name": "id", "type": "STRING", "nullable": False},
                {"name": "text", "type": "STRING", "nullable": False},
            ],
        }

        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_schema
        mock_client_class.return_value = mock_client

        with pytest.raises(SeahorseSchemaError, match="Could not find dimension"):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                use_builtin_embedding=True,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_builtin(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test add_texts with builtin embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        mock_client._active_set_flush.return_value = {
            "failed": [],
            "flushed": ["seg1"],
            "skipped": [],
        }
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        # Add texts
        ids = vectorstore.add_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_client.insert_with_embedding.assert_called_once()
        # ASF should be called after insertion
        mock_client._active_set_flush.assert_called_once_with(sync_mode="reader-sync")

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_builtin_batches_embedding_requests_to_50_rows(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test add_texts batches /v2/data/embedding requests (max 50 rows)."""
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 50,
        }
        mock_client._active_set_flush.return_value = {
            "failed": [],
            "flushed": ["seg1"],
            "skipped": [],
        }
        mock_client_class.return_value = mock_client

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        texts = [f"text {i}" for i in range(120)]
        metadatas = [{"i": i} for i in range(120)]
        ids = vectorstore.add_texts(texts, metadatas)

        assert len(ids) == 120
        assert mock_client.insert_with_embedding.call_count == 3

        for call in mock_client.insert_with_embedding.call_args_list:
            data = call.kwargs["data"]
            assert len(data) <= 50

        mock_client._active_set_flush.assert_called_once_with(sync_mode="reader-sync")

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_external(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        sample_embedding: list,
        mock_table_schema: dict,
    ) -> None:
        """Test add_texts with external embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        # Now uses insert_with_embedding with include_dense=False
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        mock_client._active_set_flush.return_value = {
            "failed": [],
            "flushed": ["seg1"],
            "skipped": [],
        }
        mock_client_class.return_value = mock_client

        # Setup mock embedding
        mock_embedding = Mock()
        mock_embedding.embed_documents.return_value = [
            sample_embedding,
            sample_embedding,
            sample_embedding,
        ]

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        # Add texts
        ids = vectorstore.add_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_embedding.embed_documents.assert_called_once_with(sample_texts)
        # Now uses insert_with_embedding (Dense in data, Sparse always via builtin)
        mock_client.insert_with_embedding.assert_called_once()
        call_kwargs = mock_client.insert_with_embedding.call_args.kwargs
        assert call_kwargs["include_dense"] is False  # Dense already in data
        # Sparse is always generated via builtin embedding (no include_sparse param)
        # ASF should be called after insertion
        mock_client._active_set_flush.assert_called_once_with(sync_mode="reader-sync")

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_external_batches_embedding_requests_to_50_rows(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test external embedding add_texts batches /v2/data/embedding requests."""
        # Use a small dimension for test performance
        mock_schema = {
            "table_name": "test-table",
            "columns": [
                {"name": "id", "type": "STRING", "nullable": False},
                {"name": "metadata", "type": "STRING", "nullable": False},
                {"name": "text", "type": "STRING", "nullable": False},
                {
                    "name": "dense_vector",
                    "type": {"name": "DENSE_VECTOR", "element": "FLOAT32", "dim": 3},
                    "nullable": False,
                },
            ],
        }

        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_schema
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 50,
        }
        mock_client._active_set_flush.return_value = {
            "failed": [],
            "flushed": ["seg1"],
            "skipped": [],
        }
        mock_client_class.return_value = mock_client

        mock_embedding = Mock()

        texts = [f"text {i}" for i in range(120)]
        metadatas = [{"i": i} for i in range(120)]
        mock_embedding.embed_documents.return_value = [[0.0, 0.0, 0.0] for _ in texts]

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        ids = vectorstore.add_texts(texts, metadatas)

        assert len(ids) == 120
        assert mock_client.insert_with_embedding.call_count == 3

        for call in mock_client.insert_with_embedding.call_args_list:
            assert call.kwargs["include_dense"] is False
            data = call.kwargs["data"]
            assert len(data) <= 50

        mock_client._active_set_flush.assert_called_once_with(sync_mode="reader-sync")

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_similarity_search(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        mock_table_schema: dict,
    ) -> None:
        """Test similarity_search method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        # Now uses client.search() instead of semantic_search
        mock_client.search.return_value = mock_search_results
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Search
        docs = vectorstore.similarity_search("machine learning", k=2)

        # Verify
        assert len(docs) == 2
        assert docs[0].page_content == "Machine learning is fun"
        assert docs[0].metadata["source"] == "doc1.pdf"
        mock_client.search.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_similarity_search_with_filter(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        mock_table_schema: dict,
    ) -> None:
        """Test similarity_search with metadata filter."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        # Now uses client.search() instead of semantic_search
        mock_client.search.return_value = mock_search_results
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Search with filter
        filter_dict = {"source": "doc1.pdf"}
        docs = vectorstore.similarity_search("test", k=2, filter=filter_dict)

        # Verify
        assert len(docs) == 2

        # Check that filter was converted to SQL and passed to API
        call_args = mock_client.search.call_args
        assert call_args.kwargs["filter_sql"] is not None
        assert "metadata LIKE" in call_args.kwargs["filter_sql"]
        # Check that we requested k results (not k*10)
        assert call_args.kwargs["top_k"] == 2

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_delete(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test delete method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        # v2 API에서는 삭제 성공 시 빈 객체 반환
        mock_client.delete_data.return_value = {}
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Delete
        result = vectorstore.delete(ids=["id1", "id2"])

        # Verify - v2에서는 예외 없이 완료되면 True 반환
        assert result is True
        mock_client.delete_data.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_from_texts(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test from_texts class method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        mock_client._active_set_flush.return_value = {
            "failed": [],
            "flushed": ["seg1"],
            "skipped": [],
        }
        mock_client_class.return_value = mock_client

        # Create vectorstore from texts
        vectorstore = SeahorseVectorStore.from_texts(
            texts=sample_texts,
            metadatas=sample_metadatas,
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Verify
        assert isinstance(vectorstore, SeahorseVectorStore)
        assert vectorstore.dimension == 4096
        mock_client.insert_with_embedding.assert_called_once()
        # ASF should be called after insertion
        mock_client._active_set_flush.assert_called_once_with(sync_mode="reader-sync")

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_asf_failure_does_not_affect_insert(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test that ASF failure does not affect insert result."""
        from seahorse_vector_store.exceptions import SeahorseAPIError

        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        # ASF fails
        mock_client._active_set_flush.side_effect = SeahorseAPIError(
            status_code=500,
            error_message="Flush failed",
        )
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        # Add texts should succeed even if ASF fails
        ids = vectorstore.add_texts(sample_texts, sample_metadatas)

        # Verify insertion still succeeded
        assert len(ids) == len(sample_texts)
        mock_client.insert_with_embedding.assert_called_once()
        mock_client._active_set_flush.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_external_dimension_mismatch(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test add_texts raises error when embedding dimension mismatches."""
        from seahorse_vector_store.exceptions import SeahorseDimensionMismatchError

        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        # Setup mock embedding with WRONG dimension (1024 instead of 4096)
        mock_embedding = Mock()
        mock_embedding.embed_documents.return_value = [
            [0.1] * 1024,  # Wrong dimension
            [0.1] * 1024,
            [0.1] * 1024,
        ]

        # Create vectorstore with external embedding
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        # Should raise SeahorseDimensionMismatchError
        with pytest.raises(SeahorseDimensionMismatchError) as exc_info:
            vectorstore.add_texts(sample_texts, sample_metadatas)

        # Dimension should match what's in the schema (4096)
        assert exc_info.value.expected == 4096
        assert exc_info.value.actual == 1024

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_dimension_from_schema(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test that dimension is correctly retrieved from table schema."""
        # Create schema with different dimension (1024)
        custom_schema = {
            "table_name": "custom-table",
            "columns": [
                {"name": "id", "type": "STRING", "nullable": False},
                {"name": "text", "type": "STRING", "nullable": False},
                {
                    "name": "dense_vector",
                    "type": {
                        "name": "DENSE_VECTOR",
                        "element": "FLOAT32",
                        "dim": 1024,  # Different dimension
                    },
                    "nullable": False,
                },
            ],
        }

        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = custom_schema
        mock_client_class.return_value = mock_client

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        # Verify dimension matches schema
        assert vectorstore.dimension == 1024
