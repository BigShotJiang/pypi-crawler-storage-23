"""Unit tests for SeahorseClient."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.client import SeahorseClient
from seahorse_vector_store.exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseRateLimitError,
    SeahorseValidationError,
)


class TestSeahorseClient:
    """Tests for SeahorseClient class."""

    def test_init(self, mock_api_key: str, mock_base_url: str) -> None:
        """Test client initialization."""
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )

        assert client._base_url == mock_base_url
        assert client._api_key == mock_api_key
        assert client._timeout == 30.0
        assert client._max_retries == 3

    def test_init_strips_trailing_slash(self, mock_api_key: str) -> None:
        """Test that base_url trailing slash is stripped."""
        client = SeahorseClient(
            base_url="https://example.com/",
            api_key=mock_api_key,
        )

        assert client._base_url == "https://example.com"

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_unwrap_coral_response_success(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_coral_response_success: dict,
    ) -> None:
        """Test CoralResponse unwrapping for successful response."""
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )

        # Mock response
        mock_response = Mock()
        mock_response.json.return_value = mock_coral_response_success

        result = client._unwrap_coral_response(mock_response)

        assert result == mock_coral_response_success["data"]

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_unwrap_coral_response_error(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_coral_response_error: dict,
    ) -> None:
        """Test CoralResponse unwrapping for error response."""
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )

        # Mock response
        mock_response = Mock()
        mock_response.json.return_value = mock_coral_response_error
        mock_response.status_code = 400

        with pytest.raises(SeahorseAPIError) as exc_info:
            client._unwrap_coral_response(mock_response)

        assert exc_info.value.status_code == 400
        assert exc_info.value.error_code == 400001

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_unwrap_coral_response_auth_error(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test CoralResponse unwrapping for authentication error."""
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )

        # Mock 401 error response
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": False,
            "code": 401,
            "data": None,
            "exception": {
                "error_code": 401,
                "error_message": "Unauthorized",
            },
        }
        mock_response.status_code = 401

        with pytest.raises(SeahorseAuthenticationError):
            client._unwrap_coral_response(mock_response)

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_unwrap_coral_response_rate_limit(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test CoralResponse unwrapping for rate limit error."""
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )

        # Mock 429 error response
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": False,
            "code": 429,
            "data": None,
            "exception": {
                "error_code": 429,
                "error_message": "Rate limit exceeded",
            },
        }
        mock_response.status_code = 429

        with pytest.raises(SeahorseRateLimitError):
            client._unwrap_coral_response(mock_response)


class TestSeahorseClientMethods:
    """Tests for SeahorseClient API methods."""

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_insert_with_embedding(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_coral_response_success: dict,
    ) -> None:
        """Test insert_with_embedding method."""
        # Setup mock
        mock_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = mock_coral_response_success
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_session.request.return_value = mock_response

        mock_httpx_client.return_value = mock_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._session = mock_session

        # Call method
        data = [{"id": "doc1", "text": "Hello", "metadata": "{}"}]
        result = client.insert_with_embedding(
            data=data,
            embedding_source="text",
            dense_column="dense_vector",
            sparse_column="sparse_vector",
        )

        # Verify
        assert result == mock_coral_response_success["data"]
        mock_session.request.assert_called_once()

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_insert_with_embedding_validates_max_rows(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test insert_with_embedding validates max rows (50) before request."""
        mock_session = MagicMock()
        mock_httpx_client.return_value = mock_session

        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._session = mock_session

        data = [{"id": f"doc{i}", "text": "Hello", "metadata": "{}"} for i in range(51)]

        with pytest.raises(SeahorseValidationError, match="up to 50 rows"):
            client.insert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column="dense_vector",
                sparse_column="sparse_vector",
            )

        mock_session.request.assert_not_called()

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_insert_with_embedding_validates_embedding_source_max_bytes(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test insert_with_embedding validates embedding_source max bytes (32KB)."""
        mock_session = MagicMock()
        mock_httpx_client.return_value = mock_session

        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._session = mock_session

        too_large_text = "a" * (32 * 1024 + 1)
        data = [{"id": "doc1", "text": too_large_text, "metadata": "{}"}]

        with pytest.raises(SeahorseValidationError, match="exceeds"):
            client.insert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column="dense_vector",
                sparse_column="sparse_vector",
            )

        mock_session.request.assert_not_called()

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_active_set_flush(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test _active_set_flush private method."""
        # Setup mock
        mock_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "failed": [],
                "flushed": ["v1|hash|single|pk|0|2|"],
                "skipped": [],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_session.request.return_value = mock_response

        mock_httpx_client.return_value = mock_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._session = mock_session

        # Call method
        result = client._active_set_flush(sync_mode="reader-sync")

        # Verify
        assert result["flushed"] == ["v1|hash|single|pk|0|2|"]
        assert result["failed"] == []
        mock_session.request.assert_called_once()

        # Verify the request payload
        call_args = mock_session.request.call_args
        assert call_args[0][0] == "POST"
        assert "/v2/data/active-set-flush" in call_args[0][1]
        assert call_args[1]["json"]["sync_mode"] == "reader-sync"

    @patch("seahorse_vector_store.client.httpx.Client")
    def test_active_set_flush_with_segment_ids(
        self,
        mock_httpx_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test _active_set_flush with segment_ids."""
        # Setup mock
        mock_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "failed": [],
                "flushed": ["seg1"],
                "skipped": [],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_session.request.return_value = mock_response

        mock_httpx_client.return_value = mock_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._session = mock_session

        # Call method with segment_ids
        result = client._active_set_flush(
            sync_mode="reader-sync",
            segment_ids=["seg1"],
        )

        # Verify
        assert result["flushed"] == ["seg1"]
        call_args = mock_session.request.call_args
        assert call_args[1]["json"]["segment_ids"] == ["seg1"]
