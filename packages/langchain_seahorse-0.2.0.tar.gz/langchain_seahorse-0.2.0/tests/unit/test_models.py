"""Unit tests for models module."""

import pytest

from seahorse_vector_store.models import (
    DenseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
    SearchMode,
    SparseSearchConfig,
)


class TestSearchMode:
    """SearchMode enum tests."""

    def test_search_mode_values(self) -> None:
        """Test SearchMode enum values."""
        assert SearchMode.DENSE.value == "dense"
        assert SearchMode.SPARSE.value == "sparse"
        assert SearchMode.HYBRID.value == "hybrid"

    def test_search_mode_is_string_enum(self) -> None:
        """Test SearchMode inherits from str."""
        assert isinstance(SearchMode.DENSE, str)
        assert SearchMode.DENSE == "dense"

    def test_search_mode_from_string(self) -> None:
        """Test creating SearchMode from string."""
        assert SearchMode("dense") == SearchMode.DENSE
        assert SearchMode("sparse") == SearchMode.SPARSE
        assert SearchMode("hybrid") == SearchMode.HYBRID

    def test_search_mode_invalid_value(self) -> None:
        """Test SearchMode with invalid value raises error."""
        with pytest.raises(ValueError):
            SearchMode("invalid")


class TestDenseSearchConfig:
    """DenseSearchConfig tests."""

    def test_default_values(self) -> None:
        """Test default values."""
        config = DenseSearchConfig()
        assert config.column == "dense_vector"
        assert config.ef_search is None

    def test_custom_values(self) -> None:
        """Test custom values."""
        config = DenseSearchConfig(column="my_vector", ef_search=200)
        assert config.column == "my_vector"
        assert config.ef_search == 200

    def test_ef_search_only(self) -> None:
        """Test setting only ef_search."""
        config = DenseSearchConfig(ef_search=100)
        assert config.column == "dense_vector"
        assert config.ef_search == 100


class TestSparseSearchConfig:
    """SparseSearchConfig tests."""

    def test_default_values(self) -> None:
        """Test default values (BM25 defaults)."""
        config = SparseSearchConfig()
        assert config.column == "sparse_vector"
        assert config.k == 1.2
        assert config.b == 0.75

    def test_custom_values(self) -> None:
        """Test custom BM25 values."""
        config = SparseSearchConfig(column="my_sparse", k=1.5, b=0.8)
        assert config.column == "my_sparse"
        assert config.k == 1.5
        assert config.b == 0.8

    def test_bm25_parameter_ranges(self) -> None:
        """Test BM25 parameter edge cases."""
        # b should be 0-1
        config = SparseSearchConfig(b=0.0)
        assert config.b == 0.0

        config = SparseSearchConfig(b=1.0)
        assert config.b == 1.0


class TestFusionConfig:
    """FusionConfig tests."""

    def test_default_values(self) -> None:
        """Test default RRF values."""
        config = FusionConfig()
        assert config.type == "rrf"
        assert config.k == 60
        assert config.alpha == 0.5

    def test_custom_values(self) -> None:
        """Test custom fusion values."""
        config = FusionConfig(type="rrf", k=100, alpha=0.7)
        assert config.type == "rrf"
        assert config.k == 100
        assert config.alpha == 0.7

    def test_alpha_weight(self) -> None:
        """Test alpha weight interpretation."""
        # alpha=0.7 means 70% dense, 30% sparse
        config = FusionConfig(alpha=0.7)
        assert config.alpha == 0.7

        # alpha=0 means pure sparse
        config = FusionConfig(alpha=0.0)
        assert config.alpha == 0.0

        # alpha=1 means pure dense
        config = FusionConfig(alpha=1.0)
        assert config.alpha == 1.0


class TestHybridSearchConfig:
    """HybridSearchConfig tests."""

    def test_default_values(self) -> None:
        """Test default values with automatic initialization."""
        config = HybridSearchConfig()

        # __post_init__ should set defaults
        assert config.dense is not None
        assert config.sparse is not None
        assert config.fusion is not None

        # Check nested defaults
        assert config.dense.column == "dense_vector"
        assert config.sparse.column == "sparse_vector"
        assert config.fusion.type == "rrf"

    def test_custom_dense_config(self) -> None:
        """Test with custom dense config."""
        config = HybridSearchConfig(dense=DenseSearchConfig(ef_search=200))
        assert config.dense is not None
        assert config.dense.ef_search == 200
        # Other configs should have defaults
        assert config.sparse is not None
        assert config.fusion is not None

    def test_custom_sparse_config(self) -> None:
        """Test with custom sparse config."""
        config = HybridSearchConfig(sparse=SparseSearchConfig(k=1.5, b=0.8))
        assert config.sparse is not None
        assert config.sparse.k == 1.5
        assert config.sparse.b == 0.8

    def test_custom_fusion_config(self) -> None:
        """Test with custom fusion config."""
        config = HybridSearchConfig(fusion=FusionConfig(alpha=0.7))
        assert config.fusion is not None
        assert config.fusion.alpha == 0.7

    def test_full_custom_config(self) -> None:
        """Test with all custom configs."""
        config = HybridSearchConfig(
            dense=DenseSearchConfig(column="my_dense", ef_search=150),
            sparse=SparseSearchConfig(column="my_sparse", k=1.8, b=0.6),
            fusion=FusionConfig(type="rrf", k=80, alpha=0.6),
        )

        assert config.dense.column == "my_dense"
        assert config.dense.ef_search == 150
        assert config.sparse.column == "my_sparse"
        assert config.sparse.k == 1.8
        assert config.sparse.b == 0.6
        assert config.fusion.k == 80
        assert config.fusion.alpha == 0.6

    def test_none_values_get_defaults(self) -> None:
        """Test that None values are replaced with defaults."""
        config = HybridSearchConfig(dense=None, sparse=None, fusion=None)

        assert config.dense is not None
        assert config.sparse is not None
        assert config.fusion is not None
