"""Unit tests for search functionality."""

from unittest.mock import MagicMock, patch

import pytest

from seahorse_vector_store.client import SeahorseClient
from seahorse_vector_store.models import (
    DenseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
    SearchMode,
    SparseSearchConfig,
)


class TestSearchPayloadBuilder:
    """Test _build_search_payload method."""

    @pytest.fixture
    def client(self) -> SeahorseClient:
        """Create a SeahorseClient instance."""
        return SeahorseClient(
            base_url="https://test.api.seahorse.dnotitia.ai",
            api_key="test-api-key",
        )

    def test_dense_search_with_text(self, client: SeahorseClient) -> None:
        """Test dense search payload with text query."""
        config = HybridSearchConfig(
            dense=DenseSearchConfig(column="dense_vector", ef_search=100)
        )
        payload = client._build_search_payload(
            query_text="test query",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.DENSE,
            config=config,
            projection=None,
            filter_sql=None,
        )

        assert payload["search_mode"] == "dense"
        assert payload["top_k"] == 5
        assert "dense" in payload
        assert payload["dense"]["column"] == "dense_vector"
        assert payload["dense"]["text"] == ["test query"]
        assert payload["dense"]["parameters"]["ef_search"] == 100
        assert "sparse" not in payload
        assert "fusion" not in payload

    def test_dense_search_with_vector(self, client: SeahorseClient) -> None:
        """Test dense search payload with vector query."""
        config = HybridSearchConfig()
        query_vector = [0.1] * 4096

        payload = client._build_search_payload(
            query_text=None,
            query_vector=query_vector,
            top_k=10,
            search_mode=SearchMode.DENSE,
            config=config,
            projection=None,
            filter_sql=None,
        )

        assert payload["search_mode"] == "dense"
        assert "dense" in payload
        assert payload["dense"]["vector"] == [query_vector]
        assert "text" not in payload["dense"]

    def test_sparse_search_with_text(self, client: SeahorseClient) -> None:
        """Test sparse search payload with text query."""
        config = HybridSearchConfig(
            sparse=SparseSearchConfig(column="sparse_vector", k=1.5, b=0.8)
        )
        payload = client._build_search_payload(
            query_text="test query",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.SPARSE,
            config=config,
            projection=None,
            filter_sql=None,
        )

        assert payload["search_mode"] == "sparse"
        assert "sparse" in payload
        assert payload["sparse"]["column"] == "sparse_vector"
        assert payload["sparse"]["text"] == ["test query"]
        assert payload["sparse"]["parameters"]["k"] == 1.5
        assert payload["sparse"]["parameters"]["b"] == 0.8
        assert "dense" not in payload
        assert "fusion" not in payload

    def test_sparse_search_requires_text(self, client: SeahorseClient) -> None:
        """Test sparse search raises error without text query."""
        config = HybridSearchConfig()

        with pytest.raises(ValueError, match="Sparse search requires query_text"):
            client._build_search_payload(
                query_text=None,
                query_vector=[0.1] * 4096,
                top_k=5,
                search_mode=SearchMode.SPARSE,
                config=config,
                projection=None,
                filter_sql=None,
            )

    def test_hybrid_search_with_text(self, client: SeahorseClient) -> None:
        """Test hybrid search payload with text query."""
        config = HybridSearchConfig(
            dense=DenseSearchConfig(ef_search=150),
            sparse=SparseSearchConfig(k=1.2, b=0.75),
            fusion=FusionConfig(k=60, alpha=0.6),
        )
        payload = client._build_search_payload(
            query_text="test query",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.HYBRID,
            config=config,
            projection=None,
            filter_sql=None,
        )

        assert payload["search_mode"] == "hybrid"
        assert "dense" in payload
        assert "sparse" in payload
        assert "fusion" in payload

        # Dense config
        assert payload["dense"]["text"] == ["test query"]
        assert payload["dense"]["parameters"]["ef_search"] == 150

        # Sparse config
        assert payload["sparse"]["text"] == ["test query"]
        assert payload["sparse"]["parameters"]["k"] == 1.2
        assert payload["sparse"]["parameters"]["b"] == 0.75

        # Fusion config
        assert payload["fusion"]["type"] == "rrf"
        assert payload["fusion"]["parameters"]["k"] == 60
        assert payload["fusion"]["parameters"]["alpha"] == 0.6

    def test_hybrid_search_with_vector_and_text(self, client: SeahorseClient) -> None:
        """Test hybrid search with both vector and text query."""
        config = HybridSearchConfig()
        query_vector = [0.1] * 4096

        payload = client._build_search_payload(
            query_text="test query",
            query_vector=query_vector,
            top_k=5,
            search_mode=SearchMode.HYBRID,
            config=config,
            projection=None,
            filter_sql=None,
        )

        # Dense uses vector, Sparse uses text
        assert payload["dense"]["vector"] == [query_vector]
        assert payload["sparse"]["text"] == ["test query"]

    def test_hybrid_search_requires_text_for_sparse(
        self, client: SeahorseClient
    ) -> None:
        """Test hybrid search requires text for sparse part."""
        config = HybridSearchConfig()

        with pytest.raises(ValueError, match="Sparse search requires query_text"):
            client._build_search_payload(
                query_text=None,
                query_vector=[0.1] * 4096,
                top_k=5,
                search_mode=SearchMode.HYBRID,
                config=config,
                projection=None,
                filter_sql=None,
            )

    def test_filter_sql_included(self, client: SeahorseClient) -> None:
        """Test filter SQL is included in payload."""
        config = HybridSearchConfig()
        payload = client._build_search_payload(
            query_text="test query",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.DENSE,
            config=config,
            projection=None,
            filter_sql="source = 'arxiv'",
        )

        assert payload["filter"] == "source = 'arxiv'"

    def test_projection_default_by_mode(self, client: SeahorseClient) -> None:
        """Test default projection varies by search mode."""
        config = HybridSearchConfig()

        # Dense mode
        payload_dense = client._build_search_payload(
            query_text="test",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.DENSE,
            config=config,
            projection=None,
            filter_sql=None,
        )
        assert "distance" in payload_dense["projection"]

        # Sparse mode
        payload_sparse = client._build_search_payload(
            query_text="test",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.SPARSE,
            config=config,
            projection=None,
            filter_sql=None,
        )
        assert "score" in payload_sparse["projection"]

        # Hybrid mode
        payload_hybrid = client._build_search_payload(
            query_text="test",
            query_vector=None,
            top_k=5,
            search_mode=SearchMode.HYBRID,
            config=config,
            projection=None,
            filter_sql=None,
        )
        assert "score" in payload_hybrid["projection"]


class TestClientSearch:
    """Test search() method."""

    @pytest.fixture
    def client(self) -> SeahorseClient:
        """Create a SeahorseClient instance."""
        return SeahorseClient(
            base_url="https://test.api.seahorse.dnotitia.ai",
            api_key="test-api-key",
        )

    def test_search_requires_query(self, client: SeahorseClient) -> None:
        """Test search raises error without query."""
        with pytest.raises(
            ValueError, match="Either query_text or query_vector must be provided"
        ):
            client.search()

    @patch.object(SeahorseClient, "_request")
    def test_search_default_mode_is_hybrid(
        self, mock_request: MagicMock, client: SeahorseClient
    ) -> None:
        """Test default search mode is hybrid."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "success": True,
            "data": {"data": [[{"id": "1", "text": "test", "score": 0.9}]]},
        }
        mock_request.return_value = mock_response

        client.search(query_text="test query")

        # Check that the payload has hybrid mode
        call_args = mock_request.call_args
        payload = call_args.kwargs["json"]
        assert payload["search_mode"] == "hybrid"

    @patch.object(SeahorseClient, "_request")
    def test_search_with_dense_mode(
        self, mock_request: MagicMock, client: SeahorseClient
    ) -> None:
        """Test search with dense mode."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "success": True,
            "data": {"data": [[{"id": "1", "text": "test", "distance": 0.1}]]},
        }
        mock_request.return_value = mock_response

        results = client.search(
            query_text="test query",
            search_mode=SearchMode.DENSE,
        )

        call_args = mock_request.call_args
        payload = call_args.kwargs["json"]
        assert payload["search_mode"] == "dense"
        assert len(results) == 1

    @patch.object(SeahorseClient, "_request")
    def test_search_with_config(
        self, mock_request: MagicMock, client: SeahorseClient
    ) -> None:
        """Test search with custom config."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "success": True,
            "data": {"data": [[{"id": "1", "text": "test", "score": 0.9}]]},
        }
        mock_request.return_value = mock_response

        config = HybridSearchConfig(
            dense=DenseSearchConfig(ef_search=200),
            fusion=FusionConfig(alpha=0.8),
        )

        client.search(
            query_text="test query",
            search_mode=SearchMode.HYBRID,
            config=config,
        )

        call_args = mock_request.call_args
        payload = call_args.kwargs["json"]
        assert payload["dense"]["parameters"]["ef_search"] == 200
        assert payload["fusion"]["parameters"]["alpha"] == 0.8
