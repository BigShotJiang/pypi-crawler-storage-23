"""Unit tests for SeahorseClient async methods."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.client import SeahorseClient
from seahorse_vector_store.exceptions import SeahorseValidationError


class TestSeahorseClientAsync:
    """Tests for SeahorseClient async methods."""

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_ainsert_with_embedding(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_coral_response_success: dict,
    ) -> None:
        """Test async insert_with_embedding method."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = mock_coral_response_success
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        # Make request return a coroutine
        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method
        data = [{"id": "doc1", "text": "Hello", "metadata": "{}"}]
        result = await client.ainsert_with_embedding(
            data=data,
            embedding_source="text",
            dense_column="dense_vector",
            sparse_column="sparse_vector",
        )

        # Verify
        assert result == mock_coral_response_success["data"]

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_ainsert_with_embedding_validates_max_rows(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async insert validates max rows (50) before request."""
        mock_async_session = MagicMock()
        mock_async_session.request = MagicMock()
        mock_httpx_async_client.return_value = mock_async_session

        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        data = [{"id": f"doc{i}", "text": "Hello", "metadata": "{}"} for i in range(51)]

        with pytest.raises(SeahorseValidationError, match="up to 50 rows"):
            await client.ainsert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column="dense_vector",
                sparse_column="sparse_vector",
            )

        assert not mock_async_session.request.called

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_ainsert_with_embedding_validates_embedding_source_max_bytes(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async insert validates embedding_source max bytes (32KB)."""
        mock_async_session = MagicMock()
        mock_async_session.request = MagicMock()
        mock_httpx_async_client.return_value = mock_async_session

        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        too_large_text = "a" * (32 * 1024 + 1)
        data = [{"id": "doc1", "text": too_large_text, "metadata": "{}"}]

        with pytest.raises(SeahorseValidationError, match="exceeds"):
            await client.ainsert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column="dense_vector",
                sparse_column="sparse_vector",
            )

        assert not mock_async_session.request.called

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_asemantic_search(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test async semantic_search method."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "num_resultsets": 1,
                "data": [mock_search_results],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method
        results = await client.asemantic_search(
            query="test query",
            top_k=5,
            index_name="embedding",
        )

        # Verify
        assert len(results) == 2
        assert results == mock_search_results

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_avector_search(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test async vector_search method."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "num_resultsets": 1,
                "data": [mock_search_results],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method
        query_vector = [0.1] * 1024
        results = await client.avector_search(
            index_name="embedding",
            query_vectors=[query_vector],
            top_k=5,
        )

        # Verify
        assert len(results) == 1
        assert results[0] == mock_search_results

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_adelete_data(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async delete_data method."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        # v2 API에서는 삭제 성공 시 빈 객체 반환
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {},
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method
        result = await client.adelete_data(delete_condition="id = 'test'")

        # Verify - v2에서는 빈 객체 반환
        assert result == {}

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_aactive_set_flush(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async _aactive_set_flush private method."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "failed": [],
                "flushed": ["v1|hash|single|pk|0|2|"],
                "skipped": [],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method
        result = await client._aactive_set_flush(sync_mode="reader-sync")

        # Verify
        assert result["flushed"] == ["v1|hash|single|pk|0|2|"]
        assert result["failed"] == []

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_aactive_set_flush_with_segment_ids(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async _aactive_set_flush with segment_ids."""
        # Setup mock
        mock_async_session = MagicMock()
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {
                "failed": [],
                "flushed": ["seg1"],
                "skipped": [],
            },
        }
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
        )
        client._async_session = mock_async_session

        # Call method with segment_ids
        result = await client._aactive_set_flush(
            sync_mode="reader-sync",
            segment_ids=["seg1"],
        )

        # Verify
        assert result["flushed"] == ["seg1"]

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.client.httpx.AsyncClient")
    async def test_arequest_retry_logic(
        self,
        mock_httpx_async_client: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async request retry logic."""
        # Setup mock
        mock_async_session = MagicMock()

        # First call fails with 500, second succeeds
        call_count = 0

        async def mock_request(*args, **kwargs):
            nonlocal call_count
            call_count += 1

            if call_count == 1:
                mock_response = Mock()
                mock_response.status_code = 500
                mock_response.text = "Server error"
                return mock_response
            else:
                mock_response = Mock()
                mock_response.status_code = 200
                mock_response.json.return_value = {
                    "success": True,
                    "code": 200,
                    "data": {"result": "ok"},
                }
                mock_response.raise_for_status = Mock()
                return mock_response

        mock_async_session.request = mock_request
        mock_httpx_async_client.return_value = mock_async_session

        # Create client with max_retries=3
        client = SeahorseClient(
            base_url=mock_base_url,
            api_key=mock_api_key,
            max_retries=3,
        )
        client._async_session = mock_async_session

        # Call method
        response = await client._arequest("GET", "/test")

        # Verify - should have retried and succeeded
        assert response.status_code == 200
        assert call_count == 2  # Failed once, then succeeded
