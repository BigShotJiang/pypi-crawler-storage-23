"""Unit tests for SeahorseVectorStore async methods."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.vectorstores import SeahorseVectorStore


class TestSeahorseVectorStoreAsync:
    """Tests for SeahorseVectorStore async methods."""

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_builtin(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test async add_texts with builtin embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_insert(*args, **kwargs):
            return {"inserted_row_count": 3}

        async def mock_asf(*args, **kwargs):
            return {"failed": [], "flushed": ["seg1"], "skipped": []}

        mock_client.ainsert_with_embedding = mock_insert
        mock_client._aactive_set_flush = mock_asf
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        # Add texts
        ids = await vectorstore.aadd_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        assert all(isinstance(id, str) for id in ids)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_builtin_batches_embedding_requests_to_50_rows(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test async add_texts batches /v2/data/embedding requests (max 50 rows)."""
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        insert_calls = []

        async def mock_insert(*args, **kwargs):
            insert_calls.append(kwargs)
            return {"inserted_row_count": len(kwargs.get("data", []))}

        asf_calls = []

        async def mock_asf(*args, **kwargs):
            asf_calls.append(kwargs)
            return {"failed": [], "flushed": ["seg1"], "skipped": []}

        mock_client.ainsert_with_embedding = mock_insert
        mock_client._aactive_set_flush = mock_asf
        mock_client_class.return_value = mock_client

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        texts = [f"text {i}" for i in range(120)]
        metadatas = [{"i": i} for i in range(120)]
        ids = await vectorstore.aadd_texts(texts, metadatas)

        assert len(ids) == 120
        assert len(insert_calls) == 3
        assert len(asf_calls) == 1
        assert asf_calls[0]["sync_mode"] == "reader-sync"
        assert all(len(c["data"]) <= 50 for c in insert_calls)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_external(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        sample_embedding: list,
        mock_table_schema: dict,
    ) -> None:
        """Test async add_texts with external embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        # Now uses ainsert_with_embedding with include_dense=False
        async def mock_ainsert_with_embedding(*args, **kwargs):
            return {"inserted_row_count": 3}

        async def mock_asf(*args, **kwargs):
            return {"failed": [], "flushed": ["seg1"], "skipped": []}

        mock_client.ainsert_with_embedding = mock_ainsert_with_embedding
        mock_client._aactive_set_flush = mock_asf
        mock_client_class.return_value = mock_client

        # Setup mock embedding
        mock_embedding = Mock()
        mock_embedding.embed_documents.return_value = [
            sample_embedding,
            sample_embedding,
            sample_embedding,
        ]

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        # Add texts
        ids = await vectorstore.aadd_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_embedding.embed_documents.assert_called_once_with(sample_texts)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_external_batches_embedding_requests_to_50_rows(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async external embedding add_texts batches /v2/data/embedding requests."""
        mock_schema = {
            "table_name": "test-table",
            "columns": [
                {"name": "id", "type": "STRING", "nullable": False},
                {"name": "metadata", "type": "STRING", "nullable": False},
                {"name": "text", "type": "STRING", "nullable": False},
                {
                    "name": "dense_vector",
                    "type": {"name": "DENSE_VECTOR", "element": "FLOAT32", "dim": 3},
                    "nullable": False,
                },
            ],
        }

        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_schema

        insert_calls = []

        async def mock_insert(*args, **kwargs):
            insert_calls.append(kwargs)
            return {"inserted_row_count": len(kwargs.get("data", []))}

        asf_calls = []

        async def mock_asf(*args, **kwargs):
            asf_calls.append(kwargs)
            return {"failed": [], "flushed": ["seg1"], "skipped": []}

        mock_client.ainsert_with_embedding = mock_insert
        mock_client._aactive_set_flush = mock_asf
        mock_client_class.return_value = mock_client

        mock_embedding = Mock()
        texts = [f"text {i}" for i in range(120)]
        metadatas = [{"i": i} for i in range(120)]
        mock_embedding.embed_documents.return_value = [[0.0, 0.0, 0.0] for _ in texts]

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        ids = await vectorstore.aadd_texts(texts, metadatas)

        assert len(ids) == 120
        assert len(insert_calls) == 3
        assert len(asf_calls) == 1
        assert asf_calls[0]["sync_mode"] == "reader-sync"
        assert all(c["include_dense"] is False for c in insert_calls)
        assert all(len(c["data"]) <= 50 for c in insert_calls)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_asf_failure_does_not_affect_insert(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        mock_table_schema: dict,
    ) -> None:
        """Test that async ASF failure does not affect insert result."""
        from seahorse_vector_store.exceptions import SeahorseAPIError

        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_insert(*args, **kwargs):
            return {"inserted_row_count": 3}

        async def mock_asf_fail(*args, **kwargs):
            raise SeahorseAPIError(
                status_code=500,
                error_message="Flush failed",
            )

        mock_client.ainsert_with_embedding = mock_insert
        mock_client._aactive_set_flush = mock_asf_fail
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        # Add texts should succeed even if ASF fails
        ids = await vectorstore.aadd_texts(sample_texts, sample_metadatas)

        # Verify insertion still succeeded
        assert len(ids) == len(sample_texts)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        mock_table_schema: dict,
    ) -> None:
        """Test async similarity_search method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_asearch(*args, **kwargs):
            return mock_search_results

        # Now uses client.asearch() instead of asemantic_search
        mock_client.asearch = mock_asearch
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Search
        docs = await vectorstore.asimilarity_search("machine learning", k=2)

        # Verify
        assert len(docs) == 2
        assert docs[0].page_content == "Machine learning is fun"
        assert docs[0].metadata["source"] == "doc1.pdf"

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search_with_score(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        mock_table_schema: dict,
    ) -> None:
        """Test async similarity_search_with_score method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_asearch(*args, **kwargs):
            return mock_search_results

        # Now uses client.asearch() instead of asemantic_search
        mock_client.asearch = mock_asearch
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Search with score
        docs_and_scores = await vectorstore.asimilarity_search_with_score(
            "test query", k=2
        )

        # Verify
        assert len(docs_and_scores) == 2
        doc, score = docs_and_scores[0]
        assert hasattr(doc, "page_content")
        assert isinstance(score, float)
        # Default mode is HYBRID, which uses 'score' field
        assert score == 0.85

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search_by_vector(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        sample_embedding: list,
        mock_table_schema: dict,
    ) -> None:
        """Test async similarity_search_by_vector method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_vector_search(*args, **kwargs):
            return [mock_search_results]

        mock_client.avector_search = mock_vector_search
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Search by vector
        docs = await vectorstore.asimilarity_search_by_vector(sample_embedding, k=2)

        # Verify
        assert len(docs) == 2
        assert all(hasattr(doc, "page_content") for doc in docs)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_adelete(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test async delete method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema

        async def mock_delete(*args, **kwargs):
            # v2 API에서는 삭제 성공 시 빈 객체 반환
            return {}

        mock_client.adelete_data = mock_delete
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Delete
        result = await vectorstore.adelete(ids=["id1", "id2"])

        # Verify - v2에서는 예외 없이 완료되면 True 반환
        assert result is True

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_adelete_empty_list(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_table_schema: dict,
    ) -> None:
        """Test async delete with empty ID list."""
        mock_client = MagicMock()
        mock_client.get_table_schema.return_value = mock_table_schema
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Delete with empty list
        result = await vectorstore.adelete(ids=[])

        # Should return None
        assert result is None
