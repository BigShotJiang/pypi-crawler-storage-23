"""Seahorse Vector Store - LangChain VectorStore integration for Seahorse API Gateway.

Supports Dense, Sparse, and Hybrid (RRF) search modes.
"""

from .exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseDimensionMismatchError,
    SeahorseException,
    SeahorseRateLimitError,
    SeahorseSchemaError,
    SeahorseValidationError,
)
from .models import (
    DenseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
    SearchMode,
    SparseSearchConfig,
)
from .vectorstores import SeahorseVectorStore

__version__ = "0.2.0"

__all__ = [
    # VectorStore
    "SeahorseVectorStore",
    # Search Mode & Config
    "SearchMode",
    "DenseSearchConfig",
    "SparseSearchConfig",
    "FusionConfig",
    "HybridSearchConfig",
    # Exceptions
    "SeahorseException",
    "SeahorseAPIError",
    "SeahorseAuthenticationError",
    "SeahorseRateLimitError",
    "SeahorseSchemaError",
    "SeahorseValidationError",
    "SeahorseDimensionMismatchError",
]
